

# Generated at 2022-06-11 17:35:47.985894
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import tempfile
    from ansible_collections.ansible.test.unit.test_collection_loader import _AnsibleCollectionPkgLoaderBase

    tmpdir = tempfile.mkdtemp()

    # a loader for a non-package
    loader_non_package = _AnsibleCollectionPkgLoaderBase(
        'ansible.test', [tmpdir],
    )

    # a loader for a package
    loader_package = _AnsibleCollectionPkgLoaderBase(
        'ansible.test', [tmpdir],
    )


# Generated at 2022-06-11 17:35:52.144438
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # note: a valid, but empty, meta/main.yml is required for this to succeed
    test_data = dict(
        collection_name='test.dummy_collections',
        fullname='ansible_collections.test.dummy_collections',
        expected_result=dict(
            collection_name='test.dummy_collections',
            collection_path='/root/.ansible/collections/ansible_collections/test/dummy_collections',
            collection_meta=dict(),
        )
    )
    result = _AnsibleCollectionPkgLoader_load_module_impl(test_data)
    assert result == test_data['expected_result']



# Generated at 2022-06-11 17:36:00.110377
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from tempfile import gettempdir
    from shutil import rmtree
    _tempdir = gettempdir()
    _temp_path = os.path.join(_tempdir, 'ansible_collections')

# Generated at 2022-06-11 17:36:01.810389
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    _load_module = _AnsibleCollectionPkgLoaderBase.load_module
    assert callable(_load_module)
    # TODO: implement your test here
    # raise NotImplementedError()

# Generated at 2022-06-11 17:36:12.366622
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    """
      GIVEN: A sample collection with a plugin.
      WHEN:  The method is called with the sample collection
      THEN:  The source code is returned.
    """
    tmp_dir = tempfile.mkdtemp()
    collection_path = os.path.join(tmp_dir, 'ansible_collections')
    os.makedirs(os.path.join(collection_path, 'somens', 'plugins', 'test'))
    with open(os.path.join(collection_path, 'somens', 'plugins', 'test', '__init__.py'), 'w') as f:
        f.write('#!/usr/bin/env python\n"""Ansible collection somens"""')


# Generated at 2022-06-11 17:36:15.523862
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class MockClass:
        pass

    assert 'MockClass(path=None)' == str(MockClass())


# unit test for method _get_filefinder_path_hook of class _AnsiblePathHookFinder

# Generated at 2022-06-11 17:36:22.714092
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    plugin_types = [
        "action",
        "become",
        "cache",
        "callback",
        "cliconf",
        "connection",
        "doc_fragments",
        "filter",
        "httpapi",
        "inventory",
        "lookup",
        "module_utils",
        "modules",
        "netconf",
        "playbook",
        "role",
        "shell",
        "strategy",
        "terminal",
        "test",
        "vars"]

    # Testing 2 digit to keep shorter
    # Test format: "input_value" : "expected_result"
    # Test dict is a list of tuples

# Generated at 2022-06-11 17:36:32.788479
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase('ns1.ns2.pkg1', path_list=['/path/to/somewhere'])
    pkg_dir = '/path/to/somewhere/ns1/ns2/pkg1/'
    loader._subpackage_search_paths = [pkg_dir]

    # If a file is found, return the file data
    with patch('os.path.isfile', return_value=True):
        with patch('builtins.open', mock_open(read_data='FILE_DATA')) as mocked_open:
            assert loader.get_source('ns1.ns2.pkg1') == 'FILE_DATA'

# Generated at 2022-06-11 17:36:41.607038
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class MetaYmlToDict(object):
        def __init__(self, file_path, file_name):
           self.file_path = file_path
           self.file_name =file_name

        def get_runtime_yml(self):
            if os.path.isfile(self.file_path):
                with open(self.file_path, 'rb') as fd:
                    raw_routing = fd.read()
            else:
                raw_routing = ''
            return raw_routing
    class DummyCollectionPath(list):
        def append(self, value):
            return self.append(value)

    # Case 1: Success case, testing with valid input
    module_name = "dummy_module"
    module_type = "dummy_module_type"
    sub_module

# Generated at 2022-06-11 17:36:47.897463
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:37:19.682329
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    #nada
    pass


# Generated at 2022-06-11 17:37:30.419593
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.utils.collection_loader import _AnsibleCollectionRootPkgLoader
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_sub_dir = tempfile.mkdtemp(dir=tmp_dir)

    with tempfile.NamedTemporaryFile(delete=False, prefix='__init__', suffix='.py', dir=tmp_sub_dir):
        pass

    # Create an instance of _AnsiblePathHookFinder
    finder = _AnsiblePathHookFinder('', tmp_dir)

    # Try to find a module in the temp directory
    loader = finder.find_module('tempfile')

    # Check the correct loader was found
    assert loader == None

    # Try to find the __init__ module in the tmp_sub_dir

# Generated at 2022-06-11 17:37:36.941333
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import inspect

    def _test_helper(module_name, mock_path, expect_modules):
        mock_importer_cls = type('MockImporter', (_AnsibleCollectionPkgLoaderBase,), {})
        mock_importer_cls.__module__ = module_name
        mock_importer_cls_iter_modules_args, _, _, _ = inspect.getargspec(mock_importer_cls.iter_modules.__func__)
        mock_importer_cls_iter_modules_args.pop()
        mock_importer_cls_iter_modules_args.insert(0, 'self')

# Generated at 2022-06-11 17:37:48.114697
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from importlib._bootstrap_external import SourceFileLoader
    path = './tests/unit/test_import_from_path/test_data/test_load_module_data/ansible'
    fullname = 'ansible'
    module_name = 'collection_module'
    file_path = os.path.join(os.getcwd(), path, module_name) + '.py'
    source_code = open(file_path, 'rb').read()
    code_obj = compile(source=source_code, filename=file_path, mode='exec', flags=0, dont_inherit=True)
    loader = SourceFileLoader(module_name, file_path)
    module = sys.modules[module_name] = loader.load_module()

    # test return module

# Generated at 2022-06-11 17:37:55.848635
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    """Module-level test for the loader class, which is abstract and therefor cannot be tested by Ansiballz."""

    class _EmptyArgsLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            assert self._split_name == ['ansible_collections', 'ns1', 'ns2']
            assert self._rpart_name == ('ansible_collections.ns1', '.', 'ns2')
            assert self._parent_package_name == 'ansible_collections.ns1'
            assert self._package_to_load == 'ns2'

    class _ValidArgsLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            assert self._split_name == ['ansible_collections', 'ns1', 'ns2']
            assert self._

# Generated at 2022-06-11 17:38:04.535036
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    print('test_AnsibleCollectionRef___repr__')
    func = AnsibleCollectionRef.__repr__
    assert func(AnsibleCollectionRef(u'ansible.builtin', u'', u'ping', u'module')) == 'AnsibleCollectionRef(collection=u\'ansible.builtin\', subdirs=u\'\', resource=u\'ping\')'
    assert func(AnsibleCollectionRef(u'ansible.builtin', u'', u'ping', u'module')) != 'AnsibleCollectionRef(collection=\'ansible.builtin\', subdirs=\'\', resource=\'ping\')'

# Generated at 2022-06-11 17:38:15.272000
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    testdir = tempfile.TemporaryDirectory()


# Generated at 2022-06-11 17:38:26.174698
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """
    Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase.
    :return: None.
    """

    # Test case: Test with absolute path.
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.test_namespace.test_collection", ["/root/collections"])
    assert loader._AnsibleCollectionPkgLoaderBase__init__("ansible_collections.test_namespace.test_collection", ["/root/collections"]) is None
    path = "/root/collections/ansible_collections/test_namespace/test_collection/__init__.py"
    assert loader.get_data(path) == b"# empty package\n"

    # Test case: Test with relative path.
    # Expected result: Exception.

# Generated at 2022-06-11 17:38:28.901500
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    assert _AnsibleCollectionPkgLoaderBase("ansible_collections.coll_name.ns").get_data("/some/path/to/module.py") == None


# Generated at 2022-06-11 17:38:30.085260
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    pass


# Generated at 2022-06-11 17:39:16.233480
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref = AnsibleCollectionRef.try_parse_fqcr('chrome.chromedriver', 'role')
    assert ref == None

    ref = AnsibleCollectionRef.try_parse_fqcr('na.na.chrome.chromedriver', 'role')
    assert ref == None

    ref = AnsibleCollectionRef.try_parse_fqcr('na.na.chrome.chromedriver', 'role')
    assert ref == None

    ref = AnsibleCollectionRef.try_parse_fqcr('na.na.chrome.chromedriver', 'role')
    assert ref == None

    ref = AnsibleCollectionRef.try_parse_fqcr('na.na.chrome.chromedriver', 'role')
    assert ref == None


# Generated at 2022-06-11 17:39:19.182691
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.network.ios.ios_system', ['/usr/local/share/ansible/collections'])
    assert loader


# Generated at 2022-06-11 17:39:26.545777
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    cf = _AnsibleCollectionFinder()
    assert type(cf) == _AnsibleCollectionFinder
    assert type(cf._ansible_pkg_path) == str
    assert type(cf._n_configured_paths) == list
    assert type(cf._n_cached_collection_paths) == type(None)
    assert type(cf._n_cached_collection_qualified_paths) == type(None)
    assert type(cf._n_playbook_paths) == list


# Generated at 2022-06-11 17:39:34.450840
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.collections import AnsibleCollectionLoader

    # the path given must be the fullname of a valid python module
    with pytest.raises(ValueError) as excinfo:
        acp = _AnsibleCollectionPkgLoaderBase('')
        acp.get_code('')

    # the fullname given must match the loader's fullname
    with pytest.raises(ValueError) as excinfo:
        fullname = 'ansible.plugins.action.ping'
        acp = _AnsibleCollectionPkgLoaderBase(fullname)
        acp.get_code('ansible.a')

    # test the actual path (to be sure the code is in our test path)

# Generated at 2022-06-11 17:39:42.572919
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    with strip_outer_quotes(_AnsibleInternalRedirectLoader('ansible.module_utils.basic', 'test')._redirect) == 'ansible.module_utils._text' and \
         pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.module_utils.basic', 'test')
    # TODO: work out how to mock out builtin metadata properly
    with patch('ansible.utils.collection_loader.builtin_collection_metadata', {'plugin_routing': {'import_redirection': {'ansible.module_utils.basic': {'redirect': 'ansible.module_utils._text'}}, 'module_utils': {'ansible.module_utils._text': {'redirect': 'any.ansible.module_utils._text'}}}}):
        assert _

# Generated at 2022-06-11 17:39:50.426518
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # Parameters:
    # 1. collection_name : candidate collection name to validate
    # 2. expected_result : Expected result
    test_params = [
        ('one.two', True),
        ('one2.two2', True),
        ('one.two.three', False),
        ('one', False),
        ('1.2', False),
        ('one.two.three', False),
        ('as.df', True),
        ('asdf', False),
        ('a b.c', False),
        ('as.b c', False),
        ('a-b.c', False),
        ('as.b-c', False)
    ]


# Generated at 2022-06-11 17:40:02.078095
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:40:12.147899
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from sys import modules
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader as _AnsibleCollectionPkgLoader
    from ansible.module_utils.six import PY3
    if not PY3:
        from mock import patch
    # Test if the load_module method returns an object of type ModuleType
    path = '/usr/share/ansible/collections/ansible_collections/test/plugins'
    fullname = 'ansible_collections.test.plugins'
    _AnsibleCollectionPkgLoader_load_module = _AnsibleCollectionPkgLoader(path=path, package_to_load='plugins', module_name='plugins')
    collection_module = _AnsibleCollectionPkgLoader_load_module.load_module(fullname)

# Generated at 2022-06-11 17:40:22.843196
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Task: setup
    from ansible.collections.community.general.plugins.module_utils._text import to_native
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    import sys
    import __builtin__ as builtins

    def _set_module_attr(module, attr, value):
        setattr(module, attr, value)
        return value

    _vendored_import_exception_type = '__ansible_vendored_exception__'

    def _set_ansible_vendored_exc(exc):
        if not exc:
            return

        _set_module_attr(builtins, _vendored_import_exception_type, exc)

    def _get_ansible_vendored_exc():
        return

# Generated at 2022-06-11 17:40:34.508407
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create an instance of _AnsibleCollectionPkgLoaderBase for test
    parent_dir = os.path.dirname(__file__)
    search_paths = [os.path.join(parent_dir, 'collections/ansible_collections/name/collection')]
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.name.collection', search_paths)
    assert ansible_collection_pkg_loader_base._get_candidate_paths(['']) == [os.path.join('')]

    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.name.collection', search_paths)

# Generated at 2022-06-11 17:41:11.342578
# Unit test for method find_module of class _AnsiblePathHookFinder

# Generated at 2022-06-11 17:41:21.310752
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    """AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type unit tests"""

# Generated at 2022-06-11 17:41:31.237469
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    '''
    Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

    Expects to be called from the same directory as the module

    Arguments: n/a

    Returns: n/a

    Raises: n/a
    '''
    import sys
    import tempfile

    class _TestLoader(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, path):
            _AnsibleCollectionPkgLoaderBase.__init__(self, 'ansible_collections.test', [path])
            self._source_code_path = os.path.join(path, '__init__.py')


# Generated at 2022-06-11 17:41:39.188886
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.ansible_1', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.builtin', [])
    assert loader._redirect is not None
    loader = _AnsibleInternalRedirectLoader('ansible.modules.foo', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.modules.foo_1', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.modules.foo.bar', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.foo', [])
    assert loader._redirect is None
    loader = _AnsibleInternal

# Generated at 2022-06-11 17:41:48.124125
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    collection_name = 'ansible.test'
    subdirs = 'abc.def'
    resource = 'test_module'
    ref_type = 'module'

    ref = 'ansible.test.abc.def.test_module'
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    assert ansible_collection_ref.fqcr == 'ansible.test.abc.def.test_module'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.ansible.test'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.ansible.test.plugins.abc.def.module.test_module'

# Generated at 2022-06-11 17:41:59.484790
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    collection_ref = AnsibleCollectionRef
    assert collection_ref.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert collection_ref.legacy_plugin_dir_to_plugin_type('shell_plugins') == 'shell'
    assert collection_ref.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert collection_ref.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert collection_ref.legacy_plugin_dir_to_plugin_type('vars_plugins') == 'vars'
    assert collection_ref.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-11 17:42:07.557464
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import b
    import pytest

    legacy_plugin_dir_name = b("action_plugins")
    plugin_type = "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name) == plugin_type
    legacy_plugin_dir_name = b("lookup_plugins")
    plugin_type = "lookup"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name) == plugin_type
    legacy_plugin_dir_name = b("library")
    plugin_type = "modules"

# Generated at 2022-06-11 17:42:13.226870
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns_name.coll_name.resource', 'plugin') == \
        AnsibleCollectionRef('ns_name.coll_name', '', 'resource', 'plugin')

    assert AnsibleCollectionRef.from_fqcr('ns_name.coll_name.subdir.resource', 'plugin') == \
        AnsibleCollectionRef('ns_name.coll_name', 'subdir', 'resource', 'plugin')

    assert AnsibleCollectionRef.from_fqcr('ns_name.coll_name.rolename', 'role') == \
        AnsibleCollectionRef('ns_name.coll_name', '', 'rolename', 'role')


# Generated at 2022-06-11 17:42:20.588555
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class _AnsibleCollectionPkgLoaderBaseSubclass(
        _AnsibleCollectionPkgLoaderBase
    ):
        def _validate_args(self):
            self._source_code_path = os.path.join(self._candidate_paths[0], self._package_to_load + '.py')

    test_loader = _AnsibleCollectionPkgLoaderBaseSubclass(
        fullname='ansible_collections.dummy.dummy',
        path_list=['/tmp/dummy_collection', '/tmp/dummy_collection2'],
    )
    with open(test_loader._source_code_path, 'w') as fp:
        print('# This is a dummy file', file=fp)
        print('def dummy_content():', file=fp)

# Generated at 2022-06-11 17:42:31.317301
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test with collection, subdirs and resource as args
    collection = 'ansible.builtin'
    subdirs = 'module_utils.basic'
    resource = 'hosts.py'
    ref_type = 'module'
    ref = AnsibleCollectionRef(collection, subdirs, resource, ref_type)
    assert repr(ref) == "AnsibleCollectionRef(collection='ansible.builtin', subdirs='module_utils.basic', resource='hosts.py')"

    # Test with collection, subdirs and resource as kwargs
    collection = 'ansible.builtin'
    subdirs = 'module_utils.basic'
    resource = 'hosts.py'
    ref_type = 'module'

# Generated at 2022-06-11 17:43:13.201863
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    test_class = AnsibleCollectionRef
    assert test_class.is_valid_fqcr('ns.coll.resource')
    assert test_class.is_valid_fqcr('ns.coll.subdir1.resource')
    assert not test_class.is_valid_fqcr('ns.coll')
    assert not test_class.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra')
    assert not test_class.is_valid_fqcr('')
    assert not test_class.is_valid_fqcr(None)

# Generated at 2022-06-11 17:43:23.320359
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class Fake_AnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            pass

        def _get_candidate_paths(self, path_list):
            return [
                '/fake/path/to/ansible_collections/ns1/coll1/plugins/modules',
                '/fake/path/to/ansible_collections/ns1/coll1/plugins/module_utils',
            ]

        def _get_subpackage_search_paths(self, candidate_paths):
            return []

    loader_instance = Fake_AnsibleCollectionPkgLoaderBase('ns1.coll1.plugins')

# Generated at 2022-06-11 17:43:35.190504
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import json
    import stat
    import os
    import shutil
    import tempfile
    from packaging.specifiers import SpecifierSet
    from packaging.version import Version
    from ansible_collections.ansible.plugns.loader import _AnsibleCollectionPkgLoaderBase

    # create a temporary folder structure
    tdir = tempfile.TemporaryDirectory()
    v_dir = os.path.join(tdir.name, 'test_pkg')

    # create the following folder structure:
    # ─ v_dir
    #    └── 1.0.0
    #        └── ansible_collections
    #            └── test_ns
    #                └── test_pkg
    #                    ├── __init__.py
    #                    └── __pycache__
    #                        └── __init

# Generated at 2022-06-11 17:43:48.167274
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():

    from ansible_collections.ansible import test_collection
    from ansible_collections.all import foobar
    from ansible.module_utils.six import advance_iterator

    def _test_loader(mod, expected_name, expected_path):
        assert isinstance(mod, types.ModuleType)
        assert mod.__name__ == expected_name
        assert mod.__file__ == expected_path

    def _test_loader_raises(mod, expected_name, expected_path):
        try:
            _test_loader(mod, expected_name, expected_path)
            raise Exception("test_loader: expected exception")
        except (ImportError, AttributeError) as e:
            pass

    def _test_loader_none(mod):
        assert mod is None


# Generated at 2022-06-11 17:43:52.481127
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    loader = _AnsibleCollectionPkgLoaderBase('.ansible_collections.acd')
    repr_string = loader.__repr__()
    assert repr_string == '_AnsibleCollectionPkgLoaderBase(path=None)', repr_string

# Generated at 2022-06-11 17:44:00.923068
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import collections
    import string
    import tempfile
    import sys

    # make 'package' on disk
    package_path = tempfile.mkdtemp()
    # component __init__.py
    with open(os.path.join(package_path, '__init__.py'), 'w', encoding='utf-8') as f:
        f.write('# empty package')

    # component package/module.py
    test_module_text = '# code with utf-8: ' + collections.OrderedDict(((c, c) for c in string.ascii_lowercase)).__repr__()
    with open(os.path.join(package_path, 'module.py'), 'w', encoding='utf-8') as f:
        f.write(test_module_text)

    # unit class
   

# Generated at 2022-06-11 17:44:09.084321
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Allocate and populate an object of class _AnsiblePathHookFinder
    collection_finder = _AnsibleCollectionFinder()
    pathctx = '/path/to/file'

    obj = _AnsiblePathHookFinder(collection_finder, pathctx)
    # Check for the method find_module of class _AnsiblePathHookFinder
    assert callable(getattr(obj, 'find_module', None))
    # Check for the method iter_modules of class _AnsiblePathHookFinder
    assert callable(getattr(obj, 'iter_modules', None))



# Generated at 2022-06-11 17:44:19.771634
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # assertEqual is a Python assertion that throws a AssertionError if given arguments are not equal
    assertEqual(
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins"), "action"
    )
    assertEqual(
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("become_plugins"), "become"
    )
    assertEqual(
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("callback_plugins"), "callback"
    )
    assertEqual(
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("cache_plugins"), "cache"
    )

# Generated at 2022-06-11 17:44:29.384640
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    # Test if the created AnsibleCollectionRef is correct
    acr = AnsibleCollectionRef.from_fqcr("namespace.collection.module", "module")
    assert acr.collection == "namespace.collection"
    assert acr.subdirs == ""
    assert acr.resource == "module"
    assert acr.ref_type == "module"

    # Test if the created AnsibleCollectionRef is correct
    acr = AnsibleCollectionRef.from_fqcr("namespace.collection.subdir1.module", "module")
    assert acr.collection == "namespace.collection"
    assert acr.subdirs == "subdir1"
    assert acr.resource == "module"
    assert acr.ref_type == "module"

    # Test if the created AnsibleCollectionRef is correct
    ac