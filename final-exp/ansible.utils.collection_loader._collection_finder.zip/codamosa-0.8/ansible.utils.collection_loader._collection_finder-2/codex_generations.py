

# Generated at 2022-06-11 17:35:40.864646
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('community.general', '', ['fake_path/'], True, False)
    assert loader._package_to_load == 'general'
    assert loader._parent_package_name == 'community'
    assert loader._fullname == 'community.general'



# Generated at 2022-06-11 17:35:49.309912
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module') == AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module').fqcr == 'ns.coll.subdir1.subdir2.resource'

    with pytest.raises(ValueError):
        AnsibleCollectionRef.try_parse_fqcr('invalid', 'module')



# Generated at 2022-06-11 17:35:55.187635
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert '_AnsibleCollectionPkgLoaderBase(path=None)' == repr(_AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.a.b.c', path_list=None))
    assert '_AnsibleCollectionPkgLoaderBase(path=/tmp/c)' == repr(_AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.a.b.c', path_list=['/tmp/c']))



# Generated at 2022-06-11 17:36:02.852103
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('something_else')


# Generated at 2022-06-11 17:36:07.037793
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    collection_pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible', path_list=['/tmp/ansible_collections_ansible_ns'])
    data = collection_pkg_loader.get_data('/tmp/ansible_collections_ansible_ns/ansible_collections/ansible/file/init.py')
    assert data == b''

# Generated at 2022-06-11 17:36:17.679769
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    tmpdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-11 17:36:28.466326
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    testAnsibleCollectionRef = AnsibleCollectionRef('namespace.collection', 'subdirs', 'resource', 'role')
    assert testAnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdirs.resource', 'role')
    assert not testAnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdirs.resource', 'module')
    assert not testAnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdirs.resource', 'playbook')
    assert testAnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdirs.resource')


# Generated at 2022-06-11 17:36:29.420267
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    assert True == True

# Generated at 2022-06-11 17:36:39.438636
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    refobj = AnsibleCollectionRef.from_fqcr('ns.coll.rolename', ref_type='role')
    assert refobj == AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='rolename', ref_type='role')

    refobj = AnsibleCollectionRef.from_fqcr('ns.coll.rolename.yaml', ref_type='playbook')
    assert refobj == AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='rolename', ref_type='playbook')

    refobj = AnsibleCollectionRef.from_fqcr('ns.coll.some.subdirs.modulename', ref_type='module')

# Generated at 2022-06-11 17:36:42.498477
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import random
    fullname = 'ansible_collections.%s.%s' % (random.randint(1, 100000), random.randint(1, 100000))
    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    assert loader.get_filename(fullname)



# Generated at 2022-06-11 17:38:35.966706
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import tempfile
    tmp_root    = tempfile.mkdtemp()
    tmp_root1   = os.path.join(tmp_root, 'ansible_collections')
    tmp_root2   = os.path.join(tmp_root, 'foo')
    tmp_ns_root = os.path.join(tmp_root, 'ns_space')
    pkg         = 'foo'
    namespace   = 'ns_space'
    ns_pkg      = os.path.join(namespace, pkg)
    pkg_path    = os.path.join(tmp_root1, pkg)
    ns_pkg_path = os.path.join(tmp_root1, ns_pkg)
    src_file    = os.path.join(pkg_path, '__init__.py')
    ns_src

# Generated at 2022-06-11 17:38:48.042814
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ansible_loaders = []
    self = ansible_loaders
    # all the loader classes inherit the method get_code from _AnsibleCollectionPkgLoaderBase class
    # this test is written for one of the loader class and it is assumed that all the inheritances will
    # pass the same test.
    _AnsibleCollectionPkgLoader = ansible_loaders[4]
    # synthetic module, no source on disk, no code
    loader = _AnsibleCollectionPkgLoader('test.collections.somens', path_list=[os.path.join(os.path.dirname(__file__), 'fixtures', 'collections')])
    assert loader.get_code('test.collections.somens') == None

    # synthetic module, no source on disk, no code
    # FUTURE: this is a

# Generated at 2022-06-11 17:38:56.901514
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    fpath = '/home/jfrancoi/Documents/PythonProjects/ansible/lib/ansible/plugins/modules/copy.py'
    #cpath = ['/home/jfrancoi/Documents/PythonProjects/ansible/lib/ansible/modules/files/tmp']
    name = '/home/jfrancoi/Documents/PythonProjects/ansible/lib/ansible/plugins/modules/copy.py'
    acp = _AnsibleCollectionPkgLoaderBase(name)
    assert (acp.get_filename(name) == fpath)
    #assert (acp.get_filename(name) == cpath)


# Generated at 2022-06-11 17:39:03.736156
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    test = _AnsibleCollectionPkgLoaderBase('ansible_collections.some_ns')
    test._subpackage_search_paths = []
    assert test.is_package('ansible_collections.some_ns')

    test._subpackage_search_paths = None
    assert not test.is_package('ansible_collections.some_ns')

    test._subpackage_search_paths = ['/test']
    assert test.is_package('ansible_collections.some_ns')

    test._subpackage_search_paths = ['/test', '/test2']
    assert test.is_package('ansible_collections.some_ns')

# unit test get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:39:14.441006
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # fail
    # redirect = _AnsibleInternalRedirectLoader()
    # assert redirect.load_module('module') is None
    pass


# def _module_file_from_path(module_name, path):
#     # look for a module
#     b_module_base = to_bytes(os.path.join(path, module_name))
#     found_module_path = None
#     for suffix, mode, type_ in imp.get_suffixes():
#         if not suffix:
#             continue
#
#         b_candidate_module_path = b_module_base + to_bytes(suffix)
#
#         if os.path.isfile(b_candidate_module_path):
#             # TODO: handle suffixes we don't like?
#             found_module_path =

# Generated at 2022-06-11 17:39:25.091689
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test checks method get_source of class _AnsibleCollectionPkgLoaderBase
    #  using traditional unittest.TestCase
    from io import StringIO
    from importlib import machinery
    from ansible.plugins.loader import _AnsibleCollectionPkgLoaderBase

    from unittest import TestCase

    class Test__AnsibleCollectionPkgLoaderBase_get_source(TestCase):
        def test__get_source(self):
            # Test case for method get_source of class _AnsibleCollectionPkgLoaderBase.
            # Test checks if get_source returns expected code.
            loaders = _AnsibleCollectionPkgLoaderBase('Foo')
            self.assertIsNone(loaders.get_source('Foo'))
            loader = machinery.FileFinder(None, ['/dev/null'])
            loader

# Generated at 2022-06-11 17:39:33.617945
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    def _test_iter_modules(loader, pref_len, name_len, pkg_name):
        module_list = []
        for module in loader.iter_modules(None):
            module_list.append(module)

        assert len(module_list) == 3, '{0} should contain 3 modules, contains {1}'.format(pkg_name, len(module_list))
        for module in module_list:
            assert len(module[0]) == pref_len, 'module name should be {0} chars, is {1}'.format(pref_len, len(module[0]))
            assert len(module[1]) == name_len, 'module name should be {0} chars, is {1}'.format(name_len, len(module[1]))

# Generated at 2022-06-11 17:39:39.624704
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    mock_fullname = 'my_fullname'
    mock_path_list = ['my/path/list']
    test_object = _AnsibleCollectionPkgLoaderBase(mock_fullname, mock_path_list)
    with patch('ansible.module_utils.six.moves.builtins.open', return_value=mock_open(read_data='test_data')):
        assert test_object.get_source(mock_fullname) == 'test_data'

# Generated at 2022-06-11 17:39:48.754124
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import os

    # Make the test module available in a public project
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))

    # Import the test module
    from test.loader import load_fixture

    # Load the fixtures
    fixtures = load_fixture('loader_test__AnsibleCollectionPkgLoaderBase_load_module')
    pkg_loader = fixtures['pkg_loader']
    fake_module = fixtures['fake_module']

    # Load the expected values
    expected = fixtures['expected']

    # Set the return value of get_code to the expected value
    pkg_loader._fullname = 'ansible_collections.ns.collection'

# Generated at 2022-06-11 17:39:59.412682
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'unknown_type')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace', 'subdir1.subdir2', 'resource', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2.invalid', 'resource', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'invalid_resource', 'module')

# Generated at 2022-06-11 17:40:40.232984
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader._meta_yml_to_dict import _meta_yml_to_dict as _AMT2D
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader as _ACP

    # set the _AnsibleCollectionPkgLoader.load_module attribute
    _ACP._meta_yml_to_dict = _AMT2D
    # set the _AnsibleCollectionPkgLoader._meta_yml_to_dict attribute
    _ACP.load_module = _ACP.load_module.__get__(_ACP, _ACP)

    import ansible.config.constants as c

    class _Amc:

        def __init__(self):
            self._config = {}
            self._data = {}
            self._cache_paths = []
            self._

# Generated at 2022-06-11 17:40:42.495610
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    collection_pkg_loader_base_test = _AnsibleCollectionPkgLoaderBase("", "")
    assert collection_pkg_loader_base_test.load_module("test") == None



# Generated at 2022-06-11 17:40:44.863912
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _AnsibleInternalRedirectLoader('ansible.collections.test_name.test_module', ['/test/path']).load_module('ansible.collections.test_module')


# Generated at 2022-06-11 17:40:51.762905
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Arrange
    import sys
    # Assume:
    # def __init__(self, fullname, path_list):
    #     self._redirect = None
    redirectLoader = _AnsibleInternalRedirectLoader(fullname='ansible.runner.shell', path_list=[])
    sys.modules['ansible.runner.shell'] = None
    expected_sys_modules = {'ansible.runner.shell': None}

    # Act
    redirectLoader.load_module('ansible.runner.shell')

    # Assert
    assert sys.modules == expected_sys_modules

# Unit tests for class _AnsibleInternalRedirectLoader

# Generated at 2022-06-11 17:40:57.260896
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    module = _AnsibleCollectionPkgLoader('ansible.test.test_integration', '/test/test_integration')
    assert module.load_module('ansible.test.test_integration')
    assert module.load_module('ansible.test.test_integration')



# Generated at 2022-06-11 17:41:03.789218
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    exitcode = 1
    #NOTE: this test method is just a stub test, which is intended to
    #      give an idea how to use the baseclass.
    #      It is a stub, and not an actual unit test.
    #      It is just to show how to use the below base class.
    # Create an instance of ansible.utils.collection_loader._AnsibleCollectionPkgLoader,
    # and call the method load_module() of it.
    test_instance = _AnsibleCollectionPkgLoader()
    try:
        test_instance.load_module([])
        exitcode = 0
    except SystemExit:
        pass
    except Exception:
        pass
    return exitcode


# Generated at 2022-06-11 17:41:13.838169
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os

    import shutil
    from ansible.module_utils._text import to_bytes, to_text

    from ansible_collections.ansible_collections.ns1.coll1.plugins.module_utils.bar import my_fn as bar
    from ansible_collections.ansible_collections.ns1.coll1.plugins.modules.my_mod import my_fn as my_mod

    from ansible_collections.ansible_collections.ns1.coll2.plugins.module_utils.foo import my_fn as foo
    from ansible_collections.ns1.coll3.plugins.module_utils.baz import my_fn as baz
    from ansible_collections.ns2.coll1.plugins.modules.my_mod import my_fn as my_mod_2


# Generated at 2022-06-11 17:41:23.307831
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    def check_result(fullname, redirection_module, result):
        if result == redirection_module:
            return
        if result != sys.modules.get(fullname):
            raise
        if result.__loader__ != self:
            raise
        if result.__file__ != self.get_filename(fullname):
            raise
        if result.__package__ != self._parent_package_name or self._subpackage_search_paths is not None:
            if result.__package__ != fullname:
                raise
        if self._subpackage_search_paths is not None:  # empty is legal
            if result.__path__ != self._subpackage_search_paths:
                raise

    def get_module_code(module_fullname):
        return self.get_code(module_fullname)

   

# Generated at 2022-06-11 17:41:33.710803
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    module = 'apache'
    fqcr = 'ansible.builtin' + '.' + module
    ref_type = 'module'
    result = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert result.collection == 'ansible.builtin'
    assert result.subdirs == ''
    assert result.resource == module
    assert result.ref_type == ref_type
    assert result.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    assert result.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.modules.' + module
    assert result.fqcr == fqcr


# Generated at 2022-06-11 17:41:44.641004
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():  # The name of the method is added to make the test easy to run
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._install()
    apf = _AnsiblePathHookFinder(collection_finder, '/tmp/ansible_collections/junipernetworks')
    assert apf.find_module('junipernetworks.ansible_junos_stdlib')
    collection_finder._n_configured_paths = ['/tmp/ansible_collections/junipernetworks/ansible_collections']
    apf = _AnsiblePathHookFinder(collection_finder, '/tmp/ansible_collections/junipernetworks')
    assert apf.find_module('junipernetworks.ansible_junos_stdlib')
    collection_finder._remove()


# Generated at 2022-06-11 17:42:05.196597
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # FIXME: add more assertions
    test0 = _AnsibleCollectionPkgLoaderBase('ansible.test0', None)
    assert test0.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'

# Generated at 2022-06-11 17:42:11.462726
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    """
    check to see if the method load_module works
    """
    #mock the module ansible

# Generated at 2022-06-11 17:42:19.873852
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    '''
    Passing package_to_load of ansible_collections.abc.xyz
    '''
    # Passing fake paths
    package_to_load = 'ansible_collections.abc.xyz'
    loader = _AnsibleCollectionPkgLoaderBase(package_to_load, path_list=['/a/b/c', '/d/e/f'])
    result_filename = loader.get_filename(package_to_load)
    expected_filename = os.path.join('/a/b/c', 'xyz')
    assert result_filename == expected_filename

    '''
    Passing package_to_load of ansible_collections.abc.xyz
    '''
    # Passing fake paths
    package_to_load = 'ansible_collections.abc.xyz'
    loader

# Generated at 2022-06-11 17:42:30.673943
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test Scenario where the code file is a simple python file (e.g. collection/colA/plugins/module/file.py)
    full_name = "ansible.colA.plugins.module.file"
    full_name = to_native(full_name)
    split_name = full_name.split('.')
    package_to_load = split_name[-1]

    possible_paths = []
    path_list = ["/home/user/ansible-devel/lib/ansible", "/home/user/ansible-devel/lib/ansible/collections"]
    possible_paths.append(os.path.join(path_list[1], package_to_load))

# Generated at 2022-06-11 17:42:34.321527
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    file_finder_path_hook = _AnsiblePathHookFinder._filefinder_path_hook
    assert 'FileFinder' in repr(file_finder_path_hook)

# HACK: pkgutil.iter_modules_files() only serves the purpose of finding submodules in the collections.
# But it only finds files matching the glob pattern, it doesn't consider all the directories `iter_modules()` considers.
# We use this function to replace the original one, which considers directories that files might be in,
# so that more submodules are found. The directory is then checked by pkgutil.get_data() to ensure it's a file
# we can load.

# Generated at 2022-06-11 17:42:40.054543
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    with pytest.raises(ImportError):
        test = _AnsibleInternalRedirectLoader('test', [])
    with pytest.raises(ImportError):
        test = _AnsibleInternalRedirectLoader('ansible.not_redirected', [])
    test = _AnsibleInternalRedirectLoader('ansible.builtin.copy', [])
    assert test._redirect == 'ansible.modules.files.copy'



# Generated at 2022-06-11 17:42:49.718585
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    """Function to test _AnsibleCollectionFinder.find_module() method"""
    from ansible_collections.nttmcp.mcp.tests.unit.compat.mock import patch
    from ansible_collections.nttmcp.mcp.tests.unit.compat.mock import MagicMock
    from ansible_collections.nttmcp.mcp.plugins.module_utils.network.cloud import _AnsibleCollectionFinder
    from ansible_collections.nttmcp.mcp.plugins.module_utils.network.cloud import pkgutil
    from ansible_collections.nttmcp.mcp.plugins.module_utils.network.cloud import _AnsiblePathHookFinder
    from ansible_collections.nttmcp.mcp.plugins.module_utils.network.cloud import os

# Generated at 2022-06-11 17:42:57.208951
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible
    pkg_loader = _AnsibleCollectionPkgLoader('ansible_collections.test_ns.test_coll', os.path.join(os.path.dirname(ansible.__file__), 'collections/ansible_collections/test_ns/test_coll'), ['init'], _meta_yml_to_dict=_meta_yml_to_dict)
    module = pkg_loader.load_module('ansible_collections.test_ns.test_coll')
    assert module._collection_meta['name'] == 'test_ns.test_coll'



# Generated at 2022-06-11 17:43:07.773650
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import tempfile
    import shutil
    import sys
    import os
    import ansible.utils.collection_loader
    import ansible.module_utils

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 17:43:19.442698
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-11 17:44:07.922744
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder(collection_finder=None, pathctx=None)

# pylint: disable=too-many-public-methods,too-few-public-methods

# Generated at 2022-06-11 17:44:12.315139
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _meta_yml_to_dict
    _meta_yml_to_dict = True
    module_name = ("ansible_collections.test","test","test")
    loader = _AnsibleCollectionPkgLoader()
    module = loader.load_module(module_name)
    assert module._collection_meta == {},module._collection_meta


# Generated at 2022-06-11 17:44:21.033697
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # test with action_plugins
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'

    # test with lookup_plugins
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'

    # test with connection_plugins
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

    # test with library
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'


# Generated at 2022-06-11 17:44:30.243299
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader as original_location
    original_location._meta_yml_to_dict = mock.Mock(return_value="")
    collection_name = 'ansible.builtin'
    ansible_pkg_path = os.path.dirname(import_module('ansible').__file__)
    metadata_path = os.path.join(ansible_pkg_path, 'config/ansible_builtin_runtime.yml')
    with open(to_bytes(metadata_path), 'rb') as fd:
        raw_routing = fd.read()
    expected_value = {"test": "test"}
    original_location._meta_yml_to_dict = mock.Mock(return_value=expected_value)