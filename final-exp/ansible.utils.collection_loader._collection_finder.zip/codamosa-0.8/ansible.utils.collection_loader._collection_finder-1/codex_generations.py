

# Generated at 2022-06-11 17:35:47.780375
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    def test_func():
        base = _AnsibleCollectionPkgLoaderBase('foo', [])
        assert base.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'
        base = _AnsibleCollectionPkgLoaderBase('foo', ['/path/to/something'])
        assert base.__repr__() == "_AnsibleCollectionPkgLoaderBase(path=['/path/to/something'])"
    test_func()

# Generated at 2022-06-11 17:35:53.463455
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    d = mkdtemp()
    try:
        with open(os.path.join(d, 'goose.yml'), 'w') as f:
            f.write('this is a goose')
        f = _AnsibleCollectionPkgLoaderBase('foo.bar', [d])
        assert f.get_source('foo.bar') == 'this is a goose'
    finally:
        shutil.rmtree(d)



# Generated at 2022-06-11 17:36:04.738083
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # do we load the module only once?
    module_loader = _AnsibleCollectionPkgLoader(fullname='ansible_collections.tockins.myns.mypkg', path=['/my/path'])

    # instantiate the package module
    module = module_loader.load_module(fullname='ansible_collections.tockins.myns.mypkg')
    # the module must be a package
    assert module.__package__ == 'ansible_collections.tockins.myns.mypkg'
    # the package moudule has a __path__ attribute
    assert module.__path__ == ['/my/path']
    # the package module has a __loader__ attribute
    assert module.__loader__ == module_loader


# Generated at 2022-06-11 17:36:14.786814
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_type = 'module'

    ref = 'ns.coll.resource'
    assert AnsibleCollectionRef.try_parse_fqcr(ref, ref_type).fqcr == ref
    assert AnsibleCollectionRef.try_parse_fqcr(ref, ref_type).collection == 'ns.coll'
    assert AnsibleCollectionRef.try_parse_fqcr(ref, ref_type).subdirs == ''
    assert AnsibleCollectionRef.try_parse_fqcr(ref, ref_type).resource == 'resource'
    assert AnsibleCollectionRef.try_parse_fqcr(ref, ref_type).ref_type == 'module'

    ref = 'ns.coll.subdir1.resource'

# Generated at 2022-06-11 17:36:23.037583
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():

    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/path/to/collections']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'

    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/path/to/collections']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'

# Generated at 2022-06-11 17:36:32.974526
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible_collections.ansible.plugins.loader import _AnsibleCollectionPkgLoaderBase, _AnsibleCollectionPackageRedirector
    from ansible_collections.ansible.plugins.module_utils.common.parameters import ModuleParameters
    from ansible_collections.ansible.plugins.module_utils.common import module_params

    # current module
    assertModuleNameEquals(__name__, 'ansible_collections.ansible.plugins.loader')

    # TODO: find way to test with actual content
    #module_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.somesubns',
    #                                                path_list=['/path/to/collection/root'])
    #module = module_loader.load_module('ansible_collections.s

# Generated at 2022-06-11 17:36:41.734951
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class Impl( _AnsibleCollectionPkgLoaderBase):
        def __init__(*args):
            pass
    class Impl( _AnsibleCollectionPkgLoaderBase):
        def __init__(*args):
            pass
    #_AnsibleCollectionPkgLoaderBase.get_source(self,fullname) -> <class '_AnsibleCollectionPkgLoaderBase'>
    assert isinstance(_AnsibleCollectionPkgLoaderBase.get_source(Impl('fullname'),'fullname'), _AnsibleCollectionPkgLoaderBase)
    #_AnsibleCollectionPkgLoaderBase.get_source(self,fullname) -> <class '_AnsibleCollectionPkgLoaderBase'>

# Generated at 2022-06-11 17:36:52.121724
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import logging
    import sys
    import os
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.utils.collection_loader import _AnsibleCollectionFinder, _AnsibleCollectionConfig
    from ansible.module_utils import common_errno
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
    script_path = os.path.dirname(os.path.realpath(__file__))
    ansible

# Generated at 2022-06-11 17:37:03.006405
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_instance = _AnsibleCollectionPkgLoaderBase('my.name', path_list=['/p'])
    assert test_instance.get_data('x') is None
    assert test_instance.get_data('/x') is None
    # New instance without subpackage_search_paths
    test_instance = _AnsibleCollectionPkgLoaderBase('my.name')
    assert test_instance.get_data('x') is None
    assert test_instance.get_data('/x') is None
    # New instance with an existing file and
    # with a subpackage_search_paths attribute
    test_instance = _AnsibleCollectionPkgLoaderBase('my.name', path_list=['/p'])
    # create a file

# Generated at 2022-06-11 17:37:09.973150
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # try with 0 paths, it should raise exception
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.builtin.some_module', [])

    # try with 1 path, it should raise exception
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.builtin.some_module', ['path1'])

    # try with 2 paths, it should raise exception
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.builtin.some_module', ['path1', 'path2'])

    # try with which doesn't start with ansible
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('other.builtin.some_module', [])

    #

# Generated at 2022-06-11 17:37:50.382620
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    myobj = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type
    assert myobj('action_plugins') == 'action', "Failed: action_plugins"
    assert myobj('lookup_plugins') == 'lookup', "Failed: lookup_plugins"
    assert myobj('library') == 'modules', "Failed: libary"


# Generated at 2022-06-11 17:37:53.466901
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='fullname', path_list=['path_list'])
    fullname = 'fullname'
    # Call method
    source = loader.get_source(fullname)
    # Assert return value
    assert source == None

# Generated at 2022-06-11 17:38:02.175355
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # make sure we have a find_module implementation for every collection
    config = AnsibleCollectionConfig()
    finder = _AnsibleCollectionFinder()

    # Tuple (collection_name, module_name)
    module_names = set()
    for collection_name in config.get_collections():
        for module_name in config.get_collections_modules(collection_name):
            module_names.add((collection_name, module_name))

    for collection_name, module_name in module_names:
        fullname = 'ansible_collections.{collection_name}.{module_name}'.format(
            collection_name=collection_name,
            module_name=module_name,
        )
        try:
            finder.find_module(fullname)
        except ModuleNotFoundError:
            assert False

# Generated at 2022-06-11 17:38:13.178527
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref_1 = AnsibleCollectionRef(collection_name='collection_name', subdirs=None, resource=None, ref_type='ref_type')
    assert ref_1.collection == 'collection_name', 'AnsibleCollectionRef() should set the collection attribute'
    assert ref_1.subdirs == '', 'AnsibleCollectionRef() should set the subdirs attribute to an empty string'
    assert ref_1.resource == None, 'AnsibleCollectionRef() should set the resource attribute'
    assert ref_1.ref_type == 'ref_type', 'AnsibleCollectionRef() should set the ref_type attribute'
    assert ref_1.n_python_collection_package_name == 'ansible_collections.collection_name', 'AnsibleCollectionRef() should set the python_collection_package_name for Python packages'

# Generated at 2022-06-11 17:38:24.571909
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test case 1
    current_dir = os.path.dirname(os.path.abspath(__file__))
    collection_loader = _AnsibleCollectionPkgLoader(None, 'test_coll')
    collection_loader.collection_name = 'test'
    collection_loader.collection_path = current_dir
    collection_loader._split_name = ['ansible_collections', 'test_coll', 'test']
    collection_loader._source_code_path = current_dir
    try:
        collection_loader.load_module('test_coll.test')
        assert False
    except ValueError:
        pass

    # Test case 2
    collection_loader = _AnsibleCollectionPkgLoader(None, 'test_coll')
    collection_loader.collection_name = 'test'
    collection_loader.collection

# Generated at 2022-06-11 17:38:31.600260
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    result = _AnsibleInternalRedirectLoader('ansible.module_utils.network.fortios.fortios',
                                            ['ansible_collections/ansible/builtin', 'ansible_collections/cisco/fortios'])
    assert result._redirect is None


# Custom module finder that will try to load internal Ansible redirects before doing a normal import.
# Must be set as the first finder in sys.meta_path to work.

# Generated at 2022-06-11 17:38:44.395101
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # First, test valid FQCRs
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')  # The canonical form of a FQCR
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.resource')  # A FQCR with 4 subdirs
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource')  # A FQCR with 1 subdir
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource.py')  # A FQCR with 1 subdir and an extension

    # Test some invalid FQCRs

# Generated at 2022-06-11 17:38:54.511367
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Note that we are testing the behavior or the method on the base class. The method is not supposed to be used
    # directly on the base class.
    # Set up
    pkg_loader_base_class = _AnsibleCollectionPkgLoaderBase
    expected_code_obj = compile(
        source='', filename='<string>', mode='exec', flags=0, dont_inherit=True
    )
    os.makedirs('./foo/bar')

    # Test
    module_loader = pkg_loader_base_class('foo.bar')
    # Should return None because source code is None
    actual_code_obj = module_loader.get_code('foo.bar')
    assert expected_code_obj.co_filename == actual_code_obj.co_filename
    assert expected_code_obj.co_

# Generated at 2022-06-11 17:39:02.500125
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # unit test for a proper set of matching paths
    matching_paths = ['/opt/ansible/tmp/awx_test/collections/ansible_collections/dummy/mypkg',
                      '/opt/ansible/tmp/awx_test/collections/ansible_collections/dummy/mypkg/subpkg',
                      '/opt/ansible/tmp/awx_test/collections/ansible_collections/dummy/mypkg/subpkg/subsubpkg']

# Generated at 2022-06-11 17:39:12.678424
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """ testing the from_fqcr method of class AnsibleCollectionRef """
    acr = None
    col_name = "ansible_namespace.fake_collection"
    resource = "fake_module_name"
    ref_type = "module"
    fqcrs = [
        "ansible_namespace.fake_collection.fake_module_name",
        "ansible_namespace.fake_collection.fake_subdir1.fake_module_name",
        "ansible_namespace.fake_collection.fake_subdir1.fake_subdir2.fake_module_name"
    ]

# Generated at 2022-06-11 17:41:09.131267
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    from ansible.module_utils.six.moves import builtins
    lm = builtins.__import__('ansible.parsing.dataloader')
    sys.modules['ansible'] = lm
    lm.__file__ = 'ansible/parsing/dataloader.py'
    cf = _AnsibleCollectionFinder()
    assert cf.find_module('ansible.builtin') is not None


# Generated at 2022-06-11 17:41:15.087986
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    collection_name = "namespace.collectionname"
    subdirs = "subdir1.subdir2"
    resource = "resource"
    ref_type = "module"
    ansible_collection_ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert ansible_collection_ref.collection == collection_name
    assert ansible_collection_ref.subdirs == subdirs
    assert ansible_collection_ref.resource == resource
    assert ansible_collection_ref.ref_type == ref_type



# Generated at 2022-06-11 17:41:24.551916
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import tempfile
    import shutil
    import time
    my_dir = os.path.join(tempfile.gettempdir(), "ansible_collections")
    os.makedirs(my_dir)
    for file in ['test.py','test.pyc','test.pyo','test.so','test.pyd','__init__.py','__init__.pyc','__init__.pyo','__init__.so','__init__.pyd']:
        with open(os.path.join(my_dir, file), 'w') as f:
            f.write('#!/usr/bin/python\nimport test')

# Generated at 2022-06-11 17:41:33.100136
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # __file__ is not set, so get_source should return None
    loader = _AnsibleCollectionPkgLoaderBase('foo', path_list=['/tmp'])
    assert loader.get_source('foo') is None
    # Test without loading module
    loader._source_code_path = '/tmp/foo.py'
    assert loader.get_source('foo') == b'#\n'
    # Test after loading module
    loader.load_module('foo')
    assert loader.get_source('foo') == b'#\n'


# Generated at 2022-06-11 17:41:39.405560
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    """Test _AnsibleCollectionPkgLoaderBase.load_module
    """

    # We can't really test this since we're not a real loader, but at least we can check if it returns the
    # expected types and such
    loader = _AnsibleCollectionPkgLoaderBase('foo')
    assert loader.load_module('foo') is not None
    assert type(loader.load_module('foo')) == ModuleType
    try:
        loader.load_module('bar')
        # We should have received an exception since bar != foo
        assert False
    except ValueError:
        pass
# End of unit test -- _AnsibleCollectionPkgLoaderBase.load_module



# Generated at 2022-06-11 17:41:46.947781
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # _AnsibleCollectionPkgLoaderBase.get_source
    import os
    import tempfile
    loader = None
    name = None
    path = None
    try:
        name = 'some_name'
        path = [tempfile.mkdtemp()]
        loader = _AnsibleCollectionPkgLoaderBase(name, path_list=path)
        loader._source_code_path = os.path.join(path[0], '__init__.py')
        assert loader.get_source(name) == b''
    finally:
        if loader and path:
            shutil.rmtree(path[0])


# Generated at 2022-06-11 17:41:57.981495
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'

# Generated at 2022-06-11 17:42:06.824764
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    assert AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module_utils.module')
    assert not AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module_utils.module',u'lookup')
    assert AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module')
    assert AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module')
    assert AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module.')
    assert not AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module..')
    assert not AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.module.module..')

# Generated at 2022-06-11 17:42:10.237023
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    collection_name = 'ns.collname'
    ref = AnsibleCollectionRef.is_valid_collection_name(collection_name)
    assert ref == True

    collection_name = 'nsd.collname'
    # Invalid collection_name,
    # should raise ValueError
    with pytest.raises(ValueError):
        AnsibleCollectionRef.is_valid_collection_name(collection_name)

# Generated at 2022-06-11 17:42:20.151825
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # testing acr = from_fqcr('ns.coll.resource', 'module')
    acr = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert isinstance(acr, AnsibleCollectionRef)
    assert acr.collection == 'ns.coll'
    assert acr.subdirs == ''
    assert acr.resource == 'resource'
    assert acr.ref_type == 'module'
    assert acr.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert acr.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert acr.fqcr == 'ns.coll.resource'
    # testing acr = from_fqcr('ns.coll.resource

# Generated at 2022-06-11 17:43:10.266100
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:43:21.328549
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # noinspection PyProtectedMember
    # FUTURE: provide a more complete unit test, including a ref_type
    def assert_ref_eq(left, right):
        # we'll check this way to avoid having to populate everything explicitly
        assert left.__dict__ == right.__dict__

    # with subdirs
    legacy_module_style_str = u'my_ns.my_coll.module_utils.module_utils.module'
    my_ref_1 = AnsibleCollectionRef.from_fqcr(legacy_module_style_str, u'module')
    my_ref_2 = AnsibleCollectionRef(u'my_ns.my_coll', u'module_utils.module_utils', u'module', u'module')


# Generated at 2022-06-11 17:43:33.465951
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    #pylint: disable=unused-argument
    class MockCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass  # override behavior to allow more flexibility
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths
        def _validate_final(self):
            pass
        def get_source(self, fullname):
            return b'print("test{}")'.format(fullname)
        def get_filename(self, fullname):
            return 'test/path/{}.py'.format(fullname)

    # no source, file, or package

# Generated at 2022-06-11 17:43:35.968723
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    """ test__AnsibleInternalRedirectLoader_load_module """
    _AnsibleInternalRedirectLoader("ansible.module_utils", "test").load_module("test")


# Generated at 2022-06-11 17:43:48.406996
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:43:58.629123
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class AnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):

        def __init__(self, fullname, path_list=None):
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens

            self._source_code_path = os.path.join(path, 'testfile')
            self._decoded_source = None
            self._compiled_code = None

            self._validate_args()



# Generated at 2022-06-11 17:44:08.917838
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Replace if os.path.isfile(b_routing_meta_path) is True with False,
    # which means test case when routing.yml not found
    b_routing_meta_path = False
    # Replace if raw_routing: with True,
    # which means test case when routing.yml found
    raw_routing = True
    from ansible.module_utils.six import PY2
    raise_exception = False
    try:
        if raw_routing:
            routing_dict = _meta_yml_to_dict('', ('stdlib.3.2.0', 'runtime.yml'))
            # stdlib_collection_meta = self._canonicalize_meta(routing_dict)
    except Exception as ex:
        raise_exception = True
    assert raise_exception

# Generated at 2022-06-11 17:44:19.532908
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    api.init_configuration()
    test_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible-collections', path_list=['/tmp/ansible-collections'])
    test_loader._split_name = ['ansible_collections', 'it']
    test_loader._rpart_name = ('', 'it')
    test_loader._parent_package_name = ''
    test_loader._package_to_load = 'it'
    test_loader._validate_args()
    _c_paths = test_loader._get_candidate_paths([to_native(p) for p in ['/tmp/ansible-collections']])
    test_loader._candidate_paths = _c_paths
    _s_paths = test_loader._get_subpackage_search

# Generated at 2022-06-11 17:44:29.211730
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import zlib
    collection_name = 'ansible.builtin'
    ansible_pkg_path = os.path.dirname(import_module('ansible').__file__)
    metadata_path = os.path.join(ansible_pkg_path, 'config/ansible_builtin_runtime.yml')
    with open(to_bytes(metadata_path), 'rb') as fd:
        raw_routing = fd.read()

    class _MetaYmlToDict:
        @staticmethod
        def __init__(self):
            self.def_count = 0
            self.result_yml = ''
        def __call__(self, decoded_source, filename='test', encoding='utf-8', errors='surrogate_or_strict'):
            self.def_count += 1
