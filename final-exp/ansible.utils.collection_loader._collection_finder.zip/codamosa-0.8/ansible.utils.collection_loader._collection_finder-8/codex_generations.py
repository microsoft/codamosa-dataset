

# Generated at 2022-06-11 17:35:50.032572
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:35:58.862638
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr(u'myc.myo.mym', u'module') == AnsibleCollectionRef(u'myc.myo', u'', u'mym', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'myc.myo.mys.mym', u'module') == AnsibleCollectionRef(u'myc.myo', u'mys', u'mym', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'myc.myo.myr', u'role') == AnsibleCollectionRef(u'myc.myo', u'', u'myr', u'role')

# Generated at 2022-06-11 17:36:04.006391
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Create a temporary directory for testing
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_name = temp_dir.name
    os.mkdir(os.path.join(temp_dir_name, 'ansible_collections'))
    os.mkdir(os.path.join(temp_dir_name, 'ansible_collections', 'acme'))
    os.mkdir(os.path.join(temp_dir_name, 'ansible_collections', 'acme', 'network'))
    os.mkdir(os.path.join(temp_dir_name, 'ansible_collections', 'acme', 'network', 'plugins'))

# Generated at 2022-06-11 17:36:07.629801
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    f = _AnsibleCollectionRootPkgLoader
    assertEqual(f('a.b')._parent_package_name, "a")
    assertEqual(f('a.b')._package_to_load, "b")
    assertRaises(ImportError, f, 'a')



# Generated at 2022-06-11 17:36:09.443004
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    example = _AnsibleCollectionPkgLoaderBase_get_code()
    print(example)

# Generated at 2022-06-11 17:36:20.797348
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class PackageLoader( _AnsibleCollectionPkgLoaderBase ):
        def __init__(self, name, path):
            super(PackageLoader, self).__init__(name, path)
    PACKAGE_NAME = "ansible_collections.ns.module" 
    import os
    import tempfile
    tempdir = tempfile.gettempdir()
    path = os.path.join( tempdir, "ns", "module" )
    if not os.path.exists( path ):
        os.makedirs( path )
    loader = PackageLoader( PACKAGE_NAME, path )
    data = loader.get_data(os.path.join( path, PACKAGE_NAME.split('.')[-1] + ".py" ))
    stdout.write( "data: %s" % data )


# Generated at 2022-06-11 17:36:32.068912
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    path = os.path.join(os.path.dirname(__file__), '_data', 'sample_collections', 'namespace_ns', 'collection_name', 'plugins', 'modules')
    fullname = 'ansible_collections.namespace_ns.collection_name.plugins.modules.sample_module'
    _file_finder_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    finder = _AnsiblePathHookFinder(collection_finder=None, pathctx=path)
    loader = finder.find_module(fullname)
    assert isinstance(loader, pkgutil.ImpImporter)
    if PY3:
        # For Python 3 we can only get a FileFinder finder but not a specific loader.
        loader = finder.find_module

# Generated at 2022-06-11 17:36:34.800127
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ctx = _AnsiblePathHookFinder(_AnsibleCollectionFinder(), "ansible_collections/ansible")
    ansible_module = ctx.find_module("ansible")
    print(ansible_module)
    assert(ansible_module != None)
    assert(ansible_module.load_module != None)


# Generated at 2022-06-11 17:36:42.497825
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ns = "ansible"
    collection = "core"
    refs = {
        "module": "ping",
        "module_with_subdir": "subdir.ping",
        "role": "role_name",
        "role_with_subdir": "subdir.role_name",
        "playbook": "playbook_name.yml",
        "doc_fragment": "doc_fragment"}
    for ref_type, ref in refs.items():
        collection_ref = AnsibleCollectionRef.from_fqcr("{}.{}.{}".format(ns, collection, ref), ref_type=ref_type)
        assert collections.namedtuple.__eq__(collection_ref, collection_ref)



# Generated at 2022-06-11 17:36:43.288884
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert True == True



# Generated at 2022-06-11 17:37:15.175951
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    path_list = [b"/home/daniel/.ansible/collections/ansible_collections/somens"]
    fullname = "ansible_collections.somens.testmodule"
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    pytest_assert(loader.is_package(fullname) == True)



# Generated at 2022-06-11 17:37:23.092754
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('my.collection', None, 'mymodule', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='my.collection', subdirs=None, resource='mymodule')"
    ref = AnsibleCollectionRef('my.collection', 'subdir1.subdir2', 'mymodule', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='my.collection', subdirs='subdir1.subdir2', resource='mymodule')"


# Generated at 2022-06-11 17:37:28.704768
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import sys, types
    if sys.version_info.major == 2:
        ModuleType = types.ModuleType
    elif sys.version_info.major == 3:
        ModuleType = types.ModuleType
    _AnsibleCollectionPkgLoaderBase = sys.modules[__name__ + '._AnsibleCollectionPkgLoaderBase']

    # FIXME: implement test_get_source test



# Generated at 2022-06-11 17:37:35.955333
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.module') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.module', ref_type='module') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.module', ref_type='role') is False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.foo.module') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.foo.module', ref_type='module') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.foo.module', ref_type='role') is False

# Generated at 2022-06-11 17:37:47.262518
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    class TestAnsibleCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_final(self):
            return
    class TestPathFinder():
        def __init__(self, path):
            self._path = path
        @staticmethod
        def find_module(fullname=None, path=None):
            if fullname is None:
                return None
            else:
                return TestAnsibleCollectionPkgLoader(fullname, path)

    test_pkg_path = os.path.join(os.path.dirname(__file__), "test_data", "base_loader_iter_modules")
    # NOTE: _AnsiblePathHookFinder's constructor takes an actual path string, not a list as
    # _AnsibleCollectionPkgLoaderBase does, so we need to convert the

# Generated at 2022-06-11 17:37:58.241923
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    """Unit test for method load_module of class _AnsibleCollectionPkgLoader
    """

    import ansible.utils.collection_loader
    import ansible.plugins.action.copy
    import ansible.plugins.action.shell

    # This is the folder of the collections in the sources of Ansible.
    # It may be different depending on the installation.
    ansible_collections_path = os.path.join(os.path.dirname(ansible.utils.collection_loader.__file__), '../../../lib/ansible/collections')

    #
    # (1) Load the package ansible.cisco and the module ansible.cisco.ios
    #
    _AnsibleCollectionPkgLoader(
        name='ansible.cisco',
        path=ansible_collections_path,
    )



# Generated at 2022-06-11 17:38:02.329925
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj = AnsibleCollectionRef('dummy', 'dummy', 'dummy', 'dummy')

    res = obj.__repr__()
    assert res == "AnsibleCollectionRef(collection='dummy', subdirs='dummy', resource='dummy')", 'Unexpected result from AnsibleCollectionRef.__repr__'


# Generated at 2022-06-11 17:38:03.841893
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    AnsibleCollectionRef('joe.test', '', 'mytest', 'role')


# Generated at 2022-06-11 17:38:13.226122
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'

    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('not a thing')


# Unit tests for method is_valid_collection_name of class AnsibleCollectionRef

# Generated at 2022-06-11 17:38:24.571873
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():

    from ansible.utils.collection_loader import AnsibleCollectionConfig, _AnsibleCollectionPkgLoader

    coll_loader = _AnsibleCollectionPkgLoader(path=['/tmp/sandbox/ansible_collections/ns1/coll1', '/tmp/sandbox/ansible_collections/ns1/coll2'], fullname=None, package_to_load='coll3')


#
#   _____              __
#  / ___/_________  __/ /_____  ____ _____  ____ ___
# / /__/ ___/ __ \/ / / __/ _ \/ __ `/ __ \/ __ `__ \
# \___/_/  / /_/ / / / /_/  __/ /_/ / / / / / / / / /
# /____/\___/\____/_/_/\

# Generated at 2022-06-11 17:39:15.624998
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # ex_path = 'examples/collections/ansible_collections/acme/my_fixtures/plugins/module_utils/fixture.py'
    ex_path = 'examples/collections/ansible_collections/acme/my_fixtures/plugins/module_utils'
    my_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.acme.my_fixtures.plugins.module_utils')
    my_loader._source_code_path = ex_path
    my_loader._parent_package_name = 'ansible_collections.acme.my_fixtures'

    print(my_loader)
    print(my_loader.get_source('ansible_collections.acme.my_fixtures.plugins.module_utils'))

# Generated at 2022-06-11 17:39:24.176954
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    mock_fullname = 'ansible_collections.ns.module'
    mock_path = ['path1', 'path2']
    mock_module_path = ['path1/ns/module', 'path2/ns/module', 'path2/ns/module/__init__.py']
    mock_loader = _AnsibleCollectionPkgLoaderBase(mock_fullname, mock_path)
    mock_loader._source_code_path = mock_module_path
    assert repr(mock_loader) == '_AnsibleCollectionPkgLoaderBase(path={0})'.format(mock_module_path)


# Generated at 2022-06-11 17:39:32.990122
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    base_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_finder')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.testns.testcoll2', path_list=[base_path])
    # Test that source code of a module could be retrieved and compiled
    code_obj = loader.get_code('ansible_collections.testns.testcoll2.mytestmod')
    mytestmod = ModuleType('ansible_collections.testns.testcoll2.mytestmod')
    exec(code_obj, mytestmod.__dict__)
    assert mytestmod.TESTMOD_ATTR == 'testmod2'
    # Test that source code of a package could be retrieved and compiled

# Generated at 2022-06-11 17:39:41.889360
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    from ansible_collections.a.b.c.plugins.module_utils import bar

    # Test a success case
    actual = AnsibleCollectionRef.try_parse_fqcr(ref=bar.__name__, ref_type='module_utils')
    desired = 'a.b.c.module_utils.bar'
    assert actual == desired

    # Test a failed case
    actual = AnsibleCollectionRef.try_parse_fqcr(ref=bar.__name__, ref_type='module_ulos')
    desired = None
    assert actual == desired

    actual = AnsibleCollectionRef.try_parse_fqcr(ref=bar.__name__, ref_type='utils')
    desired = None
    assert actual == desired


# Generated at 2022-06-11 17:39:46.094547
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar.baz',
                                             path_list=['/path/to/ansible_collections/foo/bar'])
    assert loader.is_package('ansible_collections.foo.bar.baz') == True



# Generated at 2022-06-11 17:39:56.740882
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    for test_string in ['a.b.c', 'a.b.c.d', 'a.b.c.d.e', 'a.b.c.d.e.f']:
        assert AnsibleCollectionRef.is_valid_fqcr(test_string) is True

    for test_string in ['.a.b.c', 'a.b.', 'a.b.c.', 'a.b..c', 'a', 'a.b.', 'a..b', 'a.b.c.!!!']:
        assert AnsibleCollectionRef.is_valid_fqcr(test_string) is False

    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c', ref_type='module') is True

# Generated at 2022-06-11 17:40:04.166264
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # from_fqcr
    #assert_equal(expected, AnsibleCollectionRef.from_fqcr(ref, ref_type))

    ref = "namespace.collection.resource"
    ref_type = "module"
    assert_equal(
        AnsibleCollectionRef("namespace.collection", "", "resource", ref_type),
        AnsibleCollectionRef.from_fqcr(ref, ref_type))

    ref = "namespace.collection.subdir1.resource"
    ref_type = "module"
    assert_equal(
        AnsibleCollectionRef("namespace.collection", "subdir1", "resource", ref_type),
        AnsibleCollectionRef.from_fqcr(ref, ref_type))

    ref = "namespace.collection.rolename"
    ref_type = "role"

# Generated at 2022-06-11 17:40:10.894760
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    try:
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('invalid_type')
        assert False, 'expected ValueError for unknown plugin type'
    except ValueError:
        pass



# Generated at 2022-06-11 17:40:21.846878
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    os.makedirs(os.path.join(fixtures_path, 'foo', 'bar'))
    with open(os.path.join(fixtures_path, 'foo', '__init__.py'), 'w') as f:
        f.write('test module foo')
    with open(os.path.join(fixtures_path, 'foo', 'bar', '__init__.py'), 'w') as f:
        f.write('test module bar')
    with open(os.path.join(fixtures_path, 'foo', 'bar', 'baz.py'), 'w') as f:
        f.write('test module baz')
    with open(os.path.join(fixtures_path, 'foo', 'baz.py'), 'w') as f:
        f.write('test module baz')

# Generated at 2022-06-11 17:40:22.576822
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    pass



# Generated at 2022-06-11 17:42:01.512255
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # fixture
    acf = _AnsibleCollectionFinder(paths=['/path/to/collection/root/'])
    acf._n_collection_paths = ['/path/to/collection/root/']

    # test
    expected_outcome = None
    assert acf.find_module('ansible') == expected_outcome


# Generated at 2022-06-11 17:42:05.169511
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    assert _AnsibleCollectionPkgLoaderBase.get_code is _AnsibleCollectionPkgLoaderBase.get_code



# Generated at 2022-06-11 17:42:14.164239
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test function for constructor of class _AnsibleInternalRedirectLoader
    import ansible.utils.collection_loader as cu
    assert cu._AnsibleInternalRedirectLoader('ansible.module_utils.abc', [])._redirect is None
    assert cu._AnsibleInternalRedirectLoader('ansible.module_utils.cloud.amazon', [])._redirect == 'ansible.module_utils.cloud.amazon.aws'
    assert cu._AnsibleInternalRedirectLoader('ansible.module_utils.cloud.canonical', [])._redirect == 'ansible.module_utils.cloud.canonical.ucs'
    assert cu._AnsibleInternalRedirectLoader('ansible.module_utils.cloud.cloudscale', [])._redirect == 'ansible.module_utils.cloud.cloudscale.cloudscale'

# Generated at 2022-06-11 17:42:21.178426
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # set up module parameters
    fullname = 'testfullname'
    name = 'testname'
    loader = 'testloader'
    code_obj = 'testcodeobj'
    # create test loader
    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    # create test module
    module = ModuleType(name)
    # set exec parameters
    module.__dict__['__loader__'] = loader
    module.__dict__['__file__'] = loader.get_filename(fullname)
    module.__dict__['__package__'] = ".".join(fullname.split(".")[:2])
    module.__dict__['__path__'] = [os.path.join(fullname, '__init__.py')]
    # verify exec
    code_obj() in module.__dict__

# Generated at 2022-06-11 17:42:31.762469
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_loader = _AnsibleCollectionPkgLoader('test._test_fixture_collection.plugins.modules')
    import ansible.plugins.loader
    ansible.plugins.loader._meta_yml_to_dict = {'plugin_routing': {'action_plugin': {'add_host': {'redirect': '../../../../../../library/ansible/modules/system/add_host.py'}}}}
    try:
        assert collection_loader.load_module('test._test_fixture_collection.plugins.modules') == None
    except:
        assert False
    import ansible.plugins.loader
    ansible.plugins.loader._meta_yml_to_dict = {'plugin_routing': {'action_plugin': {'add_host': {}}}}

# Generated at 2022-06-11 17:42:41.697231
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    o = AnsibleCollectionRef.from_fqcr("ns.name.rolename", "role")
    assert o.collection == "ns.name", "collection"
    assert o.subdirs == u'', "subdirs"
    assert o.resource == "rolename", "resource"
    assert o.ref_type == u'role', "ref_type"
    assert o.fqcr == "ns.name.rolename", "fqcr"
    assert o.n_python_collection_package_name == 'ansible_collections.ns.name', "n_python_collection_package_name"
    assert o.n_python_package_name == 'ansible_collections.ns.name.roles.rolename', "n_python_package_name"
    o = AnsibleCollectionRef.from_fq

# Generated at 2022-06-11 17:42:51.939535
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Define test data
    data_module_source_code_path = [
      (
        'tests/units/local/ansible_collections/ns/collection/module.py',
        '''
         # BEGIN OF MODULE SOURCE CODE
         # END OF MODULE SOURCE CODE
        ''',
      ),
    ]
    data_module_decoded_source = [
      (
        'tests/units/local/ansible_collections/ns/collection/module.py',
        '',
      ),
    ]

# Generated at 2022-06-11 17:42:59.661730
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    module_name = 'ansible_collections.some_namespace'
    path = 'path/not/found'

    loader = _AnsibleCollectionPkgLoaderBase(module_name, path)

    assert len(sys.modules.keys()) == 0

    # first check for raising ImportError for not found path.
    with pytest.raises(ImportError):
        loader.load_module(module_name)

    # create the path
    os.makedirs(path)

    # second check for raising ImportError for found path.
    with pytest.raises(ImportError):
        loader.load_module(module_name)

    # create the submodule
    module_submodule_path = os.path.join(path, module_name.split('.')[-1])

# Generated at 2022-06-11 17:43:09.808191
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.collections.ns.subpkg', ['utils/fixtures/collections/collections/ns'])
    assert loader is not None

    code = loader.get_code(loader._fullname)
    assert code is not None
    assert code.co_filename == 'ansible_collections/collections/ns/subpkg/__init__.py'

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.collections.ns.subpkg.subsubpkg', ['utils/fixtures/collections/collections/ns'])
    code = loader.get_code(loader._fullname)
    assert code is None


# Generated at 2022-06-11 17:43:13.865342
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.builtin', '.').load_module('ansible.builtin')


_AnsibleCollectionLoader._AnsibleInternalRedirectLoader = _AnsibleInternalRedirectLoader



# Generated at 2022-06-11 17:43:39.032889
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import tempfile
    import shutil
    from ansible.module_utils.common._collections_compat import PATH_HOOKS
    from ansible.module_utils.six import PY3
    import ansible.module_utils.common.ansible_collections.community.general.plugins.module_utils.virtualenv
    paths = [tempfile.mkdtemp()]
    collection_finder = _AnsibleCollectionFinder(paths)
    collection_finder._install()
    # test: if the module name begins with 'ansible_collections', the path_hook will find the module and use the loader provided by
    # the collection_finder
    assert '1' == ansible.module_utils.common.ansible_collections.community.general.plugins.module_utils.virtualenv.is_virtualenv()
    # test:

# Generated at 2022-06-11 17:43:49.540924
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Ensuring _AnsibleCollectionPkgLoaderBase().__repr__() is a <class 'str'>
    _repr_str=str(_AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.jctanner.test_collection", path_list=['/path/to/ansible_collections/jctanner/test_collection']))
    assert isinstance(_repr_str, str)
    # Check if the return string output matches the expected
    assert _repr_str == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/ansible_collections/jctanner/test_collection])'


# Generated at 2022-06-11 17:43:55.913623
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    finder = _AnsibleCollectionFinder()
    finder.find_module("ansible.modules.test")
    finder.find_module("ansible_collections.somens.somecoll.test_module", "/")
    finder.find_module("ansible_collections.somens", "/")
    finder.find_module("ansible_collections")
    finder.find_module("ansible_collections", "/")



# Generated at 2022-06-11 17:44:02.709662
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    pkg_loader_class_name = '_AnsibleCollectionPkgLoaderBase'
    pkg_loader_class = getattr(sys.modules[__name__], pkg_loader_class_name)
    # CONSTANTS
    test_pkg_name = 'ansible_collections.my_namespace.my_collection.plugins.modules'
    test_code_path = '/opt/ansible/ansible_collections/my_namespace/my_collection/plugins/modules'
    test_file = 'test_file.py'
    test_file_path = '/opt/ansible/ansible_collections/my_namespace/my_collection/plugins/modules/test_file.py'
    test_synthetic_file = '__synthetic__'
    # initialize test candidate paths
    test_cand

# Generated at 2022-06-11 17:44:04.987422
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('example.collection.module', '')
    assert loader is not None


# Generated at 2022-06-11 17:44:07.801616
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # TODO: Write test(s) for method try_parse_fqcr of class AnsibleCollectionRef
    pass


# Generated at 2022-06-11 17:44:14.472061
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.coll', path_list=['/foo/bar/baz'])
    with pytest.raises(ValueError) as ve_excobj:
        loader.get_filename('ansible_collections.ns.bob')
    assert "this loader cannot find files for ansible_collections.ns.bob, only ansible_collections.ns.coll" == str(ve_excobj.value)

    assert "/foo/bar/baz/coll/__synthetic__" == loader.get_filename(loader._fullname)


# Generated at 2022-06-11 17:44:25.489866
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # get a temporary directory
    test_dir = tempfile.mkdtemp()

    # create a test module
    test_module_name = 'test_namespace.test_collection.test_module'
    test_module_code = '''
import os
print("Module loaded!")
'''

    # create a collection package directory
    collection_package_dir = os.path.join(test_dir, 'test_namespace', 'test_collection')
    os.makedirs(collection_package_dir)

    # write the test module
    with open(os.path.join(collection_package_dir, 'test_module.py'), 'w') as f:
        f.write(test_module_code)

    # clean up the test environment
    def cleanup():
        shutil.rmtree(test_dir)
   