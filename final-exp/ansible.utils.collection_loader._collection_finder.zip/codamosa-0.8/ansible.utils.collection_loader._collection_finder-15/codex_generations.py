

# Generated at 2022-06-11 17:35:29.859362
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    if 'ansible_collections' not in sys.modules:
        raise Exception('ansible_collections not in sys.modules, unit test precondition failed')

    # use the internal _AnsiblePathHookFinder to create a loader for the Ansible core package; we'll then try to
    # create a subpackage loader with a list of paths that includes the collections path and the core path,
    # so that we can validate a lot of core-and-collections-related behavior in the same unit test,
    # which is really important since the loader will never see the collection path alone in a real environment.

    # HACK: use a different path iterator to get the core path, as the one we use in the path hook uses a
    # different iterator that skips deps paths
    core_deps_mgr = collections.deps_role.CollectionsDep

# Generated at 2022-06-11 17:35:34.974642
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    class_obj = AnsibleCollectionRef(None, None, None, None)
    legacy_plugin_dir_name = 'action_plugins'
    plugin_type = class_obj.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)
    assert plugin_type == 'action', 'Expected to get action as plugin_type, got %s' % plugin_type
    legacy_plugin_dir_name = 'library'
    plugin_type = class_obj.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)
    assert plugin_type == 'modules', 'Expected to get modules as plugin_type, got %s' % plugin_type
    legacy_plugin_dir_name = 'library_files'

# Generated at 2022-06-11 17:35:43.625491
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class DummyClass:
        pass
    _AnsibleCollectionPkgLoaderBase_instance = _AnsibleCollectionPkgLoaderBase(DummyClass, DummyClass)
    _repr = repr(_AnsibleCollectionPkgLoaderBase_instance)
    # assert statements
    assert repr(_AnsibleCollectionPkgLoaderBase_instance) == '_AnsibleCollectionPkgLoaderBase(path=<class \'__main__.DummyClass\'>)', 'expected "<class __main__.DummyClass>", got: ' + repr(_AnsibleCollectionPkgLoaderBase_instance)



# Generated at 2022-06-11 17:35:54.086892
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import os
    import tempfile

    test_dir = tempfile.mkdtemp()
    test_dir_name = os.path.basename(test_dir)
    test_dir_ns = 'ansible_collections.myorg.myns'

    test_file = tempfile.NamedTemporaryFile(dir=test_dir).name
    test_file_name = os.path.basename(test_file)

    test_package_dir = tempfile.mkdtemp(dir=test_dir)
    test_package_dir_name = os.path.basename(test_package_dir)
    test_package_ns = 'ansible_collections.myorg.myns.{0}'.format(test_package_dir_name)


# Generated at 2022-06-11 17:36:04.795358
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("callback_plugins") == "callback"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("connection_plugins") == "connection"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("filter_plugins") == "filter"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("httpapi_plugins") == "httpapi"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("inventory_plugins") == "inventory"

# Generated at 2022-06-11 17:36:14.824931
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import ANY,MagicMock,Mock,call,patch,sentinel
    _fullname = MagicMock(spec_set=str)
    _subpackage_search_paths = MagicMock(spec_set=list)
    _source_code_path = MagicMock(spec_set=str)
    _AnsibleCollectionPkgLoaderBase._fullname = _fullname
    _AnsibleCollectionPkgLoaderBase._subpackage_search_paths = _subpackage_search_paths
    _AnsibleCollectionPkgLoaderBase._source_code_path = _source_code_path
    sut = _AnsibleCollectionPkgLoaderBase(None, sentinel.path_list)

# Generated at 2022-06-11 17:36:18.031048
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    assert load_module(fullname='ansible.playbook.role_include', path_list=['ansible.playbook.role_include']) == None


# Generated at 2022-06-11 17:36:30.194838
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Variables
    fqcr = u"test_col.test_mod"
    ref_type = u"module"

    # Test of be able to parse a valid fqcr and return a AnsibleCollectionRef object
    ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert isinstance(ref, AnsibleCollectionRef)

    # Test that a string that is not a collection reference will return None
    fqcr = u"test_col"
    ref_type = u"module"
    ref = AnsibleCollectionRef.try_parse_fqcr(fqcr, ref_type)
    assert ref is None

    # Test that a string that is not a collection reference, but is properly formatted will return None
    fqcr = u"test_col.test_module"
    ref_type

# Generated at 2022-06-11 17:36:36.600256
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    """
    Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
    """
    fake_loader = _AnsibleCollectionPkgLoaderBase('test')
    fake_loader._source_code_path = '/home/test/__init__.py'
    file_name = fake_loader.get_filename('test')
    assert file_name == '/home/test/__init__.py'


# Generated at 2022-06-11 17:36:44.096737
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    from units.mock.loader import DictDataLoader
    data_loader = DictDataLoader({'__init__.py': '', '__synthetic__': ''})
    loader = _AnsibleCollectionPkgLoaderBase('test', path_list=['/test/path'])
    loader._get_data = data_loader.get_data
    assert loader._fullname == 'test'
    assert loader._split_name == ['test']
    assert loader._rpart_name == ('', '', 'test')
    assert loader._package_to_load == 'test'
    assert loader._parent_package_name == ''
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None

# Generated at 2022-06-11 17:37:44.248531
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import_path = '../ansible_collections/test/plugins/module_utils/ansible_test_collection'
    fullname = 'ansible_collections.test.plugins.module_utils.ansible_test_collection.my_module_utils'
    loader = _AnsibleCollectionPkgLoaderBase(fullname, [import_path])
    # Test for valid code object
    code_obj = loader.get_code(fullname)
    assert isinstance(code_obj, types.CodeType) is True
    # Test for empty string
    loader_empty_string = _AnsibleCollectionPkgLoaderBase(fullname + '.', [import_path])
    assert loader_empty_string.get_code(fullname) is None
    # Test for invalid `fullname`
    assert loader.get_code(fullname)

# Generated at 2022-06-11 17:37:49.771046
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Function not supported by Py2
    if six.PY2:
        return

    collection_finder = _AnsibleCollectionFinder(paths=['/usr/share/ansible'])
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, '/usr/share/ansible')
    path_hook_finder.find_module('ansible_collections.ansible.fake')


# Generated at 2022-06-11 17:37:57.805706
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    acr = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'module', 'module')
    assert acr.collection == u'ns.coll'
    assert acr.subdirs == u'subdir1.subdir2'
    assert acr.resource == u'module'
    assert acr.ref_type == u'module'
    assert acr.n_python_collection_package_name == u'ansible_collections.ns.coll'
    assert acr.n_python_package_name == u'ansible_collections.ns.coll.plugins.module.subdir1.subdir2.module'
    assert acr.fqcr == u'ns.coll.subdir1.subdir2.module'


# Generated at 2022-06-11 17:38:04.073871
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.a.c')
    assert loader._source_code_path is None
    assert loader._subpackage_search_paths is None
    assert loader.is_package(fullname='ansible_collections.ns.a.c') is False
    assert loader.get_filename(fullname='ansible_collections.ns.a.c') == '<string>'
    assert loader.get_filename(fullname='ansible_collections.ns.a.c.d') is None

# Generated at 2022-06-11 17:38:14.897288
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    """
    Unit test for method load_module of class _AnsibleInternalRedirectLoader
    """

    if not _meta_yml_to_dict:
        raise ValueError('ansible.utils.collection_loader._meta_yml_to_dict is not set')

    # Method load_module of class _AnsibleInternalRedirectLoader
    # Unit test for method load_module of class _AnsibleInternalRedirectLoader
    _meta_yml_to_dict = lambda x, y: yaml.safe_load(x)
    # Get a reference to the _AnsibleInternalRedirectLoader class
    _AnsibleInternalRedirectLoader_class = _AnsibleInternalRedirectLoader
    # Get a reference to the method load_module of class _AnsibleInternalRedirectLoader
    _AnsibleInternalRedirectLoader_

# Generated at 2022-06-11 17:38:18.819661
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')



# Generated at 2022-06-11 17:38:28.223724
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert collection_finder._ansible_pkg_path == os.path.dirname(os.path.abspath(__file__))
    assert collection_finder._n_configured_paths == []
    assert collection_finder._n_cached_collection_qualified_paths == None
    assert collection_finder._n_playbook_paths == []
    assert collection_finder._n_collection_paths == []
    assert collection_finder.find_module("ansible") is None
    collection_finder._ansible_collection_path_hook(collection_finder._ansible_pkg_path)
    collection_finder.set_playbook_paths(".")
    assert collection_finder._ansible_pkg_path in collection_finder._n_cached_collection_paths
   

# Generated at 2022-06-11 17:38:37.038339
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    """
    Test the get_filename method of _AnsibleCollectionPkgLoaderBase,
    the abstract class for AnsibleCollectionPkgLoader and AnsibleRolePkgLoader
    Return a truthy value if the get_filename method returns correct value.
    Return a falsey value if the get_filename method is not correct
    """
    # mocked _AnsibleCollectionPkgLoaderBase class
    class Mock_AnsibleCollectionPkgLoaderBase:
        def __init__(self, fullname, path_list):
            self._fullname = fullname
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]

# Generated at 2022-06-11 17:38:44.495967
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    _AnsibleInternalRedirectLoader("ansible.module_utils.basic.AnsibleModule", "ansible.module_utils.basic.AnsibleModule")
    _AnsibleInternalRedirectLoader("ansible.module_utils.connection.Connection", "ansible.module_utils.connection.Connection")


# HACK: stash this in a better place
_meta_yml_to_dict = None



# Generated at 2022-06-11 17:38:54.599371
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    try:
        AnsibleCollectionRef(collection_name='',
                             subdirs=None,
                             resource='',
                             ref_type='')
    except ValueError as e:
        assert str(e).startswith("invalid collection name")
    try:
        AnsibleCollectionRef(collection_name='',
                             subdirs='',
                             resource='',
                             ref_type='')
    except ValueError as e:
        assert str(e).startswith("invalid collection name")
    try:
        AnsibleCollectionRef(collection_name='',
                             subdirs='.subdir1.subdir2',
                             resource='',
                             ref_type='')
    except ValueError as e:
        assert str(e).startswith("invalid collection name")
   

# Generated at 2022-06-11 17:39:25.606118
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    acr = AnsibleCollectionRef.try_parse_fqcr('qux.foo', 'module')
    assert acr.n_python_package_name == 'ansible_collections.qux.foo.plugins.module'
    assert acr.n_python_collection_package_name == 'ansible_collections.qux.foo'
    assert acr.resource == 'module'
    assert acr.collection == 'qux.foo'
    assert acr.fqcr == 'qux.foo.module'
    acr = AnsibleCollectionRef.try_parse_fqcr('qux.foo.bar', 'module')
    assert acr is None


# Generated at 2022-06-11 17:39:33.912585
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    try:
        _AnsibleCollectionPkgLoaderBase().get_data(path=None)
    except ValueError:
        pass
    else:
        assert False

    try:
        _AnsibleCollectionPkgLoaderBase().get_data(path='files/')
    except ValueError:
        pass
    else:
        assert False

    content = _AnsibleCollectionPkgLoaderBase().get_data(path='/does/not/exist')
    assert content == None

    content = _AnsibleCollectionPkgLoaderBase().get_data(path='/does/not/exist/__init__.py')
    assert content == ''

    content = _AnsibleCollectionPkgLoaderBase().get_data(path='files/')
    assert content == None

    content = _AnsibleCollectionPkgLoaderBase().get_

# Generated at 2022-06-11 17:39:43.867268
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr(None, None) is None
    assert AnsibleCollectionRef.try_parse_fqcr(None, 'test') is None
    assert AnsibleCollectionRef.try_parse_fqcr('test', None) is None
    assert AnsibleCollectionRef.try_parse_fqcr('test', 'test') is None
    assert AnsibleCollectionRef.try_parse_fqcr('test.test', None) is None
    assert AnsibleCollectionRef.try_parse_fqcr('test.test', 'test') is None
    assert AnsibleCollectionRef.try_parse_fqcr('test.test', 'module') is None
    assert AnsibleCollectionRef.try_parse_fqcr('test.test.test', 'module') is None

# Generated at 2022-06-11 17:39:54.159316
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionPathHook
    from ansible.utils.collection_loader._collection_pkg_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader._collection_pkg_loader import _AnsibleCollectionNSPackageLoader
    import sys
    import os

    # let's look a very simple collection
    collection_1 = os.path.join(_FIXTURE_BASE, 'ansible_collections', 'my_namespace', 'my_collection')
    # let's look at a collection with a top-level submodule

# Generated at 2022-06-11 17:40:05.100879
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test invalid ref
    a = AnsibleCollectionRef('namespace.collection','', 'resource', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection.subdirectory', '', 'resource', 'module')

    # Test invalid ref
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection.subdirectory', 'subdirectory', 'resource', 'module')

    # Test valid subdir
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.sub1', 'role')

    # Test invalid subdir
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.-sub1', 'role')

    # Test invalid collection name

# Generated at 2022-06-11 17:40:11.996595
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef('namespace.collectionname', None, 'resource', 'doc_fragments').n_python_collection_package_name == 'ansible_collections.namespace.collectionname'
    assert AnsibleCollectionRef('namespace.collectionname', None, 'resource', 'doc_fragments').n_python_package_name == 'ansible_collections.namespace.collectionname.plugins.doc_fragments.resource'
    assert AnsibleCollectionRef('namespace.collectionname', 'subdir1.subdir2', 'resource', 'doc_fragments').n_python_collection_package_name == 'ansible_collections.namespace.collectionname'
    assert AnsibleCollectionRef('namespace.collectionname', 'subdir1.subdir2', 'resource', 'doc_fragments').n_python_package

# Generated at 2022-06-11 17:40:22.739825
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # normal valid constructor, with collection distro, subdirs, resource, and ref_type
    assert AnsibleCollectionRef(u'namespace.collection', u'subdir1.subdir2', u'resource', u'role').fqcr == u'namespace.collection.subdir1.subdir2.resource'

    with pytest.raises(ValueError):
        AnsibleCollectionRef(u'invalid_namespace.invalid_collection', u'subdir1.subdir2', u'resource', u'role')

    # test "optional" attributes
    assert AnsibleCollectionRef(u'namespace.collection', u'', u'resource', u'role').fqcr == u'namespace.collection.resource'
    assert AnsibleCollectionRef(u'namespace.collection', None, u'resource', u'role').fq

# Generated at 2022-06-11 17:40:32.569393
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible_collections.not_a_real_collection.plugins.module_utils.facts.system.distribution import rhel  # noqa

    assert isinstance(_AnsibleCollectionPkgLoaderBase(rhel.__name__, [os.path.dirname(rhel.__file__)]), _AnsibleCollectionPkgLoaderBase) # noqa
    loader = _AnsibleCollectionPkgLoaderBase(rhel.__name__, [os.path.dirname(rhel.__file__)])
    data = loader.get_data(rhel.__file__)
    assert data is not None


# Generated at 2022-06-11 17:40:40.099621
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    if not _meta_yml_to_dict:
        raise ValueError('ansible.utils.collection_loader._meta_yml_to_dict is not set')

    pkg_path = os.path.dirname(os.path.dirname(__file__))
    builtin_meta_path = os.path.join(pkg_path, 'config/ansible_builtin_runtime.yml')
    with open(to_bytes(builtin_meta_path), 'rb') as fd:
        raw_meta = fd.read()

# Generated at 2022-06-11 17:40:48.000108
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # action_plugins
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action') == 'action'
    # cache_plugins
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache') == 'cache'
    # callback_plugins
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback') == 'callback'
    # cliconf_plugins
    assert AnsibleCollection

# Generated at 2022-06-11 17:42:21.513514
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('')  # class under test
    for prefix in ('test_plugin', 'collection.test_plugin', 'test_plugin.test'):
        try:
            loader.get_code(prefix)
        except IOError:
            # the path 'ansible_collections.test_plugin' does not exist, ignore
            pass



# Generated at 2022-06-11 17:42:32.113865
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Reference:
    # https://docs.python.org/3/library/unittest.html
    # https://docs.python.org/3/library/unittest.mock.html
    # https://docs.python.org/3/library/unittest.mock-examples.html
    import unittest
    import unittest.mock

    from ansible.utils._text import to_native

    class TestSrcLoader(unittest.TestCase):

        def setUp(self):
            self.loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.namespace.package', path_list=['path_list'])
            self.loader.get_source = unittest.mock.MagicMock()

# Generated at 2022-06-11 17:42:41.145622
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_file='/tmp/test_file.txt'
    test_path='/tmp/test_path/'
    test_data = 'Test data'
    test_data_bytes = b'Test data'
    with open(test_file, 'wb') as testfile:
        testfile.write(test_data_bytes)

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.namespace.collection')
    assert None == loader._SyntheticCollectionResourceLoader__search_paths
    assert loader.get_data(test_file) == test_data_bytes
    assert loader.get_data(test_path) is None
    os.unlink(test_file)



# Generated at 2022-06-11 17:42:51.247874
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_module_name = 'ansible.module_utils'
    test_module_name_without_ansible = 'module_utils'
    redirect_module = 'module_utils.facts'
    class MockRedirectLoader:
        def __init__(self, redirect_module):
            self.redirect_module=redirect_module
        def load_module(self, name):
            return self.redirect_module
    class MockModule:
        class_var = None
        def __init__(self, redirect_module):
            self.redirect_module = redirect_module
        def set_class_var(self, var):
            self.class_var = var
    test_module_mock = MockModule(redirect_module)

# Generated at 2022-06-11 17:42:58.556368
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    # This is testing for a simple string transform method
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'

    # This is testing for a method that throws an exception if you provide invalid input
    try:
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('foo_plugins')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-11 17:43:02.793461
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # This should work
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.foo.bar', 'module')

    # This should fail
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.foo.bar.bat', 'module')



# Generated at 2022-06-11 17:43:10.116651
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    try:
        ansible_collections = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo.bar")
        result = ansible_collections.get_filename("ansible_collections.foo.bar.baz")
    except Exception as e:
        raise e
    if isinstance(result, str):
        assert True
    else:
        assert False

test__AnsibleCollectionPkgLoaderBase_get_filename()

# Generated at 2022-06-11 17:43:12.997407
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ldr = _AnsibleCollectionPkgLoaderBase("test")
    assert repr(ldr) == '_AnsibleCollectionPkgLoaderBase(path=None)'

# Generated at 2022-06-11 17:43:23.182490
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-11 17:43:35.109816
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    import pytest

    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.try_parse_fqcr(None)

    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.try_parse_fqcr('')

    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.try_parse_fqcr(' ')

    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.try_parse_fqcr('ns1.coll1.')

    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.try_parse_fqcr('ns1.coll1.res1.fake1')

    with pytest.raises(ValueError):
        collection

# Generated at 2022-06-11 17:44:05.384181
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # see the unittest of the method that calls this method for more details
    raise NotImplementedError()

# Generated at 2022-06-11 17:44:08.340484
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    module_name = 'ansible_collections.ns.module'
    loader_class = _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:44:14.796574
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test method load_module of class _AnsibleInternalRedirectLoader

    # no redirection
    try:
        _AnsibleInternalRedirectLoader('ansible', None).load_module('ansible.builtin')
        assert False, "expected exception"
    except ImportError:
        pass

    try:
        _AnsibleInternalRedirectLoader('ansible', None).load_module('ansible.builtin.plugins')
        assert False, "expected exception"
    except ImportError:
        pass

    try:
        _AnsibleInternalRedirectLoader('ansible', None).load_module('ansible.builtin.plugins.action')
        assert False, "expected exception"
    except ImportError:
        pass


# Generated at 2022-06-11 17:44:25.776258
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.utils.collection_loader as loader
    loader._get_collection_metadata = get_collection_metadata
    from ansible.collection import namedtuple
    import_redirection = {
        'ansible.builtin.config': {
            'redirect': 'ansible.config.manager'
        }
    }
    builtin_meta = {
        'import_redirection': import_redirection
    }
    def get_collection_metadata(coll_name, config=None):
        if coll_name == 'ansible.builtin':
            return builtin_meta
        else:
            return None

    # case where redirect is not found, hence load_module throws error
    ans_internal_loader = loader._AnsibleInternalRedirectLoader('ansible.builtin.config', [])