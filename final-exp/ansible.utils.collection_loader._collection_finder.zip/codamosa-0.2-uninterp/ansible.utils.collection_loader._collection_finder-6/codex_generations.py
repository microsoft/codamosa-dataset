

# Generated at 2022-06-17 14:43:52.157615
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module')
    loader._source_code_path = 'ansible_collections/test/test_collection/test_module.py'
    loader._decoded_source = '#!/usr/bin/python\n'
    loader._compiled_code = compile(source='#!/usr/bin/python\n', filename='ansible_collections/test/test_collection/test_module.py', mode='exec', flags=0, dont_inherit=True)
    module = loader.load_module('ansible_collections.test.test_collection.test_module')
    assert module.__file__ == 'ansible_collections/test/test_collection/test_module.py'


# Generated at 2022-06-17 14:44:03.876809
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid collection reference
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.subdir2.module'
    assert ref.fqcr == 'ns.coll.subdir1.subdir2.resource'

    # Test with valid collection reference with no subdirs

# Generated at 2022-06-17 14:44:15.122283
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)

        def test_get_code(self):
            # test with a package
            pkg_path = os.path.join(self.tmpdir, 'ansible_collections', 'test_ns', 'test_coll')
            os.makedirs(pkg_path)
            with open(os.path.join(pkg_path, '__init__.py'), 'w') as f:
                f.write('# test package init')

# Generated at 2022-06-17 14:44:21.613468
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test case 1
    # Test for the case where _meta_yml_to_dict is not set
    # Expected result: ValueError
    try:
        _AnsibleCollectionPkgLoader(path=None, package_to_load='ansible_collections').load_module('ansible_collections')
    except ValueError:
        pass
    else:
        assert False

    # Test case 2
    # Test for the case where collection_name is ansible.builtin
    # Expected result:
    _AnsibleCollectionPkgLoader(path=None, package_to_load='ansible_collections').load_module('ansible_collections.ansible.builtin')

    # Test case 3
    # Test for the case where collection_name is not ansible.builtin
    # Expected result:
    _

# Generated at 2022-06-17 14:44:29.829027
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import sys
    import tempfile
    import unittest
    import shutil
    import textwrap

    from ansible.module_utils.six import PY3

    from ansible.module_utils._text import to_bytes, to_text

    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoaderBase

    class TestLoader(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(TestLoader, self).__init__(fullname, path_list)

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths


# Generated at 2022-06-17 14:44:39.873931
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _meta_yml_to_dict
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionRootPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _iter_modules_impl
    from ansible.utils.collection_loader import _AnsibleCollectionLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionLoaderBaseImpl

# Generated at 2022-06-17 14:44:51.929188
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test for method get_code(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for empty source code
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_ns.my_coll')
    loader._source_code_path = 'ansible_collections/my_ns/my_coll/__init__.py'
    loader._subpackage_search_paths = ['ansible_collections/my_ns/my_coll']
    assert loader.get_code('ansible_collections.my_ns.my_coll') is None
    # test for non-empty source code
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_ns.my_coll')

# Generated at 2022-06-17 14:44:52.739262
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:44:57.397055
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for path is None
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data(None)
    # test for path is not None
    assert _AnsibleCollectionPkgLoaderBase().get_data('/tmp/test') is None



# Generated at 2022-06-17 14:44:58.640304
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass



# Generated at 2022-06-17 14:45:49.704353
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:45:57.085216
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # test for invalid package name
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.foo.bar')

    # test for valid package name
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.foo')
    assert loader._fullname == 'ansible_collections.foo'
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'foo'


# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on the configured collection root path, and Python namespace package aggregation is not allowed at or

# Generated at 2022-06-17 14:46:01.203676
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    import os
    import sys
    import importlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the collection directory
    collection_dir = os.path.join(tmpdir, 'ansible_collections', 'test_namespace', 'test_collection')
    os.makedirs(collection_dir)

    # Create the module file
    module_file = os.path.join(collection_dir, 'test_module.py')
    with open(module_file, 'w') as f:
        f.write('# test module')

    # Create the package directory
    package_dir = os.path.join(collection_dir, 'test_package')
    os.makedirs(package_dir)

    # Create the package file
    package_

# Generated at 2022-06-17 14:46:07.240420
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
    assert loader.is_package('ansible_collections.ns.module') == False
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.package')
    assert loader.is_package('ansible_collections.ns.package') == True

# Generated at 2022-06-17 14:46:13.413397
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader

# Generated at 2022-06-17 14:46:21.873573
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:26.280135
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # test_is_package_with_no_subpackage_search_paths_returns_false
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll'])
    assert loader.is_package('ansible_collections.test_ns.test_coll') == False

    # test_is_package_with_subpackage_search_paths_returns_true
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll'])
    loader._subpackage_search_paths = ['/path/to/test_coll']

# Generated at 2022-06-17 14:46:34.878961
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'playbook')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'not_a_valid_ref_type')
    assert not Ansible

# Generated at 2022-06-17 14:46:40.641825
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test for method get_source(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    #
    # This is a test for the method get_source of the class _AnsibleCollectionPkgLoaderBase
    #
    # The test case is:
    #
    # 1. Create a class _AnsibleCollectionPkgLoaderBase
    # 2. Call the method get_source
    # 3. Assert the result
    #
    # The test case is not implemented yet.
    pass


# Generated at 2022-06-17 14:46:49.901732
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:47:45.373445
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils.common.text.converters import to_native, to_text, to_bytes
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six import PY3
    from ._collection_config import AnsibleCollectionConfig
    from contextlib import contextmanager
    from types import ModuleType
    from importlib import import_module
    from importlib import reload as reload_module
    from tokenize import Name as _VALID_IDENTIFIER_REGEX
    from keyword import iskeyword

# Generated at 2022-06-17 14:47:56.915344
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test with a path that does not exist
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', path_list=['/tmp/test_collection'])
    assert loader.get_source('ansible_collections.test.test_collection') is None

    # Test with a path that exists
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', path_list=['/tmp'])
    assert loader.get_source('ansible_collections.test.test_collection') is None

    # Test with a path that exists and a file that exists
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', path_list=['/tmp'])

# Generated at 2022-06-17 14:48:02.089404
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a valid module
    module_name = 'ansible_collections.test.test_collection.test_module'
    module_path = os.path.join(os.path.dirname(__file__), 'test_collection', 'test_module.py')

# Generated at 2022-06-17 14:48:07.819521
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # test for method get_data of class _AnsibleCollectionPkgLoaderBase
    # mock _AnsibleCollectionPkgLoaderBase
    class Mock_AnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.

# Generated at 2022-06-17 14:48:19.920182
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir.resource')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir.subdir.resource')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir.subdir.subdir.resource')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir.subdir.subdir.subdir.resource')

# Generated at 2022-06-17 14:48:30.850952
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1
    # Test for the case when path is not specified
    # Expected result: ValueError
    try:
        _AnsibleCollectionPkgLoaderBase.get_data(None)
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    # Test case 2
    # Test for the case when path is relative
    # Expected result: ValueError

# Generated at 2022-06-17 14:48:34.581408
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test for method load_module of class _AnsibleInternalRedirectLoader
    # This test is not implemented
    pass

# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:48:46.434736
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.pkg', path_list=['/path/to/pkg'])
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/pkg])'

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.pkg.mod', path_list=['/path/to/pkg'])
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/path/to/pkg/mod.py)'



# Generated at 2022-06-17 14:48:52.484064
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _meta_yml_to_dict
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionFinder
    from ansible.utils.collection_loader import AnsibleCollectionLoaderBase
    from ansible.utils.collection_loader import AnsibleCollectionFinderBase
    from ansible.utils.collection_loader import AnsibleCollectionConfigBase
    from ansible.utils.collection_loader import AnsibleCollectionConfigData
    from ansible.utils.collection_loader import AnsibleCollectionConfigParser
    from ansible.utils.collection_loader import AnsibleCollectionConfigParserBase

# Generated at 2022-06-17 14:49:03.302308
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.pkg', path_list=['/path/to/ns'])
    assert loader.get_filename('ansible_collections.ns.pkg') == '/path/to/ns/pkg/__synthetic__'

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.pkg.mod', path_list=['/path/to/ns'])
    assert loader.get_filename('ansible_collections.ns.pkg.mod') == '/path/to/ns/pkg/mod.py'

    # Test with a package with multiple paths

# Generated at 2022-06-17 14:50:47.801996
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for valid fqcr
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fq

# Generated at 2022-06-17 14:50:57.055593
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:51:07.451516
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.utils.collection_loader import _AnsibleCollectionFinder

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the file system structure:
    #   <tmp_dir>/
    #       ansible_collections/
    #           ansible/
    #               plugins/
    #                   module_utils/
    #                       foo.py
    #           my_namespace/
    #               my_collection/
    #                   plugins/
    #                       module_utils/
    #                           bar.py
    #           my_namespace2/
    #               my_

# Generated at 2022-06-17 14:51:17.813107
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-17 14:51:27.891410
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import sys
    import os
    import tempfile
    import shutil
    import textwrap
    import importlib
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.machinery_source
    import importlib.machinery_bytecode
    import importlib.machinery_synthetic
    import importlib.machinery_path
    import importlib.machinery_pkgutil
    import importlib.machinery_pkgresources
    import importlib.machinery_pkg_resources
    import importlib.machinery_pkg_resources_loader
    import importlib.machinery_pkg_resources_loader_synthetic
    import importlib.machinery_pkg_resources_loader_bytecode
    import importlib.machinery_pkg_resources

# Generated at 2022-06-17 14:51:38.175637
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # test_get_code_with_code_object
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
    loader._source_code_path = 'ansible_collections/ns/module.py'
    loader._compiled_code = compile('print("Hello World")', 'ansible_collections/ns/module.py', 'exec')
    assert loader.get_code('ansible_collections.ns.module') == loader._compiled_code

    # test_get_code_with_no_code_object
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
    loader._source_code_path = 'ansible_collections/ns/module.py'

# Generated at 2022-06-17 14:51:38.866320
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass



# Generated at 2022-06-17 14:51:43.545690
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])
    assert loader._redirect == 'ansible.module_utils.basic'


# this is the path hook that will be registered with sys.meta_path. It looks for Ansible Python modules and
# redirects them to the appropriate collection.

# Generated at 2022-06-17 14:51:49.373886
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:52:00.994790
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert Ans

# Generated at 2022-06-17 14:52:37.073743
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for the case where the module is not in the ansible package
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.module_utils.foo', None)

    # Test for the case where the module is in the ansible package, but is not redirected
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.builtin.foo', None)

    # Test for the case where the module is in the ansible package and is redirected
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.module_utils.foo', None)
    assert loader._redirect == 'ansible.module_utils.foo'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook

# Generated at 2022-06-17 14:52:45.894190
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _meta_yml_to_dict
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionNotFound
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleFileLoader
    from ansible.utils.collection_loader import AnsibleModuleNotFound
    from ansible.utils.collection_loader import AnsibleModuleRef
    from ansible.utils.collection_loader import AnsiblePackageLoader
    from ansible.utils.collection_loader import AnsiblePackageNotFound

# Generated at 2022-06-17 14:52:54.637525
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'subdir1', 'rolename', 'role')

# Generated at 2022-06-17 14:53:06.120282
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'