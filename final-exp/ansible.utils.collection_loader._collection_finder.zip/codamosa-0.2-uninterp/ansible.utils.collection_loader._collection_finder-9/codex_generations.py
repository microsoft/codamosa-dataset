

# Generated at 2022-06-17 14:44:16.304765
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:44:21.535265
# Unit test for constructor of class _AnsibleCollectionLoader

# Generated at 2022-06-17 14:44:29.828198
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for normal import
    try:
        _AnsibleInternalRedirectLoader('ansible.module_utils.basic', None)
        assert False
    except ImportError:
        pass

    # Test for import of ansible.builtin.module_utils.basic
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.module_utils.basic', None)
    assert loader._redirect == 'ansible.module_utils.basic'

    # Test for import of ansible.builtin.module_utils.basic.basic
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.module_utils.basic.basic', None)
    assert loader._redirect == 'ansible.module_utils.basic.basic'

    # Test for import of ansible.builtin.module_utils.basic.basic.basic

# Generated at 2022-06-17 14:44:39.823617
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with a valid redirect
    fullname = 'ansible.builtin.copy'
    path_list = []
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    loader._redirect = 'ansible.builtin.copy'
    assert loader.load_module(fullname) == import_module('ansible.builtin.copy')

    # Test with an invalid redirect
    fullname = 'ansible.builtin.copy'
    path_list = []
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    loader._redirect = 'ansible.builtin.copy_invalid'
    assert loader.load_module(fullname) == import_module('ansible.builtin.copy_invalid')


# This loader only answers for intercepted Ansible Python modules.

# Generated at 2022-06-17 14:44:51.887589
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionRedirectLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSRedirectLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSNoCodeLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSNoCodeRedirectLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSNoCodeSyntheticLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSNoCodeSyntheticRedirectLoader

# Generated at 2022-06-17 14:44:59.566174
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub2')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub2.sub3')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub2.sub3.sub4')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub2.sub3.sub4.sub5')
    assert not AnsibleCollectionRef.is_valid_collection_name

# Generated at 2022-06-17 14:45:09.237193
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test for ansible.builtin
    loader = _AnsibleInternalRedirectLoader('ansible.builtin', [])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', [])
    assert loader._redirect == 'ansible.builtin.foo'

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar', [])
    assert loader._redirect == 'ansible.builtin.foo.bar'

    # test for ansible.module_utils
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils', [])
    assert loader._redirect == 'ansible.module_utils'

    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.foo', [])

# Generated at 2022-06-17 14:45:20.724347
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:45:31.002946
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:45:45.227792
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:23.016945
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionRedirectLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSRedirectLoader
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    from ansible.utils.collection_loader import _AnsiblePathHookFinder
    from ansible.utils.collection_loader import _AnsiblePathHook
    from ansible.utils.collection_loader import _AnsiblePathHookFinder
    from ansible.utils.collection_loader import _Ans

# Generated at 2022-06-17 14:46:28.853184
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test with a valid collection name
    collection_name = 'namespace.collection'
    subdirs = 'subdir1.subdir2'
    resource = 'mymodule'
    ref_type = 'module'
    ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert repr(ref) == 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'subdir1.subdir2\', resource=\'mymodule\')'
    # Test with an invalid collection name
    collection_name = 'namespace.collection.name'
    ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    with pytest.raises(ValueError):
        repr(ref)


# Generated at 2022-06-17 14:46:37.871605
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:49.099472
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:59.453497
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('ansible_collections.namespace.collection', ['/path/to/collections'])
    assert loader._package_to_load == 'collection'
    assert loader._parent_package_name == 'ansible_collections.namespace'
    assert loader._fullname == 'ansible_collections.namespace.collection'
    assert loader._split_name == ['ansible_collections', 'namespace', 'collection']
    assert loader._candidate_paths == ['/path/to/collections/namespace/collection']
    assert loader._subpackage_search_paths == ['/path/to/collections/namespace/collection']
    assert loader._source_code_path == '/path/to/collections/namespace/collection/__init__.py'
    assert loader._comp

# Generated at 2022-06-17 14:47:11.884178
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-name')

    # Test invalid collection names
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll name')
    assert not Ans

# Generated at 2022-06-17 14:47:22.609419
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:33.367630
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import ansible_collections.somens.collection_name.plugins.module_utils.somemodule
    loader = ansible_collections.somens.collection_name.plugins.module_utils.somemodule.__loader__
    assert loader.is_package('ansible_collections.somens.collection_name.plugins.module_utils.somemodule')
    assert not loader.is_package('ansible_collections.somens.collection_name.plugins.module_utils')
    assert not loader.is_package('ansible_collections.somens.collection_name.plugins')
    assert not loader.is_package('ansible_collections.somens.collection_name')
    assert not loader.is_package('ansible_collections.somens')

# Generated at 2022-06-17 14:47:46.494541
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    loader = _AnsibleCollectionPkgLoader(['ansible_collections', 'my_namespace', 'my_collection'], ['/path/to/my_collection'])
    loader.load_module('ansible_collections.my_namespace.my_collection')
    assert loader._collection_meta == {}
    assert loader._compiled_code is not None
    assert loader._decoded_source is not None
    assert loader._redirect_module is None
    assert loader._source_code_path is not None
    assert loader._subpackage_search_paths == ['/path/to/my_collection']
    assert loader._package_to_load == 'my_collection'

# Generated at 2022-06-17 14:47:51.204889
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    loader = _AnsibleCollectionPkgLoader(['ansible_collections', 'test', 'collection'], None)
    loader.load_module('ansible_collections.test.collection')
    assert loader._collection_meta == {}


# Generated at 2022-06-17 14:48:24.613209
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1
    # Test for a path that is not a file
    # Expected result: None
    test_path = '/tmp/test_path'
    test_loader = _AnsibleCollectionPkgLoaderBase('test_loader', [])
    assert test_loader.get_data(test_path) is None

    # Test case 2
    # Test for a path that is a file
    # Expected result: The content of the file
    test_path = '/tmp/test_path'
    test_loader = _AnsibleCollectionPkgLoaderBase('test_loader', [])
    with open(test_path, 'w') as f:
        f.write('test_content')
    assert test_loader.get_data(test_path) == b'test_content'
    os.remove(test_path)



# Generated at 2022-06-17 14:48:26.880422
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:48:34.510293
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for package with only one subpackage
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll'])
    assert loader.get_filename('ansible_collections.test_ns.test_coll') == '/path/to/test_coll/__synthetic__'

    # Test for package with multiple subpackages
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll', '/path/to/test_coll2'])
    assert loader.get_filename('ansible_collections.test_ns.test_coll') == '<ansible_synthetic_collection_package>'

    # Test for package

# Generated at 2022-06-17 14:48:45.092901
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test with empty path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test', [])
    assert list(loader.iter_modules('')) == []

    # Test with non-empty path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test', ['test/unit/data/collection_loader'])
    assert list(loader.iter_modules('')) == [('ansible_collections.test.test_collection_loader', True)]



# Generated at 2022-06-17 14:48:46.946101
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six', [])
    assert loader._redirect == 'ansible.module_utils.six'


# Generated at 2022-06-17 14:48:58.377623
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    from ansible.utils.collection_loader import _AnsibleCollectionLoader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionRootPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSPkgLoader
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.utils.collection_loader import _AnsiblePathHookFinder
    import os
    import sys
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a collection directory

# Generated at 2022-06-17 14:49:06.424479
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for a package with a single path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.package', path_list=['/path/to/package'])
    assert loader.get_filename('ansible_collections.ns.package') == '/path/to/package/__synthetic__'

    # Test for a package with multiple paths
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.package', path_list=['/path/to/package', '/path/to/package2'])
    assert loader.get_filename('ansible_collections.ns.package') == '<ansible_synthetic_collection_package>'

    # Test for a module

# Generated at 2022-06-17 14:49:15.978198
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import sys
    import tempfile
    import shutil
    import importlib
    import importlib.abc
    import importlib.util
    import unittest

    class _TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

        def _validate_final(self):
            pass

    class _TestAnsibleCollectionPkgLoader(_TestAnsibleCollectionPkgLoaderBase):
        def _get_subpackage_search_paths(self, candidate_paths):
            return None


# Generated at 2022-06-17 14:49:17.195910
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:49:25.064467
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('vars_plugins') == 'vars'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'

# Generated at 2022-06-17 14:50:22.278055
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for valid fqcr
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')

# Generated at 2022-06-17 14:50:26.177077
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for method get_filename(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # This method is tested by the other tests in this module.
    pass


# Generated at 2022-06-17 14:50:33.236406
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'role')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'playbook')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'doc_fragment')
    assert not AnsibleCollectionRef

# Generated at 2022-06-17 14:50:35.405619
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-17 14:50:41.476218
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('namespace.collection', 'subdirs', 'resource', 'ref_type').__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-17 14:50:47.379539
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'

# Generated at 2022-06-17 14:50:51.978566
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test the case that the collection name is ansible.builtin
    # Test the case that the collection name is not ansible.builtin
    pass


# handles locating the actual collection package and associated metadata

# Generated at 2022-06-17 14:51:03.346906
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:51:11.106102
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname123')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname_123')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname123_')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname_123_')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname_123_456')
    assert AnsibleCollectionRef.is_valid_collection

# Generated at 2022-06-17 14:51:21.111274
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module').fqcr == 'ns.coll.resource'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module').fqcr == 'ns.coll.subdir1.resource'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role').fqcr == 'ns.coll.rolename'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role').fqcr == 'ns.coll.rolename'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname.yml', 'playbook').fqcr == 'ns.coll.playbookname'
    assert AnsibleCollectionRef.from_

# Generated at 2022-06-17 14:53:09.155094
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase