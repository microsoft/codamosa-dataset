

# Generated at 2022-06-17 14:43:53.966102
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import os
    import tempfile
    import shutil
    import sys
    import unittest

    class Test_AnsibleCollectionPkgLoaderBase_iter_modules(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)

            self.test_dir_path = to_bytes(self.test_dir)
            self.test_dir_path_native = to_native(self.test_dir)

            self.test_dir_path_native_subdir = os.path.join(self.test_dir_path_native, 'subdir')
            os.mkdir(self.test_dir_path_native_subdir)

            self.test_dir_path_

# Generated at 2022-06-17 14:44:00.871470
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:44:05.752644
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # test valid fqcr
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yaml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yaml', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yaml', 'playbook')
    assert AnsibleCollectionRef.is_

# Generated at 2022-06-17 14:44:15.745049
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Test _AnsibleCollectionPkgLoaderBase._validate_args()
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoaderBase('ansible.test')

    # Test _AnsibleCollectionPkgLoaderBase._get_candidate_paths()
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test')
    assert loader._get_candidate_paths(['/a/b', '/c/d']) == ['/a/b/test', '/c/d/test']

    # Test _AnsibleCollectionPkgLoaderBase._get_subpackage_search_paths()
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test')

# Generated at 2022-06-17 14:44:17.700722
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for get_filename method of class _AnsibleCollectionPkgLoaderBase
    # Arrange
    # Act
    # Assert
    assert True



# Generated at 2022-06-17 14:44:18.936794
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass



# Generated at 2022-06-17 14:44:26.226670
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid collection reference
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # Test with valid collection reference with subdirs
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')

# Generated at 2022-06-17 14:44:37.316514
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name.name.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name.name.name.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name.name.name.name.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.name.name.name.name.name.name')
    assert not AnsibleCollectionRef.is_valid

# Generated at 2022-06-17 14:44:38.408107
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:44:50.927757
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Test for valid input
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns1', path_list=['/path/to/collections'])
    assert loader._fullname == 'ansible_collections.ns1'
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'ns1'
    assert loader._candidate_paths == ['/path/to/collections/ns1']
    assert loader._subpackage_search_paths == []
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None

    # Test for invalid input

# Generated at 2022-06-17 14:45:14.354087
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:45:24.964667
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/path/to/foo/bar']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/path/to/foo/bar)'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/path/to/foo/bar']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/path/to/foo/bar)'

# Generated at 2022-06-17 14:45:32.887257
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test constructor of class AnsibleCollectionRef
    # Test with valid inputs
    ref = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module.subdir1.subdir2.resource'
    assert ref.fqcr == 'ns.coll.subdir1.subdir2.resource'


# Generated at 2022-06-17 14:45:38.379343
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test that we don't answer for non-ansible imports
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo.bar', None)

    # test that we don't answer for non-redirected imports
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.foo', None)

    # test that we answer for redirected imports
    assert _AnsibleInternalRedirectLoader('ansible.builtin.foo', None)


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:45:48.606662
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:45:59.160761
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('vars_plugins')

# Generated at 2022-06-17 14:46:11.548786
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for invalid collection name
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')

    # Test for invalid subdirs
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2.subdir3', 'resource', 'module')

    # Test for invalid ref_type
    with pytest.raises(ValueError):
        AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'invalid_ref_type')

    # Test for valid collection name
    assert AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')

    # Test for valid subdirs

# Generated at 2022-06-17 14:46:20.415332
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test case 1
    # Test for the case when the filename is not None
    # Input:
    #   fullname = 'ansible_collections.test_collection.test_namespace.test_module'
    #   self._fullname = 'ansible_collections.test_collection.test_namespace.test_module'
    #   self._source_code_path = 'ansible_collections/test_collection/test_namespace/test_module.py'
    #   self._subpackage_search_paths = None
    # Expected result:
    #   filename = 'ansible_collections/test_collection/test_namespace/test_module.py'
    fullname = 'ansible_collections.test_collection.test_namespace.test_module'
    test_loader = _AnsibleCollection

# Generated at 2022-06-17 14:46:25.006850
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:46:34.285158
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test_collection')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test_collection_1')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test_collection_1.2')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test_collection_1.2.3')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test_collection_1.2.3.4')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.test_collection_1.2.3.4.5')

# Generated at 2022-06-17 14:46:57.253098
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # TODO: implement
    pass

# Generated at 2022-06-17 14:47:09.108462
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary subdirectory
    temp_subdir = tempfile.mkdtemp(dir=temp_dir)
    # Create a temporary file in the subdirectory
    temp_subfile = tempfile.NamedTemporaryFile(dir=temp_subdir, delete=False)
    # Create a temporary subdirectory in the subdirectory
    temp_subsubdir = tempfile.mkdtemp(dir=temp_subdir)
    # Create a temporary file in the subdirectory in the subdirectory
    temp_subsubfile = tempfile.NamedTemporaryFile(dir=temp_subsubdir, delete=False)
    # Create

# Generated at 2022-06-17 14:47:13.732394
# Unit test for method find_module of class _AnsiblePathHookFinder

# Generated at 2022-06-17 14:47:23.906796
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext.ext.ext')

# Generated at 2022-06-17 14:47:34.173769
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    class Test__AnsibleCollectionPkgLoaderBase_get_code(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempdir_path = os.path.join(self.tempdir, 'ansible_collections', 'test_namespace', 'test_collection')
            os.makedirs(self.tempdir_path)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 14:47:46.708376
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:52.077813
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:59.726287
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test with valid ref
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yaml', 'playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yaml', 'playbook')

# Generated at 2022-06-17 14:48:05.165839
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(collection_name='namespace.collection', subdirs=None, resource='resource', ref_type='ref_type')
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collection', subdirs=None, resource='resource')"


# Generated at 2022-06-17 14:48:17.705591
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for get_filename when source code path is not None
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_collection.test_namespace.test_module', path_list=['/path/to/test_collection/test_namespace'])
    loader._source_code_path = '/path/to/test_collection/test_namespace/test_module.py'
    assert loader.get_filename('ansible_collections.test_collection.test_namespace.test_module') == '/path/to/test_collection/test_namespace/test_module.py'

    # Test for get_filename when source code path is None and is_package is True

# Generated at 2022-06-17 14:48:41.516740
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 14:48:50.095137
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:49:01.109687
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1'


# Generated at 2022-06-17 14:49:10.407229
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')

# Generated at 2022-06-17 14:49:20.533267
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-17 14:49:27.108069
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test for method is_valid_fqcr(ref, ref_type=None)
    # of class AnsibleCollectionRef
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yml', 'playbook')
   

# Generated at 2022-06-17 14:49:37.544157
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with a valid collection reference
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # Test with a valid collection reference with subdirs
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')

# Generated at 2022-06-17 14:49:47.967836
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import tempfile
    import shutil
    import os
    import sys
    import os.path
    import pkgutil
    import re
    import sys
    from keyword import iskeyword
    from tokenize import Name as _VALID_IDENTIFIER_REGEX

    # DO NOT add new non-stdlib import deps here, this loader is used by external tools (eg ansible-test import sanity)
    # that only allow stdlib and module_utils
    from ansible.module_utils.common.text.converters import to_native, to_text, to_bytes
    from ansible.module_utils.six import string_types, PY3
    from ._collection_config import AnsibleCollectionConfig

    from contextlib import contextmanager
    from types import ModuleType


# Generated at 2022-06-17 14:49:56.282930
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', ['/tmp/ansible_collections/test/test_collection'])
    assert loader.is_package('ansible_collections.test.test_collection') == True
    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module', ['/tmp/ansible_collections/test/test_collection'])
    assert loader.is_package('ansible_collections.test.test_collection.test_module') == False


# Generated at 2022-06-17 14:50:07.416981
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with a valid redirect
    _AnsibleCollectionConfig.configured_collection_paths = [os.path.join(os.path.dirname(__file__), 'fixtures', 'collections')]
    _AnsibleCollectionConfig.configured_collection_ignore_paths = []
    _AnsibleCollectionConfig.configured_collection_ignore_files = []
    _AnsibleCollectionConfig.configured_collection_ignore_dirs = []
    _AnsibleCollectionConfig.configured_collection_ignore_roles = []
    _AnsibleCollectionConfig.configured_collection_ignore_role_types = []
    _AnsibleCollectionConfig.configured_collection_ignore_role_deps = []
    _AnsibleCollectionConfig.configured_collection_ignore_role_defaults = []
    _An

# Generated at 2022-06-17 14:51:14.778573
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils._text import to_bytes, to_text

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tmpdir_b = to_bytes(self.tmpdir)
            self.tmpdir_t = to_text(self.tmpdir)
            self.tmpdir_t_slash = to_text(self.tmpdir) + '/'
            self.tmpdir_b_slash = to_bytes(self.tmpdir) + b'/'
            self.tmpdir_t_slash_len = len(self.tmpdir_t_slash)
            self.tmpdir_b_slash

# Generated at 2022-06-17 14:51:25.321227
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename', ref_type='role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname', ref_type='playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yml', ref_type='playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yaml', ref_type='playbook')

# Generated at 2022-06-17 14:51:36.292992
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'

# Generated at 2022-06-17 14:51:48.337408
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-1.2')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-1.2.3')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name-1.2.3.4')

# Generated at 2022-06-17 14:51:58.558127
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module that has a code object
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.testns.testcoll', path_list=['/path/to/testcoll'])
    loader._source_code_path = '/path/to/testcoll/testmod.py'
    loader._compiled_code = compile(source='print("hello")', filename='/path/to/testcoll/testmod.py', mode='exec', flags=0, dont_inherit=True)
    module = loader.load_module('ansible_collections.testns.testcoll.testmod')
    assert module.__name__ == 'ansible_collections.testns.testcoll.testmod'
    assert module.__file__ == '/path/to/testcoll/testmod.py'
    assert module

# Generated at 2022-06-17 14:52:08.734833
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'subdir1', 'rolename', 'role')
    assert AnsibleCollectionRef.from_

# Generated at 2022-06-17 14:52:16.915508
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test_AnsibleCollectionRef_from_fqcr_with_valid_fqcr_and_ref_type_module
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # test_AnsibleCollectionRef_from_fqcr_with_valid_fqcr_and_ref_type

# Generated at 2022-06-17 14:52:27.394194
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collName')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')

# Generated at 2022-06-17 14:52:37.633489
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test the case where the source code is not None
    # Create a _AnsibleCollectionPkgLoaderBase object
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection')
    # Set the source code path
    loader._source_code_path = 'test_source_code_path'
    # Set the source code
    loader._decoded_source = 'test_source_code'
    # Call get_code
    code = loader.get_code('ansible_collections.test.test_collection')
    # Assert that the code is not None
    assert code is not None
    # Assert that the code is a code object
    assert isinstance(code, types.CodeType)
    # Assert that the code is the same as the compiled code
    assert code == loader._compiled

# Generated at 2022-06-17 14:52:46.266307
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module
    fullname = 'ansible_collections.my_namespace.my_collection.plugins.module_utils.my_module'
    path_list = ['/path/to/my_namespace/my_collection/plugins/module_utils/my_module.py']
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    module = loader.load_module(fullname)
    assert module.__name__ == fullname
    assert module.__loader__ == loader
    assert module.__file__ == path_list[0]
    assert module.__package__ == 'ansible_collections.my_namespace.my_collection.plugins.module_utils'

    # Test with a package