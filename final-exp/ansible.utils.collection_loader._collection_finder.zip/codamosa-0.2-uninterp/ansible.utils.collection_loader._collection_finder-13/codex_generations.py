

# Generated at 2022-06-17 14:43:54.862505
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test case 1
    ref = 'ansible.builtin.command'
    ref_type = 'module'
    expected_result = AnsibleCollectionRef('ansible.builtin', '', 'command', 'module')
    result = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert result == expected_result

    # Test case 2
    ref = 'ansible.builtin.command'
    ref_type = 'role'
    expected_result = None
    result = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert result == expected_result

    # Test case 3
    ref = 'ansible.builtin.command'
    ref_type = 'module'

# Generated at 2022-06-17 14:44:01.802360
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test for method load_module(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for invalid fullname
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase('ansible_collections.test').load_module('ansible_collections.test.test')
    # test for valid fullname
    _AnsibleCollectionPkgLoaderBase('ansible_collections.test').load_module('ansible_collections.test')

# Generated at 2022-06-17 14:44:13.610973
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    # Create a temporary subdirectory
    tmp_subdir = tempfile.mkdtemp(dir=tmp_dir)
    # Create a temporary file in the subdirectory
    tmp_subdir_file = tempfile.NamedTemporaryFile(dir=tmp_subdir, delete=False)
    # Create a temporary subdirectory in the subdirectory
    tmp_subdir_subdir = tempfile.mkdtemp(dir=tmp_subdir)
    # Create a temporary file in the subdirectory in the subdirectory

# Generated at 2022-06-17 14:44:22.485330
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', 'ansible_collections', '')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths is None



# Generated at 2022-06-17 14:44:28.421089
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', path_list=['/tmp'])
    assert loader.is_package('ansible_collections.test.test_collection')

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module', path_list=['/tmp'])
    assert not loader.is_package('ansible_collections.test.test_collection.test_module')



# Generated at 2022-06-17 14:44:29.841023
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement
    pass

# this is the path_hook that gets registered with sys.path_hooks. It's responsible for finding the correct loader
# for a given import request, and returning it.

# Generated at 2022-06-17 14:44:35.198450
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:44:43.891882
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder(paths=['/tmp/ansible_collections'])
    assert collection_finder._n_configured_paths == ['/tmp/ansible_collections']
    assert collection_finder._n_cached_collection_paths is None
    assert collection_finder._n_cached_collection_qualified_paths is None
    assert collection_finder._n_playbook_paths == []
    assert collection_finder._ansible_pkg_path == '/usr/lib/python2.7/site-packages/ansible'



# Generated at 2022-06-17 14:44:54.585128
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import os
    import sys
    import tempfile
    import shutil
    import importlib

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create the test package
    test_pkg_dir = os.path.join(tmpdir, 'test_pkg')
    os.mkdir(test_pkg_dir)
    test_pkg_init_path = os.path.join(test_pkg_dir, '__init__.py')
    with open(test_pkg_init_path, 'w') as f:
        f.write('test_pkg_init_code')

    # create the test module
    test_module_path = os.path.join(test_pkg_dir, 'test_module.py')
    with open(test_module_path, 'w') as f:
        f

# Generated at 2022-06-17 14:45:06.816078
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1: test get_data with path that is a file
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_plugin')
    loader._source_code_path = './test/unit/lib/ansible_test/_data/plugins/modules/test_module.py'

# Generated at 2022-06-17 14:45:47.279535
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')

# Generated at 2022-06-17 14:45:55.463161
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'

# Generated at 2022-06-17 14:46:01.280749
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:13.683724
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:22.124744
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import os
    import sys
    import tempfile
    import shutil
    import importlib
    import unittest
    import unittest.mock
    import ansible.module_utils.six.moves.builtins as __builtin__
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves as six_moves

    class Test__AnsibleCollectionPkgLoaderBase_load_module(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tempdir)
            self.tempdir_path = to_bytes(self.tempdir)

# Generated at 2022-06-17 14:46:33.464631
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test constructor
    ref = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.subdir2.module'
    assert ref.fqcr == 'ns.coll.subdir1.subdir2.resource'

    # test constructor with no subdirs

# Generated at 2022-06-17 14:46:46.766941
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for invalid collection name
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll.name', 'subdir', 'resource', 'module')

    # Test for invalid subdirs
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir.name', 'resource', 'module')

    # Test for invalid ref_type
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir', 'resource', 'invalid_type')

    # Test for valid collection name
    AnsibleCollectionRef('ns.coll', 'subdir', 'resource', 'module')

    # Test for valid subdirs
    AnsibleCollectionRef('ns.coll', 'subdir.name', 'resource', 'module')

    # Test for valid ref

# Generated at 2022-06-17 14:46:57.396053
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1
    # Test for the case where path is not specified
    try:
        _AnsibleCollectionPkgLoaderBase.get_data(None)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test case 2
    # Test for the case where path is relative
    try:
        _AnsibleCollectionPkgLoaderBase.get_data('relative_path')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test case 3
    # Test for the case where path is absolute but file does not exist
    assert _AnsibleCollectionPkgLoaderBase.get_data('/path/to/non_existing_file') is None

    # Test case 4
    # Test for the case where path

# Generated at 2022-06-17 14:46:59.812701
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test for method get_code(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # This method is tested indirectly by test__AnsibleCollectionPkgLoader_get_code
    pass


# Generated at 2022-06-17 14:47:12.206716
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins')

# Generated at 2022-06-17 14:47:47.261145
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for a file that exists
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my.ns', path_list=['/tmp/my/ns'])
    assert loader.get_data('/tmp/my/ns/__init__.py') == b''
    # test for a file that does not exist
    assert loader.get_data('/tmp/my/ns/__init__.pyx') is None
    # test for a file that does not exist, but the parent directory does
    assert loader.get_data('/tmp/my/ns/__init__.py') == b''
    # test for a file that exists, but is not in the search path
    assert loader.get

# Generated at 2022-06-17 14:47:50.164435
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # _AnsibleCollectionPkgLoaderBase.__repr__()
    # TODO: implement your test here
    raise NotImplementedError()



# Generated at 2022-06-17 14:47:51.437886
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # test_ansible_internal_redirect_loader_load_module
    # TODO: implement this test
    pass


# this is the hook that gets added to sys.meta_path to handle Ansible Python module imports

# Generated at 2022-06-17 14:47:55.616253
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', None)
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', [])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', ['foo'])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', ['foo', 'bar'])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', ['foo', 'bar', 'baz'])
    assert loader._redirect is None


# Generated at 2022-06-17 14:47:57.563600
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 14:48:09.114059
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:48:20.780604
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a valid module
    test_module = 'ansible_collections.test.test_collection.plugins.module_utils.test_module'
    test_module_path = 'ansible_collections/test/test_collection/plugins/module_utils/test_module.py'
    test_module_path_bytes = to_bytes(test_module_path)
    test_module_path_native = to_native(test_module_path)
    test_module_path_native_bytes = to_bytes(test_module_path_native)
    test_module_path_native_bytes_str = to_text(test_module_path_native_bytes)
    test_module_path_native_bytes_str_bytes = to_bytes(test_module_path_native_bytes_str)
    test_module_

# Generated at 2022-06-17 14:48:31.107134
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:48:46.558396
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:48:51.579930
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test iter_modules with a package that has subpackages
    test_path = os.path.join(os.path.dirname(__file__), 'test_data', 'collection_pkg_loader', 'ansible_collections', 'test_ns', 'test_coll')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=[test_path])
    assert loader.iter_modules(prefix='ansible_collections.test_ns.test_coll') == [('ansible_collections.test_ns.test_coll.test_pkg', True)]

# Generated at 2022-06-17 14:49:45.411364
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: x
    loader = _AnsibleCollectionPkgLoader('ansible_collections.foo.bar', ['/path/to/collections'])
    loader.load_module('ansible_collections.foo.bar')


# Generated at 2022-06-17 14:49:56.194073
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'', u'resource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'subdir1', u'resource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.rolename', u'role') == AnsibleCollectionRef(u'ns.coll', u'', u'rolename', u'role')

# Generated at 2022-06-17 14:49:57.552025
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 14:50:08.513729
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.config.constants
    ansible.config.constants.COLLECTIONS_PATHS = ['/tmp/ansible_collections']
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.utils.collection_loader
    ans

# Generated at 2022-06-17 14:50:13.921368
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert repr(ref) == 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'subdir1.subdir2\', resource=\'resource\')'


# Generated at 2022-06-17 14:50:22.975922
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:50:31.859697
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.resource')

# Generated at 2022-06-17 14:50:45.347952
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:50:50.333549
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test for method load_module(self, fullname)
    # of class _AnsibleInternalRedirectLoader
    # test for the case that the module is not redirected
    # test for the case that the module is redirected
    pass



# Generated at 2022-06-17 14:50:52.394385
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with valid input
    # Test with invalid input
    pass

# Generated at 2022-06-17 14:52:01.779427
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.builtins as __builtin__
    import ansible.module_utils.six.moves.urllib.parse as urlparse
    import ansible.module_utils.six.moves.urllib.error as urlerror
    import ansible.module_utils.six.moves.urllib.request as urlrequest
    import ansible.module_utils.six.moves.http_cookiejar as cookielib
    import ansible.module_utils.six.moves.xmlrpc_client as xmlrpclib

# Generated at 2022-06-17 14:52:11.522672
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # test for empty package init
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=['/path/to/foo/bar'])
    assert loader.get_code('ansible_collections.foo.bar') is not None

    # test for empty package init
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=['/path/to/foo/bar'])
    assert loader.get_code('ansible_collections.foo.bar') is not None

    # test for empty package init
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=['/path/to/foo/bar'])

# Generated at 2022-06-17 14:52:14.556421
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('namespace.collection', 'subdirs', 'resource', 'ref_type').__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-17 14:52:24.922860
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resource')

# Generated at 2022-06-17 14:52:30.330969
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
    assert _AnsibleCollectionFinder(paths='/tmp/ansible_collections', scan_sys_paths=True)
    assert _AnsibleCollectionFinder(paths=['/tmp/ansible_collections'], scan_sys_paths=True)
    assert _AnsibleCollectionFinder(paths=['/tmp/ansible_collections'], scan_sys_paths=False)


# Generated at 2022-06-17 14:52:39.857792
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test_AnsibleCollectionRef_from_fqcr_with_valid_fqcr_and_ref_type
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # test_AnsibleCollectionRef_from_fqcr_with_valid_fqcr_and_ref_type_with

# Generated at 2022-06-17 14:52:48.998263
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {'plugin_routing': {'action': {'test_action': {'redirect': 'test_action'}}}}
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    loader = _AnsibleCollectionPkgLoader(['ansible_collections', 'test_namespace', 'test_collection'], ['/tmp'])
    loader.load_module('ansible_collections.test_namespace.test_collection')

# Generated at 2022-06-17 14:52:59.052467
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    import os
    import sys
    import tempfile

    # create a temp dir
    tmpdir = tempfile.mkdtemp()

    # create a temp file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # create a temp subdir
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)

    # create a temp file in the subdir
    fd, tmpfile2 = tempfile.mkstemp(dir=tmpdir2)
    os.close(fd)

    # create a temp subdir in the subdir
    tmpdir3 = tempfile.mkdtemp(dir=tmpdir2)

    # create a temp file in the subdir in the sub

# Generated at 2022-06-17 14:53:05.728795
# Unit test for method load_module of class _AnsibleInternalRedirectLoader