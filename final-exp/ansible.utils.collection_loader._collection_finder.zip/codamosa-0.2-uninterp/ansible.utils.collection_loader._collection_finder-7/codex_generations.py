

# Generated at 2022-06-17 14:43:59.876716
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra.extras')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra.extras.extras')

# Generated at 2022-06-17 14:44:06.027974
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # Arrange
    playbook_paths = ['/path/to/playbook1', '/path/to/playbook2']
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._n_playbook_paths = []

    # Act
    collection_finder.set_playbook_paths(playbook_paths)

    # Assert
    assert collection_finder._n_playbook_paths == ['/path/to/playbook1/collections', '/path/to/playbook2/collections']


# Generated at 2022-06-17 14:44:15.933086
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test with empty path_list
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=[])
    assert loader.is_package('ansible_collections.ns.module') == False

    # Test with non-empty path_list
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=['/tmp/ansible_collections/ns/module'])
    assert loader.is_package('ansible_collections.ns.module') == False

    # Test with non-empty path_list
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=['/tmp/ansible_collections/ns'])

# Generated at 2022-06-17 14:44:20.110062
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', ['/path/to/collection'])
    assert loader.is_package('ansible_collections.test.test_collection')

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module', ['/path/to/collection'])
    assert not loader.is_package('ansible_collections.test.test_collection.test_module')


# Generated at 2022-06-17 14:44:29.363558
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import os
    import tempfile
    import shutil
    import sys
    import importlib
    import importlib.util

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a collection
    collection_dir = os.path.join(tmpdir, 'ansible_collections', 'test_namespace', 'test_collection')
    os.makedirs(collection_dir)

    # Create a module
    module_dir = os.path.join(collection_dir, 'test_module')
    os.makedirs(module_dir)
    module_file = os.path.join(module_dir, '__init__.py')
    with open(module_file, 'w') as f:
        f.write('# test module')

    # Create a package
    package_dir = os

# Generated at 2022-06-17 14:44:38.268034
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', 'ansible_collections', '')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths is None



# Generated at 2022-06-17 14:44:50.725846
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test with empty path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=[])
    assert loader.get_filename('ansible_collections.test_ns.test_coll') == '<ansible_synthetic_collection_package>'

    # Test with path containing a file
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=['/path/to/file.py'])
    assert loader.get_filename('ansible_collections.test_ns.test_coll') == '/path/to/file.py'

    # Test with path containing a directory

# Generated at 2022-06-17 14:44:58.875481
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname.yml', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')
    assert AnsibleCollectionRef.from_f

# Generated at 2022-06-17 14:45:07.186064
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.pkg', path_list=['/path/to/pkg'])
    assert loader.is_package('ansible_collections.ns.pkg') == True

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=['/path/to/module'])
    assert loader.is_package('ansible_collections.ns.module') == False

# Generated at 2022-06-17 14:45:18.645848
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection.plugins.module_utils.my_module')
    loader._source_code_path = 'ansible_collections/my_namespace/my_collection/plugins/module_utils/my_module.py'
    loader._decoded_source = 'def my_func():\n    return "my_func"'
    loader._compiled_code = compile(source='def my_func():\n    return "my_func"', filename='ansible_collections/my_namespace/my_collection/plugins/module_utils/my_module.py', mode='exec', flags=0, dont_inherit=True)

# Generated at 2022-06-17 14:46:42.005415
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test for method get_code(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for empty source code
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection')
    loader._source_code_path = None
    assert loader.get_code('ansible_collections.test.test_collection') is None
    # test for non-empty source code
    loader._source_code_path = 'test_file'
    loader._decoded_source = 'test_source'
    assert loader.get_code('ansible_collections.test.test_collection') is not None
    assert loader.get_code('ansible_collections.test.test_collection').co_filename == 'test_file'

# Generated at 2022-06-17 14:46:51.551340
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)

            self.mock_module_name = 'ansible_collections.my_ns.my_coll.my_pkg'
            self.mock_module_path = os.path.join(self.tmpdir, 'ansible_collections', 'my_ns', 'my_coll', 'my_pkg')

# Generated at 2022-06-17 14:46:59.753694
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.fqcr == 'ns.coll.subdir1.subdir2.resource'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.subdir2.module'

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
   

# Generated at 2022-06-17 14:47:12.205694
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test case 1
    # Test if the method load_module of class _AnsibleCollectionPkgLoader
    # can handle the case when the variable _meta_yml_to_dict is not set.
    # Expected result:
    # The method load_module of class _AnsibleCollectionPkgLoader
    # should raise ValueError.
    try:
        _meta_yml_to_dict = None
        loader = _AnsibleCollectionPkgLoader(path=None, fullname='ansible_collections.test.test_collection', package_to_load='test_collection')
        loader.load_module('ansible_collections.test.test_collection')
    except ValueError:
        pass
    except Exception as ex:
        assert False, "Unexpected exception raised: " + str(ex)

# Generated at 2022-06-17 14:47:22.859225
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resource')

# Generated at 2022-06-17 14:47:27.790289
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import ansible.utils.collection_loader
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.six.moves.urllib.robotparser
    import ansible.module_utils.six.moves.urllib.parse

# Generated at 2022-06-17 14:47:36.162954
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import tempfile
    import shutil
    import os
    import sys
    import importlib
    import importlib.abc
    import importlib.machinery

    # create a temp dir
    tmpdir = tempfile.mkdtemp()
    # create a temp module
    module_name = 'test_module'
    module_path = os.path.join(tmpdir, module_name + '.py')
    with open(module_path, 'w') as f:
        f.write('a = 1')
    # create a temp package
    package_name = 'test_package'
    package_path = os.path.join(tmpdir, package_name)
    os.mkdir(package_path)
    # create a temp package init

# Generated at 2022-06-17 14:47:37.099420
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# handles locating the actual collection package and associated metadata

# Generated at 2022-06-17 14:47:41.278751
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {'plugin_routing': {'action': {'test': {'redirect': '../../test'}}}}
    loader = _AnsibleCollectionPkgLoader(['ansible_collections', 'test', 'test'], None)
    loader.load_module('ansible_collections.test.test')
    assert loader._canonicalize_meta({}) == {}
    assert loader._canonicalize_meta({'plugin_routing': {'action': {'test': {'redirect': '../../test'}}}}) == {'plugin_routing': {'action': {'test': {'redirect': '../../test'}}}}


# handles locating the actual collection package and

# Generated at 2022-06-17 14:47:48.551539
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('vars_plugins')

# Generated at 2022-06-17 14:49:01.267096
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test case data
    fullname = 'ansible.builtin.test'
    path_list = []
    # Perform the test
    test_obj = _AnsibleInternalRedirectLoader(fullname, path_list)
    test_obj.load_module(fullname)
    # Return the result
    return True


# this is the path hook for the ansible_collections package. It is responsible for finding the correct loader for
# the requested package/module.

# Generated at 2022-06-17 14:49:09.394542
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test for not interested
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('test.test', None)

    # test for not redirected
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.test', None)

    # test for redirected
    _AnsibleInternalRedirectLoader('ansible.builtin.test', None)


# this is the path hook that gets registered with sys.path_hooks. It will answer for any import that starts with
# ansible_collections, and will proxy to the built-in import mechanisms for everything else.

# Generated at 2022-06-17 14:49:16.591920
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])
    assert loader._redirect == 'ansible.builtin.module_utils.basic'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:49:17.559631
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:49:18.389019
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 14:49:22.181850
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])
    assert loader._redirect == 'ansible.module_utils.basic'


# Generated at 2022-06-17 14:49:31.820213
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None

# Generated at 2022-06-17 14:49:45.829759
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:49:56.395710
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test with a non-existing path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_ns.my_coll', ['/tmp/my_coll'])
    assert loader.get_source('ansible_collections.my_ns.my_coll') is None

    # Test with a non-existing file
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_ns.my_coll', ['/tmp/my_coll/my_coll'])
    assert loader.get_source('ansible_collections.my_ns.my_coll') is None

    # Test with an existing file

# Generated at 2022-06-17 14:50:07.495513
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resource')

# Generated at 2022-06-17 14:50:31.377241
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:50:45.218301
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:50:49.552736
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Test for constructor of class _AnsiblePathHookFinder
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None


# Generated at 2022-06-17 14:51:01.903111
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module that has a code object
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', path_list=['/tmp/ansible_collections/test/test_collection'])
    loader._source_code_path = '/tmp/ansible_collections/test/test_collection/__init__.py'
    loader._compiled_code = compile(source='', filename='/tmp/ansible_collections/test/test_collection/__init__.py', mode='exec', flags=0, dont_inherit=True)
    module = loader.load_module('ansible_collections.test.test_collection')
    assert module.__file__ == '/tmp/ansible_collections/test/test_collection/__init__.py'

# Generated at 2022-06-17 14:51:11.029860
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.collections import is_collection_ref
    from ansible.module_utils.common.collections import is_collection_version_specifier
    from ansible.module_utils.common.collections import is_collection_version_requirement
    from ansible.module_utils.common.collections import is_collection_version_requirement_specifier
    from ansible.module_utils.common.collections import is_collection_version_requirement_specifier_list

# Generated at 2022-06-17 14:51:17.606156
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test with a valid path
    path = '/tmp/test_path'
    with open(path, 'w') as f:
        f.write('test_content')
    loader = _AnsibleCollectionPkgLoaderBase('test_name', [path])
    assert loader.get_source('test_name') == 'test_content'
    os.remove(path)

    # Test with an invalid path
    loader = _AnsibleCollectionPkgLoaderBase('test_name', ['/tmp/invalid_path'])
    assert loader.get_source('test_name') is None



# Generated at 2022-06-17 14:51:27.196912
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    import pytest

    from ansible.module_utils.common.text.converters import to_native, to_text, to_bytes
    from ansible.module_utils.six import string_types, PY3
    from ._collection_config import AnsibleCollectionConfig
    from ._collection_meta import _meta_yml_to_dict
    from contextlib import contextmanager
    from types import ModuleType

    try:
        from importlib import import_module
    except ImportError:
        def import_module(name):
            __import__(name)
            return sys.modules[name]


# Generated at 2022-06-17 14:51:33.019882
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test valid fqcr
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'subdir1', 'rolename', 'role')
   

# Generated at 2022-06-17 14:51:47.045104
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-17 14:51:53.761159
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    loader = _AnsibleCollectionPkgLoader(['ansible_collections', 'test', 'test'], ['/path/to/test'])
    loader.load_module('ansible_collections.test.test')


# Generated at 2022-06-17 14:52:16.031175
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 14:52:26.271169
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:52:36.925643
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_plugin')
    loader._subpackage_search_paths = ['/tmp/test_collection/test_plugin']
    assert loader.get_data('/tmp/test_collection/test_plugin/__init__.py') == ''
    assert loader.get_data('/tmp/test_collection/test_plugin/test_module.py') == b'# test module\n'

# Generated at 2022-06-17 14:52:45.796652
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test for valid collection reference
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'

    # Test for valid collection reference with subdirs
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'

    # Test for valid collection reference with subdirs and extension
    ref = AnsibleCollectionRef.from_fqcr

# Generated at 2022-06-17 14:52:54.636723
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1'


# Generated at 2022-06-17 14:53:06.082978
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type