

# Generated at 2022-06-17 14:44:14.645368
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yaml', 'playbook')

# Generated at 2022-06-17 14:44:20.404952
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    ansible.utils.collection_loader._get_collection_metadata = lambda x: {'import_redirection': {'ansible.builtin.foo': {'redirect': 'ansible.builtin.bar'}}}
    ansible.utils.collection_loader._get_ancestor_redirect = lambda x, y: None
    ansible.utils.collection_loader._AnsibleCollectionLoader._redirected_package_map = {}
    ansible.utils.collection_loader._AnsibleCollectionLoader._allows_package_code = True

# Generated at 2022-06-17 14:44:21.805308
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:44:32.479148
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test constructor
    assert AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module') == \
        AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')

    # Test constructor with invalid collection name
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll.coll', 'subdir1.subdir2', 'resource', 'module')

    # Test constructor with invalid subdirs
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2.subdir3', 'resource', 'module')

    # Test constructor with invalid ref_type

# Generated at 2022-06-17 14:44:44.821441
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test iter_modules with empty prefix
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll'])
    assert list(loader.iter_modules(prefix='')) == [('test_coll', False, 'ansible_collections.test_ns.test_coll')]

    # Test iter_modules with non-empty prefix
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll'])
    assert list(loader.iter_modules(prefix='test_coll')) == [('test_coll', False, 'ansible_collections.test_ns.test_coll')]

    #

# Generated at 2022-06-17 14:44:50.239772
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1'


# Generated at 2022-06-17 14:44:58.546180
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('vars_plugins')

# Generated at 2022-06-17 14:45:08.933757
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:45:20.633057
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:45:30.944839
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test with valid collection reference
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml', 'playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yml', 'playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml', 'role')
    assert Ans

# Generated at 2022-06-17 14:46:41.251631
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with valid fqcr
    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert ref.fqcr == 'ns.coll.resource'
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.fqcr == 'ns.coll.subdir1.subdir2.resource'
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_

# Generated at 2022-06-17 14:46:51.201183
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test for valid collection reference
    ref = AnsibleCollectionRef.from_fqcr('my.collection.mymodule', 'module')
    assert ref.collection == 'my.collection'
    assert ref.subdirs == ''
    assert ref.resource == 'mymodule'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.my.collection'
    assert ref.n_python_package_name == 'ansible_collections.my.collection.plugins.module'
    assert ref.fqcr == 'my.collection.mymodule'

    # Test for valid collection reference with subdirs
    ref = AnsibleCollectionRef.from_fqcr('my.collection.subdir1.subdir2.mymodule', 'module')
    assert ref.collection

# Generated at 2022-06-17 14:46:59.504858
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test case 1
    ref = 'ns.coll.resource'
    ref_type = 'module'
    expected = AnsibleCollectionRef(collection_name='ns.coll', subdirs='', resource='resource', ref_type='module')
    actual = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert expected == actual

    # Test case 2
    ref = 'ns.coll.subdir1.resource'
    ref_type = 'module'
    expected = AnsibleCollectionRef(collection_name='ns.coll', subdirs='subdir1', resource='resource', ref_type='module')
    actual = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert expected == actual

    # Test case 3
    ref = 'ns.coll.rolename'


# Generated at 2022-06-17 14:47:11.942486
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:22.650777
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:29.785716
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:37.203990
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:47:45.419117
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import tempfile
    import shutil
    import sys
    import textwrap
    import unittest

    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')
            self.test_file_content = textwrap.dedent('''
                def test_func():
                    return 'test_func'
            ''')
            with open(self.test_file, 'w') as f:
                f.write(self.test_file_content)

# Generated at 2022-06-17 14:47:56.955804
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')

# Generated at 2022-06-17 14:48:08.496640
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname.yml', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')

# Generated at 2022-06-17 14:48:50.058090
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import sys
    import tempfile
    import unittest
    from ansible.module_utils._text import to_bytes, to_text

    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file.py')
            with open(self.test_file, 'w') as f:
                f.write('#!/usr/bin/python\nprint("Hello World")\n')

        def tearDown(self):
            os.remove(self.test_file)
            os.rmdir(self.test_dir)


# Generated at 2022-06-17 14:48:59.290578
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test case 1
    # Input:
    #   fullname = 'ansible_collections.ns.test'
    #   self._fullname = 'ansible_collections.ns.test'
    #   self._subpackage_search_paths = None
    #   self._source_code_path = None
    # Expected output:
    #   filename = '<ansible_synthetic_collection_package>'
    fullname = 'ansible_collections.ns.test'
    self = _AnsibleCollectionPkgLoaderBase(fullname)
    self._fullname = 'ansible_collections.ns.test'
    self._subpackage_search_paths = None
    self._source_code_path = None
    filename = self.get_filename(fullname)

# Generated at 2022-06-17 14:49:05.370070
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import ansible.utils.collection_loader
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.facts
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.text
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.process
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.network
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.crypto
   

# Generated at 2022-06-17 14:49:09.951462
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.machinery_source
    import importlib.machinery_bytecode
    import importlib.machinery_synthetic
    import importlib.machinery_path
    import importlib.machinery_pkgutil
    import importlib.machinery_imp
    import importlib.machinery_extension
    import importlib.machinery_namespace
    import importlib.machinery_winreg
    import importlib.machinery_zipimport
    import importlib.machinery_c_extension
    import importlib.machinery_loader
    import importlib.machinery_loader

# Generated at 2022-06-17 14:49:20.495537
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module that has no code
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module', path_list=['/tmp/ansible_collections/test/test_collection/test_module'])
    loader._subpackage_search_paths = None
    loader._source_code_path = '/tmp/ansible_collections/test/test_collection/test_module/__synthetic__'
    module = loader.load_module('ansible_collections.test.test_collection.test_module')
    assert module.__name__ == 'ansible_collections.test.test_collection.test_module'
    assert module.__loader__ == loader

# Generated at 2022-06-17 14:49:24.764084
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_obj = AnsibleCollectionRef('collection_name', 'subdirs', 'resource', 'ref_type')
    assert repr(test_obj) == "AnsibleCollectionRef(collection='collection_name', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-17 14:49:29.079970
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(u'ns.coll', u'subdir1.subdir2', u'resource', u'module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='ns.coll', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:49:37.991880
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test case data
    fullname = 'ansible_collections.ns.module'
    path_list = ['/path/to/ansible_collections/ns/module']
    module_path = '/path/to/ansible_collections/ns/module/module.py'

# Generated at 2022-06-17 14:49:43.924191
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', None)
    assert loader._redirect == 'ansible.builtin.module_utils.basic'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:49:50.158651
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for the case where the toplevel package is not ansible
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('notansible.module', None)

    # Test for the case where the module is not redirected
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.module', None)

    # Test for the case where the module is redirected
    loader = _AnsibleInternalRedirectLoader('ansible.module', None)
    assert loader._redirect == 'ansible.builtin.module'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:50:45.189303
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname', 'playbook') is not None

    # Test with invalid input
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'role') is None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'playbook') is None
    assert AnsibleCollectionRef

# Generated at 2022-06-17 14:50:55.900766
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-17 14:51:06.531810
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import tempfile
    import shutil
    import os
    import sys
    import importlib
    import types

    def _mock_get_data(path):
        return 'test_data'

    def _mock_get_filename(fullname):
        return 'test_filename'

    def _mock_get_code(fullname):
        return 'test_code'

    def _mock_is_package(fullname):
        return True

    def _mock_load_module(fullname):
        return 'test_module'

    def _mock_iter_modules(prefix):
        return 'test_iter_modules'

    def _mock_get_candidate_paths(path_list):
        return 'test_candidate_paths'


# Generated at 2022-06-17 14:51:14.098270
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.subdir')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.subdir1.subdir2')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.subdir1.subdir2.subdir3')

    # Test invalid collection name
    assert not AnsibleCollection

# Generated at 2022-06-17 14:51:24.591236
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub.sub.sub.sub')
    assert not AnsibleCollectionRef.is_valid

# Generated at 2022-06-17 14:51:35.751242
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for a path that does not exist
    path = '/tmp/ansible_collections/ansible_collections/test/plugins/module_utils/test_module_utils.py'
    assert _AnsibleCollectionPkgLoaderBase().get_data(path) is None
    # test for a path that exists
    path = '/tmp/ansible_collections/ansible_collections/test/plugins/module_utils/test_module_utils.py'
    assert _AnsibleCollectionPkgLoaderBase().get_data(path) is not None
    # test for a path that exists but is not a file

# Generated at 2022-06-17 14:51:48.203343
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: x
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: x
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load.fire = lambda x, y: x
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load.fire.return_value = 'ansible.builtin'
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load.fire.return_value = 'ansible.builtin'

# Generated at 2022-06-17 14:51:58.404444
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import reduce

# Generated at 2022-06-17 14:52:08.533702
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import os
    import tempfile
    import shutil
    import sys
    import unittest

    class Test_AnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = tempfile.NamedTemporaryFile(dir=self.temp_dir, delete=False)
            self.temp_file.write(b'foo')
            self.temp_file.close()
            self.temp_file_name = os.path.basename(self.temp_file.name)
            self.temp_file_path = os.path.join(self.temp_dir, self.temp_file_name)

# Generated at 2022-06-17 14:52:10.551414
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement unit test for method load_module of class _AnsibleCollectionPkgLoader
    pass
