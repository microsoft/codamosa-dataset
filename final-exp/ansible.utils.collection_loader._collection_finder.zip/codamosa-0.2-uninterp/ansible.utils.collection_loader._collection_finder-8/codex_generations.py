

# Generated at 2022-06-17 14:44:14.428712
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1
    # Test for the function get_data of class _AnsibleCollectionPkgLoaderBase
    # Input:
    #   path = '__init__.py'
    #   self._subpackage_search_paths = ['/home/ansible/ansible_collections/ansible/test_collection/plugins/modules/']
    # Expected output:
    #   ''
    path = '__init__.py'
    self = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.test_collection.plugins.modules',
                                           ['/home/ansible/ansible_collections/ansible/test_collection/plugins/modules/'])

# Generated at 2022-06-17 14:44:21.326337
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for method get_filename(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # This method is tested in class _AnsibleCollectionPkgLoaderBase
    # and its subclasses.
    #
    # This test is for the case where the package is a directory.
    #
    # Arrange
    fullname = 'ansible_collections.ns.package'
    path_list = ['/path/to/ansible_collections/ns/package']
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)

    # Act
    filename = loader.get_filename(fullname)

    # Assert
    assert filename == '/path/to/ansible_collections/ns/package/__synthetic__'

    # Arrange

# Generated at 2022-06-17 14:44:29.681321
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test for method get_source(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for empty source
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my.ns', ['/path/to/my/ns'])
    loader._source_code_path = '/path/to/my/ns/__init__.py'
    assert loader.get_source('ansible_collections.my.ns') == ''
    # test for non-empty source
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my.ns', ['/path/to/my/ns'])
    loader._source_code_path = '/path/to/my/ns/__init__.py'

# Generated at 2022-06-17 14:44:38.832562
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import mock

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_

# Generated at 2022-06-17 14:44:46.597597
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # test with a file that exists
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.module', path_list=['/path/to/collection'])
    assert loader.get_data('/path/to/collection/module.py') == b'#!/usr/bin/python\n'

    # test with a file that does not exist
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.module', path_list=['/path/to/collection'])
    assert loader.get_data('/path/to/collection/module.py2') is None

    # test with a file that exists in multiple locations

# Generated at 2022-06-17 14:44:55.596036
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import sys
    import tempfile
    import shutil
    import importlib
    import unittest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class _TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

        def _validate_final(self):
            pass


# Generated at 2022-06-17 14:45:07.643544
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import importlib
    import pkgutil
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.builtins as __builtin__

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary module
    module = os.path.join(tmpdir, 'ansible_collections', 'test_ns', 'test_coll', 'plugins', 'modules', 'test_module.py')
    os.makedirs(os.path.dirname(module))
    with open(module, 'w') as f:
        f.write('#')
    # Create a temporary collection

# Generated at 2022-06-17 14:45:14.597070
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext.ext.ext')

# Generated at 2022-06-17 14:45:25.603006
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar').__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/foo/bar']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/foo/bar])'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/foo/bar', '/foo/baz']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/foo/bar, /foo/baz])'

# Generated at 2022-06-17 14:45:34.295253
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:17.402261
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test 1:
    # Test that the constructor of _AnsibleInternalRedirectLoader raises ImportError when the fullname is not
    # 'ansible'
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('not_ansible', [])

    # Test 2:
    # Test that the constructor of _AnsibleInternalRedirectLoader raises ImportError when the fullname is 'ansible'
    # but the module is not redirected
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.not_redirected', [])

    # Test 3:
    # Test that the constructor of _AnsibleInternalRedirectLoader does not raise ImportError when the fullname is
    # 'ansible' and the module is redirected

# Generated at 2022-06-17 14:46:24.979372
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extra')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extra.extra')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extra.extra.extra')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extra.extra.extra.extra')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extra.extra.extra.extra.extra')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extra.extra.extra.extra.extra.extra')
    assert not Ans

# Generated at 2022-06-17 14:46:30.453736
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import tempfile
    import shutil
    import os
    import sys
    import importlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary module file
    module_file = os.path.join(tmpdir, 'test_module.py')

# Generated at 2022-06-17 14:46:32.690806
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement test
    pass


# Generated at 2022-06-17 14:46:46.314131
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test for ansible.builtin
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', [])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar', [])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar.baz', [])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar.baz.qux', [])
    assert loader._redirect is None

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar.baz.qux.quux', [])
    assert loader._redirect is None


# Generated at 2022-06-17 14:46:57.345263
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test with collection_name = 'namespace.collectionname', subdirs = 'subdir1.subdir2', resource = 'mymodule', ref_type = 'action'
    # Expected result: 'AnsibleCollectionRef(collection=\'namespace.collectionname\', subdirs=\'subdir1.subdir2\', resource=\'mymodule\')'
    collection_name = 'namespace.collectionname'
    subdirs = 'subdir1.subdir2'
    resource = 'mymodule'
    ref_type = 'action'
    expected_result = 'AnsibleCollectionRef(collection=\'namespace.collectionname\', subdirs=\'subdir1.subdir2\', resource=\'mymodule\')'

# Generated at 2022-06-17 14:47:04.489693
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid fqcr
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'

# Generated at 2022-06-17 14:47:16.140388
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.subdir')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.subdir1.subdir2')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.subdir1.subdir2.subdir3')

    # Test for invalid collection name

# Generated at 2022-06-17 14:47:18.205567
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', None)
    assert loader._redirect == 'ansible.builtin.module_utils.basic'


# Generated at 2022-06-17 14:47:23.613660
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # test for method get_data of class _AnsibleCollectionPkgLoaderBase
    # mock _AnsibleCollectionPkgLoaderBase class
    class Mock_AnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections

# Generated at 2022-06-17 14:47:50.219125
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-17 14:47:57.974317
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', ['/tmp/test_collection'])
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/tmp/test_collection])'
    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module', ['/tmp/test_collection'])
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/tmp/test_collection/test_module.py)'



# Generated at 2022-06-17 14:48:10.016482
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub.sub.sub.sub.sub')

# Generated at 2022-06-17 14:48:16.725095
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test with valid data
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:48:24.330819
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for ansible.builtin
    loader = _AnsibleInternalRedirectLoader('ansible.builtin', None)
    assert loader._redirect is None

    # Test for ansible.builtin.foo
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', None)
    assert loader._redirect == 'ansible.builtin.foo'

    # Test for ansible.builtin.foo.bar
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar', None)
    assert loader._redirect == 'ansible.builtin.foo.bar'

    # Test for ansible.builtin.foo.bar.baz
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar.baz', None)
    assert loader._

# Generated at 2022-06-17 14:48:33.613315
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:48:47.579452
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname.yml', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')

    # Test with invalid input

# Generated at 2022-06-17 14:48:58.482280
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:49:04.751785
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import pkgutil
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a collection
    collection_dir = os.path.join(tmpdir, 'ansible_collections', 'test', 'plugins', 'modules')
    os.makedirs(collection_dir)

    # Create a module
    module_file = os.path.join(collection_dir, 'test_module.py')
    with open(module_file, 'w') as f:
        f.write('#!/usr/bin/python\n')

# Generated at 2022-06-17 14:49:15.729055
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # test with ansible_collections
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._install()
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, 'ansible_collections')
    assert path_hook_finder.find_module('ansible_collections.test.test_collection')
    assert path_hook_finder.find_module('ansible_collections.test.test_collection.plugins.modules.test_module')
    assert path_hook_finder.find_module('ansible_collections.test.test_collection.plugins.modules.test_module.test_module')
    assert path_hook_finder.find_module('ansible_collections.test.test_collection.plugins.modules.test_module.test_module.test_module')

# Generated at 2022-06-17 14:49:47.758037
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test for ansible.builtin
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', None)
    assert loader._redirect == 'ansible.builtin.foo'

    # test for ansible.builtin.foo
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', None)
    assert loader._redirect == 'ansible.builtin.foo'

    # test for ansible.builtin.foo.bar
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar', None)
    assert loader._redirect == 'ansible.builtin.foo.bar'

    # test for ansible.builtin.foo.bar.baz

# Generated at 2022-06-17 14:49:57.914425
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:50:09.176629
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resource')

# Generated at 2022-06-17 14:50:19.431176
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for constructor of class AnsibleCollectionRef
    # Test for invalid collection name
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll.name', 'subdir1.subdir2', 'resource', 'module')
    # Test for invalid subdirs
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2.subdir3', 'resource', 'module')
    # Test for invalid ref_type
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'invalid')
    # Test for valid collection name
    AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')


# Generated at 2022-06-17 14:50:23.611693
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.urls
    import ansible.module_utils.urls.__init__
    import ansible.module_utils.urls.url_connection
    import ansible

# Generated at 2022-06-17 14:50:30.098169
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # test constructor of class _AnsiblePathHookFinder
    collection_finder = _AnsibleCollectionFinder()
    pathctx = '/tmp/ansible_collections'
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    assert ansible_path_hook_finder._pathctx == pathctx
    assert ansible_path_hook_finder._collection_finder == collection_finder
    assert ansible_path_hook_finder._file_finder is None


# Generated at 2022-06-17 14:50:37.984221
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test case data
    fullname = 'ansible_collections.test.test_collection'
    filename = '<ansible_synthetic_collection_package>'
    source_code = 'def test():\n    pass\n'
    mode = 'exec'
    flags = 0
    dont_inherit = True
    # Perform the test
    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    loader._source_code_path = filename
    loader._decoded_source = source_code
    result = loader.get_code(fullname)
    assert result == compile(source=source_code, filename=filename, mode=mode, flags=flags, dont_inherit=dont_inherit)

# Generated at 2022-06-17 14:50:48.232754
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {'import_redirection': {'ansible.builtin.foo': {'redirect': 'ansible.builtin.bar'}}}
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', [])
    assert loader._redirect == 'ansible.builtin.bar'
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.bar', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.baz', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.baz.qux', [])

# Generated at 2022-06-17 14:50:53.562598
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test case data
    test_cases = [
        # (
        #     "Test description string",
        #     {
        #         "fullname": "ansible_collections.ns.module",
        #         "path_list": [
        #             "/path/to/ansible_collections/ns/module"
        #         ],
        #         "expected_result": "source code"
        #     }
        # )
    ]
    for t_case in test_cases:
        # Configure the arguments and expectation
        t_desc, t_data = t_case
        t_fullname = t_data.get("fullname")
        t_path_list = t_data.get("path_list")
        t_expected_result = t_data.get("expected_result")

        # Execute the

# Generated at 2022-06-17 14:50:54.758670
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:52:09.443752
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test_AnsibleCollectionRef_from_fqcr_1
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # test_AnsibleCollectionRef_from_fqcr_2

# Generated at 2022-06-17 14:52:11.368520
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
    # This test is not implemented.
    pass


# Generated at 2022-06-17 14:52:23.011520
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:52:27.319542
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test for method load_module of class _AnsibleInternalRedirectLoader
    # This test is not implemented yet.
    pass

# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:52:37.525711
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for the case where the toplevel package is not 'ansible'
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo.bar', None)

    # Test for the case where the toplevel package is 'ansible' but there is no redirection
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.foo.bar', None)

    # Test for the case where the toplevel package is 'ansible' and there is redirection
    loader = _AnsibleInternalRedirectLoader('ansible.foo.bar', None)
    assert loader._redirect == 'ansible.builtin.foo.bar'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook imp

# Generated at 2022-06-17 14:52:46.236698
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:52:57.521957
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test valid collection references
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'', u'resource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.subdir2.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'subdir1.subdir2', u'resource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.rolename', u'role') == AnsibleCollectionRef(u'ns.coll', u'', u'rolename', u'role')

# Generated at 2022-06-17 14:53:08.784815
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for empty path
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data('')
    # test for relative path
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data('relative/path')
    # test for non-existing path
    assert _AnsibleCollectionPkgLoaderBase().get_data('/non/existing/path') is None
    # test for existing path
    assert _AnsibleCollectionPkgLoaderBase().get_data(__file__) is not None
    # test for existing path with __init__.py