

# Generated at 2022-06-17 14:43:52.865803
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Test with no args
    assert _AnsibleCollectionPkgLoaderBase.__repr__(None) == '_AnsibleCollectionPkgLoaderBase(path=None)'
    # Test with args
    assert _AnsibleCollectionPkgLoaderBase.__repr__(None, path='/path/to/something') == '_AnsibleCollectionPkgLoaderBase(path=/path/to/something)'


# Generated at 2022-06-17 14:44:04.052946
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection', ['/path/to/collection'])
    loader._subpackage_search_paths = ['/path/to/collection/test_collection']
    loader._source_code_path = '/path/to/collection/test_collection/__init__.py'
    loader._decoded_source = '# test'
    loader._compiled_code = compile(source='# test', filename='/path/to/collection/test_collection/__init__.py', mode='exec', flags=0, dont_inherit=True)
    module = loader.load_module('ansible_collections.test.test_collection')
    assert module.__loader__ == loader

# Generated at 2022-06-17 14:44:07.603095
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for method try_parse_fqcr of class AnsibleCollectionRef
    # This method is not implemented yet
    pass


# Generated at 2022-06-17 14:44:11.165500
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test for _AnsibleCollectionPkgLoaderBase.get_code()
    #
    # This test is for the method get_code of class _AnsibleCollectionPkgLoaderBase
    #
    # Setup
    #
    # Run
    #
    # Assert
    #
    # Cleanup
    pass


# Generated at 2022-06-17 14:44:22.523256
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-17 14:44:28.424601
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for valid fqcr
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')

    # Test for invalid fqcr
    assert not AnsibleCollectionRef.try_parse

# Generated at 2022-06-17 14:44:32.775120
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test for method load_module of class _AnsibleCollectionPkgLoaderBase
    # This is a class method
    # TODO: implement your test here
    raise NotImplementedError()

# Generated at 2022-06-17 14:44:39.925247
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('ansible.builtin.test', ['/tmp'])
    assert loader._fullname == 'ansible.builtin.test'
    assert loader._split_name == ['ansible', 'builtin', 'test']
    assert loader._package_to_load == 'test'
    assert loader._candidate_paths == ['/tmp']
    assert loader._subpackage_search_paths == ['/tmp']
    assert loader._source_code_path == None
    assert loader._decoded_source == None
    assert loader._compiled_code == None
    assert loader._redirect_module == None
    assert loader._redirected_package_map == {}
    assert loader._allows_package_code == True


# Generated at 2022-06-17 14:44:46.940090
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar').__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/foo/bar']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/foo/bar])'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/foo/bar', '/baz/quux']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/foo/bar, /baz/quux])'



# Generated at 2022-06-17 14:44:57.298459
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test valid collection names
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'subdir1', 'rolename', 'role')

# Generated at 2022-06-17 14:46:14.318138
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import stat
    import pkgutil
    import importlib
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.machinery_source
    import importlib.machinery_bytecode
    import importlib.machinery_synthetic
    import importlib.machinery_compiled
    import importlib.machinery_extension
    import importlib.machinery_namespace
    import importlib.machinery_pkgutil
    import importlib.machinery_path
    import importlib.machinery_windows_extension
    import importlib.machinery_zipimport
    import importlib.machinery_importers

# Generated at 2022-06-17 14:46:18.724665
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:46:27.698165
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra.extras')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra.extras.extras')

# Generated at 2022-06-17 14:46:37.846637
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test that we don't answer for non-ansible imports
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo.bar', [])

    # test that we don't answer for non-redirected ansible imports
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.foo', [])

    # test that we do answer for redirected ansible imports
    loader = _AnsibleInternalRedirectLoader('ansible.foo', [])
    assert loader._redirect == 'ansible.builtin.foo'


# this is the path hook that intercepts ansible_collections imports and routes them to the appropriate loader

# Generated at 2022-06-17 14:46:44.546033
# Unit test for method find_module of class _AnsiblePathHookFinder

# Generated at 2022-06-17 14:46:52.970369
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test with a non-ansible module
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo.bar', [])

    # Test with a non-redirected ansible module
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.module_utils.foo', [])

    # Test with a redirected ansible module
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.facts', [])
    assert loader._redirect == 'ansible.module_utils.facts.system'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:46:53.927254
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # TODO: implement
    pass

# Generated at 2022-06-17 14:47:05.173141
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subdir')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subdir.resource')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subdir.resource.ext')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subdir.resource.ext.ext')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subdir.resource.ext.ext.ext')

# Generated at 2022-06-17 14:47:16.821097
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'playbook')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'not_a_type')

# Generated at 2022-06-17 14:47:22.110298
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-17 14:48:31.945149
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test with a package
    test_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.package', path_list=['/path/to/ns/package'])
    assert test_loader.get_code('ansible_collections.ns.package') is None

    # Test with a module
    test_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=['/path/to/ns/module'])
    assert test_loader.get_code('ansible_collections.ns.module') is not None



# Generated at 2022-06-17 14:48:46.872150
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'playbook')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'doc_fragment')

# Generated at 2022-06-17 14:48:52.732032
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with a valid redirect
    _AnsibleCollectionConfig._config = {
        'collections_paths': [],
        'collections_paths_cache': {},
        'collections_paths_cache_time': 0,
        'collections_paths_cache_expiration': 0,
        'collections_paths_cache_enabled': False,
        'collections_paths_cache_lock': threading.Lock(),
    }
    _AnsibleCollectionConfig._config['collections_paths'].append(os.path.join(os.path.dirname(__file__), 'fixtures', 'test_collections'))
    _AnsibleCollectionConfig._config['collections_paths_cache_enabled'] = True

# Generated at 2022-06-17 14:48:55.653525
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Test for method find_module of class _AnsiblePathHookFinder
    # TODO: implement this test
    pass



# Generated at 2022-06-17 14:49:00.269657
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = '/tmp/ansible_collections/ansible/test/plugins/modules'
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    fullname = 'ansible_collections.ansible.test.plugins.modules.test_module'
    path = None
    assert path_hook_finder.find_module(fullname, path) is not None


# Generated at 2022-06-17 14:49:06.064086
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # test for method get_code of class _AnsibleCollectionPkgLoaderBase
    # mock _AnsibleCollectionPkgLoaderBase
    mock_AnsibleCollectionPkgLoaderBase = MagicMock(spec=_AnsibleCollectionPkgLoaderBase)
    mock_AnsibleCollectionPkgLoaderBase.get_filename.return_value = '<string>'
    mock_AnsibleCollectionPkgLoaderBase.get_source.return_value = 'test'
    # call method get_code
    mock_AnsibleCollectionPkgLoaderBase.get_code('test')
    # assert
    mock_AnsibleCollectionPkgLoaderBase.get_filename.assert_called_once_with('test')
    mock_AnsibleCollectionPkgLoaderBase.get_source.assert_called_once_with('test')

#

# Generated at 2022-06-17 14:49:08.016987
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 14:49:17.398882
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # test_path_list = ['/tmp/ansible_collections/ansible/test/plugins/module_utils/test_utils']
    test_path_list = ['/tmp/ansible_collections/ansible/test/plugins/module_utils/test_utils']
    test_fullname = 'ansible_collections.ansible.test.plugins.module_utils.test_utils'
    test_package_to_load = 'test_utils'
    test_parent_package_name = 'ansible_collections.ansible.test.plugins.module_utils'
    test_split_name = test_fullname.split('.')
    test_rpart_name = test_fullname.rpartition('.')

# Generated at 2022-06-17 14:49:21.920805
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _AnsibleCollectionPkgLoaderBase_test(object):
        def __init__(self, fullname, path_list=None):
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens

            self._source_code_path = None
            self._decoded_source = None
            self._compiled_code = None

            self._valid

# Generated at 2022-06-17 14:49:23.293470
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:51:51.374754
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 14:52:01.743344
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml.j2')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yml.j2')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml.j2', 'playbook')
    assert AnsibleCollectionRef.is_

# Generated at 2022-06-17 14:52:11.487491
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname.yml', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')
    assert AnsibleCollectionRef.from_f

# Generated at 2022-06-17 14:52:19.000390
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1:
    # Test if the method returns the correct data when the path is a file
    # and the file exists
    # Expected result:
    # The data of the file is returned
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection')
    data = loader.get_data('/tmp/test_data')
    assert data == b'This is a test file'

    # Test case 2:
    # Test if the method returns the correct data when the path is a file
    # and the file does not exist
    # Expected result:
    # None is returned
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection')
    data = loader.get_data('/tmp/test_data_not_exist')

# Generated at 2022-06-17 14:52:24.785113
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.utils.collection_loader import _get_collection_metadata
    from ansible.utils.collection_loader import _nested_dict_get
    from ansible.utils.collection_loader import _meta_yml_to_dict
    from ansible.utils.collection_loader import _get_ancestor_redirect
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader

# Generated at 2022-06-17 14:52:33.863487
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-17 14:52:34.858282
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:52:44.007084
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid ref
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # Test with valid ref with subdirs
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'

# Generated at 2022-06-17 14:52:53.509250
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module
    module_name = 'ansible_collections.test.test_collection.plugins.module_utils.test_module_utils'
    module_path = os.path.join(os.path.dirname(__file__), '../../../../../../../../lib/ansible/module_utils/test_module_utils.py')
    module_attrs = dict(
        __loader__=_AnsibleCollectionPkgLoaderBase(module_name),
        __file__=module_path,
        __package__='ansible_collections.test.test_collection.plugins.module_utils'
    )

# Generated at 2022-06-17 14:53:02.253842
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1
    # Test for the case when path is None
    # Expected result: ValueError
    try:
        _AnsibleCollectionPkgLoaderBase().get_data(None)
    except ValueError:
        pass
    else:
        assert False

    # Test case 2
    # Test for the case when path is a relative path
    # Expected result: ValueError
    try:
        _AnsibleCollectionPkgLoaderBase().get_data('relative_path')
    except ValueError:
        pass
    else:
        assert False

    # Test case 3
    # Test for the case when path is an absolute path
    # Expected result: None
    assert _AnsibleCollectionPkgLoaderBase().get_data('/absolute_path') is None

    # Test case 4
    # Test for the case when path