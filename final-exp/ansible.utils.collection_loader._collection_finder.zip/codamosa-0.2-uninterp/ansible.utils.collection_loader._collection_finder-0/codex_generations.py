

# Generated at 2022-06-17 14:43:52.429297
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins')

# Generated at 2022-06-17 14:44:01.538175
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = 'ansible_collections/ns/collection'
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    fullname = 'ansible_collections.ns.collection.plugins.module_utils.module_utils'
    path = None
    ansible_path_hook_finder.find_module(fullname, path)
    # TODO: assert something



# Generated at 2022-06-17 14:44:03.519612
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:44:14.646850
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with valid fqcr
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')

    # Test with invalid fqcr
    assert not AnsibleCollectionRef.try_parse

# Generated at 2022-06-17 14:44:19.342287
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'

# Generated at 2022-06-17 14:44:22.615836
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # TODO: implement this test
    assert False

# Generated at 2022-06-17 14:44:30.022786
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:44:39.914116
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:44:51.970029
# Unit test for method load_module of class _AnsibleInternalRedirectLoader

# Generated at 2022-06-17 14:44:59.625087
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:01.427942
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import tempfile
    import shutil
    import sys
    import types
    import unittest
    from ansible.module_utils._text import to_bytes, to_text

    class Test_AnsibleCollectionPkgLoaderBase_get_code(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_dir_bytes = to_bytes(self.temp_dir)
            self.temp_dir_text = to_text(self.temp_dir)
            self.temp_file = tempfile.NamedTemporaryFile(dir=self.temp_dir, delete=False)
            self.temp_file_bytes = to_bytes(self.temp_file.name)

# Generated at 2022-06-17 14:46:13.821175
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a package
    # Create a package
    pkg_name = 'ansible_collections.test.test_collection.test_namespace.test_pkg'
    pkg_path = os.path.join(os.path.dirname(__file__), 'data', 'test_collection', 'test_namespace', 'test_pkg')
    os.makedirs(pkg_path)
    # Create a module
    module_name = 'test_module'
    module_path = os.path.join(pkg_path, module_name + '.py')
    with open(module_path, 'w') as f:
        f.write('test_var = "test_value"')
    # Create a loader

# Generated at 2022-06-17 14:46:22.227839
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for valid collection reference
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yaml.j2', 'playbook')
    assert AnsibleCollectionRef.try_parse_

# Generated at 2022-06-17 14:46:26.660399
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test case 1
    # Input:
    #   fullname = 'ansible_collections.test.test_collection'
    #   self._fullname = 'ansible_collections.test.test_collection'
    #   self._source_code_path = None
    #   self._subpackage_search_paths = ['/home/user/ansible_collections/test/test_collection']
    # Expected output:
    #   filename = '/home/user/ansible_collections/test/test_collection/__synthetic__'
    #   return filename
    fullname = 'ansible_collections.test.test_collection'
    self = _AnsibleCollectionPkgLoaderBase(fullname)
    self._fullname = 'ansible_collections.test.test_collection'
    self._source

# Generated at 2022-06-17 14:46:35.364759
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-17 14:46:42.315260
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.somens', path_list=['/path/to/somens']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/somens])'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.somens', path_list=['/path/to/somens']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/somens])'

# Generated at 2022-06-17 14:46:51.703213
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # Test with valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection') == True

    # Test with invalid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subcollection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subcollection.subcollection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subcollection.subcollection.subcollection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subcollection.subcollection.subcollection.subcollection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subcollection.subcollection.subcollection.subcollection.subcollection') == False


# Generated at 2022-06-17 14:46:59.898827
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary sub-directory
    temp_subdir = tempfile.mkdtemp(dir=temp_dir)
    # Create a temporary sub-file
    temp_subfile = tempfile.NamedTemporaryFile(dir=temp_subdir, delete=False)
    # Create a temporary sub-sub-directory
    temp_subsubdir = tempfile.mkdtemp(dir=temp_subdir)
    # Create a temporary sub-sub-file
    temp_subsubfile = tempfile.NamedTemporaryFile(dir=temp_subsubdir, delete=False)
    # Create a temporary sub-sub-

# Generated at 2022-06-17 14:47:04.938515
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:47:16.605340
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    import os

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a subdirectory in the temporary directory
    subdir = os.path.join(tmpdir, 'subdir')
    os.mkdir(subdir)

    # create a file in the subdirectory
    file_path = os.path.join(subdir, 'file.py')
    with open(file_path, 'w') as f:
        f.write('#')

    # create a package in the subdirectory
    package_path = os.path.join(subdir, 'package')
    os.mkdir(package_path)

    # create a file in the package
    package_file_path = os.path.join(package_path, 'file.py')

# Generated at 2022-06-17 14:47:49.846219
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible_collections
    import ansible_collections.ansible
    import ansible_collections.ansible.builtin
    import ansible_collections.ansible.builtin.plugins
    import ansible_collections.ansible.builtin.plugins.module_utils
    import ansible_collections.ansible.builtin.plugins.module_utils.basic
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.common
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.common.text
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.common.text.converters
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.common.text.conver

# Generated at 2022-06-17 14:47:58.891509
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test case 1:
    # Input:
    #   ref = 'ns.coll.resource'
    #   ref_type = 'module'
    # Expected output:
    #   AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='resource', ref_type='module')
    ref = 'ns.coll.resource'
    ref_type = 'module'
    expected_output = AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='resource', ref_type='module')
    actual_output = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert expected_output == actual_output

    # Test case 2:
    # Input:
    #   ref = 'ns.coll.subdir1.subdir2.resource'
    #   ref_type

# Generated at 2022-06-17 14:48:11.422182
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid collection reference
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    # Test with valid collection reference with subdirs
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')

# Generated at 2022-06-17 14:48:21.715063
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:48:24.240907
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement
    pass

# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:48:32.931376
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:48:47.265816
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test for method get_code(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for the case when source code is not available
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module')
    assert loader.get_code('ansible_collections.test.test_collection.test_module') is None
    # test for the case when source code is available
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module')
    loader._source_code_path = 'test/unit/test_loader/test_data/test_module.py'
    assert loader.get_code('ansible_collections.test.test_collection.test_module') is not None




# Generated at 2022-06-17 14:48:58.453042
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:49:06.507673
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:49:16.013375
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test for method get_source(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module')
    assert loader.get_source('ansible_collections.test.test_collection.test_module') == '# test module\n'
    # test for a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_package')
    assert loader.get_source('ansible_collections.test.test_collection.test_package') == '# test package\n'
    # test for a package with no __init__.py

# Generated at 2022-06-17 14:49:47.812391
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test case 1
    fullname = 'ansible_collections.ns.module'
    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    loader._source_code_path = '/path/to/module.py'
    assert loader.get_filename(fullname) == '/path/to/module.py'

    # Test case 2
    fullname = 'ansible_collections.ns.module'
    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    loader._source_code_path = None
    loader._subpackage_search_paths = ['/path/to/module']
    assert loader.get_filename(fullname) == '/path/to/module/__synthetic__'

    # Test case 3
    fullname = 'ansible_collections.ns.module'
   

# Generated at 2022-06-17 14:49:57.913791
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.utils.collection_loader import _get_collection_metadata
    from ansible.utils.collection_loader import _nested_dict_get
    from ansible.utils.collection_loader import _meta_yml_to_dict
    from ansible.utils.collection_loader import _get_ancestor_redirect
    from ansible.utils.collection_loader import _AnsibleCollectionConfig
    from ansible.utils.collection_loader import _AnsibleCollectionLoader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNSPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionRootPkgLoader

# Generated at 2022-06-17 14:50:09.178420
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import pkgutil
    import sys
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary module inside that directory
    module_name = 'ansible_collections.my.my_collection.plugins.modules.my_module'
    module_file_name = module_name.replace('.', os.sep) + '.py'
    module_file_path = os.path.join(tmp_dir, module_file_name)
    with open(module_file_path, 'w') as f:
        f.write('# module file')

    # Create a temporary package inside that directory
    package_name = 'ansible_collections.my.my_collection.plugins.modules.my_package'
    package_file_

# Generated at 2022-06-17 14:50:19.434284
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll.name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name.name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll-name.name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll.name.name')
    assert AnsibleCollectionRef.is_valid_collection_

# Generated at 2022-06-17 14:50:24.542894
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test for method is_package(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    # This test is for the case where fullname is not equal to self._fullname
    # and raises a ValueError
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')
    with pytest.raises(ValueError):
        loader.is_package('ansible_collections.foo')


# Generated at 2022-06-17 14:50:31.521422
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.package', path_list=['/path/to/package'])
    assert loader.get_filename('ansible_collections.ns.package') == '/path/to/package/__synthetic__'

    # Test for a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=['/path/to/module'])
    assert loader.get_filename('ansible_collections.ns.module') == '/path/to/module.py'

    # Test for a package with multiple paths

# Generated at 2022-06-17 14:50:45.246058
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test with a package that has subpackages
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection', ['/path/to/my_collection'])
    assert loader.iter_modules('ansible_collections.my_namespace.my_collection') == [('ansible_collections.my_namespace.my_collection.my_subpackage', True)]

    # Test with a package that has subpackages and modules
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection', ['/path/to/my_collection'])

# Generated at 2022-06-17 14:50:55.963048
# Unit test for method load_module of class _AnsibleInternalRedirectLoader

# Generated at 2022-06-17 14:51:06.655577
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yaml')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yaml.j2')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yml.j2')

# Generated at 2022-06-17 14:51:12.872495
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=['/path/to/foo/bar'])
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/foo/bar])'

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar.baz', path_list=['/path/to/foo/bar'])
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/path/to/foo/bar/baz.py)'



# Generated at 2022-06-17 14:51:38.973781
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:51:47.250187
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:51:56.068568
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection') == True
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name') == True
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection-name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection.name.name') == False

# Generated at 2022-06-17 14:52:04.405125
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible_collections.ansible.builtin.plugins.module_utils.basic
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.test_module
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.test_module.test_module
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.test_module.test_module.test_module
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.test_module.test_module.test_module.test_module
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.test_module.test_module.test_module.test_module.test_module
    import ansible_collections

# Generated at 2022-06-17 14:52:16.020583
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    class Test_AnsibleCollectionFinder_find_module(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tmpdir_path = os.path.join(self.tmpdir, 'ansible_collections')
            os.makedirs(self.tmpdir_path)
            self.tmpdir_path_2 = os.path.join(self.tmpdir, 'ansible_collections_2')
            os.makedirs(self.tmpdir_path_2)
            self.tmpdir_path_3 = os.path.join(self.tmpdir, 'ansible_collections_3')

# Generated at 2022-06-17 14:52:22.622418
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with a valid redirect
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.module_utils.basic', [])
    assert loader._redirect == 'ansible.module_utils.basic'
    mod = loader.load_module('ansible.builtin.module_utils.basic')
    assert mod.__name__ == 'ansible.module_utils.basic'
    assert sys.modules['ansible.builtin.module_utils.basic'].__name__ == 'ansible.module_utils.basic'

    # Test with an invalid redirect
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.module_utils.basic', [])
    loader._redirect = 'ansible.module_utils.invalid'
    with pytest.raises(ImportError):
        loader.load_module

# Generated at 2022-06-17 14:52:30.986820
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')

# Generated at 2022-06-17 14:52:34.801738
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # This method is tested by test__AnsibleCollectionPkgLoader_get_data
    pass


# Generated at 2022-06-17 14:52:44.036608
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:52:53.508810
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Test the constructor of class _AnsibleCollectionFinder
    # Test the case when paths is None
    paths = None
    scan_sys_paths = True
    ansible_collection_finder = _AnsibleCollectionFinder(paths, scan_sys_paths)
    assert ansible_collection_finder._n_configured_paths == []
    assert ansible_collection_finder._n_cached_collection_paths is None
    assert ansible_collection_finder._n_cached_collection_qualified_paths is None
    assert ansible_collection_finder._n_playbook_paths == []

    # Test the case when paths is a string
    paths = '/tmp'
    scan_sys_paths = True