

# Generated at 2022-06-17 14:44:28.456271
# Unit test for method find_module of class _AnsibleCollectionFinder

# Generated at 2022-06-17 14:44:38.690590
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('ansible.builtin.ping', ['/tmp/ansible_collections/ansible/builtin/plugins/modules'])
    assert loader._fullname == 'ansible.builtin.ping'
    assert loader._split_name == ['ansible', 'builtin', 'ping']
    assert loader._package_to_load == 'ping'
    assert loader._candidate_paths == ['/tmp/ansible_collections/ansible/builtin/plugins/modules']
    assert loader._subpackage_search_paths == []
    assert loader._source_code_path == None
    assert loader._compiled_code == None
    assert loader._decoded_source == None
    assert loader._redirect_module == None
    assert loader._redirected_package_map == {}
    assert loader._

# Generated at 2022-06-17 14:44:44.064118
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.playbookname', 'playbook') == AnsibleCollectionRef('ns.coll', '', 'playbookname', 'playbook')

# Generated at 2022-06-17 14:44:49.037419
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.resource')

# Generated at 2022-06-17 14:44:52.871629
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module').__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:45:04.364051
# Unit test for constructor of class _AnsibleCollectionLoader

# Generated at 2022-06-17 14:45:10.956669
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None

# Generated at 2022-06-17 14:45:15.080996
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/path/to/ansible_collections'])
    assert loader._fullname == 'ansible_collections'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', 'ansible_collections', '')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == ['/path/to/ansible_collections/ansible_collections']
    assert loader._subpackage

# Generated at 2022-06-17 14:45:16.598308
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass



# Generated at 2022-06-17 14:45:27.164179
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:25.182451
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_path = '/tmp/test_path'
    test_data = 'test_data'
    test_file = os.path.join(test_path, 'test_file')
    test_file_data = 'test_file_data'
    test_dir = os.path.join(test_path, 'test_dir')
    test_dir_file = os.path.join(test_dir, 'test_dir_file')
    test_dir_file_data = 'test_dir_file_data'
    test_dir_init = os.path.join(test_dir, '__init__.py')
    test_dir_init_data = 'test_dir_init_data'
    test_dir_init_data_2 = 'test_dir_init_data_2'
    test_dir_init_

# Generated at 2022-06-17 14:46:34.314615
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2_')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2_3')

# Generated at 2022-06-17 14:46:38.454746
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # test for method load_module of class _AnsibleCollectionPkgLoader
    # mock _meta_yml_to_dict
    _meta_yml_to_dict = MagicMock()

# Generated at 2022-06-17 14:46:49.367935
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname', 'playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.playbookname.yml', 'playbook')
    assert Ansible

# Generated at 2022-06-17 14:46:57.698827
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=['/path/to/test_coll'])
    assert loader.is_package('ansible_collections.test_ns.test_coll')

    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll.test_module', path_list=['/path/to/test_coll'])
    assert not loader.is_package('ansible_collections.test_ns.test_coll.test_module')

# Generated at 2022-06-17 14:47:04.505759
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename.yml', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')

# Generated at 2022-06-17 14:47:16.194743
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename.yml', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')

# Generated at 2022-06-17 14:47:20.920984
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename.yml', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef

# Generated at 2022-06-17 14:47:27.235673
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test with valid data
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:47:35.864861
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:48:38.423740
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import ansible.module_utils.six as six
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.collections import AnsibleCollectionConfig
    from ansible.module_utils.common.collections import _AnsibleCollectionFinder
    from ansible.module_utils.common.collections import _AnsibleCollectionLoader
    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoader
    from ansible.module_utils.common.collections import _AnsibleCollectionNSPkgLoader

# Generated at 2022-06-17 14:48:44.723603
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case 1
    # Test for the case where path is not specified
    try:
        _AnsibleCollectionPkgLoaderBase.get_data(None)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test case 2
    # Test for the case where path is relative
    try:
        _AnsibleCollectionPkgLoaderBase.get_data('test')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test case 3
    # Test for the case where path is absolute and file exists
    if not os.path.isfile('/tmp/test'):
        with open('/tmp/test', 'w') as f:
            f.write('test')
    assert _AnsibleCollection

# Generated at 2022-06-17 14:48:48.293371
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test for method get_code(self, fullname)
    # of class _AnsibleCollectionPkgLoaderBase
    #
    # This test is not implemented.
    #
    # TODO: Implement this test.
    #
    # assertEqual(expected, _AnsibleCollectionPkgLoaderBase.get_code(fullname))
    raise SkipTest("TODO: Implement this test.")



# Generated at 2022-06-17 14:48:58.567854
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra.extra')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.extra.extra.extra')

# Generated at 2022-06-17 14:49:08.868610
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'

# Generated at 2022-06-17 14:49:20.083864
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-17 14:49:30.448830
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test with a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection', path_list=['/path/to/my_collection'])
    assert loader.get_filename('ansible_collections.my_namespace.my_collection') == '/path/to/my_collection/__synthetic__'
    # Test with a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection.my_module', path_list=['/path/to/my_collection'])
    assert loader.get_filename('ansible_collections.my_namespace.my_collection.my_module') == '/path/to/my_collection/my_module.py'


# Generated at 2022-06-17 14:49:40.929532
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test with a valid collection
    loader = _AnsibleCollectionPkgLoader(path=['/home/user/ansible_collections/ansible_collections/test_collection/test_namespace/test_collection'],
                                         package_to_load='test_collection',
                                         fullname='ansible_collections.test_collection.test_namespace.test_collection')
    loader._meta_yml_to_dict = lambda x, y: {'plugin_routing': {'action': {'test_plugin': {'redirect': 'test_collection.test_namespace.test_collection.plugins.test_plugin'}}}}
    loader.load_module('ansible_collections.test_collection.test_namespace.test_collection')

# Generated at 2022-06-17 14:49:42.601104
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: implement
    pass



# Generated at 2022-06-17 14:49:51.580784
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for empty path
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data('')
    # test for relative path
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data('relative_path')
    # test for non-existing path
    assert _AnsibleCollectionPkgLoaderBase().get_data('/non_existing_path') is None
    # test for existing path
    assert _AnsibleCollectionPkgLoaderBase().get_data('/etc/hosts') is not None



# Generated at 2022-06-17 14:50:33.026792
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins')

# Generated at 2022-06-17 14:50:45.547382
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for invalid collection name
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')

    # Test for invalid subdirs
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2.subdir3', 'resource', 'module')

    # Test for invalid resource
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource.ext', 'module')

    # Test for invalid ref_type
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'invalid_type')

    # Test for valid

# Generated at 2022-06-17 14:50:56.143531
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2_3')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2_3_4')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name1_2_3_4_5')

# Generated at 2022-06-17 14:51:06.739103
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for a file that exists
    loader = _AnsibleCollectionPkgLoaderBase('ansible.collections.testns.testcoll')
    loader._subpackage_search_paths = ['/tmp']
    assert loader.get_data('/tmp/test.py') == b'#!/usr/bin/python\n'
    # test for a file that does not exist
    assert loader.get_data('/tmp/test.py') is None
    # test for a file that exists but is a directory
    assert loader.get_data('/tmp/test') is None
    # test for a file that exists but is a directory
    assert loader.get_data('/tmp/test/test.py') is None


# Generated at 2022-06-17 14:51:14.290986
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # test_AnsibleCollectionRef_try_parse_fqcr_1
    ref = 'ns.coll.resource'
    ref_type = 'module'
    expected = AnsibleCollectionRef(collection_name='ns.coll', subdirs='', resource='resource', ref_type='module')
    actual = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert actual == expected

    # test_AnsibleCollectionRef_try_parse_fqcr_2
    ref = 'ns.coll.subdir1.resource'
    ref_type = 'module'
    expected = AnsibleCollectionRef(collection_name='ns.coll', subdirs='subdir1', resource='resource', ref_type='module')

# Generated at 2022-06-17 14:51:22.516736
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import unittest
    import unittest.mock as mock

    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import reload_module

    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoaderBase

    # TODO: test with a real collection

    class TestPkgLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            return path_list


# Generated at 2022-06-17 14:51:30.320817
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:51:35.331238
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'ref_type').__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:51:48.117121
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:51:58.364419
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type