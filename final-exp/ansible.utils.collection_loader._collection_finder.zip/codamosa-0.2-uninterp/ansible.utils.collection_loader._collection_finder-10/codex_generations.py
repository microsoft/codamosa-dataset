

# Generated at 2022-06-17 14:45:08.826140
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'

# Generated at 2022-06-17 14:45:15.329241
# Unit test for constructor of class _AnsibleCollectionFinder

# Generated at 2022-06-17 14:45:22.841252
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.test_ns')
    assert loader._fullname == 'ansible_collections.test_ns'
    assert loader._split_name == ['ansible_collections', 'test_ns']
    assert loader._rpart_name == ('ansible_collections', '.', 'test_ns')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'test_ns'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == ['/test_ns']
    assert loader._subpackage_search_paths == ['/test_ns']


# Implements Ans

# Generated at 2022-06-17 14:45:32.385712
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with a valid redirect
    fullname = 'ansible.module_utils.six'
    path_list = []
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    loader._redirect = 'ansible.module_utils.six'
    assert loader.load_module(fullname) == sys.modules[fullname]

    # Test with an invalid redirect
    fullname = 'ansible.module_utils.six'
    path_list = []
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    loader._redirect = None
    with pytest.raises(ValueError):
        loader.load_module(fullname)


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook imp

# Generated at 2022-06-17 14:45:45.740643
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:45:47.386139
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 14:45:52.741696
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test case data
    fullname = 'ansible_collections.test.test_collection'
    filename = '<ansible_synthetic_collection_package>'
    source_code = '#!/usr/bin/python\n# -*- coding: utf-8 -*-\n\n\nclass TestClass(object):\n    def __init__(self):\n        self.test_var = \'test_value\'\n\n    def test_method(self):\n        return self.test_var\n\n\nif __name__ == \'__main__\':\n    test_class = TestClass()\n    print(test_class.test_method())\n'
    # Perform the test
    test_obj = _AnsibleCollectionPkgLoaderBase(fullname)
    test_obj

# Generated at 2022-06-17 14:45:56.903162
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:45:57.433544
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:46:05.739703
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:46:39.344734
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # Test for constructor of class _AnsibleCollectionLoader
    loader = _AnsibleCollectionLoader('ansible_collections.test.test_collection.plugins.module_utils.test_module_utils', ['/tmp/test_collection'])
    assert loader._fullname == 'ansible_collections.test.test_collection.plugins.module_utils.test_module_utils'
    assert loader._split_name == ['ansible_collections', 'test', 'test_collection', 'plugins', 'module_utils', 'test_module_utils']
    assert loader._package_to_load == 'plugins.module_utils.test_module_utils'
    assert loader._candidate_paths == ['/tmp/test_collection']

# Generated at 2022-06-17 14:46:46.886325
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo', path_list=['/path/to/foo']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/path/to/foo)'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo', path_list=[]).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'



# Generated at 2022-06-17 14:46:57.391574
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import os
    import tempfile
    import shutil
    import sys
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url

# Generated at 2022-06-17 14:47:09.329276
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('ansible_collections.test.test_collection.test_plugin', ['/path/to/test_collection'])
    assert loader._fullname == 'ansible_collections.test.test_collection.test_plugin'
    assert loader._package_to_load == 'test_plugin'
    assert loader._parent_package_name == 'ansible_collections.test.test_collection'
    assert loader._split_name == ['ansible_collections', 'test', 'test_collection', 'test_plugin']
    assert loader._candidate_paths == ['/path/to/test_collection/test_plugin']
    assert loader._subpackage_search_paths == ['/path/to/test_collection/test_plugin']

# Generated at 2022-06-17 14:47:20.547170
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import pkgutil
    import importlib
    import importlib.abc
    import importlib.util
    import importlib.machinery
    import importlib.machinery_source
    import importlib.machinery_bytecode
    import importlib.machinery_synthetic
    import importlib.machinery_extension
    import importlib.machinery_pkgutil
    import importlib.machinery_pkgresources
    import importlib.machinery_winreg
    import importlib.machinery_path
    import importlib.machinery_namespace
    import importlib.machinery_zip
    import importlib.machinery_imp
    import importlib.machinery_cffi

# Generated at 2022-06-17 14:47:32.615111
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for a package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', ['/path/to/collection'])
    loader._subpackage_search_paths = ['/path/to/collection/foo/bar']
    assert loader.get_filename('ansible_collections.foo.bar') == '/path/to/collection/foo/bar/__synthetic__'

    # Test for a module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', ['/path/to/collection'])
    loader._source_code_path = '/path/to/collection/foo/bar.py'
    assert loader.get_filename('ansible_collections.foo.bar') == '/path/to/collection/foo/bar.py'

    #

# Generated at 2022-06-17 14:47:46.197880
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    import os
    import sys
    import pkgutil
    import importlib
    import unittest
    import ansible.module_utils.six as six

    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.collection_name = 'test_collection'
            self.collection_path = os.path.join(self.tmpdir, self.collection_name)
            self.collection_module_path = os.path.join(self.collection_path, 'plugins', 'modules')

# Generated at 2022-06-17 14:47:48.694618
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement
    pass


# Generated at 2022-06-17 14:47:58.284979
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test valid fqcr
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'subdir1', 'rolename', 'role')
   

# Generated at 2022-06-17 14:48:04.031400
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:49:15.691988
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid fqcr
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'

    # Test with valid fqcr and subdirs
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'

    # Test with valid fqcr and role

# Generated at 2022-06-17 14:49:24.245813
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:49:33.353527
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module that has no code
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection.test_module', path_list=[])
    loader._subpackage_search_paths = None
    loader._source_code_path = None
    module = loader.load_module('ansible_collections.test.test_collection.test_module')
    assert module.__name__ == 'ansible_collections.test.test_collection.test_module'
    assert module.__loader__ == loader
    assert module.__file__ is None
    assert module.__package__ == 'ansible_collections.test.test_collection'

    # Test with a module that has code

# Generated at 2022-06-17 14:49:46.586231
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for a valid collection reference
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    # Test for a valid collection reference with subdirs
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    # Test for an invalid collection reference
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource.invalid', 'module')
    # Test for an invalid collection reference with subdirs
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource.invalid', 'module')
    # Test for a valid collection reference with a playbook extension

# Generated at 2022-06-17 14:49:50.274042
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a valid module
    test_module_name = 'ansible_collections.test_ns.test_coll.plugins.modules.test_module'
    test_module_path = 'ansible_collections/test_ns/test_coll/plugins/modules/test_module.py'

# Generated at 2022-06-17 14:49:55.330202
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.fqcr == 'ns.coll.resource'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'

# Generated at 2022-06-17 14:50:06.540713
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == 'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert ref.collection == 'ns.coll'

# Generated at 2022-06-17 14:50:17.582654
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import os
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import _thread
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import reload
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import config

# Generated at 2022-06-17 14:50:20.059454
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', None)
    assert loader._redirect == 'ansible.module_utils.basic'


# Generated at 2022-06-17 14:50:23.423113
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(collection_name='namespace.collection', subdirs='subdir1.subdir2', resource='resource', ref_type='module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-17 14:51:25.032110
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('vars_plugins')

# Generated at 2022-06-17 14:51:36.067017
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test for valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.coll_name2')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.coll_name2.coll_name3')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.coll_name2.coll_name3.coll_name4')

# Generated at 2022-06-17 14:51:38.649335
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: implement test
    pass


# Generated at 2022-06-17 14:51:47.088978
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test 1
    # Test with a valid path
    # Expected result: source code of the file
    test_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_collection')
    test_loader._source_code_path = os.path.join(os.path.dirname(__file__), '__init__.py')

# Generated at 2022-06-17 14:51:56.044929
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test for method try_parse_fqcr of class AnsibleCollectionRef
    # FIXME: this test is incomplete
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname', 'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.playbookname.yml', 'playbook')

# Generated at 2022-06-17 14:52:03.260650
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir_to

# Generated at 2022-06-17 14:52:12.444433
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoaderBase

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tempdir)

        def test_get_filename_package(self):
            # create a package
            pkg_path = os.path.join(self.tempdir, 'foo')
            os.mkdir(pkg_path)
            # create a subpackage
            subpkg_path = os.path.join(pkg_path, 'bar')

# Generated at 2022-06-17 14:52:20.129359
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {'plugin_routing': {'action': {'test': {'redirect': '..test'}}}}
    loader = _AnsibleCollectionPkgLoader(['ansible_collections', 'test', 'test'], 'ansible_collections.test.test', '/tmp')
    loader.load_module('ansible_collections.test.test')


# Generated at 2022-06-17 14:52:21.318361
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # TODO: implement
    pass

# Generated at 2022-06-17 14:52:23.517400
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # test_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test', path_list=['/tmp/test'])
    # test_loader.get_code(fullname='ansible_collections.test')
    pass



# Generated at 2022-06-17 14:52:47.148835
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import types
    import unittest

    class _AnsibleInternalRedirectLoaderTestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.test_module_name = 'test_module'
            self.test_module_path = os.path.join(self.test_dir, self.test_module_name + '.py')

# Generated at 2022-06-17 14:52:57.709872
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test with valid input
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename.yml', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')

# Generated at 2022-06-17 14:53:08.926975
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for the case where the toplevel package is not 'ansible'
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo.bar', [])

    # Test for the case where the toplevel package is 'ansible' but the module is not redirected
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.foo', [])

    # Test for the case where the toplevel package is 'ansible' and the module is redirected
    loader = _AnsibleInternalRedirectLoader('ansible.foo', [])
    assert loader._redirect == 'ansible_collections.foo'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built