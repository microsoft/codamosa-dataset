

# Generated at 2022-06-17 14:44:04.079076
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:44:15.201564
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid collection names
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name

# Generated at 2022-06-17 14:44:21.660444
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:44:27.903036
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'subdir1', 'rolename', 'role')
    assert AnsibleCollectionRef.from_

# Generated at 2022-06-17 14:44:38.604692
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc.Loader
    import importlib.abc.MetaPathFinder
    import importlib.abc.InspectLoader
    import importlib.abc.ResourceLoader
    import importlib.abc.ExecutionLoader
    import importlib.abc.Loader
    import importlib.abc.MetaPathFinder
    import importlib.abc.InspectLoader
    import importlib.abc.ResourceLoader
    import importlib.abc.ExecutionLoader
    import importlib.abc.Loader
    import importlib.abc.MetaPathFinder
    import importlib.abc.InspectLoader
    import importlib.abc.ResourceLoader

# Generated at 2022-06-17 14:44:42.776299
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-17 14:44:46.934949
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible_collections.ansible.builtin
    import ansible_collections.ansible.builtin.plugins.module_utils.basic
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.basic
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.basic.__init__
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.basic.__main__
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.basic.__main__.__init__
    import ansible_collections.ansible.builtin.plugins.module_utils.basic.basic.__main__.__init__.__init__
    import ansible_collections.ansible.builtin.plugins

# Generated at 2022-06-17 14:44:55.770107
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test with a valid redirect
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six', [])
    redirect_loader._redirect = 'six'
    assert redirect_loader.load_module('ansible.module_utils.six') == six

    # Test with an invalid redirect
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six', [])
    redirect_loader._redirect = 'six.moves'
    with pytest.raises(ImportError):
        redirect_loader.load_module('ansible.module_utils.six')


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:45:07.738478
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('terminal_plugins') == 'terminal'

# Generated at 2022-06-17 14:45:14.653891
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import ansible.utils.collection_loader
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.six.moves.urllib.robotparser
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request

# Generated at 2022-06-17 14:45:51.726548
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test with a module that has a package
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a package with a module
        pkg_name = 'ansible_collections.test.test_collection'
        pkg_path = os.path.join(tmpdirname, pkg_name.replace('.', os.sep))
        os.makedirs(pkg_path)
        with open(os.path.join(pkg_path, '__init__.py'), 'w') as f:
            f.write('#')
        with open(os.path.join(pkg_path, 'test_module.py'), 'w') as f:
            f.write('#')
        # Create a loader

# Generated at 2022-06-17 14:45:58.402360
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for method get_data(self, path)
    # of class _AnsibleCollectionPkgLoaderBase
    # test for empty path
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data('')
    # test for relative path
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase().get_data('relative_path')
    # test for non-existent path
    assert _AnsibleCollectionPkgLoaderBase().get_data('/non_existent_path') is None
    # test for existing path
    assert _AnsibleCollectionPkgLoaderBase().get_data(__file__) is not None
    # test for existing path to a directory

# Generated at 2022-06-17 14:46:11.448616
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:46:20.341483
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test valid collection name
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name1.coll_name2')

    # Test invalid collection name
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.coll.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.coll.coll.coll')

# Generated at 2022-06-17 14:46:23.815548
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # _AnsibleCollectionPkgLoader.load_module(fullname)
    # TODO: implement your test here
    raise NotImplementedError()


# Generated at 2022-06-17 14:46:34.192220
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # test_get_source_with_no_source_code_path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', [])
    assert loader.get_source('ansible_collections.foo.bar') is None

    # test_get_source_with_source_code_path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', [])
    loader._source_code_path = 'foo'
    assert loader.get_source('ansible_collections.foo.bar') is None

    # test_get_source_with_source_code_path_and_decoded_source
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', [])

# Generated at 2022-06-17 14:46:41.666168
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # test_data_path = os.path.join(os.path.dirname(__file__), 'data')
    test_data_path = os.path.join(os.path.dirname(__file__), 'data')
    test_data_path = os.path.abspath(test_data_path)
    test_data_path = to_bytes(test_data_path)
    test_data_path = to_native(test_data_path)
    # test_data_path = os.path.join(os.path.dirname(__file__), 'data')
    # test_data_path = os.path.abspath(test_data_path)
    # test_data_path = to_bytes(test_data_path)
    # test_data_path = to_native(test

# Generated at 2022-06-17 14:46:51.390565
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:46:59.630486
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x, y: {}
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.on_collection_load = lambda x, y: None

# Generated at 2022-06-17 14:47:12.099291
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module') == AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'module') == AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename.yml', 'role') == AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')
    assert AnsibleCollectionRef.try_parse_fq

# Generated at 2022-06-17 14:48:24.530443
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext2')

# Generated at 2022-06-17 14:48:33.613678
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # create a mock module
    mock_module = MagicMock()
    mock_module.__path__ = ['path']
    mock_module._collection_meta = {}
    mock_module.__file__ = 'file'
    mock_module.__loader__ = 'loader'
    mock_module.__package__ = 'package'

    # create a mock loader
    mock_loader = MagicMock()
    mock_loader._split_name = ['ansible', 'collections', 'namespace']
    mock_loader._subpackage_search_paths = ['path']
    mock_loader.get_filename.return_value = 'file'
    mock_loader.load_module.return_value = mock_module

    # create a mock AnsibleCollectionConfig
    mock_config = MagicMock()
    mock_config.on_collection_

# Generated at 2022-06-17 14:48:47.580710
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-17 14:48:54.317993
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six', None)
    assert loader._redirect == 'ansible.module_utils.six'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:49:01.641073
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder

# Generated at 2022-06-17 14:49:08.741600
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test with collection_name = 'namespace.collectionname', subdirs = 'subdir1.subdir2', resource = 'mymodule', ref_type = 'action'
    ref = AnsibleCollectionRef('namespace.collectionname', 'subdir1.subdir2', 'mymodule', 'action')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='namespace.collectionname', subdirs='subdir1.subdir2', resource='mymodule')"


# Generated at 2022-06-17 14:49:19.986134
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'playbook')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'not_a_valid_type')
    assert not AnsibleCollectionRef

# Generated at 2022-06-17 14:49:25.859561
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x,y: {}
    loader = _AnsibleCollectionPkgLoader(['/path/to/collection'], 'ansible_collections.namespace.collection')
    loader.load_module('ansible_collections.namespace.collection')


# Generated at 2022-06-17 14:49:36.007141
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:49:47.501718
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionRedirectLoader
    from ansible.utils.collection_loader import _AnsibleCollectionSyntheticLoader
    from ansible.utils.collection_loader import _AnsibleCollectionNamespaceLoader
    from ansible.utils.collection_loader import _AnsibleCollectionModuleLoader

    # test _AnsibleCollectionPkgLoaderBase
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')
    assert repr(loader) == '_AnsibleCollectionPkgLoaderBase(path=None)'

    # test _AnsibleCollectionPkgLoader
    loader = _Ans

# Generated at 2022-06-17 14:51:27.351544
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:51:29.035608
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # _AnsibleCollectionPkgLoader.load_module()
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 14:51:35.348766
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('roles') == 'role'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('playbooks') == 'playbook'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-17 14:51:48.059228
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:51:56.323388
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    from ansible.module_utils.six import PY3

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_native

    from ansible.utils.collection_loader import _AnsibleCollectionFinder, _AnsibleCollectionLoader, _AnsibleCollectionPkgLoader, _AnsibleCollectionNSPkgLoader, _AnsibleCollectionRootPkgLoader, _AnsibleInternalRedirectLoader

    class TestAnsibleCollectionFinder(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 14:52:03.572670
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Test with no arguments
    collection_finder = _AnsibleCollectionFinder()
    assert collection_finder._ansible_pkg_path == os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    assert collection_finder._n_configured_paths == []
    assert collection_finder._n_cached_collection_paths is None
    assert collection_finder._n_cached_collection_qualified_paths is None
    assert collection_finder._n_playbook_paths == []

    # Test with arguments
    collection_finder = _AnsibleCollectionFinder(paths=['/tmp'], scan_sys_paths=False)
    assert collection_finder._ansible_pkg_path == os.path

# Generated at 2022-06-17 14:52:15.439801
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:52:24.995932
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for non-ansible module
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('test.module', None)

    # Test for non-redirected module
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.module', None)

    # Test for redirected module
    loader = _AnsibleInternalRedirectLoader('ansible.module.test', None)
    assert loader._redirect == 'ansible.builtin.test'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-17 14:52:34.154115
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-17 14:52:35.506243
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: implement unit test
    pass
