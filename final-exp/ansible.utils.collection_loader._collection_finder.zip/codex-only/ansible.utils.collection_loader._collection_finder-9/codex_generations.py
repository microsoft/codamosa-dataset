

# Generated at 2022-06-23 13:43:41.264076
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    path_list=[to_bytes(os.path.join(test_data_path, 'file_finder_path_hook_test'))]
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list)
    assert loader
    assert loader._fullname == 'ansible_collections'
    assert loader._subpackage_search_paths == path_list



# Generated at 2022-06-23 13:43:50.856779
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Testing method __repr__ of class _AnsibleCollectionPkgLoaderBase
    # using a subclass.

    # test with no path
    class _TestLoaderNoPath(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
    loader = _TestLoaderNoPath('failed_path', path_list=[])
    assert loader.__repr__() == '_TestLoaderNoPath(path=None)'

    # test with empty path list
    class _TestLoaderEmptyPath(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
    loader = _TestLoaderEmptyPath('failed_path', path_list=[])
    assert loader.__repr__() == '_TestLoaderEmptyPath(path=[])'

    # test with populated path list

# Generated at 2022-06-23 13:44:00.808759
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # You can set paths for a test.
    sys.path[0] = 'path1'
    sys.path[1] = 'path2'
    sys.path[2] = 'path3'
    sys.path[3] = 'path4'
    sys.path[4] = 'path5'
    _AnsibleCollectionFinder.collection_finder.set_playbook_paths(['a/b/c', 'd/e/f', 'g/h/i', 'j/k/l', 'm/n/o'])
    # This function calls function _remove, which clears the paths set by the set_playbook_paths method.
    # So the paths set by the set_playbook_paths method are not seen.
    _AnsibleCollectionFinder.remove()
    # You can set new

# Generated at 2022-06-23 13:44:09.920534
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Setup
    name = 'ansible.test_collection.test_ns1.test_ns2.test_pkg'
    path_list = ['/path/to/ansible/collection_name/ns1/ns2/test_pkg']
    loader = _AnsibleCollectionPkgLoaderBase(name, path_list)
    assert loader._subpackage_search_paths == ['/path/to/ansible/collection_name/ns1/ns2/test_pkg']

    # Pre test actions
    assert loader.is_package(name) == True
    assert loader.is_package('ansible.test_collection.test_ns1.test_ns2') == False
    assert loader.is_package('ansible.test_collection.test_ns1.test_ns2.test_pkg.test_module') == False

# Generated at 2022-06-23 13:44:15.904220
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    _AnsibleCollectionPkgLoaderBase_load_module_paths = ["/tmp"]
    _AnsibleCollectionPkgLoaderBase_load_module_fullname = "foo"
    loader = _AnsibleCollectionPkgLoaderBase(
        _AnsibleCollectionPkgLoaderBase_load_module_fullname,
        path_list=_AnsibleCollectionPkgLoaderBase_load_module_paths
    )
    module = loader.load_module(_AnsibleCollectionPkgLoaderBase_load_module_fullname)
    assert module is not None
    assert isinstance(module, ModuleType)
    assert module.__dict__["__loader__"] is loader
    assert module.__dict__["__package__"] == ""



# Generated at 2022-06-23 13:44:20.391396
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # test different values of fullname and _fullname
    loader = _AnsibleCollectionPkgLoaderBase('fullname', '/test')
    assert loader.is_package('fullname')
    try:
        loader.is_package('test')
    except ValueError:
        pass
    else:
        assert (False)
    loader = _AnsibleCollectionPkgLoaderBase('fullname', [])
    assert (not loader.is_package('fullname'))



# Generated at 2022-06-23 13:44:28.971630
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible import context
    from ansible.utils.collection_loader.collection_finder import _AnsibleCollectionFinder
    from ansible.utils.collection_loader.module_finder import _AnsibleModuleFinder

    # test starting with a single collection path
    def cfl_init(path):
        # create a collection finder with a single path
        return _AnsibleCollectionFinder(path=[path])

    cf = cfl_init(context.CLIARGS['collections_paths'])
    mf = _AnsibleModuleFinder([context.CLIARGS['collections_paths']], collection_finder=cf)
    collections = [c.split('.')[0] for c in mf.iter_collections()]

    # test starting with an empty collection path
    mf = _Ansible

# Generated at 2022-06-23 13:44:40.456856
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    path_list = ['/path/to/collections1',
                 '/path/to/collections2',
                 '/path/to/collections3']

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.acme', path_list)
    assert ['/path/to/collections1/acme',
            '/path/to/collections2/acme',
            '/path/to/collections3/acme'] == loader._candidate_paths
    assert '/path/to/collections1/acme' == loader._subpackage_search_paths[0]
    assert 'ansible_collection.acme' == loader._fullname
    assert 'ansible_collections' == loader._parent_package_name
    assert 'acme' == loader._package_to_load

# Generated at 2022-06-23 13:44:42.737848
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = '/foo/bar'
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    expected = "_AnsiblePathHookFinder(path='/foo/bar')"
    actual = repr(ansible_path_hook_finder)
    assert actual == expected

# Generated at 2022-06-23 13:44:51.830821
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    try:
        from ansible.utils.collection_loader import _meta_yml_to_dict
    except ImportError:
        _meta_yml_to_dict = None
        
    # Create the test object
    for path in get_collection_paths():
        if os.path.isdir(path):
            pkg_to_load = 'command'
            package_name = 'ansible_collections.ansible.builtin'
            fullname = 'ansible_collections.ansible.builtin.command'
            
            cpl = _AnsibleCollectionPkgLoader(package_name, to_text(path), pkg_to_load)
            if cpl._source_code_path == None:
                continue
            
            # Run the code under test

# Generated at 2022-06-23 13:44:57.701625
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-23 13:44:58.882934
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # TODO: Add tests for the method to test for valid and invalid FQCRs
    pass


# Generated at 2022-06-23 13:45:11.633736
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import path_hook_utilities as util
    fpath = "../collection_data"
    path_list = [util.init_paths(fpath)]
    loader_obj = _AnsibleCollectionPkgLoaderBase("ansible_collections.all.plugins.module_utils.basic", path_list)
    filenames = ["__init__.py","ping.py","__main__.py","__init__.py","p.py","__init__.py","__init__.py","__init__.py","ansible_module_ping.py"]

# Generated at 2022-06-23 13:45:18.429028
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    filename = '/usr/share/ansible/roles/myrole/'
    loader = _AnsibleCollectionPkgLoaderBase(filename, [])
    assert loader.__repr__() == "AnsibleCollectionPkgLoaderBase(path=None)"



# Generated at 2022-06-23 13:45:22.002695
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.plugin', ['/tmp/path'])
    loader._subpackage_search_paths = ['/tmp/path/1', '/tmp/path/2']
    assert loader.get_data('/tmp/path/1/__init__.py') == ''


# Generated at 2022-06-23 13:45:24.741548
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    obj = _AnsiblePathHookFinder(None, 'some_path')
    expected = "{0}(path='{1}')".format(obj.__class__.__name__, 'some_path')
    actual = repr(obj)
    assert expected == actual, 'Expected and actual values do not match'



# Generated at 2022-06-23 13:45:37.402616
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import subprocess
    import sys
    import os
    import shutil
    import tempfile

    # Copy over the contents of test_data/ into tmp/
    # FUTURE: currently this test relies on the repo having a specific relative path
    # (../../), which is NOT true when running in a venv with zipped modules. Modify
    # the test to handle this by copying over the test data into a created tempdir.
    ansible_base = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    C = _AnsibleCollectionPkgLoaderBase
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir += '/test_data'

# Generated at 2022-06-23 13:45:50.801024
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    try:
        importlib.reload(sys)
    except NameError:
        import imp
        imp.reload(sys)

    try:
        importlib.reload(os)
    except NameError:
        import imp
        imp.reload(os)

    try:
        importlib.reload(pkgutil)
    except NameError:
        import imp
        imp.reload(pkgutil)

    try:
        importlib.reload(_AnsibleCollectionFinder)
    except NameError:
        import imp
        imp.reload(_AnsibleCollectionFinder)

    try:
        importlib.reload(_AnsiblePathHookFinder)
    except NameError:
        import imp
        imp.reload(_AnsiblePathHookFinder)

    test_obj = _Ans

# Generated at 2022-06-23 13:45:55.666907
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Test the contructor of class _AnsiblePathHookFinder without calling def __init__ directly.
    # Then validate the value of the global variable _filefinder_path_hook.
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None



# Generated at 2022-06-23 13:46:05.444257
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # make a directory
    (fd, path) = tempfile.mkstemp()
    os.close(fd)

    # create a bunch of files in the directory
    for name in ('__init__.py', '__init__.pyc', 'foo.py', 'foo/__init__.py', 'foo.pyc', 'bar.py', 'bar/__init__.py', 'bar.pyc'):
        with open(os.path.join(path, name), 'w') as f:
            f.write('test')

    # test files in the directory
    base = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=[path])

# Generated at 2022-06-23 13:46:15.883299
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    def _test_path(path, expected_result, expected_error_type=None):
        try:
            assert(_AnsibleCollectionPkgLoaderBase.get_data(path) == expected_result)
        except Exception as err:
            assert (type(err) == expected_error_type)
    _test_path('/abc/abc.py', 'abc\n', None)
    try:
        _AnsibleCollectionPkgLoaderBase.get_data('abc.py')
    except Exception as err:
        assert (type(err) == ValueError)
    _test_path('/abc/__init__.py', '', None)
    _test_path('/abc/def.py', 'def\n', None)
    _test_path('/abc/def.py', 'def\n', None)
   

# Generated at 2022-06-23 13:46:16.975367
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # pass
    pass


# Generated at 2022-06-23 13:46:26.711686
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class Foo(_AnsibleCollectionPkgLoaderBase):
        def _validate_final(self):
            pass

        def get_source(self, fullname):
            pass

    f = Foo('foo', path_list=['/bar/baz'])
    assert f._package_to_load == 'foo'
    assert f._parent_package_name == ''
    assert f._candidate_paths == ['/bar/baz/foo']

    f = Foo('foo.bar', path_list=['/bar/baz'])
    assert f._package_to_load == 'bar'
    assert f._parent_package_name == 'foo'
    assert f._candidate_paths == ['/bar/baz/bar']



# Generated at 2022-06-23 13:46:33.073544
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Testing on a non existent package
    loader = _AnsibleCollectionPkgLoaderBase('ns1.ns2.ns3', path_list=['/path/to/ansible_collections/ns1/ns2'])
    if loader.is_package('ns1.ns2.ns3') != False:
        raise AssertionError('is_package should return false for non existent package')

    # Testing on an existent package
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns1.ns2', path_list=['/path/to/ansible_collections/ns1/ns2'])
    if loader.is_package('ansible_collections.ns1.ns2') != True:
        raise AssertionError('is_package should return true for existent package')

   

# Generated at 2022-06-23 13:46:42.596280
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """This function is a test function for class _AnsibleCollectionPkgLoaderBase"""
    print("##### Test get_data of class _AnsibleCollectionPkgLoaderBase #####")
    class _AnsibleCollectionPkgLoaderBase_test(object):
        """This class inherits _AnsibleCollectionPkgLoaderBase and is used for testing"""
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths
        def get_filename(self, fullname):
            if fullname == 'test_fullname':
                return 'test_get_filename.py'
            else:
                return None
        def get_source(self, fullname):
            return None

# Generated at 2022-06-23 13:46:50.823391
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    fullname = 'ansible_collections'
    loader = _AnsibleCollectionRootPkgLoader(fullname)

    assert loader._fullname == fullname
    assert loader._split_name == ['ansible_collections']
    assert loader._package_to_load == 'ansible_collections'
    assert loader._parent_package_name == ''

    assert loader._subpackage_search_paths is None
    assert loader._source_code_path is None



# Generated at 2022-06-23 13:46:59.695802
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    from ansible.module_utils._text import to_native

    test_data = ['ansible_collections/ns/collection/module_utils/module',
                 'ansible_collections/ns/collection/filter_plugins/filter',
                 'ansible_collections/ns/collection/roles/role',
                 'ansible_collections/ns/collection/modules/module', ]

    # Make a 'mock' FS using a temp dir
    tmp_dir = tempfile.mkdtemp(prefix='test_ansible_collections_')
    # Add test data to mock FS
    for data in test_data:
        os.makedirs(os.path.join(tmp_dir, os.path.dirname(data)))
        # Create a fake module by writing a buffer to the new file, then add it to the mock FS


# Generated at 2022-06-23 13:47:03.218342
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    a = AnsibleCollectionRef('a', 'b', 'c', 'd')
    assert repr(a) == "AnsibleCollectionRef(collection='a', subdirs='b', resource='c')"

# Generated at 2022-06-23 13:47:13.737516
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:47:20.642122
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    fullname = 'ansible_collections'
    path_list = []
    root_pkg_loader = _AnsibleCollectionRootPkgLoader(fullname, path_list)
    assert fullname == root_pkg_loader._fullname
    assert root_pkg_loader._redirect_module is None
    assert ['ansible_collections'] == root_pkg_loader._split_name
    assert ('', '.', 'ansible_collections') == root_pkg_loader._rpart_name
    assert '' == root_pkg_loader._parent_package_name
    assert 'ansible_collections' == root_pkg_loader._package_to_load
    assert '' == root_pkg_loader._source_code_path
    assert None is root_pkg_loader._decoded_source
    assert None is root_pkg_loader._comp

# Generated at 2022-06-23 13:47:30.726127
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_path = os.path.normpath(os.path.join(os.getcwd(), '../ansible_collections'))
    ansible_collection_loader.init(collection_path)

    test_collection_loader = ansible_collection_loader.collection_loader('ansible.builtin')
    test_collection_loader.load_module('ansible.builtin')

    test_collection_loader2 = ansible_collection_loader.collection_loader('ansible_collections.test.test_utils.tools_test')
    test_collection_loader2.load_module('ansible_collections.test.test_utils.tools_test')



# Generated at 2022-06-23 13:47:43.934926
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    source_code_path = 'test_source_code_path'
    decoded_source = 'test_decoded_source'
    compiled_code = 'test_compiled_code'

    class _AnsibleCollectionPkgLoaderBaseTest(_AnsibleCollectionPkgLoaderBase):

        def _validate_args(self): pass
        def _get_candidate_paths(self, path_list): return path_list
        def _get_subpackage_search_paths(self, candidate_paths): return candidate_paths
        def _validate_final(self): pass

        def get_source(self, fullname):
            return decoded_source
        def get_filename(self, fullname):
            return source_code_path
        def get_code(self, fullname):
            return compiled_code

       

# Generated at 2022-06-23 13:47:55.863062
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    finder = _AnsibleCollectionFinder()
    assert finder.find_module('ansible')
    assert finder.find_module('ansible_collections')
    assert not finder.find_module('ansible_collections.notexists')
    assert not finder.find_module('ansible_collections.notexists.notexists')
    assert finder.find_module('ansible_collections.somenamespace')
    assert finder.find_module('ansible_collections.somenamespace.somecollection')
    assert finder.find_module('ansible_collections.somenamespace.somecollection.someplugin')
    assert not finder.find_module('ansible_collections.somenamespace.somecollection.notexists')




# Generated at 2022-06-23 13:48:07.615237
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    """Unit test for constructor of class _AnsibleCollectionLoader"""

    # _AnsibleCollectionLoader(self, fullname, path)
    # setup
    fullname = 'ansible_collections.mynamespace.mycollection.mysubmodule'
    path = '/usr/share/ansible/collections/mynamespace/mycollection/plugins/modules/mysubmodule'

    # test
    ac = _AnsibleCollectionLoader(fullname, path)

    # verify
    assert ac._package_to_load == 'ansible_collections.mynamespace.mycollection.mysubmodule'
    assert ac._split_name == ['ansible_collections', 'mynamespace', 'mycollection', 'mysubmodule']
    assert ac._fullname == 'ansible_collections.mynamespace.mycollection.mysubmodule'


# Generated at 2022-06-23 13:48:17.601734
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Init
    path_list=[]
    fullname = 'ansible_collections.foo'
    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo')

    # Test
    obj.is_package(fullname)

    # AssertionError: this loader cannot answer is_package for ansible_collections.bar, only ansible_collections.foo
    try:
        obj.is_package('ansible_collections.bar')
    except AssertionError:
        pass


# Generated at 2022-06-23 13:48:27.618997
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collec-tion')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace,collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collec-tion.subdir')
    assert not AnsibleCollectionRef.is_valid_collection_name('na/mespace.collec-tion')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.subdir')
    assert not Ansible

# Generated at 2022-06-23 13:48:37.902245
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # create a temporary directory to use as a fake collection
    with tempfile.TemporaryDirectory() as temp_dir:
        # create an instance of _AnsibleCollectionPkgLoaderBase
        # NOTE: the path list must be a list of native strings
        loader = _AnsibleCollectionPkgLoaderBase(
            os.path.join('ansible_collections', 'ns', 'test'), path_list=[temp_dir])
        # create a fake collection module
        pkg_path = os.path.join(temp_dir, 'ns', 'test')
        os.makedirs(pkg_path)
        with open(os.path.join(pkg_path, '__init__.py'), 'w') as pkg_init:
            pkg_init.write('__version__ = "1.0"')
        # load the module

# Generated at 2022-06-23 13:48:46.509147
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    plugin_dir_name = 'action_plugins'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir_name) == 'action'
    plugin_dir_name = 'library'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir_name) == 'modules'
    plugin_dir_name = 'my-action_plugins'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir_name) == 'my-action'
    plugin_dir_name = 'my-action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir_name) == 'my-action'
    plugin_dir_name = 'my_action'
    assert AnsibleCollectionRef

# Generated at 2022-06-23 13:48:51.410703
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # setup
    fullname = 'ansible.foo'
    path_list = ['ansible', 'ansible.foo']
    path_hook = _AnsibleInternalRedirectLoader(fullname, path_list)

    # test
    print(path_hook.__class__.__name__)

    # teardown: n/a


# Generated at 2022-06-23 13:48:53.189332
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert not _AnsibleCollectionPkgLoaderBase(path_list='path_list').__repr__()



# Generated at 2022-06-23 13:49:04.006175
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import ansible_collections.test.collection_loader_test
    test_source_path = os.path.abspath(ansible_collections.test.collection_loader_test.__file__)
    test_source_dir = os.path.dirname(test_source_path)
    test_module_dir, test_module_name = os.path.split(test_source_dir)
    test_collection_dir, test_collection_name = os.path.split(test_module_dir)
    test_collection_name = '.'.join(test_collection_name.split('.')[:2])

    loader = _AnsibleCollectionPkgLoaderBase(to_text(test_collection_name), [to_native(test_collection_dir)])

# Generated at 2022-06-23 13:49:09.733417
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    r = AnsibleCollectionRef('ansible.builtin', 'action', 'copy', 'action')
    assert r.fqcr == 'ansible.builtin.action.copy'
    assert r.collection == 'ansible.builtin'
    assert r.resource == 'copy'
    assert r.ref_type == 'action'
    assert r.subdirs == ''
    assert r.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.action.copy'


# Generated at 2022-06-23 13:49:21.097505
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # test all the different cases (collection, subdirs, resource)
    print(u'TEST CASE: AnsibleCollectionRef___repr__')
    test_dict = {
      'test_collection': {'test_subdir': 'test_resource'},
      'test_collection': {'': 'test_resource'},
      'test_collection': {None: 'test_resource'},
      'test_collection': {'test_subdir': ''},
      'test_collection': {'test_subdir': None},
    }

    for collection in test_dict:
        for subdirs, resource in test_dict[collection].items():
            ref_type = u'action'
            ref = AnsibleCollectionRef(collection, subdirs, resource, ref_type)

# Generated at 2022-06-23 13:49:28.367002
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Mock the class AnsibleCollectionConfig.  Note, this requires ansible.config.collection_loader.AnsibleCollectionConfig
    #   to be a class and not module function
    from ansible.config.collection_loader import AnsibleCollectionConfig
    import types
    original_on_collection_load = AnsibleCollectionConfig.on_collection_load
    AnsibleCollectionConfig.on_collection_load = types.MethodType(lambda self, collection_name, collection_path: collection_name, AnsibleCollectionConfig)

    # Mock the calls to _meta_yml_to_dict in _AnsibleCollectionPkgLoader.load_module
    from ansible.utils.collection_loader import _meta_yml_to_dict
    # Note, this requires _meta_yml_to_dict to be referenced in _AnsibleCollectionPkgLoader.load

# Generated at 2022-06-23 13:49:39.169166
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():

    # Test when fullname = 'ansible_collections'.
    # This test simulates finding module 'ansible_collections.ns.collection.module'.
    collection_finder = _AnsibleCollectionFinder()
    pathctx = '/foo/ansible_collections'
    fullname = 'ansible_collections.ns.collection.module'
    expected_result = _AnsibleCollectionLoader(fullname=fullname, path_list=[pathctx])
    actual_result = _AnsiblePathHookFinder(collection_finder, pathctx).find_module('ansible_collections.ns.collection.module')
    assert expected_result == actual_result

    # Test when fullname = 'ansible_collections' and path not specified.
    # This test simulates finding module 'ansible_collections.ns.collection.module'.

# Generated at 2022-06-23 13:49:51.245358
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    from .paths import _get_collection_importer
    from .utils import _ensure_unscoped_collection_name

    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo.bar.baz', None)

    # check that we only answer for ansible toplevel modules
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('collection.foo.baz', None)

    # check that we return ImportError if there's no redirection
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.foo.baz', None)

    # check that we return ImportError if there's no redirection

# Generated at 2022-06-23 13:49:59.549550
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr("user.role_name", "role")._fqcr == "user.role_name"
    assert AnsibleCollectionRef.from_fqcr("user.role_name.yml", "role")._fqcr == "user.role_name"
    assert AnsibleCollectionRef.from_fqcr("user.role_name.yaml", "role")._fqcr == "user.role_name"
    assert AnsibleCollectionRef.from_fqcr("user.role.role_name", "role")._fqcr == "user.role.role_name"
    assert AnsibleCollectionRef.from_fqcr("user.role.role_name.yml", "role")._fqcr == "user.role.role_name"

# Generated at 2022-06-23 13:50:06.253438
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    data_path = 'ansible/module_utils/basic.py'
    fullname = 'ansible.module_utils'
    paths = [os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')]
    cls = _AnsibleCollectionPkgLoaderBase(fullname, paths)
    data = cls.get_data(data_path)
    assert data is not None
    assert data[0:1] == b'#'

# Generated at 2022-06-23 13:50:10.336761
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert repr(AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'ref_type')) == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-23 13:50:14.672412
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.parsing.convert_bool', '')
    loader.load_module('ansible.module_utils.parsing.convert_bool')


# This loader only answers for intercepted Ansible Python modules that have been redirected by a namespace or collection

# Generated at 2022-06-23 13:50:18.618888
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert repr(AnsibleCollectionRef(u'ansible.builtin', u'', u'mymodule', u'module')) == "AnsibleCollectionRef(collection=u'ansible.builtin', subdirs=u'', resource=u'mymodule')"


# Generated at 2022-06-23 13:50:20.325477
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # TODO: write unit test
    assert False, "TODO: write unit test"

# Generated at 2022-06-23 13:50:25.436066
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test for valid fqcr
    ref = 'namespace.collectionname.lookupplugins.lookup1'
    ref_type = 'lookup'
    result = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    assert type(result) == AnsibleCollectionRef


# Generated at 2022-06-23 13:50:30.318038
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('', '', '', '')
    assert not loader._candidate_paths
    assert not loader._subpackage_search_paths
    assert not loader._source_code_path
    assert not loader._compiled_code


# Generated at 2022-06-23 13:50:40.326706
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('my_collection.my_namespace', 'my_collection.my_namespace.my_package')
    assert loader
    assert loader._split_name == ['my_collection', 'my_namespace', 'my_package']

test__AnsibleCollectionPkgLoader()


# Implements Ansible's module routing.
# This is a package loader with some extra rules on top: look in the associated collection namespace's meta
# and decide if the requested module is part of the collection's package. If it is, import it via the collection
# loader. If it isn't, look for a redirected module target. If we find one, remember it and return the loader
# associated with its target. When the module is actually loaded, it will be loaded by the target collection's
# loader. If the module isn't part of the collection or

# Generated at 2022-06-23 13:50:52.074714
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import tempfile
    import shutil
    import pkgutil

    def file_finder_hook(path):
        # return a file finder object corresponding to the path
        return next(iter(pkgutil.iter_importers(path)))

    with tempfile.TemporaryDirectory() as tmp_dir:
        test_path = tmp_dir
        try:
            test_coll_finder = _AnsibleCollectionFinder()
            test_coll_finder._ansible_collection_path_hook = file_finder_hook
            test_coll_finder._ansible_collection_path_hook(test_path)
        except ImportError as e:
            raise e
        finally:
            shutil.rmtree(tmp_dir)



# Generated at 2022-06-23 13:51:04.169549
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import sys
    import unittest

    def get_correct_result(sp):
        return True if sp is not None else False

    def get_packages_list(sp):
        if sp is not None:
            return [
                p for p in sp
                if os.path.isdir(os.path.join(to_bytes(p), to_bytes(self._package_to_load)))
            ]
        else:
            return []

    class Test_AnsibleCollectionPkgLoaderBase_class(unittest.TestCase):
        def setUp(self):
            self._fullname = 'ansible_collections.test.test_package'
            self._package_to_load = 'test_package'
            self._subpackage_search_paths = []

# Generated at 2022-06-23 13:51:12.126095
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class DummyAnsibleCollectionPkgLoaderBase(object):
        def load_module(self, fullname):
            return None
        def is_package(self, fullname):
            return False
        def get_source(self, fullname):
            return None
        def get_code(self, fullname):
            return None
        def iter_modules(self, prefix):
            return None
    d = DummyAnsibleCollectionPkgLoaderBase()
    d._subpackage_search_paths = ['path/to/dummy/package1', 'path/to/dummy/package2']
    # Test on a valid relative path and a valid absolute path
    assert d.get_data(path='/etc/hosts') == None
    assert d.get_data(path='hosts') == None
    # Test on a non

# Generated at 2022-06-23 13:51:19.227298
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # FUTURE: test the rest of this class
    ref = AnsibleCollectionRef.from_fqcr(u'testng.testing.subdir1.subdir2.subdir3.subdir4.subdir5.subdir6.subdir7.subdir8.subdir9.subdir10',
                                         u'doc_fragments')

    assert ref.collection == u'testng.testing'
    assert ref.subdirs == u'subdir1.subdir2.subdir3.subdir4.subdir5.subdir6.subdir7.subdir8.subdir9.subdir10'
    assert ref.resource == u'subdir10'
    assert ref.ref_type == u'doc_fragments'



# Generated at 2022-06-23 13:51:19.814217
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    pass



# Generated at 2022-06-23 13:51:24.838756
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar.baz')
    assert loader.get_source('ansible_collections.foo.bar.baz') == None
    assert loader.get_code('ansible_collections.foo.bar.baz') == None
    assert loader.get_filename('ansible_collections.foo.bar.baz') == None
    assert loader.iter_modules(prefix='ansible_collections.foo.bar.baz') == []
    assert loader.is_package('ansible_collections.foo.bar.baz') == False


# Generated at 2022-06-23 13:51:33.956959
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible.utils.collection_loader import _iter_modules_impl

    def test__iter_modules_impl(search_paths, prefix):
        with mock.patch('ansible_collections.ansible.builtin.plugins.module_utils.ansible_search_paths', return_value=search_paths):
            return list(_iter_modules_impl(sys.path, prefix))

    # python 2/3 compatible import from module
    from ansible.module_utils import basic

    # create a fake module in the python search path
    with tempfile.TemporaryDirectory() as tempdir_name:
        fake_module_file = os.path.join(tempdir_name, 'fake_module.py')

# Generated at 2022-06-23 13:51:43.631982
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_loader = _AnsibleCollectionPkgLoaderBase('foo.bar.baz')
    test_loader._subpackage_search_paths = ['/Users/test/test_data/test']
    data = test_loader.get_data('/Users/test/test_data/test/__main__.py')
    assert data
    assert type(data) is type(b'')

    data = test_loader.get_data('/Users/test/test_data/test/sub_dir/__init__.py')
    assert data
    assert type(data) is type(b'')

    data = test_loader.get_data('foo/bar')
    assert data is None


# Generated at 2022-06-23 13:51:48.103420
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    import random
    import string
    path = random.choice(string.ascii_letters)
    load = _AnsibleCollectionPkgLoaderBase(path)
    result = repr(load)
    assert result == '{0}(path={1})'.format(load.__class__.__name__, path)

test__AnsibleCollectionPkgLoaderBase___repr__()



# Generated at 2022-06-23 13:51:55.569543
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    collection_finder=_AnsibleCollectionFinder()
    playbook_paths='/path/to/playbook/dir'
    assert collection_finder._n_playbook_paths == []
    collection_finder.set_playbook_paths(playbook_paths)
    assert collection_finder._n_playbook_paths == ['/path/to/playbook/dir/collections']


# Generated at 2022-06-23 13:52:01.229056
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with tempfile.TemporaryDirectory() as tmp_dir:
        module_name = 'module'
        collection_name = 'namespace.collection'
        # Create collections and directories needed
        os.makedirs(os.path.join(tmp_dir, collection_name, 'plugins', 'modules', module_name))
        ansible_module = tmp_dir + os.sep + 'module.py'
        with open(ansible_module, 'w') as f:
            f.write('#!/usr/bin/python')
        module_path = tmp_dir + os.sep + 'ansible/modules'
        ansible_module_name = 'ansible.modules.module'
        # Redirect module 'module' to 'module_alt'
        collections_module_name = 'namespace.collection.plugins.modules.module'

# Generated at 2022-06-23 13:52:06.940293
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    class_AnsibleCollectionPkgLoader = _AnsibleCollectionPkgLoader("my_collection", "/some/path")
    assert class_AnsibleCollectionPkgLoader._package_to_load == 'my_collection'
    assert class_AnsibleCollectionPkgLoader._subpackage_search_paths == ["/some/path"]
    assert class_AnsibleCollectionPkgLoader._candidate_paths[0] == "/some/path/my_collection"
# /Unit test for constructor of class _AnsibleCollectionPkgLoader


# Generated at 2022-06-23 13:52:13.949200
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(namespace='test_collection_loader', package='test_package', module='test_module')
    assert loader._fullname == 'test_collection_loader.test_package.test_module'
    assert loader._package_to_load == 'test_package.test_module'
    assert loader._split_name == ['test_collection_loader', 'test_package', 'test_module']
    assert loader._parent_package_name == 'test_collection_loader.test_package'
    assert loader._candidate_paths == []

    assert loader.is_package('test_collection_loader.test_package.test_module')

    loader = _AnsibleCollectionPkgLoader(namespace='test_collection_loader', package='test_package')

# Generated at 2022-06-23 13:52:26.214877
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible.module_utils._text import to_native
    import unittest
    import os
    import tempfile

    class TestCase_get_data(unittest.TestCase):
        def setUp(self):
            self.test_dirs = []

            self.test_data=b'here is some test data'
            self.test_data_unicode=b'\xe2\x9c\xba'
            self.test_data_error=b'\xff'

            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            import shutil

            for td in self.test_dirs:
                shutil.rmtree(td, ignore_errors=True)
            shutil.rmtree(self.temp_dir, ignore_errors=True)

       

# Generated at 2022-06-23 13:52:30.216699
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    l = _AnsibleCollectionPkgLoaderBase(b'c1.m1')
    assert not l.is_package()
    l = _AnsibleCollectionPkgLoaderBase(b'c2.m2')
    assert l.is_package()


# Generated at 2022-06-23 13:52:36.928368
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('some_namespace.some_collection') == True
    assert AnsibleCollectionRef.is_valid_collection_name('some.namespace.some_collection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('some_namespace.some.collection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('some_namespace.some_collection_name.some_collection') == False
    assert AnsibleCollectionRef.is_valid_collection_name('some_namespace.some_collection_with_keyword_name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('some_namespace.some_invalid_name_@') == False

# Generated at 2022-06-23 13:52:47.387308
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    pkg_load = _AnsibleCollectionNSPkgLoader('ansible_collections.test', path_list=['/tmp/test'])
    assert pkg_load._candidate_paths == ['/tmp/test/test']
    assert pkg_load._subpackage_search_paths == ['/tmp/test/test']
    assert pkg_load._rpart_name == ('ansible_collections', '.', 'test')
    assert pkg_load._split_name == ['ansible_collections', 'test']
    assert pkg_load._parent_package_name == 'ansible_collections'
    assert pkg_load._package_to_load == 'test'
    assert pkg_load._fullname == 'ansible_collections.test'
    assert pkg_load._source_code_

# Generated at 2022-06-23 13:52:51.424807
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert repr(_AnsiblePathHookFinder(collection_finder=None, pathctx='/foo/bar')) \
    == "_AnsiblePathHookFinder(path='/foo/bar')"

# Generated at 2022-06-23 13:52:52.121405
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    assert True

# Generated at 2022-06-23 13:52:55.469781
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('a.b', 'b', 'c', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='a.b', subdirs='b', resource='c')"
    

# Generated at 2022-06-23 13:53:02.407400
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_types = [
        'action',
        'become',
        'cache',
        'callback',
        'cliconf',
        'connection',
        'doc_fragments',
        'filter',
        'httpapi',
        'inventory',
        'lookup',
        'module_utils',
        'modules',
        'netconf',
        'role',
        'shell',
        'strategy',
        'terminal',
        'test',
        'vars',
        'playbook',
    ]
    for ref_type in ref_types:
        assert not AnsibleCollectionRef.try_parse_fqcr('', ref_type)
        assert not AnsibleCollectionRef.try_parse_fqcr('[]', ref_type)
        assert not AnsibleCollectionRef.try_parse_

# Generated at 2022-06-23 13:53:10.183283
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('foo') 

    if not hasattr(loader, 'get_code'):
        raise Exception('Missing method get_code')
    code_object = loader.get_code('foo')
    if code_object != None:
        raise Exception('Method get_code must return None')

    loader = _AnsibleCollectionPkgLoaderBase('foo', ['/bar'])
    loader.get_filename = MagicMock(return_value='/bar')
    loader.get_source = MagicMock(return_value='baz')
    code_object = loader.get_code('foo')
    if code_object == None:
        raise Exception('Method get_code must return a code object')

# Generated at 2022-06-23 13:53:14.665573
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    finder = _AnsibleCollectionFinder()
    finder.set_playbook_paths(['test/_data/ansible_collections', 'test/_data/ansible_collections_2'])
    assert finder._n_playbook_paths == ['test/_data/ansible_collections/collections', 'test/_data/ansible_collections_2/collections']



# Generated at 2022-06-23 13:53:26.548721
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # TODO: this should move to tests/unit/module_utils/collection_finder.py
    import tempfile
    path = tempfile.mkdtemp()

# Generated at 2022-06-23 13:53:33.923331
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import pytest
    with pytest.raises(Exception):
        _AnsiblePathHookFinder(None, None)
        _AnsiblePathHookFinder._get_filefinder_path_hook()
        _AnsiblePathHookFinder._filefinder_path_hook
        _AnsiblePathHookFinder._filefinder_path_hook
        _AnsiblePathHookFinder._pathctx
        _AnsiblePathHookFinder._collection_finder


_AnsibleCollectionConfig = AnsibleCollectionConfig  # pre-scoped to resolve circular import


# TODO: move to loader class

# Generated at 2022-06-23 13:53:40.415442
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import os
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    # Set up a mock environment
    class MockFsMkDir(object):
        def mkdir(self, path, mode=511):
            pass

        def makedirs(self, name, mode=511, exist_ok=False):
            pass

        def create_bom(self, path, bom_prefix='bom'):
            pass

        def bom_dir(self, path):
            pass

        def bom_dir_contents(self, path):
            pass

        def bom_dir_exists(self, path):
            pass

        def get_readme_content(self, content_path, collection_name):
            pass

