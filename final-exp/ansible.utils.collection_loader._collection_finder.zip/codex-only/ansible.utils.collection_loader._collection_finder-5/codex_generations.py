

# Generated at 2022-06-23 13:43:45.049430
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print("start test__AnsibleCollectionPkgLoaderBase_get_data")
    base_loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.myns.mycol", ["/path/to/collection"])
    assert base_loader.get_data("/path/to/collection") == None
    assert base_loader.get_data("/path/to/collection/__init__.py") == ""
    assert base_loader.get_data("/path/to/collection/__init__.py") == ""
    assert base_loader.get_data("/path/to/collection/__init__.py") == ""
    assert base_loader.get_data("") == None
    assert base_loader.get_data("/path/to/mycol") == None

# Generated at 2022-06-23 13:43:47.568889
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # test for _AnsibleCollectionRootPkgLoader
    # create a instance of _AnsibleCollectionRootPkgLoader with fullname and path_list
    ansible_collection_root_loader = _AnsibleCollectionRootPkgLoader('ansible_collections', ['__test_path__'])
    # the instance is valid, so test it
    assert ansible_collection_root_loader._fullname == 'ansible_collections'
    assert ansible_collection_root_l

# Generated at 2022-06-23 13:43:52.745684
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(
        collection_name='test.test1',
        subdirs='test.test1',
        resource='test.test1',
        ref_type='role',
    )
    assert repr(ref) == 'AnsibleCollectionRef(collection=\'test.test1\', subdirs=\'test.test1\', resource=\'test.test1\')'


# Generated at 2022-06-23 13:43:59.571236
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == u'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == u'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lib') == u'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('roles') == u'role'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == u'modules'

# Generated at 2022-06-23 13:44:01.876510
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    _AnsibleCollectionPkgLoaderBase("test")


# Generated at 2022-06-23 13:44:09.320616
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
    assert collection_finder._ansible_pkg_path
    assert collection_finder._n_configured_paths
    assert isinstance(collection_finder._n_configured_paths, list)
    assert collection_finder._n_cached_collection_paths
    assert collection_finder._n_cached_collection_qualified_paths
    assert collection_finder._n_playbook_paths
    assert collection_finder._n_configured_paths == collection_finder._n_collection_paths



# Generated at 2022-06-23 13:44:15.904564
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test what happens with a directory
    loader = _AnsibleCollectionPkgLoaderBase('foo.bar', '/tmp')
    assert loader.get_data('foo') is None

    # Test what happens with a file
    with temp_file('') as fd:
        loader = _AnsibleCollectionPkgLoaderBase('foo.bar', os.path.dirname(fd.name))
        assert loader.get_data(os.path.basename(fd.name)) == b''

    # Test what happens with data
    with temp_file('test') as fd:
        loader = _AnsibleCollectionPkgLoaderBase('foo.bar', os.path.dirname(fd.name))
        assert loader.get_data(os.path.basename(fd.name)) == b'test'



# Generated at 2022-06-23 13:44:24.855791
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import ast
    ast_node = ast.AST()
    ast.copy_location(ast_node, ast.parse('''
'''))
    a = _AnsibleCollectionPkgLoaderBase(ast_node)
    ast_node = ast.AST()
    ast.copy_location(ast_node, ast.parse('''
'''))
    a.get_filename(ast_node)
    ast_node = ast.AST()
    ast.copy_location(ast_node, ast.parse('''
'''))
    a.get_code(ast_node)
    ast_node = ast.AST()
    ast.copy_location(ast_node, ast.parse('''
'''))
    a.load_module(ast_node)
    ast_node = ast.AST()

# Generated at 2022-06-23 13:44:29.834802
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('foo.bar', None, 'mymod', 'module')
    assert repr(ref) == "AnsibleCollectionRef(collection='foo.bar', subdirs=None, resource='mymod')"



# Generated at 2022-06-23 13:44:40.655753
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import ansible_test.data.ansible_util.legacy_collection_loader._test_data as mock_test_data

    # 1) Using string as value for playbook_paths
    test_data = mock_test_data.data__AnsibleCollectionFinder_set_playbook_paths1
    collection_finder = _AnsibleCollectionFinder(paths=test_data['paths'])

    collection_paths_pre_set_playbook_paths = collection_finder._n_collection_paths
    actual_playbook_paths = collection_finder._n_playbook_paths
    assert actual_playbook_paths == test_data['expected_playbook_paths']

# Generated at 2022-06-23 13:44:46.671403
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():

    class _AnsibleCollectionPkgLoaderBaseSubclass(_AnsibleCollectionPkgLoaderBase):
        _subpackage_search_paths = ['a', 'b']
    
    fullname = 'foo'

    # Test when not fullname
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase(fullname).is_package(fullname='bar')


# Generated at 2022-06-23 13:44:54.176505
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():  # pylint: disable=invalid-name

    # Assert that the method set_playbook_paths in class _AnsibleCollectionFinder creates a list of
    # the unique directories that are passed to it.

    collection_finder = _AnsibleCollectionFinder()
    collection_finder.set_playbook_paths(['/path1', '/path1', '/path2', '/path2', '/path2'])
    assert collection_finder._n_playbook_paths == ['/path1/collections', '/path2/collections']

    collection_finder = _AnsibleCollectionFinder()
    collection_finder.set_playbook_paths(['/path1/collections', '/path1', '/path2/collections'])

# Generated at 2022-06-23 13:45:05.468011
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # _AnsibleCollectionPkgLoaderBase.__init__(): Subclass _AnsibleCollectionPkgLoaderBase and validate member variables
    class _AnsibleCollectionPkgLoaderBaseSubclass(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            assert self._fullname == 'ansible_collections.test_loader', 'fullname is invalid: ' + str(self._fullname)
            assert self._split_name == ['ansible_collections', 'test_loader'], 'split_name is invalid'
            assert self._rpart_name == ('ansible_collections', '.', 'test_loader'), 'rpart_name is invalid'
            assert self._parent_package_name == 'ansible_collections', 'parent_package_name is invalid'
            assert self._package_to_load

# Generated at 2022-06-23 13:45:16.062836
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Setup
    real_collection_finder = AnsibleCollectionConfig.collection_finder
    collection_finder = _AnsibleCollectionFinder(paths=['/path/to/fixture/ansible_collections/are/here'])
    AnsibleCollectionConfig.collection_finder = collection_finder

    try:
        # Exercise
        path_hook_finder = _AnsiblePathHookFinder(collection_finder, '/path/to/fixture/ansible_collections/are/here')
        result = path_hook_finder.find_module('ansible_collections.another.collection')

        # Verify
        assert type(result) is _AnsibleCollectionLoader
    finally:
        # Teardown
        AnsibleCollectionConfig.collection_finder = real_collection_finder


# Implements a path_hook finder for

# Generated at 2022-06-23 13:45:25.904009
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    testmodname = 'test__AnsibleInternalRedirectLoader'
    testpkgname = 'ansible.test__AnsibleInternalRedirectLoader'

# Generated at 2022-06-23 13:45:38.003618
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name("foo.bar")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo.bar.still_bar")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo_bar")

    if sys.version_info[:2] == (3, 5):
        assert not AnsibleCollectionRef.is_valid_collection_name("foo.False")
        assert not AnsibleCollectionRef.is_valid_collection_name("False.foo")
        assert AnsibleCollectionRef.is_valid_collection_name("foo.myFalse")
        assert AnsibleCollectionRef.is_valid_collection_name("myFalse.foo")
    elif sys.version_info[:2] >= (3, 6):
        assert AnsibleCollectionRef.is_valid_collection

# Generated at 2022-06-23 13:45:39.360156
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    _AnsibleCollectionFinder()



# Generated at 2022-06-23 13:45:41.620506
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    x = AnsibleCollectionRef(
        'my.collection',
        'roles',
        'my_role',
        'role',
    )
    repr_x = repr(x)
    repr_x_expected = "AnsibleCollectionRef(collection='my.collection', subdirs='roles', resource='my_role')"
    assert repr_x == repr_x_expected


# Generated at 2022-06-23 13:45:48.295709
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    obj = _AnsiblePathHookFinder(None, None)
    assert obj._filefinder_path_hook is filefinder_path_hook
    assert obj._collection_finder is None
    assert obj._pathctx is None
    assert obj._file_finder is None


# Generated at 2022-06-23 13:45:59.315743
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.utils.import_plugins import _get_collection_metadata

    loader = _AnsibleInternalRedirectLoader('ansible.plugins.module_utils.module_utils', [])
    mod = loader.load_module('ansible.plugins.module_utils')
    assert mod.__name__ == 'ansible.builtin.module_utils'

    loader = _AnsibleInternalRedirectLoader('ansible.plugins.filter.ipaddr', [])
    mod = loader.load_module('ansible.builtin.ipaddr')
    assert mod.__name__ == 'ansible.builtin.ipaddr'

    loader = _AnsibleInternalRedirectLoader('ansible.plugins.filter.ipaddr', [])
    mod = loader.load

# Generated at 2022-06-23 13:46:03.580834
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    path_list = ['/foo/baz', '/bar/baz']
    fullname = 'ansible_collections.baz'
    class Test(object):
        _subpackage_search_paths = path_list
        _fullname = fullname
    t = Test()
    t.is_package(fullname)



# Generated at 2022-06-23 13:46:14.786804
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.sub')
    loader._subpackage_search_paths = ['/run/ansible_collections/ns/sub', '/run/ansible_collections/ns/sub2']
    loader._source_code_path = '/run/ansible_collections/ns/sub/__init__.py'
    assert loader.get_source('ansible_collections.ns.sub') == b'# test'
    
    
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.sub')
    loader._subpackage_search_paths = ['/run/ansible_collections/ns/sub', '/run/ansible_collections/ns/sub2']

# Generated at 2022-06-23 13:46:24.911126
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    def test__AnsibleCollectionPkgLoaderBase___init__(self):
        pass

    def test__AnsibleCollectionPkgLoaderBase__load_module(self, fullname):
        pass

    def test__AnsibleCollectionPkgLoaderBase__module_file_from_path(self, leaf_name, path):
        pass

    def test__AnsibleCollectionPkgLoaderBase__validate_final(self):
        pass

    def test__AnsibleCollectionPkgLoaderBase__validate_args(self):
        pass

    def test__AnsibleCollectionPkgLoaderBase__get_subpackage_search_paths(self, candidate_paths):
        pass

    def test__AnsibleCollectionPkgLoaderBase__get_candidate_paths(self, path_list):
        pass


# Generated at 2022-06-23 13:46:32.482331
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    import ansible.module_utils.ansible_release as ansible_release

    if ansible_release.__version_info__ == (2, 9, 0):
        # iskeyword() checks to see if a keyword exists. It doesn't check if it's a reserved word.
        # ispything is defined in ansible/module_utils/six/moves/builtins.py
        iskeyword = lambda x: x in ispything.kwlist
    else:
        iskeyword = lambda x: x in kwlist


# Generated at 2022-06-23 13:46:38.274033
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader("foo.bar", [])
    obj = _AnsibleInternalRedirectLoader("ansible.module_utils.facts", [])
    assert obj._redirect is None
    with pytest.raises(ValueError):
        obj.load_module("ansible.module_utils.facts")


# Generated at 2022-06-23 13:46:47.316917
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    acr = AnsibleCollectionRef('test.test', None, 'test', 'test')
    assert acr.__repr__() == "AnsibleCollectionRef(collection='test.test', subdirs=None, resource='test')"

    acr = AnsibleCollectionRef('test.test', 'test.test', 'test', 'test')
    assert acr.__repr__() == "AnsibleCollectionRef(collection='test.test', subdirs='test.test', resource='test')"

    acr = AnsibleCollectionRef('test.test', 'test', 'test', 'test')
    assert acr.__repr__() == "AnsibleCollectionRef(collection='test.test', subdirs='test', resource='test')"



# Generated at 2022-06-23 13:46:57.450409
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    sys.modules = {}
    file_content = """a = 1
b = 2
"""
    temp_dir = tempfile.mkdtemp()
    tmpfile = os.path.join(temp_dir, 'test.py')
    with open(os.path.join(tmpfile), 'w') as f:
        f.write(file_content)
    fullname = 'ansible.collections.namespace.test'
    kwargs = {
        'fullname': fullname,
        'path_list': [temp_dir]
    }
    loader = _AnsibleCollectionPkgLoaderBase(**kwargs)
    module = loader.load_module(fullname)
    assert type(module) == types.ModuleType
    assert module.__name__ == 'ansible.collections.namespace.test'
   

# Generated at 2022-06-23 13:47:09.537185
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    #
    # This test function is not executed by Ansible. It is made to test
    # the constructor of the class _AnsibleCollectionFinder
    #
    # There are two cases of use

    #
    # Case 1: Only the first parameter, paths
    #
    sys._getframe()
    case_1_paths = ['/my_collection/']
    sys._getframe()
    # Creation of the _AnsibleCollectionFinder instance
    case_1_instance = _AnsibleCollectionFinder(paths=case_1_paths)

    # Asserts the private attributes
    assert case_1_instance._ansible_pkg_path == os.path.dirname(sys.modules['ansible'].__file__)
    assert case_1_instance._n_configured_paths == case_1

# Generated at 2022-06-23 13:47:21.666976
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    print(">>> test__AnsiblePathHookFinder___repr__")
    _ansible_collection_finder = _AnsibleCollectionFinder(scan_sys_paths=False)
    _ansible_collection_finder.set_playbook_paths([])
    _ansible_collection_finder._install()
    _AnsiblePathHookFinder(_ansible_collection_finder, "ansible_module")
    print("<<< test__AnsiblePathHookFinder___repr__")
test__AnsiblePathHookFinder___repr__()


# Base class for collection finders; this should be inherited by any finders that need to assert that they aren't
# being used under the wrong context.

# Generated at 2022-06-23 13:47:27.111906
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase.__repr__(None) == '_AnsibleCollectionPkgLoaderBase(path=None)'
    assert _AnsibleCollectionPkgLoaderBase.__repr__('_AnsibleCollectionPkgLoaderBase()') == '_AnsibleCollectionPkgLoaderBase(path=None)'
    assert _AnsibleCollectionPkgLoaderBase.__repr__('_AnsibleCollectionPkgLoaderBase(path=None)') == '_AnsibleCollectionPkgLoaderBase(path=None)'



# Generated at 2022-06-23 13:47:29.723547
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    assert _AnsibleCollectionPkgLoaderBase(__name__, None)


# for internal use only; don't return submodule names

# Generated at 2022-06-23 13:47:36.873479
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    with mock.patch('__builtin__.open', mock.mock_open(read_data='package_code')):
        p = _AnsibleCollectionPkgLoaderBase('parent_package.package', path_list=['path/to/package'])
    with patch('ansible_collections.ansible.plugins.module_utils.facts.ansible_collections.ansible.ansible_facts.facts.my_shared_library.my_shared_module', Mock(name='my_shared_module')):
        result = p.get_source('parent_package.package')
    assert result == 'package_code'


# Generated at 2022-06-23 13:47:47.894705
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    class custom_loader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            # filter candidate paths for existence (NB: silently ignoring package init code and same-named modules)
            return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]
        def _validate_final(self):
            pass

    import ansible_collections.somens
    loader = custom_loader(ansible_collections.somens.__name__, path_list=[ansible_collections.somens.__path__[0]])
    # Check the return value

# Generated at 2022-06-23 13:47:59.859904
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    with tempfile.TemporaryDirectory() as tmpd:
        path = os.path.join(tmpd, 'test1')
        os.mkdir(path)
        with open(os.path.join(path, '__init__.py'), 'w') as f:
            f.write('# package init')
        with open(os.path.join(path, 'module1.py'), 'w') as f:
            f.write('# module1')
        pkgloader = _AnsibleCollectionPkgLoaderBase('some_collection.some_ns.some_pkg', path_list=[path])
        modules = pkgloader.iter_modules(prefix='some_collection')
        expected = ['some_ns.some_pkg.module1']
        assert list(modules) == expected



# Generated at 2022-06-23 13:48:06.836339
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class Mock__AnsibleCollectionPkgLoaderBase(object):
        # Mocking the base class _AnsibleCollectionPkgLoaderBase
        # to validate the the method get_source
        def __init__(self, fullname, path_list=None):
            self._split_name = 'ansible_collections.ns1.coll1'.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]
            self._package_to_load = self._rpart_name[2]
            self._subpackage_search_paths = \
                [os.path.join(p, self._package_to_load) for p in path_list]

# Generated at 2022-06-23 13:48:17.792109
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.testns')
    assert isinstance(loader, _AnsibleCollectionNSPkgLoader)
    assert loader._fullname == 'ansible_collections.testns'
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'testns'

# Implements loading of a collection package. Note that at this point, namespacing for Python modules only applies
# to ns modules, not to collection packages. Collection packages have a single root path and do not support
# aggregation.

# Generated at 2022-06-23 13:48:27.679433
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    with pytest.raises(ValueError):
        # missing collection name
        AnsibleCollectionRef(None, None, 'resource', 'type')

    with pytest.raises(ValueError):
        # missing collection name
        AnsibleCollectionRef('', None, 'resource', 'type')

    with pytest.raises(ValueError):
        # missing subdirectories
        AnsibleCollectionRef('ns.foo', None, 'resource', 'type')

    with pytest.raises(ValueError):
        # missing subdirectories
        AnsibleCollectionRef('ns.foo', '', 'resource', 'type')

    with pytest.raises(ValueError):
        # missing resource name
        AnsibleCollectionRef('ns.foo', 'subdirs', None, 'type')


# Generated at 2022-06-23 13:48:37.677034
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef.is_valid_collection_name("namespace.collectionname")
    assert not AnsibleCollectionRef.is_valid_collection_name("nonamespace.nocollection")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.collectionname.bar")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.collectionname.bar.foo")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace..collectionname")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.collection.name")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.foo.name")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.collectionname.1")
    assert Ansible

# Generated at 2022-06-23 13:48:46.336532
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    def test_path_hook(path):
        path = to_native(path)
        if path.startswith(test_root_path):
            tph = _AnsiblePathHookFinder(None, path)
            return tph
        else:
            raise ImportError('path should start with {0}'.format(test_root_path))

    test_root_path = 'foo/bar'
    sys.path_hooks.insert(0, test_path_hook)
    sys.path_importer_cache.clear()
    sys.modules.clear()


# Generated at 2022-06-23 13:48:56.549311
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    with pytest.raises(ValueError, match=("Invalid collection name")):
        AnsibleCollectionRef("ns.coll", None, "res", "type")

    with pytest.raises(ValueError, match=("Subdirs entry includes invalid characters")):
        AnsibleCollectionRef("ansible.col", "sub1.sub!", "res", "type")

    with pytest.raises(ValueError, match=("Invalid collection ref_type")):
        AnsibleCollectionRef("ansible.col", None, "res", "type!")

    with pytest.raises(ValueError, match=("Reference is not a valid collection reference")):
        AnsibleCollectionRef.try_parse_fqcr("ns.", "type")


# Generated at 2022-06-23 13:49:04.695963
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Mocking objects
    class sys:
        modules = {'ansible.module_utils.six': mock.MagicMock()}

    # Setting up mock
    sys.modules['ansible.module_utils.six'].__path__ = mock.MagicMock()
    sys.modules['ansible.module_utils.six'].__path__[0] = 'ansible_module_utils_six_path'
    sys.modules['ansible.module_utils.six'].__file__ = 'ansible_module_utils_six_file'

    # Mocking stat
    stat = os.stat
    os.stat = mock.MagicMock()
    os.stat.return_value = namedtuple("stat", ("st_mode",))(33204)
    os.path.isdir = mock.MagicMock()
   

# Generated at 2022-06-23 13:49:13.814499
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ansible_collection_ref_obj = AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'role')
    assert ansible_collection_ref_obj.collection == 'ns.coll'
    assert ansible_collection_ref_obj.subdirs == ''
    assert ansible_collection_ref_obj.ref_type == 'role'
    assert ansible_collection_ref_obj.resource == 'resource'
    assert ansible_collection_ref_obj.n_python_package_name == 'ansible_collections.ns.coll.roles.resource'
    assert ansible_collection_ref_obj.n_python_collection_package_name == 'ansible_collections.ns.coll'


# Generated at 2022-06-23 13:49:21.862598
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    name = 'ansible_collections.test_collection.subcollection.package'
    path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_collection', 'test_namespace')
    pkg = _AnsibleCollectionPkgLoaderBase(name, path_list=[path])
    # Test for error
    filename = pkg.get_filename(name)
    assert 'ansible_collections/test_collection/test_namespace' not in filename

# Generated at 2022-06-23 13:49:30.831169
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    """
    Unit test of class AnsibleCollectionRef
    """
    # Test our constructor
    ansible_ref = AnsibleCollectionRef(collection_name="namespace.collection_name", subdirs="subdir1.subdir2", resource="resource_name", ref_type="some_ref_type")
    assert ansible_ref.collection == "namespace.collection_name"
    assert ansible_ref.subdirs == "subdir1.subdir2"
    assert ansible_ref.resource == "resource_name"
    assert ansible_ref.ref_type == "some_ref_type"
    assert ansible_ref.fqcr == "namespace.collection_name.subdir1.subdir2.resource_name"

# Generated at 2022-06-23 13:49:32.073206
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader



# Generated at 2022-06-23 13:49:43.698916
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    with pytest.raises(TypeError):
        AnsibleCollectionRef(5, None, 'name', 'ref_type')
    with pytest.raises(TypeError):
        AnsibleCollectionRef('5', None, 'name', 'ref_type')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll.name', None, 'name', 'ref_type')
    with pytest.raises(TypeError):
        AnsibleCollectionRef('ns.coll', 5, 'name', 'ref_type')
    with pytest.raises(TypeError):
        AnsibleCollectionRef('ns.coll', '5', 'name', 'ref_type')
    with pytest.raises(TypeError):
        AnsibleCollectionRef('ns.coll', None, 5, 'ref_type')

# Generated at 2022-06-23 13:49:49.711780
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Pass a bare path; it should be used as the path list to be sent to the finder.
    def _test_simple_path(path):
        cf = _AnsibleCollectionFinder([path])
        achf = _AnsiblePathHookFinder(cf, path)
        assert achf.find_module('ansible_collections') is not None

    _test_simple_path('foo')
    _test_simple_path('foo/bar')

    # If a path component isn't a directory, it should not be used.
    def _test_broken_path(path):
        cf = _AnsibleCollectionFinder([path])
        achf = _AnsiblePathHookFinder(cf, path)
        # An attempt to load the root package will result in an ImportError because no path in the path

# Generated at 2022-06-23 13:49:58.799893
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader.from_list(['foo.bar.baz'], ['a', 'b', 'c'])
    assert loader._package_to_load == 'baz'
    assert loader._split_name == ['foo', 'bar', 'baz']

    loader = _AnsibleCollectionPkgLoader.from_list(['foo.bar'], ['a', 'b', 'c'])
    assert loader._package_to_load == 'bar'
    assert loader._split_name == ['foo', 'bar']

    loader = _AnsibleCollectionPkgLoader.from_list(['foo'], ['a', 'b', 'c'])
    assert loader._package_to_load == 'foo'
    assert loader._split_name == ['foo']

    loader = _AnsibleCollectionPkg

# Generated at 2022-06-23 13:50:02.411763
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    apf = _AnsiblePathHookFinder(None, 'some_pathctx')
    res = repr(apf).split("'")
    assert len(res) == 3
    assert res[0] == '_AnsiblePathHookFinder(path='
    assert res[1] == 'some_pathctx'
    assert res[2] == ')'

# Generated at 2022-06-23 13:50:07.293368
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    obj = _AnsiblePathHookFinder(object(), '/fake/path')
    expected = "{0}(path='/fake/path')".format(obj.__class__.__name__)
    got = obj.__repr__()

    assert got == expected

# Generated at 2022-06-23 13:50:18.574690
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-23 13:50:26.381218
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():

    import ansible.utils.collection_loader

    class _AnsibleInternalRedirectLoaderTest:
      # TODO: right now, this is an empty testcase stub.
      # Remove this if tests for this class are added as needed.
      pass

    _AnsibleInternalRedirectLoaderTest.test__AnsibleInternalRedirectLoader_load_module = lambda self: True
    test = _AnsibleInternalRedirectLoaderTest()
    test.test__AnsibleInternalRedirectLoader_load_module()


# represents a namespace package corresponding to a collection namespace (one level inside ansible_collections)
# matches sys.path_hooks when the requested import is of the right form, and must return an importer
# (generally a list of importers, but we don't currently have to worry about the multi-path case)

# Generated at 2022-06-23 13:50:37.931389
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_type = u'action'
    fqcr = 'ansible.builtin.apache'
    output_ref = AnsibleCollectionRef.try_parse_fqcr(fqcr, ref_type)
    assert output_ref.collection == 'ansible.builtin'
    assert output_ref.subdirs == ''
    assert output_ref.resource == 'apache'
    assert output_ref.ref_type == 'action'
    assert output_ref.fqcr == 'ansible.builtin.apache'
    assert output_ref.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    assert output_ref.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.action'


# Generated at 2022-06-23 13:50:41.409698
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    for i in {'a.b.c', 'a.b.c.d', 'a.b.c.d.e'}:
        print('testing: %s' % i)
        assert AnsibleCollectionRef.is_valid_fqcr(i)



# Generated at 2022-06-23 13:50:47.647104
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    hook_finder = _AnsiblePathHookFinder(None, '/mock/path')
    hook_finder._collection_finder = _AnsibleCollectionFinder()
    hook_finder._collection_finder.set_playbook_paths(['/mock/path/collections'])
    assert hook_finder.find_module('ansible_collections.to_be_mocked') is not None
    # ansible modules should be handled by FileFinder
    if PY3:
        assert hook_finder.find_module('ansible.plugins') is not None
    else:
        assert hook_finder.find_module('ansible.plugins') is None
    assert hook_finder.find_module('to_be_mocked') is None

# Generated at 2022-06-23 13:50:56.145744
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test normal case
    ansible_collection_ref, _ = testutils.create_test_ansible_collection_ref()
    assert repr(ansible_collection_ref) == 'AnsibleCollectionRef(collection=\'test.collection\', subdirs=\'\', resource=\'mymodule\')'
    # Test on case where the resource name is not a python identifier
    ansible_collection_ref = AnsibleCollectionRef(collection_name='test.collection', subdirs='', resource='my-module', ref_type='module')
    assert repr(ansible_collection_ref) == 'AnsibleCollectionRef(collection=\'test.collection\', subdirs=\'\', resource=\'my-module\')'


# Generated at 2022-06-23 13:51:06.458525
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    fqcr = 'ansible.builtin.ping'
    resource = 'ping'
    acr = AnsibleCollectionRef.from_fqcr(fqcr, 'module')

    assert acr.collection == 'ansible.builtin'
    assert acr.subdirs == ''
    assert acr.resource == resource
    assert acr.ref_type == 'module'
    assert acr.fqcr == fqcr
    assert acr.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    assert acr.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.module.ping'


# Generated at 2022-06-23 13:51:16.698892
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    from ansible.utils.plugin_docs import CollectionRefDocFragment
    ref = AnsibleCollectionRef.from_fqcr("ns.coll.resource", "doc_fragment")
    assert ref.n_python_collection_package_name == "ansible_collections.ns.coll"
    assert ref.n_python_package_name == "ansible_collections.ns.coll.plugins.doc_fragment"
    assert ref.collection == "ns.coll"
    assert ref._fqcr == "ns.coll.resource"
    assert ref.resource == "resource"
    assert ref.ref_type == "doc_fragment"
    assert ref.subdirs == ""

    # Test with a subdir

# Generated at 2022-06-23 13:51:23.414986
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    import sys

    def _get_mapping_for_version(version_str):
        _module = sys.modules.get('__main__', sys.modules['ansible'])
        _mapping = {'keywords': _module.__builtins__.__dict__['__keywords'], 'identifiers': _module.__builtins__.__dict__['__identifiers']}
        return _mapping

    # Prepare test data

# Generated at 2022-06-23 13:51:33.242898
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # directory layout:
    # fixtures/ansible_collections/invalid_collection1/collection.yml
    # fixtures/ansible_collections/ansible_somenamespace/invalid_collection2/collection.yml
    # fixtures/ansible_collections/ansible_somenamespace/invalid_collection3/collection.yml
    # fixtures/ansible_collections/ansible_somenamespace/invalid_collection4/collection.yml
    # fixtures/ansible_collections/ansible_somenamespace/somecollection/hello.py
    import tempfile
    import shutil
    import ansible_collections.ansible.somenamespace.somecollection.hello
    import sys
    import imp

    test_base_dir = tempfile.mkdtemp()

    # copy fixtures in temporary

# Generated at 2022-06-23 13:51:44.312420
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    def mock_import_module(mod):
        return mod.replace('.', '/')
    import_module_func = import_module
    import_module_func.side_effect = mock_import_module
    collection_loader = _AnsibleCollectionLoader('test.test_collection.test_collection_loader', ['.'])
    import_module_func.assert_called_with('test.test_collection')
    assert collection_loader._path_to_search is not None
    import_module_func.side_effect = import_module_func
    assert collection_loader._split_name == ['test', 'test_collection', 'test_collection_loader']
    assert collection_loader._fullname == 'test.test_collection.test_collection_loader'
    assert collection_loader._path_to_search == './test/test_collection'

# Generated at 2022-06-23 13:51:46.790577
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo')



# Generated at 2022-06-23 13:51:59.937879
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class _AnsibleCollectionPkgLoaderBase_get_code(unittest.TestCase):
        def test_simple(self):
            # No source on disk, get_code should return none
            loader = _AnsibleCollectionPkgLoaderBase("fake.name")
            res = loader.get_code("fake.name")
            self.assertEqual(res, None)

            # Sourc code exists on disk and is empty, get_code should return a code object
            loader.get_source = lambda name: ''
            loader.get_filename = lambda name: '<string>'
            res = loader.get_code("fake.name")
            self.assertIsInstance(res, types.CodeType)

            # Fail to compile source, raises exception
            loader.get_source = lambda name: 'a'

# Generated at 2022-06-23 13:52:04.688795
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    assert _AnsibleCollectionRootPkgLoader, '_AnsibleCollectionRootPkgLoader class is not defined'

    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('.oops')

    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('.ansible_collections.oops')

    _AnsibleCollectionRootPkgLoader('ansible_collections')



# Generated at 2022-06-23 13:52:06.696533
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    _AnsibleCollectionRootPkgLoader('ansible_collections', ['a', 'b', 'c'])



# Generated at 2022-06-23 13:52:13.760527
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test with valid values
    assert AnsibleCollectionRef.is_valid_fqcr(u"ns.coll.resource", u'module')
    assert AnsibleCollectionRef.is_valid_fqcr(u"ns.coll.subdir1.subdir2.resource", u'module')

    # Test with invalid values
    assert not AnsibleCollectionRef.is_valid_fqcr(u"ns.coll.resource", u'role')
    assert not AnsibleCollectionRef.is_valid_fqcr(u"ns.coll.resource.testing", u'module')
    assert not AnsibleCollectionRef.is_valid_fqcr(u"ns.coll.subdir1.subdir2.resource.", u'module')

# Generated at 2022-06-23 13:52:26.093038
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr("ns1.coll1.resource1") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns1.coll1.subdir1.resource1") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns1.coll1.rolename") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns1.coll1.rolename.yml") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns1.coll1.rolename.yaml") == True

    assert AnsibleCollectionRef.is_valid_fqcr("ns1.coll1.resource1") == True

# Generated at 2022-06-23 13:52:36.024283
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # passing invalid string
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible.foo_bar")
    assert not AnsibleCollectionRef.is_valid_collection_name("ans.foo")
    assert not AnsibleCollectionRef.is_valid_collection_name("ans.foo.bar")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible.")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible.foo.bar.baz")
    assert not AnsibleCollectionRef.is_valid_collection_name("ans.foo.bar")
    assert not AnsibleCollectionRef.is_valid_collection_name("ans.foo.bar.baz")

# Generated at 2022-06-23 13:52:40.125776
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    legacy_plugin_dir_name = 'action_plugins'
    plugin_type = 'action'
    assert plugin_type == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)


# Generated at 2022-06-23 13:52:46.676683
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Unit test for method get_source of AnsibleCollectionPkgLoaderBase
    loader = _AnsibleCollectionPkgLoaderBase('')
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '__init__.py')
    with open(path, 'r') as f:
        assert loader.get_source('') == f.read()

test__AnsibleCollectionPkgLoaderBase_get_source()


# Generated at 2022-06-23 13:52:57.451494
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import os
    import tempfile
    import shutil
    import pytest

    fd, tmp_dir = tempfile.mkstemp(prefix='ansible_collections.')
    os.close(fd)
    os.rmdir(tmp_dir)
    os.makedirs(tmp_dir)
    tmp_file_list = []

    def build_file_list():
        with open(os.path.join(tmp_dir, 'foo.py'), 'w') as fd:
            print("print('foo')", file=fd)
            tmp_file_list.append(fd.name)

        with open(os.path.join(tmp_dir, 'bar', '__init__.py'), 'w') as fd:
            print("print('bar.__init__')", file=fd)
            tmp

# Generated at 2022-06-23 13:53:02.233994
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    i = AnsibleCollectionRef.from_fqcr(ref="my_ns.my_coll.my_resource", ref_type="module")
    j = AnsibleCollectionRef(collection_name="my_ns.my_coll", subdirs="", resource="my_resource", ref_type="module")
    assert i == j


# Generated at 2022-06-23 13:53:05.876100
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    finder = _AnsiblePathHookFinder(collection_finder=None, pathctx="my_path")
    if finder.find_module("my_module") is not None or finder.find_module("my_module", None) is not None:
        assert False

# Generated at 2022-06-23 13:53:11.873807
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection = AnsibleCollectionRef('ansible_namespace.collection_name', 'subdirs', 'resource', 'action')
    assert collection.__repr__() == "AnsibleCollectionRef(collection='ansible_namespace.collection_name', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-23 13:53:15.636333
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    test_path_ctx = 'test path'
    test_collection_finder = 'test finder'
    instance = _AnsiblePathHookFinder(test_collection_finder, test_path_ctx)
    repr_ = repr(instance)
    expected = '_AnsiblePathHookFinder(path=\'test path\')'
    assert repr_ == expected

# Generated at 2022-06-23 13:53:27.464042
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # This will cache the ansible_collection finder instance, so this is not a valid test if the AnsibleCollectionFinder instance
    # has already been created
    assert AnsibleCollectionConfig.collection_finder is None

    # This will test the constructor of the class _AnsiblePathHookFinder
    assert AnsibleCollectionFinder._AnsiblePathHookFinder.__name__ == '_AnsiblePathHookFinder'
    assert AnsibleCollectionFinder._AnsiblePathHookFinder.__doc__ == None
    assert AnsibleCollectionFinder._AnsiblePathHookFinder.__module__ == 'ansible.module_utils.collection_loader._collection_finder'

    # Instance the class and verify it's initialized properly
    finder = AnsibleCollectionFinder()
    finder_hook = AnsibleCollectionFinder

# Generated at 2022-06-23 13:53:35.664462
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Use cases
    # Empty context
    assert repr(AnsibleCollectionRef(None, None, None, None)) == 'AnsibleCollectionRef(collection=None, subdirs=None, resource=None)'
    # Bad parameters
    try:
        assert repr(AnsibleCollectionRef(None, None, None, 'module'))
    except ValueError:
        pass

    # Good parameters
    assert repr(AnsibleCollectionRef('dummy.collection', 'subdir.subdir2', 'resource', 'module')) == 'AnsibleCollectionRef(collection=' +\
        '\'dummy.collection\', subdirs=\'subdir.subdir2\', resource=\'resource\')'
    return True
