

# Generated at 2022-06-23 13:43:38.933336
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    obj = _AnsiblePathHookFinder(collection_finder=None, pathctx='pathctx')
    assert obj.__repr__() == "_AnsiblePathHookFinder(path='pathctx')"


# Implements a path-based importer that redirects all imports to a fixed target.
# Used to redirect "import ansible.module_utils.some_module" to
# "from ansible_collections.ansible.module_utils import some_module"

# Generated at 2022-06-23 13:43:41.630958
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # TODO: this test needs to be refactored, so that the finder can be mocked
    # and the test can be run in isolation.
    # See https://github.com/ansible/ansible/issues/67190
    return True


# TODO: plugin loader redirections?

# Generated at 2022-06-23 13:43:49.965503
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _meta_yml_to_dict
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible_collections.tmo.push_stats.plugins.modules import push_stats
    from ansible_collections.tmo.push_stats.plugins.module_utils import push_stats_common

    _meta_yml_to_dict = push_stats_common._meta_yml_to_dict
    cl = _AnsibleCollectionPkgLoader('ansible_collections.tmo.push_stats', ['.'], push_stats)

# Generated at 2022-06-23 13:44:00.491938
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import io
    import io, io

    class Test_AnsibleCollectionPkgLoaderBase(
        _AnsibleCollectionPkgLoaderBase
    ):
        def __init__(self, fullname, **kwargs):
            self.fullname = fullname
            self.source_code_path = None
            if fullname == "ansible_collections.ns1.ns2.mod_a.mod_b":
                kwargs["subpackage_search_paths"] = ["/var/tmp/mod_b"]
                self.source_code_path = "/var/tmp/mod_b/__init__.py"

# Generated at 2022-06-23 13:44:07.398362
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assertRaises(ImportError, _AnsibleInternalRedirectLoader, 'fake.module.not_interesting', '/path/to/fake/modules')
    assertRaises(ImportError, _AnsibleInternalRedirectLoader, 'ansible.fake.module.not_interesting', '/path/to/fake/modules')

    # TODO: test against real ansible/builtin modules


# Check if any of the configured collection roots have the given collection namespace path. This is used by
# _AnsibleCollectionRootPkgLoader to determine if a given collections namespace package should be loadable.

# Generated at 2022-06-23 13:44:20.405607
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # ref_type = 'module'
    ref = AnsibleCollectionRef('namespace.collectionname', None, 'someresource', 'module')
    assert ref.collection == 'namespace.collectionname'
    assert ref.subdirs == u''
    assert ref.resource == 'someresource'
    assert ref.ref_type == 'module'
    assert ref.fqcr == 'namespace.collectionname.someresource'
    assert ref.n_python_package_name == 'ansible_collections.namespace.collectionname.plugins.module'

    # ref_type = 'role'
    ref = AnsibleCollectionRef('namespace.collectionname', None, 'someresource', 'role')
    assert ref.collection == 'namespace.collectionname'
    assert ref.subdirs == u''

# Generated at 2022-06-23 13:44:26.733128
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    """Unit test for constructor of class _AnsibleCollectionLoader"""
    #
    # Test for successful instantiation of _AnsibleCollectionLoader.
    #
    test_loader = _AnsibleCollectionLoader('loader', [os.path.join(os.path.sep, 'path', 'to', 'module')])
    assert isinstance(test_loader, _AnsibleCollectionLoader)

# Unit test method _get_candidate_paths() of class _AnsibleCollectionLoader.

# Generated at 2022-06-23 13:44:37.173599
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print('START TEST test__AnsibleCollectionPkgLoaderBase_get_data')
    # Create test data to use with function

# Generated at 2022-06-23 13:44:44.217855
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # AnsibleCollectionPkgLoaderBase = _AnsibleCollectionPkgLoaderBase
    # fullname = TEST_CASE.get_value_with_type(python_lib.Str)
    # path_list = TEST_CASE.get_value_with_type(python_lib.List)
    #
    # obj = AnsibleCollectionPkgLoaderBase()
    # TEST_CASE.assertEqual(obj.__repr__(), TEST_CASE.get_return_value())
    pass


# class method to save object related state in object_config.json file

# Generated at 2022-06-23 13:44:52.684278
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible_collections.test.dummy.plugins.module_utils import test_data_utils
    import sys

    # Mock a file for testing.
    with test_data_utils.mock_module_file(module_name='ansible_collections.test.dummy.plugins.module_utils.test_module') as mock_module_file:
        # Create a new module to test with.
        module = ModuleType('ansible_collections.test.dummy.plugins.module_utils.test_module')
        # The module must be referenced in the sys modules so that python can use it.
        sys.modules['ansible_collections.test.dummy.plugins.module_utils.test_module'] = module
        # Create a new test loader.

# Generated at 2022-06-23 13:44:54.380835
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    m = 'ansible_collections.ansible.powerhshell.plugins.modules'
    loader = _AnsibleCollectionPkgLoaderBase(m)
    assert loader.is_package(m)


# Generated at 2022-06-23 13:45:05.702061
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    from tests import test_loader as test_loader
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    import tempfile
    import shutil

    collection = 'testcollection'
    namespace = 'testns'
    role = 'testrole'
    plugin = 'testplugin'
    plugin_type = 'testplugintype'
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create Collection structure
    ns_dir = os.path.join(temp_dir, namespace)
    coll_dir = os.path.join(ns_dir, collection)
    coll_dir_tree = [
        os.path.join(coll_dir, 'plugins'),
        os.path.join(coll_dir, 'roles')
    ]

# Generated at 2022-06-23 13:45:16.115342
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # unit test for plugin routing canonicalization
    loader = _AnsibleCollectionPkgLoaderBase('ansible.collections.ns.collection',
                                             ['fake_path', 'fake_path/collection'])
    loader._package_to_load = loader._fullname
    loader._source_code_path = os.path.join('fake_path/collection', '__synthetic__')
    loader._subpackage_search_paths = ['fake_path/collection']

    module = loader.load_module(loader._fullname)
    module_meta = module._collection_meta
    # no meta
    assert module_meta == {}

    # meta/runtime.yml does not exists

# Generated at 2022-06-23 13:45:24.730258
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    code = "print(hello)"
    loader = _AnsibleCollectionPkgLoaderBase("ansible.collection.test", path_list=["/path/to/package"])
    loader._source_code_path = "/path/to/package/test_package.py"
    loader._compiled_code = compile(source=code, filename=loader._source_code_path, mode='exec', flags=0, dont_inherit=True)

    assert loader.get_code("ansible.collection.test") == compile(source=code, filename=loader._source_code_path, mode='exec', flags=0, dont_inherit=True)

# Generated at 2022-06-23 13:45:35.080982
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from collections import namedtuple
    ModuleSpec = namedtuple('ModuleSpec', ('name', 'loader'))
    FakeLoader = namedtuple('FakeLoader', ('path'))
    faker = FakeLoader(path='/path/to/collection')
    spec = ModuleSpec('ansible_collections.ns.module_that_does_not_exist', faker)
    loader = _AnsibleCollectionPkgLoaderBase(spec.name)
    assert repr(loader) == '{0}(path=/path/to/collection/module_that_does_not_exist)'.format(loader.__class__.__name__)

# Generated at 2022-06-23 13:45:38.725234
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.testns')
    assert loader._package_to_load == 'testns'
    assert loader._parent_package_name == 'ansible_collections'

# A collection package is a special-cased namespace package that
# has a specific search path rather than aggregating over every configured collection root.
# This loader will redirect an import request
# to the collection root where the package lives. All submodules/packages under the collection
# are loaded from that one namespace. The root namespace is a _AnsibleCollectionRootPkgLoader,
# which will dispatch to _AnsibleCollectionPkgLoader or _AnsibleCollectionModuleLoader as
# appropriate.

# Generated at 2022-06-23 13:45:51.831589
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import time
    import os
    import os.path
    import sys
    import shutil
    import tempfile
    import pytest
    import subprocess
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six.moves import shlex_quote

    import_module('ansible_collections.somens.somecoll.plugins.module_utils.somesubmodule')

    # import_module('somens.somecoll.plugins.module_utils.somesubmodule')
    # import_module('ansible_collections.ansible')
    # import_module('ansible_collections.somens_missing.somecoll.plugins.module_utils.somesubmodule')
    # import_

# Generated at 2022-06-23 13:46:03.610136
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _TestableAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        # Avoid having to mock filesystem calls when testing methods that are otherwise not mocking
        def __init__(self, fullname, path_list=None, module_file_name=None, package_file_name=None):
            self._mock_module_file_name = module_file_name
            self._mock_package_file_name = package_file_name
            _AnsibleCollectionPkgLoaderBase.__init__(self, fullname, path_list)


# Generated at 2022-06-23 13:46:14.819848
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    def assert_fqcr_results(ref, ref_type, expected_result):
        """
        Utility method to assert and provide context on failure
        """
        result = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)

        assert result is expected_result, \
            'Expected AnsibleCollectionRef.try_parse_fqcr({0!r}, {1!r}) to return {2!r}, got {3!r}'.format(
                ref, ref_type, expected_result, result)


# Generated at 2022-06-23 13:46:17.683353
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert True == AnsibleCollectionRef.is_valid_collection_name("ansible.my_collection")
    assert True == AnsibleCollectionRef.is_valid_collection_name("ansible.mycollection")
    assert False == AnsibleCollectionRef.is_valid_collection_name("ansible.my_collection.sub1")


# Generated at 2022-06-23 13:46:21.138427
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    l = _AnsibleCollectionPkgLoaderBase('a.b.c', ['d', 'e'])
    assert l.is_package('a.b.c') == True
    assert l.is_package('a') == False


# Generated at 2022-06-23 13:46:22.774479
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    """Test method find_module of class _AnsiblePathHookFinder"""
    pass



# Generated at 2022-06-23 13:46:30.803998
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    fullname = 'ansible.module_utils.helpers'
    import ansible.module_utils.helpers
    assert ansible.module_utils.helpers
    # instance of _AnsibleInternalRedirectLoader
    loader = _AnsibleInternalRedirectLoader(fullname, [])
    key = 'ansible.module_utils.helpers'
    assert key in sys.modules
    assert sys.modules[key]
    # sys.modules[key] is a instance of ansible.module_utils.helpers
    # assert sys.modules[key].__name__ == 'ansible.module_utils.helpers'
    module = loader.load_module(fullname)
    assert module
    # instance of ansible.module_utils.helpers

# Generated at 2022-06-23 13:46:36.009934
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    my_collection_finder = _AnsibleCollectionFinder(paths=[])
    pathctx = '/tmp/ansible_collections/ns/coll/module_utils'
    assert _AnsiblePathHookFinder(my_collection_finder, pathctx)._pathctx == pathctx


# Generated at 2022-06-23 13:46:46.284257
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # LEGACY MODULE
    ref = AnsibleCollectionRef.try_parse_fqcr(u"ansible.builtin.template",
                                              u"module")
    assert ref == AnsibleCollectionRef(u"ansible.builtin", u"", u"template",
                                       u"module")

    # LEGACY MODULE
    ref = AnsibleCollectionRef.try_parse_fqcr(u"template",
                                              u"module")
    assert ref == None

    # LEGACY MODULE
    ref = AnsibleCollectionRef.try_parse_fqcr(u"ansible.builtin.template",
                                              u"module")
    assert ref == AnsibleCollectionRef(u"ansible.builtin", u"", u"template",
                                       u"module")

    # LEGACY MODULE
    ref = AnsibleCollection

# Generated at 2022-06-23 13:46:53.262503
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # we want to make sure the module is imported first
    __import__('ansible.builtin')

    # now, let's test the code
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.builtin.ping', None)
    assert redirect_loader is not None

    # this doesn't actually load the module, just set it up for it
    redirect_loader.load_module('ansible.builtin.ping')



# Generated at 2022-06-23 13:46:58.270179
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    c = AnsibleCollectionRef('my.collection', 'a.b.c', 'my_thing', 'action')
    assert c.collection_name == 'my.collection'
    assert c.ref_type == 'action'
    assert c.python_package_name == 'ansible_collections.my.collection.plugins.a.b.c.action'


# Generated at 2022-06-23 13:47:09.602679
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    def _test_case(test_name, loader, path, expected):
        try:
            result = loader.get_data(path)
        except Exception as ex:
            result = repr(ex)
        if result != expected:
            raise AssertionError('{0} failed for path {1} with loader {2}: expected {3}, actual {4}'.
                                 format(test_name, path, loader, expected, result))

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=['/bar/'])
    loader._subpackage_search_paths = ['/bar/baz']
    _test_case('nonexistent path', loader, '/bar/nonexistent', None)
    _test_case('file outside of search path', loader, '/file.txt', None)

# Generated at 2022-06-23 13:47:18.627116
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # test construction of _AnsibleCollectionPkgLoaderBase
    _AnsibleCollectionPkgLoaderBase(module_name='module_name',
                                    path_list='path_list',
                                    package_to_load='package_to_load'
                                    )

    # test construction of _AnsibleCollectionRootPkgLoader
    _AnsibleCollectionRootPkgLoader(
        module_name='ansible_collections',
        path_list='path_list',
        package_to_load='ansible_collections'
    )

    # test construction of _AnsibleCollectionNSPkgLoader
    # the upper level collection_name is not considered in argument module_name

# Generated at 2022-06-23 13:47:30.256348
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = AnsibleCollectionRef('ns.coll', 'subdir1', 'resname', 'module')

    assert ref.is_valid_fqcr('ns.coll.resname', 'module') is True
    assert ref.is_valid_fqcr('ns.coll.subdir1.resname', 'module') is True

    assert ref.is_valid_fqcr('ns.coll.resname', 'role') is False
    assert ref.is_valid_fqcr('ns.coll.subdir1.resname', 'role') is False

    assert ref.is_valid_fqcr('ns.coll.resname') is True
    assert ref.is_valid_fqcr('ns.coll.subdir1.resname') is True


# Generated at 2022-06-23 13:47:43.877870
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref1 = AnsibleCollectionRef.from_fqcr('awx.awx.user', 'lookup')
    assert ref1.fqcr == 'awx.awx.user'
    assert ref1.collection == 'awx.awx'
    assert ref1.subdirs == ''
    assert ref1.resource == 'user'
    assert ref1.ref_type == 'lookup'
    assert ref1.n_python_collection_package_name == 'ansible_collections.awx.awx'
    assert ref1.n_python_package_name == 'ansible_collections.awx.awx.plugins.lookup'

    ref2 = AnsibleCollectionRef.from_fqcr('awx.awx.lib.user', 'lookup')

# Generated at 2022-06-23 13:47:55.805971
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name(u'ns.collname')  # collection name
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.name')  # invalid
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns..collname')  # invalid
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll-name')  # invalid
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.collname.sub')  # invalid
    assert not AnsibleCollectionRef.is_valid_collection_name(u'collname')  # invalid
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.')  # invalid
    assert not AnsibleCollectionRef.is_

# Generated at 2022-06-23 13:48:02.010545
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo')

    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._split_name == ['ansible_collections']
    assert loader._package_to_load == ''
    assert loader._parent_package_name == ''


# Generated at 2022-06-23 13:48:11.828955
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    with pytest.raises(ValueError):
        ansible_collection_loader = _AnsibleCollectionLoader()
    with pytest.raises(ImportError):
        ansible_collection_loader = _AnsibleCollectionLoader(path_list=['/usr/share/ansible'])
    ansible_collection_loader = _AnsibleCollectionLoader(path_list=['/usr/share/ansible'], name='ansible.builtin.config')
    assert ansible_collection_loader._fullname == 'ansible.builtin.config'
    assert ansible_collection_loader._package_to_load == 'config'
    assert ansible_collection_loader._split_name == ['ansible', 'builtin', 'config']
    assert ansible_collection_loader._candidate_paths is None
    assert ansible_collection

# Generated at 2022-06-23 13:48:19.377471
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = os.path.join(os.path.dirname(__file__), "..")
    collection_finder._install()
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)

    prefix = "ansible"
    modules = ansible_path_hook_finder.iter_modules(prefix)
    assert ("ansible", False, False) in modules



# Generated at 2022-06-23 13:48:28.947087
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():

    class _AnsibleCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return self._subpackage_search_paths

        def _validate_final(self):
            self._subpackage_search_paths = ['/tmp/test/']

    coll_loader = _AnsibleCollectionPkgLoader('test.test')

    is_pkg = coll_loader.is_package('test.test')
    assert is_pkg == True, "is_package returns incorrect value"

test__AnsibleCollectionPkgLoaderBase_is_package()



# Generated at 2022-06-23 13:48:38.669540
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('foo', '.') == ('foo.py', True, None)
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('foo', '/var/lib/bar') == ('/var/lib/bar/foo.py', True, None)
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('foo', '/var/lib/bar') == ('/var/lib/bar/foo.py', True, None)
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('foo', './bar') == ('./bar/foo.py', True, None)

# Generated at 2022-06-23 13:48:49.900267
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns.test_coll', path_list=['/test_path']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[\'/test_path/test_coll\'])'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns.test_coll.test_pkg', path_list=['/test_path']).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=[\'/test_path/test_coll\'])'
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns.test_coll.test_pkg.test_mod', path_list=['/test_path']).__repr

# Generated at 2022-06-23 13:48:59.190889
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    assert sys.path_importer_cache != {}

    ansible_root_path = os.path.dirname(os.path.dirname(os.path.abspath(ansible.__file__)))
    collection_finder_1 = _AnsibleCollectionFinder([ansible_root_path])
    collection_finder_1._install()


# Generated at 2022-06-23 13:49:02.431997
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_type = 'module'
    ref = 'not.a.real.collection.mymodule'
    assert AnsibleCollectionRef.try_parse_fqcr(ref, ref_type) is None


# Generated at 2022-06-23 13:49:11.020327
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Confirm parsing of a full FQCR
    fqcr = 'ns.coll.subdir.resource'
    ns, coll, subdir, res = AnsibleCollectionRef.from_fqcr(fqcr, 'action')
    assert ns == 'ns'
    assert coll == 'coll'
    assert subdir == 'subdir'
    assert res == 'resource'

    # Confirm parsing of a minimal FQCR
    fqcr = 'ns.coll.resource'
    ns, coll, subdir, res = AnsibleCollectionRef.from_fqcr(fqcr, 'action')
    assert ns == 'ns'
    assert coll == 'coll'
    assert subdir == ''
    assert res == 'resource'

    # Confirm parsing of a playbook FQCR

# Generated at 2022-06-23 13:49:22.078133
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    AnsibleCollectionConfig.instance()
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ':'.join(['/path1/to/collection', '/path2/to/collection'])

    if not os.path.exists('/path1/to/collection/namespace1/collection1'):
        os.mkdir('/path1/to/collection/namespace1/collection1')
    if not os.path.exists('/path1/to/collection/namespace2/collection2'):
        os.mkdir('/path1/to/collection/namespace2/collection2')

    if not os.path.exists('/path2/to/collection/namespace1/collection1'):
        os.mkdir('/path2/to/collection/namespace1/collection1')
   

# Generated at 2022-06-23 13:49:29.165810
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Arrange
    ref = 'ansible.example_collection.plugins.action_plugins.somesubdir.helloworld'
    # ref = 'ansible.example_collection.plugins.helloworld'
    # ref = 'ansible.example_collection.plugins.helloworld.py'
    ref_type = 'action'
    excepted_ret = None

    # Act
    ret = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)

    # Assert
    if excepted_ret != ret:
        print('AnsibleCollectionRef.try_parse_fqcr() test failed.')
        return 1
    else:
        print('AnsibleCollectionRef.try_parse_fqcr() test passed.')
        return 0


# Generated at 2022-06-23 13:49:35.798545
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert not AnsibleCollectionRef.is_valid_collection_name('network')
    assert not AnsibleCollectionRef.is_valid_collection_name('network.^')
    assert not AnsibleCollectionRef.is_valid_collection_name('.')
    assert not AnsibleCollectionRef.is_valid_collection_name('network..')
    assert not AnsibleCollectionRef.is_valid_collection_name('network.cisco.ansible_module')
    assert not AnsibleCollectionRef.is_valid_collection_name('for')
    assert not AnsibleCollectionRef.is_valid_collection_name('network.cisco.')
    assert AnsibleCollectionRef.is_valid_collection_name('network.cisco')
    assert AnsibleCollectionRef.is_valid_collection_name('cisco.ios')
    assert AnsibleCollectionRef.is_

# Generated at 2022-06-23 13:49:46.042236
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # Only test constructor of class _AnsibleCollectionLoader
    import_data_path = os.path.join(os.path.dirname(os.path.abspath(ansible.__file__)), 'test/test_utils/test_collection_loader.py')
    with open(import_data_path, 'rb') as fd:
        code = fd.read()

    loader = _AnsibleCollectionLoader(import_data_path, code, import_data_path, None)
    assert loader._fullname == 'ansible.test_utils.test_collection_loader'
    assert loader._decoded_source == code
    assert loader._compiled_code is None
    assert loader._source_code_path == import_data_path
    assert loader._subpackage_search_paths is None
    assert loader._package_

# Generated at 2022-06-23 13:49:53.188725
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    path = 'test/units/support/testdata'
    finder = AnsibleCollectionFinder(path)
    loader = finder.find_module('ansible_collections.myorg.myanoncol')
    assert loader != None
    assert loader.iter_modules('ansible_collections.myorg.myanoncol') != None


# Generated at 2022-06-23 13:50:02.394945
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    fcf = AnsibleCollectionConfig.collection_finder
    assert isinstance(fcf, _AnsibleCollectionFinder)

    apf = _AnsiblePathHookFinder(fcf, '/path/to/my/collections')
    assert isinstance(apf, _AnsiblePathHookFinder)
    assert apf._pathctx == '/path/to/my/collections'


# A loader that handles modules and packages that live below a known collection
# eg, ansible_collections.somenamespace.somecollection.plugins.module_utils.some_module

# Generated at 2022-06-23 13:50:07.708781
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
  print(AnsibleCollectionRef('test', None, 'resource', 'role'))
  assert AnsibleCollectionRef('test', None, 'resource', 'role') == 'AnsibleCollectionRef(collection=\'test\', subdirs=\'\', resource=\'resource\')'



# Generated at 2022-06-23 13:50:18.934603
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    collection_path = 'tests/fixtures/build/placebo_collections'
    ansible_collections_path = os.path.join(collection_path, 'ansible_collections')
    os.makedirs(ansible_collections_path)
    role_collection_name_space = 'role'
    role_collection_name = 'test'
    role_collection_path = os.path.join(ansible_collections_path, role_collection_name_space, role_collection_name)
    os.makedirs(role_collection_path)
    meta_file = os.path.join(role_collection_path, 'meta.json')


# Generated at 2022-06-23 13:50:25.049113
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/'])
    assert loader._fullname == 'ansible_collections'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', '', 'ansible_collections')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == ['/ansible_collections']
    assert loader._subpackage_search_paths == []


# Generated at 2022-06-23 13:50:36.793999
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    """Test get_filename method of class _AnsibleCollectionPkgLoaderBase

    Subclass _AnsibleCollectionPkgLoaderBase, override get_filename method, and assert results
    """

    class _TestAnsibleCollectionPathFinder(PathFinder):
        def __init__(self):
            super(_TestAnsibleCollectionPathFinder, self).__init__((), (lambda x: ()))
            self._found = False
            self._load_count = 0
            self._ret_preferred_pkg_loader = None

        def __call__(self, name, *args, **kwargs):
            return self.find_module(name, *args, **kwargs)

        def find_module(self, fullname, path=None):
            self._found = True
            self._load_count += 1
            return self._

# Generated at 2022-06-23 13:50:43.145879
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Call the method with all possible arguments.
    # module_utils/basic.py has been symlinked to /tmp/ansible_collections/ansible/ansible/module_utils/basic.py
    assert _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase__get_source(
        module_utils.basic,
        "/tmp/ansible_collections/ansible/ansible/module_utils/basic.py"
    ) is not None

# Generated at 2022-06-23 13:50:54.482710
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsibleCollectionFinder._remove()

# Generated at 2022-06-23 13:50:59.617536
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(collection_name='foo.bar', subdirs=None, resource='myresource', ref_type='someplugin')

    assert repr(ref) == 'AnsibleCollectionRef(collection=\'foo.bar\', subdirs=\'\', resource=\'myresource\')'



# Generated at 2022-06-23 13:51:04.222496
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Initialize test values
    fullname = "ansible_collections.ansible_collections"

    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    loader.get_code(fullname)
    assert loader._compiled_code is not None


# Generated at 2022-06-23 13:51:09.278490
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert(repr(_AnsiblePathHookFinder(None, '/path/to/test')) == "_AnsiblePathHookFinder(path='/path/to/test')")

# Generated at 2022-06-23 13:51:11.635444
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    f = _AnsiblePathHookFinder(None, 'ansible_collections')
    assert repr(f) == '_AnsiblePathHookFinder(path=\'ansible_collections\')'



# Generated at 2022-06-23 13:51:16.779882
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():

    class _AnsibleCollectionPkgLoaderBaseTest(_AnsibleCollectionPkgLoaderBase):
        pass

    _AnsibleCollectionPkgLoaderBaseTest('ansible_collections.ns')
    _AnsibleCollectionPkgLoaderBaseTest('ansible_collections.ns.test')



# Generated at 2022-06-23 13:51:21.307795
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert 'ansible' == collection_finder._ansible_pkg_path
    assert [] == collection_finder._n_configured_paths
    assert [] == collection_finder._n_playbook_paths
    assert [] == collection_finder._n_collection_paths
    assert None is collection_finder._n_cached_collection_paths
    assert None is collection_finder._n_cached_collection_qualified_paths



# Generated at 2022-06-23 13:51:28.263785
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    ctx = os.path.join(os.path.expanduser('~'), 'foo_bar')
    i = _AnsiblePathHookFinder('bogus',ctx)
    assert to_text(i.__repr__()) ==_AnsiblePathHookFinder.__name__ + "(path='{ctx}')".format(ctx=ctx)


# Generated at 2022-06-23 13:51:39.193222
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from io import StringIO
    import sys
    import tempfile
    import unittest

    class TestCode(unittest.TestCase):
        def setUp(self):
            self.old_sys_stdout = sys.stdout
            self.old_sys_modules = sys.modules.copy()
            self.output = StringIO()
            sys.stdout = self.output
            self.tmpdir = tempfile.mkdtemp()
            self.source_code = 'print("test_stdout_msg")'
            self.test_pkg_name = 'test_package'
            self.test_module_name = 'test_module'
            self.test_module_name2 = 'test_module2'
            # Create test package

# Generated at 2022-06-23 13:51:45.973706
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data', 'plugins', 'modules', 'python.py')
    test_path = to_native(test_path)

    l = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible', ['/'])
    if l.get_data(test_path) != get_data(test_path):
        exit(1)

# Generated at 2022-06-23 13:51:58.961409
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _test(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(_test, self).__init__(fullname, path_list)

        def _validate_args(self):
            assert self._fullname == 'ansible_collections.ns.subdir.subdir2.pkg'
            assert self._split_name == ['ansible_collections', 'ns', 'subdir', 'subdir2', 'pkg']
            assert self._rpart_name == ('ansible_collections.ns.subdir.subdir2', '.', 'pkg')
            assert self._parent_package_name == 'ansible_collections.ns.subdir.subdir2'
            assert self._package_to_load == 'pkg'


# Generated at 2022-06-23 13:52:10.961791
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Input initialization
    arg_fullname = "Test loadder"
    arg_fullname_0 = "Test loadder-0"

    try: #Try to import the _AnsibleCollectionPkgLoaderBase
        from ansible.plugins.loader import _AnsibleCollectionPkgLoaderBase
    except:
        # If not, load the corresponding class
        class _AnsibleCollectionPkgLoaderBase:
            # Initializing state variables
            _fullname = None
            _decoded_source = ""
            _compiled_code = None

            # Initializer
            def __init__(self, fullname):
                self._fullname = fullname

            # Implementations of method get_code
            def get_code(self, fullname):
                if self._fullname == fullname:
                    return self._compiled_code

# Generated at 2022-06-23 13:52:12.833835
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    loader = _AnsibleCollectionPkgLoaderBase('foo', [])

# Generated at 2022-06-23 13:52:16.876011
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    C = AnsibleCollectionRef
    n = u'it.f5.bigip'
    if C.is_valid_collection_name(n):
        return True
    else:
        return False


# Generated at 2022-06-23 13:52:25.134905
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print("Testing _AnsibleCollectionPkgLoaderBase.get_data()")
    # initialize arguments (kwargs)
    fullname = "ansible_collections.example_namespace.example_collection"
    path = "/usr/share/ansible/collections/ansible_collections/example_namespace/example_collection/__init__.py"
    kwargs = {
        'fullname': fullname,
        'path': path
    }
    # initialize the mock
    kvio_mock = mock.Mock()
    kvio_mock.kvio_path_isdir.return_value = True
    kvio_mock.kvio_path_isfile.return_value = True
    _AnsibleCollectionPkgLoaderBase.kvio = kvio_mock


# Generated at 2022-06-23 13:52:35.345973
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef('my.awesome_collection', subdirs=None, resource='my_module', ref_type=u'module')
    assert ref.collection == 'my.awesome_collection'
    assert ref.subdirs == ''
    assert ref.resource == 'my_module'
    assert ref.ref_type == 'module'

    ref = AnsibleCollectionRef('my.awesome_collection', subdirs=u'module_utils', resource='my_utils', ref_type=u'module_utils')
    assert ref.collection == 'my.awesome_collection'
    assert ref.subdirs == 'module_utils'
    assert ref.resource == 'my_utils'
    assert ref.ref_type == 'module_utils'


# Generated at 2022-06-23 13:52:46.281289
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # mock class
    class Loader(object):
        def __init__(self):
           self._fullname='ansible_collections.test_c.plugin_foo'
           self._subpackage_search_paths = ['/foo/bar']
        def is_package(self, fullname):
           return True

    loader = Loader()
    # tests for case without package
    assert loader.get_data('/foo/bar/__init__.py') == None
    assert loader.get_data('/foo/bar/__init__.pyc') == None
    # tests for case with package
    assert loader.get_data('/foo/bar/__init__.py') == ''
    assert loader.get_data('/foo/bar/__init__.pyc') == None



# Generated at 2022-06-23 13:52:57.164582
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.some_dir.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.some_dir.some_dir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.yml')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.some_dir')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.1.2.3')

# Generated at 2022-06-23 13:53:01.075476
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    loader = _AnsibleCollectionPkgLoaderBase('foo_collection.plugin')
    assert repr(loader) == '_AnsibleCollectionPkgLoaderBase(path=None)'


# Generated at 2022-06-23 13:53:09.600095
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    module_path = 'ansible_collections.test_collection.test_ns.test_module'

    # test case for modules with no submodules
    loader = _AnsibleCollectionPkgLoaderBase(module_path)
    loader._source_code_path = '/path/to/test_module.py'
    module = loader.load_module(module_path)
    assert module == sys.modules[module_path]
    del sys.modules[module_path]

    # test case for packages with no submodules
    loader = _AnsibleCollectionPkgLoaderBase(module_path)
    loader._subpackage_search_paths = ['/path/to/test_ns']
    module = loader.load_module(module_path)
    assert loader.is_package(module_path)

# Generated at 2022-06-23 13:53:18.759839
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    from collections import namedtuple
    from os import path
    from _collection_loader import _AnsibleCollectionFinder
    from _collection_loader import AnsibleCollectionConfig
    from _collection_loader import _AnsibleCollectionPkgLoader
    from _collection_loader import _AnsiblePathHookFinder
    from unittest import TestCase
    from shutil import rmtree
    from tempfile import mkdtemp
    from _ansible_module_runner import _AnsibleModuleRunner

    _FakeArgs = namedtuple('_FakeArgs', 'collection_paths force_collection no_deprecated_collections module_path')


# Generated at 2022-06-23 13:53:28.426052
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():  # FIXME: name
    ctx = 'ansible_collections.ns.coll'
    full_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ctx.replace('.', '/'))
    coll_dir = os.path.dirname(full_path)

    # FUTURE: consider using https://docs.pytest.org/en/latest/tmpdir.html
    real_tempdir = tempfile.gettempdir()


# Generated at 2022-06-23 13:53:34.835323
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
   
    # Test missing collection ref
    assert not AnsibleCollectionRef.is_valid_fqcr(None), "Failed Base case test."
    assert not AnsibleCollectionRef.is_valid_fqcr(''), "Failed Base case test."
    
    # Test regular Expression used in collection ref
    assert not AnsibleCollectionRef.is_valid_fqcr('1'), "Failed Regular Expression test."
    assert not AnsibleCollectionRef.is_valid_fqcr('@'), "Failed Regular Expression test."
    assert not AnsibleCollectionRef.is_valid_fqcr('1.1'), "Failed Regular Expression test."
    assert not AnsibleCollectionRef.is_valid_fqcr('1.a'), "Failed Regular Expression test."