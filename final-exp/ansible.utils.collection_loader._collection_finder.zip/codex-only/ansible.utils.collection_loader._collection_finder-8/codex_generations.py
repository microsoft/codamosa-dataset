

# Generated at 2022-06-23 13:43:44.993658
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    ''' Unit tests for method _AnsibleCollectionPkgLoaderBase.iter_modules of class _AnsibleCollectionPkgLoaderBase '''
    # Create a _AnsibleCollectionPkgLoaderBase object for testing
    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'iter_modules')
    test_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_collection', path_list=[test_path])
    # Test execution of method iter_modules
    test_prefix = 'ansible_collections.test_collection'
    # The result should be a generator
    assert isinstance(test_loader.iter_modules(test_prefix), types.GeneratorType)
    # The result should contain tuples

# Generated at 2022-06-23 13:43:53.146349
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    pkgs = [os.path.sep + 'my_collections' + os.path.sep + name for name in ['foo', 'bar_1.2.3']]

    pkg_loader = _AnsibleCollectionPkgLoaderBase('foo', path_list=pkgs)
    assert pkg_loader.is_package('foo') == False

    pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=pkgs)
    assert pkg_loader.is_package('ansible_collections.foo') == True

    pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=pkgs)
    assert pkg_loader.is_package('ansible_collections.foo.bar') == False



# Generated at 2022-06-23 13:44:04.418353
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping

    def _test_iter_modules_impl(mocked_module_finder, mocked_fullname, mocked_directories):

        collection_finder = _AnsibleCollectionFinder()
        pathctx = 'abc/xyz/ansible_collections/ns/coll'

        instance = _AnsiblePathHookFinder(collection_finder, pathctx)


# Generated at 2022-06-23 13:44:10.903722
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    plugin_dir = 'action'
    action = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir)
    assert action == 'action'
    plugin_dir = 'action_plugins'
    action = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir)
    assert action == 'action'
    plugin_dir = 'lookup_plugins'
    action = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir)
    assert action == 'lookup'


# Generated at 2022-06-23 13:44:22.641285
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(['/Users/briancurtin/workspace/ansible/packaging/ansible/collection_loader.py'], 'ansible.collections.test.test_test')
    assert loader._fullname == 'ansible.collections.test.test_test'
    assert loader._parent_package_name == 'ansible.collections.test'
    assert loader._package_to_load == 'test_test'
    assert loader._candidate_paths == ['/Users/briancurtin/workspace/ansible/packaging/ansible/collections/ansible_collections/test/test_test']
    assert loader._subpackage_search_paths is None

# Generated at 2022-06-23 13:44:29.135193
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_type_test = AnsibleCollectionRef('namespace.test', None, 'resource', 'test_ref_type')
    ref_test = AnsibleCollectionRef.try_parse_fqcr('namespace.test.resource', 'test_ref_type')
    assert ref_test.collection == ref_type_test.collection
    assert ref_test.subdirs == ref_type_test.subdirs
    assert ref_test.resource == ref_type_test.resource
    assert ref_test.ref_type == ref_type_test.ref_type

# Generated at 2022-06-23 13:44:40.497071
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import sys
    import os
    import tempfile
    import shutil
    import pkgutil
    import unittest
    from collections import namedtuple

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()

            # create some test packages/modules
            self.package_a_dir = os.path.join(self.test_dir, 'ansible_collections', 'collection_a')
            os.makedirs(self.package_a_dir)

            self.package_b_dir = os.path.join(self.test_dir, 'ansible_collections', 'collection_b')
            os.makedirs(self.package_b_dir)


# Generated at 2022-06-23 13:44:48.364693
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    with pytest.raises(TypeError, match="__init__\(\).*missing.*"):
        AnsibleCollectionRef(collection_name=None, subdirs=None, resource=None, ref_type=None)

    ref = AnsibleCollectionRef(collection_name='dummy.collection', subdirs='subdir1.subdir2', resource='dummy_resource', ref_type='dummy_type')
    assert ref
    assert 'dummy.collection' in ref.__repr__()
    assert 'subdir1.subdir2' in ref.__repr__()
    assert 'dummy_resource' in ref.__repr__()
    assert 'dummy_type' not in ref.__repr__()



# Generated at 2022-06-23 13:44:56.013338
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import tempfile
    hook = _AnsiblePathHookFinder(None, tempfile.gettempdir())
    repr_ = hook.__repr__()
    expected = "{0}(path='{1}')".format(hook.__class__.__name__, hook._pathctx)
    assert repr_ == expected, "Received unexpected repr: {0}".format(repr_)



# Generated at 2022-06-23 13:45:08.334248
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # should fail without ref type
    assert None == AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', None)
    # should fail with empty ref type
    assert None == AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', '')
    # should fail with invalid ref type
    assert None == AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', 'xxx')
    # should fail with invalid reference
    assert None == AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource.', 'module')
    assert None == AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource.ext', 'module')

# Generated at 2022-06-23 13:45:15.715775
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # just returning whatever get_data returns is fine for our purposes
    # (in fact, we have to do this because we have an internal-only package init called __synthetic__)
    with patch.object(_AnsibleCollectionPkgLoaderBase, 'get_data') as gd:
        loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')
        gd.return_value = 'keep it simple, stupid'
        assert loader.get_source('ansible_collections.foo.bar') == 'keep it simple, stupid'
        assert loader.get_source('whatever') is None



# Generated at 2022-06-23 13:45:23.101997
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/foo/bar'])
    assert loader._fullname == 'ansible_collections'
    assert loader._package_to_load == 'ansible_collections'
    assert loader._candidate_paths == ['/foo/bar/ansible_collections']
    assert loader._subpackage_search_paths == []
    assert loader.get_filename('ansible_collections') == '<ansible_synthetic_collection_package>'



# Generated at 2022-06-23 13:45:29.072350
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    collections_loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert collections_loader._fullname == 'ansible_collections'
    assert collections_loader._source_code_path is None
    assert collections_loader._split_name == ['ansible_collections']
    assert collections_loader._rpart_name == ('', 'ansible_collections', '')
    assert collections_loader._parent_package_name == collections_loader._rpart_name[0]
    assert collections_loader._package_to_load == collections_loader._rpart_name[2]
    assert collections_loader._candidate_paths == []
    assert collections_loader._subpackage_search_paths == []



# Generated at 2022-06-23 13:45:40.322531
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_strings = [
        ('action_plugins', 'action'),
        ('callback_plugins', 'callback'),
        ('connection_plugins', 'connection'),
        ('filter_plugins', 'filter'),
        ('lookup_plugins', 'lookup'),
        ('module_utils', 'module_utils'),
        ('modules', 'module'),
        ('vars_plugins', 'vars'),
        ('library', 'module')
    ]
    for test_string, expected in test_strings:
        assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_string) == expected, "{0} != {1}".format(
            AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_string), expected)


# FIXME: move to 'helpers' or similar

# Generated at 2022-06-23 13:45:43.425165
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    finder = _AnsibleCollectionFinder()
    assert not finder is None


# Generated at 2022-06-23 13:45:55.932694
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import os
    import tempfile
    import shutil
    collections_path = tempfile.mkdtemp()
    import ansible_collections.test_namespace.test_collection123.plugins.module_utils.test_module as test_module
    test_module_path = os.path.dirname(test_module.__file__)
    test_module_dirname = os.path.basename(test_module_path)
    test_module_basename = os.path.basename(test_module.__file__)

# Generated at 2022-06-23 13:46:02.884473
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:46:07.594023
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # invalid playbook_paths
    try:
        _AnsibleCollectionFinder().set_playbook_paths(None)
        assert False
    except Exception as e:
        assert str(e) == 'playbook_paths must be a list or string'

    # valid playbook_paths
    try:
        _AnsibleCollectionFinder().set_playbook_paths('/home/ec2-user')
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-23 13:46:14.294438
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # arrange
    path_context = ''
    path_hook = _AnsiblePathHookFinder(collection_finder=None, pathctx=path_context)
    prefix = 'ansible_collections'
    expected = [
        ('ansible.executor.module_common','ansible.executor.module_common'),
    ]

    # act
    result = list(path_hook.iter_modules(prefix))

    # assert
    assert result == expected

# Generated at 2022-06-23 13:46:17.583534
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert _AnsibleCollectionFinder(paths=['test/data/collections/sha2', 'test/data/collections/sha1'])

test__AnsibleCollectionFinder()



# Generated at 2022-06-23 13:46:21.404108
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj = AnsibleCollectionRef('namespace.collection', 'subdirs', 'resource', 'ref_type')
    assert obj.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-23 13:46:24.071908
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.foo.bar', ['/path/to/somewhere'])


# Generated at 2022-06-23 13:46:31.733039
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Creates an instance of class _AnsiblePathHookFinder
    ansible_path_hook_finder = _AnsiblePathHookFinder(None, '/ansible/')
    # Calls method find_module of class _AnsiblePathHookFinder
    ansible_path_hook_finder.find_module('ansible_collections.acme.molecule')
    # Calls method find_module of class _AnsiblePathHookFinder
    ansible_path_hook_finder.find_module('ansible_collections.acme.molecule.test')
    # Calls method find_module of class _AnsiblePathHookFinder
    ansible_path_hook_finder.find_module('ansible.utils.unsafe_proxy.stack')
    # Calls method find_module of class _An

# Generated at 2022-06-23 13:46:41.214882
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():

    #
    # Test case 1: An exception is raised by constructors of class _AnsibleCollectionPkgLoader
    #
    # function _validate_args
    # exception0: raise ValueError if 'subpackage_search_paths' is not a list
    with pytest.raises(ValueError):
        loader = _AnsibleCollectionPkgLoader(subpackage_search_paths='/test/test', package_to_load='test')

    # exception1: raise ValueError if 'subpackage_search_paths' is a list of length 0
    with pytest.raises(ValueError):
        loader = _AnsibleCollectionPkgLoader(subpackage_search_paths=[], package_to_load='test')

    # exception2: raise ValueError if 'subpackage_search_paths' is a list of length greater

# Generated at 2022-06-23 13:46:44.526641
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert result == 'action'


# Generated at 2022-06-23 13:46:56.017630
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():

    # create mock package loader objects to test
    class MyPackageLoader1(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            _AnsibleCollectionPkgLoaderBase._validate_args(self)
            if self._package_to_load != 'my_pkg':
                raise ValueError('package to load must be my_pkg, not %s' % self._package_to_load)
        def _validate_final(self):
            _AnsibleCollectionPkgLoaderBase._validate_final(self)
            if len(self._subpackage_search_paths) != 1:
                raise ValueError('expected 1 subpackage_search_paths, got %s' % self._subpackage_search_paths)


# Generated at 2022-06-23 13:46:59.601507
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    """Test method __repr__ of class _AnsiblePathHookFinder"""
    obj = _AnsiblePathHookFinder(None, 'path')
    repr_result = repr(obj)
    repr_expected = "_AnsiblePathHookFinder(path='path')"
    assert repr_result == repr_expected



# Generated at 2022-06-23 13:47:01.277632
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    pass


# Generated at 2022-06-23 13:47:10.498373
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    path = os.path.join(os.path.dirname(__file__), 'data', 'resources', 'plugins', 'modules')
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.ansible", [path])
    modules = loader.iter_modules(prefix="ansible_collections.ansible")
    assert(list(modules) == [("ansible_collections.ansible.misc", False),
                             ("ansible_collections.ansible.misc.demo", False),
                             ("ansible_collections.ansible.misc.demo.plugins", True),
                             ("ansible_collections.ansible.misc.demo.plugins.modules", True),
                             ("ansible_collections.ansible.misc.demo.plugins.modules.tags", True)])



# Generated at 2022-06-23 13:47:22.942197
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    print('-----------------')
    print('Function: from_fqcr')
    print('-----------------')

    # Arrange
    local_ref = 'ns.coll.resource'
    local_ref_type = 'module'

    local_ref_2 = 'ns.coll.subdir1.subdir2.resource'
    local_ref_type_2 = 'role'

    local_ref_3 = 'ns.coll.rolename'
    local_ref_type_3 = 'role'

    local_ref_4 = 'ns.coll.playbookname'
    local_ref_type_4 = 'playbook'

    local_ref_5 = 'ns.coll.playbookname.yml'
    local_ref_type_5 = 'playbook'


# Generated at 2022-06-23 13:47:28.110294
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # test if _AnsiblePathHookFinder._filefinder_path_hook value is correct
    _filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    assert _filefinder_path_hook is not None



# Generated at 2022-06-23 13:47:37.222608
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class _AnsibleCollectionPkgLoaderBase_get_source_TestClass(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            self._fullname = fullname
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens

            self._redirect_module = None
            self._source_code_path = None
            self._decoded_source = None
            self

# Generated at 2022-06-23 13:47:47.988946
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import sys
    import tempfile
    import os
    import shutil
    import ansible_collections.ansible.os_migrate.tests.unit.data.loader_data_files.ansible_collections.ns_pkg_loader_data.ns_pkg_loader_data as ns_pkg_loader_data
    import ansible_collections.ansible.os_migrate.tests.unit.data.loader_data_files.ansible_collections.ns_pkg_loader_data.ns_pkg_loader_data.coll_pkg_loader_data as coll_pkg_loader_data
    import ansible_collections.ansible.os_migrate.tests.unit.data.loader_data_files.ansible_collections.ns_pkg_loader_data.ns_pkg_loader_data.coll_pkg_loader_data

# Generated at 2022-06-23 13:48:00.211440
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    class _AnsibleCollectionPkgLoaderBaseTester(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
    # custom _validate_args() allow us to test all code paths for load_module, without needing to create directories
    module_attrs = dict(
        __loader__=None,
        __file__='',
        __package__='',
    )
    with _AnsibleCollectionPkgLoaderBaseTester('') as loader:
        with pytest.raises(ImportError):
            loader.load_module('test')
    with _AnsibleCollectionPkgLoaderBaseTester('test') as loader:
        assert loader._fullname == 'test'
        _module = loader.load_module('test')

# Generated at 2022-06-23 13:48:01.905532
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert isinstance(_AnsibleCollectionFinder(), _AnsibleCollectionFinder)


# Generated at 2022-06-23 13:48:05.154140
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/dummy/path'])
    assert loader


# Generated at 2022-06-23 13:48:19.202234
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:48:22.172379
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    r = _AnsiblePathHookFinder(None, 'foo')
    assert r.__repr__() == "_AnsiblePathHookFinder(path='foo')"

# Generated at 2022-06-23 13:48:30.992332
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader as cl
    loader = cl._AnsibleCollectionPkgLoader('ansible.builtin', [])

    class _meta_yml_to_dict:
        @staticmethod
        def convert(raw_yml, path):
            return dict(k='v')

    cl._meta_yml_to_dict = _meta_yml_to_dict

    class AnsibleCollectionConfig:
        @staticmethod
        def on_collection_load(_, collection_name, collection_path):
            assert collection_name == 'ansible.builtin'
            assert collection_path == '' # to avoid spurious errors on CI


# Generated at 2022-06-23 13:48:39.865076
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    test_paths = [
        'test/unit/utils/collection_finder/test_data/one'
    ]

    # test_data/one/
    #   collections/
    #     testns.testcoll1/
    #       plugins/
    #         modules/
    #       plugins/ansible_collections/testns/testcoll1/
    #         modules/
    #   ansible_collections/
    #     testns.testcoll2/
    #       plugins/
    #         modules/
    #       plugins/ansible_collections/testns/testcoll2/
    #         modules/

    modules = []
    finder = _AnsibleCollectionFinder(test_paths, scan_sys_paths=False)
    finder_imp = finder._ansible_collection_path_

# Generated at 2022-06-23 13:48:45.293383
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    acr = AnsibleCollectionRef('ns.col', 'subdir1.subdir2', 'mod', 'module')
    assert acr.__repr__() == 'AnsibleCollectionRef(collection="ns.col", subdirs="subdir1.subdir2", resource="mod")'



# Generated at 2022-06-23 13:48:54.063677
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():

    # This is a quick test to see if the path exists, if not raise an error
    def _get_candidate_paths(self, path_list):
        return [os.path.join(p, self._package_to_load) for p in path_list]

    tmpfile = os.path.join('/tmp/unit-tests', 'test__AnsibleCollectionRootPkgLoader')
    os.makedirs(tmpfile)

    try:
        loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/tmp/unit-tests'])
    except ImportError:
        if not os.path.exists(_get_candidate_paths(loader, tmpfile)):
            raise

    shutil.rmtree(tmpfile)


# Generated at 2022-06-23 13:49:02.527222
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
	collection_loader = _AnsibleCollectionPkgLoader('test', ['fullname', 'package_to_load'])
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']
	assert collection_plugin_path == ['test']

# Generated at 2022-06-23 13:49:10.260571
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
  path_list = ['test_data', 'test_data/ansible_collections']
  fullname = 'ansible_collections.my_ns.my_coll.my_pkg'
  test_obj = _AnsibleCollectionPkgLoaderBase(fullname, path_list)

  assert test_obj.get_filename(fullname) == 'test_data/ansible_collections/my_ns/my_coll/my_pkg/__init__.py'
  assert test_obj.get_filename('ansible_collections.my_ns.my_coll') == '<ansible_synthetic_collection_package>'


# Generated at 2022-06-23 13:49:21.727202
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # Simple examples
    assert AnsibleCollectionRef.is_valid_collection_name('_ns.collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns_._collname')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname_')

    assert not AnsibleCollectionRef.is_valid_collection_name('.')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns._collname')
    assert not AnsibleCollectionRef.is_valid_collection_name('.ns._collname')
    assert not AnsibleCollectionRef.is_valid_collection_name('_ns._collname')

# Generated at 2022-06-23 13:49:24.021566
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('ansible.builtin',10)
    print('TEST PASSED')


# Generated at 2022-06-23 13:49:32.921945
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class MyLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            super(MyLoader, self)._validate_args()
            self._candidate_paths = self._get_candidate_paths([])

    ldr = MyLoader('ansible_collections.foo.bar')
    assert ldr.get_filename('ansible_collections.foo.bar') == '<ansible_synthetic_collection_package>'

    # direct import from a path; 
    ldr = MyLoader('ansible_collections.foo.bar', ['some/path/here'])
    assert ldr.get_filename('ansible_collections.foo.bar') == os.path.join('some/path/here', 'bar', '__synthetic__')

    # direct import from

# Generated at 2022-06-23 13:49:44.265244
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    acr = AnsibleCollectionRef('namespace.collection', 'subdir.subdir2', 'resource.Name', 'module')

    assert(acr.is_valid_fqcr('namespace.collection.subdir.subdir2.resource.Name', 'module'))
    assert(not acr.is_valid_fqcr('namespace.subdir.subdir2.resource.Name', 'module'))
    assert(not acr.is_valid_fqcr('ns.coll.subdir.subdir2.resource.Name', 'module'))
    assert(acr.is_valid_fqcr('namespace.collection.subdir.subdir2.resource.Name'))
    assert(not acr.is_valid_fqcr('namespace.subdir.subdir2.resource.Name'))
   

# Generated at 2022-06-23 13:49:47.217188
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    from os.path import expanduser

    c = _AnsibleCollectionFinder()

    c._install()

    expected = "{0}(path='{1}')".format(_AnsiblePathHookFinder.__name__, expanduser('~/.ansible/collections'))
    assert expected == repr(_AnsiblePathHookFinder(c, expanduser('~/.ansible/collections')))

# Generated at 2022-06-23 13:49:58.128143
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    test_cases = [
        {
            'desc': 'root package loader, valid',
            'args': ['ansible_collections'],
            'subpackage_search_path': [],
            'expect': None
        },
        {
            'desc': 'root package loader, invalid name',
            'args': ['ansible_collections.test'],
            'subpackage_search_path': [],
            'expect': ImportError
        },
        {
            'desc': 'root package loader, invalid name',
            'args': ['test'],
            'subpackage_search_path': [],
            'expect': ImportError
        }
    ]


# Generated at 2022-06-23 13:50:07.211351
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Start with a valid FQCR
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.name') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.dir1.dir2.dir3.dir4.dir5.name') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.dir1.dir2.dir3.dir4.dir5.name', ref_type='module') is True

    # Invalid FQCRs
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.dir1.dir2.dir3.dir4.dir5.') is False

# Generated at 2022-06-23 13:50:18.485660
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    """Test if method find_module of class _AnsibleCollectionFinder is working as expected."""
    # Create an instance of the class _AnsibleCollectionFinder
    ansible_collection_finder = _AnsibleCollectionFinder()
    # Check if is not found a module
    assert ansible_collection_finder.find_module('ansible', 'path') == None
    # Check if is not found a ansible.module_utils.another_module
    assert ansible_collection_finder.find_module('ansible.module_utils.another_module') == None
    # Check if is not found a ansible_collections.another_collection.another_module
    assert ansible_collection_finder.find_module('ansible_collections.another_collection.another_module') == None
    # Check if is not found a ansible_col

# Generated at 2022-06-23 13:50:22.571383
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    finder = _AnsibleCollectionFinder()
    path_hook = _AnsiblePathHookFinder(finder, "some_pathctx")
    current_module = sys.modules[__name__]
    assert path_hook.find_module("test__AnsiblePathHookFinder_find_module", [current_module.__path__]) == current_module



# Generated at 2022-06-23 13:50:35.220267
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef(u'foo.bar', u'subdirs', u'resource', u'module').__repr__() == 'AnsibleCollectionRef(collection=\'foo.bar\', subdirs=\'subdirs\', resource=\'resource\')'
    assert AnsibleCollectionRef(u'foo.bar', None, u'resource', u'module').__repr__() == 'AnsibleCollectionRef(collection=\'foo.bar\', subdirs=\'\', resource=\'resource\')'
    assert AnsibleCollectionRef(u'foo.bar', u'', u'resource', u'module').__repr__() == 'AnsibleCollectionRef(collection=\'foo.bar\', subdirs=\'\', resource=\'resource\')'


# Generated at 2022-06-23 13:50:39.039952
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.test', ['path_list'])
    assert loader.load_module('ansible.test').__name__ == 'ansible.test'
    assert loader.load_module('ansible.test').__package__ == 'ansible'


# Generated at 2022-06-23 13:50:46.365099
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # subpackage_search_paths None
    f,fobj = tempfile.mkstemp(prefix='AnsibleCollectionDiscovery')
    fobj.close()
    source_code_path = f
    l = _AnsibleCollectionPkgLoaderBase('y', path_list=['x'])
    l._source_code_path = source_code_path
    l._subpackage_search_paths = None
    r = l.__repr__()
    assert r == '{0}(path={1})'.format(l.__class__.__name__, source_code_path)
    os.unlink(source_code_path)
    # subpackage_search_paths ('x')
    f, fobj = tempfile.mkstemp(prefix='AnsibleCollectionDiscovery')

# Generated at 2022-06-23 13:50:52.612752
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    collector = mock.MagicMock()
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.something.else', path_list=[collector])
    data = loader.get_data('/dev/null')
    collector.read_local_file.assert_called_with('/dev/null')
    assert data == collector.read_local_file.return_value



# Generated at 2022-06-23 13:51:04.686031
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Path to a collection with a local content_dir
    collection_dir = ANSIBLE_COLLECTIONS_FOLDER.joinpath('ns')
    # The content_dir path as a str
    content_dir_str = str(collection_dir.joinpath('tasks'))

    # Test for an existing module
    module_name = 'b_module.py'
    pkg_loader = _AnsibleCollectionPkgLoaderBase('ns', [content_dir_str])
    assert pkg_loader.iter_modules('ns') is not None
    assert pkg_loader.iter_modules('ns.tasks') is not None
    assert module_name in list(pkg_loader.iter_modules('ns.tasks'))

    # Test for a not existing module
    module_name = 'not_existing_module.py'


# Generated at 2022-06-23 13:51:15.114245
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    path = "/path/to/collections/ansible_galaxy/cookbooks/test_collection/tasks"
    prefix = "test_collection.cookbooks.test_collection"
    expected_return = [('test_collection.cookbooks.test_collection.test', '/path/to/collections/ansible_galaxy/cookbooks/test_collection/tasks/test.yaml', 'yaml')]
    collection_finder = _AnsibleCollectionFinder()
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, path)
    assert ansible_path_hook_finder.iter_modules(prefix) == expected_return



# Generated at 2022-06-23 13:51:17.454268
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionLoader('ns.coll.sub.mod', [''], 1)

# Unit test load_module of class _AnsibleCollectionLoader

# Generated at 2022-06-23 13:51:24.730693
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo')
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar')
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._package_to_load == 'ansible_collections'
    assert loader._parent_package_name == ''



# Generated at 2022-06-23 13:51:33.930530
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    """
    Unit test for method is_valid_collection_name of class AnsibleCollectionRef
    """
    ansible_collections = []

    # https://github.com/ansible/ansible/pull/62741
    ansible_collections.append({
        'name': 'ansible_collections.foo.bar.collection1',
        'should_pass': True
    })

    ansible_collections.append({
        'name': 'ansible_collections.foo.bar.collection2',
        'should_pass': True
    })

    ansible_collections.append({
        'name': 'ansible_collections.foo.bar.collection3',
        'should_pass': True
    })


# Generated at 2022-06-23 13:51:44.731254
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert isinstance(collection_finder, object)
    assert hasattr(collection_finder, '_n_configured_paths')
    assert hasattr(collection_finder, '_n_playbook_paths')
    assert hasattr(collection_finder, '_ansible_pkg_path')
    assert hasattr(collection_finder, '_ansible_collection_path_hook')
    assert hasattr(collection_finder, '_n_cached_collection_paths')
    assert hasattr(collection_finder, '_n_cached_collection_qualified_paths')
    assert hasattr(collection_finder, '_n_collection_paths')
    assert hasattr(collection_finder, '_reload_hack')


    # Test for finder
    assert has

# Generated at 2022-06-23 13:51:52.088952
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    acr = AnsibleCollectionRef('', '', '', '')
    assert acr.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert acr.legacy_plugin_dir_to_plugin_type('action_plugins.mydir') == 'action'
    assert acr.legacy_plugin_dir_to_plugin_type('action') == 'action'
    assert acr.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert acr.legacy_plugin_dir_to_plugin_type('mydir') == 'mydir'
    assert acr.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    with pytest.raises(ValueError):
        acr.legacy_

# Generated at 2022-06-23 13:51:59.626877
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    c = _AnsibleCollectionFinder()
    c._install()

    assert isinstance(c, _AnsibleCollectionFinder)
    path_hook = c._ansible_collection_path_hook(c._ansible_pkg_path)
    assert isinstance(path_hook, _AnsiblePathHookFinder)
    return path_hook


# Base loader that uses a local _n_collection_finder_object _AnsiblePathHookFinder for iter_modules, etc.

# Generated at 2022-06-23 13:52:11.345725
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Mock class _AnsibleInternalRedirectLoader
    class Mock_AnsibleInternalRedirectLoader(object):
        def __init__(self, fullname, path_list):
            self._redirect = None

            split_name = fullname.split('.')
            toplevel_pkg = split_name[0]
            module_to_load = split_name[-1]

            if toplevel_pkg != 'ansible':
                raise ImportError('not interested')

            builtin_meta = _get_collection_metadata('ansible.builtin')

            routing_entry = _nested_dict_get(builtin_meta, ['import_redirection', fullname])
            if routing_entry:
                self._redirect = routing_entry.get('redirect')

            if not self._redirect:
                raise Import

# Generated at 2022-06-23 13:52:24.539077
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    fullname = 'ansible.plugins.action'
    path_list = ['/tmp', '/tmp1']
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    try:
        mod = loader.load_module(fullname)
    except ImportError:
        assert False


# this is just a wrapper around the "normal" import machinery. It allows us to leverage Python's built-in module caching,
# path re-write hooks (if any), normal importlib loading, and so on. It does this by essentially intercepting all
# Python module imports and making them pass through this path hook instead, in turn invoking this path_hook method.
# Simple directory-based packages and normal module imports just pass straight through, while our custom redirects
# are handled by the _AnsibleInternalRedirectLoader.

# Generated at 2022-06-23 13:52:30.984261
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar')

    with pytest.raises(ValueError):
        _AnsibleCollectionRootPkgLoader('ansible_collections').load_module('ansible_collections.foo.bar')

    _AnsibleCollectionRootPkgLoader('ansible_collections')



# Generated at 2022-06-23 13:52:33.775774
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    #_AnsibleCollectionPkgLoaderBase.get_source
    assert get_source('ansible_collections') == 'ansible_collections'



# Generated at 2022-06-23 13:52:45.650866
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # We need a fake path list, which needs to be a real path
    fake_path = u'/this/is/a/fake/path'

    # Make sure that the constructor works with some dummy input
    loader0 = _AnsibleCollectionNSPkgLoader('ansible_collections.namespace.collection', path_list=[fake_path])

    # Make sure that the correct attributes are set
    assert loader0._fullname == 'ansible_collections.namespace.collection'
    assert loader0._redirect_module is None
    assert loader0._split_name == ['ansible_collections', 'namespace', 'collection']
    assert loader0._rpart_name == ('ansible_collections.namespace', '.', 'collection')
    assert loader0._parent_package_name == 'ansible_collections.namespace'


# Generated at 2022-06-23 13:52:51.164827
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.somens', path_list=[])
    assert loader == loader
    with pytest.raises(ImportError):
        loader2 = _AnsibleCollectionNSPkgLoader('ansible_collections', path_list=[])


# Generated at 2022-06-23 13:52:54.985705
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import sys
    import ansible.utils.collection_loader
    loader = ansible.utils.collection_loader._AnsibleInternalRedirectLoader('ansible.module_utils', [])
    assert loader._redirect == 'ansible_collections.ansible.module_utils'

# Generated at 2022-06-23 13:53:04.329519
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:53:15.110200
# Unit test for constructor of class _AnsibleCollectionFinder

# Generated at 2022-06-23 13:53:23.130758
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    c = _AnsibleCollectionFinder()
    c._install()

    assert repr(c._ansible_collection_path_hook('/foo/bar/')) == \
        "{0}(path='/foo/bar/')".format(_AnsiblePathHookFinder.__name__)
    assert repr(c._ansible_collection_path_hook('/foo/bar')) == \
        "{0}(path='/foo/bar')".format(_AnsiblePathHookFinder.__name__)


# Generated at 2022-06-23 13:53:29.247068
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_name = 'namespace.collectionname'
    subdirs = 'subdir1.subdir2'
    resource = 'resourceName'
    ref_type = 'action'
    ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collectionname', subdirs='subdir1.subdir2', resource='resourceName')"

# Generated at 2022-06-23 13:53:37.524542
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    finder = _AnsibleCollectionFinder()
    playbook_paths = ['path1', 'path2', 'path2', 'path2', 'path1']
    finder._n_playbook_paths = []
    finder._n_cached_collection_paths = []
    finder._n_cached_collection_qualified_paths = []
    finder.set_playbook_paths(playbook_paths)
    cached_collection_paths = finder._n_cached_collection_paths
    assert cached_collection_paths == ['path1', 'path2', 'path1']
    assert len(playbook_paths) == 5
    assert len(finder._n_playbook_paths) == 2
    assert finder._n_cached_collection_paths == cached_collection_