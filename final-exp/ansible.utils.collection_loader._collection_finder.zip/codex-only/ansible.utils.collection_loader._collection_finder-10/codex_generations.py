

# Generated at 2022-06-23 13:43:41.973749
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    loader = _AnsibleCollectionPkgLoader('a.b.c', '/foo/bar')
    assert 'a.b.c' == loader.load_module('a.b.c').__name__
    assert 'a.b.c' == loader.load_module('a.b.c').__name__
    try:
        loader.load_module('a.b.c.d')
        assert False
    except ValueError:
        assert True
    
    

# Generated at 2022-06-23 13:43:51.361519
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import _AnsibleCollectionLoader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionRoleLoader

    # find the test collection dir root
    if TEST_DIRECTORY is None:
        raise Exception('TEST_DIRECTORY must be defined')

    test_directory = os.path.join(TEST_DIRECTORY, 'unit', 'utils', 'ansible_test_collections', 'ansible_namespace')

    # build a test ref
    ref = AnsibleCollectionRef.init_from_str('ansible_namespace.test_collection')

    # build the test loaders

# Generated at 2022-06-23 13:44:00.873954
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Setup
    loader = _AnsibleCollectionPkgLoaderBase('foo', ['bar'])
    sys.modules.pop('foo', None)
    loader._source_code_path = 'bar/foo.py'
    loader._subpackage_search_paths = None
    loader._redirect_module = None

    expected_module = ModuleType('foo')
    expected_module.__file__ = loader.get_filename('foo')
    expected_module.__loader__ = loader

    test_code = '''if __name__ == '__main__':
    import doctest
    doctest.testmod()
    '''

    # Test
    with open(loader._source_code_path, 'wb') as fd:
        fd.write(to_bytes(test_code))

    loader.load_module('foo')

# Generated at 2022-06-23 13:44:09.994286
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import tempfile
    import shutil

    def _safe_rm_path(path):
        path = to_native(path, errors='surrogate_or_strict')
        if os.path.exists(path):
            shutil.rmtree(path)

    @contextmanager
    def _playbook_finder_context():
        # noinspection PyTypeChecker
        finder = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
        try:
            finder._install()
            yield finder
        finally:
            _safe_rm_path(os.path.join(runner_dir, 'collections'))
            _safe_rm_path(os.path.join(runner_dir, 'ansible_collections'))
            _AnsibleCollectionFinder._

# Generated at 2022-06-23 13:44:21.844444
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():

    module_name = 'ansible_collections.a.b.c'                  # Exists in FS
    module_name_pyc = module_name + '.pyc'                     # Doesn't exist in FS
    module_name_non_existent = 'ansible_collections.a.b.cc'    # Doesn't exist in FS
    module_name_ansible = 'ansible.a.b.c'                      # Exists in FS

    path_hook_finder = _AnsiblePathHookFinder(None, '/tmp/ansible_collections')    # TODO: Mock
    if sys.version_info >= (3, 0):
        find_module_method = unittest.mock.Mock(__name__='FileFinder.find_module')
    else:
        find_module_method = unittest.m

# Generated at 2022-06-23 13:44:30.653059
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    filename = sys._getframe().f_code.co_name
    msg = "Test Case no: TC-%s-%s - %s" % (filename, 1, test_AnsibleCollectionRef_try_parse_fqcr.__doc__)
    print("%s" % msg)

    obj = AnsibleCollectionRef.try_parse_fqcr('namespace.collection.name', 'module')
    assert isinstance(obj, AnsibleCollectionRef)

    obj = AnsibleCollectionRef.try_parse_fqcr('namespace.collection.name', 'module')
    assert isinstance(obj, AnsibleCollectionRef)

    obj = AnsibleCollectionRef.try_parse_fqcr('namespace.collection.name.py', 'playbook')
    assert isinstance(obj, AnsibleCollectionRef)

    assert Ansible

# Generated at 2022-06-23 13:44:40.813375
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert not AnsibleCollectionRef.is_valid_collection_name(u'namespace.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns..coll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.subcoll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.subcoll.resource')

    assert AnsibleCollectionRef.is_valid_collection_name(u'my.coll')
    assert AnsibleCollectionRef.is_valid_collection_name(u'ns.collname')
    assert AnsibleCollectionRef

# Generated at 2022-06-23 13:44:50.720377
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    test_fullname = 'ansible_collections.foo_namespace.bar_collection.synthetic'
    root_path = '/tmp/ansible_collections/foo_namespace/bar_collection'
    resource_path = '/tmp/ansible_collections/foo_namespace/bar_collection/synthetic/test.py'
    # test _AnsibleCollectionPkgLoaderBase
    pkg_loader = _AnsibleCollectionPkgLoaderBase(
        fullname=test_fullname,
        path_list=[root_path])
    assert pkg_loader._split_name == ['ansible_collections', 'foo_namespace', 'bar_collection', 'synthetic']
    assert pkg_loader._fullname == test_fullname

# Generated at 2022-06-23 13:44:55.625228
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    module_result = AnsibleCollectionRef.try_parse_fqcr('a.b.c.d', 'module')
    assert isinstance(module_result, AnsibleCollectionRef)
    assert module_result.collection == u'a.b'
    assert module_result.subdirs == u'c'
    assert module_result.resource == u'd'
    assert module_result.ref_type == u'module'
    playbook_result = AnsibleCollectionRef.try_parse_fqcr('a.b.c.d', 'playbook')
    assert playbook_result is None


# Generated at 2022-06-23 13:45:00.021317
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase.__repr__ == _AnsibleCollectionPkgLoaderBase.__repr__.im_func


# Basic loader for a top-level namespace package. These are used when we have a package dir, but no __init__.py
# (which can happen when a collection is installed without any content).

# Generated at 2022-06-23 13:45:12.801429
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    print(AnsibleCollectionRef.is_valid_collection_name('not.a.valid.collection.name'))
    print(AnsibleCollectionRef.is_valid_collection_name('not_a_valid_collection_name'))
    print(AnsibleCollectionRef.is_valid_collection_name('not.a.valid.collection_name'))
    try:
        print(AnsibleCollectionRef.is_valid_collection_name('notavalidcollectionname'))
    except:
        pass
    try:
        print(AnsibleCollectionRef.is_valid_collection_name('not.'"'"'.a.valid.collection_name'))
    except:
        pass
    print(AnsibleCollectionRef.is_valid_collection_name('ns.collname'))

# Generated at 2022-06-23 13:45:24.730788
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    def assert_valid_collection_name(collection_name):
        assert AnsibleCollectionRef.is_valid_collection_name(collection_name)

    def assert_invalid_collection_name(collection_name):
        assert not AnsibleCollectionRef.is_valid_collection_name(collection_name)

    assert_valid_collection_name('foo.bar')
    assert_invalid_collection_name('foo')
    assert_invalid_collection_name('foo.')
    assert_invalid_collection_name('.bar')
    assert_invalid_collection_name('foo.bar.baz')
    assert_invalid_collection_name('foo.bar?')
    assert_invalid_collection_name('foo.bar-1')
    assert_invalid_collection_name('foo.bar*')
    assert_invalid

# Generated at 2022-06-23 13:45:37.391114
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """AnsibleCollectionRef.from_fqcr unit test"""

    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(u'ansible.netcommon.test', u'module_utils')
    # Validate the object's collection attribute
    assert ansible_collection_ref.collection == u'ansible.netcommon'

    # Validate the object's subdirs attribute
    assert ansible_collection_ref.subdirs == u'test'

    # Validate the object's resource attribute
    assert ansible_collection_ref.resource == u'test'

    # Validate the object's ref_type attribute
    assert ansible_collection_ref.ref_type == u'module_utils'

    # Validate the object's n_python_collection_package_name attribute
    assert ansible_collection_ref

# Generated at 2022-06-23 13:45:50.801713
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import re
    from ansible_collections.ansible.misc.tests.unit import MockModuleSpec

    test_module_path = 'ansible_collections.ansible.misc.plugins.module.testmod'

    finder = MockModuleSpec.Finder()
    finder.register_spec(MockModuleSpec.make_spec(test_module_path, list(), parent_package_name='ansible_collections'))

    loader = _AnsibleCollectionPkgLoaderBase(test_module_path, ['path'])
    module = loader.load_module(test_module_path)
    assert isinstance(module, types.ModuleType)
    assert module.__name__ == test_module_path
    assert module.__loader__ == loader

# Generated at 2022-06-23 13:45:59.242968
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Init
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.mycollection.myns.mypkg1')
    loader._candidate_paths = ["/tmp"]
    loader._subpackage_search_paths = ['/tmp/mycollection/myns/mypkg1']
    loader._source_code_path = "/tmp/mycollection/myns/mypkg1/__init__.py"
    loader._decoded_source = None
    # Run
    result = loader.get_source(loader._fullname)
    # Verify
    assert(result == "")



# Generated at 2022-06-23 13:46:11.056963
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    simple_module = AnsibleCollectionRef.from_fqcr('mynamespace.mycollection.mymodule', 'module')
    assert simple_module.collection == 'mynamespace.mycollection'
    assert simple_module.subdirs == ''
    assert simple_module.resource == 'mymodule'
    assert simple_module.ref_type == 'module'
    assert simple_module.n_python_package_name == 'ansible_collections.mynamespace.mycollection.plugins.modules'
    assert simple_module.fqcr == 'mynamespace.mycollection.mymodule'
    assert simple_module.n_python_collection_package_name == 'ansible_collections.mynamespace.mycollection'


# Generated at 2022-06-23 13:46:18.868048
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with MockModule('test.namespace.collection.module') as mock_module:
        import test.namespace.collection.module
        mock_module_vars = [
            'test.namespace.collection',
            'test.namespace.collection.module',
            'test.namespace.collection.module.__name__',
            'test.namespace.collection.module.__package__',
            'test.namespace.collection.module.__loader__',
        ]
        with _fake_redirect_loader(mock_module_vars, mock_module):
            import ansible.internal.module_utils.module


# Generated at 2022-06-23 13:46:27.820367
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    tmpdir = tempfile.mkdtemp(prefix='_AnsibleCollectionPkgLoaderBase_get_data')

    path = os.path.join(tmpdir, 'z.py')
    with open(path, 'w') as f:
        f.write('#!/usr/bin/env python\n')
        f.write('# -*- coding: utf-8 -*-\n')
        f.write('\n')
        f.write('\n')
        f.write('def main():\n')
        f.write('    pass\n')
        f.write('\n')
        f.write('\n')
        f.write('if __name__ == "__main__":\n')
        f.write('    main()\n')
        f.write('\n')

    #

# Generated at 2022-06-23 13:46:37.843861
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    c = _AnsibleCollectionFinder()
    c.find_module('mypkg.mycoll.mymodule', path=['/foo'])
    c.find_module('mypkg.mycoll.mymodule', path=['/foo', 'bar'])
    c.find_module('mypkg.mycoll', path=['/foo'])
    c.find_module('ansible_collections.mypkg.mycoll', path=['/foo'])
    c.find_module('ansible_collections', path=['/foo'])
    c.find_module('ansible', path=['/foo'])

# Generated at 2022-06-23 13:46:44.417495
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():

    # Arrange
    collection_finder = _AnsibleCollectionFinder()
    pathctx = 'any/path'
    finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    prefix = 'ansible_collections.'

    # Act
    actual = finder.iter_modules(prefix)

    # Assert
    assert list(actual) == []


# Generated at 2022-06-23 13:46:54.074019
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert isinstance(collection_finder, _AnsibleCollectionFinder)
    assert len(collection_finder._n_collection_paths) == 0
    return collection_finder


if PY3:
    def _module_repr(module):
        return '<module {0} ({1})>'.format(module.__name__, module.__file__)
else:
    def _module_repr(module):
        return '<module {0} from {1}>'.format(module.__name__, module.__file__)



# Generated at 2022-06-23 13:47:02.209344
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # testings for a single path
    test_finder = _AnsibleCollectionFinder()
    test_finder.set_playbook_paths('/test/path/collections')
    assert test_finder._n_playbook_paths == ['/test/path/collections']

    # testings for a list of paths
    test_finder.set_playbook_paths(['/test/path/collections', '/test/path1/collections'])
    assert test_finder._n_playbook_paths == ['/test/path/collections', '/test/path1/collections']

    # testings for a string with multiple paths
    test_finder.set_playbook_paths('/test/path/collections:/test/path1/collections')
    assert test_finder._n_playbook_paths

# Generated at 2022-06-23 13:47:12.359171
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():

    # Setup
    test_path = '/path/to/some/package'
    test_prefix = 'ns_prefix.'
    expected_return = []

    # Override methods and attributes
    class _AnsibleCollectionPkgLoaderBase1(object):
        @staticmethod
        def _module_file_from_path(leaf_name, path):
            return None, False, None
    _AnsibleCollectionPkgLoaderBase1.is_package = _AnsibleCollectionPkgLoaderBase.is_package
    _AnsibleCollectionPkgLoaderBase1.iter_modules = _AnsibleCollectionPkgLoaderBase.iter_modules
    _AnsibleCollectionPkgLoaderBase1.__init__ = lambda *args, **kwargs: None

# Generated at 2022-06-23 13:47:24.087392
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    cls = _AnsibleCollectionPkgLoaderBase
    test_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    test_file=os.path.join(test_dir,'test.data')
    os.makedirs(os.path.dirname(test_file),exist_ok=True)
    with open(test_file,'w') as f:
        f.write("Test")
    test_file2=os.path.join(test_dir,'test1.data')
    os.makedirs(os.path.dirname(test_file2),exist_ok=True)
    with open(test_file2,'w') as f:
        f.write("Test")
    out = cls.get_data(test_file)


# Generated at 2022-06-23 13:47:32.943902
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/path/to/ansible_collections'])
    assert loader._fullname == 'ansible_collections'
    assert loader._split_name == ['ansible_collections']
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._candidate_paths == ['/path/to/ansible_collections/ansible_collections']
    assert loader._subpackage_search_paths == []



# Generated at 2022-06-23 13:47:44.794647
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.testns1.testcoll1.testsubcoll1',
        path_list=['/root/ansible_collections']
    )
    result = loader.get_source(fullname=loader._fullname)
    assert result is None

    loader._source_code_path = '/root/ansible_collections/testns1/testcoll1/testsubcoll1/__init__.py'
    with open(loader._source_code_path, 'rb') as fd:
        encoded_source = fd.read()
        decoded_source = encoded_source.decode('utf-8')
    result = loader.get_source(fullname=loader._fullname)
    assert result == decoded_source
    result = loader

# Generated at 2022-06-23 13:47:50.895148
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns..coll')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.ns')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'ns.coll.ns.coll')

    # not keywords when we

# Generated at 2022-06-23 13:48:01.773077
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test cases of valid inputs
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_collection.my_module', u'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_collection.my_module', u'modules') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_collection.my_module') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_collection.my_module.my_role', u'role') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_collection.my_module.my_role', u'roles') == True

# Generated at 2022-06-23 13:48:11.715622
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    sys.path_importer_cache.clear()
    finder = _AnsibleCollectionFinder()

    finder.set_playbook_paths(['/usr/share/ansible/collections'])
    sys.path_hooks.insert(0, finder._ansible_collection_path_hook)
    finder.find_module('ansible.module_utils.basic')
    assert 'ansible.module_utils.basic' in sys.modules

    # uncache the module_util
    del sys.modules['ansible.module_utils.basic']

    # When there is no module_utils folder in collections path
    finder.set_playbook_paths(['/nonexistent/path'])

# Generated at 2022-06-23 13:48:20.852326
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # Test with a path that doesn't exist
    paths = ["path_to_file"]
    test_finder = _AnsibleCollectionFinder(paths=paths)
    assert test_finder.find_module('ansible', path=None) is None

    # Test with a path that exist
    paths = [ANSIBLES_PATH]
    test_finder = _AnsibleCollectionFinder(paths)
    assert test_finder.find_module('ansible', path=None) is not None
    assert test_finder.find_module('ansible_collections.ns.collection', path=None) is not None




# Generated at 2022-06-23 13:48:31.629534
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # Make sure an importer for the ansible_collections toplevel is created
    import_path_list = ['/tmp']
    pkg_loader = _AnsibleCollectionRootPkgLoader('ansible_collections', import_path_list)
    assert pkg_loader._fullname == 'ansible_collections'
    assert pkg_loader._split_name == ['ansible_collections']
    assert pkg_loader._rpart_name == ('', 'ansible_collections', '')
    assert pkg_loader._parent_package_name == ''
    assert pkg_loader._package_to_load == 'ansible_collections'
    assert pkg_loader._source_code_path is None
    assert pkg_loader._decoded_source is None

# Generated at 2022-06-23 13:48:40.313346
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # Missing string argument
    caught = False
    try:
        _AnsibleCollectionLoader()
    except TypeError:
        caught = True
    assert caught

    # Missing collection_paths argument
    caught = False
    try:
        _AnsibleCollectionLoader(fullname=None)
    except TypeError:
        caught = True
    assert caught

    # Invalid fullname argument
    caught = False
    try:
        _AnsibleCollectionLoader(fullname='.', collection_paths=[])
    except ImportError:
        caught = True
    assert caught

    caught = False
    try:
        _AnsibleCollectionLoader(fullname='..', collection_paths=[])
    except ImportError:
        caught = True
    assert caught


# Generated at 2022-06-23 13:48:51.136258
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # TODO: mock
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    with pytest.raises(ImportError, match='not interested'):
        loader = _AnsibleInternalRedirectLoader("invalid_name", None)
    with pytest.raises(ImportError, match='not redirected'):
        loader = _AnsibleInternalRedirectLoader("ansible.module_utils.mathstuff.logger", None)
    loader = _AnsibleInternalRedirectLoader("ansible.module_utils.module_docs_fragments", None)
    assert loader._redirect == 'ansible.module_utils.mathstuff.logger'



# Generated at 2022-06-23 13:49:00.036714
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    name1 = 'ansible.config.manager'
    path1 = ['/tmp/ansible_collections']
    name2 = 'ansible.utils.color'
    path2 = [path1[0]]
    name3 = 'ansible.utils.color.ansible_color.AnsiColorizer'
    path3 = [path1[0]]
    name4 = 'ansible.color'
    path4 = [path1[0]]
    name5 = 'ansible.color.ansible_color.AnsiColorizer'
    path5 = [path1[0]]

# Generated at 2022-06-23 13:49:03.907241
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # Mock grouped parameters
    path = 'path'

    # Execute the method under test
    result = _AnsiblePathHookFinder(path=path).__repr__()

    # Check the result
    assert(result is not None)



# Generated at 2022-06-23 13:49:11.845249
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import sys
    import types
    import collections.abc

    test_module = types.ModuleType("ansible_collections")
    # test_module.__file__ = "/path/to/ansible_collections"
    # test_module.__package__ = "ansible_collections"
    # test_module.__path__ = ["path/to/ansible_collections/__init__.py"]
    sys.modules["ansible_collections"] = test_module

    # test_loader_module = types.ModuleType("ansible.utils.collection_loader")
    # sys.modules["ansible.utils.collection_loader"] = test_loader_module


# Generated at 2022-06-23 13:49:20.698861
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    collection_finder = _AnsibleCollectionFinder()
    # Note: we explicitly test the case of passing duplicate paths
    collection_finder.set_playbook_paths(['/var/lib/awx/projects/test1/collections', '/var/lib/awx/projects/test1/collections'])
    assert len(collection_finder._n_playbook_paths) == 1
    assert '/var/lib/awx/projects/test1/collections' in collection_finder._n_playbook_paths
    assert '/var/lib/awx/projects/test1/collections' in collection_finder._n_cached_collection_qualified_paths



# Generated at 2022-06-23 13:49:31.348097
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # test valid collection references
    valid_references = [
        'namespace.collection.subdir1.subdir2.resource',
        'namespace.collection.resource',
        'namespace.collection.subdir1_subdir2.resource',
        'namespace.collection.subdir1.subdir2_subdir3.resource',
        'namespace.collection.subdir1.subdir2_subdir3.subdir4.resource',
        'namespace.collection.subdir1.subdir2.subdir3.subdir4_subdir5.subdir6.subdir7.subdir8.resource',
    ]

    for ref in valid_references:
        ar = AnsibleCollectionRef.from_fqcr(ref, 'plugin')
        assert ar._fqcr == ref

    # test invalid collection

# Generated at 2022-06-23 13:49:42.386705
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # collection path the same as ansible package path
    paths = [os.path.dirname(sys.modules['ansible'].__file__)]
    assert _AnsibleCollectionFinder(paths)._ansible_pkg_path \
        == os.path.dirname(sys.modules['ansible'].__file__)
    # ansible package path is not in the collection paths
    assert os.path.dirname(sys.modules['ansible'].__file__) \
        not in _AnsibleCollectionFinder(paths)._n_collection_paths
    # the collection path with 'ansible_collections' added should be in the collection paths
    paths = [os.path.join(os.path.dirname(sys.modules['ansible'].__file__), "ansible_collections")]

# Generated at 2022-06-23 13:49:54.620919
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import tempfile
    import unittest


    class Test(unittest.TestCase):
        def test_get_filename_with_package(self):
            with tempfile.TemporaryDirectory() as tmpdir:
                pkgdir = os.path.join(tmpdir, 'ansible_collections', 'foo', 'bar')
                os.makedirs(pkgdir)
                with open(os.path.join(pkgdir, '__init__.py'), 'w'):
                    pass
                with open(os.path.join(pkgdir, 'baz.py'), 'w'):
                    pass

                loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')

# Generated at 2022-06-23 13:49:59.217128
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase()
    # code_obj = loader.get_code(fullname)
    assert (loader.get_code is not None)


# Generated at 2022-06-23 13:50:00.496867
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader(fullname='ansible_collections')



# Generated at 2022-06-23 13:50:11.458214
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # Create a test namespace object for testing the constructor of class _AnsibleCollectionPkgLoader
    test_namespace_obj = 'test_namespace'

    pkg_loader_obj = _AnsibleCollectionPkgLoader(namespace=test_namespace_obj, package_to_load='package_to_load_test')

    assert pkg_loader_obj._fullname == 'test_namespace.package_to_load_test'
    assert pkg_loader_obj._namespace == 'test_namespace'
    assert pkg_loader_obj._package_to_load == 'package_to_load_test'
    assert pkg_loader_obj._split_name == ['test_namespace', 'package_to_load_test']
    assert pkg_loader_obj._candidate_paths == {}
    assert p

# Generated at 2022-06-23 13:50:21.904168
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Test for: __init__(self, paths=None, scan_sys_paths=True)
    #
    # Usage: test__AnsibleCollectionFinder()
    #
    # Return: None
    #
    # Version: v1.0.1

    # It is hard to write unit tests for this class since the its properties rely on the operation system.
    # The version v1.0.0 is not able to test this constructor.
    # For this version, we only test whether the class is constructed as expected.

    # get the current ansible directory
    ansible_dir = os.path.dirname(sys.modules['ansible'].__file__)

    # create the _AnsibleCollectionFinder class
    c1 = _AnsibleCollectionFinder(ansible_dir, False)
    c2 = _An

# Generated at 2022-06-23 13:50:23.879961
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    _AnsibleCollectionFinder()


# Generated at 2022-06-23 13:50:35.795022
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_name = 'test_name'
    test_routing_entry = {'redirect': 'test_redirect'}
    test_redirect = 'test_redirect'
    test_builtin_meta = {'import_redirection': {test_name: test_routing_entry}}
    _AnsibleInternalRedirectLoader._get_collection_metadata = Mock(return_value=test_builtin_meta)
    _AnsibleInternalRedirectLoader.find_module = Mock(_AnsibleInternalRedirectLoader)
    _AnsibleInternalRedirectLoader.load_module = Mock(_AnsibleInternalRedirectLoader)
    _AnsibleInternalRedirectLoader.load_module._redirect = test_redirect

    import_module = Mock(return_value='test_module')
    sys = Mock()
    sys

# Generated at 2022-06-23 13:50:47.653878
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible_collections.foo.bar.plugins.module_utils import basic
    from ansible_collections.foo.bar.plugins.modules import copy
    from ansible_collections.foo.bar.plugins.modules import file
    from ansible_collections.foo.vector.plugins.module_utils import basic
    from ansible_collections.foo.vector.plugins.modules import copy
    from ansible_collections.foo.vector.plugins.modules import file
    import ansible_collections.foo.bar.plugins.modules.copy
    import ansible_collections.foo.bar.plugins.modules.file
    import ansible_collections.foo.vector.plugins.modules.copy
    import ansible_collections.foo.vector.plugins.modules.file
    import ansible_collections.foo.bar.plugins.module

# Generated at 2022-06-23 13:50:56.525356
# Unit test for method __repr__ of class AnsibleCollectionRef

# Generated at 2022-06-23 13:51:07.111138
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test a non-ansible import, this should not be accepted
    loader = _AnsibleInternalRedirectLoader('os.path', None)
    assert not loader._redirect

    # test a valid ansible import, it should accept it and set the redirect
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.os.path', None)
    # we should have a redirect set
    assert loader._redirect == 'os.path'

    # test a valid import that has no redirect set
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.ansible_galaxy_cli', None)
    # no redirect set for this one
    assert not loader._redirect


# create a collection config object and nuke the old one

# Generated at 2022-06-23 13:51:16.673359
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # no args, with args
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens', ['/foo/bar', '/baz/qux'])
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens', ['/foo/bar/', '/baz/qux/'])
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens', [])
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens', ['/foo/bar', '/baz/qux'])

# Generated at 2022-06-23 13:51:23.357113
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ansible', ['/root/ansible_collections'])
    assert loader._fullname == 'ansible_collections.ansible'
    assert loader._split_name == ['ansible_collections', 'ansible']
    assert loader._rpart_name == ('ansible_collections', '.', 'ansible')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'ansible'
    assert loader._subpackage_search_paths == ['/root/ansible_collections/ansible']
    assert loader._candidate_paths == ['/root/ansible_collections/ansible']
    assert loader._package_to_load == 'ansible'

# Implements

# Generated at 2022-06-23 13:51:31.557069
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # pylint: disable=protected-access
    collection_finder = _AnsibleCollectionFinder()
    assert 'ansible' == collection_finder._ansible_pkg_path
    assert not collection_finder._n_configured_paths
    assert not collection_finder._n_cached_collection_paths
    assert not collection_finder._n_cached_collection_qualified_paths
    assert not collection_finder._n_playbook_paths

    # TODO: add test for import sanity test providing a different impl
    assert _meta_yml_to_dict is not None



# Generated at 2022-06-23 13:51:40.304508
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    test_case__AnsibleCollectionPkgLoaderBase_get_filename = _AnsibleCollectionPkgLoaderBase_get_filename(
        'test__AnsibleCollectionPkgLoaderBase_get_filename',
        'test__AnsibleCollectionPkgLoaderBase_get_filename')
    assert test_case__AnsibleCollectionPkgLoaderBase_get_filename.get_filename('test__AnsibleCollectionPkgLoaderBase_get_filename') == '<ansible_synthetic_collection_package>'

test__AnsibleCollectionPkgLoaderBase_get_filename()



# Generated at 2022-06-23 13:51:47.429896
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import unittest

    class TestFindModule(unittest.TestCase):

        def test_find_module(self):
            finder = _AnsiblePathHookFinder(collection_finder=None, pathctx='pathctx')
            self.assertIsNone(finder.find_module('test'))
            self.assertIsNotNone(finder.find_module('ansible'))
            self.assertIsNotNone(finder.find_module('ansible_collections'))

    unittest.main()


# TODO: cache results for finder lookup

# Generated at 2022-06-23 13:51:58.455711
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # ansible_collections/foo/bar/baz/__init__.py
    test_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'loader_util_data',
        'ansible_collections',
        'foo',
        'bar',
        'baz',
        '__init__.py',
    )
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar.baz', path_list=[test_path])
    assert loader.is_package('ansible_collections.foo.bar.baz') is True

# Generated at 2022-06-23 13:52:07.306079
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from tests.compat import patch
    from mock import Mock

    AnsibleCollectionConfig.__init__ = Mock()
    AnsibleCollectionConfig.__init__.return_value = None

    AnsibleCollectionConfig.init_config_definitions = Mock()
    AnsibleCollectionConfig.init_config_definitions.return_value = None

    AnsibleCollectionConfig.on_collection_load = Mock()
    AnsibleCollectionConfig.on_collection_load.fire = Mock()
    AnsibleCollectionConfig.on_collection_load.fire.return_value = None


# Generated at 2022-06-23 13:52:13.021887
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # The constructor of class _AnsibleCollectionNSPkgLoader will pass
    # if run the first 10 lines
    path_list = ['dummy']
    fullname = 'ansible_collections.dummy'
    t = _AnsibleCollectionNSPkgLoader(fullname, path_list=path_list)
    pass


# Loads a Python collection package, which includes implicit package support (package dirs with no package init code)
# and a __main__.py file. This loader has no behavior around how the collection is loaded; it only handles
# the Python-level code files and implicit packages.

# Generated at 2022-06-23 13:52:22.238485
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    a = AnsibleCollectionRef('test', '', 'foo', 'module')
    assert a.is_valid_fqcr("test.foo", "module") is True
    assert a.is_valid_fqcr("test.foo", "module") is True
    assert a.is_valid_fqcr("test.foo") is True
    assert a.is_valid_fqcr("test.foo.bar") is False
    assert a.is_valid_fqcr("test.foo.", "module") is False



# Generated at 2022-06-23 13:52:26.591142
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    module_name = 'ansible_collections.ansible_collections.my_namespace.my_collection.plugins.modules.my_module'
    test_module = _AnsiblePathHookFinder.find_module(module_name)
    assert test_module.__name__ == module_name


# Generated at 2022-06-23 13:52:29.167948
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(None, None).__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'

# Generated at 2022-06-23 13:52:36.263890
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # This test only check constructor of class AnsibleCollectionRef,
    # but not other methods

    # Test 1:
    # If a ref has no field collection
    # It should raise ValueError
    try:
        AnsibleCollectionRef('foo.bar', 'baz', 'qux', 'quux')
    except ValueError:
        pass
    except Exception:
        raise AssertionError("testcase test_AnsibleCollectionRef: test 1 failed")
    else:
        raise AssertionError("testcase test_AnsibleCollectionRef: test 1 failed")

    # Test 2:
    # If a ref has field collection but with illegal format
    # It should raise ValueError
    try:
        AnsibleCollectionRef('foo.barbaz', 'baz', 'qux', 'quux')
    except ValueError:
        pass

# Generated at 2022-06-23 13:52:46.985059
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    expected = "{0}(path='')".format('_AnsiblePathHookFinder')
    result = _AnsiblePathHookFinder(collection_finder=None, pathctx=None).__repr__()
    assert expected == result


# Generated at 2022-06-23 13:52:55.381323
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    import unittest2
    import importlib._bootstrap
    class _TestAnsibleCollectionPkgLoaderBase(importlib._bootstrap._AnsibleCollectionPkgLoaderBase):
        def iter_modules(self, prefix):
            return None
    class Test__AnsibleCollectionPkgLoaderBase___repr__(unittest2.TestCase):
        m = _TestAnsibleCollectionPkgLoaderBase(None, None)
        repr_ = repr(m)
        status = repr_.find("path=None")
        assert status != -1


# Generated at 2022-06-23 13:53:04.602988
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Create an instance of _AnsibleCollectionPkgLoaderBase
    fullname = 'ansible_collections.ns.some_collection.some_ns.some_pkg'
    
    # Create an instance of _AnsibleCollectionPkgLoaderBase
    loader_instance = _AnsibleCollectionPkgLoaderBase(fullname)
    
    # Get data from loader instance
    path = os.path.join('/', 'root', 'ansible_collections', 'ns', 'some_collection', 'some_ns', 'some_pkg', '__init__.py')
    data = loader_instance.get_data(path)
    
    # Get path and data from loader instance

# Generated at 2022-06-23 13:53:15.476431
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Positive cases-------------------------------------------------------------------------------------------------
    # case: collection reference with one subdir and the resource file has the required extension
    test1 = AnsibleCollectionRef('ns.coll', 'subdir1', 'test_handler.py', 'module')
    assert test1.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.module'

    # case: collection reference with two subdirs and the resource file has the required extension
    test2 = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'test_handler.py', 'role')
    assert test2.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.subdir2.role'

    # case: collection reference with three subdirs and the resource file has the required extension


# Generated at 2022-06-23 13:53:19.821802
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    obj = _AnsiblePathHookFinder(collection_finder=None, pathctx='/test/test/test')
    assert obj._pathctx == '/test/test/test'
    assert obj._collection_finder is None
    assert obj._file_finder is None



# Generated at 2022-06-23 13:53:28.988799
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # noinspection PyUnusedLocal
    module_file_from_path = _AnsibleCollectionNSPkgLoader._module_file_from_path
    with pytest.raises(ValueError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.foo', ['/tmp'])
    with pytest.raises(ValueError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.foo.bar', ['/tmp'])
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.ansible', ['/tmp'])
    _AnsibleCollectionNSPkgLoader('ansible_collections.ansible.builtin', ['/tmp'])
    # noinspection PyStatementEffect
    module_file_from_path




# Generated at 2022-06-23 13:53:34.002515
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    """
    Unit test for constructor of class _AnsibleInternalRedirectLoader
    """

    invalid_tests = [
        ('', [])
    ]

    for fullname, path_list in invalid_tests:
        loader = None
        try:
            loader = _AnsibleInternalRedirectLoader(fullname, path_list)
        except ImportError:
            # this is what we want to see
            pass


# Generated at 2022-06-23 13:53:38.658430
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('foo')
    loader._subpackage_search_paths = []
    loader.get_code('foo')
    with pytest.raises(ValueError):
        loader.get_code('bar')
    loader._subpackage_search_paths = None
    loader._source_code_path = 'bar'
    loader.get_code('foo')
    with pytest.raises(ValueError):
        loader.get_code('bar')

