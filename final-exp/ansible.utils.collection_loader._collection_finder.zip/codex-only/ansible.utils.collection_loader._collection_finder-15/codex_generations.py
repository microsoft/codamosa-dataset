

# Generated at 2022-06-23 13:43:41.396373
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'filter_plugins') == u'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'library') == u'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'libraries') == u'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'module_utils') == u'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'callback_plugins') == u'callback'

    # FUT

# Generated at 2022-06-23 13:43:47.722031
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections")
    try:
        loader.get_source(fullname="ansible_collections.group1.collection1")
    except ValueError as e:
        assert str(e) == 'this loader cannot load source for ansible_collections.group1.collection1, only ansible_collections'
        return

    raise AssertionError('expected exception for value not matching self._fullname')

# Generated at 2022-06-23 13:43:52.140812
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with a valid reference
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.coll.subdir1.resource", u"module")
    # Test with an invalid reference
    assert AnsibleCollectionRef.try_parse_fqcr(u"invalid_reference", u"module") is None


# Generated at 2022-06-23 13:44:02.810774
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():

    # "Fixture" for the test.
    def _create_mock_path_hook_finder():
        class _MockPathHookFinder(_AnsiblePathHookFinder):
            def __init__(self):
                self._collection_finder = None
                self._pathctx = None
                self._file_finder = None

            def find_module(self, fullname, path=None):
                return None

            def iter_modules(self, prefix):
                return []

        path_hook_finder = _MockPathHookFinder()
        return path_hook_finder
    # Test that iter_modules works as intended when path list is empty
    def test_that_iter_modules_returns_empty_when_path_is_empty():
        path_hook_finder = _create_mock_path_hook_

# Generated at 2022-06-23 13:44:10.205740
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # test for Py3
    assert isinstance(_AnsiblePathHookFinder({'ansible_collections': 'good_path'}, 'good_path'), _AnsiblePathHookFinder)

    # test for Py2 - sys.path_hooks is a list of callable objects
    # temporarily replace the original attr of sys.path_hooks with a list of callable objects
    import sys
    import os
    original_path_hooks = sys.path_hooks
    sys.path_hooks = [os.getcwd]
    assert isinstance(_AnsiblePathHookFinder({'ansible_collections': 'good_path'}, 'good_path'), _AnsiblePathHookFinder)
    sys.path_hooks = original_path_hooks


# Used for routing `ansible

# Generated at 2022-06-23 13:44:16.705537
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # _AnsibleInternalRedirectLoader.__init__(self, fullname, path_list)
    _AnsibleInternalRedirectLoader_non_redirect_fullname = 'ansible.test'
    _AnsibleInternalRedirectLoader_redirect_fullname = 'ansible._ansible.test'

    fullname = _AnsibleInternalRedirectLoader_non_redirect_fullname
    path_list = None
    obj = _AnsibleInternalRedirectLoader(fullname, path_list)
    try:
        obj.load_module(fullname)
    except ImportError as e:
        pass

    fullname = _AnsibleInternalRedirectLoader_redirect_fullname
    path_list = None
    obj = _AnsibleInternalRedirectLoader(fullname, path_list)

# Generated at 2022-06-23 13:44:27.653670
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = AnsibleCollectionRef()
    assert ref.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resourcename') is True
    assert ref.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resourcename.py') is True
    assert ref.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resourcename.yaml') is True
    assert ref.is_valid_fqcr('ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.resourcename.yml') is True
    assert ref.is_

# Generated at 2022-06-23 13:44:39.150882
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Note: All tests should fail with a Value exception.
    try:
        AnsibleCollectionRef('', '', '', '')
    except ValueError:
        pass
    else:
        raise AssertionError('Empty collection name should not be allowed')
    try:
        AnsibleCollectionRef(u'_my.collection', '', '', '')
    except ValueError:
        pass
    else:
        raise AssertionError('Unsupported collection name should not be allowed')
    try:
        AnsibleCollectionRef(u'_my.collection', '', '', '')
    except ValueError:
        pass
    else:
        raise AssertionError('Unsupported collection name should not be allowed')

# Generated at 2022-06-23 13:44:43.545596
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    acf = _AnsibleCollectionFinder(
        paths=['/tmp/sample_collections'],
        scan_sys_paths=False,
    )

    loader = acf.find_module('ansible_collections.ns.foo')
    assert isinstance(loader, _AnsibleCollectionLoader)



# Generated at 2022-06-23 13:44:52.396105
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    import pytest
    # test with valid FQCR's
    ref=AnsibleCollectionRef('k8s.namespace', '', 'namespace', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr(ref.fqcr)
    ref=AnsibleCollectionRef('k8s.namespace', '', 'namespace', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr(ref.fqcr, ref_type='module')
    ref=AnsibleCollectionRef('k8s.namespace_dir', 'dir1.dir2', 'namespace', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr(ref.fqcr, ref_type='module')

# Generated at 2022-06-23 13:45:02.584419
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    test_path = os.path.join(os.path.dirname(__file__), 'testdata')
    f = _AnsiblePathHookFinder('not a real collection finder', test_path)
    found = set(f.iter_modules(''))
    expected = {
        'testmodule',
        'testmodule.submodule',
        'testmodule_package',
        'testmodule_package.submodule',
        'testmodule_package.subpackage',
        'testmodule_package.subpackage.submodule',
        'testmodule_package_non_ansible_collections',
        'testmodule_package_non_ansible_collections.submodule'
    }
    assert found == expected


# Generated at 2022-06-23 13:45:08.416237
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    print("Testing method try_parse_fqcr of class AnsibleCollectionRef")
    test1 = 'test_plugin.testplugin.ping'
    test1_type = 'module'
    test2 = 'test_plugin.testplugin.testdir.ping'
    test2_type = 'module'
    test3 = 'test_plugin.testplugin.testdir.testdir2.ping'
    test3_type = 'module'
    test4 = 'test_plugin.testplugin.ping.yml'
    test4_type = 'playbook'
    test5 = 'test_plugin.testplugin.testdir.ping.yml'
    test5_type = 'playbook'
    test6 = 'test_plugin.testplugin.testdir.testdir2.ping.yml'

# Generated at 2022-06-23 13:45:17.112211
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

        def _validate_args(self):
            pass

    from ansible.plugins.loader import collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionNotFound
    loader = TestAnsibleCollectionPkgLoaderBase(
        'ansible.collections.testns.testcoll.testpkg',
        path_list=[collection_loader.get_collection_path('testns.testcoll')]
    )

# Generated at 2022-06-23 13:45:25.442707
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    with mock.patch('ansible.utils.plugin_docs.AnsiblePluginDocs.get_man_paths') as get_man_paths:
        with mock.patch.object(AnsiblePluginDocs, '__init__') as init:
            mock_manager = mock.MagicMock()
            init.return_value = None
            apd = AnsiblePluginDocs(mock_manager)
            apd.get_man_paths.return_value = ['/path/to/file']

            # Test for file name
            module_doc = 'module'
            man_doc = 'man'
            apd.get_docstring_obj.return_value = module_doc
            apd._read_doc_file.return_value = man_doc

            path = '/path/to/file1'
            doc

# Generated at 2022-06-23 13:45:37.798890
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:45:49.334714
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(name='ansible.builtin', path=None)
    print(loader.load_module(fullname='ansible.builtin'))
    print(loader)
    loader = _AnsibleCollectionPkgLoader(name='ansible.builtin', path='/root/ansible/ansible/config')
    print(loader.load_module(fullname='ansible.builtin'))
    print(loader.load_module(fullname='ansible.builtin.accelerate'))
    print(loader.load_module(fullname='ansible.builtin.accelerate.b'))


# Generated at 2022-06-23 13:45:51.363740
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert isinstance(_AnsibleCollectionFinder(['/tmp']), _AnsibleCollectionFinder)



# Generated at 2022-06-23 13:46:02.967001
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_obj = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.foo.bar',
        path_list=['/path/to/search']
    )

    # test an absolute path that actually exists
    test_obj._source_code_path = '/path/to/search/foo/bar/__init__.py'
    assert test_obj.get_data('/path/to/search/foo/bar/__init__.py') == b''

    # test an absolute path that doesn't exist
    assert not test_obj.get_data('/path/to/search/foo/bar/path/that/does/not/exist')

    # test a relative path
    assert test_obj.get_data('path/that/does/not/exist') == None

    # test an absolute path to

# Generated at 2022-06-23 13:46:14.414503
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    collection_name = u'ns.coll'
    subdirs = u'subdir1.subdir2'
    resource = u'resource'
    ref_type = u'role'
    ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type).fqcr
    assert ref == u'ns.coll.subdir1.subdir2.resource'
    assert AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)
    assert AnsibleCollectionRef.from_fqcr(ref, ref_type).fqcr == ref
    collection_name = u'ns.coll'
    subdirs = None
    resource = u'resource'
    ref_type = u'role'

# Generated at 2022-06-23 13:46:20.430661
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():  # pylint:disable=unused-variable
    collection_finder = _AnsibleCollectionFinder()
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, 'testing/ansible/collections')
    assert ansible_path_hook_finder.find_module('ansible.playbooks')
    assert ansible_path_hook_finder.find_module('ansible_collections.ns.collection.module')
    assert ansible_path_hook_finder.iter_modules('ansible_collections.ns.collection')
    assert repr(ansible_path_hook_finder) == '_AnsiblePathHookFinder(path=\'testing/ansible/collections\')'


# Internal alternative to os.listdir that always returns utf8 for convenience
# TODO: remove this

# Generated at 2022-06-23 13:46:26.632070
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    modname = 'ansible.parsing.yaml.objects'
    class test_module(object): pass
    class test_sys(object):
        modules = {'ansible.parsing.yaml.objects': test_module()}
    loader = _AnsibleInternalRedirectLoader(modname, None)
    loader.load_module(modname)
    with pytest.raises(ValueError):
        l = _AnsibleInternalRedirectLoader(None, None)
        l.load_module(None)

# Generated at 2022-06-23 13:46:31.009045
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    path_list = ["/Users/gjanssen/ansible/collections/ansible_collections/ansible/plugins/modules", "/Users/gjanssen/ansible/collections/ansible_collections/ansible/plugins/modules"]
    for _path in path_list:
        for name, is_pkg in _iter_modules_impl([_path], None):
            print(name, is_pkg)

# Generated at 2022-06-23 13:46:34.823226
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    with patch('ansible_collections.ansible.builtins.loader.get_collection_roots'):
        path_list = ['/root1', '/root2']
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.my_ns', path_list=path_list)
        assert loader._candidate_paths == ['/root1/my_ns', '/root2/my_ns']


# Implements the reference implementation of implicit implicit package support
# (package dir, no __init__.py).

# Generated at 2022-06-23 13:46:40.619370
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Initialize a AnsibleCollectionRef instance
    ref = AnsibleCollectionRef('collection', 'subdirs', 'resource', 'ref_type')

    # Represent the instance of class AnsibleCollectionRef as a string
    result = ref.__repr__()

    assert result == "AnsibleCollectionRef(collection='collection', subdirs='subdirs', resource='resource')"

# Generated at 2022-06-23 13:46:53.497418
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    '''
    check if method load_module of class _AnsibleCollectionPkgLoaderBase_load_module is work as expected
    '''

    # check if there is no code object for a module
    code_object = None
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test')
    module = loader.load_module('ansible_collections.test')
    assert module.__loader__ is loader
    assert module.__code__ is code_object
    assert module.__file__ == '<ansible_synthetic_collection_package>'
    assert module.__package__ == 'ansible_collections.test'
    assert module.__name__ == 'ansible_collections.test'
    assert module.__path__ == loader._subpackage_search_paths
    assert module.__

# Generated at 2022-06-23 13:47:02.003816
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    #  if toplevel_pkg not in ['ansible', 'ansible_collections']:
    fullname = 'abc'
    path = None
    ansible_collection_finder = _AnsibleCollectionFinder()
    assert ansible_collection_finder.find_module(fullname, path) == None
    #  if part_count == 1:
    fullname = 'ansible'
    path = None
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(fullname=fullname, path_list=path)
    assert ansible_collection_finder.find_module(fullname, path) == ansible_internal_redirect_loader
    #  if part_count > 1 and path is None:
    fullname = 'ansible.abc'
    path = None

# Generated at 2022-06-23 13:47:03.065339
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: test coverage
    pass


# Generated at 2022-06-23 13:47:13.381054
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ''' test__AnsibleCollectionPkgLoaderBase_is_package
    Test cases for method _AnsibleCollectionPkgLoaderBase.is_package
    '''
    # Test cases for method _AnsibleCollectionPkgLoaderBase.is_package
    # Case 1: Test for valid result
    with pytest.raises(ValueError):
        loader = _AnsibleCollectionPkgLoaderBase(fullname = 'ansible_collections.ns')
        loader.is_package(fullname='ansible_collections.ns.pkg')

    # Case 2: Test for valid result
    loader = _AnsibleCollectionPkgLoaderBase(fullname = 'ansible_collections.ns.pkg')
    assert loader.is_package(fullname='ansible_collections.ns.pkg') is True

    # Case 3: Test for

# Generated at 2022-06-23 13:47:23.661911
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    tmpdir = tempfile.TemporaryDirectory()
    try:
        ldr = _AnsibleCollectionPkgLoaderBase('ansible_collections.foobar', [tmpdir.name])
        tmpdir.name = to_native(tmpdir.name)
        assert ldr.get_source('ansible_collections.foobar') is None
        filepath = os.path.join(tmpdir.name, '__init__.py')
        with open(filepath, 'wb') as f:
            f.write(b'test_data')
        assert ldr.get_source('ansible_collections.foobar') == b'test_data'
    finally:
        tmpdir.cleanup()



# Generated at 2022-06-23 13:47:30.726251
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # init args required for parent
    fullname = 'ansible_collections.my.collection'
    path_list = os.path.realpath(__file__)
    obj = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert obj.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'
    del fullname
    del path_list
    del obj


# Generated at 2022-06-23 13:47:43.929662
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    '''
    Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
    '''

    from mock import MagicMock
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Set up a test ansible Collection config object and
    # Collection Finder using a mock sys.path
    config = AnsibleCollectionConfig()
    cf = _AnsibleCollectionFinder(
        paths=['foo', 'bar', 'baz'],
        scan_sys_paths=False,
    )
    cf._install()
    config.collection_finder = cf
    sys = MagicMock()
    sys.path = []
    sys.path.extend(['foo', 'bar', 'baz'])

    #

# Generated at 2022-06-23 13:47:52.812550
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Init test variables
    collection_finder = _AnsibleCollectionFinder(paths=['~/ansible'], scan_sys_paths=True)
    fullname = '~/ansible/collections'
    path_context = '~/ansible'

    result = collection_finder.find_module(fullname=fullname, path=path_context)
    assert result[0] != None, "Failed to find module {}".format(fullname)
    assert result[1] == '.py', "Failed to find module {}".format(fullname)
    



# Generated at 2022-06-23 13:48:02.726448
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:48:09.623128
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    pkg = 'ansible_collections.namespace.collection.subcollection'
    target_cls = _AnsibleCollectionDirectPkgLoader
    loader = target_cls(pkg)
    assert loader.is_package(pkg)

    pkg = 'ansible_collections.namespace.collection.subcollection.module'
    target_cls = _AnsibleCollectionRedirectLoader
    loader = target_cls(pkg)
    assert not loader.is_package(pkg)



# Generated at 2022-06-23 13:48:21.308329
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    import unittest
    import sys

    # We are testing a class inside a class, with private arguments.
    # Set up mocks as needed.
    class ModuleTypeMock(object):
        def __init__(self, name):
            self.name = name

    def _loader_mock_init(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    class LoaderMock(object):
        def __init__(self, *args, **kwargs):
            _loader_mock_init(self, *args, **kwargs)

        @staticmethod
        def _iter_modules_impl(paths, prefix):
            return []

    def _meta_yml_to_dict_mock(meta_yaml, meta_path):
        return dict()

# Generated at 2022-06-23 13:48:32.611851
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    tst = _AnsibleCollectionFinder()
    r1 = tst.find_module('ansible.playbook.play')
    r2 = tst.find_module('ansible_collections.somens.somecoll.someplugin')
    r3 = tst.find_module('ansible_collections.somens.somecoll')
    r4 = tst.find_module('ansible_collections')
    r5 = tst.find_module('ansible.module_utils')
    assert(isinstance(r1, _AnsibleInternalRedirectLoader))
    assert(isinstance(r2, _AnsibleCollectionLoader))
    assert(isinstance(r3, _AnsibleCollectionPkgLoader))
    assert(isinstance(r4, _AnsibleCollectionNSPkgLoader))
   

# Generated at 2022-06-23 13:48:42.350890
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    assert not AnsibleCollectionRef.is_valid_fqcr(u'a_role', u'role')

    assert not AnsibleCollectionRef.is_valid_fqcr(u'a_role.yml', u'role')

    assert AnsibleCollectionRef.is_valid_fqcr(u'a_role')

    assert AnsibleCollectionRef.is_valid_fqcr(u'a_role.yml')

    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.a_role')

    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.a_role', u'role')

    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.a_role.yml')


# Generated at 2022-06-23 13:48:54.153390
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils import collection_loader
    # Test for ansible.builtin
    # Use ansible.collection_loader.get_collection_name to make the import_module
    # work properly
    collection_name = collection_loader.get_collection_name('ansible.builtin')

# Generated at 2022-06-23 13:48:57.963026
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
	assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
	assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
	assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'modules'
	try:
		assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('Test')
	except ValueError as e:
		pass


# Generated at 2022-06-23 13:49:07.059302
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    """
    Method _AnsibleCollectionPkgLoaderBase.__repr__ should return the expected value.
    """
    # Initialize a _AnsibleCollectionPkgLoaderBase instance
    obj = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.my_namespace.my_collection',
        path_list=['/tmp/ansible_collections/my_namespace/my_collection'])
    # Execute the method
    val = obj.__repr__()
    # Check the result
    assert val == '_AnsibleCollectionPkgLoaderBase(path=/tmp/ansible_collections/my_namespace/my_collection)'

# Generated at 2022-06-23 13:49:13.445223
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.subdir2.resource', u'module')
    assert ansible_collection_ref.collection == u'ns.coll'
    assert ansible_collection_ref.subdirs == u'subdir1.subdir2'
    assert ansible_collection_ref.resource == u'resource'
    assert ansible_collection_ref.ref_type == u'module'

    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(u'ns.coll.rolename', u'role')
    assert ansible_collection_ref.collection == u'ns.coll'
    assert ansible_collection_ref.subdirs == u''

# Generated at 2022-06-23 13:49:14.006209
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert True

# Generated at 2022-06-23 13:49:25.510047
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    from ansible.errors import AnsibleUndefinedVariable

    # Arrange
    ref = "foo.bar.module_name"
    ref_type = 'module'
    variable_manager = mock.MagicMock(spec=Variables)
    variable_manager.get_vars = mock.MagicMock(
        spec=Variables.get_vars,
        return_value={
            "ansible_collection_path": ""
        }
    )
    variable_manager.extra_vars = dict()
    variable_manager.set_available_variables = mock.Mock(
        spec=Variables.set_available_variables
    )
    variable_manager.set_fact = mock.Mock(spec=Variables.set_fact)

    # Act
    actual = AnsibleCollectionRef.try_parse_fqcr

# Generated at 2022-06-23 13:49:27.894684
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():

    with pytest.raises(Exception):
        loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_collection_name.test_module_name')



# Generated at 2022-06-23 13:49:35.999626
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile
    import shutil
    import pkgutil
    import random
    import textwrap

    from ansible_collections.testns.testcoll import plugins

    # TODO(galaxy): move this to a module under unit/test/test_collections
    # Create a simple package in a temporary directory
    _NS = 'ansible_collections'
    _NAME = 'testns.testcoll'
    _PKG_NAME = 'testcoll'
    _MOD_NAME = 'foo'
    _MOD_DATA = 'bar'
    _MOD_WITH_ERROR_NAME = 'with_error'
    _MOD_WITH_ERROR_DATA = textwrap.dedent('''\
        def bar():
            raise Exception('test')
        ''')

    _TEST_COLLECTION_ROOT = None

# Generated at 2022-06-23 13:49:46.167841
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    import_ansible_module = import_module('ansible')
    ansible_path = os.path.dirname(import_ansible_module.__file__)
    ansible_modules_path = os.path.join(ansible_path, 'modules')
    collection_module_path = os.path.join(ansible_modules_path, 'my.custom.collection_module')

    # test for a collection module
    loader = _AnsibleCollectionPkgLoader('my.custom.collection_module', [collection_module_path])
    assert loader.get_filename('my.custom.collection_module') == os.path.join(collection_module_path, '__init__.py')
    assert loader.get_data(loader.get_filename('my.custom.collection_module')) is None



# Generated at 2022-06-23 13:49:49.887051
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test normal behavior
    # Test with arguments that would fail
    # Test with arguments that would fail
    pass



# Generated at 2022-06-23 13:49:58.888387
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    pass

    # TODO: add this back once we've decided how to unit test collection_finder bits
    # Test for the case where the abs path of the module to import is not in the sys.path.
    #import tempfile
    #import shutil
    #import os
    #import os.path
    #import importlib
    #tmpdir = tempfile.mkdtemp()

    #coll_dir_name = 'test_collection_dir'
    #coll_dir = os.path.join(tmpdir, coll_dir_name)
    #os.mkdir(coll_dir)

    #my_module_name = 'test_my_module'
    #my_module_file = os.path.join(coll_dir, my_module_name+'.py')
    #with open(my_module_file, 'w')

# Generated at 2022-06-23 13:50:08.950485
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    path_sep = ':'
    if os.name == 'nt':
        path_sep = ';'
    path_ctx = '/some/ansible/path/'
    path_hook_finder = _AnsiblePathHookFinder(path_ctx)
    assert path_hook_finder._pathctx == path_ctx
    assert path_hook_finder._collection_finder._ansible_pkg_path == path_ctx
    assert path_hook_finder._collection_finder._n_configured_paths == [path_ctx]
    assert path_hook_finder._collection_finder._n_playbook_paths == []
    fake_collection_finder = _AnsibleCollectionFinder(['/fake/path'])

# Generated at 2022-06-23 13:50:16.267217
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    fullname = 'ansible_collections.ns1.ns2.coll.mod'
    package_to_load = 'mod'
    paths = ['/path/to/mod.py']

    loader = _AnsibleCollectionLoader(fullname, package_to_load, paths)
    assert loader._fullname == 'ansible_collections.ns1.ns2.coll.mod'
    assert loader._package_to_load == 'mod'
    assert loader._candidate_paths == ['/path/to/mod.py']


# Generated at 2022-06-23 13:50:20.003513
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('foo.bar.baz', os.path.expanduser('~'))
    assert loader.__class__.__name__ == '_AnsibleCollectionLoader'
    assert loader._fullname == 'foo.bar.baz'
    assert loader._candidate_paths == [os.path.expanduser('~')]
    assert loader._split_name == ['foo', 'bar', 'baz']
    assert loader._package_to_load == 'baz'



# Generated at 2022-06-23 13:50:32.376990
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-23 13:50:39.235614
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Arrange
    _AnsiblePathHookFinder._filefinder_path_hook = None
    finder = _AnsiblePathHookFinder(None, 'test')

    # Act
    actual = finder.find_module('ansible.test')

    # Assert
    assert actual is None



# Implements most of the import protocol with one exception: the `load_module` method. This is intended to be used
# by an import context that doesn't do a lot of loading itself (eg the meta_path finder).

# Generated at 2022-06-23 13:50:45.120389
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    try:
        _AnsibleInternalRedirectLoader('ansible.builtin.unknown_plugin', None)
    except ImportError as ex:
        ansible_fqcn = '__main__.test__AnsibleInternalRedirectLoader'
        ansible_hash = aufteilung._default_hash_functions[ansible_fqcn](aufteilung._discovered_api_objects[ansible_fqcn])
        assert aufteilung._discovered_api_objects[ansible_fqcn]._result['data'][0] == ansible_hash



# Generated at 2022-06-23 13:50:55.436519
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    #
    # Test basic construction of a loader
    #
    source_code_path = "/some/package/__init__.py"
    subpackage_search_paths = ["/some/package/submodules"]
    loader = _AnsibleCollectionPkgLoaderBase(
        "foo.bar.baz",
        path_list=["/some/package"]
    )
    assert loader._source_code_path == source_code_path
    assert loader._subpackage_search_paths == subpackage_search_paths

    #
    # Test construction of a loader using the _AnsibleCollectionPkgLoaderBase's get_subpackage_search_paths
    # and _get_candidate_paths method to determine the subpackage search paths
    #

# Generated at 2022-06-23 13:51:06.946857
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # pylint: disable=unused-variable
    ansible_collections = ['base', 'test']

    # Assert that we can only load the ansible_collections toplevel package
    try:
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.test')
        assert True == False
    except ImportError:
        assert True == True

    # Assert that we can only load collections namespace packages
    try:
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections')
        assert True == True
    except ImportError:
        assert True == False

    # Assert that not finding ansible is an exception

# Generated at 2022-06-23 13:51:16.843029
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # NOTE: test values should be in native str to not rely on the host encoding
    VALID_COLLECTION_NAMES = [
        u'test.collection',
        u'test.collec_tion',
        u'test.Collection',
        u'test.collec-tion',
        u'test.collection1',
        u'test.collec.tion',
        u'test.1collection',
        u'test.collec_tion1',
        u'test.co-llect.ion',
        u'test.coll.ection',
        u'test.col.lection',
        u'test.c.ollection'
    ]

# Generated at 2022-06-23 13:51:22.597405
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    import tempfile

    # a package with submodules
    with tempfile.TemporaryDirectory() as tmpdir:
        pkg_path = os.path.join(tmpdir, 'ansible_collections', 'test', 'plugins', 'modules')
        os.makedirs(pkg_path)
        _, module_path = tempfile.mkstemp(dir=pkg_path, suffix='.py', prefix='test_')
        _, pkg_path_init = tempfile.mkstemp(dir=pkg_path, suffix='.py', prefix='__init__')

        loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.plugins.modules', path_list=[tmpdir])
        assert loader.get_filename('ansible_collections.test.plugins.modules') == pkg_path_init
       

# Generated at 2022-06-23 13:51:33.000545
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import imp
    import ansible.internal_redirect_loader as red_load
    sys.modules['ansible.utils.plugin_docs.__main__'] = 'mock_mod'
    assert red_load._AnsibleInternalRedirectLoader.load_module(None, 'ansible.utils.plugin_docs.__main__') == 'mock_mod'
    # if the method is changed, the above test can fail
    sys.modules.pop('ansible.utils.plugin_docs.__main__', None)
    imp.reload(red_load)

# Generated at 2022-06-23 13:51:44.127761
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='wb') as tf:
        tf.file.write(b'foo')
        tf.file.flush()

        loader = _AnsibleCollectionPkgLoaderBase('ansible.foo', path_list=tempfile.gettempdir())
        assert loader.get_data(tf.name) == b'foo'
        assert loader.get_data(os.path.join(tempfile.gettempdir(), 'foo')) is None
        assert loader.get_data(os.path.join(tempfile.gettempdir(), 'foo', '__init__.py')) == ''

        # can't really test packages that are on disk here


# HACK: only want to include this test if we're running ansible code from the source checkout (eg via tox)

# Generated at 2022-06-23 13:51:51.725212
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    dump_path = '/tmp/ansible/test_collections'
    valid_mod_path = 'ansible_collections.test_ns.test_coll.plugins.test_mod_name.py'
    valid_mod_content = 'def test_mod_name():\n    pass\n'
    os.makedirs(dump_path, exist_ok=True)
    with open(os.path.join(dump_path, valid_mod_path), 'w') as f:
        f.write(valid_mod_content)
    loader = _AnsibleCollectionPkgLoaderBase(valid_mod_path, [dump_path])
    assert loader.get_source(valid_mod_path) == valid_mod_content
    os.remove(os.path.join(dump_path, valid_mod_path))
   

# Generated at 2022-06-23 13:51:56.610401
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    pathctx = '__path_ctx__'
    collection_finder = None

    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    assert repr(ansible_path_hook_finder) == "_AnsiblePathHookFinder(path='__path_ctx__')"


# Called when a loader (eg _AnsibleCollectionLoader) needs to import something other than a collection, but which
# is still part of the Ansible world. Acts as a switchboard for directing imports to the correct loader for the
# thing being imported

# Generated at 2022-06-23 13:52:06.254966
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile
    import shutil
    finder = _AnsiblePathHookFinder(None, None)
    tmproot = tempfile.mkdtemp()
    dir_modules = os.path.join(tmproot, 'modules')
    shutil.copytree(os.path.join(os.path.dirname(__file__), 'test', 'data', 'test_module'), dir_modules)
    collection_paths = [dir_modules]
    os.mkdir(os.path.join(dir_modules, 'testdir'))
    shutil.copy(os.path.join(os.path.dirname(__file__), 'test', 'data', 'test_module.py'),
                os.path.join(dir_modules, 'testdir'))

# Generated at 2022-06-23 13:52:10.368412
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Prepare test data
    # TODO: fill in test data
    # Execute the code to be tested
    obj = _AnsiblePathHookFinder(None, None)
    # Verify the result
    assert True # TODO: implement your test here


# Generated at 2022-06-23 13:52:22.118648
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile
    testdir = tempfile.TemporaryDirectory()
    file1_path = os.path.join(testdir.name, '__init__.py')
    file2_path = os.path.join(testdir.name, 'foo.py')
    with open(file1_path, 'w') as fp:
        fp.write('')
    with open(file2_path, 'w') as fp:
        fp.write('')
    assert [module[1] for module in _AnsiblePathHookFinder(None, testdir.name).iter_modules(prefix='')] == ['foo']
    testdir.cleanup()



# Generated at 2022-06-23 13:52:31.250265
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # FIXME: should be in a unit test
    r = AnsibleCollectionRef(u'ns.coll', u'', u'resource', u'role')
    assert repr(r) == "AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='resource')"

    # FIXME: should be in a unit test
    r = AnsibleCollectionRef(u'ns.coll', u'subdir1.subdir2', u'resource', u'role')
    assert repr(r) == "AnsibleCollectionRef(collection='ns.coll', subdirs='subdir1.subdir2', resource='resource')"



# Generated at 2022-06-23 13:52:42.789328
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class x(_AnsibleCollectionPkgLoaderBase):
        def __init__(self):
            super(x, self).__init__(self)
        def _validate_final(self):
            self._subpackage_search_paths = 0
        def _synthetic_filename(self):
            return 1
        def _get_candidate_paths(self, path_list):
            return 2
    a = x()
    assert a.__repr__() == "_AnsibleCollectionPkgLoaderBase(path=0)"
    a._subpackage_search_paths = None
    a._source_code_path = '3'
    assert a.__repr__() == "_AnsibleCollectionPkgLoaderBase(path='3')"



# Generated at 2022-06-23 13:52:49.274464
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    """Unit test to ensure _AnsiblePathHookFinder is working as expected."""
    collection_finder = _AnsibleCollectionFinder()
    path_context = '.'
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, path_context)
    assert repr(ansible_path_hook_finder) == _AnsiblePathHookFinder.__name__ + "(path='.')"



# Generated at 2022-06-23 13:53:00.022883
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    arc = AnsibleCollectionRef
    assert arc.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert arc.legacy_plugin_dir_to_plugin_type('library') == 'module'
    assert arc.legacy_plugin_dir_to_plugin_type('modules') == 'module'
    assert arc.legacy_plugin_dir_to_plugin_type('roles') == 'role'
    assert arc.legacy_plugin_dir_to_plugin_type('playbooks') == 'playbook'
    assert arc.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert arc.legacy_plugin_dir_to_plugin_type('test_plugins') == 'test'


# Generated at 2022-06-23 13:53:08.659027
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:53:13.648188
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    class TestClass:
        @staticmethod
        def file_finder(package_name, paths):
            pass
    assert isinstance(_AnsibleCollectionPkgLoader('ansible_collections.namespace.collection', TestClass), _AnsibleCollectionPkgLoaderBase)


# Generated at 2022-06-23 13:53:25.965891
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    temp_dirpath = tempfile.mkdtemp()

# Generated at 2022-06-23 13:53:32.150301
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    """Unit test for method __repr__ of class _AnsiblePathHookFinder"""
    _AnsiblePathHookFinder._filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    obj = _AnsiblePathHookFinder(collection_finder=None, pathctx=None)
    res = obj.__repr__()
    assert res == "{0}(path='None')".format(obj.__class__.__name__)