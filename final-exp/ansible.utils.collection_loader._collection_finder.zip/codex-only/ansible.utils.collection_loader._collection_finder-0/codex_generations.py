

# Generated at 2022-06-23 13:43:41.308035
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import __main__

    finder = _AnsibleCollectionFinder()
    mymain = sys.modules["__main__"]
    mymain.__file__ = "mymain.py"
    mainpath = os.path.dirname(os.path.abspath(mymain.__file__))
    assert finder.find_module("this_should_never_exist") is None
    assert finder.find_module("ansible") is not None
    assert finder.find_module("ansible_collections") is not None
    assert finder.find_module("ansible_collections.ansible") is not None
    assert finder.find_module("ansible_collections.dummy") is not None
    assert finder.find_module("ansible_collections.ansible.test") is not None

# Generated at 2022-06-23 13:43:46.842803
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin', None)
    print(loader.load_module('ansible.builtin'))


# special module loader for handling imports from the top-level ansible namespace (e.g. ansible.version)
# modules in this namespace should be kept locked to a single collection, unlike submodules which can redirect

# Generated at 2022-06-23 13:43:53.348327
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    with open(os.devnull, 'w') as nullstream:
        with contextlib.redirect_stdout(nullstream):
            try:
                unittest.main(argv=['ansible.module_utils.six.moves._ansible_collections_finder'], verbosity=0, exit=False)
            except SystemExit:
                assert False, "test of __AnsiblePathHookFinder failed"
test__AnsiblePathHookFinder()

# TODO: make loaders come from the loader factory


# Generated at 2022-06-23 13:44:04.698213
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    collection_finder = _AnsibleCollectionFinder(paths=["/good/path/to/ansible_collections/somenamespace/somecollection"])
    collection_finder._install()
    try:
        apf = _AnsiblePathHookFinder(collection_finder, pathctx="/good/path/to/ansible_collections/somenamespace/somecollection/someplugin")
        assert len(apf._get_filefinder_path_hook()) == 1
        assert apf.__repr__() == "_AnsiblePathHookFinder(path='/good/path/to/ansible_collections/somenamespace/somecollection/someplugin')"
    finally:
        collection_finder._remove()


# Generated at 2022-06-23 13:44:12.953987
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-23 13:44:14.598367
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase.__repr__(None) == '_AnsibleCollectionPkgLoaderBase(path=None)'


# Generated at 2022-06-23 13:44:26.487109
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import unittest
    import sys
    from textwrap import dedent
    from shutil import rmtree
    from tempfile import mkdtemp
    from collections import namedtuple
    from ansible.module_utils.six import PY3

    # Base class for test cases
    class CollectionFinderTestCase(unittest.TestCase):
        class test_package_spec(namedtuple("test_package_spec", ['name', 'top_level', 'namespace', 'collection', 'sub_path', 'path'])):
            """
            Defines a specification for a package to be returned by find_module() and the expected attributes of the returned loader object
            """

# Generated at 2022-06-23 13:44:31.594207
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import os
    test_path = os.path.join(os.getcwd(),'unit_test')
    _AnsibleCollectionFinder._remove()
    ansible_collection_finder = _AnsibleCollectionFinder(test_path)
    return ansible_collection_finder._n_playbook_paths



# Generated at 2022-06-23 13:44:42.703400
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    class test_loader(_AnsibleCollectionPkgLoader):
        def __init__(self, path, fullname):
            super(test_loader, self).__init__(path, fullname)

    # Unit test for case that fullname is `ansible_collections.community.general.plugins`
    # and path is `/path/to/ansible_collections/community/general/plugins`
    name_1 = 'ansible_collections.community.general.plugins'
    path_1 = '/path/to/ansible_collections/community/general/plugins'
    test = test_loader(path_1, name_1)
    assert test._package_to_load == 'plugins'
    assert test._parent_package_name == 'ansible_collections.community.general'
    assert test._candidate_paths

# Generated at 2022-06-23 13:44:50.610370
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collections_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'ansible_collections',
    )
    ansible_collections_path = os.path.normpath(ansible_collections_path)
    assert _AnsiblePathHookFinder(None, ansible_collections_path)  # pylint: disable=protected-access


# this allows us to construct a collection finder from a path defined by either a file or a dir; if a directory,
# we find the matching collection meta dir and use it (otherwise we just use the provided path as-is)

# Generated at 2022-06-23 13:45:02.587441
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.import_plugins import import_plugin

# Generated at 2022-06-23 13:45:04.905609
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert 'action' == result

    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert 'modules' == result


# Generated at 2022-06-23 13:45:15.745698
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    expected = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource', 'module') == expected
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource', None) == expected

    expected = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource', 'role') == expected
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource', None) == expected

# Generated at 2022-06-23 13:45:25.745421
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('FooModule') is False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.FooModule') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.FooModule') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.FooModule.subdir2') is False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.FooModule.subdir2', 'module') is False

    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.FooModule.subdir2', 'role') is True

# Generated at 2022-06-23 13:45:37.923886
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.utils.collection_loader as collection_loader
    collection_loader._meta_yml_to_dict = _meta_yml_to_dict_stub
    result = {}
    def import_module_stub(name):
        result['name'] = name
        return {'import_module': result}
    setattr(collection_loader, 'import_module', import_module_stub)
    setattr(collection_loader._AnsibleInternalRedirectLoader, 'load_module', collection_loader._AnsibleInternalRedirectLoader.load_module)
    collection_loader.AnsibleCollectionConfig.on_collection_load = collection_loader.AnsibleCollectionConfig.on_collection_load

# Generated at 2022-06-23 13:45:43.972376
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    expected_result = "_AnsiblePathHookFinder(path='pathctx')"
    actual_result = _AnsiblePathHookFinder(None, 'pathctx').__repr__()
    assert actual_result == expected_result


# TODO: eliminate all these, they should just be PathImporter instances

# Generated at 2022-06-23 13:45:56.410193
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # Constructor with invalid fullname
    try:
        _AnsibleCollectionLoader(None)
    except ImportError as e:
        assert "fullname" in e.args[0]
        assert "None" in e.args[0]

    # Constructor with wrong fullname format
    try:
        _AnsibleCollectionLoader("ansible_collections")
    except ValueError as e:
        assert "this loader is only for sub-collection modules/packages" in e.args[0]
        assert "ansible_collections" in e.args[0]

    # Constructor with valid fullname
    loader = _AnsibleCollectionLoader("ansible_collections.my_namespace.my_collection.plugins.module_utils.my_module")

# Generated at 2022-06-23 13:46:01.972956
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible

    loader = _AnsibleInternalRedirectLoader('ansible.plugins.loader', [])
    module_name = 'ansible.plugins.loader'
    module = loader.load_module(module_name)
    assert module is ansible.plugins.loader, 'ansible.plugins.loader not redirected to {}. Actual module is {}.'.format(ansible.plugins.loader, module)



# Generated at 2022-06-23 13:46:13.977427
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('ansible.collection.test', path_list=['/path/to'])
    loader._source_code_path = '/path/to/ansible/collection/test.py'
    assert loader.get_filename('ansible.collection.test') == '/path/to/ansible/collection/test.py'

    loader = _AnsibleCollectionPkgLoaderBase('ansible.collection.test', path_list=['/path/to/ansible/collection/test'])
    assert loader.get_filename('ansible.collection.test') == '/path/to/ansible/collection/test'
    loader._subpackage_search_paths = ['/path/to/ansible/collection/test', '/path/to1']

# Generated at 2022-06-23 13:46:19.053528
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import ansible_collections
    collection_finder = AnsibleCollectionFinder()
    ansible_collections_path = to_native(os.path.dirname(to_bytes(ansible_collections.__file__)))

    finder_instance = _AnsiblePathHookFinder(collection_finder, ansible_collections_path)

    # since we are testing the constructor here, not any of the methods, we can pass in a dummy module name to find_module
    first = next(finder_instance.iter_modules("dummy_module"))

    assert first[0] == "dummy_module"
    assert first[2] is True



# Generated at 2022-06-23 13:46:24.989657
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    assert_raises(ImportError, _AnsibleCollectionRootPkgLoader, 'ansible_collections.foo')
    assert_raises(ImportError, _AnsibleCollectionRootPkgLoader, 'ansible_collections.foo.bar')
    assert_raises(ImportError, _AnsibleCollectionRootPkgLoader, 'foo.bar')
    assert_raises(ImportError, _AnsibleCollectionRootPkgLoader, 'foo')

    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert_equal(loader._fullname, 'ansible_collections')
    assert_equal(loader._parent_package_name, '')
    assert_equal(loader._package_to_load, 'ansible_collections')



# Generated at 2022-06-23 13:46:26.694341
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    AnsibleCollectionConfig._collection_finder = None
    _AnsibleCollectionFinder.set_playbook_paths([])
    assert(AnsibleCollectionConfig._collection_finder is not None)


# Generated at 2022-06-23 13:46:38.348402
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    import ansible_collections
    import ansible_collections.ns

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns')
    assert isinstance(loader, _AnsibleCollectionNSPkgLoader)
    assert loader is not None

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.a')
    assert isinstance(loader, _AnsibleCollectionNSPkgLoader)
    assert loader is not None

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ac')
    assert isinstance(loader, _AnsibleCollectionNSPkgLoader)
    assert loader is not None

test__AnsibleCollectionNSPkgLoader()



# Generated at 2022-06-23 13:46:46.702774
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # Test should cover all logical paths through the method
    # _AnsiblePathHookFinder.__repr__
    for x in [False, True]:
        for y in [False, True]:
            for z in [False, True]:
                for t in [False, True]:
                    if not ((not (not (not x)) and not y) or (not (not x) and not (not (not y))) or (not (not (not x)) and not (not y))):
                        _AnsiblePathHookFinder.init_AnsiblePathHookFinder(x, y, z, t)
                        #
                #
            #
        #
    #

# Generated at 2022-06-23 13:46:57.333388
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    fullname = "ansible.module_utils.six.moves.shutil"
    path_list = []

    _r = _AnsibleInternalRedirectLoader(fullname, path_list)
    _r.load_module(fullname)


if PY3:
    _AnsibleCollectionConfig.register_importer()
    path_hook_importer = _AnsibleCollectionConfig.path_hook_importer
else:
    path_hook_importer = _AnsibleCollectionConfig.path_hook_importer()


# This is a "reward" import hook that intercepts certain Ansible internal module names and redirects them to other
# modules in more modern Ansible collections. This loader is meant to only answer for those specific interception points,
# and will delegate to the default importers for normal Python modules. This is a single imp

# Generated at 2022-06-23 13:47:09.496456
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr('test_ns.test_coll.test_resource', 'module')
    assert ansible_collection_ref.collection == 'test_ns.test_coll'
    assert ansible_collection_ref.ref_type == 'module'
    assert ansible_collection_ref.resource == 'test_resource'
    assert ansible_collection_ref.subdirs is None
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.test_ns.test_coll'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.test_ns.test_coll.plugins.module'


# Generated at 2022-06-23 13:47:18.342354
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])
    assert loader._redirect is None
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.basic', [])
    assert loader._redirect == 'ansible.module_utils.basic'
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.hashivault', [])
    assert loader._redirect == 'ansible.module_utils.hashivault'


# Generated at 2022-06-23 13:47:30.097994
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:47:42.233687
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    results = [_AnsibleCollectionNSPkgLoader(fullname='ansible_collections.ns', path_list=[])]
    assert(results[0]._fullname == 'ansible_collections.ns')

# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on the configured collection root path, and Python namespace package aggregation is not allowed at or below
# the collection. Implements implicit package (package dir) support for both Py2/3. Package init code is ignored
# by this loader.

# Generated at 2022-06-23 13:47:50.195148
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import tempfile
    import shutil
    import os

    collection_name = 'test_collection'
    file_name = 'test_file.py'
    content = 'test_content'

    tmp_dir = tempfile.mkdtemp()
    collection_path = os.path.join(tmp_dir, collection_name)
    os.makedirs(collection_path)

    file_path = os.path.join(collection_path, file_name)
    with open(file_path, 'w') as f:
        f.write(content)

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.{0}'.format(collection_name), path_list=[tmp_dir])
    assert loader.get_data(file_path) == content.encode('utf-8')

    shutil

# Generated at 2022-06-23 13:47:59.668672
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import unittest
    import ansible.utils.collection_loader
    # test 'method load_module'
    ansible.utils.collection_loader._AnsibleCollectionConfig.import_collections = lambda *args, **kwargs: None
    ansible.utils.collection_loader._AnsibleCollectionConfig.path_map = lambda *args, **kwargs: None
    ansible.utils.collection_loader._AnsibleInternalRedirectLoader.load_module = lambda *args, **kwargs: None
    # TODO: add code
    #raise NotImplementedError


# this is the only non-redirect path we actually catch

# Generated at 2022-06-23 13:48:10.809756
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    path_list = ['/a/b', '/a/c', '/a/d']
    package_to_load = 'p1'
    fullname = 'ansible_collections.{0}'.format(package_to_load)
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert loader._candidate_paths == [os.path.join(p, package_to_load) for p in path_list]
    assert loader._subpackage_search_paths is None
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == package_to_load
    assert loader._fullname == fullname
    assert loader._split_name == fullname.split('.')

# Generated at 2022-06-23 13:48:21.141928
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # It is a package if we are asked for the correct name and we have defined a search path
    # (Note: this class is abstract and does not implement load_module()
    t = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_collection', path_list=['/test_path'])
    assert t._subpackage_search_paths == ['/test_path']
    assert t.is_package('ansible_collections.test_collection')
    assert not t.is_package('ansible_collections.test_collection.subpackage')

    # Not a package if the parent package is not the package we are looking for.
    assert not t.is_package('ansible_collections.another_collection')


# Generated at 2022-06-23 13:48:32.478467
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    import datetime


# Generated at 2022-06-23 13:48:42.350237
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    base_loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.collection_name'
    )

    dir_mock = Mock()
    dir_mock.__iter__.return_value = ['some_module.py', '__init__.py', 'nested_module']
    dir_mock.__getitem__.return_value = 'some_module.py'
    dir_mock.__contains__.return_value = True
    isfile_mock = Mock()
    isfile_mock.__call__ = Mock(return_value=True)
    isdir_mock = Mock()
    isdir_mock.__call__ = Mock(return_value=True)
    listdir_mock = Mock()

# Generated at 2022-06-23 13:48:46.288247
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    with _AnsibleCollectionFinder() as acf:
        assert acf._n_collection_paths == []
        assert acf._ansible_pkg_path == os.path.dirname(sys.modules['ansible'].__file__)
        assert acf._n_playbook_paths == []
        assert acf._n_configured_paths == []
        assert acf._n_cached_collection_paths is None
        assert acf._n_cached_collection_qualified_paths is None


# Generated at 2022-06-23 13:48:53.193002
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    namespace_name = 'ansible_collections'
    collections_path = 'collections'
    parent_path = os.path.join(FIXTURE_DIR, collections_path)
    sub_path = os.path.join(parent_path, namespace_name)
    loader = _AnsibleCollectionPkgLoaderBase(namespace_name, path_list=[sub_path])
    assert loader.get_filename(namespace_name) == '<ansible_synthetic_collection_package>'

# Generated at 2022-06-23 13:49:02.199251
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Import _AnsiblePathHookFinder for testing.
    from ansible.utils.collection_loader._collection_finder import _AnsiblePathHookFinder

    # Create a test path_hook using a tempdir.
    import tempfile
    tmpdir = os.path.realpath(tempfile.mkdtemp())

    # Skip test if we could not create the directory.
    import shutil
    if tmpdir is None:
        shutil.rmtree(tmpdir)
        return

    # Create a test module in the tempdir.
    test_module = os.path.join(tmpdir, 'testmodule.py')
    with open(test_module, 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("# importable module\n")
        f

# Generated at 2022-06-23 13:49:10.606632
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    from ansible.module_utils.common.text.converters import to_text
    import os
    import tempfile

    paths = []
    try:
        for i in range(0, 4):
            paths.append(tempfile.mkdtemp())

        f = _AnsibleCollectionFinder()
        f.set_playbook_paths(paths)

        path_set = set()
        for p in f._n_playbook_paths:
            path_set.add(os.path.basename(to_text(p, errors='surrogate_or_strict')))

        assert path_set == set(['collections'])
    finally:
        for p in paths:
            os.rmdir(p)



# Generated at 2022-06-23 13:49:21.958858
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    # Make a temporary directory
    temp_dir = to_native(tempfile.mkdtemp())

# Generated at 2022-06-23 13:49:29.067516
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    AnsibleCollectionRef('ns1.coll1', 'subdir1.subdir2', 'resource1', 'role')
    AnsibleCollectionRef('ns1.coll1', 'subdir1.subdir2', 'resource1', 'module')
    AnsibleCollectionRef('ns1.coll1', None, 'resource1', 'role')
    AnsibleCollectionRef('ns1.coll1', None, 'resource1', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns1.coll1.subdir1', None, 'resource1', 'role')
    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns1.coll1', 'subdir1.subdir2.subdir3', 'resource1', 'role')
    with pytest.raises(ValueError):
        Ans

# Generated at 2022-06-23 13:49:35.747619
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    test_data = dict(
        test_data_1 = dict(
            fullname = 'ansible_collections',
            expected_result = None
        ),
        test_data_2 = dict(
            fullname = 'ansible_collections.something',
            expected_result = None
        ),
        test_data_3 = dict(
            fullname = 'ansible_collections.something.more',
            expected_result = None
        ),
    )
    for test_name, test_data in test_data.items():
        loader = _AnsibleCollectionPkgLoaderBase(
            fullname=test_data.get('fullname'),
        )
        result = loader.get_code(fullname=test_data.get('fullname'))
        assert result == test_data.get('expected_result')


# Generated at 2022-06-23 13:49:45.009784
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    assert True
    # FIXME
    # _AnsibleCollectionFinder._remove()
    # assert True
    # assert _AnsibleCollectionFinder._ansible_collection_path_hook('ansible_collections') == _AnsiblePathHookFinder
    # assert _AnsibleCollectionFinder._ansible_collection_path_hook('ansible/module_utils') == _AnsiblePathHookFinder
    # assert _AnsibleCollectionFinder._ansible_collection_path_hook('ansible/modules') == _AnsiblePathHookFinder
    # assert not _AnsibleCollectionFinder._ansible_collection_path_hook('ansible/other')



# Generated at 2022-06-23 13:49:55.821540
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    reference_list = ['namespace.collection.module', 'namespace.collection.playbook', 'namespace.collection.roles', 'namespace.collection.subdir1.subdir2.resource', 'namespace.collection.subdir1.resource', 'namespace.collection.resource']
    for ref in reference_list:
        ref_type = None
        if ref.split('.')[-1] == 'playbook':
            ref_type = 'playbook'
        collection = AnsibleCollectionRef.from_fqcr(ref, ref_type)
        if not isinstance(collection,AnsibleCollectionRef):
            return False
    return True

# Generated at 2022-06-23 13:49:59.258468
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    import os
    import tempfile

    tf = tempfile.mkdtemp()

    foo_tf = os.path.join(tf, 'foo')
    os.mkdir(foo_tf)


# Generated at 2022-06-23 13:50:07.703022
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import inspect
    import os

    # Set up AnsibleCollectionConfig
    acc_package_name = os.path.dirname(inspect.getfile(AnsibleCollectionConfig))
    acc_test_dir = os.path.join(acc_package_name, 'tests')
    test_data_dir = os.path.join(acc_test_dir, 'test_data')
    ansible_collections_path = os.path.join(test_data_dir, 'ansible_collections')
    acc = AnsibleCollectionConfig(
        _meta_yml_to_dict,
        ansible_collections_path
    )
    # Set up _AnsibleCollectionFinder
    acf = _AnsibleCollectionFinder(paths=[ansible_collections_path])
    # Test _AnsibleCollectionF

# Generated at 2022-06-23 13:50:10.428190
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: write unit test
    pass

# We use this in our path_hook, which is installed for any top-level package starting with `ansible_`

# Generated at 2022-06-23 13:50:16.362797
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    split_name = 'ansible_collections.namespace.collection.module'.split('.')

    ldr = _AnsibleCollectionPkgLoader(split_name, '')
    assert ldr._split_name == split_name
    assert ldr._fullname == 'ansible_collections.namespace.collection.module'
    assert ldr._parent_package_name == 'ansible_collections.namespace.collection'
    assert ldr._package_to_load == 'module'



# Generated at 2022-06-23 13:50:21.796801
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    assert StaticLoader._validate_basepath(['/path/to/col'])
    assert StaticLoader._validate_basepath(['/path/to/col', '/path/to/other/col'])
    assert StaticLoader._validate_basepath([])
    with pytest.raises(TypeError):
        StaticLoader._validate_basepath(1)
    with pytest.raises(TypeError):
        StaticLoader._validate_basepath('/path/to/col')
    with pytest.raises(TypeError):
        StaticLoader._validate_basepath(['/path/to/col', 'path/to/other/col'])
    with pytest.raises(TypeError):
        StaticLoader._validate_basepath(['/path/to/col', 1])

# Generated at 2022-06-23 13:50:34.646018
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():

    # Test for valid collection name
    collection_name = 'namespace.collection'
    assert AnsibleCollectionRef.is_valid_collection_name(collection_name)

    # Test for invalid collection name
    collection_name = 'namespace.collection,name'
    assert not AnsibleCollectionRef.is_valid_collection_name(collection_name)

    collection_name = 'namespace.collection name'
    assert not AnsibleCollectionRef.is_valid_collection_name(collection_name)

    collection_name = 'namespace.42'
    assert not AnsibleCollectionRef.is_valid_collection_name(collection_name)

    collection_name = 'namespace.type'
    assert not AnsibleCollectionRef.is_valid_collection_name(collection_name)

    collection_name = 'namespace,collection'
    assert not Ans

# Generated at 2022-06-23 13:50:42.885065
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
  """Test _AnsibleCollectionPkgLoaderBase.get_filename"""
  _a = _AnsibleCollectionPkgLoaderBase("ansible.builtin.diff")
  _a._source_code_path = "/Users/evgeny/.ansible/collections/ansible_collections/ansible/builtin/diff.py"
  _a._get_subpackage_search_paths = lambda x: None
  pwd = os.getcwd()
  try:
    os.chdir("/")
    assert _a.get_filename("ansible.builtin.diff") == "/ansible_collections/ansible/builtin/diff.py"
  finally:
    os.chdir(pwd)

# Generated at 2022-06-23 13:50:44.975309
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader(None, None)
    assert loader._split_name is None
    assert loader._package_to_load is None
    assert loader._subpackage_search_paths == []
    assert loader._source_code_path is None
    assert loader._collection_search_paths == []
    assert loader._redirect_module is None



# Generated at 2022-06-23 13:50:55.342557
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the file system structure:
    #   $ tmp_dir/
    #       ansible_collections/
    #           ansible/
    #               builtin/
    #                   __init__.py     # empty
    #                   meta/
    #                       runtime.yml  # empty
    #           the_namespace/
    #               the_collection/
    #                   __init__.py     # empty
    #                   module.py
    #                   meta/
    #                       runtime.yml  # empty
    #
    tmp_ansible_collections_dir = os.path.join(tmp_dir, u'ansible_collections')
    os.makedirs(tmp_ansible_collections_dir)
    tmp_ans

# Generated at 2022-06-23 13:51:06.550218
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('collection1.plugins')
    loader._subpackage_search_paths = ['collection1.plugins']
    with pytest.raises(ValueError) as err:
        loader.get_filename('collection1.plugins')
    assert 'this loader can not find files for collection1.plugins, only collection1.plugins' in str(err)

    loader._subpackage_search_paths = None
    loader._source_code_path = 'collection1.plugins'
    assert loader.get_filename('collection1.plugins') == 'collection1.plugins'
    loader._source_code_path = None
    assert loader.get_filename('collection1.plugins') == '<ansible_synthetic_collection_package>'

# Generated at 2022-06-23 13:51:16.149992
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # subclasses should all inherit from this base, so we can just instantiate it
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.subns')
    assert loader._fullname == 'ansible_collections.ns.subns'
    assert loader._parent_package_name == 'ansible_collections.ns'
    assert loader._package_to_load == 'subns'
    assert loader._subpackage_search_paths is None
    assert loader._source_code_path is None

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test')
    assert loader._fullname == 'ansible_collections.test'
    # _parent_package_name should be set to something sane even if is_package is going to return false

# Generated at 2022-06-23 13:51:29.196813
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('m_t.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('pro.some_collection_name')
    assert AnsibleCollectionRef.is_valid_collection_name('pro.some_collection_name_with_123')
    assert AnsibleCollectionRef.is_valid_collection_name('my.coll_1')
    assert AnsibleCollectionRef.is_valid_collection_name('my.coll_1')
    assert AnsibleCollectionRef.is_valid_collection_name('foo.bar')

    assert not AnsibleCollectionRef.is_valid_collection_name('namespace1.coll1.coll2')
    assert not AnsibleCollectionRef.is_valid_collection_

# Generated at 2022-06-23 13:51:40.704960
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    c = AnsibleCollectionRef('namespace.mycoll', None, 'mymodule', 'module')
    assert c.collection == 'namespace.mycoll'
    assert c.subdirs == ''
    assert c.resource == 'mymodule'
    assert c.ref_type == 'module'
    assert c.fqcr == 'namespace.mycoll.mymodule'
    assert c.n_python_package_name == 'ansible_collections.namespace.mycoll.plugins.module'

    c = AnsibleCollectionRef('namespace.mycoll', 'myplugin', 'mymodule', 'module')
    assert c.collection == 'namespace.mycoll'
    assert c.subdirs == 'myplugin'
    assert c.resource == 'mymodule'
    assert c.ref_type == 'module'
    assert c

# Generated at 2022-06-23 13:51:45.006287
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # NOTE: this test is only here to satisfy flake8's inclusion of test_loader.py, this is not intended
    # to be a test of the _AnsibleCollectionFinder itself.  The testing of this method happens in
    # test_collection_loader/test_loader_meta.py
    pass



# Generated at 2022-06-23 13:51:58.444041
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # In case the class _AnsibleCollectionFinder is not defined yet, define it
    _AnsibleCollectionFinder = AnsibleCollectionConfig._AnsibleCollectionFinder
    #Create an instance of _AnsibleCollectionFinder
    instance = _AnsibleCollectionFinder()
    # Assert that the attribute _n_configured_paths is an empty list
    assert instance._n_configured_paths == []
    # Assert that the attribute _n_cached_collection_paths is None
    assert instance._n_cached_collection_paths == None
    # Assert that the attribute _n_cached_collection_qualified_paths is None
    assert instance._n_cached_collection_qualified_paths == None
    # Assert that the attribute _n_playbook_paths is an empty list
   

# Generated at 2022-06-23 13:52:07.275001
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name("ns.coll")
    assert not AnsibleCollectionRef.is_valid_collection_name("ns." + ".".join(flatten(list(kwlist.values()))))
    assert not AnsibleCollectionRef.is_valid_collection_name("ns." + ".".join(flatten(list(identifier.values()))))
    assert not AnsibleCollectionRef.is_valid_collection_name("ns." + ".".join(flatten(list(future_keywords.values()))))
    assert not AnsibleCollectionRef.is_valid_collection_name("ns.coll." + ".".join(flatten(list(kwlist.values()))))

# Generated at 2022-06-23 13:52:15.983177
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test modules
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', ref_type='module')
    assert ref.collection == u'ns.coll'
    assert ref.subdirs == u''
    assert ref.resource == u'resource'
    assert ref.ref_type == u'module'
    assert ref.n_python_collection_package_name == u'ansible_collections.ns.coll'
    assert ref.n_python_package_name == u'ansible_collections.ns.coll.plugins.module'
    assert ref.fqcr == u'ns.coll.resource'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', ref_type='module')

# Generated at 2022-06-23 13:52:24.136927
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    plugin_name = "sample.plugin"
    plugin_type = "action"
    assert AnsibleCollectionRef.is_valid_fqcr(plugin_name, plugin_type)

    plugin_name = "ns.coll.sample.plugin"
    plugin_type = "action"
    assert AnsibleCollectionRef.is_valid_fqcr(plugin_name, plugin_type)

    plugin_name = "ansible.builtin"
    plugin_type = "action"
    assert not AnsibleCollectionRef.is_valid_fqcr(plugin_name, plugin_type)

    plugin_name = "ansible.builtin.sample.plugin"
    plugin_type = "action"
    assert not AnsibleCollectionRef.is_valid_fqcr(plugin_name, plugin_type)


# Generated at 2022-06-23 13:52:35.387683
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    l = _AnsibleCollectionPkgLoaderBase('ansible.collections.qcloud')
    l._subpackage_search_paths = ["/l/m/c/qcloud/plugins/modules",
                                  "/l/m/c/qcloud/plugins/module_utils",
                                  "/l/m/c/qcloud/plugins/inventory/script",
                                  "/l/m/c/qcloud/plugins/cliconf",
                                  "/l/m/c/qcloud/plugins/doc_fragments",
                                  "/l/m/c/qcloud/plugins/lookup",
                                  "/l/m/c/qcloud/plugins/filter",
                                  "/l/m/c/qcloud/plugins/terminal",
                                  "/l/m/c/qcloud/plugins/connection", ]


# Generated at 2022-06-23 13:52:41.819009
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    '''
    Basic test of class _AnsibleCollectionPkgLoaderBase.  Only tests that _AnsibleCollectionPkgLoaderBase.__repr__()
    works correctly and is not all_caps.
    '''

    CUT = _AnsibleCollectionPkgLoaderBase('')

    assert CUT.__repr__() == 'AnsibleCollectionPkgLoaderBase(path=None)'



# Generated at 2022-06-23 13:52:50.009339
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    def test_case(legacy_plugin_dir_name, expected_plugin_type):
        actual_plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)
        assert actual_plugin_type == expected_plugin_type

    # from PluginLoader
    test_case('action_plugins', 'action')
    test_case('become_plugins', 'become')
    test_case('cache_plugins', 'cache')
    test_case('callback_plugins', 'callback')
    test_case('cliconf_plugins', 'cliconf')
    test_case('connection_plugins', 'connection')
    test_case('doc_fragments', 'doc_fragments')
    test_case('filter_plugins', 'filter')

# Generated at 2022-06-23 13:52:55.065398
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    test_cases = [
        ('ansible.test', []),
        ('ansible.test.test_collection', []),
    ]
    for fullname, path_list in test_cases:
        loader = _AnsibleInternalRedirectLoader(fullname, path_list)
        assert loader._redirect is not None



# Generated at 2022-06-23 13:53:01.803812
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # create a dummy runtime.yml file
    import tempfile
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    meta_file = None

# Generated at 2022-06-23 13:53:11.832660
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert isinstance(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource'), bool)
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')

    assert isinstance(AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource'), bool)
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')

    assert isinstance(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module'), bool)
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')


# Generated at 2022-06-23 13:53:20.931739
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import runpy
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.community.plugins.module_utils.network.f5', '/tmp')
    test_file = '/tmp/ansible_collections/ansible/community/plugins/module_utils/network/f5/common/check_mode.py'
    assert loader.get_code(loader._fullname) is None
    loader._source_code_path = test_file
    assert loader.get_code(loader._fullname) is not None

# Generated at 2022-06-23 13:53:26.288343
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragment_plugins') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir

# Generated at 2022-06-23 13:53:32.481002
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader(['ansible.posix', 'file'], ['/tmp/ansible_collections/ansible/posix/plugins/modules'])
    assert ['ansible', 'posix', 'file'] == loader._split_name
    assert loader._candidate_paths == ['/tmp/ansible_collections/ansible/posix/plugins/modules']
    assert loader._package_to_load == 'file'
    assert loader._module_to_load == 'file'

