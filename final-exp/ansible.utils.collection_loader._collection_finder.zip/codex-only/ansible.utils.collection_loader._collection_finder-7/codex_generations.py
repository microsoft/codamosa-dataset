

# Generated at 2022-06-23 13:43:39.949094
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Tests that an exception is raised when the provided name is not the same as the _fullname of the loader
    with pytest.raises(ValueError):
        loader = _AnsibleCollectionPkgLoaderBase('test', 'test')
        loader.is_package('test1')

# Generated at 2022-06-23 13:43:49.734028
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create an instance of the base class
    from ansible_collections.my.my_collection.plugins.module_utils import my_utils
    my_utils_obj = _AnsibleCollectionPkgLoaderBase.__new__(_AnsibleCollectionPkgLoaderBase)
    # The handler for my_utils_obj is supposed to be a dictionary
    my_utils_obj.__dict__ = my_utils.__dict__
    assert isinstance(my_utils_obj.__dict__, dict)
    assert isinstance(my_utils_obj.get_filename('my_utils'), str)
    assert isinstance(my_utils_obj.get_source('my_utils'), str)
    assert isinstance(my_utils_obj.is_package('my_utils'), bool)

# Generated at 2022-06-23 13:43:58.028454
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    test_ref = AnsibleCollectionRef.from_fqcr(ref="namespace.collection.subdir1.subdir2.resource", ref_type="role")
    assert test_ref.collection == 'namespace.collection'
    assert test_ref.subdirs == 'subdir1.subdir2'
    assert test_ref.resource == 'resource'
    assert test_ref.ref_type == 'role'
    assert test_ref.fqcr == 'namespace.collection.subdir1.subdir2.resource'
    assert test_ref.n_python_collection_package_name == 'ansible_collections.namespace.collection'
    assert test_ref.n_python_package_name == 'ansible_collections.namespace.collection.roles.subdir1.subdir2.resource'
# Unit

# Generated at 2022-06-23 13:44:00.734489
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert _AnsiblePathHookFinder._get_filefinder_path_hook()

# unit tests for _AnsiblePathHookFinder.find_module

# Generated at 2022-06-23 13:44:05.897952
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # input
    fullname = 'ansible_collections.bismark'
    # test
    test_obj = _AnsibleCollectionPkgLoaderBase(fullname)
    # output
    result = test_obj.get_filename(fullname)
    assert result == '<ansible_synthetic_collection_package>'
test__AnsibleCollectionPkgLoaderBase_get_filename()

# Generated at 2022-06-23 13:44:11.966427
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # Test _AnsibleCollectionLoader.__init__ with empty collection_name
    with pytest.raises(ValueError) as exception_info:
        _AnsibleCollectionLoader('', None)
    assert 'invalid collection module name' in str(exception_info.value)

    # Test _AnsibleCollectionLoader.__init__ with invalid collection_name
    with pytest.raises(ValueError) as exception_info:
        _AnsibleCollectionLoader('invalid collection name', None)
    assert 'invalid collection module name' in str(exception_info.value)

    # Test _AnsibleCollectionLoader.__init__ with collection_name consists of white space
    with pytest.raises(ValueError) as exception_info:
        _AnsibleCollectionLoader('test.collections.name ', None)

# Generated at 2022-06-23 13:44:14.856459
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import ansible_collections.ns1.test
    assert ansible_collections.ns1.test.__file__.endswith('__synthetic__')

# Test the get_code method of class _AnsibleCollectionPkgLoaderBase
test__AnsibleCollectionPkgLoaderBase_get_code()


# Generated at 2022-06-23 13:44:26.527113
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible_collections.test.test_utils.mock import MockAnsibleModule, patch, mock_open
    import os
    import pkgutil
    import shutil
    import tempfile

    def _mock_iter_modules(paths, prefix):
        a_path = os.path.join(tmpdir, b'ansible_collections', b'ns1', b'coll1', b'modules', b'module1')
        b_path = os.path.join(tmpdir, b'ansible_collections', b'ns1', b'coll1', b'modules', b'module2')
        c_path = os.path.join

# Generated at 2022-06-23 13:44:29.669012
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert len(_AnsibleCollectionFinder._AnsiblePathHookFinder._get_filefinder_path_hook()) == 1


# Generated at 2022-06-23 13:44:40.538080
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    """Unit test to check return value of _AnsibleCollectionPkgLoaderBase.get_code(fullname)"""

    # Test data
    module_attrs = {'__loader__': None, '__file__': 'test.txt', '__package__': ''}
    module_attrs_1 = {'__loader__': None, '__file__': 'test.txt', '__package__': 'ansible', '__path__':['modules']}

    # create module obj
    module = ModuleType('ansible')
    module_1 = ModuleType('ansible')

    # assign the attributes of module
    for attr, value in module_attrs.items():
        setattr(module, attr, value)

    # assign the attributes of module_1

# Generated at 2022-06-23 13:44:47.100613
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    collection_finder = _AnsibleCollectionFinder(paths=[])
    assert collection_finder.find_module('ansible') is not None
    assert collection_finder.find_module('ansible_collections') is not None
    assert collection_finder.find_module('ansible_collections.test_collection_loader') is not None
    assert collection_finder.find_module('ansible.module_utils.test_collection_loader') is not None
    assert collection_finder.find_module('ansible.module_utils.test_collection_loader.ansible') is not None


# Generated at 2022-06-23 13:44:51.952732
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # test case 1
    # TODO: implement
    print('unit test case 1:', end='')
    assert False



# Generated at 2022-06-23 13:44:55.466826
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref = AnsibleCollectionRef('namespace.collectionname', 'subdirs', 'resource', 'ref_type')
    expected = "AnsibleCollectionRef(collection='namespace.collectionname', subdirs='subdirs', resource='resource')"
    if str(ansible_collection_ref) != expected:
        raise AssertionError(
            'Expected %s, got %s' % (expected, str(ansible_collection_ref))
        )


# Generated at 2022-06-23 13:45:07.519522
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert not AnsibleCollectionRef.is_valid_fqcr(None)
    assert not AnsibleCollectionRef.is_valid_fqcr(15)
    assert not AnsibleCollectionRef.is_valid_fqcr('')

    assert not AnsibleCollectionRef.is_valid_fqcr('.')
    assert not AnsibleCollectionRef.is_valid_fqcr('..')
    assert not AnsibleCollectionRef.is_valid_fqcr('...')

    assert not AnsibleCollectionRef.is_valid_fqcr('a.b')
    assert not AnsibleCollectionRef.is_valid_fqcr('a..b')
    assert not AnsibleCollectionRef.is_valid_fqcr('a..b.c')

    assert not AnsibleCollectionRef.is_valid_fqcr('.b')


# Generated at 2022-06-23 13:45:11.362807
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    val_1 = AnsibleCollectionRef.is_valid_fqcr('foo.bar.mod')
    val_2 = AnsibleCollectionRef.is_valid_fqcr('foo.bar.mod', 'module')
    val_3 = AnsibleCollectionRef.is_valid_fqcr('foo.bar.mod', 'playbook')
    val_4 = AnsibleCollectionRef.is_valid_fqcr('foo.bar.mod', 'action')
    assert val_1 == True
    assert val_2 == True
    assert val_3 == False
    assert val_4 == False


# Generated at 2022-06-23 13:45:20.371107
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import mock
    from ansible.module_utils.common.collections import _AnsibleInternalRedirectLoader as classToTest
    test_instance = classToTest('ansible.foo', [])
    test_instance._redirect = 'ansible'
    test_instance.load_module('ansible.foo')
    assert sys.modules['ansible.foo'] == 'ansible' , 'Unable to call method load_module'

# Generated at 2022-06-23 13:45:26.892388
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', [])
    assert loader is not None
    try:
        loader = _AnsibleCollectionRootPkgLoader('ansible', [])
    except ImportError:
        pass
    else:
        raise AssertionError('Expected loader to fail with wrong import for ansible')
    try:
        loader = _AnsibleCollectionRootPkgLoader('ansible_collections.foo', ['/foo'])
    except ImportError:
        pass
    else:
        raise AssertionError('Expected loader to fail with wrong import for ansible_collections.foo')



# Generated at 2022-06-23 13:45:28.799241
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('', '', '', [])



# Generated at 2022-06-23 13:45:39.589968
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # Create test cases from examples in Ansible.
    testcases = [
        "ansible.windows",
        "ansible_collections.geerlingguy.nginx",
        "certbot.plugins.dns",
        "community.general",
        "network.napalm",
        "not_a_fqcn",
        "not.a.fqcn",
        "notasdf.afqcn",
        "system.network",
        "weirdboi.is.a_collection_name",
        "weirdboi.is.a-collection_name",
    ]
    # Run tests
    for tc in testcases:
        assert AnsibleCollectionRef.is_valid_collection_name(tc) == True


# Generated at 2022-06-23 13:45:46.388990
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    import tempfile
    import unittest

    class TestAnsibleCollectionNSPkgLoader(unittest.TestCase):
        def test_ansible_collections(self):
            # create a temp directory and populate it with a collection layout structure
            d = tempfile.mkdtemp()

            # create the collection layout within the temp dir
            os.makedirs(os.path.join(d, 'ansible_collections', 'my_namespace', 'my_collection', 'roles', 'test_role', 'tasks'))

            # create files within the temp dir
            # ansible/playbook.py
            with open(os.path.join(d, 'ansible_collections', 'ansible', 'playbook.py'), 'w+') as f:
                f.write('')

            # ansible/plugins

# Generated at 2022-06-23 13:45:49.814418
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    """Unit test for method find_module of class _AnsibleCollectionFinder"""
    finder = _AnsibleCollectionFinder()
    assert finder._n_configured_paths == []



# Generated at 2022-06-23 13:45:58.254818
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    base_dir = _get_test_dir()
    cf = _AnsibleCollectionFinder(paths=base_dir)
    cf._install()
    achf = _AnsiblePathHookFinder(collection_finder=cf, pathctx=os.path.join(base_dir, 'ansible_collections', 'namespace1'))
    actual = achf.find_module('ansible_collections.namespace1.collection1.plugins.module_utils.os.path')
    assert isinstance(actual, _AnsibleCollectionLoader)


# Generated at 2022-06-23 13:46:08.619151
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    import os

    class TestImportLoader(object):
        def __init__(self, split_name, namespace_package=False):
            self._split_name = split_name
            self._namespace_package = namespace_package
            self._loader = _AnsibleCollectionPkgLoader(split_name, namespace_package=namespace_package)

        def _test_init(self):
            # _split_name
            assert self._loader._split_name == self._split_name
            # _namespace_package
            assert self._loader._namespace_package == self._namespace_package
            # _fullname
            assert self._loader._fullname == '.'.join(self._split_name)
            # _package_to_load
            assert self._loader._package_to_load == self._split_name[-1]

# Generated at 2022-06-23 13:46:20.176482
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    def t1():
        _AnsibleCollectionPkgLoaderBase('ansible_collections.z')
    def t2():
        _AnsibleCollectionPkgLoaderBase('ansible_collections.z', path_list=['/p1'])
    def t3():
        _AnsibleCollectionPkgLoaderBase('ansible_collections.z', path_list=['/p1', '/p2'])
    def t4():
        _AnsibleCollectionPkgLoaderBase('ansible.foo')
    def t5():
        _AnsibleCollectionPkgLoaderBase('foo.bar')
    def t6():
        _AnsibleCollectionPkgLoaderBase('foo')

    t1()
    t2()
    t3()

    with pytest.raises(ImportError) as exc:
        t

# Generated at 2022-06-23 13:46:30.040030
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import tempfile
    import shutil
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 13:46:34.650312
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    fullname = "ansible_collections.my_namespace.my_collection"
    path = None
    private_module = _AnsibleCollectionPkgLoaderBase(fullname, path)

# Generated at 2022-06-23 13:46:36.866554
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    AnsibleCollectionConfig.collection_finder = None

    original_paths = sys.path
    sys.path = []
    _AnsibleCollectionFinder()
    sys.path = original_paths



# Generated at 2022-06-23 13:46:43.047201
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library") == "modules"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("test_plugins") == "test"



# Generated at 2022-06-23 13:46:54.865146
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('ansible_collections.whatever', '/foo/bar') == \
        ('/foo/bar/ansible_collections/whatever.py', True, None)
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('ansible', '/') == \
        ('/ansible.py', True, None)
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('ansible.plugins', '/') == \
        ('/plugins', True, '/plugins')
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('ansible.plugins', '/foo/bar') == \
        ('/foo/bar/plugins', True, '/foo/bar/plugins')
    assert _AnsibleCollection

# Generated at 2022-06-23 13:46:58.269893
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    paths = ['/some/path/collections']
    cf = _AnsibleCollectionFinder(paths)
    cf.set_playbook_paths(paths)
    assert cf._n_playbook_paths == paths
    


# Generated at 2022-06-23 13:47:09.604096
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(_TestAnsibleCollectionPkgLoaderBase, self).__init__(fullname, path_list)
            self._subpackage_search_paths = path_list
    test_path = 'test-path'
    test_module_name = 'test-module'
    test_subpackage_name = 'test-subpackage'
    subpackage_path = os.path.join(test_path, test_subpackage_name)
    submodule_path = os.path.join(subpackage_path, test_module_name)
    test_submodule_code = 'test-submodule-code'

# Generated at 2022-06-23 13:47:21.714737
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Test 1: instantiate _AnsibleCollectionPkgLoaderBase, with fullname = ansible_collections.somens
    with patch.object(AnsibleImportError, '__init__', return_value=None):
        try:
            _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
        except AnsibleImportError:
            assert True

    # Test 2: instantiate _AnsibleCollectionPkgLoaderBase, with fullname = somens
    with patch.object(AnsibleImportError, '__init__', return_value=None):
        try:
            _AnsibleCollectionPkgLoaderBase('somens')
        except AnsibleImportError:
            assert True


# Generated at 2022-06-23 13:47:27.281316
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # test None ansible_collections.test_ns.test_ns
    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_ns')
    assert not obj.get_filename('ansible_collections.test_ns.test_ns')



# Generated at 2022-06-23 13:47:29.512305
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():  # pylint: disable=invalid-name
    path_hook_finder = _AnsiblePathHookFinder(None, '/')
    assert repr(path_hook_finder) == "_AnsiblePathHookFinder(path='/')"



# Generated at 2022-06-23 13:47:38.000901
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import sys
    from units.compat.mock import patch, MagicMock
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.module_utils.ansible_release as ansible_release
    m = MagicMock(side_effect=RuntimeError('test_get_data'))

    # Ensure that all Exception or RuntimeError are caught properly
    with patch.object(ansible_release, '__get_init_path', m):
        collection_finder = _AnsibleCollectionFinder()
        if PY3:
            loader = _AnsiblePathHookFinder(to_native(os.path.dirname(ansible_release.__file__)), collection_finder)
        else:
            loader = _Ans

# Generated at 2022-06-23 13:47:48.452291
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(name='ansible_collections.namespace.name', path=[])
    loader = _AnsibleCollectionPkgLoader(name='ansible_collections.namespace.name', path=['path1', 'path2'])

    # test normal runtime usage
    loader = _AnsibleCollectionPkgLoader(name='ansible_collections.namespace.name', path=[os.path.join(os.path.dirname(__file__), 'test_data')])
    loader = _AnsibleCollectionPkgLoader(name='ansible_collections.namespace.name', path=[os.path.join(os.path.dirname(__file__), 'test_data')])
    loader.load_module('ansible_collections.namespace.name')
    loader.get_

# Generated at 2022-06-23 13:47:55.543905
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    finder = _AnsiblePathHookFinder(
        collection_finder=_AnsibleCollectionFinder(),
        pathctx='/foo/bar',
    )
    assert repr(finder) == r"_AnsiblePathHookFinder(path='/foo/bar')"


# Implement an import loader for various internal things that we want to divert to the collection loader.

# Generated at 2022-06-23 13:48:07.300127
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    plugin_dir = os.path.join(base_dir, 'lib/ansible/plugins')
    collection_loader = _AnsibleCollectionLoader(['ansible_collections.ansible.builtin'], [plugin_dir])
    assert collection_loader._package_to_load == 'ansible_collections.ansible.builtin'
    assert collection_loader._fullname == 'ansible_collections.ansible.builtin'
    assert collection_loader._split_name == ['ansible_collections', 'ansible', 'builtin']
    assert collection_loader._candidate_paths == [plugin_dir]
    assert collection_loader._source_code_path

# Generated at 2022-06-23 13:48:19.892229
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    assert_equals(_AnsibleCollectionPkgLoaderBase.get_data('test/test_test.py'), 
'#!/usr/bin/python\n\n# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase\n\ndef test__AnsibleCollectionPkgLoaderBase_get_data():\n\n    assert_equals(_AnsibleCollectionPkgLoaderBase.get_data(\'test/test_test.py\'), \n                  None\n                  )\n\ndef assert_equals(ret, expected, msg=None):\n    if ret == expected:\n        print(\'passed\')\n    else:\n        print(\'failed\', msg if msg else \'\')\n\n')



# Generated at 2022-06-23 13:48:27.678949
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    output = _AnsibleCollectionPkgLoaderBase._module_file_from_path('mypkg', '/path')
    assert output[0] == '/path/mypkg/__synthetic__' and output[1] == False and output[2] == '/path/mypkg'
    # this scenario is not implemented yet
    output = _AnsibleCollectionPkgLoaderBase._module_file_from_path('mymod', '/path')
    assert output[0] == '/path/mymod.py' and output[1] == True and output[2] == None

# Generated at 2022-06-23 13:48:36.030335
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    testname = 'test_get_filename'
    # TODO: Due to all the logic in this method, it's hard to test, we need to mock out a lot of method calls
    test_loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.microsoft.azure.plugins.module_utils.azure_rm_common")
    assert test_loader.get_filename("ansible_collections.microsoft.azure.plugins.module_utils.azure_rm_common") is not None
    # TODO: Since there is no good way to test this, we just check that the method doesnot return None


# Generated at 2022-06-23 13:48:41.525371
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("ansible.windows", "file")

    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("ansible.windows.ping", "file")

    ref = AnsibleCollectionRef.from_fqcr("ansible.windows.ping", "module")
    assert ref.collection == "ansible.windows"
    assert ref.subdirs == ""
    assert ref.resource == "ping"
    assert ref.ref_type == "module"


# Generated at 2022-06-23 13:48:53.932209
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    import tempfile
    test_pkg_name = 'ansible_collections.ansible.test'
    temp_dir_obj = tempfile.TemporaryDirectory(prefix='ansible_test_')
    temp_dir = temp_dir_obj.name
    sys.path.append(temp_dir)

# Generated at 2022-06-23 13:49:01.608115
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    test_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    test_path = os.path.dirname(test_path)
    test_path = os.path.join(test_path, 'test', 'core', 'test_collections')

    finder = _AnsiblePathHookFinder(None, test_path)
    modules = finder.iter_modules()
    assert len(list(modules)) > 0



# Generated at 2022-06-23 13:49:02.985495
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # TODO: rewrite test
    pass



# Generated at 2022-06-23 13:49:07.978430
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Assign
    module = 'ansible'
    loader = _AnsibleCollectionPkgLoader('__main__', 'ansible', 'ansible', ('/Users/tianrun/PycharmProjects/ansible-test/test_data/test_collection',))
    # Act
    result = loader.load_module(module)
    # Assert
    assert module == result.__name__



# Generated at 2022-06-23 13:49:17.608743
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Check for strings with malformed reference
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr(None, u'module')
        AnsibleCollectionRef.from_fqcr(u'', u'module')
        AnsibleCollectionRef.from_fqcr(u'module', None)
        AnsibleCollectionRef.from_fqcr(u'module', u'')
        AnsibleCollectionRef.from_fqcr(u'module', u'unsupported')

    # Check for strings with valid reference
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module')
    assert ansible_collection_ref.fqcr == u'ns.coll.resource'
    assert ansible_collection_ref

# Generated at 2022-06-23 13:49:21.785372
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    obj = _AnsibleCollectionRootPkgLoader('ansible_collections', ['/path/to/my/collections'])
    assert obj._fullname == 'ansible_collections'
    assert obj._split_name == ['ansible_collections']
    assert obj._candidate_paths == ['/path/to/my/collections']
    assert obj._parent_package_name == ''
    assert obj._package_to_load == 'ansible_collections'
    assert obj._subpackage_search_paths == ['/path/to/my/collections']
    assert obj._source_code_path is None
    assert obj._decoded_source is None
    assert obj._compiled_code is None



# Generated at 2022-06-23 13:49:32.026929
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    pathhook = _AnsiblePathHookFinder(None, os.path.join(os.path.dirname(__file__), 'data/pkgutil'))
    assert sorted(pathhook.iter_modules('')) == sorted([('module', ''), ('module.submodule', ''), ('other_module', '')])
    assert sorted(pathhook.iter_modules('module')) == sorted([('module', ''), ('module.submodule', '')])
    assert sorted(pathhook.iter_modules('module.')) == sorted([('module', ''), ('module.submodule', '')])

    pathhook = _AnsiblePathHookFinder(None, os.path.join(os.path.dirname(__file__), 'data/pkgutil/module'))

# Generated at 2022-06-23 13:49:43.653586
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from unittest import TestCase

    from ansible_collections.ansible.builtin.tests.unit.compat import mock

    from ansible_collections.ansible.builtin.plugins.loader.collection_loader._module_finder import _AnsibleCollectionPkgLoaderBase

    class TestAnsibleCollectionPkgLoaderBase(TestCase):

        def test_get_code_init(self):
            # Imports and assert statements
            mock_loader = mock.Mock(spec_set=_AnsibleCollectionPkgLoaderBase)
            mock_compile = mock.Mock()

# Generated at 2022-06-23 13:49:55.504918
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns')
    assert loader._fullname == 'ansible_collections.ns'
    assert loader._split_name == ['ansible_collections', 'ns']
    assert loader._rpart_name == ('ansible_collections', '.', 'ns')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'ns'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths == []

# Implements the collection package and its subpackages. The collection package is the first one found on the
# configured

# Generated at 2022-06-23 13:50:03.969230
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
  assert AnsibleCollectionRef.from_fqcr("ns.coll.resource", "module") == AnsibleCollectionRef("ns.coll", "", "resource", "module")
  assert AnsibleCollectionRef.from_fqcr("ns.coll.subdir1.resource", "module") == AnsibleCollectionRef("ns.coll", "subdir1", "resource", "module")
  assert AnsibleCollectionRef.from_fqcr("ns.coll.rolename", "role") == AnsibleCollectionRef("ns.coll", "", "rolename", "role")


# Generated at 2022-06-23 13:50:07.708109
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    pkg = _AnsibleCollectionPkgLoader(['ansible_collections', 'aci', 'aci_rest'])
    # If a specific testing is needed, code can be added here
    # ...


# Generated at 2022-06-23 13:50:08.790031
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    assert _AnsibleCollectionPkgLoaderBase().get_data(path='/usr/') == None


# Generated at 2022-06-23 13:50:17.352211
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # 1. Setup
    fullname = 'ansible_collections.my_namespace.my_collection'
    path_list = ["/home/foo/path1", "/home/foo/path2"]
    expected_result = '_AnsibleCollectionPkgLoaderBase(path=[/home/foo/path1/my_collection, /home/foo/path2/my_collection])'
    cls = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    # 2. Exercise
    result = cls.__repr__()
    #3. Verify
    assert result == expected_result
    # 4. Cleanup (unnecessary)



# Generated at 2022-06-23 13:50:23.699408
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.mynamespace', path_list=['/tmp'])
    assert loader is not None


# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on the configured collection root path, and Python namespace package aggregation is not allowed at or below
# the collection. Implements implicit package (package dir) support for both Py2/3. Package init code is ignored
# by this loader.

# Generated at 2022-06-23 13:50:35.652413
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    test_pkg_path = to_bytes(os.path.realpath(os.path.join(__file__, '../../lib/ansible_test/_data/collection_pkgloader_test_pkg1')))
    pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.testns.pkg', [test_pkg_path])
    assert 'pkg.subpkg1' in pkg_loader.iter_modules('')
    assert 'pkg.subpkg1.subsubpkg1' in pkg_loader.iter_modules('')
    assert 'pkg.subpkg2' in pkg_loader.iter_modules('')
    assert 'pkg.module1' in pkg_loader.iter_modules('')
    assert 'pkg.module2' in pkg_loader.iter_modules('')

# Generated at 2022-06-23 13:50:47.654688
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:50:52.372970
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    # path to module
    path = "test-module-name"

    # full module name
    fullname = "test-module-name"

    # definde new class _AnsibleCollectionPkgLoader
    class _AnsibleCollectionPkgLoader(object):
        split_name = ["class-name"]
        subpackage_search_paths = ["test-path"]

        # load module
        def load_module(self, fullname):
            return "\n"

        # canonical_meta
        def _canonicalize_meta(self, meta_dict):
            return "can_meta"

        # return full module name
        def get_filename(self, fullname):
            return fullname

    # create new object of class _AnsibleCollectionPkgLoader
    loader = _AnsibleCollectionPkgLoader()

    #

# Generated at 2022-06-23 13:51:04.384348
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('ansible_collections.foo.bar.baz', ['/var/tmp/ansible'])
    assert loader._is_final_loader is False
    assert loader._package_to_load == 'ansible_collections.foo.bar'
    assert loader._split_name == ['ansible_collections', 'foo', 'bar', 'baz']
    assert loader._package_to_load_fullname == 'ansible_collections.foo.bar'
    assert loader._fullname == 'ansible_collections.foo.bar.baz'
    assert loader._candidate_paths == ['/var/tmp/ansible/collections']
    assert loader._subpackage_search_paths is None
    assert loader._source_code_path is None

# Generated at 2022-06-23 13:51:16.363325
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name("ansible.ssh")
    assert AnsibleCollectionRef.is_valid_collection_name("namespace.collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible_user.collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible.")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible.collection.something")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible_collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("ansible")
    assert not AnsibleCollectionRef.is_valid_collection_name("collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.collection.something")
    assert not Ans

# Generated at 2022-06-23 13:51:29.380953
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    import pytest

# Generated at 2022-06-23 13:51:32.904554
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.something', '')
    assert loader._redirect == 'ansible.builtin.module_utils.something'



# Generated at 2022-06-23 13:51:44.082597
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:51:51.698382
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    _AnsibleCollectionFinder._remove()

    collection_paths = [
        '~/ansible_collections',
        '~/ansible_collections/ansible_collections',
        '/tmp/ansible_collections',
        '/tmp/ansible_collections/ansible_collections',
    ]

    # filter out collection paths that don't exist
    collection_paths = [p for p in collection_paths if os.path.isdir(os.path.expanduser(p))]

    if not collection_paths:
        raise AssertionError('test__AnsiblePathHookFinder_find_module needs one or more existing collection paths')

    # create a collection_finder and use it to set up the path_hooks and importer cache
    collection_finder = _AnsibleCollectionFinder

# Generated at 2022-06-23 13:52:02.561547
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    import sys
    import ansible.plugins.loader
    # ansible.plugins.loader can also be called as ansible_collections.ns.coll.plugins.loader
    # this line ensures that this is the case to make sure that the unit test doesn't fail due to the
    # namespace import.
    assert(sys.modules[ansible.plugin_loader.__module__].__name__ == 'ansible_collections.ns.coll.plugins.loader')

    # The test function should throw an exception when the constructor is called with an incorrect format
    # 1.1 The full qualified collection ref should be a string
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr(1, 'mytype')

    # 1.2 The collection ref should start with a namespace followed by a '.'

# Generated at 2022-06-23 13:52:13.363143
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:52:25.760745
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('some.collection')
    assert not AnsibleCollectionRef.is_valid_fqcr('some.collection.')
    assert not AnsibleCollectionRef.is_valid_fqcr('some.collection.subdir')
    assert AnsibleCollectionRef.is_valid_fqcr('some.collection.subdir', 'doc_fragment')
    assert not AnsibleCollectionRef.is_valid_fqcr('some.collection.subdir', 'module')
    assert not AnsibleCollectionRef.is_valid_fqcr('some.collection.subdir')
    assert AnsibleCollectionRef.is_valid_fqcr('some.collection.subdir.subsubdir')

# Generated at 2022-06-23 13:52:33.962536
# Unit test for method iter_modules of class _AnsiblePathHookFinder

# Generated at 2022-06-23 13:52:45.651749
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:52:56.815062
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    assert sys.version_info >= (3, 8)
    from types import ModuleType
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader

    module = ModuleType('test_ansible_internal_redirect_load')
    module.__path__ = []
    sys.modules['test_ansible_internal_redirect_load'] = module
    assert module == sys.modules['test_ansible_internal_redirect_load']

    loader = _AnsibleInternalRedirectLoader('test_ansible_internal_redirect_load', [])
    module = loader.load_module('test_ansible_internal_redirect_load')
    assert module == sys.modules['test_ansible_internal_redirect_load']

# Generated at 2022-06-23 13:53:05.242239
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.collections import AnsibleCollectionLoader
    from ansible.module_utils.common.collections import PathMetaLoader
    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoaderBase
    import sys
    import os

    ####### 1. test source is not None, get_data return None, get_source is None, get_filename is None
    path = os.path.join(os.getcwd(), 'test_module_utils', 'resources', 'other_test_module')
    path = to_native(path)
    print("path : {0}".format(path))

    # Monkey Patch PathMetaLoader._import_module


# Generated at 2022-06-23 13:53:15.292380
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns1.coll1.mod1', 'module') == AnsibleCollectionRef(u'ns1.coll1', u'', u'mod1', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns1.coll1.sub1.mod1', 'module') == AnsibleCollectionRef(u'ns1.coll1', u'sub1', u'mod1', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns1.coll1.rolename', 'role') == AnsibleCollectionRef(u'ns1.coll1', u'', u'rolename', 'role')

# Generated at 2022-06-23 13:53:20.153546
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'library') == u'modules'

    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'non_existing_plugin')


# Generated at 2022-06-23 13:53:31.099117
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible_collections.ansible.plugins.loader import get_all_plugin_loaders as get_all_plugin_loaders2
    from ansible_collections.ansible.plugins.loader import get_collection_info
    from ansible_collections.nsbl.plugins.loader import get_all_plugin_loaders as get_all_plugin_loaders3
    from ansible_collections.nsbl.plugins.loader import get_collection_info as get_collection_info2
    from ansible_collections.nsbl.collection.plugins.loader import get_collection_info as get_collection_info3

    paths = ["/tmp/ansible_collections"]


# Generated at 2022-06-23 13:53:37.298878
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    path_list = ['/path/to/a/collection', '/path/to/another/collection']
    fullname = 'ansible_collections'
    loader = _AnsibleCollectionRootPkgLoader(fullname, path_list)
    assert loader._fullname == 'ansible_collections'
    assert loader._parent_package_name == ''

    path = '/path/to/a/collection/ns1'
    assert loader._subpackage_search_paths == [path, '/path/to/another/collection/ns1']
    assert loader._validate_final() is None

