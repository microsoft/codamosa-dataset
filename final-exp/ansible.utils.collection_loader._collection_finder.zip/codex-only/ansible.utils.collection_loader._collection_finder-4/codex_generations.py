

# Generated at 2022-06-23 13:43:39.270057
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(None, None)
    assert loader


# Unit testing for functions in the module

# Generated at 2022-06-23 13:43:49.175274
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    try:
        _AnsibleCollectionPkgLoaderBase('some_module.some_package')
    except ImportError:
        pass
    else:
        raise AssertionError('Expected ImportError for loading non-ansible_collections package')

    try:
        _AnsibleCollectionPkgLoaderBase('.some_package')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError for empty package')

    try:
        _AnsibleCollectionPkgLoaderBase('ansible_collections.some_package.some_module')
    except ImportError:
        pass
    else:
        raise AssertionError('Expected ImportError for module in ansible collection')

    _AnsibleCollectionPkgLoaderBase('ansible_collections.some_package.some_package')




# Generated at 2022-06-23 13:43:57.591320
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    collection_ref = AnsibleCollectionRef.from_fqcr("my_plugin.something", "module")
    assert collection_ref.collection == "my_plugin"
    assert collection_ref.resource == "something"
    assert collection_ref.ref_type == "module"
    assert collection_ref.subdirs == ""
    assert collection_ref.fqcr == "my_plugin.something"

    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.from_fqcr("my_plugin", "module")
    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.from_fqcr("my_plugin.something.more", "module")
    with pytest.raises(ValueError):
        collection_ref = AnsibleCollectionRef.from_fqcr

# Generated at 2022-06-23 13:44:02.901761
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.baz', u'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.baz.qux', u'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar', u'module') is None
    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.baz', u'role') is not None
    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.baz.qux', u'role') is not None
    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.baz.qux.quux', u'role')

# Generated at 2022-06-23 13:44:05.453611
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('foo', 'bar', 'baz', 'role')
    assert "foo.bar.baz" == ref.__repr__(), ref.__repr__()

# Generated at 2022-06-23 13:44:11.725652
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Setup
    from ansible_collections.foo.bar.plugins.module_utils.some_module import Foo
    import shlex

    package_name = Foo.__module__
    split_parts = package_name.split('.')
    leaf_package_name = split_parts[-1]
    top_package_name = split_parts[0]
    toplevel_package_dir = os.path.dirname(Foo.__file__)
    target_package_dir = os.path.dirname(toplevel_package_dir)
    test_path = os.path.join(target_package_dir, package_name.replace('.', '/'))
    test_path_list = [test_path]


# Generated at 2022-06-23 13:44:23.686721
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    test_path_ctx = "test_path_ctx"
    test_fullname = "test_fullname"
    test_path = ["test_path"]

    # Check path arg
    test_obj = _AnsiblePathHookFinder(None, test_path_ctx)
    result = test_obj.find_module(test_fullname, test_path)
    assert result is None

    # Check toplevel_pkg == 'ansible_collections'
    test_obj = _AnsiblePathHookFinder(None, test_path_ctx)
    result = test_obj.find_module(test_fullname)
    assert result is None

    # Check toplevel_pkg == 'ansible'
    test_obj = _AnsiblePathHookFinder(None, test_path_ctx)
   

# Generated at 2022-06-23 13:44:30.306075
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    ld = _AnsibleCollectionLoader(fullname="ansible_collections.foo.bar.baz")
    assert isinstance(ld, _AnsibleCollectionLoader)
    assert ld._fullname == "ansible_collections.foo.bar.baz"
    #
    # ld = _AnsibleCollectionLoader(fullname="foo.bar.baz")
    # assert isinstance(ld, _AnsibleCollectionLoader)
    # assert ld._fullname == "ansible_collections.foo.bar.baz"



# Generated at 2022-06-23 13:44:40.695473
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import io
    import sys
    import tempfile

    class _AnsibleCollectionPkgLoaderBase_load_module(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            pass

        def _get_subpackage_search_paths(self, candidate_paths):
            pass


    _AnsibleCollectionPkgLoaderBase_load_module._allows_package_code = False

    _AnsibleCollectionPkgLoaderBase_load_module._compiled_code = None

    _AnsibleCollectionPkgLoaderBase_load_module._decoded_source = None

    _AnsibleCollectionPkgLoaderBase_load_module._fullname = ''

    _AnsibleCollectionPkgLoaderBase_load_

# Generated at 2022-06-23 13:44:50.647235
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible', ['/mock/cand/path'])
    # test get_filename for a package
    assert pkg_loader.get_filename('ansible_collections.ansible') == '/mock/cand/path/ansible/__synthetic__'
    # test get_filename for a module
    assert pkg_loader.get_filename('ansible_collections.ansible.module') == '/mock/cand/path/ansible/module.py'
    # test get_filename with a non-existant module

# Generated at 2022-06-23 13:44:54.734302
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr(u'test.dummy.test_module', u'module').resource == u'test_module'
    assert AnsibleCollectionRef.try_parse_fqcr(u'test.dummy.test_module', u'role') is None
    assert AnsibleCollectionRef.try_parse_fqcr(u'test.dummy.test_module', u'playbook') is None



# Generated at 2022-06-23 13:44:59.836080
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Test case 1: Collection namespace YAML file defined
    path_list = ['ansible_collections/']
    x = _AnsibleCollectionNSPkgLoader('ansible_collections.ansible', path_list)
    assert x
    assert x.is_package('ansible_collections.ansible')
    assert x.get_filename('ansible_collections.ansible') == '<ansible_synthetic_collection_package>'
    assert len(x.get_source('ansible_collections.ansible')) == 0

    # Test case 2: Collection namespace YAML file not defined
    path_list = ['ansible_collections/']
    x = _AnsibleCollectionNSPkgLoader('ansible_collections.notexisting', path_list)

# Generated at 2022-06-23 13:45:02.532738
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder._get_filefinder_path_hook()



# Generated at 2022-06-23 13:45:04.577811
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.collection.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.collection.subdir1.subdir2.resource')


# Generated at 2022-06-23 13:45:15.557288
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """
    Tests for method AnsibleCollectionRef.from_fqcr
    """
    # test a valid fqcr with no subdirs
    r = AnsibleCollectionRef.from_fqcr(u'namespace.collection.resource', u'role')

    assert r.collection == u'namespace.collection'
    assert r.subdirs == u''
    assert r.resource == u'resource'
    assert r.ref_type == u'role'
    assert r.fqcr == u'namespace.collection.resource'
    assert r.n_python_collection_package_name == u'ansible_collections.namespace.collection'
    assert r.n_python_package_name == u'ansible_collections.namespace.collection.roles.resource'

    # test a valid fqcr with sub

# Generated at 2022-06-23 13:45:25.613827
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import os
    import sys
    import collections
    import pkgutil
    import unittest
    import tempfile
    from pathlib import Path
    from shutil import rmtree
    from unittest.mock import Mock

    # Mock the named tuple returned by pkgutil.iter_modules, as this
    # isn't defined in Python 3.6
    pkgutil_ModuleInfo = collections.namedtuple('ModuleInfo', ['name', 'loader', 'is_package'])

    # Mock the loader class, returning an empty ModuleInfo named tuple
    class MockLoader:
        def __init__(self):
            pass

        def get_filename(self):
            return ''

        def get_data(self, path):
            return ''

        def exec_module(self, module):
            pass


# Generated at 2022-06-23 13:45:37.842575
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    valid_names = [
        'ansible.test_collection',
        'ansible-test.test_collection',
        'ansible_test.test_collection',
        'ansible-test-collection.test_collection',
        'ansible_test_collection.test_collection',
        'ansible-test.test-collection',
        'ansible_test.test_collection',
        'ansible-test.test-collection',
        'ansible_test.test-collection',
        'ansible-test.test-collection'
    ]

# Generated at 2022-06-23 13:45:50.235844
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    tests = (
        ('namespace.name', True),
        ('namespace.name-with-dash', True),
        ('namespace._name_with_underscore', True),
        ('namespace.0name_with_number', False),
        ('namespace.bad:name_with_colon', False),
        ('namespace.bad name with space', False),
        ('namespace', False),
        ('name_with_no.dots', False),
        ('namespace.name.toodeep', False),
        ('ansible.builtin', False),
    )
    for test_value, result in tests:
        assert AnsibleCollectionRef.is_valid_collection_name(test_value) == result



# Generated at 2022-06-23 13:45:58.794873
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    init_args = {
        'package_name': 'galaxy.zoo.animal',
        'path_only': False,
    }
    expected_attrs = {
        '_package_to_load': 'animal',
        '_fullname': 'galaxy.zoo.animal',
        '_split_name': ['galaxy', 'zoo', 'animal'],
    }
    pkg_loader = _AnsibleCollectionPkgLoader(**init_args)
    for attr, value in expected_attrs.items():
        assert getattr(pkg_loader, attr) == value


# Generated at 2022-06-23 13:46:10.233072
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():  # skipcq: BAN-B404
    import tempfile
    tmpdir = tempfile.mkdtemp(prefix='ansible_collections_')

    # make a fake namespace
    tmpnsdir = os.path.join(tmpdir, 'nsdir')
    os.mkdir(tmpnsdir)
    with open(os.path.join(tmpnsdir, '__init__.py'), 'w') as nsinit:
        nsinit.write('\n')
    with open(os.path.join(tmpnsdir, '__init__.pyc'), 'wb') as nsinit:
        pass
    os.mkdir(os.path.join(tmpnsdir, 'collectiondir'))

# Generated at 2022-06-23 13:46:18.831440
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _meta_yml_to_dict = lambda x, y: {}
    collection_name = 'ansible.builtin'
    collection_meta = _get_collection_metadata(collection_name)
    _import_redirection = {}
    _module_file_from_path = lambda x, y: '', True, ''
    split_name = ['ansible', 'some_module']
    fullname = '.'.join(split_name)
    module_to_load = split_name[-1]
    path_list = ['/some_path']
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    assert loader.load_module(fullname)

# Generated at 2022-06-23 13:46:27.793529
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    """
    Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
    """
    _ansible_collections_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections')
    assert _ansible_collections_loader.get_filename('ansible_collections') == 'ansible/collection_loader/_ansible_collections.py', 'test__AnsibleCollectionPkgLoaderBase_get_filename() failed'
    _ansible_collections_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_plugin')
    assert _ansible_collections_loader.get_filename('ansible_collections.test_plugin') == 'plugins/test_plugin/__synthetic__', 'test__AnsibleCollectionPkgLoaderBase_get_filename() failed'


# Generated at 2022-06-23 13:46:39.449814
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Define errors
    errors = []

    # Get expected output
    expected_output = {
        'collection': 'example.collection',
        'subdirs': '',
        'resource': 'mylib',
        'ref_type': 'module_utils'
    }

    # Create AnsibleCollectionRef
    test_ACR = AnsibleCollectionRef(
        collection_name='example.collection',
        subdirs=None,
        resource='mylib',
        ref_type='module_utils'
    )

    # Append an error if any of the expected output does not match

# Generated at 2022-06-23 13:46:45.519826
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test args and return type.
    # Test when _redirect is not None
    # Test when _redirect is None

    split_name = 'ansible.builtin.raw'.split('.')
    builtin_meta = _get_collection_metadata('ansible.builtin')
    routing_entry = _nested_dict_get(builtin_meta, ['import_redirection', fullname])
    mod = import_module(self._redirect)

# Generated at 2022-06-23 13:46:56.506804
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    import collections
    r = collections.namedtuple('r', ['collection', 'subdirs', 'resource'])

# Generated at 2022-06-23 13:47:03.557599
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # This test should be run only for Python 3
    os.makedirs('/tmp/ansible_collections/my_namespace/my_collection/plugins/module_utils', exist_ok=True)
    os.makedirs('/tmp/ansible_collections/my_namespace/my_collection/plugins/modules', exist_ok=True)
    os.makedirs('/tmp/ansible_collections/my_namespace/my_other_collection/plugins/module_utils', exist_ok=True)
    os.makedirs('/tmp/ansible_collections/my_namespace/my_other_collection/plugins/modules', exist_ok=True)

# Generated at 2022-06-23 13:47:07.817844
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    from ansible.module_utils.collection_loader import _AnsibleCollectionFinder, _AnsiblePathHookFinder
    from ansible.module_utils.collection_loader import _AnsibleCollectionNSPkgLoader, _AnsibleCollectionLoader

    # Instanciate _AnsibleCollectionFinder class
    finder1 = _AnsibleCollectionFinder(scan_sys_paths=False)

    # Instanciate _AnsiblePathHookFinder class
    finder2 = _AnsiblePathHookFinder(finder1, finder1._n_configured_paths[0])

    # test method find_module
    loader1 = finder2.find_module("ansible")
    loader2 = finder2.find_module("ansible_collections")
    loader3 = finder2

# Generated at 2022-06-23 13:47:20.749305
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir_to

# Generated at 2022-06-23 13:47:26.029424
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    obj = _AnsibleCollectionFinder(paths='/foo/bar')._ansible_collection_path_hook('/foo/bar')
    repr_str = repr(obj)
    assert repr_str == "_AnsiblePathHookFinder(path='/foo/bar')"


# NB: the internal redirection loader only applies to the 'ansible' package, and exists to handle a few special cases
# where it's necessary to not commit to a specific internal API in a release, but still do something sensible.

# Generated at 2022-06-23 13:47:36.090022
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_data = [
        (u'action_plugins', u'action'),
        (u'lookup_plugins', u'lookup'),
        (u'library', u'modules')
    ]

    for test_value, expected_value in test_data:
        test_value = to_text(test_value)
        expected_value = to_text(expected_value)
        try:
            value = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_value)
        except Exception as e:
            raise AssertionError(u'Failed to parse {0} due to exception: {1}'.format(to_native(test_value), e))


# Generated at 2022-06-23 13:47:47.451662
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader, _meta_yml_to_dict

    try:
        _AnsibleCollectionPkgLoader(None, 'ansible.builtin', 'ansible_collections/ansible/builtin').load_module('ansible.builtin')
    except Exception as e:
        print(e)
        assert False
    try:
        _AnsibleCollectionPkgLoader(None, 'ansible.builtin', 'ansible_collections/ansible/builtin').load_module(
            'ansible.builtin12')
    except Exception as e:
        print(e)
        assert True

# Generated at 2022-06-23 13:47:58.682247
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'

    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugin')

    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('non_plugin')


# Generated at 2022-06-23 13:48:09.856913
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert(AnsibleCollectionRef.is_valid_fqcr('a.b.c') is True)
    assert(AnsibleCollectionRef.is_valid_fqcr('a.b.c.d') is True)
    assert(AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e') is True)
    assert(AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e.f') is True)
    assert(AnsibleCollectionRef.is_valid_fqcr('1a.b.c') is False)
    assert(AnsibleCollectionRef.is_valid_fqcr('a.1b.c') is False)

# Generated at 2022-06-23 13:48:13.712719
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    try:
        _AnsibleCollectionRootPkgLoader('foo')
    except ImportError:
        pass
    else:
        raise AssertionError()
    try:
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo')
    except ImportError:
        pass
    else:
        raise AssertionError()
    try:
        _AnsibleCollectionRootPkgLoader('ansible_collections')
    except ImportError:
        raise AssertionError()



# Generated at 2022-06-23 13:48:15.813374
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    c = _AnsibleCollectionFinder()
# End of Unit test



# Generated at 2022-06-23 13:48:23.579303
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('not_a_real_dir') == 'not_a_real_dir'
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('')



# Generated at 2022-06-23 13:48:34.501259
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    print("AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type tests")

    print("Convert 'action_plugins' to 'action':")
    print("'"+AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins")+"' should be 'action'")
    if AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action":
        print("Passed")
    else:
        print("Failed")

    print("Convert 'library' to 'modules':")
    print("'"+AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library")+"' should be 'modules'")

# Generated at 2022-06-23 13:48:43.546434
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    """
    check class AnsibleCollectionRef method try_parse_fqcr
    """
    # ansible_collections.ns.coll.subdir1.subdir2.resource
    # ansible_collections.ns.coll.subdir1.subdir2.resource.yml

    ## Parameter Request_data is not valid
    assert AnsibleCollectionRef.try_parse_fqcr(None, None) == None
    assert AnsibleCollectionRef.try_parse_fqcr('ansible_collections.ns.coll.subdir1.subdir2.resource', 'role') != None
    assert AnsibleCollectionRef.try_parse_fqcr('ansible_collections.ns.coll.subdir1.subdir2.resource.yml', 'playbook') != None
    assert AnsibleCollectionRef.try_parse_

# Generated at 2022-06-23 13:48:50.102767
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    loader = _AnsibleCollectionFinder()
    assert loader._ansible_pkg_path
    assert isinstance(loader._n_configured_paths, list)
    if loader._n_cached_collection_paths is not None:
        assert isinstance(loader._n_cached_collection_paths, list)
    if loader._n_cached_collection_qualified_paths is not None:
        assert isinstance(loader._n_cached_collection_qualified_paths, list)

# TODO: this smells like something that has to be cached at some point, so we don't keep scanning

# Generated at 2022-06-23 13:48:54.741081
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    #
    # _AnsiblePathHookFinder: <_AnsiblePathHookFinder(path='ansible_collections/somens')>
    #
    assert isinstance(_AnsiblePathHookFinder("ansible_collections/somens", "ansible_collections/somens").__repr__(), type(""))



# Generated at 2022-06-23 13:49:05.848199
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import os
    import sys
    import tempfile

    # an export of the ansible library modules
    cwd = os.path.dirname(os.path.abspath(__file__))
    # py3 as of 3.8 adds a '/' to entries in the zipfile, so we have to remove the trailing '/'
    ansiballs_root = os.path.join(os.path.dirname(cwd), "lib/ansible/modules/")[:-1]

    # create a temporary directory and add it to sys.path
    tempdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-23 13:49:15.302893
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    fullname = "ansible_collections.username.collectionname.plugins.module_utils.foo"
    paths = [
        str(Path.cwd() / "ansible_collections" / "username" / "collectionname" / "plugins" / "module_utils"),
        str(Path.cwd() / "ansible_collections" / "username" / "collectionname" / "plugins" / "modules"),
    ]
    loader = _AnsibleCollectionPkgLoaderBase(fullname, paths)

# Generated at 2022-06-23 13:49:19.981206
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    with pytest.raises(ValueError) as error:
        _AnsibleCollectionPkgLoaderBase().get_filename('ansible_collections.my_ns')
    assert 'this loader cannot find files for ansible_collections.my_ns' in to_native(error.value)



# Generated at 2022-06-23 13:49:31.152800
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    import os, sys

    test_dir = os.path.dirname(os.path.dirname(__file__))
    test_dir = os.path.dirname(test_dir)
    test_dir = os.path.join(test_dir, 'resources/collections')
    ansible_collections_dir = os.path.join(test_dir, 'ansible_collections')

    if sys.version_info[0] >= 3:
        try:
            os.rmdir(ansible_collections_dir)
        except OSError:
            pass
    else:
        try:
            os.rmdir(ansible_collections_dir)
        except WindowsError:
            pass


# Generated at 2022-06-23 13:49:42.123730
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', ref_type='module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', ref_type='role')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', ref_type='playbook')

# Generated at 2022-06-23 13:49:54.360756
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    l = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ansible')
    assert l.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'
    l = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections')
    l._subpackage_search_paths = ['.']
    assert l.__repr__() == "_AnsibleCollectionPkgLoaderBase(path=['.'])"
    l._subpackage_search_paths = []
    assert l.__repr__() == "_AnsibleCollectionPkgLoaderBase(path=[])"
    l._subpackage_search_paths = None
    assert l.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'
    l._source_

# Generated at 2022-06-23 13:50:05.389350
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    import ansible_collections

    path = unfrackpath(ansible_collections.__path__[0])
    display = Display()

    def _mock_get_data(path):
        if path.endswith('/__synthetic__'):
            return to_bytes('')
        elif path.endswith('/test_loader_module_load.py'):
            return to_bytes('dummy_value')
        else:
            return None


# Generated at 2022-06-23 13:50:16.750407
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # Test that the collection finder for Ansible 2.9.X does not
    # remove the sys.path_hooks entry for _AnsibleCollectionFinder.
    collection_finder = _AnsibleCollectionFinder()
    path = '/tmp/fake_path'
    collection_finder._ansible_collection_path_hook(path)

    # The test fails if _AnsibleCollectionFinder._ansible_collection_path_hook
    # removes the previously added sys.path_hooks entry.
    assert sys.path_hooks[0].__self__ == collection_finder
    assert sys.path_hooks[0].path == path

    # Test that the collection finder for Ansible 2.9.X does not remove
    # the sys.path_importer_cache entry for _AnsiblePathHookFinder.
   

# Generated at 2022-06-23 13:50:24.808573
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('ansible_collections.test.test_loaders', ['fake_path'])
    assert loader._fullname == 'ansible_collections.test.test_loaders'
    assert loader._split_name == ['ansible_collections', 'test', 'test_loaders']
    assert loader._package_to_load == 'test_loaders'
    assert loader._parent_package_name == 'ansible_collections.test'
    assert loader._parent_package_path == 'fake_path'
    assert loader._subpackage_search_paths == ['fake_path/test_loaders']
    assert loader._candidate_paths == ['fake_path/test_loaders']


# Generated at 2022-06-23 13:50:27.118756
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    module = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')
    module.get_code()

# Generated at 2022-06-23 13:50:35.274118
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_module_name = "ansible.module_utils.__init__"
    test_module_fullname = "ansible.module_utils.__init__"
    expected_module = "ansible.builtin.module_utils"
    loader = _AnsibleInternalRedirectLoader(test_module_name, None)
    if loader.load_module(test_module_fullname).__name__ != expected_module:
        raise AssertionError("Failed to redirect module")

# Generated at 2022-06-23 13:50:43.819951
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    import io
    import sys
    from contextlib import contextmanager
    from ansible.module_utils._text import to_bytes

    import ansible_collections
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_text
    # These are all module-private symbols, but we need to test them (even though
    # we relied on isinstance() in the past, we need to avoid that for cases where
    # some code might be importing either the AnsibleLoader or test code import from
    # the ansible.module_utils.legacy.collections.loader namespace,
    # if they were both present)
    _AnsibleCollectionPkgLoaderBase = ansible_collections.ansible.builtin.plugins.module_utils.legacy.collections.loader._AnsibleCollectionPkgLoaderBase



# Generated at 2022-06-23 13:50:54.051639
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('my.ns', 'my.ns.coll', '/path/to/my/ns/coll', [], True)
    assert not loader._redirect_module
    assert loader._fullname == 'my.ns.coll'
    assert loader._split_name == ['my', 'ns', 'coll']
    assert loader._parent_package_name == 'my.ns'
    assert loader._source_code_path is None
    assert loader._package_to_load == 'coll'
    assert loader._candidate_paths == ['/path/to/my/ns']
    assert loader._subpackage_search_paths == ['/path/to/my/ns/coll']

# Generated at 2022-06-23 13:51:06.039224
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import inspect
    import random
    import tempfile

    loader = _AnsibleCollectionPkgLoaderBase('foo.bar.baz', [])

    if '_synthetic_filename' in inspect.getmembers(loader):
        # test _synthetic_filename() while it's there...
        def test_synthetic_filename(test_case, expected_filename):
            test_case.assertEqual(loader._synthetic_filename('foo.bar.baz'), expected_filename)

        class SyntheticFilenameTestCase(unittest.TestCase):
            def test_empty_path(self):
                test_synthetic_filename(self, '<ansible_synthetic_collection_package>')


# Generated at 2022-06-23 13:51:07.988845
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader(None, 'ansible_collections.z.a.b.c')
    assert loader



# Generated at 2022-06-23 13:51:14.150265
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    path = _AnsibleCollectionPkgLoaderBase_get_test_path()
    sub_package = 'mynamespace.mycollection.mymodule'
    candidate_paths = [os.path.join(path, p) for p in sub_package.split(".")]
    loader = _AnsibleCollectionPkgLoaderBase(sub_package, path_list=candidate_paths)
    loader._get_candidate_paths = lambda path_list: path_list
    expected = ['mynamespace', 'mynamespace.mycollection', 'mynamespace.mycollection.mymodule']
    result_set = set(loader.iter_modules(prefix=None))
    expected_set = set(expected)
    assert result_set == expected_set

# Generated at 2022-06-23 13:51:21.139344
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == True

    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.with.extension') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.with.extension', 'module') == False

# Generated at 2022-06-23 13:51:32.446232
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    try:
        _AnsibleCollectionNSPkgLoader(fullname='ansible_collections.foo', path_list=['/tmp/ansible_collections/valid'])
        assert False, 'expected ValueError'
    except ValueError:
        pass

    try:
        _AnsibleCollectionNSPkgLoader(fullname='ansible_collections.somenamespace.foo', path_list=['/tmp/ansible_collections/valid'])
        assert False, 'expected ValueError'
    except ValueError:
        pass

    try:
        _AnsibleCollectionNSPkgLoader(fullname='ansible_collections.some_namespace', path_list=['/tmp/ansible_collections/invalid'])
        assert False, 'expected ImportError'
    except ImportError:
        pass




# Generated at 2022-06-23 13:51:33.571569
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    pass



# Generated at 2022-06-23 13:51:44.505746
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('ns1.coll1.res1') == AnsibleCollectionRef('ns1.coll1', '', 'res1', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns1.coll1.res1', 'role') == AnsibleCollectionRef('ns1.coll1', '', 'res1', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ns1.coll1.module.res1') == AnsibleCollectionRef('ns1.coll1', 'module', 'res1', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns1.coll1.module.res1', 'module') == AnsibleCollectionRef('ns1.coll1', 'module', 'res1', 'module')
    assert Ans

# Generated at 2022-06-23 13:51:47.778397
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(fullname='ansible.builtin', package_name='builtin',
                                        candidates=['/usr/local/lib/ansible_collections'],
                                        collection_namespace='ansible')


# Generated at 2022-06-23 13:52:00.529821
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible.tox import ToxPlugin
    plugin = ToxPlugin('test')
    type(plugin).__package__ = '__test_package__'
    import ansible_collections.test.test_plugins
    # TODO: hook tox into tox_support, so we can use tox's builtin tox_functional.test_support to get the plugin package's path
    # TODO: we'll need to use a different source code path than the one we're getting here when we do
    pkg_path = os.path.dirname(ansible_collections.test.test_plugins.__file__)
    path_list = [
        pkg_path
    ]
    loader = _AnsibleCollectionPkgLoader(path_list, plugin)
    assert loader._source_code_path

# Generated at 2022-06-23 13:52:07.635380
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():

    # Given a collection module loader
    loader = _AnsibleCollectionPkgLoaderBase(namespace='my_namespace', plugin_type='my_plugin_type',
                                             plugin_name='my_plugin_name')

    # When I call the method is_package
    ret = loader.is_package(fullname='foo')

    # Then the method is_package should not have raised any exception and ret should be False
    assert ret is False


# Generated at 2022-06-23 13:52:16.254050
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    __AnsibleCollectionPkgLoaderBase = sys.modules[__package__ + '._AnsibleCollectionPkgLoaderBase']
    fullname = 'fullname_placeholder'
    # Test with a non-empty filename
    filename = 'filename_placeholder'
    subpackage_search_paths = ['subpackage_search_paths_placeholder']
    source_code_path = 'source_code_path_placeholder'
    pkg_loader = __AnsibleCollectionPkgLoaderBase(fullname, subpackage_search_paths)
    pkg_loader._source_code_path = source_code_path
    filename_result = pkg_loader.get_filename(fullname)
    assert filename_result == source_code_path
    # Test with an empty filename
    filename = ''
    subpackage_search_path

# Generated at 2022-06-23 13:52:27.610356
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # unit test for get_filename to exercise coverage
    def test_case(module_name, search_paths):
        def source_code(module_name, search_paths):
            # see if any package path is the file we want to find
            for sp in search_paths:
                path = os.path.join(sp, module_name)
                if os.path.isfile(to_bytes(path)):
                    return path

            # see if there's a package under either search_paths candidate
            for sp in search_paths:
                path = os.path.join(sp, module_name)
                if os.path.isdir(to_bytes(path)):
                    initpath = os.path.join(path, '__init__.py')

# Generated at 2022-06-23 13:52:38.574610
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:52:43.411181
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj = AnsibleCollectionRef('collection_name', 'subdirs', 'resource', 'ref_type')
    repr_ = repr(obj)
    repr_.startswith('AnsibleCollectionRef(collection=')


# Unit tests for method test_is_valid_collection_name of class AnsibleCollectionRef

# Generated at 2022-06-23 13:52:48.499457
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    '''
    Unit test for method load_module of class _AnsibleCollectionPkgLoader
    '''

    # setup
    fake_path = '/fake/path'

# Generated at 2022-06-23 13:52:49.508210
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')



# Generated at 2022-06-23 13:53:00.607077
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import os
    import shutil
    import tempfile

# Generated at 2022-06-23 13:53:09.092897
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        td = to_native(td)

        acf = _AnsibleCollectionFinder(paths=td)

        # Test the repr implementation of _AnsiblePathHookFinder
        sample_module = 'foo'
        sub_folder = os.path.join(td, sample_module)
        os.makedirs(sub_folder)
        sub_folder_init_file = os.path.join(sub_folder, '__init__.py')
        with open(sub_folder_init_file, 'w') as f:
            f.write('def foo(): return "foo"')

        sub_module_file = os.path.join(sub_folder, 'sample.py')

# Generated at 2022-06-23 13:53:22.021436
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    class MyTestCollectionFinder():
        def find_module(self, *args, **kwargs):
            return None
    collection_finder = MyTestCollectionFinder()
    pathctx = "/home/ansibullbot/gitrepos/ansible/ansible_collections/ansible_collections/testns/testcoll"
    apf = _AnsiblePathHookFinder(collection_finder, pathctx)
    assert repr(apf) == "_AnsiblePathHookFinder(path='/home/ansibullbot/gitrepos/ansible/ansible_collections/ansible_collections/testns/testcoll')"

# TODO: all of our loaders are more or less copy-pasted from each other, with 1-2 lines changed for each. We should
# consolidate them into a single loader with a

# Generated at 2022-06-23 13:53:26.598512
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'



# Generated at 2022-06-23 13:53:35.589640
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    import tests.support
