

# Generated at 2022-06-23 13:43:43.644331
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test when _redirect is None
    # _AnsibleInternalRedirectLoader.__init__ is called before
    # _AnsibleInternalRedirectLoader.load_module, so just call it here
    # to set _redirect to None and test
    loader = _AnsibleInternalRedirectLoader('ansible.foo', ['/usr/lib/ansible/'])
    assert loader._redirect is None
    with pytest.raises(ValueError) as err:
        loader.load_module('ansible.foo')
    assert 'no redirect found for ansible.foo' in str(err.value)

    # Test when there is a redirect
    loader = _AnsibleInternalRedirectLoader('ansible.foo', ['/usr/lib/ansible/'])

# Generated at 2022-06-23 13:43:44.555879
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    pass

# Generated at 2022-06-23 13:43:54.098882
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    # Initialize module name
    module_names = ['ansible.builtin', 'ansible.builtin.plugins', 'ansible.builtin.plugins.modules', 'ansible.builtin.plugins.modules.docall', 'ansible.builtin.plugins.modules.docall.docall']
    # Initialize package to load
    package_to_load = 'docall'
    # Initialize source code path
    source_code_path = None
    # Initialize candidate paths
    candidate_paths = None
    # Initialize subpackage search paths
    subpackage_search_paths = None
    # Initialize redirect module 
    redirect_module = None
    # Initialize split name

# Generated at 2022-06-23 13:44:00.418997
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert AnsibleCollectionConfig.collection_finder is None
    _AnsibleCollectionFinder(scan_sys_paths=False)
    assert AnsibleCollectionConfig.collection_finder is not None
    assert AnsibleCollectionConfig.collection_finder._n_configured_paths == []
    assert AnsibleCollectionConfig.collection_finder._n_cached_collection_paths is None
    assert AnsibleCollectionConfig.collection_finder._n_cached_collection_qualified_paths is None
    assert AnsibleCollectionConfig.collection_finder._n_playbook_paths == []
    assert AnsibleCollectionConfig.collection_finder._ansible_pkg_path

    _AnsibleCollectionFinder._remove()
    assert AnsibleCollectionConfig.collection_finder is None
    assert AnsibleCollectionConfig.collection_finder._n_configured_paths == []

# Generated at 2022-06-23 13:44:05.711386
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ar = AnsibleCollectionRef(collection_name='namespace.collection',
                              subdirs='',
                              resource='mymodule',
                              ref_type='module')

    assert ar.__repr__() == 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'\', resource=\'mymodule\')'



# Generated at 2022-06-23 13:44:09.305163
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from collections import namedtuple
    from os import path
    import re
    import shutil
    import tempfile

    Source = namedtuple('Source', ['filename', 'source'])

# Generated at 2022-06-23 13:44:21.150234
# Unit test for method load_module of class _AnsibleCollectionPkgLoader

# Generated at 2022-06-23 13:44:29.021104
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Verify that it validates args and no subpackage search paths on normal operation
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.test', path_list=['/a/dir'])
    assert loader._subpackage_search_paths is None

    # Verify that it raises exception when no subpackage search
    # paths are found and not ansible namespace
    with pytest.raises(ImportError) as ie:
        _AnsibleCollectionNSPkgLoader('ansible_collections.no_subpckg', path_list=['/a/dir'])

    # Verify that it raises exception when invalid args in constructor

# Generated at 2022-06-23 13:44:40.456647
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    tmp_dir = tempfile.mkdtemp()
    tmp_dirs = [os.path.join(tmp_dir, 'library'),
                os.path.join(tmp_dir, 'library2/'),
                os.path.join(tmp_dir, 'library3'),
                os.path.join(tmp_dir, 'library4/'),
               ]
    for t in tmp_dirs:
        os.makedirs(t)

    p3 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.collection_name.pkg3', [tmp_dir])
    assert p3.is_package('ansible_collections.ns.collection_name.pkg3')

    # test is_package() with empty directories

# Generated at 2022-06-23 13:44:45.764529
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_name = 'namespace.collection'
    subdirs = 'subdir1.subdir2'
    resource = 'resource'
    ref_type = 'type'
    obj_A = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    obj_A.__repr__()



# Generated at 2022-06-23 13:44:52.554552
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    import ansible.utils.collection_loader
    r = ansible.utils.collection_loader.AnsibleCollectionRef.from_fqcr('dummy.collection.dir.module', 'module')
    assert r.fqcr == 'dummy.collection.dir.module'
    assert r.collection == 'dummy.collection'
    assert r.resource == 'module'
    assert r.n_python_package_name == 'ansible_collections.dummy.collection.plugins.dir.module'
    assert r.ref_type == 'module'
    assert r.n_python_collection_package_name == 'ansible_collections.dummy.collection'

    r = ansible.utils.collection_loader.AnsibleCollectionRef.from_fqcr('dummy.collection.role', 'role')

# Generated at 2022-06-23 13:44:56.730552
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # Test with the bare minimum set of arguments
    pkgloader = _AnsibleCollectionPkgLoader(path='/path/to/collections',
                                            fullname='ansible.builtin',
                                            package_to_load='builtin')
    assert pkgloader._subpackage_search_paths == []
    assert pkgloader._source_code_path == ''
    assert pkgloader._parent_package_name == 'ansible'
    assert pkgloader._package_to_load == 'builtin'
    assert pkgloader._fullname == 'ansible.builtin'
    assert pkgloader._split_name == ['ansible', 'builtin']

    # Test with a non-existent path

# Generated at 2022-06-23 13:45:05.573833
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    p = _AnsibleCollectionNSPkgLoader('ansible_collections.a')
    assert p._subpackage_search_paths is None


# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on the configured collection root path, and Python namespace package aggregation is not allowed at or below
# the collection. Implements implicit package (package dir) support for both Py2/3. Package init code is ignored
# by this loader.

# Generated at 2022-06-23 13:45:10.733601
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.random.module', '')
    return loader

# ------------------------------------------------------------------------------
# AnsibleCollectionConfig: manages the collection config, sets up the ANSIBLE_COLLECTIONS_PATHS config var
# ------------------------------------------------------------------------------


# Generated at 2022-06-23 13:45:14.319193
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('invalid')


# Generated at 2022-06-23 13:45:23.710683
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import tempfile
    # create temp dir
    tempdir = tempfile.mkdtemp()
    p = os.path.join(tempdir, 'ansible_collections', 'foo', 'bar', '__init__.py')
    os.makedirs(os.path.dirname(p))
    with open(p, 'w') as f:
        f.write('# this is a fake __init__.py\n')
    for p in [p for p in os.listdir(tempdir) if not p.startswith('.')]:
        sys.path.append(os.path.join(tempdir, p))
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', [os.path.join(tempdir, 'ansible_collections')])

# Generated at 2022-06-23 13:45:29.413897
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin', ['foo'])
    assert isinstance(loader, _AnsibleInternalRedirectLoader)
    with raises(ImportError):
        loader = _AnsibleInternalRedirectLoader('ansible.builtin2', ['foo'])
    with raises(ImportError):
        loader = _AnsibleInternalRedirectLoader('ansible.builtin.bar', ['foo'])
    with raises(ImportError):
        loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', ['foo'])
    with raises(ImportError):
        loader = _AnsibleInternalRedirectLoader('foo', ['foo'])


# Generated at 2022-06-23 13:45:36.249209
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    module_name =  "ansible_collections.foo.bar.baz.qux"
    temp_path = tempfile.mkdtemp()

    # create test file
    sub_path = os.path.join(temp_path, 'foo', 'bar', 'baz', 'qux.py')
    try:
        os.makedirs(os.path.dirname(sub_path))
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    with open(sub_path, "w") as f:
        f.write("test_data")

    # create test loader
    loader = _AnsibleCollectionPkgLoaderBase(module_name, [temp_path])

    # call get_source

# Generated at 2022-06-23 13:45:42.294077
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test basic behavior for method load_module of class _AnsibleCollectionPkgLoaderBase
    try:
        fullname = "ansible_collections.somens"
        path_list = ["/Users/foo/ansible/collections/ansible_collections"]
        instance = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
        instance.load_module(fullname)
        assert True
    except Exception as e:
        assert False, "An exception was raised: {}".format(e)

# Generated at 2022-06-23 13:45:46.648916
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    fixture_loader = _AnsibleCollectionPkgLoaderBase('foo.bar', path_list=['/tmp/ansible'])
    # FIXME: need to mock out the disk to test this, but I'm too lazy for that now
    pass



# Generated at 2022-06-23 13:45:50.649144
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    _AnsibleCollectionPkgLoader('ansible_collections.test.test', '/path/to/collection')
    #_AnsibleCollectionPkgLoader('ansible_collections.test.test', '/path/to/collection')



# Generated at 2022-06-23 13:45:51.318201
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
	pass

# Generated at 2022-06-23 13:45:52.008140
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    assert True


# Generated at 2022-06-23 13:46:01.492204
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_instance = ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_collections.__main__.ansible_col

# Generated at 2022-06-23 13:46:13.667541
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import copy
    import tempfile

    # Create the temp directory for testing
    with tempfile.TemporaryDirectory() as tmp_dir:
        # Set up the collection file structure
        collection_path = os.path.join(tmp_dir, 'ansible_collections', 'test_collection1')
        os.makedirs(collection_path)
        # Write the test data to a file
        with open(os.path.join(collection_path, 'meta', 'runtime.yml'), 'w') as f:
            f.write('# comment\ntest_data: true\n')
        # Call the (tested) method
        loader = _AnsibleCollectionPkgLoader(('test_collection1', 'test_collection1', 'test_collection1'), None, tmp_dir)

# Generated at 2022-06-23 13:46:15.220318
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert _AnsibleCollectionFinder('.') is not None


# Generated at 2022-06-23 13:46:24.909692
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import sys
    import importlib
    importlib.reload(sys)
    #sys.setdefaultencoding('utf8')
    sys.modules.clear()
    del sys.modules['ansible.utils']
    del sys.modules['ansible.utils.collection_loader']
    del sys.modules['ansible.utils.collection_loader.module_loader']

    #import ansible.utils
    import ansible.utils.module_loader
    del sys.modules['ansible.utils.module_loader']
    importlib.reload(ansible.utils.module_loader)
    #import ansible.utils.collection_loader
    import ansible.utils.collection_loader
    del sys.modules['ansible.utils.collection_loader']
    importlib.reload(ansible.utils.collection_loader)
    #import

# Generated at 2022-06-23 13:46:32.244411
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:46:41.478528
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Tests for method find_module of class
    # :class:`_AnsiblePathHookFinder`

    # this test does not run on Python 2
    if PY2:
        return
    from importlib.util import spec_from_loader
    from . import _collection_loader

    # Get a temporary collection for testing
    with _create_fake_collection() as collection_path:
        # Create the path hook finder
        finder = _AnsiblePathHookFinder(
            _AnsibleCollectionFinder(scan_sys_paths=False),
            pathctx=collection_path,
        )

        # Define the expected modules in this collection

# Generated at 2022-06-23 13:46:48.792138
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    pkg_name = 'ansible_collections.namespace'
    loader = _AnsibleCollectionLoader(pkg_name, [], allow_package_code=True)

    assert loader._fullname == pkg_name
    assert loader._split_name == ['ansible_collections', 'namespace']
    assert loader._package_to_load == 'namespace'


# Generated at 2022-06-23 13:46:58.358019
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = AnsibleCollectionRef
    # Test when a valid ref_type is passed
    assert ref.is_valid_fqcr('ns.coll.modulename', 'module')
    assert ref.is_valid_fqcr('ns.coll.rolename', 'role')

    def test_AnsibleCollectionRef_from_fqcr():
        # Test when a valid value is passed
        test_fqcr = 'ns.coll.modulename'
        ref_type = 'module'
        expected_fqcr = 'ns.coll.modulename'
        obj = AnsibleCollectionRef.from_fqcr(test_fqcr, ref_type)
        assert obj.fqcr == expected_fqcr

        # Test when an invalid value is passed

# Generated at 2022-06-23 13:47:01.336743
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    l = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert(l)

    try:
        l = _AnsibleCollectionRootPkgLoader('ansible_collections.some_name')
        assert False
    except Exception as e:
        assert True



# Generated at 2022-06-23 13:47:07.117181
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    import sys
    import json
    import imp
    import tempfile
    from ansible.utils.shlex import shlex_split

    test_dir = tempfile.mkdtemp()
    # NOTE: you need to ensure that the module name will map to the path test_dir, otherwise this will fail.
    #       this is currently true by default for builtin modules, since it uses the module_name as the path without
    #       any other prefixes. this may not be true for collections or other custom module_utils.
    module_name = os.path.basename(test_dir)
    sys.path.append(test_dir)
    module_path = os.path.join(test_dir, module_name)
    mod_path = os.path.join(module_path, '__init__.py')
    mod_file = open

# Generated at 2022-06-23 13:47:19.583025
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    """
    Tests the method try_parse_fqcr of class AnsibleCollectionRef.

    :return:
    """

    # test with well formed FQCRs
    assert AnsibleCollectionRef.try_parse_fqcr("namespace.collection.resource", "role")
    assert AnsibleCollectionRef.try_parse_fqcr("namespace.collection.resource", "module")
    assert AnsibleCollectionRef.try_parse_fqcr("namespace.collection.resource", "playbook")
    assert AnsibleCollectionRef.try_parse_fqcr("namespace.collection.subdir.resource", "role")
    assert AnsibleCollectionRef.try_parse_fqcr("namespace.collection.subdir.resource", "module")

# Generated at 2022-06-23 13:47:28.533361
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Test _AnsiblePathHookFinder._get_filefinder_path_hook
    assert hasattr(_AnsiblePathHookFinder._get_filefinder_path_hook(), '__call__')

    # Test _AnsiblePathHookFinder.__repr__
    assert repr(_AnsiblePathHookFinder(None, 'test_path')) == "AnsiblePathHookFinder(path='test_path')"


# Implements a loader for top-level packages in the ansible_collections namespace. This is the thing you get when you
# import ansible_collections.

# Generated at 2022-06-23 13:47:34.722461
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # A._AnsibleCollectionFinder_find_module_toplevel_pkg is not defined
    try: test__AnsibleCollectionFinder_find_module()
    except NameError as e: print(e)
    else: print('test__AnsibleCollectionFinder_find_module has failed')
    # A._AnsibleCollectionFinder_find_module_part_count is not defined
    try: test__AnsibleCollectionFinder_find_module()
    except NameError as e: print(e)
    else: print('test__AnsibleCollectionFinder_find_module has failed')
    # A._AnsibleCollectionFinder_find_module_path is not defined
    try: test__AnsibleCollectionFinder_find_module()
    except NameError as e: print(e)
    else: print

# Generated at 2022-06-23 13:47:42.441639
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    pathctx = 'test/test_data'
    collection_finder = _AnsibleCollectionFinder(paths=pathctx)
    instance = _AnsiblePathHookFinder(collection_finder, pathctx)
    prefix = 'test'
    result = instance.find_module('test.test_data.test_collection_loader.test_find_module', path=[pathctx])
    expected = None
    assert result == expected


# Generated at 2022-06-23 13:47:50.272826
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert(not AnsibleCollectionRef.is_valid_fqcr(''))
    assert(not AnsibleCollectionRef.is_valid_fqcr('$^))'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('*'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('*.*'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('*.*.*'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('*x.*x.*x'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('x.x.x.*'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('x.x.x.x$^)'))

# Generated at 2022-06-23 13:47:59.969399
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    raised = None
    try:
        _AnsibleInternalRedirectLoader('bad.module', '')
    except ImportError as ex:
        raised = True
    if not raised:
        raise Exception('Expected ImportError to be raised')

    raised = None
    try:
        _AnsibleInternalRedirectLoader('magic_ansible_module', '')
    except ImportError as ex:
        raised = True
    if not raised:
        raise Exception('Expected ImportError to be raised')

    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.magic', '')
    if not loader._redirect:
        raise Exception('Expected redirect to be set')


# Generated at 2022-06-23 13:48:08.315977
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    """Test for method __repr__ of class _AnsiblePathHookFinder"""
    f = _AnsiblePathHookFinder(None, None)
    ansible_test_data_loader.run_test_case(f.__repr__(), 'ansible.utils.collection_loader._AnsiblePathHookFinder(path=\'None\')')


# Possibly working on a better version of this, inspired by the private FileFinder class in importlib.util, but for
# now we're going to use the stdlib's

# Generated at 2022-06-23 13:48:17.114283
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    a = _AnsibleCollectionPkgLoaderBase(path_list=['/test/path'], fullname="test_fullname")
    assert repr(a) == '_AnsibleCollectionPkgLoaderBase(path=/test/path)'
    a = _AnsibleCollectionPkgLoaderBase(path_list=None, fullname="test_fullname")
    assert repr(a) == '_AnsibleCollectionPkgLoaderBase(path=None)'



# Generated at 2022-06-23 13:48:27.473115
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert (AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource'))
    assert (AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource'))
    assert (AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module'))
    assert (not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.extra'))
    assert (not AnsibleCollectionRef.is_valid_fqcr('ns.coll'))
    assert (not AnsibleCollectionRef.is_valid_fqcr('ns'))
    assert (not AnsibleCollectionRef.is_valid_fqcr('.resource'))
    assert (not AnsibleCollectionRef.is_valid_fqcr('ns..coll.resource'))


# Generated at 2022-06-23 13:48:35.531171
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # Test Case 1: Raise ImportError for ansible_collections.test.
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoader('ansible_collections.test')
    # Test Case 2: Raise ImportError for test.test.
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoader('test.test')
    # Test Case 3: Raise ImportError for ansible_collections.test.version
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoader('ansible_collections.test.version')



# Generated at 2022-06-23 13:48:42.877690
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # create a mock module for package ansible_collections.myns
    pkg = ModuleType('ansible_collections.myns')
    pkg.__path__ = ['<path_list>']
    pkg.__init__ = MagicMock()
    pkg.__loader__ = MagicMock(get_code=lambda x, y: 'code')
    sys.modules['ansible_collections.myns'] = pkg

    # create a mock module for package ansible_collections.myns.myns
    myns = ModuleType('ansible_collections.myns.myns')
    myns.__path__ = ['<path_list>']
    myns.__init__ = MagicMock()
    myns.__loader__ = MagicMock(get_code=lambda x, y: 'code')

# Generated at 2022-06-23 13:48:47.800455
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ldr = _AnsibleInternalRedirectLoader('ansible.module_utils.connection.utils', [])
    assert ldr.load_module('ansible.module_utils.connection.utils') == module_loader._redirect_module



# Generated at 2022-06-23 13:48:57.499611
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class _AnsibleCollectionPkgLoaderBaseTest(unittest.TestCase):
        def test_it(self):
            class TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
                def _validate_args(self):
                    pass

                def _get_candidate_paths(self, path_list):
                    pass

                def _get_subpackage_search_paths(self, candidate_paths):
                    pass

                def _validate_final(self):
                    pass

            # path is subpackage_search_paths
            loader = TestAnsibleCollectionPkgLoaderBase(fullname='namespace.collection.name', path_list=['/tmp/foo', '/tmp/bar'])

# Generated at 2022-06-23 13:49:00.190971
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    module = _AnsibleInternalRedirectLoader('test_load_module', '')
    assert module.load_module('') == ''


# ansible.builtin.plugins is a custom namespace that pulls in plugin packages from all collections

# Generated at 2022-06-23 13:49:02.526155
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'



# Generated at 2022-06-23 13:49:11.075985
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Input arguments
    fullname = 'ansible_collections.tony_collection1.testing'
    path_list = ['/tmp/collection_dir/arbitrary_dir/ansible_collections/', '/tmp/collection_dir/arbitrary_dir/ansible.builtin/']

    # Return value
    return_value = None  # default

    # Establish a patch line to mock out the needed internal method and set the appropriate return value
    with patch.object(
            _AnsibleCollectionPkgLoaderBase,
            'get_source',
            return_value=return_value
    ) as patched_get_source:
        # Create a reference to the function under test
        function_under_test = _AnsibleCollectionPkgLoaderBase(fullname, path_list)

        # Create a dictionary of the keyword arguments to

# Generated at 2022-06-23 13:49:22.078851
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    _ACPLB = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.sub_coll_name.sub_pkg_name')
    _ACPLB._subpackage_search_paths = ['/sub_coll_name/sub_pkg_name/sub_sub_pkg_name',
                                       '/sub_coll_name/sub_pkg_name',
                                       '/sub_coll_name/sub_pkg_name',
                                       '/sub_coll_name/sub_pkg_name',
                                       '/sub_coll_name/sub_pkg_name',
                                       ]
    fullname = 'ansible_collections.sub_coll_name.sub_pkg_name'
    filename = _ACPLB.get_filename(fullname)

# Generated at 2022-06-23 13:49:29.166431
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import __builtin__
    if IS_PY3:
        import builtins as __builtin__
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    #initialize the ansible meta data

# Generated at 2022-06-23 13:49:35.797654
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    pathctx = 'fixtures/test/unit/ansible_collections/testns/testcoll/plugins/module_utils'
    collection_finder = _AnsibleCollectionFinder()
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)

    # Assert that _get_filefinder_path_hook returns non-null value
    assert ansible_path_hook_finder._get_filefinder_path_hook() is not None

    # Assert the value of _filefinder_path_hook
    assert ansible_path_hook_finder._filefinder_path_hook == ansible_path_hook_finder._get_filefinder_path_hook()

    # Assert find_module returns correct value

# Generated at 2022-06-23 13:49:46.011319
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import tests.support.paths as paths
    from .collections_loader import _AnsibleCollectionPkgLoaderBase
    from ansible_collections.cluster_test.test_ns.plugins.filter.test_ns_filter import CallbackModule
    test_plugins_dir = tempfile.mkdtemp()
    paths.setup_path_injection(base_dir=os.path.dirname(CallbackModule.__file__), test_plugins_dir=test_plugins_dir)
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.cluster_test.test_ns.plugins.filter')
    expected_modules = ['test_ns_filter']

# Generated at 2022-06-23 13:49:57.663946
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # HACK - this needs to be moved down to the Method Under Test
    import json

    # TODO: move the common test code into setup() and teardown(), py2/py3 support
    test_data = json.loads(open(os.path.join(data_context().content.collection_loader._collection_path,
                                             'ansible_collections', 'ansible', 'plugins', 'module_utils', 'basic',
                                             'module_utils_basic.json')).read())

    # HACK - this needs to be moved down to the Method Under Test
    expected_filename = b'module_utils_basic.py'

# Generated at 2022-06-23 13:50:00.485815
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    af = _AnsibleCollectionFinder(paths=['./', '../'])
    assert af._n_configured_paths == ['./', '../']



# Generated at 2022-06-23 13:50:08.465359
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import types
    import collections
    import ansible_collections.community.general.plugins.module_utils.module_utils_ansible as module_utils_ansible
    from ansible.plugins.loader import module_loader
    from ansible.module_utils import common_missing_required_lib

    loader = module_loader.get(module_utils_ansible.__name__)
    assert(isinstance(loader, _AnsibleCollectionPkgLoaderBase))
    assert(isinstance(loader.get_code(loader._fullname), types.CodeType))
    assert(loader.get_code(loader._fullname) is loader._compiled_code)
    assert(loader.get_code(loader._fullname) is loader.get_code(loader._fullname))

# Generated at 2022-06-23 13:50:10.696105
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    my_ref = AnsibleCollectionRef('namespace.collection', None, 'resource', 'ref_type')
    assert my_ref


# Generated at 2022-06-23 13:50:21.414199
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert not AnsibleCollectionRef.is_valid_collection_name(u'foo')
    assert AnsibleCollectionRef.is_valid_collection_name(u'foo.bar')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'foo.bar.baz')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'foo.bar.baz.qux')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'foo.bar.123.baz.qux')
    assert AnsibleCollectionRef.is_valid_collection_name(u'foo.bar123')
    assert not AnsibleCollectionRef.is_valid_collection_name(u'foo.bar23.baz')

# Generated at 2022-06-23 13:50:23.319195
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    assert False, 'Replace this with a real unit test'



# Generated at 2022-06-23 13:50:35.418476
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert_equal(_AnsibleInternalRedirectLoader('ansible.module_utils.six', None)._redirect, 's'+'ix')
    assert_equal(_AnsibleInternalRedirectLoader('ansible.module_utils.six.moves', None)._redirect, 'six.moves')
    assert_equal(_AnsibleInternalRedirectLoader('ansible.module_utils.six.moves.configparser', None)._redirect, 'six.moves.configparser')
    assert_equal(_AnsibleInternalRedirectLoader('ansible.module_utils.six.moves.queue', None)._redirect, 'six.moves.queue')

# Generated at 2022-06-23 13:50:47.602042
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    _path_list = ['/path/to/ansible_collections/foo/bar', '/path/to/ansible_collections/foo/baz', '/path/to/ansible_collections/foo/baz/bazx']
    _fullname = 'ansible_collections.foo.bar'

    path_list = ['/path/to/ansible_collections/foo/bar', '/path/to/ansible_collections/foo/baz', '/path/to/ansible_collections/foo/baz/bazx']
    fullname = 'ansible_collections.foo.bar'

    acpl_base = _AnsibleCollectionPkgLoaderBase(fullname, path_list=path_list)
    assert acpl_base is not None
    assert acpl_base._validate_args

# Generated at 2022-06-23 13:50:49.920468
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test with toplevel_pkg != 'ansible'
    _AnsibleInternalRedirectLoader('notansible.module', '')



# Generated at 2022-06-23 13:51:02.010573
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name("foo.bar")
    assert AnsibleCollectionRef.is_valid_collection_name("foo.bar1")
    assert AnsibleCollectionRef.is_valid_collection_name("foo.bar_1")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo.")
    assert not AnsibleCollectionRef.is_valid_collection_name(".foo")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo.bar.baz")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo.bar-baz")
    assert not AnsibleCollectionRef.is_valid_collection_name("foo.bar_baz.")
    assert not AnsibleCollection

# Generated at 2022-06-23 13:51:04.525179
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    _AnsibleCollectionFinder.test__AnsibleCollectionFinder_set_playbook_paths()


# Generated at 2022-06-23 13:51:13.021580
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert _AnsiblePathHookFinder(None, '/foo').__repr__() == "_AnsiblePathHookFinder(path='/foo')"
    assert _AnsiblePathHookFinder(None, '/foo/bar').__repr__() == "_AnsiblePathHookFinder(path='/foo/bar')"


# A custom importer that essentially acts as a no-op, since at this point we're just trying to prime the collection paths

# Generated at 2022-06-23 13:51:20.766495
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_case_list = list()
    _AnsibleInternalRedirectLoader_load_module_test_case_0 = {
        'test_case_name': '_AnsibleInternalRedirectLoader_load_module_test_case_0',
        'fullname': 'test_fullname',
        'expected': AssertionError('no redirect found for test_fullname')
    }
    test_case_list.append(
        _AnsibleInternalRedirectLoader_load_module_test_case_0
    )

# Generated at 2022-06-23 13:51:26.188110
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    expected = "test_ansibullbot.plugins.collection.collection_loader._AnsiblePathHookFinder(path='/tmp')"
    actual = repr(_AnsiblePathHookFinder(None, '/tmp'))
    assert expected == actual


# Generated at 2022-06-23 13:51:34.390385
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    search_paths = [
        '/home/ansible/collection/collection1',
        '/home/ansible/collection/collection2',
        '/home/ansible/collection/collection3',
    ]
    fullname = 'ansible_collections.collection.collection1'
    package = 'collection1'
    loader = _AnsibleCollectionPkgLoader(fullname, package, search_paths)
    assert loader._package_to_load == 'collection1'
    assert loader._fullname == fullname
    assert len(loader._candidate_paths) == len(search_paths)
    assert len(loader._subpackage_search_paths) == len(search_paths)
    assert loader._source_code_path is None


# Generated at 2022-06-23 13:51:45.187627
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref1 = AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.resource', u'module')
    assert ref1 is not None
    assert ref1.fqcr == u'ns.coll.resource'

    ref2 = AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.subdir1.resource', u'module')
    assert ref2 is not None
    assert ref2.subdirs == u'subdir1'
    assert ref2.fqcr == u'ns.coll.subdir1.resource'


# Generated at 2022-06-23 13:51:53.276240
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # Test: basic
    # >>> _AnsiblePathHookFinder(collection_finder = 'value_1', pathctx = 'value_2').__repr__()
    # '_AnsiblePathHookFinder(path=\'value_2\')'
    pass


# Path-based null module importer. Used to allow discovery of submodules under the null module (which is a package)

# Generated at 2022-06-23 13:52:03.551988
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class DummyLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_final(self):
            if self._source_code_path is None and not self._subpackage_search_paths:
                raise ImportError('dummy loader only works for modules/packages with code/dirs')

    test_path = '/tmp/loader_test'
    test_module_path = os.path.join(test_path, 'ns_with_package_init.py')
    test_package_path = os.path.join(test_path, 'synthetic_package')
    test_ns_package_path = os.path.join(test_path, 'ns_with_package_init')

    def test_loader_for_file(name):
        loader = DummyLoader(name, path_list=[test_path])


# Generated at 2022-06-23 13:52:13.920571
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():  # pylint: disable=unused-variable
    from importlib.util import find_spec
    from ansible.module_utils.common.collections import AnsibleCollectionConfig
    from ansible.module_utils.common.collections import get_collection_name
    from ansible.module_utils.common.collections import get_collection_name_from_ns
    from ansible.module_utils.common.collections import get_collection_role_path
    from ansible.module_utils.common.collections import get_collection_role_names
    from ansible.module_utils.common.collections import get_collection_roles
    from ansible.module_utils.common.collections import get_collection_filter_from_ns
    from ansible.module_utils.common.collections import get_collection_filter_from_ns


# Generated at 2022-06-23 13:52:17.776810
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    from ansible.module_utils._text import to_text
    acr = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(None)


# Generated at 2022-06-23 13:52:28.516493
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    assert _AnsiblePathHookFinder is not None
    assert _AnsiblePathHookFinder.find_module is not None
    _filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    assert _filefinder_path_hook is not None
    assert isinstance(_filefinder_path_hook, type)
    _ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder=None, pathctx='/tmp')
    if PY3:
        assert 'find_module' in dir(_filefinder_path_hook)
        assert 'find_spec' in dir(_filefinder_path_hook)
    else:
        assert 'find_module' in dir(pkgutil.ImpImporter)
        assert 'find_spec' in dir

# Generated at 2022-06-23 13:52:35.963778
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    test_path_ctx = '/tmp'
    test_fullname = 'ansible.module_utils.facts'
    test_prefix = 'ansible.module_utils'
    test_collection_finder = _AnsibleCollectionFinder()
    test = _AnsiblePathHookFinder(test_collection_finder, test_path_ctx)

    assert test._get_filefinder_path_hook() == _AnsiblePathHookFinder._filefinder_path_hook
    assert test.find_module(test_fullname) == test_collection_finder.find_module(test_fullname, path=[test_path_ctx])
    assert test.iter_modules(test_prefix) == _iter_modules_impl([test_path_ctx], test_prefix)

# Generated at 2022-06-23 13:52:42.355830
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])
    assert redirect_loader._redirect == 'ansible.module_utils.basic'


# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-23 13:52:53.389427
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import tempfile
    import shutil
    import os
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_text, to_native
    # create a temp directory for mock collections
    tmp_path = tempfile.mkdtemp()
    tmp_path = to_native(tmp_path)
    os.makedirs(os.path.join(tmp_path, 'one'))

    # create the first collection
    collection_path = os.path.join(tmp_path, 'one')
    collection_path = to_native(collection_path)
    collection_root_path = os.path.join(collection_path, '.ansible')
    os.makedirs(collection_root_path)


# Generated at 2022-06-23 13:53:04.087422
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import os
    import os.path
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.utils.collection_loader import _AnsibleCollectionFinder
    import ansible.utils.plugin_docs

    # Testing the return value of the base class method get_data when called with a value of path = path_to_empty_file
    # Test Case 1: Ensuring that the get_data method returns content on disk for a file and the path is given as an absolute path as expected and we expect a non-empty string to be returned
    path_to_file = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data', 'utils', 'plugins.txt'))

# Generated at 2022-06-23 13:53:07.375888
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():  # pylint: disable=unused-argument
    finder = _AnsibleCollectionFinder([os.path.expanduser('~/ansible_collections')])

    assert "ansible_collections" in finder._n_collection_paths



# Generated at 2022-06-23 13:53:12.589342
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    # Given
    legacy_plugin_dir_name = 'filter_plugins'

    # When
    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)

    # Then
    assert result == 'filter'


# Generated at 2022-06-23 13:53:24.259200
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile
    import shutil
    import collections
    import pkgutil
    import sys
    import types

    acf = _AnsibleCollectionFinder()
    acf._install()
    sys.path_importer_cache.clear()

    def _write_fake_collection(ns, coll, path):
        if not os.path.exists(path):
            os.makedirs(path)
        for f in ['__init__.py', 'tests/__init__.py', 'tests/test_plugins.py']:
            fp = os.path.join(path, f)
            if not os.path.exists(os.path.dirname(fp)):
                os.makedirs(os.path.dirname(fp))
            with open(fp, 'w') as f:
                f

# Generated at 2022-06-23 13:53:31.685354
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')

    assert not hasattr(loader, 'module')

    loader.load_module('ansible_collections.somens')

    assert hasattr(loader, 'module')
    assert loader.module

    assert 'ansible_collections.somens' in sys.modules
    assert sys.modules['ansible_collections.somens']
    assert sys.modules['ansible_collections.somens'] == loader.module


# Generated at 2022-06-23 13:53:42.390871
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for packages with exactly one search path
    x = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=['/path/to/collection/'])
    assert x.get_filename('ansible_collections.foo') == '/path/to/collection/foo/__synthetic__'
    x = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=['/path/to/collection/'])
    assert x.get_filename('ansible_collections.foo') == '/path/to/collection/foo/__synthetic__'

    # Test for packages with more than one search path