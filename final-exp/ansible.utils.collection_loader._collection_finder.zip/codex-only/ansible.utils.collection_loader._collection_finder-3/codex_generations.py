

# Generated at 2022-06-23 13:43:41.422682
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert "action" == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins")
    assert "action" == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action")
    assert "action" == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins_")
    assert "action" == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins_asd")
    assert "role" == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library")
    assert "role" == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library_asd")

# Generated at 2022-06-23 13:43:45.593155
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    with pytest.raises(ValueError):
        loader = _AnsibleCollectionPkgLoaderBase(
            'ansible.collections.example.namespace',
            path_list=None
        )
        loader.get_source('ansible.collections.example.namespace')

# Generated at 2022-06-23 13:43:53.495374
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _TestImportLoader(_AnsibleCollectionPkgLoaderBase):
        pass

    # Test case 1: fullname = ac.ns.collection.module
    # expected:
    #           _split_name = ['ansible_collections', 'ac.ns.collection', 'module']
    #           _fullname    = 'ansible_collections.ac.ns.collection.module'
    #           _rpart_name = ('ansible_collections.ac.ns.collection', 'module')
    #           _parent_package_name = 'ansible_collections.ac.ns.collection'
    #           _package_to_load = 'module'
    fullname = 'ansible_collections.ac.ns.collection.module'
    collection_data_paths = ['some/path/to/collection']
    loader = _Test

# Generated at 2022-06-23 13:44:01.953771
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    collection_name = 'cloud_providers'
    inits_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'sanity', 'code', 'units', 'ansible_collections', collection_name, '__init__.py')
    inits_path = os.path.abspath(inits_path)
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.{0}'.format(collection_name), [os.path.dirname(inits_path)])

    assert loader.get_code('ansible_collections.{0}'.format(collection_name)) is not None



# Generated at 2022-06-23 13:44:07.782711
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert u'action' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert u'modules' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert u'lookup' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins_missing')



# Generated at 2022-06-23 13:44:16.705593
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    test_fullname = 'ansible_collections.ns.coll'
    test_pathctx = '/path/to/coll'
    collection_finder_mock = mock.MagicMock()
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder_mock, test_pathctx)
    assert ansible_path_hook_finder.__repr__() == '_AnsiblePathHookFinder(path=\'/path/to/coll\')'


# Generated at 2022-06-23 13:44:25.146492
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    try:
        _AnsibleCollectionNSPkgLoader('a.b', ['/c'])
        assert False
    except ImportError as e:
        assert e.args[0] == 'this loader can only load collections namespace packages, not a.b'


# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on the configured collection root path, and Python namespace package aggregation is not allowed at or below
# the collection. Implements implicit package (package dir) support for both Py2/3. Package init code is ignored
# by this loader.

# Generated at 2022-06-23 13:44:29.417110
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    loader = _AnsibleCollectionPkgLoaderBase(path_list=['/test/path'])
    assert loader.iter_modules('test') == []



# Generated at 2022-06-23 13:44:34.264979
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    main_ref = AnsibleCollectionRef('collection_name', 'subdirs', 'resource', 'ref_type')
    assert repr(main_ref) == 'AnsibleCollectionRef(collection=\'collection_name\', subdirs=\'subdirs\', resource=\'resource\')'



# Generated at 2022-06-23 13:44:44.333237
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    test_instance = _AnsibleCollectionPkgLoaderBase("ansible_collections.mock_collection_dir.mock_toplevel_pkg",
                                                    path_list=["/mock_path/mock_collection_dir/mock_toplevel_pkg"])

    assert(test_instance._fullname == "ansible_collections.mock_collection_dir.mock_toplevel_pkg")
    assert(test_instance._split_name == ["ansible_collections", "mock_collection_dir", "mock_toplevel_pkg"])
    assert(test_instance._rpart_name == ("ansible_collections.mock_collection_dir", ".", "mock_toplevel_pkg"))

# Generated at 2022-06-23 13:44:45.764870
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    assert _AnsibleCollectionRootPkgLoader is not None


# Generated at 2022-06-23 13:44:53.653667
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # create a symlink from current directory to the ansible_pkg/ansible/modules directory
    if not os.path.exists('modules'):
        os.symlink(os.path.join(os.path.dirname(__file__), '..', 'ansible', 'modules'), 'modules')
    ansible_mod_path = os.path.join(os.getcwd(), 'modules')
    # create an object to test the method iter_modules
    obj_AnsiblePathHookFinder = _AnsiblePathHookFinder('', [ansible_mod_path])
    # test iter_modules
    actual_result = list([m[0] for m in obj_AnsiblePathHookFinder.iter_modules(prefix=None)])

# Generated at 2022-06-23 13:44:59.431124
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    base = _AnsibleCollectionPkgLoaderBase(fullname='test_repr', path_list=['test_path'])
    assert str(base) == '_AnsibleCollectionPkgLoaderBase(path=test_path)'
    base = _AnsibleCollectionPkgLoaderBase(fullname='test_repr1')
    assert str(base) == '_AnsibleCollectionPkgLoaderBase(path=None)'



# Generated at 2022-06-23 13:45:12.204645
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-23 13:45:24.471819
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import sys
    import imp
    import tempfile
    import shutil
    import os
    import traceback
    from ansible.module_utils.six import PY3

    try:
        from importlib import reload_module
    except ImportError:
        reload_module = reload

    # Setup mocks for use with unit tests
    class MockModule:

        def __init__(self, name, **kwargs):
            self.__file__ = kwargs.get('__file__')
            self.__name__ = name
            self.__package__ = name
            self.__loader__ = kwargs.get('__loader__')
            self.__path__ = []

    class MockModuleLoader:

        def __init__(self, name, **kwargs):
            self.__name__ = name
            self.__package

# Generated at 2022-06-23 13:45:34.368639
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('fake.collection', 'path/to/fake/collection', None)
    assert loader.__repr__() == '_AnsibleCollectionPkgLoader(path=path/to/fake/collection)'

    with pytest.raises(ImportError):
        loader = _AnsibleCollectionPkgLoader('ansible_collections', 'path/to/fake/collection', None)
    with pytest.raises(ImportError):
        loader = _AnsibleCollectionPkgLoader('ansible_collections.fake', 'path/to/fake/collection', None)



# Generated at 2022-06-23 13:45:39.318400
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader("ansible.user", None)
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader("ansible.extras.user", None)
    _AnsibleInternalRedirectLoader("ansible.builtin", None)


# Generated at 2022-06-23 13:45:42.293878
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(u'a.b', u'c.d', u'e', u'modules')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='a.b', subdirs='c.d', resource='e')"

# Generated at 2022-06-23 13:45:48.253719
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    acr = AnsibleCollectionRef.try_parse_fqcr(u'foo.bar', u'module')
    assert acr.fqcr == u'foo.bar'
    assert acr.collection == u'foo.bar'
    assert acr.subdirs == u''
    assert acr.resource == u'bar'
    assert acr.ref_type == u'module'
    assert acr.n_python_package_name == u'ansible_collections.foo.bar.plugins.module'

    acr = AnsibleCollectionRef.try_parse_fqcr(u'foo.bar', u'role')
    assert acr.fqcr == u'foo.bar'
    assert acr.collection == u'foo.bar'
    assert acr.subdirs == u''
   

# Generated at 2022-06-23 13:45:59.281197
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.module_utils.common.text.converters import to_text
    for _ in sys.meta_path:
        if isinstance(_, _AnsibleCollectionFinder):
            sys.meta_path.remove(_)
    my_finder = _AnsibleCollectionFinder()
    my_finder._install()
    with open(os.path.join(os.path.dirname(__file__), '__init__.py')) as f:
        __init_module = f.read()
    with open(os.path.join(os.path.dirname(__file__), '__main__.py')) as f:
        __main_module = f.read()

# Generated at 2022-06-23 13:46:07.296081
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    import tempfile

    def create_import_module_context(module_name, module_path, parent_package_name, loader_type):
        if loader_type == '_AnsibleCollectionPkgLoader':
            loader = _AnsibleCollectionPkgLoader(module_name, parent_package_name, module_path)
        else:
            loader = _AnsibleCollectionPkgRedirectLoader(module_name, parent_package_name, module_path)


# Generated at 2022-06-23 13:46:16.941551
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    mod = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.ec2_url_utils',
                                         path_list=[])
    mod.load_module(fullname='ansible.module_utils.ec2_url_utils')
    # assert result
    # TODO: check for other redirection errors


# TODO: need to handle packaging in collections
# TODO: need to handle get_data in collections
# TODO: handle implicit packages in individual collection package entries

# TODO: look in the builtin ansible namespace for things not found in the runtime, including dups and
# the fallback to builtin if python2/3 modules exist
# TODO: handle subpackages for each ansible runtime namespace
# TODO: handle collections for each ansible runtime namespace (fallback to builtin if not found, skip duplicates)

# Generated at 2022-06-23 13:46:27.687589
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import ansible_collections.my.my_ns.plugins.module_utils.my_utils

    assert sys.modules.get('ansible_collections') is not None
    assert sys.modules.get('ansible_collections.my') is not None
    assert sys.modules.get('ansible_collections.my.my_ns') is not None
    assert sys.modules.get('ansible_collections.my.my_ns.plugins') is not None
    assert sys.modules.get('ansible_collections.my.my_ns.plugins.module_utils') is not None
    assert sys.modules.get('ansible_collections.my.my_ns.plugins.module_utils.my_utils') is not None


# Generated at 2022-06-23 13:46:35.643056
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible_collections.somens.somelib.plugins.module_utils import lookups as lookups
    assert isinstance(_AnsibleCollectionPkgLoaderBase( 'ansible_collections.somens.somelib', path_list=[os.path.dirname(lookups.__file__)] ).get_filename('ansible_collections.somens.somelib'), str)

# Generated at 2022-06-23 13:46:42.924862
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('test_name', path_list=['/test/path'])
    loader._subpackage_search_paths = []
    assert loader.is_package('test_name') is False

    loader._subpackage_search_paths = None
    assert loader.is_package('test_name') is False

    loader._subpackage_search_paths = ['/test/path/subpackage']
    assert loader.is_package('test_name') is True


# Generated at 2022-06-23 13:46:49.205216
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('ansible_collections.ns.a.b.c', [])
    loader = _AnsibleCollectionLoader('ansible_collections.a.b.c', [])
    loader = _AnsibleCollectionLoader('ansible_collections.a.builtin', [])
    return True


# Generated at 2022-06-23 13:46:55.800737
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # noinspection PyIntegrityError
    ctx = _AnsibleCollectionFinder()._ansible_collection_path_hook('/foo/bar')
    assert isinstance(ctx, _AnsiblePathHookFinder)
    assert ctx._pathctx == '/foo/bar'
    assert isinstance(ctx._filefinder_path_hook, types.BuiltinFunctionType)  # FunctionType in Python 2

# Assumes that _AnsiblePathHookFinder can be constructed!

# Generated at 2022-06-23 13:47:01.557122
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Set up test data
    collection_name = 'namespace.collectionname'
    subdirs = 'subdir1.subdir2'
    resource = 'mymodule'

    # Invoke method
    test_obj = AnsibleCollectionRef(collection_name, subdirs, resource, 'module')
    retval = test_obj.__repr__()

    # Check return value
    assert retval == "AnsibleCollectionRef(collection='namespace.collectionname', subdirs='subdir1.subdir2', resource='mymodule')"


# Generated at 2022-06-23 13:47:05.293868
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    loader = _AnsibleCollectionPkgLoaderBase('GPLv2', path_list=[])

    # test function outcome
    assert loader.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=None)'

# Generated at 2022-06-23 13:47:11.520756
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    for pkg_name, pkg_data in (
            ('../ansible_collections/foo/bar', None),
            ('../ansible_collections/foo/bar/__init__', None),
            ('../ansible_collections/foo/bar/baz', 'baz'),
    ):
        loader = _AnsibleCollectionPkgLoaderBase(pkg_name, path_list=['.'])
        actual = loader.get_source(pkg_name)
        assert actual == pkg_data, \
            "loader get_source() got {0} instead of {1}".format(actual, pkg_data)



# Generated at 2022-06-23 13:47:23.464037
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module').subdirs == 'subdir1.subdir2'
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module').resource == 'resource'
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'module').collection == 'ns.coll'

# Generated at 2022-06-23 13:47:34.579086
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ### A. setting up fixtures

    # The Ansible package (which contains ansible.builtin)
    ansible_pkg_path = os.path.dirname(import_module('ansible').__file__)

    # The contents of the ansible.builtin.plugins.module_utils package
    ansible_bultin_plugins_module_utils_path = os.path.join(ansible_pkg_path, 'lib/ansible/plugins/module_utils')


# Generated at 2022-06-23 13:47:46.624006
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # py2 doesn't support pathlib :(
    import tempfile

    from test.support import TESTFN, unlink

    class_ = _AnsiblePathHookFinder

    # Create some .py modules that can be loaded, and some data files.
    subtrue = os.path.join(TESTFN, 'subtrue')
    os.mkdir(subtrue)
    with open(os.path.join(subtrue, '__init__.py'), 'w') as file:
        file.write('# package')
    with open(os.path.join(subtrue, 'one.py'), 'w') as file:
        file.write('# module one')
    with open(os.path.join(subtrue, 'two.py'), 'w') as file:
        file.write('# module two')

# Generated at 2022-06-23 13:47:59.097766
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import ansible_collections.test.collection1.plugins.module_utils.basic as basic
    assert(basic.loader._AnsibleCollectionPkgLoaderBase.is_package(fullname="ansible_collections.test.collection1.plugins") == False)
    assert(basic.loader._AnsibleCollectionPkgLoaderBase.is_package(fullname="ansible_collections.test.collection1.plugins.module_utils") == True)
    assert(basic.loader._AnsibleCollectionPkgLoaderBase.is_package(fullname="ansible_collections.test.collection1.plugins.module_utils.basic") == True)

# Generated at 2022-06-23 13:48:10.449638
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test case with empty path
    with pytest.raises(ValueError) as e:
        _AnsibleCollectionPkgLoaderBase.get_data(None)
    assert 'must be specified' in str(e.value)

    # Test case with relative path
    with pytest.raises(ValueError) as e:
        _AnsibleCollectionPkgLoaderBase.get_data('relative_path')
    assert 'relative resource paths not supported' in str(e.value)

    # Test case with non existing file
    with pytest.raises(Exception) as e:
        _AnsibleCollectionPkgLoaderBase.get_data(os.path.join(os.path.realpath(os.getcwd()), 'not_existing_file'))
    assert 'open' in str(e.value)

    # Test

# Generated at 2022-06-23 13:48:21.625791
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Create a temporary directory for testing.
    with tempfile.TemporaryDirectory() as tmpdir:
        # This directory is created so that we can copy a real python package.
        # This real python package is used to test if the constructor creates an object for a
        # valid python package.
        python_pkg_path = os.path.join(tmpdir, 'pkg')
        os.mkdir(python_pkg_path)
        shutil.copytree(os.path.join(os.path.dirname(__file__), 'data', 'pkg'), python_pkg_path)

        # This directory is created so that we can copy a real python module.
        # This real python module is used to test if the constructor creates an object for a
        # valid python module.

# Generated at 2022-06-23 13:48:32.911847
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import tempfile
    import shutil

    # we need to create temp dirs and files, but we must use the native path sep
    # or else the tests will fail on windows
    if os.path.sep == '\\':
        temp_dir_prefix = 'C:\\Windows\\Temp\\test_collections_'
    else:
        temp_dir_prefix = '/tmp/test_collections_'

    def create_test_dirs(temp_dir_prefix=temp_dir_prefix):
        # create the test dirs
        test_dir = tempfile.mkdtemp(prefix=temp_dir_prefix)
        collection_dir = 'somenamespace-somecollection'
        namespace_dir = os.path.join(test_dir, 'ansible_collections', collection_dir)

# Generated at 2022-06-23 13:48:37.264922
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # __init__ of _AnsibleCollectionPkgLoaderBase object
    p = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll')

    assert p.is_package('ansible_collections.test_ns.test_coll')



# Generated at 2022-06-23 13:48:46.007581
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    """Test the constructor of class _AnsibleInternalRedirectLoader

    """
    with pytest.raises(ImportError, match='not interested'):
        _AnsibleInternalRedirectLoader('test', [])

    builtin_meta = _get_collection_metadata('ansible.builtin')

# Generated at 2022-06-23 13:48:50.338114
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    p = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    assert isinstance(p, _AnsibleCollectionPkgLoaderBase)
    assert p.is_package('ansible_collections.somens')


# Generated at 2022-06-23 13:48:59.114343
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # test collection found
    foo_loader = _AnsibleCollectionPkgLoader('foo.bar.baz', get_all_collection_paths(['/tmp/path']), 'some_file.py')
    assert foo_loader._subpackage_search_paths == ['/tmp/path/foo/bar/baz']

    # test collection not found
    missing_loader = _AnsibleCollectionPkgLoader('mynamespace.mycollection.my', get_all_collection_paths(['/tmp/path']), 'some_file.py')
    assert missing_loader._subpackage_search_paths == []



# Generated at 2022-06-23 13:49:02.196258
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', ['/tmp/'])
    path = '/tmp/foo'
    assert isinstance(loader.get_data(path), bytes)



# Generated at 2022-06-23 13:49:11.525155
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import subprocess
    import tempfile
    import metaplugin

    # todo
    # create temp file and add some python code
    # create loader and return source code
    # delete file

    # create temp file
    temp_file = tempfile.TemporaryFile()
    temp_file.write(b'print("Hi!")\n')
    temp_file.seek(0)

    # create loader object and set needed attrs
    loader = _AnsibleCollectionPkgLoaderBase('test_loader_object')
    loader._split_name = 'test_loader_object'.split('.')
    loader._rpart_name = 'test_loader_object'.rpartition('.')
    loader._fullname = 'test_loader_object'
    loader._source_code_path = temp_file.name
    loader._validate_args

# Generated at 2022-06-23 13:49:22.155319
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Tests for __init__ method
    obj = _AnsibleInternalRedirectLoader('ansible.module_utils.other', 'path')
    assert obj._redirect == None
    assert obj.load_module('ansible.module_utils.other') == None


# Implements Ansible's custom import logic for Python modules.
# Ansible has custom logic for locating plugins and other modules within collections, as well as custom logic for
# locating modules that are part of the Ansible project (in the ansible.builtin collection). This loader
# is used as a path_hook importer that understands all of Ansible's import mechanics and proxies everything else to
# the builtin import mechanisms. The proxy is necessary to avoid any issues with the builtin import cache (where
# subsequent imports of an internal Ansible module would fail if we didn't first use the builtin import mechanisms
# to

# Generated at 2022-06-23 13:49:32.248508
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    path_list = ['/home/centos/projects/ansible/mazer/test/integration/targets/testsh/testsh/ansible_collections/test_col/plugins/modules/']
    fullname = 'test_col.test_at'    
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert loader._package_to_load == 'test_at'
    loader._validate_final()
    source = loader.get_source('ansible_collections.test_col.test_at')

# Generated at 2022-06-23 13:49:43.965261
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    candidate_paths = ['/tmp/mypath']
    subpackage_search_paths = ['/tmp/mypath/mypackage']
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.mypackage',
        candidate_paths=candidate_paths, subpackage_search_paths=subpackage_search_paths)

    assert loader._fullname == 'ansible_collections.mypackage'
    assert loader._redirect_module == None
    assert loader._split_name == ['ansible_collections', 'mypackage']
    assert loader._rpart_name == ('ansible_collections', '.', 'mypackage')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'mypackage'
    assert loader._source_code

# Generated at 2022-06-23 13:49:46.161340
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    d = _AnsibleCollectionPkgLoaderBase(fullname='ansible.plugins')
    assert repr(d) == '_AnsibleCollectionPkgLoaderBase(path=/Users/michael/source/python-ansible/lib/ansible/plugins)'



# Generated at 2022-06-23 13:49:57.757865
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr(u'acme.rolename1', 'role')
    assert ref.collection == u'acme'
    assert ref.subdirs == u''
    assert ref.resource == u'rolename1'
    assert ref.ref_type == 'role'
    assert ref.fqcr == u'acme.rolename1'

    ref = AnsibleCollectionRef.from_fqcr(u'acme.rolename2.rolename1', 'role')
    assert ref.collection == u'acme'
    assert ref.subdirs == u'rolename2'
    assert ref.resource == u'rolename1'
    assert ref.ref_type == 'role'
    assert ref.fqcr == u'acme.rolename2.rolename1'

   

# Generated at 2022-06-23 13:50:05.690975
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('galactic.federation.star_fleet', ['/tmp/galactic/federation/star_fleet/'])
    assert loader._split_name == ['galactic', 'federation', 'star_fleet']
    assert loader._package_to_load == 'star_fleet'
    assert loader._parent_package_name == 'galactic.federation'
    assert loader._fullname == 'galactic.federation.star_fleet'
    assert loader._candidate_paths == ['/tmp/galactic/federation/star_fleet/']
    assert loader._subpackage_search_paths == ['/tmp/galactic/federation/star_fleet/']


# Generated at 2022-06-23 13:50:17.034392
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import plugin_loaders

    # NOTE: the collection finder should NOT be installed yet, this should drive the unit test in isolation
    assert not AnsibleCollectionConfig.collection_finder

    # NOTE: the _AnsiblePathHookFinder class can't be used in isolation because it relies on the collection_finder
    # to be already initialized, so the unit test is in this class

    # NOTE: path_hook is not supposed to receive a path parameter, but we need to test it, so we disable the
    # check in `_AnsiblePathHookFinder.find_module`.
    collection_finder = AnsibleCollectionConfig.collection_finder = _AnsibleCollectionFinder.__new__(_AnsibleCollectionFinder)
    collection_finder._n_configured_path

# Generated at 2022-06-23 13:50:25.539306
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert 'action' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert 'cliconf' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins')
    assert 'connection' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins')
    assert 'httpapi' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('httpapi_plugins')
    assert 'lookup' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins')
    assert 'cache' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins')
    assert 'terminal' == AnsibleCollectionRef.legacy_plugin_

# Generated at 2022-06-23 13:50:34.593609
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Given
    fullname = 'ansible_collections.ns.collection_name.plugins.module_utils.helper'
    path_list = ['/path/to/ns/collection_name']
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)

    # When
    actual = loader.get_filename(fullname)

    # Then
    expected = os.path.join(to_bytes(path_list[0]), to_bytes('plugins/module_utils/helper/__synthetic__'))
    assert actual == expected

# Generated at 2022-06-23 13:50:43.369235
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder = _AnsibleCollectionFinder()
    assert ansible_collection_finder.find_module("ansible") == None
    assert ansible_collection_finder.find_module("ansible.module_utils") == None
    assert ansible_collection_finder.find_module("ansible_collections") == None
    assert ansible_collection_finder.find_module("ansible_collections.ns") == None
    assert ansible_collection_finder.find_module("ansible_collections.ns.collection") == None
    assert ansible_collection_finder.find_module("ansible_collections.ns.collection.plugins") == None
    assert ansible_collection_finder.find_module("ansible_collections.ns.collection.plugins.module_utils") == None
    assert ansible_collection_finder

# Generated at 2022-06-23 13:50:54.662358
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import collections
    import inspect
    import tempfile
    import types
    from ansible_collections import foo_baz

    loader = _AnsibleCollectionPkgLoaderBase(__name__)
    # Test if the code object returned by method get_code is of type CodeType
    assert isinstance(loader.get_code(__name__), types.CodeType)
    # Test if the code object returned by method get_code contains all the required attributes

# Generated at 2022-06-23 13:51:06.459579
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # 1. validate_args, get_candidate_paths, get_subpackage_search_paths, validate_final
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar')

    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar', ['ns1', '/ns2/foo/bar'])

    assert isinstance(_AnsibleCollectionRootPkgLoader('ansible_collections', ['ns1', '/ns2/foo/bar']),
                      _AnsibleCollectionRootPkgLoader)

    # 2. load_module()
    # 2.1. _new_or_existing_module()

# Generated at 2022-06-23 13:51:16.149740
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # testing constructor of class AnsibleCollectionRef
    assert AnsibleCollectionRef('ns.coll', 'subdir', 'resource', 'role')
    assert AnsibleCollectionRef('ns.coll', None, 'resource', 'role')
    assert AnsibleCollectionRef('ns.coll', 'subdir.subdir2', 'resource', 'role')
    assert AnsibleCollectionRef('ns.coll', 'subdir.subdir2.subdir3', 'resource', 'role')

    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir', 'resource', 'bad_type')

    with pytest.raises(ValueError):
        AnsibleCollectionRef('ns.coll', 'subdir', 'resource.', 'role')


# Generated at 2022-06-23 13:51:29.198277
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Initialise the environment
    current_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    sys.path.insert(0, current_dir)
    os.chdir(current_dir)
    import ansible
    sys.modules['ansible'] = ansible

    finder = _AnsibleCollectionFinder()
    finder._install()
    assert not finder.collection_finder != finder

    root = os.path.join(current_dir, 'test', 'units', 'utils', 'find_collection')
    os.environ['ANSIBLE_COLLECTIONS_PATH'] = root

# Generated at 2022-06-23 13:51:40.705498
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('terminal_plugins') == 'terminal'

# Generated at 2022-06-23 13:51:49.681312
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    cplb = _AnsibleCollectionPkgLoaderBase('mocked_name', path_list=['mocked_path'])
    cplb._subpackage_search_paths = ['mocked_subpackage_search_path']
    cplb._redirect_module = 'mocked_redirect_module'
    cplb._fullname = 'test_fullname'

    res = cplb.load_module('foo')
    assert res == 'mocked_redirect_module'

    # get_code is mocked to just return 'mocked_code_obj' to prevent execution of the code
    cplb._subpackage_search_paths = None
    cplb.get_code = lambda x: 'mocked_code_obj'
    res = cplb.load_module('foo')

# Generated at 2022-06-23 13:51:57.052470
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    """
    Test the constructor of class _AnsiblePathHookFinder
    """
    _ansible_collection_finder = _AnsibleCollectionFinder()
    _path_hook_finder = _AnsiblePathHookFinder(_ansible_collection_finder, '/usr/share/ansible')
    assert str(_path_hook_finder) == "_AnsiblePathHookFinder(path='/usr/share/ansible')"


# Generated at 2022-06-23 13:52:06.541241
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    assert t._AnsibleCollectionPkgLoaderBase._module_file_from_path('__init__.py', '.') == ('./__init__.py', True, None)
    assert t._AnsibleCollectionPkgLoaderBase._module_file_from_path('__init__.py', './ansible_collections') == ('./ansible_collections/__init__.py', True, './ansible_collections')
    assert t._AnsibleCollectionPkgLoaderBase._module_file_from_path('__init__.py', './ansible_collections/some_namespace') == ('./ansible_collections/some_namespace/__init__.py', True, './ansible_collections/some_namespace')
    assert t._AnsibleCollectionPkgLoaderBase._module_

# Generated at 2022-06-23 13:52:13.660250
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # Check for False when collection_name fails length check
    assert not AnsibleCollectionRef.is_valid_collection_name('')
    # Check for False when collection_name is None
    assert not AnsibleCollectionRef.is_valid_collection_name(None)
    # Check for False when collection_name's namespace is not a valid Python identifier
    assert not AnsibleCollectionRef.is_valid_collection_name('1_ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('invalid-ns.coll')
    # Check for False when collection_name's namespace is a Python keyword
    assert not AnsibleCollectionRef.is_valid_collection_name('for.coll')
    # Check for False when collection_name's name is not a valid Python identifier

# Generated at 2022-06-23 13:52:26.008237
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    conf = AnsibleCollectionConfig()
    loader = _AnsibleCollectionPkgLoader('ansible.collections.foo.bar', 'baz', conf)
    loader = _AnsibleCollectionPkgLoader('ansible.collections.foo.bar.baz', '', conf)
    loader = _AnsibleCollectionPkgLoader('ansible.collections.ansible_namespace.bar.baz', '', conf)
    loader = _AnsibleCollectionPkgLoader('ansible.collections.ansible_namespace.ansible_builtin.baz', '', conf)
    loader = _AnsibleCollectionPkgLoader('ansible.collections.ansible_namespace.ansible_builtin.baz', '', conf)

# Generated at 2022-06-23 13:52:35.952919
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class _AnsibleCollectionPkgLoader_load_module():
        def __init__(self):
            self._meta_yml_to_dict = None

    def test_method(self):
        fullname = 'ansible.collection.nginx'
        _AnsibleCollectionConfig.on_collection_load.fire(collection_name='ansible.collection.nginx',
                                                         collection_path='/home/jdoe/ansible_collections/nginx')
        self._split_name = ['ansible', 'collection', 'nginx']
        self._package_to_load = 'nginx'
        self._parent_package_name = 'ansible.collection'
        self._fullname = 'ansible.collection.nginx'

# Generated at 2022-06-23 13:52:41.134889
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource1', 'callback')
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource1')"


# Generated at 2022-06-23 13:52:43.364365
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'



# Generated at 2022-06-23 13:52:50.837726
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test a correct constructor
    try:
        loader = _AnsibleInternalRedirectLoader('ansible.builtin.service', None)
        assert loader._redirect == 'ansible.legacy.service'
    except ImportError:
        # raise an error
        assert False

    # test an error for non-ansible package
    try:
        loader = _AnsibleInternalRedirectLoader('test.builtin', None)
        # raise an error
        assert False
    except ImportError:
        # pass
        pass

    # test an error for not redirected package name
    try:
        loader = _AnsibleInternalRedirectLoader('ansible.builtin.subprocess', None)
        # raise an error
        assert False
    except ImportError:
        # pass
        pass


#
# Path hooks
#


# Generated at 2022-06-23 13:53:01.326050
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    path_list = [to_native(p) for p in ['/tmp/ansible_collections/dummy_collection/ns1/module1',
                                       '/tmp/ansible_collections/dummy_collection/ns1/module1/ns2']]

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.dummy_collection.ns1.module1', path_list=path_list)
    assert to_text(loader.get_source('ansible_collections.dummy_collection.ns1.module1')) == 'this is dummy_collection.ns1.module1'
    assert to_text(loader.get_source('ansible_collections.dummy_collection.ns1.module1.ns2')) == 'this is dummy_collection.ns1.module1.ns2'


# Generated at 2022-06-23 13:53:06.823704
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    import ansible.utils.collection_loader
    assert ansible.utils.collection_loader.__name__ == 'ansible.utils.collection_loader'
    # As _AnsibleCollectionLoader is created as a function, so it can not be instantiated.
    try:
        al = ansible.utils.collection_loader.AnsibleCollectionLoader()
    except TypeError as e:
        assert "Can't instantiate abstract class AnsibleCollectionLoader with abstract methods" == str(e)

# Generated at 2022-06-23 13:53:12.558094
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('my_namespace', 'my_collection', 'my_module')

    assert loader._fullname == 'my_namespace.my_collection.my_module', \
        "Failed to initialize _AnsibleCollectionLoader with fullname: %s" % loader._fullname


# Generated at 2022-06-23 13:53:24.257562
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    ansible_collections_paths = ["/foo/bar", "/foo/bar/bar1"]
    with pytest.raises(ImportError):
        loader = _AnsibleCollectionRootPkgLoader("ansible_collections.foo", ansible_collections_paths)

    loader = _AnsibleCollectionRootPkgLoader("ansible_collections", ansible_collections_paths)
    assert loader._fullname == 'ansible_collections'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', 'ansible_collections', '')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path

# Generated at 2022-06-23 13:53:32.951279
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    path_hook_finder = _AnsiblePathHookFinder(
        collection_finder=_AnsibleCollectionFinder(
            paths=['/tmp'],
            scan_sys_paths=False,
        ),
        pathctx='/tmp/ansible_collections',
    )
    path_hook_finder.find_module = lambda name, path: True
    path_hook_finder.iter_modules = _AnsiblePathHookFinder.iter_modules.__func__
    # This test concerns only the logic of the method iter_modules. So
    # we need to mock any method or property called from iter_modules.
    path_hook_finder._test_iter_modules__listdir = lambda directory: ['a', 'b', 'c', 'd']
    path_hook_finder._test_iter_modules__isd