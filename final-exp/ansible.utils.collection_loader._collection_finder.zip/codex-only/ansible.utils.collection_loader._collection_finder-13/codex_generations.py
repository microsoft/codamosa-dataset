

# Generated at 2022-06-23 13:43:39.459610
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    path = '/tmp'
    package_to_load = 'ansible'
    _AnsibleCollectionLoader(path, package_to_load)


# Generated at 2022-06-23 13:43:49.334958
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cache_plugins') == u'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cliconf_plugins') == u'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'connection_plugins') == u'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'doc_fragments') == u'doc_fragments'

# Generated at 2022-06-23 13:43:55.602963
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible_collections.ansible.builtin import ansible_python_pkg_mgr_config as apc
    from ansible_collections.ansible.builtin import ansible_python_pkg_mgr_utils as apu

    init_s = "__all__ = ['foo', 'bar']\n"
    foo_s = "def foo(arg):\n    return 'foo'\n"
    bar_s = "def bar():\n    return 'bar'\n"

    class MyLoader(_AnsibleCollectionPkgLoaderBase):
        def _get_subpackage_search_paths(self, candidate_paths):
            if self._package_to_load == 'pkg':
                return candidate_paths
            return []

    # checked with i_path
    i_path, s_path = ap

# Generated at 2022-06-23 13:44:07.577206
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Valid cases
    AnsibleCollectionRef(collection_name='ansible.test',
                         subdirs=None,
                         resource='test_module',
                         ref_type='module')
    AnsibleCollectionRef(collection_name='ansible.test',
                         subdirs='first.second',
                         resource='test_module',
                         ref_type='module')
    AnsibleCollectionRef(collection_name='ansible.test',
                         subdirs=None,
                         resource='test_filter',
                         ref_type='filter')
    AnsibleCollectionRef(collection_name='ansible.test',
                         subdirs='first.second',
                         resource='test_module',
                         ref_type='module')

# Generated at 2022-06-23 13:44:14.147752
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader.load_module('ansible_collections') is not None
    with raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.whatever')
    with raises(ImportError):
        _AnsibleCollectionRootPkgLoader('whatever')



# Generated at 2022-06-23 13:44:26.278054
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    collection_finder = _AnsibleCollectionFinder()

    collection_finder.set_playbook_paths([])

    assert collection_finder.find_module('ansible.module_utils.basic') is not None

    assert collection_finder.find_module('ansible_collections') is not None
    assert collection_finder.find_module('ansible_collections', path=[]) is not None

    # Path is mandatory for subpackages
    assert collection_finder.find_module('ansible_collections.foo') is None
    assert collection_finder.find_module('ansible_collections.foo', path=['ansible_collections']) is not None

    # Path is mandatory for collections
    assert collection_finder.find_module('ansible_collections.foo.bar') is None

# Generated at 2022-06-23 13:44:36.320033
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = 'ansible.module_utils.network.nxos.plugins.modules.nxos_hsrp'
    foo = _AnsiblePathHookFinder(collection_finder, pathctx)
    assert str(foo) == "_AnsiblePathHookFinder(path='ansible.module_utils.network.nxos.plugins.modules.nxos_hsrp')"
    testMod = 'ansible.module_utils.network.nxos.plugins.modules.nxos_hsrp.nxos_hsrp'
    modules = list(foo.iter_modules(prefix=None))
    assert len(modules) > 0



# Generated at 2022-06-23 13:44:38.060188
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Constructor
    _AnsibleCollectionFinder()



# Generated at 2022-06-23 13:44:48.790850
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # test for a non-package file
    l = _AnsibleCollectionPkgLoaderBase('dummy', path_list=[])
    l._source_code_path = '/path/to/nothing'
    assert l.get_source('dummy') is None

    # test for a non-existent file
    l = _AnsibleCollectionPkgLoaderBase('dummy', path_list=[])
    l._source_code_path = '/path/to/nothing/file.py'
    assert l.get_source('dummy') == ''

    # test for an actual file
    l = _AnsibleCollectionPkgLoaderBase('dummy', path_list=[])
    l._source_code_path = os.path.join('test', 'support', 'ansible_pkg_loaders_data', 'file.py')

# Generated at 2022-06-23 13:44:58.099999
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansiblecollectionref_obj = AnsibleCollectionRef(collection_name='namespace.collection',
                                                    subdirs='subdir1.subdir2',
                                                    resource='resource_name',
                                                    ref_type='modules')
    ansiblecollectionref_repr = ansiblecollectionref_obj.__repr__()
    assert ansiblecollectionref_repr == 'AnsibleCollectionRef(collection=\'namespace.collection\', ' \
                                        'subdirs=\'subdir1.subdir2\', resource=\'resource_name\')'

# Generated at 2022-06-23 13:45:09.744357
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    f = _AnsibleCollectionPkgLoaderBase
    assert f(fullname="ansible_collections.foo").__repr__() == "AnsibleCollectionPkgLoaderBase(path=[])"
    assert f(fullname="ansible_collections.foo", path_list=['/abspath']).__repr__() == "AnsibleCollectionPkgLoaderBase(path=[u'/abspath/foo'])"
    assert f(fullname="ansible_collections.foo", path_list=['/abspath1', '/abspath2']).__repr__() == "AnsibleCollectionPkgLoaderBase(path=[u'/abspath1/foo', u'/abspath2/foo'])"



# Generated at 2022-06-23 13:45:12.934664
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert _AnsiblePathHookFinder(collection_finder, '/some/path')._pathctx == '/some/path'


# Generated at 2022-06-23 13:45:20.310246
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    from ansible.utils._collection_finder import _AnsibleCollectionFinder
    paths = ["~/ansible", "~/ansible1", "~/ansible2"]
    playbook_paths = ["~/ansible/collections", "~/ansible1/collections", "~/ansible2/collections"]
    ansible_collection_finder = _AnsibleCollectionFinder(paths=paths, scan_sys_paths=True)
    # Test when playbook_paths is string type
    ansible_collection_finder.set_playbook_paths(playbook_paths[0])
    assert ansible_collection_finder._n_playbook_paths == playbook_paths[0:1]

    # Test when playbook_paths is list type
    ansible_collection_finder.set_playbook

# Generated at 2022-06-23 13:45:27.944442
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import tempfile
    import shutil
    import os

    test_collections = os.path.join(os.path.dirname(__file__), 'test_data', 'test_collections')
    # Create temporary directory to put collection files
    tmp_dir = tempfile.mkdtemp()

    # Create multiple paths to test
    multiple_paths = []
    for i in range(3):
        tmp_path = os.path.join(tmp_dir, str(i))
        os.makedirs(tmp_path)
        shutil.copytree(test_collections, os.path.join(tmp_path, 'collections'))
        multiple_paths.append(tmp_path)

    # Create duplicate path to test

# Generated at 2022-06-23 13:45:35.165846
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.dummy.collection', path_list=['/tmp'])
    assert loader._fullname == 'ansible_collections.dummy.collection'
    assert loader._split_name == ['ansible_collections', 'dummy', 'collection']
    assert loader._rpart_name == ('ansible_collections.dummy', '.', 'collection')
    assert loader._parent_package_name == 'ansible_collections.dummy'
    assert loader._package_to_load == 'collection'

    assert loader._redirect_module is None
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None


# Generated at 2022-06-23 13:45:47.097623
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data/import_playbook'))
    sys.modules.pop('ansible_collections', None)
    sys.modules.pop('ansible_collections.my.vers', None)
    sys.modules.pop('ansible_collections.my', None)
    sys.modules.pop('ansible_collections.net', None)
    sys.modules.pop('ansible', None)

# Generated at 2022-06-23 13:45:58.645487
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-23 13:46:05.787718
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import os
    loader = None
    try:
        loader = _AnsibleInternalRedirectLoader('tst.tst', ['tst'])
        assert loader._redirect == None
        loader = _AnsibleInternalRedirectLoader('ansible.tst', ['tst'])
        assert loader._redirect != None
    except ImportError as ex:
        print(ex)
        # assert os.getenv('ANSIBLE_UNIT_TEST', False) == True

#####################################################################################
#
# Code to handle loading/implementing the ansible_collections namespace package (and related packages)
#
#####################################################################################


# Generated at 2022-06-23 13:46:09.025704
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import_module('_ansible_collections_finder_util.unit_tests.test_ansible_collections_path_hook_finder')


# Generated at 2022-06-23 13:46:20.233498
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import os
    import tempfile

    class _AnsibleCollectionPkgLoaderBase_Mock(object):
        def __init__(self, fullname, path_list=None): # pass path_list here
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens
            self._source_code_path = None

# Generated at 2022-06-23 13:46:30.036143
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    from collections import namedtuple

# Generated at 2022-06-23 13:46:40.398989
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    cref = AnsibleCollectionRef.from_fqcr('a.b.c','plugins')
    assert cref.collection == 'a.b'
    assert cref.subdirs == 'c'
    assert cref.resource == 'c'
    assert cref.ref_type == 'plugins'
    assert cref.n_python_collection_package_name == 'ansible_collections.a.b'
    assert cref.n_python_package_name == 'ansible_collections.a.b.plugins.c'

    cref = AnsibleCollectionRef.from_fqcr('a.b.c.d','plugins')
    assert cref.collection == 'a.b'
    assert cref.subdirs == 'c.d'
    assert cref.resource == 'd'
    assert cref

# Generated at 2022-06-23 13:46:47.819471
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert repr(_AnsiblePathHookFinder(None,'/path/to/whatever')) in (
        '_AnsiblePathHookFinder(path=\'/path/to/whatever\')',  # python2
        '_AnsiblePathHookFinder(path=\'/path/to/whatever\')',  # python3
    )

# Generated at 2022-06-23 13:46:57.769216
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr(u'col.name.subdir1.subdir2.myresource', u'module') == AnsibleCollectionRef(u'col.name', u'subdir1.subdir2', u'myresource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'col.name.subdir1.subdir2', u'role') == AnsibleCollectionRef(u'col.name', u'subdir1.subdir2', u'', u'role')
    assert AnsibleCollectionRef.from_fqcr(u'col.name.rolename', u'role') == AnsibleCollectionRef(u'col.name', u'', u'rolename', u'role')

# Generated at 2022-06-23 13:47:03.875961
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ValueError) as e:
        _AnsibleCollectionRootPkgLoader('.ansible_collections')
    with pytest.raises(ImportError) as e:
        _AnsibleCollectionRootPkgLoader('ansible_collections.totp')



# Generated at 2022-06-23 13:47:11.933491
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test 1
    import ansible.utils.collection_loader as cl
    cl._meta_yml_to_dict = lambda a, b: {'plugin_routing': {'module': {'ansible.builtin': {'redirect': 'ansible.python.modules.module_utils.basic'}}}}
    loader = _AnsibleCollectionPkgLoader(package_to_load='ansible')
    loader._load_module()
    
    # Test 2
    cl._meta_yml_to_dict = lambda a, b: {'plugin_routing': {'module': {'ansible.builtin': {'redirect': 'ansible.python.modules.module_utils.basic'}}}}
    loader = _AnsibleCollectionPkgLoader(package_to_load='ansible.builtin')
    loader._

# Generated at 2022-06-23 13:47:23.778108
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    test_data = [
        'namespace.coll_name',
        'namespace.coll_name123',
        'namespace.coll_name_123',
        'namespace.coll_name-123',
        'namespace.coll_name',
        'namespace.coll_name_123.',
        'namespace.coll_name_123..',
        'namespace',
        'namespace.coll_name.test',
        'namespace.coll_name.test.test2',
    ]

    test_result = []

    for test in test_data:
        test_result.append(AnsibleCollectionRef.is_valid_collection_name(test))


# Generated at 2022-06-23 13:47:28.282921
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', [])
    assert loader


# this loader only answers for a core-only redirection defined in ansible.config.DEFAULT_RUNTIME_HOOKS

# Generated at 2022-06-23 13:47:30.726128
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('foo','','bar','bar').__repr__() == AnsibleCollectionRef('foo','','bar','bar')


# Generated at 2022-06-23 13:47:43.977249
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as path:
        # Create a module
        module_name = 'test_module'
        module_path = os.path.join(path, module_name + '.py')
        with open(module_path, 'w') as module:
            module.write('A line')
        # Create a package
        package_name = 'test_package'
        package_path = os.path.join(path, package_name)
        os.mkdir(package_path)
        # Create a submodule
        submodule_name = 'test_submodule'
        submodule_path = os.path.join(package_path, submodule_name + '.py')
        with open(submodule_path, 'w') as submodule:
            submodule.write('A line')

# Generated at 2022-06-23 13:47:45.305587
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # TODO
    pass

# Generated at 2022-06-23 13:47:46.006737
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    pass


# Generated at 2022-06-23 13:47:51.868083
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # collection name format is ns.collname
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.foo') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.amazon.ec2') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.internal.collections.test_collections') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.amazon.ec2_with..dot') == False
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.foo.') == False
    assert AnsibleCollectionRef.is_valid_collection_name('.ansible.foo') == False

# Generated at 2022-06-23 13:47:55.752231
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    path = "path"
    hookFinder = _AnsiblePathHookFinder(None, path)
    re = hookFinder.__repr__()
    assert re == "_AnsiblePathHookFinder(path='path')"



# Generated at 2022-06-23 13:47:56.938093
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # TODO: implement
    assert True


# Generated at 2022-06-23 13:48:08.398501
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-23 13:48:20.702875
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    """
    (unit test for method is_valid_collection_name of class AnsibleCollectionRef)
    Checks if is_valid_collection_name method of class AnsibleCollectionRef return True if the parameter is a valid
    collection name and False if not.
    :return: None
    """
    # Example valid collection name
    valid_ansible_collection_name = "namespace.collection_name"
    #Example invalid collection name
    invalid_ansible_collection_name = "namespace.collection name"
    # Example valid collection name
    valid_ansible_collection_name_2 = "namespace_two.collection_name_two"
    # Example invalid collection name
    invalid_ansible_collection_name_2 = "namespace_two.collection name_two"

    # Checks if is_valid_collection_name method returns True if the parameter

# Generated at 2022-06-23 13:48:31.497335
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Empty string
    assert AnsibleCollectionRef.try_parse_fqcr('') is None

    # Invalid ref type
    assert AnsibleCollectionRef.try_parse_fqcr('ns.collname.resource', ref_type='invalid') is None

    # Not fully-qualified collection reference
    assert AnsibleCollectionRef.try_parse_fqcr('ns.collname.invalid') is None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.collname.invalid', ref_type='action') is None

    # Role does not have subdirs
    assert AnsibleCollectionRef.try_parse_fqcr('ns.collname.rolename', ref_type='role') is None

# Generated at 2022-06-23 13:48:38.518394
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    assert _AnsibleCollectionNSPkgLoader("ansible_collections.test.test_collection") is not None


# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on the configured collection root path, and Python namespace package aggregation is not allowed at or below
# the collection. Implements implicit package (package dir) support for both Py2/3. Package init code is ignored
# by this loader.

# Generated at 2022-06-23 13:48:45.003077
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible.module_utils.basic
    import ansible_collections.ansible.netcommon.plugins.modules.net_interface

    # test import from ansible.module_utils
    collection_finder = _AnsibleCollectionFinder(paths=['{0}/module_utils'.format(os.getcwd())])
    collection_finder._install()

    path_finder = _AnsiblePathHookFinder(collection_finder, pathctx=to_native(os.path.dirname(to_bytes(ansible.module_utils.basic.__file__)), errors='surrogate_or_strict'))
    mod_finder = path_finder.find_module(fullname='net_interface', path=None)
    assert 'ansible_collections.ansible.netcommon.plugins.modules.net_interface'

# Generated at 2022-06-23 13:48:53.837920
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('a.b.c', [], False, None)
    assert loader._fullname == 'a.b.c'

    loader = _AnsibleCollectionPkgLoader('a.b.c', ['/foo/bar'], False, None)
    assert loader._fullname == 'a.b.c'
    assert loader._candidate_paths == ['/foo/bar']

    loader = _AnsibleCollectionPkgLoader('a.b.c', ['/foo/bar'], True, None)
    assert loader._fullname == 'a.b.c'
    assert loader._candidate_paths == ['/foo/bar']

    loader = _AnsibleCollectionPkgLoader('a.b.c', ['/foo/bar'], True, 'ns_pkg')

# Generated at 2022-06-23 13:49:05.127876
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import os
    import unittest
    import sys
    from types import ModuleType

    from collections import namedtuple
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY2
    from ansible.core import plugin_loader, loaders
    if PY2:
        from ansible.compat.six.moves import builtins
    else:
        import builtins

    MockModule = namedtuple('MockModule', ['__file__'])

    class _CollectionPathHookFinder(_AnsiblePathHookFinder):
        # override to keep this instance's collection finder from logging
        def __init__(self, pathctx):
            super(_CollectionPathHookFinder, self).__init__(pathctx)
            self._collection_

# Generated at 2022-06-23 13:49:14.792778
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create a sub-directory in the temp_dir
        sub_dir = os.path.join(temp_dir, 'ansible')
        os.mkdir(sub_dir)
        os.mkdir(os.path.join(sub_dir, 'collections'))
        collection1 = os.path.join(sub_dir, 'collections', 'test')
        os.mkdir(collection1)
        os.mkdir(os.path.join(collection1, 'plugins'))
        os.mkdir(os.path.join(collection1, 'plugins', 'action'))
        # Create a file in the temporary directory

# Generated at 2022-06-23 13:49:20.276777
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # FIXME: get the collection config root dir from here
    raise NotImplementedError()

# we import this directly so we can re-use its functionality in our path_hook
# importer.
from importlib import _bootstrap_external

_AnsibleInternalRedirectLoader.__module__ = _bootstrap_external.__name__



# Generated at 2022-06-23 13:49:29.413169
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection', 'module') == AnsibleCollectionRef('namespace.collection', u'', u'mymodule', u'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin', 'module') == AnsibleCollectionRef('ansible.builtin', u'', u'mymodule', u'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.subdir1.subdir2.mymodule', 'module') == AnsibleCollectionRef('ansible.builtin', u'subdir1.subdir2', u'mymodule', u'module')

    # check parsings that should fail

# Generated at 2022-06-23 13:49:35.905509
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:49:46.122681
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # test find_module with no args
    finder = _AnsiblePathHookFinder(None, None)
    assert finder.find_module('ansible.module_utils.basic')

    # test find_module with path
    finder = _AnsiblePathHookFinder(None, None)
    assert finder.find_module('ansible.module_utils.basic', None)

    # test find_module with no args
    finder = _AnsiblePathHookFinder(None, None)
    assert finder.find_module('ansible_collections.somens.somecoll.somemod')

    # test find_module with path
    finder = _AnsiblePathHookFinder(None, None)

# Generated at 2022-06-23 13:49:57.726830
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    finder = _AnsibleCollectionFinder(paths=[])

    assert finder._n_playbook_paths == []
    assert finder._n_cached_collection_paths is None
    assert finder._n_collection_paths == finder._n_configured_paths

    # Add paths to the playbook by calling set_playbook_paths.
    finder.set_playbook_paths(['/path1', '/path2', '/path3'])

    assert finder._n_playbook_paths == ['/path1/collections', '/path2/collections', '/path3/collections']
    assert finder._n_cached_collection_paths is None
    assert finder._n_collection_paths == finder._n_configured_paths + finder._n_play

# Generated at 2022-06-23 13:50:06.916138
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collname')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collname.subdir1')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collname.module')
    assert not AnsibleCollectionRef.is_valid_collection_name('a.b.c.d')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.col lname')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns..collname')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collname.py')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collname.ini')



# Generated at 2022-06-23 13:50:18.263112
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_class = type(
        "_AnsibleCollectionRootPkgLoader",
        (_AnsibleCollectionPkgLoader,),
        {}
    )
    _AnsibleCollectionConfig = type(
        "_AnsibleCollectionConfig",
        (object,),
        {"on_collection_load": None, "set_collection_playbook_paths": None}
    )
    AnsibleCollectionConfig = _AnsibleCollectionConfig()
    set_collection_playbook_paths = MagicMock()
    AnsibleCollectionConfig.set_collection_playbook_paths = set_collection_playbook_paths
    on_collection_load = MagicMock()
    AnsibleCollectionConfig.on_collection_load = on_collection_load

# Generated at 2022-06-23 13:50:19.221714
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    assert True


# Generated at 2022-06-23 13:50:32.055633
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # case 1, nothing in the path
    class _AnsibleCollectionPkgLoaderBaseTester(_AnsibleCollectionPkgLoaderBase):
        def _get_subpackage_search_paths(self, candidate_paths):
            return []

    # case 2, some modules in the path
    class _AnsibleCollectionPkgLoaderBaseTester2(_AnsibleCollectionPkgLoaderBase):
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

    # case 3, some modules within packages in the path
    class _AnsibleCollectionPkgLoaderBaseTester3(_AnsibleCollectionPkgLoaderBase):
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

    # case 4, some modules within packages in

# Generated at 2022-06-23 13:50:33.559758
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    assert False, 'This test needs to be filled out'


# Generated at 2022-06-23 13:50:42.814018
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():

    test_path = '/home/robin/ansiblepy3/lib/ansible/collections'

# Generated at 2022-06-23 13:50:47.748443
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():

    fqcr = AnsibleCollectionRef('namespace.collection_name', 'optional_subdir', 'resource_name', 'foo')
    fqcr2 = eval(fqcr.__repr__())

    assert fqcr == fqcr2


# Generated at 2022-06-23 13:50:52.832302
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # pylint: disable=unused-variable
    # should throw exception
    try:
        loader = _AnsibleCollectionPkgLoaderBase("foo.bar")
        assert False
    except (ImportError, ValueError):
        pass

    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo.bar")



# Generated at 2022-06-23 13:51:04.879205
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-23 13:51:16.402744
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-23 13:51:29.380461
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # I didn't test the the self._file_finder, too hard to mock
    with patch('ansible_collections.ansible.collection_finder._AnsiblePathHookFinder._get_filefinder_path_hook') as mock_get_filefinder_path_hook,\
            patch('ansible_collections.ansible.collection_finder._AnsibleCollectionFinder'):
        mock_get_filefinder_path_hook.return_value = '/somehook'
        pathctx = '/some/path/context'
        apf = _AnsiblePathHookFinder('/some/finder', pathctx)
        assert _AnsiblePathHookFinder._filefinder_path_hook == '/somehook'
        assert apf._pathctx == pathctx


# Implements a collection namespace pkg loader. It's a

# Generated at 2022-06-23 13:51:40.922637
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.utils.collection_loader as loader
    loader._get_collection_metadata = lambda x: {'import_redirection': {'ansible.module': {'redirect': 'ansible.module_utils'}}}
    assert _AnsibleInternalRedirectLoader('ansible.module', []).load_module('ansible.module') == sys.modules['ansible.module_utils']
    loader._get_collection_metadata = lambda x: {'import_redirection': {'ansible.module': {'redirect': 'ansible.module'}}}
    with pytest.raises(ValueError):
        _AnsibleInternalRedirectLoader('ansible.module', []).load_module('ansible.module')
    loader._get_collection_metadata = lambda x: {'import_redirection': {}}

# Generated at 2022-06-23 13:51:49.812701
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # This should succeed
    ldr = _AnsibleCollectionLoader(['test_data.test_collection'])
    assert ldr._fullname == 'test_data.test_collection'
    assert ldr._split_name == ['test_data', 'test_collection']
    assert ldr._package_to_load == 'test_collection'
    assert ldr._subpackage_search_paths is None
    assert ldr._source_code_path == ''
    assert ldr._candidate_paths == ['test_data/test_collection', 'test_data/test_collection/']
    assert ldr._redirected_package_map == {}
    assert ldr._allows_package_code == True

    # This should fail
    with pytest.raises(ValueError) as excinfo:
        ldr = _Ans

# Generated at 2022-06-23 13:52:01.839793
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # FIXME: this test is broken.
    #
    # This is copied from ansible.module_utils.collection_loader_unittest.TestLoadSource

    def test_ns_package__get_source():
        # make a doc/sourceless ns package
        test_pack_path = os.path.join(test_data_path, 'ansible_collections',
                                      'ns_package')
        if os.path.isdir(test_pack_path):
            shutil.rmtree(test_pack_path)

        os.makedirs(test_pack_path)

        # load it
        # TODO: this should not require a source-based loader!
        loader = collections_loader.AnsibleCollectionLoader(None, [test_pack_path], None)

# Generated at 2022-06-23 13:52:12.921240
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible_collections.ansible.ansible_collections.skeleton.plugins.modules import win_chocolatey_source
    from ansible_collections.ansible.ansible_collections.skeleton.plugins.modules import one_level_subpackage_subsub
    from ansible_collections.ansible.ansible_collections.skeleton.plugins.modules import two_level_subpackage_subsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsubsub

# Generated at 2022-06-23 13:52:25.580389
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import tempfile
    import shutil
    import sys
    import os

    # -------------------------------------------------------------------------
    # Testing data

    test_dict = dict(
        # A collection to test with
        collection="t.c.a",

        # The directory where it's installed
        test_collections_path=tempfile.mkdtemp(),

        # The path to the modules directory in the collection
        modules_dir=os.path.join(tempfile.mkdtemp(), 'modules'),
        ansible_dir=os.path.join(tempfile.mkdtemp(), 'ansible'),
    )

    # Create the collection
    os.makedirs(os.path.join(test_dict['test_collections_path'], *test_dict['collection'].split(".")), exist_ok=True)

    # Create the modules directory
    os

# Generated at 2022-06-23 13:52:30.629979
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(
        collection_name='namespace.collection',
        subdirs=None,
        resource='resource',
        ref_type='module_utils'
    )
    assert repr(ref) == "AnsibleCollectionRef(collection='namespace.collection', subdirs=None, resource='resource')"



# Generated at 2022-06-23 13:52:34.720061
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible.cli.galaxy import AnsibleCollectionRef
    expected = 'AnsibleCollectionRef(collection=\'ansible.builtin\', subdirs=\'modules\', resource=\'ping\')'
    assert expected == str(AnsibleCollectionRef('ansible.builtin', 'modules', 'ping', 'module'))


# Generated at 2022-06-23 13:52:46.015611
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():

    def test_filefinder_path_hook(self):
        with patch('ansible.module_utils.common.collections_loader._AnsiblePathHookFinder.__init__') as mock_constructor:
            mock_constructor.return_value = None

            result = _AnsiblePathHookFinder.get_filefinder_path_hook()
            assert result == None

    mock_constructor = MagicMock()
    mock_constructor.__init__ = MagicMock(return_value=None)
    mock_constructor.find_module = MagicMock(return_value=None)
    mock_constructor.iter_modules = MagicMock(return_value=[])

    with patch.object(sys.modules[__name__], '_AnsibleCollectionFinder', mock_constructor):

        test_file

# Generated at 2022-06-23 13:52:56.973907
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins.') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins.subdir') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'connection_plugins') == u'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'lookup_plugins') == u'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'filter_plugins') == u'filter'
   

# Generated at 2022-06-23 13:53:05.381371
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
  # TODO: may need to mock the following methods
  # _validate_args(), _validate_final(), _get_candidate_paths(), _get_subpackage_search_paths()

  mock_path_list = ['/ansible/collections/ansible_collections/broken_source']
  mock_full_name = 'ansible_collections.broken_source'
  loader = _AnsibleCollectionPkgLoaderBase(mock_full_name, mock_path_list)

  # _redirect_module is set
  loader._redirect_module = Mock()
  module = loader.load_module(mock_full_name)
  assert module is loader._redirect_module
  assert sys.modules[mock_full_name] is loader._redirect_module

  # _redirect_module not set

# Generated at 2022-06-23 13:53:09.472990
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    test_path_list = ['path/to/my/collections/ansible_collections']
    test_fullname = 'ansible_collections'
    test_loader = _AnsibleCollectionRootPkgLoader(test_fullname, test_path_list)
    assert test_loader._fullname == test_fullname
    assert test_loader._redirect_module is None
    assert test_loader._split_name == test_fullname.split('.')
    assert test_loader._rpart_name == test_fullname.rpartition('.')
    assert test_loader._parent_package_name == ''
    assert test_loader._package_to_load == ''
    assert test_loader._source_code_path is None
    assert test_loader._decoded_source is None
    assert test_loader._compiled_

# Generated at 2022-06-23 13:53:22.590761
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import json
    import collections

    import ansible
    # ansible_collections is not available on ansible.__path__
    # we need to import ansible_collections from its package
    a_collections = importlib.import_module('ansible.collections')
    import ansible.collections.config.ansible_builtin_runtime

    class PluginMock(object):
        def __init__(self, data_dict=None, type_name=None, name=None, canonical_package_name=None, subdir=None):
            self._data_dict = data_dict or {}
            self._type_name = type_name
            self._name = name
            self._canonical_package_name = canonical_package_

# Generated at 2022-06-23 13:53:31.921271
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    '''
    function:
        AnsibleCollectionRef.try_parse_fqcr
    purpose:

    returns:
        success/failure
    '''
    ret_value = True


# Generated at 2022-06-23 13:53:41.105342
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """Test for method get_data of class _AnsibleCollectionPkgLoaderBase
    """
    # TODO: fix the test
    return
    # Get a random collection path
    collection_path = random_collection_path()
    # Create the loader
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my.ns', collection_path)
    # Get the absolute path to the __init__.py of the collection
    init_file = os.path.join(collection_path, '__init__.py')
    # Check we retrieve the expected file
    assert loader.get_data(init_file) == ''