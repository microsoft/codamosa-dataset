

# Generated at 2022-06-23 13:43:36.141834
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    pass

# Generated at 2022-06-23 13:43:44.424415
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    """
    Test the functionality of the method:
    - AnsibleCollectionRef.__repr__
    """
    assert AnsibleCollectionRef('ns1.coll1', None, 'res1', 'type1').__repr__() == "AnsibleCollectionRef(collection='ns1.coll1', subdirs='', resource='res1')"
    assert AnsibleCollectionRef('ns1.coll1', 'sub1.sub2', 'res1', 'type1').__repr__() == "AnsibleCollectionRef(collection='ns1.coll1', subdirs='sub1.sub2', resource='res1')"

# Generated at 2022-06-23 13:43:49.245569
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import ansible.builtin.config

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.config', None)
    assert loader._redirect
    assert loader.load_module('ansible.builtin.config') is ansible.builtin.config


# FIXME: move this elsewhere, it's a runtime shared state object
_collection_paths = AnsibleCollectionConfig.get_collections_paths()



# Generated at 2022-06-23 13:43:55.560880
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    test_modules_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test_collections')

    # Test that _validate_args() with no args raise and exception
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoaderBase._validate_args()

    # Test that path_list is required and that _get_candidate_paths() and _get_subpackage_search_paths()
    #   returns correct paths and dir
    loaderbase = _AnsibleCollectionPkgLoaderBase('test_validate_args.package', path_list=[test_modules_path])
    assert loaderbase._candidate_paths == [os.path.join(test_modules_path, 'package')]
    assert loaderbase._subpackage_search_

# Generated at 2022-06-23 13:44:04.813345
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # path is None
    loader = _AnsibleCollectionPkgLoaderBase('fullname', [])
    assert repr(loader) == '_AnsibleCollectionPkgLoaderBase(path=None)'
    # path is not None
    loader = _AnsibleCollectionPkgLoaderBase('fullname', ['path1', 'path2'])
    expected = '_AnsibleCollectionPkgLoaderBase(path=[\'path1\', \'path2\'])'
    assert repr(loader) == expected



# Generated at 2022-06-23 13:44:14.368594
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import tempfile
    import shutil

    with tempfile.NamedTemporaryFile() as f:
        shutil.copyfile('test/data/test_collection_finder/test_collection_1/galaxy.yml', f.name)
        # This is a very crude way to test whether the file was copied correctly, but the
        # tempfile module doesn't appear to provide a better way to do this.
        assert f.read().decode() == 'namespace: example\nname: collection-1\nversion: 1.0.0\n'

    with tempfile.TemporaryDirectory() as temp_dir:
        assert temp_dir is not None
        collection_1_dir = os.path.join(temp_dir, 'collection-1')
        assert collection_1_dir is not None

# Generated at 2022-06-23 13:44:15.522551
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    _AnsibleCollectionPkgLoaderBase.get_data('/tmp/')


# Generated at 2022-06-23 13:44:24.283973
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # NOTE: This is a module-level function and not a method of the class
    # Set up the mocks

    ansible_collections_mock = 'ansible_collections'
    test_subject_object = 'ansible_collections.a.b'
    test_subject = 'b'
    module_attrs = dict(
        __loader__=test_subject_object,
        __file__='test_filename',
        __package__=test_subject_object  # sane default for non-packages
    )


    # Begin test
    # NB: we're actually loading a module/package
    test_subject.module_attrs = module_attrs
    assert test_subject_object.load_module(ansible_collections_mock) == True

    # short-circuit redirect; we've already imported the redirected module

# Generated at 2022-06-23 13:44:25.393728
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # FIXME: needs a "real" test
    pass



# Generated at 2022-06-23 13:44:36.690003
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:44:46.230173
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    tests = [
        (u'namespace.collectionname', True),
        (u'ns.collname', True),
        (u'ns.coll-name', False),
        (u'invalid.collection.name', False),
        (u'invalid.collection.name.', False),
        (u'invalid..collection.name', False),
        (u'ns.coll name', False),
        (u'ns.coll 1name', False),
        (u'ns.coll', False),
        (u'.collname', False),
        (u'ns.', False),
        (u'ns', False),
        (u'', False),
        (1, False),
        (None, False),
    ]


# Generated at 2022-06-23 13:44:52.823852
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_values = [
        {'legacy_plugin_dir_name': 'action_plugins', 'expected': 'action'},
        {'legacy_plugin_dir_name': 'library', 'expected': 'modules'},
        {'legacy_plugin_dir_name': 'lookup_plugins', 'expected': 'lookup'},
        {'legacy_plugin_dir_name': 'test', 'expected': 'test'},
        {'legacy_plugin_dir_name': 'filter_plugins', 'expected': 'filter'},
    ]

    for test_value in test_values:
        assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(
            test_value['legacy_plugin_dir_name']) == test_value['expected']


# Generated at 2022-06-23 13:45:03.900430
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-23 13:45:07.874109
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('namespace', [], None)
    assert loader.__class__.__name__ == '_AnsibleCollectionLoader'



# Generated at 2022-06-23 13:45:16.831436
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    
    # initialize Ansible with current working directory as config directory
    Ansible.__init__(config=[])
    loader = _AnsibleCollectionPkgLoader(package_to_load="my_package", path_to_load_from="my_path")
    loader._split_name = ["ansible", "collections", "my_collection"]
    loader._subpackage_search_paths = ["/root/ansible/ansible/ansible_collections/my_collection/my_package"]
    loader._package_to_load = "my_package"

    # If _meta_yml_to_dict is None
    Ansible.__init__(config=[])
    loader = _AnsibleCollectionPkgLoader(package_to_load="my_package", path_to_load_from="my_path")
    loader._

# Generated at 2022-06-23 13:45:23.524707
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    mock_path_list = ['collection_root_path/', 'collection_root_path2/']
    mock_package_to_load = 'package_name'

    # Mock the os.path.isdir() method.
    path_isdir_mock = mocker.patch('os.path.isdir')
    path_isdir_mock.return_value = False
    path_isdir_mock.side_effect = lambda x: x.endswith('collection_root_path/package_name')

    # Mock the os.path.exists() method.
    path_exists_mock = mocker.patch('os.path.exists')
    path_exists_mock.return_value = False

# Generated at 2022-06-23 13:45:29.868797
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    from unittest import TestCase

    test = TestCase()

    test.assertEqual(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins'), 'action')
    test.assertEqual(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins'), 'connection')
    test.assertEqual(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins'), 'cache')
    test.assertEqual(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins'), 'callback')
    test.assertEqual(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins'), 'cliconf')

# Generated at 2022-06-23 13:45:40.795888
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    def test_(fullname, expected_result):
        test1 = _AnsibleInternalRedirectLoader(fullname, '')
        test1.load_module(fullname)
        test2 = sys.modules[fullname]
        assert test1._redirect == test2._redirect == expected_result
    test_('ansible', 'ansible.builtin')
    test_('ansible.builtin', 'ansible.builtin')
    test_('ansible.builtin.foo.bar', 'ansible.builtin.foo.bar')
    test_('ansible.builtin.collection', 'ansible.builtin.collection')
    test_('ansible.builtin.foo.bar.baz', 'ansible.builtin.foo.bar.baz')

# Generated at 2022-06-23 13:45:44.185765
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Python namespace package default constructor
    loader = _AnsibleCollectionNSPkgLoader('foo.bar.baz')
    assert loader._fullname == 'foo.bar.baz'
    assert loader._parent_package_name == 'foo.bar'
    assert loader._package_to_load == 'baz'
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths == []
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None


# Implements Python namespace package support when provided a collection root list.

# Generated at 2022-06-23 13:45:46.721459
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import_redirect_map = {
        'ansible.builtin.file': {
            'redirect': 'ansible.builtin'
        }
    }
    # TODO: write a test for method load_module of class _AnsibleInternalRedirectLoader
pass



# Generated at 2022-06-23 13:45:58.377005
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef('a.b', 'c.d', 'e', 'f')
    assert AnsibleCollectionRef('a.b', u'c.d', 'e', 'f')
    assert AnsibleCollectionRef(u'a.b', None, u'e', u'f')
    assert AnsibleCollectionRef('a.b', None, u'e', 'f')
    assert AnsibleCollectionRef('a.b', '', 'e', 'f')
    assert AnsibleCollectionRef('a.b', 'e.f', 'g', u'module')
    assert AnsibleCollectionRef('a.b', None, 'g', 'module')
    assert AnsibleCollectionRef('a.b', 'e.f', 'g', 'role')
    assert AnsibleCollectionRef('a.b', None, 'g', 'role')

# Generated at 2022-06-23 13:46:08.881551
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # This prevents us from being double-added to things, which causes path_importer_cache to
    # break caching of path hook finders, and allows us to recreate things for testing purposes.
    _AnsibleCollectionFinder._remove()
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._install()

    # Test the default constructor of _AnsiblePathHookFinder
    assert(_AnsiblePathHookFinder._filefinder_path_hook is not None)

    # Test the constructor of _AnsiblePathHookFinder
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, '/tmp/ansible_collections')
    assert(path_hook_finder._collection_finder is collection_finder)

# Generated at 2022-06-23 13:46:20.188309
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock

    def fake_get_data(loader, path):
        return 'fake_get_data'

    module = 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.some_module'
    with patch.object(AnsibleCollectionLoader, 'get_file_content', return_value=fake_get_data):
        loader = AnsibleCollectionLoader(
            Mock(),
            Mock(),
            collection_name=module.split('.')[1]
        )
        pkg_loader = loader.load_module(module)

    source = pkg_loader.get

# Generated at 2022-06-23 13:46:28.891622
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    from ansible.utils._text import to_text
    from ansible.module_utils.six import StringIO

    # create dummy collection used to test _AnsiblePathHookFinder.iter_modules
    dummy_collection = 'dummy_collection'
    dummy_namespace = 'dummy_namespace'
    dummy_subdir = 't'
    dummy_subdir_path = os.path.join(dummy_collection, dummy_namespace, dummy_subdir)
    dummy_subdir_path = to_native(dummy_subdir_path)

    ansible_collections_path = os.path.join(os.getcwd(), dummy_subdir_path)

    # create temporary file __init__.py

# Generated at 2022-06-23 13:46:39.831050
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from io import StringIO
    from importlib.util import spec_from_loader
    from collections import namedtuple
    class _AnsibleCollectionPkgTestLoader(object):
        def __init__(self):
            self.spec = None
            self.loader = None
            self.fullname = None
            self.path_list = None
        def __call__(self, fullname, path_list):
            #  We create callable objects to mimic the action of a path hook. The callable object
            #   instantiates a loader, and the loader somehow finds a resource that has the
            #   desired spec.
            self.fullname = fullname
            self.path_list = path_list
            self.loader = _AnsibleCollectionPkgTestLoader.Loader(self)

# Generated at 2022-06-23 13:46:52.791596
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from collections import namedtuple
    import ansible
    #
    # Create mock package
    #
    with TemporaryDirectory() as tempdir:
        mock_package_dir = os.path.join(tempdir, 'test_collections', 'test_ns', 'test_package')
        os.makedirs(mock_package_dir)
        # place empty __init__.py so package gets created
        with open(os.path.join(mock_package_dir, '__init__.py'), 'w'):
            pass
        # place mock file
        mock_file_name = os.path.join(mock_package_dir, 'test_file.py')
        mock_file_content = 'test_file_content'

# Generated at 2022-06-23 13:47:01.954428
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    with pytest.raises(ValueError):
        AnsibleCollectionRef("user.invalid_collection",None,"some_python_module","module")
    with pytest.raises(ValueError):
        AnsibleCollectionRef("user.invalid_collection",None,"some_python_module","module")

    # Valid 
    AnsibleCollectionRef("user.valid_collection",None,"some_python_module","module")
    AnsibleCollectionRef("user.valid_collection","subdirs","some_python_module","module")
    AnsibleCollectionRef("user.valid_collection","subdirs1.subdirs2","some_python_module","module")
    AnsibleCollectionRef("user.valid_collection",None,"some_python_module","role")

# Generated at 2022-06-23 13:47:12.000390
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('acme.st2') == True
    assert AnsibleCollectionRef.is_valid_collection_name('acme.test_ansible_modules') == True
    assert AnsibleCollectionRef.is_valid_collection_name('acme.test-ansible-modules') == False
    assert AnsibleCollectionRef.is_valid_collection_name('valid-name1.valid-name-2') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.1invalid-name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('ns!.1invalid-name') == False
    assert AnsibleCollectionRef.is_valid_collection_name('ns.invalid.name') == False
    assert AnsibleCollectionRef.is_valid_collection_

# Generated at 2022-06-23 13:47:19.426573
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    def get_meta_content(meta_file):
        return b'---\nhost_type:posix1\nhost_granularity_key:hostname'

    # Fake meta.yml reading method for unit test
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = get_meta_content

    # Unit test
    loader = _AnsibleCollectionPkgLoader('a.b.c', '1.2.3')
    module = loader.load_module('abc')
    assert module._collection_meta == {'host_type': 'posix1', 'host_granularity_key': 'hostname'}

# This class implements loading of modules from an Ansible collection package. The
# special case of the ``ansible.builtin`` collection is also supported.

# Generated at 2022-06-23 13:47:31.024928
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():

    class TestFinder(_AnsiblePathHookFinder):
        def __init__(self, pathctx):
            self._pathctx = pathctx
            self._collection_finder = None

    def assert_iter_modules_correct(finder, prefix, expected_names):
        def _mk_fullnames(names):
            return tuple('ansible_collections.{0}'.format(n) for n in names)

        assert tuple(finder.iter_modules(prefix)) == _mk_fullnames(expected_names)

    f = TestFinder('test/data/fsroot')


# Generated at 2022-06-23 13:47:44.025616
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        ns_dir = os.path.join(tmpdir, 'ansible_collections')
        os.makedirs(os.path.join(ns_dir, 'test_ns', 'test_collection1'))
        os.makedirs(os.path.join(ns_dir, 'test_ns', 'test_collection2'))
        col1_module_dir = os.path.join(ns_dir, 'test_ns', 'test_collection1', 'test_module1')
        col1_module_from_parent_dir = os.path.join(ns_dir, 'test_ns', 'test_collection1')

# Generated at 2022-06-23 13:47:55.907239
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    expected = {'collection': 'ns.coll', 'subdirs': 'subdir.subdir', 'resource': 'resourceName', 'ref_type': 'action', 'fqcr': 'ns.coll.subdir.subdir.resourceName'}
    ref = AnsibleCollectionRef(expected['collection'], expected['subdirs'], expected['resource'], expected['ref_type'])
    assert ref.collection == expected['collection']
    assert ref.subdirs == expected['subdirs']
    assert ref.resource == expected['resource']
    assert ref.ref_type == expected['ref_type']
    assert ref.fqcr == expected['fqcr']


# Generated at 2022-06-23 13:47:57.671111
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    # This method was tested via mock only
    pass


# Generated at 2022-06-23 13:48:08.989612
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test FQCR with valid plugin type
    # Tests containing valid ref_type
    assert AnsibleCollectionRef.is_valid_fqcr('test.test', 'action') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test', 'callback') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test.test', 'cliconf') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test.test.test', 'connection') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test.test.test.test', 'doc_fragments') == True

# Generated at 2022-06-23 13:48:20.135868
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    try:
        obj = AnsibleCollectionRef(
            collection_name='ns.coll',
            subdirs='subdir1.subdir2',
            resource='resource',
            ref_type='module'
        )
    except Exception as e:
        print(e)
        return False
    ret = repr(obj)
    if ret != 'AnsibleCollectionRef(collection=\'ns.coll\', subdirs=\'subdir1.subdir2\', resource=\'resource\')':
        print('Unexpected return value {!r}'.format(ret))
        return False
    return True
# ===== END UNIT TESTS =====


# ===== BEGIN UNIT TESTS =====

# Generated at 2022-06-23 13:48:30.991915
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _AnsibleCollectionConfig._mock_collections_path = [os.path.join(os.path.dirname(__file__), '..', '..', 'testdata', 'collection_loader', 'collection_path')]
    _AnsibleCollectionConfig._mock_ansible_search_path = _AnsibleCollectionConfig._mock_collections_path
    _AnsibleCollectionConfig.instance()._init_collections_path()
    _AnsibleCollectionConfig.instance()._init_collection_lists()

    b_ansible_pkg_path = to_bytes(os.path.dirname(import_module('ansible').__file__))

# Generated at 2022-06-23 13:48:37.795226
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # sample file
    import os
    import tempfile
    test_file = tempfile.NamedTemporaryFile(mode='w+b', delete=False)
    test_file.write(b'foo')
    test_file.close()

    # create loader
    loader = _AnsibleCollectionPkgLoaderBase(os.path.dirname(test_file.name))

    # test
    result = loader.get_data(test_file.name)
    assert result == b'foo'
    assert type(result) == type(b'')

# Generated at 2022-06-23 13:48:42.161600
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
  expected_result = '<ansible_synthetic_collection_package>'
  actual_result = _AnsibleCollectionPkgLoaderBase._synthetic_filename('<ansible_synthetic_collection_package>')
  assert expected_result == actual_result, "Method get_data of class _AnsibleCollectionPkgLoaderBase does not work as expected"

# Generated at 2022-06-23 13:48:54.111456
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    from ansible.collections.ansible.plugins.loader import _AnsibleCollectionPkgLoaderBase
    from ansible.collections.ansible.plugins.loader import _AnsibleCollectionModuleLoader

    # mock _loader_base
    loader_base_mock = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.sov', path_list=['t_dir'])
    loader_base_mock._subpackage_search_paths = ['t_dir', 't_dir/sov']
    assert loader_base_mock.get_data('t_dir/sov/__init__.py') == ''

    loader_base_mock = _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:49:05.451263
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    res = AnsibleCollectionRef.from_fqcr("ansible.builtin.python_module", "module")
    assert res.__repr__() == "AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='python_module')"

    res = AnsibleCollectionRef.from_fqcr("ansible.builtin.python_module", "module")
    assert res.__repr__() == "AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='python_module')"

    res = AnsibleCollectionRef.from_fqcr("ansible.builtin.python_module", "module")
    assert res.__repr__() == "AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='python_module')"

   

# Generated at 2022-06-23 13:49:09.062855
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    acr = AnsibleCollectionRef('ns.coll', None, 'res', 'type')
    assert repr(acr) == "AnsibleCollectionRef(collection='ns.coll', subdirs=None, resource='res')"



# Generated at 2022-06-23 13:49:18.317734
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    tempdir = tempfile.mkdtemp()
    print('tempdir: %s'%tempdir)
    plugin_package = 'test_plugin_package'
    plugin_path_package = os.path.join(tempdir,plugin_package)
    os.mkdir(plugin_path_package)
    plugin_file = 'action_plugin_1.py'
    plugin_path_file = os.path.join(plugin_path_package, plugin_file)
    with open(plugin_path_file, 'w') as f:
        f.write('#!/usr/bin/env python\n')
        f.write('print("Test")\n')
    print('plugin_path_file: %s'%plugin_path_file)

# Generated at 2022-06-23 13:49:27.459756
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:49:38.265121
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:49:43.605850
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    check_repr(
        _AnsibleCollectionPkgLoaderBase(
            fullname='ansible_collections.test',
            path_list=['/path/to/test']),
        '<class \'ansible.module_utils._text.AnsibleCollectionPkgLoaderBase\'>(path=["/path/to/test/test"])')

# Generated at 2022-06-23 13:49:49.457707
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    """
    Test method _AnsibleCollectionPkgLoaderBase.iter_modules()
    """
    class TmpAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        """
        Temporary class to init _AnsibleCollectionPkgLoaderBase
        """
        def __init__(self, fullname, path_list=None):
            super(TmpAnsibleCollectionPkgLoaderBase, self).__init__(fullname, path_list)


# Generated at 2022-06-23 13:50:00.176899
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create the class for unit testing.
    class _AnsibleCollectionPkgLoaderBaseTest(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, *args, **kwargs):
            super(_AnsibleCollectionPkgLoaderBaseTest, self).__init__( *args, **kwargs)
        def get_data(self, path):
            return None
        def get_filename(self, fullname):
            return None
        def get_code(self, fullname):
            return None

    # case 1: prefix=test, subpackage_search_paths=[test1]
    test1 = _AnsibleCollectionPkgLoaderBaseTest('ansible_collections.test', [os.path.join(os.path.sep, 'test1')])

# Generated at 2022-06-23 13:50:06.394420
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert _AnsiblePathHookFinder.__repr__.__doc__ == """Represents a path in the file system to look for Python modules for importing.

Args:
  path (str): A string value of the path to add to sys.path.

Returns:
  str: Returns a string representation of the Python import path.

"""


# Used to redirect things like ansible.module_utils to the appropriate collection path

# Generated at 2022-06-23 13:50:17.900679
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'my.mod')
    # Check that it can handle all valid ref_types and that it is case insensitive
    for ref_type in AnsibleCollectionRef.VALID_REF_TYPES:
        assert AnsibleCollectionRef.is_valid_fqcr(u'my.mod.' + ref_type, ref_type)
        assert AnsibleCollectionRef.is_valid_fqcr(u'my.mod.' + ref_type.upper(), ref_type)
    # Check that it returns False if the ref_type is invalid
    with pytest.raises(ValueError):
        assert not AnsibleCollectionRef.is_valid_fqcr(u'my.mod.wrong', u'wrong')
    # Check that it returns False if ref is not a string (also test P

# Generated at 2022-06-23 13:50:25.957224
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class Subclass(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

# Generated at 2022-06-23 13:50:37.606542
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():

    assert AnsibleCollectionRef.is_valid_fqcr(u'foo.bar')   # namespace and name
    assert AnsibleCollectionRef.is_valid_fqcr(u'foo.bar', u'module')   # namespace and name
    assert AnsibleCollectionRef.is_valid_fqcr(u'foo.bar.test')   # namespace, name, resource
    assert AnsibleCollectionRef.is_valid_fqcr(u'foo.bar.test', u'module')   # namespace, name, resource
    assert AnsibleCollectionRef.is_valid_fqcr(u'foo.bar.sub1.test')   # namespace, name, subdir, resource
    assert AnsibleCollectionRef.is_valid_fqcr(u'foo.bar.sub1.sub2.test')   # namespace, name, sub

# Generated at 2022-06-23 13:50:49.069915
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import ansible
    assert ansible.__file__.endswith('lib/ansible/__init__.py')
    config = AnsibleCollectionConfig([os.path.dirname(ansible.__file__)])

    # If the imported ansible module is in the same directory as ansible.builtin, then this test will pass.
    # Otherwise, the test must be skipped.
    if 'ansible.builtin' in config.get_collections():
        collection, module = 'ansible', 'plugins'
        fullname = '.'.join([collection, module])
        loader = _AnsibleInternalRedirectLoader(fullname, [])
        assert loader._redirect == 'ansible.builtin.plugins'
    else:
        pytest.skip("Ansible not found in path")

# Implements the custom namespace

# Generated at 2022-06-23 13:50:55.028713
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert_raises(ImportError, _AnsibleInternalRedirectLoader, '', None)
    assert_raises(ImportError, _AnsibleInternalRedirectLoader, 'ansible.not_exist', None)
    assert_raises(ImportError, _AnsibleInternalRedirectLoader, 'not_ansible.plugin.name', None)


# must be an Ansible Python module to be loaded here

# Generated at 2022-06-23 13:51:06.730202
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import sys
    import os
    import pytest
    from ansible.module_utils._text import to_text, to_bytes, to_native
    current_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib')
    collection_path = os.path.join(current_path, 'ansible_collections')

    sys.path.append(collection_path)
    from ansible_collections.ansible.test.lib_test_utils import _AnsibleCollectionPkgLoaderBase, CollectionFinder
    clb = _AnsibleCollectionPkgLoaderBase('ansible_collections', [collection_path])

# Generated at 2022-06-23 13:51:16.307389
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # prepare data
    import tests.unit.utils.ansible_collections.ansible.collections.community.misc.plugins.module_utils.some_path
    mod_path = os.path.dirname(os.path.abspath(tests.unit.utils.ansible_collections.ansible.collections.community.misc.plugins.module_utils.some_path.__file__))
    # run code to test
    ans_path_finder = _AnsiblePathHookFinder(_AnsibleCollectionFinder(), mod_path)
    it = ans_path_finder.iter_modules(prefix='')

# Generated at 2022-06-23 13:51:29.335054
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import ansible.utils.collection_loader

    # no redirect
    fullname = 'ansible.builtin.foo'
    with pytest.raises(ImportError) as ce:
        _AnsibleInternalRedirectLoader(fullname, [])
    assert ce.value.args[0] == 'not redirected, go ask path_hook'

    # found redirect
    # ('builtin.foo', ''), ('builtin.bar', ''), ('builtin.foo.plugin', 'builtin.bar')]
    entry = ('builtin.foo', 'ansible.builtin.bar')
    ansible.utils.collection_loader.CollectionRegistry.add_collection_import_redirects([entry])
    loader = _AnsibleInternalRedirectLoader(fullname, [])

# Generated at 2022-06-23 13:51:40.867558
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils._nspkg_impl import _AnsibleCollectionPkgLoader
    import ansible.utils.collection_loader
    loader = _AnsibleCollectionPkgLoader(ns_pkg_name='myns', package_to_load='mycoll',
                                         candidate_paths=['/path/to/myns.mycoll'],
                                         import_error_mock=ansible.utils.collection_loader.ImportError)
    ansible.utils.collection_loader._meta_yml_to_dict = load_meta_yml_to_dict()
    AnsibleCollectionConfig.on_collection_load = on_collection_load()
    pkg_x = loader.load_module('myns.mycoll')
    pkg_x.__name__ = 'myns.mycoll'
    assert pkg_

# Generated at 2022-06-23 13:51:47.190463
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    try:
        _AnsibleInternalRedirectLoader('ansible.modules', [])
    except ImportError:
        pass
    else:
        assert False, "_AnsibleInternalRedirectLoader should raise ImportError with wrong namespace"

    try:
        _AnsibleInternalRedirectLoader('ansible.builtin.core', [])
    except ImportError:
        pass
    else:
        assert False, "_AnsibleInternalRedirectLoader should raise ImportError if no redirect"


# Generated at 2022-06-23 13:52:00.143632
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import sys
    import os
    orig_sys_path = list(sys.path)
    f = _AnsibleCollectionFinder([])
    # this path will cause an exception per (1) in the loop below
    f.set_playbook_paths(['/junk/path'])
    assert(f._n_playbook_paths == [])
    # test multiple paths
    f.set_playbook_paths([os.path.join(os.path.dirname(__file__), 'data', 'coll1'),
                          os.path.join(os.path.dirname(__file__), 'data', 'coll2')])

# Generated at 2022-06-23 13:52:05.873491
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef(u'namespace.test', u'subdirs.test', u'resource_test', u'type_test').__repr__() == \
        'AnsibleCollectionRef(collection=\'namespace.test\', subdirs=\'subdirs.test\', resource=\'resource_test\')'

# Generated at 2022-06-23 13:52:06.634579
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import mock


# Generated at 2022-06-23 13:52:11.730035
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    print(_AnsibleCollectionPkgLoader('ansible_collections.awesome.plugins.module_utils.hello_world', None))
    print(_AnsibleCollectionPkgLoader('ansible_collections.awesome.plugins.test_module_utils.test_utils', None))
    try:
        print(_AnsibleCollectionPkgLoader('ansible_collections.aaa.plugins.module_utils.hello', None))
        assert False, "Should not reach here"
    except ImportError:
        pass


# Generated at 2022-06-23 13:52:20.654600
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_name = "namespace.collectionname"
    subdirs = "subdir1.subdir2"
    resource = "mymodule"
    ref_type = "module"
    test = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert test.__repr__() == 'AnsibleCollectionRef(collection=\'namespace.collectionname\', subdirs=\'subdir1.subdir2\', resource=\'mymodule\')'


# Generated at 2022-06-23 13:52:29.564815
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Create a new loader
    loader = _AnsibleCollectionFinder()

    # Test the property _n_collection_paths
    assert(loader._n_configured_paths == loader._n_collection_paths)

    # Set the value of the property _n_playbook_paths
    loader._n_playbook_paths = ["/tmp/test"]

    # Test the property _n_collection_paths
    assert(loader._n_playbook_paths + loader._n_configured_paths == loader._n_collection_paths)


# Generated at 2022-06-23 13:52:36.527490
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Create a _AnsibleCollectionPkgLoaderBase object
    acplb = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns', ['/home/laptop/.ansible/collections/ansible_collections/'])
    # Call method load_module
    acplb.load_module('ansible_collections.ns')
    # Call method load_module with an argument
    try:
        acplb.load_module('ansible_collections.somens')
    except ValueError as e:
        # Expecting an ValueError Exception
        assert True, "Expecting an ValueError Exception"


# Test load_module for an alternative path
# Create a _AnsibleCollectionPkgLoaderBase object

# Generated at 2022-06-23 13:52:47.209149
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection.extraname')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace..collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection_with_underscore')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.collection!')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.true')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.else')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.if')
    assert not AnsibleCollectionRef.is_valid_collection_

# Generated at 2022-06-23 13:52:58.099805
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    package_path = None
    code_path = None
    module_name = "ansible_collections.module.name"
    loader = _AnsibleCollectionPkgLoaderBase(module_name, path_list=['some_path'])
    assert loader._module_file_from_path('module', 'some_path') == (None, None)
    assert loader.get_source(module_name) == None
    
    package_path = 'some_path'
    code_path = 'some_path/module.py'
    loader = _AnsibleCollectionPkgLoaderBase(module_name, path_list=['some_path'])
    assert loader._module_file_from_path('module', 'some_path') == (code_path, True, None)

# Generated at 2022-06-23 13:53:01.954572
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Instantiate an object of type _AnsiblePathHookFinder
    p = _AnsiblePathHookFinder(None, '/tmp')
    assert p._pathctx == '/tmp'


# Implements a loader for top-level ansible_collections packages.

# Generated at 2022-06-23 13:53:04.819342
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    finder = _AnsibleCollectionFinder(paths=['/home/user/ansible_collections'])
    assert isinstance(finder, _AnsibleCollectionFinder)


# Generated at 2022-06-23 13:53:06.457478
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns.collection')


# Generated at 2022-06-23 13:53:14.466574
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    _AnsibleCollectionFinder._remove()
    path_list = ["/ansible_collections"]
    toplevel_pkg = "ansible_collections"
    fullname = "ansible_collections"
    module_to_find = "ansible_collections"
    part_count = 1
    path = path_list
    _AnsibleCollectionFinder.find_module(fullname,path)
# Global dictionary for keeping variables for unit testing. unit_test_dict
unit_test_dict = {}


# Generated at 2022-06-23 13:53:17.016027
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # TODO: method not implemented
    pass

# This uses the kernprof module to profile the collection import and package discovery process

# Generated at 2022-06-23 13:53:25.759258
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # call the class constructor
    collection_finder = AnsibleCollectionConfig.collection_finder
    pathhookfinder = _AnsiblePathHookFinder(collection_finder, '/tmp')
    assert(isinstance(pathhookfinder, _AnsiblePathHookFinder))
    assert(pathhookfinder._pathctx == '/tmp')
    assert(isinstance(pathhookfinder._collection_finder, _AnsibleCollectionFinder))
    assert(pathhookfinder._filefinder_path_hook is not None)

# Helper function for _AnsiblePathHookFinder.iter_modules

# Generated at 2022-06-23 13:53:34.930516
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    dir_name = os.path.dirname(os.path.realpath(__file__))
    collection_finder = _AnsibleCollectionFinder()

    # Set playbook paths from ansible_playbooks
    collection_finder.set_playbook_paths([os.path.join(dir_name, 'ansible_playbooks')])
    assert collection_finder._n_playbook_paths == [os.path.join(dir_name, 'ansible_playbooks', 'collections')]

    # Set playbook paths from ansible_collections
    collection_finder.set_playbook_paths([os.path.join(dir_name, 'ansible_collections')])

# Generated at 2022-06-23 13:53:38.419952
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
  repr_value = repr(_AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo_bar', path_list=['/tmp/foo_bar/src']))
  assert repr_value == "{0}(path={1})".format(_AnsibleCollectionPkgLoaderBase.__name__, ['/tmp/foo_bar/src'])