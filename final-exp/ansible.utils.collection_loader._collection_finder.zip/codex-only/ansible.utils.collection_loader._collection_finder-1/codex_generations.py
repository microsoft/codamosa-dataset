

# Generated at 2022-06-23 13:43:44.827353
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    assert ('action' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins'))
    assert ('callback' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins'))
    assert ('connection' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins'))
    assert ('filter' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins'))
    assert ('inventory' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('inventory_plugins'))
    assert ('lookup' == AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins'))

# Generated at 2022-06-23 13:43:54.492924
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == u'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == u'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == u'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == u'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == u'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir

# Generated at 2022-06-23 13:44:04.456753
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('bad.name', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('a.bad.name', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('a.bad', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('good.name', 'action')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr(u'a good.name', 'module')

# Generated at 2022-06-23 13:44:10.349613
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import tempfile
    tempdir = tempfile.TemporaryDirectory()
    try:
        path = tempdir.name
        myfinder = _AnsiblePathHookFinder(object(), path)
        assert repr(myfinder) == f"_AnsiblePathHookFinder(path='{path}')"
    finally:
        tempdir.cleanup()


# Wraps internal usage of the default loader.get_data() method, delegating to the per-pkg loader's get_data() when
# available.

# Generated at 2022-06-23 13:44:22.147416
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    test_root_paths = ['/somewhere/not/existent']
    test_path = '/somewhere/not/existent/collections'
    test_fullname = 'ansible_collections.some.collection'

    def fake_toplevel_pkg_loader(fullname=None, path_list=None):
        # Pylint doesn't see that toplevel_pkg_loader is actually an instance
        # of _AnsibleCollectionLoader, so it complains.
        # pylint: disable=attribute-defined-outside-init
        if not fullname.startswith('ansible_collections') or path_list != test_path:
            raise AssertionError('Unexpected input for toplevel_pkg_loader')
        self.fullname = fullname
        self.path_list = path_list


# Generated at 2022-06-23 13:44:30.794419
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import os
    import tempfile
    import shutil
    import sys
    import pkgutil
    import ansible_collections

    # Create a temp folder, with a folder ansible_collections, which has a collection "mycoll"
    with tempfile.TemporaryDirectory() as temp_dir:

        temp_sub_folder = os.path.join(temp_dir, "ansible_collections")
        temp_sub_sub_folder = os.path.join(temp_sub_folder, "mycoll")
        os.mkdir(temp_sub_sub_folder)
        with open(os.path.join(temp_sub_sub_folder, "__init__.py"), "w") as f:
            f.write("")

        # Find the modules using the path hook

# Generated at 2022-06-23 13:44:40.929898
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible.module_utils.ansible_modlib._text import to_text
    from ansible.module_utils.ansible_modlib._text import strip_internal_comments
    from ansible.module_utils.ansible_galaxy_api._text import to_text
    from ansible.module_utils.ansible_galaxy_api._text import strip_internal_comments
    from ansible.module_utils.ansible_modlib.common import diff_objects
    from ansible.module_utils.ansible_modlib.common import get_all_subclasses
    from ansible.module_utils.ansible_modlib.common import is_subclass
    from ansible.module_utils.ansible_modlib.common import module_formatter
    from ansible.module_utils.ansible_modlib.common import remove

# Generated at 2022-06-23 13:44:50.786643
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    class BaseFinder:
        def find_spec(self, fullname):
            return True
    importlib.machinery.PathFinder.__init__ = BaseFinder.__init__
    importlib.machinery.PathFinder.find_spec = BaseFinder.find_spec
    importlib.machinery.FileFinder.__init__ = BaseFinder.__init__
    importlib.machinery.FileFinder.find_spec = BaseFinder.find_spec
    importlib.machinery.SourceFileLoader.__init__ = BaseFinder.__init__

    # This is the main method we want to test
    # _AnsiblePathHookFinder.__init__()
    # Testcase 1:
    # Test to verify that the constructor of _AnsiblePathHookFinder works fine

# Generated at 2022-06-23 13:44:56.891589
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    result = _AnsibleCollectionPkgLoaderBase.iter_modules('ansible.collections.acme.testcollection')

# Generated at 2022-06-23 13:44:58.650436
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    foo = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo.bar")




# Generated at 2022-06-23 13:45:11.381499
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ''' AnsibleCollectionRef test '''
    # Test Valid Names
    test_ansible_collection_ref = AnsibleCollectionRef('namespace.collectionname', None, 'resource_name', 'ref_type')
    assert test_ansible_collection_ref.collection == 'namespace.collectionname'
    assert test_ansible_collection_ref.subdirs == ''
    assert test_ansible_collection_ref.resource == 'resource_name'
    assert test_ansible_collection_ref.ref_type == 'ref_type'
    assert test_ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.namespace.collectionname'

# Generated at 2022-06-23 13:45:23.822407
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():

    def _test_finder(finder, fullname, path, expected_loader_class):
        loader = finder.find_module(fullname, path)
        if not loader:
            assert expected_loader_class is None
        else:
            loader_class = type(loader)
            assert loader_class == expected_loader_class

    class MockSysModules(object):
        def __init__(self, modules=None):
            self.modules = {} if modules is None else modules

        def __getitem__(self, item):
            return self.modules[item]

        def __setitem__(self, key, value):
            self.modules[key] = value

        def __iter__(self):
            for key in self.modules:
                yield key


# Generated at 2022-06-23 13:45:25.935108
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', '/path/list')
    assert loader, "Failed to create loader"



# Generated at 2022-06-23 13:45:33.279478
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Input data for the method
    path_list = []
    split_name = ['ansible_collections', 'my_namespace', 'my_collection']
    self = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.my_namespace.my_collection', path_list=path_list)
    self._split_name = split_name
    self._package_to_load = split_name[-1]
    self._parent_package_name = '.'.join(split_name[:-1])
    path_list = ['/path/to/collection/plugins']
    self._candidate_paths = self._get_candidate_paths([p for p in path_list])

# Generated at 2022-06-23 13:45:38.612133
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible.utils.collection_loader import AnsibleCollectionRef

    ref = AnsibleCollectionRef(u'ns.coll', None, u'module_name', u'module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='ns.coll', subdirs=None, resource='module_name')"


# Generated at 2022-06-23 13:45:51.786892
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile, shutil
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 13:45:56.371429
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.module_deprecation', None)
    assert loader._redirect == 'ansible.module_utils.module_deprecation'



# Generated at 2022-06-23 13:46:03.046851
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    import collections
    ansible_collections = collections.defaultdict(dict)

    # Test data

# Generated at 2022-06-23 13:46:14.471898
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-23 13:46:24.173098
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:46:29.486048
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_ref = AnsibleCollectionRef('namespace.collectionname', 'subdir1.subdir2', 'modulename', 'module')
    assert repr(collection_ref) == \
            "AnsibleCollectionRef(collection='namespace.collectionname', subdirs='subdir1.subdir2', resource='modulename')"


# Generated at 2022-06-23 13:46:36.544289
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('ansible.mycollection', ['path'])
    assert loader._fullname == 'ansible.mycollection'
    assert loader._package_to_load == 'mycollection'
    assert loader._split_name == ['ansible', 'mycollection']
    assert loader._parent_package_name == 'ansible'
    assert loader._subpackage_search_paths == ['path/mycollection']


# Generated at 2022-06-23 13:46:46.729550
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    with pytest.raises(ImportError, match='this loader can only load collections namespace packages'):
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns.pkg.module')

    with pytest.raises(ImportError, match='this loader can only load collections namespace packages'):
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns')

    with pytest.raises(ImportError, match='this loader can only load collections namespace packages, not ansible_collections.ns.pkg'):
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns.pkg')

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns')
    assert 'ansible_collections.ns' == loader._fullname

# Generated at 2022-06-23 13:46:56.016410
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_data = [{'legacy_plugin_dir_name': 'action_plugins', 'expected_result': 'action'}, {'legacy_plugin_dir_name': 'library', 'expected_result': 'modules'}]

    for index, test_case in enumerate(test_data):
        assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_case['legacy_plugin_dir_name']) == test_case['expected_result'], 'AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type() test#{0} with data: {1} failed'.format(index, test_case)


# Generated at 2022-06-23 13:47:03.211365
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    try:
        ansible_collection_root_pkg_loader = _AnsibleCollectionRootPkgLoader('')
        # This shouldn't be reached as the constructor of _AnsibleCollectionRootPkgLoader should raise errors
        assert False is True
    except ImportError as e:
        assert e.args[0] == 'this loader can only load the ansible_collections toplevel package, not '

# Generated at 2022-06-23 13:47:07.752261
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    collection_finder = _AnsibleCollectionFinder(paths=['test/collection_path_test/data'], scan_sys_paths=False)
    collection_finder._install()
    assert len(collection_finder._n_configured_paths) == 1
    obj = _AnsiblePathHookFinder(collection_finder,'test/collection_path_test/data')
    # should be 3 packages under this path
    assert len([x for x in obj.iter_modules(None)]) == 3
    collection_finder._remove()
test__AnsiblePathHookFinder_iter_modules()


# Finds modules under a top-level collection root package.

# Generated at 2022-06-23 13:47:20.703132
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    # test ns.coll.subdir1.subdir2.resourcename, type=module
    fqcr = u'my_ns.mycoll.subdir1.subdir2.myresource'
    ref_type = u'module'
    ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)

    assert ref.collection == u'my_ns.mycoll'
    assert ref.subdirs == u'subdir1.subdir2'
    assert ref.resource == u'myresource'
    assert ref.ref_type == u'module'
    assert ref.n_python_collection_package_name == u'ansible_collections.my_ns.mycoll'

# Generated at 2022-06-23 13:47:21.809144
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder

# Generated at 2022-06-23 13:47:33.540074
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    pl = _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase('test', ['/dir'])
    pl._source_code_path = 'test/test/test.py'
    pl._decoded_source = 'test'
    pl._compiled_code = 'test'
    assert pl.get_code('test') == 'test'
    pl._compiled_code = None
    assert pl.get_code('test') == 'test'
    pl._source_code_path = 'test/test/'
    pl._decoded_source = 'test'
    pl._compiled_code = 'test'
    assert pl.get_code('test') == 'test'
    pl._source_code_path = ''
    pl._decoded_source = ''
    pl._compiled_code = None


# Generated at 2022-06-23 13:47:45.406924
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Need to setup up a finder to pass in
    collection_finder = _AnsibleCollectionFinder([os.path.dirname(os.path.dirname(__file__))])

    # Create a new _AnsiblePathHookFinder to test
    test_path_hook_finder = _AnsiblePathHookFinder(collection_finder, os.path.dirname(os.path.dirname(__file__)))
    module = test_path_hook_finder.find_module('ansible_collections.ansible.testcoll.tests')

    # Ensure we got a module back
    assert module is not None, "Did not get back a module as expected"
    assert hasattr(module, 'load_module'), "Did not get back a module with load_module method as expected"

# Generated at 2022-06-23 13:47:47.963697
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase(): # noqa
    """
    Returns:
        bool: success or failure
    """
    _AnsibleCollectionPkgLoaderBase('ansible_collections.test1', path_list=['/tmp'])

    assert True # _AnsibleCollectionPkgLoaderBase class constructor
    return True


# Generated at 2022-06-23 13:48:00.215717
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    this_module = sys.modules[__name__]
    loader = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.parsing.convert_bool', path_list=[])
    assert loader._redirect == 'ansible.module_utils.common.convert_bool'

    loader = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.parsing.convert_bool', path_list=[])
    assert loader._redirect == 'ansible.module_utils.common.convert_bool'

    loader = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.parsing.url_path_argument', path_list=[])

# Generated at 2022-06-23 13:48:07.112487
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():

    #set up args
    fullname = 'xxx'

    #set up return values
    _compiled_code = 'yyy'

    filename = 'zzz'

    source_code = 'aaa'

    #define side_effect functions
    def get_filename(fullname):
        return filename

    def get_source():
        return source_code

    #patch target function
    patch_get_filename = patch('ansible.module_utils.common._AnsibleCollectionPkgLoaderBase.get_filename')
    patch_get_filename.start()
    patch_get_filename.side_effect = get_filename

    patch_get_source = patch('ansible.module_utils.common._AnsibleCollectionPkgLoaderBase.get_source')
    patch_get_source.start()
    patch_get_source.side_

# Generated at 2022-06-23 13:48:13.892408
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Setup the AnsibleCollectionPkgLoader object
    load_module_instance = _AnsibleCollectionPkgLoader('a', 'b', 'c')

    # Setup some arguments for the method load_module
    fullname = 'd'

    # Execute the code to be tested
    load_module_instance.load_module(fullname)

# Generated at 2022-06-23 13:48:20.926400
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    data = 'hi' 
    obj = _AnsibleCollectionPkgLoaderBase(fullname='foo', path_list=None)
    obj._decoded_source = data
    obj._source_code_path = 'somewhere'
    # first case: _decoded_source is set
    res = obj.get_source('foo')
    assert res == data
    # second case: _decoded_source is not set
    res = obj.get_source('foo')
    assert res == data

# Generated at 2022-06-23 13:48:28.947129
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    acr = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert acr.__repr__() ==  'AnsibleCollectionRef(collection=\'ns.coll\', subdirs=\'subdir1.subdir2\', resource=\'resource\')'
    acr = AnsibleCollectionRef('ns.coll', None, 'resource', 'module')
    assert acr.__repr__() == 'AnsibleCollectionRef(collection=\'ns.coll\', subdirs=\'\', resource=\'resource\')'



# Generated at 2022-06-23 13:48:35.741554
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    t_ref_type = "module"
    with pytest.raises(ValueError) as excinfo:
        AnsibleCollectionRef.from_fqcr("ns.coll.subdir1.subdir2.mymodule.py", t_ref_type)
    assert "AnsibleCollectionRef(collection='ns.coll', subdirs='subdir1.subdir2', resource='mymodule.py')" in to_text(excinfo.value)


# Generated at 2022-06-23 13:48:43.023561
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    _module_file_from_path = _AnsibleCollectionPkgLoaderBase._module_file_from_path
    _module_file_from_path.__annotations__ = {}

    class _LoaderForTest(_AnsibleCollectionPkgLoaderBase):
        def __init__(self):
            super(_LoaderForTest, self).__init__('ansible_collections.namespace.collection.module')
            # mock the internals of _AnsibleCollectionPkgLoaderBase
            self._source_code_path, self._allows_package_code, self._subpackage_search_paths = _module_file_from_path('module', '/fake/path')
            self._redirect_module = None

        def get_code(self, fullname):
            pass  # can't call super().get_code because of codepath split

# Generated at 2022-06-23 13:48:54.428717
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import os
    import os.path
    import sys

    from ansible.module_utils._text import to_bytes, to_native

    from ansible.module_utils.common.collections import AnsibleCollectionLoader
    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoaderBase

    def get_test_path(path):
        return os.path.join(os.path.dirname(__file__), 'test_data', path)

    sys.modules.pop('ansible_collections', None)

    # test target we can load a path directly
    test_path1 = get_test_path('collections/test_collection/')
    test_collection = AnsibleCollectionLoader.load(test_path1)
    test_module = test_collection.get('foo.bar.baz')


# Generated at 2022-06-23 13:49:01.660378
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.plugins
    ansible.plugins.__all__.append('foobar')
    sys.modules['ansible.plugins'] = ansible.plugins
    _AnsibleInternalRedirectLoader('ansible.plugins.foobar',[]).load_module('ansible.plugins.foobar')
    assert sys.modules['ansible.plugins.foobar'] == ansible.plugins
    sys.modules['ansible.plugins.foobar'] == ansible.plugins

# Generated at 2022-06-23 13:49:11.135233
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    class MockModuleFinder:
        def __init__(self):
            self.find_module_called = False

        def find_module(self, fullname, path_list):
            self.find_module_called = True
            return _AnsibleInternalRedirectLoader(fullname, path_list)

    # create mock module finder and store it in a global variable
    module_finder = MockModuleFinder()
    sys.meta_path.insert(0, module_finder)

    class MockAnsibleBuiltinMeta:
        def __init__(self):
            self.import_redirection = {'ansible.builtin': {'ansible.builtin.bool_type': {'redirect': 'ansible.builtin.bool_type'}}}

    # create mock builtin meta
    builtin_meta = MockAns

# Generated at 2022-06-23 13:49:19.518817
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = '/path/to/ansible_collections/ns/coll'
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    assert ansible_path_hook_finder._pathctx == '/path/to/ansible_collections/ns/coll'
    assert ansible_path_hook_finder._collection_finder == collection_finder
    assert type(ansible_path_hook_finder._file_finder) == type(None)


# Generated at 2022-06-23 13:49:25.322763
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Tests for AnsibleCollectionRef.__repr__
    acr = AnsibleCollectionRef('foo.bar', '', 'baz', 'module')
    assert repr(acr) == "AnsibleCollectionRef(collection='foo.bar', subdirs='', resource='baz')"



# Generated at 2022-06-23 13:49:33.955963
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils import collection_loader as UCL
    split_name = 'module_utils.module_name.module_to_load'.split('.')
    fullname = '.'.join(split_name)
    toplevel_pkg = split_name[0]
    module_to_load = split_name[-1]
    routing_entry = dict({
        'redirect': 'module_utils.module_name.module_redirect'
    })
    builtin_meta = dict({
        'import_redirection': dict({
            fullname: routing_entry
        })
    })
    existing_module = dict({
        'fullname': 'module_utils.module_name.module_redirect.__name__'
    })

# Generated at 2022-06-23 13:49:41.282931
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == u'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library_plugins') == u'modules'


# Generated at 2022-06-23 13:49:52.605532
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import sys, os
    import_redirection_dict = {
        "ansible.builtin.foo": {"redirect": "ansible.builtin.bar"}}
    builtin_metadata = {'import_redirection': import_redirection_dict}
    builtin_meta = _AnsibleInternalRedirectLoader('ansible.builtin.foo', '/ansible/builtin')
    assert builtin_meta.load_module('ansible.builtin.foo') == ImportError
    _get_collection_metadata.cached_meta_dict['ansible.builtin'] = builtin_metadata
    assert builtin_meta.load_module('ansible.builtin.foo') == module


# unit test for _get_ancestor_redirect

# Generated at 2022-06-23 13:49:53.687373
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # TODO: unit tests for this
    pass

# Generated at 2022-06-23 13:49:55.660218
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/home/ansible'])
    loader


# Generated at 2022-06-23 13:50:06.095687
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr("community.kubernetes.k8s_raw", "module") == \
        AnsibleCollectionRef("community.kubernetes", "k8s_raw", "k8s_raw", "module")
    assert AnsibleCollectionRef.from_fqcr("community.kubernetes.k8s_raw", "module") == \
        AnsibleCollectionRef("community.kubernetes", "k8s_raw", "k8s_raw", "module")
    assert AnsibleCollectionRef.from_fqcr("ansible.builtin.ping", "module") == \
        AnsibleCollectionRef("ansible.builtin", "", "ping", "module")

# Generated at 2022-06-23 13:50:17.384984
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert "ansible_collections.ns1.coll.plugins.action.res" == AnsibleCollectionRef.from_fqcr("ns1.coll.res", "action").n_python_package_name
    assert "ansible_collections.ns1.coll.plugins.action.res" == AnsibleCollectionRef.from_fqcr("ns1.coll.action.res", "action").n_python_package_name
    assert "ansible_collections.ns1.coll.plugins.module_utils.res" == AnsibleCollectionRef.from_fqcr("ns1.coll.res", "module_utils").n_python_package_name

# Generated at 2022-06-23 13:50:25.721319
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    loader._source_code_path = "source_code_path_file"
    loader._decoded_source = "decoded_source"
    #_get_code is called which in turn calls get_source which in turn sets self._decoded_source
    code = loader.get_code('ansible_collections.somens')
    assert code.co_filename == "source_code_path_file"
    # This time _decoded_source is set so get_code doesnot call get_source
    code = loader.get_code('ansible_collections.somens')
    assert code.co_filename == "source_code_path_file"

test__AnsibleCollectionPkgLoaderBase_get_code()



# Generated at 2022-06-23 13:50:37.355370
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # pylint: disable=unused-variable, redefined-outer-name
    from . import AnsibleCollectionConfig

    new_sys_meta_path = object()
    new_sys_path_hooks = object()
    new_sys_path_importer_cache = object()

    old_sys_meta_path = sys.meta_path
    old_sys_path_hooks = sys.path_hooks
    old_sys_path_importer_cache = sys.path_importer_cache


# Generated at 2022-06-23 13:50:40.213739
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('collection', 'subdir', 'resource', 'doc_fragments').__repr__() == "AnsibleCollectionRef(collection='collection', subdirs='subdir', resource='resource')"

# Generated at 2022-06-23 13:50:45.647490
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    redirect_loader = _AnsibleInternalRedirectLoader("ansible.builtin.hostname", None)
    assert redirect_loader._redirect == "ansible.builtin.hostname"


#
# imported_module_map
#
# This stores a weakref to the python module object that is used by the module_utils from each
# collection. The key is a concatenation of the collection namespace and module_utils directory.
# The value is a list of Python module objects for the module_utils in that directory.
#

imported_module_utils_map = {}



# Generated at 2022-06-23 13:50:55.765764
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import os.path
    os.path.join = lambda path, *args, **kwargs: path

    paths = ['/path/foo/bar', '/path/bar/baz', '/path/baz/foo']

    # Find and return a module
    hook = _AnsiblePathHookFinder('', paths)
    hook.find_module = lambda name, path=None: hook
    hook._collection_finder = hook
    hook._filefinder_path_hook = hook
    hook._pathctx = hook
    hook.__class__.__name__ = hook
    hook.__getattribute__ = lambda attribute: hook
    hook.__repr__ = hook

    print(repr(hook))


# Generated at 2022-06-23 13:51:02.420055
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # test expected cases
    _AnsibleCollectionRootPkgLoader('ansible_collections')

    # test exceptions
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.jctanner.testcoll')

    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('fakecollections')



# Generated at 2022-06-23 13:51:04.876571
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'



# Generated at 2022-06-23 13:51:16.440090
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import traceback
    import warnings

    class Importer(object):
        def __init__(self, loader):
            self.loader = loader

        def load_module(self, fullname):
            return self.loader.load_module(fullname)

    class FakeModule(object):
        def __init__(self, fullname):
            self.__file__ = '.'.join(fullname.split('.'))
            self.__name__ = fullname

        def __repr__(self):
            return self.__name__

    def test(name, builtin_pkg_name):
        res = None


# Generated at 2022-06-23 13:51:23.782309
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    loader = _AnsibleCollectionPkgLoaderBase('foo.bar')
    assert repr(loader) == '_AnsibleCollectionPkgLoaderBase(path=None)'
    loader = _AnsibleCollectionPkgLoaderBase('foo.bar', ['/tmp/path'])
    assert repr(loader) == '_AnsibleCollectionPkgLoaderBase(path=[\'/tmp/path\'])'



# Generated at 2022-06-23 13:51:31.255105
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name[0] == ''
    assert loader._rpart_name[2] == 'ansible_collections'
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'

test__AnsibleCollectionRootPkgLoader()



# Generated at 2022-06-23 13:51:42.897507
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # create a file within a temp directory
    temp_dir_obj = tempfile.TemporaryDirectory()
    temp_dir_path = temp_dir_obj.name
    module_name = "test_module"
    test_module_path = os.path.join(temp_dir_path, module_name)
    with open(test_module_path, 'w') as module_file:
        module_file.write("class Test: pass")
    # create a folder within a temp directory
    temp_dir_obj_2 = tempfile.TemporaryDirectory()
    temp_dir_path_2 = temp_dir_obj_2.name
    inner_folder_name = "inner_folder"
    inner_folder_path = os.path.join(temp_dir_path_2, inner_folder_name)
    os.mkdir

# Generated at 2022-06-23 13:51:45.735999
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # TODO: write unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
    raise NotImplementedError()

# Generated at 2022-06-23 13:51:58.756714
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    import pytest

# Generated at 2022-06-23 13:52:07.449304
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    from ansible.module_utils import six
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(six.u('')) == six.u('')
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(six.u('action_plugins')) == six.u('action')
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(six.u('library')) == six.u('modules')
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(six.u('lookup_plugins')) == six.u('lookup')

# Generated at 2022-06-23 13:52:14.295179
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Ansible collection namespace package loader, with search paths
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns_a')
    assert loader._fullname == 'ansible_collections.ns_a'
    assert loader._package_to_load == 'ns_a'
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths is None

    # Ansible collection namespace package loader, no search paths
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns_a', path_list=['/home/dir_a', '/home/dir_b'])
    assert loader._fullname == 'ansible_collections.ns_a'
    assert loader._package_to

# Generated at 2022-06-23 13:52:26.473617
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # test if method is_package of class _AnsibleCollectionPkgLoaderBase returns expected result
    from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionPkgLoaderBase
    class MyClass(_AnsibleCollectionPkgLoaderBase):
        def __init__(self):
            return
    fullname = 'my_package'
    ins = MyClass()
    ins._fullname = fullname
    assert ins.is_package(fullname) == True
# unit test for class `_AnsibleCollectionPkgLoaderBase`
from ansible.utils.path import unfrackpath
from collections import namedtuple
from contextlib import ExitStack
from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionPkgLoaderBase
import pytest
import os
import tempfile
from shutil import rmt

# Generated at 2022-06-23 13:52:36.321247
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    file_name = os.path.join('/tmp/ansible_collections/kube/example', '__init__.py')
    with open(file_name, 'w') as file:
        file.write('#!/usr/bin/python')

    path_list = ['/tmp/ansible_collections/kube/example/']
    fullname = 'ansible_collections.kube.example'
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    #assert
    assert loader.get_source(fullname) == '#!/usr/bin/python'
    # cleanup
    os.remove(file_name)
    shutil.rmtree(os.path.dirname(os.path.dirname(file_name)))



# Generated at 2022-06-23 13:52:47.023276
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_path = "tests/units/cli/loader/"
    data_path = test_path + "fake_data/"

    # Retrieve source code of python package
    loader = _AnsibleCollectionPkgLoaderBase("", path_list=[data_path + "python_package"])
    assert loader
    assert loader.get_data("__init__.py") == b"# empty init"

    # Retrieve source code of python module
    loader = _AnsibleCollectionPkgLoaderBase("", path_list=[data_path + "python_module"])
    assert loader
    assert loader.get_data("test_python_module.py") == b"'# empty module'"

    # Retrieve source code of python module from package

# Generated at 2022-06-23 13:52:55.426282
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Do nothing, just run the code.
    # Eliminate the pylint warning: "Method could be a function"
    # pylint: disable=R0201
    assert True


# NB: this is only here to provide the backend that pkgutil's iter_modules uses during `import`s; while pkgutil will
# frequently delegate to the importer (and even the importer's finder), it will also iterate *all* of the modules it
# otherwise would have imported from a directory, so we have to have a path-based finder in place for that.

# Generated at 2022-06-23 13:53:04.674952
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    #_import_module is a private method, so here is a workaround
    _import_module_backup = ansible.utils.collection_loader._import_module
    def _import_module(name, package=None):
        if name == 'ansible':
            return import_module('ansible')
        else:
            return _import_module_backup(name, package)
    ansible.utils.collection_loader._import_module = _import_module

    # TODO: add metadata config in metadata.json to test the case for which ansible.builtin is a synthetic collection
    # TODO: config file metadata.json
    # FIXME: this test case is not complete
    # TODO: find a way to mock _meta_yml_to_dict, otherwise it is hard to write a

# Generated at 2022-06-23 13:53:15.580865
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # constructor should fail with invalid collection name
    invalid_collection_names = ['', 'ansible', 'ansible.module', 'ansible.', '.module']
    for invalid_name in invalid_collection_names:
        try:
            AnsibleCollectionRef(invalid_name, None, None, None)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid collection name {0} did not raise ValueError'.format(invalid_name))

    # constructor should fail with invalid subdirs
    invalid_subdirs = [None, '', 'a/b', './a']
    for invalid_subdirs in invalid_subdirs:
        try:
            AnsibleCollectionRef('a.b', invalid_subdirs, None, None)
        except ValueError:
            pass

# Generated at 2022-06-23 13:53:19.582540
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    import pytest
    args = (u'ansible.base', u'', u'test', u'module')
    namespace = AnsibleCollectionRef(*args)
    assert namespace.__repr__() == "AnsibleCollectionRef(collection=u'ansible.base', subdirs=u'', resource=u'test')"



# Generated at 2022-06-23 13:53:28.880140
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    with open(os.path.join(os.path.expanduser('~'), 'ansible.cfg'), 'w') as fd:
        fd.write('[defaults]\ncollections_paths=./collections\n')

    data = _AnsibleCollectionPkgLoaderBase.get_data(path='./collections/ansible_collections/ansible/plugins/modules/ping.py')

# Generated at 2022-06-23 13:53:37.265418
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    current_dir_path = os.path.dirname(os.path.realpath(__file__))
    tested_instance = _AnsibleCollectionPkgLoaderBase('test', [current_dir_path])
    assert tested_instance.get_data('test.txt') == b'test file\n'
    assert tested_instance.get_data('test_dir/test.txt') == b'test file\n'
    assert tested_instance.get_data('test_dir/test_dir/test.txt') == b'test file\n'
    assert tested_instance.get_data('does_not_exist') is None
    assert tested_instance.get_data('./relative/path/not/supported') is None
    assert tested_instance.get_data('../.././relative/path/not/supported') is None
