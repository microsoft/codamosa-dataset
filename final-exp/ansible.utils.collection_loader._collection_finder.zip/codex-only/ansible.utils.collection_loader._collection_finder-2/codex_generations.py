

# Generated at 2022-06-23 13:43:42.210619
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    pass

    #test_modules_path = 'test_ansible_collections/test_collection/plugins/modules'
    #test_metadata_path = 'test_ansible_collections/test_collection/meta/collection_info.json'
    #test_metadata_with_version_path = 'test_ansible_collections/test_collection/meta/collection_info_with_version.json'
    #test_metadata_with_invalid_version_path = 'test_ansible_collections/test_collection/meta/collection_info_with_invalid_version.json'
    #test_metadata_with_invalid_keys = 'test_ansible_collections/test_collection/meta/collection_info_with_invalid_keys.json'
    #
    #test_module_filename = 'test_ansible

# Generated at 2022-06-23 13:43:43.454870
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.ns')


# Generated at 2022-06-23 13:43:47.066026
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase('fullname', ['/test/path'])
    source = loader.get_source('fullname')
    # FIXME: test with a data/file/module


# Generated at 2022-06-23 13:43:54.328977
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    testedClass = _AnsibleCollectionPkgLoaderBase
    testedMethod = 'get_code'

    c = testedClass('foo.bar')
    try:
        c.get_code('foo')
        assert False, "should raise error"
    except ValueError:
        pass

    assert c.get_code('foo.bar') is None

    class C1(testedClass):
        def _validate_final(self):
            self._source_code_path = '/tmp/pytest'

        def get_source(self, fullname):
            pass


    c = C1('foo.bar')
    try:
        c.get_code('foo')
        assert False, "should raise error"
    except ValueError:
        pass

    assert c.get_code('foo.bar') is None


# Generated at 2022-06-23 13:44:04.300966
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    global _AnsiblePathHookFinder
    import types
    import runpy
    global mocked_get_data
    global mocked_isfile
    from collections import namedtuple
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import builtins
    # create a convenient mock for all the methods we use
    def mocked_get_data(self, path):
        with open(path, 'r') as f:
            code = f.read()
        return code
    class mocked_isfile:
        def __init__(self, path):
            self.path = path
        def __call__(self, path):
            if path == self.path:
                return True
            else:
                return False
    # create a mock for our entry point


# Generated at 2022-06-23 13:44:10.760333
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Note: If the loader is constructed with an empty list of paths, an ImportError is thrown
    # For example:
    # ValueError: no ansible_collections.my_namespace found in []
    _AnsibleCollectionNSPkgLoader('ansible_collections.my_namespace', path_list=[])
    # Note: If the loader is constructed with a list of paths, no error is thrown
    # For example:
    _AnsibleCollectionNSPkgLoader('ansible_collections.my_namespace', path_list=['/tmp'])



# Generated at 2022-06-23 13:44:16.678579
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns.some_coll')
    assert loader._split_name == ['ansible_collections', 'ns', 'some_coll']
    assert loader._rpart_name == ('ansible_collections.ns', '.', 'some_coll')
    assert loader._parent_package_name == 'ansible_collections.ns'
    assert loader._package_to_load == 'some_coll'


# Implements Ansible's plugin discovery:
# * discover plugins by scanning filesystem paths
# * if the module is a Python module, delegate to the normal path-based finder
# * if the module is not a Python module, return a synthetic module to be later run by the plugin_loader

# Generated at 2022-06-23 13:44:27.616274
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    #Constructor testing
    ansible_collection_ref_object = AnsibleCollectionRef('namespace.collection_name', 'subdir1.subdir2', 'resource_name', 'plugin_type')
    assert(ansible_collection_ref_object.collection == 'namespace.collection_name')
    assert(ansible_collection_ref_object.subdirs == 'subdir1.subdir2')
    assert(ansible_collection_ref_object.resource == 'resource_name')
    assert(ansible_collection_ref_object.ref_type == 'plugin_type')
    assert(ansible_collection_ref_object.n_python_collection_package_name == 'ansible_collections.namespace.collection_name')


# Generated at 2022-06-23 13:44:35.159095
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('', 'collection.foo.bar')
    assert len(loader._split_name) == 3
    assert loader._package_to_load == 'bar'
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths == None
    assert loader._source_code_path == None
    assert loader._compiled_code == None
    assert loader._decoded_source == None
    assert loader._redirect_module == None
    assert loader._parent_package_name == 'collection.foo'
    assert loader._fullname == 'collection.foo.bar'


# Generated at 2022-06-23 13:44:46.896687
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    test_loader = _AnsibleCollectionLoader('test', [], fullname='collection_loader_unittest.ansible_collections.basic_collections.test')
    assert test_loader._package_to_load == 'collection_loader_unittest', "Failed to set package_to_load"
    assert test_loader._candidate_paths == [], "Failed to set candidate_paths"
    assert test_loader._fullname == 'collection_loader_unittest.ansible_collections.basic_collections.test', "Failed to set fullname"
    assert test_loader._split_name == ['collection_loader_unittest', 'ansible_collections', 'basic_collections', 'test'], "Failed to set split_name"

# Generated at 2022-06-23 13:44:59.748134
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'new-ns.new-coll.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr(u'new_ns.new-coll.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr(u'new.ns.new-coll.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr(u'new_ns.new_coll.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr(u'a.b.c.d') is True
    assert AnsibleCollectionRef.is_valid_fqcr(u'a.b.c.d.e') is True

# Generated at 2022-06-23 13:45:02.431546
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    a = _AnsibleCollectionLoader('ansible.test', [])
    assert a

# Generated at 2022-06-23 13:45:14.157848
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class _AnsibleCollectionPkgLoaderBaseUnitTest(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths
        def _validate_final(self):
            pass
        def get_data(self, path):
            if path == './test/fixtures/ansible_collections/collection_loader/schema.json':
                return '{"$schema": "foo"}'
            if path == './test/fixtures/ansible_collections/collection_loader/__init__.py':
                return '#!/usr/bin/python'

# Generated at 2022-06-23 13:45:21.706123
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # test for get_source method
    # FIXME:  this test does not validate actual code
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b"")
    test_file.close()
    loader = _AnsibleCollectionPkgLoaderBase("ansible")
    loader._source_code_path = test_file.name
    loader.get_source("ansible")
    os.remove(test_file.name)


# Generated at 2022-06-23 13:45:29.520309
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    """Unit test for method set_playbook_paths of class _AnsibleCollectionFinder"""
    import ansible_collections
    import ansible_collections.ansible
    import ansible_collections.ansible.tests
    import ansible_collections.another.collection
    finder = _AnsibleCollectionFinder([os.path.dirname(ansible_collections.__file__)])
    # Use the module import to get the path to the ansible_collections dir
    #  before the finder is installed to mimic the execution path in Ansible
    #  init code, as the list of paths to check for collections is updated
    #  when find_module() is called for a collection, which is too late
    #  for our test setup.

# Generated at 2022-06-23 13:45:38.899317
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    pathctx = os.path.join(os.path.dirname(__file__), "test_utils.py")
    ansible_path_hook_finder = _AnsiblePathHookFinder("", pathctx)
    assert isinstance(ansible_path_hook_finder, _AnsiblePathHookFinder)
    if PY3:
        # cache the native FileFinder (take advantage of its filesystem cache for future find/load requests)
        assert isinstance(ansible_path_hook_finder._file_finder, pkgutil.FileFinder)
    assert ansible_path_hook_finder._pathctx == pathctx



# Generated at 2022-06-23 13:45:43.505004
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    with should_be_true():
        test_pkg_loader = _AnsibleCollectionNSPkgLoader(fullname='ansible_collections.test', path_list=['/test/collection/path'])
        assert test_pkg_loader._candidate_paths[0] == '/test/collection/path/test'
        assert test_pkg_loader._subpackage_search_paths[0] == '/test/collection/path/test'


# Generated at 2022-06-23 13:45:50.065540
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'module')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback')

import re


# Generated at 2022-06-23 13:46:00.979938
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # init
    fullname = 'a.b'
    path_list = ['/']
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    loader._get_candidate_paths = Mock()
    loader._get_subpackage_search_paths = Mock(return_value=None)
    loader._validate_args = Mock()
    loader._validate_final = Mock()
    # is_package
    assert loader.is_package(fullname) == False

    mock_value = ['/']
    loader._get_subpackage_search_paths = Mock(return_value=mock_value)
    # is_package
    assert loader.is_package(fullname) == True

# Generated at 2022-06-23 13:46:13.278390
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible_collections.foo.bar.plugins.modules.macports import Macports
    from ansible_collections.foo.bar.plugins.modules.bacula_dir import Bacula_dir
    from ansible_collections.foo.bar.plugins.modules.heartbeat import Heartbeat

# Generated at 2022-06-23 13:46:23.526055
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import ansible_collections.ansible.distutils

    def foo():
        return "foo"

    def bar():
        return "bar"

    def load_module(fullname, module_attrs):
        with _AnsibleCollectionPkgLoaderBase._new_or_existing_module(fullname, **module_attrs) as module:
            # execute the module's code in its namespace
            code_obj = foo.__code__
            exec(code_obj, module.__dict__)
            return module

    def load_module2(fullname, module_attrs):
        with _AnsibleCollectionPkgLoaderBase._new_or_existing_module(fullname, **module_attrs) as module:
            # execute the module's code in its namespace
            code_obj = bar.__code__

# Generated at 2022-06-23 13:46:31.319454
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Stub for testing _AnsibleCollectionPkgLoaderBase.get_filename
    def _get_candidate_paths(path_list):
        return [os.path.join(p, 'library') for p in path_list]
    # Stub for testing _AnsibleCollectionPkgLoaderBase.get_filename
    def _get_subpackage_search_paths(candidate_paths):
        return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]
    # Stub for testing _AnsibleCollectionPkgLoaderBase.get_filename
    def _validate_final():
        return
    # Stub for testing _AnsibleCollectionPkgLoaderBase.get_filename
    def _module_file_from_path(leaf_name, path):
        has_code = True
       

# Generated at 2022-06-23 13:46:41.012753
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class test_pkg_loader(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return path_list
    loader = test_pkg_loader('some_module')
    code_object = loader.get_code('some_module')
    assert code_object.__file__ == 'some_module.py'

    class test_pkg_loader(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return path_list

        def is_package(self, _):
            return True
    loader = test_pkg_loader('some_module')
    code_object = loader.get_code('some_module')
    assert code_object.__file__ == 'some_module/__init__.py'



# Generated at 2022-06-23 13:46:53.820091
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    classloader = _AnsibleCollectionPkgLoaderBase('ansible_test')
    assert classloader._fullname == 'ansible_test'
    assert classloader._redirect_module == None
    assert classloader._split_name == ['ansible_test']
    assert classloader._rpart_name[0] == '' and classloader._rpart_name[1] == '' and classloader._rpart_name[2] == 'ansible_test'
    assert classloader._parent_package_name == ''
    assert classloader._package_to_load == 'ansible_test'
    assert classloader._source_code_path == None
    assert classloader._decoded_source == None
    assert classloader._compiled_code == None
    assert classloader._candidate_paths == None
    assert classloader._subpackage_search

# Generated at 2022-06-23 13:47:01.225559
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    paths = ['/test/test_collection']
    test = None
    try:
        test = _AnsibleCollectionFinder(paths=paths)
    except Exception as e:
        assert False, e

    assert test.__dict__['_ansible_pkg_path'] is not None
    assert test.__dict__['_n_configured_paths'] is not None
    assert test.__dict__['_n_cached_collection_paths'] is None
    assert test.__dict__['_n_cached_collection_qualified_paths'] is None
    assert test.__dict__['_n_playbook_paths'] == []


# Generated at 2022-06-23 13:47:10.465547
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-23 13:47:22.224748
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection = AnsibleCollectionRef("namespace.collectionname", "subdir1.subdir2", "rolename", "role")
    assert ansible_collection.collection == 'namespace.collectionname'
    assert ansible_collection.subdirs == 'subdir1.subdir2'
    assert ansible_collection.resource == 'rolename'
    assert ansible_collection.ref_type == 'role'
    assert ansible_collection.n_python_collection_package_name == 'ansible_collections.namespace.collectionname'
    assert ansible_collection.n_python_package_name == 'ansible_collections.namespace.collectionname.roles.subdir1.subdir2.rolename'



# Generated at 2022-06-23 13:47:33.976132
# Unit test for method load_module of class _AnsibleInternalRedirectLoader

# Generated at 2022-06-23 13:47:40.814453
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    """
    Test _AnsibleCollectionPkgLoader.load_module

    :return:
    """
    loader = _AnsibleCollectionPkgLoader('ansible.collections.testcol.plugins.module_utils', ['.'])
    loader.load_module()

if __name__ == '__main__':
    test__AnsibleCollectionPkgLoader_load_module()

# Generated at 2022-06-23 13:47:49.545444
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    mod_name = 'ansible.plugins.action'

# Generated at 2022-06-23 13:47:56.440855
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    my_ansible_collection = AnsibleCollectionRef(collection_name='test.test',
                                                 subdirs=None,
                                                 resource='test',
                                                 ref_type='test')
    assert my_ansible_collection.is_valid_collection_name('test') == False
    assert my_ansible_collection.is_valid_collection_name('test.test') == True



# Generated at 2022-06-23 13:48:08.012728
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test of is_valid_collection_name
    try:
        AnsibleCollectionRef.is_valid_collection_name(u'an.sib.le')
        assert False, 'is_valid_collection_name did not raise an exception'
    except ValueError:
        pass
    if not AnsibleCollectionRef.is_valid_collection_name(u'ansible.builtin'):
        assert False, 'is_valid_collection_name did not return True for ansible.builtin'
    if not AnsibleCollectionRef.is_valid_collection_name(u'ansible.my_collection'):
        assert False, 'is_valid_collection_name did not return True for ansible.my_collection'

    # Test of is_valid_fqcr

# Generated at 2022-06-23 13:48:20.517393
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import os

    import pytest
    from ansible.vars import combine_vars, persist_vars
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader._collection_finder import _CollectionFinder

    collection1_name = 'my_col1'
    collection1_path = u'/tmp/ansible_collections/my_col1/'
    collection1_package_name = 'my_col1.namespace1'
    collection1_package_path = u'/tmp/ansible_collections/my_col1/namespace1/'
    collection1_package_file = '__init__.py'

# Generated at 2022-06-23 13:48:31.314233
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # prepare a fake env
    prefix = 'ansible_collections.ns_name.collection_name'
    module_name = 'module_name'
    subpackage_name = 'subpackage_name'
    test_dir = 'test_dir'
    test_dir_path = os.path.join(test_dir, subpackage_name)
    test_data_file_contents = b'test_data'
    with tempfile.TemporaryDirectory() as td:
        # create a directory to house our test data
        os.mkdir(os.path.join(td, test_dir))
        # create a test data file
        with open(os.path.join(td, test_dir, 'test_data'), 'wb') as f:
            f.write(test_data_file_contents)
        # create a

# Generated at 2022-06-23 13:48:34.926789
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class TestAnsibleCollectionPkgLoaderBase(ansible.module_utils.six.with_metaclass(_AnsibleCollectionPkgLoaderBase)):
        pass

    loader = TestAnsibleCollectionPkgLoaderBase('my.package')



# Generated at 2022-06-23 13:48:42.388643
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader

    ansible.utils.collection_loader._meta_yml_to_dict = _meta_yml_to_dict

    # test case 1
    collection_name = 'testcase1.testcase1'
    collection_path = '/root/'

    class TestAnsibleCollectionConfig(object):
        on_collection_load_call_count = 0

        @classmethod
        def on_collection_load(cls, collection_name=None, collection_path=None):
            cls.on_collection_load_call_count += 1
            assert collection_name == collection_name
            assert collection_path == collection_path

    AnsibleCollectionConfig = TestAnsibleCollectionConfig

    class TestModule(object):
        __path__ = ['/root/']

# Generated at 2022-06-23 13:48:43.969545
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert _AnsibleInternalRedirectLoader('ansible.module_utils.foo.builtin', None)


# Generated at 2022-06-23 13:48:52.963208
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import pprint
    from types import ModuleType
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase

    # helper function to compare the expected and actual module attributes
    def compare_module(expected, actual):
        if len(expected) != len(actual):
            return False
        for k,v in expected.items():
            if k not in actual:
                return False
            if actual[k] != v:
                return False
        return True

    # mockup the target class
    class _AnsibleCollectionPkgLoaderBaseMockup(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list):
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self

# Generated at 2022-06-23 13:48:59.561473
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    try:
        finder = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
        finder.set_playbook_paths(playbook_paths=['test_path'])

        assert finder._n_playbook_paths == ['test_path/collections']
        assert finder._n_cached_collection_paths == None
    except IOError:
        assert False
    except:
        assert False


# Generated at 2022-06-23 13:49:09.155107
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import tempfile
    import ansible
    tmpdir = tempfile.mkdtemp()
    test_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    test_file.write("""def hello():
    pass
""")
    test_file.close()
    sub_dir = os.path.join(tmpdir, 'testsub')
    if not os.path.exists(sub_dir):
        os.mkdir(sub_dir)
    test_subfile = tempfile.NamedTemporaryFile(mode='w', dir=sub_dir, delete=False)
    test_subfile.write("""def hello():
    pass
""")
    test_subfile.close()

# Generated at 2022-06-23 13:49:14.035389
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    vals = ["valid.name", "invalid.", ".invalid", "valid..invalid", "????.????", "in-valid.name", "invalid.name1"]
    expected = [True, False, False, False, False, False, False]
    actual = []
    for val in vals:
        actual.append(AnsibleCollectionRef.is_valid_collection_name(val))
    assert actual == expected

# Generated at 2022-06-23 13:49:25.532878
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():

    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.extra')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource.extra')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns..coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('12.domains.com.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.12.domains.com.resource')

# Generated at 2022-06-23 13:49:36.662994
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # input args
    fullname = 'ansible_collections.ns.leaf'
    # set up context
    dut = _AnsibleCollectionPkgLoaderBase(fullname)
    dut._parent_package_name = 'ansible_collections.ns'
    dut._package_to_load = 'leaf'
    dut._source_code_path = '.'
    dut._split_name = ['ansible_collections', 'ns', 'leaf']
    dut._rpart_name = ('ansible_collections.ns', '.', 'leaf')
    # exercise
    actual = dut.load_module(fullname)
    # verify
    assert actual is sys.modules['ansible_collections.ns.leaf']
    assert sys.modules['ansible_collections.ns.leaf'].__loader

# Generated at 2022-06-23 13:49:45.495085
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # GIVEN
    expected_result = r"AnsibleCollectionRef(collection='namespace.collection', subdirs='.', resource='resource')"
    expected_result = to_native(expected_result)
    # WHEN
    result = AnsibleCollectionRef('namespace.collection', '.', 'resource', 'collection')

    # THEN
    assert isinstance(result, AnsibleCollectionRef)
    assert result.__repr__() == expected_result



# Generated at 2022-06-23 13:49:57.201135
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    test_cases = [
        dict(
            input_value='a.b.c',
            expected=AnsibleCollectionRef(collection_name='a.b', subdirs="", resource="c", ref_type=""),
        ),
        dict(
            input_value='a.b.c.d',
            expected=AnsibleCollectionRef(collection_name='a.b', subdirs="c", resource="d", ref_type=""),
        ),
        dict(
            input_value='a.b.c.d.e',
            expected=AnsibleCollectionRef(collection_name='a.b', subdirs="c.d", resource="e", ref_type=""),
        ),
    ]

# Generated at 2022-06-23 13:50:02.397003
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    path = '/home/deshmukh/GitHub/ansibullbot/ansibullbot/tests/fixtures/ansible_collections/ansible/os_server/__synthetic__'
    data = _AnsibleCollectionPkgLoaderBase.get_data(path)
    with open(path) as file:
        assert data == file.read()



# Generated at 2022-06-23 13:50:09.782574
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.test', ['/tmp/ns'])
    loader._source_code_path = '/tmp/ns/test/__init__.py'
    result = loader.get_source('ansible_collections.ns.test')
    assert result == '__import__("ansible_collections.ns.test.foo")\n# synthetic collection package\n', "get source method failed"



# Generated at 2022-06-23 13:50:15.084934
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_split_name = 'ansible.module_utils.parsing.convert_bool'.split('.')
    _AnsibleInternalRedirectLoader(fullname=ansible_split_name, path_list='')


# this is only for explicit imports of builtin modules (ansible.module_utils.parsing.convert_bool)

# Generated at 2022-06-23 13:50:24.075023
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test constructor with valid entries
    cr = AnsibleCollectionRef(u'namespace.test', u'', u'newtest', u'role')
    assert cr.collection == u'namespace.test'
    assert cr.subdirs == u''
    assert cr.resource == u'newtest'
    assert cr.ref_type == u'role'
    assert cr.fqcr == u'namespace.test.newtest'

    cr = AnsibleCollectionRef(u'namespace.test', u'', u'newtest.yml', u'playbook')
    assert cr.collection == u'namespace.test'
    assert cr.subdirs == u''
    assert cr.resource == u'newtest'
    assert cr.ref_type == u'playbook'

# Generated at 2022-06-23 13:50:31.581587
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert repr(_AnsiblePathHookFinder(['path1', 'path2'])) == "_AnsiblePathHookFinder(path_list=['path1', 'path2'])"


# override pkgutil.iter_modules to respect any path manipulations; this is mostly used by
# ansible.module_utils.common._load_params which is called from many places.
# TODO: replace more of pkgutil.iter* calls in order to handle any path context overhaul

# Generated at 2022-06-23 13:50:38.202120
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('namespace.collection.subcollection.module')
    assert loader.get_filename('namespace.collection.subcollection.module') == '<ansible_synthetic_collection_package>'
    loader._subpackage_search_paths = []
    loader._source_code_path = '/tmp/toto.py'
    assert loader.get_filename('namespace.collection.subcollection.module') == '/tmp/toto.py'



# Generated at 2022-06-23 13:50:45.888096
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class TestLoader(object):
        def __init__(self, fullname, path_list = None):
            super(TestLoader, self).__init__()
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens

            self._source_code_path = None
            self._decoded_source = None
            self._compiled_code = None



# Generated at 2022-06-23 13:50:53.647605
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # TODO: In-memory collections are not yet supported, so this test is currently disabled.
    #
    # collection = {'namespace': {'name': 'collection', 'version': '0.0.1'},
    #               'plugins': {'modules': {'module.py': 'def var():\n    return 42\n'}}}
    # col_loader = AnsibleCollectionLoader(collection)
    # col_loader.load_module('module')
    #
    # assert sys.modules['module'].var() == 42
    pass



# Generated at 2022-06-23 13:51:05.622338
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # invalid collection_name
    with pytest.raises(ValueError) as excinfo:
        AnsibleCollectionRef('name.space', '', 'resource', 'role')
    assert to_native(excinfo.value) == 'invalid collection name (must be of the form namespace.collection): \'name.space\''

    # invalid subdirs
    with pytest.raises(ValueError) as excinfo:
        AnsibleCollectionRef('name.space', 'invalid/subdir', 'resource', 'role')
    assert to_native(excinfo.value) == 'invalid subdirs entry: \'invalid/subdir\' (must be empty/None or of the form subdir1.subdir2)'

    # invalid ref_type

# Generated at 2022-06-23 13:51:10.840303
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    
    def custom_get_source(self, fullname):
        return ';).'.encode('utf-8')
    
    _AnsibleCollectionPkgLoaderBase.get_source = custom_get_source
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns')
    source = loader.get_source('ansible_collections.ns')
    print(source)
    assert source.decode('utf-8') == ';).'

# Generated at 2022-06-23 13:51:19.129904
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Create an instance of _AnsibleCollectionPkgLoaderBase
    full_name = 'ansible_collections.somens'
    path_list = []
    instance = _AnsibleCollectionPkgLoaderBase(full_name, path_list)
    # Assert instance attribute _subpackage_search_paths has None as its value
    assert instance._subpackage_search_paths == None
    # Assert instance method is_package is False
    assert instance.is_package(full_name) == False

    # Create an instance of _AnsibleCollectionPkgLoaderBase
    full_name_new = 'ansible_collections.somens'
    path_list_new = []
    instance_new = _AnsibleCollectionPkgLoaderBase(full_name_new, path_list_new)
    # Assert

# Generated at 2022-06-23 13:51:31.173566
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Setup
    if not os.path.exists('tmp'):
        os.mkdir('tmp')
    if not os.path.exists('tmp/test_collections'):
        os.mkdir('tmp/test_collections')
    if not os.path.exists('tmp/test_collections/test_collections'):
        os.mkdir('tmp/test_collections/test_collections')
    if not os.path.exists('tmp/test_collections/test_collections/test_collection'):
        os.mkdir('tmp/test_collections/test_collections/test_collection')

# Generated at 2022-06-23 13:51:42.797110
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    '''
    _AnsibleCollectionPkgLoader.load_module - This function loads the module required by a given import statement
    '''
    # test case 1
    # if the module is being reloaded, the values in sys.modules[fullname] are updated with the values of module_attrs
    fullname = 'ansible_collections.ns.col_pkg.some_module'
    module_attrs = {'__loader__': '', '__file__': '', '__package__': 'ansible_collections.ns.col_pkg'}
    created_module = False
    module = ModuleType(fullname)
    created_module = True
    sys.modules[fullname] = module
    for attr, value in module_attrs.items():
        setattr(module, attr, value)

    assert sys

# Generated at 2022-06-23 13:51:50.906099
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("connection_plugins") == "connection"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("lookup_plugins") == "lookup"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library") == "module"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("vars_plugins") == "vars"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("filter_plugins") == "filter"

# Generated at 2022-06-23 13:52:02.368346
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # this code is auto-generated, so it can be a bit "off"
    # (eg, unquoted identifiers, formatting, raw values not cast, etc)
    # Could probably clean it up with a good python code formatter+linter
    collection_path = '/home/audyou/.ansible/collections/ansible_collections/audyou/mycollection'
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.audyou.mycollection',
        path_list = [ to_bytes(collection_path) ]
    )
    # The following code should be equivalent to:
    # loader.get_filename('ansible_collections.audyou.mycollection')
    filename = loader.get_filename(loader._fullname)

# Generated at 2022-06-23 13:52:07.042965
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # _AnsibleCollectionNSPkgLoader.__init__(fullname, path_list=None)
    cases = [
        ('ansible_collections', None, None),  # too short
        ('ansible_collections.foobar', None, 'ansible_collections.foobar')]  # OK
    for case in cases:
        try:
            loader = _AnsibleCollectionNSPkgLoader(*case[:2])
        except ImportError as e:
            assert e.args[0] == 'this loader can only load collections namespace packages, not %s' % case[0]  # right exception?
        else:
            assert loader._fullname == case[2]  # right name?

# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections names

# Generated at 2022-06-23 13:52:15.855206
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import unittest

    class Test__AnsiblePathHookFinder(unittest.TestCase):
        def setUp(self):
            self._AnsiblePathHookFinder_instance = _AnsiblePathHookFinder(None, None)

        def test__AnsiblePathHookFinder(self):
            self.assertEqual(self._AnsiblePathHookFinder_instance._pathctx, None)
            self.assertEqual(self._AnsiblePathHookFinder_instance._collection_finder, None)
            self.assertEqual(self._AnsiblePathHookFinder_instance._file_finder, None)

# Generated at 2022-06-23 13:52:19.394707
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
  with pytest.raises(NotImplementedError):
    _AnsibleCollectionPkgLoaderBase('').is_package('')



# Generated at 2022-06-23 13:52:29.752791
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # Part 1: Private member of the class _AnsibleCollectionFinder is tested.
    # The private member '_n_configured_paths' is tested, which has been created in
    # __init__ function by taking inputs from user.
    # The value of '_n_configured_paths' for different inputs is tested.
    # To test this we will create a instance of a class '_AnsibleCollectionFinder'
    # with param 'paths='.
    af_paths = ['$HOME', 'path2']
    finder1 = _AnsibleCollectionFinder(paths=af_paths)
    if PY3:
        assert finder1._n_configured_paths == [os.path.expanduser('~'), 'path2']
    else:
        assert finder1._n_

# Generated at 2022-06-23 13:52:36.650846
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-23 13:52:47.033203
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import os, tempfile
    def create_test_file(directory, filename, content):
        filepath = os.path.join(directory, filename)
        with open(filepath, 'w') as target_file:
            target_file.write(content)
        return filepath

    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = create_test_file(tmpdir, 'test.txt', 'test string')
        assert _AnsibleCollectionPkgLoaderBase.get_data(test_file) == 'test string'
        assert _AnsibleCollectionPkgLoaderBase.get_data(
            os.path.join(os.path.dirname(test_file), 'test_not_exist.txt')) is None

# Generated at 2022-06-23 13:52:56.449009
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    path = []
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.test', path_list=path)
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.test_ns', path_list=path)
    loader.load_module('ansible_collections.test_ns')
    loader.get_source(fullname='ansible_collections.test_ns')
    loader.get_code(fullname='ansible_collections.test_ns')
    loader.is_package('ansible_collections.test_ns')
    loader.iter_modules(prefix=None)
    loader.__repr__()



# Generated at 2022-06-23 13:53:02.380191
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():

    # Path for testing with non existant module
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                        'lib', 'ansible_collections', 'mock', 'module')

    # Test with non existant module
    loader = _AnsibleCollectionPkgLoaderBase('mock.module', [path])
    if not loader.is_package('mock'):
        display.error("Failed to check is_package in a non existant module")



# Generated at 2022-06-23 13:53:12.710818
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Unit test for method is_valid_fqcr of class AnsibleCollectionRef
    # Create some valid fqcr
    ref_type = 'module'
    fqcr_list = ['foo.bar.baz', 'foo.bar.baz.fooo.baar', 'foo.bar.baz.fooo.baar.bazz',
                 'f.b.b.f.b.f.b.f.b.b.f.b.f.b.f.b.b.f.b.f.b.b.f.b.f.b.f.b.b.f.b.f.b.b.f.b.f.b.f.b.b.f.b.f.b.b.f.b.f.b.f.b.b']

# Generated at 2022-06-23 13:53:19.542236
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', ['/var/tmp/foo'])
    assert loader._package_to_load == 'ansible_collections'
    assert loader._parent_package_name == ''
    loader = _AnsibleCollectionRootPkgLoader('foo', ['/var/tmp/bar'])
    assert repr(loader) == "_AnsibleCollectionRootPkgLoader(path=None)"



# Generated at 2022-06-23 13:53:28.879626
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    abs_module_path = "/ansible_collections/somens/module.py"

    # Loader for module.py
    class _AnsibleCollectionPkgLoaderBaseTest(_AnsibleCollectionPkgLoaderBase):
        def __init__(self):
            fullname = "ansible_collections.somens"
            path_list = []
            _AnsibleCollectionPkgLoaderBase.__init__(self, fullname, path_list)
            self._source_code_path = abs_module_path

        def _get_candidate_paths(self, path_list):
            return [abs_module_path]

        def _get_subpackage_search_paths(self, candidate_paths):
            return []

    loader = _AnsibleCollectionPkgLoaderBaseTest()

    expected_source

# Generated at 2022-06-23 13:53:35.078994
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.a.b.c.d', 'role') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.a.b.c', 'role') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.a.b.c', 'module') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.a.b.c', 'collection') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.a.b.c', 'playbook') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.a.b.c') == False

    assert AnsibleCollectionRef.is_valid_fq

# Generated at 2022-06-23 13:53:39.038028
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    c = _AnsibleCollectionFinder()
    c.set_playbook_paths(['t1', 't2'])

    assert c._n_playbook_paths == ['t1/collections', 't2/collections']

    c.set_playbook_paths(['t4', 't4'])

    assert c._n_playbook_paths == ['t4/collections']

    # TODO: test de-dupe behavior
    # TODO: test overrides
    # TODO: test resolving relative paths?
    # TODO: test exceptions?


_LOAD_INIT = 0x01
_LOAD_CODE = 0x02
_LOAD_BUILTINS = 0x04

