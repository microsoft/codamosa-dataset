

# Generated at 2022-06-25 12:51:41.363909
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.builtin.set_fact')
    ansible_collection_pkg_loader._source_code_path = 'mod_path_0'
    ansible_collection_pkg_loader._subpackage_search_paths = None
    with open('mod_path_0', 'w') as f_0:
        f_0.write('test_module')
    ansible_collection_pkg_loader.get_data('mod_path_0')


# Generated at 2022-06-25 12:51:52.056068
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder = _AnsibleCollectionFinder()

    # Test top-level packages.
    ansible_collection_finder.find_module('ansible')
    # Test for sub-packages.
    ansible_collection_finder.find_module('ansible.module_utils')

    # Test for top-level ansible_collections package.
    ansible_collection_finder.find_module('ansible_collections')

    # Test for name spaces.
    ansible_collection_finder.find_module('ansible_collections.namespace')

    # Test for collection packages.
    ansible_collection_finder.find_module('ansible_collections.namespace.collection')

    # Test for modules outside of a collection.

# Generated at 2022-06-25 12:52:00.597407
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    try:
        import ansible.module_utils.urls
    except ImportError:
        pass
    else:
        # If ansible.module_utils.urls is already loaded, this test can't pass
        return
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.urls', [])
    loader.load_module('ansible.module_utils.urls')
    import ansible.module_utils.urls
    assert (ansible.module_utils.urls.__name__ == 'ansible.module_utils.http')

# Generated at 2022-06-25 12:52:11.928358
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test case where module_to_load is a collection namespace
    loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.collectors.all')
    # Test case where module_to_load is a collection namespace
    loader_1 = _AnsibleCollectionPkgLoaderBase('ansible_collections.collectors.all', path_list=['/tmp/ansible_collections/collector0'])
    # Test case where module_to_load is a collection namespace and not in the sys.path
    loader_2 = _AnsibleCollectionPkgLoaderBase('ansible_collections.collectors.all', path_list=['/tmp/ansible_collections/collector1'])
    # Test case where module_to_load is a collection module
    loader_3 = _AnsibleCollectionPkgLoader

# Generated at 2022-06-25 12:52:19.574674
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    pkg = _AnsibleCollectionPkgLoaderBase('collections.test_ns')
    pkg._source_code_path = None
    pkg._subpackage_search_paths = ['/path/to/dir']

    assert pkg.get_filename('collections.test_ns') == '/path/to/dir/__synthetic__'

    pkg._subpackage_search_paths = []

    assert pkg.get_filename('collections.test_ns') == '<ansible_synthetic_collection_package>'

    pkg._source_code_path = '/path/to/collections/test_ns/somemodule.py'
    pkg._subpackage_search_paths = None


# Generated at 2022-06-25 12:52:28.379099
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # parse valid ref, with different case
    fqcr = 'AnSiBlE.TEST.PLUGIN'
    assert AnsibleCollectionRef.try_parse_fqcr(fqcr, 'module')
    # parse valid ref, using only lower case
    fqcr = 'ansible.test.plugin'
    assert AnsibleCollectionRef.try_parse_fqcr(fqcr, 'module')
    # parse valid subdir plugin
    fqcr = 'ansible.test.subdir1.subdir2.plugin'
    assert AnsibleCollectionRef.try_parse_fqcr(fqcr, 'module')
    # parse valid role
    fqcr = 'ansible.test.rolename'
    assert AnsibleCollectionRef.try_parse_fqcr(fqcr, 'role')
    f

# Generated at 2022-06-25 12:52:38.041452
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test with invalid collection reference
    fqcr = AnsibleCollectionRef.try_parse_fqcr("ns.coll.rolename.not a role", 'role')
    assert(fqcr is None)

    # Test with valid collection reference
    fqcr = AnsibleCollectionRef.try_parse_fqcr("ns.coll.rolename", 'role')
    assert(fqcr is not None)
    assert(fqcr.collection == "ns.coll")
    assert(fqcr.subdirs == "")
    assert(fqcr.n_python_collection_package_name == "ansible_collections.ns.coll")
    assert(fqcr.n_python_package_name == "ansible_collections.ns.coll.roles.rolename")

# Generated at 2022-06-25 12:52:46.197863
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collection.p0.p1')
    output = ansible_collection_pkg_loader_base_0.is_package('ansible_collection.p0.p1')
    assert output == False
    output = ansible_collection_pkg_loader_base_0.is_package('ansible_collection.p0.p1.p2')
    assert output == True

if __name__ == '__main__':
    test_case_0()
    test__AnsibleCollectionPkgLoaderBase_is_package()

# Generated at 2022-06-25 12:52:56.264626
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Check that the method try_parse_fqcr correctly parses a valid FQCR
    test_ref_with_subdir = 'some.great.module'
    test_ref_without_subdir = 'namespace.collection.some_module'
    test_ref_with_subdir_type = 'module'
    test_ref_without_subdir_type = 'module'

    result_with_subdir = AnsibleCollectionRef.try_parse_fqcr(test_ref_with_subdir, test_ref_with_subdir_type)
    result_without_subdir = AnsibleCollectionRef.try_parse_fqcr(test_ref_without_subdir, test_ref_without_subdir_type)

    assert result_with_subdir is not None
    assert result_with_subdir.sub

# Generated at 2022-06-25 12:52:59.156282
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader_base = _AnsibleCollectionPkgLoaderBase("ansible_collections.base")
    data0 = loader_base.get_data('/etc/hosts')
    data1 = loader_base.get_data('/etc/resolv.conf')

    assert data0 is not None
    assert data1 is not None


# Generated at 2022-06-25 12:53:38.800699
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
  from importlib import util

  test_mod_code = util.find_spec("tests.test_module_loader_module").loader.get_code("tests.test_module_loader_module")
  global module_code
  module_code = test_mod_code



# Generated at 2022-06-25 12:53:45.853094
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test for valid inputs
    # Test for a module in the root of the plugin
    output_01 = AnsibleCollectionRef.from_fqcr(ref='namespace.collection.module', ref_type='modules')
    assert output_01.n_python_package_name == 'ansible_collections.namespace.collection.plugins.modules'
    assert output_01.resource == 'module'
    assert output_01.ref_type == 'modules'

    # Test for a module which resides in a subdirectory
    output_02 = AnsibleCollectionRef.from_fqcr(ref='namespace.collection.subdir.module', ref_type='modules')
    assert output_02.n_python_package_name == 'ansible_collections.namespace.collection.plugins.modules.subdir'

# Generated at 2022-06-25 12:53:56.431062
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.subdir3.resource', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.subdir3.resource.py', 'module')
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.subdir3.resource.py', 'action')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.subdir3.resource.py', 'playbook')

# Generated at 2022-06-25 12:54:04.739543
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    source_code = 'this is the source code'
    module_mock = MagicMock()
    module_mock.__dict__ = {'__loader__': source_code,
                            '__path__': source_code,
                            '__file__': source_code,
                            '__name__': source_code,
                            '__package__': source_code}


# Generated at 2022-06-25 12:54:16.989764
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.namespace.collection1')
    ansible_collection_pkg_loader_base._subpackage_search_paths = ['/playbooks/ansible_collections/namespace1/collection1', '/playbooks/ansible_collections/namespace2/collection1']
    # Test with positive path
    data = ansible_collection_pkg_loader_base.get_data('/playbooks/ansible_collections/namespace1/collection1/module.py')
    assert data != None
    # Test with None path value
    with pytest.raises(ValueError) as execinfo:
        data = ansible_collection_pkg_loader_base.get_data(None)

# Generated at 2022-06-25 12:54:21.506818
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    test_loader = _AnsibleCollectionPkgLoaderBase('test_name', [ 'test_pth_list' ])

    assert test_loader.get_source('ansible_collections.a.b.c.d') == None


# Generated at 2022-06-25 12:54:25.983903
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    toplevel_pkg = 'string'
    fullname = 'string'
    path = ['string']
    x = ansible_collection_finder_0._AnsiblePathHookFinder(ansible_collection_finder_0, 'string').find_module(fullname, path)


# Generated at 2022-06-25 12:54:29.955576
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # TODO: create/mock loader and/or paths
    result = _AnsibleCollectionPkgLoaderBase.get_source('module_name')
    assert result == None


# Generated at 2022-06-25 12:54:41.282948
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Create an instance of _AnsibleCollectionPkgLoaderBase
    test_module_name = 'junit.module_0'
    test_module_path = 'test/ansible_collections/junit/module_0/module_0.py'
    loader_0 = _AnsibleCollectionPkgLoaderBase(test_module_name, [os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                                                               'ansible_collections')])
    module_0_absolute_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                           'ansible_collections/junit/module_0/module_0.py')

# Generated at 2022-06-25 12:54:44.884190
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader_0 = _AnsibleCollectionRootPkgLoader('ansible_collections')
    root_pkg_loader_repr = loader_0.__repr__()
    assert root_pkg_loader_repr.startswith('_AnsibleCollectionRootPkgLoader(path=')



# Generated at 2022-06-25 12:55:23.902364
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    if not os.path.isdir(TEST_DATA_DIR):
        raise ValueError('test data dir not found')

    # case 0
    builtin_loader = _AnsibleCollectionPkgLoader('ansible.builtin', [TEST_DATA_DIR])
    _AnsibleInternalRedirectLoader._redirected_package_map = {}
    # test case 0
    # redirect target is an existing package that has been imported already
    assert sys.modules['ansible'] is builtin_loader.load_module('ansible')
    redirector = _AnsibleInternalRedirectLoader('ansible.builtin.test_redirector_0', [TEST_DATA_DIR])
    assert redirector.load_module('ansible.builtin.test_redirector_0').__name__ == 'ansible'
    # make

# Generated at 2022-06-25 12:55:35.455865
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    test_loader = _AnsibleCollectionPkgLoaderBase("ansible.builtin", path_list=["/tmp"])
    assert test_loader.get_filename("ansible.builtin") == "/tmp/builtin/__init__.py"

    # test case when _subpackage_search_paths is None
    test_loader = _AnsibleCollectionPkgLoaderBase("ansible.builtin", path_list=[])
    assert test_loader.is_package("ansible.builtin") is False
    assert test_loader.get_filename("ansible.builtin") == "/tmp/builtin.py"

    # test case when _subpackage_search_paths is empty
    test_loader = _AnsibleCollectionPkgLoader

# Generated at 2022-06-25 12:55:43.061287
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_package_loader_base_1 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns1.test_col1.test_pkg1', path_list=['/abc/abc1','/abc/abc2'])
    ansible_collection_package_loader_base_1._subpackage_search_paths = ['/abc/abc1']
    isPackage = ansible_collection_package_loader_base_1.is_package(fullname='ansible_collections.test_ns1.test_col1.test_pkg1')
    assert isPackage == True


# Generated at 2022-06-25 12:55:50.158026
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:56:00.371396
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    AnsibleCollectionRef(collection_name='ns1.coll1',
                         subdirs='',
                         resource='module1',
                         ref_type='module')
    AnsibleCollectionRef(collection_name='ns1.coll1',
                         subdirs='subdir1.subdir2',
                         resource='module1',
                         ref_type='module')
    AnsibleCollectionRef(collection_name='ns1.coll1',
                         subdirs='',
                         resource='rolename1',
                         ref_type='role')
    AnsibleCollectionRef(collection_name='ns1.coll1',
                         subdirs='',
                         resource='playbookname1.playbook1',
                         ref_type='playbook')

# Generated at 2022-06-25 12:56:09.855411
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class MockAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return None

        def _validate_final(self):
            self._source_code_path = self._candidate_paths[0]

    loader = MockAnsibleCollectionPkgLoaderBase(
        'ansible_collections.ns.coll.plugin',
        path_list=['/path/to/ansible_collections/ns/coll/plugins/filter']
    )

    assert loader.get_data('/path/to/ansible_collections/ns/coll/plugins/filter/test.py') is not None

# Generated at 2022-06-25 12:56:18.853417
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase("", [])
    assert loader.get_data("/some/file") == None
    loader = _AnsibleCollectionPkgLoaderBase("", ["/usr/local/share/ansible/ansible_collections/testns"])
    assert loader.get_data("/usr/local/share/ansible/ansible_collections/testns/testcoll/__init__.py") == ""
    assert loader.get_data("/usr/local/share/ansible/ansible_collections/testns/testcoll/__init__.py") == ""


# Generated at 2022-06-25 12:56:27.810834
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_ns.test_module')
    loader_1 = _AnsibleCollectionPkgLoaderBase(
        'ansible_collections.test.test_ns.synthetic_package.subpackage.submodule')

    module_0 = loader_0.load_module('ansible_collections.test.test_ns.test_module')
    module_1 = loader_1.load_module('ansible_collections.test.test_ns.synthetic_package.subpackage.submodule')

    assert module_0.__name__ == 'ansible_collections.test.test_ns.test_module'
    assert module_0.__package__ == 'ansible_collections.test.test_ns'
    assert module_

# Generated at 2022-06-25 12:56:33.600542
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_case = dict(
        src_path = '/tmp/test_file',
        split_name = ['ansible_collections', 'test', 'collection']
    )
    loader = _AnsibleCollectionPkgLoader(test_case['src_path'], path=[test_case['src_path']], split_name=test_case['split_name'])
    # TODO: Do more assertions
    # This line will fail without mock of _meta_yml_to_dict
    test_module = loader.load_module(test_case['split_name'])
    assert hasattr(test_module,'_collection_meta')

# Generated at 2022-06-25 12:56:38.838567
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'

# Generated at 2022-06-25 12:58:15.678969
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible_collections.test_ns.test_coll.plugins.modules import debug_test_module
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test_ns.test_coll.plugins.modules.debug_test_module')
    source_code = loader.get_source(fullname='ansible_collections.test_ns.test_coll.plugins.modules.debug_test_module')
    assert source_code == debug_test_module.__source__, "Unexpected source code"



# Generated at 2022-06-25 12:58:23.836519
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.plugins.loader', ['dummy_path'])
    assert redirect_loader._redirect == 'ansible.builtin.plugins.loader'
    redirect_loader.load_module('ansible.plugins.loader')



# Generated at 2022-06-25 12:58:29.099197
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    name = "test_1.test_2"
    path = ['ansible_collections/namespace1/collection1/plugins/modules/foo']
    loader = _AnsibleCollectionPkgLoaderBase(name, path)

    # Test with a valid resource path
    res_path = loader._source_code_path = 'ansible_collections/namespace1/collection1/plugins/modules/foo/lib/bar.py'
    data = loader.get_data(res_path)
    assert os.stat(res_path).st_size == len(data)

    # Test with an invalid resource path (file does not exist)
    res_path = './ansible_collections/namespace1/collection1/plugins/modules/foo/lib/bar.py'
    data = loader.get_data(res_path)


# Generated at 2022-06-25 12:58:36.306378
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    pkg_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', [])
    res_0 = pkg_loader_0.get_filename('ansible_collections.foo.bar')
    assert res_0 == '<ansible_synthetic_collection_package>'


# Generated at 2022-06-25 12:58:46.115217
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # ansible_collections.plugins.module_utils.network.fortinet
    acpl = _AnsibleCollectionPkgLoader('ansible_collections/plugins/module_utils/network/fortinet', None)
    module = acpl.load_module('ansible_collections.plugins.module_utils.network.fortinet')

    assert module._collection_meta is not None
    assert module._collection_meta

# Generated at 2022-06-25 12:58:57.121316
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    module_spec = ModuleSpec('test_collection_loader.test_mod', _AnsibleCollectionPkgLoader('test_mod', ['test_mod']))
    module = module_spec.loader.load_module('test_collection_loader.test_mod')

    assert module._name == 'test_collection_loader.test_mod', "Loaded module's name is not correct"
    assert module.__file__ == '<string>', "Loaded module's __file__ is not correct"
    assert module.__loader__ == module_spec.loader, "Loaded module's __loader__ is not correct"
    assert module.__package__ == 'test_collection_loader.test_mod', "Loaded module's __package__ is not correct"

# Generated at 2022-06-25 12:59:07.136716
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.f5networks.f5_modules',
        path_list=[ '.']
    )
    ansible_collection_pkg_loader_base_0.get_filename(
        fullname='ansible_collections.f5networks.f5_modules'
    )
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.ansible.modules_core',
        path_list=[ '.']
    )
    ansible_collection_pkg_loader_base_0.get_filename(
        fullname='ansible_collections.ansible.modules_core'
    )


# Generated at 2022-06-25 12:59:12.143340
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.abc.abc', path_list=['/a/b/c'])
    ansible_collection_loader_0._source_code_path = '/a/b/c/abc/__init__.py'
    filename = ansible_collection_loader_0.get_filename('ansible_collections.abc.abc')

    ansible_collection_loader_1 = _AnsibleCollectionPkgLoaderBase('ansible_collections.abc.abc', path_list=['/a/b/c'])
    ansible_collection_loader_1._source_code_path = '/a/b/c/abc/def.py'

# Generated at 2022-06-25 12:59:14.127274
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('fullname')
    print(str(ansible_collection_pkg_loader_base.__repr__()))


# Generated at 2022-06-25 12:59:19.554579
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # setup
    test_case_name = 'test__AnsibleCollectionPkgLoaderBase_get_code'
    test_case_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    test_case_dir = os.path.join(test_case_dir, 'test_data')
    test_case_dir = os.path.join(test_case_dir, test_case_name)
    test_case_path = os.path.join(test_case_dir, 'test_case')
    test_case_pkg = 'ansible_collections.plugin.test.test_case'

    test_case_0_file_path = os.path.join(test_case_path, 'test_case_0.py')
    test_case_0