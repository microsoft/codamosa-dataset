

# Generated at 2022-06-25 12:51:19.935163
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    ansible_collection_root_pkg_loader = _AnsibleCollectionRootPkgLoader('ansible_collections')


# Generated at 2022-06-25 12:51:23.682130
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    ansible_internal_redirect_loader_0 = None
    ansible_internal_redirect_loader_1 = _AnsibleInternalRedirectLoader(ansible_internal_redirect_loader_0, ansible_internal_redirect_loader_0)



# Generated at 2022-06-25 12:51:28.951556
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():

    ansible_collection_loader_0 = None
    ansible_internal_redirector_0 = _AnsibleInternalRedirectLoader(ansible_collection_loader_0, ansible_collection_loader_0)

# Helper function to test the constructor of class _AnsibleInternalRedirectLoader

# Generated at 2022-06-25 12:51:35.284854
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ansible_collection_loader_0 = _AnsibleCollectionLoader(None, None)
    ansible_collection_loader_1 = _AnsibleCollectionLoader(ansible_collection_loader_0, ansible_collection_loader_0)
    ansible_collection_pkg_loader_0 = None
    ansible_collection_pkg_loader_1 = _AnsibleCollectionPkgLoaderBase(None, None)
    with pytest.raises(Exception):
        ansible_collection_pkg_loader_1.get_code(None)


# Generated at 2022-06-25 12:51:40.160631
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_collection_loader_0 = None
    ansible_collection_loader_1 = _AnsibleInternalRedirectLoader(ansible_collection_loader_0, ansible_collection_loader_0)
    ansible_collection_loader_2 = ansible_collection_loader_1.load_module('ansible.builtin')


# Generated at 2022-06-25 12:51:51.503899
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # setup a temp directory
    tmp_test_dir = os.path.join(tempfile.gettempdir(), 'test__AnsibleCollectionPkgLoaderBase_get_data')
    if os.path.exists(tmp_test_dir):
        shutil.rmtree(tmp_test_dir)
    os.mkdir(tmp_test_dir)

    # create a test file and a directory (submodule/subpackage of the test file)
    test_file_name = 'test-file.py'
    test_file_content = 'test content'
    test_module_file = os.path.join(tmp_test_dir, test_file_name)
    test_submodule_name = 'submodule'

# Generated at 2022-06-25 12:51:56.645811
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')  == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')         == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins')  == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules')         == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils')    == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('plugins')         == 'plugin'

# Generated at 2022-06-25 12:52:00.030791
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():

    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_loader_0 = ansible_collection_finder_0.find_module('ansible_collections.geerlingguy.drupal')

    assert(isinstance(ansible_collection_loader_0, _AnsibleCollectionLoader))


# Generated at 2022-06-25 12:52:03.696085
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme.test')
    source_0 = ansible_collection_pkg_loader_base_0.get_source('ansible_collections.acme.test')
    # This test's implementation is incomplete and may need revision
    pass

# Test implementation of method ansible_collections.ansible.plugins.module_utils._text._text._get_collection_name of class NoneType

# Generated at 2022-06-25 12:52:09.650121
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref = AnsibleCollectionRef('namespace', 'subdir1.subdir2', 'filename', 'module')
    assert ansible_collection_ref.collection == 'namespace'
    assert ansible_collection_ref.subdirs == 'subdir1.subdir2'
    assert ansible_collection_ref.ref_type == 'module'
    assert ansible_collection_ref.resource == 'filename'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.namespace'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.namespace.plugins.subdir1.subdir2.module'

# Generated at 2022-06-25 12:52:40.834003
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext.ext') == True

    # Incorrect minimum number of parts
    assert AnsibleCollectionRef.is_valid_fqcr('coll.resource') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll') == False

    # Incorrect number of parts
    assert AnsibleCollectionRef.is_valid_f

# Generated at 2022-06-25 12:52:51.058286
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert_equal(AnsibleCollectionRef.try_parse_fqcr('acme.foobar', 'role'), None)
    assert_equal(AnsibleCollectionRef.try_parse_fqcr('acme.foobar', 'module'), None)
    assert_equal(AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'role'), None)
    assert_equal(AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module'), None)
    assert_equal(AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'role'), None)
    assert_equal(AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'module'), None)

# Generated at 2022-06-25 12:52:58.934831
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from ansible_collections.my.mytest.tests.test_ansible_galaxy_collections import collections_behavior_cases # import test data
    case_0 = collections_behavior_cases.get(0) # get test case 0
    assertion = collections_behavior_cases.get(1) # get expected assertion
    # Execute code to be tested
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.my.mytest', case_0)
    # Verify assertion values
    assert isinstance(ansible_collection_pkg_loader_base_0.__repr__(), str) == assertion[0]


# Generated at 2022-06-25 12:53:00.495068
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections')


# Generated at 2022-06-25 12:53:06.262503
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():

    if AnsibleCollectionRef.is_valid_fqcr("b.c.d"):
        print("PASS: b.c.d is a valid FQCR")
    else:
        print("FAILED: b.c.d is a valid FQCR")

    if AnsibleCollectionRef.is_valid_fqcr("b.c.d.e"):
        print("PASS: b.c.d.e is a valid FQCR")
    else:
        print("FAILED: b.c.d.e is a valid FQCR")

    if not AnsibleCollectionRef.is_valid_fqcr("b.c.d.e.d"):
        print("PASS: b.c.d.e.d is not a valid FQCR")

# Generated at 2022-06-25 12:53:10.381425
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    test_finding_module_path = ['collections', 'ansible_collections/guru/collection/plugins/modules']
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    _AnsiblePathHookFinder.find_module(ansible_collection_finder_0, 'ansible_collections.guru.collection.plugins.modules', path=test_finding_module_path)


# Generated at 2022-06-25 12:53:16.201133
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class test__AnsibleCollectionPkgLoaderBase_get_source_0(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            self._source_code_path = "/tmp/foo.py"
    obj_0 = test__AnsibleCollectionPkgLoaderBase_get_source_0("foo", path_list=["/tmp"])
    assert obj_0.get_source("foo") is None
    assert obj_0.get_source("foo") is None


# Generated at 2022-06-25 12:53:19.616648
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert _AnsibleInternalRedirectLoader('ansible.plugins.modules.cloud.vmware', '')._redirect == 'ansible.builtin.vmware_vm_facts'
    with pytest.raises(ValueError):
        _AnsibleInternalRedirectLoader('ansible.plugins.modules.network.ios', '')


# Generated at 2022-06-25 12:53:22.209151
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    assert(AnsibleCollectionRef.try_parse_fqcr(to_text('ns.coll.subdir1.subdir2.resource'), to_text('module')) == None)
    ansible_collection_finder_1 = _AnsibleCollectionFinder()


# Generated at 2022-06-25 12:53:24.931113
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    l0 = _AnsibleInternalRedirectLoader('ansible.module_utils.six.moves', [''])


# Generated at 2022-06-25 12:54:01.457381
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test for get_source for a non-existing parent directory
    # Test for get_source for a file in an existing directory
    # Test for get_source for an empty file in a parent directory
    # Test for get_source for a non-existing file
    path_list = ["/tmp/testdir"]
    test_obj = _AnsibleCollectionPkgLoaderBase("ansible.test_obj", path_list)
    test_path = "/tmp/testdir/ansible"
    assert test_obj.get_source(test_path) is None

    # Test for get_source for an existing file
    ansible_path = "/tmp"
    open(ansible_path, "a").close()
    assert test_obj.get_source(ansible_path) is not None

    # Test for get_source for an empty file


# Generated at 2022-06-25 12:54:11.066724
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0._n_cached_collection_paths = ['ansible_collections']
    ansible_collection_path_hook_0 = ansible_collection_finder_0._ansible_collection_path_hook('ansible_collections')
    try:
        ansible_collection_path_hook_0.find_module('ansible')
        assert False # should have thrown exception
    except ImportError:
        pass


# Generated at 2022-06-25 12:54:22.067158
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    os.makedirs('/tmp/ansible_collections/foobar/plugins/module_utils')
    open('/tmp/ansible_collections/foobar/plugins/module_utils/foobar.py', 'w').close()
    os.makedirs('/tmp/ansible_collections/foobar/plugins/lookups')
    open('/tmp/ansible_collections/foobar/plugins/lookups/foo.py', 'w').close()
    os.makedirs('/tmp/ansible_collections/foobar/plugins/filter')
    open('/tmp/ansible_collections/foobar/plugins/filter/bar.py', 'w').close()


# Generated at 2022-06-25 12:54:27.151421
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Case 1:
    result = AnsibleCollectionRef.from_fqcr('my.collection.mymodule.module', 'module')
    assert result.collection == u'my.collection'
    assert result.subdirs == u''
    assert result.resource == u'mymodule.module'
    assert result.ref_type == u'module'

    # Case 2:
    result = AnsibleCollectionRef.from_fqcr('my.collection.something.mymodule.module', 'module')
    assert result.collection == u'my.collection'
    assert result.subdirs == u'something'
    assert result.resource == u'mymodule.module'
    assert result.ref_type == u'module'

    # Case 3:

# Generated at 2022-06-25 12:54:32.672181
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.ns.module_name",
                                                                         path_list=["/path1","/path2"])
    assert ansible_collection_pkg_loader_base.__repr__() == "_AnsibleCollectionPkgLoaderBase(path=None)"

# Generated at 2022-06-25 12:54:43.749161
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for:
    #   _AnsibleCollectionPkgLoaderBase.get_filename(self, fullname)
    #
    # This test case will create and initialise the following class
    #   _AnsibleCollectionPkgLoaderBase

    # Use the following arguments to initialise the class:
    #   fullname = 'ansible_collections.ns_name.collection_name'
    #   _parent_package_name = 'ansible_collections'
    #   _package_to_load = 'ns.collection_name'

    # Get the filename (eg: the __file__ property)
    #   Use _AnsibleCollectionPkgLoaderBase.get_filename(self, fullname)
    #   to get the value for filename.
    #   Return filename

    loader1 = _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:54:47.750935
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    fullname = "ansible_collections.ns.test"
    path_list = ['/tmp/ansible_collections/ns/test']
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)

# Generated at 2022-06-25 12:54:51.189301
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns_name.some_ns.some_coll.some_ns')
    ansible_collection_pkg_loader_base_0.__repr__()


# Generated at 2022-06-25 12:55:02.808485
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_path_hook_finder_0 = _AnsiblePathHookFinder('/home/jovyan/.ansible/collections')

    # Test if fullname is equal to self._fullname
    ansible_collection_path_hook_finder_1 = _AnsiblePathHookFinder('/home/jovyan/.ansible/collections')

    # Test if self._redirect_module is not None
    ansible_collection_path_hook_finder_2 = _AnsiblePathHookFinder('/home/jovyan/.ansible/collections')

    # Test if fullname is equal to self._fullname and __package__ is equal to self._parent_package_name

# Generated at 2022-06-25 12:55:06.420033
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(None, '', '')
    ansible_collection_pkg_loader_0.load_module('')


if __name__ == '__main__':
    print("<<< Start unit test >>>")
    test_case_0()
    test__AnsibleCollectionPkgLoader_load_module()
    print("<<< Finish unit test >>>")

# Generated at 2022-06-25 12:55:37.036888
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import builtins, sys
    loader = _AnsibleInternalRedirectLoader("ansible.module_utils.cloud.ovirt", "")

    # test 1
    loader.load_module("ansible.module_utils.cloud.ovirt")



# Generated at 2022-06-25 12:55:40.463855
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref_type = 'module'
    # Positive case
    fqcr = 'ns.coll.resource'
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)


# Generated at 2022-06-25 12:55:48.789414
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    valid_collection_names = [
        'ns.coll',
        'ns.coll-1',
        'ns.coll_1',
        'ns.coll-1_2-3',
    ]
    invalid_collection_names = [
        'ns.coll1.coll2',
        'ns.collns.',
        'ns..coll',
        'ns.coll1.coll2',
        'ns.coll_',
        'ns.coll-',
        'ns.coll.',
        'ns..coll',
        'ns....coll',
        'ns.coll..subdir1',
        'ns.coll.subdir1.subdir2.subdir3',
    ]

    for name in valid_collection_names:
        assert AnsibleCollectionRef.is_valid_collection_name(name) is True



# Generated at 2022-06-25 12:55:58.700426
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    _ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.mypkg')
    the_source = _ansible_collection_pkg_loader_base.get_source() # <== This is the method to test
    assert the_source is None

    # mock data
    _ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.mypkg')
    _ansible_collection_pkg_loader_base._decoded_source = 'Hello world'
    the_source = _ansible_collection_pkg_loader_base.get_source()
    assert the_source == 'Hello world'

    # mock data
    _ansible_collection_pkg_loader_base = _AnsibleCollectionPkg

# Generated at 2022-06-25 12:56:03.267507
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    pass
    # TODO: Can this be tested?
    # ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('', '')
    # try:
    #     ansible_internal_redirect_loader_0.load_module('')
    # except Exception as e:
    #     pass

# Generated at 2022-06-25 12:56:12.544884
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _TestCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        _allows_package_code = True

        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

    package_dir = os.path.dirname(os.path.dirname(__file__))
    path_list = [package_dir]

    # Normal case: a file exists and is returned
    loader_0 = _TestCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection', path_list)
    found_data = loader_0.get_data('vars/main.yml')
   

# Generated at 2022-06-25 12:56:23.957790
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource1'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource1'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource2'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource1.subdir2'))
    assert(not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource1.subdir3'))

# Generated at 2022-06-25 12:56:31.498962
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:56:33.904847
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase('foo')
    assert loader.get_source('foo') == None


# Generated at 2022-06-25 12:56:44.572529
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns0.collection0.resource0', 'module') == AnsibleCollectionRef('ns0.collection0', '', 'resource0', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns1.coll1.subdir1.resource1', 'module') == AnsibleCollectionRef('ns1.coll1', 'subdir1', 'resource1', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns2.coll2.subdir2.resource2', 'role') == AnsibleCollectionRef('ns2.coll2', 'subdir2', 'resource2', 'role')

# Generated at 2022-06-25 12:57:37.980963
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    pass


# Generated at 2022-06-25 12:57:45.760860
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # test1: test the collection_name parameter

    # define an invalid collection_name
    wrong_collection_name = 'ansible.plugins'
    try:
        ref = AnsibleCollectionRef(wrong_collection_name, None, 'copy', 'module')
        assert False
    except ValueError as e:
        # make sure the error message is correct
        assert str(e) == 'invalid collection name (must be of the form namespace.collection): ' + wrong_collection_name

    # define a valid collection_name
    collection_name = 'ansible.mycollection'

    # define a valid subdirs
    subdirs = 'test.path'

    # define a valid resource
    resource = 'myresource'

    # define a valid ref_type
    ref_type = 'module'


# Generated at 2022-06-25 12:57:54.041694
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_case_0_collection_loader = _AnsibleCollectionPkgLoaderBase.from_module_info(ansible_module_0_info)
    assert test_case_0_collection_loader.get_data('/usr/share/ansible/collections/ansible/test_case_0/plugins/module_utils/test_case_0/__init__.py') == b''

if __name__ == "__main__":
    test_case_0()
    test__AnsibleCollectionPkgLoaderBase_get_data()

# Generated at 2022-06-25 12:58:03.017294
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-25 12:58:05.461681
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six', '')
    path_list = ['test_0']
    assert path_list == ''
    assert loader.__init__('ansible.module_utils.six', path_list) == (None)


# Generated at 2022-06-25 12:58:11.362495
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Instance of class AnsibleCollectionRef
    ansible_collection_ref_0 = AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', 'module')
    assert ansible_collection_ref_0.collection == "namespace.collection"
    assert ansible_collection_ref_0._fqcr == "namespace.collection.resource"
    assert ansible_collection_ref_0.n_python_collection_package_name == "ansible_collections.namespace.collection"
    assert ansible_collection_ref_0.n_python_package_name == "ansible_collections.namespace.collection.plugins.module"
    assert ansible_collection_ref_0.ref_type == "module"
    assert ansible_collection_ref_0.resource == "resource"
    assert ansible

# Generated at 2022-06-25 12:58:22.085043
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library") == "modules"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("module_utiles") == "module_utils"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("module_utils") == "module_utils"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("modules") == "modules"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("doc_fragments") == "doc_fragments"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_

# Generated at 2022-06-25 12:58:27.844140
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test invalid fqcr
    with pytest.raises(ValueError) as e:
        AnsibleCollectionRef.from_fqcr('noname.collection.incorrect.resource', 'module')

    assert to_native(str(e.value)) == 'noname.collection.incorrect.resource is not a valid collection reference'

    # test valid fqcr
    collref = AnsibleCollectionRef.from_fqcr('names.collections.resource', 'module')
    assert collref.collection == 'names.collections'
    assert collref.resource == 'resource'
    assert collref.ref_type == 'module'
    assert collref.subdirs == ''

    # test valid fqcr with subdirs

# Generated at 2022-06-25 12:58:40.744500
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    finder = _AnsibleCollectionFinder()
    path = ansible_galaxy_meta_path_finder(finder)

    path_list = ['/path/to/ansible2.6/lib/ansible_collections/foo/bar/__init__.py']
    for p in path_list:
        path.find_module("ansible_collections.foo.bar")
    loader_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo.bar", path_list)
    loader_0.get_filename("ansible_collections.foo.bar")

    path_list = ['/path/to/ansible2.6/lib/ansible_collections/foo/bar']

# Generated at 2022-06-25 12:58:48.798463
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    def get_collection_meta_of_module(module):
        if not module._collection_meta:
            return {}
        else:
            return module._collection_meta

    # Patch _meta_yml_to_dict
    meta_yml_dict = {'plugin_routing':{'module_utils':{'utils':{'redirect':'collection.tests.utils'}}}}
    patch_meta_yml_dict = patch("ansible.utils.collection_loader._meta_yml_to_dict", return_value=meta_yml_dict)
    patch_meta_yml_dict.start()

    # These two collection paths are from test fixture. They refer to the two fake collections built below.
    AnsibleCollectionConfig.default_collection_path = ['./test/unit/ansible_test_collection_0']

# Generated at 2022-06-25 12:59:46.776016
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # test case 1
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.rolename", "role") == True
    # test case 2
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.someaction", "role") == False
    # test case 3
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.action_plugins.someaction", "role") == False
    # test case 4
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.role.rolename", "role") == False
    # test case 5
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.subdir1.subdir2.rolename", "role") == True
    # test case 6
    assert Ansible

# Generated at 2022-06-25 12:59:50.106391
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    """
    _AnsibleInternalRedirectLoader's load_module method unit test
    """

    # create an instance of the class to be tested
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader('ansible.builtin.log', None)



# Generated at 2022-06-25 12:59:56.707592
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    expected_AnsibleCollectionRef_1 = AnsibleCollectionRef('n.c', None, 'resource', 'module')
    actual_AnsibleCollectionRef_1 = AnsibleCollectionRef.from_fqcr('n.c.resource', 'module')
    assert expected_AnsibleCollectionRef_1 == actual_AnsibleCollectionRef_1

    expected_AnsibleCollectionRef_2 = AnsibleCollectionRef('n.c', 'subdir1.subdir2', 'resource', 'module')
    actual_AnsibleCollectionRef_2 = AnsibleCollectionRef.from_fqcr('n.c.subdir1.subdir2.resource', 'module')
    assert expected_AnsibleCollectionRef_2 == actual_AnsibleCollectionRef_2


# Generated at 2022-06-25 12:59:58.255452
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    _AnsibleCollectionPkgLoaderBase._repr_test()


# Generated at 2022-06-25 13:00:09.164714
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections')

    # test case: no path
    try:
        ansible_collection_pkg_loader_base_0.get_data(None)
        assert False
    except ValueError:
        assert True

    # test case: relative path
    try:
        ansible_collection_pkg_loader_base_0.get_data('relative_path')
        assert False
    except ValueError:
        assert True

    # test case: file does not exists
    assert ansible_collection_pkg_loader_base_0.get_data('/does/not/exists') is None