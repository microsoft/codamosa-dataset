

# Generated at 2022-06-25 12:51:52.206978
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import tempfile
    import os
    import errno

    # Create a dummy ansible namespace folder
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, "ansible"))

    # Create a collection namespace folder
    os.mkdir(os.path.join(tmpdir, "ansible_collections"))
    testcol_path = os.path.join(tmpdir, "ansible_collections", "test_col")

    # Create a collection module folder
    os.mkdir(testcol_path)
    module_path = os.path.join(testcol_path, "module")
    os.mkdir(module_path)

    # Create a test file
    test_file_path = os.path.join(module_path, "testfile.py")

# Generated at 2022-06-25 12:52:02.340826
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', path_list=['/path/to/ansible.builtin.foo'])
    assert loader._redirect == 'ansible.foo', 'Failed to redirect to correct path'
    loader2 = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar', path_list=['/path/to/ansible.builtin.foo'])
    assert loader2._redirect == 'ansible.foo.bar', 'Failed to redirect to correct path'
    loader3 = _AnsibleInternalRedirectLoader('ansible.builtin.foo.bar.baz', path_list=['/path/to/ansible.builtin.foo'])

# Generated at 2022-06-25 12:52:08.507538
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:52:17.063852
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:52:26.385133
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # Invalid collection names and resource
    collection_name = "invalid.collection_name"
    subdirs = "subdir1"
    resource = "invalid.resource"
    ref_type = "module"
    try:
        AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    except ValueError as e:
        assert "invalid collection name" in to_native(e)
        pass
    except Exception as e:
        assert False, "Unexpected exception {}".format(to_native(e))

    collection_name = "ansible.test_collection"
    subdirs = "subdir1"
    resource = "invalid.resource"
    ref_type = "module"

# Generated at 2022-06-25 12:52:30.153026
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.my_namespace.my_collection',
                                             path_list=['/path/to/collections', '/path/to/collections2'])
    loader._source_code_path = '/path/to/collections/my_namespace/my_collection/__init__.py'
    loader.get_code('ansible_collections.my_namespace.my_collection')
    assert True


# Generated at 2022-06-25 12:52:34.627304
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Should return true for a valid collection fqcr
    assert(AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource") == True)

    # Should return true for a valid collection fqcr with multiple subdirs
    assert(AnsibleCollectionRef.is_valid_fqcr("ns.coll.subdir1.subdir2.resource") == True)

    # Should return false for a collection fqcr with multiple subdirs but no resource
    assert(AnsibleCollectionRef.is_valid_fqcr("ns.coll.subdir1.subdir2") == False)


# Generated at 2022-06-25 12:52:37.254091
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    try:
        ansible_collection_ref = AnsibleCollectionRef('Ansible.test', '', 'test', 'module')
    except Exception as e:
        pytest.fail(e)


# unit test for function is_valid_collection_name

# Generated at 2022-06-25 12:52:47.574355
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # TODO: re-structure this test case, this is horrible
    # Initialize test case
    ansible_collection_finder = _AnsibleCollectionFinder()
    # set $PYTHONPATH and $ANSIBLE_COLLECTIONS_PATHS to workspace dir
    env_var_pythonpath = os.getcwd()
    env_var_ansible_collections_paths = os.getcwd()

    # Set path using the environment variables
    # TODO: the environment variables are important, are they really necessary or should they be commented out?
    os.environ['PYTHONPATH'] = env_var_pythonpath
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = env_var_ansible_collections_paths

    # Set scanner_sys_paths to False for the find

# Generated at 2022-06-25 12:52:57.347010
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Check that module is_package returns False when object name is "ansible_collections.some_namespace"
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.some_namespace")
    assert ansible_collection_loader_0.is_package("ansible_collections.some_namespace") == False
    # Check that module is_package returns True when object name is "ansible_collections.some_namespace.some_collection"
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.some_namespace.some_collection")
    assert ansible_collection_loader_0.is_package("ansible_collections.some_namespace.some_collection") == True
    # Check that module

# Generated at 2022-06-25 12:53:37.139767
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import os
    import random
    import tempfile
    from ansible.module_utils._text import to_bytes

    # generate a random collection name
    collection_name = 'awkward_namespace'
    collection_pkg_name = ''.join([random.choice('abcdefghijklmnopqrstuvwxyz') for __ in range(random.randint(6, 14))])
    collection_name = '{0}.{1}'.format(collection_name, collection_pkg_name)

    # setup a temporary collection directory
    tmpdir = tempfile.mkdtemp()
    collection_path = os.path.join(tmpdir, 'ansible_collections', collection_name)
    os.makedirs(to_bytes(collection_path))

# Generated at 2022-06-25 12:53:45.081027
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:53:55.580981
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_loader_base = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.test", path_list="/mnt/c/Users/et6389/Desktop/ansible-collections/test")
    assert ansible_collection_loader_base._AnsibleCollectionPkgLoaderBase__module_file_from_path(leaf_name="__init__.py", path="/mnt/c/Users/et6389/Desktop/ansible-collections/test") == ("/mnt/c/Users/et6389/Desktop/ansible-collections/test/__init__.py", True, None)
    ansible_collection_loader_base.get_data(path="/mnt/c/Users/et6389/Desktop/ansible-collections/test/__init__.py")

#

# Generated at 2022-06-25 12:53:59.356332
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef('test.test', subdirs='test', resource='test', ref_type='test')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='test.test', subdirs='test', resource='test')"

# Generated at 2022-06-25 12:54:06.369802
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _AnsibleCollectionPkgLoaderBaseTest( _AnsibleCollectionPkgLoaderBase ):
        def _validate_final( self ):
            super( _AnsibleCollectionPkgLoaderBaseTest, self )._validate_final()
            self._subpackage_search_paths = [
                '/ansible_collections/foo/bar/'
            ]
    a = _AnsibleCollectionPkgLoaderBaseTest( 'ansible_collections.foo.bar' )
    assert a.get_data( '/ansible_collections/foo/bar/a.txt' ) == b'foo'
    assert a.get_data( '/ansible_collections/foo/bar/b.txt' ) == b'bar'
    assert a.get_data( '/ansible_collections/foo/bar/c.txt' )

# Generated at 2022-06-25 12:54:07.749860
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with pytest.raises(ImportError):
        loader = _AnsibleInternalRedirectLoader(fullname='ansible.cli', path_list=[])



# Generated at 2022-06-25 12:54:12.760944
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref_0 = AnsibleCollectionRef('namespace1.collection2', 'subdirs3', 'resource4', 'ref_type5')
    assert repr(ansible_collection_ref_0) == "'AnsibleCollectionRef(collection='namespace1.collection2', subdirs='subdirs3', resource='resource4')'"


# Generated at 2022-06-25 12:54:18.776144
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # setup test case
    ref = "ansible.test.test_module"
    ref_type = "module"
    # expected results
    expected = AnsibleCollectionRef("ansible.test",None, "test_module", "module")
    # observed results
    actual = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    # assert
    assert expected == actual


# Generated at 2022-06-25 12:54:27.876363
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import pkg_resources
    import collections

    global sys
    global _ns_package_loader_cls
    global _AnsibleCollectionPkgLoaderBase

    sys = collections.defaultdict(set)
    sys.path = sys.path
    # set global variables for _AnsibleCollectionPkgLoaderBase class
    _AnsibleCollectionPkgLoaderBase._subpackage_search_paths = ('subpackage_path',)
    _AnsibleCollectionPkgLoaderBase._source_code_path = ('source_code_path',)
    _AnsibleCollectionPkgLoaderBase._compiled_code = ('compiled_code',)
    _AnsibleCollectionPkgLoaderBase._validate_args = ('validate_args',)

# Generated at 2022-06-25 12:54:33.800408
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    """
    The test consists of two parts:
    1. Testing load_module in case when 'ansible.builtin' collection is missing.
    2. Testing load_module in case when 'ansible.builtin' collection is present in 'meta/runtime.yml'
    """
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.collection_roots = [os.path.dirname(os.path.dirname(__file__)) + '/../../../']
    module_name = 'ansible.builtin'
    module = ansible_collection_finder_0.load_module(module_name)
    # Testing load_module in case when 'ansible.builtin' collection is missing.

# Generated at 2022-06-25 12:55:11.440744
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:55:21.832257
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.foo.bar.baz', [])
    assert loader._redirect is None
    with pytest.raises(ImportError):
        loader.load_module('ansible.foo.bar.baz')
    loader._redirect = 'ansible.plugins.action.baz'
    with pytest.raises(ValueError):
        loader.load_module('ansible.foo.bar.baz')

# this method creates a mocked AnsibleCollectionConfig class (the real class has a singleton, so
# we can't use it directly)

# Generated at 2022-06-25 12:55:25.446464
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo.bar")
    repr_rep = repr(ansible_collection_pkg_loader_base_0)
    assert repr_rep == '_AnsibleCollectionPkgLoaderBase(path=None)', 'representation of _AnsibleCollectionPkgLoaderBase is invalid'


# Generated at 2022-06-25 12:55:28.090070
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # method is tested via test_case_1()
    pass

# TODO: unit tests for load_module, get_source, get_filename

# Generated at 2022-06-25 12:55:35.834750
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    assert ansible_collection_finder_1.find_module("ansible") == None
    assert ansible_collection_finder_1.find_module("ansible_collections") == None
    assert ansible_collection_finder_1.find_module("ansible_collections.ansible") == None
    assert ansible_collection_finder_1.find_module("ansible_collections.ansible.modules") == None


# Generated at 2022-06-25 12:55:45.393303
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:55:53.869649
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Collection Ref that is valid
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.builtin.ping", "module")
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.builtin.ping", "playbook")
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.builtin.ping", "role")
    # Collection ref that is invalid
    assert not AnsibleCollectionRef.is_valid_fqcr("ansible.builtin.ping", "library")
    assert not AnsibleCollectionRef.is_valid_fqcr("ansible.builtin.ping", "documentation")


# Generated at 2022-06-25 12:55:56.394489
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    #NOTE: this test is a work in progress
    test_case=0
    if test_case==0:
        test__AnsibleCollectionPkgLoaderBase_get_data_case_0()


# Generated at 2022-06-25 12:56:04.988741
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():

    # setup path variables
    import sys
    import os
    path = "/tmp/ansible/ansible_collections/foo/bar/__init__.py"
    path_list = ["/tmp/ansible/ansible_collections/foo/bar"]

    # instantiate class variables
    _AnsibleCollectionPkgLoaderBase._source_code_path = path
    _AnsibleCollectionPkgLoaderBase._subpackage_search_paths = path_list

    # call method get_filename and store it in variable filename
    filename = _AnsibleCollectionPkgLoaderBase.get_filename(_AnsibleCollectionPkgLoaderBase, 'foo.bar')

    # check if filename is as expected
    assert path == filename


# Generated at 2022-06-25 12:56:14.631065
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    # test for the following line:  mod = import_module(self._redirect)
    # mock import_module function and store the value of the first parameter
    with mock.patch('ansible.utils.collection_loader.import_module', return_value=None) as import_module_mock:
        _AnsibleInternalRedirectLoader('bla', None).load_module('bla')
        assert(import_module_mock.call_args_list[0][0][0] == 'bla')
    import_module = utils.import_module
    # test for the following line:  sys.modules[fullname] = mod
    # mock sys.modules and check that fullname is set to mod
    with mock.patch.object(sys, 'modules') as modules_mock:
        _AnsibleInternal

# Generated at 2022-06-25 12:57:32.791770
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, '/home/yous/ansible_collections')
    assert ansible_path_hook_finder_0._pathctx == '/home/yous/ansible_collections'
    assert ansible_path_hook_finder_0._file_finder is None


# this is just to echo the path onto the module itself

# Generated at 2022-06-25 12:57:41.650689
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    def _get_data_fn():
        ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(
            fullname='ansible_collections.fullname',
            path_list=['/some_path']
        )
        ansible_collection_pkg_loader_base.get_data('/some_path/foo')

    # SUT
    from tempfile import mkdtemp
    import os
    try:
        tmpdir = mkdtemp()
        open(tmpdir + '/foo', 'w').close()
        _get_data_fn()
    finally:
        os.remove(tmpdir + '/foo')
        os.rmdir(tmpdir)


# Generated at 2022-06-25 12:57:49.379131
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    def mock_load_module(self, fullname):
        return _AnsibleCollectionPkgLoader.load_module(self, fullname)

    class MockAnsibleCollectionPkgLoader:
        _meta_yml_to_dict = {}
        pass

    _AnsibleCollectionPkgLoader.load_module = mock_load_module

    mock_ansible_collection_pkg_loader_0 = MockAnsibleCollectionPkgLoader()

    assert mock_ansible_collection_pkg_loader_0._meta_yml_to_dict == {}



# Generated at 2022-06-25 12:57:54.964507
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # __repr__ is used to display objects in the python prompt.
    message = "_AnsibleCollectionPkgLoaderBase(path=None)"
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(fullname="__mypackagename")
    assert message == ansible_collection_pkg_loader_base_0.__repr__()

# Generated at 2022-06-25 12:58:03.661091
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """
    Test the method AnsibleCollectionRef.from_fqcr.
    """
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr('ns.col.res', 'role')
    assert ansible_collection_ref.collection == 'ns.col'
    assert ansible_collection_ref.subdirs == ''
    assert ansible_collection_ref.resource == 'res'
    assert ansible_collection_ref.ref_type == 'role'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.ns.col'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.ns.col.roles.res'

# Generated at 2022-06-25 12:58:07.123761
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, 'plat-linux')
    ansible_path_hook_finder_0.find_module('ansible')
    ansible_path_hook_finder_0.find_module('ansible.builtin')
    ansible_path_hook_finder_0.find_module('ansible_collections.ansible.builtin')
    ansible_path_hook_finder_0.find_module('ansible.utils')


# Generated at 2022-06-25 12:58:12.861249
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    #test for a good fqcr, ref_type as 'module'
    fqcr = 'ns.coll.subdir1.subdir2.resource'
    ref_type = 'module'
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert ansible_collection_ref.from_fqcr(fqcr, ref_type) is not None,\
        "ref_type 'module' - failed to parse a valid fqcr 'ns.coll.subdir1.subdir2.resource'"

    #test for a good fqcr, ref_type as 'modules'
    ref_type = 'modules'
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert ansible_collection

# Generated at 2022-06-25 12:58:22.779106
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Valid ref for action plugin
    action_ref = AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.subdir1.subdir2.resource', u'action')
    assert action_ref.collection == u'namespace.collection'
    assert action_ref.ref_type == u'action'
    assert action_ref.n_python_collection_package_name == u'ansible_collections.namespace.collection'
    assert action_ref.n_python_package_name == u'ansible_collections.namespace.collection.plugins.subdir1.action.subdir2'
    assert action_ref.resource == u'resource'
    assert action_ref.subdirs == u'subdir1.subdir2'

# Generated at 2022-06-25 12:58:26.835443
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.utils.collection_loader
    ansible_collection_loader = ansible.utils.collection_loader._AnsibleInternalRedirectLoader("ansible.plugins.action.copy", "ansible.plugins.action")
    ansible_collection_loader.load_module("ansible.plugins.action.copy")

# End unit testing


# Generated at 2022-06-25 12:58:38.960331
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(None, None)
    assert ansible_path_hook_finder_0.find_module('ansible') is not None
    assert ansible_path_hook_finder_0.find_module('ansible.module_utils') is not None
    assert ansible_path_hook_finder_0.find_module('ansible_collections.foo.a_collection') is not None
    assert ansible_path_hook_finder_0.find_module('ansible_collections.foo.a_collection.plugins') is not None
    assert ansible_path_hook_finder_0.find_module('ansible_collections.foo.a_collection.plugins.module_utils') is not None
    # Test for modules whose paths are not in sys.path

# Generated at 2022-06-25 12:59:05.834652
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Setup
    _meta_yml_to_dict = mock.MagicMock()
    fullname = 'ansible.builtin'
    module = mock.MagicMock()
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoader(fullname)
    ansible_collection_pkg_loader._meta_yml_to_dict = _meta_yml_to_dict
    ansible_collection_pkg_loader.load_module = mock.MagicMock()
    ansible_collection_pkg_loader.load_module.return_value = module
    ansible_collection_pkg_loader._collection_meta = 'meta'

    # Test
    result = ansible_collection_pkg_loader.load_module(fullname)

    # Verify
    ansible_collection_pkg_loader.load_module.assert_

# Generated at 2022-06-25 12:59:09.014059
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # test of method __repr__ of class _AnsibleCollectionFinder with normal parameters
    result = ansible_collection_finder_0.__repr__()
    assert isinstance(result, str)
    print("test of method _AnsibleCollectionPkgLoaderBase of class _AnsibleCollectionPkgLoaderBase with normal parameters passed")
# test_case_0()
test__AnsibleCollectionPkgLoaderBase___repr__()

# Generated at 2022-06-25 12:59:13.757527
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Case: Valid fqcr for role type.
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource", "role")
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.subdir1.subdir2.resource", "role")
    assert not AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource", "strategy")

    # Case: Valid fqcr for playbook type.
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource.yml", "playbook")
    assert not AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource.yaml", "playbook")
    assert not AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource", "playbook")

# Generated at 2022-06-25 12:59:17.725338
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader('ansible.builtin.debug', None)
    ansible_internal_redirect_loader.load_module('ansible.builtin.debug')


# Generated at 2022-06-25 12:59:24.204112
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef('test.foo', 'subdir1.subdir2', 'test_mod', 'module')
    assert AnsibleCollectionRef(u'test.foo', u'subdir1.subdir2', u'test_mod', u'module')
    assert AnsibleCollectionRef('test.foo', None, 'test_mod', 'module')
    assert AnsibleCollectionRef(u'test.foo', None, u'test_mod', u'module')
    assert AnsibleCollectionRef(u'test.foo', u'', u'test_mod', u'module')
    assert AnsibleCollectionRef('test.foo', u'subdir1.subdir2', 'test_mod', 'module')

# Generated at 2022-06-25 12:59:34.318200
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_loader_base_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.jctanner.test")
    ansible_collection_loader_base_0._subpackage_search_paths = ["/tmp/t1/ansible_collections/jctanner/test/doc_fragments", "/tmp/t1/ansible_collections/jctanner/test/doc_fragments/sub_pkg1", "/tmp/t1/ansible_collections/jctanner/test/doc_fragments/sub_pkg2", "/tmp/t1/ansible_collections/jctanner/test/modules", "/tmp/t1/ansible_collections/jctanner/test/modules/sub_pkg3"]
    assert ansible_collection_loader_

# Generated at 2022-06-25 12:59:40.724012
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    try:
        ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr("ns.mycollection.myresource", "module")
        print(ansible_collection_ref_0.collection)
        print(ansible_collection_ref_0.subdirs)
        print(ansible_collection_ref_0.resource)
        print(ansible_collection_ref_0.ref_type)
        print(ansible_collection_ref_0._fqcr)
    except Exception:
        pass


# Generated at 2022-06-25 12:59:50.425521
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # test a collection that has a runtime.yml
    path_to_collection = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib', 'ansible', 'collections', 'ansible_collections', 'community', 'system', 'action'))
    module_name = 'ansible_collections.community.system.action'
    import ansible_collections.community.system.action
    module = getattr(ansible_collections, 'community').system.action
    assert module._collection_meta['plugin_routing']['action']['debug']['redirect'] == 'debug'
    assert module._collection_meta['plugin_routing']['action']['debug']['redirect_params'] == {}

# Generated at 2022-06-25 12:59:59.758508
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Just initialize because 'load_module' needs to use sys.modules
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # Initialize _AnsibleCollectionPkgLoaderBase object to call load_module method with
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(
        'ansible_collections.namespace.collection.module_name')

    # Use new_or_existing_module of class _AnsibleCollectionPkgLoaderBase to create a new module

# Generated at 2022-06-25 13:00:03.977475
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # invalid fqcr
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns..coll.resource')
    # valid fqcr
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource')
