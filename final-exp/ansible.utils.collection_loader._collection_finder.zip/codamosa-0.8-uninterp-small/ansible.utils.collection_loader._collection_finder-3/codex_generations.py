

# Generated at 2022-06-25 12:51:13.880828
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    test = _AnsibleInternalRedirectLoader('test', 'path')
    assert test.load_module('test')


# Generated at 2022-06-25 12:51:15.570448
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    assert False


# Generated at 2022-06-25 12:51:24.920788
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    collection = AnsibleCollectionRef('ansible.test', None, 'mymodule', 'module')
    assert collection.collection == 'ansible.test'
    assert collection.subdirs == ''
    assert collection.resource == 'mymodule'
    assert collection.ref_type == 'module'
    assert collection.n_python_collection_package_name == 'ansible_collections.ansible.test'
    assert collection.n_python_package_name == 'ansible_collections.ansible.test.plugins.module.mymodule'
    assert str(collection) == 'ansible.test.mymodule'

    collection = AnsibleCollectionRef('ansible.test', 'subdir1', 'mymodule', 'module')
    assert collection.collection == 'ansible.test'
    assert collection.subdirs == 'subdir1'
   

# Generated at 2022-06-25 12:51:26.698369
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    test_case_0()

# Generated at 2022-06-25 12:51:32.237849
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    find_module_0 = ansible_collection_finder_0.find_module('ansible.module_utils.network.junos.junos')
    print(find_module_0.load_module('ansible.module_utils.network.junos.junos'))


# Generated at 2022-06-25 12:51:36.960989
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    acr = AnsibleCollectionRef()
    dir_name = "action_plugins"
    plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(dir_name)
    assert plugin_type == 'action'

    dir_name = "library"
    plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(dir_name)
    assert plugin_type == 'modules'

    dir_name = "shell_plugins"
    plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(dir_name)
    assert plugin_type == 'shell'

    dir_name = "terminal_plugins"
    plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(dir_name)
    assert plugin_

# Generated at 2022-06-25 12:51:40.049851
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    ansible_collection_nspkg_loader = _AnsibleCollectionNSPkgLoader('foo')
    assert isinstance(ansible_collection_nspkg_loader, _AnsibleCollectionNSPkgLoader)



# Generated at 2022-06-25 12:51:50.291476
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    my_coll_finder = _AnsibleCollectionFinder()
    my_package_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.mynamespace', path_list=['/path/to/package'])
    my_package_loader._subpackage_search_paths = ['/path/to/package']
    my_package_loader._package_to_load = '__init__.py'
    assert(my_package_loader.get_data('/path/to/package/__init__.py') == '')

if __name__ == '__main__':
    test__AnsibleCollectionPkgLoaderBase_get_data()
    test_case_0()

# Generated at 2022-06-25 12:51:57.475769
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # invalid collection name
    assert AnsibleCollectionRef.try_parse_fqcr('abc.def.xyz', 'role') == None
    # missing resource
    assert AnsibleCollectionRef.try_parse_fqcr('collection.roles', 'role') == None
    # missing namespace
    assert AnsibleCollectionRef.try_parse_fqcr('foo.xyz', 'role') == None
    # invalid subdirs
    assert AnsibleCollectionRef.try_parse_fqcr('collection.foo.bar', 'role') == None
    # valid name (collection.name.role)
    assert AnsibleCollectionRef.try_parse_fqcr('collection.name.role', 'role') != None
    # valid name (collection.name.foo.bar.role)
    assert AnsibleCollectionRef.try_parse_fqcr

# Generated at 2022-06-25 12:52:00.446294
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # _AnsiblePathHookFinder.find_module is a function
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # The function should raise an ImportError if collection_name is empty
    with pytest.raises(ImportError):
        ansible_collection_finder_0.find_module()



# Generated at 2022-06-25 12:53:02.031842
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    mock_fullname = "ansible_collections.acme.foo"
    mock_path = [
        "/Library/Frameworks/Python.framework/Versions/3.7/lib/python3.7/site-packages/ansible_collections",
        "/Users/somesu/Documents/workspace/Python-Plus/python_advanced_features/python_advanced_features/ansible_collections"
    ]
    mock_subpackage_search_paths = [
        "/Library/Frameworks/Python.framework/Versions/3.7/lib/python3.7/site-packages/ansible_collections/acme/foo",
        "/Users/somesu/Documents/workspace/Python-Plus/python_advanced_features/python_advanced_features/ansible_collections/acme/foo"
    ]


# Generated at 2022-06-25 12:53:10.653651
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Creating and initializing the instance of _AnsibleCollectionPkgLoaderBase
    mock_obj = Mock()
    mock_obj.side_effect = ansible.module_utils.basic._AnsibleCollectionPkgLoaderBase(
        'ansible_collections.test_collection',
        ['/test/path']
    )

    # Testing the positive scenario
    mock_obj.get_data.return_value = 'Test'
    assert mock_obj.get_data('/test/path/test.py') == 'Test'

    # Testing the negative scenario
    mock_obj.get_data.return_value = None
    assert mock_obj.get_data('/test/path/test.py') is None



# Generated at 2022-06-25 12:53:13.555082
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    _AnsibleCollectionFinder().find_module(fullname='ansible')
    _AnsibleCollectionFinder().find_module(fullname='ansible_collections')


# Generated at 2022-06-25 12:53:16.796275
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader('ansible.collections.foo.bar.baz', 'path')
    try:
        ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader('ansiblesss.collections.foo.bar.baz', 'path')
    except ImportError as e:
        pass


# Generated at 2022-06-25 12:53:19.245982
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('ansible.test', path_list=['/test'])
    assert(loader.is_package('ansible.test') == False)


# Generated at 2022-06-25 12:53:23.476073
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():

    # testing valid fqcr
    assert AnsibleCollectionRef.is_valid_fqcr('ansible.module.test', 'module') == True

    # testing invalid fqcr
    assert AnsibleCollectionRef.is_valid_fqcr('ansible', 'module') == False

    # testing valid fqcr without ref type
    assert AnsibleCollectionRef.is_valid_fqcr('ansible.module.test') == True

    # testing invalid fqcr without ref type
    assert AnsibleCollectionRef.is_valid_fqcr('ansible') == False

    # negative testing
    assert AnsibleCollectionRef.is_valid_fqcr('') == False



# Generated at 2022-06-25 12:53:34.349961
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkgloder_base_0 = _AnsibleCollectionPkgLoaderBase(None, None)
    with pytest.raises(ValueError) as excinfo:
        ansible_collection_pkgloder_base_0.get_source('ansible_collections.ana.package')
    assert 'this loader cannot load source for ansible_collections.ana.package, only ansible_collections.ana.package' == str(excinfo.value)
    ansible_collection_pkgloder_base_0._fullname = 'ansible_collections.ana.package'
    ansible_collection_pkgloder_base_0._source_code_path = '/home/sunny/ansible/ana/package/__init__.py'

    # test case 1
    ansible_collection_p

# Generated at 2022-06-25 12:53:41.006285
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    """
    This unit test is just to ensure that the definition of AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type() is correct.
    """
    ansible_collection_ref_0 = AnsibleCollectionRef('collection_name', 'subdirs', 'resource', 'ref_type')
    legacy_plugin_dir_name = 'action_plugins'
    plugin_type = ansible_collection_ref_0.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)


# Generated at 2022-06-25 12:53:44.230160
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_obj = ansible.utils.collection_loader._AnsibleCollectionRef('test_collection_name', 'test_subdirs', 'test_resource')
    assert repr(test_obj) == "AnsibleCollectionRef(collection='test_collection_name', subdirs='test_subdirs', resource='test_resource')"


# Generated at 2022-06-25 12:53:49.386249
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    fullpath = '../test/test_data/tests/test_utils/test_loader/ansible_collections/test/tasks/main.yml'
    with open(fullpath, 'rb') as fd:
        expected_source = fd.read()
    fullname = 'ansible_collections.test.tasks'
    package_path = b'../test/test_data/tests/test_utils/test_loader/ansible_collections/test/tasks'
    package_path = package_path.decode('utf-8')
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list=[package_path])
    source = loader.get_source(fullname)
    assert source == expected_source


# Generated at 2022-06-25 12:54:16.821718
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    _AnsibleCollectionPkgLoaderBase_is_package_0 = _AnsibleCollectionPkgLoaderBase(None, None)
    _AnsibleCollectionPkgLoaderBase_is_package_0.is_package(None)


# Generated at 2022-06-25 12:54:27.036978
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # GIVEN
    test_file = '../test_data/test_2_module/test_plugins/test_module_utils/test_utils/test_collection/__init__.py'
    test_loader = _AnsibleCollectionPkgLoaderBase('test.collection', path_list=[])
    test_loader._candidate_paths = [os.path.join(os.path.dirname(test_file), 'test_collection')]
    test_loader._source_code_path = test_file
    test_loader._decoded_source = None
    test_loader._compiled_code = None
    # WHEN
    result = test_loader.get_source('test.collection')
    # THEN
    assert 'def test():' in result
    # assert file.closed


# Generated at 2022-06-25 12:54:38.369290
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    filename = 'meta/runtime.yml'
    loader = _AnsibleCollectionPkgLoader('ansible.collections.my_namespace.my_collection', ['/path/to/collection/root'])

    with open('/path/to/collection/root/ansible_collections/my_namespace/my_collection/meta/runtime.yml', 'rb') as fd:
        raw = fd.read()


# Generated at 2022-06-25 12:54:43.618782
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    loader = _AnsibleCollectionPkgLoaderBase('_AnsibleCollectionPkgLoaderBase.test__AnsibleCollectionPkgLoaderBase___repr__')
    result = loader.__repr__()
    expected = "_AnsibleCollectionPkgLoaderBase(path=None)"
    assert result == expected, "'__repr__' should return the correct value"


# Generated at 2022-06-25 12:54:51.364849
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:55:03.032186
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library") == "modules"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("become_plugins") == "become"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("cache_plugins") == "cache"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("callback_plugins") == "callback"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("cliconf_plugins") == "cliconf"

# Generated at 2022-06-25 12:55:04.463266
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _load_module_0 = _AnsibleInternalRedirectLoader()

# def assert_list_equal(list1, list2, msg=None):
#     assert_equal(list1, list2)

# Generated at 2022-06-25 12:55:12.326059
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    acr = AnsibleCollectionRef('ansible_collections.test.collection', 'subdir1.subdir2', 'test_resource', 'module')
    assert acr.collection == 'ansible_collections.test.collection'
    assert acr.subdirs == 'subdir1.subdir2'
    assert acr.resource == 'test_resource'
    assert acr.ref_type == 'module'
    assert acr.n_python_package_name == 'ansible_collections.test.collection.plugins.subdir1.subdir2.module'
    assert acr.n_python_collection_package_name == 'ansible_collections.test.collection'


# Generated at 2022-06-25 12:55:22.183955
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class _AnsibleCollectionPkgLoaderImpl(_AnsibleCollectionPkgLoaderBase):
        def _validate_final(self):
            # we're just going to test this method, so let's use a known value to get the test going
            self._source_code_path = "/some_path"

    _AnsibleCollectionPkgLoaderImpl("ansible_collections.my.ns").get_filename("ansible_collections.my.ns")

if __name__ == '__main__':
    test_case_0()
    test__AnsibleCollectionPkgLoaderBase_get_filename()

# Generated at 2022-06-25 12:55:33.154857
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.rolename', 'role').subdirs == 'subdir1.subdir2'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.rolename', 'role').resource == 'rolename'
    assert AnsibleCollectionRef

# Generated at 2022-06-25 12:58:17.145295
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader()
    ansible_collection_pkg_loader_0.load_module('ansible_collections.test_namespace.test_collection')


# Generated at 2022-06-25 12:58:25.045063
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """
    Tests the method from_fqcr of class AnsibleCollectionRef
    :return: None
    """
    # Test all valid fully qualified collection reference
    with pytest.raises(ValueError) as exc_info:
        AnsibleCollectionRef.from_fqcr("invalid_reference", "action")

    msg_expected = "invalid_reference is not a valid collection reference"
    msg_actual = str(exc_info.value)
    assert msg_expected == msg_actual

    ansible_core_collection = AnsibleCollectionRef.from_fqcr("ansible.builtin.action", "action")
    assert ansible_core_collection.collection == "ansible.builtin"
    assert ansible_core_collection.resource == "action"
    assert ansible_core_collection.ref_type == "action"

# Generated at 2022-06-25 12:58:36.220664
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test case 1 : Plugin name with "plugin" keyword
    loader_1 = _AnsibleCollectionPkgLoader(['ansible_collections', 'test_org_test', 'test_collection_name_with_plugin', 'test_plugin_file'])
    assert loader_1.load_module(None) is None

    # Test case 2 : Plugin name without "plugin" keyword
    loader_2 = _AnsibleCollectionPkgLoader(['ansible_collections', 'test_org_test', 'test_collection_name_without_plugin', 'test_plugin_file'])
    assert loader_2.load_module(None) is None

    # Test case 3 : Plugin name with different keyword

# Generated at 2022-06-25 12:58:46.075571
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.some.name')

    ansible_collection_loader_0 = ansible_collection_finder_0.find_module('ansible_collections.some.name')
    assert ansible_collection_loader_0.get_filename('ansible_collections.some.name') == 'ansible_collections/some/name/__init__.py'
    assert ansible_collection_loader_0 is not None

    ansible_collection_loader_1 = ansible_collection_finder_0.find_module('ansible_collections.some.name.sub')

# Generated at 2022-06-25 12:58:57.066880
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: generate temp dir and copy in full builtin content and use that
    # TODO: use a python_version agnostic way to find the builtin path
    ansible_pkg_path = os.path.dirname(import_module('ansible').__file__)
    test_pkg_path = ansible_pkg_path
    with open(os.path.join(test_pkg_path, 'meta/runtime.yml'), 'rb') as fd:
        raw_runtime_meta = fd.read()
    runtime_yaml_dict = _meta_yml_to_dict(raw_runtime_meta, ('ansible', 'test_pkg', 'runtime.yml'))


# Generated at 2022-06-25 12:59:07.096133
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('my.coll', 'role') == "AnsibleCollectionRef(collection='my.coll', subdirs='', resource='coll')"
    assert AnsibleCollectionRef.try_parse_fqcr('my.coll.mysubdir', 'role') == "AnsibleCollectionRef(collection='my.coll', subdirs='mysubdir', resource='coll')"
    assert AnsibleCollectionRef.try_parse_fqcr('my.coll.mysubdir.coin', 'role') == "AnsibleCollectionRef(collection='my.coll', subdirs='mysubdir', resource='coin')"

# Generated at 2022-06-25 12:59:09.487046
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # test _AnsibleCollectionPkgLoader.load_module() with an empty _meta_yml_to_dict()
    global _meta_yml_to_dict
    _meta_yml_to_dict = lambda *args, **kwargs: None
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:59:11.448639
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    fullname = 'ansible_collections.ns.x.x'
    pkg_loader = _AnsibleCollectionPkgLoaderBase(fullname)
    print(pkg_loader)
    print(pkg_loader.get_code(fullname))


# Generated at 2022-06-25 12:59:15.031325
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    path = "/tmp/test_ansible_collections/ansible_collections/new_col/old_ansible/plugins/missing_module.py"
    ansible_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.new_col.old_ansible.plugins', path)
    contents = ansible_pkg_loader_base_0.get_data(path)
    assert contents == b''


# Generated at 2022-06-25 12:59:24.680964
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_loader = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.ansible.unit_tests")
    assert test_loader.get_data("/ansible_collections/ansible/unit_tests/data/missing_file") is None
    assert test_loader.get_data("/ansible_collections/ansible/unit_tests/data/existing_file.txt") == b"exists\n"
    assert test_loader.get_data("/ansible_collections/ansible/unit_tests/data/existing_file.txt") == b"exists\n"
    assert test_loader.get_data("/ansible_collections/ansible/unit_tests/data/__init__.py") == b""

# Generated at 2022-06-25 13:00:13.135162
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    _AnsibleCollectionPkgLoaderBase.FILE_SEPARATOR = os.path.sep
    _meta_yml_to_dict = lambda x, y: "{'plugin_routing':{ 'module':{'path':'/home/test/test_module'} } }"
    module = ModuleType('ansible.builtin.module')
    module.__path__ = ["/home/test"]
    module._collection_meta = {}
    module.__loader__ = _AnsibleCollectionPkgLoader(['test'], ['test_module'], path=['/home/test'])
    ansible_builtin_module = "/home/test/meta/runtime.yml"

    module.__loader__.load_module(module)