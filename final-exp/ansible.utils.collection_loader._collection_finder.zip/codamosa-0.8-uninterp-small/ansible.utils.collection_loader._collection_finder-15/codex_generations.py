

# Generated at 2022-06-25 12:51:24.606598
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    float_0 = 2094.186
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(float_0)


# Generated at 2022-06-25 12:51:33.366069
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Setup
    collection_name_0 = 'collection_name_0'
    subdirs_0 = 'subdirs_0'
    resource_0 = 'resource_0'

    ansible_collection_ref_0 = AnsibleCollectionRef(collection_name_0, subdirs_0, resource_0)

    # Assertions
    _assert_repr(ansible_collection_ref_0, 'AnsibleCollectionRef(collection={0!r}, subdirs={1!r}, resource={2!r})'.format(collection_name_0, subdirs_0, resource_0))


# Generated at 2022-06-25 12:51:38.994000
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collections_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(True)
    assert ansible_collections_pkg_loader_base_0.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=True)'


# Generated at 2022-06-25 12:51:50.874971
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Scenario 1:
    # No __file__
    # Path = None
    # Result = <string>
    try:
        ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections')
        assert ansible_collection_pkg_loader_base_0.get_filename(ansible_collection_pkg_loader_base_0._fullname) == '<string>'
    except Exception as e:
        print("Error: " + str(e))

    float_0 = 1272.55
    # Scenario 2:
    # Existing __file__
    # Path = float_0/__init__.py
    # Result = float_0/__init__.py

# Generated at 2022-06-25 12:51:56.065953
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = 'a.b'
    ref_type = 'module'

    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(ref, ref_type)

    # test_from_fqcr()
    # Case 1
    try:
        ref = 'a.b'
        ref_type = 'modu'
        ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    except ValueError as e:
        print(e)

    # Case 2
    ref = 'a.b'
    ref_type = 'module'
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(ref, ref_type)

    # test_try_parse_fqcr()
    # Case 1

# Generated at 2022-06-25 12:51:57.961941
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
  ref = 456695
  ref_type = 82838
  try:
    AnsibleCollectionRef.is_valid_fqcr(ref_type)
  except ValueError:
    pass


# Generated at 2022-06-25 12:52:00.723701
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Arrange
    float_0 = 2094.186
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(float_0)
    # Act
    ansible_collection_pkg_loader_0.load_module(float_0)


# Generated at 2022-06-25 12:52:03.685372
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    _AnsibleCollectionPkgLoader(0)


# Generated at 2022-06-25 12:52:05.899184
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref = 'mazer.collection.subdir.foo'
    ref_type = 'role'
    result = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    assert result is not None


# Generated at 2022-06-25 12:52:09.848779
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    float_0 = 0.111
    int_0 = 969
    str_0 = '_'
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(str_0, int_0)
    assert isinstance(ansible_collection_ref_0, AnsibleCollectionRef)

    str_1 = '!%'
    ansible_collection_ref_1 = AnsibleCollectionRef.try_parse_fqcr(str_1, int_0)
    assert ansible_collection_ref_1 is None


# Generated at 2022-06-25 12:52:38.899828
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    """
    Test that try_parse_fqcr returns empty for an invalid collection reference, and valid for a valid one
    """
    ref_0 = AnsibleCollectionRef.try_parse_fqcr('foo.bar.baz', 'role')
    assert ref_0 is None

    ref_0 = AnsibleCollectionRef.try_parse_fqcr('ns.coll.baz', 'role')
    assert ref_0 is not None



# Generated at 2022-06-25 12:52:45.382974
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = to_text('test.test_collection.test_module')
    ref_type = to_text('module')
    # Test if this ref is a valid one
    ansible_collection_ref_0 = AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)
    assert ansible_collection_ref_0 is True

if __name__ == '__main__':
    test_AnsibleCollectionRef_is_valid_fqcr()

# Generated at 2022-06-25 12:52:46.516758
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(float_0)


# Generated at 2022-06-25 12:52:49.704426
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase()
    ansible_collection_pkg_loader_base_0.get_filename()


# Generated at 2022-06-25 12:52:50.691884
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test to complete
    pass


# Generated at 2022-06-25 12:52:56.090206
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    float_0 = 2290.69
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(float_0)
    ansible_collection_pkg_loader_base.__repr__()


if __name__ == '__main__':
    test_case_0()
    test__AnsibleCollectionPkgLoaderBase___repr__()
    sys.exit(0)

# Generated at 2022-06-25 12:52:58.475803
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # temp
    if float._AnsibleCollectionPkgLoader_load_module != 0:
        float.test_case_0()
    else:
        float.test_case_0()
        float._AnsibleCollectionPkgLoader_load_module = 1

# Generated at 2022-06-25 12:53:02.344706
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref_type = 'test_value'
    ref = AnsibleCollectionRef('test_value', 'test_value', 'test_value', ref_type)
    assert repr(ref) == 'AnsibleCollectionRef(collection={0!r}, subdirs={1!r}, resource={2!r})'.format('test_value', 'test_value', 'test_value')


# Generated at 2022-06-25 12:53:07.249610
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    path = './scripts'
    ansible_collection_pkg_loader_base1 = _AnsibleCollectionPkgLoaderBase(path)
    ansible_collection_pkg_loader_base_obj1 = ansible_collection_pkg_loader_base1.__class__
    ansible_collection_pkg_loader_base_obj1.iter_modules(path)



# Generated at 2022-06-25 12:53:09.911199
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(0, "")
    issubclass(ansible_path_hook_finder_0.find_module(""), object)


# Generated at 2022-06-25 12:53:41.639199
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Checking when ref is of the form 'ns.coll.resource'
    test_AnsibleCollectionRef_from_fqcr_resource = 'some_resource'
    test_AnsibleCollectionRef_from_fqcr_collection = 'ns.coll'
    ref_type = 'role'
    test_AnsibleCollectionRef_from_fqcr_fqcr = test_AnsibleCollectionRef_from_fqcr_collection + '.' + test_AnsibleCollectionRef_from_fqcr_resource
    test_AnsibleCollectionRef_from_fqcr_n_python_collection_package_name = 'ansible_collections.ns.coll'

# Generated at 2022-06-25 12:53:45.977524
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    float_0 = -4444.863219403585
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(path=None, collection_name='ansible_collections.my_namespace.my_collection')
    ansible_collection_pkg_loader_0.load_module()


# Generated at 2022-06-25 12:53:49.895884
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef('ns1.coll1', 'subdir1.subdir2', 'mod1', 'module')
    assert isinstance(ref, AnsibleCollectionRef)
    assert ref._fqcr == u'ns1.coll1.subdir1.subdir2.mod1'


# Generated at 2022-06-25 12:53:51.772579
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # TODO: add assertions to this unit test
    pass


# Generated at 2022-06-25 12:53:58.118373
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 12:54:03.093538
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase
    ansible_collection_pkg_loader_base_0.get_code(ansible_collection_pkg_loader_base_0)



# Generated at 2022-06-25 12:54:16.950749
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Setup
    float_0 = -1474.405436646059
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # test_case_0()
    _AnsibleCollectionPkgLoaderBase_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    # Assertion
    _AnsibleCollectionPkgLoaderBase_0.is_package('ansible_collections.somens')
    try:
        _AnsibleCollectionPkgLoaderBase_0.is_package('ansible_collections.somens')
    except ValueError():
        pass

if __name__ == '__main__':
    test__AnsibleCollectionPkgLoaderBase_is_package()
    sys.exit()

# Generated at 2022-06-25 12:54:27.168901
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object_19 = object()
    object_20 = object()
    object_21 = object()
    object_22

# Generated at 2022-06-25 12:54:28.201573
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_case_0()


# Generated at 2022-06-25 12:54:31.721134
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    float_0 = -4444.863219403585
    ansible_collection_loader__ansible_collections__somens_0 = _AnsibleCollectionPkgLoader_ansible_collections__somens()
    tuple_0 = ansible_collection_loader__ansible_collections__somens_0.iter_modules('')
    assert tuple_0 == ()


# Generated at 2022-06-25 12:54:56.505562
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    float_0 = -894.8582617753596
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('ansible', [])

    ansible_internal_redirect_loader_0.load_module()


# Generated at 2022-06-25 12:55:00.892745
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    test_ref = 'namespace.collection.subdir.resource'
    p = AnsibleCollectionRef.try_parse_fqcr(test_ref, 'role')
    if p.n_python_collection_package_name == 'ansible_collections.namespace.collection':
        print(True)


# Generated at 2022-06-25 12:55:09.288595
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    fullname_0 = 'ansible.module_utils'
    path_0 = None
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, '/tmp/ansible_doucvo/ansible_collections')
    ansible_path_hook_finder_0.find_module(fullname_0, path_0)
    ansible_path_hook_finder_0.find_module(fullname_0)


# Generated at 2022-06-25 12:55:17.442983
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('', '', '', '', '', data=None)
    assert loader._source_code_path == ''
    assert loader._package_to_load == ''
    assert loader._parent_package_name == ''
    assert loader._fullname == ''
    assert loader._split_name == ''
    assert loader._candidate_paths == ''
    assert loader._subpackage_search_paths is None
    assert loader._compiled_code is None
    assert loader._decoded_source == ''


# Generated at 2022-06-25 12:55:24.332379
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # This test case verifies that the get_source() method returns expected output
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder('', ansible_collection_finder_0)
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('test.test_name','')
    result = ansible_collection_pkg_loader_base_0.get_source('test_source')
    print(result)


# Generated at 2022-06-25 12:55:35.971039
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    float_1 = float_0 - float(3.0)
    float_2 = float_1 / float(0.0)
    float_3 = float_2 / float(0.0)
    float_4 = float_3 - float(1.0)
    float_5 = float_4 - float(1.0)
    float_6 = float_5 * float(1.0)
    float_7 = float_6 + float(-3.0)
    float_8 = float_7 - float(-3.0)
    float_9 = float_8 + float(-3.0)
    float_10 = float_9 - float(3.0)
    float_11

# Generated at 2022-06-25 12:55:40.506195
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo')
    if ansible_collection_pkg_loader_base_0.is_package():
        raise ValueError('Could not get method is_package of class _AnsibleCollectionPkgLoaderBase')


# Generated at 2022-06-25 12:55:47.178490
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(['ansible.builtin'])
    ansible_collection_pkg_loader_0.load_module('ansible.builtin')


# Generated at 2022-06-25 12:55:52.688440
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('', None)
    str_0 = ansible_collection_pkg_loader_base_0.__repr__()
    str_1 = ansible_collection_pkg_loader_base_0.__repr__()
    assert str_0 == str_1


# Generated at 2022-06-25 12:55:55.281393
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader('.')
    ansible_collection_pkg_loader_0.load_module('.')



# Generated at 2022-06-25 12:56:24.036782
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader()
    fullname_0 = ansible_collection_pkg_loader_0.load_module(0)
    assert fullname_0 == 401, "Load module method of _AnsibleCollectionPkgLoader failed."


# Generated at 2022-06-25 12:56:28.046729
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(float_0)
    ansible_collection_pkg_loader_base_0.get_filename(ansible_collection_pkg_loader_base_0._fullname)


# Generated at 2022-06-25 12:56:30.987897
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # some_package is used to trigger the desired path through the code
    float_1 = 0.0028742066548608765
    ansible_internal_redirect_loader_1 = _AnsibleInternalRedirectLoader('some.package', float_1)


# Generated at 2022-06-25 12:56:33.722459
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader('.')
    ansible_collection_pkg_loader_0.load_module('.')


# Generated at 2022-06-25 12:56:38.954270
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    fqcr = "some.collection.some_module"
    ref_type = "module"
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert "my.collection" == ansible_collection_ref_0.collection
    assert "my.collection.some_module" == ansible_collection_ref_0.fqcr
    assert "some_module" == ansible_collection_ref_0.resource
    assert "module" == ansible_collection_ref_0.ref_type
    assert "some.collection" == ansible_collection_ref_0.n_python_collection_package_name
    assert "some.collection.some_module" == ansible_collection_ref_0.n_python_package_name
    assert "" == ansible_

# Generated at 2022-06-25 12:56:48.210967
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=None)


if __name__ == '__main__':
    import sys
    # sys.path.append('/Users/alfanhui/Projects/temp/ansible_collections_2')
    test__AnsibleCollectionPkgLoaderBase___repr__()
    # test_case_0()

# Generated at 2022-06-25 12:56:59.673936
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    split_name = ('ansible_collections', 'ansible_collections.somens', 'ansible_collections.somens.somecoll_name')
    toplevel_pkg = split_name[0]
    if toplevel_pkg == 'ansible_collections':
        # collections content? delegate to the collection finder
        ansible_collection_finder_0.find_module(fullname=split_name, path=[self._pathctx])

# Generated at 2022-06-25 12:57:06.039776
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(ansible_collection_finder_0, 0.0)
    ansible_internal_redirect_loader_0.load_module(ansible_collection_finder_0)


# Generated at 2022-06-25 12:57:12.855903
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    float_0 = -4444.863219403585
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somespace.strange', path=[ansible_collection_finder_0._paths('ansible_collections.somespace.strange')])
    ansible_collection_loader_0.get_data('/path/to/non-existant/module')


# Generated at 2022-06-25 12:57:20.791227
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    float_0 = -1.4913674200957774
    ansible_collection_loader__ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('ansible', [])
    module_0 = ansible_collection_loader__ansible_internal_redirect_loader_0.load_module('ansible')
    module_1 = ansible_collection_loader__ansible_internal_redirect_loader_0.load_module('ansible')
    module_2 = ansible_collection_loader__ansible_internal_redirect_loader_0.load_module('ansible')
    module_3 = ansible_collection_loader__ansible_internal_redirect_loader_0.load_module('ansible')
    module_4 = ansible_collection_loader__ansible_internal_redirect_

# Generated at 2022-06-25 12:57:50.044107
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    fqcr_case_0 = 'test.test.test.test'
    ref_type_case_0 = 'module'
    ref_case_0 = AnsibleCollectionRef.try_parse_fqcr(fqcr_case_0, ref_type_case_0)
    assert ref_case_0.fqcr == fqcr_case_0


# Generated at 2022-06-25 12:58:00.534721
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ANSIBLE_COLLECTION_NAME = 'ansible.builtin'
    REF_TYPE = 'module'
    GOOD_REF_1 = 'ansible.builtin.copy'
    GOOD_REF_2 = 'ansible.builtin.subdir1.subdir2.copy'
    BAD_REF_1 = 'ansible.builtin.subdir1.subdir2.copy.bad'
    BAD_REF_2 = 'ansible.builtin.subdir1.subdir2.copy.bad'

    fqcr = AnsibleCollectionRef.try_parse_fqcr(GOOD_REF_1, REF_TYPE)
    assert fqcr is not None
    assert fqcr.fqcr == GOOD_REF_1
    assert fqcr.collection == ANSIBLE_COLLECTION_NAME


# Generated at 2022-06-25 12:58:10.019797
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():

    # Load module 'ansible.plugins.action.copy'
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.action.copy', 'ansible_collections.ns.collection')
    loader.load_module('ansible.plugins.action.copy')
    assert 'ansible.plugins.action' in sys.modules
    assert 'ansible.plugins.action.copy' in sys.modules

    # Load module 'ansible.module_utils.six.moves'
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six.moves', 'ansible_collections.ns.collection')
    loader.load_module('ansible.module_utils.six.moves')
    assert 'ansible.module_utils' in sys.modules

# Generated at 2022-06-25 12:58:17.812475
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Define the parameters the unit test will run with
    test_params = [
        {
            "fullname": "ansible.module_utils.basic",
            "path_list": None,
        },
    ]

    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader("ansible.module_utils.basic",None)
    ansible_internal_redirect_loader.load_module("ansible.module_utils.basic")


# Generated at 2022-06-25 12:58:25.477582
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections', path_list=[])
    ansible_collection_pkg_loader_base_0.__repr__()
    ansible_collection_pkg_loader_base_1 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.geerlingguy', path_list=[])
    ansible_collection_pkg_loader_base_1.__repr__()
    ansible_collection_pkg_loader_base_2 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.geerlingguy.foo', path_list=[])
    ansible_collection_pkg_loader_base_2.__repr__()
    ansible_collection_pkg_loader_

# Generated at 2022-06-25 12:58:36.641242
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    import_path = 'ansible_collections.my_namespace.my_collection.plugins.module_utils.subdir.subsubdir.subsubsubdir'
    assert AnsibleCollectionRef.from_fqcr(import_path, 'module_utils') == AnsibleCollectionRef(
        'my_namespace.my_collection',
        'subdir.subsubdir.subsubsubdir',
        'subsubsubdir',
        'module_utils'
    )

    import_path = 'ansible_collections.my_namespace.my_collection.plugins.lookup'
    assert AnsibleCollectionRef.from_fqcr(import_path, 'lookup') == AnsibleCollectionRef(
        'my_namespace.my_collection',
        '',
        'lookup',
        'lookup'
    )

# Generated at 2022-06-25 12:58:40.315060
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_pkloader_base = _AnsibleCollectionPkgLoaderBase
    get_source_result = ansible_pkloader_base.get_source('test_fullname')
    assert get_source_result is None


# Generated at 2022-06-25 12:58:48.585953
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    myhandler = TestHandler()
    myhandler.setLevel(logging.DEBUG)
    logger.addHandler(myhandler)

    expected = 'action'
    actual = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert actual == expected
    actual = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('vars_plugins')
    assert actual == expected
    actual = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins')
    assert actual == expected

    expected = 'modules'
    actual = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert actual == expected

    expected = 'module_utils'
    actual = AnsibleCollectionRef.legacy_plugin_dir_to_plugin

# Generated at 2022-06-25 12:58:53.265260
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    try:
        _AnsibleCollectionLoader(None, None)
        assert False
    except ValueError:
        pass

    try:
        _AnsibleCollectionLoader('foo', None)
        assert False
    except ValueError:
        pass



# Generated at 2022-06-25 12:58:59.507056
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Setup
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('ansible.builtin.setup', None)

    # Test
    ansible_internal_redirect_loader_0.load_module('ansible.builtin.setup')
    # Verify


if __name__ == "__main__":
    test_case_0()
    # test__AnsibleInternalRedirectLoader_load_module()

# Generated at 2022-06-25 12:59:26.017471
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _meta_yml_to_dict = MagicMock()

    _AnsibleInternalRedirectLoader._meta_yml_to_dict = _meta_yml_to_dict
    _AnsibleInternalRedirectLoader_load_module_instance = _AnsibleInternalRedirectLoader(fullname='ansible.builtin.new_foo', path_list='/var/lib/awx/venv/awx/lib/python3.6/site-packages/ansible/builtin')
    assert _AnsibleInternalRedirectLoader_load_module_instance.load_module('ansible.builtin.new_foo') == '_AnsibleInternalRedirectLoader_modulename'

    _AnsibleInternalRedirectLoader._meta_yml_to_dict = _meta_yml_to_dict
    _Ans

# Generated at 2022-06-25 12:59:36.028749
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    sys.path_hooks.append(_AnsibleCollectionPathHook)
    sys.meta_path.insert(0, _AnsibleCollectionFinder())
    # Test 1, which is supposed to fail
    try:
        import ansible.errors.ansible_errors
    except ValueError as e:
        pass
    # Test 2, which is supposed to fail
    try:
        import ansible.utils.selinux_spec
    except ValueError as e:
        pass
    # Test 3, which is supposed to fail
    try:
        import ansible.utils.unsafe_proxy
    except ValueError as e:
        pass
    # Test 4, which is supposed to fail
    try:
        import ansible.utils.unsafe_proxy
    except ValueError as e:
        pass
    # Test

# Generated at 2022-06-25 12:59:39.520776
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.collection')
    assert not ansible_collection_pkg_loader_base_0.is_package('ansible_collections.ns.collection')


# Generated at 2022-06-25 12:59:43.403395
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    acplb = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.name')
    source = acplb.get_source('ansible_collections.ns.name')
    assert source == None


# Generated at 2022-06-25 12:59:51.965246
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # mock module for testing
    collection_paths = ['/test_mod', '/test_pkg']
    pathctx = '/test_collection_paths'
    n_prefix = '/test_n_prefix'
    # mock module for testing
    mod_collections = import_module('ansible_collections')

    # ansible_collection_finder_0 is an instance of _AnsibleCollectionFinder
    ansible_collection_finder_0 = _AnsibleCollectionFinder(paths=collection_paths)
    ansible_collection_finder_0._n_playbook_paths = collection_paths
    ansible_collection_finder_0._ansible_collection_path_hook(pathctx)

    # ansible_path_hook_finder_0 is an instance of _AnsiblePathHookFinder
    ansible

# Generated at 2022-06-25 13:00:02.165029
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 13:00:11.826483
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test with code
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens_0.something', path_list=[os.path.join(COLLECTIONS_PATHS[0], 'somens_0', 'something')])
    ansible_collection_pkg_loader_base_0.get_code('ansible_collections.somens_0.something')
    assert 'ansible_collections.somens_0.something' == 'ansible_collections.somens_0.something'
    # Test without code
    ansible_collection_pkg_loader_base_1 = _AnsibleCollectionPkgLoaderBase('plugin_loader_1', path_list=COLLECTIONS_PATHS)
    ansible_collection_pkg