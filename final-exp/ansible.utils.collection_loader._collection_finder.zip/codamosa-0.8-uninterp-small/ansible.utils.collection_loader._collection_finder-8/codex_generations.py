

# Generated at 2022-06-25 12:51:30.423311
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    ansible_collection_loader_base_1 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    assert ansible_collection_loader_base_1.get_filename('ansible_collections.somens') == '__synthetic__'



# Generated at 2022-06-25 12:51:38.376424
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():

    finder_0 = _AnsibleCollectionFinder()
    finder_0._find_distributions_at_path = MagicMock(return_value=[])
    loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.sub.package', path_list=[])
    print('Created _AnsibleCollectionPkgLoaderBase instance')
    print('is_package: {0}'.format(loader_0.is_package('ansible_collections.ns.sub.package')))
    print('import: {0}'.format(loader_0.load_module('ansible_collections.ns.sub.package')))
    print('get_source: {0}'.format(loader_0.get_source('ansible_collections.ns.sub.package')))

# Generated at 2022-06-25 12:51:50.832019
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # test with an existing path
    print("test__AnsibleCollectionPkgLoaderBase_get_data: test with an existing path")
    acp = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.test_collection", path_list=["/var/tmp/test_collection"])
    acp._source_code_path = '/var/tmp/test_collection/__init__.py'
    try:
        acp.get_data("/var/tmp/test_collection/tests/data/test.txt")
    except Exception as e:
        print(e)
    else:
        print("test__AnsibleCollectionPkgLoaderBase_get_data: test with an existing path - PASS")

    # test with a non existing path

# Generated at 2022-06-25 12:51:55.283704
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    test_good = ['namespace.collection']
    test_bad = ['namespace.collection1.collection2']

    for test in test_good:
        with pytest.raises(ValueError):
            AnsibleCollectionRef(test, None, None, None)

    for test in test_bad:
        with pytest.raises(ValueError):
            AnsibleCollectionRef(test, None, None, None)



# Generated at 2022-06-25 12:52:01.621552
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref_type = 'module'
    ref = 'namespace.collection.foo'
    actual = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    assert actual.ref_type == 'module'
    assert actual.collection == 'namespace.collection'
    assert actual.subdirs == 'foo'
    assert actual.resource == 'foo'

    ref = 'ns.coll.res'
    actual = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    assert actual.ref_type == 'module'
    assert actual.collection == 'ns.coll'
    assert actual.subdirs == ''
    assert actual.resource == 'res'

    ref = 'ns.coll.subdir.res'
    actual = AnsibleCollectionRef.from_fqcr(ref, ref_type)

# Generated at 2022-06-25 12:52:06.868209
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_pkg_loader_base_obj = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.somens.somesubns")
    ansible_collection_pkg_loader_base_obj.load_module(fullname="ansible_collections.somens.somesubns")


# Generated at 2022-06-25 12:52:15.799505
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Create a simple module with a name
    class test_module(ModuleType):
        pass

    # Create the test case
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(path = [])
    ansible_collection_pkg_loader_0._split_name = ['ansible_collections', 'ansible', 'builtin']
    ansible_collection_pkg_loader_0._fullname = 'ansible_collections.ansible.builtin'
    ansible_collection_pkg_loader_0._package_to_load = 'builtin'
    ansible_collection_pkg_loader_0._parent_package_name = 'ansible_collections.ansible'
    ansible_collection_pkg_loader_0._subpackage_search_paths = []
    ansible_collection_pkg_

# Generated at 2022-06-25 12:52:21.458624
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader_instance = _AnsibleInternalRedirectLoader("ansible.builtin.win_group", "/tmp/")
    fullname = "ansible.builtin.win_group"
    if loader_instance is None:
        raise ValueError("Failed to instantiate loader_instance")
    if HAS_SYMBOLS:
        loader_instance.load_module.__doc__ =  _AnsibleInternalRedirectLoader.load_module.__doc__
    module_instance = loader_instance.load_module(fullname)
    if module_instance:
        return True
    else:
        raise ValueError("Failed to execute load_module")


# Generated at 2022-06-25 12:52:26.664064
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    ansible_collection_finder_1 = _AnsibleCollectionFinder()

    # setup test case
    # Case 0:
    # test __init__
    namespace_package_0 = 'ansible_collections.namespace0'

    # Case 1
    # test __init__
    path_0 = 'path0'  # type: str
    collection_0 = 'collection0'  # type: str
    package_0 = 'package0'  # type: str
    fullname_0 = '.'.join([namespace_package_0, collection_0, package_0])  # type: str

    # Case 2
    # test __init__
    # fullname_0 = '.'.join([namespace_package_0, collection_0, package_0, 'subpackage0'])
    # fullname_1 =

# Generated at 2022-06-25 12:52:30.606421
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.ansible")
    ansible_collection_pkg_loader_base_0._subpackage_search_paths = ansible_collection_pkg_loader_base_0._subpackage_search_paths
    assert ansible_collection_pkg_loader_base_0.is_package("ansible_collections.ansible")



# Generated at 2022-06-25 12:52:58.609741
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    ansible_Internal_redirect_loader = _AnsibleInternalRedirectLoader('ansible.module_utils.common', None)

# test_Ansible_collection_loader is the test for the class _AnsibleCollectionLoader

# Generated at 2022-06-25 12:53:05.196993
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    test = _AnsibleCollectionPkgLoaderBase(fullname='hello', path_list=[os.path.dirname(__file__)])
    assert {m[1] for m in test.iter_modules(prefix='')} == {'hello', 'hello_module', '__init__'}, \
        "Package 'hello' does not contain expected modules"
    assert {m[1] for m in test.iter_modules(prefix='hello.')} == {'hello_module', '__init__'}, \
        "Package 'hello' does not contain expected modules"
    assert list(test.iter_modules(prefix='hello.hello_module')) == [], \
        "Module 'hello_module' should not contain modules"

# Generated at 2022-06-25 12:53:13.255717
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0._install()
    assert ansible_collection_finder_0.find_module('ansible.module_utils.network.common.utils') is not None
    assert ansible_collection_finder_0.find_module('ansible.module_utils.network.common.utils', None) is not None
    assert ansible_collection_finder_0.find_module('ansible.module_utils.network.common.utils', []) is not None
    assert ansible_collection_finder_0.find_module('ansible_collections.ansible') is not None
    assert ansible_collection_finder_0.find_module('ansible_collections.ansible', None) is not None
    assert ansible_collection_finder_

# Generated at 2022-06-25 12:53:20.786347
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    acr = AnsibleCollectionRef
    assert acr.is_valid_fqcr(u'foo.bar', u'role')
    assert acr.is_valid_fqcr(u'ns.coll.myrole', u'role')
    assert acr.is_valid_fqcr(u'ns.coll.subdir.myrole', u'role')
    assert acr.is_valid_fqcr(u'foo.bar', u'role')
    assert acr.is_valid_fqcr(u'ns.coll.mymodule')
    assert acr.is_valid_fqcr(u'ns.coll.subdir.mymodule')
    assert acr.is_valid_fqcr(u'ns.coll.action.myaction', u'action')
    assert acr.is_

# Generated at 2022-06-25 12:53:23.129207
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    target = AnsibleCollectionRef(u'a.b', u'c.d', u'e', u'f')
    should_be = "AnsibleCollectionRef(collection='a.b', subdirs='c.d', resource='e')"
    actual = target.__repr__()
    assert actual == should_be



# Generated at 2022-06-25 12:53:31.810477
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Create an instance of _AnsibleCollectionPkgLoaderBase
    fullname = "ansible_collections.ns.module0"
    path_list = ["/path_0", "/path_1"]
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert repr(ansible_collection_pkg_loader_base_0) == "_AnsibleCollectionPkgLoaderBase(path=['/path_0', '/path_1'])"

# Generated at 2022-06-25 12:53:38.793738
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import sys
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = None
    ns_pkg_loader = _AnsibleCollectionPkgLoader(package_to_load='ansible', fullname='ansible.builtin')
    try:
        ns_pkg_loader.load_module('ansible.builtin')
    except ValueError as e:
        assert str(e) == 'ansible.utils.collection_loader._meta_yml_to_dict is not set'

    ansible.utils.collection_loader._meta_yml_to_dict = __fake__meta_yml_to_dict__
    sys.modules.pop('ansible.builtin', None)

# Generated at 2022-06-25 12:53:47.438750
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collections_name = 'ansible_collections'
    namespace_name = 'namespace'
    package_name = 'package'
    module_name = 'module'
    meta_yml = b"""
some_key: some_value
"""

    with patch('os.path.isdir', return_value=True), \
         patch.object(_AnsibleCollectionPkgLoader, 'get_data', return_value=meta_yml):
        loader = _AnsibleCollectionPkgLoader(ansible_collections_name, namespace_name, package_name)

        with patch.object(_AnsibleCollectionPkgLoader, 'get_filename') as get_filename_mock:
            get_filename_mock.return_value = 'filename'


# Generated at 2022-06-25 12:53:53.278063
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test case 0.
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.c0.t1')
    print(ansible_collection_pkg_loader_base_0)
    ansible_collection_pkg_loader_base_0.load_module(ansible_collection_pkg_loader_base_0._fullname)



# Generated at 2022-06-25 12:53:57.848195
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(fullname = 'ansible.module_utils.another_utils', path_list = 'path_list')
    ansible_internal_redirect_loader.load_module(fullname = 'ansible.module_utils.another_utils')


# Generated at 2022-06-25 12:54:26.615022
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    finder = _AnsibleCollectionFinder()
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('jds.jds_collection.test', path_list=[os.path.join('test', 'unit')])
    # test method body
    ansible_collection_pkg_loader_base.__repr__()


# Generated at 2022-06-25 12:54:32.117023
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder(paths=[os.getcwd()])
    ansible_collection_finder_0._install()
    ansible_collection_finder_0.set_playbook_paths(paths=[os.getcwd()])
    ansible_collection_finder_0.set_playbook_paths(paths=[os.getcwd()])
    ansible_collection_finder_0.find_module(fullname='ansible_collections') 
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(collection_finder=ansible_collection_finder_0, pathctx=os.getcwd()) 
    ansible_path_hook_finder_0.find_module(fullname='ansible_collections')


# Generated at 2022-06-25 12:54:43.255197
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    #Create a mock object
    class Mock:
        def __init__(self):
            self.mock = 'mock'

    #Create a mock object for iter modules
    class Mock_iter_modules:
        def __init__(self, fullname):
            self.fullname = fullname

        # Mock iter modules
        def iter_modules(self):
            return [Mock()]

    # create a mock object for load_module
    class Mock_load_module:
        def __init__(self):
            self.mock = 'mock'

    # create a mock object for load_module
    class Mock_load_module_None:
        def __init__(self):
            self.mock = None

    #Create a mock object for finder path hook

# Generated at 2022-06-25 12:54:50.988677
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from importlib import import_module

    ansible_collections_loader_0 = _AnsibleCollectionFinder()
    ansible_collections_loader_0._install()

    # Add the path to the collection 'ansible_collections.test' to the internal list of paths
    ansible_collections_loader_0._n_configured_paths.append(to_native(to_bytes(os.path.dirname(__file__), errors='surrogate_or_strict'))+"/ansible_collections")

    # Try to import the module 'ansible_collections.test.test_js_module' from the collection
    module

# Generated at 2022-06-25 12:54:59.188821
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # Should return the corresponding plugin ref_type (eg, 'action', 'role')
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('invalid_action') == 'action'
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('invalid_library')


# Generated at 2022-06-25 12:54:59.587396
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    pass



# Generated at 2022-06-25 12:55:04.845274
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    name = 'ansible_collections.foo.bar'
    package_path = '/path/to/ansible_collections/foo/bar'
    module = ModuleType(name)
    with patch('ansible.utils.collection_loader._meta_yml_to_dict', MagicMock()):
        with patch.dict('sys.modules', {name:module}, clear=True):
            loader = _AnsibleCollectionPkgLoader(package_path)
            assert loader.load_module(name) == module
            assert hasattr(module, '_collection_meta')
            assert module._collection_meta == {}
            assert hasattr(module, '__loader__')
            assert module.__loader__ == loader
            assert hasattr(module, '__file__')
            assert module.__file__ == ''

# Generated at 2022-06-25 12:55:10.205251
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('test.test') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test.test') == True
    assert AnsibleCollectionRef.is_valid_fqcr('test.test.test.test.test') == True


# Generated at 2022-06-25 12:55:16.621451
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:55:19.374099
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ansible_collection_ref = AnsibleCollectionRef()
    ref = "collection.name.role.name"
    ref_type = "role"
    actual_ansible_collection_ref = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    expected_ansible_collection_ref = AnsibleCollectionRef("collection.name", "role", "name", "role")
    assert actual_ansible_collection_ref == expected_ansible_collection_ref



# Generated at 2022-06-25 12:56:15.399965
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # case 1
    # Internal redirect should be loaded
    test_case = 'ansible.builtin.simple_math'
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(test_case, [])
    assert ansible_internal_redirect_loader._redirect == 'ansible_collections.builtin.simple_math'

    # case 2
    # Non ansible namespace should return Import Error
    test_case = 'not_ansible.builtin.simple_math'
    with pytest.raises(ImportError, match=r'.*not interested.*'):
        ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(test_case, [])

    # case 3
    # Direct import should throw ImportError

# Generated at 2022-06-25 12:56:24.417070
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # We should be able to import a module that exists in the ansible_collections namespace
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible_dev.test_collection.test_module',
                                             path_list=['/tmp/ansible_collections/ansible_dev/test_collection'])
    assert loader.iter_modules('ansible_collections.ansible_dev.test_collection.test_module') == [('ansible_collections.ansible_dev.test_collection.test_module', True, True, None)]
    assert loader.iter_modules('ansible_collections.ansible_dev.test_collection.test_module.test_module') == []

    # We should not be able to import a module that doesn't exist in the ansible_collections namespace

# Generated at 2022-06-25 12:56:32.126102
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('httpapi_plugins') == 'httpapi'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin

# Generated at 2022-06-25 12:56:36.605912
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # It should return module with attribute '_collection_meta'
    loader = _AnsibleCollectionPkgLoader('_meta_yml_to_dict', ['my.collection', 'ansible', 'builtin'], None, None)
    module = loader.load_module("")
    assert module._collection_meta == {}


# Generated at 2022-06-25 12:56:37.502437
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    pass # test is not required


# Generated at 2022-06-25 12:56:49.156883
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # FIXME(kkas): should be in class, but that would require mock.patch.multiple or other patching mechanism.
    def check_try_parse_fqcr(ref, ref_type, expected_collection, expected_subdirs, expected_resource):
        fqcr = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
        assert fqcr
        assert ref == fqcr.fqcr
        assert expected_collection == fqcr.collection
        assert expected_subdirs == fqcr.subdirs
        assert expected_resource == fqcr.resource

    # simple valid test set
    check_try_parse_fqcr('my.c', 'roles', 'my.c', '', 'roles')

# Generated at 2022-06-25 12:57:00.116292
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == \
           AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module') == \
           AnsibleCollectionRef('ns.coll', 'subdir1', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module') == \
           AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role') == \
           AnsibleCollectionRef('ns.coll', '', 'rolename', 'role')

# Generated at 2022-06-25 12:57:11.333058
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Case 0: load role
    fqcr = 'namespace.collection.role'
    ref_type = 'role'
    expected_result_0 = AnsibleCollectionRef(u'namespace.collection', u'', u'role', u'role')
    acr_0 = AnsibleCollectionRef.try_parse_fqcr(fqcr, ref_type)
    assert expected_result_0 == acr_0

    # Case 1: load action
    fqcr = 'namespace.collection.action'
    ref_type = 'action'
    expected_result_1 = AnsibleCollectionRef(u'namespace.collection', u'', u'action', u'action')
    acr_1 = AnsibleCollectionRef.try_parse_fqcr(fqcr, ref_type)
    assert expected_result_

# Generated at 2022-06-25 12:57:19.603112
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_data = [
       ( 'action_plugins', 'action'),
       ( 'become_plugins', 'become'),
       ( 'cache_plugins', 'cache'),
       ( 'callback_plugins', 'callback'),
       ( 'cliconf_plugins', 'cliconf'),
       ( 'connection_plugins', 'connection'),
       ( 'httpapi_plugins', 'httpapi'),
       ( 'inventory_plugins', 'inventory'),
       ( 'lookup_plugins', 'lookup'),
       ( 'shell_plugins', 'shell'),
       ( 'strategy_plugins', 'strategy'),
       ( 'terminal_plugins', 'terminal'),
       ( 'library', 'modules'),
    ]

    for (dir_name, exp_type) in test_data:
       act_type = AnsibleCollectionRef.legacy_plugin_dir_

# Generated at 2022-06-25 12:57:23.783994
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test that the method will return a valid AnsibleCollectionRef object when the input is correct
    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.plugin', 'role')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'plugin'
    assert ref.ref_type == 'role'

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.plugin', 'role')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'plugin'
    assert ref.ref_type == 'role'


# Generated at 2022-06-25 12:57:50.562045
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'role') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.') == False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource_a.') == False

# Generated at 2022-06-25 12:58:00.836744
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_plugin=''
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_plugin)

    with pytest.raises(ValueError):
        test_plugin='unknown_plugintype'
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_plugin)

    with pytest.raises(ValueError):
        test_plugin='ansible.builtin.cache'
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_plugin)

    with pytest.raises(ValueError):
        test_plugin='ansible.builtin.not_a_real_plugin_type'
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(test_plugin)



# Generated at 2022-06-25 12:58:10.298628
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test case setup
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(fullname = 'ansible.module_utils.basic', path_list = 'ansible.module_utils.basic')
    # Test 1 - Call load_module
    ansible_internal_redirect_loader.load_module(fullname = 'ansible.module_utils.basic')
    _AnsibleInternalRedirectLoader._redirect = 'ansible.builtin.module_utils.basic'
    ansible_internal_redirect_loader.load_module(fullname = 'ansible.module_utils.basic')
    _AnsibleInternalRedirectLoader._redirect = 'ansible.builtin.module_utils.basic'

# Generated at 2022-06-25 12:58:21.437798
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:58:31.936433
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0._install()
    ansible_collection_finder_0.set_playbook_paths([])
    assert ansible_collection_finder_0._n_configured_paths == []
    assert ansible_collection_finder_0._n_cached_collection_paths is None
    assert ansible_collection_finder_0._n_cached_collection_qualified_paths is None
    assert ansible_collection_finder_0._n_playbook_paths == []
    ansible_collection_finder_0._install()
    ansible_collection_finder_0.set_playbook_paths([])
    assert ansible_collection_finder_0._n_configured_paths == []
    assert ans

# Generated at 2022-06-25 12:58:42.481702
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():

    from types import CodeType

    _AnsibleCollectionPkgLoaderBase._allows_package_code = True

    # for a normal module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.somemodule', ['/path/to/collections_root'])
    assert(loader)
    assert(isinstance(loader, _AnsibleCollectionPkgLoaderBase))
    code_obj = loader.get_code('ansible_collections.somens.somemodule')
    assert(isinstance(code_obj, CodeType))

    # for a "synthetic" module
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.somemodule', ['/path/to/collections_root'])

# Generated at 2022-06-25 12:58:47.694052
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six.moves', 'path_list')
    # testing with path_list, to check if path_list is getting replaced with something like
    # 'ansible.module_utils.six.client.modules' and testing to check if
    # _AnsibleInternalRedirectLoader.load_module(fullname) is making call to ansible.module_utils.six.client.modules
    assert_that(calling(loader.load_module).with_args("ansible.module_utils.six.moves"), raises(ImportError))



# Generated at 2022-06-25 12:58:51.831435
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths(["/etc/ansible/hosts"])


# Generated at 2022-06-25 12:59:02.554585
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # testing for valid FQCR
    assert AnsibleCollectionRef.is_valid_fqcr('ns1.coll1.resource1') == True, "FQCR expected to be valid"
    assert AnsibleCollectionRef.is_valid_fqcr('ns1.coll1.subdir1.resource1') == True, "FQCR expected to be valid"
    assert AnsibleCollectionRef.is_valid_fqcr('ns1.coll1.role1') == True, "FQCR expected to be valid"
    # testing for invalid FQCR
    assert AnsibleCollectionRef.is_valid_fqcr('') == False, "FQCR expected to be invalid"
    assert AnsibleCollectionRef.is_valid_fqcr('ns1.coll1') == False, "FQCR expected to be invalid"

# Generated at 2022-06-25 12:59:11.278985
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    plugin_dir_list = ['action_plugins', 'become_plugins', 'cache_plugins', 'callback_plugins',
                       'cliconf_plugins', 'connection_plugins', 'doc_fragments', 'filter_plugins',
                       'httpapi_plugins', 'inventory_plugins', 'library', 'lookup_plugins',
                       'module_utils', 'modules', 'netconf_plugins', 'notification_plugins', 'roles',
                       'shell_plugins', 'strategy_plugins', 'terminal_plugins', 'test_plugins', 'vars_plugins']


# Generated at 2022-06-25 12:59:37.210629
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    test_case_0()

# This is the main point of entry for this module. It is called from AnsibleCollectionConfig.enable() and
# configures the sys.meta_path list with _AnsibleCollectionFinder.
_finder = None


# Generated at 2022-06-25 12:59:40.082827
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader(fullname='ansible.builtin.open_url', path_list=[])
    loader.load_module('ansible.builtin.open_url')


# Generated at 2022-06-25 12:59:49.876686
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_type = 'filter'
    ref_string = 'ansible_collections.namespace.collection.plugins.filter.myfilter'
    r = AnsibleCollectionRef.try_parse_fqcr(ref_string, ref_type)
    assert r.fqcr == ref_string
    assert r.ref_type == ref_type

    ref_type = 'action'
    ref_string = 'ansible_collections.namespace.collection.plugins.action.myaction'
    r = AnsibleCollectionRef.try_parse_fqcr(ref_string, ref_type)
    assert r.fqcr == ref_string
    assert r.ref_type == ref_type

    ref_type = 'module'
    ref_string = 'ansible_collections.namespace.collection.plugins.modules.mymodule'

# Generated at 2022-06-25 12:59:58.913458
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    test_dir = os.path.dirname(os.path.dirname(__file__))
    test_dir = os.path.join(test_dir, 'test', 'unit', 'test_collection_finders')
    test_dir = os.path.join(test_dir, 'test_data', 'test_AnsibleCollectionPkgLoaderBase_get_code')

    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = os.path.join(test_dir, 'collection-path')
    ansible_collection_finder_1 = _AnsibleCollectionFinder()

    sys.path.insert(0, os.path.join(test_dir, 'work-directory'))

    # find module 'ansible_collections.test_namespace.synthetic_subpackage' when it is a synthetic package

# Generated at 2022-06-25 13:00:05.097565
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref_0 = AnsibleCollectionRef(collection_name='ansible.builtin', subdirs='subdir1.subdir2', resource='someaction', ref_type='action')
    assert repr(ansible_collection_ref_0) == "AnsibleCollectionRef(collection='ansible.builtin', subdirs='subdir1.subdir2', resource='someaction')"


# Generated at 2022-06-25 13:00:08.751133
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase()
    ansible_collection_pkg_loader_base._source_code_path
    ansible_collection_pkg_loader_base.get_source('')


# Generated at 2022-06-25 13:00:13.563381
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():

    src_path = os.path.dirname(os.path.realpath(__file__))
    dest_path = os.path.join(src_path, 'test_data/test_sub_collection')
    sys.path.insert(0, dest_path)

    _AnsibleInternalRedirectLoader = _AnsibleInternalRedirectLoader('ansible.builtin.test_module', None)
    _AnsibleInternalRedirectLoader.load_module('ansible.builtin.test_module')

