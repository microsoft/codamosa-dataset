

# Generated at 2022-06-25 12:51:39.302878
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleCollectionPkgLoaderBase, self).__init__(*args, **kwargs)
            self._subpackage_search_paths = [os.path.dirname(__file__)]

    t = TestAnsibleCollectionPkgLoaderBase('ansible.test', path_list=[os.path.dirname(__file__)])

    # test file in current directory
    assert t.get_data('loader_base_test.py') is not None

    # test file in subdirectory
    assert t.get_data('utils/__init__.py') is not None

    # test file which does not exist

# Generated at 2022-06-25 12:51:50.915905
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from collections import namedtuple
    mod_dummy = namedtuple('Module', ['__init__', '__dict__'])
    mod_dummy.__init__.__defaults__ = (None,) * len(mod_dummy.__init__.__defaults__)
    mod_dummy.__dict__.__setitem__('__name__', 'ansible_collections.my_namespace.my_collection.plugins.modules.dummy')
    mod_dummy.__dict__.__setitem__('__package__', 'ansible_collections.my_namespace.my_collection.plugins.modules')

# Generated at 2022-06-25 12:51:51.860041
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    pass



# Generated at 2022-06-25 12:51:55.844294
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_case_0()


# Generated at 2022-06-25 12:52:02.181907
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('.')

    assert not AnsibleCollectionRef.is_valid_fqcr('namespace.collection')
    assert not AnsibleCollectionRef.is_valid_fqcr('namespace_collection.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('namespacecollection.resource')

    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.resource', 'module')
    assert not AnsibleCollectionRef.is_valid_fqcr('namespace.collection.resource', 'some_invalid_type')



# Generated at 2022-06-25 12:52:08.120466
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    AnsibleCollectionRef("namespace.collection", "subdir1.subdir2.subdir3", "some.py", "module")
    AnsibleCollectionRef("namespace.collection", None, "some.py", "module")
    AnsibleCollectionRef("namespace.collection", "", "some.py", "module")
    AnsibleCollectionRef("namespace.collection", "", "some.py", "role")

    AnsibleCollectionRef("namespace.collection", "subdir1.subdir2.subdir3", "some.yml", "playbook")
    AnsibleCollectionRef("namespace.collection", None, "some.yml", "playbook")
    AnsibleCollectionRef("namespace.collection", "", "some.yml", "playbook")


# Generated at 2022-06-25 12:52:12.692862
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Create object ansible_collection_finder_0
    ansible_collection_finder_0 = _AnsibleCollectionFinder()

    # Create object path_hook_finder_0
    path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder=ansible_collection_finder_0, pathctx='/path/to/collection')

    # Invoke method find_module
    result_0 = path_hook_finder_0.find_module("test_ansible_collections")


# Generated at 2022-06-25 12:52:18.152408
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # instantiate variables
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.myns.mycoll.plugins.parsing', path_list=['/home/ansible/ansible/plugins', '/etc/ansible/plugins/modules'])
    # is_package()
    assert ansible_collection_pkg_loader_base_0.is_package('ansible_collections.myns.mycoll.plugins.parsing') == True


# Generated at 2022-06-25 12:52:24.037157
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():

    # Test Code
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(fullname='stdlib.prepare_vars',path_list=['/home/pjq/.ansible/collections/ansible_collections/hudson/plugin'])
    filename = ansible_collection_pkg_loader_base_0.get_filename(fullname='stdlib.prepare_vars')
    print(filename)


# Generated at 2022-06-25 12:52:25.792047
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    ansible_collection_root_pkg_loader_0 = _AnsibleCollectionRootPkgLoader(fullname='ansible_collections', path_list=['/usr/share/ansible/collections'])


# Generated at 2022-06-25 12:52:56.541263
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # test correct fqcr
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(
        'ansible.test.test_collection.test_module', 'module')
    assert ansible_collection_ref.collection == 'ansible.test_collection'
    assert ansible_collection_ref.subdirs == 'test'
    assert ansible_collection_ref.ref_type == 'module'
    assert ansible_collection_ref.resource == 'test_module'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.ansible.test_collection'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.ansible.test_collection.plugins.test.module'

# Generated at 2022-06-25 12:53:04.236455
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # TODO: some of these likely need to be updated if/when we support directory redirects
    base_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.other.empty_pkg', ['/tmp/ansible-test-pkgs/other/empty_pkg'])
    base_loader.load_module('ansible_collections.other.empty_pkg')
    assert_equal(base_loader._fullname, 'ansible_collections.other.empty_pkg')

    base_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.other.empty_init_pkg', ['/tmp/ansible-test-pkgs/other/empty_init_pkg'])
    base_loader.load_module('ansible_collections.other.empty_init_pkg')

# Generated at 2022-06-25 12:53:12.621671
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    module_attrs = dict(
        __loader__=None,
        __file__='<bogus>',
        __package__='this.is.a.package',
    )
    with _AnsibleCollectionPkgLoaderBase._new_or_existing_module('this.is.a.module', **module_attrs) as module:
        assert module.__loader__ is None
        assert module.__file__ == '<bogus>'
        assert module.__package__ == 'this.is.a.package'
        sys.modules.pop('this.is.a.module')
    # no exception thrown from the with block means we didn't fail.
    assert module.__loader__ is None
    assert module.__file__ == '<bogus>'

# Generated at 2022-06-25 12:53:18.860678
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    _meta_yml_to_dict = to_text

    # _AnsibleCollectionPkgLoader.__init__(*args: object, **kwargs: object) -> None
    # _AnsibleCollectionPkgLoader.load_module(*args: object, **kwargs: object) -> object
    # _AnsibleCollectionPkgLoader.load_module(*args: object, **kwargs: object) -> object

# Generated at 2022-06-25 12:53:23.755189
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref = AnsibleCollectionRef('namespace_name.collection_name', 'subdir', 'resource', 'module')
    # The __repr__() method returns a printable representation of the object.
    # A string is returned in "``" quotes if no argument is given.
    # Quote characters, backslashes and special characters are escaped with \.
    # However, at the interactive console, the output is displayed in quotes by the interactive console itself.
    # In this case, the returned string representation is displayed.
    ansible_collection_ref_repr = ansible_collection_ref.__repr__()
    assert ansible_collection_ref_repr == "AnsibleCollectionRef(collection='namespace_name.collection_name', subdirs='subdir', resource='resource')"


# Generated at 2022-06-25 12:53:33.732464
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.ping', None)
    mod = loader.load_module('ansible.builtin.ping')
    assert(len(mod.__path__) == 2)
    assert(mod.__path__[0] == os.path.join(os.path.dirname(import_module('ansible').__file__), 'lib/ansible/modules/core/system/ping'))
    assert(mod.__path__[1] == os.path.join(os.path.dirname(import_module('ansible').__file__), 'lib/ansible/modules/legacy/core/system/ping'))


# Generated at 2022-06-25 12:53:38.476265
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ac_loader_base = _AnsibleCollectionPkgLoaderBase("test_module")
    ac_loader_base._source_code_path = to_bytes("/home/jdoe/module_source.py")
    code_obj = ac_loader_base.get_code("test_module")
    assert(code_obj)


# Generated at 2022-06-25 12:53:47.030431
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', 'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource', 'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource.py', 'playbook') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.subdir3.resource.py', 'playbook') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('subdir1.subdir2.subdir3.resource.py', 'playbook') is None
    assert AnsibleCollectionRef.try_parse_

# Generated at 2022-06-25 12:53:50.869602
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_collection_package = 'ansible_collections.some_namespace.some_name'
    module = importlib.import_module(test_collection_package)
    collection_metadata = module._collection_meta
    assert collection_metadata != None


# Generated at 2022-06-25 12:53:58.743970
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    collection_fullname='ansible_collections.my_namespace.my_collection'
    path = ['/var/lib/awx/venv/ansible/lib/python3.6/site-packages/ansible_collections/my_namespace/my_collection/my_namespace/my_collection']
    loader = _AnsibleCollectionPkgLoaderBase(collection_fullname,path)
    print(loader.get_filename(collection_fullname))
    print(loader)
    print(loader.is_package(collection_fullname))


# Generated at 2022-06-25 12:54:27.512501
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():

    ansible_collection_finder = _AnsibleCollectionFinder()

    # Test for method find_module of class _AnsibleCollectionFinder if fullname = ansible
    # ----------------------------------------------------------------------------------
    # Test if the method return None when loading a module in 'ansible' package
    # Case 1 : fullname = ansible, path = None
    # Case 2 : fullname = ansible, path = []
    # Case 3 : fullname = ansible, path = ['foo']
    # Case 4 : fullname = ansible, path = 'foo'

    # Case 1 : fullname = ansible, path = None
    # ---------------------------------------
    path_1 = None
    loader_1 = ansible_collection_finder.find_module('ansible', path=path_1)
    assert loader_1 is None

    # Case 2 : fullname =

# Generated at 2022-06-25 12:54:30.479863
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase(None)
    try:
        print(ansible_collection_pkg_loader_0.get_filename('garbage'))
    except:
        pass


# Generated at 2022-06-25 12:54:41.786110
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    '''
    test for get_source

    :return:
    '''
    abs_path = os.path.dirname(os.path.abspath(__file__))
    base_path = os.path.dirname(abs_path)
    namespace = 'ansible_collections'
    collection = 'hp'
    plugin = 'modules'
    plugin_path = namespace + '.' + collection + '.' + plugin
    plugin_path_0 = os.path.join(base_path, namespace, collection, plugin)

    print('\n')
    print(plugin_path_0)
    print('\n')

    loader = _AnsibleCollectionPkgLoaderBase(plugin_path, [base_path])
    print(loader.get_source(plugin_path))


# Generated at 2022-06-25 12:54:49.417690
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:54:51.772490
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    assert(_AnsibleCollectionPkgLoaderBase(None).is_package(None) == False)
    assert(_AnsibleCollectionPkgLoaderBase(None, None).is_package(None) == False)


# Generated at 2022-06-25 12:54:58.188390
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_case_input_0 = "module_utils"
    test_case_ref_type_output_0 = "_AnsibleCollectionFinder.legacy_plugin_dir_to_plugin_type(test_case_input_0)"
    test_case_output_0 = test_case_ref_type_output_0
    assert test_case_output_0 == "module_utils", test_case_output_0


# Generated at 2022-06-25 12:55:08.756493
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref1 = AnsibleCollectionRef.from_fqcr('test.test_col.test_rsc', 'role')
    assert ref1.collection == 'test.test_col'
    assert ref1.ref_type == 'role'
    assert ref1.resource == 'test_rsc'
    assert ref1.n_python_package_name == 'ansible_collections.test.test_col.roles.test_rsc'

    ref2 = AnsibleCollectionRef.from_fqcr('test.test_col.test_rsc.yml', 'playbook')
    assert ref2.collection == 'test.test_col'
    assert ref2.resource == 'test_rsc.yml'

# Generated at 2022-06-25 12:55:15.808859
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = ansible_ref_type = None

    # from_fqcr: ns.coll.resource
    ref = 'ns.coll.resource'
    ansible_ref_type = 'module'
    assert AnsibleCollectionRef.from_fqcr(ref, ansible_ref_type).n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert AnsibleCollectionRef.from_fqcr(ref, ansible_ref_type).n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert AnsibleCollectionRef.from_fqcr(ref, ansible_ref_type).fqcr == 'ns.coll.resource'

# Generated at 2022-06-25 12:55:21.764373
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr(u'a_namespace.a_collection.a_resource', u'module')
    assert AnsibleCollectionRef.try_parse_fqcr(u'a_namespace.a_collection.a_resource.yml', u'playbook')
    assert AnsibleCollectionRef.try_parse_fqcr(u'a_namespace.a_collection.a_resource', u'playbook')
    assert not AnsibleCollectionRef.try_parse_fqcr(u'a_namespace.a_collection.a_resource.yml', u'role')
    assert AnsibleCollectionRef.try_parse_fqcr(u'a_namespace.a_collection.rolename', u'role')

# Generated at 2022-06-25 12:55:32.152599
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # Test for case of toplevel_pkg
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths([])
    fullname_0 = "ansible"
    path_0 = None
    m_0 = ansible_collection_finder_0.find_module(fullname_0, path_0)
    assert isinstance(m_0, _AnsibleInternalRedirectLoader)

    # Test for case of part_count == 1
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    ansible_collection_finder_1.set_playbook_paths([])
    fullname_1 = "ansible"
    path_1 = []

# Generated at 2022-06-25 12:56:13.127027
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    test_data = [
        "ns.coll.resource",
        "ns.coll.rolename",
        "ns.coll.subdir1.resource",
        "ns.coll.subdir1.rolename",
        "ns.coll.subdir1.subdir2.resource",
        "ns.coll.subdir1.subdir2.rolename",
        "ns.coll.subdir1.subdir2.rolename.yml",
        "ns.coll.subdir1.subdir2.rolename.yaml",
        "ns.coll.subdir1.subdir2.rolename.plb",
    ]

    result = []

# Generated at 2022-06-25 12:56:24.456748
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-25 12:56:32.212597
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    file_content = "test_module_0_0"
    cur_dir = os.getcwd()
    test_dir = os.path.join(cur_dir, "ansible_collections")

# Generated at 2022-06-25 12:56:43.066904
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ansible_collection_ref_0 = AnsibleCollectionRef.is_valid_fqcr('a.b.c.d')
    assert ansible_collection_ref_0 == True
    ansible_collection_ref_1 = AnsibleCollectionRef.is_valid_fqcr('a.b.c.d', 'roles')
    assert ansible_collection_ref_1 == True
    ansible_collection_ref_2 = AnsibleCollectionRef.is_valid_fqcr('a', 'roles')
    assert ansible_collection_ref_2 == False
    ansible_collection_ref_3 = AnsibleCollectionRef.is_valid_fqcr('a.b', 'roles')
    assert ansible_collection_ref_3 == False
    ansible_collection_ref_4 = AnsibleCollectionRef.is_

# Generated at 2022-06-25 12:56:52.769256
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    acp0 = 'ansible_collections.cisco.asa.plugins.modules.asa_file_copy'
    prefix = 'ansible_collections.cisco.asa.plugins.modules'
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(acp0, [to_native('tests/data/ansible_collections/cisco/asa/plugins')])
    ansible_collection_pkg_loader_base_0._get_subpackage_search_paths = lambda x: ['/home/rverma/repos/ansible/ansible/lib/ansible/modules/network/asa']
    ansible_collection_pkg_loader_base_0._get_candidate_paths = lambda x: x

    # test IterModules
    actual = ansible_collection_pkg

# Generated at 2022-06-25 12:57:02.269298
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    print("\n====== test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type starts ======")

# Generated at 2022-06-25 12:57:09.822666
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    AnsibleCollectionRef_test = AnsibleCollectionRef('ansible.collections.test1', 'plugins.testtype', 'testresource',
                                                     'test')

    assert AnsibleCollectionRef_test.collection == 'ansible.collections.test1'
    assert AnsibleCollectionRef_test.subdirs == 'plugins.testtype'
    assert AnsibleCollectionRef_test.resource == 'testresource'
    assert AnsibleCollectionRef_test.ref_type == 'test'

#  Unit test for the list_collection_folders() method.

# Generated at 2022-06-25 12:57:13.933798
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(self=None, fullname='ansible_collections.namespace.collection', path_list=[])
    ansible_collection_pkg_loader_base_0.is_package('ansible_collections.namespace.collection')


# Generated at 2022-06-25 12:57:16.105173
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader()
    print(ansible_internal_redirect_loader_0.load_module())


# Generated at 2022-06-25 12:57:23.355394
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:58:00.456603
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # TODO: figure out how to test this for code coverage
    # TODO: figure out how to inject a mock PY3 file finder

    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, '/test_path_hook_context')

    fullname_0 = 'test_fullname_0'
    find_module_0 = ansible_path_hook_finder_0.find_module(fullname_0)

    assert find_module_0 is not None


# Generated at 2022-06-25 12:58:06.662791
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test constructor with correct parameters
    ansible_collection_ref = AnsibleCollectionRef('ns.engine', None, 'engine', 'module_utils')
    assert ansible_collection_ref.collection == 'ns.engine'
    assert ansible_collection_ref.subdirs == ''
    assert ansible_collection_ref.resource == 'engine'
    assert ansible_collection_ref.ref_type == 'module_utils'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.ns.engine'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.ns.engine.plugins.module_utils'
    assert ansible_collection_ref.fqcr == 'ns.engine.engine'

    # test constructor with some incorrect parameters
   

# Generated at 2022-06-25 12:58:09.363277
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder = _AnsibleCollectionFinder()
    # unit-test example not working
    assert ansible_collection_finder.find_module(fullname='sample') is None


# Generated at 2022-06-25 12:58:20.453407
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == ''
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.fqcr == 'ns.coll.resource'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1'

# Generated at 2022-06-25 12:58:26.998615
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test data
    collection_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.pkg', path_list=[
        '/path/to/ansible_collections',
        '/path/to/ansible_collections/ns',
        '/path/to/ansible_collections/ns/pkg',
        '/path/to/ansible_collections/ns/pkg/subpkg',
    ])
    os.makedirs('/path/to/ansible_collections/ns/pkg/subpkg')
    path = mkdtemp()

    # Test cases
    # Case 1: module name starts with the specified prefix
    with open(os.path.join(path, 'amodule.py'), 'wt') as f:
        f.write('a = 3')

# Generated at 2022-06-25 12:58:37.120036
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.test.test_collection.test_plugin',
        path_list=[os.path.join(os.getcwd(), 'test_data/collection_collection_plugin')]
    )

    source = loader.get_source(fullname='ansible_collections.test.test_collection.test_plugin')
    expected_result = '#!/usr/bin/python\n\n"""\n  test_plugin\n"""\n\n\ndef test():\n    pass\n\n'
    assert source == expected_result


# Generated at 2022-06-25 12:58:44.248847
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Define inputs
    path_list = [
        '/Users/username/Projects/ansible/ansible-devel/lib/ansible/ansible_collections/jdauphant/net_tools/plugins/action'
    ]
    fullname = 'ansible_collections.jdauphant.net_tools.plugins.action.cliconf_config'
    # Execute the function
    return _AnsibleCollectionPkgLoaderBase(fullname, path_list).get_code(fullname)


# Generated at 2022-06-25 12:58:53.665119
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # TODO: this needs to actually unit test _AnsibleCollectionPkgLoaderBase.iter_modules()
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')
    assert loader.iter_modules(prefix='ansible_collections.foo.bar') == []
    # return empty list for non-existent path
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=['/does/not/exist'])
    assert loader.iter_modules(prefix='ansible_collections.foo.bar') == []
    # return empty list for a synthetic package

# Generated at 2022-06-25 12:59:04.336477
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # ansible_collections.ns.coll.plugins.some_plugin_type.resource
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr('ns.coll.some_plugin_type.resource','some_plugin_type')
    # ansible_collections.ns.coll.plugins.some_plugin_type.subdir1.subdir2.resource
    ansible_collection_ref_1 = AnsibleCollectionRef.from_fqcr('ns.coll.some_plugin_type.subdir1.subdir2.resource','some_plugin_type')
    # ansible_collections.ns.coll.roles.resource
    ansible_collection_ref_2 = AnsibleCollectionRef.from_fqcr('ns.coll.resource','role')
    # ansible_collections.ns.coll.

# Generated at 2022-06-25 12:59:08.451441
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    path_list = []
    _ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('x', path_list)
    try:
        _ansible_internal_redirect_loader_0.load_module('x')
        assert True
    except Exception as ex:
        assert False
