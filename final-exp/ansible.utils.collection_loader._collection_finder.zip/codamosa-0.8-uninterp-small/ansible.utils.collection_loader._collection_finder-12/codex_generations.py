

# Generated at 2022-06-25 12:51:39.301351
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(bytes_0, [])
    str_0 = ansible_internal_redirect_loader_0.load_module(bytes_0)
    assert str_0 is None

# Generated at 2022-06-25 12:51:45.629297
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(bytes_0)
    ansible_collection_pkg_loader_base_0.__repr__()


# Generated at 2022-06-25 12:51:54.515846
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    ansible_collection_loader_0 = _AnsibleCollectionLoader(bytes_0)
    _AnsibleCollectionPkgLoaderBase_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.somens.plugins.modules", [['/usr/local/lib/python3.6/dist-packages']])
    _AnsibleCollectionPkgLoaderBase_0._subpackage_search_paths = ['/usr/local/lib/python3.6/dist-packages/ansible_collections/somens/plugins/modules']
    ansible_collection_loader_0._subpackage_search_paths = _AnsibleCollectionPkgLoaderBase_0._sub

# Generated at 2022-06-25 12:51:59.748382
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    try:
        _AnsibleCollectionFinder._remove()
        assert(AnsibleCollectionConfig.collection_finder is None)
        paths = [b'/tmp/test_path']
        _AnsibleCollectionFinder(paths)
    except ImportError as e:
        raise AssertionError('Could not instantiate _AnsibleCollectionFinder due to %s' % e)
    _AnsibleCollectionFinder._remove()


# Generated at 2022-06-25 12:52:10.750677
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    bytes_1 = b'\xe0\n\xd9\xa05\x0b\x11\x1d\x7f\xb1'
    bytes_2 = b'\xe0\nH\x0f\x17\x1f;\xa2\xcd\xe0\x91\x03'
    bytes_3 = b'\xe0\n\x87U\xdf\xe8\xb8\x17\xa6\xdb'
    bytes_4 = b'\xe0\n+\x97\x8e\x9e2\xb1\xe2\x18\xfc'
    list_0 = []
   

# Generated at 2022-06-25 12:52:18.110677
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:52:25.305423
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Instantiate a class object for _AnsibleCollectionPkgLoaderBase
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    _AnsibleCollectionPkgLoaderBase_0 = _AnsibleCollectionPkgLoaderBase(bytes_0, path_list=None)

    # Call method get_code of _AnsibleCollectionPkgLoaderBase_0
    _AnsibleCollectionPkgLoaderBase_0._AnsibleCollectionPkgLoaderBase__synthetic_filename(bytes_0)


# Generated at 2022-06-25 12:52:30.893378
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'

# Generated at 2022-06-25 12:52:34.232860
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(b'/test/test_ansible_collections.py', [bytes_0])
    assert isinstance(ansible_collection_pkg_loader_base_0.get_code(b'/test/test_ansible_collections.py'), (None, types.CodeType)), "Should return a CodeType or None"


# Generated at 2022-06-25 12:52:39.596620
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    bytes_0 = b'\\\x0f\\\xa0\x1a\xbd\xbd\x02\x9b\x9d\x0e\x1c\x03\x17%\xbcq*\xae\xac\x9f\xe8\x0e\x91\x96\x04\x8e\xda\xdf\xad\x96\xdc\xc5\x19'
    ansible_collection_loader_0 = _AnsibleCollectionLoader(bytes_0)
    ansible_collection_loader_0.find_module('ansible_collections.local.testns.testcoll.plugins.module_utils')

# Generated at 2022-06-25 12:53:09.628761
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader(
        fullname = 'ansible',
        path_list = ['ansible.builtin.meta', 'ansible.builtin.meta'],
    )
    loader.load_module()

# Test case for method load_module of class _AnsibleInternalRedirectLoader

# Generated at 2022-06-25 12:53:15.909678
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # Note: _AnsibleCollectionNSPkgLoader has class attributes, we test them by running its methods with a specific class
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    bytes_1 = b'\xb2\x8e\x15\x18\x83\xce\xbb\xc7\xe1Qn\xa7\x8c'
    # bytes_0 uses 0xfc as part of its data, xunta_bytecode_has_modifier_0xfc() returns true
    xunta_bytecode_has_modifier_0xfc = True
    # bytes_0 has no 0xfc, xunta_bytecode_has_modifier_0xfc() returns false
    xunta_bytecode_has

# Generated at 2022-06-25 12:53:18.655944
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    args = {"path": b"\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc"}
    result = _AnsibleCollectionPkgLoaderBase.get_data(**args)
    assert result is None


# Generated at 2022-06-25 12:53:23.603846
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    fullname = 'ansible.builtin'
    path_list = '/tmp'
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)
    assert(loader._fullname == fullname)
    assert(loader._path_list == [path_list])
    assert(loader._path_mtime == -1)
    assert(loader._data == None)



# Generated at 2022-06-25 12:53:28.781488
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    input0 = ['./test_cases/test_case_0/test_case_0_input', 'is_package']
    inst_0 = _AnsibleCollectionLoader(*input0)


# Generated at 2022-06-25 12:53:36.400892
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    case_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    case_0._source_code_path = '/Users/paulthomson/Desktop/ansible_collections/ansible_collections/somens/__init__.py'
    case_0._subpackage_search_paths = ['/Users/paulthomson/Desktop/ansible_collections/ansible_collections/somens']
    filename = case_0.get_filename('ansible_collections')
    assert filename == '/Users/paulthomson/Desktop/ansible_collections/ansible_collections/somens/__init__.py'
    case_1 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    case_1

# Generated at 2022-06-25 12:53:38.717143
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    fullname = 'ansible_collections.for_test'
    path_list = ['/fake_path']
    loader = _AnsibleCollectionNSPkgLoader(fullname, path_list)
    assert loader


# Generated at 2022-06-25 12:53:44.427291
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    finder = _AnsibleCollectionFinder()
    str_0 = to_text('/tmp/ansible_collections/nmaullin_test_collection')
    str_1 = to_text('/tmp/ansible_collections/nmaullin_test_collection/plugins/module_utils/test_collection.py')
    ret = finder.find_module(str_0, str_1)
    assert ret == None

    # Unit test for method import_module of class _AnsibleCollectionFinder
    # Need to provide test for this.



# Generated at 2022-06-25 12:53:51.352548
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    _AnsibleCollectionPkgLoaderBase._source_code_path = 'random_file'
    _AnsibleCollectionPkgLoaderBase._module_file_from_path.__func__.__code__ = test_case_0.__code__
    _AnsibleCollectionPkgLoader._AnsibleCollectionPkgLoader__package_to_load = 'random_package'
    module = _AnsibleCollectionPkgLoader('random_package')
    assert module.load_module('random_package') == None


# Generated at 2022-06-25 12:53:54.714494
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    obj = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', ())
    assert isinstance(obj, _AnsibleInternalRedirectLoader)
    test_case_0()


# Generated at 2022-06-25 12:54:20.344974
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    pass


# Generated at 2022-06-25 12:54:25.433054
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    fullname = 'ansible_collections.foo'
    path_list = ['/Users/a/code/github/ansible/lib/ansible/collections']
    pkg_loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    result = pkg_loader.is_package(fullname)
    print(result)
    #assert result == expected


# Generated at 2022-06-25 12:54:32.450062
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    _AnsibleCollectionPkgLoader_instance = _AnsibleCollectionPkgLoader(bytes_0)
    test_case_0(bytes_0)
    _AnsibleCollectionPkgLoader_instance.load_module(bytes_0)


# Generated at 2022-06-25 12:54:34.541484
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    global bytes_0
    _AnsibleCollectionPkgLoaderBase.get_code(bytes_0)


# Generated at 2022-06-25 12:54:44.994981
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collections_path_hook_finder = _AnsiblePathHookFinder('/help')
    ansible_collections_path_hook_finder._pathctx = '/help'

# Generated at 2022-06-25 12:54:49.931600
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # NOTE: Auto-generated.
    # Function __repr__ should print the value of the fields in the class.
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'
    # self._fullname = fullname
    # self._redirect_module = None
    # self._split_name = fullname.split('.')
    # self._rpart_name = fullname.rpartition('.')
    # self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
    # self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens



# Generated at 2022-06-25 12:54:53.369111
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj_0 = AnsibleCollectionRef('collection_name', 'subdirs', 'resource', 'ref_type')
    assert obj_0.__repr__() == 'AnsibleCollectionRef(collection=\'collection_name\', subdirs=\'subdirs\', resource=\'resource\')'



# Generated at 2022-06-25 12:55:04.729369
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test to ensure we're always passing a prefix here
    prefix_0 = '#\x05D\x8a'
    bytes_0 = b'\xfc\xd8\x97\xfc\xab\xe5\x8d\xa3\x10K\x03\x0c\x0c\xe6\x17 b\x90E\x8e\xc9\xb0\xeb\x94\xe8\x07\xb7'

# Generated at 2022-06-25 12:55:10.227264
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    i = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', '')
    bytes_0 = b'\xe0\ni\xd5\x8frI\xca\x13\r\x02\xfc'

# Generated at 2022-06-25 12:55:13.963026
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_0 = u'ansible_collections.my_namespace.mycollection.linux.plugins.modules.ping'
    ref_type_0 = u'roles'
    ansible_collection_ref_0 = AnsibleCollectionRef.try_parse_fqcr(ref_0, ref_type_0)

    assert(ansible_collection_ref_0 != None)

# Generated at 2022-06-25 12:55:46.793325
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:55:54.349060
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'not_a_valid_ref_type')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.playbook')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.playbook', 'playbook')



# Generated at 2022-06-25 12:55:58.094601
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(fullname='ansible.z.test', path_list=None)
    _ansible_internal_redirect_loader_0.load_module(fullname='ansible.z.test')



# Generated at 2022-06-25 12:56:03.968356
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    pkgname = 'test_collection.test_ns.test_pkg'
    pkg_loader = _AnsibleCollectionPkgLoaderBase(fullname=pkgname, path_list=['fixtures/collection_artifact/test_collection/test_ns/test_pkg'])
    pkg_source = pkg_loader.get_source(fullname=pkgname)

    assert(pkg_source is not None)
    assert(pkg_source != '')


# Generated at 2022-06-25 12:56:08.788305
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    playbook_paths_0 = ['/home/igarciam/workspace/ansible/lib/ansible_collections/ansible/os_migrate/plugins/modules']
    ansible_collection_finder_0.set_playbook_paths(playbook_paths_0)


# Generated at 2022-06-25 12:56:19.794442
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # case 1
    collection_name = 'namespace0.collection0'
    subdirs = 'sub.dir0'
    resource = 'resource0'
    ref_type = 'module'
    ansible_collection_ref_obj1 = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert repr(ansible_collection_ref_obj1) == 'AnsibleCollectionRef(collection=\'namespace0.collection0\', subdirs=\'sub.dir0\', resource=\'resource0\')'
    assert ansible_collection_ref_obj1.collection == 'namespace0.collection0'
    assert ansible_collection_ref_obj1.fqcr == 'namespace0.collection0.sub.dir0.resource0'
    assert ansible_collection_ref_obj1

# Generated at 2022-06-25 12:56:28.390648
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_ref_test_case_0 = AnsibleCollectionRef.from_fqcr('ns.coll.res', 'module')
    assert isinstance(ansible_collection_ref_test_case_0, AnsibleCollectionRef)
    assert ansible_collection_ref_test_case_0.collection == 'ns.coll'
    assert ansible_collection_ref_test_case_0.subdirs == ''
    assert ansible_collection_ref_test_case_0.resource == 'res'

    ansible_collection_ref_test_case_1 = AnsibleCollectionRef.from_fqcr('ns.coll.resources', 'module')
    assert isinstance(ansible_collection_ref_test_case_1, AnsibleCollectionRef)
    assert ansible_collection_ref_test_case_1.collection

# Generated at 2022-06-25 12:56:32.078828
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    try:
        internal_redirect_loader = _AnsibleInternalRedirectLoader('ansible.plugins.action.command', ['/tmp'])
    except ImportError:
        return

    # We don't do any canonicalization on the redirect, so this is not a valid target
    assert internal_redirect_loader.load_module('ansible.plugins.action.command')



# Generated at 2022-06-25 12:56:42.913689
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr('ansible.builtin.sequence', 'filter')
    assert ref.fqcr == u'ansible.builtin.sequence'
    assert ref.collection == u'ansible.builtin'
    assert ref.subdirs == u''
    assert ref.resource == u'sequence'
    assert ref.ref_type == u'filter'
    assert ref.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    assert ref.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.filter.sequence'
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.builtin')

# Generated at 2022-06-25 12:56:52.624266
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _TestClass(object):
        def __init__(self, path_list, path):
            self._candidate_paths = _TestClass._get_candidate_paths(path_list, path)

        @staticmethod
        def _get_candidate_paths(path_list, path):
            return [os.path.join(p, path) for p in path_list]

        @staticmethod
        def get_data(path):
            data = None
            for p in _TestClass._candidate_paths:
                b_path = to_bytes(p)
                if os.path.isfile(b_path):
                    with open(b_path, 'rb') as fd:
                        data = fd.read()
                        break
            return data


# Generated at 2022-06-25 12:57:28.205057
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader_obj = _AnsibleInternalRedirectLoader('ansible.utils.collection_loader', None)
    assert isinstance(loader_obj, _AnsibleInternalRedirectLoader)


# Generated at 2022-06-25 12:57:38.015269
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():

    module_file_name = "__init__.py"
    module_name = "ansible_collections.ns.moduleA"

    # _module_file_from_path tested
    # get_code tested

    # Mock class _AnsibleCollectionPkgLoaderBase
    class _AnsibleCollectionPkgLoaderBaseMock(_AnsibleCollectionPkgLoaderBase):
        def _validate_final(self):
            pass

        def __init__(self, fullname, path_list=None):
            super(_AnsibleCollectionPkgLoaderBaseMock, self).__init__(fullname, path_list)

            # Mock values for _module_file_from_path()
            self._module_path = os.path.join(self._candidate_paths[0], module_file_name)


# Generated at 2022-06-25 12:57:45.906190
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    _collection_root_0 = "/tmp/ansible_collections_root_0"
    _collection_root_1 = "/tmp/ansible_collections_root_1"

    ansible_collection_path_hook_0 = _AnsiblePathHook([ansible_collection_path_hook_0],
                                                      ansible_collection_finder_0)

    os.mkdir(_collection_root_0)
    os.mkdir(_collection_root_1)

    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase(
        "ansible_collections.nti_linux.cp",
        path_list=[ansible_collection_path_hook_0, _collection_root_0, _collection_root_1]
    )

    module_iter = ansible_collection_pkg

# Generated at 2022-06-25 12:57:56.949021
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    t_paths = ['/home/project/ansible_collections/ns1/coll1/module1',
               '/home/project/ansible_collections/ns1/coll1/module2',
               '/home/project/ansible_collections/ns1/coll1/module3',
               '/home/project/ansible_collections/ns1/coll1/module4',
               '/home/project/ansible_collections/ns1/coll2']
    t_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns1.coll1', t_paths)
    assert t_loader.iter_modules('') == ['module1', 'module2', 'module3', 'module4']


# Generated at 2022-06-25 12:58:00.611919
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('test_collection', 'subdir1.subdir2', 'testmodule', 'module')
    assert repr(ref) == 'AnsibleCollectionRef(collection=\'test_collection\', subdirs=\'subdir1.subdir2\', resource=\'testmodule\')'


# Generated at 2022-06-25 12:58:10.139148
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for empty file
    base_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.yamlet.yamlet', path_list=['/tmp/playbooks/'])
    base_loader._source_code_path = '/tmp/playbooks/yamlet'
    assert base_loader.get_data('test.py') == None
    # Test for empty file and dir
    base_loader._source_code_path = '/tmp/playbooks/yamlet/test/'
    assert base_loader.get_data('test.py') == None
    # Test for file that should be where it should be
    base_loader._source_code_path = '/tmp/playbooks/yamlet/test.py'
    assert base_loader.get_data('test.py') == None
    assert base

# Generated at 2022-06-25 12:58:14.178548
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    collection_ref = AnsibleCollectionRef("namespace.collection", "subdir1.subdir2", "resource", "module")
    assert collection_ref


# Generated at 2022-06-25 12:58:21.974392
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # create mock object for test
    _AnsiblePathHookFinder_obj = _AnsiblePathHookFinder(ansible_collection_finder_0, 'usr/lib/python3.7/site-packages/ansible_collections')
    # call method find_module on the mock object
    _AnsiblePathHookFinder_ret_val = _AnsiblePathHookFinder_obj.find_module(fullname='ansible_collections.tougho.tougher', path=None)
    # check value returned
    assert(_AnsiblePathHookFinder_ret_val is None)



# Generated at 2022-06-25 12:58:27.725246
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:58:35.342493
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # create a test instance of _AnsibleCollectionFinder
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # verify that find_module returns None when fullname is not ansible_collections
    assert ansible_collection_finder_0.find_module('not_ansible_collections') is None, 'incorrect return value'

    # create a second test instance of _AnsibleCollectionFinder
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    # verify that find_module returns None when fullname is not ansible_collections
    assert ansible_collection_finder_1.find_module('not_ansible_collections', []) is None, 'incorrect return value'


# Generated at 2022-06-25 13:00:02.969367
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase()
    source_code = loader.get_source('test_name')
    loader.get_code('test_name')

# Generated at 2022-06-25 13:00:12.424610
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test case 1
    test_case_1 = AnsibleCollectionRef("namespace.collection", "subdir1.subdir2", "mymodule", "module")
    result_actual = test_case_1.__repr__()
    result_expected = 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'subdir1.subdir2\', resource=\'mymodule\')'
    if result_actual != result_expected:
        raise Exception("Failed test_AnsibleCollectionRef___repr__ (1)")

    # Test case 2
    test_case_2 = AnsibleCollectionRef("namespace.collection", "subdir1.subdir2", "mymodule", "module")
    result_actual = test_case_2.__repr__()

# Generated at 2022-06-25 13:00:17.848604
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
    ansible_collection_finder_0._install()
    ansible_collection_finder_0.set_playbook_paths(playbook_paths=None)
    import_module('ansible_collections')
    assert isinstance(sys.modules['ansible_collections'], ModuleType)
    assert sys.modules['ansible_collections'].__name__ == 'ansible_collections'
    assert sys.modules['ansible_collections'].__package__ == ''
    assert sys.modules['ansible_collections'].__path__ == []
    import_module('ansible_collections.somens')