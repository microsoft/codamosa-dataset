

# Generated at 2022-06-25 12:51:35.794022
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(None, None)
    try:
        # Python 3.6+
        import importlib.util
        file_finder_module = importlib.util.find_spec('FileFinder')
        if file_finder_module is not None:
            module_path = file_finder_module.origin
            path_hook_finder_0 = ansible_path_hook_finder_0.find_module('FileFinder', [module_path])
    except (ImportError, AttributeError):
        # Python <= 3.5
        path_hook_finder_0 = ansible_path_hook_finder_0.find_module('FileFinder', [
            '/usr/lib/python3.5/importlib/machinery.py'])

# Generated at 2022-06-25 12:51:43.556986
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():

    # instantiation of loader with empty package.
    loader_0 = _AnsibleCollectionPkgLoaderBase('tmp.ansible_collections.tmp', ['/tmp/ansible'])
    # instantiation of loader with non-empty package.
    loader_1 = _AnsibleCollectionPkgLoaderBase('tmp.ansible_collections.tmp.plugins', ['/tmp/ansible'])

    # test for empty package.
    try:
        # trigger the exception
        loader_0.load_module('tmp.ansible_collections.tmp')
    except Exception as e:
        assert isinstance(e, ImportError)
    else:
        raise Exception("ImportError should be raised.")

    # test for non-empty package.

# Generated at 2022-06-25 12:51:53.382885
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action', "incorrect type returned"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache') == 'cache', "incorrect type returned"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules', "incorrect type returned"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doctest_plugins') == 'doc_fragments', "incorrect type returned"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup', "incorrect type returned"

# Generated at 2022-06-25 12:51:54.568617
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr("testing.collection.module") == True


# Generated at 2022-06-25 12:51:59.248451
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    try:
        ansible_collection_finder_0.find_module("ansible")
        assert("ansible" in sys.modules)
    except ImportError:
        assert("ansible" not in sys.modules)
    ansible_collection_finder_0._remove()


# Generated at 2022-06-25 12:52:03.372510
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase("ansible_collections.somens.somens_collection")
    assert ansible_collection_pkg_loader_base.get_filename("ansible_collections.somens.somens_collection") == \
           "/mnt/c/Users/johan/Documents/test_testplans/test_testplan/../test_testplan/ansible_collections/somens/somens_collection"


# Generated at 2022-06-25 12:52:06.253726
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():

    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths(['collections'])


# Generated at 2022-06-25 12:52:13.825666
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.test_collection')
    ansible_collection_loader_base_0._subpackage_search_paths = '/Users/zhuangshuo/dev/ansible/playbook/collections/ansible_collections/ns/test_collection'
    assert ansible_collection_loader_base_0.__repr__() == "_AnsibleCollectionPkgLoaderBase(path='/Users/zhuangshuo/dev/ansible/playbook/collections/ansible_collections/ns/test_collection')"


# Generated at 2022-06-25 12:52:19.361994
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    dirpath = "/tmp/ansible"
    ld = _AnsibleCollectionPkgLoaderBase("fullname", path_list= [dirpath])
    ld._source_code_path = dirpath
    assert ld.get_source('fullname') == None


# unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:52:23.836113
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    loader = _AnsibleCollectionPkgLoader(3, ['ansible_collections'])
    with pytest.raises(ValueError):
        loader.load_module('ansible_collections')
    with pytest.raises(ValueError):
        loader.load_module('ansible_collections.ns.package')


# Generated at 2022-06-25 12:53:00.886356
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    fqcr_0 = AnsibleCollectionRef.from_fqcr("col1.mod1", "module")
    assert fqcr_0.collection == "col1"
    assert fqcr_0.subdirs == u''
    assert fqcr_0.resource == "mod1"
    assert fqcr_0.ref_type == u'module'
    assert fqcr_0._fqcr == "col1.mod1"
    assert fqcr_0.n_python_collection_package_name == "ansible_collections.col1"
    assert fqcr_0.n_python_package_name == "ansible_collections.col1.plugins.module.mod1"


# Generated at 2022-06-25 12:53:02.498630
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    ansible_collection_loader_0 = _AnsibleCollectionLoader('', '', '', '', '')



# Generated at 2022-06-25 12:53:04.764945
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader('ansible.module_utils.parsing.convert_bool', [])

# Run all tests

# Generated at 2022-06-25 12:53:13.016865
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    """
    Given a list of packages generate expected output
    :return:
    """
    import ansible_collections

    # in the normal case, we have a flat hierarchy
    collection_0 = ansible_collections.ns1
    package_list = ['pkg0', 'pkg1']
    expected_output = [('ns1', 'pkg0', True), ('ns1', 'pkg1', True)]
    assert [p for p in collection_0.__loader__.iter_modules(prefix='ns1.')] == expected_output

    # in the nested case, we also have nested packages
    collection_1 = ansible_collections.ns2
    package_list = ['pkg0', 'pkg1', 'pkg2']


# Generated at 2022-06-25 12:53:17.176999
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    ansible_collection_finder_1._install()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_1, '/home/vagrant/test_ansible_collections')
    ansible_path_hook_finder_0.find_module('ansible_collections.ansible.netcommon.plugins.modules.na_elementsw_host')
    ansible_path_hook_finder_0.find_module('ansible_collections.ansible.netcommon.plugins.modules.na_elementsw_host', '/home/vagrant/test_ansible_collections')

# Generated at 2022-06-25 12:53:21.797860
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Successfully parse a collection name
    result = AnsibleCollectionRef.try_parse_fqcr("namespace.colname", "module")
    assert result is not None
    assert result.fqcr == "namespace.colname"
    assert result.resource == "colname"
    assert result.n_python_package_name == "ansible_collections.namespace.colname"
    assert result.n_python_collection_package_name == "ansible_collections.namespace.colname"
    assert result.collection == "namespace.colname"
    assert result.ref_type == "module"
    assert result.resource == "colname"

    result = AnsibleCollectionRef.try_parse_fqcr("namespace.colname.test", "module")
    assert result is not None

# Generated at 2022-06-25 12:53:33.226007
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():

    # Case where package_to_load is 'test' and parent_package_name is 'ansible_collections'
    collection_loader_0 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test')
    if collection_loader_0.get_filename('ansible_collections.test'):
        raise AssertionError('Failed when package_to_load is \'test\' and parent_package_name is \'ansible_collections\'')

    # Case where package_to_load is 'test_subpackage' and parent_package_name is 'ansible_collections.test'
    # Test where a __synthetic__ file is created (which is the case when a collection is in a directory and that
    # directory is not named '__init__.py')
    collection_loader_1 = _An

# Generated at 2022-06-25 12:53:38.479912
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    assert ansible_collection_finder_0._ansible_pkg_path == os.path.dirname(os.path.dirname(__file__))
    assert ansible_collection_finder_0._n_configured_paths == []
    assert ansible_collection_finder_0._n_cached_collection_paths == None
    assert ansible_collection_finder_0._n_cached_collection_qualified_paths == None
    assert ansible_collection_finder_0._n_playbook_paths == []


# Generated at 2022-06-25 12:53:47.072903
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # Testcase 1: Check if valid collection reference is parsed correctly
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir.module', 'module').fqcr == 'ns.coll.subdir.module'
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.module', 'module').fqcr == 'ns.coll.module'
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role').fqcr == 'ns.coll.rolename'

    # Testcase 2: Check if invalid collection reference is parsed correctly
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.module', 'role') is None

# Generated at 2022-06-25 12:53:52.246307
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('', [''])
    ansible_collection_pkg_loader_base_0.load_module('ansible_collections')
    ansible_collection_pkg_loader_base_0.load_module('ansible_collections.ansible_collections')


# Generated at 2022-06-25 12:54:40.598562
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_loader_obj = _AnsibleCollectionPkgLoader('ansible.collections.test_namespace.test_collection', 'test_loader', 'sample_data_0')
    ansible_collection_loader_obj.load_module()


# Generated at 2022-06-25 12:54:45.604244
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # make sure package root
    acplb = _AnsibleCollectionPkgLoaderBase('ansible_collections')
    assert acplb.is_package('ansible_collections')
    assert acplb.get_code('ansible_collections') is None
    assert acplb.get_source('ansible_collections') is None



# Generated at 2022-06-25 12:54:47.621426
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('name')
    ret = ansible_collection_pkg_loader_base.get_filename('name')
    assert ret == None


# Generated at 2022-06-25 12:54:54.666886
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref_0 = AnsibleCollectionRef('test_0.test_collection', '', 'mytest', 'module')
    assert ansible_collection_ref_0.collection == 'test_0.test_collection'
    assert ansible_collection_ref_0.subdirs == ''
    assert ansible_collection_ref_0.resource == 'mytest'

    ansible_collection_ref_1 = AnsibleCollectionRef('test_1.test_collection', 'subdir1', 'mytest', 'action')
    assert ansible_collection_ref_1.collection == 'test_1.test_collection'
    assert ansible_collection_ref_1.subdirs == 'subdir1'
    assert ansible_collection_ref_1.resource == 'mytest'


# Generated at 2022-06-25 12:55:05.318073
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    r1 = AnsibleCollectionRef("foo.bar", "baz", "qux", "module")
    r2 = AnsibleCollectionRef("foo.baz", "qux.quux", "corge", "module")
    r3 = AnsibleCollectionRef("moo.boo", "", "moo", "role")
    r4 = AnsibleCollectionRef("moo.zoo", None, "boo", "playbook")
    r5 = AnsibleCollectionRef("moo.zoo", "boo.bar", "baz", "playbook")
    r6 = AnsibleCollectionRef.from_fqcr("moo.zoo.boo.bar.baz.yml", "playbook")

    assert r1.collection == "foo.bar"
    assert r1.subdirs == "baz"


# Generated at 2022-06-25 12:55:13.869348
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test 1:
    # Test for origin value of variable fullname in parameter
    # Expecting to raise ValueError
    try:
        ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.subns', path_list=['/home/somens'])
        ansible_collection_pkg_loader_base_0.is_package('ansible_collections.somewrongns')
        raise Exception('Expecting ValueError')
    except ValueError:
        pass

    # Test 2:
    # Test for origin value of variable self._fullname
    # Expecting to return True

# Generated at 2022-06-25 12:55:18.224627
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    for lpdn in LegacyPluginDirs:
        plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(lpdn)
        assert plugin_type in ('action', 'become', 'cache', 'callback', 'cliconf',
                               'connection', 'doc_fragments', 'filter', 'httpapi',
                               'inventory', 'lookup', 'module_utils', 'modules',
                               'netconf', 'shell', 'strategy', 'terminal', 'vars')


# Generated at 2022-06-25 12:55:20.829229
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert _AnsibleInternalRedirectLoader('ansible.module_utils.foo', 'ansible_collections.namespace1.collection1')


# Generated at 2022-06-25 12:55:24.871809
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collection_finder = _AnsibleCollectionFinder()
    pathhook_finder = _AnsiblePathHookFinder(ansible_collection_finder, '/home/usr/sanity/collection')
    assert isinstance(pathhook_finder, _AnsiblePathHookFinder)
    # Test for find_module method
    assert pathhook_finder.find_module('ansible_collections.ansible') == None


# Generated at 2022-06-25 12:55:36.650984
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    pathctx = '/home/jon'
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, pathctx)
    source = 'ansible.module_utils.basic.ansible_test_utils'
    path = None
    ansible_path_hook_finder_0.find_module(source, path)

    # The following is a hack that just allows us to exercise this code path
    # find_spec will return a non-null loader if it finds a module.
    if PY3:
        ansible_path_hook_finder_0._file_finder = pkgutil.ImpImporter('/home/jon')

# Generated at 2022-06-25 12:57:20.887333
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    # Test a valid from_fqcr
    fqcr = 'ns.coll.resource'
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(fqcr, 'modules')
    assert ansible_collection_ref.collection == u'ns.coll'
    assert ansible_collection_ref.subdirs == u''
    assert ansible_collection_ref.resource == u'resource'
    assert ansible_collection_ref.ref_type == u'modules'
    assert ansible_collection_ref.fqcr == u'ns.coll.resource'

    # Test a valid from_fqcr with subdirectories
    fqcr = 'ns.coll.subdir1.subdir2.resource'

# Generated at 2022-06-25 12:57:24.433987
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Create an instance of _AnsibleInternalRedirectLoader
    fullname = 'ansible.builtin.setup'
    path_list = ['ansible/modules', 'ansible_collections/ansible/builtin']
    instance = _AnsibleInternalRedirectLoader(fullname, path_list)
    instance.load_module(fullname)



# Generated at 2022-06-25 12:57:30.673587
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkg_loader_instance = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.somens.somesubpkg',
        path_list=['/path/to/package/root']
    )
    ansible_collection_pkg_loader_instance.get_source(fullname='ansible_collections.somens.somesubpkg')


# Generated at 2022-06-25 12:57:36.420900
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    pkg_name = 'ansible_collections.a.b.c'
    path = ['/path/to/a/b/c']
    fullname = 'ansible_collections.a.b.c'
    ansible_collection_package_loader_obj = _AnsibleCollectionPkgLoaderBase(pkg_name, path)
    assert ansible_collection_package_loader_obj.load_module(fullname) is not None


# Generated at 2022-06-25 12:57:37.862888
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    base = _AnsibleCollectionPkgLoaderBase(fullname='dummy', path_list=None)
    assert base.iter_modules(prefix='') == []



# Generated at 2022-06-25 12:57:40.762281
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    test_case_AnsibleInternalRedirectLoader = _AnsibleInternalRedirectLoader('ansible.plugins.cache.memory', '/path/to/ansible_collections')

# Unit tests for constructor of class _AnsibleCollectionRootPkgLoader

# Generated at 2022-06-25 12:57:51.258443
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr('collection.nginx.configs.nginx', 'module')
    assert ref.collection == 'collection.nginx'
    assert ref.resource == 'nginx'
    assert ref.subdirs == 'configs'
    assert ref.ref_type == 'module'
    assert ref.fqcr == 'collection.nginx.configs.nginx'
    assert ref.n_python_collection_package_name == 'ansible_collections.collection.nginx'
    assert ref.n_python_package_name == 'ansible_collections.collection.nginx.plugins.module.configs.nginx'

    ref = AnsibleCollectionRef.from_fqcr('collection.nginx.nginx', 'module')
    assert ref.collection == 'collection.nginx'

# Generated at 2022-06-25 12:57:57.444928
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPathHookFinder(path=LOADER_TEST_DATA_ROOT)
    loader_instance = loader.find_module('ansible_collections.ns1.foo').load_module('ansible_collections.ns1.foo')
    assert loader_instance.get_code('ansible_collections.ns1.foo') is not None


# Generated at 2022-06-25 12:58:02.699929
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Arrange
    package_name = 'ansible.modules.xyz_package_name'
    subpackage_search_paths = ['/home/jacob/ansible/ansible/modules/xyz_package_name']
    o = _AnsibleCollectionPkgLoaderBase(package_name, subpackage_search_paths)

    # Act
    returned_modules = o.iter_modules()

    # Assert
    assert len(returned_modules) == 0


# Generated at 2022-06-25 12:58:05.294576
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader()
    ansible_internal_redirect_loader_0.load_module('ansible')

# Generated at 2022-06-25 12:58:33.004525
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    iRedirectLoader = __AnsibleInternalRedirectLoader('ansible.builtin.get_archive_facts', '/home/suvadeep/ansible-trunk/lib/ansible/modules/system/get_archive_facts.py')
    iRedirectLoader.load_module('ansible.builtin.get_archive_facts')


# Generated at 2022-06-25 12:58:40.557783
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoader(
        path=os.path.join(TEST_LOCATION_BASE, REPO_PATH, 'ansible_collections/bitfield/plugins'),
        fullname='ansible_collections.bitfield.plugins',
        package_to_load='plugins',
        collection_name='bitfield',
        collection_namespace='bitfield',
    )

    ansible_collection_pkg_loader.load_module(fullname='ansible_collections.bitfield.plugins')


# Generated at 2022-06-25 12:58:48.695525
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    test_case_1 = [
        (u'ns.coll.resource', u'module', 'ns.coll.resource'),
        (u'ns.coll.subdir1.resource', u'module', 'ns.coll.subdir1.resource'),
        (u'ns.coll.rolename', u'role', 'ns.coll.rolename'),
        (u'ns.coll.subdir1.subdir2.rolename', u'role', 'ns.coll.subdir1.subdir2.rolename')
        #(u'ns.coll.subdir1.subdir2.playbook', u'playbook', 'ns.coll.subdir1.subdir2.playbook')
    ]


# Generated at 2022-06-25 12:58:54.501799
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    try:
        AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
        AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource', 'module')
    except ValueError as exp:
        pytest.fail(msg="ValueError raised: {}".format(exp))


# Generated at 2022-06-25 12:59:05.177595
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class AnsibleCollectionPkgLoaderBase_Mock(object):

        def __init__(self, fullname, **kwargs):
            self._subpackage_search_paths = None
            self._source_code_path = None

        def get_filename(self, fullname):
            if fullname != self._fullname:
                raise ValueError('this loader cannot find files for {0}, only {1}'.format(fullname, self._fullname))

            filename = self._source_code_path

            if not filename and self.is_package(fullname):
                if len(self._subpackage_search_paths) == 1:
                    filename = os.path.join(self._subpackage_search_paths[0], '__synthetic__')

# Generated at 2022-06-25 12:59:09.937491
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.name')
    loader_base._candidate_paths = ['/tmp/ns/name']
    loader_base._subpackage_search_paths = ['/tmp/ns/name']

    # exists
    if os.path.isfile('/tmp/ns/name/foo.py'):
        os.remove('/tmp/ns/name/foo.py')
    pwd = os.getcwd()
    os.chdir('/tmp/ns/name')
    with open('foo.py', 'w') as f:
        f.write('hello world')
    try:
        os.remove('/tmp/ns/name/__init__.py')
    except:
        pass

    loader_base._source_code_

# Generated at 2022-06-25 12:59:12.442433
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens')
    assert repr(ansible_collection_pkg_loader_base_0) == '_AnsibleCollectionPkgLoaderBase(path=/Users/rashmi/ansible_collections/somens/)'


# Generated at 2022-06-25 12:59:22.303303
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    module_name = 'ansible.collections.testns.testcoll.plugins.lookup.testlookup'
    builtin_meta = _get_collection_metadata('ansible.builtin')
    routing_entry = _nested_dict_get(builtin_meta, ['import_redirection', module_name])
    redirect = routing_entry.get('redirect')
    finder = _AnsibleInternalRedirectLoader(module_name, [])
    finder.load_module(module_name)
    assert sys.modules['ansible.collections.testns.testcoll.plugins.lookup.testlookup'].__name__ == redirect


# Generated at 2022-06-25 12:59:24.267238
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Positive test case

# Generated at 2022-06-25 12:59:32.729965
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test data
    fullname = 'ansible.test.test_name'
    # For test #1
    path_list = ['/path/to/test/path_list']
    expected_result = 'module object'
    # TODO: how to test for this?
    # expected_result = 'attribute error'

    # For test #1
    ansible_collection_loader_0 = _AnsibleInternalRedirectLoader(fullname, path_list)
    actual_result_01 = ansible_collection_loader_0.load_module(fullname)
    assert(actual_result_01 == expected_result)
    # TODO: how to test for this?
    # assert(actual_result_01 == expected_result)


# Generated at 2022-06-25 12:59:50.643921
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    module_path_1 = '/tmp/test/test_module.py'
    ansible_collection_loader_1 = _AnsibleCollectionPkgLoaderBase("", path_list=["/tmp/test"])
    with open(module_path_1, 'w') as fd:
        fd.write("print('This is a test')\n")
    assert ansible_collection_loader_1.get_data(module_path_1) == b"print('This is a test')\n"



# Generated at 2022-06-25 12:59:52.767140
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Test case data
    fullname = 'ansible.module_utils.common.parameters.Parameter'
    path_list = []
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(fullname, path_list)
    ansible_internal_redirect_loader_0.load_module(fullname)


# Generated at 2022-06-25 13:00:02.471233
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print("Running {}...".format(pv(sys._getframe().f_code.co_name)))
    test_obj = _AnsibleCollectionPkgLoaderBase.__new__(_AnsibleCollectionPkgLoaderBase)
    test_obj.__init__(fullname='ansible_collections.ns.a')
    # test file exists
    path = ['/tmp/a.txt']
    ret = test_obj.get_data(path)
    assert ret != None
    # test file does not exist
    path = ['/tmp/b.txt']
    ret = test_obj.get_data(path)
    assert ret == None
    # test empty
    path = []
    ret = test_obj.get_data(path)
    assert ret == None


# Generated at 2022-06-25 13:00:07.967108
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    class DummyModuleName:
        pass
    redirect_loader = _AnsibleInternalRedirectLoader(DummyModuleName, None)
    DummyModuleName.__name__ = 'ansible'
    redirect_loader.load_module(DummyModuleName)
    DummyModuleName.__name__ = 'ansible.hello'
    redirect_loader.load_module(DummyModuleName)


# Generated at 2022-06-25 13:00:10.737803
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collections_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase()
    ansible_collections_pkg_loader_base_0.__repr__()


# Generated at 2022-06-25 13:00:14.490336
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # no redirect metadata, empty loader
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.test', None)
    module = loader.load_module('ansible.plugins.test')
    assert module is None
    # explicit redirect metadata, simple module
    module = import_module('test.test_utils.test_collection_loader')
    assert module is not None
    assert module.name == 'ansible.plugins.test'
