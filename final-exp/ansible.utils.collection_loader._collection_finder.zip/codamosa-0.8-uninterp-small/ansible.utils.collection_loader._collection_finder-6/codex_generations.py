

# Generated at 2022-06-25 12:52:15.349249
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    import tempfile

    # test with default file path
    ansible_collection_root_pkg_loader_0 = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert ansible_collection_root_pkg_loader_0._fullname == 'ansible_collections'
    assert ansible_collection_root_pkg_loader_0._redirect_module is None
    assert ansible_collection_root_pkg_loader_0._split_name == ['ansible_collections']
    assert ansible_collection_root_pkg_loader_0._rpart_name == ('', 'ansible_collections', '')
    assert ansible_collection_root_pkg_loader_0._parent_package_name == ''
    assert ansible_collection_root_pkg_loader_0._package_to_load == ''

# Generated at 2022-06-25 12:52:21.990931
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ansible_collection_root_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.ansible_module_0.plugins.module_utils.somens.ansible_module_1")
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)
    ansible_collection_finder_0._search_collection_paths("ansible_collections.ansible_module_0.plugins.module_utils.somens.ansible_module_1")
    ansible_collections_namespace_loader_0 = _AnsibleCollectionPkgLoaderBase("ansible_collections.ansible_module_0.plugins.module_utils.somens")
    ansible_collection_finder_0._path_hooks.append

# Generated at 2022-06-25 12:52:26.194948
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('inventory_plugins')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils')
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins')
    AnsibleCollectionRef.legacy

# Generated at 2022-06-25 12:52:30.494712
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # test valid reference
    ansible_collection_ref_0 = None

    ansible_collection_ref_1 = AnsibleCollectionRef.from_fqcr(
        'ansible.builtin.raw', 'module')

    ansible_collection_ref_1.ref_type == 'module'
    ansible_collection_ref_1.collection == 'ansible.builtin'
    ansible_collection_ref_1.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    ansible_collection_ref_1.resource == 'raw'
    ansible_collection_ref_1.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.module.raw'

    # test invalid reference

# Generated at 2022-06-25 12:52:42.693216
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # check for an invalid fqcr:
    assert AnsibleCollectionRef.is_valid_fqcr("nota.fqcr") == False
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.modulename.extra") == False
    # check for a valid module fqcr:
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.modulename", "module") == True
    # check for a valid role fqcr:
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.rolename", "role") == True
    # check for a valid doc_fragment fqcr:
    assert AnsibleCollectionRef.is_valid_fqcr("namespace.collection.docname", "doc_fragment") == True

#

# Generated at 2022-06-25 12:52:46.901570
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class _MockedAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            pass

        def _get_subpackage_search_paths(self, candidate_paths):
            pass

        def _validate_final(self):
            pass

        def _module_file_from_path(self, leaf_name, path):
            return os.path.join(path, leaf_name), True, os.path.join(path, leaf_name)

        def _synthetic_filename(self, fullname):
            return os.path.join('<ansible_synthetic_collection_package>', fullname)



# Generated at 2022-06-25 12:52:56.776348
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    ref = "ansible_collections.foo.bar.sample_module"

    ref_type = "module"

    Test_AnsibleCollectionRef = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)

    assert  Test_AnsibleCollectionRef.collection == "ansible_collections.foo.bar"
    assert  Test_AnsibleCollectionRef.fqcr == "ansible_collections.foo.bar.sample_module"
    assert  Test_AnsibleCollectionRef.n_python_collection_package_name == "ansible_collections.foo.bar"
    assert  Test_AnsibleCollectionRef.n_python_package_name == "ansible_collections.foo.bar.plugins.module"
    assert  Test_AnsibleCollectionRef.resource == "sample_module"

# Generated at 2022-06-25 12:53:01.678392
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, 'pathctx')
    loaded_module = ansible_path_hook_finder_0.find_module('fullname')
    assert loaded_module != None, 'unable to load module'


# Generated at 2022-06-25 12:53:08.314094
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)
    ansible_collection_pkg_loader_1 = ansible_collection_finder_0._AnsibleCollectionPkgLoader('fullname_0')
    assert '_AnsibleCollectionPkgLoader' == ansible_collection_pkg_loader_1.__class__.__name__


# Generated at 2022-06-25 12:53:16.466478
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test case: success, full test
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module')
    # Test case: failure, invalid collection reference
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource.invalid', 'module') is None
    # Test case: failure, invalid collection name
    assert AnsibleCollectionRef.try_parse_fqcr('ns..coll.resource', 'module') is None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll. substring.resource', 'module') is None
    # Test case: failure, invalid collection path
    assert AnsibleCollectionRef.try_parse_fqcr('resource', 'module') is None


# Generated at 2022-06-25 12:53:56.569056
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj_AnsibleCollectionRef = AnsibleCollectionRef(None, None, None, None)
    # No exception is expected
    repr(obj_AnsibleCollectionRef)


# Generated at 2022-06-25 12:53:59.604338
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_loader_0 = _AnsibleCollectionLoader(ansible_collection_root_pkg_loader_0)



# Generated at 2022-06-25 12:54:02.243813
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(ansible_collection_root_pkg_loader_0, None, 0)


# Generated at 2022-06-25 12:54:09.549474
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    """
    This test case verifies that the method try_parse_fqcr of class AnsibleCollectionRef
    is working as expected.
    """

# Generated at 2022-06-25 12:54:20.529538
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():

    def test_case_1():
        ansible_collection_pkg_loader_1 = _AnsibleCollectionPkgLoaderBase('')
        ansible_collection_pkg_loader_1.get_filename()

    def test_case_2():
        ansible_collection_pkg_loader_2 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
        ansible_collection_pkg_loader_2.get_filename()

    def test_case_3():
        ansible_collection_pkg_loader_3 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
        ansible_collection_pkg_loader_3.get_filename('ansible_collections.ns.module')

    def test_case_4():
        ansible_collection_pkg_loader_4

# Generated at 2022-06-25 12:54:24.589301
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    test_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible.mazuza')
    assert test_loader.is_package(fullname='ansible.mazuza')
    assert not test_loader.is_package(fullname='ansible.mazuza.sub')


# Generated at 2022-06-25 12:54:36.358107
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    proto_ansible_collection_root_pkg_loader = _AnsibleCollectionRootPkgLoader("ansible_collections")
    ansible_collection_root_pkg_loader_0 = _AnsibleCollectionRootPkgLoader("ansible_collections", "ansible")
    ansible_collection_root_pkg_loader_1 = _AnsibleCollectionRootPkgLoader("ansible_collections.somens", "ansible")

    assert ansible_collection_root_pkg_loader_0._fullname == "ansible_collections"
    assert ansible_collection_root_pkg_loader_0._rpart_name == ("", None, None)
    assert ansible_collection_root_pkg_loader_0._parent_package_name == ""
    assert ansible_collection_root_pkg_loader_0._package_to

# Generated at 2022-06-25 12:54:42.467694
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():

    valid_fqcr = "test.test.test"
    result = AnsibleCollectionRef.is_valid_fqcr(valid_fqcr)
    assert result == True

    invalid_fqcr = "test.test.test.test"
    result = AnsibleCollectionRef.is_valid_fqcr(invalid_fqcr)
    assert result == False


# Generated at 2022-06-25 12:54:49.880896
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource_name', 'module')
    assert ref.collection == 'namespace.collection'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource_name'
    assert ref.ref_type == 'module'
    assert ref.fqcr == 'namespace.collection.subdir1.subdir2.resource_name'
    assert ref.n_python_collection_package_name == 'ansible_collections.namespace.collection'
    assert ref.n_python_package_name == 'ansible_collections.namespace.collection.plugins.module.subdir1.subdir2'


if __name__ == '__main__':
    test_AnsibleCollectionRef()

# Generated at 2022-06-25 12:54:54.462549
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    sys.path = ['', '/usr/lib/python2.7/dist-packages/ansible', '/usr/lib/python2.7/dist-packages', '/usr/lib/python2.7']
    fullname = 'ansible.module_utils'
    path_list = ['/usr/lib/python2.7/dist-packages/ansible']
    redirect_loader_1 = _AnsibleInternalRedirectLoader(fullname, path_list)
    redirect_loader_1.load_module(fullname)



# Generated at 2022-06-25 12:55:23.262677
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    test_case_0()


# Generated at 2022-06-25 12:55:30.889567
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collection_finder_1 = test_case_0()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_1, '/home/test/test_collection/ansible_collections/test')
    assert(ansible_path_hook_finder_0._pathctx == '/home/test/test_collection/ansible_collections/test')
    assert(ansible_path_hook_finder_0._collection_finder == ansible_collection_finder_1)


# Generated at 2022-06-25 12:55:37.865051
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    print('Beginning testing of class _AnsibleCollectionPkgLoaderBase')
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)
    ansible_collection_finder_0.find_module('ansible')
    ansible_collection_finder_0._find_module_path(importlib.machinery.PathFinder(), 'ansible')


# Generated at 2022-06-25 12:55:47.101012
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # create a fake collection loader that can iterate modules
    my_collection_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.my_collection',
                                                           path_list=['/path/to/my_collection'])
    # use the same loaders list from an AnsiblePathHookFinder, then also add the collection loader
    loaders = [_AnsiblePathHookFinder._filefinder_path_hook('/path/to/my_collection')]
    loaders.append(my_collection_loader)
    # create a collection finder with this list
    collection_finder = _AnsibleCollectionFinder(loaders)
    # test that the finder uses _iter_modules of the collection loader, and that it finds the collection and
    # its modules when using that iterator
    collection

# Generated at 2022-06-25 12:55:50.661831
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    test__AnsibleCollectionPkgLoaderBase_get_code_instance(package_to_load="c1.ns1.baz",
                                                           source_code_path="/ansible_collections/c1/ns1/baz.py")


# Generated at 2022-06-25 12:55:55.440520
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)
    ansible_collection_finder_0.set_playbook_paths('playbook_paths_0')


# Generated at 2022-06-25 12:56:04.757085
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Prerequisite for this test.
    ansible_collection_finder_0 = _AnsibleCollectionFinder(None)
    ansible_collection_root_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.root_ns', ['/path/to/collections'])
    ansible_collection_root_pkg_loader_0._subpackage_search_paths = ['/path/to/collections/root_ns/ansible_collections/foo_ns', '/path/to/collections/root_ns/ansible_collections/bar_ns']
    ansible_collection_finder_0._loader_for_ns['root_ns'] = ansible_collection_root_pkg_loader_0

    ansible_collection_loader_0 = ansible_collection_finder_0.find_module

# Generated at 2022-06-25 12:56:14.429285
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:56:20.244913
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    """_AnsibleCollectionPkgLoaderBase - Test is_package method"""
    ans_col_pkg_load_0 = _AnsibleCollectionPkgLoaderBase()
    # NOTE: this is an abstract class, so method can't be tested
    # assert ans_col_pkg_load_0.is_package()


# Generated at 2022-06-25 12:56:24.152387
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref_0 = AnsibleCollectionRef(
        "ansible", "linux_yum_repo_facts", "linux_yum_repo_facts", "module")
    ansible_collection_ref_0_repr = repr(ansible_collection_ref_0)


# Generated at 2022-06-25 12:57:00.892517
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    collection_name=u"namespace.collection_name"
    subdirs=u"subdir1.subdir2"
    resource=u"resource_name"
    _ref0 = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type='module')

    # Compare object attributes
    if(not _ref0.collection == collection_name):
        raise AssertionError("AnsibleCollectionRef.collection does not match input value")
    if(not _ref0.subdirs == subdirs):
        raise AssertionError("AnsibleCollectionRef.subdirs does not match input value")
    if(not _ref0.resource == resource):
        raise AssertionError("AnsibleCollectionRef.resource does not match input value")

# Generated at 2022-06-25 12:57:11.942760
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'modules')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback')

# Generated at 2022-06-25 12:57:17.075341
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    a1 = _AnsibleCollectionPkgLoaderBase("somens")
    a1._subpackage_search_paths = ["/a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/"]
    assert a1.is_package("somens") == True, "Failure - test_case_1"


# Generated at 2022-06-25 12:57:21.593915
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_module_name = 'ansible_collections.ansible_fake_data.helm'
    test_module_path = '/usr/share/ansible/collections/ansible_collections/ansible_fake_data/helm'
    test0 = _AnsibleCollectionPkgLoader(test_module_name, test_module_path)
    assert test0.load_module(test_module_name) == sys.modules[test_module_name]

#

# Generated at 2022-06-25 12:57:24.246017
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)
    ansible_collection_finder_0.find_spec(fullname)


# Generated at 2022-06-25 12:57:35.071225
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_ns_pkg_loader_0 = _AnsibleCollectionNSPkgLoader('', ansible_collection_root_pkg_loader_0)
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader('', ansible_collection_ns_pkg_loader_0)
    ansible_collection_loader_0 = _AnsibleCollectionLoader('', ansible_collection_pkg_loader_0)
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('', ansible_collection_loader_0)
    ansible_internal_redirect_loader_0.load_module('ansible.test.test_utils_collection_loader.test_case_0.test_case_0')

#

# Generated at 2022-06-25 12:57:40.284601
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # Validating conversion of legacy plugin dir to ref type.
    legacy_plugin_dirs = [
        'action_plugins',
        'become_plugins',
        'cache_plugins',
        'callback_plugins',
        'cliconf_plugins',
        'connection_plugins',
        'doc_fragments',
        'filter_plugins',
        'httpapi_plugins',
        'inventory_plugins',
        'lookup_plugins',
        'module_utils',
        'modules',
        'netconf_plugins',
        'shell_plugins',
        'strategy_plugins',
        'terminal_plugins',
        'test',
        'vars_plugins'
    ]


# Generated at 2022-06-25 12:57:50.456765
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns1.pkga')
    assert loader.is_package('ansible_collections.ns1.pkga') is True

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns1.pkga.subpkga')
    assert loader.is_package('ansible_collections.ns1.pkga.subpkga') is True

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns1.pkga.subpkgb')
    assert loader.is_package('ansible_collections.ns1.pkga.subpkgb') is True


# Generated at 2022-06-25 12:57:54.694994
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    testLoader = unittest.TestLoader()
    testSuite = testLoader.loadTestsFromTestCase(Test_AnsibleCollectionPkgLoaderBase_is_package)
    text_test_runner = unittest.TextTestRunner().run(testSuite)


# Generated at 2022-06-25 12:58:03.448829
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    path = '/test/test__AnsibleCollectionPkgLoaderBase_iter_modules'
    l = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.a.b', path_list=[path])
    # create the following directory structure:
    # path/foo
    # path/bar/__init__.py
    # path/baz/__init__.py
    # path/baz/baz_1.py
    # path/baz/baz_2.py
    # path/baz/baz_3.py
    if not os.path.exists(path):
        os.mkdir(path)

# Generated at 2022-06-25 12:58:50.585203
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths([])
    ansible_collection_finder_0._install()
    ansible_collection_finder_0._ansible_collection_path_hook('/usr/ansible_pkg/ansible_collections')
    ansible_collection_finder_0.find_module('ansible.test_module')
    ansible_collection_finder_0.find_module('ansible_collections.test_module')



# Generated at 2022-06-25 12:59:00.741966
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    redirect = None

    fullname = 'ansible.module_utils.six'
    split_name = fullname.split('.')
    toplevel_pkg = split_name[0]
    module_to_load = split_name[-1]

    if toplevel_pkg != 'ansible':
        raise ImportError('not interested')

    builtin_meta = _get_collection_metadata('ansible.builtin')

    routing_entry = _nested_dict_get(builtin_meta, ['import_redirection', fullname])
    if routing_entry:
        redirect = routing_entry.get('redirect')

    if redirect:
        pass
    else:
        raise ImportError('not redirected, go ask path_hook')
		

# Generated at 2022-06-25 12:59:04.243619
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # This is a valid ref
    try:
        ansible_collection_ref_0 = AnsibleCollectionRef('ansible.test_collection', '', 'mytestmodule', 'module')
    except:
        print('test_AnsibleCollectionRef() failed')

# Generated at 2022-06-25 12:59:09.332548
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_root_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase(None,
                                                                           None)
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)
    ansible_collection_finder_0.find_module('ansible_collections.somens.somecoll.somemodule')


# Generated at 2022-06-25 12:59:15.862164
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # finalize is the last method called in load_module of _AnsibleCollectionPkgLoaderBase.
    # This method requires executing a code object in the module object dictionary.
    # In order to test this method, I will mock the code object as a dummy function
    # The trap is to test this method, we will have to mock the module objects with
    # fake code in its dictionary. This is doable, we just need to pass the name of
    # the module in fullname. So the method load_module must work correctly for a
    # module that we have not imported yet.
    #
    # Upon success the function will fail with a RuntimeError.
    # Upon failure the function will fail with an exception

    # mock the module objects
    class module_type():
        def __init__(self):
            self.__dict__ = dict()


# Generated at 2022-06-25 12:59:17.841159
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'test')
    assert ref.collection == 'namespace.collection'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'test'

# Generated at 2022-06-25 12:59:22.354540
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader_0 =  _AnsibleInternalRedirectLoader('ansible.module_utils.parsing.convert_bool', None)
    assert ansible_internal_redirect_loader_0
    #assert namespace_pkg_loader_0.load_module('ansible.module_utils.parsing.convert_bool') is None


# Generated at 2022-06-25 12:59:28.902841
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # initialize class object
    ansible_collection_root_pkg_loader_0 = None
    ansible_collection_finder_0 = _AnsibleCollectionFinder(ansible_collection_root_pkg_loader_0)

    # initialize method args
    fullname = 'ansible_collections.azure.azcollection.plugins.module_utils.azure_rm_common'

    # construct class object for method get_code
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(fullname, ansible_collection_finder_0)

    # test method get_code of class _AnsibleCollectionPkgLoader
    ansible_collection_pkg_loader_0.get_code(fullname)


# Generated at 2022-06-25 12:59:39.136519
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme.test')
    # module/package location support
    loader_0._subpackage_search_paths = [os.path.join('/tmp/test', '__init__.py'), '/tmp/test']
    loader_0._source_code_path = os.path.join('/tmp/test', '__init__.py')
    # passing an initializer list of arguments to a class
    loader_1 = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme.test', path_list=['/tmp/test'])
    # passing an initializer list of arguments to a class
    loader_2 = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme.test', path_list=[])


# Generated at 2022-06-25 12:59:43.449522
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    fullname = 'ns.coll.pkg'
    _AnsibleCollectionPkgLoader_load_module(fullname)
    fullname = 'ansible.builtin'
    _AnsibleCollectionPkgLoader_load_module(fullname)
