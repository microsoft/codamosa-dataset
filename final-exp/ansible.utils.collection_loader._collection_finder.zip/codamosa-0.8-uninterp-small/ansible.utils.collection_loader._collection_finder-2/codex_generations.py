

# Generated at 2022-06-25 12:51:39.453780
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    float_0 = -4159.0
    ansible_collection_nspkg_loader_0 = _AnsibleCollectionNSPkgLoader('ansible_collections.notreal.test', ['/usr/share/ansible/collections'])


# Generated at 2022-06-25 12:51:50.915354
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    float_0 = -62.0
    float_1 = -61.0
    float_2 = -64.0
    float_3 = -65.0
    float_4 = -60.0
    float_5 = -58.0
    float_6 = -63.0
    float_7 = -66.0
    float_8 = -59.0
    float_9 = -57.0
    float_10 = -56.0
    float_11 = -67.0
    float_12 = -68.0
    float_13 = -52.0
    float_14 = -53.0
    float_15 = -54.0
    float_16 = -55.0
    float_17 = -51.0
    float_18 = -50.0
    float_19 = -49.0

# Generated at 2022-06-25 12:52:01.475826
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    assert _AnsibleCollectionFinder.find_module(ansible_collection_finder_0, 'ansible') is None
    assert _AnsibleCollectionFinder.find_module(ansible_collection_finder_0, 'ansible') is None
    assert _AnsibleCollectionFinder.find_module(ansible_collection_finder_0, 'ansible_collections.cloudsmith.cloud') is None
    assert _AnsibleCollectionFinder.find_module(ansible_collection_finder_0, 'ansible_collections.cloudsmith.cloud') is None
    assert _AnsibleCollectionFinder.find_module(ansible_collection_finder_0, 'ansible_collections.cloudsmith.cloud') is None
    assert _Ansible

# Generated at 2022-06-25 12:52:07.675205
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("become_plugins") == "become"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("cache_plugins") == "cache"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("callback_plugins") == "callback"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("cliconf_plugins") == "cliconf"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("connection_plugins") == "connection"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-25 12:52:14.297764
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'any')
    assert isinstance(ansible_collection_ref_0, AnsibleCollectionRef), "test_AnsibleCollectionRef_from_fqcr: expected ansible_collection_ref_0 to be of type AnsibleCollectionRef"
    assert ansible_collection_ref_0.fqcr == 'ns.coll.resource', "test_AnsibleCollectionRef_from_fqcr: expected ansible_collection_ref_0.fqcr to be ns.coll.resource"

    ansible_collection_ref_1 = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.resource', 'any')

# Generated at 2022-06-25 12:52:23.418322
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-25 12:52:24.317696
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
  # TODO: fix
  pass


# Generated at 2022-06-25 12:52:31.739398
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    float_1 = -2425.0
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    ansible_collection_finder_1._install()
    ansible_collection_finder_1._AnsibleCollectionFinder__remove()
    str_0 = 'ansible_collections'
    bool_0 = ansible_collection_finder_1._n_collection_paths.append(str_0)
    ansible_collection_finder_1._n_cached_collection_paths = None
    str_1 = 'ansible'
    list_0 = [str_1]
    float_2 = 14.5
    bool_0 = ansible_collection_finder_1._n_collection_paths.insert(float_2, list_0)
    ansible_collection_finder_1._n

# Generated at 2022-06-25 12:52:39.289702
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    float_0 = -2425.0
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible.modules.network.napalm', ['/home/zope/project/network'] )
    ansible_collection_pkg_loader_base_0.get_data('napalm_get_facts.py')


# Generated at 2022-06-25 12:52:40.465978
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    test_case_0()


# Generated at 2022-06-25 12:53:13.554262
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    float_0 = 537.0
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(None, None)
    ansible_internal_redirect_loader_0.load_module(None)


# Generated at 2022-06-25 12:53:16.354574
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    rand_0 = randint(0, 10)
    ref_0 = str(rand_0)
    subject_0 = AnsibleCollectionRef.from_fqcr(ref_0)
    assert subject_0 != None


# Generated at 2022-06-25 12:53:20.454373
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Set up test data
    self_0 = _AnsibleCollectionPkgLoaderBase
    fullname_0 = 'ansible_collections.some_ns.some_collection'
    self_0.load_module(fullname_0)
    # Perform the method call
    result = self_0.get_code(fullname_0)
    # Evaluate test results
    # FIXME: Write actual test results
    assert True


# Generated at 2022-06-25 12:53:22.642791
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    fullname = 'ansible_collections.java'
    path_list = [os.path.join("/stress_test_data/data","ansible_collections")]
    obj = _AnsibleCollectionPkgLoaderBase(fullname,path_list)
    obj.test_1()


# Generated at 2022-06-25 12:53:25.895263
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    fullname = '<fullname>'
    path = '<path>'
    test_obj = _AnsiblePathHookFinder(ansible_collection_finder_0, '/home/user1/.local/share/virtualenvs/import-test-HTbTsGgb/local/lib/python2.7/site-packages/ansible/modules/cloud/amazon/cloud.py')
    result = test_obj.find_module(fullname, path)
    assert result is None
    return


# Generated at 2022-06-25 12:53:31.233089
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    float_0 = -902.0
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase()
    # should not print any error, exception in this method
    ansible_collection_pkg_loader_base_0.__repr__()


# Generated at 2022-06-25 12:53:33.031872
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    test_case_0()


# Generated at 2022-06-25 12:53:34.842058
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    param_0 = _AnsibleCollectionPkgLoaderBase._get_source("ansible_collections.local.hosts")
    assert param_0


# Generated at 2022-06-25 12:53:40.852687
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # test arguments
    fullname = b'ansible_collections'
    path_list = [b'/modules/ansible_collections']

    # select a test method to run
    test_method = test_case_0

    # run the test
    test_method(fullname, path_list)


if __name__ == '__main__':
    # Test method for class _AnsibleCollectionRootPkgLoader
    test__AnsibleCollectionRootPkgLoader()

# Generated at 2022-06-25 12:53:44.319829
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    float_0 = -2425.0
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collections_path_hook_finder_0 = _AnsiblePathHookFinder(__loader__, ansible_collection_finder_0)

    ansible_collections_path_hook_finder_0.__repr__()


# Generated at 2022-06-25 12:54:10.495286
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.basic', path_list=None)
    test_class = type('TestClass', (object,), dict(_AnsibleInternalRedirectLoader=_AnsibleInternalRedirectLoader, ansible_internal_redirect_loader=ansible_internal_redirect_loader))
    retvar = test_class.ansible_internal_redirect_loader.load_module(fullname='ansible.module_utils.basic')

if __name__ == '__main__':
    test__AnsibleInternalRedirectLoader_load_module()

# Generated at 2022-06-25 12:54:14.683896
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    global _meta_yml_to_dict

    # the global function _meta_yml_to_dict is tested in a separate test case
    # We just set a dummy function here
    def _meta_yml_to_dict_mock(yml_content, yml_filename):
        return {'prop_1':'val_1', 'prop_2':'val_2', 'prop_3' :'val_3'}

    _meta_yml_to_dict = _meta_yml_to_dict_mock

    # We mock the method on_collection_load of class AnsibleCollectionConfig
    # class AnsibleCollectionConfig is tested in a different test case
    # The method on_collection_load is called by method _AnsibleCollectionPkgLoader_load_module
    # in _AnsibleCollectionPkg

# Generated at 2022-06-25 12:54:24.234854
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_paths = ['/home/user/ansible_collections/ns', '/home/user/ansible_collections/ns/sub']
    ansible_collection_package = 'ansible_collections.ns'
    loader = _AnsibleCollectionPkgLoaderBase(ansible_collection_package, ansible_collection_paths)
    # test successful
    try:
        loader.is_package(ansible_collection_package)
    except ValueError:
        assert False
    # test failure
    try:
        loader.is_package('ansible_collections.ns.sub')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 12:54:28.345789
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Setup
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    fullname = ""
    path = None
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, "/Users/user/Documents/ansible-development/ansible/lib/ansible")
    print("ansible_path_hook_finder_0: ", ansible_path_hook_finder_0)
    # Expectations
    ansible_collection_finder_0.find_module(fullname, path=[ansible_path_hook_finder_0._pathctx])

    # Teardown
    # ansible_path_hook_finder_0.tearDown()
    ansible_collection_finder_0.tearDown()



# Generated at 2022-06-25 12:54:40.365292
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    #
    # This test case is constructed to exercise the following corner case:
    #
    # The package is represented by one or more search paths, forcing
    # _AnsibleCollectionPkgLoaderBase to look for a __init__.py file.
    #
    # In this case, the collection is a single directory with no __init__.py
    #
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.ns0.coll0.pkg0',
        path_list=['/path/to/ansible_collections/ns0/coll0/pkg0'],
    )

    assert loader.is_package('ansible_collections.ns0.coll0.pkg0') == True

# Generated at 2022-06-25 12:54:45.324711
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    class_object = AnsibleCollectionRef(
        'ansible_collections.ns.coll',
        subdirs='subdir1.subdir2',
        resource='res1',
        ref_type='module',
    )
    assert class_object.__repr__() == "AnsibleCollectionRef(collection='ansible_collections.ns.coll', subdirs='subdir1.subdir2', resource='res1')"


# Generated at 2022-06-25 12:54:51.850984
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref = AnsibleCollectionRef("namespace.collectionname", "", "mymodule", "module")
    assert ansible_collection_ref.collection == 'namespace.collectionname'
    assert ansible_collection_ref.subdirs == u''
    assert ansible_collection_ref.resource == u'mymodule'
    assert ansible_collection_ref.ref_type == u'module'
    assert ansible_collection_ref.fqcr == "namespace.collectionname.mymodule"
    assert ansible_collection_ref.n_python_package_name == "ansible_collections.namespace.collectionname.plugins.module"
    assert ansible_collection_ref.n_python_collection_package_name == "ansible_collections.namespace.collectionname"


# Generated at 2022-06-25 12:55:03.447130
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    """Unit test for method find_module of class _AnsiblePathHookFinder"""
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, '/home/ops/ansible_collections/ansible_collections')
    ansible_path_hook_finder_0.find_module()
    ansible_path_hook_finder_0.find_module(fullname='test_case_0')
    ansible_path_hook_finder_0.find_module(path='/home/ops/ansible_collections/ansible_collections')

# Generated at 2022-06-25 12:55:09.727688
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.base_pkg',
            path_list=[os.path.join(os.path.dirname(__file__), 'test_data', 'ansible_collections')])
    fullname = 'ansible_collections.base_pkg'
    ansible_collection_pkg_loader.load_module(fullname)
    assert fullname in sys.modules
    assert fullname in ansible_collection_pkg_loader.__dict__


# Generated at 2022-06-25 12:55:15.855136
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert (AnsibleCollectionRef.is_valid_fqcr('test_coll.test_role') == True)
    assert (AnsibleCollectionRef.is_valid_fqcr('test_coll.test_role.yaml') == False)
    assert (AnsibleCollectionRef.is_valid_fqcr('test_coll.test_role.yml') == False)
    assert (AnsibleCollectionRef.is_valid_fqcr('test_coll.test_role.yaml', 'role') == False)
    assert (AnsibleCollectionRef.is_valid_fqcr('test_coll.test_role.yml', 'role') == False)


# Generated at 2022-06-25 12:55:58.186919
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test1: test with valid value
    assert(AnsibleCollectionRef.try_parse_fqcr('collection.rolename', 'role'))

    # Test2: test with empty collection.rolename
    assert(AnsibleCollectionRef.try_parse_fqcr('', 'role') is None)

    # Test3: test with empty collection name
    assert(AnsibleCollectionRef.try_parse_fqcr('.rolename', 'role') is None)

    # Test4: test with empty role name
    assert(AnsibleCollectionRef.try_parse_fqcr('collection.', 'role') is None)

    # Test5: test with invalid ref_type
    assert(AnsibleCollectionRef.try_parse_fqcr('collection.rolename', 'action') is None)

    # Test6: test

# Generated at 2022-06-25 12:56:01.761706
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref_0 = AnsibleCollectionRef(None, None, None, None)
    assert repr(ansible_collection_ref_0) == 'AnsibleCollectionRef(collection=None, subdirs=None, resource=None)'


# Generated at 2022-06-25 12:56:11.187348
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    try:
        ref = AnsibleCollectionRef.from_fqcr('ns.coll.myaction', 'action')
        assert ref.collection is 'ns.coll'
        assert ref.subdirs is ''
        assert ref.ref_type is 'action'
        assert ref.resource is 'myaction'
        assert ref.fqcr is 'ns.coll.myaction'
        assert ref.n_python_package_name is 'ansible_collections.ns.coll.plugins.action'
        assert ref.n_python_collection_package_name is 'ansible_collections.ns.coll'
    except ValueError:
        assert False


# Generated at 2022-06-25 12:56:19.505724
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_path_hook_0 = ansible_collection_finder_0._ansible_collection_path_hook()
    ansible_path_hook_finder_0 = ansible_collection_path_hook_0("./ansible_collections/somens/somecoll")
    ansible_path_hook_finder_0.find_module("somecoll")
    ############################################
    #### CODE SMELL
    ansible_file_finder_0 = ansible_path_hook_finder_0._file_finder


# Generated at 2022-06-25 12:56:28.201012
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_path_hook_finder_0 = _AnsiblePathHookFinder(pathctx='/home/daniel/ansible_collections/ansible_collections/ansible/community/aws', collection_finder=ansible_collection_finder_0)
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ansible.community.aws', path_list=['/home/daniel/ansible_collections/ansible_collections/ansible/community/aws', '/usr/lib/python3.7/site-packages/ansible_collections'])
    assert ansible_collection_loader_0.get_data(path='./') is None

# Unit

# Generated at 2022-06-25 12:56:30.866161
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('ansible.builtin')
    path_list = []
    ansible_internal_redirect_loader_0.load_module(path_list)


# Generated at 2022-06-25 12:56:41.230934
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    cases = {}
    cases[0] = {'exp_coll': 'namespace.collectionname', 'exp_subdirs': u'', 'exp_res': 'resource', 'exp_type': 'module',
                'input': 'namespace.collectionname.resource'}
    cases[1] = {'exp_coll': 'namespace.coll', 'exp_subdirs': 'subdir1.subdir2', 'exp_res': 'resource', 'exp_type': 'lookup',
                'input': 'namespace.coll.subdir1.subdir2.resource'}
    cases[2] = {'exp_coll': 'namespace.coll', 'exp_subdirs': u'', 'exp_res': 'role', 'exp_type': 'role',
                'input': 'namespace.coll.role'}



# Generated at 2022-06-25 12:56:51.622869
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    the_list = ['path_a','path_b','path_c']
    prefix = 'ansible_collections.my_ns'

# Generated at 2022-06-25 12:57:01.697375
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    package_name='.test'
    true_module_name='ansible_collections.ansible.test'
    true_parent_package_name='ansible_collections.test'
    true_package_to_load='test'
    path_list=['/a/b/c']
    true_sub_package_search_paths=['/a/b/c/test']

    # test init method
    _a = _AnsibleCollectionPkgLoaderBase(true_module_name,path_list)

    assert _a._fullname == true_module_name
    assert _a._split_name == ['ansible_collections','ansible','test']
    assert _a._rpart_name == ('ansible_collections.ansible','.','test')
    assert _a._parent_package_name == true

# Generated at 2022-06-25 12:57:12.366895
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # Test role
    ref = AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.role_name', u'role')
    assert ref.collection == u'namespace.collection'
    assert ref.subdirs == u''
    assert ref.resource == u'role_name'
    assert ref.ref_type == u'role'

    # Test role subdir role
    ref = AnsibleCollectionRef.try_parse_fqcr(u'namespace.collection.subdir1.role_name', u'role')
    assert ref.collection == u'namespace.collection'
    assert ref.subdirs == u'subdir1'
    assert ref.resource == u'role_name'
    assert ref.ref_type == u'role'

    # Test role subdir subdir role
    ref

# Generated at 2022-06-25 12:57:42.545280
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoader('ansible_collections.ns.collection', ['path'])
    with mock.patch('ansible.utils.import_module') as import_module_mock:
        ansible_collection_pkg_loader.load_module('ansible_collections.ns.collection')
        import_module_mock.has_calls([mock.call('ansible')])



# Generated at 2022-06-25 12:57:53.991561
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    try:
        result = AnsibleCollectionRef.is_valid_fqcr(None)
        # Test case should be changed to fail
        assert False
    except ValueError as e :
        assert True
    except Exception as e:
        print('Exception raised: ' + str(e))
        assert False
    try:
        result = AnsibleCollectionRef.is_valid_fqcr('')
        assert False
    except ValueError as e :
        assert True
    except Exception as e:
        print('Exception raised: ' + str(e))
        assert False
    try:
        result = AnsibleCollectionRef.is_valid_fqcr('ans1.coll1')
        assert False
    except ValueError as e :
        assert True
    except Exception as e:
        print('Exception raised: ' + str(e))


# Generated at 2022-06-25 12:58:02.986977
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.collections.ansible.builtin import package_loader
    from ansible.utils.collection_loader import _meta_yml_to_dict
    import os
    import sys
    import imp

    def _meta_yml_to_dict(data, source_file):
        import yaml

        try:
            return yaml.safe_load(data)
        except Exception as ex:
            raise ValueError('error parsing collection metadata: {0}'.format(to_native(ex)))

    _meta_yml_to_dict_old = _meta_yml_to_dict
    _meta_yml_to_dict = _meta_yml_to_dict
    import ansible.collections.ansible.builtin.plugins.action
    _meta_yml_to_dict = _meta_yml

# Generated at 2022-06-25 12:58:09.737659
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase("db_utils")
    ansible_collection_pkg_loader_base_0._source_code_path = "/Users/zam/dev/ansible/ansible-modules-core/database/db_utils"
    ansible_collection_pkg_loader_base_0.get_source("db_utils")
    if ansible_collection_pkg_loader_base_0._decoded_source != None:
        print("Test passed")



# Generated at 2022-06-25 12:58:20.971481
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir_to

# Generated at 2022-06-25 12:58:27.325918
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref1 = AnsibleCollectionRef.try_parse_fqcr(u'n.c', u'module')
    assert isinstance(ref1, AnsibleCollectionRef)
    assert ref1.collection == u'n.c'
    assert ref1.subdirs == u''
    assert ref1.resource == u'module'
    assert ref1.ref_type == u'module'
    assert ref1.fqcr == u'n.c.module'
    assert ref1.n_python_collection_package_name == u'ansible_collections.n.c'
    assert ref1.n_python_package_name == u'ansible_collections.n.c.plugins.module'


# Generated at 2022-06-25 12:58:39.723130
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # empty list -> empty
    ansibleCollectionPkgLoaderBase = _AnsibleCollectionPkgLoaderBase('')
    assert(ansibleCollectionPkgLoaderBase.iter_modules([]) == [])

    # no dirs -> empty
    filePath1 = '/tmp/abc.py'
    open(filePath1, 'a').close()
    assert(ansibleCollectionPkgLoaderBase.iter_modules([filePath1]) == [])

    # one dir -> empty
    dirPath1 = '/tmp/dir1'
    os.mkdir(dirPath1)
    assert(ansibleCollectionPkgLoaderBase.iter_modules([dirPath1]) == [])

    # one dir + non-empty subdirs -> empty
    dirPath2 = dirPath1 + '/dir2'
    os.mkdir(dirPath2)
   

# Generated at 2022-06-25 12:58:48.307021
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    print ("TESTING: _AnsibleCollectionPkgLoaderBase.__repr__()")
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder('/data/jenkins/jobs/ansible-doc-test/workspace/hacking/test/units/lib/ansible/utils/testdata/ansible_collections/fake_collection', ansible_collection_finder_0)
    ansible_collections_pkg_loader_0 = _AnsibleCollectionsPkgLoaderBase('ansible_collections.fake_collection', [ansible_path_hook_finder_0])

# Generated at 2022-06-25 12:58:55.549081
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections", path_list=["collections/ansible_collections"])
    module_0 = ansible_collection_pkg_loader_0.load_module(fullname="ansible_collections")

    # Test for attribute __module__ of class module_0 at global scope
    print(getattr(module_0, "__module__"))



# Generated at 2022-06-25 12:59:00.206961
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    """Test for method get_code of class _AnsibleCollectionPkgLoaderBase"""
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase()
    assert isinstance(ansible_collection_pkg_loader_base_0.get_code(), object)



# Generated at 2022-06-25 12:59:49.512224
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    _meta_yml_to_dict = Dummy()
    ansible_collection_loader_2 = _AnsibleCollectionPkgLoader('_meta_yml_to_dict', 'path', 'dest_path',
                                                              'package_to_load', 'split_name', 'fullname')
    ansible_collection_loader_2.load_module('fullname')


# Generated at 2022-06-25 12:59:58.052153
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # A valid input
    assert AnsibleCollectionRef('test.test1', '', 'test2', 'action')
    # subdirs is not empty
    assert AnsibleCollectionRef('test.test1', 'sub', 'test2', 'action')
    # Input contain some characters that are not ascii
    assert AnsibleCollectionRef('проверка.test1', 'sub', 'test2', 'action')
    # subdirs contains some characters that are not ascii
    assert AnsibleCollectionRef('test.test1', 'подпапка', 'test2', 'action')
    # The resource contains some characters that are not ascii
    assert AnsibleCollectionRef('test.test1', 'sub', 'добавить', 'action')
    # Test a

# Generated at 2022-06-25 13:00:00.533198
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref_0 = AnsibleCollectionRef('collection_0', 'collection', 'ref_0', 'ansible.0')


# Generated at 2022-06-25 13:00:03.917361
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = "ansible_collections.ns.coll.resource"
    ref_type = "module"
    assert AnsibleCollectionRef.is_valid_fqcr(ref, ref_type) == True


# Generated at 2022-06-25 13:00:12.961278
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection')
    assert(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments')