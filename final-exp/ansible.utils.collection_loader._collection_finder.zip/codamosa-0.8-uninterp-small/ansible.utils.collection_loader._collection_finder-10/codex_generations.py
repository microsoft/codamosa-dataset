

# Generated at 2022-06-25 12:50:57.602977
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    path_list = None
    int_0 = 33188
    str_0 = "$'T(g"
    str_1 = "ansible_collections.somens"
    dict_0 = dict()
    dict_1 = dict()
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(int_0, str_0, path_list)
    ansible_collection_pkg_loader_base_1 = _AnsibleCollectionPkgLoaderBase(str_1, path_list)
    ansible_collection_pkg_loader_base_2 = _AnsibleCollectionPkgLoaderBase(dict_0, path_list)
    ansible_collection_pkg_loader_base_3 = _AnsibleCollectionPkgLoaderBase(dict_1, path_list)


# Generated at 2022-06-25 12:51:01.602832
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Declare variables
    int_0 = 33188
    str_0 = "$'T(g"
    # Instantiate class
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(int_0, str_0)
    # Call method load_module
    ansible_internal_redirect_loader_0.load_module(int_0)



# Generated at 2022-06-25 12:51:11.723020
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    str_0 = "ansible_collections.foo"
    lst_0 = ["/cnx/staging/ansible/ansible_collections", "/usr/local/share/ansible/ansible_collections"]
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(str_0, lst_0)
    str_1 = "ansible_collections.foo"
    str_2 = "/usr/local/share/ansible/ansible_collections/foo"
    assert(ansible_collection_pkg_loader_base_0.get_filename(str_1) == str_2)

test_case_0()
test__AnsibleCollectionPkgLoaderBase_get_filename()

# Generated at 2022-06-25 12:51:18.665881
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    int_0 = 62187
    str_0 = '"c%u'
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(int_0, str_0)
    str_1 = 'gtS\'t'
    ret_0 = ansible_internal_redirect_loader_0.iter_modules(str_1)
    if ret_0 is not None:
        print(ret_0)



# Generated at 2022-06-25 12:51:23.727694
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():

    ansible_collection_ref_0 = AnsibleCollectionRef(str_0, str_1, str_2, str_3)
    ansible_collection_ref_1 = AnsibleCollectionRef.try_parse_fqcr(int_0, str_1)
    ansible_collection_ref_2 = AnsibleCollectionRef.try_parse_fqcr(int_0, str_1)
    ansible_collection_ref_3 = AnsibleCollectionRef.try_parse_fqcr(str_0, str_1)
    ansible_collection_ref_4 = AnsibleCollectionRef.try_parse_fqcr(ansible_collection_ref_3, ansible_collection_ref_0)
    result = is_valid_fqcr(str_0)
    assert result == int_0


# Generated at 2022-06-25 12:51:33.200044
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    str_0 = "Cw%6'#U"
    str_1 = '$>@!4?<'
    bool_timestamp = time.time()
    int_0 = 786829634
    int_1 = 694707916
    int_timestamp = int(bool_timestamp)
    tuple_1 = (str_1, int_0, int_1, int_timestamp)
    tuple_0 = (str_0, tuple_1)
    obj_0 = _AnsibleCollectionPkgLoaderBase(tuple_0)
    # check that the returned value is not None
    obj_0.get_source(tuple_0)


# Generated at 2022-06-25 12:51:34.264017
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef("test.test", "test", "test", "test")


# Generated at 2022-06-25 12:51:37.953689
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    int_0 = 50
    str_0 = 'R9XHU/'
    _AnsibleCollectionPkgLoaderBase_0 = _AnsibleCollectionPkgLoaderBase(int_0, str_0)
    str_0 = 'lKs$'
    str_1 = _AnsibleCollectionPkgLoaderBase_0.get_data(str_0)


# Generated at 2022-06-25 12:51:40.360980
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    int_0 = 33188
    str_0 = "$'T(g"
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(int_0, str_0)


# Generated at 2022-06-25 12:51:47.103939
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref_0 = "test.test.test"
    expect_0 = None
    ref_type_0 = "test"
    acr_obtain_0 = AnsibleCollectionRef.try_parse_fqcr(ref_0, ref_type_0)
    if expect_0 != acr_obtain_0:
        print("Test 1: Failed")
    else:
        print("Test 1: Success")



# Generated at 2022-06-25 12:52:58.574904
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    str_0 = 'test.test'
    ansible_collection_ref_0 = AnsibleCollectionRef.from_fqcr(str_0, str_0)
    assert isinstance(ansible_collection_ref_0, AnsibleCollectionRef)
    assert len(ansible_collection_ref_0.collection) == len('test')
    assert ansible_collection_ref_0.collection == 'test'
    assert len(ansible_collection_ref_0.subdirs) == len('')
    assert ansible_collection_ref_0.subdirs == ''
    assert len(ansible_collection_ref_0.resource) == len('test')
    assert ansible_collection_ref_0.resource == 'test'
    assert len(ansible_collection_ref_0.ref_type) == len('test')

# Generated at 2022-06-25 12:53:02.335948
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    str_0 = 'test.test'
    ansible_collection_ref_0 = AnsibleCollectionRef(str_0, str_0, str_0, str_0)
    fullname_0 = 'test.test'
    path_list_0 = ['test.test']
    # _AnsibleInternalRedirectLoader.__init__(fullname_0, path_list_0)
    # _AnsibleInternalRedirectLoader.load_module(fullname_0)



# Generated at 2022-06-25 12:53:11.274823
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    str_0 = 'test.test'
    str_1 = 'test.test'
    str_2 = 'test.test'
    str_3 = 'test.test'
    ansible_collection_ref_0 = AnsibleCollectionRef(str_0, str_1, str_2, str_3)
    list_0 = list()
    list_0.append(ansible_collection_ref_0)
    list_1 = list()
    list_1.append(ansible_collection_ref_0)
    list_1.append(ansible_collection_ref_0)
    list_2 = list()
    list_2.append(ansible_collection_ref_0)
    list_2.append(ansible_collection_ref_0)

# Generated at 2022-06-25 12:53:15.206594
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    str_0 = 'test.test'
    ansible_collection_ref_0 = AnsibleCollectionRef(str_0, str_0, str_0, str_0)
    assert ansible_collection_ref_0.is_valid_collection_name(str_0) == True


# Generated at 2022-06-25 12:53:17.617294
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # create an instance of the _AnsibleCollectionPkgLoaderBase class
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(str_0)


# Generated at 2022-06-25 12:53:25.844856
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    _AnsibleCollectionPkgLoaderBase_obj = _AnsibleCollectionPkgLoaderBase(str())
    assert isinstance(_AnsibleCollectionPkgLoaderBase_obj._AnsibleCollectionPkgLoaderBase__get_candidate_paths(list()), list)
    assert isinstance(_AnsibleCollectionPkgLoaderBase_obj._AnsibleCollectionPkgLoaderBase__get_subpackage_search_paths(list()), list)
    assert isinstance(_AnsibleCollectionPkgLoaderBase_obj._AnsibleCollectionPkgLoaderBase__module_file_from_path(str(), str()), tuple)


# Generated at 2022-06-25 12:53:35.355792
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    str_0 = 'test.test'
    str_1 = 'action.test.test'
    str_2 = 'test.test.test.test'
    str_3 = 'test.test.test'
    str_4 = 'test.test.test.test.test'
    str_5 = '.test.test'
    str_6 = 'test.test.test.test.test.test.test'
    str_7 = 'test.test.test.test.test.test.test.test.test'
    str_8 = 'test.test.test.test.test.test.test.test.test.test'
    str_9 = 'test.test.test.test.test.test.test.test.test.test.test'

# Generated at 2022-06-25 12:53:36.944218
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    _AnsibleCollectionPkgLoaderBase.get_data(str)


# Generated at 2022-06-25 12:53:40.531354
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    str_0 = '/new/test/test'
    str_1 = '/home/stmadden/dev/ansible/test'
    pkg_loader = _AnsibleCollectionPkgLoaderBase(str_0, str_1)
    pkg_loader.get_data(str_0)


# Generated at 2022-06-25 12:53:49.586354
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    str_0 = 'test.test'
    ansible_collections_ref_0 = AnsibleCollectionRef(str_0, str_0, str_0, str_0)

    # Test case 1
    str_0 = 'test.test'
    ansible_collection_ref_0 = AnsibleCollectionRef(str_0, str_0, str_0, str_0)
    a_0 = _AnsibleCollectionPkgLoaderBase(ansible_collection_ref_0, None)
    b_0 = a_0.get_source(ansible_collection_ref_0)


    # Test case 2
    str_0 = 'test.test'
    ansible_collection_ref_0 = AnsibleCollectionRef(str_0, str_0, str_0, str_0)
    a_0 = _

# Generated at 2022-06-25 12:56:53.082654
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    _AnsibleCollectionPkgLoader('ansible_collections.test_collection.test_collection_pack.pkg_m_0', path_list64=[], path_list32=[]).load_module("ansible_collections.test_collection.test_collection_pack.pkg_m_0")


# Generated at 2022-06-25 12:57:02.514156
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    from_fqcr_tests = [
        ('ns.coll.resource', 'module', ('ns', 'coll', '', 'resource')),
        ('ns.coll.subdir1.subdir2.resource', 'module', ('ns', 'coll', 'subdir1.subdir2', 'resource')),
        ('ns.coll.rolename', 'role', ('ns', 'coll', '', 'rolename')),
        ('ns.coll.playbookname.yml', 'playbook', ('ns', 'coll', '', 'playbookname')),
        ('ns.coll.playbookname.yaml', 'playbook', ('ns', 'coll', '', 'playbookname')),
    ]

    for ref, ref_type, expected in from_fqcr_tests:
        collection_ref = AnsibleCollectionRef.from_f

# Generated at 2022-06-25 12:57:12.899464
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    fake_fullname = 'ansible_collections.fake_collection'

    # test class init with a name that is not 'ansible_collections'
    # error should be raised.
    with pytest.raises(ImportError) as exec_info:
        loader_0 = _AnsibleCollectionPkgLoaderBase('fake_collection')

    # test class init with a name that is not 'ansible_collections'
    # error should be raised.
    fullname_1_1 = 'ansible_collections.fake_collection'
    package_1_1 = 'fake_collection'
    with pytest.raises(ImportError) as exec_info_1_1:
        path_1 = ['/usr/lib/python2.7/site-packages']

# Generated at 2022-06-25 12:57:17.375534
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    collection_path = '/etc/ansible/collections/my_collection/my_namespace/my_colleciton_name'
    loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_colleciton_name')
    loader_base.get_source('ansible_collections.my_namespace.my_colleciton_name')



# Generated at 2022-06-25 12:57:18.063123
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    assert test_case_0() is None



# Generated at 2022-06-25 12:57:24.744093
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_ = _AnsibleCollectionFinder()

    # call method with fullname 'ansible' and path None
    ansible_collection_finder_._AnsibleCollectionFinder_find_module(fullname='ansible', path=None)
    # call method with fullname 'ansible.parsing' and path None
    ansible_collection_finder_._AnsibleCollectionFinder_find_module(fullname='ansible.parsing', path=None)
    # call method with fullname 'ansible_collections' and path []
    ansible_collection_finder_._AnsibleCollectionFinder_find_module(fullname='ansible_collections', path=[])
    # call method with fullname 'ansible_collections.ns' and path []
    ansible_collection_finder_._An

# Generated at 2022-06-25 12:57:29.432707
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.strategy.strategy_loader', None)
    loader.load_module('ansible.plugins.strategy.strategy_loader')


if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-25 12:57:31.913536
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder = _AnsibleCollectionFinder()
    ansible_path_hook_finder = _AnsiblePathHookFinder(ansible_collection_finder, '/var/lib/awx/venv/ansible/lib/python3.6/site-packages')
    pprint(ansible_path_hook_finder.find_module('dbus'))



# Generated at 2022-06-25 12:57:41.729154
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0._path_cache.clear()
    ansible_collection_finder_0._path_cache.append(os.path.dirname(to_bytes('test/test_collections_loader/osc_collection/')))
    subpackage_search_paths = [to_bytes('test/test_collections_loader/osc_collection/osc/')]
    ansible_collection_finder_0.collection_package_name = 'osc'
    ansible_collection_finder_0._path_cache_key = 'osc'

# Generated at 2022-06-25 12:57:45.095791
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _loader = _AnsibleInternalRedirectLoader('ansible.module_utils.parsing.convert_bool', [])
    _loader.load_module(fullname='ansible.module_utils.parsing.convert_bool')


# Generated at 2022-06-25 12:58:23.545502
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(
        'foo'
    )

    repr_value = ansible_collection_pkg_loader_base_0.__repr__()
    assert repr_value == '_AnsibleCollectionPkgLoaderBase(path=None)'


# Generated at 2022-06-25 12:58:25.962422
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.module_utils.six', None)
    assert (redirect_loader._redirect == 'six')


# Generated at 2022-06-25 12:58:33.863949
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.testNS.testCol.testPlugins.testPlugin.action',
        path_list=['ansible_collections/testNS/testCol/testPlugins/testPlugin/action']
    )
    code = loader.get_code('ansible_collections.testNS.testCol.testPlugins.testPlugin.action')
    assert code is not None, 'Code should not be empty.'



# Generated at 2022-06-25 12:58:44.166555
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    class DummyClass(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            assert self._split_name[0] == 'ansible_collections'

    assert os.path.exists("DummyClass.py")

    # Test for correct __file__ value
    #
    dummy_class = DummyClass("ansible_collections")
    assert os.path.exists(dummy_class._fullname)
    assert dummy_class.get_source("ansible_collections") == dummy_class.get_data("DummyClass.py")

    # Test for valid ImportError
    #
    ansible_collections = DummyClass("ansible_collections")

# Generated at 2022-06-25 12:58:53.529107
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test for empty file content
    absolutepath = "/home/ansible/ansible_collections/somens"
    loader = _AnsibleCollectionPkgLoaderBase("somens",[absolutepath])
    path = "__synthetic__"
    assert loader.get_data(path) == b""

    # Test for right file content
    absolutepath = "/home/ansible/ansible_collections/somens"
    loader = _AnsibleCollectionPkgLoaderBase("somens",[absolutepath])
    path = "data/data.txt"
    assert loader.get_data(path) == b'This is a test content'

    # Test for error with uninitialized path

# Generated at 2022-06-25 12:59:04.288151
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    def test_case(ref_string, ref_type, ns, coll, subdirs, resource):
        collection_ref = AnsibleCollectionRef.from_fqcr(ref_string, ref_type)
        assert collection_ref.collection == ns + u'.' + coll
        assert collection_ref.subdirs == subdirs
        assert collection_ref.resource == resource
        assert collection_ref.ref_type == ref_type

        # FUTURE: direct test of the returned package name(s) here

    test_case(u'collection.test_collection.test.test_module', u'module', u'collection', u'test_collection', u'test', u'test_module')

# Generated at 2022-06-25 12:59:08.084019
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    try:
        ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(fullname = '', path_list = [])
        ansible_internal_redirect_loader_0.load_module(fullname = '')
    except ImportError:
        pass


# Generated at 2022-06-25 12:59:09.911878
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.test_load_module', None)


# Generated at 2022-06-25 12:59:16.262253
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible_collections.not_a_real_collection.plugins.module_utils.notaconfig import notaconfig
    import ansible_collections.not_a_real_collection.plugins.module_utils.notaconfig
    _loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.not_a_real_collection.plugins.module_utils.notaconfig',
                                              ['.'])
    assert _loader.is_package(
        'ansible_collections.not_a_real_collection.plugins.module_utils.notaconfig') == True
    assert _loader.get_code(
        'ansible_collections.not_a_real_collection.plugins.module_utils.notaconfig') is not None

# Generated at 2022-06-25 12:59:18.979487
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    module_info_1 = ansible_collection_finder_1.find_module('ansible', path=None)


# Generated at 2022-06-25 13:00:13.985480
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    class FakeLoader(object):
        def get_data(self, path):
            return path

    loader = FakeLoader()
    assert 'tmp/foo/__init__.py' == _AnsibleCollectionPkgLoaderBase.get_data(loader, '/tmp/foo/__init__.py')
    assert 'tmp/foo.py' == _AnsibleCollectionPkgLoaderBase.get_data(loader, '/tmp/foo.py')
    assert '' == _AnsibleCollectionPkgLoaderBase.get_data(loader, '/tmp/foo/__init__.py')
