

# Generated at 2022-06-25 12:51:31.569170
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    expected = '_AnsibleCollectionPkgLoaderBase(path=[])'
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme.what', path_list=list())
    result = loader.__repr__()
    assert result == expected, "Failed test of method __repr__ of _AnsibleCollectionPkgLoaderBase"


# Generated at 2022-06-25 12:51:34.240686
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref_values = ['test.test', 'test.test.', 'test.test.testtest', 'test.test.testtest_test', 'test.test.\u4e00']

    for ref in ref_values:
        assert not AnsibleCollectionRef.is_valid_fqcr(ref), "Failed, ref '{}' is None and should be string".format(ref)



# Generated at 2022-06-25 12:51:43.106833
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test if the source code can be successfully compiled
    # Case 0: the name "ansible_collections.test.test0" exists in the module
    ansible_collection_pkg_loader_test0_0 = _AnsibleCollectionPkgLoader('ansible_collections.test.test0')
    ansible_collection_pkg_loader_test0_0.get_code('ansible_collections.test.test0')

    # Case 1: the name "ansible_collections.test.test1" does not exist in the module
    ansible_collection_pkg_loader_test1_0 = _AnsibleCollectionPkgLoader('ansible_collections.test.test1')

# Generated at 2022-06-25 12:51:53.018142
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.subdir2.resource', u'module').collection == u'ns.coll'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.subdir2.resource', u'module').subdirs == u'subdir1.subdir2'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module').collection == u'ns.coll'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module').subdirs == u''
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module').resource == u'resource'
    assert AnsibleCollectionRef

# Generated at 2022-06-25 12:52:02.419139
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Create a loader to be used for testing
    real_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens', path_list=['/tmp/mycollections'])
    real_loader._subpackage_search_paths = ['/tmp/mycollections/somens']
    real_loader._source_code_path, has_code, package_path = \
        _AnsibleCollectionPkgLoaderBase._module_file_from_path('somens', '/tmp/mycollections')

    # load_module expects a module with a name, but we don't really care, so pass anything as long as it's a str
    with mock.patch('ansible.module_utils._ansible_module_loader.ModuleType', return_value='test_module') as mock_mod:
        module = real

# Generated at 2022-06-25 12:52:07.236045
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    _loader_0 = ansible_collection_finder_0._n_collection_paths[0]
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, _loader_0)
    ansible_path_hook_finder_0.find_module('ansible_collections.does_not_exist')
    # assert that no exception is raised
    pass

test__AnsiblePathHookFinder_find_module()


# Generated at 2022-06-25 12:52:15.947295
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # this method is only supposed to handle packages
    self._source_code_path = None
    self._compiled_code = None

    # we're actually loading a module/package
    module_attrs = dict(
        __loader__=self,
        __file__=self.get_filename(fullname),
        __package__=self._parent_package_name  # sane default for non-packages
    )

    # eg, I am a package
    if self._subpackage_search_paths is not None:  # empty is legal
        module_attrs['__path__'] = self._subpackage_search_paths
        module_attrs['__package__'] = fullname  # per PEP366


# Generated at 2022-06-25 12:52:21.501592
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase("ns_1.collection_1.module_1")
    try:
        sys.modules["ns_1.collection_1.module_1"] = ModuleType("ns_1.collection_1.module_1")
    except:
        pass
    ansible_collection_loader_0.load_module("ns_1.collection_1.module_1")


# Generated at 2022-06-25 12:52:26.114625
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():

    # Test case where the import is not redirected
    _AnsibleInternalRedirectLoader_loader = _AnsibleInternalRedirectLoader('ansible.cli','')
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader_loader.load_module('ansible.cli')

    # Test case where the import is redirected to cli.ansible
    _AnsibleInternalRedirectLoader_loader = _AnsibleInternalRedirectLoader('ansible.cli','')
    _AnsibleInternalRedirectLoader_loader._redirect = 'cli.ansible'
    assert _AnsibleInternalRedirectLoader_loader.load_module('ansible.cli') == None


# Generated at 2022-06-25 12:52:29.610777
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='collection1.namespace1.somemodule1', path_list=['/some/collection1/namespace1/somemodule1'])
    loader._source_code_path = '/some/collection1/namespace1/somemodule1/somefile.py'
    loader.get_source(fullname='collection1.namespace1.somemodule1')


# Generated at 2022-06-25 12:53:39.427255
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # This test case will raise an exception if the pre-condition is not fulfilled

    # Arrange
    _AnsibleCollectionPkgLoader._AnsibleCollectionPkgLoaderBase._meta_yml_to_dict = None
    _AnsibleCollectionPkgLoader.load_module(self,'abcd')


# Generated at 2022-06-25 12:53:47.874925
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Given a AnsibleCollectionConfig config object
    config = AnsibleCollectionConfig()

    # When I create a AnsibleCollectionFinder instance with the config object
    ansible_collection_finder = _AnsibleCollectionFinder(config=config)

    # And I import a collection 'abc.xyz' from the local collection path
    import abc.xyz
    type(abc.xyz)._collection_meta = {}
    abc.xyz._collection_meta = {}

    # And I set the path of the module for the collection in the ansible_collections loader
    abc.xyz.__loader__ = ansible_collection_finder.collection_package_loader['ansible_collections/abc/xyz/']

    # And I set the path of the module for the collection namespace in the ansible_collections loader

# Generated at 2022-06-25 12:53:58.744560
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Since we are using _AnsibleCollectionFinder, _AnsibleInternalRedirectLoader, _AnsibleCollectionFQCRPathFinder,
    # _AnsibleCollectionPythonPathFinder, _AnsibleCollectionFileFinder, our test cases are related to them.
    # Add the nested dir for test
    _AnsibleCollectionFinder._BASE_PATHS_CACHE['/tmp/ansible'] = 'ansible'

    # Where ref_type = role and fqcr = abc.def.defaults
    fqcr_role_def = AnsibleCollectionRef.from_fqcr('abc.def.defaults', 'role')
    assert fqcr_role_def.collection == 'abc.def'
    assert fqcr_role_def.subdirs == ''
    assert fqcr_

# Generated at 2022-06-25 12:54:06.877724
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # The first test case is the standard name space and collection:
    collection_name = 'namespace.collection'
    test_case_1 = AnsibleCollectionRef.try_parse_fqcr(collection_name, 'module')

    assert test_case_1.collection == 'namespace.collection'
    assert test_case_1.subdirs == ''
    assert test_case_1.resource == 'collection'
    assert test_case_1.ref_type == 'module'

    # The second test case is collection with sub-directory:
    sub_directory = 'sub_directory'
    collection_name = 'namespace.collection.sub_directory'
    test_case_2 = AnsibleCollectionRef.try_parse_fqcr(collection_name, 'module')


# Generated at 2022-06-25 12:54:10.731291
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    fqcr = 'ansible.builtin.get_url'
    ref_type = 'module'
    acr = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert acr.collection == 'ansible.builtin'
    assert acr.subdirs == ''
    assert acr.resource == 'get_url'
    assert acr.ref_type == ref_type
    assert acr.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    assert acr.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.modules'


# Generated at 2022-06-25 12:54:20.115921
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'', u'resource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'subdir1', u'resource', u'module')
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.rolename', u'role') == AnsibleCollectionRef(u'ns.coll', u'', u'rolename', u'role')


# Generated at 2022-06-25 12:54:24.544315
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref_0 = AnsibleCollectionRef("foo", "bar", "baz", "qux")
    result = ansible_collection_ref_0.__repr__()
    assert result == 'AnsibleCollectionRef(collection=\'foo\', subdirs=\'bar\', resource=\'baz\')'


# Generated at 2022-06-25 12:54:30.965209
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type

# Generated at 2022-06-25 12:54:38.222249
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    #import pudb

    mock_fullname = "ansible.module_utils.basic"
    mock_path_list = "/usr/lib/python3.6/site-packages/ansible/module_utils"

    #pudb.set_trace()
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(mock_fullname, mock_path_list)
    ansible_internal_redirect_loader_0.load_module(mock_fullname)


# Generated at 2022-06-25 12:54:47.416012
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    collection_name = 'my.collection'
    subdirs = 'module_utils.util'
    resource = 'my_module'
    ref_type = 'module'
    ansible_collection_ref_0 = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert ansible_collection_ref_0.collection == collection_name
    # FIXME: fix this
    #assert ansible_collection_ref_0.n_python_collection_package_name == 'ansible_collections.my.collection'
    assert ansible_collection_ref_0.resource == resource
    assert ansible_collection_ref_0.ref_type == ref_type
    # FIXME: fix this
    #assert ansible_collection_ref_0.n_python_package_name == 'ansible_collections

# Generated at 2022-06-25 12:55:05.857419
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    answer_0 =  _AnsibleCollectionFinder()
    assert answer_0 is not None, 'answer_0 is None'


# Generated at 2022-06-25 12:55:08.896176
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Static variable, to be used in the method below
    _AnsibleInternalRedirectLoader._redirect = 'ansible.builtin.get_url'
    # Create an instance of class _AnsibleInternalRedirectLoader and call methods of the class
    instance = _AnsibleInternalRedirectLoader()
    # The following makes an import of the module
    instance.load_module('ansible.modules.get_url')

test_case_0()
test__AnsibleInternalRedirectLoader_load_module()

# Generated at 2022-06-25 12:55:10.773518
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    ansible_collection_finder_1._remove()



# Generated at 2022-06-25 12:55:16.953218
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    ansible_collection_loader_0 = _AnsibleCollectionPkgLoader(None, 'ansible_collections.ns.collection_pkg', None)
    ansible_collection_loader_0.load_module("ansible_collections.ns.collection_pkg")


# Generated at 2022-06-25 12:55:23.679864
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase(
        'ansible_collections.connection.kubernetes',
        path_list=[[
            '/Users/ithiele/.ansible/collections/ansible_collections/connection/kubernetes/plugins/modules',
            '/Users/ithiele/.ansible/collections/ansible_collections/connection/kubernetes/collection/plugins/modules'
        ]]
    )

    ansible_collection_loader_0.get_code('ansible_collections.connection.kubernetes')


# Generated at 2022-06-25 12:55:28.423733
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.module_utils.six import PY2

    import_module1 = 'ansible.module_utils.parsing.convert_bool'
    import_module2 = 'ansible.module_utils.basic.basic'
    import_module3 = 'ansible.module_utils.six'

    ansible_internal_redirect_loader1 = _AnsibleInternalRedirectLoader.__new__(_AnsibleInternalRedirectLoader)
    # import_module_exception1 = 'ImportError: No module named module_utils.parsing.convert_bool'

# Generated at 2022-06-25 12:55:39.699695
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # case 0.1
    fqcr_name = 's1.c1.a_role'
    plugin_type = 'role'
    ansible_collection_ref_case_0_1 = AnsibleCollectionRef.try_parse_fqcr(fqcr_name, plugin_type)
    assert (ansible_collection_ref_case_0_1.collection == u's1.c1')
    assert (ansible_collection_ref_case_0_1.ref_type == u'role')
    assert (ansible_collection_ref_case_0_1.n_python_collection_package_name == u'ansible_collections.s1.c1')

# Generated at 2022-06-25 12:55:52.682753
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # expects to find dir /usr/share/ansible/collections/
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.sample',
        path_list=['/usr/share/ansible/collections/']
    )
    # expects to find /usr/share/ansible/collections/sample/__init__.py
    assert ansible_collection_loader_0.get_filename('ansible_collections.sample') == ansible_collection_loader_0._subpackage_search_paths[0] + '/__init__.py'

    # expects to find file /usr/share/ansible/collections/sample/mod.py

# Generated at 2022-06-25 12:55:58.230922
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Create a dummy _AnsibleCollectionPkgLoaderBase object
    test_object = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.coll', path_list=['/path/to/coll'])
    # set the values for method _get_candidate_paths
    test_object._get_candidate_paths = MagicMock(return_value = ['/path/to/coll/coll'])
    # set the values for method _get_subpackage_search_paths
    test_object._get_subpackage_search_paths = MagicMock(return_value = ['/path/to/coll/coll'])
    # set the values for method _validate_final
    test_object._validate_final = MagicMock(return_value = 'return_value')
    # set the values

# Generated at 2022-06-25 12:56:02.650698
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref = AnsibleCollectionRef('test_collection', None, 'test_resource', 'test_ref_type')
    assert ansible_collection_ref.__repr__() == 'AnsibleCollectionRef(collection=\'test_collection\', subdirs=\'\', resource=\'test_resource\')'


# Generated at 2022-06-25 12:56:25.461062
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ns_coll_name = 'ns.coll'
    subdirs = 'test_subdir1.test_subdir2'
    resource = 'testresource'
    ref_type = 'module'

    ref = AnsibleCollectionRef(ns_coll_name, subdirs, resource, ref_type)
    assert repr(ref) == "AnsibleCollectionRef(collection='ns.coll', subdirs='test_subdir1.test_subdir2', resource='testresource')"



# Generated at 2022-06-25 12:56:33.430399
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # check the invalid input case
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('ns.coll.resource.ext', 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module.ext')

    # check the valid input case
    # check the normal non-extension case
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ansible_collection_ref.collection == u'ns.coll'
    assert ansible_collection_ref.subdirs == u''
    assert ansible_collection_ref.resource == u'resource'
    assert ansible_collection_ref.ref_type == 'module'
    assert ansible

# Generated at 2022-06-25 12:56:37.216582
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_pkg_loader_base_1 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
    return ansible_collection_pkg_loader_base_1.load_module('ansible_collections.ns.module')
    #assert(True)


# Generated at 2022-06-25 12:56:48.861631
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef(u'foo.abc', u'', u'xyz', u'module').fqcr == u'foo.abc.xyz'
    assert AnsibleCollectionRef(u'foo.abc', u'', u'xyz', u'module').n_python_package_name == u'ansible_collections.foo.abc.plugins.module'

    try:
        AnsibleCollectionRef(u'foo.abc', u'', u'xyz', u'foo')
        assert 1 == 0
    except:
        assert 1 == 1

    try:
        AnsibleCollectionRef(u'foo.abc', u'', u'xyz', u'action')
        assert 1 == 1
    except:
        assert 1 == 0

    # test for dynamic collection loader
    AnsibleCollectionFinder._module_cache

# Generated at 2022-06-25 12:56:49.726867
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])


# Generated at 2022-06-25 12:56:56.661010
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    expected_from_fqcr_0 = AnsibleCollectionRef(collection='namespace.collection', subdirs=u'', resource='resource', ref_type=u'module')
    actual_from_fqcr_0 = AnsibleCollectionRef.from_fqcr('namespace.collection.resource', ref_type=u'module')
    assert actual_from_fqcr_0.fqcr == expected_from_fqcr_0.fqcr, "Failed to parse the fqcr 'namespace.collection.resource' with ref_type=module"
    
    expected_from_fqcr_1 = AnsibleCollectionRef(collection='namespace.collection', subdirs=u'subdir1', resource='resource', ref_type=u'module')
    actual_from_fqcr_1 = Ans

# Generated at 2022-06-25 12:57:03.441956
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns0.coll0.mod0', 'module') == True, "Failed for testing is_valid_fqcr for 'ns0.coll0.mod0'"
    assert AnsibleCollectionRef.is_valid_fqcr('ns0.coll0.mod0') == True, "Failed for testing is_valid_fqcr for 'ns0.coll0.mod0'"
    assert AnsibleCollectionRef.is_valid_fqcr('ns0.coll0.rol0', 'role') == True, "Failed for testing is_valid_fqcr for 'ns0.coll0.rol0'"

# Generated at 2022-06-25 12:57:08.214318
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    if AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') != 'action':
        raise AssertionError()

if __name__ == '__main__':
    test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type()

# Generated at 2022-06-25 12:57:16.270462
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    class _AnsibleInternalRedirectLoader_load_module(object):
        def __init__(self, _fullname, path_list):
            self._fullname = _fullname
            self._path_list = path_list

    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader_load_module('ansible.plugins.connection.basic', ['/tmp/build_dir/ansible-test-test__AnsibleInternalRedirectLoader_load_module/lib/ansible/plugins/connection/basic.py'])
    try:
        ansible_internal_redirect_loader.load_module()
        assert True
    except:
        assert False



# Generated at 2022-06-25 12:57:19.325864
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    test_class = AnsibleCollectionRef("ns.coll", "subdir1.subdir2", "myres", "role")
    test_class2 = AnsibleCollectionRef("ns.coll", "subdir1", "myres", "playbook")


# Generated at 2022-06-25 12:57:44.133414
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader_0 = _AnsibleInternalRedirectLoader(fullname='ansible.internal.common', path_list='ansible.test.test_utils.test_collections.test__AnsibleInternalRedirectLoader_load_module.<locals>.path_list_0')
    loader_0.load_module()


# Generated at 2022-06-25 12:57:51.008809
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    temp_path = tempfile.mkdtemp()
    test_file = os.path.join(temp_path, 'test.py')
    with open(test_file, 'w') as f:
        f.write("a = 1")
    loader = _AnsibleCollectionPkgLoaderBase(test_file, temp_path)
    assert(loader.get_source(test_file) == b"a = 1")


# Generated at 2022-06-25 12:58:01.137095
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_path = os.path.join(os.getcwd(), 'test', 'files', 'sample_ansible_collections')
    ansible_collections_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.mycollection.myns', [ansible_collection_path])
    module = ansible_collections_loader_0.load_module('ansible_collections.mycollection.myns')
    assert module
    module = ansible_collections_loader_0.load_module('ansible_collections.mycollection.myns.myplugin')
    assert module
    module = ansible_collections_loader_0.load_module('ansible_collections.mycollection.myns.myplugin2')
    assert module
    module = ansible_collections_loader_0

# Generated at 2022-06-25 12:58:06.431531
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader_0 = _AnsibleCollectionPkgLoaderBase(fullname='unit_test', path_list=['/tmp'])
    code_obj_0 = loader_0.get_code('unit_test')
    assert code_obj_0 == None

if __name__ == "__main__":
    test_case_0()
    test__AnsibleCollectionPkgLoaderBase_get_code()

# Generated at 2022-06-25 12:58:14.498685
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    print("Testing get_filename of AnsibleCollectionLoader")
    expected_code_path = '/root/.ansible/collections/ansible_collections/test_namespace/test_collection/plugins/module_utils/test_lib.py'
    collection_finder_0 = _AnsibleCollectionFinder()
    collection_finder_0._find_module_paths = {
        'test_namespace': ['/root/.ansible/collections/ansible_collections']
    }
    collection_finder_0._matching_collections = [
        '/root/.ansible/collections/ansible_collections/test_namespace/test_collection'
    ]

# Generated at 2022-06-25 12:58:20.413843
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    a = AnsibleCollectionRef
    # Check for plugin_dir 'action_plugins'
    if a.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action':
        print("test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type - passed")
    else:
        print("test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type - failed")


# Generated at 2022-06-25 12:58:25.477199
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test for valid string for fqcr
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.py')
    # Test for wrong string for fqcr
    assert not AnsibleCollectionRef.is_valid_fqcr('')
    # Test for mixed string for fqcr
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.py1')
    # Test for mixed string for fqcr
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.1')



# Generated at 2022-06-25 12:58:36.641358
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Testing with correct and incorrect refs
    correct_refs = [
        'ns.coll.res', 'ns.coll.res.ext', 'ns.coll.res.ext.ext2',
        'ns.coll.sub1.res', 'ns.coll.sub1.res.ext', 'ns.coll.sub1.res.ext.ext2',
        'ns.coll.sub1.sub2.res', 'ns.coll.sub1.sub2.res.ext', 'ns.coll.sub1.sub2.res.ext.ext2'
    ]


# Generated at 2022-06-25 12:58:46.371243
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-25 12:58:53.127453
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoader(path="test_path",
                                                                target_type=None,
                                                                target_name="test_name")
    ansible_collection_pkg_loader.load_module("test_name")
    ansible_collection_pkg_loader.load_module("test_name")
    ansible_collection_pkg_loader.load_module("test_name")


# Generated at 2022-06-25 13:00:01.034344
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Not implemented yet
    fullname = 'ansible.internal.debug'
    path_list = []
    _AnsibleCollectionLoader = _AnsibleInternalRedirectLoader(fullname, path_list)



# Generated at 2022-06-25 13:00:11.296995
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Positive tests
    # case 1: no prefix, no subdirs, with ext
    assert str(AnsibleCollectionRef.from_fqcr('ns.coll.resource.yml', 'playbook')) == "AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='resource.yml')"
    # case 2: with prefix, no subdirs, with ext
    assert str(AnsibleCollectionRef.from_fqcr('path.to.ansible_collections.ns.coll.resource.yml', 'playbook')) == "AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='resource.yml')"
    # case 3: with prefix, no subdirs, no ext