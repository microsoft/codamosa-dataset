

# Generated at 2022-06-25 12:51:11.950318
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.f5networks.tests.unit.plugins.modules')
    loader._source_code_path = '/home/joe/devel/ansible/lib/ansible/config/module_docs.py'
    loader._decoded_source = b'#!/usr/bin/env python\n# -*- coding: utf-8 -*-\n\n"""\n:copyright: (c) 2012 by the Ansible Project\n:license: BSD, see LICENSE for more details.\n"""\n\n\n'
    source_code = loader.get_source(loader._fullname)
    assert source_code is not None
    # assert source_code == b'#!/usr/bin/env python\n# -*- coding: ut

# Generated at 2022-06-25 12:51:22.780047
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    logger.info('start test__AnsibleCollectionPkgLoaderBase_load_module')
    module_name = 'ansible.module_utils.basic'
    module_namespace = {}

    # Create a test package loader
    module_loader = _AnsibleCollectionPkgLoaderBase(module_name, ['/usr/share/ansible/plugins/module_utils'])

    # Load the module
    sys.modules[module_name] = module_namespace
    module_loader.load_module(module_name)

    # Check the results
    logger.info('check results')
    if module_namespace['json_dict'] != {'k1': 'v1', 'k2': 2, 'k3': 'v2'}:
        print('Error: test failed')
        logger.error('Error: test failed')


# Generated at 2022-06-25 12:51:28.690899
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    pkg_loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.ns.module'
    )
    assert pkg_loader.get_source('ansible_collections.ns.module') is None
    assert pkg_loader._decoded_source is None
    assert pkg_loader._source_code_path is None


# Generated at 2022-06-25 12:51:31.021889
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = AnsibleCollectionRef.is_valid_fqcr('my_collection.my_role')
    assert ref is True


# Generated at 2022-06-25 12:51:38.753314
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """
    Tests the from_fqcr method of class AnsibleCollectionRef
    """
    ar1 = AnsibleCollectionRef.from_fqcr('namespace.collection.module', 'module')
    assert ar1.collection == 'namespace.collection'
    assert ar1.subdirs == ''
    assert ar1.resource == 'module'
    assert ar1.ref_type == 'module'
    assert ar1.fqcr == 'namespace.collection.module'
    assert ar1.n_python_collection_package_name == 'ansible_collections.namespace.collection'
    assert ar1.n_python_package_name == 'ansible_collections.namespace.collection.plugins.module'


# Generated at 2022-06-25 12:51:50.875959
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class _AnsibleCollectionPkgLoaderBase_Test(ImportTestCase, TestCase):
        def setUp(self):
            self.test_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.testcol')

        def test_get_code_example(self):
            self.test_loader._subpackage_search_paths = None
            self.assertEqual(self.test_loader.get_code('ansible_collections.testcol'), None)
            # TODO: add more tests
            # TODO: what do we want encoding/newline requirements to be?
            # TODO: assertRaises is a context manager, use it
            pass

    test_cases_0 = _AnsibleCollectionPkgLoaderBase_Test()
    test_cases_0.setUp()
    test_cases_0

# Generated at 2022-06-25 12:51:53.574919
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    no_code_loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo.bar", path_list=[])
    assert no_code_loader.get_code("ansible_collections.foo.bar") is None


# Generated at 2022-06-25 12:51:57.283655
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    collection_name = 'Ansible.test';
    loader = AnsibleCollectionPackageLoader(collection_name, path_list=['/some/path']);
    result = loader.__repr__();
    assert result == '{0}(path=/some/path)'.format(loader.__class__.__name__);


# Generated at 2022-06-25 12:52:02.660780
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    ansible_collection_ref_0 = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert ansible_collection_ref_0 == 'action'

    ansible_collection_ref_1 = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert ansible_collection_ref_1 == 'module'

    try:
        ansible_collection_ref_2 = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('abc')
    except ValueError:
        pass
    else:
        assert False, "expected ValueError to be thrown"


# Generated at 2022-06-25 12:52:08.801078
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()

    # TODO: need to figure out how to mock a path hook in unit test
    # ansible_collection_finder_0.set_playbook_paths(["/tmp/test0", "/tmp/test1"])

    # test for constructor
    ansible_path_hook_finder_0_result = _AnsiblePathHookFinder(ansible_collection_finder_0, '/tmp')
    assert ansible_path_hook_finder_0_result
    assert ansible_path_hook_finder_0_result._pathctx == '/tmp'
    assert ansible_path_hook_finder_0_result._collection_finder == ansible_collection_finder_0
    assert not ansible_path_hook_finder_0_result._file_finder

# Generated at 2022-06-25 12:52:30.918776
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, 'ansible_collections')
    ansible_path_hook_finder_0.find_module('ansible_collections')


# Generated at 2022-06-25 12:52:33.155859
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths(['collections'])


# Generated at 2022-06-25 12:52:45.987121
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ldr = _AnsibleInternalRedirectLoader('ansible.plugins.module_utils', None)
    # force an exception by creating an empty dictionary
    ldr._redirect = {}
    # Since this is an empty dictionary we should get a ValueError
    with pytest.raises(ValueError) as value_error:
        ldr.load_module('ansible.plugins.module_utils')
        assert 'no redirect found for ansible.plugins.module_utils' in value_error

    ldr = _AnsibleInternalRedirectLoader('ansible.plugins.module_utils', None)
    # force an exception by creating a string
    ldr._redirect = 'ansible.builtin.module_utils'
    # Since this is a string we should get an exception

# Generated at 2022-06-25 12:52:56.049242
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Create a new AnsibleCollectionRef object
    ansible_collection_ref = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'role')


    # Case 1: ref_type is "role" and ref ends with 'yml' or 'yaml'
    # Create a new AnsibleCollectionRef object
    ansible_collection_ref_from_fqcr_case_1 = AnsibleCollectionRef.from_fqcr('namespace.collection.subdir1.subdir2.resource.yml', 'role')

    # Assert object properties
    assert ansible_collection_ref_from_fqcr_case_1.collection == ansible_collection_ref.collection
    assert ansible_collection_ref_from_fqcr_case_1.subdirs == ansible_collection_

# Generated at 2022-06-25 12:53:02.711732
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # Test simple case
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    fullname_0 = 'ansible.module_utils.nat'
    path_0 = None
    assert isinstance(ansible_collection_finder_0.find_module(fullname_0, path_0), _AnsibleInternalRedirectLoader)

    # Test mixed case
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    fullname_1 = 'ansible.module_utils.complex_args'
    path_1 = None
    assert isinstance(ansible_collection_finder_1.find_module(fullname_1, path_1), _AnsibleInternalRedirectLoader)

    # Test mixed case
    ansible_collection_finder_2 = _AnsibleCollectionFinder()


# Generated at 2022-06-25 12:53:04.143025
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins")
    assert plugin_type == "action"


# Generated at 2022-06-25 12:53:08.068013
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(fullname="", path_list=[])
    try:
        ansible_internal_redirect_loader.load_module("")
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 12:53:16.774204
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('test.module', 'module').fqcr == 'test.module'
    assert AnsibleCollectionRef.try_parse_fqcr('test.module', 'module').ref_type == 'module'
    assert AnsibleCollectionRef.try_parse_fqcr('test.module') == None
    assert AnsibleCollectionRef.try_parse_fqcr('test.module', 'role') == None
    assert AnsibleCollectionRef.try_parse_fqcr('test.test.test.test', 'module') == None
    assert AnsibleCollectionRef.try_parse_fqcr('test.test.test.test') == None
    assert AnsibleCollectionRef.try_parse_fqcr('test.module', 'test').resource == 'module'


# Generated at 2022-06-25 12:53:19.828055
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    full_name = 'ansible_collections.community.general.plugins.modules.setup'
    loader = _AnsibleCollectionPkgLoaderBase(full_name)
    # execution starts here
    module = loader.load_module(full_name)


# Generated at 2022-06-25 12:53:31.153428
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    class DummyAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname):
            _AnsibleCollectionPkgLoaderBase.__init__(self, fullname)
        def get_code(self, fullname):
            return compile(source='__file__ = "__init__.py"', filename=self._fullname, mode='exec', flags=0, dont_inherit=True)

    loader = DummyAnsibleCollectionPkgLoaderBase("ansible_collections.my_namespace.my_collection")
    module = loader.load_module("ansible_collections.my_namespace.my_collection")

    assert module.__file__ == "__init__.py"


# Generated at 2022-06-25 12:54:59.367677
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(
        'ansible_collections.ansible.modules_core')
    print('Expected:', "ansible_collections.ansible.modules_core")
    print('Actual:', ansible_collection_pkg_loader_base_0.package_to_load)
    if ansible_collection_pkg_loader_base_0.package_to_load == "ansible_collections.ansible.modules_core":
        print("Test Passed")
    else:
        print("Test Failed")


# Generated at 2022-06-25 12:55:04.479890
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class TestAnsibleCollectionPkgLoader(_AnsibleCollectionPkgLoader):
        def __init__(self, split_name, package_to_load, candidate_paths):
            super(TestAnsibleCollectionPkgLoader, self).__init__(split_name, package_to_load, candidate_paths)
            self._subpackage_search_paths = [os.path.join(self._subpackage_search_paths[0], 'subdir')]

    loader = TestAnsibleCollectionPkgLoader(
        split_name=['ansible_collections', 'foobar', 'barpackage'],
        package_to_load='barpackage',
        candidate_paths=['/tmp/collections_test/1', '/tmp/collections_test/2']
    )

    module = loader.load_module

# Generated at 2022-06-25 12:55:06.543872
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # test for redirection to a non-existing module
    with pytest.raises(ImportError):
        __AnsibleInternalRedirectLoader = _AnsibleInternalRedirectLoader('ansible.builtin.abc', [])



# Generated at 2022-06-25 12:55:11.736778
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test for execution of method load_module when exception is raised.
    with pytest.raises(ValueError) as err_info:
        _AnsibleCollectionPkgLoader(path=None)

    assert 'ansible.utils.collection_loader._meta_yml_to_dict is not set' in str(err_info.value)

    # Test for execution of method load_module when exception is raised.
    with pytest.raises(ValueError) as err_info:
        _AnsibleCollectionPkgLoader(path=None)
        _AnsibleCollectionPkgLoader._meta_yml_to_dict = lambda x: True
        _AnsibleCollectionPkgLoader(path=None)


# Generated at 2022-06-25 12:55:23.645531
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    class mock_module_spec(object):
        def __init__(self, name):
            self.name = name
    path = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, 'plugins', 'modules')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections', path)
    search_paths = [os.path.join(path, f) for f in os.listdir(path) if os.path.isdir(os.path.join(path, f))]
    loader._subpackage_search_paths = search_paths
    modules = list(loader.iter_modules('ansible_collections'))
    assert len(modules) == 14


# Generated at 2022-06-25 12:55:35.220205
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    print("\ntest_AnsibleCollectionRef_from_fqcr:")
    try:
        ansible_collection_ref = AnsibleCollectionRef.from_fqcr("joe.mycoll", "module")
    except ValueError as e:
        print("ansible_collection_ref = AnsibleCollectionRef.from_fqcr(\"joe.mycoll\", \"module\"): ValueError: " + str(e))
        return 1
    print("ansible_collection_ref = AnsibleCollectionRef.from_fqcr(\"joe.mycoll\", \"module\")")
    print("ansible_collection_ref.ref_type = " + ansible_collection_ref.ref_type)
    print("ansible_collection_ref.collection = " + ansible_collection_ref.collection)

# Generated at 2022-06-25 12:55:44.915929
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    fullname = 'ansible_collections.testns.sub'
    filename = 'ansible_collections/testns/sub/__init__.py'
    code = compile(source='def foo(): return 1', filename=filename, mode='exec', flags=0, dont_inherit=True)

    class fake_loader(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname):
            _AnsibleCollectionPkgLoaderBase.__init__(self, fullname)
            self._source_code_path = filename
            self._compiled_code = code
            self._subpackage_search_paths = ['tmp']

    loader = fake_loader(fullname)

    # test that get_code() of class _AnsibleCollectionPkgLoaderBase returns the code
    assert loader.get_code

# Generated at 2022-06-25 12:55:49.078581
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    collection_name = 'namespace.collectionname'
    resource = 'resource'
    resource_good = []
    resource_good.append(resource)
    resource_good.append(resource + '.py')
    resource_good.append(resource + '.txt')
    resource_good.append(resource + '.testing')
    resource_good.append(resource + '.testing.txt')
    resource_good.append(resource + '.testing.py')
    resource_good.append(resource + '.juniper_junos')
    resource_good.append(resource + '.juniper_junos.txt')
    resource_good.append(resource + '.juniper_junos.py')
    resource_bad = []
    resource_bad.append(resource + '.t/xt')
    resource_bad.append(resource + '.t.xt')
   

# Generated at 2022-06-25 12:55:53.206557
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('ansible.builtin.ansible_builtin',
                                                                        ['ansible.builtin.ansible_builtin'])



# Generated at 2022-06-25 12:56:02.383566
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    params_1 = ('ansible', None)
    try:
        ansible_collection_finder_1.find_module(*params_1)
    except NotImplementedError:
        pass

    params_2 = ('ansible', ['abc', 'def'])
    try:
        ansible_collection_finder_1.find_module(*params_2)
    except NotImplementedError:
        pass

    params_3 = ('ansible_collections', None)
    try:
        ansible_collection_finder_1.find_module(*params_3)
    except NotImplementedError:
        pass

    params_4 = ('ansible_collections', ['abc', 'def'])

# Generated at 2022-06-25 12:56:35.922499
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref_0 = AnsibleCollectionRef(u'namespace.collection', u'subdir1.subdir2', u'mymodule', u'module')


# Generated at 2022-06-25 12:56:43.660864
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    a = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.collection1.module1')
    a._subpackage_search_paths = ['/Users/xxx/ansible_collections/ns/collection1/module1']
    f = a.get_filename('ansible_collections.ns.collection1.module1')
    assert f == '/Users/xxx/ansible_collections/ns/collection1/module1'
    assert isinstance(a, _AnsibleCollectionPkgLoaderBase)



# Generated at 2022-06-25 12:56:53.208848
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    dirname = os.path.dirname(__file__)

# Generated at 2022-06-25 12:56:59.302877
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    x = _AnsibleCollectionPkgLoaderBase('.')
    try:
        x.get_data(None)
        assert False, "Expected exception not found"
    except:
        pass

    try:
        x.get_data('/tmp/file1.txt')
        assert False, "Expected exception not found"
    except:
        pass


# Generated at 2022-06-25 12:57:08.158604
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_module = MockModule(name = 'ansible.builtin.file')
    test_module.__loader__ = _AnsibleInternalRedirectLoader(fullname='ansible.builtin.file', path_list=[])

    assert test_module.__name__ == 'ansible.builtin.file'
    assert test_module.__loader__._redirect == None

    test_module.__loader__.load_module(fullname='ansible.builtin.file')
    assert test_module.__loader__._redirect == 'ansible.builtin.file_permission'


# Generated at 2022-06-25 12:57:16.960737
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, '.')

    import ansible_collections
    import ansible_collections.ansible
    import ansible_collections.foo
    
    import ansible_collections.ansible.bar
    import ansible_collections.ansible.baz
    import ansible_collections.foo.baaar
    import ansible_collections.foo.baaz
    
    import ansible_collections.ansible.bar.deep
    import ansible_collections.ansible.baz.deeper
    import ansible_collections.foo.baaar.deepest
    import ansible_collections.foo

# Generated at 2022-06-25 12:57:23.979367
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    test_cases = dict()
    test_cases['ansible_collections.gp.my_collection'] = None
    test_cases['ansible_collections.gp.my_collection.plugins.lookup'] = None
    test_cases['ansible_collections.gp.my_collection.plugins.lookup.my_plugin'] = None
    test_cases['ansible_collections.gp.my_collection.plugins.lookup.my_plugin.my_module'] = None
    test_cases['ansible_collections.gp.my_collection.plugins.lookup.my_plugin.my_other_module'] = None
    test_cases['ansible_collections.gp.my_collection.plugins.lookup.my_plugin.my_package'] = None

# Generated at 2022-06-25 12:57:28.099666
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    testcases = [("ansible.test", False),
                 ("ansible.test_collection_name", False),
                 ("ansible.test_test", False),
                 ("ansible.test.", False),
                 ("ansible.test", True),
                 ("ansible_test.test", False),
                 ("ansible_test.test", True),
                 ("ansible.test_test.test", True),
                 ("ansible.test test", False),
                 ("ansible.test_test.test.", False),
                 ("ns1.collection1", True),
                 ("ns1.collection1.", False),
                 ("ns1.ns2.collection1", False),
                 ("ns1.test_test.test", True),
                 ]
    for testcase in testcases:
        assert AnsibleCollectionRef.is_valid_collection_name

# Generated at 2022-06-25 12:57:30.633854
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader_0 = _AnsibleInternalRedirectLoader('ansible.module_utils.facts', ['path'])
    loader_0.load_module('ansible.module_utils.facts')


# Generated at 2022-06-25 12:57:31.958553
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ansible_collection_ref_0 = AnsibleCollectionRef.is_valid_fqcr('foo.bar.baz')
    assert ansible_collection_ref_0


# Generated at 2022-06-25 12:58:06.880793
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert _AnsibleInternalRedirectLoader('ansible.builtin', '')
    assert _AnsibleInternalRedirectLoader('hello.world', '')
    assert _AnsibleInternalRedirectLoader('ansible.builtin.ping', '')


# Generated at 2022-06-25 12:58:12.670528
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    LEGACY_PACKAGE_NAME = 'ansible_collections.namespace.collection.plugins.module_utils.mymodule'
    LEGACY_PLUGIN_PATH = '/path/to/collections/namespace/collection/plugins/module_utils/mymodule.py'
    LEGACY_MODULE_FQCR = 'test_fqcr'
    LEGACY_MODULE_NAME = 'test_name'
    LEGACY_MODULE_DOC = 'test_doc'
    LEGACY_MODULE_LOADER_CLASS = 'test_loader'
    LEGACY_MODULE_PATH = 'test_module_path'
    LEGACY_SUBDIRS = 'test_subdirs'
    LEGACY_REF_TYPE = 'test_ref_type'
    LEGACY_REF_NAME = 'test_ref_name'

# Generated at 2022-06-25 12:58:18.934173
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    loader = _AnsibleCollectionPkgLoader('ansible.collections.my_collection.plugins', [''], 'plugins')
    loader.get_data = MagicMock()
    loader.get_data.return_value = 'toto\ntiti\ntata'
    loader.is_package = MagicMock()
    loader.is_package.return_value = True
    loader.get_code = MagicMock()
    loader.get_code.return_value = None
    module = loader.load_module('my_name')
    loader.is_package.assert_called_once_with('my_name')
    assert module.__file__ == '<ansible_synthetic_collection_package>'
    assert module.__doc__ == 'toto\ntiti\ntata'

# Generated at 2022-06-25 12:58:23.169412
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.init_paths()
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(ansible_collection_finder_0.collection_root_paths, 'ansible.posix', '__init__')
    ansible_collection_pkg_loader_0._meta_yml_to_dict = lambda raw_metadata, meta_data_name: {}
    ansible_collection_pkg_loader_0.load_module('ansible.posix')


# Generated at 2022-06-25 12:58:32.409074
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:58:42.824855
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:58:49.773968
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    reference_list = [
        ('x.y.z', True),
        ('x.y', False),
        ('x.y.z.a', False),
        ('x.y..z', False),
        ('x.y.!z', False),
        ('x.y.zi', True),
        ('ansible.builtin.vars.foo', True),
        ('ansible.builtin.vars.foo.bar', True),
        ('ansible.builtin.vars.foo.bar.baz', False),
        ('ansible.builtin.vars.foo.bar.baz', True),
        ('ansible.builtin.vars.foo.!bar', False),
    ]

    for (reference, expected) in reference_list:
        result = AnsibleCollectionRef.is_valid_fq

# Generated at 2022-06-25 12:58:56.417112
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Test data
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    fullname = "ansible_collections"
    path = ["/usr/local/lib/python3.6/site-packages/ansible_collections", "/home/ansible/.ansible/collections"]

    # Call the method under test
    ansible_collection_finder_0.find_module(fullname, path)

    # Test assertions
    assert ansible_collection_finder_0 is not None



# Generated at 2022-06-25 12:58:59.640408
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    args = ('ansible.builtin.my_action', 'action')
    ans = AnsibleCollectionRef.is_valid_fqcr(*args)
    assert ans == True


# Generated at 2022-06-25 12:59:09.253330
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Create a fake directory, so as to be able to iterate on it
    test_iter_modules_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_iter_modules")
    os.makedirs(test_iter_modules_path)

    # Create fake files / dirs to test that iter_modules works as expected
    os.mkdir(os.path.join(test_iter_modules_path, "fake_dir_1"))
    open(os.path.join(test_iter_modules_path, "fake_dir_1", "__init__.py"), "w").close()
    open(os.path.join(test_iter_modules_path, "fake_dir_1", "fake_1.py"), "w").close()

# Generated at 2022-06-25 13:00:07.350079
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdir1.subdir2.subdir3.subdir4.subdir5.subdir6.subdir7.subdir8.subdir9.subdir10.subdir11.subdir12.subdir13.subdir14.subdir15.subdir16.subdir17.subdir18.subdir19.subdir20.subdir21.subdir22.subdir23.subdir24.subdir25.subdir26.subdir27.subdir28.subdir29.subdir30.subdir31.subdir32.subdir33.subdir34.subdir35.resource')

# Generated at 2022-06-25 13:00:11.730476
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    finder = _AnsibleCollectionFinder()
    assert finder.find_module('ansible_collections.foo.bar') is not None
