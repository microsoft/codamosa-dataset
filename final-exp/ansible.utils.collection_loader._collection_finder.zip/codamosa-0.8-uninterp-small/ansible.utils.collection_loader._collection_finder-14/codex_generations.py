

# Generated at 2022-06-25 12:51:00.381469
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    loader_base = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.mock_collection',
                                                  path_list=['/home/david/.ansible/collections/ansible_collections/mock_collection'])
    loader_base.get_data('/home/david/.ansible/collections/ansible_collections/mock_collection/mock_namespace/tasks/main.yml')


# Generated at 2022-06-25 12:51:11.839225
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert (AnsibleCollectionRef.try_parse_fqcr('mycollection.mymod', 'module') == AnsibleCollectionRef('mycollection.mymod', '', 'mymod', 'module'))
    assert (AnsibleCollectionRef.try_parse_fqcr('mycollection.subdir.mymod', 'module') == AnsibleCollectionRef('mycollection.subdir', 'subdir', 'mymod', 'module'))
    assert (AnsibleCollectionRef.try_parse_fqcr('mycollection.subdir.subdir.mymod', 'module') == AnsibleCollectionRef('mycollection.subdir', 'subdir.subdir', 'mymod', 'module'))

# Generated at 2022-06-25 12:51:14.197952
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    obj = _AnsibleCollectionRootPkgLoader("ansible_collections")


# Generated at 2022-06-25 12:51:22.821253
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase("test_ns.test_collection")
    assert ansible_collection_loader_0._AnsibleCollectionPkgLoaderBase__init__("test_ns.test_collection") == None
    assert ansible_collection_loader_0.get_code("test_ns.test_collection") != None
    assert ansible_collection_loader_0.is_package("test_ns.test_collection") == True
    assert ansible_collection_loader_0.get_source("test_ns.test_collection") != None

# This is a module that doesn't exist, to test if ImportError is raised

# Generated at 2022-06-25 12:51:27.083303
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # a. No subdirs
    #    i. No extension
    #    ii. Extension
    # b. Subdirs
    #    i. No extension
    #    ii. Extension
    # c. No collection reference
    # d. No resource

    # a.i.
    parsed_ref = AnsibleCollectionRef.from_fqcr(u'collection.role', u'role')
    assert parsed_ref.n_python_package_name == 'ansible_collections.collection.roles'
    assert parsed_ref.n_python_collection_package_name == 'ansible_collections.collection'
    assert parsed_ref.resource == 'role'
    assert parsed_ref.fqcr == 'collection.role'

    # a.ii.
    parsed_ref = AnsibleCollectionRef.from_fqcr

# Generated at 2022-06-25 12:51:29.918885
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader_base = _AnsibleCollectionPkgLoaderBase('test', path_list=['/test/test'])
    loader_base.get_filename('test')


# Generated at 2022-06-25 12:51:36.727582
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # Test 1:
    # This method tests the constructor of class _AnsibleCollectionRootPkgLoader.
    # Test 1 is expected to SUCCEED.
    root_pkg_loader_0 = _AnsibleCollectionRootPkgLoader(fullname="ansible_collections")


# Generated at 2022-06-25 12:51:38.073438
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    test_case_0()



# Generated at 2022-06-25 12:51:50.745404
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, "test_path_hook_finder_0")
    split_name_0 = "123.456".split(".")
    toplevel_pkg_0 = split_name_0[0]
    if (toplevel_pkg_0 == "ansible_collections"):
        # collections content? delegate to the collection finder
        ansible_collection_finder_0.find_module("123.456", path=["test_path_hook_finder_0"])
    else:
        if (PY3):
            if not (path_hook_finder_0._file_finder):
                path_hook_finder_0._file_finder

# Generated at 2022-06-25 12:52:00.042080
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    f = _AnsibleCollectionPkgLoaderBase(fullname = 'ansible_collections.geerlingguy.dns',
                                        path_list = ['/path/to/collection/containing/dns/package'])
    f._source_code_path = None
    assert f.get_source(fullname = 'ansible_collections.geerlingguy.dns') is None

    f = _AnsibleCollectionPkgLoaderBase(fullname = 'ansible_collections.geerlingguy.dns',
                                        path_list = ['/path/to/collection/containing/dns/package'])
    f._source_code_path = '/path/to/collection/containing/dns/package/__init__.py'

# Generated at 2022-06-25 12:53:30.789627
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader()
    assert _ansible_internal_redirect_loader.load_module('../playbooks/play_utils.py') == '__init__.py'


# Generated at 2022-06-25 12:53:33.768851
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('foo.bar', path_list=[])
    filename = loader.get_filename('foo.bar')
    if filename != None:
        raise Exception('loader.get_filename: expected value None, got ' + str(filename))


# Generated at 2022-06-25 12:53:36.044877
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths(playbook_paths=['/home/nano/.ansible/collections'])


# Generated at 2022-06-25 12:53:40.342055
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens', path_list=['C:\\Users\\BHARRIN2'])
    test_module_0 = ansible_collection_loader_0.load_module('ansible_collections.somens.test_module_0')
    return (test_module_0.__file__)


# Generated at 2022-06-25 12:53:49.184190
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # variable init
    collection_ns = 'ansible_collections.collection_ns'
    collection_pkg = 'ansible_collections.collection_ns.collection_pkg'
    collection_pkg_contents = 'ansible_collections.collection_ns.collection_pkg.pkg_contents'
    ansible_contents = 'ansible_collections.ansible.ansible_contents'
    ansible_ns = 'ansible_collections.ansible'
    ansible_pkg = 'ansible_collections.ansible.ansible_pkg'
    ansible_pkg_contents = 'ansible_collections.ansible.ansible_pkg.pkg_contents'

    # Test with missing parameter

# Generated at 2022-06-25 12:53:59.906269
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # test with a _AnsibleCollectionPkgLoaderBase instance
    coll_loader_0 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.plugin',
                                                   path_list=[C.COLLECTIONS_PATHS])
    is_pkg_0 = coll_loader_0.is_package('ansible_collections.ns.plugin')
    if is_pkg_0 != True:
        raise AssertionError('ansible_collections.ns.plugin is a package but not recognized as such')

    # test with an existing module (no package)
    coll_loader_1 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.plugin.module',
                                                   path_list=[C.COLLECTIONS_PATHS])
    is_pkg_1

# Generated at 2022-06-25 12:54:05.021491
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_pkg_loader_0 = _AnsibleCollectionPkgLoader('/home/capa/ansible-collections/ansible_collections/jctanner/foo', 'ansible_collections.jctanner.foo', 'foo', {'/home/capa/ansible-collections', '/home/capa/ansible-modules'})
    collection_pkg_loader_0.load_module('ansible_collections.jctanner.foo')
    collection_pkg_loader_0.load_module('foo')



# Generated at 2022-06-25 12:54:09.537926
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref_types = ['module', 'lookup', 'role', 'playbook']

# Generated at 2022-06-25 12:54:20.529910
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0._install()
    ansible_collection_finder_0.set_playbook_paths([os.path.dirname(__file__)])
    ansible_collection_finder_0._reload_hack('ansible.module_utils.basic')
    # Test 1, call method find_module of class _AnsiblePathHookFinder with arguments fullname='ansible_collections.some.collection', path=None
    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, to_native(os.path.join(os.path.dirname(__file__), 'ansible_collections'), errors='surrogate_or_strict'))

# Generated at 2022-06-25 12:54:28.936313
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    _AnsibleCollectionPkgLoader_load_module_class_0 = _AnsibleCollectionPkgLoader('', '', None)

    # Usage 1: Test with valid input
    ansible_collection_finder_0.path = ['/home/vagrant/.ansible/collections/ansible_collections/test_namespace/test_collection/mylib']
    _AnsibleCollectionPkgLoader_load_module_class_0.module_name = 'ansible.ansible_collections.test_namespace.test_collection.mylib'

# Generated at 2022-06-25 12:55:24.876938
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    mymodule = _AnsibleInternalRedirectLoader('ansible.builtin.package', '')
    assert hasattr(mymodule, 'load_module')
    assert callable(getattr(mymodule, 'load_module'))

ansible_collection_finder_0 = _AnsibleCollectionFinder()


# Generated at 2022-06-25 12:55:34.757531
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.mymodule', 'module')
    assert ref==None

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.mymodule', 'module')
    assert ref.collection == 'ns.coll'

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.mymodule', 'module')
    assert ref.subdirs == ''

    ref = AnsibleCollectionRef.try_parse_fqcr('ns.coll.mymodule', 'module')
    assert ref.resource == 'mymodule'


# Generated at 2022-06-25 12:55:44.227116
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ar1 = AnsibleCollectionRef("foo.bar", None, "baz", "role")
    ar2 = AnsibleCollectionRef("foo.bar", None, "baz", "role")
    ar3 = AnsibleCollectionRef("foo.bar", None, "baz", "not a real ref type")
    ar4 = AnsibleCollectionRef("foo.bar", None, "baz", None)
    assert(ar1 != ar2)
    assert(ar1 == ar2)
    assert(str(ar1) == "AnsibleCollectionRef(collection='foo.bar' subdirs='' resource='baz')")
    assert(ar1.ref_type == "roles")
    # Test the is_valid_fqcr method in the AnsibleCollectionRef class

# Generated at 2022-06-25 12:55:46.635724
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder._filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()



# Generated at 2022-06-25 12:55:49.255952
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('demo.mock', 'mock_module', 'a', 'module').__repr__() == "AnsibleCollectionRef(collection='demo.mock', subdirs='mock_module', resource='a')"


# Generated at 2022-06-25 12:55:59.500815
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # Unit test for the constructor of class AnsibleCollectionRef
    # Valid collection-name and reference-type
    collection_name = 'namespace.collectionname'
    collection_ref = AnsibleCollectionRef(collection_name, 'subdir1.subdir2', 'resource', 'ref_type')
    assert isinstance(collection_ref, AnsibleCollectionRef)

    # Invalid collection-name
    collection_name = 'namespace.collectionname.'
    try:
        collection_ref = AnsibleCollectionRef(collection_name, 'subdir1.subdir2', 'resource', 'ref_type')
        assert False
    except ValueError:
        assert True

    # Invalid subdirs

# Generated at 2022-06-25 12:56:08.875838
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ansible_collection_ref = AnsibleCollectionRef.try_parse_fqcr('community.aws.ec2', 'module')
    if ansible_collection_ref is None :
        raise ValueError('ansible_collection_ref is None')
    if ansible_collection_ref.collection != 'community.aws':
        raise ValueError('Incorrect ansible_collection_ref.collection')
    if ansible_collection_ref.resource != 'ec2':
        raise ValueError('Incorrect ansible_collection_ref.resource')
    if ansible_collection_ref.ref_type != 'module':
        raise ValueError('Incorrect ansible_collection_ref.ref_type')

# Generated at 2022-06-25 12:56:19.857815
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    fqcr = "jdoe.nginx.nginx"
    ref_type = "module"
    ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert ref.collection == "jdoe.nginx"

    fqcr = "jdoe.nginx"
    ref_type = "module"
    with pytest.raises(ValueError):
        ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)

    fqcr = "jdoe.nginx.nginx"
    ref_type = "module"
    with pytest.raises(ValueError):
        ref = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)


# Generated at 2022-06-25 12:56:24.385576
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref_0 = AnsibleCollectionRef(collection_name='namespace.collectionname',
                                                    subdirs=None,
                                                    resource='mymodule',
                                                    ref_type='module')
    ansible_collection_ref_1 = AnsibleCollectionRef(collection_name='namespace.collectionname',
                                                    subdirs='subdir1.subdir2',
                                                    resource='mymodule',
                                                    ref_type='module')



# Generated at 2022-06-25 12:56:31.325808
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # the point of this test case is to verify the default behavior of the get_code method when the subpackage_search_paths attribute is undefined (ie, the module is a pure synthetic one)
    mydir = os.path.dirname(os.path.abspath(__file__))
    new_obj = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.acme.test_ns_pkg")
    new_obj._subpackage_search_paths = []
    new_obj.get_code(fullname="ansible_collections.acme.test_ns_pkg")
    # assert that the computed value of the attribute _compiled_code is correct
    assert new_obj._compiled_code is not None


# Generated at 2022-06-25 12:57:09.490942
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # Try parsing a valid fqcr for a role
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.rolename', 'role')

    # Try parsing a valid fqcr for a module
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.modulename', 'module')

    # Try parsing a valid fqcr with a subdir for a module
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir.modulename', 'module')

    # Try parsing a valid fqcr with a subdir for a module
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir.subdir.modulename', 'module')

    # Try parsing a valid fqcr for a role with a hyphen

# Generated at 2022-06-25 12:57:11.901186
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    assert ansible_collection_finder_1._AnsibleCollectionFinder_find_module()


# Generated at 2022-06-25 12:57:20.012615
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    ansible_collection_finder_test = _AnsibleCollectionFinder()
    ansible_collection_finder_test.set_playbook_paths(['test_fixtures/base_dir'])
    assert ansible_collection_finder_test._ansible_pkg_path is not None
    assert ansible_collection_finder_test._n_configured_paths is not None
    assert ansible_collection_finder_test._n_cached_collection_paths is None
    assert ansible_collection_finder_test._n_cached_collection_qualified_paths is None
    assert ansible_collection_finder_test._n_playbook_paths is not None
    assert ansible_collection_finder_test._ansible_collection_path_hook is not None
    assert ansible_collection_finder_test.find_module

# Generated at 2022-06-25 12:57:27.471046
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    loader = ansible_collection_finder_0._loaders['ansible.misc.collection_loader.collection_finder_mock_1']
    #loader.get_data("/home/wchen/ansible/test/unit/lib/ansible/modules/network/fortios/ps/test/__init__.py.data")
    loader.get_data("/home/wchen/ansible/test/unit/lib/ansible/modules/network/fortios/ps/test/__init__.py")


# Generated at 2022-06-25 12:57:36.423417
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test case 0
    # Test get_code() for an importable path
    fake_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    fake_pkg_name = os.path.basename(fake_path)
    fake_full_pkg_name = "ansible.{0}".format(fake_pkg_name)
    fake_loader = _AnsibleCollectionPkgLoaderBase(fake_full_pkg_name, [fake_path])
    fake_loader.get_code(fake_full_pkg_name)

    # Test case 1
    # Test get_code() for an importable file
    fake_file_name = os.path.join(fake_path, '__init__.py')
    fake_loader = _AnsibleCollectionPkgLoader

# Generated at 2022-06-25 12:57:38.194453
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    pathctx_0 = os.path.join('ansible', 'collections')
    collection_finder_0 = None
    test__AnsiblePathHookFinder_0 = _AnsiblePathHookFinder(collection_finder_0, pathctx_0)



# Generated at 2022-06-25 12:57:44.759463
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    # Create instance of class under test
    # class _AnsibleCollectionPkgLoader(object, _AnsibleCollectionPkgLoaderBase)
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader('some_package_to_load', 'some_parent_package_name', 'some_path_item', 'some_source_code_path')

    # Call method under test
    ansible_collection_pkg_loader_0.load_module("default")

    # Check that the correct instance of _AnsibleCollectionMetaData has been created
    assert(ansible_collection_pkg_loader_0._collection_meta.__class__.__name__ == "_AnsibleCollectionMetaData")


# Generated at 2022-06-25 12:57:56.817881
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # Passing of different values for ref_type as 'action', 'become', 'cache', 'callback', 'cliconf', 'connection',
    #  'doc_fragments', 'filter', 'httpapi', 'inventory', 'lookup', 'module_utils', 'modules', 'netconf', 'role',
    # 'shell', 'strategy', 'terminal', 'test', 'vars'
    ref_types = ['action', 'become', 'cache', 'callback', 'cliconf', 'connection', 'doc_fragments', 'filter',
                 'httpapi', 'inventory', 'lookup', 'module_utils', 'modules', 'netconf', 'role', 'shell',
                 'strategy', 'terminal', 'test', 'vars']


# Generated at 2022-06-25 12:58:04.407421
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    fqcr = 'ns.coll.res'
    ref_type = 'module'

    # Create a try_parse_fqcr object
    try_parse_fqcr_obj = AnsibleCollectionRef.try_parse_fqcr(fqcr, ref_type)
    # print (try_parse_fqcr_obj)
    #assert try_parse_fqcr_obj.collection == "ns.coll"
    #assert try_parse_fqcr_obj.subdirs == ""
    #assert try_parse_fqcr_obj.resource == "res"
    #assert try_parse_fqcr_obj.ref_type == "module"

    fqcr = 'ns.coll.res.ext'
    ref_type = 'playbook'
    # Create a try_parse_fqcr

# Generated at 2022-06-25 12:58:10.282403
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr('ansible.builtin.json_query', 'lookup')
    assert ref.collection == 'ansible.builtin'
    assert ref.ref_type == 'lookup'
    assert ref.resource == 'json_query'

    ref = AnsibleCollectionRef.from_fqcr('ansible.builtin.template', 'lookup')
    assert ref.collection == 'ansible.builtin'
    assert ref.ref_type == 'lookup'
    assert ref.resource == 'template'

    ref = AnsibleCollectionRef.from_fqcr('ansible.builtin.foo.bar', 'python')
    assert ref.collection == 'ansible.builtin'
    assert ref.ref_type == 'python'
    assert ref.resource == 'bar'
    assert ref

# Generated at 2022-06-25 12:59:13.595802
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():

    ansible_collection_finder_0 = _AnsibleCollectionFinder()

    _ansible_internal_redirect_loader_0 = None
    _ansible_collection_root_pkg_loader_0 = None
    _ansible_collection_ns_pkg_loader_0 = None
    _ansible_collection_pkg_loader_0 = None
    _ansible_collection_loader_0 = None

    ansible_collection_finder_0.set_playbook_paths([])
    ansible_collection_finder_0._install()

    toplevel_pkg = 'ansible'
    module_to_find = ''
    part_count = 1


# Generated at 2022-06-25 12:59:19.100954
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Test for Ansible collection package
    # Ansible collection package does not contain meta/runtime.yml
    with patch('os.path.isdir') as isdir_mock:
        with patch('ansible.utils.collection_loader.os.path.isfile') as isfile_mock:
            with patch('ansible.utils.collection_loader._meta_yml_to_dict', new=None):
                # Test with Ansible collection package
                isdir_mock.return_value = True
                isfile_mock.return_value = False
                pth = os.sep + 'foo'
                loader = _AnsibleCollectionPkgLoader(pth, 'package')
                module = loader.load_module('ansible.collection.package')
                assert module._collection_meta == {}

    # Test for Ansible

# Generated at 2022-06-25 12:59:21.757722
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_case_name = "test_case_0"
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # meta_yml_to_dict is not set

# Generated at 2022-06-25 12:59:24.229981
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_collection_loader_0 = _AnsibleInternalRedirectLoader( "ansible.module_utils.basic", "./ansible/module_utils/basic.py")


# Generated at 2022-06-25 12:59:34.363200
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    dir = os.path.dirname(os.path.realpath(__file__))
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(fullname="ansible_collections.my_collection.my_ns.my_plugin", path_list=[dir,"modules"])
    assert ansible_collection_pkg_loader_base.get_data(path="/dev/null") == None
    assert ansible_collection_pkg_loader_base.get_data(path="__init__.py") == ""
    assert ansible_collection_pkg_loader_base.get_data(path="__init__.py") == ""
    assert ansible_collection_pkg_loader_base.get_data(path="__init__.py") == ""
    assert ansible_collection_pkg_loader_base.get

# Generated at 2022-06-25 12:59:44.469783
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:59:53.125424
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder(paths=[os.path.join(os.path.dirname(__file__), 'conftest/data/collections')])
    assert ansible_collection_finder_1.find_module(fullname='ansible_collections.community.other')
    assert ansible_collection_finder_1.find_module(fullname='ansible_collections.community.other.plugins.module_utils.foo')
    assert ansible_collection_finder_1.find_module(fullname='ansible_collections.community.other.plugins.filter.foo')
    assert ansible_collection_finder_1.find_module(fullname='ansible_collections.community.other.plugins.cliconf.foo')

# Generated at 2022-06-25 13:00:03.143091
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2')
    assert not AnsibleCollectionRef.is_valid_fqcr('subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.ext')

    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', ref_type='module')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2', ref_type='module')

    assert AnsibleCollectionRef.is_

# Generated at 2022-06-25 13:00:03.926266
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    pass


# Generated at 2022-06-25 13:00:08.504973
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type