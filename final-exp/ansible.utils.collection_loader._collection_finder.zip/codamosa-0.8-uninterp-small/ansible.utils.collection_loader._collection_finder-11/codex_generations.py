

# Generated at 2022-06-25 12:51:32.410281
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = 'test.test.test'
    ref_type = 'role'
    obj = AnsibleCollectionRef.from_fqcr(ref, ref_type)

    assert obj.collection == 'test.test'
    assert obj.ref_type == 'role'
    assert obj.resource == 'test'
    assert obj.subdirs == ''
    assert obj._fqcr == 'test.test.test'
    assert obj.n_python_collection_package_name == 'ansible_collections.test.test'
    assert obj.n_python_package_name == 'ansible_collections.test.test.roles.test'

    ref = 'test.test.test.test'
    ref_type = 'role'
    obj = AnsibleCollectionRef.from_fqcr(ref, ref_type)



# Generated at 2022-06-25 12:51:37.099527
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref_0 = AnsibleCollectionRef('namespace.collection', subdirs, 'resource', 'ref_type')
    try:
        pass
    except ValueError as e:
        pass
    except BaseException as e:
        pass
    ansible_collection_ref_1 = AnsibleCollectionRef('ansible_collections.namespace.collection', subdirs, 'resource', 'ref_type')
    try:
        pass
    except ValueError as e:
        pass
    except BaseException as e:
        pass
    ansible_collection_ref_2 = AnsibleCollectionRef('ns.coll.resource.ref_type', subdirs, 'resource', 'ref_type')
    try:
        pass
    except ValueError as e:
        pass
    except BaseException as e:
        pass

    #

# Generated at 2022-06-25 12:51:42.143278
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    pkg_name = _AnsibleCollectionLoader._validate_args()
    subpackage_search_paths = _AnsibleCollectionLoader._validate_final()


# Generated at 2022-06-25 12:51:44.150689
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # self, fullname, path_list
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader(None, None)

if __name__ == '__main__':
    test_case_0()
    test__AnsibleInternalRedirectLoader()

# Generated at 2022-06-25 12:51:48.009594
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    collection_ref = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    collection_ref = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')



# Generated at 2022-06-25 12:51:53.683771
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase()

    str_0 = ansible_collection_pkg_loader_base_0.get_source(str_0 = 'test_get_source__AnsibleCollectionPkgLoaderBase_0')
    print('[Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase]')
    print('[Result] str_0 = ' + str_0)
    return


# Generated at 2022-06-25 12:52:02.453517
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    path_0 = None
    map_0 = {}
    str_0 = 'an empty collection'
    str_1 = 'ansible_collections'
    str_2 = 'ns'
    str_3 = 'an empty collection, a collection with modules, and a collection with modules and subpackages'

    cls_0 = _AnsibleCollectionPkgLoaderBase
    cls_0.__name__ = str_1
    cls_0.__doc__ = str_3
    ret_0 = cls_0('ansible_collections.ns', None)
    ret_1 = repr(ret_0)
    assert ret_1 == 'ansible_collections(path=None)'

    cls_0 = _AnsibleCollectionPkgLoaderBase
    cls_0.__name__ = str_1
    cl

# Generated at 2022-06-25 12:52:03.914926
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref_0 = AnsibleCollectionRef('collection', 'subdirs', 'resource', 'ref_type')


# Generated at 2022-06-25 12:52:13.478304
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    if not _meta_yml_to_dict:
        raise ValueError('ansible.utils.collection_loader._meta_yml_to_dict is not set')
    str_0 = 'Ignoring "%s" as it is not used in "%s"'
    str_1 = 'plugin_routing'
    str_2 = 'ansible.builtin.plugins.action.debug'
    str_3 = 'ansible.builtin.plugins.module_utils.basic'
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.find_module('module_utils')
    ansible_collection_finder_0.find_module('module_utils')
    ansible_collection_finder_0.find_module('module_utils')
    ansible_collection_finder_0

# Generated at 2022-06-25 12:52:16.132588
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('loader.py')
    ansible_collection_pkg_loader_base_0.get_data('abs_path')


# Generated at 2022-06-25 12:52:39.798264
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr("namespace.collection.path.to.a.resource", "module")
    # validation of the returned object
    assert ansible_collection_ref.collection == u'namespace.collection'
    assert ansible_collection_ref.subdirs == 'path.to.a'
    assert ansible_collection_ref.resource == 'resource'
    assert ansible_collection_ref.ref_type == 'module'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.namespace.collection'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.namespace.collection.plugins.path.to.a.module'
    assert ansible_collection_ref.fq

# Generated at 2022-06-25 12:52:41.854046
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    # Test case for non-existing path
    ansible_collection_loader_1 = _AnsibleCollectionPkgLoader('ansible_collections.test.test_module', 'fake_path')
    ansible_collection_loader_1.load_module('ansible_collections.test.test_module')


# Generated at 2022-06-25 12:52:47.392726
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    mock_fullname = "ansible_collections.mycollection.myns"
    mock_path = "/usr/share/ansible/collections/ansible_collections/mycollection/myns/__init__.py"
    mock_loader = _AnsibleCollectionPkgLoaderBase(mock_fullname)
    mock_loader.get_data(mock_path)


# Generated at 2022-06-25 12:52:49.287257
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase()


# Generated at 2022-06-25 12:52:58.051266
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test that an invalid key raises an error
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr(to_text("foo.bar.baz.bat"), to_text("action"))

    # Test that a valid AnsibleCollectionRef object is returned
    test_AnsibleCollectionRef = AnsibleCollectionRef.from_fqcr(to_text("ansible.base.someaction"), to_text("action"))
    assert test_AnsibleCollectionRef.ref_type == "action"
    assert test_AnsibleCollectionRef.subdirs == ""
    assert test_AnsibleCollectionRef.resource == "someaction"
    assert test_AnsibleCollectionRef.collection == "ansible.base"


# Generated at 2022-06-25 12:52:59.259447
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.foo')
    assert loader._package_to_load == 'foo'


# Generated at 2022-06-25 12:53:01.815978
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    ansible_collection_ref_0 = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert ansible_collection_ref_0 == 'action'


# Generated at 2022-06-25 12:53:08.779479
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    pm = None
    AnsibleCollectionPkgLoaderBase = _AnsibleCollectionPkgLoaderBase("ansible_collections.host.name")
    try:
        pm = AnsibleCollectionPkgLoaderBase.load_module("ansible_collections.host.name")
    except:
        # No handler for exception ImportError('this loader cannot load source for ansible_collections.host.name, only ansible_collections.host.name')
#        assert False
        pass
    assert pm == None
    return



# Generated at 2022-06-25 12:53:13.181517
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
   # 1. Create an instance of _AnsibleCollectionPkgLoaderBase
   test_obj = _AnsibleCollectionPkgLoaderBase("ansible_collections.other")
   # 2. Test get_filename
   test_obj.get_filename("ansible_collections.other")

# Method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-25 12:53:16.315969
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections')
    assert ansible_collection_pkg_loader_base_0.is_package('ansible_collections') == False


# Generated at 2022-06-25 12:53:43.746510
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cache_plugins') == u'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'callback_plugins') == u'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cliconf_plugins') == u'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'connection_plugins') == u'connection'

# Generated at 2022-06-25 12:53:48.286158
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase('ansible.test')
    assert ansible_collection_pkg_loader_base.is_package('ansible.test') == False
    assert ansible_collection_pkg_loader_base.is_package('ansible.test2') == False


# Generated at 2022-06-25 12:53:59.114516
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import os
    import tempfile
    import shutil
    import ansible.utils.collection_loader
    import ansible.utils.collection_list

    # Set up to test error handling
    class _helper():
        def __init__(self, error_to_raise, return_value=''):
            self.error_to_raise = error_to_raise
            self.return_value = return_value

        def __call__(self, raw_data):
            if self.error_to_raise:
                raise ImportError('error from _meta_yml_to_dict')
            return self.return_value

        def __str__(self):
            return str(self.error_to_raise)


    # Make a temp dir to be used by the _AnsibleCollectionFinder

    # First make a collection_finder

# Generated at 2022-06-25 12:54:04.977425
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible_mitogen.plugins.module_utils.mitogen.connection', ['/usr/local/lib/python3.6/site-packages/ansible_mitogen-0.2.9-py3.6.egg/ansible_mitogen/plugins/module_utils/mitogen/connection'])
    ansible_collection_pkg_loader_base_0.get_code('ansible_collections.ansible_mitogen.plugins.module_utils.mitogen.connection')



# Generated at 2022-06-25 12:54:06.852553
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.repr_string','/some/path')
    fullname = loader.load_module('ansible.builtin.repr_string')
    print(fullname)



# Generated at 2022-06-25 12:54:09.278797
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    if not PY2:
        raise unittest.SkipTest('Skipping for now')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.testns')
    loader._source_code_path = 'test_path'
    assert loader.get_filename('ansible_collections.testns') == "test_path"



# Generated at 2022-06-25 12:54:12.390861
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder = _AnsibleCollectionFinder()
    try:
        ansible_collection_finder.find_module('ansible')
    except ImportError:
        pass


# Generated at 2022-06-25 12:54:16.384380
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    """unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
    """
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.my.ns')
    assert loader.get_source() == None


# Generated at 2022-06-25 12:54:26.691542
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # mock up an AnsibleCollectionPkgLoaderBase
    from ansible.module_utils._text import to_bytes
    loader_metadata = dict(
        _fullname='ansible_collections.ns.module',
        _is_redirect_package=False,
        _split_name=['ansible_collections', 'ns', 'module'],
        _rpart_name=('ansible_collections.ns', '.', 'module'),
        _package_to_load='module',
        _candidate_paths=[],
        _subpackage_search_paths=None,
        _source_code_path=None,
        _decoded_source=None,
        _compiled_code=None,
    )

# Generated at 2022-06-25 12:54:31.254378
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    os.chdir("/Users/aoneill/Development/ansible_collections/ansible_collections/homeassistant")
    from ansible_collections.community.homeassistant.plugins.module_utils import ha

    print("get_code(ha) = " + ha.__loader__.get_code(__name__))


# Generated at 2022-06-25 12:55:46.804811
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    _AnsibleInternalRedirectLoader('ansible.module_utils.foo_utils', ['ansible_collections.namespace.collection.foo_utils'])
    

# Generated at 2022-06-25 12:55:56.698204
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    # Note that we have to execute the test case setup code manually
    ansible_collection_finder_0._install()
    ansible_collection_finder_0.set_playbook_paths(['/home/matt/ansibule/chapters/chapter03', '/home/matt/ansibule/collection_tests/collections/', '/home/matt/ansibule/collection_tests/collections/coll_bar'])
    # Test case setup code ends here

    # Test case execution code follows
    ansible_collection_finder_0.find_module('ansible_collections.coll_foo.plugins.module_utils.foo')
    # Test case execution code ends here

    # Test case cleanup code follows
    # Test case cleanup code ends here


# Generated at 2022-06-25 12:56:06.248386
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-25 12:56:15.359226
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_pkg_loader_base_0 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.acme.plugins.module_utils.example', path_list=['ansible_collections/acme/plugins/module_utils/example', 'ansible_collections/acme/plugins/module_utils', 'ansible_collections/acme/plugins', 'ansible_collections/acme', 'ansible_collections'])
    with patch('sys.modules', new={}):
        with pytest.raises(Exception):
            ansible_collection_pkg_loader_base_0.load_module(fullname='ansible_collections.acme.plugins.module_utils.example')

# Generated at 2022-06-25 12:56:21.319182
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_internal_redirect_loader_0 = _AnsibleInternalRedirectLoader('ansible.module_utils.facts.system.linux.file', ['/var/opt/ansible/ansible_facts/ansible/module_utils/facts/system/linux/file'])
    ansible_internal_redirect_loader_0.load_module('ansible.module_utils.facts.system.linux.file')


# Generated at 2022-06-25 12:56:27.549194
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Loader should redirect to 'ansible.collection.collection1.plugins.module_utils.basic'
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.plugins.module_utils.basic', [])
    # Call load_module() of redirect_loader to get the redirected module
    module = redirect_loader.load_module('ansible.plugins.module_utils.basic')
    # Assert that the module is loaded from expected path
    assert module.__file__.endswith('/ansible_collections/ansible/collection1/plugins/module_utils/basic.py')


# Generated at 2022-06-25 12:56:36.270862
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.res', 'module').resource == 'res'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.res', 'module').collection == 'ns.coll'
    assert AnsibleCollectionRef.from_fqcr('ns.coll.res', 'module').ref_type == 'module'

    # Bad values will throw
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('ns.coll.res', 'badtype')

    assert AnsibleCollectionRef.from_fqcr('ns.coll.res', 'module').subdirs == ''

    assert AnsibleCollectionRef.from_fqcr('ns.coll.subdir.res', 'module').subdirs == 'subdir'


# Generated at 2022-06-25 12:56:47.850713
# Unit test for method load_module of class _AnsibleInternalRedirectLoader

# Generated at 2022-06-25 12:56:58.998334
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_case_1 = AnsibleCollectionRef('namespace.coll', 'subdirs_1', 'resource_1', 'action')
    test_case_2 = AnsibleCollectionRef('namespace.coll', 'subdirs_2', 'resource_2', 'action')
    test_case_3 = AnsibleCollectionRef('namespace.coll', 'subdirs_3', 'resource_3', 'action')
    test_case_4 = AnsibleCollectionRef('namespace.coll', 'subdirs_4', 'resource_4', 'action')
    test_case_5 = AnsibleCollectionRef('namespace.coll', 'subdirs_5', 'resource_5', 'action')

# Generated at 2022-06-25 12:57:06.941279
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.some_namespace')
    loader._subpackage_search_paths = ['/dir1']
    assert loader.get_data('/file1') is None
    assert loader.get_data('file1') is None
    assert loader.get_data('/dir1/file1') is None
    assert loader.get_data('__init__.py') is None
    assert loader.get_data('/dir1/__init__.py') is None


# Generated at 2022-06-25 12:57:35.777267
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    error_list = []

    # Construct args
    path = '/foo'

    # Construct class object
    acpl = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.foo', ['/foo'])

    # Return value tests
    method_return_value = acpl.get_data(path)
    if(method_return_value is not None):
        error_list.append("Method get_data did not return None")

    assert(len(error_list) == 0), error_list


# Generated at 2022-06-25 12:57:37.468201
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_case_0()



# Generated at 2022-06-25 12:57:45.106556
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.set_playbook_paths(['/path/to/playbook'])
    find_module_result = ansible_collection_finder_0.find_module(
        'ansible_collections.collection1.playbook')
    # AnsibleCollectionPkgLoader
    assert type(find_module_result).__name__ == '_AnsibleCollectionPkgLoader'
    find_module_result = ansible_collection_finder_0.find_module(
        'ansible_collections.not_exists.playbook')
    # None
    assert find_module_result is None
    find_module_result = ansible_collection_finder_0.find_module(
        'ansible_collections')

# Generated at 2022-06-25 12:57:48.953792
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0.load_module('ansible.builtin.module_utils.module_common')


# Generated at 2022-06-25 12:57:59.791513
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collection_loader_0 = _AnsibleCollectionPkgLoaderBase('ansible.module_utils.basic')
    ansible_collection_loader_1 = _AnsibleCollectionPkgLoaderBase('ansible.collections.foo.bar')
    ansible_collection_loader_2 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar')
    ansible_collection_loader_3 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar.baz')
    ansible_collection_loader_4 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar.baz.thing')
    ansible_collection_loader_5 = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar.baz.thing.morning')

# Generated at 2022-06-25 12:58:06.253735
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'test')
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'test').__dict__.get('subdirs')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.resource', 'test').__dict__.get('subdirs') == 'subdir1.subdir2'
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'test').__dict__.get('subdirs') == 'subdir1'
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'test').__dict__.get('ext')
    assert AnsibleCollectionRef

# Generated at 2022-06-25 12:58:08.268460
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_collection_finder_0._install()

    ansible_path_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, 'foo')



# Generated at 2022-06-25 12:58:14.233233
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder = _AnsibleCollectionFinder()

    module_to_find = 'ansible.module_utils.facts'
    fullname = 'ansible.module_utils.facts'

    # set path to None, this is to test the case when path is None
    path = None
    expected_value = _AnsibleInternalRedirectLoader(fullname, path)

    # Call _AnsibleCollectionFinder.find_module(fullname, path)
    value = ansible_collection_finder.find_module(fullname, path)

    assert expected_value == value


# Generated at 2022-06-25 12:58:18.887876
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader_0 = _AnsibleCollectionPkgLoader(None, 'ansible.builtin', ['ansible.builtin', 'ansible.builtin.plugins'])
# TODO: at least do the other test (with ansible.runtime.yml and meta_yml_to_dict)


# Generated at 2022-06-25 12:58:26.182841
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Test when file '__init__.py' exists
    foo_mock_path_b = to_bytes('/tmp/foo')
    foo_mock_path = to_native(foo_mock_path_b)
    os.makedirs(foo_mock_path_b)
    open(foo_mock_path_b + b'/__init__.py', 'a').close()
    class _AnsibleCollectionPkgLoaderBase_foo(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return [foo_mock_path_b]
    _AnsibleCollectionPkgLoaderBase_foo_loader = _AnsibleCollectionPkgLoaderBase_foo('ansible_collections.foo')
    assert _AnsibleCollectionPkg

# Generated at 2022-06-25 12:59:00.032513
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class _AnsibleCollectionPkgLoader_test_load_module(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(_AnsibleCollectionPkgLoader_test_load_module, self).__init__(*args, **kwargs)
            __package__ = 'ansible.utils.collection_loader'
            ansible_pkg_path = os.path.dirname(import_module('ansible').__file__)
            self.loader = _AnsibleCollectionPkgLoader('ansible.collections.test_ns.test_collection',
                                                      [os.path.join(ansible_pkg_path, 'data/ansible_collections/ansible/test_ns/test_collection')])

        def test_load_module(self):
            self.loader.load

# Generated at 2022-06-25 12:59:02.991923
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    obj = _AnsibleInternalRedirectLoader('ansible.foo.bar', ['/does/not/matter'])
    obj.load_module('ansible')



# Generated at 2022-06-25 12:59:11.558379
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    
    # test for attribute `_meta_yml_to_dict` of class `_AnsibleCollectionFinder`
    assert callable(ansible_collection_finder_0._meta_yml_to_dict), 'attribute `_meta_yml_to_dict` of `_AnsibleCollectionFinder` should be callable!'
    assert ansible_collection_finder_0._meta_yml_to_dict.__class__.__name__ == '_LicensedFunction', 'attribute `_meta_yml_to_dict` of `_AnsibleCollectionFinder` should an instance of `_LicensedFunction`!'
    # test for attribute `_meta_yml_to_dict` of class `_AnsibleCollectionFinder`
   

# Generated at 2022-06-25 12:59:12.869162
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Test 1
    test_case_0()



# Generated at 2022-06-25 12:59:18.185723
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()
    fullname = 'ansible'
    path = None

    res0 = ansible_collection_finder_1._AnsibleCollectionFinder__find_module(fullname, path)
    assert type(res0) == _AnsibleInternalRedirectLoader


# Generated at 2022-06-25 12:59:22.073508
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    ansible_collection_finder_0 = _AnsibleCollectionFinder()
    ansible_pah_hook_finder_0 = _AnsiblePathHookFinder(ansible_collection_finder_0, '/root/collections')
    assert ansible_pah_hook_finder_0.find_module('ansible.collections')

    # Unit test for method iter_modules of class _AnsiblePathHookFinder

# Generated at 2022-06-25 12:59:30.417351
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_input_dir_names = [
        'action_plugins',
        'become_plugins',
        'cache_plugins',
        'callback_plugins',
        'cliconf_plugins',
        'connection_plugins',
        'doc_fragments',
        'filter_plugins',
        'httpapi_plugins',
        'inventory_plugins',
        'library',
        'lookup_plugins',
        'module_utils',
        'modules',
        'netconf_plugins',
        'shell_plugins',
        'strategy_plugins',
        'terminal_plugins',
        'tersible_plugins',
        'test_plugins',
        'vars_plugins'
    ]


# Generated at 2022-06-25 12:59:40.807901
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    print("starting test_AnsibleInternalRedirectLoader")
    print("_AnsibleInternalRedirectLoader(ansible.builtin.foo)")
    loader = _AnsibleInternalRedirectLoader("ansible.builtin.foo", None)
    print("_AnsibleInternalRedirectLoader(ansible.builtin.bar)")
    loader = _AnsibleInternalRedirectLoader("ansible.builtin.bar", None)
    print("_AnsibleInternalRedirectLoader(ansible.builtin)")
    loader = _AnsibleInternalRedirectLoader("ansible.builtin", None)
    print("_AnsibleInternalRedirectLoader(ansible.builtin.foo)")
    loader = _AnsibleInternalRedirectLoader("ansible.builtin.foo", None)

# Generated at 2022-06-25 12:59:50.589487
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # given
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname = "ansible_collections.some.ns",
        path_list = [
            "/tmp/some.ns/some/ns.py",
            "/tmp/some.ns/some/ns/__init__.py",
            "/tmp/some.ns/some/ns/sub.py"
        ]
    )

    # when
    actual_module = loader.get_data(path="/tmp/some.ns/some/ns.py")
    actual_package = loader.get_data(path="/tmp/some.ns/some/ns/__init__.py")
    actual_submodule = loader.get_data(path="/tmp/some.ns/some/ns/sub.py")
    actual_not_found = loader.get_data

# Generated at 2022-06-25 12:59:57.719623
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_finder_1 = _AnsibleCollectionFinder()

    # these are the arguments passed to the loader
    loader_args = ['ansible_collections.community.foo', 'my_package', ['/ansible_collections/community/foo']]

    ansible_collection_loader_1 = _AnsibleCollectionPkgLoader(*loader_args)
    ansible_collection_loader_1.load_module('ansible_collections.community.foo')


if __name__ == '__main__':
    print(sys.version)
    test_case_0()
    test__AnsibleCollectionPkgLoader_load_module()

# Generated at 2022-06-25 13:00:14.410601
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoader(paths=CollectionPaths())
    ansible_collection_pkg_loader.load_module(fullname = 'ansible_collections.foo.bar')
    ansible_collection_pkg_loader.load_module(fullname = 'ansible_collections.foo.bar.baz')

