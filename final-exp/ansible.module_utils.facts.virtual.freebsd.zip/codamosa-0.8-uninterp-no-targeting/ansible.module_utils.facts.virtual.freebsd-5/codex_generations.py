

# Generated at 2022-06-20 20:14:14.714534
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual('netbsd')
    assert virtual_facts.virtual_facts['virtualization_type'] == ''
    assert virtual_facts.virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:14:24.895119
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create instance and check that all attributes are initialized to empty
    # values
    freebsd_virtual_facts = FreeBSDVirtual()
    for attr_name in freebsd_virtual_facts.__dict__:
        if attr_name.startswith('_'):
            # Ignore private attributes
            continue
        assert not getattr(freebsd_virtual_facts, attr_name)

    # Run method get_virtual_facts
    freebsd_virtual_facts.get_virtual_facts()

    # Check that all attributes have been correctly initialized
    assert freebsd_virtual_facts.virtualization_type
    assert freebsd_virtual_facts.virtualization_role
    assert freebsd_virtual_facts.virtualization_tech_guest
    assert freebsd_virtual_facts.virtualization_tech_host

# Generated at 2022-06-20 20:14:30.553838
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    # Assert that FreeBSDVirtual is a subclass of Virtual and
    # VirtualSysctlDetectionMixin which are available in
    # ansible.module_utils.facts.virtual.base.py and
    # ansible.module_utils.facts.virtual.sysctl.py respectively
    fb_ancestors = [FreeBSDVirtual, Virtual, VirtualSysctlDetectionMixin]
    for anc in fb_ancestors:
        assert issubclass(FreeBSDVirtual, anc)


# Generated at 2022-06-20 20:14:41.939784
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # We will mock sysctl value, so we not need to run it
    get_sysctl_mock = lambda x: None
    # We will mock virtual_product, so we not need to run it
    get_virtual_product_mock = lambda x: None
    # We will mock virtual_vendor, so we not need to run it
    get_virtual_vendor_mock = lambda x: None

    # We will check result using assert_called* methods, so we not need to run
    # the code in fact
    run_command_method = lambda x: None

    from ansible.module_utils.facts.virtual import freebsd
    freebsd.get_sysctl = get_sysctl_mock
    freebsd.get_virtual_product = get_virtual_product_mock
    freebsd.get_virtual

# Generated at 2022-06-20 20:14:45.518130
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:14:48.061034
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv is not None
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:49.204347
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsdv = FreeBSDVirtual()


# Generated at 2022-06-20 20:14:58.076452
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    # Test FreeBSD virtual machine
    get_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in get_virtual_facts
    assert 'virtualization_role' in get_virtual_facts
    assert 'virtualization_ogle' not in get_virtual_facts
    assert 'virtualization_tech_host' in get_virtual_facts
    assert 'virtualization_tech_guest' in get_virtual_facts

    # Test FreeBSD host machine
    get_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in get_virtual_facts
    assert 'virtualization_role' in get_virtual_facts
    assert 'virtualization_ogle' not in get_virtual_facts

# Generated at 2022-06-20 20:15:09.305995
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''This is a unit test for method get_virtual_facts of class FreeBSDVirtual
    '''

    # Empty return value when there is no virtualization technology detected
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    # Return value when there is a virtualization technology detected
    virtual_facts_with_tech = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    virtual_facts_with_tech['virtualization_tech_guest'].add

# Generated at 2022-06-20 20:15:13.239792
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector.collect()['virtualization_type'] != ''

# Generated at 2022-06-20 20:15:20.669630
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()

    # Check empty values
    assert fb_virtual.data['virtualization_role'] == ''
    assert fb_virtual.data['virtualization_type'] == ''

# Generated at 2022-06-20 20:15:21.277248
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:33.104907
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test define virtualization_type == xen
    facts = FreeBSDVirtual({}, {}, {'kernel': 'FreeBSD'})
    facts._file_exists_cache = {'/dev/xen/xenstore': True}
    facts.sysctl = lambda key: None
    facts.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'

    # Test virtualization_role == guest
    facts = FreeBSDVirtual({}, {}, {'kernel': 'FreeBSD'})
    facts._file_exists_cache = {'/dev/xen/xenstore': True}
    facts.sysctl = lambda key: None
    facts.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'

    # Test define virtualization_type == 'bhyve'
    facts = FreeBSDVirtual

# Generated at 2022-06-20 20:15:38.332539
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:15:49.179207
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    mock_command_outputs = {
        'sysctl kern.vm_guest': 'kern.vm_guest: none',
        'sysctl hw.hv_vendor': 'hw.hv_vendor: None',
        'sysctl security.jail.jailed': 'security.jail.jailed: 0',
        'sysctl machdep.cpu.vendor': 'machdep.cpu.vendor: GenuineIntel',
        'sysctl hw.model': 'hw.model: Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz',
    }

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def _exec_cmd(self, command):
            return mock_command_outputs[command]

    virtual_facts = FreeBSDVirtual().get_virtual_facts()


# Generated at 2022-06-20 20:15:50.677305
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    clct = FreeBSDVirtualCollector()
    assert clct.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:55.404524
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual(None, None, {}).get_virtual_facts()
    assert 'virtualization_tech_host' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts

# Generated at 2022-06-20 20:15:58.479688
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:00.775352
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual_obj = FreeBSDVirtual.get_instance()
    assert isinstance(fbsd_virtual_obj, FreeBSDVirtual)


# Generated at 2022-06-20 20:16:03.291767
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()


# Generated at 2022-06-20 20:16:10.052065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virt = FreeBSDVirtual({})

    for func in (
        fbsd_virt.get_virtual_facts
    ):
        assert not func()

# Generated at 2022-06-20 20:16:11.561920
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:13.635433
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({'module_setup': {'filter': '*'}})
    assert virtual is not None

# Generated at 2022-06-20 20:16:24.977142
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual._get_sysctl = lambda fact: {'sec_jail_jailed': {'virtualization_tech': 'container'},
                                        'kern_vm_guest': {'virtualization_tech': 'xen'},
                                        'hw_hv_vendor': {'virtualization_tech': 'vmware'}}
    virtual._get_product = lambda fact: {'hw.model': {'vendor_product': 'VMware Virtual Platform',
                                                      'vendor_tech': 'vmware',
                                                      'vendor_name': 'VMware, Inc.'}}

# Generated at 2022-06-20 20:16:27.268450
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None, None).collect()
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-20 20:16:35.797722
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Unit test for constructor of class FreeBSDVirtual"""

    cfg = {
        'location': 'facts/fixtures/virtual',
        'paths': [
            'virtual_sysctl',
            'virtual_hw_model',
        ],
        'fact': 'virtual',
        'platform': 'FreeBSD'
    }

    collector = FreeBSDVirtualCollector(cfg=cfg, collection_directory='/')
    virtual_facts = collector.collect()

    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'xen'

    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'guest'

    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:16:41.933033
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({'ansible_facts': {}}, platform='FreeBSD')
    virtual_facts = virtual.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')
    assert(virtual_facts['virtualization_tech_guest'] == set())
    assert(virtual_facts['virtualization_tech_host'] == set())

# Generated at 2022-06-20 20:16:51.562763
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({}, {}, False)
    v._module.fail_json = Mock(side_effect=fail_json)
    v.detect_virt_product = Mock(side_effect=detect_virt_product)
    v.detect_virt_vendor = Mock(side_effect=detect_virt_vendor)
    facts = v.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_tech_host'] == set(['vmware'])
    assert facts['virtualization_tech_guest'] == set(['xen', 'kvm'])

# Generated at 2022-06-20 20:16:53.781785
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert isinstance(virt, FreeBSDVirtual)
    assert isinstance(virt, Virtual)
    assert isinstance(virt, VirtualSysctlDetectionMixin)


# Generated at 2022-06-20 20:17:00.689568
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import MagicMock, patch

    class TestFreeBSDVirtual(unittest.TestCase):
        def setUp(self):
            self.sys_module_mock = MagicMock()
            self.sys_module_mock.platform = "FreeBSD"
            self.sys_module_mock.version = "11.3"

            self.module_mock = MagicMock()
            self.module_mock.run_command = MagicMock(return_value=(0, 'test_return', ''))

# Generated at 2022-06-20 20:17:06.428236
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:17:11.024832
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technologies_guest' in virtual_facts
    assert 'virtualization_technologies_host' in virtual_facts

# Generated at 2022-06-20 20:17:15.905578
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    freebsd_virtual = FreeBSDVirtual({}, None)
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtual_facts == {}


# Generated at 2022-06-20 20:17:19.418418
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbdvc = FreeBSDVirtualCollector()
    assert fbdvc._platform == 'FreeBSD'
    assert fbdvc._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:17:21.697024
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual()
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:25.492852
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtualCollector().collect()
    assert virtual['virtualization_tech_host'] == set(['hw_vendor'])
    assert virtual['virtualization_tech_guest'] == set(['kern_vm_guest', 'hw_vendor', 'security_jail_jailed'])

# Generated at 2022-06-20 20:17:37.902102
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtualization_sysctl_files = {
        'hw.hv_vendor':
            [
                ('hw.hv_vendor', 'OpenBSD')
            ],

        'kern.vm_guest':
            [
                ('kern.vm_guest', 'none')
            ],

        'security.jail.jailed':
            [
                ('security.jail.jailed', 0)
            ]
    }

    virtualization_vendor_files = {
        'hw.model':
            [
                ('hw.model', 'VirtualBox')
            ]
    }

    module_name = 'test_ansible_freebsd_virtual_facts'
    mock_module = type(module_name, (object,), {})

# Generated at 2022-06-20 20:17:43.362568
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''
    assert virtual.data['virtualization_tech_guest'] == set()
    assert virtual.data['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:17:45.040381
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc, FreeBSDVirtualCollector)
    assert vc._platform == 'FreeBSD'


# Generated at 2022-06-20 20:17:48.282480
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v._platform == 'FreeBSD'
    assert v._fact_class.platform == 'FreeBSD'
    assert v.platform == 'FreeBSD'
    assert v.virtual()['virtualization_type'] != ''


# Generated at 2022-06-20 20:18:01.772192
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test all possible cases
    supported_facts = set(('virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host',
                           'virtualization_product_guest', 'virtualization_product_host'))
    unsupported_facts = set(('virtual', 'virtualization_product'))

    # Instantiate the FreeBSDVirtual class
    bsd_virtual = FreeBSDVirtual()

    # Create a backup of supported_facts
    supported_facts_backup = supported_facts.copy()

    # Check that the tested method returns a dict
    assert isinstance(bsd_virtual.get_virtual_facts(), dict)

    # Check that the returned dict contains all expected keys
    assert supported_facts_backup == set(bsd_virtual.get_virtual_facts().keys())

    # Check that unsupported

# Generated at 2022-06-20 20:18:03.787016
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:05.957584
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:18:09.987384
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from facts.collector import FactCollector
    from ansible.utils.display import Display

    display = Display()
    fact_collector = FactCollector(display, [FreeBSDVirtualCollector], None)

    # class FreeBSDVirtual
    result = fact_collector.collect()
    assert result is not None



# Generated at 2022-06-20 20:18:11.907934
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbvc = FreeBSDVirtualCollector(None, None)
    assert fbvc.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:13.219315
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    VF = FreeBSDVirtual('bsd')
    assert VF.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:16.073834
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    # Test that FreeBSDVirtual is a subclass of Virtual
    assert issubclass(FreeBSDVirtual, Virtual)
    # Test that f is an instance of Virtual
    assert isinstance(f, Virtual)

# Generated at 2022-06-20 20:18:20.295158
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''
    assert virtual.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:18:23.238087
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vmfact = FreeBSDVirtual()
    assert vmfact.platform == "FreeBSD"


# Generated at 2022-06-20 20:18:26.153365
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert type(virtual_facts) is dict

# Generated at 2022-06-20 20:18:48.017696
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsdv = FreeBSDVirtual()

    # Test 'virtualization_type' and 'virtualization_role' facts
    # using the hw.model sysctl
    os.environ = {'hw_model': 'VirtualBox', 'hw_model_id': '6'}
    facts = freebsdv.get_virtual_facts()
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'

    # Test 'virtualization_type' and 'virtualization_role' facts
    # using the xendriv kern.vm_guest sysctl
    del facts
    os.environ = {'hw_model': '', 'hw_model_id': '6'}
    os.environ = {'kern_vm_guest': 'bhyve'}

# Generated at 2022-06-20 20:18:52.358915
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:18:55.340061
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:58.081727
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None, None, None).fact_class,
                      FreeBSDVirtual)

# Generated at 2022-06-20 20:19:08.154913
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json
    import os
    import tempfile

    os_release = '''
NAME=FreeBSD
VERSION=11.1-RELEASE
ID=freebsd
ID_LIKE=freebsd
PRETTY_NAME="FreeBSD 11.1-RELEASE"
VERSION_ID="11.1-RELEASE"
'''

    with tempfile.NamedTemporaryFile('w', dir=os.path.dirname(os.path.abspath(__file__))) as os_release_file:
        os_release_file.write(os_release)
        os_release_file.flush()
        virtual_facts = FreeBSDVirtual(module_utils_facts={}).get_virtual_facts()


# Generated at 2022-06-20 20:19:11.464027
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector._platform == 'FreeBSD'
    assert facts_collector._fact_class == FreeBSDVirtual

# end of class FreeBSDVirtualCollector

# Generated at 2022-06-20 20:19:12.697607
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({},{},{})
    assert virtual is not None

# Generated at 2022-06-20 20:19:14.157003
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:17.332559
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:19:21.612029
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    This is a unit test for the FreeBSDVirtual class, using the constructor
    """

    obj = FreeBSDVirtual()
    assert obj.platform == 'FreeBSD'
    assert obj.virtualization_type == ''
    assert obj.virtualization_role == ''

# Generated at 2022-06-20 20:19:58.038286
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class is FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:59.177126
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(None)
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:00.242837
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:04.166947
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:20:14.794403
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # check if FreeBSDVirtual is subclass of Virtual
    assert issubclass(FreeBSDVirtual, Virtual)
    # check if FreeBSDVirtual is subclass of VirtualSysctlDetectionMixin
    assert issubclass(FreeBSDVirtual, VirtualSysctlDetectionMixin)

    # check the attribute platform of class FreeBSDVirtual is 'FreeBSD'
    assert FreeBSDVirtual.platform == 'FreeBSD'

    # check if FreeBSDVirtual is instance of VirtualSysctlDetectionMixin
    assert isinstance(FreeBSDVirtual(), VirtualSysctlDetectionMixin)

    # check if FreeBSDVirtual is instance of Virtual
    assert isinstance(FreeBSDVirtual(), Virtual)

    # check for freebsd instance
    freebsd_fact = FreeBSDVirtual()

    # check for platform attribute
    assert freebsd_fact.platform == 'FreeBSD'


# Generated at 2022-06-20 20:20:23.027761
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsdv = FreeBSDVirtual({})

    # Test detection of FreeBSD jails
    bsdv.gather_sysctl_facts('security.jail.jailed', '0', 'str')
    bsdv.gather_sysctl_facts('kern.vm_guest', 'other', 'str')
    bsdv.gather_sysctl_facts('hw.hv_vendor', '', 'str')
    bsdv.gather_sysctl_facts('hw.model', '', 'str')
    bsdv.gather_file_facts('/dev/xen/xenstore', False)

    facts = bsdv.get_virtual_facts()
    assert facts['virtualization_type'] == 'jail'
    assert facts['virtualization_role'] == 'guest'

    # Test detection of X

# Generated at 2022-06-20 20:20:24.861424
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    t = FreeBSDVirtualCollector()
    assert t._fact_class == FreeBSDVirtual
    assert t._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:25.738619
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual

# Generated at 2022-06-20 20:20:26.284427
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:20:29.883463
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Initialize FreeBSDVirtual class
    freebsd_virtual = FreeBSDVirtual({})
    # Assert that the class name is FreeBSDVirtual
    assert freebsd_virtual.__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-20 20:21:41.621446
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    code to test class FreeBSDVirtualCollector
    '''
    # Instantiate object of class FreeBSDVirtualCollector
    h=FreeBSDVirtualCollector()
    # Test if the object is an instance of class FreeBSDVirtualCollector
    assert isinstance(h,FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:21:44.204604
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:21:46.162647
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.get_virtual_facts() is not None

# Generated at 2022-06-20 20:21:48.893691
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:57.704628
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    suggested_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'systemd': None,
    }
    virtual = FreeBSDVirtual(suggested_facts, None)
    assert isinstance(virtual, Virtual)
    assert isinstance(virtual, FreeBSDVirtual)
    # Assert that parameters are correctly set
    attrs = [
        'platform',
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ]
    for attr in attrs:
        assert hasattr(virtual, attr)
        assert getattr(virtual, attr) == suggested_facts[attr]



# Generated at 2022-06-20 20:22:01.926280
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual({}, {})
    assert fb_virtual.platform == 'FreeBSD'
    assert fb_virtual.facter_path == '/usr/local/bin/facter'
    assert fb_virtual.dmidecode_path == '/usr/local/sbin/dmidecode'
    assert fb_virtual.sysctl_path == '/sbin/sysctl'
    assert fb_virtual.platform_virtual_facts == {}
    assert fb_virtual.virtual_facts == {}


# Generated at 2022-06-20 20:22:02.870328
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-20 20:22:06.952201
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kv = FreeBSDVirtual()
    facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
    }
    assert facts == kv.get_virtual_facts()

# Generated at 2022-06-20 20:22:09.609495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:22:15.181295
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['xen', 'jail', 'zone', '', 'vmware', 'parallels', 'virtualbox', 'hyperv', 'vserver', 'kvm']
    assert virtual_facts['virtualization_role'] in ['guest', 'host', '']