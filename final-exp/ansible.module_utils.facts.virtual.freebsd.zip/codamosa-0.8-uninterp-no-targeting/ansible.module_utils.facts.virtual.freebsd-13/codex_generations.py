

# Generated at 2022-06-20 20:14:16.273766
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert "virtualization_type" in virtual_facts
    assert "virtualization_role" in virtual_facts
    assert "virtualization_technologies_guest" in virtual_facts
    assert "virtualization_technologies_host" in virtual_facts

# Generated at 2022-06-20 20:14:22.236555
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    cur_dir = os.path.dirname(__file__)
    file_path = os.path.abspath(cur_dir)
    file_path = file_path + "/test_FreeBSDVirtual_get_virtual_facts.py"
    f = open(file_path, "w")

# Generated at 2022-06-20 20:14:25.653580
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_instance = FreeBSDVirtualCollector()
    assert facts_instance.platform == 'FreeBSD'
    assert facts_instance._fact_class == FreeBSDVirtual
    assert facts_instance._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:27.161017
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:14:40.027331
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an empty FreeBSDVirtual object
    fbsdvirt = FreeBSDVirtual()

    # Set empty values as default
    fbsdvirt.get_virtual_facts()
    assert fbsdvirt.virtual_facts['virtualization_type'] == ''
    assert fbsdvirt.virtual_facts['virtualization_role'] == ''

    # Testing in a Jail
    fbsdvirt.sysctl_dict = {
        'hw.model': 'VirtualBox',
        'security.jail.jailed': '2',
        'kern.vm_guest': 'unknown',
        'hw.hv_vendor': 'None',
        'hw.hv_version': 'None'
    }
    fbsdvirt.get_virtual_facts()

# Generated at 2022-06-20 20:14:44.841575
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    freebsd_virtual_collector = FreeBSDVirtual()
    result = freebsd_virtual_collector.get_virtual_facts()

    # Expected result with tests on a virtual machine
    result_expected = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
    }

    # Test each values of the result
    for key in result:
        assert result[key] == result_expected[key]

# Generated at 2022-06-20 20:14:56.192700
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test facts
    test_facts = {
        'system': 'FreeBSD',
        'kernel': 'FreeBSD',
        'machine': 'amd64',
        'os_family': 'FreeBSD',
        'distribution': 'FreeBSD',
        'virtualization_type': '',
        'virtualization_role': '',
    }

    # Expected facts
    virtual_facts = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware', 'virtualbox']),
        'virtualization_tech_host': set([]),
    }
    virtual_facts['virtualization_type_full'] = 'vmware'

    _test_FreeBSDVirtual = FreeBSDVirtual(test_facts, None)
    result = _

# Generated at 2022-06-20 20:14:58.312166
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  assert FreeBSDVirtualCollector._platform == 'FreeBSD'
  assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:03.764171
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, {})
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
    }
    assert sorted(virtual.get_virtual_facts().items()) == sorted(virtual_facts.items())

# Generated at 2022-06-20 20:15:07.493733
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    results = v.get_virtual_facts()
    assert 'virtualization_type' in results
    assert 'virtualization_role' in results
    assert 'virtualization_tech_host' in results
    assert 'virtualization_tech_guest' in results

# Generated at 2022-06-20 20:15:13.610301
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    plugin = FreeBSDVirtual()
    assert plugin.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:17.540387
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert isinstance(fv, Virtual)
    assert isinstance(fv, VirtualSysctlDetectionMixin)
    assert fv.platform == 'FreeBSD'
    assert fv.get_virtual_facts() == {}



# Generated at 2022-06-20 20:15:19.571956
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:31.841118
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual class object
    fb_virt = FreeBSDVirtual()
    # Create a dictionary that will serve as the input to the method
    # get_virtual_facts of class FreeBSDVirtual
    input_virtual_facts = {
        'kern.vm_guest': 'other',
        'hw.model': 'HVM domU'
    }
    # Assign the created dictionary to the fact_virtual_data attribute of
    # the FreeBSDVirtual class object
    fb_virt.fact_virtual_data = input_virtual_facts
    # Get the result of calling the method get_virtual_facts of class
    # FreeBSDVirtual
    result = fb_virt.get_virtual_facts()
    # Check if the expected result is same as the result obtained by calling
    # the method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:15:41.460028
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual()

    MOCK_OUTPUT_VIRTUAL_PRODUCT_KERN_VM_GUEST = {
        "HARDWARE_SYSTEM_PRODUCT": "VirtualBox"
    }

    MOCK_OUTPUT_VIRTUAL_PRODUCT_HW_HV_VENDOR = {
        "HARDWARE_SYSTEM_PRODUCT": "VMware"
    }

    MOCK_OUTPUT_VIRTUAL_PRODUCT_SEC_JAIL_JAILED = {
        "SECURITY_JAIL_JAILED": "1"
    }

    MOCK_OUTPUT_VIRTUAL_VENDOR = {
        "HARDWARE_MODEL": "VirtualBox"
    }


# Generated at 2022-06-20 20:15:43.499738
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({},{})
    assert isinstance(fv, Virtual)



# Generated at 2022-06-20 20:15:48.270341
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual({})
    assert fv.get_virtual_facts() == {
        'virtual_facts': {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set([]),
            'virtualization_tech_host': set([]),
        }
    }

# Generated at 2022-06-20 20:15:51.782288
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = VirtualCollector().get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:15:59.796437
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual('localhost')
    f._get_virtual_facts = lambda: {'virtualization_type': 'hvm', 'virtualization_role': 'host',
                                    'virtualization_tech_guest': set(['virtualbox', 'kvm']),
                                    'virtualization_tech_host': set(['virtualbox', 'kvm'])}
    f._get_virtual_vendor_facts = lambda: {'virtualization_type': 'hvm', 'virtualization_role': 'host',
                                           'virtualization_tech_guest': set(['virtualbox', 'kvm']),
                                           'virtualization_tech_host': set(['virtualbox', 'kvm'])}
    f.collect()

# Generated at 2022-06-20 20:16:03.236617
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:09.899697
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collect_virt = FreeBSDVirtualCollector()
    assert collect_virt.platform == 'FreeBSD'
    assert collect_virt._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:22.386071
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    # Initialize FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()
    # Set some static facts
    freebsd_virtual.sysctl = {'kern.vm_guest': 'none',
                              'hw.hv_vendor': 'Bhyve',
                              'security.jail.jailed': '0'}
    freebsd_virtual.hw_model = 'QEMU Virtual CPU'
    # Create variables needed by the test
    sysctl_guest = {'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}
    sysctl_host = {'virtualization_tech_guest': set(),
                   'virtualization_tech_host': set(['bhyve'])}

# Generated at 2022-06-20 20:16:27.638163
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """This function tests the constructor of class FreeBSDVirtual"""
    virtual_instance = FreeBSDVirtual()
    assert isinstance(virtual_instance, Virtual)
    assert isinstance(virtual_instance, FreeBSDVirtual)
    assert hasattr(virtual_instance, 'get_virtual_facts')

# Generated at 2022-06-20 20:16:29.513889
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsdVirtual = FreeBSDVirtual()
    assert freebsdVirtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:34.888586
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def get_file_content(path):
        return  "hw.vmm.vm_guest: freebsd"

    setattr(FreeBSDVirtualCollector, '_read_file_on_disk', get_file_content)
    virtual_facts = FreeBSDVirtualCollector(None).collect()
    # Expected results
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:16:36.608988
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual()
    assert obj


# Generated at 2022-06-20 20:16:38.299755
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:40.320793
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert hasattr(FreeBSDVirtual, 'platform')
    assert FreeBSDVirtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:45.006091
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-20 20:16:47.525930
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector(None)
    assert freebsd_virtual._platform == 'FreeBSD'
    assert freebsd_virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:00.262400
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:17:01.540092
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:17:02.577022
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:17:04.291799
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class is FreeBSDVirtual
    assert virtual_collector._platform is 'FreeBSD'

# Generated at 2022-06-20 20:17:06.653570
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'

    assert fv._platform == 'FreeBSD'
    assert fv._fact_class.platform == 'FreeBSD'
    assert fv._fact_class.get_virtual_facts.__self__.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:08.787390
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = VirtualCollector._platforms['FreeBSD']().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:17:10.926576
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert isinstance(virt, Virtual)


# Test that this module runs without errors

# Generated at 2022-06-20 20:17:19.646725
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class is not None
    assert collector._fact_class.platform == 'FreeBSD'
    assert collector._fact_class.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '',
                                                         'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:17:23.190138
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fb_vco = FreeBSDVirtualCollector()
    assert fb_vco.platform == 'FreeBSD'
    assert fb_vco._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:28.411286
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Create an instance of FreeBSDVirtualCollector and fill in the attributes
    of the instance.
    """

    # Run the constructor
    facts_class = FreeBSDVirtualCollector()

    # Check all the class attributes
    assert facts_class._fact_class == FreeBSDVirtual
    assert facts_class._platform == 'FreeBSD'
    assert facts_class._virtual_facts == {}
    assert facts_class._cache_dir == 'ansible_virtual_facts'
    assert facts_class._cache_file == 'ansible_virtual_facts_cache'
    assert facts_class._write_cache is True
    assert facts_class._use_cache is True


# Generated at 2022-06-20 20:17:46.531957
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    # Set empty values as default
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert (virtual.get_virtual_facts() == virtual_facts)

# Generated at 2022-06-20 20:17:58.360163
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit tests for the output of the get_virtual_facts method of the FreeBSDVirtual class
    facts = FreeBSDVirtual().get_virtual_facts()

    # test for virtualization_type
    test = 'virtualization_type'
    assert test in facts, 'test ("%s") not found in output' % test
    assert facts[test] == 'xen' or facts[test] == '', 'The value of %s %s is not xen or blank' % (test, facts[test])

    # test for virtualization_role
    test = 'virtualization_role'
    assert test in facts, 'test ("%s") not found in output' % test
    assert facts[test] == 'guest' or facts[test] == '', 'The value of %s %s is not guest or blank' % (test, facts[test])

    # test

# Generated at 2022-06-20 20:18:10.805050
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Patch module_utils.virtual.sysctl.VirtualSysctlDetectionMixin.get_sysctl_value
    # method to return known values
    import ansible.module_utils.facts.virtual.sysctl
    get_sysctl_value_orig = ansible.module_utils.facts.virtual.sysctl.VirtualSysctlDetectionMixin.get_sysctl_value

    freebsd_virtual = FreeBSDVirtual()

    def get_sysctl_value_mock(self, variable_name):
        if variable_name == 'kern.vm_guest':
            return 'vmware'
        if variable_name == 'hw.hv_vendor':
            return 'bhyve'
        if variable_name == 'security.jail.jailed':
            return 1

# Generated at 2022-06-20 20:18:14.204799
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test FreeBSDVirtualCollector
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:16.295706
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    assert FreeBSDVirtual().platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:27.728534
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class TestFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            super(TestFreeBSDVirtual, self).__init__()
            self._virtual_facts = {}
            self.sysctl_virtualization_facts = {}

        def detect_virt_product(self, sysctl):
            product_facts = {}
            product_facts['virtualization_type'] = self.sysctl_virtualization_facts.get(sysctl, '')
            product_facts['virtualization_role'] = self.sysctl_virtualization_facts.get('virtualization_role', '')
            return product_facts

        def detect_virt_vendor(self, sysctl):
            vendor_facts = {}
            vendor_facts['virtualization_type'] = self.sysctl_virtualization_facts.get(sysctl, '')
            vendor_

# Generated at 2022-06-20 20:18:29.073385
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc is not None

# Generated at 2022-06-20 20:18:32.235705
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:18:38.949537
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import collector

    # Update the _gather_platforms
    collector._gather_platforms = []

    # Create the instance and test it.
    fbvc = FreeBSDVirtualCollector()
    assert fbvc
    assert isinstance(fbvc, FreeBSDVirtualCollector)
    assert fbvc.platform == 'FreeBSD'
    assert fbvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:41.380151
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert obj._platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:26.389306
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_sysctl_kernel_vm_guest = {
        "kern.vm_guest": "other",
        "virtualization_type": "other",
        "virtualization_role": "guest",
        "virtualization_technology_guest": [],
        "virtualization_technology_host": []
    }
    fake_sysctl_hw_hv_vendor = {
        "hw.hv_vendor": "other",
        "virtualization_type": "other",
        "virtualization_role": "host",
        "virtualization_technology_guest": [],
        "virtualization_technology_host": []
    }

# Generated at 2022-06-20 20:19:29.298584
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual
    assert isinstance(fbsd_virtual, Virtual)
    assert isinstance(fbsd_virtual, VirtualSysctlDetectionMixin)

# Generated at 2022-06-20 20:19:32.981480
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Arrange.
    # Act.
    c = FreeBSDVirtualCollector()

    # Assert.
    assert c is not None
    assert isinstance(c, VirtualCollector)
    assert c._platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:19:35.335313
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collect = FreeBSDVirtualCollector()
    assert isinstance(collect._fact_class, FreeBSDVirtual)
    assert collect._platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:36.246747
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector(None)
    assert fvc.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:36.810006
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:19:38.244363
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert isinstance(v,FreeBSDVirtual)
    assert isinstance(v,Virtual)

# Generated at 2022-06-20 20:19:38.739392
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:19:39.636329
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:50.551791
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'hardware_product_name': '',
        'hardware_vendor_name': '',
        'hardware_serial_number': '',
        'hardware_uuid': ''
    }

    def add_virtual_tech(tech_type, tech_set, tech_name):
        tech_set.add(tech_name)

    class FreeBSDSysctlDetectionMixinMock():
        SEC_JAIL_JAILED = ['0']
        KERN_VM_GUEST = ['other']
        HW_HV_VENDOR = ['Other']

# Generated at 2022-06-20 20:21:02.379242
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:21:03.848765
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == "FreeBSD"

# Generated at 2022-06-20 20:21:08.503837
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:21:13.925240
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvcollector = FreeBSDVirtualCollector()
    assert fvcollector._platform == 'FreeBSD'
    assert issubclass(fvcollector._fact_class, FreeBSDVirtual)
    assert issubclass(fvcollector._fact_class, Virtual)
    assert fvcollector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:14.856305
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:21:15.703962
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert isinstance(virtual, FreeBSDVirtual)



# Generated at 2022-06-20 20:21:18.029553
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    test_object = FreeBSDVirtual()
    assert test_object.platform == 'FreeBSD'


# Generated at 2022-06-20 20:21:19.945679
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:23.264554
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd = FreeBSDVirtual('freebsd')
    assert bsd.platform == "FreeBSD"


# Generated at 2022-06-20 20:21:27.387720
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''
    virtual_collector_object = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector_object, VirtualCollector)
    assert virtual_collector_object._platform == 'FreeBSD'
    assert virtual_collector_object._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:23:47.701520
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest

    collect = FreeBSDVirtualCollector()

    vs = collect.collect()
    assert vs['virtualization_type'] in ('', 'xen', 'vmware', 'physical')
    assert vs['virtualization_role'] in ('', 'guest', 'host', 'physical')



# Generated at 2022-06-20 20:23:49.351617
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    results = FreeBSDVirtual({})
    assert results['virtualization_type'] == ''
    assert results['virtualization_role'] == ''

# Generated at 2022-06-20 20:23:52.747298
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual()
    assert freebsd.get_virtual_facts()['virtualization_type'] == 'xen'
    assert freebsd.get_virtual_facts()['virtualization_role'] == 'guest'
    assert 'xen' in freebsd.get_virtual_facts()['virtualization_tech_guest']
    assert 'xen' not in freebsd.get_virtual_facts()['virtualization_tech_host']

# Generated at 2022-06-20 20:23:54.961052
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'


# Generated at 2022-06-20 20:24:04.320728
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    kern_vm_guest = dict()
    kern_vm_guest['virtualization_tech_guest'] = set()
    kern_vm_guest['virtualization_tech_host'] = set()
    hw_hv_vendor = dict()
    hw_hv_vendor['virtualization_tech_guest'] = set()
    hw_hv_vendor['virtualization_tech_host'] = set()
    sec_jail_jailed = dict()
    sec_jail_jailed['virtualization_tech_guest'] = set()
    sec_jail_jailed['virtualization_tech_host'] = set()

    instance = FreeBSDVirtual()
    instance.read_file = lambda filepath: kern_vm_guest
    instance.is_