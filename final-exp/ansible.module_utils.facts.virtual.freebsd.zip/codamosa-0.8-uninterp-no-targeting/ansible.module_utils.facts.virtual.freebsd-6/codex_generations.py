

# Generated at 2022-06-20 20:14:14.817612
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:14:21.592120
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {'virtualization_tech_guest': guest_tech, 'virtualization_tech_host': host_tech}
    assert FreeBSDVirtual(virtual_facts).virtual
    host_tech.add('xen')
    assert FreeBSDVirtual(virtual_facts).virtual
    guest_tech.add('openvz')
    assert FreeBSDVirtual(virtual_facts).virtual


# Generated at 2022-06-20 20:14:25.425215
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = {}
    FreeBSDVirtual(facts, {})

    for key in ['virtualization_type', 'virtualization_role',
                'virtualization_tech_guest', 'virtualization_tech_host']:
        assert key in facts

# Generated at 2022-06-20 20:14:31.557130
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    output_sysctl = 'jail: no\nvm.vmtotal: 6 entries\nhw.hv_vendor: Unknown\nsecurity.jail.jailed: 0\nkern.vm_guest:  guest_type = "unknown"\nhw.model: VMware, Inc. VMware Virtual Platform\n'
    freebsd_virtual.sysctl_output = output_sysctl

    expected = {
        'virtualization_type': 'unknown',
        'virtualization_role': '',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(['vmware']),
    }

    assert freebsd_virtual.get_virtual_facts() == expected

# Generated at 2022-06-20 20:14:40.265049
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # A unit test for the module
    # The name of the test class must begin with 'test_' and the name of
    # the testing function must begin with 'test_'.
    # The testing function must accept exactly one argument, 'self'.
    #
    # https://docs.python.org/2.7/library/unittest.html#basic-example
    #
    # If you need more help,
    # see https://github.com/ansible/ansible/blob/devel/test/units/modules/aix_lsdev_fact.py
    module = FreeBSDVirtual()
    assert module._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:52.810039
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Mock a FreeBSD system for testing
    provided_sysctl_product = {'hw.hv_vendor': 'VirtualBox',
                               'kern.vm_guest': 'other',
                               'security.jail.jailed': '0'}

    provided_sysctl_vendor = {'hw.model': 'Intel(R) Core(TM) i3-2310M CPU @ 2.10GHz'}

    """
    Expected result:
    {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set()
    }
    """
    # Instantiate a FreeBSDVirtual object

# Generated at 2022-06-20 20:14:57.665084
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create fixture
    virtual_fact = FreeBSDVirtual()

    # Test get_virtual_facts method
    result_virtual_facts = virtual_fact.get_virtual_facts()

    # Check the result
    assert 'virtualization_type' in result_virtual_facts
    assert 'virtualization_role' in result_virtual_facts
    assert 'virtualization_tech_guest' in result_virtual_facts
    assert 'virtualization_tech_host' in result_virtual_facts

# Generated at 2022-06-20 20:15:09.042596
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockedFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, product):
            return {'virtualization_tech_guest': {'kvm'},
                    'virtualization_tech_host': {'openvz'}}

        def detect_virt_vendor(self, vendor):
            return {'virtualization_tech_guest': {'kvm'},
                    'virtualization_tech_host': {'openvz'}}

    mocked_freebsd_virtual = MockedFreeBSDVirtual()

    virtual_facts = mocked_freebsd_virtual.get_virtual_facts()

    assert set(virtual_facts['virtualization_tech_host']) == {'openvz'}
    assert set(virtual_facts['virtualization_tech_guest']) == {'kvm'}
   

# Generated at 2022-06-20 20:15:19.439221
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_sysctl_values = {}
    fake_sysctl_values['hw.hv_vendor'] = 'VMware'
    fake_sysctl_values['kern.vm_guest'] = 'vmware'
    fake_sysctl_values['security.jail.jailed'] = '1'
    facts = FreeBSDVirtual(sysctl_values=fake_sysctl_values)

    virtual_facts = facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware', \
        "virtualization_type for VMware VM running on FreeBSD is wrong"
    assert virtual_facts['virtualization_role'] == 'guest', \
        "virtualization_role for VMware VM running on FreeBSD is wrong"

# Generated at 2022-06-20 20:15:21.272948
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:29.048327
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()
    assert f.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:15:34.935065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collection = FreeBSDVirtualCollector(None, "FreeBSD")
    collection.parse()
    result = collection.get_facts()

    assert 'virtualizations' in result
    virtualizations = result['virtualizations']

    assert virtualizations[0]['virtualization_type'] == 'xen'
    assert virtualizations[0]['virtualization_role'] == 'guest'
    assert virtualizations[0]['virtualization_tech_host'] == set()
    assert virtualizations[0]['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-20 20:15:37.810895
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:40.542835
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual({},{},{},{})
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:43.868690
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual
    assert virtual.sysctl_cmd == '/sbin/sysctl hw.hv_vendor security.jail.jailed kern.vm_guest'

# Generated at 2022-06-20 20:15:44.400176
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vf = FreeBSDVirtual()
    assert vf.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:49.231002
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

# Generated at 2022-06-20 20:15:49.873922
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:58.199610
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts_dict = dict()
    facts_dict['ansible_os_family'] = 'FreeBSD'
    facts_dict['ansible_system'] = 'FreeBSD'
    facts_dict['ansible_distribution'] = 'FreeBSD'
    facts_dict['ansible_distribution_version'] = '11.2-RELEASE'
    facts_dict['ansible_distribution_release'] = '11.2-RELEASE'

    virtual = FreeBSDVirtual(facts_dict)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'



# Generated at 2022-06-20 20:16:04.958149
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Constructor of class FreeBSDVirtual should set new_facts to a dict of keys,
    virtualization_type and virtualization_role, with values '','guest'."""
    virt = FreeBSDVirtual({})
    assert virt.new_facts['virtualization_type'] == 'xen'
    assert virt.new_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:16:13.789987
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual('freebsd')
    assert (virtual_facts.facts['virtualization_type']
            == virtual_facts.get_virtual_facts()['virtualization_type'])
    assert (virtual_facts.facts['virtualization_role']
            == virtual_facts.get_virtual_facts()['virtualization_role'])



# Generated at 2022-06-20 20:16:15.225707
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform is not None

# Generated at 2022-06-20 20:16:18.826530
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, {})
    (virtualization_facts, host_facts) = virtual.get_virtual_facts_from_sysctl()
    print(virtualization_facts)

# Generated at 2022-06-20 20:16:21.113351
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:30.332118
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    # kern_vm_guest test
    virtual_facts.KERN_VM_GUEST = 'vmware'
    virtual_facts.HW_HV_VENDOR = 'BHYVE'
    virtual_facts.SEC_JAIL_JAILED = 0
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == 'vmware'
    assert 'vmware' in virtual_facts.get_virtual_facts()['virtualization_tech_guest']
    assert 'vmware' in virtual_facts.get_virtual_facts()['virtualization_tech_host']
    # hw_hv_vendor test
    
    virtual_facts.KERN_VM_GUEST = 'none'

# Generated at 2022-06-20 20:16:35.469684
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    _test_virtual = FreeBSDVirtual()
    _test_data = _test_virtual.get_virtual_facts()
    assert "virtualization_type" in _test_data
    assert "virtualization_role" in _test_data
    assert "virtualization_tech_guest" in _test_data
    assert "virtualization_tech_host" in _test_data



# Generated at 2022-06-20 20:16:40.772771
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    class_inst = FreeBSDVirtualCollector()
    if FreeBSDVirtual not in class_inst.__class__.__bases__:
        raise Exception("%s is not an instance of FreeBSDVirtual" % class_inst)
    if class_inst._platform != 'FreeBSD':
        raise Exception("%s is not a FreeBSD platform" % class_inst._platform)

# Generated at 2022-06-20 20:16:50.552688
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb = FreeBSDVirtual()
    # GET_VIRTUAL_FAKE_FACTS is the ansible_facts passed to the module
    # get_virtual_facts is a method of FreeBSDVirtual
    # returned_facts is the ansible_facts returned to the module
    returned_facts = fb.get_virtual_facts(GET_VIRTUAL_FAKE_FACTS)
    assert returned_facts == GET_VIRTUAL_RETURNED_FACTS


# Generated at 2022-06-20 20:16:54.756983
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            self.sysctl_facts = {
                'kern.vm_guest': {
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set(),
                },
                'hw.hv_vendor': {
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set(),
                },
                'security.jail.jailed': {
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set(),
                },
            }

    # Checking physical machine
    result = {}

# Generated at 2022-06-20 20:16:56.748802
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:17:01.912968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, VirtualCollector)

# Generated at 2022-06-20 20:17:02.642938
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual

# Generated at 2022-06-20 20:17:07.566602
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:17:11.584640
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-20 20:17:23.194629
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    my_freebsd_virtual = FreeBSDVirtual({}, {})
    j = os.path.join
    test_files_dir = j(os.path.dirname(os.path.realpath(__file__)), 'files')
    my_freebsd_virtual.get_file_content = lambda x: open(j(test_files_dir, x)).read()
    virtual_facts = my_freebsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-20 20:17:31.253867
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import json

    _freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Convert the test data to JSON format
    _freebsd_virtual_collector_json = json.dumps(_freebsd_virtual_collector.collect())

    # Verify whether the test data and constructor data are fixed
    assert _freebsd_virtual_collector_json == '{"virtualization_tech_host": [], "ansible_virtualization_type": "", "ansible_virtualization_role": "", "virtualization_tech_guest": []}'

# Generated at 2022-06-20 20:17:34.302015
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_collector = FreeBSDVirtualCollector()
    assert freebsd_collector.platform == 'FreeBSD'
    assert freebsd_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:36.524462
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Unit test FreeBSDVirtualCollector.get_virtual_facts()

# Generated at 2022-06-20 20:17:39.554246
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # FreeBSDVirtual should be instance of FreeBSDVirtual
    virtual_facts = FreeBSDVirtual({})
    assert isinstance(virtual_facts, FreeBSDVirtual)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:49.197153
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_facts = dict(kernel='FreeBSD',
                      virtual=None,
                      system='FreeBSD',
                      sysctl={'kern.vm_guest': 'unknown',
                              'hw.hv_vendor': 'OpenBSD',
                              'security.jail.jailed': '0',
                              'hw.model': 'OpenBSD'})
    expected_facts = dict(virtualization_type='openbsd-xen',
                          virtualization_role='host',
                          virtualization_tech_host=set(['openvz']),
                          virtualization_tech_guest=set([]))
    test_obj = FreeBSDVirtual(mock_facts)
    assert test_obj.get_virtual_facts() == expected_facts

# Generated at 2022-06-20 20:18:01.773123
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd.restapi_facts import RestApiFacts
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.restapi_facts = RestApiFacts()
        def exit_json(self):
            return None
        def fail_json(self):
            return None
    fake_module = FakeModule()
    fake_module.params = {'gather_subset': '!all,!any'}
    virtual_facts = FreeBSDVirtual(fake_module).get_virtual_facts()

# Generated at 2022-06-20 20:18:03.613057
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    virtual_facts = virtual_facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:18:05.423415
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_instance = FreeBSDVirtual(None)
    assert freebsd_virtual_instance


# Generated at 2022-06-20 20:18:07.257537
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()
    assert fb_virtual.platform == "FreeBSD"

# Generated at 2022-06-20 20:18:09.390426
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtualCollector()
    res = obj.get_virtual_facts()
    assert('virtualization_role' in res)

# Generated at 2022-06-20 20:18:18.554511
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    # Test output type
    assert isinstance(virtual_facts, dict)
    for key in ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']:
        # Test key
        assert key in virtual_facts
        # Test value type
        if key == 'virtualization_tech_guest' or key == 'virtualization_tech_host':
            assert isinstance(virtual_facts[key], set)
        else:
            assert isinstance(virtual_facts[key], str)

# Generated at 2022-06-20 20:18:28.218110
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock module
    module = type('AnsibleModule', (), {'params': {'gather_subset': ['!all', 'virtual']}})()
    # Create instance of FreeBSDVirtual, then we can call the methods.
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    bsd_virtual_facts = FreeBSDVirtual(module)

    # Mock data
    # Virtualization type
    kern_vm_guest = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-20 20:18:36.381521
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils._text import to_bytes

    test_obj = FreeBSDVirtual({}, {})

    s = '''
Virtualization: xen
            guest OS type: FreeBSD
'''
    # Assert that the expected virtualization_type and virtualization_role are
    # detected.
    test_input = {'proc_cmdline': to_bytes(s),
                  'product_name': to_bytes(s),
                  'dmesg': to_bytes(s)}
    output = test_obj.get_virtual_facts(test_input)
    assert output['virtualization_type'] == 'xen'
    assert output['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:18:38.351179
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virt = FreeBSDVirtual({})
    assert fbsd_virt.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:40.815557
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual(None)
    assert virt is not None
    assert virt.platform == 'FreeBSD'
    assert virt.service_mgr == ''

# Generated at 2022-06-20 20:18:51.528212
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:59.490614
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup FreeBSDVirtual class for testing
    virtual_facts = FreeBSDVirtual()
    # Execute method get_virtual_facts of class FreeBSDVirtual
    virtual_facts_type = virtual_facts.get_virtual_facts()
    # Assert the result
    assert virtual_facts_type.has_key('virtualization_type')
    assert virtual_facts_type.has_key('virtualization_role')
    assert virtual_facts_type.has_key('virtualization_tech_guest')
    assert virtual_facts_type.has_key('virtualization_tech_host')

# Generated at 2022-06-20 20:19:04.555765
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import _VirtualSysctlDetectionMixin
    with open('/dev/null', 'w') as DEVNULL:
        orig_stdout = os.dup(sys.stdout.fileno())
        os.dup2(DEVNULL.fileno(), sys.stdout.fileno())
        _VirtualSysctlDetectionMixin.detect_virt_product = _detect_virt_product_mock
        _VirtualSysctlDetectionMixin.detect_virt_vendor = _detect_virt_vendor_mock
        virtual = FreeBSDVirtual()
        virtual_facts = virtual.get_virtual_facts()
        os.dup2(orig_stdout, sys.stdout.fileno())
        assert virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:19:14.465491
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kern_vm_guest = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    hw_hv_vendor = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    sec_jail_jailed = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:19:17.129898
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == "FreeBSD"
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:19:20.999890
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''


# Generated at 2022-06-20 20:19:22.011455
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:28.266534
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.module = MockFreeBSDModule()
    freebsd_virtual.get_virtual_facts()

    virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
    }
    assert freebsd_virtual.facts == virtual_facts



# Generated at 2022-06-20 20:19:37.668004
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtualCollector()
    virtual_facts = collector.get_virtual_facts()

    # Values of virtualization_type and virtualization_role
    # which are computed from module_utils/facts/virtual/sysctl.py
    assert virtual_facts['virtualization_type'] == 'other'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Values of virtualization_tech_guest and virtualization_tech_host
    # which are computed from module_utils/facts/virtual/sysctl.py
    assert virtual_facts['virtualization_tech_guest'] == set(['xen',
                                                              'parallels'])
    assert virtual_facts['virtualization_tech_host'] == set(['parallels'])

    # Values of virtualization_type and virtualization_role
    # which are

# Generated at 2022-06-20 20:19:39.395463
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts


# Generated at 2022-06-20 20:19:55.735327
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create test object of class FreeBSD_Virtual
    freebsd_virtual = FreeBSDVirtual()
    # Check if the result is a instance of class FreeBSDVirtual
    assert isinstance(freebsd_virtual, FreeBSDVirtual)


# Generated at 2022-06-20 20:20:02.904813
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual({})
    # check content of virtual_facts
    assert 'virtualization_type' in fbv.virtual_facts
    assert 'virtualization_role' in fbv.virtual_facts
    assert 'virtualization_tech_guest' in fbv.virtual_facts
    assert 'virtualization_tech_host' in fbv.virtual_facts
    # check content of virtual_facts['virtualization_tech_guest']
    for k in [
        'bhyve', 'jail', 'kvm', 'openvz', 'xen', 'vmware',
    ]:
        assert k in fbv.virtual_facts['virtualization_tech_guest']
    # check content of virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:20:13.711228
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    freebsd_virtual = FreeBSDVirtual()

    # pylint: disable=protected-access
    freebsd_virtual._sysctl_info = {
        'kern.vm_guest': 'freebsd',
        'security.jail.jailed': '0',
        'hw.hv_vendor': 'Bhyve',
        'hw.model': 'Genuine Intel(R) CPU @ 2.90GHz'
    }
    # pylint: enable=protected-access

    virtual_facts = freebsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'bhyve'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == {'bhyve'}

# Generated at 2022-06-20 20:20:22.467063
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test to test the constructed facts of class FreeBSDVirtual'''
    test_platform = 'FreeBSD'
    test_facts = {}
    test_facts['virtualization_type'] = 'hardware'
    test_facts['virtualization_role'] = 'host'
    test_facts['virtualization_tech_guest'] = set(['kvm', 'hyperv'])
    test_facts['virtualization_tech_host'] = set(['docker'])
    test_facts['virtualization_vendor_facts'] = {'virtualization_vendor': 'HPE', 'virtualization_nested': 'True', 'virtualization_nested_guest': 'True', 'virtualization_nested_role': 'guest'}
    freebsd_virtual = FreeBSDVirtual(test_platform, test_facts)
    assert freebsd

# Generated at 2022-06-20 20:20:26.158011
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Set empty values as default
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:20:28.862989
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.__class__._fact_class is FreeBSDVirtual
    assert collector.__class__._platform is 'FreeBSD'

# Generated at 2022-06-20 20:20:31.228966
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:20:33.743690
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual



# Generated at 2022-06-20 20:20:35.191709
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-20 20:20:44.683377
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class FreeBSDVirtual
    facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    # Create a subclass of FreeBSDVirtual.
    class MyFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, sysctl_property):
            if sysctl_property == 'kern.vm_guest':
                return {
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set(),
                }

# Generated at 2022-06-20 20:21:18.560154
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert(hasattr(FreeBSDVirtualCollector, '_platform'))
    assert(FreeBSDVirtualCollector._platform == 'FreeBSD')



# Generated at 2022-06-20 20:21:29.829310
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class Runner(object):
        def __init__(self, module_name, module_args, tmp, task_vars=None):
            self.module_name = module_name
            self.module_args = module_args
            self.tmp = tmp
            self.task_vars = task_vars

        def run(self):
            return None

    sysctl_facts = {'hw.hv_vendor': 'bhyve',
                    'kern.vm_guest': 'bhyve',
                    'security.jail.jailed': 1,
                    'hw.model': 'FreeBSD/amd64'}

    facts = {'ansible_system': 'FreeBSD'}
    virt = FreeBSDVirtual(Runner, facts, sysctl_facts)
    result = virt.get_virtual_facts()
    assert result

# Generated at 2022-06-20 20:21:33.667302
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert isinstance(f, FreeBSDVirtualCollector)
    assert isinstance(f._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:21:43.482324
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    host_tech = set()
    guest_tech = set()
    os.path.exists = lambda path: True
    virtual_facts = fbsd_virtual.get_virtual_facts()
    if os.path.exists('/dev/xen/xenstore'):
        guest_tech.add('xen')
        virtual_facts['virtualization_type'] = 'xen'
        virtual_facts['virtualization_role'] = 'guest'

    kern_vm_guest = {}
    hw_hv_vendor = {}
    sec_jail_jailed = {}

# Generated at 2022-06-20 20:21:44.272172
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:21:45.326921
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:21:50.859565
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    This method unit tests the get_virtual_facts method of the class FreeBSDVirtual
    :return:
    """
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:21:55.141873
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fb = FreeBSDVirtualCollector()
    assert isinstance(fb, VirtualCollector)
    assert issubclass(fb.__class__, VirtualCollector)
    assert isinstance(fb._fact_class([]), FreeBSDVirtual)
    assert not isinstance(fb, FreeBSDVirtual)


# Generated at 2022-06-20 20:21:56.920162
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc._fact_class, FreeBSDVirtual)
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:00.679874
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_obj = FreeBSDVirtual()
    assert freebsd_virtual_obj.platform == 'FreeBSD'
    assert freebsd_virtual_obj.get_virtual_facts() == \
        {'virtualization_type': '', 'virtualization_role': '',
         'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:22:39.149211
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_obj = FreeBSDVirtual({})
    assert virtual_obj.collect()
    assert virtual_obj.data

# Generated at 2022-06-20 20:22:39.723170
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:41.841558
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collection = FreeBSDVirtualCollector()

    # On FreeBSD virtual facts should always be empty dict
    result = collection.get_virtual_facts()
    assert result == collection._fact_class.EMPTY_FACTS

# Generated at 2022-06-20 20:22:51.762729
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class FreeBSDVirtual
    bsd = FreeBSDVirtual()
    # pylint: disable=protected-access
    vf = bsd._get_virtual_facts()
    # pylint: enable=protected-access
    assert 'virtualization_type' in vf
    assert 'virtualization_role' in vf
    assert 'virtualization_tech_guest' in vf
    assert 'virtualization_tech_host' in vf
    assert 'virtualization_product' in vf
    assert 'virtualization_vendor' in vf

# Generated at 2022-06-20 20:22:54.977801
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == "FreeBSD"

    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == "FreeBSD"

# Generated at 2022-06-20 20:23:02.155981
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual_dict = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in freebsd_virtual_dict
    assert 'virtualization_role' in freebsd_virtual_dict
    assert 'virtualization_tech_guest' in freebsd_virtual_dict
    assert 'virtualization_tech_host' in freebsd_virtual_dict

# Generated at 2022-06-20 20:23:02.988466
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual = FreeBSDVirtualCollector()
    assert bsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:08.347592
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    facts_dict = dict()
    facts_dict['virtualization_type'] = 'xen'
    facts_dict['virtualization_role'] = 'guest'
    facts_dict['virtualization_tech_guest'] = set(['xen'])
    facts_dict['virtualization_tech_host'] = set()

    fb_virtual = FreeBSDVirtual(facts_dict)
    # test get_virtual_facts method
    assert(fb_virtual.get_virtual_facts() == facts_dict)

# Generated at 2022-06-20 20:23:13.154099
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()

    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._virtual_facts == {}
    assert virtual_facts._all_facts == {}
    assert virtual_facts._supported_fact_groups == frozenset(['virtual'])

# Generated at 2022-06-20 20:23:14.098262
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()
