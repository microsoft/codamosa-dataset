

# Generated at 2022-06-20 20:14:12.534695
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.collector_class == FreeBSDVirtualCollector


# Generated at 2022-06-20 20:14:24.536436
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test with "kern.vm_guest=other"
    kern_vm_guest_other = {'kern.vm_guest': 'other'}
    assert FreeBSDVirtual(kern_vm_guest_other).virtualization_type == ''
    assert FreeBSDVirtual(kern_vm_guest_other).virtualization_role == ''
    assert FreeBSDVirtual(kern_vm_guest_other).virtualization_tech_guest == set()
    assert FreeBSDVirtual(kern_vm_guest_other).virtualization_tech_host == set()

    # Test with "hw.hv_vendor=bhyve"
    hw_hv_vendor_bhyve = {'hw.hv_vendor': 'bhyve'}

# Generated at 2022-06-20 20:14:31.418981
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create a subtest with a stubbed sysctl
    def _test_with_sysctl(test, sysctl_func):

        # Create a FreeBSDVirtual instance
        freebsd_virtual_collector = FreeBSDVirtual()
        freebsd_virtual_collector._read_sysctl = sysctl_func

        # Test
        virtual_facts_dict = freebsd_virtual_collector.get_virtual_facts()

        # Assertions
        test.assertEquals(virtual_facts_dict['virtualization_type'], 'oracle')
        test.assertEquals(virtual_facts_dict['virtualization_role'], 'guest')
        test.assertEquals(virtual_facts_dict['virtualization_tech_guest'], set(['oracle']))

# Generated at 2022-06-20 20:14:42.085989
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = FreeBSDVirtual()
    # set values for bsd_version
    setattr(module, 'bsd_version', [ 8,4,18 ])

    # set values for virtualization_type
    setattr(module, 'virtualization_type', 'xen')
    assert module.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen'])
    }

    # set values for virtualization_type
    setattr(module, 'virtualization_type', 'xen')
    setattr(module, 'virtualization_tech_guest', set(['kvm']))

# Generated at 2022-06-20 20:14:42.958650
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-20 20:14:50.682109
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up FreeBSDVirtual instance
    virtual_ins = FreeBSDVirtual()

    # Call method get_virtual_facts with un-mocked function
    result = virtual_ins.get_virtual_facts()

    # Basic test for keys in returned result
    for key in ('virtualization_type', 'virtualization_role',
                'virtualization_tech_guest', 'virtualization_tech_host'):
        assert key in result



# Generated at 2022-06-20 20:14:52.662425
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    fv.collect()
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:54.994928
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''constructor'''
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:58.202712
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual import FreeBSDVirtualCollector
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:00.978192
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Test FreeBSDVirtual constructor
    """
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:11.396657
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual()

    assert fbsd_virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set([]),
    }

# Generated at 2022-06-20 20:15:12.353436
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-20 20:15:16.577773
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {}

    # Run the constructor of FreeBSDVirtualCollector
    virtual_Factory = FreeBSDVirtualCollector(facts, None)

    # Check if the result is of class FreeBSDVirtualCollector
    assert type(virtual_Factory) == FreeBSDVirtualCollector


# Generated at 2022-06-20 20:15:18.855405
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual({})
    fb.collect()
    assert fb.data.get('virtualization_type')
    assert fb.data.get('virtualization_role')

# Generated at 2022-06-20 20:15:23.871490
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_dict = {'virtual_facts': {'virtualization_type': '',
                                            'virtualization_role': '',
                                            'virtualization_tech_guest': set(),
                                            'virtualization_tech_host': set()}}
    virtual = FreeBSDVirtual(module=None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts() == virtual_facts_dict

# Generated at 2022-06-20 20:15:27.090108
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = True
    obj = FreeBSDVirtualCollector()
    if obj._fact_class is not FreeBSDVirtual:
        result = False
    if obj._platform is not 'FreeBSD':
        result = False
    return result

# Generated at 2022-06-20 20:15:29.160198
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtualCollector = FreeBSDVirtualCollector()
    assert virtualCollector.platform == 'FreeBSD'
    assert virtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:31.055323
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbvc = FreeBSDVirtualCollector()
    assert fbvc.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:32.650634
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert(virtual_facts.virtualization_type == '')


# Generated at 2022-06-20 20:15:39.106956
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}, {}).get_virtual_facts()
    assert type(virtual_facts) is dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:15:47.578830
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual('FreeBSD')
    assert isinstance(fb, FreeBSDVirtual)

# Generated at 2022-06-20 20:15:54.100611
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    get_virtual_facts = FreeBSDVirtual(None, None, None).get_virtual_facts()
    assert get_virtual_facts['virtualization_type'] == 'xen'
    assert get_virtual_facts['virtualization_role'] == 'guest'
    assert get_virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert get_virtual_facts['virtualization_tech_host'] == set([])



# Generated at 2022-06-20 20:16:00.611760
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    # test for sysctl jail
    jail_fact = dict(security_jail_jailed=1)
    sysctl = dict(security_jail_jailed=1)
    virtual_facts = virtual.get_virtual_facts(sysctl, jail_fact)
    assert 'jail' in virtual_facts['virtualization_type']
    assert 'guest' in virtual_facts['virtualization_role']
    assert 'jail' in virtual_facts['virtualization_tech_guest']
    assert 'freebsd Jail' in virtual_facts['virtualization_tech_guest']

    # test for sysctl vm_guest
    vm_guest_fact = dict(kern_vm_guest=1)
    sysctl = dict(kern_vm_guest=1)
    virtual_

# Generated at 2022-06-20 20:16:03.599929
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:05.526736
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:09.525596
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """ Test for constructor of class FreeBSDVirtual """
    freebsd_virtual_obj = FreeBSDVirtual()
    assert freebsd_virtual_obj.platform == 'FreeBSD'
    assert freebsd_virtual_obj.get_virtual_facts() == {}

# Generated at 2022-06-20 20:16:10.944790
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == FreeBSDVirtual.platform

# Generated at 2022-06-20 20:16:16.910863
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual({}, {}, "FreeBSD")
    results = fv.get_virtual_facts()
    assert results['virtualization_type'] == 'xen'
    assert results['virtualization_role'] == 'guest'
    assert results['virtualization_tech_guest'] == set(['xen'])
    assert results['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:16:20.292379
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create instance of FreeBSDVirtual class
    fb_virtual = FreeBSDVirtual()
    assert fb_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:22.256295
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == Virtual

# Generated at 2022-06-20 20:16:48.066630
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    facts = virtual.collect()
    assert facts['virtualization_type'] != 'NA'
    assert facts['virtualization_role'] != 'NA'
    assert facts['virtualization_type_role'] != 'NA'
    assert facts['virtualization_type_facts']['system_uuid'] != 'NA'
    assert facts['virtualization_type_facts']['product_name'] != 'NA'
    assert facts['virtualization_type_facts']['product_version'] != 'NA'

# Generated at 2022-06-20 20:16:49.210599
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:16:49.992515
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:16:57.466197
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def FakeSysctlDetectionMixin_detect_virt_product(self, sysctl='/dev/null'):
        if sysctl == 'kern.vm_guest':
            return {'virtualization_tech_host': [],
                    'virtualization_tech_guest': []}
        elif sysctl == 'hw.hv_vendor':
            return {'virtualization_tech_host': [],
                    'virtualization_tech_guest': []}
        elif sysctl == 'security.jail.jailed':
            return {'virtualization_tech_host': [],
                    'virtualization_tech_guest': []}


# Generated at 2022-06-20 20:16:58.763463
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check instance
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)



# Generated at 2022-06-20 20:17:00.344441
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v
    assert isinstance(v, Virtual)
    assert not v.sysctl_available
    assert not v.sysctl_path



# Generated at 2022-06-20 20:17:05.648353
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:17:08.642264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:18.338402
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    # Set up a dictionary of facts for MockFreeBSDVirtual to return
    test_facts = {
        'virtualization_type': 'KVM',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(['qemu']),
        'virtualization_tech_host': set(['kvm']),
    }

    # Construct a MockFreeBSDVirtual object, with test_facts dictionary
    test_virtual = MockFreeBSDVirtual(ansible_facts=test_facts)
    # Assert that the result of get_virtual_facts is equal to the
    # test_facts dictionary
    assert test_virtual.get_virtual_facts() == test_facts



# Generated at 2022-06-20 20:17:20.306390
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == "FreeBSD"

# Generated at 2022-06-20 20:17:57.478483
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""

    expected_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }

    tested_facts = FreeBSDVirtual().get_virtual_facts()

    assert tested_facts['virtualization_role'] == expected_facts['virtualization_role']
    assert tested_facts['virtualization_type'] == expected_facts['virtualization_type']
    assert tested_facts['virtualization_tech_guest'] == expected_facts['virtualization_tech_guest']
    assert tested_facts['virtualization_tech_host'] == expected_facts['virtualization_tech_host']

# Unit test

# Generated at 2022-06-20 20:18:03.534520
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsdVirtual = FreeBSDVirtual()
    assert freebsdVirtual.platform == 'FreeBSD'
    assert freebsdVirtual.virtualization_type == ''
    assert freebsdVirtual.virtualization_role == ''


# Generated at 2022-06-20 20:18:05.716387
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._platform == 'FreeBSD'
    assert isinstance(fv._fact_class, type)

# Generated at 2022-06-20 20:18:08.106400
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:09.504591
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:15.223766
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''

    # if we run on FreeBSD we expect that detected platform matches class
    # FreeBSDVirtualCollector._platform attribute
    if os.name == 'posix' and os.uname()[0] == FreeBSDVirtualCollector._platform:
        assert FreeBSDVirtualCollector.platform() == FreeBSDVirtualCollector._platform

# Generated at 2022-06-20 20:18:27.020257
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # mocking python-system-info to return valid values
    get_sbin_sysctl = lambda x: "1"
    type(ModuleStub)._sbin_sysctl = property(get_sbin_sysctl)

    # the expected output

# Generated at 2022-06-20 20:18:35.821471
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_methods = {
        'detect_virt_product': lambda x: {
            'virtualization_tech_guest': {'tech-guest'},
            'virtualization_tech_host': {'tech-host'}
        },
        'detect_virt_vendor': lambda x: {
            'virtualization_tech_guest': {'tech-guest'},
            'virtualization_tech_host': {'tech-host'}
        }
    }

    mock_method_names = mock_methods.keys()

    # Patch all the mock methods
    for method_name in mock_method_names:
        exec("%s = mock.Mock(side_effect=mock_methods['%s'])" % (method_name, method_name))

    # Create an instance of FreeBSDVirtual

# Generated at 2022-06-20 20:18:37.980981
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO: Add unit test for method get_virtual_facts of class FreeBSDVirtual
    assert True is False

# Generated at 2022-06-20 20:18:40.438969
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert(f.platform == 'FreeBSD')
    assert(f.fact_class == FreeBSDVirtual)

# Generated at 2022-06-20 20:19:45.830579
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:49.127765
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host_facts = dict(virtual_facts=dict(platform='FreeBSD'))
    virtual = FreeBSDVirtual(host_facts=host_facts)
    assert virtual.platform == "FreeBSD"

# Generated at 2022-06-20 20:19:58.670409
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class _loader(object):
        def get_basedir(self):
            return "/"

    class _module_loader(object):
        def get_package_paths(self):
            return []


# Generated at 2022-06-20 20:19:59.782721
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-20 20:20:11.470993
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlFactCollector
    from ansible.module_utils.facts.virtual.sysctl_jail import VirtualSysctlJailFactCollector
    from ansible.module_utils.facts.virtual.sysctl_xen import VirtualSysctlXenFactCollector
    from ansible.module_utils.facts.virtual.vendor import VirtualVendorFactCollector

    # Prepare test inputs and expected outputs

# Generated at 2022-06-20 20:20:15.009302
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd = FreeBSDVirtualCollector()
    assert freebsd.platform == 'FreeBSD'
    assert freebsd._fact_class == FreeBSDVirtual
    assert freebsd._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:17.315848
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None, 'freebsd')
    assert virtual_facts.platform == 'FreeBSD'
    assert not virtual_facts.any_errors_fatal()

# Generated at 2022-06-20 20:20:18.511693
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtuals = FreeBSDVirtual()
    assert isinstance(virtuals, Virtual)

# Generated at 2022-06-20 20:20:19.971792
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert not virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:20:23.186790
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, {})
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:22:39.330808
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:22:40.924972
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:22:44.699511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:22:50.796601
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:22:53.074906
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:56.312106
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:22:58.566940
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:03.063176
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_vc = FreeBSDVirtualCollector()
    assert freebsd_vc._platform == 'FreeBSD'
    assert issubclass(freebsd_vc._fact_class, Virtual)
    assert issubclass(freebsd_vc._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:23:07.946682
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    c = FreeBSDVirtual()
    # virtual_facts has to be a dictionary
    assert type(c.get_virtual_facts()) == dict
    # virtual_facts has to contain some keys
    assert 'virtualization_type' in c.get_virtual_facts().keys()
    assert 'virtualization_role' in c.get_virtual_facts().keys()
    # virtual_facts has to contain some values
    assert c.get_virtual_facts()['virtualization_type'] != ''
    assert c.get_virtual_facts()['virtualization_role'] != ''

# Generated at 2022-06-20 20:23:18.218048
# Unit test for method get_virtual_facts of class FreeBSDVirtual