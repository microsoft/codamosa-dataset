

# Generated at 2022-06-20 20:14:14.652370
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_facts = FreeBSDVirtual()
    assert freebsd_virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:16.578499
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None, None, None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:17.939307
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert issubclass(FreeBSDVirtual, Virtual)


# Generated at 2022-06-20 20:14:28.503371
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=W0212
    # Access to protected member
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    class VirtualManager:
        def __init__(self, available_sections):
            self.available_sections = available_sections

        def get_section_values(self, section):
            return self.available_sections[section]

    class TextConfig:
        def __init__(self, sysctl_output):
            self.sysctl_output = sysctl_output

        def read(self):
            return self.sysctl_output

    # Fake sysctl

# Generated at 2022-06-20 20:14:40.683468
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(FakeModule)
    assert virtual.sysctl_facts['kern.vm_guest'].key == 'kern.vm_guest'
    assert virtual.sysctl_facts['kern.vm_guest'].parser.__name__ == 'parse_kern_vm_guest'
    assert virtual.sysctl_facts['hw.hv_vendor'].key == 'hw.hv_vendor'
    assert virtual.sysctl_facts['hw.hv_vendor'].parser.__name__ == 'parse_hw_hv_vendor'
    assert virtual.sysctl_facts['security.jail.jailed'].key == 'security.jail.jailed'

# Generated at 2022-06-20 20:14:53.290086
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    def mock_detect_virt_product(sysctl):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        }

    def mock_detect_virt_vendor(hw_model):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        }

    freebsd_virtual = FreeBSDVirtual()
    setattr(freebsd_virtual, 'detect_virt_product', mock_detect_virt_product)


# Generated at 2022-06-20 20:15:02.831599
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb_virtual = FreeBSDVirtual()

    hw_hv_vendor = {
        'security.jail.jailed': '0',
        'virtualization_type': '',
        'hw.hv_vendor': '',
        'kern.vm_guest': 'none',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    # Mock
    fb_virtual.detect_virt_product = lambda x: hw_hv_vendor[x]
    fb_virtual.detect_virt_vendor = lambda x: {'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    # get_virtual_facts() should not fail for FreeBSD without any virtualization

# Generated at 2022-06-20 20:15:13.048934
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FACT_SUBSETS = {}
    FACT_SUBSETS['virtualization_type'] = ['vbox', 'kvm', 'xen', 'vmware']
    FACT_SUBSETS['virtualization_role'] = ['host', 'guest']

    # Test vbox facts
    test_vbox_facts = FreeBSDVirtual(FACT_SUBSETS)
    assert test_vbox_facts['virtualization_type'] == 'virtualbox', test_vbox_facts['virtualization_type']
    assert test_vbox_facts['virtualization_role'] == 'host', test_vbox_facts['virtualization_role']
    assert 'virtualbox' in test_vbox_facts['virtualization_tech_guest'], test_vbox_facts['virtualization_tech_guest']
    assert 'virtualbox' in test

# Generated at 2022-06-20 20:15:17.583475
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.populate()
    facts = {'virtualization_role': 'guest',
             'virtualization_type': 'xen'}
    assert set(facts.items()).issubset(
            set(virtual_facts.virtual_facts.items()))

# Generated at 2022-06-20 20:15:18.797345
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Dummy test to pass CI
    assert True

# Generated at 2022-06-20 20:15:27.687796
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert hasattr(virtual_collector, '_fact_class') and \
           virtual_collector._fact_class == FreeBSDVirtual
    assert hasattr(virtual_collector, '_platform') and \
           virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:31.666262
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None).get_all_facts()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_technology' in virtual_facts.keys()

# Generated at 2022-06-20 20:15:33.743049
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    local_facts = FreeBSDVirtualCollector()
    assert local_facts._platform == 'FreeBSD'
    assert local_facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:15:34.369106
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:41.715702
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Define expected values

    expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()
    }

    # Instantiate class
    class_inst = FreeBSDVirtual()

    # Call get_virtual_facts method
    actual = class_inst.get_virtual_facts()

    assert actual == expected

# Generated at 2022-06-20 20:15:42.872485
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_v = FreeBSDVirtual()

# Generated at 2022-06-20 20:15:53.946016
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:15:59.498478
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert isinstance(virtual_facts, dict)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:16:00.608846
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-20 20:16:03.598493
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual({})
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:11.270512
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:16:13.846450
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None)._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector(None, None)._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:25.118587
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access

    # Test 1: OpenBSD jail
    openbsd_jail = {'security.jail.jailed': (1,)}
    collection = FreeBSDVirtualCollector(openbsd_jail, None).collection
    assert collection['virtualization_type'] == 'jail'
    assert collection['virtualization_role'] == 'guest'

    # Test 2: FreeBSD jail
    freebsd_jail = {'security.jail.jailed': (0,)}
    collection = FreeBSDVirtualCollector(freebsd_jail, None).collection
    assert collection['virtualization_type'] == ''
    assert collection['virtualization_role'] == ''

    # Test 3: vmware virtual machine
    vmware_machine = {'hw.hv_vendor': 'VMware'}


# Generated at 2022-06-20 20:16:28.268247
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class is not None
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:32.156216
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect(None, None)

    assert virtual_facts['virtualization_type']
    assert virtual_facts['virtualization_role']
    assert virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:16:33.129975
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()

# Generated at 2022-06-20 20:16:39.379746
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    fbsd_virtual = FreeBSDVirtual()
    fbsd_virtual_facts = fbsd_virtual.get_virtual_facts()
    assert fbsd_virtual_facts['virtualization_type'] == ''
    assert fbsd_virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:16:42.181185
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'


if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-20 20:16:52.813660
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'FreeBSDVirtual_testdata.py')
    data = {}
    exec(open(test_file).read(), data)
    get_virtual_facts = FreeBSDVirtual()
    for (test_name, test_data) in data['test_data'].items():
        for (sysctlname, sysctldata) in test_data.items():
            get_virtual_facts._sysctl_data[sysctlname] = sysctldata
        facts = get_virtual_facts.get_virtual_facts()
        assert len(test_data) == len(facts)
        for fact_name, fact_val in facts.items():
            assert test_data[fact_name]

# Generated at 2022-06-20 20:16:56.483608
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsdv = FreeBSDVirtual({})
    expected_virtual_facts = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    actual_virtual_facts = bsdv.get_virtual_facts()
    assert actual_virtual_facts == expected_virtual_facts

# Generated at 2022-06-20 20:17:07.845303
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual(None)
    assert obj.platform == 'FreeBSD'
    assert obj.virtualization_type == ''
    assert obj.virtualization_role == ''

# Generated at 2022-06-20 20:17:08.571407
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert isinstance(facts, dict)


# Generated at 2022-06-20 20:17:12.749461
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual instance for testing.
    module = 'ansible.module_utils.facts.virtual.freebsd'
    FreeBSDVirtual = VirtualCollector._plugin_classes[module]
    virtual_facts = FreeBSDVirtual()
    del virtual_facts.data['virtualization_type']
    del virtual_facts.data['virtualization_role']

# Generated at 2022-06-20 20:17:23.188766
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fixture_file = 'freebsd_virtual_facts.json'
    fixture_data = load_fixture(fixture_file)
    freebsdvirtual_obj = FreeBSDVirtual()
    freebsdvirtual_obj.collect_sysctl_facts = mock_collect_sysctl_facts
    freebsdvirtual_obj.collect_dmesg_facts = mock_collect_dmesg_facts
    virtual_facts = freebsdvirtual_obj.get_virtual_facts()
    assert virtual_facts == fixture_data



# Generated at 2022-06-20 20:17:26.255342
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual({})
    facts = vf.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:17:30.216405
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual



# Generated at 2022-06-20 20:17:35.622239
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbvirt = FreeBSDVirtual({'module_setup': True})
    assert fbvirt.platform == 'FreeBSD'
    assert fbvirt.virttype in ('kvm', '')
    assert fbvirt.virtualization_type in ('kvm', '')
    assert fbvirt.virtualization_role in ['guest', 'host', '']

# Generated at 2022-06-20 20:17:38.191881
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Test that an instance of FreeBSDVirtual can be created.
    '''
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'


# Generated at 2022-06-20 20:17:40.650151
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    a = FreeBSDVirtual()
    assert a.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:50.344278
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:18:03.937818
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:05.715276
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'



# Generated at 2022-06-20 20:18:07.159389
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:14.301087
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = dict()
    # Virtualization Type
    facts['virtualization_type'] = 'xen'
    # Virtualization Role
    facts['virtualization_role'] = 'guest'
    # Virtualization Tech
    facts['virtualization_tech_guest'] = {'xen'}
    facts['virtualization_tech_host'] = set()

    returned_facts = virtual.get_virtual_facts()
    assert facts == returned_facts

# Generated at 2022-06-20 20:18:20.712320
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual.'''
    facts = FreeBSDVirtual({}, {}).get_virtual_facts()
    assert facts == {'virtualization_type': '', 'virtualization_role': '',
                     'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-20 20:18:23.580909
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:25.485358
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual(None)
    assert v.platform == 'FreeBSD'
    assert v.features == ('virtualization_type', 'virtualization_role')

# Generated at 2022-06-20 20:18:28.075547
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual
    assert c._platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:36.554154
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup
    test_instance = FreeBSDVirtual(None, None)
    test_instance.detect_virt_product = lambda x: {
        'virtualization_tech_guest': set(['foo']),
        'virtualization_tech_host': set(['foo']),
    }
    test_instance.detect_virt_vendor = lambda x: {
        'virtualization_tech_guest': set(['bar']),
        'virtualization_tech_host': set(['bar']),
    }

    # Test
    fact_dict = test_instance.get_virtual_facts()

    # Assert
    assert fact_dict['virtualization_type'] == ''
    assert fact_dict['virtualization_role'] == ''
    assert 'foo' in fact_dict['virtualization_tech_guest']

# Generated at 2022-06-20 20:18:47.380425
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock methods
    class MockFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, sysctl_name):
            if sysctl_name == 'kern.vm_guest':
                return {'virtualization_type': '',
                        'virtualization_role': '',
                        'virtualization_tech_guest': set(),
                        'virtualization_tech_host': set()}
            if sysctl_name == 'hw.hv_vendor':
                return {'virtualization_type': '',
                        'virtualization_role': '',
                        'virtualization_tech_guest': set(),
                        'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:19:07.219502
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Meta class for unit test of class FreeBSDVirtual

# Generated at 2022-06-20 20:19:15.683895
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up required input for testing
    # Create a class instance
    bsd = FreeBSDVirtual()
    # Define required variable 'platform'
    bsd.platform = 'FreeBSD'

    # Create a class instance of VirtualSysctlDetectionMixin
    vcdm = VirtualSysctlDetectionMixin()

    # Mock methods that are required in get_virtual_facts method of class
    # FreeBSDVirtual
    methods = {'detect_virt_product': vcdm.detect_virt_product,
               'detect_virt_vendor': vcdm.detect_virt_vendor}

    # Apply the mocked methods and run the test
    with mock.patch.multiple(FreeBSDVirtual, **methods):
        result = bsd.get_virtual_facts()
        # Check if the result obtained is as expected

# Generated at 2022-06-20 20:19:19.286609
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_host = FreeBSDVirtual({})
    virtual_host.get_virtual_facts()
    assert virtual_host.facts['virtualization_type'] == ''
    assert virtual_host.facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:19:22.946020
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # FreeBSDVirtualCollector
    x = FreeBSDVirtualCollector()
    assert x._fact_class == FreeBSDVirtual
    assert x._platform == 'FreeBSD'
    assert x.platforms == ('FreeBSD', )

# Generated at 2022-06-20 20:19:24.882111
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-20 20:19:26.068808
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtual)

# Generated at 2022-06-20 20:19:28.325369
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-20 20:19:29.636138
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()



# Generated at 2022-06-20 20:19:31.791118
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector('fake_runner')
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:19:35.556396
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fvirt = FreeBSDVirtual(None)
    assert isinstance(fvirt, FreeBSDVirtual)
    assert isinstance(fvirt, Virtual)
    assert isinstance(fvirt, VirtualSysctlDetectionMixin)
    assert fvirt.platform == 'FreeBSD'
    assert fvirt._platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:53.430176
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({'module': None, 'params': {}})
    assert freebsd_virtual.get_virtual_facts()['virtualization_type'] == ''


# Generated at 2022-06-20 20:19:55.573907
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:56.728967
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:57.878852
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector.collect()
    assert fv

# Generated at 2022-06-20 20:19:58.709139
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    return FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:20:04.431767
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.collector import TestCollector
    from ansible.module_utils.facts.cache import FactCache

    # set up test
    facts = FreeBSDVirtual()
    test_collector = TestCollector(facts)
    test_collector.populate()
    facts.collect_fact(test_collector)
    facts.populate()
    fact_cache = FactCache()

    # test no virtualization
    facts.get_virtual_facts()
    virtual_facts = fact_cache.get_facts()['virtualization']
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:20:15.272609
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is an example of the sysctl output of a FreeBSD VPS
    sysctl_output_vps = b'''
kern.vm_guest: none
security.jail.jailed: 0
hw.hv_vendor: bhyve
hw.model: AMD Ryzen 7 1700 Eight-Core Processor
'''

    # This is an example of the sysctl output of a FreeBSD Jail
    sysctl_output_jail = b'''
kern.vm_guest: none
security.jail.jailed: 1
hw.hv_vendor: bhyve
hw.model: AMD Ryzen 7 1700 Eight-Core Processor
'''

    # This is an example of the sysctl output of a FreeBSD VM

# Generated at 2022-06-20 20:20:16.835041
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual({})
    assert fb.platform == 'FreeBSD'


# Generated at 2022-06-20 20:20:24.291399
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=too-many-locals
    # First create a FreeBSDVirtual object
    test_freebsd_virtual_obj = FreeBSDVirtual()

    # Now create a test fixture object to call get_virtual_facts
    # with a mock of that object
    test_fixture = {
        '_module': '',
        '_module_args': '',
        '_ansible_module_name': '',
        '_ansible_version': '',
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies': set([]),
    }

    # And call the get_virtual_facts method with the test fixture object
    # as the mock self object

# Generated at 2022-06-20 20:20:33.223664
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create 'get_sysctl_value' mock method
    FreeBSDModule = VirtualCollector._import_platform_module('FreeBSD')
    mock_obj = FreeBSDModule.FreeBSDVirtual(dict())
    mock_obj.get_sysctl_value = lambda x: '' if x == 'hw.hv_vendor' else 'xen'
    expected_result = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen'
    }
    result = mock_obj.get_virtual_facts()
    assert result == expected_result
    # Call get_virtual_facts method again to check caching mechanism
    result = mock_obj.get_virtual_facts()
    assert result == expected_result

# Generated at 2022-06-20 20:21:14.444548
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = __import__("ansible.module_utils.facts.virtual.freebsd")
    _module = getattr(module, "module_utils")
    virtual_module = getattr(_module, "facts")
    virtual_module = getattr(virtual_module, "virtual")
    freebsd_module = getattr(virtual_module, "freebsd")
    freebsd_virtual = freebsd_module.FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:24.981097
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v._module_name = 'test'
    v._module = MagicMock()
    v._module.run_command = MagicMock(return_value=[0, 'foo', ''])
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

    # Force the return values

# Generated at 2022-06-20 20:21:26.095985
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(None, None, None).platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:28.955069
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    if not isinstance(virtual_collector, VirtualCollector):
        raise AssertionError('test_FreeBSDVirtualCollector: Failed - expected the instance of class VirtualCollector')


# Generated at 2022-06-20 20:21:29.489529
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    return {}

# Generated at 2022-06-20 20:21:33.435247
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtualCollector.collect()
    assert virtual_facts.pop('virtualization_type') == 'xen'
    assert virtual_facts.pop('virtualization_role') == 'guest'
    assert virtual_facts.pop('virtualization_tech_host') == set()
    assert virtual_facts.pop('virtualization_tech_guest') == {'xen'}
    assert virtual_facts == {}

# Generated at 2022-06-20 20:21:38.265370
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual Class
    obj = FreeBSDVirtual()
    # Store the result of function get_virtual_facts in result
    result = obj.get_virtual_facts()
    assert result['virtualization_type'] in ['', 'xen']
    assert result['virtualization_role'] in ['', 'guest']

# Generated at 2022-06-20 20:21:39.478232
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd = FreeBSDVirtual()
    assert bsd.platform == "FreeBSD"

# Generated at 2022-06-20 20:21:40.005260
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:21:41.821903
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({}, {}, {})
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:22:51.865874
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual().platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:55.221662
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector
    assert isinstance(virtual_collector._fact_class, type)
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:23:04.213590
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual = FreeBSDVirtual()

    # Create a dict with the sysctl values we are expecting
    # NOTE: This is the output of running the module manually on FreeBSD 11.3
    #       We need to keep it in sync with changes in FreeBSD versions.
    expected_data = {
        'virtualization_type': 'none',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {
            'jail',
        },
        'virtualization_tech_host': set(),
    }

    # Check that we get the same output as with manual tests
    assert bsd_virtual.get_virtual_facts() == expected_data

# Generated at 2022-06-20 20:23:10.056257
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class FreeBSDVirtual """

    # Test case with input data having empty kern_vm_guest data
    kern_vm_guest = {}
    kern_vm_guest['kern.vm_guest'] = ''
    kern_vm_guest['virtualization_type'] = ''
    kern_vm_guest['virtualization_role'] = ''
    kern_vm_guest['virtualization_tech_host'] = set()
    kern_vm_guest['virtualization_tech_guest'] = set()

    # Test case with input data having kern_vm_guest data for vm
    kern_vm_guest['other'] = {}
    kern_vm_guest['other']['kern.vm_guest'] = 'other'

# Generated at 2022-06-20 20:23:12.988280
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({},{},{},{})
    assert (isinstance(v, FreeBSDVirtual))



# Generated at 2022-06-20 20:23:21.140354
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    freebsd_virtual_collector.sysctl_exists = True
    freebsd_virtual_collector.sysctl = {
        'kern.vm_guest': 'vmware',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': '0',
    }
    freebsd_virtual_collector.hw_model = 'FreeBSD/amd64 (host) (hostp4) (host) (host)'
    virtual_facts = freebsd_virtual_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-20 20:23:30.923017
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MyFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            pass

        def detect_virt_product(self, product):
            return {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
            }

    class MyFreeBSDVirtualCollector(FreeBSDVirtualCollector):
        _fact_class = MyFreeBSDVirtual
        _platform = 'FreeBSD'

    my_virtual = MyFreeBSDVirtual()
    virtual_facts = my_virtual.get_virtual_facts()

    assert virtual_facts is not None
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:23:32.857049
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual({}, [])
    assert fb



# Generated at 2022-06-20 20:23:36.283758
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})

    assert virtual.platform == 'FreeBSD'
    assert virtual.virtual_facts['virtualization_type'] == ''
    assert virtual.virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:23:38.009732
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
