

# Generated at 2022-06-20 20:14:14.974596
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:26.515798
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Arrange
    # Create a class for testing
    class TestFreeBSDVirtual(FreeBSDVirtual):
        platform = 'FreeBSD'

        def get_sysctl_value(self, sysctl_name):
            pass

    # Prepare data for test cases

# Generated at 2022-06-20 20:14:30.605798
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    assert 'virtualization_type' in v.get_virtual_facts()
    assert 'virtualization_role' in v.get_virtual_facts()
    assert 'virtualization_type' in v.get_all_facts()
    assert 'virtualization_role' in v.get_all_facts()
    assert 'virtualization_tech_guest' in v.get_all_facts()
    assert 'virtualization_tech_host' in v.get_all_facts()

# Generated at 2022-06-20 20:14:32.724407
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:35.537223
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual('dummy', {}, {}, [])
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:37.512239
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:39.622488
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt_instance = FreeBSDVirtualCollector()
    assert isinstance(virt_instance._fact_class, FreeBSDVirtual)
    assert virt_instance._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:42.510984
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
     v_m_f = FreeBSDVirtual({})
     facts = v_m_f.get_virtual_facts()
     assert facts['virtualization_type']
     assert facts['virtualization_role']
     assert isinstance(facts['virtualization_tech_guest'], set)
     assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:14:48.199812
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_tech_host' in virt_facts

# Generated at 2022-06-20 20:14:50.949550
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Unit test for constructor of class FreeBSDVirtual"""
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technologies': {
            'virtualization_guest': set(),
            'virtualization_host': set()
        }
    }

# Generated at 2022-06-20 20:14:56.749683
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual != None

# Generated at 2022-06-20 20:15:07.344642
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test empty constructor
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD', 'Expected FreeBSD'
    assert collector._fact_class == FreeBSDVirtual, 'Expected FreeBSDVirtual'
    assert collector._name == 'virtual', 'Expected virtual'

    # Test constructor with parameters
    collector = FreeBSDVirtualCollector(platform='FreeBSD',
                                        fact_class=FreeBSDVirtual,
                                        name='freebsd_virtual')
    assert collector._platform == 'FreeBSD', 'Expected FreeBSD'
    assert collector._fact_class == FreeBSDVirtual, 'Expected FreeBSDVirtual'
    assert collector._name == 'freebsd_virtual', 'Expected freebsd_virtual'

# Generated at 2022-06-20 20:15:11.055357
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:15:13.781661
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    output = str(virt)
    assert type(output) is str
    assert output == '<freebsd>'


# Generated at 2022-06-20 20:15:15.763757
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  virtual_collector = FreeBSDVirtualCollector()
  assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:23.222134
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockSubprocess():
        class CalledProcessError(Exception):
            pass
        def __init__(self, *args):
            self.args = args
            self.logs = []
        def check_output(self, *args, **kwargs):
            self.logs.append(args)
            if args[0] == ['sysctl', 'kern.vm_guest']:
                return b'kern.vm_guest: 0'
            if args[0] == ['sysctl', 'hw.hv_vendor']:
                return b'hw.hv_vendor: unknown'
            if args[0] == ['sysctl', 'security.jail.jailed']:
                return b'security.jail.jailed: 0'

# Generated at 2022-06-20 20:15:26.743528
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert(f.platform == 'FreeBSD')
    assert(f.virtualization_type == '')
    assert(f.virtualization_role == '')
    assert(f.virtualization_tech_guest == set())
    assert(f.virtualization_tech_host == set())


# Generated at 2022-06-20 20:15:27.896686
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:29.430964
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:32.820384
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import doctest
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    results = FreeBSDVirtual().get_virtual_facts()
    failed, tests = doctest.testmod(FreeBSDVirtual, globs={'result': results})
    assert tests == 0

# Generated at 2022-06-20 20:15:43.531931
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    # virtual_facts without virtualization_type
    virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': ''
    }

    # kern_vm_guest
    kern_vm_guest = {
        'sysctl': 'hw.hv_vendor',
        'product_name': 'bhyve',
        'virtualization_type': 'bhyve',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['bhyve']),
        'virtualization_tech_host': set()
    }

    # hw_hv_vendor

# Generated at 2022-06-20 20:15:45.834007
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj != None
    assert obj._platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:46.798824
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert isinstance(FreeBSDVirtual(), object)


# Generated at 2022-06-20 20:15:55.029805
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # If facter is installed and we're not in a virtualized environment,
    # virtual_facts will have an empty dict as a value.
    return_fact_dict = {'virtualization_type': '', 'virtualization_role': '',
                        'virtualization_tech_guest': set(),
                        'virtualization_tech_host': set()}
    assert FreeBSDVirtual().get_virtual_facts() == return_fact_dict



# Generated at 2022-06-20 20:16:04.411127
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    # Test when sysctl kern.vm_guest, hw.hv_vendor and security.jail.jailed
    # are all non-zero.
    virtual.sysctl = {'kern.vm_guest': 'other', 'hw.hv_vendor': 'KVM', 'security.jail.jailed': '1'}
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'KVM'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['kvm', 'jail'])

    # Test when sysctl kern.vm_guest is 0, hw.hv_vendor

# Generated at 2022-06-20 20:16:08.110723
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd = FreeBSDVirtualCollector()
    assert freebsd._platform == 'FreeBSD'
    assert freebsd._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:09.590707
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:10.994127
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:16.083690
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import unittest
    import doctest
    suite = doctest.DocTestSuite(FreeBSDVirtualCollector)
    return unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:16:21.681656
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of FreeBSDDualCollector class.
    """
    freebsd_collector = FreeBSDVirtualCollector()
    klass = FreeBSDVirtual
    assert freebsd_collector.fact_class == klass
    assert freebsd_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:35.660045
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Expected result of this test
    expected_virtual_facts = {
        "virtualization_role": "guest",
        "virtualization_type": "xen",
        "virtualization_tech_host": set(),
        "virtualization_tech_guest": set(['xen'])
    }

    # Create FreeBSDVirtual object and call method get_virtual_facts
    test_FreeBSDVirtual = FreeBSDVirtual({}, None)
    test_result = test_FreeBSDVirtual.get_virtual_facts()

    # Assert if result matches expected result
    assert test_result == expected_virtual_facts

# Generated at 2022-06-20 20:16:38.690868
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == "FreeBSD"


# Generated at 2022-06-20 20:16:40.705990
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == "FreeBSD"


# Generated at 2022-06-20 20:16:50.464751
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    """ Test FreeBSDVirtual"""

    # Test instance creation and default values
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''
    assert freebsd_virtual.virtualization_guest_inspect_command == ''
    assert freebsd_virtual.virtualization_host_inspect_command == ''
    assert freebsd_virtual.virtualization_guest_uuid == ''
    assert freebsd_virtual.virtualization_host_uuid == ''
    assert freebsd_virtual.virtualization_host_type == 'host'
    assert freebsd_virtual.virtualization_host_name == ''
    assert freebsd_virtual.virtualization_guest

# Generated at 2022-06-20 20:16:51.575424
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:52.097663
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:16:53.172667
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    my_class = FreeBSDVirtual()
    assert my_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:57.207345
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_c = FreeBSDVirtualCollector()
    assert fv_c
    assert fv_c._platform == 'FreeBSD'
    assert isinstance(fv_c._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:16:59.130107
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check that if FreeBSD then FreeBSDVirtualCollector is returned
    freebsd = FreeBSDVirtualCollector()
    assert isinstance(freebsd._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-20 20:17:01.821240
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert isinstance(obj._fact_class, type)
    assert issubclass(obj._fact_class, Virtual)
    assert obj._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:15.005727
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:26.392453
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl_hw_model = 'Quad-Core AMD Opteron(tm) Processor 4171 HE'
    sysctl_hw_machine = 'amd64'
    sysctl_vm_guest = ''
    sysctl_jail_jailed = 0
    sysctl_hv_vendor = ''

    test_vendor_fact = {'hw.machine': sysctl_hw_machine,
                        'hw.model': sysctl_hw_model,
                        'kern.vm_guest': sysctl_vm_guest,
                        'security.jail.jailed': sysctl_jail_jailed,
                        'hw.hv_vendor': sysctl_hv_vendor
                        }


# Generated at 2022-06-20 20:17:38.525858
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    current_dir = os.path.dirname(__file__)
    test_cases_dir = os.path.join(current_dir, '../../unit/ansible_collections/ansible/community/plugins/module_utils/facts/virtual/test_cases')

    test_cases = {
        'FreeBSD11_libvirt.json': ['libvirt-kvm', ''],
        'FreeBSD11_openbsd_jail.json': ['openbsd-jail', 'guest'],
        'FreeBSD11_qemu.json': ['qemu', ''],
        'FreeBSD11_virtualbox.json': ['virtualbox', ''],
        'FreeBSD11_xen.json': ['xen', 'guest'],
    }


# Generated at 2022-06-20 20:17:41.226405
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bvcol = FreeBSDVirtualCollector()
    assert isinstance(bvcol._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:17:50.530708
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # 1. Set required data
    # 1.1. Set virtualization_type
    test_data = {
        'virtualization_type': ''
    }

    # 1.2. Set virtualization_role
    test_data['virtualization_role'] = ''

    # 1.3. Set virtualization_tech_guest
    test_data['virtualization_tech_guest'] = set()

    # 1.4. Set virtualization_tech_host
    test_data['virtualization_tech_host'] = set()

    # 1.5. Set kern.vm_guest
    # 1.5.1. Set virtualization_tech_guest
    test_data['kern.vm_guest'] = {
        'virtualization_tech_guest': set()
    }

    # 1.5.2. Set

# Generated at 2022-06-20 20:17:52.409668
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual({})
    assert fb.platform == 'FreeBSD'



# Generated at 2022-06-20 20:17:55.852955
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.__class__.__name__ == 'FreeBSDVirtual'
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:02.599531
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    import mock
    import json
    import sys

    # Mocks for method detect_virt_product
    kern_vm_guest_mock = mock.MagicMock()
    kern_vm_guest_mock.return_value = {'virtualization_tech_guest': set(['xen']),
                                       'virtualization_tech_host': set(['xen']),
                                       'virtualization_type': 'xen',
                                       'virtualization_role': 'host'}

    hw_hv_vendor_mock = mock.MagicMock()

# Generated at 2022-06-20 20:18:05.764804
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:08.107211
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:30.833067
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:18:37.285649
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    virtual_facts = freebsd_virtual_collector.collect()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-20 20:18:39.772151
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, VirtualCollector)
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:42.186632
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:42.888924
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:18:50.710494
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:19:01.537235
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up text fixtures
    if not os.path.exists('/dev/xen/xenstore'):
        os.mkdir('/dev/xen/xenstore')

    # Negative tests
    # Test case: sysctl returns empty, hw.model returns empty
    sysctl_output = {
        'hw.hv_vendor': '',
        'kern.vm_guest': '',
        'security.jail.jailed': '0'
    }
    vm_output = ''
    virtual_facts = FreeBSDVirtual(sysctl_output, vm_output).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual

# Generated at 2022-06-20 20:19:07.772202
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    output = {
        'virtualization_type': 'xenpv',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {
            'xen'
        },
        'virtualization_tech_host': set()
    }
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual.get_virtual_facts() == output

# Generated at 2022-06-20 20:19:14.045328
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(['xen'])
    }

    freebsd_virtual = FreeBSDVirtual({'ansible_facts': {'ansible_system': 'FreeBSD'}})
    assert freebsd_virtual._facts == freebsd_virtual_facts



# Generated at 2022-06-20 20:19:26.154219
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import json
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector

    mocks_path = 'ansible/module_utils/facts/virtual/freebsd/mock_sysctl_outputs'
    path_list = [os.path.join(os.path.dirname(__file__), mocks_path)]
    module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    my_freebsd_virtual_collector = FreeBSDVirtualCollector(module=module)

    virtual_facts = my_freebsd_virtual_collector.collect()
    assert virtual_facts
    assert 'virtualization_role' in virtual_facts
   

# Generated at 2022-06-20 20:20:36.930493
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # prepare return values for different calls to 'sysctl -n <variable>'
    kern_vm_guest_jail = {'return_code': 0,
                          'stdout_lines': ['0']
                         }
    kern_vm_guest_bhyve = {'return_code': 0,
                           'stdout_lines': ['4']
                          }
    kern_vm_guest_xen = {'return_code': 0,
                         'stdout_lines': ['3']
                        }
    hw_hv_vendor_xen = {'return_code': 0,
                        'stdout_lines': ['Xen']
                       }

# Generated at 2022-06-20 20:20:45.664223
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Call the method to be tested
    bsd = FreeBSDVirtual()

    # Mock a FreeBSD guest
    kern_vm_guest = {
        'name': 'kern.vm_guest',
        'sysctl_value': 'xen',
        'virtualization_tech_guest': set(['Xen']),
        'virtualization_tech_host': set(['Xen'])
    }
    hw_hv_vendor = {
        'name': 'hw.hv_vendor',
        'sysctl_value': 'bhyve',
        'virtualization_tech_guest': set(['bhyve']),
        'virtualization_tech_host': set(['bhyve'])
    }

# Generated at 2022-06-20 20:20:48.111222
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()
    facts = f.get_virtual_facts()
    assert not facts
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:20:49.564960
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:53.196079
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    The FreeBSDVirtual constructor should set the platform attribute
    """
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'



# Generated at 2022-06-20 20:20:55.088377
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:56.291344
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj is not None

# Generated at 2022-06-20 20:20:57.294206
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:58.905059
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(None)
    assert facts.platform == 'FreeBSD'


# Generated at 2022-06-20 20:21:03.184249
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_product_host' in facts
    assert 'virtualization_product_guest' in facts

# Generated at 2022-06-20 20:23:30.824131
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    freebsd_virtual = FreeBSDVirtual()

    freebsd_virtual.detect_virt_product = MagicMock(return_value={'virtualization_tech_guest':{'test1'}, 'virtualization_tech_host': {'test2'}})
    freebsd_virtual.detect_virt_vendor = MagicMock(return_value={'virtualization_tech_guest':{'test3'}, 'virtualization_tech_host': {'test4'}})
    res = freebsd_virtual.get_virtual_facts()

    assert res['virtualization_type'] == ''
    assert res['virtualization_role'] == ''

# Generated at 2022-06-20 20:23:33.309104
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'

# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-20 20:23:35.800407
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class == FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:37.823227
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()

    assert virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:39.863257
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fake_platform_token = 'FreeBSD'
    module = VirtualCollector.collector_class(fake_platform_token)
    assert type(module) == FreeBSDVirtualCollector

# Generated at 2022-06-20 20:23:42.489784
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector.platform, str)
    assert isinstance(collector._facts, dict)
    assert collector._facts == {}

# Generated at 2022-06-20 20:23:48.494178
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual class and call get_virtual_facts.
    # The following values are expected for virtual_facts.
    #   virtualization_type = 'vmware', 'kvm' or 'xen' or 'hyperv'
    #   virtualization_role = 'guest'
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()


# Generated at 2022-06-20 20:23:49.471637
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({}, {})
    assert v.platform == 'FreeBSD'
    assert v.guest_tech is None
    assert v.host_tech is None

# Generated at 2022-06-20 20:23:50.740591
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:23:56.077005
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual
    assert f._platform == 'FreeBSD'
