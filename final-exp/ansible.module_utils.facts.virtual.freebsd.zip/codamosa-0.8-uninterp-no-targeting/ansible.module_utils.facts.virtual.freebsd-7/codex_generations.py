

# Generated at 2022-06-20 20:14:15.901222
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = {'ANSIBLE_SYSTEM_VERSION': '10-RELEASE'}
    freebsd = FreeBSDVirtualCollector(facts, {})
    assert freebsd is not None

# Generated at 2022-06-20 20:14:17.841489
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    klass = FreeBSDVirtualCollector()
    assert isinstance(klass._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:14:22.118976
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:23.701990
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-20 20:14:25.760016
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v_obj = FreeBSDVirtual()
    assert v_obj.platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:28.041613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:35.872260
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf_facts = FreeBSDVirtual({}).get_virtual_facts()

    # Checks that values are in vf_facts
    assert 'virtualization_type' in vf_facts
    assert 'virtualization_role' in vf_facts
    assert 'virtualization_tech' in vf_facts
    assert 'virtualization_tech_guest' in vf_facts
    assert 'virtualization_tech_host' in vf_facts

# Generated at 2022-06-20 20:14:47.797417
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    import pytest


# Generated at 2022-06-20 20:14:50.908773
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:14:52.459838
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc is not None

# Generated at 2022-06-20 20:14:57.910131
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:09.213436
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:15:10.752071
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fd = FreeBSDVirtual({})
    assert fd is not None

# Generated at 2022-06-20 20:15:13.138050
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual.platform == 'FreeBSD'



# Generated at 2022-06-20 20:15:18.366773
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize the class
    virtual_facts = FreeBSDVirtual({})
    assert type(virtual_facts) is FreeBSDVirtual
    # Call the method
    result = virtual_facts.get_virtual_facts()
    assert virtual_facts.platform == 'FreeBSD'
    assert type(result) is dict
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-20 20:15:26.693600
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils import basic

    test_platform = 'FreeBSD'
    test_platform_version = '5.5-RELEASE'

    test_system_facts = {
        'virtualization_type': '',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
    }
    kwargs = {
        'ansible_facts': {
            'system': {
                'platform': test_platform,
                'platform_version': test_platform_version,
            }
        }
    }
    my_freebsd_virtual = FreeBSDVirtual(basic.AnsibleModule(**kwargs))
    virtual_facts = my_freebsd_virtual.get_virtual_facts()
   

# Generated at 2022-06-20 20:15:28.208565
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == FreeBSDVirtual.platform

# Generated at 2022-06-20 20:15:30.094968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of class FreeBSDVirtualCollector.
    """
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:35.499401
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Loading mocked data
    from .unit.facts.virtual.freebsd_fixture_virtual import FreeBSDFactsVirtual
    freebsd_virtual_facts = FreeBSDFactsVirtual()
    facts_dict = freebsd_virtual_facts.build_facts()
    freebsd_virtual = FreeBSDVirtual(facts_dict)

    # Calling methods
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Asserting we have the expected virtualization_type
    assert freebsd_virtual_facts['virtualization_type'] == freebsd_virtual_facts['virtualization_type']

# Generated at 2022-06-20 20:15:37.810526
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDFacts = FreeBSDVirtual(None)
    assert FreeBSDFacts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:44.262591
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == "FreeBSD"
    assert x._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:15:50.061979
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    import sys
    import inspect
    import __builtin__

    class MockSysctl(object):
        def __init__(self):
            self.data = {
                'kern.vm_guest': 'vmware',
                'hw.hv_vendor': 'bhyve',
                'security.jail.jailed': '1',
                'hw.model': 'MacBookPro1,1',
            }

        def sysctl(self, key):
            return self.data[key]

    class MockOS(object):
        def path(self):
            class Path(object):
                def exists(self, path):
                    return True
            return Path()

        def __init__(self):
            self.path = self.path()


# Generated at 2022-06-20 20:15:52.260350
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:53.332693
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO implement this unit test
    pass

# Generated at 2022-06-20 20:15:57.863023
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create the object
    fv = FreeBSDVirtual()
    # get the facts
    facts = fv.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:15:58.722719
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-20 20:16:01.033402
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:04.037197
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:16:06.351522
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector.detect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:16:10.128748
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    fbsd_virtual = FreeBSDVirtual(None)
    assert fbsd_virtual.get_virtual_facts() is not False
    assert fbsd_virtual.get_virtual_facts() is not None

# Generated at 2022-06-20 20:16:16.466153
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual({}, {})
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:18.719171
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:22.212247
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_v_col = FreeBSDVirtualCollector()
    assert freebsd_v_col._platform == 'FreeBSD'
    assert freebsd_v_col._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:28.373086
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_object = FreeBSDVirtual()
    assert virtual_facts_object.get_virtual_facts() == {'virtualization_role': '',
                                                        'virtualization_type': '',
                                                        'virtualization_tech_guest': set([]),
                                                        'virtualization_tech_host': set([])}

# Generated at 2022-06-20 20:16:29.820237
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd = FreeBSDVirtual({})
    fbsd.get_virtual_facts()

# Generated at 2022-06-20 20:16:32.459504
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v1 = Virtual(None)
    assert v1.platform == 'Generic'

    v2 = FreeBSDVirtual(None)
    assert v2.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:36.264329
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    obj = FreeBSDVirtual()
    expected = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'qemu', 'kvm'},
        'virtualization_tech_host': {'kvm'}
    }
    obj.sysctl_dict = {'kern.vm_guest': 'kvm'}

    assert obj.get_virtual_facts() == expected

# Generated at 2022-06-20 20:16:37.527585
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector



# Generated at 2022-06-20 20:16:45.768667
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert isinstance(virt_facts, dict), 'Virtual facts must be a dict'
    assert 'virtualization_type' in virt_facts, \
        'Virtual facts must contain virtualization_type'
    assert 'virtualization_role' in virt_facts, \
        'Virtual facts must contain virtualization_role'
    assert 'virtualization_tech_guest' in virt_facts, \
        'Virtual facts must contain virtualization_tech_guest'
    assert 'virtualization_tech_host' in virt_facts, \
        'Virtual facts must contain virtualization_tech_host'

# Generated at 2022-06-20 20:16:46.521239
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()


# Generated at 2022-06-20 20:16:58.325933
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual


# Generated at 2022-06-20 20:17:00.794792
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # This test may be run on non-FreeBSD system
    try:
        FreeBSDVirtualCollector()
    except OSError:
        pass
    else:
        assert False, 'Expected OSError exception has not been raised'

# Generated at 2022-06-20 20:17:02.493290
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert len(virtual_facts._requested_facts) == 4

# Generated at 2022-06-20 20:17:03.745788
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)

# Generated at 2022-06-20 20:17:11.188616
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    print("Unit test FreeBSD Virtual")
    freebsd_facts = FreeBSDVirtual("FreeBSD")
    if freebsd_facts.platform != "FreeBSD":
        print("FAILED -> test freebsd_facts.platform")
    if freebsd_facts is None:
        print("FAILED -> test freebsd_facts")
    else:
        print("PASSED -> test freebsd_facts")



# Generated at 2022-06-20 20:17:18.395276
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert isinstance(facts['virtualization_type'], str)
    assert isinstance(facts['virtualization_role'], str)
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:17:20.806666
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert(facts['virtualization_type'] != '')

# Generated at 2022-06-20 20:17:28.551712
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts_dict = FreeBSDVirtual().get_virtual_facts()
    # Test virtualization_type fact
    assert 'virtualization_type' in facts_dict, \
        'bug in FreeBSDVirtual class, get_virtual_facts method'
    assert isinstance(facts_dict['virtualization_type'], str), \
        'bug in FreeBSDVirtual class, get_virtual_facts method, '\
        'virtualization_type fact is not a string'
    # Test virtualization_role fact
    assert 'virtualization_role' in facts_dict, \
        'bug in FreeBSDVirtual class, get_virtual_facts method'
    assert isinstance(facts_dict['virtualization_role'], str), \
        'bug in FreeBSDVirtual class, get_virtual_facts method, '\
        'virtualization_role fact is not a string'
    # Test virtual

# Generated at 2022-06-20 20:17:31.637243
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Create a FreeBSDVirtualCollector object
    obj = FreeBSDVirtualCollector()
    # Check that it is the correct type
    assert isinstance(obj, FreeBSDVirtualCollector)


# Generated at 2022-06-20 20:17:34.725441
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts_dict = dict()
    freebsd_virtual_facts = FreeBSDVirtual(facts_dict)
    assert freebsd_virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:04.339921
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-20 20:18:06.527520
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bv = FreeBSDVirtualCollector()
    assert test_FreeBSDVirtualCollector.__name__ == bv.__class__.__name__

# Generated at 2022-06-20 20:18:18.082426
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSDVirtual instance
    bsd_obj = FreeBSDVirtual({}, {})
    bsd_obj._module.get_bin_path = lambda x: x
    bsd_obj._module.run_command = lambda x: (0, '1', '')


# Generated at 2022-06-20 20:18:21.199599
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.fact_class == FreeBSDVirtual
    assert f.platform == "FreeBSD"


# Generated at 2022-06-20 20:18:24.762070
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_obj = FreeBSDVirtual()
    assert freebsd_virtual_obj.platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:27.492062
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test FreeBSDVirtual.__init__
    facts = FreeBSDVirtual()
    assert facts.facts['virtualization_type'] == ''
    assert facts.facts['virtualization_role'] == ''
    assert facts.facts['virtualization_system'] == ''

# Generated at 2022-06-20 20:18:36.099138
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v._get_facts_from_sysctl = lambda x: {
        'kern.vm_guest': 'other',
        'hw.model': 'BL465c Gen7',
        'security.jail.jailed': '0'
    }
    v._get_facts_from_dmesg = lambda: {
        'FreeBSD': {
            'dmesg': ['FreeBSD is a great OS'],
            'version_number': ['11']
        }
    }
    result = v.get_virtual_facts()

# Generated at 2022-06-20 20:18:39.146913
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual({})
    facts = testobj.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:18:41.614362
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:43.258844
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:18.397563
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector is not None


# Generated at 2022-06-20 20:19:20.779369
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector)


# Generated at 2022-06-20 20:19:23.216654
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    module = FreeBSDVirtualCollector()
    assert module._platform == 'FreeBSD'
    assert module._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:19:24.726216
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:29.304889
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''
    assert freebsd_virtual.virtualization_tech_guest == set()
    assert freebsd_virtual.virtualization_tech_host == set()

# Generated at 2022-06-20 20:19:31.419673
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector._fact_class, FreeBSDVirtual)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:32.071779
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:33.352808
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:41.283759
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()

    # Set values for sysctl detection
    virtual_facts = {'kern.vm_guest': 'none',
                     'hw.hv_vendor': '',
                     'security.jail.jailed': '0',
                     'hw.model': 'VirtualBox'}
    virt.sysctl = virtual_facts

    # hw.model results in the detection of product and vendor
    # and machine_id is set to none
    prod_vendor = {'virtualization_type': '',
                   'virtualization_role': '',
                   'virtualization_product': 'VirtualBox',
                   'virtualization_vendor': 'innotek GmbH'}
    # hw.model and sysctl results are merged

# Generated at 2022-06-20 20:19:44.232947
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vc_FreeBSD = FreeBSDVirtual()
    assert vc_FreeBSD.virtualization_type == ''
    assert vc_FreeBSD.virtualization_role == ''
    assert vc_FreeBSD.arch == ''

# Generated at 2022-06-20 20:20:55.604893
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:21:04.645572
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Validate FreeBSDVirtual class's get_virtual_facts
    function output """

    # Get sysctl paths and virtualization_type and virtualization_role
    # values from fact class.
    freebsd_virtual = FreeBSDVirtual()
    sysctl_paths = freebsd_virtual.sysctl_paths
    virtualization_type = freebsd_virtual.virtualization_type
    virtualization_role = freebsd_virtual.virtualization_role

    # Get sysctl values
    freebsd_virtual = FreeBSDVirtual()
    sysctl_data = freebsd_virtual.get_sysctl_data(sysctl_paths)

    # Get virtual_facts.
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Validate values of virtualization_type and virtualization_role.
    assert virtual_

# Generated at 2022-06-20 20:21:08.011995
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtualCollector().collect()
#     print(facts['virtualization_type'])
#     print(facts['virtualization_role'])
#     print(facts['virtualization_tech_guest'])
#     print(facts['virtualization_tech_host'])

# Generated at 2022-06-20 20:21:13.116335
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector)
    assert isinstance(freebsd_virtual_collector._fact_class, FreeBSDVirtual)
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:18.904407
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""
    test_fact_class = FreeBSDVirtual()
    test_facts = {}

    # Set empty values as default
    test_facts['virtualization_type'] = ''
    test_facts['virtualization_role'] = ''
    test_facts['virtualization_tech_guest'] = set()
    test_facts['virtualization_tech_host'] = set()

    # Virtualized in a Xen guest detected by existence of /dev/xen/xenstore
    # and set as guest
    test_fact_class.file_exists_results = {'/dev/xen/xenstore': True}
    test_facts = test_fact_class.get_virtual_facts()

    assert test_facts['virtualization_type'] == 'xen'
    assert test_facts

# Generated at 2022-06-20 20:21:24.843239
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FV = FreeBSDVirtual()
    facts = FV.get_virtual_facts()
    assert facts['virtualization_type'] is not None
    assert facts['virtualization_role'] is not None
    assert facts['virtualization_type'] != facts['virtualization_role']

# Generated at 2022-06-20 20:21:34.221168
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def read_file(path):
        with open(path) as f:
            return f.read()

    def mock_get_sysctl(cmd, data):
        virtual_facts = {
            'kern.vm_guest': 'jail',
            'hw.hv_vendor': 'Bochs',
            'security.jail.jailed': '1',
            'hw.model': 'VirtualBox',
        }
        return virtual_facts[cmd]

    def mock_open(path, **kwargs):
        if path == '/dev/xen/xenstore':
            raise IOError("Mock does not create this file")
        raise FileNotFoundError("Mock does not open this file")

    facts = FreeBSDVirtual()
    facts.get_sysctl = mock_get_sysctl
    facts.open

# Generated at 2022-06-20 20:21:35.093883
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()


# Generated at 2022-06-20 20:21:41.462013
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    class MockFreeBSDVirtual(FreeBSDVirtual):
        def _detect_virt_product(self, sysctl):
            return {'virtualization_type': 'some_type',
                    'virtualization_role': 'some_role'}
    freebsd_virtual = MockFreeBSDVirtual()
    facts = freebsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'some_type'
    assert facts['virtualization_role'] == 'some_role'


# Generated at 2022-06-20 20:21:51.796440
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_file_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_file_dir, '..', '..', 'unit', 'module_utils', 'facts', 'virtual')
    test_data_dir = os.path.abspath(test_data_dir)
    test_data_file = os.path.join(test_data_dir, 'FreeBSD_virtual_test_data.yaml')

    from ansible.utils.data import load_yaml
    test_data_map = load_yaml(test_data_file)

    for platform, virtual_data in test_data_map.items():
        test_facts = FreeBSDVirtual()