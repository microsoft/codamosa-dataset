

# Generated at 2022-06-20 20:14:12.480912
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:22.768543
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is the FreeBSDVirtual.get_virtual_facts return
    # dict without hw.model sysctl value
    expected_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['xen'])
    }

    if os.path.exists('/dev/xen/xenstore'):
        from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
        virtual = FreeBSDVirtual({})
        got_facts = virtual.get_virtual_facts()
        assert expected_facts == got_facts

# Generated at 2022-06-20 20:14:29.762238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual, FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual import VirtualCollector
    assert issubclass(FreeBSDVirtualCollector, Collector)
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert issubclass(FreeBSDVirtualCollector, VirtualSysctlDetectionMixin)
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:32.430041
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:42.804944
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = os.path.dirname(os.path.realpath(__file__)) + "/fixture/output/sysctl_kern_vm_guest"
    fbsd = FreeBSDVirtual("module", module, "fakehost")
    expected = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }
    if fbsd.get_virtual_facts() != expected:
        raise Exception("Failed: Expected " + " ".join(expected) +
                        " instead of " +
                        " ".join(fbsd.get_virtual_facts()))



# Generated at 2022-06-20 20:14:44.866636
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(dict(), dict())
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:46.968958
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:50.494932
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:54.421063
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c, VirtualCollector)
    assert isinstance(c, FreeBSDVirtualCollector)
    assert c._platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:14:56.535511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # We try to load the collector
    assert(FreeBSDVirtualCollector() is not None)

# Generated at 2022-06-20 20:15:09.006934
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual()
    facts = vf.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:15:11.394824
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v_freebsd = FreeBSDVirtual({},{})
    assert v_freebsd.platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:13.189626
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsdvirt = FreeBSDVirtual()
    assert (bsdvirt.platform == 'FreeBSD')

# Generated at 2022-06-20 20:15:20.955099
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    This is a test function for method get_virtual_facts
    """
    fbsdVirtObj = FreeBSDVirtual()
    fbsdVirtObj.sysctl = {
        'hw.model': 'Virtual Machine',
        'security.jail.jailed': '1',
        'kern.vm_guest': 'xen',
    }
    expected = {
        'virtualization_type': 'xen', 'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail', 'vmware', 'xen']),
        'virtualization_tech_host': set(['vmware'])
    }
    assert expected == fbsdVirtObj.get_virtual_facts()

    # Test case when hw.model is not recognized
    fbsdVirtObj

# Generated at 2022-06-20 20:15:27.959996
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert('virtualization_type' in virtual_facts)
    assert('virtualization_role' in virtual_facts)
    assert('virtualization_tech_host' in virtual_facts)
    assert('virtualization_tech_guest' in virtual_facts)


# Generated at 2022-06-20 20:15:32.680527
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create an instance of FreeBSDVirtual. The class __init__() should set
    # virtualization_type and virtualization_role to ''
    virtual = FreeBSDVirtual()
    # Assert that both properties are set to ''
    assert (virtual.get_virtual_facts()['virtualization_type'] == ''
            and virtual.get_virtual_facts()['virtualization_role'] == '')



# Generated at 2022-06-20 20:15:37.810315
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-20 20:15:48.693998
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    test_FreeBSDVirtual = FreeBSDVirtual({})

    # Test with no fact file
    fact_file = None
    virtual_facts = test_FreeBSDVirtual.get_virtual_facts(fact_file)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Test with non-existing fact file
    fact_file = '_non_existing_'
    virtual_facts = test_FreeBSDVirtual.get_virtual_facts(fact_file)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Test with empty fact file
    fact_file = {'_ansible_virtual_facts': {}}
    virtual_facts = test_FreeBSDVirtual.get_virtual_facts(fact_file)
   

# Generated at 2022-06-20 20:15:50.042269
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:53.044164
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()

    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts.platform == 'FreeBSD'



# Generated at 2022-06-20 20:16:03.598136
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:12.870814
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Test that the get_virtual_facts method returns the correct dict for all
    FreeBSD virtual scenarios
    """
    def mock_detect_virt_product(sysctl):
        if sysctl is 'kern.vm_guest':
            return {
                'virtualization_type': 'bhyve',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': {'bhyve'},
                'virtualization_tech_host': set()
            }
        elif sysctl is 'hw.hv_vendor':
            return {
                'virtualization_type': 'qemu',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': {'kvm'},
                'virtualization_tech_host': set()
            }

# Generated at 2022-06-20 20:16:24.439593
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, {})

    # Set some default values
    virtual.facts['virtualization_type'] = 'test_default_type'
    virtual.facts['virtualization_role'] = 'test_default_role'
    virtual.facts['virtualization_tech_guest'] = ['test_default_tech_guest']
    virtual.facts['virtualization_tech_host'] = ['test_default_tech_host']

    # Set sysctl_results to return values when virtual.detect_virt_product
    # is called

# Generated at 2022-06-20 20:16:30.028723
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:32.744632
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_FreeBSDVirtualCollector = FreeBSDVirtualCollector()
    assert test_FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert test_FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-20 20:16:38.365403
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Unit test for constructor of class FreeBSDVirtual"""

    # Construct and return true if virtual_facts is not empty
    virtual_facts = Virtual().get_virtual_facts()
    if virtual_facts:
        module = virtual_facts
        assert bool(module) is True
    else:
        module = True
        assert bool(module) is True


# Generated at 2022-06-20 20:16:44.893397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # setup the class we are testing
    class_under_test = FreeBSDVirtualCollector()

    # Assert that the class under test has the right attributes
    assert hasattr(class_under_test, '_fact_class')
    assert hasattr(class_under_test, '_platform')

    # And that the values are what we expect
    assert class_under_test._fact_class is FreeBSDVirtual
    assert class_under_test._platform is 'FreeBSD'



# Generated at 2022-06-20 20:16:51.254489
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    filename = os.path.basename(__file__)
    if filename.endswith('.pyc'):
        filename = filename[:-1]
    if filename.endswith('__init__.py'):
        filename = os.path.dirname(filename)
    filename = 'test_%s' % filename

    # locale.getpreferredencoding() is too unreliable on FreeBSD
    # (https://bugs.python.org/issue18378#msg215215)
    fact_collector = FreeBSDVirtualCollector(
        gather_subset=['!all'],
        fact_class=filename
    )

    assert fact_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:54.711940
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()

    assert facts['virtualization_type'] == ''

    assert set(facts['virtualization_tech_guest']) == set()

    assert set(facts['virtualization_tech_host']) == set()

    assert facts['virtualization_role'] == ''



# Generated at 2022-06-20 20:16:56.141943
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freeBSDVirtual = FreeBSDVirtual()
    assert freeBSDVirtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:11.892965
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.module = None
    virtual_facts = v.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:17:15.312353
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-20 20:17:26.015628
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fact_ret = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest=set(['xen', 'jail'])
    )

    testobj = FreeBSDVirtual()
    testobj.detect_virt_product = lambda a: dict(
        virtualization_tech_guest=set(['jail']),
        virtualization_tech_host=set(),
    )
    testobj.detect_virt_vendor = lambda a: dict(
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['docker']),
    )
    ret = testobj.get_virtual_facts()
    assert ret == fact_ret


# Generated at 2022-06-20 20:17:29.069841
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc is not None

# Generated at 2022-06-20 20:17:38.740851
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.detect_virt_product = detect_virt_product_side_effect
    freebsd_virtual.detect_virt_vendor = detect_virt_vendor_side_effect
    virtual_facts = freebsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'xen'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'kvm' in virtual_facts['virtualization_tech_host']
    assert 'vmware' in virtual_facts['virtualization_tech_host']


# Generated at 2022-06-20 20:17:41.232207
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test constructor"""
    facts = {}
    assert FreeBSDVirtualCollector(facts)


# Generated at 2022-06-20 20:17:44.394238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    inst = FreeBSDVirtualCollector()
    # The constructor is not expected to return anything.
    assert inst.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:45.106440
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.data.get('virtualization_type') == ''

# Generated at 2022-06-20 20:17:56.803911
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('module', (object, ), {})()
    virtual_facts_object = FreeBSDVirtual(fake_module)
    fake_platform = 'FreeBSD'

    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    # Test case:
    # Virtualization type detection with the kernel.vm_guest sysctl key
    with open('/proc/version', 'r') as version_file:
        content = version_file.read()

# Generated at 2022-06-20 20:18:00.936256
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    os_info = {}
    os_info['distribution'] = 'FreeBSD'
    os_info['distribution_version'] = '10.1'
    os_info['distribution_release'] = 'RELEASE'
    os_info['distribution_major_version'] = 10
    os_info['virtualization_type'] = ''

    collector = FreeBSDVirtualCollector(os_info)
    assert isinstance(collector, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:18:29.660252
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of FreeBSDVirtualCollector should instantiate a new instance
    of FreeBSDVirtualCollector
    """
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestFreeBSDVirtualCollector(unittest.TestCase):
        def test_constructor(self):
            try:
                FreeBSDVirtualCollector()
            except:
                self.fail("Constructor of FreeBSDVirtualCollector should instantiate a new "
                          "instance of FreeBSDVirtualCollector")

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(TestFreeBSDVirtualCollector))

# Generated at 2022-06-20 20:18:32.988520
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Constructs an instance of FreeBSDVirtual class and tests the instance
    attributes defined by the class constructor.
    """
    freebsd_virtual_instance = FreeBSDVirtual()
    assert freebsd_virtual_instance.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:35.949158
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:45.179506
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    my_module = 'ansible_collections.ntc_netscout.netgenie.plugins.module_utils.network.netgenie.argos.facts.virtual.freebsd'
    if my_module not in sys.modules:
        sys.modules[my_module] = mock.MagicMock()

    # Setting the platform to FreeBSD and verifying that the
    # get_virtual_facts method from FreeBSDVirtual class will be called
    sys.modules[my_module].platform.system.return_value = 'FreeBSD'
    FreeBSDVirtualCollector().collect()
    assert sys.modules[my_module].FreeBSDVirtual.get_virtual_facts.called

# Generated at 2022-06-20 20:18:54.476230
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual({})
    f.collect_platform_data()
    f.populate_facts()
    v_facts = f.get_virtual_facts()
    assert(v_facts['virtualization_type'].lower() == 'none')
    assert(v_facts['virtualization_role'].lower() == 'guest')
    assert(v_facts['virtualization_tech_guest'].lower() == 'n/a')
    assert(v_facts['virtualization_tech_host'].lower() == 'n/a')

# Generated at 2022-06-20 20:18:57.126402
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f is not None
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:57.728145
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:18:58.533269
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual('FreeBSD')



# Generated at 2022-06-20 20:19:02.884918
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test to test the method get_virtual_facts of class
    # FreeBSDVirtual
    # This test is done for FreeBSD version 11.0-RELEASE-p8
    # Virtualization is not enabled, so virtual_facts should be empty
    virtual_facts = {
        'virtualization_type':'',
        'virtualization_role':'',
        'virtualization_tech_host':set(),
        'virtualization_tech_guest':set()
    }
    assert virtual_facts == FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-20 20:19:05.530243
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual({})
    freebsd_virtual_facts.get_virtual_facts()


# Generated at 2022-06-20 20:19:39.216575
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()

# Generated at 2022-06-20 20:19:40.071875
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:42.407235
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance._fact_class, FreeBSDVirtual)
    assert instance._platform == 'FreeBSD'



# Generated at 2022-06-20 20:19:45.133224
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    ''' ensure we get a FreeBSDVirtual instance'''
    fbx = FreeBSDVirtual()
    assert type(fbx) == FreeBSDVirtual, 'did not get a FreeBSDVirtual instance'

# Generated at 2022-06-20 20:19:47.496997
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert virt.data['virtualization_type'] == ''
    assert virt.data['virtualization_role'] == ''

# Generated at 2022-06-20 20:19:52.840829
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    actual = v.get_virtual_facts()
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }
    assert actual == expected

# Generated at 2022-06-20 20:19:59.928450
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up the class
    fbsd_virtual_facts = FreeBSDVirtual()

    # Execute the get_virtual_facts method
    virtual_facts = fbsd_virtual_facts.get_virtual_facts()

    # assert that the virtualization_type value is one of the set
    assert virtual_facts['virtualization_type'] in [
        '',
        'jail',
        'hvm',
        'openvz',
        'xen'
    ]

    # assert that the virtualization_role value is one of the set
    assert virtual_facts['virtualization_role'] in [
        '',
        'guest'
    ]



# Generated at 2022-06-20 20:20:01.307292
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:09.121373
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:20:15.388211
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    # Test 1: No VMware, no Hyper-V, no Jail, no VirtualBox
    virt = FreeBSDVirtual({})
    virt.get_virtual_facts = Virtual.get_virtual_facts
    virt.collect_sysctl_product_info = VirtualSysctlDetectionMixin.collect_sysctl_product_info
    virt.collect_sysctl_vendor_info = Virtual.collect_sysctl_vendor_info
    facts = virt.get_virtual_facts()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

    # Test 2: VMware

# Generated at 2022-06-20 20:21:27.862276
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test the FreeBSDVirtual class from the virtual.py module
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'xen' in virtual_facts.get('virtualization_type', ''), \
        "virtualization_type is not set to 'xen' when in a Xen guest"
    assert 'guest' in virtual_facts.get('virtualization_role', ''), \
        "virtualization_role is not set to 'guest' when in a Xen guest"

# Generated at 2022-06-20 20:21:30.116093
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """ Test that we can correctly retrieve FreeBSD's virtualization facts"""
    assert VirtualCollector.get_fact_class('FreeBSD') == FreeBSDVirtual

# Generated at 2022-06-20 20:21:41.433835
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test for FreeBSDVirtual.get_virtual_facts
    """
    virtual = FreeBSDVirtual()

    # Test for virtualization_type
    # Test for kern.vm_guest = 'user' (Guest)
    virtual._sysctl_msgs = {'kern.vm_guest': "user"}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Test for virtualization_type
    # Test for hw.hv_vendor = 'VMWare'(Host)
    virtual._sysctl_msgs = {'hw.hv_vendor': "VMWare"}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-20 20:21:43.095486
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:44.802238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Returns True if class constructor works correctly'''
    obj = FreeBSDVirtualCollector()
    return isinstance(obj, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:21:55.854411
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    output_unjailed = {'hw.model': 'Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz',
                       'kern.vm_guest': 'other',
                       'security.jail.jailed': '0'}
    output_jailed = {'hw.model': 'Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz',
                     'kern.vm_guest': 'other',
                     'security.jail.jailed': '1'}
    output_bhyve = {'hw.model': 'AMD Ryzen 7 1700 Eight-Core Processor',
                    'kern.vm_guest': 'other',
                    'security.jail.jailed': '0'}

# Generated at 2022-06-20 20:21:59.371168
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, {}, {})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:22:09.226359
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl_outputs = dict(
        security_jail_jailed='0',
        kern_vm_guest='none',
        hw_hv_vendor='none')

    virt_facts = dict()
    virt_facts['security.jail.jailed'] = sysctl_outputs['security_jail_jailed']
    virt_facts['kern.vm_guest'] = sysctl_outputs['kern_vm_guest']
    virt_facts['hw.hv_vendor'] = sysctl_outputs['hw_hv_vendor']

    virtual = FreeBSDVirtual(virt_facts)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    virt_facts

# Generated at 2022-06-20 20:22:12.532756
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.data['virtualization_type'] == ''
    assert virtual_facts.data['virtualization_role'] == ''

# Generated at 2022-06-20 20:22:13.655055
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'