

# Generated at 2022-06-20 20:14:25.274832
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsdvirtual = FreeBSDVirtual(None, None)
    freebsdvirtual.virtualization_tech_guest = set()
    freebsdvirtual.virtualization_tech_host = set()

    # Test with Jail
    open('/dev/xen/xenstore', 'w').close()
    open('/compat/linux/proc/cpuinfo', 'w').close()
    open('/sbin/jail', 'w').close()
    open('/usr/sbin/jls', 'w').close()
    freebsdvirtual.facts = {}

    virtual_facts = freebsdvirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:14:27.199386
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    ''' Unit test for constructor of class FreeBSDVirtual '''
    virtual = FreeBSDVirtual()

    assert virtual._platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:35.046559
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()
    }
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert(virtual_facts == expected_virtual_facts)

# Generated at 2022-06-20 20:14:45.518024
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a fake module object
    module = type('AnsModule', (object,), {
        'params': dict(gather_subset='!all,!min')
    })()

    # Create a FreeBSDVirtual instance
    freebsd = FreeBSDVirtual(module)
    facts = freebsd.get_virtual_facts()

    # Assert facts
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert facts['virtualization_tech_host'] == set()


if __name__ == "__main__":
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:14:48.971349
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:57.983980
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Tests for method get_virtual_facts of class FreeBSDVirtual"""

    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from mock import Mock
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()

    class MockedFreeBSDVirtual(FreeBSDVirtual, VirtualSysctlDetectionMixin):
        platform = 'FreeBSD'

# Generated at 2022-06-20 20:15:00.715766
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert fv.platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:04.199278
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:09.157927
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create FreeBSDVirtual instance named 'sv'
    sv = FreeBSDVirtual()

    # Check that instance 'sv' of class FreeBSDVirtual is not None
    assert sv is not None

# Generated at 2022-06-20 20:15:19.312553
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:15:31.941553
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ..runner import TestRunner

    # VBox test
    virtual_facts = TestRunner.run_module(dict(), 'freebsd_virtual', {}, None)
    assert virtual_facts['ansible_virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in virtual_facts['ansible_virtualization_tech_host']
    assert virtual_facts['ansible_virtualization_role'] == 'host'

    # NVMe test
    virtual_facts = TestRunner.run_module(dict(), 'freebsd_virtual', {'HW_MODEL': 'VirtualBox'}, None)
    assert virtual_facts['ansible_virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in virtual_facts['ansible_virtualization_tech_host']

# Generated at 2022-06-20 20:15:33.666932
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:15:39.368918
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'
    assert fv.virtualization_type == ''
    assert fv.virtualization_role == ''
    assert fv.virtualization_tech_guest == set()
    assert fv.virtualization_tech_host == set()


# Generated at 2022-06-20 20:15:42.174435
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:44.507449
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual.platform == 'FreeBSD'
    assert virtual.__doc__  == FreeBSDVirtualCollector.__doc__

# Generated at 2022-06-20 20:15:45.877612
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt = FreeBSDVirtualCollector()
    assert virt.class_name == 'FreeBSDVirtual'

# Generated at 2022-06-20 20:15:47.361281
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-20 20:15:48.459515
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-20 20:15:50.414759
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.get_virtual_facts()

# Generated at 2022-06-20 20:15:59.302168
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()
    facts = f.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    f._sysctl_facts = {
                       'kern.vm_guest': 'None',
                       'security.jail.jailed': '0',
                       'hw.hv_vendor': 'None',
                       'hw.model': 'Amd Opteron(tm) Processor 6128'}
    facts = f.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''


# Generated at 2022-06-20 20:16:06.199542
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:16:11.438636
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtualCollector()
    virtual_facts = collector._get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_tech_guest' in virtual_facts.keys()
    assert 'virtualization_tech_host' in virtual_facts.keys()

# Generated at 2022-06-20 20:16:13.174040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:21.313913
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()

    # testing empty constructor
    assert fv.platform == 'FreeBSD'
    assert fv.possible_facts == [
        'virtualization_type',
        'virtualization_role',
        'virtualization_system',
        'virtualization_product_name',
        'virtualization_uuid',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]
    assert fv.data == {}

# Generated at 2022-06-20 20:16:23.932715
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  freebsd_virtual_collector = FreeBSDVirtualCollector()
  assert freebsd_virtual_collector.platform == 'FreeBSD'
  assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:25.338357
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert isinstance(FreeBSDVirtual( {}, {}, {} ), Virtual)


# Generated at 2022-06-20 20:16:31.021353
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtualCollector()
    virtual_facts = virtual.get_virtual_facts()
    assert type(virtual_facts) is dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:16:34.590675
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtual()
    # Check we have virtual_facts, virtual_tech_guest, virtual_tech_host
    assert hasattr(fv, 'virtual_facts')
    assert hasattr(fv, 'virtual_tech_guest')
    assert hasattr(fv, 'virtual_tech_host')

# Generated at 2022-06-20 20:16:45.491177
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual.
    """
    import json

    # get 'virtual_facts' as it would be returned by AnsibleModule.
    virtual_facts = FreeBSDVirtual(module=None).get_virtual_facts()

    # Make sure it is a dict.
    assert isinstance(virtual_facts, dict)

    # This prints the facts as JSON -- use this as a template for the
    # assertions below.
    print('Returned dictionary:\n%s' % json.dumps(virtual_facts, indent=4))

    # These are the keys we expect to be in the dictionary.  Assume
    # sysctl is always present.  Assert that the key is present, and
    # its value is a non-empty string.

# Generated at 2022-06-20 20:16:52.997089
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up the test fixture
    freebsd_virtual = FreeBSDVirtual()

    # When no virtualization is found, it should return:
    # { 'virtualization_type': '', 'virtualization_role': '' }
    # This is the same result as returned by Virtual
    result = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

    # When virtualization is found
    # FreeBSDVirtual.get_virtual_facts() should call
    # detect_virt_product and detect_virt_vendor
    # FreeBSDVirtual.detect_virt_product and detect_virt_vendor should call
    # detect_virt_type, detect_virt_product,

# Generated at 2022-06-20 20:17:02.952459
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    BSDVirtual = FreeBSDVirtual()
    BSDVirtual.get_virtual_facts()
    assert BSDVirtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:04.148425
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_facts = FreeBSDVirtual()
    assert freebsd_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:11.465250
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test get_virtual_facts with FreeBSD system

    from ansible.module_utils.facts import virtual

    FreeBSD_virtual_test_object = virtual.FreeBSDVirtual()
    FreeBSD_virtual_test_object.get_virtual_facts()

    assert FreeBSD_virtual_test_object.facts['virtualization_type'] == 'xen'
    assert FreeBSD_virtual_test_object.facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:17:14.080126
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:17:25.906554
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Basic constructor
    virtual_facts = FreeBSDVirtual()
    # The structure of the output of the method "get_virtual_facts"
    # is a dictionary with two keys:
    #  'virtualization_role': str
    #  'virtualization_type': str
    #  'virtualization_tech_guest': set
    #  'virtualization_tech_host': set
    assert 'virtualization_role' in virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts.get_virtual_facts()
    assert 'virtualization_tech_host' in virtual_facts.get_virtual_facts()
    # Check that the method "get_virtual_facts" returns a dictionary

# Generated at 2022-06-20 20:17:38.238877
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsdvirtual = FreeBSDVirtual()

    virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': {},
        'virtualization_tech_guest': {'xen'}
    }
    assert virtual_facts == freebsdvirtual.get_virtual_facts()

    virtual_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'jail'}
    }
    assert virtual_facts == freebsdvirtual.get_virtual_facts()


# Generated at 2022-06-20 20:17:42.674411
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    ret = FreeBSDVirtual().get_virtual_facts()
    assert ret == virtual_facts

# Generated at 2022-06-20 20:17:46.660121
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    mock_class = {}
    mock_class['_fact_class'] = FreeBSDVirtual
    mock_class['_platform'] = 'FreeBSD'
    assert FreeBSDVirtualCollector == type('FreeBSDVirtualCollector', (object,), mock_class)

# Generated at 2022-06-20 20:17:47.870716
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(dict())
    assert virtual.platform == "FreeBSD"

# Generated at 2022-06-20 20:17:58.946915
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import BSDFakeSysctl
    # Populate sysctl_data for hw.model
    sysctl_data = {'hw.model': 'QEMU virtual CPU version (cpu64-rhel6) (OpenBSD)'}
    sysctl = BSDFakeSysctl(sysctl_data)
    virtual_facts = FreeBSDVirtual(sysctl).get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set(['xen'])

# Generated at 2022-06-20 20:18:24.762020
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    class_module = FreeBSDVirtualCollector()
    assert class_module.os_family == 'BSD'
    assert class_module._platform == 'FreeBSD'
    assert class_module._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:18:32.284825
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    """ Test get_virtual_facts of FreeBSDVirtual class.
    Must return a dict of 'virtualization_type' and 'virtualization_role'. """

    # Initialize instace
    virtual_fbsd = FreeBSDVirtual()
    # Call get_virtual_facts
    facts = virtual_fbsd.get_virtual_facts()
    # Assert if facts['virtualization_type'] is a str
    assert isinstance(facts['virtualization_type'], str)
    # Assert if facts['virtualization_role'] is a str
    assert isinstance(facts['virtualization_role'], str)

# Generated at 2022-06-20 20:18:33.681429
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:38.351871
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test FreeBSDVirtualCollector constructor and a few functions
    '''
    FreeBSDVirtualCollector()
    assert not FreeBSDVirtualCollector.has_virtual_facts('Linux')
    assert FreeBSDVirtualCollector.has_virtual_facts('FreeBSD')

# Generated at 2022-06-20 20:18:42.116911
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Virtualization type
    freebsd_virtual = FreeBSDVirtual({})
    assert 'virtualization_type' in freebsd_virtual.data
    # Virtualization role
    assert 'virtualization_role' in freebsd_virtual.data

# Generated at 2022-06-20 20:18:44.553621
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual(dict())
    assert v.get_virtual_facts()['virtualization_type'] == 'bhyve'

# Generated at 2022-06-20 20:18:48.137811
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instance of FreeBSDVirtualCollector
    bvc = FreeBSDVirtualCollector()
    # Asserts
    assert isinstance(bvc, FreeBSDVirtualCollector)
    assert isinstance(bvc._fact_class, FreeBSDVirtual)
    assert bvc._platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:49.718197
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:18:53.150452
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result.platform == 'FreeBSD'
    assert result._fact_class is FreeBSDVirtual

# Generated at 2022-06-20 20:18:59.396440
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product_guest' in virtual_facts
    assert 'virtualization_product_host' in virtual_facts

# Generated at 2022-06-20 20:20:10.898811
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    test_obj = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
    }
    assert FreeBSDVirtual().get_facts() == test_obj

# Generated at 2022-06-20 20:20:12.348973
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(VirtualCollector.factory('FreeBSD'), FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:20:21.841985
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Generate a FreeBSDVirtual instance and call get_virtual_facts()
    with test data.

    The output data of get_virtual_facts() should match the expected data.
    """
    virtual_instance = FreeBSDVirtual(module=None)

    # fake data returned by methods:
    # detect_virt_product, detect_virt_vendor

# Generated at 2022-06-20 20:20:33.035627
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:20:36.527375
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_module = FreeBSDVirtualCollector()
    assert fact_module.platform == 'FreeBSD'
    assert fact_module.fact_class == FreeBSDVirtual
    assert fact_module.fact_class().platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:40.699697
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.data['virtualization_type'] == ''
    assert f.data['virtualization_role'] == ''
    assert f.data['virtualization_tech_guest'] == set()
    assert f.data['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:20:42.512592
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:45.513108
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual.platform == 'FreeBSD'
    assert fbsd_virtual.get_virtual_facts().get('virtualization_type') == ''
    assert fbsd_virtual.get_virtual_facts().get('virtualization_role') == ''

# Generated at 2022-06-20 20:20:50.395500
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.get_virtual_facts() == {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set(),
    }

# Generated at 2022-06-20 20:20:52.389130
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fr = FreeBSDVirtualCollector()
    assert fr._platform == 'FreeBSD'
    assert fr._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:00.157558
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Test the constructor of class FreeBSDVirtual"""
    freebsd_virtual = FreeBSDVirtualCollector.fetch_virtual(None)
    assert isinstance(freebsd_virtual, dict)
    assert isinstance(freebsd_virtual, FreeBSDVirtual)

# Generated at 2022-06-20 20:22:03.254307
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtualCollector().get_virtual_facts()
    assert virtual_facts['virtualization_type'] is not None
    assert virtual_facts['virtualization_role'] is not None

# Generated at 2022-06-20 20:22:10.781677
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # tests for get_virtual_facts for get_virtual_facts
    vm1 = FreeBSDVirtual(None, {}, {}, [])
    # mock up the sysctl_dict to make the sysctl calls succeed
    vm1.get_sysctl_dict = lambda: {
        'kern.vm_guest': ' ',
        'hw.hv_vendor': ' ',
        'security.jail.jailed': '0',
        'hw.model': ' ',
    }
    ret = vm1.get_virtual_facts()
    assert ret['virtualization_type'] == ' '
    assert ret['virtualization_role'] == ' '

    vm1 = FreeBSDVirtual(None, {}, {}, [])
    # mock up the sysctl_dict to make the sysctl calls succeed

# Generated at 2022-06-20 20:22:14.001653
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vc = FreeBSDVirtual()
    assert vc.platform == 'FreeBSD'
    assert vc.virtualization_type is None
    assert vc.virtualization_role is None

# Generated at 2022-06-20 20:22:21.210839
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up
    freebsd_virtual = FreeBSDVirtual()
    os_path_exists_orig = os.path.exists
    
    os.path.exists = lambda path: path == '/dev/xen/xenstore'

    # Execute
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assertions
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']

    # Tear down
    os.path.exists = os_path_exists_orig

# Generated at 2022-06-20 20:22:24.743455
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == "FreeBSD"
    assert facts._fact_class == FreeBSDVirtual
    assert facts._platform == "FreeBSD"

# Generated at 2022-06-20 20:22:27.189175
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class == FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:28.620490
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:30.232932
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:32.403945
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsdv = FreeBSDVirtual({}, {})
    assert bsdv.get_virtual_facts()['virtualization_type'] == ''
    assert bsdv.get_virtual_facts()['virtualization_role'] == ''