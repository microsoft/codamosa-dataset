

# Generated at 2022-06-20 20:14:15.613019
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual()
    assert module.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:18.729135
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test for constructor of FreeBSDVirtualCollector
    '''
    obj = FreeBSDVirtualCollector()

    assert obj._fact_class is not None
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:21.705242
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    expected_result = {
        'virtualization_type': '',
        'virtualization_role': '',
    }
    virtual_facts = FreeBSDVirtual()
    assert expected_result == virtual_facts.get_virtual_facts()

# Generated at 2022-06-20 20:14:25.970848
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Check whether instance of class FreeBSDVirtualCollector was created successfully
    """
    fbc = FreeBSDVirtualCollector()
    assert fbc
    assert fbc.platform == 'FreeBSD'
    assert isinstance(fbc._fact_class, FreeBSDVirtual)


# Generated at 2022-06-20 20:14:27.351789
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert facts.platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:31.680685
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:34.554857
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    fv = FreeBSDVirtualCollector()
    fact_class = fv._fact_class
    platform = fv._platform

    assert fact_class.platform == platform

# Generated at 2022-06-20 20:14:35.642722
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()


# Generated at 2022-06-20 20:14:47.580383
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test 1: no virtualization
    class Test1FreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            self.sysctl_kern_vm_guest = {}
            self.sysctl_hw_hv_vendor = {}
            self.sysctl_security_jail_jailed = {}
            self.uname_s = 'FreeBSD'
            self.uname_r = '12.0-RELEASE-p1'
            self.machine = 'amd64'
            self.hw_model = 'intel(r)core(tm)i7-8700 cpu @3.20ghz'

    freebsd_virtual = Test1FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:14:50.681676
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd = FreeBSDVirtual({})
    assert hasattr(fbsd, "platform")
    assert hasattr(fbsd, "get_virtual_facts")

# Generated at 2022-06-20 20:14:56.641681
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:57.857144
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc=FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:07.777190
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = Virtual()
    v = FreeBSDVirtual(v.all_facts)

    # Test virtualization_type
    assert v.all_facts['virtualization_type'] == 'xen'

    # Test virtualization_role
    assert v.all_facts['virtualization_role'] == 'guest'

    # Test virtualization_tech_guest
    assert v.all_facts['virtualization_tech_guest'] == {'xen'}

    # Test virtualization_tech_host
    assert v.all_facts['virtualization_tech_host'] == {'xen'}



# Generated at 2022-06-20 20:15:19.099282
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class TestFreeBSDVirtual(FreeBSDVirtual):

        def get_dmi_info(self):
            return {
                'product': {
                    'version': '',
                    'manufacturer': '',
                    'name': ''
                }
            }

    virtual_facts = TestFreeBSDVirtual()
    virtual_facts._module = {
        'get_bin_path': lambda x: '/sbin/sysctl'
    }
    virtual_facts._sysctl_output = {
        'kernel.vm.guest': 'freebsd',
        'hw.hv_vendor': 'bhyve',
        'hw.model': 'Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz',
        'security.jail.jailed': '0'
    }

    results = virtual_facts._

# Generated at 2022-06-20 20:15:22.183393
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert FreeBSDVirtual().get_virtual_facts() == dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest={'xen'},
        virtualization_tech_host=set()
    )

# Generated at 2022-06-20 20:15:23.979040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    output = FreeBSDVirtualCollector()
    assert output._platform == 'FreeBSD'
    assert output._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:26.291348
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:27.527327
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # TODO: Implement this unit test
    pass


# Generated at 2022-06-20 20:15:30.250645
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.populate()
    assert 'FreeBSD' == virtual_facts.data['ansible_facts']['virtualization_type']

# Generated at 2022-06-20 20:15:37.810904
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import FreeBSDVirtual

    f = FreeBSDVirtual()

    # Test FreeBSD virtual facts using sysctl
    f.sysctl_facts = {'kern.vm_guest': 'other',
                      'hw.hv_vendor': 'bhyve',
                      'security.jail.jailed': 0}
    assert f.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Test with model

# Generated at 2022-06-20 20:15:47.271778
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD', 'The value of FreeBSDVirtualCollector._platform is incorrect.'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual, 'The value of FreeBSDVirtualCollector._fact_class is incorrect.'
    assert isinstance(FreeBSDVirtualCollector().get_virtual_facts(), dict), 'The return type of get_virtual_facts() of FreeBSDVirtualCollector does not match the expected type.'

# Generated at 2022-06-20 20:15:48.330108
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, {})
    assert virtual

# Generated at 2022-06-20 20:15:52.258871
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    # assert that x.platform is 'FreeBSD'
    assert x.platform == 'FreeBSD'
    # assert that x.fact_class is FreeBSDVirtual
    assert x.fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:15:55.032796
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert isinstance(x, VirtualCollector)
    assert isinstance(x._fact_class(), Virtual)


# Generated at 2022-06-20 20:15:59.962013
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import virtual
    v = virtual.FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert not v.virtual

# Test the get_virtual_facts() method of FreeBSDVirtual

# Generated at 2022-06-20 20:16:02.925997
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-20 20:16:05.726426
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()

    # Testing virtualization_type
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-20 20:16:07.250357
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test if the constructor of FreeBSDVirtualCollector class raises no exception
    assert FreeBSDVirtualCollector

# Generated at 2022-06-20 20:16:09.230008
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var = FreeBSDVirtualCollector(None, None, None).get_all_facts()
    assert type(var) == dict

# Generated at 2022-06-20 20:16:10.518001
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:20.573498
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()

# Generated at 2022-06-20 20:16:22.761842
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual()

    # Check that the correct platform is set
    assert fbv.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:25.199032
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector.collect()
    assert type(virtual_facts) == dict

# Generated at 2022-06-20 20:16:35.061105
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freenas_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_technologies_guest': ['xen'],
        'virtualization_technologies_host': ['xen'],
        'virtualization_type_role': 'xen guest',
        'virtualization_products': ['xen']
    }

    amd64_jail_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_technologies_guest': ['jail'],
        'virtualization_technologies_host': ['jail'],
        'virtualization_type_role': 'jail guest',
        'virtualization_products': ['jail']
    }

    virtualbox_facts

# Generated at 2022-06-20 20:16:45.804966
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sysctl_output = {'kern.vm_guest': 'freebsd',
                     'hw.hv_vendor': 'bhyve',
                     'security.jail.jailed': 0,
                     'hw.model': 'Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz'}
    virtual_facts = FreeBSDVirtual(sysctl_output)
    result_dict = virtual_facts.get_virtual_facts()

    assert result_dict['virtualization_type'] == 'bhyve'
    assert result_dict['virtualization_role'] == 'guest'
    assert result_dict['virtualization_tech_guest'] == {'bhyve', 'jails'}
    assert result_dict['virtualization_tech_host'] == {'bhyve'}

# Generated at 2022-06-20 20:16:53.352194
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module_name = 'test_FreeBSDVirtual_get_virtual_facts'
    virtual_mock = Virtual({})

    virtual_mock.module_name = module_name

    virtual_mock.get_file_content = lambda x: None
    virtual_mock.get_cmd_output = lambda x: ''

    result = virtual_mock.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

    virtual_mock.get_file_content = lambda x: ''
    virtual_mock.get_cmd_output = lambda x: ''
    result = virtual_mock.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

    virtual_mock.get_file_

# Generated at 2022-06-20 20:16:56.468871
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    assert(FreeBSDVirtualCollector._platform == 'FreeBSD')
    assert(FreeBSDVirtualCollector._fact_class == FreeBSDVirtual)

# Generated at 2022-06-20 20:16:57.502997
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-20 20:16:58.874069
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v._platform == 'FreeBSD'
    assert v._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:04.388389
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    FBSDVirtual = FreeBSDVirtual()

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    kern_vm_guest = set(['freebsd', 'pmu'])
    hw_hv_vendor = set(['kvm'])
    sec_jail_jailed = set(['jail'])
    hw_model = set(['vmware'])
    FBSDVirtual.kern_vm_guest = kern_vm_guest
    FBSDVirtual.hw_hv_vendor = hw_hv_vendor
    F

# Generated at 2022-06-20 20:17:30.324639
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()
    assert isinstance(fb_virtual, FreeBSDVirtual)
    assert fb_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:39.549594
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    import sys
    import doctest
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    # This import statement is to make sure that the instance
    # of FreeBSDVirtual class can be created when __main__ is
    # FreeBSDVirtual itself or when __main__ is VirtualCollector.
    # It is needed for tests to pass.
    from ansible.module_utils.facts.virtual.virtual import Virtual

    # The doctest of FreeBSDVirtual class
    #
    # The purpose of the test is to make sure that the instance
    # of FreeBSDVirtual class can be created when __main__ is
    # FreeBSDVirtual itself or when __main__ is VirtualCollector.
    # It is needed for tests to pass.
    doctest.testmod(sys.modules[FreeBSDVirtual.__module__])

# Generated at 2022-06-20 20:17:44.388797
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector.virtual == FreeBSDVirtual()
    assert virtual_collector.cache == {}


# Generated at 2022-06-20 20:17:46.227759
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:17:58.096260
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    for test in [
        ('virtualization_type_is_none', None),
        ('virtualization_role_is_none', None),
        ('virtualization_type_is_guest', 'guest'),
    ]:
        context = {
            'sysctl_kern_vm_guest': test[1],
            'sysctl_hw_hv_vendor': 'VMWare',
            'sysctl_security_jail_jailed': 1,
            'hw_model': '',
            'kern_vm_guest': '',
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        }

# Generated at 2022-06-20 20:18:08.137498
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': '',
        'virtualization_tech_host': '',
    }
    virtual = FreeBSDVirtual(virtual_facts)
    assert isinstance(virtual, Virtual)
    # Check if the FreeBSDVirtual subclass has the correct 'platform' and 'distribution' members
    assert virtual.platform == 'FreeBSD' and virtual.distribution == ''
    assert virtual.is_jail == False
    assert virtual.is_virtual == False

# Generated at 2022-06-20 20:18:19.236600
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def execute_mock(cmd):
        if cmd == 'sysctl -n security.jail.jailed':
            return '0'
        elif cmd == 'sysctl -n kern.vm_guest':
            return 'some_value'
        elif cmd == 'sysctl -n hw.hv_vendor':
            return 'some_value'
        elif cmd == 'sysctl -n hw.model':
            return 'some_value'

    f = FreeBSDVirtual({'module_setup': {}})
    f._execute_module = execute_mock
    res = f.get_virtual_facts()
    assert res.get('virtualization_type') == ''
    assert res.get('virtualization_role') == ''

# Generated at 2022-06-20 20:18:22.172607
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO
    return


if __name__ == '__main__':
    # Run unit test
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:18:24.496396
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    b = FreeBSDVirtualCollector()
    assert b._platform == 'FreeBSD'
    assert b._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:18:33.830464
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Input data
    # TODO: we can use testinfra to create a FreeBSD VM and then read the sysctl values
    data = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set([]),
        virtualization_tech_host=set([]),
    )
    # Expected result
    result = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest={'xen'},
        virtualization_tech_host={'xen'},
    )
    # Test
    virtual = FreeBSDVirtual(data)
    result_test = virtual.get_virtual_facts()
    assert result == result_test

# Generated at 2022-06-20 20:19:07.381207
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:19:08.398859
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:19:10.501262
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert type(virtual_collector) == FreeBSDVirtualCollector

# Generated at 2022-06-20 20:19:12.890349
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    virtual.get_virtual_facts()
    assert virtual.virtualization_type is not None
    assert virtual.virtualization_role is not None

# Generated at 2022-06-20 20:19:16.564990
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Constructs FreeBSDVirtualCollector and verify that correct
    _platform is set.
    """
    v = FreeBSDVirtualCollector()
    assert(v._platform == 'FreeBSD')

# Generated at 2022-06-20 20:19:27.553837
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual

    class FakeModule(object):
        def run_command(self, cmd, check_rc=True):
            pass

    class TestFreeBSDVirtual(FreeBSDVirtual, VirtualSysctlDetectionMixin):
        platform = 'FreeBSD'

    # Needs to have the name 'collect' to be picked up by the collector
    def collect(self, module=None):
        return TestFreeBSDVirtual(module=FakeModule()).get_virtual_facts()

    f = FakeModule()
    f.run_command = lambda cmd, check_rc: (cmd, 0, '', '')
    v = TestFreeBSDVirtual(module=f)
    v.get_virtual_facts()

# Generated at 2022-06-20 20:19:33.275614
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD VM
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set(['xen'])

# Generated at 2022-06-20 20:19:41.193600
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    This test checks the return value of method get_virtual_facts of class FreeBSDVirtual
    """
    virtual_test = FreeBSDVirtual()

    virtual_test.sysctl = {
        'kern.vm_guest': 'kern.vm_guest: unknown',
        'hw.hv_vendor': 'hw.hv_vendor: unknown',
        'security.jail.jailed': 'security.jail.jailed: 0',
    }

    virtual_test.model = 'VirtualBox'
    virtual_test.vendor = 'innotek GmbH'
    virtual_test.xen_capabilities = []


# Generated at 2022-06-20 20:19:42.438551
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'



# Generated at 2022-06-20 20:19:50.424170
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test - FreeBSDVirtual.get_virtual_facts
    """
    fv = FreeBSDVirtual()
    assert FreeBSDVirtual.platform == 'FreeBSD'
    assert fv.platform == 'FreeBSD'
    virtual_facts = fv.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert virtual_facts == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_technologies_guest': set(), 'virtualization_technologies_host': set()}

# Generated at 2022-06-20 20:20:58.214644
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-20 20:21:00.972356
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual()
    facts = vf.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:21:02.525479
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:07.340011
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create an object of class FreeBSDVirtual
    obj = FreeBSDVirtual()
    # Try to get the value of 'virtualization_type' key
    data = obj.get_virtual_facts()
    print(data)
    # Check whether 'virtualization_type' key retrieved or not
    assert 'virtualization_type' in data.keys()
    # Check whether 'virtualization_role' key retrieved or not
    assert 'virtualization_role' in data.keys()

# Generated at 2022-06-20 20:21:09.566154
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbv = FreeBSDVirtualCollector()
    assert fbv
    assert isinstance(fbv, VirtualCollector)

# Generated at 2022-06-20 20:21:12.424144
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:21:16.781796
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector, '_platform'), 'FreeBSDVirtualCollector must have attribute _platform'
    assert hasattr(FreeBSDVirtualCollector._fact_class, 'platform'), 'FreeBSDVirtualCollector._fact_class must have attribute platform'
    assert FreeBSDVirtualCollector._platform == FreeBSDVirtualCollector._fact_class.platform, 'FreeBSDVirtualCollector._platform must equal FreeBSDVirtualCollector._fact_class.platform'


# Generated at 2022-06-20 20:21:27.823246
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create FreeBSDVirtual object
    virtual_obj = FreeBSDVirtual()

    # define virtualization_type dictionary for test
    test_virtualization_type = dict()

    # define virtualization_role dictionary for test
    test_virtualization_role = dict()

    # define virtualization_tech_guest dictionary for test
    test_virtualization_tech_guest = dict()

    # define virtualization_tech_host dictionary for test
    test_virtualization_tech_host = dict()

    # call get_virtual_facts and set result to virtual facts
    virtual_facts = virtual_obj.get_virtual_facts()

    # set virtualization_type value to dictionary and compare with original
    test_virtualization_type['virtualization_type'] = 'xen'

# Generated at 2022-06-20 20:21:28.580728
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:21:29.999835
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtualCollector.collect()
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:51.360705
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-20 20:23:54.960868
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:57.530926
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:24:00.426975
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert isinstance(v, Virtual)
    assert isinstance(v, VirtualSysctlDetectionMixin)
    assert isinstance(v, FreeBSDVirtual)


# Generated at 2022-06-20 20:24:05.251633
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert VirtualCollector._platform == 'Linux'
    assert VirtualCollector._fact_class == Virtual
    fbsd = FreeBSDVirtual()
    assert fbsd._platform == 'FreeBSD'
    assert fbsd.__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-20 20:24:08.546655
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.data
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''
    assert virtual.data['virtualization_tech_guest'] == set()
    assert virtual.data['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:24:09.922061
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, VirtualCollector)
