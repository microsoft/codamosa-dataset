

# Generated at 2022-06-20 20:14:14.300266
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    FreeBSDVirtualCollector(None, None, None)


# Generated at 2022-06-20 20:14:24.586836
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    class DummyFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, product):
            return None
        def detect_virt_vendor(self, vendor):
            return None
    expected_virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set([])
    }
    obj = DummyFreeBSDVirtual()
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts


# Generated at 2022-06-20 20:14:26.152726
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtobj = FreeBSDVirtual()
    assert virtobj.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:28.324321
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    assert facts.virtualization_type == ''
    assert facts.virtualization_role == ''



# Generated at 2022-06-20 20:14:38.672732
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    sys.modules['_raw_sysctl'] = sys.modules['ansible.module_utils.facts.virtual.sysctl']
    sys.modules['_platform'] = sys.modules['ansible.module_utils.facts.virtual.freebsd']

    test_object = FreeBSDVirtual()
    assert test_object.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    del sys.modules['_raw_sysctl']
    del sys.modules['_platform']

# Generated at 2022-06-20 20:14:39.622438
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:14:42.077535
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.data == {'virtualization_type': '',
                                    'virtualization_role': '',
                                    'virtualization_technologies': []}
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:44.277616
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_inst = FreeBSDVirtual()
    assert virtual_inst.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:46.694980
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert type(FreeBSDVirtualCollector()) == FreeBSDVirtualCollector


# Generated at 2022-06-20 20:14:50.223266
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    os.environ['PATH'] = '/bin:/usr/bin'
    freebsd_virtual_collector = FreeBSDVirtualCollector(None)

    assert freebsd_virtual_collector._fact_class is not None

# Generated at 2022-06-20 20:14:57.444747
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    assert (facts.platform == 'FreeBSD')

# Generated at 2022-06-20 20:15:07.456770
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    # Test for class creation
    assert virtual_facts.__class__.__name__ == 'FreeBSDVirtual'
    # Test for platform
    assert virtual_facts.platform == 'FreeBSD'
    # Test for virtualization_type
    assert virtual_facts.virtualization_type == ''
    # Test for virtualization_role
    assert virtual_facts.virtualization_role == ''
    # Test for virtualization_tech_guest
    assert virtual_facts.virtualization_tech_guest == set()
    # Test for virtualization_tech_host
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-20 20:15:18.921607
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    hw_hv_vendor = freebsd_virtual.detect_virt_product(
        'hw.hv_vendor'
    )
    kern_vm_guest = freebsd_virtual.detect_virt_product(
        'kern.vm_guest'
    )
    sec_jail_jailed = freebsd_virtual.detect_virt_product(
        'security.jail.jailed'
    )
    virtual_vendor_facts = freebsd_virtual.detect_virt_vendor('hw.model')

    # Scenario: no special sysctl detected

# Generated at 2022-06-20 20:15:20.669779
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert len(facts) == 3

# Generated at 2022-06-20 20:15:21.275398
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:25.494453
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector.platform == 'FreeBSD'
    assert facts_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:34.855917
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual.detect_virt_product = lambda self, sysctl_fact: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    FreeBSDVirtual.detect_virt_vendor = lambda self, sysctl_fact: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    FreeBSDVirtual.check_sysctl_fact = lambda self, sysctl_fact: True

    # check for default
    facts = FreeBSDVirtual().get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] is not None
    assert facts['virtualization_tech_host'] is not None

    # check for host

# Generated at 2022-06-20 20:15:38.109053
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of class FreeBSDVirtualCollector
    """
    obj = FreeBSDVirtualCollector()
    assert obj._fact_class == FreeBSDVirtual
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:40.820829
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:49.607639
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual1 = FreeBSDVirtualCollector.fetch_virtual_facts()
    assert virtual1['virtualization_type'] is not None
    assert virtual1['virtualization_role'] is not None
    assert virtual1['virtualization_type'] == 'xen'
    assert virtual1['virtualization_role'] == 'guest'
    assert virtual1['virtualization_tech_host'] == set()
    # On baremetal machine
    virtual2 = FreeBSDVirtualCollector.fetch_virtual_facts()
    assert virtual2['virtualization_type'] == ''
    assert virtual2['virtualization_role'] == ''
    assert virtual2['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:15:59.051071
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class == FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:59.633022
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()

# Generated at 2022-06-20 20:16:11.236604
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    # In this condition, 'uname -s' command returns 'FreeBSD'.
    os.uname = lambda: ['FreeBSD']
    # In this condition, 'kern.vm_guest' sysctl returns 'none'.
    FreeBSDVirtual.get_sysctl = lambda self, key: 'none'
    # In this condition, 'hw.hv_vendor' sysctl returns 'none'.
    FreeBSDVirtual.get_sysctl = lambda self, key: 'none'
    # In this condition, 'security.jail.jailed' sysctl returns '0'.
    FreeBSDVirtual.get_sysctl = lambda self, key: '0'
    # In this condition, 'hw.model' sysctl returns 'none'.
    FreeBSDVirtual.get_sysctl = lambda self, key: ''
    #

# Generated at 2022-06-20 20:16:14.310314
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:16.577874
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert isinstance(fv, FreeBSDVirtual)

# Generated at 2022-06-20 20:16:22.122437
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    FreeBSDVirtualCollector class constructor test
    '''
    # Setup
    obj = FreeBSDVirtualCollector()
    # Test case 1 (setup)
    assert obj._platform == "FreeBSD"
    # Test case 2 (setup)
    assert obj._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:16:29.207082
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Arrange
    virt_facts = {'virtualization_type': 'xen',
                  'virtualization_role': 'guest',
                  'virtualization_tech_guest': {'xen'},
                  'virtualization_tech_host': set()}

    # Act
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Assert
    assert virtual_facts == virt_facts

# Generated at 2022-06-20 20:16:32.743326
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})

    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:16:38.353887
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    # Passing 'None' as a sub_class in constructor of parent class
    virtual_collector_object = FreeBSDVirtualCollector(None)
    # Assert that virtual_collector_object is of type FreeBSDVirtual
    assert isinstance(virtual_collector_object, FreeBSDVirtualCollector)


# Generated at 2022-06-20 20:16:39.934907
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f,VirtualCollector)

# Generated at 2022-06-20 20:17:01.926173
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fake_module = 'fake_module'
    fake_module_args = {}
    set_module_args(fake_module_args)
    my_test_obj = FreeBSDVirtual(fake_module)

    for key in my_test_obj.virtual_facts.keys():
        assert my_test_obj.virtual_facts[key] != 'unknown'


# Generated at 2022-06-20 20:17:09.274662
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb = FreeBSDVirtual({})
    facts = fb.get_virtual_facts()
    keys = facts.keys()
    assert 'virtualization_type' in keys
    assert 'virtualization_role' in keys
    assert 'virtualization_tech_guest' in keys
    assert 'virtualization_tech_host' in keys
    assert 'virtualization_product_guest' in keys
    assert 'virtualization_product_host' in keys

# Generated at 2022-06-20 20:17:12.007172
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector(None)
    assert isinstance(collector, VirtualCollector)
    assert isinstance(collector.platforms['FreeBSD'], FreeBSDVirtual)

# Generated at 2022-06-20 20:17:13.891843
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # test creating class object with default values
    FreeBSDVirtual()


# Generated at 2022-06-20 20:17:16.789251
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vobj = FreeBSDVirtual()
    assert vobj.platform == 'FreeBSD' and vobj.name == 'FreeBSD'

# Generated at 2022-06-20 20:17:23.693691
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Test if FreeBSDVirtual contains correct data"""
    freebsd_virtual = FreeBSDVirtual()
    assert (freebsd_virtual._platform ==
            "FreeBSD"), "Wrong virtual platform detection"
    assert (freebsd_virtual._fact_class ==
            FreeBSDVirtual), "Wrong virtual fact class detection"
    assert (freebsd_virtual._collector_class ==
            FreeBSDVirtualCollector), "Wrong virtual collector class detection"

# Generated at 2022-06-20 20:17:24.903058
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtualCollector('/', [])
    assert f is not None

# Generated at 2022-06-20 20:17:26.957934
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)

    assert virtual_facts.__class__ == FreeBSDVirtual


# Generated at 2022-06-20 20:17:38.594687
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    bsd_virtual = FreeBSDVirtual(facts)

    facts['ansible_system'] = 'FreeBSD'
    facts['ansible_virtualization_role'] = 'guest'
    facts['ansible_virtualization_type'] = 'xen'
    facts['ansible_virtualization_technologies'] = set(['xen'])

# Generated at 2022-06-20 20:17:41.227179
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freeBSDVirtual = FreeBSDVirtual(module=object)
    assert freeBSDVirtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:37.149438
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test will make use of the VirtualCollector class to call
    # the get_virtual_facts method of the FreeBSDVirtual class.
    # This will return the virtual facts
    #
    # The FreeBSDVirtual class is being tested only for the
    # values that it sets, so the VirtualCollector class can
    # return arbitrary values for virtualization_type,
    # virtualization_role, virtualization_tech_host and
    # virtualization_tech_guest.
    virtual_facts_collector = FreeBSDVirtualCollector()
    virtual_facts = virtual_facts_collector.collect(None, None)

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:18:46.272544
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    frebsd_virtual_instance = FreeBSDVirtual()
    assert frebsd_virtual_instance.os.lower() == 'freebsd'
    assert frebsd_virtual_instance.distribution.lower() == 'freebsd'
    assert frebsd_virtual_instance.platform.lower() == 'freebsd'
    assert frebsd_virtual_instance.virtualization_tech_guest == set()
    assert frebsd_virtual_instance.virtualization_tech_host == set()
    assert frebsd_virtual_instance.virtualization_type == ''
    assert frebsd_virtual_instance.virtualization_role == ''


# Generated at 2022-06-20 20:18:53.477147
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    frbsd_virtual_facts = FreeBSDVirtual({})
    assert isinstance(frbsd_virtual_facts.data, dict)
    # Test facts with empty datastructure
    frbsd_virtual_facts.populate_facts()
    assert frbsd_virtual_facts.data['virtualization_type'] == ''
    assert frbsd_virtual_facts.data['virtualization_role'] == ''

# Generated at 2022-06-20 20:18:54.861388
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)


# Generated at 2022-06-20 20:18:57.578097
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._fact_class == FreeBSDVirtual
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:01.617280
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    vf = FreeBSDVirtual().get_virtual_facts()

    assert isinstance(vf, dict)
    assert 'virtualization_type' in vf
    assert 'virtualization_role' in vf
    assert 'virtualization_tech_guest' in vf
    assert 'virtualization_tech_host' in vf

    assert isinstance(vf['virtualization_type'], str)

# Generated at 2022-06-20 20:19:03.684488
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:06.153204
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    x = FreeBSDVirtual({})
    assert x.platform == 'FreeBSD'

# Unit tests for constructor of class FreeBSDVirtualCollector

# Generated at 2022-06-20 20:19:12.618412
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    This unit test was created with the intention of running
    directly the constructor of class FreeBSDVirtual.

    What it really does is to print to stdout the dictionaries
    returned by function get_virtual_facts()

    Then, we will be able to check that the facts returned are
    correct (they must be identical to the ones that we would
    get running Ansible module 'setup' on a FreeBSD system).
    """
    print(FreeBSDVirtual().get_virtual_facts())


# Generated at 2022-06-20 20:19:14.118112
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    x = FreeBSDVirtual()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:17.233660
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector._fact_class, FreeBSDVirtual)
    assert collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:21.579208
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual()
    assert module.platform == 'FreeBSD'
    assert module.get_virtual_facts()['virtualization_type'] == ''
    assert module.get_virtual_facts()['virtualization_role'] == ''
    assert module.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert module.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:20:25.528455
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c, FreeBSDVirtualCollector)
    assert c._platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:20:27.692369
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._fact_class == FreeBSDVirtual
    assert x._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:29.470795
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:35.260246
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    # FreeBSDVirtual is a subclass of Virtual class, so the following object should be a Virtual object
    assert isinstance(freebsd_virtual, Virtual)
    # FreeBSDVirtual is a subclass of Virtual class, so calling the constructor should instantiate a Virtual object
    assert isinstance(freebsd_virtual.__init__(), Virtual)
    # Calling the constructor should instantiate a FreeBSDVirtual object
    assert isinstance(freebsd_virtual.__init__(), FreeBSDVirtual)

# test_FreeBSDVirtual


# Generated at 2022-06-20 20:20:39.153118
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    t_fbsdvc = FreeBSDVirtualCollector()
    assert isinstance(t_fbsdvc, VirtualCollector)
    assert t_fbsdvc.platform == 'FreeBSD'
    assert t_fbsdvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:20:46.391701
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup FreeBSDVirtual
    fb = FreeBSDVirtual()

    # Read expected results from file
    data_path = os.path.join(os.path.dirname(__file__), 'virtual_freebsd_data.json')
    with open(data_path, 'rb') as data_file:
        data = data_file.read()

    # load json data
    import json
    test_data = json.loads(data)

    # Set variables for test
    for k, v in test_data.items():
        fb.sysctl[k] = v

    # Execute get_virtual_facts on fb and compare to test_data
    assert fb.get_virtual_facts() == test_data

# Generated at 2022-06-20 20:20:57.559125
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    c = FreeBSDVirtual()

    # Make sure all method are there
    c.detect_virt_product = mock.MagicMock()
    c.detect_virt_vendor = mock.MagicMock()

    assert c.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

    # Test with detect_virt_product returning a valid host_tech
    c.detect_virt_product.return_value = {
        'virtualization_type': 'kvm',
        'virtualization_tech_host': set(['kvm']),
        'virtualization_tech_guest': set(['kvm']),
    }
    c.detect

# Generated at 2022-06-20 20:21:02.605525
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fd_virt = FreeBSDVirtual(None)
    assert fd_virt.platform == 'FreeBSD', 'Expected platform FreeBSD'
    assert fd_virt.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }, 'Expected virtual facts'

# Generated at 2022-06-20 20:22:07.562242
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-20 20:22:09.792471
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector()._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:22:16.955418
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert hasattr(FreeBSDVirtual, '_platform')
    assert hasattr(FreeBSDVirtual, 'platform')
    assert hasattr(FreeBSDVirtual, 'get_virtual_facts')
    assert hasattr(FreeBSDVirtual, '_virtual')

    # Verify that constructor initializes properly
    assert FreeBSDVirtual().platform == FreeBSDVirtual._platform
    assert FreeBSDVirtual()._platform == FreeBSDVirtual.platform



# Generated at 2022-06-20 20:22:22.744924
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_test_class = FreeBSDVirtual(None)
    virtual_test_class.sysctl = {
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'other',
        'security.jail.jailed': '1',
        'hw.model': 'FreeBSD/amd64',
    }

    virtual_facts = virtual_test_class.get_virtual_facts()
    tests = [
        {'condition': 'virtualization_type', 'result': 'bhyve'},
        {'condition': 'virtualization_role', 'result': 'guest'},
        {'condition': 'virtualization_tech_host', 'result': set()},
        {'condition': 'virtualization_tech_guest', 'result': {'jail'}},
    ]

   

# Generated at 2022-06-20 20:22:25.721375
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:22:34.596011
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    fb = FreeBSDVirtual()

    # No virtualization
    kern_vm_guest = {'sysctl': {'kern.vm_guest': 'none'},
                     'virtualization_type': '',
                     'virtualization_role': ''}

    fb.detect_virt_product = lambda x: kern_vm_guest

    hw_model = {'sysctl': {'hw.model': 'VMWare Virtual Platform'},
                'virtualization_type': 'VMWare Virtual Platform',
                'virtualization_role': 'guest'}

    fb.detect_virt_vendor = lambda x: hw_model

    fb_virtual_facts = fb.get_virtual_facts()

    # Test virtualization_type
    assert fb_virtual_facts['virtualization_type']

# Generated at 2022-06-20 20:22:42.934982
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl_defaults import sysctl_defaults
    from ansible.module_utils.facts.virtual.sysctl_defaults import sysctl_types

    class TestFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self, module):
            super(TestFreeBSDVirtual, self).__init__(module=module)
            self.vendor_dict = {'hw.model':
                                    {'freebsd': {'virtualization_type': '',
                                                 'virtualization_tech_host': set(),
                                                 'virtualization_tech_guest': {'freebsd'}}}}

# Generated at 2022-06-20 20:22:48.553271
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    Facts = dict(FreeBSDVirtual().get_virtual_facts())
    assert Facts['virtualization_type'] == 'xen'
    assert Facts['virtualization_role'] == 'guest'
    assert Facts['virtualization_type'] == 'xen'
    assert Facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:22:49.939697
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:52.137233
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:24:06.402683
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual
    assert obj._platform == 'FreeBSD'