

# Generated at 2022-06-20 20:14:22.936897
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    # Condition: running on FreeBSD host with 'security.jail.jailed' set to 1
    # and 'kern.vm_guest' set to 'none' and 'hw.hv_vendor' set to 'KVM'
    # and 'hw.model' set to 'VirtualBox'.
    # Expected: virtualization_type = 'virtualbox'
    #           virtualization_role = 'host'
    freebsd_virtual.facts = {'kernel': 'FreeBSD',
                             'system': 'FreeBSD',
                             'virtualization_type': '',
                             'virtualization_role': ''}

# Generated at 2022-06-20 20:14:24.836714
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_fact_module = FreeBSDVirtual()
    assert virtual_fact_module.get_platform() == 'FreeBSD'

# Generated at 2022-06-20 20:14:31.193065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an instance of class FreeBSDVirtual
    fbsd_virtual_facts = FreeBSDVirtual(None)

    assert fbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
    }

    assert fbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-20 20:14:32.788591
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class is FreeBSDVirtual

# Generated at 2022-06-20 20:14:35.643154
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test FreeBSDVirtual.get_virtual_facts()
    freebsd_virtual_facts = FreeBSDVirtual()
    freebsd_virtual_facts.get_virtual_facts()

# Generated at 2022-06-20 20:14:37.109670
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:14:37.914740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-20 20:14:39.342808
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # TODO: Unit test for constructor of class FreeBSDVirtual
    assert True

# Generated at 2022-06-20 20:14:45.257600
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:14:53.201406
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('module', (), {})()
    setattr(fake_module, 'sysctl', lambda *args: 'xen')
    setattr(fake_module, 'getoutput', lambda *args: 'xen')

    fbvd = FreeBSDVirtual(module=fake_module)
    virtual_facts = fbvd.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:14:59.834125
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    ans = FreeBSDVirtual()
    assert isinstance(ans, FreeBSDVirtual)


# Generated at 2022-06-20 20:15:06.359813
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'
    assert fv.guest_fact_name == 'virtualization_tech_guest'
    assert fv.host_fact_name == 'virtualization_tech_host'
    assert fv.primary_guest_fact == 'virtualization_role'
    assert fv.primary_host_fact == 'virtualization_type'

# Generated at 2022-06-20 20:15:09.158321
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:10.187238
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-20 20:15:14.453029
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Testing FreeBSDVirtual class constructor, clear_facts=True
    fbsd_virtual = FreeBSDVirtual({}, True)

    assert fbsd_virtual.platform == 'FreeBSD'
    fbsd_virtual.clear_facts()


# Generated at 2022-06-20 20:15:15.961708
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual()
    assert obj.platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:18.401013
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:26.683386
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    data = {
        'hw.hv_vendor': '',
        'hw.model': 'FreeBSD/amd64',
        'kern.vm_guest': 'none',
        'security.jail.jailed': '0'
    }
    facts = FreeBSDVirtual(data).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    data = {
        'hw.hv_vendor': '',
        'hw.model': 'FreeBSD virtual machine',
        'kern.vm_guest': 'none',
        'security.jail.jailed': '0'
    }
    facts = FreeBSD

# Generated at 2022-06-20 20:15:28.534727
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:30.244570
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:49.075162
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_facts = {}

    # Find and remove any existing FreeBSDVirtualCollector object.
    # We need to do this in case test_FreeBSDVirtual_get_virtual_facts
    # has been called before, so that we start from a known state.
    for i in range(len(VirtualCollector.collections) - 1, -1, -1):
        if isinstance(VirtualCollector.collections[i], FreeBSDVirtualCollector):
            del VirtualCollector.collections[i]
            break

    # Create a FreeBSDVirtualCollector object and get virtual facts from it.
    virtual_collector = FreeBSDVirtualCollector(test_facts)
    virtual_collector.collect()

    # Make sure the correct virtual_facts have been set
    assert test_facts['virtualization_type'] == 'jail'
    assert 'virtualization_role'

# Generated at 2022-06-20 20:15:50.046811
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass

# Generated at 2022-06-20 20:15:55.029872
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.populate()
    results = freebsd_virtual.get_virtual_facts()
    assert results.get('virtualization_type') == ''
    assert results.get('virtualization_role') == ''

# Generated at 2022-06-20 20:15:59.682747
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    true_facts = FreeBSDVirtual().get_virtual_facts()

    assert true_facts['virtualization_type'] == 'xen'
    assert true_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:16:03.132366
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({}, {})
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:04.690939
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:07.828821
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtualCollector.fetch_virtual_facts()
    assert type(fv) is dict
    assert 'virtualization_type' in fv
    assert 'virtualization_role' in fv

# Generated at 2022-06-20 20:16:09.668912
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._fact_class == FreeBSDVirtual
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:23.255535
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''test_FreeBSDVirtual_get_virtual_facts
    This test method tests the get_virtual_facts method of the
    FreeBSDVirtual class.  It uses the output from the shell
    command specified in the example to generate the expected
    result.  This is an incomplete test: it only tests the
    values of a subset of the virtual facts.'''

    import json
    import os
    import sys
    import subprocess

    sys.path.append(os.getcwd())

    import ansible.module_utils.facts.virtual.freebsd

    # In the next section we are creating a FreeBSDVirtualCollector instance
    # and invoking its get_all_facts method.  The output of the get_all_facts
    # method is a dictionary.  The virtual_facts dictionary contains a subset
    # of the key-value pairs from the get_all

# Generated at 2022-06-20 20:16:33.962857
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Virtualization disabled, no jail
    with open('/proc/self/status') as proc_status:
        proc_status_lines = proc_status.readlines()
    freebsd_virtual = FreeBSDVirtual(proc_status_lines, {})
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert not virtual_facts['virtualization_type']
    assert not virtual_facts['virtualization_role']
    assert not virtual_facts['virtualization_tech_host']
    assert not virtual_facts['virtualization_tech_guest']

    # Virtualization enabled, no jail, no VM
    set_host_fact = {'hw_model': 'FreeBSD/amd64 (VirtualBox)', 'hw_machinearch': 'amd64'}

# Generated at 2022-06-20 20:16:51.205169
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts when running in a FreeBSD jail. This also tests
    the VirtualSysctlDetectionMixin class.
    """
    facts = {'kernel': 'FreeBSD',
             'hw_model': 'FreeBSD/amd64'}
    expected = {'virtualization_type': 'jail',
                'virtualization_role': 'guest',
                'virtualization_tech_host': set(['jail']),
                'virtualization_tech_guest': set(['jail'])}
    test_fact = FreeBSDVirtual(facts)
    result = test_fact.get_virtual_facts()
    assert expected == result

# Generated at 2022-06-20 20:16:52.313068
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert isinstance(FreeBSDVirtual({}), object)

# Generated at 2022-06-20 20:16:56.091450
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:16:57.891872
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_collector = FreeBSDVirtualCollector()
    assert fv_collector is not None
    assert fv_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:58.947834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc, VirtualCollector)

# Generated at 2022-06-20 20:17:00.315160
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual_obj = FreeBSDVirtual()
    assert fbsd_virtual_obj.platform == 'FreeBSD'


# Generated at 2022-06-20 20:17:05.597412
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Testing empty sysctl returns
    kern_vm_guest = dict(virtualization_tech_guest=set(), virtualization_tech_host=set())
    hw_hv_vendor = dict(virtualization_tech_guest=set(), virtualization_tech_host=set())
    sec_jail_jailed = dict(virtualization_tech_guest=set(), virtualization_tech_host=set())
    fbsd_virtual_facts = FreeBSDVirtual(dict(kern_vm_guest=kern_vm_guest, hw_hv_vendor=hw_hv_vendor, sec_jail_jailed=sec_jail_jailed))
    virtual_facts = fbsd_virtual_facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-20 20:17:07.761645
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    my_virtual = FreeBSDVirtual()
    assert(my_virtual.name == 'FreeBSD')

# Generated at 2022-06-20 20:17:09.473747
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual._fact_class == FreeBSDVirtual
    assert freebsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:13.135250
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    This test asserts that the FreeBSDVirtualCollector can be instantiated
    '''
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, FreeBSDVirtualCollector)
    assert isinstance(collector._fact_class, type)
    assert isinstance(collector._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-20 20:17:38.191828
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_product'] == ''
    assert virtual_facts['virtualization_hypervisor'] == ''
    assert virtual_facts['virtualization_host_type'] == ''
    assert virtual_facts['virtualization_host'] == ''

# Generated at 2022-06-20 20:17:46.830010
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create class instance and get virtual facts
    fbsd = FreeBSDVirtual()
    facts = fbsd.get_virtual_facts()

    # Check if facts are the same
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_product_guest'] == ''
    assert facts['virtualization_product_host'] == ''

# Generated at 2022-06-20 20:17:49.814348
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsdv = FreeBSDVirtual()
    if bsdv.platform:
        assert bsdv.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:55.323486
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert type(FreeBSDVirtual(None)) == FreeBSDVirtual
    assert type(FreeBSDVirtual(None).collect()) == dict
    assert type(FreeBSDVirtual(None)._platform) == str
    assert type(FreeBSDVirtual(None).get_virtual_facts()) == dict
    assert None is not FreeBSDVirtual(None)._legacy_facts

# Generated at 2022-06-20 20:17:57.711386
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None), VirtualCollector)
    assert issubclass(FreeBSDVirtualCollector._fact_class, Virtual)


# Generated at 2022-06-20 20:18:10.251418
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    from mock import Mock
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class MockFreeBSDVirtual(FreeBSDVirtual, VirtualSysctlDetectionMixin):
        def __init__(self):
            # Mocking _get_file_content so we can override the return_value.
            self._get_file_content = Mock(return_value='')

            # Mocking detect_virt_product so we can override the return_value.
            self.detect_virt_product = Mock(return_value={
                "virtualization_tech_guest": set(),
                "virtualization_tech_host": set(),
                "virtualization_type": "",
                "virtualization_role": ""})

            # Mocking detect_virt_vendor so we can override the return_value.
           

# Generated at 2022-06-20 20:18:14.042915
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # If no matches are found, the following facts should be returned
    assert FreeBSDVirtual({}).get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies': set(),
    }


# Generated at 2022-06-20 20:18:18.564528
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_vc = FreeBSDVirtualCollector()
    print(repr(freebsd_vc))
    assert freebsd_vc.platform == 'FreeBSD'
    assert freebsd_vc._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:18:22.119432
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    virtual_facts = FreeBSDVirtual()

    for key in virtual_facts.keys():
        assert 'virtual' in key

# Generated at 2022-06-20 20:18:24.761916
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-20 20:18:48.664269
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    expected_virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert virtual_facts.facts == expected_virtual_facts

# Generated at 2022-06-20 20:18:54.740337
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class is FreeBSDVirtual
    assert isinstance(x._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-20 20:18:55.343153
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:19:03.939115
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Note: This test only covers non-sysctl paths afaict, as it doesn't
    # mock the sysctl module.
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.sysctl_exists = lambda _: False
    freebsd_virtual.sysctl_available = lambda _: False
    freebsd_virtual.get_file_content = lambda _: ""

    facts = freebsd_virtual.get_virtual_facts()

    # There is no VirtualizationType fact on FreeBSD (yet)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == ''

    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:19:14.108897
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import (
        Virtual, VirtualCollector, VirtualSysctlDetectionMixin
    )
    class MockFreeBSDVirtual(Virtual, VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = {'virtualization_tech_host': set(),
                          'virtualization_tech_guest': set()}
            self.sysctl_defaults = {
                'kern.vm_guest': 'none',
                'hw.hv_vendor': 'none',
                'security.jail.jailed': 0,
                'hw.model': 'none',
            }

# Generated at 2022-06-20 20:19:17.916690
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Should return an empty dictionary
    result = FreeBSDVirtual(None).get_virtual_facts()
    assert dict == type(result)
    assert 0 == len(result)

# Generated at 2022-06-20 20:19:20.728867
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert v._name == 'freebsd'


# Generated at 2022-06-20 20:19:30.710188
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = Virtual()
    virtual._get_sysctl_value = MagicMock()

    # Set values of sysctl calls
    virtual._get_sysctl_value.side_effect = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
    virtual_facts = virtual.get_virtual_facts()

    # assert that virtualization_type is '', as no one of the checks returns something
    assert virtual_facts['virtualization_type'] == ''

    # assert that virtualization_role is '', as no one of the checks returns something
    assert virtual_facts['virtualization_role'] == ''

    # assert that virtualization_tech_guest is an empty set
    assert virtual_facts['virtualization_tech_guest'] == set

# Generated at 2022-06-20 20:19:34.742087
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:19:35.953998
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'



# Generated at 2022-06-20 20:20:09.121001
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == "FreeBSD"
    assert obj._fact_class == FreeBSDVirtual
    assert obj._platform == "FreeBSD"


# Generated at 2022-06-20 20:20:09.965239
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()


# Generated at 2022-06-20 20:20:19.500248
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.sysctl import SYSCTL_VIRTUALIZATION_TEST_DATA
    import json
    result = FreeBSDVirtual().get_virtual_facts()
    print(json.dumps(result, indent=2))
    sysctl_virtualization_test_data = SYSCTL_VIRTUALIZATION_TEST_DATA()
    # Each test case produces a result with the structure:
    # {
    #    'virtual_facts': {
    #        'virtualization_type': 'TYPE',
    #        'virtualization_role': 'ROLE',
    #        ...
    #        'virtualization_tech_guest':
    #        [
    #            'TECH1',
    #            'TECH2',
    #            'TECHN

# Generated at 2022-06-20 20:20:21.314060
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Ensure specification of FreeBSDVirtual is correct
    assert FreeBSDVirtual.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:26.795448
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector != object
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'



# Generated at 2022-06-20 20:20:35.896022
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    import json

    # Read test data
    with open('tests/unit/module_utils/facts/virtual/FreeBSD_test_data.json', 'r') as test_data:
        data = json.load(test_data)

    # Define test variables
    p = FreeBSDVirtual()

    # Valid test case
    p.sysctl = {
        'hw.hv_vendor': 'BHYVE',
        'kern.vm_guest': 'BSD_bhyve',
        'security.jail.jailed': 0,
        'hw.model': 'Test model',
        'hw.vendor': 'Test vendor'
    }

    # Execute the code to be tested
    facts = p.get_virtual_facts()

    # Define expected result

# Generated at 2022-06-20 20:20:45.164263
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ..facts.virtual import facts_module

    hostvars_in = dict(
        ansible_facts=dict(
            kern_vm_guest='',
            hw_hv_vendor='',
            security_jail_jailed='',
            hw_model='(Rack Server)'
            )
        )


# Generated at 2022-06-20 20:20:48.444500
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.virtualization_type == ''
    assert f.virtualization_role == ''
    assert f.virtualization_system == ''

# Generated at 2022-06-20 20:20:50.487179
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'



# Generated at 2022-06-20 20:20:53.105027
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual.__class__.__name__ == 'FreeBSDVirtual'
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:22:03.381395
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDFacts = FreeBSDVirtualCollector()
    except:
        assert 0, 'Failed to create instance of FreeBSDVirtualCollector'


# Generated at 2022-06-20 20:22:04.590972
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:08.120850
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Test constructor of class FreeBSDVirtualCollector'''
    # Test '_fact_class' attribue of VirtualCollector
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    # Test '_platform' attribue of VirtualCollector
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:19.321000
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    stdout_jail = 'security.jail.jailed: 0\n'
    stdout_vm_guest = 'kern.vm_guest: xf5\n'
    stdout_hw_hv_vendor = 'hw.hv_vendor: unknown\n'
    stdout_hw_model = 'hw.model: FreeBSD\n'

    v = FreeBSDVirtual({}, {}, {'sysctl': {'security.jail.jailed': stdout_jail,
                                           'kern.vm_guest': stdout_vm_guest,
                                           'hw.hv_vendor': stdout_hw_hv_vendor,
                                           'hw.model': stdout_hw_model}})

# Generated at 2022-06-20 20:22:23.708260
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual
# End of unit test for constructor of class FreeBSDVirtualCollector


# Generated at 2022-06-20 20:22:29.420907
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts_dict = dict()
    freebsd_virtual = FreeBSDVirtual(facts_dict, None)
    freebsd_virtual.collect()
    assert getattr(freebsd_virtual, 'platform') == 'FreeBSD'
    assert getattr(freebsd_virtual, '_platform') == 'FreeBSD'
    assert getattr(freebsd_virtual, '_fact_class') == FreeBSDVirtual


# Generated at 2022-06-20 20:22:31.274578
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert isinstance(fv, FreeBSDVirtual)
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:32.302867
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()

    assert virtual
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:33.390088
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-20 20:22:42.273121
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create the FreeBSDVirtual instance
    fbv = FreeBSDVirtual()

    # Mock the sysctl_get method
    fbv.sysctl_get = lambda x: {
        'kern.vm_guest': 'vmware',
        'hw.hv_vendor': 'OpenBSD',
        'security.jail.jailed': 1,
        'hw.model': 'Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz'
    }.get(x, None)

    # Set the virtualization_type to the empty string
    fbv.virtualization_type = ''

    # Call the get_virtual_facts method
    facts = fbv.get_virtual_facts()

    # Assert that virtualization_type has the correct value