

# Generated at 2022-06-20 20:14:15.689447
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    pass

# Generated at 2022-06-20 20:14:16.727874
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:14:27.747852
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb = FreeBSDVirtual()
    # Mock sysctl output, with special cases tested here:
    # xen, jailed, OpenVZ, VMware, VirtualBox
    mock_sysctl = {
        'kern.vm_guest': 'xen',
        'hw.hv_vendor': 'OpenVZ',
        'hw.model': 'VirtualBox',
        'security.jail.jailed': '1',
        'security.jail.name': 'foo',
    }
    virtual_facts = fb._test_get_virtual_facts(mock_sysctl)
    assert virtual_facts['virtual'] is True
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:14:29.614559
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)


# Generated at 2022-06-20 20:14:31.503924
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:14:42.135470
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    virtual.populate()
    assert virtual.facts['virtualization_type'] == ''
    assert virtual.facts['virtualization_role'] == ''
    assert len(virtual.facts['virtualization_tech_guest'])  == 0
    assert len(virtual.facts['virtualization_tech_host']) == 0

    assert len(virtual.facts['virtualization_technologies_guest'])  == 0
    assert len(virtual.facts['virtualization_technologies_host']) == 0
    assert virtual.facts['is_virtual'] == ''

    assert virtual.facts['virtualization_virt_type'] == ''
    assert virtual.facts['virtualization_product_name'] == ''
    assert virtual.facts['virtualization_product_version'] == ''

# Generated at 2022-06-20 20:14:43.827100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import doctest
    doctest.testmod(FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:14:46.316434
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:50.907885
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test that returns virtual facts for FreeBSD.
    """
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] in ('', 'xen')
    assert facts['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-20 20:14:52.458939
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:00.553074
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    m = Virtual()
    m._get_distribution = lambda: {'name': 'FreeBSD', 'version': '11.0'}
    vm = FreeBSDVirtual(m)
    assert vm.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:10.892854
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class Object(object):
        pass
    sysctl_vmm = Object()
    sysctl_vmm.hw_vmm_vcpu_count = '0'
    sysctl_vmm.hw_vmm_guest = '0'
    sysctl_vmm.security_jail_param_jail_jailed = '0'
    sysctl_vmm.kern_vm_guest = 'guest_unknown'
    sysctl_vmm.hw_model = 'FreeBSD/amd64'
    virtual = FreeBSDVirtual(sysctl_vmm)


# Generated at 2022-06-20 20:15:20.066477
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create a FreeBSDVirtual class object
    virtual_facts_obj = FreeBSDVirtual()

    virtual_facts = virtual_facts_obj.get_virtual_facts()

    # The following two lines are for unit test purpose only.
    # They are used to make the environment the same as the real environment
    # and make the unit test result more accurate.
    # We should remove them in the future when we improve the unit test framework.
    virtual_facts_obj.module.params['gather_subset'] = ['all']
    virtual_facts_obj.module._config = dict((k, None) for k in ('gather_subset', 'gather_timeout', 'gather_network_resources'))

    # Unit test
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:15:24.568618
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts()

# Generated at 2022-06-20 20:15:26.448994
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform == 'FreeBSD'
    assert result._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:30.950737
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert hasattr(virtual_collector, '_fact_class')
    assert hasattr(virtual_collector, '_platform')
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:15:32.881970
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSDVirtual.get_virtual_facts returns dict
    assert isinstance(FreeBSDVirtual({}).get_virtual_facts(), dict)

# Generated at 2022-06-20 20:15:37.822627
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    os_info = {'kernel': 'FreeBSD', 'version': '12.0-RELEASE'}
    virtual_facts = FreeBSDVirtual(os_info)
    assert virtual_facts.os_info == os_info

# Generated at 2022-06-20 20:15:40.814717
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert fv is not None
    assert fv.platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:52.004960
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # We create a new instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Mock sysctl's sysctl_method function
    def sysctl_method_mock(self, name, *args, **kwargs):
        if name == 'kern.vm_guest':
            return 'other'
        elif name == 'hw.hv_vendor':
            return 'unknown'
        elif name == 'security.jail.jailed':
            return '0'
        elif name == 'hw.model':
            return 'QEMU Virtual CPU version 2.1.0'
        else:
            return ''

    freebsd_virtual.sysctl = freebsd_virtual.sysctl_method_mock(sysctl_method_mock)

    # Mock os.path.exists function

# Generated at 2022-06-20 20:15:59.719602
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None, None, None, None, None)
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.virtual_facts == {}


# Generated at 2022-06-20 20:16:03.597883
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector([])
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:04.693399
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facter = FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:16:06.065287
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:16:11.372381
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_collector = FreeBSDVirtualCollector()
    virtual_collector.collect()
    virtual_facts = virtual_collector.get_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:16:13.533276
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert isinstance(freebsd_virtual, FreeBSDVirtual)

# Generated at 2022-06-20 20:16:15.855145
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:16:18.543826
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    my_fbsdvirt = FreeBSDVirtual()
    assert type(my_fbsdvirt) == FreeBSDVirtual

# Generated at 2022-06-20 20:16:20.292186
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:27.235504
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys

    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    # The sys.modules here is a clever trick so that
    # the collector can be tested without actually
    # having to collect the value from the system
    sys.modules[VirtualCollector.__module__] = VirtualCollector
    sys.modules[FreeBSDVirtual.__module__] = FreeBSDVirtual

    fv = FreeBSDVirtual()
    ve_facts = fv.get_virtual_facts()
    assert 'virtualization_type' in ve_facts
    assert 'virtualization_role' in ve_facts

# Generated at 2022-06-20 20:16:37.797538
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    current_os = FreeBSDVirtual()
    assert current_os.platform == "FreeBSD"

# Generated at 2022-06-20 20:16:42.386685
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb = FreeBSDVirtual()
    facts = fb.get_virtual_facts()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:16:53.147661
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Arrange
    virtual_file_wrapper = [
        {
            'sysctl_filepath': '/dev/xen/xenstore',
            'content': ''
        }
    ]
    virtual_sysctl_wrapper = [
        {
            'subsystem': 'kern',
            'property': 'vm_guest',
            'content': 'freebsd'
        },
        {
            'subsystem': 'hw',
            'property': 'hv_vendor',
            'content': 'Bhyve'
        },
        {
            'subsystem': 'security',
            'property': 'jail.jailed',
            'content': '1'
        }
    ]
    virtual_uname_wrapper = [
        {
            'uname': 'FreeBSD'
        }
    ]


# Generated at 2022-06-20 20:16:54.199628
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:16:56.739571
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_facts = FreeBSDVirtual()
    freebsd_facts = freebsd_virtual_facts.populate()

    assert freebsd_facts['virtualization_type']
    assert freebsd_facts['virtualization_role']

# Generated at 2022-06-20 20:17:00.716343
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual(None)
    facts_dict = virt.get_virtual_facts()
    assert isinstance(facts_dict, dict)
    assert 'virtualization_type' in facts_dict
    assert 'virtualization_role' in facts_dict
    # kern.vm_guest is unset so kern.vm_guest.vmm is the empty string.
    assert facts_dict['virtualization_type'] == ''
    assert facts_dict['virtualization_role'] == ''

# Generated at 2022-06-20 20:17:03.649540
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    virtual_facts_expected = {'virtualization_type': '', 'virtualization_role': ''}
    virtual_facts = FreeBSDVirtual.get_virtual_facts()
    assert virtual_facts == virtual_facts_expected

# Generated at 2022-06-20 20:17:04.735296
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:06.621717
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert v.get_virtual_facts()['virtualization_type'] == ''
    assert v.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:17:07.694116
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd_virtual = FreeBSDVirtual()
    assert isinstance(bsd_virtual, FreeBSDVirtual)
    assert bsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:19.140305
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:21.859194
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_bsd = FreeBSDVirtual(dict())
    assert "FreeBSD" == virtual_bsd.platform

# Generated at 2022-06-20 20:17:28.682982
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    import io
    import mock

    virtual_facts = {}

    # Mock sysctl
    mock_machdep_cpu_hw_cpuid = mock.MagicMock(return_value='2')
    mock_kern_features = mock.MagicMock(return_value='0x1b')
    mock_kern_vm_guest = mock.MagicMock(return_value='5')
    mock_hw_hv_vendor = mock.MagicMock(return_value='QEMU')
    mock_hw_hv_8 = mock.MagicMock(return_value='0')
    mock_security_jail_jailed = mock.MagicMock(return_value='0')

# Generated at 2022-06-20 20:17:30.705068
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:39.893616
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def mock_facts(name, mod=None):
        sysctl_founded_facts = {'kern.vm_guest': 'vmware'}
        hw_hv_vendor_founded_facts = {'hw.hv_vendor': 'BHYVE'}
        sec_jail_jailed_founded_facts = {'security.jail.jailed': '0'}
        hw_model_founded_facts = {'hw.model': 'Supercomputer'}
        facts = {}
        facts.update(sysctl_founded_facts)
        facts.update(hw_hv_vendor_founded_facts)
        facts.update(sec_jail_jailed_founded_facts)
        facts.update(hw_model_founded_facts)
        return facts.get(name)

    f = FreeBSD

# Generated at 2022-06-20 20:17:45.606635
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Constructor of class FreeBSDVirtual should create all class variables
    """
    fv = FreeBSDVirtual()
    assert fv.virtualization_type == ''
    assert fv.virtualization_role == ''
    assert fv.virtualization_tech_guest == set()
    assert fv.virtualization_tech_host == set()

# Generated at 2022-06-20 20:17:47.790025
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-20 20:17:59.480693
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    kvmg = {
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(),
        'virtualization_product_name': 'qemu',
        'virtualization_type': 'kvm',
    }
    kvmh = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['kvm']),
        'virtualization_product_name': 'qemu',
        'virtualization_type': 'kvm',
    }

# Generated at 2022-06-20 20:18:03.583237
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:06.177082
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, VirtualCollector)
    assert isinstance(f._fact_class, FreeBSDVirtual)
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:28.102405
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionParams


# Generated at 2022-06-20 20:18:29.863044
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'
    assert FreeBSDVirtualCollector().fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:18:33.250936
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import facts

    # Test constructor of class Virtual
    bsd_virtual_obj = facts.FreeBSDVirtualCollector().collect()[0]
    assert isinstance(bsd_virtual_obj, FreeBSDVirtual)

# Generated at 2022-06-20 20:18:37.337996
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    openbsd_virtual = FreeBSDVirtual()
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.facts['virtualization_type'] == 'openvzh'

# Generated at 2022-06-20 20:18:41.947704
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    expected_output = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_technology": set([])
    }
    fbsd_virt = FreeBSDVirtual()
    output = fbsd_virt.get_virtual_facts()
    assert output == expected_output

# Generated at 2022-06-20 20:18:43.986888
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()

    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:47.253589
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.vendor == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:59.976037
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    import os, platform

# Generated at 2022-06-20 20:19:03.274848
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtualInfo = FreeBSDVirtual()
    assert virtualInfo.platform == 'FreeBSD'
    assert virtualInfo.get_virtual_facts()['virtualization_type'] == ''
    assert virtualInfo.get_virtual_facts()['virtualization_role'] == ''
    assert virtualInfo.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtualInfo.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:19:04.329395
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(dict()).platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:26.109519
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }
    virtual = FreeBSDVirtual(module=None)
    result = virtual.get_virtual_facts()

    assert result == expected_virtual_facts

# Generated at 2022-06-20 20:19:28.712135
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_obj = FreeBSDVirtual({}, {})
    assert isinstance(virtual_facts_obj, Virtual)
    assert isinstance(virtual_facts_obj, VirtualSysctlDetectionMixin)

# Generated at 2022-06-20 20:19:30.377511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.collect() == FreeBSDVirtual().collect_virtual_facts()

# Generated at 2022-06-20 20:19:32.227147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:39.824008
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This test requires a FreeBSD environment to be functional
    # Test with a FreeBSD 10.3 virtual machine with bhyve on FreeNAS 9.10
    args = dict()
    args['ansible_facts'] = dict()
    args['ansible_facts']['system'] = dict()
    args['ansible_facts']['system']['kernel'] = 'FreeBSD'

    virtual = FreeBSDVirtual(args)
    ret = virtual.get_virtual_facts()

    assert ret['virtualization_type'] == 'bhyve'
    assert ret['virtualization_role'] == 'guest'
    assert 'bhyve' in ret['virtualization_tech_guest']
    assert 'freenas' in ret['virtualization_tech_host']

# Generated at 2022-06-20 20:19:40.827294
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual



# Generated at 2022-06-20 20:19:42.406015
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_instance = FreeBSDVirtualCollector()
    assert facts_instance.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:44.111114
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert isinstance(f, FreeBSDVirtual)



# Generated at 2022-06-20 20:19:45.728477
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:52.265352
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Test FreeBSDVirtual.get_virtual_facts()"""
    facts = FreeBSDVirtual({}, {}).get_virtual_facts()

    assert facts['virtualization_type'] in ('', 'xen')
    assert isinstance(facts['virtualization_role'], str)
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:20:09.729964
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_fact_collector = FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:20:10.577853
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:12.300489
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    # Test that instance is subclass of Virtual
    assert isinstance(virtual, Virtual)

# Generated at 2022-06-20 20:20:14.836156
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:20:16.589134
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    FreeBSDVirtual - get_virtual_facts()
    '''

    # Add code for testing here
    pass

# Generated at 2022-06-20 20:20:24.148638
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # test case:
    # kern.vm_guest = (jail, bhyve)
    # hw.hv_vendor = (bhyve)
    # security.jail.jailed = 0
    # hw.model = VMware virtual platform
    f = FreeBSDVirtual()
    f.module.sysctl_exists_dict = {'kern.vm_guest': True, 'hw.hv_vendor': True,
                                   'security.jail.jailed': True, 'hw.model': True}

# Generated at 2022-06-20 20:20:28.862734
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    test_object = FreeBSDVirtual()
    assert test_object.platform == 'FreeBSD'
    assert test_object.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': ''
    }


# Generated at 2022-06-20 20:20:31.971122
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_dict = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts_dict['virtualization_type'] == ''
    assert virtual_facts_dict['virtualization_role'] == ''

# Generated at 2022-06-20 20:20:39.237425
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBsd_virtual = FreeBSDVirtual({})
    assert isinstance(FreeBsd_virtual, FreeBSDVirtual)
    assert isinstance(FreeBsd_virtual, Virtual)
    assert isinstance(FreeBsd_virtual, VirtualCollector)
    assert FreeBsd_virtual.platform == 'FreeBSD'
    assert FreeBsd_virtual.virtualization_type == ''
    assert FreeBsd_virtual.virtualization_role == ''

# Generated at 2022-06-20 20:20:48.730230
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.collector.freebsd import \
        FreeBSDHardware

    fhw_collector = FreeBSDHardware()
    fhw_collector.collect()
    freebsd_virtual = FreeBSDVirtual(fhw_collector.facts)
    freebsd_virtual.get_virtual_facts()

    freebsd_virtual.facts['virtualization_type'] = 'xen'
    freebsd_virtual.facts['virtualization_role'] = 'guest'
    freebsd_virtual.facts['virtualization_tech_guest'] = set(['xen'])
    freebsd_virtual.facts['virtualization_tech_host'] = set()

    assert freebsd_virtual.facts['virtualization_type'] == 'xen'
   

# Generated at 2022-06-20 20:21:24.844115
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    keys = set(['virtualization_type', 'virtualization_role'])
    assert keys == set(facts.keys())

# Generated at 2022-06-20 20:21:26.581839
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:21:30.067331
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    test_FreeBSDVirtual = FreeBSDVirtual()

    # Unit test for virtualization_type
    assert test_FreeBSDVirtual.virtualization_type in ('', 'xen')
    # Unit test for virtualization_role
    assert test_FreeBSDVirtual.virtualization_role in ('', 'guest')


if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-20 20:21:33.524627
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_collector = FreeBSDVirtualCollector()
    virtual_facts = virtual_collector.collect()['ansible_facts']['ansible_virtualization_facts']
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:21:36.135632
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_all_facts()
    assert 'virtualization_role' in virtual_facts.data


# Generated at 2022-06-20 20:21:37.281042
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass

# Generated at 2022-06-20 20:21:39.131727
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-20 20:21:40.643546
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._platform == "FreeBSD"

# Generated at 2022-06-20 20:21:43.288166
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_class = FreeBSDVirtual
    platform = 'FreeBSD'
    f = FreeBSDVirtualCollector(fact_class, platform)
    assert f._fact_class == fact_class
    assert f._platform == platform

# Generated at 2022-06-20 20:21:50.859117
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    facts = basic.AnsibleModule(argument_spec=[], supports_check_mode=True)
    fb_virtual = FreeBSDVirtual(facts, None)

    virtual_facts = fb_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_tech_guest' in virtual_facts.keys()
    assert 'virtualization_tech_host' in virtual_facts.keys()

# Generated at 2022-06-20 20:23:02.708406
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Verify that FreeBSDVirtualCollector instance can be constructed."""
    fv = FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:23:05.737422
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    assert issubclass(FreeBSDVirtual, Virtual)
    assert isinstance(FreeBSDVirtual, VirtualSysctlDetectionMixin)
    assert isinstance(collector.get_platform_facts()['virtualization'], FreeBSDVirtual)

# Generated at 2022-06-20 20:23:11.960021
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Constructor test with no argument
    obj = FreeBSDVirtual()
    assert obj.platform == 'FreeBSD'

    # Constructor test with different platform argument
    obj = FreeBSDVirtual(platform='linux')
    assert obj.platform == 'linux'

    # Constructor test with no argument
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:13.974980
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._fact_class.platform == 'FreeBSD'
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:23.631958
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test default behavior, FreeBSDVirtual() should return a FreeBSDVirtual object
    fbsd_virtual_obj = FreeBSDVirtual()

    # Test __init__() is a Virtual subclass
    assert issubclass(fbsd_virtual_obj.__class__, Virtual)

    # Test __init__() is a VirtualSysctlDetectionMixin subclass
    assert issubclass(
        fbsd_virtual_obj.__class__,
        VirtualSysctlDetectionMixin,
    )

    # Test __init__() is a VirtualCollector subclass
    assert issubclass(
        fbsd_virtual_obj.__class__,
        VirtualCollector,
    )

    # Test __init__() is a FreeBSDVirtualCollector subclass

# Generated at 2022-06-20 20:23:30.753765
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual([])
    # Arrange
    facts = {}
    facts['kernel'] = 'FreeBSD'
    # Act
    v.populate(None, facts)
    # Assert
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert list(virtual_facts['virtualization_tech_guest']) == ['xen']
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:23:33.239345
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector()._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-20 20:23:35.717731
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None, None, None)
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:23:36.975838
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:23:47.301359
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual_obj = FreeBSDVirtual()

    # Mock sysctl output with:
    # - 'security.jail.jailed=0'
    # - 'hw.model=Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz'
    # - 'hw.hv_vendor=BHYVE'
    # - 'kern.vm_guest=none'
    freebsd_virtual_obj.sysctl_output = dict(security_jail_jailed='0',
                                             hw_model='Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz',
                                             hw_hv_vendor='BHYVE',
                                             kern_vm_guest='none')

    #