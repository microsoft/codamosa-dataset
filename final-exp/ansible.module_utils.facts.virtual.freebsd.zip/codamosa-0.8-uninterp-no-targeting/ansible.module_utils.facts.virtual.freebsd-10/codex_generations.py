

# Generated at 2022-06-20 20:14:11.910613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:16.020399
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """

    """
    virtualCollector = FreeBSDVirtualCollector()
    assert virtualCollector.platform == "FreeBSD"
    assert virtualCollector._fact_class == FreeBSDVirtual
    assert virtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:17.479260
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:27.951294
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlModule
    import logging

    test_obj = FreeBSDVirtual()
    test_obj.logger = logging.getLogger('FreeBSDVirtualCollector')
    test_obj.logger.setLevel(logging.CRITICAL)
    test_obj.sysctl = VirtualSysctlModule()
    test_obj.sysctl.sysctl_facts = {'hw.hv_vendor': 'bhyve'}

    assert 'bhyve' in test_obj.get_virtual_facts()['virtualization_type']

# Generated at 2022-06-20 20:14:40.343700
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}
    host_tech.add('xen')
    host_tech.add('kvm')
    guest_tech.add('xen')
    guest_tech.add('qemu')
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_host'] = host_tech
    virtual_facts['virtualization_tech_guest'] = guest_tech

# Generated at 2022-06-20 20:14:43.981254
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)
    assert isinstance(virtual_collector._fact_class(), Virtual)
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:47.135795
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v._platform == 'FreeBSD'
    assert v._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:54.693588
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import get_virtual_facts
    from ansible.module_utils.facts.virtual.sysctl import set_virtual_facts

    for jail in [True, False]:
        set_virtual_facts(jail=jail)
        virtual_facts = get_virtual_facts()
        assert 'virtualization_type' in virtual_facts
        assert 'virtualization_type' in virtual_facts
        assert 'virtualization_role' in virtual_facts


# Generated at 2022-06-20 20:15:07.777225
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    unit test for get_virtual_facts method
    """
    freebsd_virtual = FreeBSDVirtual()

    # Set a product/vendor key
    freebsd_virtual.sysctl['kern.vm_guest'] = 'vmware'
    freebsd_virtual.sysctl['hw.hv_vendor'] = 'vmware'
    freebsd_virtual.sysctl['security.jail.jailed'] = 0

    # Set another product key
    freebsd_virtual.sysctl['hw.model'] = 'VMWare Virtual Platform'

    # Call to get_virtual_facts with a known input
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Asserts
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-20 20:15:12.778132
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    # For testing, return an empty dict
    # This will be enhanced as more testing is added
    module.exit_json(ansible_facts={})



# Generated at 2022-06-20 20:15:18.237623
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:23.724068
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ret = FreeBSDVirtual({}).get_virtual_facts()
    assert set(ret.keys()) == set(('virtualization_role', 'virtualization_type',
                                   'virtualization_tech_guest',
                                   'virtualization_tech_host'))
    assert ret['virtualization_tech_host'] == set()
    assert ret['virtualization_tech_guest'] == set()
    assert ret['virtualization_role'] == ''
    assert ret['virtualization_type'] == ''

# Generated at 2022-06-20 20:15:26.449598
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Ensure the constructor works
    virtual = FreeBSDVirtual({})
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''

# Generated at 2022-06-20 20:15:28.573819
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == "FreeBSD"

# Generated at 2022-06-20 20:15:32.642786
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_freebsd_virtual = FreeBSDVirtual({})
    assert mock_freebsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:15:45.011515
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_type'] in ['xen', '', '']
    assert virtual_facts['virtualization_role'] in ['guest', '', '']
    virtualization_tech_guest = virtual_facts['virtualization_tech_guest']
    virtualization_tech_host = virtual_facts['virtualization_tech_host']
    assert 'xen' in virtualization_tech_guest
    assert 'jail' in virtualization_tech_guest
    assert 'bhyve'

# Generated at 2022-06-20 20:15:56.186411
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''

    class MockFreeBSDVirtual(FreeBSDVirtual):
        '''Mock class'''
        def __init__(self, module):
            pass

        def detect_virt_product(self, key):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

        def detect_virt_vendor(self, key):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    fact = {}
    collect_data = {}

    # test: kern.vm_guest = guest && hw.hv_vendor = guest && security.jail.jailed = not_jailed
    fact['kernel'] = 'FreeBSD'

# Generated at 2022-06-20 20:15:59.135462
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()

    # Check FreeBSD defaults
    assert f.platform == 'FreeBSD'
    assert f.get_virtual_facts() == {}

# Generated at 2022-06-20 20:16:00.126285
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(None).platform == 'FreeBSD'

# Generated at 2022-06-20 20:16:11.526423
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlVirtualizationVendorMixin
    import os

    class MockedFreeBSDVirtual(FreeBSDVirtual, VirtualSysctlDetectionMixin, VirtualSysctlVirtualizationVendorMixin):
        pass

    mocked_freebsd_virtual = MockedFreeBSDVirtual()

    mocked_freebsd_xen_virtual_candidate = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
    }

    mocked

# Generated at 2022-06-20 20:16:22.470367
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup
    instance = FreeBSDVirtual()
    instance.get_sysctl_facts = lambda *a, **kw: {
        'hw.model': 'VirtualBox'
    }
    # Execute
    virtual_facts = instance.get_virtual_facts()
    # Assert
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:16:28.478300
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is hack to make the module think it is running on a FreeBSD machine.
    import sys
    sys.platform = 'freebsd11'

    # Create a new object of class FreeBSDVirtual
    obj = FreeBSDVirtual()

    # Object should return a dictionary of virtualization facts
    facts = obj.get_virtual_facts()
    assert type(facts) is dict

# Generated at 2022-06-20 20:16:31.161625
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    v = FreeBSDVirtual({})
    assert v.platform == 'FreeBSD'
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''

# Generated at 2022-06-20 20:16:37.857782
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

    fbsd_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
    }
    assert virt.get_virtual_facts() == fbsd_facts



# Generated at 2022-06-20 20:16:47.042081
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    ####################################################
    # Unit test for virtualization_type and virtualization_role
    ####################################################
    # Test case 1 - non-virtualized FreeBSD
    test_data_1 = None
    # Fact class
    fact_cls = FreeBSDVirtualCollector()
    fact_cls.detect_virt_product = lambda x: None
    fact_cls.detect_virt_vendor = lambda x: None
    virtual_facts = fact_cls.get_virtual_facts(test_data_1)
    assert virtual_facts['virtualization_type'] == '',\
        "virtualization_type should be ''"
    assert virtual_facts['virtualization_role'] == '',\
        "virtualization_role should be ''"
    # Test case 2 - virtualized FreeBSD guest

# Generated at 2022-06-20 20:16:50.775769
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert 'FreeBSDVirtualCollector' == FreeBSDVirtualCollector.__name__
    assert VirtualCollector == FreeBSDVirtualCollector.__bases__[0]
    assert 'FreeBSD' == FreeBSDVirtualCollector._platform
    assert FreeBSDVirtual == FreeBSDVirtualCollector._fact_class
    assert not FreeBSDVirtualCollector._has_platform_for_provider


# Generated at 2022-06-20 20:16:52.164360
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bc = FreeBSDVirtualCollector()
    assert bc.platform == 'FreeBSD'
    assert bc.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:58.179747
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_technology_guest'] = set()
    virtual_facts['virtualization_technology_host'] = set()

    f = FreeBSDVirtual({})
    x = f.get_virtual_facts()
    assert x == virtual_facts


# Generated at 2022-06-20 20:17:02.802645
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    import unittest.mock

    facts = {}
    plugin = FreeBSDVirtual(facts, [], None)
    assert plugin._platform == 'FreeBSD'
    assert plugin._sysctl_kern_vm_guest == 'kern.vm_guest'
    assert plugin._sysctl_hw_hv_vendor == 'hw.hv_vendor'
    assert plugin._sysctl_sec_jail_jailed == 'security.jail.jailed'
    assert plugin._virtual_vendor_facts_product == 'hw.model'
    assert plugin._virtual_vendor_facts_type == 'hw.machine'
    assert plugin._virtual_vendor_facts_type == 'hw.machine'



# Generated at 2022-06-20 20:17:03.719244
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f is not None

# Generated at 2022-06-20 20:17:09.388947
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test the constructor and methods of the FreeBSDVirtualCollector class.
    """
    # Create a FreeBSDVirtualCollector object
    fvc = FreeBSDVirtualCollector()

    # There is not really a lot to test here, as the VirtualCollector
    # constructor has no function.


# Generated at 2022-06-20 20:17:11.767985
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.populate()
    assert virtual_facts.get('virtualization_type') == ''



# Generated at 2022-06-20 20:17:18.222005
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual_obj = FreeBSDVirtual()
    fbsd_virtual_obj.module = None
    fbsd_virtual_obj._connection = None
    fbsd_virtual_obj.get_virtual_facts()
    assert fbsd_virtual_obj.facts
    assert not fbsd_virtual_obj.module

# Generated at 2022-06-20 20:17:27.569746
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:17:30.704804
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.get_all() == {}

# Generated at 2022-06-20 20:17:33.842190
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    FreeBSDVirtualCollector.__init__
    '''
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:17:36.565973
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fcol = FreeBSDVirtualCollector()
    assert fcol.platform == 'FreeBSD', "platform is not FreeBSD"
    assert isinstance(fcol.get_virtual_facts(), dict)

# Generated at 2022-06-20 20:17:41.958963
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    frbsd = FreeBSDVirtual()
    assert frbsd
    # FreeBSD will always have 'FreeBSD' in its sys.platform, but Windows
    # can also have this value returned, so it is necessary to test against
    # 'freebsd' to detect the operating system. This is the same method
    # used in the module_utils/facts/virtual/base.py class.
    assert frbsd.platform == 'freebsd'
    assert frbsd.virtualization._name == 'FreeBSD'
    assert repr(frbsd.virtualization) == "<freebsd.FreeBSDVirtual object at 0x%x>" % (id(frbsd.virtualization))
    assert frbsd.virtualization.__str__() == "virtualization_facts"
    assert frbsd.virtualization.get_virtual_facts()

# Generated at 2022-06-20 20:17:43.318001
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:17:46.183126
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.__class__.__name__ == 'FreeBSDVirtual'


# Generated at 2022-06-20 20:17:56.003897
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # obj = FreeBSDVirtualCollector()
    # assert obj.platform == 'FreeBSD'
    assert True


# Generated at 2022-06-20 20:17:57.903551
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class == FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:02.107529
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:18:06.467489
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert 'hvm' in virtual_facts['virtualization_tech_guest']
    assert 'linux' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:18:14.108798
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Check for values for virtual_facts in LinuxVirtual().get_virtual_facts()
    '''
    # check for values for virtual_facts in FreeBSDVirtual().get_virtual_facts()
    # Need to create a class object
    virtual_facts_obj = FreeBSDVirtual()

    # check virtual_facts value
    virtual_facts = virtual_facts_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:18:16.156216
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector().collect()
    assert facts['virtualization_type'] == 'xen' or not facts['virtualization_type']

# Generated at 2022-06-20 20:18:20.084874
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual(None)
    assert virt.platform == 'FreeBSD'
    assert virt.virtualization_type is None
    assert virt.virtualization_role is None
    assert virt.virtualization_tech_guest.__class__.__name__ == 'set'
    assert virt.virtualization_tech_host.__class__.__name__ == 'set'

# Generated at 2022-06-20 20:18:27.827388
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    raw_data = {'module_setup': True}
    test_object = FreeBSDVirtual(raw_data)
    facts = {'virtualization_type': '',
             'virtualization_role': '',
             'virtualization_tech_host': set(),
             'virtualization_tech_guest': set()
            }

    def test_execute_module(self):
        return {'rc': 0, 'stdout': 'test'}

    test_object.execute_module = test_execute_module.__get__(test_object, FreeBSDVirtual)

    test_object.get_virtual_facts()

# Generated at 2022-06-20 20:18:36.381387
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bvirt = FreeBSDVirtual()
    assert isinstance(bvirt, Virtual)
    assert isinstance(bvirt, VirtualSysctlDetectionMixin)
    assert hasattr(bvirt, 'platform')
    assert bvirt.platform == 'FreeBSD'
    assert hasattr(bvirt, 'get_virtual_facts')

    bvirt.platform = 'GNU/kFreeBSD'
    # test platform=GNU/kFreeBSD
    bvirt.module = MagicMock()
    bvirt.module.run_command.return_value = (0, '', '')
    # Guest
    bvirt.module.run_command.side_effect = ['', '']
    bvirt.facts['kernel'] = 'OpenBSD'
    result = bvirt.get_virtual_facts()

# Generated at 2022-06-20 20:18:39.769413
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual()
    virtual_facts = facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:19:10.752367
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    f = FreeBSDVirtual({'ansible_facts': facts})
    # User running on baremetal with FreeBSD
    assert 'virtualization_tech_host' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_type' not in facts
    assert f.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': '', 'virtualization_type': ''}

# Generated at 2022-06-20 20:19:12.464199
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-20 20:19:13.560790
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:16.500779
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    _facts = FreeBSDVirtualCollector.collect()
    assert "virtualization_type" in _facts

# Generated at 2022-06-20 20:19:21.609774
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    expected_result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }
    freebsd = FreeBSDVirtual()

    assert freebsd.data == expected_result

# Generated at 2022-06-20 20:19:26.227783
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.get_virtual_facts() == dict(
        virtualization_role='',
        virtualization_type='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set())
    assert virtual_facts.platform == 'FreeBSD'



# Generated at 2022-06-20 20:19:35.797052
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    facter_facts = {}
    fact_file = open("tests/unit/module_utils/facts/virtual/FreeBSD/virtual", encoding='utf-8')
    for fact in fact_file:
        fact_value = fact.split("=")
        facter_facts[fact_value[0].strip()] = fact_value[1].strip()
    fact_file.close()

    fact_class = FreeBSDVirtual(facter_facts, facts)
    facter_facts = fact_class.get_virtual_facts()
    assert facter_facts['virtualization_type'] == 'xen'
    assert facter_facts['virtualization_role'] == 'guest'
    assert 'xen' in facter_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:19:42.189990
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.bsd import FreeBSDVirtual
    _test_freebsdvirtual = FreeBSDVirtual({})
    # Test if each of the virtualization facs is empty string
    assert _test_freebsdvirtual.virtual == ''
    assert _test_freebsdvirtual.virt_what == ''
    assert _test_freebsdvirtual.product_name == ''
    assert _test_freebsdvirtual.role == ''
    assert _test_freebsdvirtual.type == ''
    assert _test_freebsdvirtual.version == ''
    assert _test_freebsdvirtual.is_guest is False
    assert _test_freebsdvirtual.is_host is False

# Generated at 2022-06-20 20:19:47.374223
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    virtual_facts_expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['xen']),
    }
    assert virtual_facts_expected == virtual_facts

# Generated at 2022-06-20 20:19:55.684222
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class TestObj:
        pass

    test_obj = TestObj()
    test_obj.facts = {}

    # Define expected value
    expected_value = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
    }

    # Get virtual facts
    virtual_facts = FreeBSDVirtual(test_obj, '', '').get_virtual_facts()

    # Check virtual facts
    assert virtual_facts['virtualization_type'] == expected_value['virtualization_type']
    assert virtual_facts['virtualization_role'] == expected_value['virtualization_role']

# Generated at 2022-06-20 20:21:02.256285
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual()
    testobj.get_virtual_facts()

# Generated at 2022-06-20 20:21:03.423801
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-20 20:21:04.872578
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector

# Generated at 2022-06-20 20:21:06.747135
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == ''


# Generated at 2022-06-20 20:21:13.359661
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert type(facts) is dict
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert type(facts['virtualization_tech_guest']) is set
    assert type(facts['virtualization_tech_host']) is set

# Generated at 2022-06-20 20:21:15.324264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert hasattr(obj, '_fact_class')
    assert hasattr(obj, '_platform')
    assert obj._platform == 'FreeBSD'
    assert isinstance(obj._fact_class, (FreeBSDVirtual, object))

# Generated at 2022-06-20 20:21:27.066620
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Prepare virtualization facts
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}

    # Test for FreeBSD sysctl facts

# Generated at 2022-06-20 20:21:33.585543
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test input data
    tested_data = {
        '/dev/xen/xenstore': os.path.exists('/dev/xen/xenstore'),
        'kern.vm_guest': 'unknown',
        'hw.hv_vendor': 'unknown',
        'security.jail.jailed': '0',
        'hw.model': 'VirtualBox',
    }
    # Test function
    test_object = FreeBSDVirtual()
    result = test_object.get_virtual_facts()

    for key, value in tested_data.items():
        assert key in result
        assert result[key] == value

# Generated at 2022-06-20 20:21:35.528963
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:21:38.648444
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  assert FreeBSDVirtualCollector._platform == 'FreeBSD'
  assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
  assert isinstance(FreeBSDVirtualCollector._fact_class, object)

# Generated at 2022-06-20 20:24:00.735069
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc is not None

# Generated at 2022-06-20 20:24:04.479420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual
    assert collector.detect_facts() == [FreeBSDVirtual]