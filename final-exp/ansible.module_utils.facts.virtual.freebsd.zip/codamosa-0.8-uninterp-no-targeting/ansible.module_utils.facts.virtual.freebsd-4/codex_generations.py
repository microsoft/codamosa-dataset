

# Generated at 2022-06-20 20:14:13.964041
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert isinstance(fv, FreeBSDVirtual)



# Generated at 2022-06-20 20:14:25.921236
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test empty sysctl output
    kern_vm_guest_output = {'hw': {}, 'security': {'jail': {'jailed': ''}}, 'kern': {'vm_guest': ''}}
    hw_hv_vendor_output = {'hw': {'hv_vendor': ''}}
    sec_jail_jailed_output = {'security': {'jail': {'jailed': ''}}, 'kern': {'vm_guest': ''}, 'hw': {'hv_vendor': ''}}


# Generated at 2022-06-20 20:14:27.233334
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-20 20:14:32.030593
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual.platform == "FreeBSD"
    assert virtual._fact_class == FreeBSDVirtual
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:35.319215
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({'ansible_facts': {}})
    assert freebsd_virtual.sysctl_facts == {}
    assert freebsd_virtual.hardware_facts == {}

# Generated at 2022-06-20 20:14:37.729168
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd_virtual = FreeBSDVirtual()
    assert bsd_virtual.platform == 'FreeBSD'
    assert bsd_virtual.guest_facts is None

# Generated at 2022-06-20 20:14:44.389006
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual(module=None)
    # Save current value of Python's __dicthash__ magic attribute
    __dicthash__ = FreeBSDVirtual.__dicthash__

    # Python's __dicthash__ attribute must be set to None for the following test
    # For Python >= 3.3 it has no effect, for Python 2.6 it will deactivate the
    # built-in string truncation of virtual_facts to 20 bytes, allowing to
    # test all cases
    FreeBSDVirtual.__dicthash__ = None

    # Test that get_virtual_facts() returns dict
    assert isinstance(freebsd_virtual.get_virtual_facts, dict)
    # Test that correct virtualization_type is returned
    assert 'virtualization_type' in freebsd_virtual.get_virtual_facts


# Generated at 2022-06-20 20:14:45.346608
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc
    assert fvc._fact_class
    assert fvc._platform

# Generated at 2022-06-20 20:14:56.495816
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert v.guests is None
    assert v.host_type is None
    assert v.hypervisor_type is None
    assert v.is_guest is None
    assert v.is_hypervisor is None
    assert v.is_linux_guest is None
    assert v.is_linux_system is None
    assert v.is_xen is None
    assert v.virt_product_name is None
    assert v.virt_product_version is None
    assert v.virt_product_serial is None
    assert v.virtualization is None
    assert v.virtualization_role is None
    assert v.virtualization_type is None
    assert v.virtualization_system is None
    assert v.virtualization_uuid is None
    assert v

# Generated at 2022-06-20 20:14:58.136344
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-20 20:15:06.118264
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual('sysctl', 'hw.model')
    assert virtual.platform == 'FreeBSD'
    assert virtual.facts_module == 'sysctl'
    assert virtual.product_name == 'hw.model'



# Generated at 2022-06-20 20:15:13.962462
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_collector = FreeBSDVirtualCollector({}, None)
    freebsd_virtual = FreeBSDVirtual({}, freebsd_virtual_collector)
    # Testing default value of virtualization_type and virtualization_role for
    # FreeBSD host machine
    assert freebsd_virtual.get_virtual_facts() == {
        'virtualization_type': '', 'virtualization_role': ''
    }

# Generated at 2022-06-20 20:15:15.493172
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_module_args({})
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:15:17.269854
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:26.253907
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Expected results
    results_xen_guest = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest'
    }
    results_hyperv_host = {
        'virtualization_type': 'hyperv',
        'virtualization_role': 'host'
    }
    results_kvm_guest = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }
    results_vmware_host = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'host'
    }
    results_jail_guest = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest'
    }
    results_bhyve_

# Generated at 2022-06-20 20:15:31.212437
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtualizer = FreeBSDVirtual({})
    virtual_facts = virtualizer.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:15:33.725255
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Unit test for constructor of class FreeBSDVirtualCollector
    '''
    virtual_collector = FreeBSDVirtualCollector()

    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:39.844465
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({}, {})
    assert issubclass(FreeBSDVirtual, Virtual)
    assert issubclass(FreeBSDVirtual, VirtualSysctlDetectionMixin)
    assert isinstance(v, Virtual)
    assert v.platform == 'FreeBSD'
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''



# Generated at 2022-06-20 20:15:43.918957
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    assert FreeBSDVirtual().get_virtual_facts() == virtual_facts

# Generated at 2022-06-20 20:15:53.278862
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(module=None)
    assert facts.get_virtual_facts().get('virtualization_type') == ''
    assert facts.get_virtual_facts().get('virtualization_role') == ''
    assert str(facts.get_virtual_facts().get('virtualization_tech_guest')) == 'set([])'
    assert str(facts.get_virtual_facts().get('virtualization_tech_host')) == 'set([])'
    assert str(facts.get_virtual_facts().get('virtualization_vendor')) == 'set([])'
    assert facts.get_virtual_facts().get('virtualization_product') is None


# Generated at 2022-06-20 20:16:05.069364
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    # result of get_virtual_facts() for some FreeBSD versions
    # (FreeBSD 12.1 amd64 and FreeBSD 11.3 amd64)
    result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    v.get_virtual_facts()
    assert v.virtual_facts == result

# Generated at 2022-06-20 20:16:07.370586
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc.fact_class == FreeBSDVirtual


# Generated at 2022-06-20 20:16:09.525720
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    assert type(v.get_virtual_facts()) == dict

# Generated at 2022-06-20 20:16:11.350500
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:18.018565
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor test of FreeBSDVirtualCollector class
    """
    module = {}
    collected_facts = {}

    # create an instance of FreeBSDVirtualCollector
    virt_collector = FreeBSDVirtualCollector(module=module, facts=collected_facts)

    assert virt_collector._platform == 'FreeBSD'
    assert virt_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:18.713160
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:16:23.195141
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual({})
    result = testobj.get_virtual_facts()
    assert result['virtualization_type'] in ['', 'xen']
    assert result['virtualization_role'] in ['', 'guest']
    assert result['virtualization_technologies'] in [None, [], ['xen']]

# Generated at 2022-06-20 20:16:31.455183
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual(None)

    assert freebsd_virtual.sysctl is not None
    assert hasattr(freebsd_virtual, '_fallback_detection_methods')
    assert len(freebsd_virtual._fallback_detection_methods) == 0

    # Test that FreeBSDVirtual._detect_virtualization_type() is set
    # to FreeBSDVirtual.detect_virtualization_type()
    assert freebsd_virtual.detect_virtualization_type \
        == freebsd_virtual._detect_virtualization_type


# Generated at 2022-06-20 20:16:32.520751
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == "FreeBSD"

# Generated at 2022-06-20 20:16:43.991708
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    This function is used to test the FreeBSDVirtual constructor
    """
    virtual_sysctl = {
        'virtualization_tech_host': set(['jail']),
        'virtualization_tech_guest': set(['jail']),
        'virtualization_role': 'host'
    }

    virtual_vendor = {
        'virtualization_tech_host': set(['vbox']),
        'virtualization_tech_guest': set(['vbox']),
        'virtualization_type': 'vbox',
        'virtualization_role': 'guest'
    }

    test_obj = FreeBSDVirtual(virtual_sysctl, virtual_vendor)
    assert test_obj.virtualization_type == 'vbox'
    assert test_obj.virtualization_role == 'guest'
    assert test

# Generated at 2022-06-20 20:16:58.634140
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl = {'kern.vm_guest': 'Other', 'hw.hv_vendor': 'BHYVE',
              'security.jail.jailed': 1}
    model = 'GenuineIntel'

    freebsd_virtual_collector = FreeBSDVirtual(sysctl, model)

    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'bhyve'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = {'bhyve'}
    virtual_facts['virtualization_tech_host'] = set()

    assert freebsd_virtual_collector.get_virtual_facts() == virtual_facts

# Generated at 2022-06-20 20:17:00.415383
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-20 20:17:01.504582
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.collect()
    assert FreeBSDVirtualCollector.fetch_virtual_facts()

# Generated at 2022-06-20 20:17:05.402872
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbvirtual = FreeBSDVirtual()
    assert fbvirtual.platform == 'FreeBSD'
    assert fbvirtual.get_virtual_facts()['virtualization_type'] == ''
    assert fbvirtual.get_virtual_facts()['virtualization_role'] == ''
    assert fbvirtual.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert fbvirtual.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:17:12.628252
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()

    # assert 'virtualization_type' and 'virtualization_role'
    # 'virtualization_type' is ultimately set here
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'xen'

    # 'virtualization_role' is ultimately set here, but it was
    # previously set in virtual_sysctl_detection
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:17:15.003600
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:17:18.167704
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:17:25.376331
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual = FreeBSDVirtual({})
    bsd_virtual_facts = bsd_virtual.get_virtual_facts()
    assert(isinstance(bsd_virtual_facts['virtualization_type'], str))
    assert(isinstance(bsd_virtual_facts['virtualization_role'], str))
    assert(isinstance(bsd_virtual_facts['virtualization_tech_guest'], set))
    assert(isinstance(bsd_virtual_facts['virtualization_tech_host'], set))

# Generated at 2022-06-20 20:17:38.192325
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.virtual.sysctl import _get_sysctl_facts
    from ansible.module_utils.facts.virtual.sysctl import _get_sysctl_vals

    class MockSysctl():
        def __init__(self, return_value):
            self.return_value = return_value

        def get(self, param, default=None):
            return self.return_value.get(param, default)

    class MockVirtVendor():
        def __init__(self, return_value):
            self.return_value = return_value

        def get(self, param):
            return self.return_value


# Generated at 2022-06-20 20:17:49.635706
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-20 20:18:21.873874
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    fact_data = FreeBSDVirtualCollector(None, None).collect()
    assert fact_data.keys() == {'virtualization_role', 'virtualization_type', 'virtualization_tech_host', 'virtualization_tech_guest'}
    assert fact_data['virtualization_role'] in {'guest', 'host'}

    assert type(fact_data) is dict
    assert type(fact_data['virtualization_role']) is str
    assert type(fact_data['virtualization_type']) is str
    assert type(fact_data['virtualization_tech_host']) is set

# Generated at 2022-06-20 20:18:23.900273
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:26.649218
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector.platform == 'FreeBSD'
    assert facts_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:30.096377
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    facts = virtual_facts.get_virtual_facts()
    assert facts['virtualization_type'] in ('', 'xen')
    assert facts['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-20 20:18:33.794863
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._platform == 'FreeBSD'
    assert x.collect()['ansible_facts']['virtualization_type'] != ''
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:37.126168
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:18:44.454145
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup
    set_module_args({})
    set_module_args({})
    virtual_facts_obj = FreeBSDVirtual()

    # Act
    virtual_facts = virtual_facts_obj.get_virtual_facts()

    # Assert
    assert virtual_facts['virtualization_type'] == '', \
        "virtualization_type is not a empty string"
    assert virtual_facts['virtualization_role'] == '', \
        "virtualization_role is not a empty string"

# Generated at 2022-06-20 20:18:46.430445
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 20:18:59.300903
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from unittest import TestCase
    from ansible.module_utils.facts.virtual import FreeBSDVirtual

    class test_FreeBSDVirtual_get_virtual_facts(TestCase):
        def setUp(self):
            self.module = FreeBSDVirtual()
            # VirtualSysctlDetectionMixin needs to set its own sysctl
            self.module.sysctl = {}

        def test_empty(self):
            self.module.sysctl['kern.vm_guest'] = 'none'
            self.module.sysctl['hw.hv_vendor'] = ''
            self.module.sysctl['security.jail.jailed'] = 0
            self.module.sysctl['hw.model'] = ''

# Generated at 2022-06-20 20:19:01.216689
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'
    assert fb.module_name == 'ansible_facts.virtual.FreeBSDVirtual'


# Generated at 2022-06-20 20:20:17.888589
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] in ['', 'xen', 'jail', 'vm', 'parallels', 'virtualbox', 'vmware', 'kvm', 'hyperv', 'docker']
    assert freebsd_virtual_facts['virtualization_role'] in ['', 'guest', 'host']
    assert freebsd_virtual_facts['virtualization_tech_guest'] in [[], ['xen'], ['jail'], ['vm', 'docker'], ['parallels'], ['virtualbox', 'parallels'], ['vmware'], ['kvm'], ['hyperv'], ['docker']]

# Generated at 2022-06-20 20:20:27.322876
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # make sure Virtual instance has no facts before testing
    virtual_facts = FreeBSDVirtual()
    assert not virtual_facts.get_facts()

    # always stubs the sysctl command
    mocked_sysctl = {
        'kern.vm_guest': (0, 'none', ''),
        'hw.hv_vendor': (0, 'None', ''),
        'security.jail.jailed': (0, '0', ''),
    }

    # always stubs the dmesg command
    mocked_dmesg_lines = ("Hypervisor detected: None\n", 0, '')

    # always stubs the system_profiler command
    mocked_system_profiler_lines = ("Not a virtual machine\n", 0, '')

    # set the sysctl command stub

# Generated at 2022-06-20 20:20:31.443254
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # test case 1: correctly generate a FreeBSDVirtualCollector object
    sample_fact_class = FreeBSDVirtualCollector(None, None, None)
    assert sample_fact_class._fact_class.platform == 'FreeBSD'
    assert sample_fact_class._platform == 'FreeBSD'

# Generated at 2022-06-20 20:20:37.738471
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:20:38.644066
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_FreeBSD = FreeBSDVirtual(None, None)

# Generated at 2022-06-20 20:20:41.498046
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    virtual_facts_list = virtual_facts.get_virtual_facts()
    assert virtual_facts_list['virtualization_type'] == ''
    assert virtual_facts_list['virtualization_role'] == ''

# Generated at 2022-06-20 20:20:42.522660
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert VirtualCollector.get_platform('FreeBSD') == FreeBSDVirtualCollector

# Generated at 2022-06-20 20:20:45.065787
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:20:50.519821
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = Virtual().get_virtual_facts()
    assert 'sysctl' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-20 20:20:53.195982
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = Virtual()
    virtual_facts.populate()
    assert virtual_facts['virtualization_type'] != ''

# Generated at 2022-06-20 20:23:13.724848
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt_facts = virt.get_virtual_facts()
    assert type(virt_facts) == dict
    assert type(virt_facts['virtualization_tech']) == set


# Generated at 2022-06-20 20:23:14.904258
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:22.560872
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual class to test `get_virtual_facts`
    # method.
    freebsd_virtual = FreeBSDVirtual()

    # Patch the method `get_file_content` of class `FreeBSDVirtual` to always
    # return an empty string. This will force the test case to only test
    # sysctl detection instead of file detection.
    from unittest import mock
    with mock.patch.object(freebsd_virtual, 'get_file_content') as \
            get_file_content_mock:
        get_file_content_mock.return_value = b''

        # Test if `get_virtual_facts` returns expected values for physical
        # machine.
        virtual_facts = freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:23:25.202713
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert 'FreeBSDVirtualCollector' == FreeBSDVirtualCollector.__name__
    assert 'FreeBSD' == FreeBSDVirtualCollector._platform

# Generated at 2022-06-20 20:23:28.556554
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech == set()

# Generated at 2022-06-20 20:23:32.749055
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_fact = FreeBSDVirtual()
    virtual_facts = virtual_fact.get_virtual_facts()
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:23:33.657276
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = VirtualCollector._platforms['FreeBSD']()
    assert isinstance(result, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:23:44.079572
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock facts
    facts = {'virtualization_type': '',
             'virtualization_role': ''}

    # Mock sysctl data
    kern_vm_guest = {'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    hw_hv_vendor = {'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}
    sec_jail_jailed = {'virtualization_tech_guest': set(),
                       'virtualization_tech_host': set()}

    # Mock hw.model data
    virtual_vendor_facts = {'virtualization_tech_guest': set(),
                            'virtualization_tech_host': set()}

    # Mock FreeBSDVirtualCollector's methods
    mock_free

# Generated at 2022-06-20 20:23:46.992427
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    frebsd_virtual = FreeBSDVirtual(None, None)
    assert frebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:48.101936
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.get_all() == {}