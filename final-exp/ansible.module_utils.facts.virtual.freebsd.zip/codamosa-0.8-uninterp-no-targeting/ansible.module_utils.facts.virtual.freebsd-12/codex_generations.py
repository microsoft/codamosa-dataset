

# Generated at 2022-06-20 20:14:16.805486
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts
    assert type(virtual_facts) is dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:14:27.780425
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def mock_os_path_exists(path):
        if path == '/dev/xen/xenstore':
            return True
        return False

    def mock_detect_virt_product(sysctl, virt_type):
        if sysctl == 'kern.vm_guest':
            return {'virtualization_type': virt_type,
                    'virtualization_role': '',
                    'virtualization_tech_host': set(),
                    'virtualization_tech_guest': set()}
        elif sysctl == 'hw.hv_vendor':
            return {'virtualization_type': virt_type,
                    'virtualization_role': '',
                    'virtualization_tech_host': set(),
                    'virtualization_tech_guest': set()}

# Generated at 2022-06-20 20:14:33.655131
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test instantiation
    freebsd_virtual = FreeBSDVirtualCollector()

    # Test platform attribute
    assert freebsd_virtual.platform == 'FreeBSD'

    # Test _fact_class attribute
    assert freebsd_virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:14:44.979074
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    def _get_virtual_facts(kern_vm_guest_result, hw_hv_vendor_result,
                           sec_jail_jailed_result, hw_model_result):
        test = FreeBSDVirtual()

        virtual_facts = {}

        kern_vm_guest = VirtualSysctlDetectionMixin.detect_virt_product('kern.vm_guest')
        virtual_facts.update(kern_vm_guest)
        virtual_facts['virtualization_tech_guest'].update(kern_vm_guest_result)

        hw_hv_vendor = VirtualSysctlDetectionMixin.detect_virt_product('hw.hv_vendor')
        virtual_facts.update(hw_hv_vendor)

# Generated at 2022-06-20 20:14:48.423978
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # This is a sanity check for the constructor of class FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:14:50.621866
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    try:
        virtual = FreeBSDVirtual(None)
        assert virtual
    except:
        assert False

# Generated at 2022-06-20 20:14:52.178230
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-20 20:14:57.105824
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:05.804610
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_class = Virtual
    mock_class.platform = 'FreeBSD'
    mock_class.is_jail = True
    mock_class.has_ebtables = True
    mock_class.get_sysctl.return_value = 'vmware'
    mock_class.shell_command.return_value = (0,'personal')
    type = mock_class.get_virtual_facts()
    assert type['virtualization_type'] == 'kvm'
    assert type['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:15:10.644679
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSDVirtual.get_virtual_facts() returns a dictionary of virtual
    # facts or an empty dictionary.
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 20:15:16.242655
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = Virtual('FreeBSD')
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:17.948841
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert 'virtualization_type' in virtual.get_virtual_facts()

# Generated at 2022-06-20 20:15:19.809896
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == "FreeBSD"

# Generated at 2022-06-20 20:15:23.690776
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Constructor for class FreeBSDVirtual.
    '''
    bsd = FreeBSDVirtual()
    assert bsd.platform == 'FreeBSD'

# Generated at 2022-06-20 20:15:26.394422
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector(None, None, FreeBSDVirtual)
    assert (fv is not None)
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-20 20:15:32.690267
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({}, {})
    res = v.get_virtual_facts()
    assert res['virtualization_type'] == '', 'Virtualization type should be empty'
    assert res['virtualization_role'] == '', 'Virtualization role should be empty'
    assert not res['virtualization_tech_host'], \
        'Virtualization tech host should be empty'
    assert not res['virtualization_tech_guest'], \
        'Virtualization tech guest should be empty'

# Generated at 2022-06-20 20:15:37.344930
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact = FreeBSDVirtualCollector.fetch_virtual_facts()
    assert fact.get('virtualization_type') == 'xen'
    assert fact.get('virtualization_role') == 'guest'

# Generated at 2022-06-20 20:15:39.315946
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-20 20:15:42.118325
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of FreeBSDVirtualCollector class
    """
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:15:53.171469
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=unused-argument, unused-variable
    def fake_sysctl(module, params):
        if params['name'] in (
                'security.jail.jailed',
                'hw.model',
                'hw.hv_vendor'):
            return True, {params['name']: 'fake_value'}

        return True, {params['name']: 'none'}

    def fake_get_file_content(path, module, persist_files=False):
        if path.endswith('/sbin/dmidecode'):
            return True, 'fake_output'

        return True, ''

    def fake_uname_result(module):
        return True, '9.3-PRERELEASE'


# Generated at 2022-06-20 20:16:13.342617
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts_output = dict()
    fact_name = 'virtualization_type'
    fact_expected_output = 'xen'
    facts_output[fact_name] = fact_expected_output
    fact_name = 'virtualization_role'
    fact_expected_output = 'guest'
    facts_output[fact_name] = fact_expected_output
    fact_name = 'virtualization_tech_guest'
    fact_expected_output = ['xen']
    facts_output[fact_name] = fact_expected_output
    fact_name = 'virtualization_tech_host'
    fact_expected_output = []
    facts_output[fact_name] = fact_expected_output
    virtual_obj = FreeBSDVirtual()

# Generated at 2022-06-20 20:16:20.573486
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_facts = FreeBSDVirtual().get_virtual_facts()
    assert host_facts['virtualization_type'] in ['', 'Xen']
    assert host_facts['virtualization_role'] in ['', 'guest']
    assert host_facts['virtualization_tech_guest'] in [set(), set(['xen'])]
    assert host_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:16:23.081112
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd = FreeBSDVirtual()

    # Not using assertIsInstance to keep compatible with Python 2.6
    assert isinstance(bsd, FreeBSDVirtual)


# Generated at 2022-06-20 20:16:26.487088
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = dict()
    virtual = FreeBSDVirtualCollector(facts, None)
    assert virtual.platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:16:29.206520
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsdvirtual = FreeBSDVirtualCollector()
    if not freebsdvirtual:
        raise AssertionError(
            "Can't create FreeBSDVirtualCollector instance")

# Generated at 2022-06-20 20:16:33.963353
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    my_virtual = FreeBSDVirtual({}, None)
    assert my_virtual.platform == 'FreeBSD'
    assert 'virtualization_role' in my_virtual.facts
    assert 'virtualization_type' in my_virtual.facts
    assert 'virtualization_technologies_guest' in my_virtual.facts
    assert 'virtualization_technologies_host' in my_virtual.facts

# Generated at 2022-06-20 20:16:41.443572
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(module=None).get_virtual_facts()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert type(virtual_facts['virtualization_tech_host']) == set
    assert type(virtual_facts['virtualization_tech_guest']) == set

# Generated at 2022-06-20 20:16:42.224740
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert(len(FreeBSDVirtual().get_virtual_facts()) > 0)

# Generated at 2022-06-20 20:16:48.693518
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """ Test get_virtual_facts method of FreeBSDVirtual class """
    # Test empty facts
    bsdvirt = FreeBSDVirtual({})
    result = bsdvirt.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert not result['virtualization_tech_guest']
    assert not result['virtualization_tech_host']

# Generated at 2022-06-20 20:16:56.231369
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import mock
    import platform

    # get_virtual_facts is not compatible with Python 3, so we need to call
    # get_virtual_facts from a mocked FreeBSDVirtual class
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual as FreeBSDVirtualMock

    # We also need to mock a platform.system() returning 'FreeBSD'
    with mock.patch.object(platform, 'system', return_value='FreeBSD'):

        # Test empty values
        with mock.patch.object(FreeBSDVirtualMock, 'get_sysctl_value', side_effect=(False, False, False)):
            virtual_facts = FreeBSDVirtualMock(mock.MagicMock()).get_virtual_facts()
            assert virtual_facts['virtualization_type'] == ''
            assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:17:26.918758
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    fbsd_virtual = FreeBSDVirtual()

    # Test non-vhost and non-guest
    # Create a VirtualSysctlDetectionMixin object to mock the methods
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    sysctl = VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:17:36.651420
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    # Query system information using class FreeBSDVirtual
    fbsd_virtual = FreeBSDVirtual()
    virtual_facts = fbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == '' \
        or virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == '' \
        or virtual_facts['virtualization_role'] == 'guest'
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:17:42.121456
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # OpenBSD tests
    vd = FreeBSDVirtual({})
    virtual_facts = vd.get_virtual_facts()
    assert virtual_facts['ansible_virtualization_type'] == ''
    assert virtual_facts['ansible_virtualization_role'] == ''
    assert virtual_facts['ansible_virtualization_role'] == ''
    assert virtual_facts['ansible_virtualization_type'] == ''
    assert not virtual_facts['ansible_virtualization_tech_guest']
    assert not virtual_facts['ansible_virtualization_tech_host']

# Generated at 2022-06-20 20:17:50.819658
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import FreeBSDVirtual
    from ansible.module_utils.facts.utils import get_file_content
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.sysctl = {'kern.vm_guest': 'other', 'hw.hv_vendor': 'vmware', 'security.jail.jailed': '0'}
    freebsd_virtual.hw_model = 'Intel(R) Xeon(R) CPU E5-2690 v3 @ 2.60GHz'
    if os.path.exists('/dev/xen/xenstore'):
        content = get_file_content('/dev/xen/xenstore')
        if content is not None:
            assert 'xen' in freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:17:59.770377
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Define instance of FreeBSDVirtual class
    freebsd_virtual = FreeBSDVirtual()
    # Set instance variables with the get_virtual_facts
    freebsd_virtual.get_virtual_facts()
    # Test virtualization_type
    virtualization_facts = freebsd_virtual.virtualization_type
    assert isinstance(virtualization_facts, type(''))
    # Test virtualization_role
    virtualization_facts = freebsd_virtual.virtualization_role
    assert isinstance(virtualization_facts, type(''))
    # Test virtualization_technologies
    virtualization_facts = freebsd_virtual.virtualization_tech_host
    assert isinstance(virtualization_facts, type(set()))

# Generated at 2022-06-20 20:18:03.230689
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    free_bsd_virtual = FreeBSDVirtual()
    assert isinstance(free_bsd_virtual, Virtual)

# Generated at 2022-06-20 20:18:07.057213
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None, None, None)
    assert virtual.__dict__ == {
        '_platform': 'FreeBSD',
        '_summary': {},
        'module': None,
        'sysctl': None,
        'sysctl_all': None
    }

# Generated at 2022-06-20 20:18:08.809823
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-20 20:18:13.809222
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual
    os_type = x.get_virtual_facts()['virtualization_type']
    assert os_type in ['', 'xen']

# Generated at 2022-06-20 20:18:24.762106
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector(): # pylint: disable=invalid-name
    '''
    Test the constructor of class FreeBSDVirtualCollector
    '''
    # Test for constructor with one parameter
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector), 'Failed to create FreeBSDVirtualCollector object'
    assert isinstance(obj._platform, str), 'Incorrect _platform data type'
    assert obj._platform == 'FreeBSD', "Failed to assign FreeBSD to _platform"
    assert isinstance(obj._fact_class, type), 'Incorrect _fact_class data type'
    assert obj._fact_class == FreeBSDVirtual, 'Failed to assign FreeBSDVirtual to _fact_class'

# Generated at 2022-06-20 20:19:24.924418
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-20 20:19:26.428305
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == "FreeBSD"
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:19:35.954318
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_class = FreeBSDVirtual()

    # Testing kern.vm_guest:

# Generated at 2022-06-20 20:19:42.831422
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # returned value of get_virtual_facts
    returned_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # returned value of detect_virt_product and detect_virt_vendor

# Generated at 2022-06-20 20:19:44.354707
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-20 20:19:47.057752
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    openbsd_facts = FreeBSDVirtualCollector()
    assert openbsd_facts._platform == 'FreeBSD'
    assert openbsd_facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-20 20:19:50.336641
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test if FreeBSDVirtualCollector class could be instantiated.
    """
    collector = FreeBSDVirtualCollector()
    assert collector is not None

# Generated at 2022-06-20 20:19:55.276015
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import virtual

    virtual_instance = virtual.Virtual(collector=FreeBSDVirtualCollector())

    import json
    import sys
    print(json.dumps(virtual_instance.get_virtual_facts(), indent=4, sort_keys=True))
    print(json.dumps(virtual_instance.get_all_facts(), indent=4, sort_keys=True))

# Generated at 2022-06-20 20:19:59.294053
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == "xen"
    assert facts['virtualization_role'] == "guest"
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-20 20:20:09.121706
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test FreeBSDVirtualCollector"""
    if not os.path.exists('/dev/xen/xenstore'):
        os.mkdir('/dev/xen')
        os.mknod('/dev/xen/xenstore')
    kwargs = {'_module': None,
              '_platform': 'FreeBSD',
              '_mount_points': None,
              '_module_path': ''}
    f = FreeBSDVirtualCollector(**kwargs)
    assert f.get_all_facts()['virtualization_type'] == 'xen'

# Generated at 2022-06-20 20:22:31.686429
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # data from kern.vm_guest
    data1 = {
        '\nkern.vm_guest: none': b'none',
        '\nkern.vm_guest: vmm': b'vmm',
        '\nkern.vm_guest: bhyve': b'bhyve',
        '\nkern.vm_guest: hyperv': b'hyperv',
        '\nkern.vm_guest: jail': b'jail',
        '\nkern.vm_guest: xen': b'xen',
    }
    # data from hw.hv_vendor

# Generated at 2022-06-20 20:22:33.318483
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbsd_virtual_collector = FreeBSDVirtualCollector()
    assert fbsd_virtual_collector is not None


# Generated at 2022-06-20 20:22:41.961466
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Data is a json object containing the sysctl query results of a freebsd machine and
    # the content of hw.model and hw.vendor
    data = {
        'hw.vendor': '',
        'hw.model': 'VMware Virtual Platform',
        'kern.vm_guest': 'none',
        'hw.hv_vendor': '',
        'security.jail.jailed': '0'
    }

    facts = FreeBSDVirtual().get_virtual_facts(data)

    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert 'vmware' in facts['virtualization_tech_guest']
    assert len(facts['virtualization_tech_host']) == 0

# Generated at 2022-06-20 20:22:55.049474
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is a simple test based on an example of a FreeBSD virtual machine
    # that is hosted on a FreeBSD server.
    sysctl_output = b"""
kern.vm_guest: bhyve
hw.hv_vendor: bhyve
hw.hv_vm_guest: bhyve
security.jail.jailed: 0
"""
    hw_model = """
FreeBSD 12.0-ALPHA6 r347958 GENERIC amd64
"""
    c = FreeBSDVirtual(sysctl_output, hw_model)

# Generated at 2022-06-20 20:22:57.174162
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-20 20:23:00.218613
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.bsd import FreeBSDVirtual
    bsd_virtual = FreeBSDVirtual({})
    assert bsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-20 20:23:03.104389
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv._fact_class, FreeBSDVirtual)
    assert fv._platform == fv._fact_class.platform

# Generated at 2022-06-20 20:23:13.194867
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual()
    freebsd.sysctl = {'hw.model': 'VirtualBox'}
    freebsd.read_file = lambda x: 'jailed:0'
    freebsd.detect_virt_product = lambda x: {'virtualization_type': '', 'virtualization_role': '',
                                             'virtualization_tech_guest': set(),
                                             'virtualization_tech_host': set()}
    virtual_facts = freebsd.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': '', 'virtualization_role': '',
                             'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    freebsd.sysctl = {'hw.model': 'VirtualBox'}
    freebs

# Generated at 2022-06-20 20:23:21.301342
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    # Set empty values as default
    virtual.facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    # Simulate that files /dev/xen/xenstore, /sys/devices/system/cpu/vendor and
    # /sys/devices/virtual/dmi/id/product_name exist in the filesystem
    mocked_file_exists_map = {
        '/dev/xen/xenstore': True,
        '/sys/devices/system/cpu/vendor': True,
        '/sys/devices/virtual/dmi/id/product_name': True
    }
    # Set values returned by method get_file_content

# Generated at 2022-06-20 20:23:26.412042
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class FreeBSDVirtual '''
    # initialize
    fbv = FreeBSDVirtual()
    virtual_facts = {}

    # Test for set empty values as default
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts

    # Test for update kern.vm_guest
    kern_vm_guest = fbv.detect_virt_product('kern.vm_guest')
    assert 'virtualization_tech_guest' not in virtual_facts