

# Generated at 2022-06-17 02:57:51.082030
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-17 02:58:00.525602
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the virtualization_type is set to 'xen'
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'

    # Assert that the virtualization_role is set to 'guest'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'

    # Assert that the virtualization_tech_guest is set to 'xen'
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set(['xen'])

    # Assert that the virtualization_tech_host is set to 'xen'

# Generated at 2022-06-17 02:58:13.600098
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for virtualization_type and virtualization_role
    # when kern.vm_guest is 'none'
    kern_vm_guest_none = {'kern.vm_guest': 'none'}
    hw_hv_vendor_none = {'hw.hv_vendor': 'none'}
    sec_jail_jailed_none = {'security.jail.jailed': '0'}
    hw_model_none = {'hw.model': 'VirtualBox'}
    virtual_facts = FreeBSDVirtual(kern_vm_guest_none, hw_hv_vendor_none,
                                   sec_jail_jailed_none, hw_model_none).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
   

# Generated at 2022-06-17 02:58:22.277948
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }

    # Create a dictionary with the results of the get_virtual_facts method
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Compare the expected results with the results of the get_virtual_facts method
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 02:58:27.771068
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Create a FreeBSDVirtual object
    freebsd_virtual_collector._fact_class = freebsd_virtual

    # Call method get_virtual_facts of class FreeBSDVirtual
    freebsd_virtual_collector.get_virtual_facts()

# Generated at 2022-06-17 02:58:29.256533
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:32.180677
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:39.450200
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for FreeBSD jail
    jail_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set(['jail']),
    }
    # Test for FreeBSD bhyve
    bhyve_facts = {
        'virtualization_type': 'bhyve',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['bhyve']),
        'virtualization_tech_host': set(['bhyve']),
    }
    # Test for FreeBSD vmware

# Generated at 2022-06-17 02:58:42.319549
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:52.036032
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()
    # Call method get_virtual_facts of class FreeBSDVirtual
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    # Assert that the virtualization_type is 'xen'
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'
    # Assert that the virtualization_role is 'guest'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'
    # Assert that the virtualization_tech_guest is 'xen'
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set(['xen'])
    # Assert that the virtualization_tech_host is empty
    assert freebsd_virtual_facts

# Generated at 2022-06-17 02:58:57.262920
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:59.087771
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:07.461387
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a dict with the expected results
    expected_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 02:59:16.262894
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD jail
    jail_facts = {
        'security.jail.jailed': '1',
        'security.jail.name': 'testjail',
        'security.jail.path': '/jails/testjail',
        'security.jail.host.hostname': 'testhost',
        'security.jail.host.domainname': 'testdomain',
        'security.jail.host.hostuuid': 'testuuid',
    }
    freebsd_virtual = FreeBSDVirtual(jail_facts)
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 02:59:17.652740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:22.523073
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:31.742875
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Create a dict with the expected keys and values
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the dict returned by get_virtual_facts is equal to the expected dict
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 02:59:40.998339
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the virtualization_type is set to the correct value
    assert virtual_facts['virtualization_type'] == ''

    # Assert that the virtualization_role is set to the correct value
    assert virtual_facts['virtualization_role'] == ''

    # Assert that the virtualization_tech_guest is set to the correct value
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Assert that the virtualization_tech_host is set to the correct value
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:43.784474
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:47.939097
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:53.485468
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:56.818439
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:06.610493
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test case for FreeBSD virtual machine
    virtual_facts_test_case = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(['xen']),
    }
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts == virtual_facts_test_case

    # Test case for FreeBSD jail
    virtual_facts_test_case = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set(['jail']),
    }
    virtual_facts = FreeBSDVirtual

# Generated at 2022-06-17 03:00:10.855970
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:14.906264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:17.736065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD host
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:00:23.153171
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual_obj = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual_obj.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] == ''
    assert freebsd_virtual_facts['virtualization_role'] == ''
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set()
    assert freebsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:00:25.680887
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-17 03:00:35.348215
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test for virtualization_type
    assert freebsd_virtual.get_virtual_facts()['virtualization_type'] == ''

    # Test for virtualization_role
    assert freebsd_virtual.get_virtual_facts()['virtualization_role'] == ''

    # Test for virtualization_tech_guest
    assert freebsd_virtual.get_virtual_facts()['virtualization_tech_guest'] == set()

    # Test for virtualization_tech_host
    assert freebsd_virtual.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:00:42.779853
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Set the sysctl_values dictionary
    freebsd_virtual.sysctl_values = {
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': '0',
        'hw.model': 'QEMU Virtual CPU version 2.5+'
    }

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert the virtualization_type is 'bhyve'
    assert virtual_facts['virtualization_type'] == 'bhyve'

    # Assert the virtualization_role is 'guest'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:00:56.650438
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

    # Call the method get_virtual_facts of FreeBSDVirtual
    actual_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the expected results are equal to the actual results
    assert actual_virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:01:00.547312
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:06.504500
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()
    # Call method get_virtual_facts
    virtual_facts = freebsd_virtual.get_virtual_facts()
    # Assert that virtual_facts is a dict
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-17 03:01:09.453725
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:01:14.744639
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:16.224277
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:20.082853
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:23.126128
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:25.405996
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:36.502065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class MockFreeBSDVirtual(FreeBSDVirtual, VirtualSysctlDetectionMixin):
        def detect_virt_product(self, product):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

        def detect_virt_vendor(self, vendor):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    virtual_facts = MockFreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-17 03:01:54.174477
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Create a dict with the expected results
    expected_result = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
    }

    # Create a dict with the results of the get_virtual_facts method
    result = freebsd_virtual.get_virtual_facts()

    # Assert that the expected results and the results of the method are equal
    assert result == expected_result

# Generated at 2022-06-17 03:01:55.716035
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:57.201271
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:02.014758
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a dict with the expected values
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Call the method get_virtual_facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Compare the result with the expected values
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:02:04.674569
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:08.379689
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:10.955324
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:13.682717
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:02:22.548528
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Get virtual facts
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that virtualization_type is set
    assert 'virtualization_type' in freebsd_virtual_facts

    # Assert that virtualization_role is set
    assert 'virtualization_role' in freebsd_virtual_facts

    # Assert that virtualization_type is not empty
    assert freebsd_virtual_facts['virtualization_type'] != ''

    # Assert that virtualization_role is not empty
    assert freebsd_virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-17 03:02:24.772777
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:54.037426
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-17 03:02:56.714521
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:59.159367
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:01.573620
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:05.753858
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:03:09.356548
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:12.923067
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:15.460442
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:17.358882
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:21.420953
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-17 03:04:11.811072
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-17 03:04:19.923882
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test data
    test_data = {
        'hw.model': 'VirtualBox',
        'kern.vm_guest': 'other',
        'security.jail.jailed': 0,
        'hw.hv_vendor': '',
    }

    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual(module=None, facts=None)

    # Set the test data
    freebsd_virtual.sysctl = test_data

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert the virtual facts
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:04:24.639447
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:04:26.784738
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:04:28.408295
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:04:35.421481
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for empty facts
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test for virtualization_type and virtualization_role
    virtual_facts = FreeBSDVirtual(
        sysctl_output={'kern.vm_guest': 'vmware'}
    ).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])
    assert virtual_

# Generated at 2022-06-17 03:04:40.189928
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:04:47.034795
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that virtualization_type is set to 'xen'
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'

    # Assert that virtualization_role is set to 'guest'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:04:55.919350
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Get virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the virtual facts are empty
    assert virtual_facts == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Set the virtual facts
    freebsd_virtual_collector.set_virtual_facts(virtual_facts)

    # Assert that the virtual facts are set
    assert freebsd_virtual_collector.get_virtual_facts() == virtual_facts

# Generated at 2022-06-17 03:04:58.256690
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:00.117644
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-17 03:06:02.529396
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:05.974401
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:09.278303
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:20.111757
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Set virtualization_type and virtualization_role to empty string
    freebsd_virtual.virtualization_type = ''
    freebsd_virtual.virtualization_role = ''

    # Set virtualization_tech_guest and virtualization_tech_host to empty set
    freebsd_virtual.virtualization_tech_guest = set()
    freebsd_virtual.virtualization_tech_host = set()

    # Set kern_vm_guest, hw_hv_vendor and sec_jail_jailed to empty dict
    freebsd_virtual.kern_vm_guest = {}
    freebsd_virtual.hw_hv_vendor = {}

# Generated at 2022-06-17 03:06:21.594953
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:23.709582
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-17 03:06:28.680169
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:06:32.552360
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:34.383525
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:07:32.587184
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:07:38.790467
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, sysctl_name):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

        def detect_virt_vendor(self, sysctl_name):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    virtual_facts = MockFreeBSDVirtual().get_virtual_facts()


# Generated at 2022-06-17 03:07:39.864624
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:07:42.393184
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:07:44.079626
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f.fact_class == FreeBSDVirtual