

# Generated at 2022-06-17 02:57:52.340657
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:01.005084
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD jail
    jail_facts = {
        'kern.vm_guest': 'jail',
        'hw.hv_vendor': '',
        'security.jail.jailed': '1',
        'hw.model': '',
    }
    jail_virtual_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set(),
    }
    assert FreeBSDVirtual(jail_facts).get_virtual_facts() == jail_virtual_facts

    # Test with a FreeBSD bhyve

# Generated at 2022-06-17 02:58:02.725649
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:13.895984
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    fbsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    fbsd_virtual_collector = FreeBSDVirtualCollector()

    # Create a dict with the expected results
    expected_results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Call get_virtual_facts of FreeBSDVirtual object
    results = fbsd_virtual.get_virtual_facts()

    # Assertion
    assert results == expected_results

# Generated at 2022-06-17 02:58:19.631826
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:21.771452
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-17 02:58:28.102043
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a dict with the expected results
    expected_facts = {'virtualization_type': '',
                      'virtualization_role': '',
                      'virtualization_tech_guest': set(),
                      'virtualization_tech_host': set()}

    # Call the method get_virtual_facts
    actual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the expected results match the actual results
    assert actual_facts == expected_facts

# Generated at 2022-06-17 02:58:29.861536
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:31.480909
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:44.054077
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for FreeBSD jail
    jail_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set([])
    }
    test_facts = {
        'security.jail.jailed': 1,
        'hw.model': 'FreeBSD'
    }
    test_obj = FreeBSDVirtual(test_facts)
    assert test_obj.get_virtual_facts() == jail_facts

    # Test for FreeBSD bhyve

# Generated at 2022-06-17 02:58:57.264195
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for FreeBSD virtualization facts
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert freebsd_virtual_facts['virtualization_tech_host'] == set()

    # Test for FreeBSD virtualization facts
    freebsd_virtual = FreeBSDVirtual()

# Generated at 2022-06-17 02:58:58.799790
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:04.875564
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:15.541558
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a virtualization_type of 'xen' and virtualization_role of 'guest'
    virtual_facts = FreeBSDVirtual({'kernel': 'FreeBSD'}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with a virtualization_type of 'xen' and virtualization_role of 'guest'
    virtual_facts = FreeBSDVirtual({'kernel': 'FreeBSD'}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-17 02:59:22.350471
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This function is used to test constructor of class FreeBSDVirtualCollector
    """
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:33.253559
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-17 02:59:36.253325
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-17 02:59:42.211398
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:49.002107
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:50.673415
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:00.413986
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:02.295242
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:08.944974
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:00:16.157242
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a dict with the expected virtual facts
    expected_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the expected virtual facts are equal to the actual virtual facts
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:00:17.935306
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:19.660427
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:21.346888
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-17 03:00:22.806645
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:24.484059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:27.607269
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:42.745588
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] == ''
    assert freebsd_virtual_facts['virtualization_role'] == ''
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set()
    assert freebsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:00:45.690284
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-17 03:00:47.660782
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:52.360894
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:54.135190
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:55.646125
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:04.748993
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with empty sysctl output
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with kern.vm_guest=vmware
    virtual_facts = FreeBSDVirtual({'kern.vm_guest': 'vmware'}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])

# Generated at 2022-06-17 03:01:05.839702
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:07.561122
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-17 03:01:16.916495
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up the class we are going to test
    test_class = FreeBSDVirtual()

    # Set up the test data
    test_data = {
        'kern.vm_guest': '',
        'hw.hv_vendor': '',
        'security.jail.jailed': '',
        'hw.model': '',
    }

    # Set up the expected results
    expected_results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Run the test
    results = test_class.get_virtual_facts(test_data)

    # Check the results
    assert results == expected_results

# Generated at 2022-06-17 03:01:43.560307
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:45.954051
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-17 03:01:53.710609
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Create a FreeBSDVirtual object
    freebsd_virtual_obj = freebsd_virtual_collector.collect(freebsd_virtual, None)

    # Call method get_virtual_facts of class FreeBSDVirtual
    freebsd_virtual_obj.get_virtual_facts()

# Generated at 2022-06-17 03:01:55.550701
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:57.388329
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:06.819902
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with no virtualization
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with a FreeBSD jail
    virtual_facts = FreeBSDVirtual({'ansible_product_name': 'FreeBSD'}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['jail'])
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-17 03:02:09.892067
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:14.882445
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:02:16.964689
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:20.990771
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()
    # Get virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()
    # Assert that virtualization_type is set to 'xen'
    assert virtual_facts['virtualization_type'] == 'xen'
    # Assert that virtualization_role is set to 'guest'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:03:22.378660
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for virtualization_type and virtualization_role
    # when running on a FreeBSD jail
    jail_facts = {
        'security.jail.jailed': '1',
        'hw.model': 'FreeBSD/amd64',
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'FreeBSD',
    }
    expected_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set(['FreeBSD']),
    }
    assert FreeBSDVirtual(jail_facts).get_virtual_facts() == expected_facts

    # Test for virtualization_type and virtualization_role
    # when running on

# Generated at 2022-06-17 03:03:25.072580
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:26.805235
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:31.560910
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:33.009821
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:38.510363
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in freebsd_virtual_facts
    assert 'virtualization_role' in freebsd_virtual_facts
    assert 'virtualization_tech_guest' in freebsd_virtual_facts
    assert 'virtualization_tech_host' in freebsd_virtual_facts

# Generated at 2022-06-17 03:03:43.380467
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:45.880152
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:50.241040
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:03:52.757279
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:05:49.351608
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test case 1:
    # FreeBSD is running on a physical machine
    # Expected result:
    # virtualization_type = ''
    # virtualization_role = ''
    # virtualization_tech_guest = set()
    # virtualization_tech_host = set()
    test_case_1 = {
        'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'kern.vm_guest': 'none',
        'security.jail.jailed': '0'
    }
    expected_result_1 = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    test_1 = FreeBSD

# Generated at 2022-06-17 03:05:53.413230
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:05:55.596613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:05:58.058712
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:00.305110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:07.824928
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()
    # Call method get_virtual_facts
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    # Assert that the virtualization_type is set to 'xen'
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'
    # Assert that the virtualization_role is set to 'guest'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:06:14.173894
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:06:23.837861
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with empty sysctl output
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with sysctl output for a FreeBSD jail
    virtual_facts = FreeBSDVirtual({'ansible_sysctl': {'security.jail.jailed': 1}}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['jail'])

# Generated at 2022-06-17 03:06:26.527594
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:30.232599
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()