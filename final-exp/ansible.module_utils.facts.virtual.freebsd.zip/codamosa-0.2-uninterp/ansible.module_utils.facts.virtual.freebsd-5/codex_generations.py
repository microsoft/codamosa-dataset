

# Generated at 2022-06-17 02:57:54.414830
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-17 02:57:55.990592
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:57:59.748821
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:07.554029
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    fb_virtual = FreeBSDVirtual()

    # Create a dict with the expected results
    expected_results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Get the virtual facts
    virtual_facts = fb_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_results

# Generated at 2022-06-17 02:58:08.831483
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:15.258003
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    virtual_facts = FreeBSDVirtual()

    # Test get_virtual_facts method
    virtual_facts_result = virtual_facts.get_virtual_facts()

    # Assertion: virtual_facts_result is a dict
    assert isinstance(virtual_facts_result, dict)

    # Assertion: virtual_facts_result has keys 'virtualization_type' and 'virtualization_role'
    assert 'virtualization_type' in virtual_facts_result
    assert 'virtualization_role' in virtual_facts_result

# Generated at 2022-06-17 02:58:19.826696
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual


# Generated at 2022-06-17 02:58:21.333538
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:58:24.979306
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-17 02:58:36.318533
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-17 02:58:50.394839
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for FreeBSD virtual machine
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test for FreeBSD host
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:58:52.312731
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-17 02:58:59.233280
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD jail
    jail = FreeBSDVirtual({'ansible_system': 'FreeBSD',
                           'ansible_distribution': 'FreeBSD',
                           'ansible_distribution_version': '10.3-RELEASE'})
    jail.sysctl = {'security.jail.jailed': '1',
                   'hw.model': 'Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz',
                   'kern.vm_guest': 'other'}
    jail_facts = jail.get_virtual_facts()
    assert jail_facts['virtualization_type'] == 'jail'
    assert jail_facts['virtualization_role'] == 'guest'
    assert jail_facts['virtualization_tech_host'] == set(['jail'])
    assert jail_

# Generated at 2022-06-17 02:59:00.794466
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:10.560354
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that the virtualization_type is set to a non-empty string
    assert freebsd_virtual_facts['virtualization_type'] != ''

    # Assert that the virtualization_role is set to a non-empty string
    assert freebsd_virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-17 02:59:13.065900
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 02:59:24.129750
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-17 02:59:30.991846
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:41.047905
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts() method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assertion: virtualization_type should be empty string
    assert freebsd_virtual_facts['virtualization_type'] == ''

    # Assertion: virtualization_role should be empty string
    assert freebsd_virtual_facts['virtualization_role'] == ''

    # Assertion: virtualization_tech_guest should be empty set
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set()

    # Assertion: virtualization_tech_host should be empty set
    assert freebsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:47.509259
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 02:59:57.960291
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:00.785452
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:06.235508
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts()
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assertion: virtual_facts['virtualization_type'] is not empty
    assert virtual_facts['virtualization_type'] != ''

    # Assertion: virtual_facts['virtualization_role'] is not empty
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-17 03:00:09.183071
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:18.876242
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with empty sysctl output
    virtual = FreeBSDVirtual({})
    virtual.sysctl_output = {}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Test with sysctl output for a host
    virtual = FreeBSDVirtual({})
    virtual.sysctl_output = {'kern.vm_guest': 'none',
                             'hw.hv_vendor': 'none',
                             'security.jail.jailed': '0'}
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-17 03:00:20.564509
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:21.960783
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:00:27.670191
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD host
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with a FreeBSD guest
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:00:33.493980
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Set empty values as default
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': ''}

    # Test get_virtual_facts method
    assert freebsd_virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-17 03:00:36.697692
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-17 03:00:57.210634
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:01:03.591821
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test case 1:
    # FreeBSD is running on a bare-metal machine
    # Expected result:
    # virtualization_type: ''
    # virtualization_role: ''
    # virtualization_tech_guest: set()
    # virtualization_tech_host: set()
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:01:08.601227
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test the method get_virtual_facts
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] == ''
    assert freebsd_virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-17 03:01:12.813108
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:01:14.182670
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:17.610176
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:01:23.891487
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:01:25.492307
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f._platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:27.828721
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-17 03:01:29.950989
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:54.820104
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:01:56.694902
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:00.220179
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Get virtual facts
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Check if virtual facts are correct
    assert freebsd_virtual_facts['virtualization_type'] == ''
    assert freebsd_virtual_facts['virtualization_role'] == ''
    assert freebsd_virtual_facts['virtualization_tech_guest'] == set()
    assert freebsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:02:11.786405
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with empty sysctl output
    test_obj = FreeBSDVirtual({})
    test_obj.sysctl_output = {}
    test_obj.sysctl_all_output = {}
    test_obj.sysctl_vm_guest_output = {}
    test_obj.sysctl_hw_hv_vendor_output = {}
    test_obj.sysctl_sec_jail_jailed_output = {}
    test_obj.sysctl_hw_model_output = {}
    test_obj.sysctl_hw_machine_output = {}
    test_obj.sysctl_hw_machine_arch_output = {}
    test_obj.sysctl_hw_machine_platform_output = {}
    test_obj.sysctl_hw_machine_cpu_output = {}
    test_obj.sysctl_hw_machine

# Generated at 2022-06-17 03:02:12.787569
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.get_virtual_facts()

# Generated at 2022-06-17 03:02:17.042662
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:18.357602
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:02:20.400257
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-17 03:02:26.381410
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:02:31.314881
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-17 03:03:30.250491
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Test get_virtual_facts method
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that virtual_facts is a dict
    assert isinstance(freebsd_virtual_facts, dict)

    # Assert that virtual_facts has the following keys
    assert 'virtualization_type' in freebsd_virtual_facts
    assert 'virtualization_role' in freebsd_virtual_facts
    assert 'virtualization_tech_guest' in freebsd_virtual_facts
    assert 'virtualization_tech_host' in freebsd_virtual_facts

# Generated at 2022-06-17 03:03:35.024709
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD host
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-17 03:03:35.782389
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:39.207554
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:03:44.679004
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD host
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:03:47.182568
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:49.197061
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:49.824491
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-17 03:03:52.541486
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:03:54.631440
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-17 03:05:42.330151
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:05:42.943926
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-17 03:05:45.207539
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:05:55.734983
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Get virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that virtual_facts is a dict
    assert isinstance(virtual_facts, dict)

    # Assert that virtual_facts has the keys 'virtualization_type' and
    # 'virtualization_role'
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    # Assert that virtual_facts has the keys 'virtualization_tech_guest' and
    # 'virtualization_tech_host'
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    # Assert that virtual_facts['virtualization_tech_

# Generated at 2022-06-17 03:05:57.806725
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-17 03:06:05.512679
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    fbsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    fbsd_virtual_collector = FreeBSDVirtualCollector()

    # Get the virtual facts
    fbsd_virtual_facts = fbsd_virtual.get_virtual_facts()

    # Check the virtual facts
    assert fbsd_virtual_facts['virtualization_type'] == ''
    assert fbsd_virtual_facts['virtualization_role'] == ''
    assert fbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert fbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:06:08.911569
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Create a FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Check if the virtual facts are empty
    assert virtual_facts == {}

    # Set the virtual facts
    freebsd_virtual_collector.collect()

    # Get the virtual facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Check if the virtual facts are not empty
    assert virtual_facts != {}

# Generated at 2022-06-17 03:06:12.254987
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual


# Generated at 2022-06-17 03:06:16.803144
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:06:27.136298
# Unit test for method get_virtual_facts of class FreeBSDVirtual