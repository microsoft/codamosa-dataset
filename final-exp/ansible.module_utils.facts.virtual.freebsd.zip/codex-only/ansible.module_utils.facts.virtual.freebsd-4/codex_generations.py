

# Generated at 2022-06-23 02:00:40.074313
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert isinstance(fvc._fact_class(), FreeBSDVirtual)


# Generated at 2022-06-23 02:00:42.397297
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:53.821125
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fake_module = type('obj', (object,), {})()
    virtual = FreeBSDVirtual(fake_module)

    assert(virtual.platform == 'FreeBSD')
    assert(virtual.get_all_facts() == {})
    assert(virtual.get_virtual_facts() == {'virtualization_role': '',
                                           'virtualization_type': '',
                                           'virtualization_tech_guest': set([]),
                                           'virtualization_tech_host': set([])})

# Generated at 2022-06-23 02:00:55.887532
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert issubclass(vc._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:01:01.173786
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # This is needed to not override the default OpenBSDVirtualCollector
    if os.path.isfile('/sbin/sysctl'):
        virtual_facts = FreeBSDVirtual({})
        for key, val in virtual_facts.get_virtual_facts().items():
            assert val != '', '%s is not set' % key

# Generated at 2022-06-23 02:01:10.455364
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual.facts['hw_model'] = 'VirtualBox'

    virtual.facts['kern_vm_guest'] = 'other'
    virtual.facts['hw_hv_vendor'] = ''
    virtual.facts['security_jail_jailed'] = ''

    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_technologies': ['virtualbox'],
        'virtualization_tech_guest': ['virtualbox'],
        'virtualization_tech_host': [],
    }

# Generated at 2022-06-23 02:01:13.938331
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == "FreeBSD"
    assert isinstance(facts, VirtualCollector)


# Generated at 2022-06-23 02:01:25.086473
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test get_virtual_facts without sysctl
    fact_class = FreeBSDVirtual({})
    fact_class.str2bool = lambda x:x in ['1']
    fact_class.detect_virt_product = lambda x: dict(virtualization_type='',
                                                    virtualization_role='',
                                                    virtualization_tech_guest=set(),
                                                    virtualization_tech_host=set())
    fact_class.detect_virt_vendor = lambda x: dict(virtualization_type='',
                                                   virtualization_role='',
                                                   virtualization_tech_guest=set(),
                                                   virtualization_tech_host=set())
    virtual_facts = fact_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:01:30.355165
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    # will display virtual facts if it is running on Virtual platform
    freebsd_virtual.collect()

# Generated at 2022-06-23 02:01:33.123568
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(dict())
    assert virtual_facts.platform == 'FreeBSD'
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:01:35.475458
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:39.025843
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Unit test for constructor of class FreeBSDVirtual
    """
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:41.792634
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:01:46.085914
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host = FreeBSDVirtual()
    test_virtual_facts = {'virtualization_type': 'xen',
                          'virtualization_role': 'guest',
                          'virtualization_tech_guest': {'xen'},
                          'virtualization_tech_host': set(),
                         }
    assert host.get_virtual_facts() == test_virtual_facts

# Generated at 2022-06-23 02:01:48.969977
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert type(virtual_facts) == FreeBSDVirtual


# Generated at 2022-06-23 02:01:51.676530
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test with different arch
    freebsd_virtual = FreeBSDVirtual(None, "amd64")
    assert freebsd_virtual


# Generated at 2022-06-23 02:01:54.241293
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:56.416034
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert isinstance(v, FreeBSDVirtual)


# Generated at 2022-06-23 02:01:59.760766
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:01.492266
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:05.121894
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual.platform == 'FreeBSD'
    assert virtual.fact_class._platform == 'FreeBSD'
    assert isinstance(virtual.fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:06.934708
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == "FreeBSD"


# Generated at 2022-06-23 02:02:07.586082
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:12.903001
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:14.142610
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    return x != None


# Generated at 2022-06-23 02:02:19.650835
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    expected = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert expected == FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:02:28.818802
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    facts = VirtualCollector()
    facts.collect()
    virtual_facts = facts._fact_class().get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')
    assert(virtual_facts['virtualization_tech_guest'] == set())
    assert(virtual_facts['virtualization_tech_host'] == set())
    #
    with open('/dev/xen/xenstore', 'w') as f:
        f.write('xen')
    del VirtualCollector._fact_classes[FreeBSDVirtual]

# Generated at 2022-06-23 02:02:38.512580
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert hasattr(f, 'platform')
    assert f.platform == 'FreeBSD'
    assert hasattr(f, '_fact_class')
    assert f._fact_class.platform == 'FreeBSD'
    assert hasattr(f, 'virtual')
    assert isinstance(f.virtual, FreeBSDVirtual)
    assert hasattr(f.virtual, 'module')  # Compatibility with Virtual
    assert hasattr(f.virtual, 'facts')  # Compatibility with Virtual
    assert hasattr(f.virtual, 'get_virtual_facts')  # Compatibility with Virtual
    assert hasattr(f.virtual, 'platform')  # Compatibility with Virtual
    assert hasattr(f.virtual, 'get_virtual_fact')  # Compatibility with Virtual

# Generated at 2022-06-23 02:02:39.488657
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual('foo')

# Generated at 2022-06-23 02:02:40.790622
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:45.150038
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual = FreeBSDVirtualCollector()
    assert bsd_virtual._platform == "FreeBSD"
    assert bsd_virtual._fact_class.platform == "FreeBSD"

# Generated at 2022-06-23 02:02:47.298613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:58.588251
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for FreeBSDVirtual.get_virtual_facts
    """
    # Create instance
    virtual_facts = FreeBSDVirtual()

    # We create a fake sysctl output to test method get_virtual_facts
    # See details in test_sysctl_detection_mixin.py

# Generated at 2022-06-23 02:02:59.988162
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:02.249309
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts_dict = FreeBSDVirtual()
    assert facts_dict is not None


# Generated at 2022-06-23 02:03:08.369802
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    result = dict(virtualization_type='xen',
                  virtualization_role='guest',
                  virtualization_tech_guest=set(['xen']),
                  virtualization_tech_host=set(['xen']))
    v = FreeBSDVirtual()
    v.collect_virtual_facts()
    assert v.facts == result

# Generated at 2022-06-23 02:03:10.108180
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)


# Generated at 2022-06-23 02:03:12.106675
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert hasattr(x, 'collect')



# Generated at 2022-06-23 02:03:16.934365
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsdvirtual = FreeBSDVirtual(None)
    assert freebsdvirtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}

# Generated at 2022-06-23 02:03:19.143141
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor should always create FreeBSDVirtualCollector instance
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:03:27.836167
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)



# Generated at 2022-06-23 02:03:28.549877
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv._platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:31.169248
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_subclass = FreeBSDVirtualCollector()
    assert fact_subclass.get_all_facts()

# Generated at 2022-06-23 02:03:35.079147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-23 02:03:39.824665
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.__class__.__name__ == 'FreeBSDVirtualCollector' and \
        virtual_collector._fact_class.__name__ == 'FreeBSDVirtual' and \
        virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:43.206293
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc, FreeBSDVirtualCollector)
    assert vc.platform == 'FreeBSD'
    assert vc.fact_class == FreeBSDVirtual
    assert vc._platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:50.540878
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsdvc = FreeBSDVirtualCollector()
    assert bsdvc
    assert bsdvc._fact_class == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:03:51.567133
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:03:53.278340
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Unit test for constructor of class FreeBSDVirtualCollector
    """
    obj = FreeBSDVirtualCollector()
    # obj.collect()

# Generated at 2022-06-23 02:03:57.233358
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert virtual_collector._fact_class.platform == 'FreeBSD'
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:08.250877
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an instance of FreeBSDVirtual class
    freebsd_virtual_facts = FreeBSDVirtual()

    # Setup get_sysctl return values
    freebsd_virtual_facts.get_sysctl = lambda p: None

    freebsd_virtual_facts.get_sysctl = lambda p: {'security.jail.jailed': 1}
    assert freebsd_virtual_facts.get_virtual_facts()['virtualization_role'] == 'guest'

    freebsd_virtual_facts.get_sysctl = lambda p: {'kern.vm_guest': 'other'}
    assert freebsd_virtual_facts.get_virtual_facts()['virtualization_role'] == 'guest'
    assert freebsd_virtual_facts.get_virtual_facts()['virtualization_type'] == 'other'

    free

# Generated at 2022-06-23 02:04:09.665685
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:04:14.014655
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    o = FreeBSDVirtual()
    assert o.platform == 'FreeBSD'
    assert o.virtualization_type == ''
    assert o.virtualization_role == ''
    assert o.virtualization_tech_host == set()
    assert o.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:04:19.782070
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.virtual import Virtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    v = FreeBSDVirtual()

    assert isinstance(v, Virtual)
    assert isinstance(v, VirtualSysctlDetectionMixin)



# Generated at 2022-06-23 02:04:24.903383
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up a dict containing facts from the virtual source which
    # will be returned by Virtual.get_virtual_facts when called.
    test_info_dict = {
        'hw.hv_vendor': 'BHYVE',
        'kern.vm_guest': 'bhyve',
        'security.jail.jailed': '0',
        'hw.model': 'I635 <Virtual CPU>'
    }

    # Create a FreeBSDVirtual object
    test = FreeBSDVirtual(module=None)

    # Replace _sysctl_all method of Virtual class with a
    # method that returns test_info_dict when called.
    test._sysctl_all = lambda: test_info_dict

    # Create an empty dict for storing the return value of
    # FreeBSDVirtual.get_virtual_facts
    virtual_facts = {}



# Generated at 2022-06-23 02:04:26.516517
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:04:28.076421
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()

    assert fb.platform == 'FreeBSD'



# Generated at 2022-06-23 02:04:33.291530
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsdVirtualCollector = FreeBSDVirtualCollector()
    assert freebsdVirtualCollector  # It is a class
    assert freebsdVirtualCollector._fact_class is FreeBSDVirtual
    assert freebsdVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:34.785454
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:37.407345
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-23 02:04:40.368487
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    for key in ('virtualization_type', 'virtualization_role',
                'virtualization_technologies'):
        assert key in facts

# Generated at 2022-06-23 02:04:42.120860
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual({})
    freebsd_virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:04:43.917558
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:04:47.837230
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_fact_collector = FreeBSDVirtualCollector()
    virtual_facts = virt_fact_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['', 'xen', 'vmware', 'virtualbox', 'kvm', 'hyperv', 'bhyve', 'jail', 'chroot', 'qemu', 'parallels']
    assert virtual_facts['virtualization_role'] in ['', 'guest']

# Generated at 2022-06-23 02:04:50.167180
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:50.784152
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:53.756386
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:56.748279
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fVirt = FreeBSDVirtual({})
    assert (fVirt.get_virtual_facts()['virtualization_type'] == '')
    assert (fVirt.get_virtual_facts()['virtualization_role'] == '')

# Generated at 2022-06-23 02:04:59.863475
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:05:03.925237
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
  fbsdVirt = FreeBSDVirtual({})
  assert isinstance(fbsdVirt._platform, str)
  assert isinstance(fbsdVirt._fact_class, type)

# Generated at 2022-06-23 02:05:12.167352
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ''' Test creation of a FreeBSDVirtualCollector with empty init'''
    class fake_module(object):
        def __init__(self):
            self.params = {}

    class fake_task(object):
        def __init__(self):
            self.args = {}

    def fake_executor(self, module, task_vars=None):
        return {"stdout": "asdf"}

    my_collector = FreeBSDVirtualCollector(module=fake_module(), task_vars=fake_task(), executor=fake_executor)
    assert my_collector._fact_class == FreeBSDVirtual
    assert my_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:20.053133
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Test the results of get_virtual_facts of class FreeBSDVirtual
    '''
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.populate()
    assert freebsd_virtual.virtualization_type == 'xen'
    assert freebsd_virtual.virtualization_role == 'guest'
    assert 'xen' in freebsd_virtual.virtualization_tech_guest
    assert 'jail' not in freebsd_virtual.virtualization_tech_guest
    assert 'jail' in freebsd_virtual.virtualization_tech_host
    assert 'xen' not in freebsd_virtual.virtualization_tech_host

# Generated at 2022-06-23 02:05:22.372273
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert type(obj).__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-23 02:05:23.399084
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f

# Generated at 2022-06-23 02:05:25.312171
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fc = FreeBSDVirtualCollector()
    assert isinstance(fc._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:05:38.239556
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_data = {
        'security.jail.jailed': '0',
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'bhyve',
        'hw.model': 'i386'
    }

    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set()
    }

    # FIXME(shadower): this is a stub.  It should actually call the
    # VirtualSysctlDetectionMixin implementation.
    def function_mock(self, key, default=None):
        return mock_data.get(key, default)

    # FIXME(shadower): this is a stub.  It should actually call the
    # VirtualSysctlDetectionMix

# Generated at 2022-06-23 02:05:39.560951
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:05:40.761123
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # TODO: implement unit test
    #assert(0 == 1)
    pass

# Generated at 2022-06-23 02:05:45.561485
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert type(virtual_facts['virtualization_role']) is str
    assert type(virtual_facts['virtualization_type']) is str

# Generated at 2022-06-23 02:05:49.786331
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual({})
    assert isinstance(fb, FreeBSDVirtual)

    assert fb.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:05:56.992168
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    fb_virtual = FreeBSDVirtual(module=None, facts=facts)

    # without jail
    kern_vm_guest = dict(name='kern.vm_guest', value='other')
    hw_hv_vendor = dict(name='hw.hv_vendor', value='BHYVE')
    hw_model = dict(name='hw.model', value='foobar')
    virtual_facts = dict(virtualization_type='',
                         virtualization_role='',
                         virtualization_tech_guest=set(),
                         virtualization_tech_host=set())


# Generated at 2022-06-23 02:05:58.601941
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None, None, None)

# Generated at 2022-06-23 02:06:01.158975
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Unit test to validate constructor of class FreeBSDVirtualCollector
    """
    virtual_obj = FreeBSDVirtualCollector()
    assert virtual_obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:04.252642
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.__class__.__name__ == 'FreeBSDVirtualCollector'
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:06:07.985358
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()

    assert isinstance(fvc, FreeBSDVirtualCollector)
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:10.336936
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual(module=None)
    assert isinstance(f, FreeBSDVirtual)



# Generated at 2022-06-23 02:06:14.287373
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    # Just check it retrieves a dict
    assert isinstance(virtual_facts, dict)
    assert virtual_facts.__contains__('virtualization_type')
    assert virtual_facts.__contains__('virtualization_role')

# Generated at 2022-06-23 02:06:16.367392
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert fv is not None

# Generated at 2022-06-23 02:06:18.045747
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        collector = FreeBSDVirtualCollector()
        assert collector is not None
    except Exception as e:
        assert False, e

# Generated at 2022-06-23 02:06:24.812545
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_facts = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector_facts, FreeBSDVirtualCollector)
    assert virtual_collector_facts._platform == 'FreeBSD'
    assert virtual_collector_facts.platform == 'FreeBSD'
    assert virtual_collector_facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:31.967106
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:06:42.854095
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    def test_data(sysctl, hw_model, freebsd_virtual_dict):
        # Set up test data
        if sysctl == 'kern.vm_guest':
            sysctl_data = {
                'hw.hv_vendor': None,
                'security.jail.jailed': None,
                'sysctl_data': (
                    'vm.vmtotal: Virtual Machines: \n'
                    'vm.vmtotal.VMTT_UNKNOWN: 0\n'
                    'vm.vmtotal.VMTT_NATIVE: 0\n'
                    'vm.vmtotal.VMTT_HVM: 0\n'
                )
            }

# Generated at 2022-06-23 02:06:45.039241
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """ Test for constructor of class FreeBSDVirtual """
    virtual = FreeBSDVirtual({})
    assert virtual is not None

# Generated at 2022-06-23 02:06:51.321531
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of class FreeBSDVirtual
    obj = FreeBSDVirtual()
    _facts = obj.get_virtual_facts()
    # Check the facts returned by get_virtual_facts method
    # assert_equal() asserts the result is equal to the expected one
    assert_equal(_facts['virtualization_type'], 'kvm')
    assert_equal(_facts['virtualization_role'], 'guest')

# Generated at 2022-06-23 02:06:53.977174
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:06:56.308511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector


# Generated at 2022-06-23 02:07:05.851303
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    rval = {'virtualization_type': 'xen',
            'virtualization_role': 'guest',
            'virtualization_tech_guest': {'xen'},
            'virtualization_tech_host': set()}
    result = FreeBSDVirtual(None).get_virtual_facts()
    assert(result['virtualization_type'] == rval['virtualization_type'])
    assert(result['virtualization_role'] == rval['virtualization_role'])
    assert(result['virtualization_tech_guest'] == rval['virtualization_tech_guest'])
    assert(result['virtualization_tech_host'] == rval['virtualization_tech_host'])

# Generated at 2022-06-23 02:07:12.750468
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from collections import namedtuple
    AnsibleModule = namedtuple('AnsibleModule', ['params'])
    ansible_module = AnsibleModule(params=dict(gather_subset=[], filter=[]))
    f = FreeBSDVirtual(ansible_module)
    facts = f.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_technologies'] == []

# Generated at 2022-06-23 02:07:17.507160
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    c = FreeBSDVirtual()
    assert c.get_virtual_facts().items() <= {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }.items()

# Generated at 2022-06-23 02:07:21.341950
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts._platform == "FreeBSD"
    assert virtual_facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:24.000818
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsdc = FreeBSDVirtualCollector()
    assert bsdc
    assert bsdc._platform == 'FreeBSD'
    assert bsdc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:26.099777
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for function FreeBSDVirtual'''

    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual
    assert freebsd_virtual.platform == 'FreeBSD'



# Generated at 2022-06-23 02:07:28.284611
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = {}
    virt_instance = FreeBSDVirtual()
    assert virt_instance.get_virtual_facts() == virtual_facts


# Generated at 2022-06-23 02:07:31.402666
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:35.518944
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert isinstance(x._collector, FreeBSDVirtual)
    assert isinstance(x._fact_class, FreeBSDVirtual)
    assert x._platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:38.897427
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    test = FreeBSDVirtual()
    assert test.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:07:50.594409
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class FakeModule:
        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            return executable

    class FakeSysctlModuleUtil:

        def parse_value(self, value):
            return value
        
        def sysctl_value(self, module, sysctl_name):
            return sysctl_name
    
    fmd = FakeModule()
    fsdm = FakeSysctlModuleUtil()
    
    fv = FreeBSDVirtual(module=fmd, sysctl=fsdm)
    facts = fv.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-23 02:07:54.993380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert Virtual(platform='FreeBSD').get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-23 02:07:57.265673
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    # A FreeBSDVirtual object should be created in the collector
    assert isinstance(collector.virtobj, FreeBSDVirtual)

# Generated at 2022-06-23 02:08:08.711991
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class FreeBSDVirtualTest(FreeBSDVirtual):
        def _get_file_content(self, path):
            return ""

        def _get_sysctl(self, key):
            return ""

        def _parse_sysctl_vm_guest(self, sysctl_value):
            return {'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set(),
                    'virtualization_type': '',
                    'virtualization_role': '',
                    'virtualization_product': ''}


# Generated at 2022-06-23 02:08:16.798101
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    virtual = FreeBSDVirtual(VirtualSysctlDetectionMixin)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_technologies'] == {'xen'}
    assert virtual_facts['virtualization_technologies_guest'] == {'xen'}

# Generated at 2022-06-23 02:08:21.522507
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Check if facts are correct when running in a VM
    """
    virt = FreeBSDVirtual()
    results = virt.get_virtual_facts()
    assert 'virtualization_type' in results
    assert 'virtualization_role' in results
    assert 'virtualization_tech_guest' in results
    assert 'virtualization_tech_host' in results

# Generated at 2022-06-23 02:08:23.336275
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None


# Generated at 2022-06-23 02:08:29.228658
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:08:36.305041
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    os.environ['PATH'] = '/bin:/usr/bin'

    # Setup default values
    vc = {}
    vc['virtualization_type'] = ''
    vc['virtualization_role'] = ''
    vc['virtualization_tech_guest'] = set()
    vc['virtualization_tech_host'] = set()
    vc['virtualization_system'] = ''
    vc['virtualization_product_name'] = ''
    vc['virtualization_product_version'] = ''
    vc['virtualization_product_version'] = ''

    # Setup default stubs
    VirtualSysctlDetectionMixin.get_sysctl = lambda x: None
    VirtualSysctlDetectionMixin.get_

# Generated at 2022-06-23 02:08:38.484133
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == "FreeBSD"


# Generated at 2022-06-23 02:08:43.963681
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    result = virtual.get_virtual_facts()
    assert isinstance(result, dict)
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:08:45.307690
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # create an instance of FreeBSDVirtual with empty arg
    fb = FreeBSDVirtual()

# Generated at 2022-06-23 02:08:56.374530
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Tests FreeBSDVirtual.get_virtual_facts returns the correct data when
    hardware virtualization is used.
    """

    from ansible.module_utils._text import to_bytes

    test_sysctl_data = {
        'kern.vm_guest': b'xen\n',
        'hw.hv_vendor': b'Xen\n',
        'security.jail.jailed': b'0\n',
        'hw.model': b'Xen Virtual CPU version 3.0\n',
    }

    # Get a FreeBSDVirtual object
    virtual = FreeBSDVirtual(module=None)

    # Set up test data
    virtual.sysctl_output = test_sysctl_data

    # Check that we get the correct data

# Generated at 2022-06-23 02:09:06.073513
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    expected_facts = {
        'virtualization_tech_guest': set(['kvm', 'xen', 'xen-hvm', 'vmware',
                                          'hyperv']),
        'virtualization_tech_host': set(['kvm', 'xen', 'xen-hvm', 'vmware',
                                         'hyperv', 'vbox', 'xen-hvm-dom0']),
        'virtualization_type': '',
        'virtualization_role': ''
    }

    assert facts == expected_facts

# Generated at 2022-06-23 02:09:08.376863
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == FreeBSDVirtual.platform
    assert virtual.file_exists('/dev/xen/xenstore') == False

# Generated at 2022-06-23 02:09:09.542135
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:11.159134
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:22.107781
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json
    import sys
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO
    import os
    import tempfile
    import textwrap

    # Create a temporary directory and files
    td = tempfile.mkdtemp()
    kern_vm_guest = tempfile.mkstemp(dir=td, text=True)
    hw_hv_vendor = tempfile.mkstemp(dir=td, text=True)
    hw_model = tempfile.mkstemp(dir=td, text=True)
    sec_jail_jailed = tempfile.mkstemp(dir=td, text=True)
    xenstore = tempfile.mkstemp(dir=td, text=True)


# Generated at 2022-06-23 02:09:31.759098
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Avoid 'No sysctl utility present in this python interpreter' error
    # '_utils.unavailable_sysctl()' mocks sysctl class so NoneType is returned
    import ansible.module_utils.facts.virtual.sysctl
    ansible.module_utils.facts.virtual.sysctl._utils = None

    # In this test, we return specific values for hw.model and hw.machine
    # In order to return other values, this class should be mocked
    # import ansible.module_utils.facts.virtual.freebsd
    # ansible.module_utils.facts.virtual.freebsd._utils = None
    # And here is where __utils class should be mocked
    #  from ansible.module_utils.facts import virtual
    #  from ansible.module_utils.facts.virtual.freebsd import __utils

# Generated at 2022-06-23 02:09:43.247343
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO: This test would be more complete if it had test cases that
    # tested every possible permutation of sysctl/hw.model values
    mock_sysctl = {'kern.vm_guest.freebsd64': 'guest',
                   'kern.vm_guest.linux64': 'guest',
                   'hw.hv_vendor.vmware': 'vmware',
                   'hw.hv_vendor.bhyve': 'bhyve',
                   'security.jail.jailed': '1',
                   'hw.model': 'FreeBSD/amd64',
                   }

    virtual_facts = FreeBSDVirtual(mock_sysctl).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:09:45.078470
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == "FreeBSD"

# Generated at 2022-06-23 02:09:46.260238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:47.527768
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts_virtual = FreeBSDVirtual({})
    facts_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:09:49.335339
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    f = v.get_virtual_facts()
    assert f['virtualization_type'] == ''
    assert f['virtualization_role'] == ''

# Generated at 2022-06-23 02:09:50.638063
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fvd = FreeBSDVirtual({})
    fvd.get_virtual_facts()

# Generated at 2022-06-23 02:09:54.079816
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()


if __name__ == '__main__':
    # Unit test
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:55.714879
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    # Test if the class is correctly initialized
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:05.780733
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Mock sysctl -n
    mock_sysctl_n = [(1, 1), (None, None), (None, None)]
    mocksysctl = mock_sysctl_n.pop(0)

    def mock_sysctl(x):
        return mocksysctl.pop(0)

    # Mock hw.model
    mock_hw_model = ["some_hw_model"]

    # Mock FreeBSDVirtual class
    class MockFreeBSDVirtual(FreeBSDVirtual):

        def detect_virt_product(self, sysctl_name):
            return {
                'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_host': set(),
                'virtualization_tech_guest': set(),
            }


# Generated at 2022-06-23 02:10:07.935507
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'
    assert FreeBSDVirtualCollector()._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:09.983206
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'
    assert f.get_virtual_facts() == {}


# Generated at 2022-06-23 02:10:11.678982
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(platform_facts={})
    assert 'FreeBSD' in virtual_facts.platform

# Generated at 2022-06-23 02:10:12.854471
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    res = FreeBSDVirtual()

    assert res.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:15.817768
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Create an instance of FreeBSDVirtual and check if the platform and fact_class is set
    """

    fbsd_virt = FreeBSDVirtual({})

    assert fbsd_virt.platform == 'FreeBSD'
    assert fbsd_virt.fact_class == 'Virtual'

# Generated at 2022-06-23 02:10:23.097704
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtualhost = FreeBSDVirtual()
    assert virtualhost.get_virtual_facts()['virtualization_role'] == ''
    assert virtualhost.get_virtual_facts()['virtualization_type'] == ''
    assert type(virtualhost.get_virtual_facts()['virtualization_tech_host']) == set
    assert type(virtualhost.get_virtual_facts()['virtualization_tech_guest']) == set
    assert sum(map(len, virtualhost.get_virtual_facts().values())) > 0

# Generated at 2022-06-23 02:10:25.401012
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:26.058716
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    VirtualCollector()

# Generated at 2022-06-23 02:10:27.303198
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:10:29.232688
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:33.781941
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    with open('/dev/null', 'w'):
        v = FreeBSDVirtual()
        facts = v.get_virtual_facts()
        assert facts['virtualization_type'] == 'xen'
        assert facts['virtualization_role'] == 'guest'
        assert 'xen' in facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:10:36.740915
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    klass = FreeBSDVirtualCollector()
    assert isinstance(klass, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:10:40.067138
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._fact_class._platform == 'FreeBSD'