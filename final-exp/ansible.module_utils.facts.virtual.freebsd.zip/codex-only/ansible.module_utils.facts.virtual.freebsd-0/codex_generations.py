

# Generated at 2022-06-23 02:00:42.527146
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collection = FreeBSDVirtualCollector()
    assert collection.platform == 'FreeBSD'
    assert collection.fact_class == FreeBSDVirtual

# Unit test class FreeBSDVirtual

# Generated at 2022-06-23 02:00:44.621820
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({}, None)
    assert fv.platform == 'FreeBSD', 'platform should be FreeBSD'


# Generated at 2022-06-23 02:00:45.711169
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    c = FreeBSDVirtual()
    assert c != None


# Generated at 2022-06-23 02:00:46.833911
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert type(v) is FreeBSDVirtual

# Generated at 2022-06-23 02:00:50.172277
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    d = FreeBSDVirtualCollector()
    assert d.__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-23 02:01:02.055046
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()

    # Test case 1.
    # FreeBSD guest inside Xen hypervisor
    # /dev/xen/xenstore exists
    # kern.vm_guest is 'xen'
    # hw.hv_vendor is 'Xen'
    # security.jail.jailed is '0'
    # hw.model is 'Genuine Intel(R) CPU U7300  @ 1.30GHz'

    with open('/dev/xen/xenstore', 'w'):
        pass

    virt._sysctl_get = lambda x: 'xen'

# Generated at 2022-06-23 02:01:07.051674
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None, None)
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

# Generated at 2022-06-23 02:01:09.726214
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Test class FreeBSDVirtual.
    """
    freebsd_virtual = FreeBSDVirtual("module")
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:21.676229
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    freebsd_virtual = FreeBSDVirtual('/var/run')

    # Populate facts to bypass detection of the OS
    freebsd_virtual.facts = {'kernel': 'FreeBSD',
                             'kernel_version': '11.2-RELEASE',
                             'system': 'FreeBSD'}

    virtual_facts = freebsd_virtual.get_virtual_facts()

    if os.path.exists('/dev/xen/xenstore'):
        assert virtual_facts['virtualization_type'] == 'xen'
        assert virtual_facts['virtualization_role'] == 'guest'
    else:
        assert virtual_facts['virtualization_type'] == ''
        assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:01:28.948774
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    facts = FreeBSDVirtual('freebsd').get_virtual_facts()
    assert set(facts.keys()) == set(('virtualization_type',
                                     'virtualization_role',
                                     'virtualization_tech_guest',
                                     'virtualization_tech_host'))
    assert facts['virtualization_type'] in ['',
                                            'virtualbox',
                                            'hyperv',
                                            'virtualpc',
                                            'kvm',
                                            'xen',
                                            'jail',
                                            'linux_vserver']
    assert facts['virtualization_role'] in ['', 'guest', 'host']
    assert isinstance(facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:01:32.776159
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbv = FreeBSDVirtual()
    virtual_facts = fbv.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:01:41.046971
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set some fake facts to simulate a FreeBSD host running in a jail
    fake_facts = {'distribution': 'FreeBSD',
                  'kernel': 'FreeBSD',
                  'kernel_version': '10.1-RELEASE',
                  'kernel_version_info': (10, 1),
                  'os_family': 'FreeBSD',
                  'system_vendor': {'manufacturer': 'iXsystems'},
                  'virtualization_role': 'guest',
                  'virtualization_type': 'jail'}

    # Create a FreeBSDVirtual object
    fake_fbsd_virtual = FreeBSDVirtual(fake_facts)

    # Run get_virtual_facts()
    fact_dict = fake_fbsd_virtual.get_virtual_facts()

    # Assert that we get back the proper things

# Generated at 2022-06-23 02:01:43.535315
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:48.971951
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    os_facts = {
        'kernel': 'FreeBSD',
        'kernel_version': '12.0-RELEASE'
    }
    freebsd_virtual = FreeBSDVirtual(os_facts)
    assert freebsd_virtual.platform == "FreeBSD"
    # this is a FreeBSD specific class
    assert freebsd_virtual.get_virtual_facts()['virtualization_type'] in ('vmware', 'jail', 'xen', '')
    assert freebsd_virtual.get_virtual_facts()['virtualization_type'] != 'VirtualBox'
    assert freebsd_virtual.get_virtual_facts()['virtualization_type'] != 'QEMU'


# Generated at 2022-06-23 02:01:50.169996
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:01:53.870429
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Need to create a class, since the constructor of class Virtual is an abstract method
    class FreeBSDVirtual1(FreeBSDVirtual):
        pass
    mm = FreeBSDVirtual1()
    assert isinstance(mm, FreeBSDVirtual)
    assert isinstance(mm, Virtual)

# Generated at 2022-06-23 02:02:01.439802
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    results = dict(
        changed=False,
        ansible_facts=dict(
            ansible_virtual_facts=dict(
                virtualization_type='xen',
                virtualization_role='guest',
                virtualization_tech_guest={'jail'},
                virtualization_tech_host={'kvm', 'xen'}
            )
        )
    )

    virtual = FreeBSDVirtual(module=module)

    # This is a bit of a pain.  virtual.get_virtual_facts must be called before
    # test().  Because of how Virtual subclassed objects are created, it
    # requires the module argument to have an argument_spec, otherwise the
    # module object will have some unexpected attribute errors

# Generated at 2022-06-23 02:02:05.760526
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual_collector = FreeBSDVirtualCollector()
    assert bsd_virtual_collector._platform == "FreeBSD"
    assert issubclass(bsd_virtual_collector._fact_class, FreeBSDVirtual) is True

# Generated at 2022-06-23 02:02:07.586085
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:13.813474
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    expected_platform = 'FreeBSD'
    expected_fact_class = FreeBSDVirtual

    facts_collector = FreeBSDVirtualCollector()

    assert facts_collector._platform == expected_platform
    assert facts_collector._fact_class == expected_fact_class

# Generated at 2022-06-23 02:02:17.021807
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    paramiko.SSHException: No existing session
    """
    pass

# Generated at 2022-06-23 02:02:18.971717
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual('freebsd')
    assert facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:24.382534
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Test class FreeBSDVirtual constructor
    '''
    virt = FreeBSDVirtual(None)
    assert virt.platform == 'FreeBSD'
    assert virt.Collector is FreeBSDVirtualCollector
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''

# Generated at 2022-06-23 02:02:25.351101
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    pass

# Generated at 2022-06-23 02:02:28.088884
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:30.496420
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facter = FreeBSDVirtual({})
    assert facter.platform == 'FreeBSD'



# Generated at 2022-06-23 02:02:33.862304
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Unit test for constructor of class FreeBSDVirtualCollector
    '''
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:35.629047
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual._fact_class == FreeBSDVirtual
    assert virtual._platform == FreeBSDVirtual.platform


# Generated at 2022-06-23 02:02:40.829913
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.get_virtual_facts() is not None


# Generated at 2022-06-23 02:02:45.150360
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    output = virtual_facts.get_virtual_facts()
    assert output['virtualization_type'] or output['virtualization_role']

# Generated at 2022-06-23 02:02:46.898006
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()
    assert isinstance(fb_virtual, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:57.594964
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class FreeBSDVirtual '''
    # Test for x86_64 architecture
    facts = {'kernel': 'FreeBSD', 'kernelrelease': '11.0-CURRENT',
             'machine': 'amd64'}
    test = FreeBSDVirtual(module=None, facts=facts)
    result = test.get_virtual_facts()
    assert result['virtualization_role'] == ''
    assert result['virtualization_type'] == ''

    # Test for aarch64 architecture
    facts = {'kernel': 'FreeBSD', 'kernelrelease': '11.0-CURRENT',
             'machine': 'arm64'}
    test = FreeBSDVirtual(module=None, facts=facts)
    result = test.get_virtual_facts()
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:03:00.606184
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest=set(['xen']),
        virtualization_tech_host=set([])
    )
    assert FreeBSDVirtual().get_virtual_facts() == expected

# Generated at 2022-06-23 02:03:12.615033
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from copy import deepcopy
    facts = VirtualCollector._get_platform_facts(FreeBSDVirtual)
    facts = facts.get_virtual_facts()

    if "virtualization_type" in facts:
        assert facts["virtualization_type"] == "FreeBSD"
    else:
        assert "testcase_failed" == "virtualization_type not found"

    if "virtualization_role" in facts:
        assert facts["virtualization_role"] == "host"
    else:
        assert "testcase_failed" == "virtualization_role not found"

    assert "virtualization_tech_host" in facts
    assert "virtualization_tech_guest" in facts

    assert isinstance(facts["virtualization_tech_host"], set)

# Generated at 2022-06-23 02:03:15.378688
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual(module=None)
    assert fbsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:16.410734
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:18.039216
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f._fact_class == FreeBSDVirtual
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:21.044912
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = FakeAnsibleModule()
    facts = FreeBSDVirtual(module).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:03:32.118655
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest

    vm = FreeBSDVirtual()

    # Set up facts
    facts = {}
    vm.populate(facts)

    # No virtualization technology
    facts['kernel'] = 'FreeBSD'
    virtual_facts = vm.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # VirtualBox
    facts['kernel'] = 'FreeBSD'
    facts['product_name'] = 'VirtualBox'
    facts['product_serial'] = '0'
    virtual_facts = vm.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'

    # VMware Fusion
    facts['kernel'] = 'FreeBSD'
    facts

# Generated at 2022-06-23 02:03:36.267470
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector(None)

    # Test facts class
    assert virtual._fact_class == FreeBSDVirtual
    # Test platform
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:39.869879
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert 'virtualization' in virtual_facts.fetch_facts()
    assert 'virtualization_type' in virtual_facts.fetch_facts()['virtualization']

# Generated at 2022-06-23 02:03:42.612393
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import FreeBSDVirtual
    virtual_facts = FreeBSDVirtual()
    virtual_facts_list = virtual_facts.get_virtual_facts()
    assert virtual_facts_list

# Generated at 2022-06-23 02:03:58.240842
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create some test data
    expected_facts = {'virtualization_type': 'kvm',
                      'virtualization_role': 'host',
                      'virtualization_tech_guest': set(['']),
                      'virtualization_tech_host': set(['kvm'])
                      }
    sysctl_data = {'hw.hv_vendor': 'KVMKVMKVM\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
                   'kern.vm_guest': 'other',
                   'security.jail.jailed': 0
                   }
    # hw_model

# Generated at 2022-06-23 02:03:59.629705
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:04:02.318378
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert type(virtual_collector) is FreeBSDVirtualCollector


# Generated at 2022-06-23 02:04:03.854695
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual({})
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:07.601231
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:04:09.333380
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'


# Unit tests for class FreeBSDVirtual

# Generated at 2022-06-23 02:04:11.554074
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:04:12.847911
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    x = FreeBSDVirtual()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:16.467237
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual = FreeBSDVirtual()
    assert ('virtualization_type' and 'virtualization_role') in bsd_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:04:21.865008
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert(result.platform == 'FreeBSD')

# Generated at 2022-06-23 02:04:25.934453
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'
    assert fv.virtualization_type == ''
    assert fv.virtualization_role == ''
    assert fv.virtualization_tech_guest == set()
    assert fv.virtualization_tech_host == set()

# Generated at 2022-06-23 02:04:27.057663
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:04:28.964249
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v_c = FreeBSDVirtualCollector()
    assert v_c._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:32.689206
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:04:43.372650
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from unittest import TestCase
    from os import path
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class TestFreeBSDVirtual(FreeBSDVirtual, TestCase):
        def __init__(self):
            TestCase.__init__(self)
            self.mock_path_exists = {}
            self.mock_detect_virt_product = {}
            self.mock_detect_virt_vendor = {}
            self.mock_platform = 'FreeBSD'
            self.mock_virtual_facts = {}

        def path_exists(self, path):
            return self.mock_path_exists.get(path, False)

        def detect_virt_product(self, product):
            return self.mock_detect_virt_

# Generated at 2022-06-23 02:04:45.136538
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class == FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:46.198639
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:04:49.676379
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_module = FreeBSDVirtual()
    assert virtual_facts_module.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:55.156589
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import platform
    dist = platform.dist()
    if dist[0] == 'FreeBSD':
        virtual = FreeBSDVirtual()
        facts = virtual.get_virtual_facts()
        assert facts is not None
        assert facts['virtualization_type'] is not None
        assert facts['virtualization_type'] != ''
        assert facts['virtualization_role'] is not None
        assert facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:04:56.749400
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:59.280927
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts.__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-23 02:05:07.039356
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.cache_attr == 'ansible_virtual_freebsd'
    assert FreeBSDVirtualCollector.cache_file == 'ansible_virtual_freebsd.fact'
    assert FreeBSDVirtualCollector.cache_location == os.path.join(os.path.sep, 'var', 'ansible', 'caching', 'facts', 'virtual')
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:09.634272
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Constructor Test'''
    assert Virtual({}) is not None
    assert Virtual({}).collect() is not None
    assert Virtual({}).get_virtual_facts() is not None

# Generated at 2022-06-23 02:05:10.209139
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:05:18.352319
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.sysctl_values.update({'kern.vm_guest': 'none',
                                          'hw.hv_vendor': 'FreeBSD',
                                          'security.jail.jailed': 0})
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:05:29.145432
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Pretend we are in a jail.
    os.environ["PATH"] = '/sbin:/bin:/usr/sbin:/usr/bin'
    os.environ["PWD"] = '/'

    vr = FreeBSDVirtual()
    virtual_facts = vr.get_virtual_facts()
    assert len(virtual_facts) == 5
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technology' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:05:31.007631
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert type(virtual) is FreeBSDVirtual

# Generated at 2022-06-23 02:05:32.878263
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:38.675219
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Declare a instance of FreeBSDVirtual
    fb_vir = FreeBSDVirtual()
    # Call get_virtual_facts and check the output
    facts = fb_vir.get_virtual_facts()
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-23 02:05:39.560325
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:46.299573
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:05:46.690100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:05:49.263218
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:51.407398
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    assert virtual._platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:54.881014
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)
    assert isinstance(collector, FreeBSDVirtualCollector)
    assert isinstance(collector._fact_class, Virtual)
    assert isinstance(collector._fact_class, FreeBSDVirtual)
    assert collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:56.447293
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor of the class FreeBSDVirtualCollector should be called.
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:57.260121
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:06:03.449304
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    d = FreeBSDVirtual()

    # Set up return values for mocked functions
    d.detect_virt_product = lambda x: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    d.detect_virt_vendor = lambda x: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    print(d.get_virtual_facts())  # noqa: T001


# Generated at 2022-06-23 02:06:07.943417
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual
    assert issubclass(obj._fact_class, Virtual)

# Generated at 2022-06-23 02:06:13.059172
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    v = FreeBSDVirtual({'kernel': 'FreeBSD'})
    facts = v.get_virtual_facts()
    assert type(facts['virtualization_tech_guest']) == set
    assert type(facts['virtualization_tech_host']) == set

# Generated at 2022-06-23 02:06:16.095147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.__class__.__name__ == 'FreeBSDVirtualCollector', f.__class__.__name__

# Generated at 2022-06-23 02:06:21.985728
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_bsd_in_docker = FreeBSDVirtual({'ansible_facts': {}})
    virtual_bsd_facts = virtual_bsd_in_docker.get_virtual_facts()

    assert virtual_bsd_facts['virtualization_role'] == 'guest'
    assert virtual_bsd_facts['virtualization_type'] == 'docker'



# Generated at 2022-06-23 02:06:25.960154
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert virt._sysctl_facts is None
    assert virt._file_facts is None
    assert virt._virtual_facts is not None
    assert virt._platform == 'FreeBSD'


# Generated at 2022-06-23 02:06:28.494909
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)
    assert isinstance(instance._fact_class, FreeBSDVirtual)
    assert instance._platform == "FreeBSD"

# Generated at 2022-06-23 02:06:40.905247
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock sysctl facts as in FreeBSD
    facts_sysctl = {
        'hw.hv_vendor': 'NONE',
        'kern.vm_guest': 'NONE',
        'security.jail.jailed': 0,
        'security.jail.enforce_statfs': 2,
    }
    # Mock model fact as in FreeBSD
    facts_model = {
        'model': 'FreeBSD virtual machine'
    }

    def test_fact(self, fact, value):
        return facts_sysctl.get(fact, '') == value

    def test_model(self, model):
        return model in facts_model['model']


# Generated at 2022-06-23 02:06:48.555398
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    result = dict((k, v) for k, v in virtual.get_virtual_facts().items() if v)
    assert result['virtualization_type'] == 'jail'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['jail'])
    assert result['virtualization_tech_host'] == set(['bhyve'])

# Generated at 2022-06-23 02:06:53.207151
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual._platform == 'FreeBSD'
    assert freebsd_virtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}

# Generated at 2022-06-23 02:06:55.984726
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual("freebsd")
    assert virtual.facts["virtualization_type"] == ""
    assert virtual.facts["virtualization_role"] == ""

# Generated at 2022-06-23 02:06:58.796303
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvcollector = FreeBSDVirtualCollector()
    assert fvcollector._platform == 'FreeBSD'
    assert fvcollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:59.999550
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    m = FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:07:02.778671
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:07.026076
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This code is executed if we run this file directly
    if __name__ == '__main__':
        virtual_facts = FreeBSDVirtual().get_virtual_facts()
        print(virtual_facts)
    # Verify method get_virtual_facts() returns the correct value
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:07:19.074584
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    def fake_sysctl(param):
        if param == 'kern.vm_guest':
            return 'jail'
        if param == 'hw.model':
            return 'VirtualBox'
        if param == 'security.jail.jailed':
            return '0'
        raise Exception('Undefined sysctl test for %s' % param)

    def fake_exists(path):
        if path == '/dev/xen/xenstore':
            return True
        return False

    current_module = type(os)('fake_module')
    current_module.run_command = lambda x: (0, '', '')

    virtual_facts = FreeBSDVirtual({'module': current_module, '_sysctl': fake_sysctl, '_exists': fake_exists})
    assert virtual_facts.get_virtual_

# Generated at 2022-06-23 02:07:22.882088
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    # Check the object Instantiate
    freeBSD_facts = FreeBSDVirtualCollector()

    # Check the object properties
    assert freeBSD_facts.platform == 'FreeBSD'
    assert freeBSD_facts._fact_class == FreeBSDVirtual
    assert freeBSD_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:30.551494
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()

    # Set values to validate
    virt.facts['ansible_system'] = 'FreeBSD'
    virt.facts['ansible_product_name'] = 'FreeBSD'
    virt.facts['ansible_machine'] = 'amd64'

    facts = virt.get_virtual_facts()
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts


# Generated at 2022-06-23 02:07:32.102613
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsdv = FreeBSDVirtual()
    assert fbsdv.platform == 'FreeBSD'



# Generated at 2022-06-23 02:07:37.121413
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-23 02:07:40.201420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector().collect()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:07:42.182535
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsdvirtual = FreeBSDVirtual()
    assert freebsdvirtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:07:54.513564
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    # Creating instance of class FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Creating instance of class VirtualCollector
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Setting return value of method _get_sysctl_info of class FreeBSDVirtualCollector
    # This method is used only in this test case.
    freebsd_virtual_collector._get_sysctl_info = lambda x: {'security.jail.jailed': '0'}

    # Setting return value of method _get_sysctl_info of class FreeBSDVirtualCollector
    # This method is used only in this test case.

# Generated at 2022-06-23 02:08:06.571528
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MyFreeBSDVirtual(FreeBSDVirtual, VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl = {
                'kern.vm_guest': 'vmware',
                'hw.hv_vendor': 'bhyve',
                'security.jail.jailed': '0',
                'hw.model': 'EC2 m3.2xlarge',
            }

    facts = MyFreeBSDVirtual().get_virtual_facts()

    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_technologies'] == ['bhyve', 'amazon', 'xen', 'vmware']

# Generated at 2022-06-23 02:08:08.664538
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:10.477473
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    myFreeBSDVirtual = FreeBSDVirtual()
    assert myFreeBSDVirtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:12.684302
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    detected_facts = FreeBSDVirtual()
    assert detected_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:16.112021
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert isinstance(v, FreeBSDVirtual)


# Generated at 2022-06-23 02:08:19.013167
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None
    assert FreeBSDVirtualCollector._fact_class is FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:22.603279
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock data from sysctl and hw.model
    sysctl_data = {'hw.model': '', 'kern.vm_guest': '', 'security.jail.jailed': '', 'hw.hv_vendor': ''}
    sysctl_data['hw.model'] = ''
    sysctl_data['kern.vm_guest'] = 'none'
    sysctl_data['security.jail.jailed'] = '0'
    sysctl_data['hw.hv_vendor'] = 'none'

    # Expected result with above mock data
    result = {'virtualization_type': '',
              'virtualization_role': '',
              'virtualization_tech': set()
              }

    # Create an object of FreeBSDVirtual and call get_virtual_facts method
    v = FreeBSDVirtual

# Generated at 2022-06-23 02:08:29.854658
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class FakeModule:
        def run_command(self, cmd, check_rc=True):
            return (0, 'kern.vm_guest: vmm', '')

    mod = FreeBSDVirtual(FakeModule())
    facts = mod.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:08:37.000965
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(module=None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:08:39.414362
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual is not None
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:08:41.944612
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:44.111078
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual({'freebsd': {'sysctl': {}}, 'facter': {}})

# Generated at 2022-06-23 02:08:46.907698
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts._virtualization_type = 'test'
    assert virtual_facts.virtualization_type == 'test'


# Generated at 2022-06-23 02:08:54.106474
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Empty sysctl so that we return a dict anyway
    sysctl = {}

    # Mock_open from AnsibleModuleUtilsCore
    from ansible.module_utils.facts.virtual._utils import mock_open

    # Mock os.path.exists to return False
    from ansible.module_utils.facts.virtual._utils import mock_exists

    # Mock set to record what sysctl values are read
    from ansible.module_utils.facts.virtual._utils import mock_set

    # Mock open_mock to be the mock_open object
    open_mock = mock_open()

    # Mock os.path.exists to return False
    exists_mock = mock_exists()

    # Mock set to record what sysctl values are read
    set_mock = mock_set()

    # Create a FreeBSDVirtual object


# Generated at 2022-06-23 02:08:55.984199
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:07.467196
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Test get_virtual_facts function from class FreeBSDVirtual'''
    from ansible.module_utils.facts.virtual.sysctl import BaseSysctlVirtual

    empty_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
    }

    module = mock.Mock()
    module.INSTANCE.get_bin_path.return_value = None
    virtual_instance = FreeBSDVirtual(module=module)
    virtual_instance._get_sysctl_virtualization_facts = mock.Mock()

    # Return no virtualization info
    assert virtual_instance.get_virtual_facts() == empty_virtual_facts

    # Return virtualization_type and virtualization_role in kern.vm_guest

# Generated at 2022-06-23 02:09:09.581812
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    # Assert that FreeBSDVirtual.platform is FreeBSD
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:12.149866
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # If a FreeBSDVirtualCollector object is created, the collect method
    # should be returned, which is the class method.
    fv = FreeBSDVirtualCollector()
    assert fv.collect == FreeBSDVirtualCollector.collect

# Generated at 2022-06-23 02:09:15.635017
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    runner = FreeBSDVirtual('freebsd.example.com')
    result = runner.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_vendor' in result



# Generated at 2022-06-23 02:09:18.256123
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:24.750925
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # First create a FreeBSDVirtual object
    freebsd_virtual_object = FreeBSDVirtual()

    # Call get_virtual_facts of FreeBSDVirtual object
    freebsd_virtual_facts = freebsd_virtual_object.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in freebsd_virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-23 02:09:36.063418
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # No initialization requires for class FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()
    # Virtualization_type key should not exist
    assert 'virtualization_type' not in freebsd_virtual.facts
    # Virtualization_role key should not exist
    assert 'virtualization_role' not in freebsd_virtual.facts
    # Virtualization_tech_guest key should not exist
    assert 'virtualization_tech_guest' not in freebsd_virtual.facts
    # Virtualization_tech_host key should not exist
    assert 'virtualization_tech_host' not in freebsd_virtual.facts
    # Virtual_manufacturer key should not exist
    assert 'virtual_manufacturer' not in freebsd_virtual.facts
    # Virtual_productname key should not exist
    assert 'virtual_productname' not in freebs

# Generated at 2022-06-23 02:09:47.443353
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    FV = FreeBSDVirtual({})
    if FV.sysctl_tests is None:
        raise Exception("sysctl_tests should not be None")
    if FV.sysctl_tests == {'security.jail.jailed': [0, 1], 'hw.hv_vendor': ['Bhyve', 'Microsoft'], 'kern.vm_guest': ['none', 'vmware', 'user', 'bhyve']} is False :
        raise Exception("sysctl_tests should be {'security.jail.jailed': [0, 1], 'hw.hv_vendor': ['Bhyve', 'Microsoft'], 'kern.vm_guest': ['none', 'vmware', 'user', 'bhyve']}")

# Generated at 2022-06-23 02:09:50.769088
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.fact_class != ''
    assert virtual_facts.fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:09:57.058675
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Calling constructor with no parameter
    obj = FreeBSDVirtual()

    # Check the platform of the instance
    assert obj.platform == 'FreeBSD'

    # Check values of the facts
    assert obj.virtual == ''
    assert obj.product_name == ''
    assert obj.product_version == ''
    assert obj.serial == ''
    assert obj.uuid == ''

# Generated at 2022-06-23 02:10:00.052283
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts function of FreeBSDVirtual class
    """
    virtual_facts = FreeBSDVirtualCollector().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts



# Generated at 2022-06-23 02:10:05.946635
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Load and run the module, like Ansible would.
    from ansible.module_utils.facts import virtual
    freebsd = virtual.collect(None, FreeBSDVirtualCollector)

    assert freebsd.get('virtualization_tech_host') == set()
    assert freebsd.get('virtualization_tech_guest') == set()

    assert 'virtualization_role' in freebsd
    assert 'virtualization_type' in freebsd

# Generated at 2022-06-23 02:10:13.712697
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual import freebsd
    freebsd_virt = freebsd.FreeBSDVirtual({}, {})
    assert isinstance(freebsd_virt, freebsd.FreeBSDVirtual)
    assert isinstance(freebsd_virt, virtual.Virtual)
    assert isinstance(freebsd_virt, virtual.VirtualCollector)
    assert freebsd_virt.platform == 'FreeBSD'
    assert freebsd_virt.virtualization_type == ''
    assert freebsd_virt.virtualization_role == ''


# Generated at 2022-06-23 02:10:15.817776
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:10:27.170160
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual('freebsd', {
        'hw.model': 'VirtualBox',
        'kern.vm_guest': 'xen',
        'security.jail.jailed': '0',
    }).get_virtual_facts()

    assert virt_facts['virtualization_type'] == 'xen'
    assert virt_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virt_facts['virtualization_tech_guest']
    assert 'virtualbox' in virt_facts['virtualization_tech_host']
    assert 'kvm' not in virt_facts['virtualization_tech_guest']
    assert 'kvm' not in virt_facts['virtualization_tech_host']
    assert 'qemu' not in virt_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:10:30.680307
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Make sure we're constructing things correctly
    '''
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_all_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:10:39.174183
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Class for testing constructor
    class Arguments(object):
        def __init__(self):
            self.gather_subset = ['all']
            self.filter = ''
    # Tested method
    virt_facts = FreeBSDVirtual(object()).populate()
    assert virt_facts['virtualization_type'] == ''
    assert isinstance(virt_facts['virtualization_tech_guest'], set)
    assert isinstance(virt_facts['virtualization_tech_host'], set)


# Generated at 2022-06-23 02:10:42.015491
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Constructs a FreeBSDVirtualCollector object."""

    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'
