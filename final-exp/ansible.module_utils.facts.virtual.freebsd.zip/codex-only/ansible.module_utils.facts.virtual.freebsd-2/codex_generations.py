

# Generated at 2022-06-23 02:00:36.499913
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:00:42.946135
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
  # create an instance of FreeBSDVirtual
  freebsd_virtual = FreeBSDVirtual()
  # assert class of FreeBSDVirtual instance is FreeBSDVirtual
  assert isinstance(freebsd_virtual, FreeBSDVirtual)
  # assert class of FreeBSDVirtual is Virtual
  assert issubclass(FreeBSDVirtual, Virtual)

# Generated at 2022-06-23 02:00:48.108992
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    # Set up test data.
    os_release_fixture = '''
    PRETTY_NAME="Debian GNU/Linux 10 (buster)"
    NAME="Debian GNU/Linux"
    VERSION_ID="10"
    VERSION="10 (buster)"
    VERSION_CODENAME=buster
    ID=debian
    HOME_URL="https://www.debian.org/"
    SUPPORT_URL="https://www.debian.org/support"
    BUG_REPORT_URL="https://bugs.debian.org/"
    '''
    os_release_fixture_dict = {}
    for line in os_release_fixture.splitlines():
        key, sep, value = line.partition("=")
        if sep:
            os_release_f

# Generated at 2022-06-23 02:00:58.509179
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    # Test get_virtual_facts when on physical host
    results = {'virtualization_role': '',
               'virtualization_type': '',
               'virtualization_tech_host': set(),
               'virtualization_tech_guest': set()}
    v.sysctl_results = {}
    v.hw_model_facts = {'virtualization_tech_guest': set(),
                        'virtualization_tech_host': set(),
                        'virtualization_type': '',
                        'virtualization_role': ''}
    v.sysctl_results['kern.vm_guest'] = 'none'
    v.sysctl_results['hw.hv_vendor'] = ''
    v.sysctl_results['security.jail.jailed'] = 0
    v.hw_model_

# Generated at 2022-06-23 02:01:06.854009
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Initialize all variables
    virt = FreeBSDVirtual()
    # Run the get_virtual_facts and check for the keys in the dict
    data = virt.get_virtual_facts()
    # Set the variables to False
    key1 = key2 = False
    if 'virtualization_type' in data.keys():
        key1 = True
    if 'virtualization_role' in data.keys():
        key2 = True
    # Assert True for both key1 and key2
    assert key1 and key2

# Generated at 2022-06-23 02:01:09.165374
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:10.454910
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual()
    testobj.get_virtual_facts()

# Generated at 2022-06-23 02:01:17.025606
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(['vmware']),
        'virtualization_tech_guest': set(['vmware']),
    }
    assert FreeBSDVirtual().get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:01:18.360826
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:28.206126
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock get_file_content for FreeBSDVirtual.get_file_content()
    # kern.vm_guest. Freebsd
    facts_dct = {'security.jail.jailed': '0', 'hw.hv_vendor': 'BHYVE', 'hw.model': 'AMD Ryzen Threadripper 1950X 16-Core Processor', 'kern.vm_guest': 'jail', 'hw.hv_vmname': ''}
    vvirtual = FreeBSDVirtual(facts_dct)
    results = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'freebsd', 'jail'}, 'virtualization_tech_host': set()}
    assert(vvirtual.get_virtual_facts() == results)

    # Mock get_

# Generated at 2022-06-23 02:01:29.641160
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.detect()
    b = FreeBSDVirtualCollector()
    assert b.get_all_facts()

# Generated at 2022-06-23 02:01:31.795571
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:40.569921
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Creating FreeBSDVirtual object
    fbsd_virtual = FreeBSDVirtual()

    # Creating a dictionary to store the result
    result = {}
    result['virtualization_type'] = fbsd_virtual.detect_virt_product('kern.vm_guest')['virtualization_type']
    result['virtualization_role'] = fbsd_virtual.detect_virt_product('kern.vm_guest')['virtualization_role']
    result['virtualization_tech_host'] = fbsd_virtual.detect_virt_product('kern.vm_guest')['virtualization_tech_host']
    result['virtualization_tech_guest'] = fbsd_virtual.detect_virt_product('kern.vm_guest')['virtualization_tech_guest']

# Generated at 2022-06-23 02:01:42.780652
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instantiate FreeBSDVirtualCollector class
    facts = FreeBSDVirtualCollector()
    # Asserts
    assert facts.get_all() is not None

# Generated at 2022-06-23 02:01:44.982617
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:50.539975
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    data = FreeBSDVirtual({}, {}).get_virtual_facts()
    assert data['virtualization_type'] in ('', 'xen')
    assert data['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-23 02:01:51.813695
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:00.767292
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import ansible_facts

    # Set up all the mocks for the module
    fake_module = type('ansible.module_utils.facts.virtual.freebsd.ansible_module',
                       (object,), {})()
    fake_module.params = {'gather_subset': [], 'gather_timeout': 10, 'filter': '*'}
    fake_module.exit_json = lambda a: None
    fake_module.fail_json = lambda a: None

    # Construct the object
    inst = FreeBSDVirtual(fake_module)
    assert isinstance(inst, FreeBSDVirtual)

    # Test the facts
    results = inst.populate()
    assert 'virtualization_type' in results
    assert 'virtualization_role' in results

# Generated at 2022-06-23 02:02:05.956575
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_col = FreeBSDVirtualCollector()
    assert freebsd_virtual_col._platform == 'FreeBSD'
    assert freebsd_virtual_col._fact_class.platform == 'FreeBSD'

if __name__ == "__main__":
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:06.978059
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:07.946143
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({'module': 'fake'})
    assert virtual is not None

# Generated at 2022-06-23 02:02:12.556863
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual
    assert 'virtualization_type' in virtual.data
    assert 'virtualization_role' in virtual.data

# Generated at 2022-06-23 02:02:13.825477
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:26.078146
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.domain is None
    assert freebsd_virtual.product_name is None
    assert freebsd_virtual.serial_number is None
    assert freebsd_virtual.uuid is None
    assert freebsd_virtual.version is None
    assert freebsd_virtual.vmware_node_name == ''
    assert freebsd_virtual.vmware_server_name == ''
    assert freebsd_virtual.vmware_path == ''
    assert freebsd_virtual.vmware_guest_id == ''
    assert freebsd_virtual.vmware_host_guest == ''
    assert freebsd_virtual.virtualbox_path == ''
    assert freebsd_virtual.virtualbox_guest_ostype == ''
    assert free

# Generated at 2022-06-23 02:02:30.149146
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Tested with a FreeBSD VM running on Oracle VirtualBox
    result = {'ansible_facts':
    {'virtualization_role': '',
     'virtualization_type': '',
     'virtualization_tech_guest': set(['xen'])}}
    assert FreeBSDVirtual().get_virtual_facts() == result['ansible_facts']

# Generated at 2022-06-23 02:02:39.558452
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock all sysctl variables
    mocked_sysctl = {
        'kern.vm_guest': '',
        'hw.hv_vendor': '',
        'security.jail.jailed': '0',
        'hw.model': '',
        }

    # Mock all sysctl variables
    def mock_sysctl(self, key):
        return mocked_sysctl[key]

    fd_v = FreeBSDVirtualCollector()
    # Do not mock detect_virt_vendor
    fd_v.detect_virt_vendor = lambda x: {'virtualization_type': '', 'virtualization_role': '',
                                         'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    # TODO:
    # - Virtualization_type and virtualization_

# Generated at 2022-06-23 02:02:40.864915
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert not isinstance(facts, dict)

# Generated at 2022-06-23 02:02:52.922432
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtualCollector()
    vf = v.collect()

    assert(vf['virtualization_type'] in ('', 'xen', 'vmware', 'parallels', 'kvm', 'virtualbox',
                                         'hyper-v', 'bhyve', 'jail') or
           vf['virtualization_type'].startswith('openvz'))
    assert(vf['virtualization_role'] in ('', 'host', 'guest'))

    assert(type(vf['virtualization_tech_host']) == set)
    assert(type(vf['virtualization_tech_guest']) == set)

# Generated at 2022-06-23 02:02:55.786602
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._fact_class == FreeBSDVirtual
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:57.992141
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, {})
    # TODO: add unit test code
    assert virtual.get_virtual_facts() == ''

# Generated at 2022-06-23 02:03:00.141180
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''unit test for FreeBSDVirtual.get_virtual_facts'''
    virtual_obj = FreeBSDVirtual({})
    virtual_obj.set_defaults(option='value')
    virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:03:03.894812
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual(None)
    # If subclass doesn't override the platform property of Virtual
    # we would see 'Generic' (the value of Virtual.platform) here.
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:05.957137
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:09.132937
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:14.606707
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Return virtual facts.
    """
    fact_subclass = FreeBSDVirtual()
    facts = fact_subclass.get_virtual_facts()

    assert facts['virtualization_type'] in \
        ('xen', 'kvm', 'docker', 'jail', 'vmware', 'virtualbox', 'parallels', '')
    assert facts['virtualization_role'] in ('guest', 'host', '')

# Generated at 2022-06-23 02:03:17.430585
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector(None)
    assert fvc
    assert fvc._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:19.445523
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:20.948203
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual()
    assert module.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:23.412852
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:03:32.926904
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test that FreeBSD system info can be successfully read and facts
    extracted
    """
    import sys
    sys.modules['platform'] = FakePlatformModule()

    fake_obj = FakeSysctlModule()
    fake_obj.hw_model = 'bhyve'
    fake_obj.security_jail_jailed = '0'
    fake_obj.kern_vm_guest = 'vmware'

    fake_xen = FakeXenstoreModule()
    fake_xen.read = lambda x: 1

    sys.modules['ansible.module_utils.facts.virtual.sysctl'] = fake_obj
    sys.modules['ansible.module_utils.facts.virtual.xenstore'] = fake_xen

    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    system_

# Generated at 2022-06-23 02:03:35.644175
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_fact_instance = FreeBSDVirtual({})
    assert(isinstance(virt_fact_instance, Virtual))

# Generated at 2022-06-23 02:03:38.744506
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test call to constructor
    try:
        FreeBSDVirtualCollector()
    except(TypeError):
        assert True
    else:
        assert False


# Generated at 2022-06-23 02:03:39.541944
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f_virt = FreeBSDVirtual({})
    assert f_virt.platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:46.746491
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fact_subclass = FreeBSDVirtual({})
    virtual_facts = fact_subclass.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['', 'xen', 'vbox', 'vmware', 'kvm', 'jail', 'vserver', 'openvz', 'virtualbox', 'virtualpc', 'oracle', 'hyper-v']
    assert virtual_facts['virtualization_role'] in ['', 'guest', 'host', 'domu', 'dom0']
    assert virtual_facts['virtualization_technology'] in ['', 'xen', 'vbox', 'vmware', 'kvm', 'jail', 'vserver', 'openvz', 'vboxdrv', 'virtualbox', 'virtualpc', 'oracle', 'hyper-v']
    assert virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:03:51.764984
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    foo = FreeBSDVirtualCollector()
    assert foo.platform == 'FreeBSD'
    assert foo._fact_class is not None and issubclass(foo._fact_class, Virtual)


# Generated at 2022-06-23 02:03:53.927750
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Create a FreeBSDVirtualCollector object and check the
    # resulting name and platofrm
    vc = FreeBSDVirtualCollector()
    assert vc.name == 'FreeBSDVirtualCollector'
    assert vc.platform == 'FreeBSD'
    return True

# Generated at 2022-06-23 02:03:55.304901
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:59.630460
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = dict(
        virtualization_role='guest',
        virtualization_type='xen',
        virtualization_tech_guest=set(('xen', 'kvm')),
        virtualization_tech_host=set(('vmware',)),
    )

    assert FreeBSDVirtual().get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:04:11.053388
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    # A dict with the expected result.
    expected = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set([]),
        virtualization_tech_host=set([]),
    )
    # A dict with kern.vm_guest and hw.hv_vendor values.
    sysctl_values = dict(
        kern_vm_guest='',
        hw_hv_vendor='',
        security_jail_jailed='',
    )
    # A dict with hw.model values.
    model_values = dict(
        hw_model='',
    )
    # Create the FreeBSDVirtual object.
    virtual_fact = FreeBSD

# Generated at 2022-06-23 02:04:12.296200
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facter = FreeBSDVirtualCollector()
    assert facter.platform == FreeBSDVirtual.platform

# Generated at 2022-06-23 02:04:14.442803
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual



# Generated at 2022-06-23 02:04:17.620144
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:21.333131
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # create a FreeBSDVirtualCollector object
    facts_obj = FreeBSDVirtualCollector()
    # test the FreeBSDVirtualCollector object is initialized correctly or not
    assert facts_obj._platform == 'FreeBSD'
    assert facts_obj._fact_class == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:04:26.864494
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    import json
    facts = FreeBSDVirtual()
    assert json.dumps(facts.get_virtual_facts(), sort_keys=True) == '{"virtualization_role": "guest", "virtualization_type": "xen", "virtualization_tech_guest": [], "virtualization_tech_host": []}'

# Generated at 2022-06-23 02:04:30.066281
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class.__name__ == 'FreeBSDVirtual'



# Generated at 2022-06-23 02:04:34.188771
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fact_subclass = FreeBSDVirtual()
    facts = fact_subclass.get_virtual_facts()
    # Assert that a few mandatory keys have the right type
    assert isinstance(facts['virtualization_type'], str)

# Generated at 2022-06-23 02:04:36.050608
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None, None), VirtualCollector)


# Generated at 2022-06-23 02:04:39.067023
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.populate()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:04:40.714346
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except:
        pass


# Generated at 2022-06-23 02:04:43.372551
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:46.896608
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # 'get_virtual_facts' method returns nothing
    virtual = FreeBSDVirtual()
    res = virtual.get_virtual_facts()
    assert 'virtualization_type' in res
    assert 'virtualization_role' in res


# Generated at 2022-06-23 02:04:52.207841
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual_class = FreeBSDVirtual()

    # Test empty values as default
    assert fbsd_virtual_class._virtual_facts['virtualization_type'] == ''
    assert fbsd_virtual_class._virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:04:55.488980
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtualCollector()
    assert(virtual.get_virtual_facts()['virtualization_type'] == '')
    assert(virtual.get_virtual_facts()['virtualization_role'] == '')

# Generated at 2022-06-23 02:05:07.037751
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Results of method get_virtual_facts
    method_result = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(['vmware']),
                     'virtualization_tech_host': set(['vmware'])}

    # Create a FreeBSDVirtual object
    test_FreeBSDVirtual = FreeBSDVirtual(None)

    # Set expected results for methods is_jail, detect_virt_vendor,
    # detect_virt_product
    test_FreeBSDVirtual.is_jail = lambda: False
    test_FreeBSDVirtual.detect_virt_vendor = \
        lambda x: dict(virtualization_tech_guest=set(['vmware']),
                       virtualization_tech_host=set(['vmware']))

# Generated at 2022-06-23 02:05:09.979722
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test case 1: constructor of the class FreeBSDVirtual
    test = FreeBSDVirtual()
    assert test.platform == 'FreeBSD'
    assert test._name == 'FreeBSDVirtual'
    assert not test.seed_objs

# Generated at 2022-06-23 02:05:11.298742
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-23 02:05:19.975561
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_data = {
        'sysctl': {
            'security.jail.jailed': '0',
            'kern.vm_guest': 'other',
            'hw.hv_vendor': 'unknown',
            'hw.model': 'FreeBSD virtual machine',
        }
    }
    expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'other',
        'virtualization_tech_guest': set(['other']),
        'virtualization_tech_host': set(['other']),
    }

    facts_module = FreeBSDVirtualCollector(None, test_data, None)
    facts = facts_module.get_virtual_facts()

    assert facts == expected

# Generated at 2022-06-23 02:05:25.269042
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()

    assert(fv.platform == 'FreeBSD')
    assert(fv.virtualization_type == '')
    assert(fv.virtualization_role == '')
    assert(fv.virtualization_tech_guest == set())
    assert(fv.virtualization_tech_host == set())

# Generated at 2022-06-23 02:05:38.239622
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # create a FreeBSDVirtual object
    free_bsd_virtual = FreeBSDVirtual()

    # create a mock value of sysctl kern.vm_guest
    kern_vm_guest_dict = {
        'hw.hv_vendor': '',
        'security.jail.jailed': '',
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    # create a mock value of sysctl hw.hv_vendor

# Generated at 2022-06-23 02:05:40.900613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_obj = FreeBSDVirtualCollector()
    assert virtual_collector_obj._platform == 'FreeBSD'
    assert virtual_collector_obj._fact_class is FreeBSDVirtual


# Generated at 2022-06-23 02:05:45.330012
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class.platform == 'FreeBSD'



# Generated at 2022-06-23 02:05:46.873995
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:51.401206
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    expected_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_system='',
        virtualization_subsystem='',
        virtualization_hypervisor=[],
        virtualization_host=[],
        virtualization_guest=[],
    )
    assert virtual_facts.get_virtual_facts() == expected_facts

# Generated at 2022-06-23 02:05:53.670954
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for FreeBSDVirtual constructor.'''
    facts = FreeBSDVirtual(None, None)
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:56.646745
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._fact_class is not None
    assert facts._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:58.435825
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(dict()).platform == 'FreeBSD'


# Generated at 2022-06-23 02:06:00.343780
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_instance = FreeBSDVirtual(None)
    assert isinstance(virt_instance, FreeBSDVirtual)

# Generated at 2022-06-23 02:06:01.607705
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    obj.collect()
    assert True

# Generated at 2022-06-23 02:06:05.718531
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-23 02:06:10.432343
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_dict = FreeBSDVirtual().get_virtual_facts()
    assert test_dict['virtualization_type'] in ['', 'xen']
    assert test_dict['virtualization_role'] in ['', 'guest']
    assert test_dict['virtualization_tech'] in [[], ['xen']]

# Generated at 2022-06-23 02:06:16.226918
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] in ['xen', '', 'virtualbox', 'vmware']
    assert virtual_facts['virtualization_role'] in ['guest', 'host']

# Generated at 2022-06-23 02:06:17.243300
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert(virtual.platform == 'FreeBSD')

# Generated at 2022-06-23 02:06:28.837470
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = dict(
        virtualization_type='',
        virtualization_role=''
    )

    def get_virtual_facts_mock(self, virt, sysctl):
        virt_facts = dict(
            virtualization_type='xen',
            virtualization_role='guest'
        )
        # returnvirt_facts = dict(virtual_facts, **virt_facts)
        return virt_facts

    get_virtual_facts_orig = FreeBSDVirtual.get_virtual_facts
    FreeBSDVirtual.get_virtual_facts = get_virtual_facts_mock

    virtual_facts.update(FreeBSDVirtual().get_virtual_facts())

    FreeBSDVirtual.get_virtual_facts = get_virtual_facts_orig

    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:06:41.105266
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # In FreeBSD virtual facts class, get_virtual_facts() function is about 170 lines
    # long, so we've tested each of "branches" in it.

    # Empty values as default

    virtual_facts = VirtualCollector._get_virtual_facts_platform({}, 'FreeBSD')

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Fake virtual detections

    fake_facts = {
        'virtualization_type': 'fake',
        'virtualization_role': 'fake',
        'virtualization_tech_guest': {'fake'},
        'virtualization_tech_host': {'fake'},
    }
    virtual_facts = VirtualCollector._get_virtual_facts_platform(fake_facts, 'FreeBSD')

    assert virtual_facts == fake

# Generated at 2022-06-23 02:06:45.451380
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = 'ansible.module_utils.facts.virtual.freebsd'
    sys = {'platform': 'FreeBSD'}
    fbd = FreeBSDVirtual(module, sys)
    assert fbd.sysctl == 'sysctl'

# Generated at 2022-06-23 02:06:57.025328
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create instance of class FreeBSDVirtual
    virtual = FreeBSDVirtual()
    # Create facts
    facts = {'distribution_version': '10.2'}
    # Call method of class FreeBSDVirtual
    virtual.get_virtual_facts(facts)
    # Test assertion
    assert virtual.facts['virtualization_type'] == ''
    assert virtual.facts['virtualization_role'] == ''
    assert virtual.facts['virtualization_tech_guest'] == set()
    assert virtual.facts['virtualization_tech_host'] == set()

    # Create file /dev/xen/xenstore
    with open('/dev/xen/xenstore', 'w') as fh:
        fh.write('')
    # Create instance of class FreeBSDVirtual
    virtual = FreeBSDVirtual()
    # Create facts

# Generated at 2022-06-23 02:07:02.358350
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_obj = FreeBSDVirtual()
    assert virtual_facts_obj.platform == 'FreeBSD'
    assert virtual_facts_obj.get_virtual_facts().get('virtualization_type') == ''
    assert virtual_facts_obj.get_virtual_facts().get('virtualization_role') == ''

# Generated at 2022-06-23 02:07:05.710575
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()
    assert FreeBSDVirtual().collect().to_dict() == virtual_facts

# Generated at 2022-06-23 02:07:10.566055
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    facts = v.get_virtual_facts()

    assert('virtualization_type' in facts)
    assert('virtualization_role' in facts)
    assert('virtualization_tech_guest' in facts)
    assert('virtualization_tech_host' in facts)

# Generated at 2022-06-23 02:07:12.806378
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:17.556287
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    keys = ("product_name", "virtualization_type", "virtualization_role",
            "virtualization_tech_host", "virtualization_tech_guest")
    assert set(keys).issubset(set(virtual_facts.keys()))

# Generated at 2022-06-23 02:07:20.066527
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:07:24.042267
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    hostv = FreeBSDVirtual({})
    assert hostv.virtualization_type == ''
    assert hostv.virtualization_role == ''
    assert hostv.virtualization_tech_host == set()
    assert hostv.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:07:25.656480
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:30.682853
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test the FreeBSDVirtual class
    module_name = 'ansible.module_utils.facts.virtual.FreeBSDVirtual'
    module = __import__(module_name, fromlist=[''])
    my_obj = module.FreeBSDVirtual()
    assert my_obj
    assert my_obj.platform == 'FreeBSD'


# Generated at 2022-06-23 02:07:32.765380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    gvf = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in gvf
    assert 'virtualization_role' in gvf
    assert 'virtualization_tech_guest' in gvf
    assert 'virtualization_tech_host' in gvf

# Generated at 2022-06-23 02:07:36.734800
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Unit test for constructor of class FreeBSDVirtual
    """
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == "FreeBSD"

# Generated at 2022-06-23 02:07:38.643740
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual({})
    virtual_facts = vf.get_virtual_facts()
    assert type(virtual_facts) is dict

# Generated at 2022-06-23 02:07:40.391924
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    myCollector = FreeBSDVirtualCollector()
    assert myCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:42.006250
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual(None, None)
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:54.301077
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_object = FreeBSDVirtual()

    '''
    Return values of get_file_content and get_sysctl_value
    methods of FreeBSDVirtual class
    '''
    test_object.get_file_content = MagicMock(
        return_value='Xen dom0\n'
    )

# Generated at 2022-06-23 02:07:56.445620
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:58.804991
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Constructor of FreeBSDVirtual
    """
    virtual = FreeBSDVirtual(None)
    # Assert platform
    assert virtual.platform == "FreeBSD"



# Generated at 2022-06-23 02:08:10.439268
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test constructor of class FreeBSDVirtual'''
    # Test constructor of class FreeBSDVirtualCollector
    # Values obtained from one of the virtualization technologies
    # should be set as virtualization_type and virtualization_role
    freebsd_virtual = FreeBSDVirtual()

    # When the /dev/xen/xenstore file exists, virtualization_type should
    # be set to 'xen' and virtualization_role should be set to 'guest'
    freebsd_virtual._is_file = lambda filename: filename == '/dev/xen/xenstore'

# Generated at 2022-06-23 02:08:13.161791
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert(virtual_facts['virtualization_type'] == 'xen')

# Generated at 2022-06-23 02:08:15.829343
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv is not None

# Generated at 2022-06-23 02:08:20.579812
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_subclass = FreeBSDVirtualCollector()
    assert fact_subclass._fact_class is not None
    assert fact_subclass._platform is not None
    assert fact_subclass._fact_class.platform == fact_subclass._platform
    assert fact_subclass._fact_class.__module__ == __name__

# Generated at 2022-06-23 02:08:24.164315
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.virt_type is None
    assert virtual.virt_subtype is None

# Generated at 2022-06-23 02:08:28.202351
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    config = dict()

    # Setup FreeBSDVirtual class
    freebsd_virtual_obj = FreeBSDVirtual(config)

    # Call method get_virtual_facts
    freebsd_virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:08:34.459145
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    if sys.platform == 'freebsd10':
        test_freebsd = FreeBSDVirtual(None)
        virtual_facts = test_freebsd.get_virtual_facts()
        assert virtual_facts['virtualization_type'] != ''
        assert sorted(virtual_facts['virtualization_tech_host']) == sorted(['xen', 'kvm', 'qemu', 'vmware'])
        assert sorted(virtual_facts['virtualization_tech_guest']) == sorted(['xen', 'kvm', 'qemu', 'vmware'])
    else:
        pass


# Generated at 2022-06-23 02:08:36.047420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    my_fbc = FreeBSDVirtualCollector()
    assert my_fbc is not None

# Generated at 2022-06-23 02:08:38.621067
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    collector = FreeBSDVirtualCollector()
    facts = collector.collect(None, None)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-23 02:08:41.857442
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None)._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:53.327946
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    file_name = 'ansible/module_utils/facts/virtual/sysctl.py'
    kern_vm_guest_file = 'ansible/module_utils/facts/virtual/tests/fixtures/freebsd_sysctl_kern_vm_guest'
    hw_hv_vendor_file = 'ansible/module_utils/facts/virtual/tests/fixtures/freebsd_sysctl_hw_hv_vendor'
    hw_model_file = 'ansible/module_utils/facts/virtual/tests/fixtures/freebsd_sysctl_hw_model'
    sec_jail_jailed_file = 'ansible/module_utils/facts/virtual/tests/fixtures/freebsd_security_jail_jailed'

    # Mocks for get_file_

# Generated at 2022-06-23 02:08:55.942436
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-23 02:08:58.172068
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:09:02.139767
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:09:04.267877
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:09:06.808366
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import virtual as virtual_module
    virtual_module.collector = FreeBSDVirtualCollector
    h = FreeBSDVirtual()
    h._get_platform_specific_virtual_facts()

# Generated at 2022-06-23 02:09:08.964753
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f._fact_class == FreeBSDVirtual
    assert f._platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:10.529840
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    instance = FreeBSDVirtual()

    # 1. Check platform
    assert instance.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:14.964340
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = dict()
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    # Create an instance of FreeBSDVirtual Class
    bsd_virtual = FreeBSDVirtual()

    # Get only the virtual_facts dictionary
    virtual_facts = bsd_virtual.get_virtual_facts();

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:09:18.611215
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    # There is no way to test this part as it is based on FreeBSD sysctl
    # values which are not accessible from within the facter unit test
    # framework



# Generated at 2022-06-23 02:09:20.599725
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    # This is a FreeBSD-specific subclass of Virtual.
    bsd_collector = FreeBSDVirtualCollector()
    assert isinstance(bsd_collector, VirtualCollector)

# Generated at 2022-06-23 02:09:22.114812
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:09:33.196372
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsdv = FreeBSDVirtual()
    fbsdv.set_virtual_facts = dict()
    fbsdv.set_virtual_facts['kern.vm_guest'] = 'vmware'
    fbsdv.set_virtual_facts['hw.model'] = 'FreeBSD/amd64'
    fbsdv.set_virtual_facts['hw.hv_vendor'] = ''
    fbsdv.set_virtual_facts['security.jail.jailed'] = False
    virtual_facts = fbsdv.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_tech_host' in virtual_facts.keys()

# Generated at 2022-06-23 02:09:39.362352
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsdv = FreeBSDVirtual({})
    assert bsdv.get_virtual_facts() == {
        'vm': True,
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': set(['xen']),
        'virtualization_tech_guest': set(['xen']),
    }

# Generated at 2022-06-23 02:09:50.150519
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class mock_FreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            pass
        def detect_virt_product(self, sysctl_key):
            return {'virtualization_type': 'xen',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': {'xen'},
                    'virtualization_tech_host': {'xen'}
                    }
    def get_file_contents(filename):
        if filename == '/dev/xen/xenstore':
            return 'xenstore'
        else:
            return ''

    virtual_facts = mock_FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
   

# Generated at 2022-06-23 02:09:54.305665
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == 'FreeBSD'
    assert freebsd.virtualization_type is None
    assert freebsd.virtualization_role is None


# Generated at 2022-06-23 02:09:55.947393
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbv = FreeBSDVirtual()
    fbv.get_virtual_facts()

# Generated at 2022-06-23 02:09:56.502668
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:10:00.227695
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = dict()
    __virtual__ = lambda: 'FreeBSD'
    virtual_facts = FreeBSDVirtualCollector(__virtual__, facts_dict)
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:03.937930
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:10:10.609303
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual(None)
    fb_virtual.get_virtual_facts()
    assert fb_virtual.platform == 'FreeBSD'
    # Test virtualization_type set
    assert fb_virtual.virtualization_type is not None
    assert fb_virtual.virtualization_type != ''
    # Test virtualization_role set
    assert fb_virtual.virtualization_role is not None
    assert fb_virtual.virtualization_role != ''

# Generated at 2022-06-23 02:10:11.891032
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    a = FreeBSDVirtual({})
    assert a.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:17.892555
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # The Virtual class requires one constructor parameter which is a path to the sysfs
    # in the file system.  Here we just set it to '/' since this is sufficient for
    # the purposes of the unit test.
    virtual_facts = FreeBSDVirtual('/')
    # Call the get_virtual_facts method to run the fact collection process.
    virtual_facts.get_virtual_facts()
    # The following are some of the data keys that we expect to be present in the returned
    # virtual facts data structure.  If any of these are not present then the assertion
    # will fail.
    assert 'virtualization_type' in virtual_facts.data
    assert 'virtualization_role' in virtual_facts.data

# Generated at 2022-06-23 02:10:23.609920
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:10:26.400667
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector_obj = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector_obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:26.964162
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:10:29.234024
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    mock_platform = 'FreeBSD'
    mock_virtual = FreeBSDVirtualCollector(mock_platform)
    assert mock_virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:33.142713
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector.collect() == FreeBSDVirtual().get_all_facts()

# Generated at 2022-06-23 02:10:34.409702
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    # Test properties
    assert collector.platform == collecto

# Generated at 2022-06-23 02:10:41.237250
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == ''
    assert virtual_facts.get('virtualization_role') == ''
    assert virtual_facts.get('virtualization_tech_guest') == set()
    assert virtual_facts.get('virtualization_tech_host') == set()