

# Generated at 2022-06-23 02:00:43.459177
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSD
    facts = VirtualFreeBSD().get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:00:45.807798
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    _platform = 'FreeBSD'
    _fact_class = 'FreeBSDVirtual'

    obj = FreeBSDVirtualCollector()
    assert obj._platform == _platform
    assert obj._fact_class._platform == _platform
    assert obj._fact_class.__name__ == _fact_class

# Generated at 2022-06-23 02:00:47.270256
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector

# Generated at 2022-06-23 02:00:52.024320
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert len(vc.collect()) == 1



# Generated at 2022-06-23 02:00:54.463071
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    instantiating should create a FreeBSDVirtualCollector
    """
    assert(isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector))

# Generated at 2022-06-23 02:01:06.346312
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # Sysctl module mockup
    class SysctlMockUp(object):
        def __init__(self, data):
            self.data = data

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            pass

        def __call__(self, *args, **kwargs):
            return self

        def get(self, *args, **kwargs):
            return self

        def to_dict(self, *args, **kwargs):
            return self.data

    # /dev/(v)eth?/mockup
    class VethMockUp(dict):
        def __init__(self, data):
            super(VethMockUp, self).__init__(data)

# Generated at 2022-06-23 02:01:09.418027
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Verifies that the constructor creates an object with two attributes.
    fvc = FreeBSDVirtualCollector()
    assert hasattr(fvc, '_fact_class')
    assert hasattr(fvc, '_platform')

# Generated at 2022-06-23 02:01:20.555934
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test with a freebsd host
    freebsd_host = FreeBSDVirtualCollector()
    freebsd_host.collect()
    assert freebsd_host.data['ansible_facts']['virtualization_type'] != ''
    assert freebsd_host.data['ansible_facts']['virtualization_role'] != ''
    assert freebsd_host.data['ansible_facts']['virtualization_type'] in freebsd_host.data['ansible_facts']['virtualization_tech_host']
    assert freebsd_host.data['ansible_facts']['virtualization_role'] in freebsd_host.data['ansible_facts']['virtualization_tech_host']

# Generated at 2022-06-23 02:01:22.540275
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.get_facts() is not {}

# Generated at 2022-06-23 02:01:24.167700
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:27.248491
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:01:29.574529
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({}, {})
    assert fv


# Generated at 2022-06-23 02:01:38.891364
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:40.418612
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual().platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:41.503417
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual({}, {}).platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:42.863535
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:45.923478
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector().collect()
    assert facts['virtualization_type'] == 'xen', "FreeBSD platform is not detected as 'xen'"
    assert facts['virtualization_role'] == 'guest', "FreeBSD platform is not detected as 'guest'"

# Generated at 2022-06-23 02:01:48.611318
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fc = FreeBSDVirtualCollector()
    assert fc.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:58.643246
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest
    assert FreeBSDVirtual().get_virtual_facts() == {'virtualization_type': '',
                                                    'virtualization_role': '',
                                                    'virtualization_tech_guest': set(),
                                                    'virtualization_tech_host': set()}

    assert FreeBSDVirtual().get_all_facts() == {'virtualization_type': '',
                                                'virtualization_role': '',
                                                'virtualization_tech_guest': set(),
                                                'virtualization_tech_host': set()}

    with pytest.raises(NotImplementedError):
        FreeBSDVirtual().get_virtual_categories()

# Generated at 2022-06-23 02:02:01.194312
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    facts = FreeBSDVirtual({}, None).get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'


# Generated at 2022-06-23 02:02:04.711074
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsdpv = FreeBSDVirtual()
    freebsdpv.get_virtual_facts()
    freebsdpv.virtualization_role
    freebsdpv.virtualization_type

# Generated at 2022-06-23 02:02:05.547175
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual()

# Generated at 2022-06-23 02:02:08.762242
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__doc__ == '''\
FreeBSD-specific subclass of VirtualCollector.
It collects virtual facts using the Virtual class.
'''
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'



# Generated at 2022-06-23 02:02:18.519187
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl_xen_expected_dict = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(['xen'])
    }

    sysctl_kvm_expected_dict = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(['kvm'])
    }


# Generated at 2022-06-23 02:02:22.894250
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    # Create an instance of FreeBSDVirtual class
    virtual = FreeBSDVirtual()
    # tests for virtual.virtualization_type
    assert virtual.virtualization_type == ''
    # tests for virtual.virtualization_role
    assert virtual.virtualization_role == ''

# Generated at 2022-06-23 02:02:27.606827
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''
    assert virtual.data['virtualization_tech_guest'] == set()
    assert virtual.data['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:02:32.284282
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check if class exists
    assert 'FreeBSDVirtualCollector' in globals()
    # Check __init__
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:36.105973
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:02:46.791470
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test empty values as default facts
    empty_freebsd_virtual = FreeBSDVirtual({})
    empty_virtual_facts = empty_freebsd_virtual.get_virtual_facts()

    assert empty_virtual_facts == {'virtualization_type': '',
                                   'virtualization_role': '',
                                   'virtualization_tech_host': set(),
                                   'virtualization_tech_guest': set()}

    # Test facts for a FreeBSD host inside a Xen host
    xen_freebsd_virtual = FreeBSDVirtual({'sysctl': {'kern.vm_guest': 'xen',
                                                     'security.jail.jailed': 0,
                                                     'hw.hv_vendor': 'Xen'}})

    virtual_facts = xen_freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:02:58.052263
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Run get_virtual_facts with a mocked sysctl command
    # that returns a Xen guest virtualization detection.
    f = FreeBSDVirtual()
    f.get_virtual_facts_from_sysctl = lambda sysctl: \
        {'virtualization_tech_guest': set(['xen']),
         'virtualization_tech_host': set(['xen']),
         'virtualization_type': 'xen',
         'virtualization_role': 'guest'}
    virtual_facts = f.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:03:08.955396
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)

    # Test that valid return values are always set
    assert virtual_facts['virtualization_type'] in ['', 'xen']
    assert virtual_facts['virtualization_role'] in ['', 'guest']

# Generated at 2022-06-23 02:03:11.478736
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if not FreeBSDVirtualCollector().has_sysctls():
        raise AssertionError("FreeBSDVirtualCollector did not correctly set has_sysctls to True")

# Generated at 2022-06-23 02:03:18.284675
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb_virtual = FreeBSDVirtual()
    virtual_facts = fb_virtual.get_virtual_facts()
    assert virtual_facts.get('virtualization_role') == 'guest'
    assert virtual_facts.get('virtualization_type') == 'xen'
    assert virtual_facts.get('virtualization_tech_guest', set()) == {'xen'}
    assert virtual_facts.get('virtualization_tech_host', set()) == set()

# Generated at 2022-06-23 02:03:20.948803
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector.platform == 'FreeBSD'
    assert facts_collector.fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:03:23.788393
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Check that FreeBSDVirtual class is created correctly.
    obj = FreeBSDVirtual()
    assert obj.platform == "FreeBSD"

# Generated at 2022-06-23 02:03:33.074873
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual()
    mock_facts = {
        'kernel': 'FreeBSD',
        'hw.model': 'mock_hw_model',
        'kern.vm_guest': 'generic',
        'security.jail.jailed': '0',
        'hw.hv_vendor': 'bhyve',
    }
    vf.collect(mock_facts)
    virtual_facts = vf.get_virtual_facts()
    assert len(virtual_facts) > 0
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'generic'
    assert set(virtual_facts['virtualization_tech_guest']) == set(['generic'])
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:03:34.552845
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts is not None

# Generated at 2022-06-23 02:03:44.308219
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin


# Generated at 2022-06-23 02:03:52.122938
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.system, "FreeBSDVirtual() failed, no valid facts"
    assert freebsd_virtual.get_platform() == "FreeBSD", "freebsd_virtual.get_platform() failed, expected 'FreeBSD'"

# Generated at 2022-06-23 02:04:00.715483
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    if os.path.exists('/dev/xen/xenstore'):
        assert facts['virtualization_type'] == 'xen'
        assert facts['virtualization_role'] == 'guest'
        assert 'xen' in facts['virtualization_tech_guest']
        assert 'xen' in facts['virtualization_tech_host']

# Generated at 2022-06-23 02:04:03.709786
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.bsd import FreeBSDVirtualCollector
    sut = FreeBSDVirtualCollector()
    assert sut.fact_class._platform == "FreeBSD"

# Generated at 2022-06-23 02:04:05.849122
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:17.843841
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import virtual as virtual_facts
    from ansible.module_utils.facts import collect_subset
    from ansible.module_utils.facts.utils import get_file_content
    virtual_facts.collect_subset = collect_subset
    virtual_facts.get_file_content = get_file_content


# Generated at 2022-06-23 02:04:30.041910
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import ArchSysctlDetectionMixin
    class FreeBSDVirtualWithArchSysctlDetection(
            FreeBSDVirtual,
            ArchSysctlDetectionMixin
    ):
        pass


# Generated at 2022-06-23 02:04:31.269832
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector(None)

# Generated at 2022-06-23 02:04:34.440059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert None != fv
    assert isinstance(fv, FreeBSDVirtualCollector)


# Generated at 2022-06-23 02:04:37.020417
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:44.508095
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    freebsd_virtual = FreeBSDVirtual(None, {}, virt_facts)
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''
    assert freebsd_virtual.virtualization_tech_guest == set()
    assert freebsd_virtual.virtualization_tech_host == set()

# Generated at 2022-06-23 02:04:46.431997
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual(dict())
    assert fbv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:47.012610
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:04:51.234680
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_object = FreeBSDVirtual()
    # Test if returned value is a dict
    assert isinstance(test_object.get_virtual_facts(), dict)



# Generated at 2022-06-23 02:04:52.516829
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:02.603566
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual()
    fbsd_virtual._sysctl.read.return_value = {'kern.vm_guest': 'user', 'hw.hv_vendor': 'bhyve', 'security.jail.jailed': '0', 'hw.model': 'Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz'}
    fbsd_virtual._machine_id.read().return_value = {'id': '', 'type': 'virtualbox'}
    fbsd_virtual._product_id.read().return_value = {'product_id': 'VirtualBox'}
    fbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:05:04.991442
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtualFactCollector = FreeBSDVirtualCollector()
    assert virtualFactCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:07.882729
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    assert isinstance(freebsd_virtual_facts, dict)

# Generated at 2022-06-23 02:05:09.318125
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:12.487804
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fake_module = type('module', (object,), {'params': {'gather_subset': '!all,!min'}})
    facts_ins = FreeBSDVirtual(fake_module)
    assert facts_ins.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:17.870232
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({}, {})
    virtual_facts = facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:05:24.816261
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None
    """Test the constructor of class FreeBSDVirtualCollector."""
    with mock.patch('ansible.module_utils.facts.virtual.sysctl.VirtualSysctlDetectionMixin.detect_virt_product') as mock_detect_virt:
        FreeBSDVirtualCollector()
        mock_detect_virt.assert_called()

# Generated at 2022-06-23 02:05:27.385120
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Arrange
    # Use default FreeBSDVirtual object
    # Act
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Assert
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:05:32.404813
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt.collect_virtual_facts()
    assert virt.facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:05:33.315582
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 02:05:36.219057
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:46.111834
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # If we are running in a VPS/VM, we should be able to get virtual facts
    if os.path.exists('/proc/self/status'):
        virtual_facts = FreeBSDVirtual().get_virtual_facts()
        assert virtual_facts['virtualization_type'] != ''
        assert virtual_facts['virtualization_role'] != ''
    # Otherwise, we should not be able to get any virtual facts
    else:
        virtual_facts = FreeBSDVirtual().get_virtual_facts()
        assert virtual_facts['virtualization_type'] == ''
        assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:05:50.593223
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert ('virtualization_role' in virtual_facts)
    assert ('virtualization_type' in virtual_facts)
    assert ('virtualization_tech_guest' in virtual_facts)
    assert ('virtualization_tech_host' in virtual_facts)

# Generated at 2022-06-23 02:05:56.171821
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Constructor should set Virtual.platform to 'FreeBSD' and
    # Virtual.virtualization_type to ''
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == 'FreeBSD'
    assert freebsd.virtualization_type == ''


# Unit tests for get_virtual_facts()

# Generated at 2022-06-23 02:05:59.374890
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:00.644066
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector(
        module=dict(),
        subprocess=None)

# Generated at 2022-06-23 02:06:02.984935
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    test_virtual_obj = FreeBSDVirtual()
    assert test_virtual_obj.virtualization_type == ''
    assert test_virtual_obj.virtualization_role == ''
    assert test_virtual_obj.virtualization_tech_host == set()
    assert test_virtual_obj.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:06:05.630110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  f = FreeBSDVirtualCollector()
  assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:08.552851
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    facts = virt.get_virtual_facts()
    assert(facts['virtualization_type'] == 'xen')
    assert(facts['virtualization_role'] == 'guest')

# Generated at 2022-06-23 02:06:18.764831
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.posix import PosixVirtual

    # Method is_jail() of class FreeBSDVirtual
    def is_jail(self):
        return False

    class TestFreeBSDVirtual(FreeBSDVirtual, PosixVirtual):
        __test__ = False

    class TestFreeBSDVirtualSysctl(TestFreeBSDVirtual, VirtualSysctlDetectionMixin):
        # Method is_jail() of class FreeBSDVirtual
        def is_jail(self):
            return False

    virtual = TestFreeBSDVirtualSysctl()
    # Method get_virtual_facts() of class FreeBSDVirtual
    facts = virtual.get_virtual_facts

# Generated at 2022-06-23 02:06:30.131600
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""

    def mock_detect_virt_product(sysctl):
        """Mock for method detect_virt_product of class FreeBSDVirtual"""

        class mock_virtual_facts(object):
            virtualization_tech_guest = set()
            virtualization_tech_host = set()

            @staticmethod
            def update(update_values):
                """Mock for method update of class dict"""
                mock_virtual_facts.virtualization_tech_guest.update(
                    update_values['virtualization_tech_guest'])
                mock_virtual_facts.virtualization_tech_host.update(
                    update_values['virtualization_tech_host'])

        if sysctl == 'kern.vm_guest':
            mock_virtual_facts.virtualization_tech

# Generated at 2022-06-23 02:06:41.845335
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Fake a FreeBSD environment
    sysctl_values = {
      'hw.hv_vendor': 'None',
      'hw.model': 'FreeBSD',
      'kern.vm_guest': 'none',
      'security.jail.jailed': '0'
    }
    # Create an instance of VirtualSysctlDetectionMixin
    sysctl_mixin = VirtualSysctlDetectionMixin()
    # Fake sysctl behaviour
    sysctl_mixin._get_sysctl_cmd_values = sysctl_mixin._sysctl_cmd_values
    # Create an instance of FreeBSDVirtual
    fact_class = FreeBSDVirtual()

    facts = fact_class.get_virtual_facts(sysctl_mixin)


# Generated at 2022-06-23 02:06:43.859719
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = {}
    virt = FreeBSDVirtual(module)
    assert virt.module == module

# Generated at 2022-06-23 02:06:48.917279
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_info = FreeBSDVirtual()
    assert virtual_info.platform == 'FreeBSD'
    assert virtual_info.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_info.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:06:51.058262
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tmp_obj = FreeBSDVirtualCollector()
    assert tmp_obj._fact_class == FreeBSDVirtual
    assert tmp_obj._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:53.724552
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_virtual_facts = {'virtualization_type': '', 'virtualization_role': ''}
    assert FreeBSDVirtual().get_virtual_facts() == fake_virtual_facts

# Generated at 2022-06-23 02:07:05.518950
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_run = FreeBSDVirtual(module=None).get_virtual_facts()
    if isinstance(virtual_facts_run['virtualization_tech_guest'], set):
        virtual_facts_run['virtualization_tech_guest'] = list(virtual_facts_run['virtualization_tech_guest'])
    if isinstance(virtual_facts_run['virtualization_tech_host'], set):
        virtual_facts_run['virtualization_tech_host'] = list(virtual_facts_run['virtualization_tech_host'])

# Generated at 2022-06-23 02:07:06.908803
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:09.140796
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert FactClass is not None

# Generated at 2022-06-23 02:07:19.976230
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsdv = FreeBSDVirtual(dict())

    # Test for virtualization_type and virtualization_role
    mock_sysctl_dict = {'kern.vm_guest': 'xen', }
    bsdv._get_sysctl_facts = lambda: mock_sysctl_dict

    mock_vm_model_dict = {'vm_vendor': '', 'vm_product': ''}
    bsdv._get_vm_facts = lambda: mock_vm_model_dict

    bsdv_facts = bsdv.get_virtual_facts()

    # virtualization_type = xen
    # virtualization_role = guest
    assert bsdv_facts['virtualization_type'] == 'xen'
    assert bsdv_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:07:21.888345
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freeBSD = FreeBSDVirtual()
    assert freeBSD.platform == 'FreeBSD'
    assert freeBSD._collector == ''

# Generated at 2022-06-23 02:07:32.436584
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    freebsd_virtual_obj = FreeBSDVirtual(None)
    assert freebsd_virtual_obj.platform == 'FreeBSD'
    assert freebsd_virtual_obj._sysctl_file_path == '/proc/sysctl'
    assert freebsd_virtual_obj._sysctl_virtual_path == '/proc/sysctl'
    assert freebsd_virtual_obj._sysctl_virtual_pattern == '%s'
    assert freebsd_virtual_obj._sysctl_virtual_key == ''

    assert freebsd_virtual_obj._sysctl_product_path == '/proc/sysctl'
    assert freebsd_virtual_obj._sysctl_product_pattern == '%s'
    assert freebsd_virtual_obj._sysctl_product_key == ''

    assert freebsd_virtual_obj._hw_model

# Generated at 2022-06-23 02:07:41.288717
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    virtual_dict = virtual.get_virtual_facts()

    # The FreeBSDVirtual class should be the most specific class, so
    # virtual_collector should be an instance of the FreeBSDVirtual class.
    assert isinstance(virtual, FreeBSDVirtual)

    # FreebsdVirtual should be a subclass of Virtual.
    assert issubclass(FreeBSDVirtual, Virtual)

    # Test that the _platform and _fact_class attributes of the
    # VirtualCollector class have been changed for the FreeBSDVirtual class.
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:43.389762
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual({})
    facts = vf.get_virtual_facts()
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:07:55.374167
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:07:57.091156
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    a = FreeBSDVirtualCollector()
    assert type(a) == FreeBSDVirtualCollector


# Generated at 2022-06-23 02:08:03.849372
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Arrange
    d = {'virtual_facts': {'virtualization_type': '', 'virtualization_role': ''}}
    # Act
    f = FreeBSDVirtual(d)
    f.get_virtual_facts()
    # Assert
    assert d['virtual_facts']['virtualization_type'] == ''
    assert d['virtual_facts']['virtualization_role'] == ''

# Generated at 2022-06-23 02:08:06.866346
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual({})
    assert fbsd_virtual.data['virtualization_type'] == ''
    assert fbsd_virtual.data['virtualization_role'] == ''

# Generated at 2022-06-23 02:08:09.633125
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:17.195546
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    '''
    Mock sysctl and call Virtual.get_virtual_facts method
    to test virtual facts
    '''

    with open(os.devnull, 'w') as FNULL:
        from ansible.module_utils import basic

        mocker = basic.AnsibleModule(
            argument_spec={}
        )

        mocker.get_bin_path = lambda *args, **kwargs: 'find'
        mocker.run_command = lambda *args, **kwargs: (0, '', '')

        virtual = FreeBSDVirtual(mocker)
        virtual.get_virtual_facts = lambda *args, **kwargs: {}
        virtual.get_virtual_facts()

# Generated at 2022-06-23 02:08:21.119657
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_raw_facts = {}
    expected_raw_facts['virtualization_type'] = ''
    expected_raw_facts['virtualization_role'] = ''

    virtual_facts = FreeBSDVirtual({}, {})
    assert expected_raw_facts == virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:08:26.011462
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if os.name == 'posix':
        # test for FreeBSD
        freebsd = FreeBSDVirtualCollector()
        assert freebsd.platform == 'FreeBSD'
        assert freebsd._fact_class is not None

# Generated at 2022-06-23 02:08:34.729978
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def test_get_dict_values(obj, keys):
        retval = []
        for key in keys:
            if key in obj:
                retval.append(obj[key])
            else:
                retval.append(None)
        return retval

    # Fake guest_facts about the guest
    guest_facts = {
        'kern.vm_guest': 'test_guest',
        'hw.hv_vendor': 'test_guest',
        'security.jail.jailed': 1,
        'hw.model' : 'test_guest'
    }

    # Fake host_facts about the host

# Generated at 2022-06-23 02:08:37.087668
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsdvc = FreeBSDVirtualCollector()
    assert bsdvc.platform == 'FreeBSD'
    assert bsdvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:38.537348
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_facts = FreeBSDVirtual()
    assert type(virt_facts) is FreeBSDVirtual

# Generated at 2022-06-23 02:08:42.840427
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt = FreeBSDVirtualCollector()
    assert isinstance(virt, VirtualCollector)
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:48.743460
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Tests FreeBSDVirtual.get_virtual_facts()"""
    freebsd_virtual_facts = FreeBSDVirtual({})
    freebsd_virtual_facts.get_virtual_facts = lambda: {'virtualization_type': 'xen'}

    virtual_facts = freebsd_virtual_facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:08:49.246353
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:51.613569
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()

    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert isinstance(virtual_collector._fact_class(), Virtual)

# Generated at 2022-06-23 02:08:56.842252
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Imports
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    # Set up
    # Instantiate a freebsd virtual facts instance
    freebsd_virtual_facts = VirtualFacts(
        module_name='ansible.module_utils.facts.virtual.freebsd',
        module_args='')
    # Collect virtual facts from Freebsd by calling get_virtual_facts of
    # class FreeBSDVirtual
    virtual_facts = freebsd_virtual_facts.get_virtual_facts(freebsd_virtual_facts)
    # Test
    # Copy virtual_facts because we are destructively testing
    virtual_facts_test = virtual_facts.copy()
    # Test hw model 'VMware Virtual Platform'

# Generated at 2022-06-23 02:09:08.030336
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    '''

# Generated at 2022-06-23 02:09:12.505825
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
    }

    collector = FreeBSDVirtualCollector()
    assert collector.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:09:14.143478
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector.__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-23 02:09:17.230892
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    assert v.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-23 02:09:19.354352
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    vf = v.get_virtual_facts()
    assert vf['virtualization_type'] == ''
    assert vf['virtualization_role'] == ''

# Generated at 2022-06-23 02:09:30.208215
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_class = FreeBSDVirtual('faux')
    # fake_facts will be set as facts cache.
    fake_facts = {"virtualization_tech_guest": [],
                  "virtualization_tech_host": []}
    test_class.facts = fake_facts
    # Set values of sysctl detection methods.
    test_class.sysctl_data = ["hw.model", "hostvmhostmodel"]
    # Set values of hw.model detection method
    class hw_model:
        def search(self, string):
            return "hostvmhostmodel"
    test_class.hw_model = hw_model()
    # Set values of detect_virt_vendor of class Virtual
    test_class.virt_vendor_data = ["hostvmhostmodel",
                                   "hostvmhostmodelvirtualizationtype"]
    #

# Generated at 2022-06-23 02:09:33.161293
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }
    FreeBSDVirtual(facts).get_virtual_facts()
    assert facts == expected_facts

# Generated at 2022-06-23 02:09:35.275632
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    os_facts = dict()
    FreeBSDVirtual(os_facts=os_facts)


# Generated at 2022-06-23 02:09:36.530602
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:42.810455
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os.environ['HOSTNAME'] = 'foobar'
    bsd_virtual = FreeBSDVirtual()
    facts = bsd_virtual.get_virtual_facts()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:09:47.005398
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual._platform == 'FreeBSD'
    assert virtual.__class__.__bases__[0] == Virtual
    assert virtual.__class__.__bases__[1] == VirtualSysctlDetectionMixin


# Generated at 2022-06-23 02:09:48.742868
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:54.829746
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()

    assert sorted(facts['virtualization_tech_guest']) == \
        ['xen']
    assert sorted(facts['virtualization_tech_host']) == \
        ['xen']
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:09:57.563638
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.virtual[0]['FreeBSD'] == FreeBSDVirtual
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:59.798027
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    # Testing return type of constructor
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:10:06.061850
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Check virtual facts when all sysctl / hw.model / security.jail.jailed methods fail
    """
    m = FreeBSDVirtual({'ansible_facts': {}})
    facts = m.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:10:11.395983
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    unit test for constructor of class FreeBSDVirtualCollector
    '''
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-23 02:10:17.566900
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Requirement: None

    # Setup
    _platform_sysctl_data = {
        'hw.hv_vendor': '',
        'security.jail.jailed': 0,
        'kern.vm_guest': '',
    }

    expected = {
        'platform': 'FreeBSD',
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Run
    obj = FreeBSDVirtual(_platform_sysctl_data)
    result = obj.get_virtual_facts()

    # Assert
    assert result == expected

# Generated at 2022-06-23 02:10:29.275976
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    instance = FreeBSDVirtual({}, {})
    instance.kernel_sysctl = [
        {'value': 'other', 'name': 'kern.vm_guest', 'key': 'security.jail.jailed'},
        {'value': '0', 'name': 'hw.hv_vendor', 'key': 'hw.hv_vendor'},
        {'value': '0', 'name': 'security.jail.jailed', 'key': 'security.jail.jailed'},
    ]

# Generated at 2022-06-23 02:10:41.238211
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    fake_product_vendor = {'virtualization_type': 'kvm'}
    assert freebsd_virtual.detect_virt_product('kern.vm_guest') == fake_product_vendor

    fake_vendor = {'virtualization_type': 'kvm',
                   'virtualization_role': 'host'}
    assert freebsd_virtual.detect_virt_vendor('hw.model', 'KVM') == fake_vendor

    assert freebsd_virtual.detect_virt_vendor('hw.model') == {}

    fake_product_vendor = {'virtualization_type': 'jail',
                           'virtualization_role': 'guest'}