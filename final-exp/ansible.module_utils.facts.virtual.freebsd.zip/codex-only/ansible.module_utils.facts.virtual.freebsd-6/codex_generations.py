

# Generated at 2022-06-23 02:00:36.308247
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual(dict())
    assert v.platform == 'FreeBSD'
    assert v.kernel == 'FreeBSD'

# Generated at 2022-06-23 02:00:43.267425
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create an instance of class FreeBSDVirtual
    virtual_fbsd = FreeBSDVirtual()
    assert virtual_fbsd.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:00:45.277047
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create an empty FreeBSDVirtual object
    fvirt = FreeBSDVirtual()

    # Check that empty values are set correctly
    assert fvirt.virtualization_type == ''
    assert fvirt.virtualization_role == ''

# Generated at 2022-06-23 02:00:56.688281
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()
    test_fbsd = FreeBSDVirtual()

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    if os.path.exists('/dev/xen/xenstore'):
        guest_tech.add('xen')
        virtual_facts['virtualization_type'] = 'xen'
        virtual_facts['virtualization_role'] = 'guest'

    assert_result = test_fbsd.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'

    assert_result = test_fbsd.get_virtual_facts()
    assert result['virtualization_role'] == 'guest'

   

# Generated at 2022-06-23 02:01:02.429129
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual({}).get_virtual_facts()

    # 'virtualization_tech_guest' and 'virtualization_tech_host' must be lists
    assert isinstance(virt_facts['virtualization_tech_guest'], set)
    assert isinstance(virt_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:01:14.587041
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.collector.virtual import VirtualCollectorTestFixture
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.freebsd import FreeBSDVirtual


# Generated at 2022-06-23 02:01:19.195789
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:21.413701
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:01:25.671098
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    fbsd_virtual = FreeBSDVirtual()
    assert fbsd_virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:01:35.832113
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_obj = FreeBSDVirtual()
    freebsd_virtual_obj.module = None
    freebsd_virtual_obj.get_virtual_facts()
    assert freebsd_virtual_obj.virtual_facts['virtualization_type'] == 'xen'
    assert freebsd_virtual_obj.virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in freebsd_virtual_obj.virtual_facts['virtualization_tech_guest']
    assert 'xen' not in freebsd_virtual_obj.virtualization_tech_host

# Generated at 2022-06-23 02:01:41.166850
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()

    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_host == set()
    assert virtual.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:01:46.304241
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup a class to test with
    facts = {}
    freebsd = FreeBSDVirtual(facts, None)
    facts['virtualization_type'] = freebsd.get_virtual_facts()['virtualization_type']
    facts['virtualization_role'] = freebsd.get_virtual_facts()['virtualization_role']
    # Test that get_virtual_facts works as expected
    assert facts['virtualization_type'] in []
    assert facts['virtualization_role'] in []

# Generated at 2022-06-23 02:01:48.969466
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:52.970562
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:02:01.178518
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test on a host with a Intel(R) Xeon(R) CPU X5550 @ 2.67GHz processor
    # that has no virtualization technology
    facts_no_virtual_tech = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

    test_facts_nvt = FreeBSDVirtual(dict())
    facts_nvt = test_facts_nvt.get_virtual_facts()
    assert facts_nvt == facts_no_virtual_tech

    # Test on a host with a Intel(R) Xeon(R) CPU E5620 @ 2.40GHz processor
    # running on VMware Virtual Platform

# Generated at 2022-06-23 02:02:04.378511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector('FreeBSD')
    assert x._fact_class == FreeBSDVirtual
    assert x._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:07.586080
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    results = FreeBSDVirtualCollector()
    assert results._platform == 'FreeBSD'
    assert isinstance(results._fact_class, FreeBSDVirtual)


# Generated at 2022-06-23 02:02:12.854904
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fb_vc = FreeBSDVirtualCollector()
    assert fb_vc.platform == 'FreeBSD'
    assert fb_vc.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:23.549954
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {
            'xen'
        },
        'virtualization_tech_host': set()
    }

    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual._detect_virt_product = lambda x: {
        'virtualization_tech_guest': {
            'xen'
        },
        'virtualization_tech_host': set()
    }
    freebsd_virtual._detect_virt_vendor = lambda x: {}
    assert virtual_facts == freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:02:27.398402
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'
    assert fv.virtualization_type == ''
    assert fv.virtualization_role == ''


# Generated at 2022-06-23 02:02:37.283320
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import SysctlVirtualizationDetectionMixin

    class FreeBSDVirtualTest(FreeBSDVirtual, SysctlVirtualizationDetectionMixin):
        def get_virtual_facts(self):
            return super(FreeBSDVirtualTest, self).get_virtual_facts()

    virtual_class = FreeBSDVirtualTest()
    virtual_facts = virtual_class.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:02:38.645828
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert isinstance(virtual.vm, dict)

# Generated at 2022-06-23 02:02:39.244607
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:45.281470
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_fact = FreeBSDVirtual({})
    freebsd_virtual_result = freebsd_virtual_fact.get_virtual_facts()

    assert isinstance(freebsd_virtual_result, dict), \
        "Returned value should be a dictionary."

    assert 'virtualization_type' in freebsd_virtual_result, \
        "'virtualization_type' key should be in returned dictionary."

    assert 'virtualization_role' in freebsd_virtual_result, \
        "'virtualization_role' key should be in returned dictionary."


# Generated at 2022-06-23 02:02:51.231105
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == ''


# Generated at 2022-06-23 02:02:52.372823
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:56.275020
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtual()
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:58.503076
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:07.817089
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual class
    virtual_instance = FreeBSDVirtual()

    # Call get_virtual_facts method
    virtual_facts = virtual_instance.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:03:08.782367
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv

# Generated at 2022-06-23 02:03:12.653757
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual().get_virtual_facts()
    assert virt_facts['virtualization_type'] == ''
    assert virt_facts['virtualization_role'] == ''
    assert virt_facts['virtualization_tech_guest'] == set()
    assert virt_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:03:15.515572
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v._platform == 'FreeBSD'

if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-23 02:03:18.318390
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual({})
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert('virtualization_type' in freebsd_virtual_facts)
    assert('virtualization_role' in freebsd_virtual_facts)

# Generated at 2022-06-23 02:03:21.348479
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual()
    assert fbv._platform == 'FreeBSD'
    assert fbv.platform == 'FreeBSD'
    assert fbv._fact_class == fbv.__class__

# Generated at 2022-06-23 02:03:29.170698
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import virtual

    virtual_facts = virtual.FreeBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] in ['xen', 'kvm', 'jail', '', 'parallels', 'bochs', 'qemu', 'virtualbox', 'vmware']
    assert virtual_facts['virtualization_role'] in ['guest', 'host', '']

# Generated at 2022-06-23 02:03:34.865795
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsdvirtual = FreeBSDVirtual()
    assert fbsdvirtual
    assert fbsdvirtual.platform == 'FreeBSD'
    assert fbsdvirtual.virtualization_type == ''
    assert fbsdvirtual.virtualization_role == ''


# Generated at 2022-06-23 02:03:44.477493
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Construct an instance of FreeBSDVirtual class
    testobj = FreeBSDVirtual()
    testobj.get_virtual_facts()
    virtual_facts = testobj.virtual_facts
    testobj_dict = dict(testobj)

    # Xen host/guest
    os.environ['ANSIBLE_LOCAL_TEMP'] = '/tmp'
    os.makedirs(os.environ['ANSIBLE_LOCAL_TEMP'] + "/ansible_facts/xen_host")
    os.makedirs(os.environ['ANSIBLE_LOCAL_TEMP'] + "/ansible_facts/xen_guest")
    os.makedirs(os.environ['ANSIBLE_LOCAL_TEMP'] + "/ansible_facts/xen_dom0")

# Generated at 2022-06-23 02:03:51.421301
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:56.325552
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    import tempfile
    import pytest
    # Testing empty environment
    os.environ = dict()

    bsdv = FreeBSDVirtual()
    virtual_facts = bsdv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    # Testing Guest

    # Testing XEN
    os.environ['XEN'] = 'xen'
    virtual_facts = bsdv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:03:59.679024
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    # No collect method.
    assert not hasattr(virtual, 'collect')
    assert virtual.get_virtual_facts() == {}



# Generated at 2022-06-23 02:04:01.956360
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_instance = FreeBSDVirtual({}, FakeLoader())
    test_instance.get_virtual_facts()



# Generated at 2022-06-23 02:04:02.994759
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtualCollector()



# Generated at 2022-06-23 02:04:04.835246
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts, VirtualCollector)

# Generated at 2022-06-23 02:04:06.306177
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert(collector == FreeBSDVirtualCollector())

# Generated at 2022-06-23 02:04:18.227372
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    # Mock the Virtual class

# Generated at 2022-06-23 02:04:21.216354
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Create FreeBSDVirtualCollector object.
    """
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, VirtualCollector), \
            'Could not create FreeBSDVirtualCollector object'

# Generated at 2022-06-23 02:04:22.489379
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:04:30.898632
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    from ansible.module_utils.facts.virtual.sysctl.fake_sysctl import FakeSysctlUtil
    from ansible.module_utils.facts.virtual.sysctl.fake_guest_type import FakeGuestType
    from ansible.module_utils.facts.virtual.sysctl.fake_vendor import FakeVendor

    # Test host
    test_host = FreeBSDVirtual(None)
    test_host.set_sysctl_util(FakeSysctlUtil)
    test_host.set_guest_type_util(FakeGuestType)
    test_host.set_vendor_util(FakeVendor)


# Generated at 2022-06-23 02:04:33.015027
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:38.891816
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual('')
    assert fv.platform == 'FreeBSD'
    assert fv.version == ''
    assert fv.virttype == ''
    assert fv.product == ''
    assert fv.serial == ''
    assert fv.vcpus == -1
    assert fv.memsize == -1
    assert fv.cpumodel == ''
    assert fv.cpuscaling == ''


# Generated at 2022-06-23 02:04:46.390084
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ..test.test_virtual import TestVirtualFacts
    results = TestVirtualFacts.setup_virtual_facts_with_files(FreeBSDVirtual)
    assert results['virtualization_type'] == 'xen'
    assert results['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' not in results
    assert 'virtualization_tech_host' not in results
    assert 'virtualization_host' not in results
    assert results['virtualization_products'] == ['xen']
    assert results['virtualization_systems'] == ['xen']
    assert results['virtualization_environments'] == ['xen']

# Generated at 2022-06-23 02:04:57.863940
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Setup test class
    fb = FreeBSDVirtual()

    # Test kern.vm_guest
    fb._sysctl = {
        'kern.vm_guest': 'vmm'
    }
    result = fb.get_virtual_facts()
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'guest'
    assert ('vmm' in result['virtualization_tech_guest'])
    assert ('guest' in result['virtualization_tech_guest'])
    assert ('virtualmachine' in result['virtualization_tech_guest'])
    assert ('vmm' in result['virtualization_tech_host'])
    assert ('host' in result['virtualization_tech_host'])

# Generated at 2022-06-23 02:04:58.404441
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:59.867810
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO
    assert False

# Generated at 2022-06-23 02:05:04.733277
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    inst = FreeBSDVirtualCollector()
    assert isinstance(inst, FreeBSDVirtualCollector)
    # This test would fail if FreeBSDVirtualCollector does not have
    # FreeBSDVirtual as the _fact_class
    assert isinstance(inst._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:05:06.903098
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()

    assert freebsd_virtual
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:08.291188
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:10.041203
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector


# Generated at 2022-06-23 02:05:11.389028
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:16.103874
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:05:22.371800
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    facts = FreeBSDVirtual(None).get_virtual_facts()
    assert expected_facts == facts


# Generated at 2022-06-23 02:05:30.110452
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_shared_vals = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': set(['kvm']),
    }

    # kern.vm_guest values
    x86 = dict(test_shared_vals)
    x86['virtualization_tech_guest'] = set(['x86'])
    x86['virtualization_type'] = 'x86'
    x86['virtualization_role'] = 'guest'

    # hw.hv_vendor/hw.hv_vendor_id values
    kvm = dict(test_shared_vals)
    kvm['virtualization_tech_guest'] = set(['kvm'])

# Generated at 2022-06-23 02:05:33.109293
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    virtualization_facts = FreeBSDVirtual({}, {})
    assert virtualization_facts.platform == "FreeBSD"



# Generated at 2022-06-23 02:05:39.289600
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'].lower() in (
        'guest', 'host', 'physical', '')
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'].lower() in (
        'guest', 'host', 'physical', '')

# Generated at 2022-06-23 02:05:50.391070
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    virtualBsd = FreeBSDVirtual(None)
    # Set test data for the required facts
    test_facts = {'system': {'manufacturer': '', 'product': ''},
                'virtualization': {'role': '', 'system': '', 'type': ''},
                  'virtualization_tech_guest': set(),
                  'virtualization_tech_host': set()}
    actual_facts = virtualBsd.get_virtual_facts()

    # Do the test
    assert test_facts['virtualization_tech_guest'] == actual_facts['virtualization_tech_guest']
    assert test_facts['virtualization_tech_host'] == actual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:05:51.515946
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'


# Generated at 2022-06-23 02:06:03.577332
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    frbsdvirt = FreeBSDVirtual({})
    frbsdvirt.set_sysctl_path('/usr/bin/sysctl')

    frbsdvirt.set_sysctl_output('security.jail.jailed: 0\nhw.hv_vendor: \nkern.vm_guest: none\nhw.model: \n')
    frbsdvirt.set_uname_output('\n')
    frbsdvirt.set_dmesg_output('\n')

# Generated at 2022-06-23 02:06:13.573751
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    freebsd_virtual_facts = freebsd_virtual.fetch_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] in ['',
                                                            'xen',
                                                            'vmware',
                                                            'virtualbox',
                                                            'physical',
                                                            'jail']
    assert freebsd_virtual_facts['virtualization_role'] in ['guest',
                                                            'host',
                                                            'host/guest',
                                                            '',
                                                            'physical']

# Generated at 2022-06-23 02:06:16.092785
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Constructor of FreeBSDVirtual() should return non-None object
    assert FreeBSDVirtual() is not None

# Generated at 2022-06-23 02:06:18.283308
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:25.960284
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    virtual_facts = freebsd_virtual.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:06:28.524302
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of FreeBSDVirtualCollector object
    """
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert issubclass(obj.fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:06:40.943878
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_cases = (
            {'virtualization_type': '',
             'virtualization_role': '',
             'virtualization_tech_guest': {},
             'virtualization_tech_host': {}
            },
            {'virtualization_type': 'xen',
             'virtualization_role': 'guest',
             'virtualization_tech_guest': {'xen'},
             'virtualization_tech_host': {'xen'}
            },
    )

    for test_case in test_cases:
        obj = FreeBSDVirtual(file_exists_map={'/dev/xen/xenstore': False})
        virtual_facts = obj.get_virtual_facts()
        for (key, val) in test_case.items():
            assert virtual_facts[key] == val

# Generated at 2022-06-23 02:06:43.694471
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:06:45.451556
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj



# Generated at 2022-06-23 02:06:48.917246
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Constructor test
    '''
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual.platform == "FreeBSD"

# Generated at 2022-06-23 02:06:56.081951
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual = FreeBSDVirtual()

    # Set up the module_utils/facts/virtual/sysctl.py
    virtual.module_utils.sysctl = {}
    virtual.module_utils.sysctl.sysctlbyname = lambda _: {}
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:06:57.466024
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:59.064029
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:00.219692
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()


# Generated at 2022-06-23 02:07:03.457603
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(False)
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:10.104731
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''

    # Setup
    test_obj = FreeBSDVirtual()
    test_obj._check_sysctl = lambda *args: None      # don't call sysctl as it doesn't work in unit tests

    # Test for Xen as host

# Generated at 2022-06-23 02:07:11.816592
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)



# Generated at 2022-06-23 02:07:14.498305
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Check if facts are loaded
    """
    FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector().get_all()

# Generated at 2022-06-23 02:07:17.306163
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class is FreeBSDVirtual
    assert virtual_collector._platform is 'FreeBSD'


# Generated at 2022-06-23 02:07:28.652901
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual({})

    expected_virtual_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    freebsd_virtual._module.params = {
        'gather_subset': '!all,min'
    }

    freebsd_virtual._module.run_command = \
        lambda x: (0, 'security.jail.jailed: 0\n', '')

    virtual_facts = freebsd_virtual.get_virtual_facts()
    for key, value in list(expected_virtual_facts.items()):
        assert virtual_facts[key] == value


# Generated at 2022-06-23 02:07:39.638523
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    # Test Xen guest virtual_facts
    virtual_facts = {}
    virtual_facts['virtualization_tech_guest'] = {'xen'}
    virtual_facts['virtualization_tech_host'] = set()
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    assert virtual.get_virtual_facts() == virtual_facts

    # Test FreeBSD guest virtual_facts
    virtual_facts = {}
    virtual_facts['virtualization_tech_guest'] = {'freebsd'}
    virtual_facts['virtualization_tech_host'] = set()
    virtual_facts['virtualization_type'] = 'freebsd'
    virtual_facts['virtualization_role'] = 'guest'
    assert virtual.get

# Generated at 2022-06-23 02:07:41.637227
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector  # pyflakes

# Generated at 2022-06-23 02:07:43.785910
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector()._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:07:48.124794
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test FreeBSDVirtualCollector class
    '''
    obj = FreeBSDVirtualCollector()
    assert(obj.platform == 'FreeBSD')
    assert(obj.fact_class == FreeBSDVirtual)


# Generated at 2022-06-23 02:07:49.950662
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(module=None)
    assert facts.get_virtual_facts()

# Generated at 2022-06-23 02:07:51.922114
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:07:53.362212
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(None).platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:55.703873
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual._platform == 'FreeBSD'
    assert isinstance(freebsd_virtual, Virtual)



# Generated at 2022-06-23 02:07:57.406057
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert hasattr(virtual, 'facts')
    assert hasattr(virtual, 'platform')

# Generated at 2022-06-23 02:08:03.409155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector.__module__ == 'ansible.module_utils.facts.virtual.freebsd'
    assert collector.__class__.__name__ == 'FreeBSDVirtualCollector'
    assert collector._fact_class.__name__ == 'FreeBSDVirtual'
    assert collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:14.691494
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vm = FreeBSDVirtual()
    for _ in range(0,10):
        facts = vm.get_virtual_facts()
        assert facts is not None
        assert isinstance(facts['virtualization_role'], str)
        assert facts['virtualization_role'] in ['guest', 'host', '']
        assert isinstance(facts['virtualization_type'], str)
        assert facts['virtualization_type'] in ['xen', '']
        assert isinstance(facts['virtualization_tech_guest'], set)
        assert isinstance(facts['virtualization_tech_host'], set)
        assert facts['virtualization_tech_guest'] == set(['xen']) or facts['virtualization_tech_guest'] == set()
        assert facts['virtualization_tech_host'] == set(['xen']) or facts

# Generated at 2022-06-23 02:08:17.944184
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # This essentially tests the constructor, so we don't really need any
    # additional asserts.
    FreeBSDVirtual({})

# Generated at 2022-06-23 02:08:18.600581
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:22.121995
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert not os.path.exists('/dev/xen/xenstore')
    assert set() == virtual_facts.get_virtual_facts()['virtualization_tech_guest']


# Generated at 2022-06-23 02:08:25.215057
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:29.275780
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)
    assert virtual_collector.platform == 'FreeBSD'
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:08:31.159509
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bvc = FreeBSDVirtualCollector()
    assert bvc._platform == 'FreeBSD'
    assert bvc._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:08:35.040706
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:37.047185
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    import doctest
    doctest.testmod(FreeBSDVirtual,
                    extraglobs={'sysctl_output': 'hw.model=AMD Phenom(tm) II X6 1055T Processor\n'})


# Generated at 2022-06-23 02:08:40.289128
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import FreeBSDVirtual
    f = open('sample/virtual/FreeBSD_VIRTUAL')
    data = f.read()
    f.close()
    v = FreeBSDVirtual(data)
    v.get_virtual_facts()

# Generated at 2022-06-23 02:08:42.643096
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()



# Generated at 2022-06-23 02:08:46.269630
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:48.740567
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:52.614929
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test for FreeBSD platform
    fbsd_virtual_collector = FreeBSDVirtualCollector(None, "FreeBSD")
    assert fbsd_virtual_collector
    assert fbsd_virtual_collector.platform == "FreeBSD"

    # Test for Non-FreeBSD platform
    non_fbsd_virtual_collector = FreeBSDVirtualCollector(None, "Linux")
    assert non_fbsd_virtual_collector.platform == "Linux"

# Generated at 2022-06-23 02:08:56.203607
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('', 'xen')
    assert virtual_facts['virtualization_role'] in ('', 'guest')
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set(['xen', 'vmware', 'virtualbox'])
    assert virtual_facts['virtualization_system'] in ('', 'vmware', 'virtualbox', 'xen')

# Generated at 2022-06-23 02:08:58.338545
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()



# Generated at 2022-06-23 02:09:01.361783
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    o = FreeBSDVirtual(None)
    assert o.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:03.763694
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual
    assert collector._fact_class().platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:06.000597
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:08.378495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    s = '''hw.machine: amd64
kern.vm_guest: other
hw.model: FreeBSD'''

    bvc = FreeBSDVirtualCollector(s, None)
    assert bvc is not None

# Generated at 2022-06-23 02:09:09.873519
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsdv = FreeBSDVirtual()
    assert bsdv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:12.110269
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbfreebsd = FreeBSDVirtual({})
    assert isinstance(fbfreebsd, Virtual)
    assert fbfreebsd.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:13.798487
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:15.062708
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virt_facts = FreeBSDVirtual()
    assert fbsd_virt_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:21.366762
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtualCollector().collect()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert 'xen' in facts['virtualization_tech_guest']
    assert 'xen' not in facts['virtualization_tech_host']
    assert 'FreeBSD' in facts['virtualization_tech_guest']
    assert 'FreeBSD' not in facts['virtualization_tech_host']

# Generated at 2022-06-23 02:09:32.224719
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_sysctl_outputs = {
        'security.jail.jailed': '0',
        'kern.vm_guest': 'none',
        'hw.model': 'Intel(R) Xeon(R) CPU L5520  @ 2.27GHz',
        'hw.hv_vendor': 'None',
    }

    virtual_facts = FreeBSDVirtual(fake_sysctl_outputs).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    fake_sysctl_outputs['hw.hv_vendor'] = 'KVMKVMKVM'
    virtual_

# Generated at 2022-06-23 02:09:35.452800
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virt = FreeBSDVirtual()
    assert freebsd_virt._platform == 'FreeBSD'
    assert freebsd_virt._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:35.999834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:37.838880
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:09:49.191606
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_text

    # Init FreeBSDVirtual and call get_virtual_facts
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    # Init VirtualCollector
    facts_collector = collector.get_collector(FreeBSDVirtualCollector.platform)
    # Init FreeBSDVirtualCollector
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Call add_sysctl_virtual_facts of virtual_collector
    freebsd_virtual_collector.add_sysctl_virtual_facts(freebsd_virtual_facts)

# Generated at 2022-06-23 02:09:53.328595
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    facts = FreeBSDVirtual(module).get_virtual_facts()

    assert facts['virtualization_type']
    assert facts['virtualization_role']

# Generated at 2022-06-23 02:09:55.946804
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert isinstance(x.facts, FreeBSDVirtual)


# Generated at 2022-06-23 02:09:57.223445
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()

    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:59.235223
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:00.755728
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({},{},{},{})



# Generated at 2022-06-23 02:10:11.304888
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('module', (object,), {
        '_ansible_facts': {},
        'get_bin_path': lambda ext: '/bin/echo',
        'run_command': lambda cmd: {
            'stdout': (
                'kern.vm_guest: other\n'
                'hw.hv_vendor: VMware, Inc.\n'
                'security.jail.jailed: 0\n'
                'hw.model: Intel(R) Core(TM) i7-6650U CPU @ 2.20GHz\n'
            ),
            'rc': 0,
        }
    })()

    freebsd_virtual = FreeBSDVirtual(fake_module)
    facts = freebsd_virtual.get_virtual_facts()

    # Known facts

# Generated at 2022-06-23 02:10:14.051254
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:10:15.133918
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual(None)
    fbv.get_virtual_facts()

# Generated at 2022-06-23 02:10:16.607255
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    for key, value in freebsd.get_virtual_facts().items():
        assert value == ''

# Generated at 2022-06-23 02:10:19.092311
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual({'ansible_facts': {'machine': 'amd64'}, 'ansible_machine': 'amd64'})
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:20.687088
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == FreeBSDVirtualCollector._platform

# Generated at 2022-06-23 02:10:25.755555
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test FreeBSDVirtual constructor
    virtual = FreeBSDVirtual()
    assert virtual
    assert virtual.name == 'freebsd'
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-23 02:10:27.680386
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test that the first object is an instance of class FreeBSDVirtual
    assert isinstance(FreeBSDVirtual(), FreeBSDVirtual)


# Generated at 2022-06-23 02:10:39.786824
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    test_object = FreeBSDVirtual()

    # FreeBSD running as a non-virtualized guest
    def get_file_content(path):
        # First test - Non-virtualized
        return ""

    def get_sysctl(keys):
        return {'security.jail.jailed': 0}

    test_object.get_file_content = get_file_content
    test_object.get_sysctl = get_sysctl

    facts = test_object.get_virtual_facts()
    assert facts['virtualization_type'] == 'None'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    # FreeBSD running in a jail
    def get_file_content(path):
        return ""