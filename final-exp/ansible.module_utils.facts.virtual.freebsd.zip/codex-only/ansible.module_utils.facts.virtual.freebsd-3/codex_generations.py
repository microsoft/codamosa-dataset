

# Generated at 2022-06-23 02:00:39.601410
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)

# Generated at 2022-06-23 02:00:42.396944
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)
    assert isinstance(collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:00:43.348378
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:00:45.332823
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fc = FreeBSDVirtual()

    # Test no match case
    result = fc._get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

# Generated at 2022-06-23 02:00:47.383335
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:00:50.755576
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class._platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:52.665293
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:04.055934
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:06.810187
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:19.510153
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Unit test for virtualization_type & virtualization_role
    # Set content of sysctl kern.vm_guest to "other" (unknown)
    def kern_vm_guest():
        return {'kern.vm_guest': 'other'}

    # Assert that virtualization_type is empty string and virtualization_role
    # is empty string.
    def assert_virtualization_type_and_role(facts):
        assert facts['virtualization_type'] == ''
        assert facts['virtualization_role'] == ''

    # Set content of file '/dev/xen/xenstore'
    def xenstore_file():
        return '/dev/xen/xenstore'

    # Assert that virtualization_type is 'xen' and virtualization_role is
    # 'guest'.

# Generated at 2022-06-23 02:01:22.741052
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, [], {})
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''



# Generated at 2022-06-23 02:01:26.304961
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type(str("FakeModule"), (object,), {})()
    fake_module.get_bin_path = lambda *args: None
    facts = FreeBSDVirtual({}, fake_module).get_virtual_facts()
    assert facts['virtualization_type'] != '' or facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:01:29.321749
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual()
    assert fbv.platform == "FreeBSD"

# Generated at 2022-06-23 02:01:38.769502
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Sample sysctl output for FreeBSD VMs on OpenStack
    # Note: Any output for FreeBSD VMs on Azure is welcome.
    kern_vm_guest_output = '''
kern.vm_guest: unknown
    '''
    hw_hv_vendor_output = '''
hw.hv_vendor: BHYVE
    '''
    hw_model_output = '''
hw.model: Intel(R) Xeon(R) CPU E5-2676 v3 @ 2.40GHz'''

    virtual_facts = FreeBSDVirtual(module=None,
                                   subprocess_args={'shell': True},
                                   subprocess_executable='/usr/bin/env').get_virtual_facts()


# Generated at 2022-06-23 02:01:47.603091
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Test the get_virtual_facts method of FreeBSDVirtual and Virtual (base class)"""
    # create the instance of class FreeBSDVirtual and
    # set get_file_content return value
    virtual_obj = FreeBSDVirtual()
    virtual_obj.get_file_content = lambda fact_path: ''

    # set get_file_lines return value
    virtual_obj.get_file_lines = lambda fact_path: ['']

    # set get_mount_size return value
    virtual_obj.get_mount_size = lambda fact_path: 0

    # set get_mount_point return value
    virtual_obj.get_mount_point = lambda fact_path: '/'

    # set get_file_content and
    # get_file_lines retrun value

# Generated at 2022-06-23 02:01:50.891740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvm = FreeBSDVirtualCollector()
    assert fvm is not None

# Generated at 2022-06-23 02:01:54.159808
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.get_virtual_facts()['virtualization_type'] == 'xen'
    assert collector.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:01:57.778255
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual


# Generated at 2022-06-23 02:02:03.050557
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # create an instance of FreeBSDVirtual()
    virtual = FreeBSDVirtual()

    # check the value of VirtualizationType
    assert virtual


# Generated at 2022-06-23 02:02:11.067221
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'kvm'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_host'] = set()
    virtual_facts['virtualization_tech_host'].add('kvm')
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_guest'].add('kvm')
    freebsd = FreeBSDVirtual()

    assert freebsd.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:02:17.038102
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()

    expected_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }

    # By mocking the sysctl command, we can test the function very flexibly.
    def mocked_freebsd_vsysctl(key):
        assert key == 'kern.vm_guest'
        return 'xen\n'

    f._get_freebsd_vsysctl = mocked_freebsd_vsysctl

    actual_facts = f._get_virtual_facts()

    assert expected_facts == actual_facts

# Generated at 2022-06-23 02:02:18.628137
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt.get_virtual_facts()

# Generated at 2022-06-23 02:02:24.176619
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.BASE_FACTS = {'sysctl': {'kern.vm_guest': 'none'}}
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:02:34.827744
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''

    # Mock the module builtins so we can control the environment variables
    builtins_module = '__builtin__'
    try:
        # >= Python 3
        builtins_module = 'builtins'
    except ImportError:
        # <= Python 2
        pass

    # Mock the module os so we can control the environment variables
    import ansible.module_utils.facts.virtual.freebsd
    os = ansible.module_utils.facts.virtual.freebsd.os
    module_builtins = __import__(builtins_module)
    module_os = __import__('os')

    # Specify which environment variables you want in your test case
    # (the keys are the variable name, the values are the variable value)
    os_environ

# Generated at 2022-06-23 02:02:36.997706
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:46.203732
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of class FreeBSDVirtual, when called on FreeBSD system.
    """
    # Given the presence of sysctl like 'security.jail.jailed=1' on FreeBSD,
    # Returned virtual_facts should be updated with virtualization_type=jail
    # and virtualization_role=guest
    # And the set of virtualization_tech_guest should contain 'jail'
    with open('/proc/sys/security/jail/jailed', 'w') as fd:
        fd.write('1')

    vf = FreeBSDVirtual().get_virtual_facts()

    assert vf['virtualization_type'] == 'jail'
    assert vf['virtualization_role'] == 'guest'
    assert 'jail' in vf['virtualization_tech_guest']

   

# Generated at 2022-06-23 02:02:49.949380
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual
    assert freebsd_virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:51.426370
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:02:53.579978
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts._facts.get('virtual') == {}


# Generated at 2022-06-23 02:02:57.595049
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test to see if FreeBSDVirtualCollector is properly constructed
    '''
    v = FreeBSDVirtualCollector()
    assert isinstance(v, FreeBSDVirtualCollector)
    assert issubclass(type(v._fact_class), Virtual)
    assert v._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:58.446404
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    return FreeBSDVirtualCollector

# Generated at 2022-06-23 02:03:07.769938
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('', (), {'get_bin_path': lambda x, y, z: '/sbin/sysctl'})
    virtual_facts = FreeBSDVirtual(fake_module)
    virtual_facts.sysctl_cmd = ['sysctl', '-n']
    facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }
    assert virtual_facts.get_virtual_facts() == facts

# Generated at 2022-06-23 02:03:11.388659
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    assert virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:03:22.810266
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    hostname_sysctl = dict()

    hostname_sysctl['security.jail.jailed'] = '0'
    hostname_sysctl['hw.hv_vendor'] = 'Apple'
    hostname_sysctl['kern.vm_guest'] = 'none'

    _FreeBSDVirtual = FreeBSDVirtual(hostname_sysctl)
    _FreeBSDVirtual_facts = _FreeBSDVirtual.get_virtual_facts()

    assert _FreeBSDVirtual_facts['virtualization_type'] == ''
    assert _FreeBSDVirtual_facts['virtualization_role'] == ''
    assert 'jail' not in _FreeBSDVirtual_facts['virtualization_tech_guest']
    assert 'cloud' not in _FreeBSDVirtual_facts['virtualization_tech_guest']
    assert 'container' not in _FreeBSDVirtual_

# Generated at 2022-06-23 02:03:24.567021
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({}, False)
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:29.125874
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:38.095709
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}

    virtual = FreeBSDVirtual(module=None)
    facts.update(virtual.get_virtual_facts())

    # Assert that we get 'xen' from configured sysctl
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert 'xen' in facts['virtualization_tech_guest']

    # Assert that we find 'xen' from kern.vm_guest
    assert 'xen' in facts['virtualization_tech_guest']

    # Assert that we find 'xen' from hw.hv_vendor
    assert 'xen' in facts['virtualization_tech_guest']

    # Assert that we find 'jail' from security.jail.jailed
    assert 'jail' in facts

# Generated at 2022-06-23 02:03:39.925085
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert hasattr(virtual_facts, 'get_all_facts')

# Generated at 2022-06-23 02:03:41.027347
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Create class FreeBSDVirtualCollector
    c = FreeBSDVirtualCollector()
    # Check
    assert c.find_sysctl_cmd() == 'sysctl -n'

# Generated at 2022-06-23 02:03:43.560958
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check constructor of class FreeBSDVirtualCollector
    obj = FreeBSDVirtualCollector()
    assert issubclass(obj._fact_class, Virtual)
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:52.122813
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    results = dict(virtualization_type='',
                   virtualization_role='',
                   virtualization_tech_guest=set(),
                   virtualization_tech_host=set())

    assert (FreeBSDVirtual(None, results).virtual) == ('', '', set(), set())

# Generated at 2022-06-23 02:03:54.880662
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    dut = FreeBSDVirtualCollector()
    assert isinstance(dut, VirtualCollector)
    assert dut._fact_class == FreeBSDVirtual
    assert dut._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:56.091990
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create an instance of FreeBSDVirtual
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:03:59.373127
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert hasattr(FreeBSDVirtual, 'platform')
    assert FreeBSDVirtual.platform == 'FreeBSD'
    assert hasattr(FreeBSDVirtual, 'get_virtual_facts')
    assert callable(FreeBSDVirtual.get_virtual_facts)

# Generated at 2022-06-23 02:04:03.415630
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Call constructor
    freebsd_virtual = FreeBSDVirtual()

    # Assert that FreeBSDVirtual['platform'] is correctly set
    freebsd_virtual_platform = freebsd_virtual['platform']
    assert freebsd_virtual_platform == FreeBSDVirtual.platform

# Generated at 2022-06-23 02:04:14.015712
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest

    fbsd_virtual = FreeBSDVirtual()

    # Test for virtualization_type
    if os.path.exists('/dev/xen/xenstore'):
        assert fbsd_virtual.get_virtual_facts()['virtualization_type'] == 'xen'
    else:
        assert fbsd_virtual.get_virtual_facts()['virtualization_type'] == ''

    # Test for virtualization_role
    if os.path.exists('/dev/xen/xenstore'):
        assert fbsd_virtual.get_virtual_facts()['virtualization_role'] == 'guest'
    else:
        assert fbsd_virtual.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:04:17.926129
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:19.254731
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_vc = FreeBSDVirtualCollector()
    assert freebsd_vc.platform == 'FreeBSD'
    assert freebsd_vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:23.855163
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Empty argument
    my_obj = FreeBSDVirtual()
    # Check for class type
    assert(my_obj.__class__.__name__ == 'FreeBSDVirtual')
    # Check the attributes
    assert(my_obj.platform == 'FreeBSD')



# Generated at 2022-06-23 02:04:24.657753
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtualCollector().get_virtual_facts()

# Generated at 2022-06-23 02:04:28.519896
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:30.148828
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:35.857542
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector

    freebsd_test_object = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector is not None
    assert freebsd_test_object._platform == 'FreeBSD'
    assert freebsd_test_object._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:40.715086
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.facts['virtualization_type'] == ''
    assert fv.facts['virtualization_role'] == ''
    assert fv.facts['virtualization_tech_host'] == set()
    assert fv.facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:04:45.524317
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Here we instantiate the FreeBSDVirtualCollector class without any arguments
    # and expect the object to be created successfully
    foo = FreeBSDVirtualCollector()
    assert foo

# Generated at 2022-06-23 02:04:49.296731
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsdvc = FreeBSDVirtualCollector()
    assert isinstance(bsdvc, VirtualCollector)
    assert bsdvc.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:51.779236
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_info = FreeBSDVirtual({}, {}, None)
    assert freebsd_virtual_info.platform == 'FreeBSD'


# Generated at 2022-06-23 02:04:54.036521
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_collector = FreeBSDVirtualCollector()
    assert isinstance(fact_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:04:54.948505
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert isinstance(FreeBSDVirtual(), FreeBSDVirtual)

# Generated at 2022-06-23 02:04:56.183030
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:04.729147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).get_facts()
    for fact in [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_host',
        'virtualization_tech_guest',
        'virtualization_product_host',
        'virtualization_product_guest',
    ]:
        assert fact in facts
    assert isinstance(facts['virtualization_tech_host'], set)
    assert isinstance(facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:05:09.273958
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    fbsdvirtual = FreeBSDVirtual(Virtual, VirtualSysctlDetectionMixin)
    assert fbsdvirtual.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-23 02:05:11.712607
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'
    assert f.virtualization_type == ''
    assert f.virtualization_role == ''

# Generated at 2022-06-23 02:05:14.812763
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.get_fact_class() is FreeBSDVirtual

# Generated at 2022-06-23 02:05:15.876949
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:05:26.373286
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup the class and facts to test
    test_class = FreeBSDVirtual({})
    test_class.sysctl = {'hw.hv_vendor': 'BHYVE',
                         'hw.model': 'Intel(R) Xeon(R) CPU E31270 @ 3.40GHz',
                         'kern.vm_guest': 'other',
                         'security.jail.jailed': '0'}

    # Run the method
    facts = test_class.get_virtual_facts()

    # Check the facts
    assert facts == {'virtualization_type': 'bhyve',
                     'virtualization_role': 'host',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': {'bhyve'}}

# Generated at 2022-06-23 02:05:28.926484
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'



# Generated at 2022-06-23 02:05:41.172158
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""
    # pylint: disable=protected-access
    collector = FreeBSDVirtualCollector()
    virtual_facts = collector._get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

    jail = collector._get_jail_info()
    assert virtual_facts['virtualization_type'] == jail['virtualization_type']
    assert virtual_facts['virtualization_role'] == jail['virtualization_role']
    # pylint: enable=protected-access

# Generated at 2022-06-23 02:05:50.269659
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Here is a test case
    result = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen', 'jail']),
        'virtualization_tech_host': set()
    }

    # Create a FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Call method get_all_facts
    all_facts = freebsd_virtual_collector.get_all_facts()

    # Test result
    assert result == all_facts

# Generated at 2022-06-23 02:05:53.602114
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__doc__ is not None
    assert FreeBSDVirtualCollector.get_virtual_facts.__doc__ is not None
    assert FreeBSDVirtualCollector._platform == platform
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:04.549182
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test requires that we fake the subprocess call
    def _fake_call(command):
        """
        This method is used to fake subprocess call
        """
        result = ''
        command = command.strip().split(' ')[-1]
        if command == '/sbin/sysctl -n security.jail.jailed':
            result = '0'
        elif command == '/sbin/sysctl -n kern.vm_guest':
            result = 'none'
        elif command == '/sbin/sysctl -n hw.hv_vendor':
            result = 'None'
        elif command == '/sbin/sysctl -n hw.model':
            result = 'Qumranet Virtual Machine (KVM)'
        return result

    # Set the subprocess call to our fake
    VirtualSys

# Generated at 2022-06-23 02:06:06.948824
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_facts = FreeBSDVirtual({})
    assert fb_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:12.384546
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    vm_facts = v.get_virtual_facts()
    assert isinstance(vm_facts, dict)
    assert 'virtualization_type' in vm_facts
    assert 'virtualization_role' in vm_facts
    assert 'virtualization_tech_guest' in vm_facts
    assert 'virtualization_tech_host' in vm_facts

# Generated at 2022-06-23 02:06:20.060336
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # empty sysctl(8) and dmesg(8) outputs
    kern_vm_guest = ''
    hw_hv_vendor = ''
    sec_jail_jailed = ''
    hw_model = ''

    # empty kldstat(8) output
    kldstat = ''

    # sysctl(8) output for a FreeBSD 10.2-RELEASE virtual machine on KVM

# Generated at 2022-06-23 02:06:29.241324
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    Virtual._collectors = {}
    Virtual._fact_class = None
    host_tech = set(['xen', 'kvm'])
    guest_tech = set(['freebsd'])
    virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': host_tech,
        'virtualization_tech_guest': guest_tech,
    }
    fbsd = FreeBSDVirtual()
    assert fbsd.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:06:31.638657
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x != None

# Generated at 2022-06-23 02:06:42.811305
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json
    import os.path

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'data')

    expected_virtual_facts = json.load(open(os.path.join(test_data_dir, 'FreeBSDVirtual_get_virtual_facts.json')))

    def _mock_sysctl_all(*args, **kwargs):
        sysctl_all = {
            'hw.model': 'Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz',
            'kern.vm_guest': 'other',
            'security.jail.jailed': 0,
        }

# Generated at 2022-06-23 02:06:44.375674
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    d = FreeBSDVirtualCollector()
    assert d._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:56.212542
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v._sysctl_all = {}
    v._sysctl_all['kern.vm_guest'] = 'other'
    v._sysctl_all['hw.hv_vendor'] = 'Bochs'
    v._sysctl_all['hw.model'] = 'FreeBSD/amd64 guest'
    v._sysctl_all['security.jail.jailed'] = 0
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_product_name'] == 'FreeBSD'
    assert facts['virtualization_product_version'] == 'amd64 guest'
    # It's a jail

# Generated at 2022-06-23 02:07:08.142398
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:07:19.429043
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:07:21.711006
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Test constructor of FreeBSDVirtual class
    """

    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:24.001756
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = VirtualCollector._get_platform_facts(None, [FreeBSDVirtualCollector])
    assert(virtual.platform == "FreeBSD")

# Generated at 2022-06-23 02:07:27.546503
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """This method will instantiate the FreeBSDVirtualCollector class."""

    obj_freebsdvirtualcollector = FreeBSDVirtualCollector()
    assert obj_freebsdvirtualcollector is not None


# Generated at 2022-06-23 02:07:30.682753
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-23 02:07:31.900555
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()
    assert fb_virtual


# Generated at 2022-06-23 02:07:37.884693
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    expected_virtual_facts = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set(['xen'])}
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:07:42.405931
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Ansible facts class FreeBSDVirtual collects and makes available
    '''
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    ansible_virtual_facts = FreeBSDVirtual({})
    virtual_facts_result = ansible_virtual_facts.get_virtual_facts()
    print(virtual_facts_result)

# Generated at 2022-06-23 02:07:54.704370
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    fact_module = FreeBSDVirtual({})
    assert fact_module.get_virtual_facts() == {}
    sysctl_fact = {'virtualization_type': 'xen', 'virtualization_role': 'guest',
                   'virtualization_tech_guest': {u'xen_domu'},
                   'virtualization_tech_host': set()}
    fact_module.detect_virt_product = lambda x: sysctl_fact if x == 'kern.vm_guest' else {}
    assert fact_module.get_virtual_facts() == sysctl_fact
    fact_module.detect_virt_product = lambda x: {}

# Generated at 2022-06-23 02:07:56.493238
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:58.903437
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:01.140968
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    instance = FreeBSDVirtual()
    assert instance.platform == 'FreeBSD'



# Generated at 2022-06-23 02:08:04.046157
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:05.408862
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert len(virtual_facts) > 0

# Generated at 2022-06-23 02:08:10.063218
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ''' Unit test for constructor of class FreeBSDVirtualCollector '''
    # Run the constructor
    obj = FreeBSDVirtualCollector()
    # Check that the value of virtual_facts object is Empty
    if hasattr(obj, 'virtual_facts'):
        assert False
    else :
        assert True

# Generated at 2022-06-23 02:08:13.096689
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._fact_class == FreeBSDVirtual
    assert facts._platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:21.755972
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(None)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    # in unit test, these values are inherited from base class
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts

# Generated at 2022-06-23 02:08:25.161189
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:34.459134
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from platform import system
    from platform import release
    from platform import machine
    from platform import python_implementation
    from platform import python_version
    from platform import python_compiler

    facts = FreeBSDVirtual({})

# Generated at 2022-06-23 02:08:38.414023
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    expected_dict = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    assert FreeBSDVirtual().get_virtual_facts() == expected_dict

# Generated at 2022-06-23 02:08:40.597600
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:43.647796
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    actual_freebsd_virtual = FreeBSDVirtual(None)
    assert actual_freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:49.091759
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts() == {
        'virtual_facts': {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        }
    }

# Generated at 2022-06-23 02:08:55.260040
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:08:57.915373
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    virtual_facts = freebsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:09:08.277023
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:09:13.401739
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    data = dict(VirtualCollector._test_data('FreeBSD'))
    obj = FreeBSDVirtual(data, {})
    facts = obj.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-23 02:09:20.228102
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json

    # Load data about supported virtualization facts
    v_facts_file = os.path.join(os.path.dirname(__file__), '../../../systems/FreeBSD/virtual.json')
    v_facts_data = json.load(open(v_facts_file, 'rb'))

    # Load data about supported FreeBSD virtualization vendors
    v_vendor_file = os.path.join(os.path.dirname(__file__), '../../../systems/FreeBSD/virtual/vendor.json')
    v_vendor_data = json.load(open(v_vendor_file, 'rb'))

    # Load data about supported FreeBSD virtualization products

# Generated at 2022-06-23 02:09:31.274164
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    test_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail']),
        'virtualization_tech_host': set(['FreeBSD']),
    }

    def syctl_mock(*args, **kwargs):
        return 0

    def read_file_mock(*args, **kwargs):
        if args[0] == 'hw.model':
            return 0
        elif args[0] == '/proc/cpuinfo':
            return "model name  : QEMU Virtual CPU version 1.0"
        else:
            return 0

    def read_file_mock_xen(*args, **kwargs):
        if args[0] == 'hw.model':
            return 1
       

# Generated at 2022-06-23 02:09:34.105526
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)
    assert isinstance(instance.collect(), dict)


# Generated at 2022-06-23 02:09:36.485527
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_virtual_facts()
    print(virtual_facts.get_virtual_facts())


# Generated at 2022-06-23 02:09:47.823538
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert virtual_facts['virtualization_type'] in ['xen', '', 'None']
    assert virtual_facts['virtualization_role'] in ['guest', '', 'None']
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:09:49.964170
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:00.098408
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virt_facts = virtual.get_virtual_facts()
    assert type(virt_facts) == dict
    expected_keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]
    assert all(key in virt_facts for key in expected_keys)
    assert type(virt_facts['virtualization_type']) == str
    assert type(virt_facts['virtualization_role']) == str
    assert type(virt_facts['virtualization_tech_guest']) == set
    assert type(virt_facts['virtualization_tech_host']) == set

# Generated at 2022-06-23 02:10:01.713366
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test that FreeBSDVirtual object is created correctly
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:12.215619
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:10:13.976972
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO: implement FreeBSDVirtual.get_virtual_facts
    # TODO: implement test for FreeBSDVirtual.get_virtual_facts
    pass

# Generated at 2022-06-23 02:10:16.128527
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vm = FreeBSDVirtualCollector()
    assert isinstance(vm, VirtualCollector)
    assert vm._platform == 'FreeBSD'
    assert vm._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:10:17.369743
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-23 02:10:18.510647
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:20.109146
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:21.122742
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()


# Generated at 2022-06-23 02:10:29.617602
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert isinstance(vc._fact_class, type) and issubclass(vc._fact_class, Virtual)
    assert vc._fact_class().platform == 'FreeBSD'
    assert vc._fact_class().get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:10:33.463587
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    module = type('module_dummy_class', (object,), {'exit_json': {}, 'fail_json': {}})
    module_inst = module()
    fbc = FreeBSDVirtualCollector(module_inst)
    assert fbc.platform == 'FreeBSD'


# Generated at 2022-06-23 02:10:37.080954
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:10:42.524095
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    virtual_facts = FreeBSDVirtual().get_virtual_facts(facts)

    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')
    assert('virtualization_tech_guest' not in virtual_facts)
    assert('virtualization_tech_host' not in virtual_facts)