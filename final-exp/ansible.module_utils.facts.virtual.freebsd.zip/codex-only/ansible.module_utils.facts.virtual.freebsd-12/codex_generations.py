

# Generated at 2022-06-23 02:00:47.498954
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    # Xen guest
    fv.detect_virt_product = lambda key: {'virtualization_tech_guest': set(['xen']), 'virtualization_tech_host': set(['xen'])}
    fv.detect_virt_vendor = lambda key: {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}
    vf = fv.get_virtual_facts()
    assert vf['virtualization_type'] == 'xen'
    assert vf['virtualization_role'] == 'guest'

    # bhyve guest

# Generated at 2022-06-23 02:00:59.560902
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mock the sysctl object, then create instance of Virtual class
    virtual_facts = FreeBSDVirtual({
        'sysctl_all': {
            'kern.vm_guest': 'bhyve',
            'hw.hv_vendor': 'BHYVE',
            'security.jail.jailed': '0',
            'hw.model': 'AMD-FX(tm)-8350'
        }
    })

    # Test the returned data structure for FreeBSDVirtual.get_virtual_facts method
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': 'bhyve',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['bhyve', 'hvm']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:01:05.702297
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_technologies == ''

    virtual_facts = FreeBSDVirtual(data={'key': 'value'})
    assert virtual_facts.data['key'] == 'value'

# Generated at 2022-06-23 02:01:07.470750
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-23 02:01:08.982479
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'



# Generated at 2022-06-23 02:01:10.320430
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:13.787729
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class is FreeBSDVirtual


# Generated at 2022-06-23 02:01:16.129371
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()

    assert isinstance(f, Virtual)
    assert isinstance(f, FreeBSDVirtual)

# Generated at 2022-06-23 02:01:21.010111
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import virtual
    facts = virtual.VirtualCollector.collect(None, {})
    assert isinstance(facts, dict)
    platform = facts['ansible_facts']['virtualization_type']
    assert platform in ['vmware', 'virtualbox', 'parallels', 'kvm', 'xen', 'hyperv']

# Generated at 2022-06-23 02:01:24.340548
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({})
    # Python vars are assigned to a new reference when they are passed into a method
    vf = facts.get_virtual_facts()
    assert vf['virtualization_role'] in ['guest', 'host', 'zone']

# Generated at 2022-06-23 02:01:31.270274
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class == FreeBSDVirtual
    assert isinstance(x.fact_class(), Virtual)


# Generated at 2022-06-23 02:01:36.527807
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create instance of FreeBSDVirtual
    bsdvirt = FreeBSDVirtual()

    # Compare keys of return value of get_virtual_facts() with a known
    # list of keys.
    assert set(bsdvirt.get_virtual_facts().keys()) == set([
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ])

# Generated at 2022-06-23 02:01:45.957518
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual."""
    fakefacts_freebsd_vmware = {
        'ansible_facts': {
            'hw_model': 'VMware Virtual Platform'
        }
    }
    virtual_instance = FreeBSDVirtual()
    expected_virtual_facts = {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {
            'vmware',
        },
        'virtualization_tech_host': set(),
    }

    actual_virtual_facts = virtual_instance.get_virtual_facts(
        fakefacts_freebsd_vmware
    )

    assert actual_virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:01:48.611322
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:54.282269
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test FreeBSD Virtualization Facts
    fv = FreeBSDVirtual({})
    fv_facts = fv.get_virtual_facts()
    assert fv_facts['virtualization_type'] == '', \
           "Default is empty string"
    assert fv_facts['virtualization_role'] == '', \
           "Default is empty string"

# Generated at 2022-06-23 02:01:56.772845
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = FreeBSDVirtual(module=None)
    assert virtual.get_virtual_facts() == facts

# Generated at 2022-06-23 02:02:08.953670
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtualCollector = FreeBSDVirtualCollector([])
    assert virtualCollector._platform == 'FreeBSD'
    assert virtualCollector.collect()['ansible_facts']['virtualization_type'] == ''
    assert 'virtualization_role' in virtualCollector.collect()['ansible_facts']
    assert virtualCollector.collect()['ansible_facts']['virtualization_role'] == ''
    assert 'virtualization_tech_guest' in virtualCollector.collect()['ansible_facts']
    assert 'virtualization_tech_host' in virtualCollector.collect()['ansible_facts']

# Generated at 2022-06-23 02:02:10.654861
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == 'FreeBSD'
    assert facts.virt_class == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:02:17.262235
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    # Output of sysctl kern.vm_guest
    assert virtual_facts.detect_virt_product('kern.vm_guest') == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_role': '',
        'virtualization_type': ''
    }

    # Output of sysctl hw.hv_vendor
    assert virtual_facts.detect_virt_product('hw.hv_vendor') == {
        # Does not set virtualization_role or virtualization_type
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_role': '',
        'virtualization_type': ''
    }

    # Output

# Generated at 2022-06-23 02:02:20.044409
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-23 02:02:26.018077
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    new_instance = FreeBSDVirtual('platform', 'command')
    virtual_facts = new_instance.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:02:30.925500
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create the object to test
    bsdv = FreeBSDVirtual({})

    # Call the method to test
    virtual_facts = bsdv.get_virtual_facts()

    # Set the expected facts
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    # Compare actual facts with expected facts
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:02:36.388585
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # This is how we would normally instantiate a FreeBSDVirtualCollector object:
    # FreeBSDVirtualCollector()
    # However, that causes a create_chroot error, so for the sake of unit testing
    # we instantiate VirtualCollector instead.  We only need to test that the
    # FreeBSDVirtualCollector constructor sets the correct _fact_class attribute.
    vc = VirtualCollector()
    assert vc._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:02:41.426860
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import VirtualCollector
    v=VirtualCollector._get_collector('FreeBSD')
    assert v.__class__.__name__ == 'FreeBSDVirtualCollector', "Failed to create FreeBSDVirtualCollector instance"

# Generated at 2022-06-23 02:02:45.877005
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt = FreeBSDVirtualCollector()
    assert str(virt.__class__) == "<class 'ansible.module_utils.facts.virtual.freebsd.FreeBSDVirtualCollector'>"

# Generated at 2022-06-23 02:02:47.149385
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Nothing to test in constructor
    pass

# Generated at 2022-06-23 02:02:47.830270
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:53.449027
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    This is a unit test for method get_virtual_facts of class FreeBSDVirtual.
    The unit test will assert virtualization_type and virtualization_role from
    the facts output.
    """
    virtual_facts = FreeBSDVirtualCollector.collect()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:02:54.888986
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual(dict())
    assert f


# Generated at 2022-06-23 02:02:56.506389
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:00.312629
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from collections import namedtuple
    load_fixture = namedtuple('load_fixture', 'content')
    lf = load_fixture(content='')
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:02.905339
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert not fvc.virtual

# Generated at 2022-06-23 02:03:14.076571
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create a FreeBSDVirtual object
    fb = FreeBSDVirtual({})

    # Test virtual_facts
    virtual_facts = fb.get_virtual_facts()

    # Test virtualization_type
    assert virtual_facts['virtualization_type'] in ['kqemu', 'openvz', 'xen', 'vmware', 'hyperv', 'virtualbox', 'vbox', 'jail', 'bhyve', 'docker', 'zone', 'chroot']
    # Other possible values: 'vserver', 'qemu', 'user', 'bochs', 'parallels', 'phyp', 'physical', 'os400', 'kvm', 'ibm_powerkvm', 'parallels', '', ''

    # Test virtualization_role
    assert virtual_facts['virtualization_role'] in ['guest', 'host']

    # Test

# Generated at 2022-06-23 02:03:16.535761
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fd = FreeBSDVirtual(dict())
    assert isinstance(fd, FreeBSDVirtual)

# Generated at 2022-06-23 02:03:18.328183
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:30.593412
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import inspect
    # Instanciate object
    freebsd_virtual = FreeBSDVirtual()
    # Get dict() representation of object
    freebsd_virtual_dict = inspect.getmembers(freebsd_virtual)
    # Get the get_virtual_facts method from the dict
    get_virtual_facts = [
        item for item in freebsd_virtual_dict
        if item[0] == 'get_virtual_facts'
    ][0]
    # Invoke get_virtual_facts method
    facts = get_virtual_facts[1]()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:03:37.544402
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Unit test to verify that class FreeBSDVirtualCollector is instantiated correctly"""
    fact_class = FreeBSDVirtualCollector._fact_class
    assert fact_class is not None
    assert fact_class.platform is not None
    assert fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:41.536856
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Create an object of FreeBSDVirtual, which is a subclass of Virtual
    """
    fb_virtual_object = FreeBSDVirtual({})
    assert fb_virtual_object is not None
    assert fb_virtual_object.platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:49.617827
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    # TODO: expand to test more
    assert 'virtualization_type' in virtual_facts.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:03:51.114485
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    m = FreeBSDVirtualCollector()
    m.collect()


# Generated at 2022-06-23 02:03:51.718370
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:03:52.876052
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:03:55.146985
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual is not None
    assert freebsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:56.759300
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_instance = FreeBSDVirtualCollector()
    assert isinstance(facts_instance.get_facts(), dict)

# Generated at 2022-06-23 02:04:07.800746
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    "test FreeBSDVirtual get_virtual_facts"
    # We need to mock sysctl_dict to simulate
    # that we are running inside a jail and to
    # set the machine hardware model to None.
    jail_sysctl_dict = {
        'kern.hostuuid': '',
        'kern.vm_guest': 'other',
        'hw.hv_vendor': '',
        'security.jail.jailed': 1,
        'hw.model': None,
        'hw.machine': None
    }

# Generated at 2022-06-23 02:04:20.035348
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup fixture for test
    freebsd_virtual = FreeBSDVirtual(module=None, facts={})

    # Test-cases.
    # Test-case 1: If sysctl exists, then we are on a FreeBSD host.
    # This test doesn't require the host be virtualized.
    result = freebsd_virtual.get_virtual_facts()
    # Expected result: the type and role are empty.
    expected = {'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_host': [],
                'virtualization_tech_guest': []}
    assert result == expected, result

    # Reset fixture for next test
    freebsd_virtual = FreeBSDVirtual(module=None, facts={})

    # Test-case 2: If we have hw_model or hw_vendor

# Generated at 2022-06-23 02:04:32.456396
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test case when jail is used to virtualize system
    jail = FreeBSDVirtual()
    jail.virtual_facts = {'security.jail.jailed': '0'}
    assert jail.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '',
                                        'virtualization_tech_guest': set(['jail']),
                                        'virtualization_tech_host': set()}
    jail.virtual_facts = {'security.jail.jailed': '1'}
    assert jail.get_virtual_facts() == {'virtualization_type': 'jail',
                                        'virtualization_role': 'guest',
                                        'virtualization_tech_guest': set(['jail']),
                                        'virtualization_tech_host': set(['jail'])}

# Generated at 2022-06-23 02:04:33.993078
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:36.235467
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.search_paths == ['/dev/xen/xenstore']



# Generated at 2022-06-23 02:04:38.890420
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    assert type(virtual_facts) == dict


# Generated at 2022-06-23 02:04:44.307235
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({}, {})
    assert isinstance(fv, FreeBSDVirtual)
    assert isinstance(fv, Virtual)
    assert isinstance(fv, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:04:45.771351
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual({}).__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:04:51.850944
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = {}
    FreeBSDVirtualCollector(facts_dict)
    assert facts_dict['virtualization_type'] == 'xen' or \
           facts_dict['virtualization_type'] == 'virtualbox' or \
           facts_dict['virtualization_type'] == 'openvz' or \
           facts_dict['virtualization_type'] == ''

# Generated at 2022-06-23 02:04:56.183482
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_tech_guest'].issubset(set(['vmware', 'virtualbox']))
    assert virtual_facts['virtualization_tech_host'].issubset(set(['vmware', 'virtualbox']))

# Generated at 2022-06-23 02:05:00.046189
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'VirtualBox',
        'virtual_technology': ''
    }
    with open('/proc/cpuinfo', 'rb') as f:
        cpuinfo = f.read()
        res = FreeBSDVirtual(cpuinfo=cpuinfo).get_virtual_facts()
        virtual_facts.update(res)
        assert res == virt

# Generated at 2022-06-23 02:05:02.653468
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    my_fact = FreeBSDVirtual()
    assert my_fact.platform == 'FreeBSD'



# Generated at 2022-06-23 02:05:07.089773
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    expected_keys = {'virtualization_type', 'virtualization_role',
                     'virtualization_tech_guest',
                     'virtualization_tech_host'}
    assert set(virtual_facts) == expected_keys

# Generated at 2022-06-23 02:05:10.727149
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual.platform == 'FreeBSD'
    assert isinstance(virtual._fact_class, type)
    assert virtual._fact_class.__name__ == 'FreeBSDVirtual'
    assert isinstance(virtual._fact_class(), Virtual)

# Generated at 2022-06-23 02:05:16.226334
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    fact_collector = FreeBSDVirtualCollector()
    assert isinstance(fact_collector._fact_class, type)
    assert fact_collector._platform == 'FreeBSD'
    assert fact_collector.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:16.809513
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:05:23.300282
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    # Check FreeBSDVirtualCollector instance
    assert(isinstance(collector, FreeBSDVirtualCollector))
    # Check _fact_class of FreeBSDVirtualCollector instance
    assert(collector._fact_class == FreeBSDVirtual)
    # Check _platform of FreeBSDVirtualCollector instance
    assert(collector._platform == FreeBSDVirtualCollector._platform)


# Generated at 2022-06-23 02:05:25.924122
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()
    freebsd_virtual.detect_virt_vendor('hw.model')

# Generated at 2022-06-23 02:05:32.103009
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, {})
    assert virtual['virtualization_type'] == ''
    assert virtual['virtualization_role'] == ''
    assert virtual['virtualization_system'] == ''
    assert virtual['virtualization_subsystem'] == ''
    assert virtual['virtualization_role'] == ''
    assert virtual['virtualization_vendor'] == ''

# Generated at 2022-06-23 02:05:40.608951
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbvirtual = FreeBSDVirtual()
    if str(type(fbvirtual)) != "<class 'ansible.module_utils.facts.virtual.freebsd.FreeBSDVirtual'>":
        raise AssertionError("Expected class type <class 'ansible.module_utils.facts.virtual.freebsd.FreeBSDVirtual'>, but got %s " % str(type(fbvirtual)))


# Generated at 2022-06-23 02:05:45.009815
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_ins = FreeBSDVirtualCollector(None, None, None, None)
    assert facts_ins.platform == 'FreeBSD'
    assert facts_ins._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:46.917467
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_instance = FreeBSDVirtualCollector()
    assert isinstance(virtual_instance, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:05:51.526993
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:05:58.225165
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'
    assert fb.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:06:07.943868
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual({})
    # Xen DomU
    xen_domu_facts = dict()
    xen_domu_facts['hw_model'] = 'FreeBSD domU'
    xen_domu_facts['kern_version'] = 'FreeBSD 8.3-RELEASE-p6'
    xen_domu_facts['compat_version'] = '2'
    xen_domu_facts['kern_vm_guest'] = 'Xen'
    xen_domu_facts['hw_hv_vendor'] = 'Xen'
    xen_domu_facts['security_jail_jailed'] = '0'
    xen_domu_facts['security_jail_maxversion'] = '0'

# Generated at 2022-06-23 02:06:10.287174
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:18.711459
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    unit test for method get_virtual_facts
    '''

    # Define the test object
    test_obj = FreeBSDVirtual()

    # Define test variables
    # Expected Results
    expected_results = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest={'xen'},
        virtualization_tech_host={},
    )

    test_obj.collect()
    actual_result = test_obj.get_virtual_facts()

    assert actual_result == expected_results, "Test Result:   %s\nTest Expected: %s" % (actual_result, expected_results)

# Generated at 2022-06-23 02:06:30.101064
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    # If no virtualization technology detected, then the virtualization_type
    # and virtualization_role are empty strings.
    facts_virtual_none = {'virtualization_type': '', 'virtualization_role': '',
                          'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    assert v.get_virtual_facts() == facts_virtual_none

    # "hw.model" is set to a non-empty value
    # The virtualization type is based on "hw.model".
    # The virtualization role is guest.
    # The supported virtualization technologies detected
    # are in "virtualization_tech_guest".
    v.hw_model = 'QEMU Virtual CPU version 1.0.0'

# Generated at 2022-06-23 02:06:36.199447
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import collector
    collector._load_collectors()
    for col in collector.all_collectors:
        assert(col.platform == 'FreeBSD')
        assert(col.__class__.__name__ == 'FreeBSDVirtualCollector')
        break

# Generated at 2022-06-23 02:06:38.855972
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f._platform == 'FreeBSD'
    assert f.platform == 'FreeBSD'
    assert isinstance(f, FreeBSDVirtual)
    assert f.get_all() != {}

# Generated at 2022-06-23 02:06:42.235849
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Create an instance of FreeBSDVirtualCollector and
    inspect the value after construction
    """
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._virt_subclasses == {}
    assert virtual_collector._cache.keys() == ['_facts']

# Generated at 2022-06-23 02:06:43.897753
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:06:44.797952
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:06:56.485312
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_host": set(),
        "virtualization_tech_guest": set(),
    }
    freebsd_sysctl_vd_hw_model_dict = {
        "hw.model": "VirtualBox",
        "virtualization_tech_guest": set(['kvm', 'virtualbox']),
        "virtualization_tech_host": set(['kvm', 'virtualbox']),
    }

# Generated at 2022-06-23 02:07:08.422148
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sysctl_map = {
        'hw.model': 'E3500 or E4500',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': '0',
        'kern.vm_guest': 'bhyve'
    }

    FreeBSDVirtual.sysctl = sysctl_map

    assert FreeBSDVirtual().get_virtual_facts() == {
        'virtualization_type': 'bhyve',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['bhyve']),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:07:11.244569
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(module=None).get_virtual_facts()
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:07:11.820016
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:07:13.366382
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual

# Generated at 2022-06-23 02:07:24.970247
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test function for method get_virtual_facts of class FreeBSDVirtual
    """
    # Create the class
    test_class = FreeBSDVirtual(None)
    # Create test fact data
    fact_data = {
        "hw.hv_vendor": '',
        "hw.model": '',
        "security.jail.jailed": "0",
        "kern.vm_guest": "none"
    }

    # Test before setting the virtual facts from fact data to the class
    assert test_class.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }

    # Set the virtual facts from fact data to the class


# Generated at 2022-06-23 02:07:27.939196
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fFreeBSDVirtualCollector = FreeBSDVirtualCollector()
    assert fFreeBSDVirtualCollector._platform == 'FreeBSD'
    assert fFreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:30.725946
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test the constructor of FreeBSDVirtualCollector"""
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:34.343625
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fact_collector = FreeBSDVirtual()
    facts = fact_collector.get_virtual_facts()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:07:37.166138
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, FreeBSDVirtualCollector)
    assert issubclass(collector.platforms['FreeBSD'], FreeBSDVirtual)

# Generated at 2022-06-23 02:07:39.503145
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc.fact_class == FreeBSDVirtual
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:42.927005
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # check correct file
    virt = FreeBSDVirtual()
    assert virt._platform == 'FreeBSD'

    # check correct class
    assert isinstance(virt, Virtual)
    assert isinstance(virt, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:07:45.160227
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd_virtual = FreeBSDVirtual()
    assert bsd_virtual


# Generated at 2022-06-23 02:07:52.360849
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtual()
    virtual_facts = collector.get_virtual_facts()
    # check if virtual_facts are valid
    assert virtual_facts
    assert isinstance(virtual_facts['virtualization_type'], basestring)
    assert isinstance(virtual_facts['virtualization_role'], basestring)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:07:54.627550
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:56.870686
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:02.896476
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test with no params
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual
    # Test with params
    fvc = FreeBSDVirtualCollector(platform='Platy', fact_class='Fish')
    assert fvc._platform == 'Platy'
    assert fvc._fact_class == 'Fish'

# Generated at 2022-06-23 02:08:04.963537
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({}, {})
    assert fv.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:07.160996
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    fv_pl = fv.platform
    assert fv_pl == 'FreeBSD'

# Generated at 2022-06-23 02:08:08.566957
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:10.441161
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual('none')
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:13.161795
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    assert FreeBSDVirtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:16.533579
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:17.251015
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:18.786532
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    fvc.collect()


# Generated at 2022-06-23 02:08:20.366199
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host = FreeBSDVirtual({})
    assert host.platform == "FreeBSD"


# Generated at 2022-06-23 02:08:23.751461
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc,FreeBSDVirtualCollector)
    assert isinstance(fvc._fact_class,FreeBSDVirtual)

# Generated at 2022-06-23 02:08:33.599684
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    input_sysctl_values = {'hw.hv_vendor': 'QEMU',
                           'hw.model': 'QEMU Virtual CPU version 2.0.0',
                           'kern.vm_guest': 'other',
                           'security.jail.jailed': '0'}

    facts = {}
    facts['virtualization_type'] = 'QEMU'
    facts['virtualization_role'] = 'guest'
    facts['virtualization_tech_guest'] = set(['qemu'])
    facts['virtualization_tech_host'] = set(['qemu'])

    virtual_h = FreeBSDVirtual(input_sysctl_values)

    assert virtual_h.get_virtual_facts() == facts

# Generated at 2022-06-23 02:08:35.659491
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    # get instantiation
    virtual = FreeBSDVirtual()
    assert virtual.__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:08:37.000661
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    cls = FreeBSDVirtual()
    assert cls._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:39.103046
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual('/')
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_virtual_facts() is not None

# Generated at 2022-06-23 02:08:41.896799
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.get_virtual_facts()

# Generated at 2022-06-23 02:08:48.254898
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    data = {}
    data['virtualization_type'] = 'FreeBSD'
    data['virtualization_role'] = 'guest'
    data['virtualization_tech_guest'] = ['paravirtualization_FreeBSD']
    data['virtualization_tech_host'] = ['paravirtualization_FreeBSD']
    freeBSDVirtual = FreeBSDVirtual(data)
    assert freeBSDVirtual is not None


# Generated at 2022-06-23 02:08:49.769382
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    test_instance = FreeBSDVirtual('platform', 'sysctl')
    assert test_instance.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:52.306738
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert(virtual_collector.platform == 'FreeBSD')
    assert(virtual_collector.fact_class.platform == 'FreeBSD')
    assert(virtual_collector.fact_class._platform == 'FreeBSD')

# Generated at 2022-06-23 02:08:53.829099
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:01.169493
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import platform
    from sys import version_info

    if not hasattr(FreeBSDVirtual(None).get_virtual_facts(), 'items'):
        raise Exception('FreeBSDVirtual.get_virtual_facts does not return a dictionary.')

    if not version_info.major == 2:
        # Python 3.x
        # Check items of empty dictionary
        assert FreeBSDVirtual(None).get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': ''}

    # Test with a freebsd10.2 host as reported by dmidecode -s system-product-name

# Generated at 2022-06-23 02:09:10.931682
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual()
    # Check virtual type and roles
    setattr(fbsd_virtual, '_dmesg_lines', ['FreeBSD is a guest'])
    setattr(fbsd_virtual, '_sysctl_lines', ['hw.vendor = VMware'])
    virtual_facts = fbsd_virtual.get_virtual_facts()
    assert 'vmware' == virtual_facts['virtualization_type']
    assert 'guest' == virtual_facts['virtualization_role']
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])
    assert virtual_facts['virtualization_tech_host'] == set()
    # FreeBSD inside a VMWare ESXi host

# Generated at 2022-06-23 02:09:15.560452
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This is a unit test for constructor of class FreeBSDVirtualCollector
    """
    var_obj = FreeBSDVirtualCollector()
    var_obj.collect()
    assert var_obj._fact_class == FreeBSDVirtual
    assert var_obj._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:17.860434
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:24.987915
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    FreeBSDVirtual - constructor test
    '''
    #
    # FreeBSDVirtual.__init__(self, *args, **kwargs)
    #
    virt = FreeBSDVirtual()
    # FreeBSDVirtual.platform
    assert virt.platform == 'FreeBSD', 'platform value is not "FreeBSD"'
    # FreeBSDVirtual.virtualization_type
    assert virt.virtualization_type == '', \
        'virtualization_type value is not ""'
    # FreeBSDVirtual.virtualization_role
    assert virt.virtualization_role == '', \
        'virtualization_role value is not ""'

# Generated at 2022-06-23 02:09:29.650940
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Given a FreeBSD system, instantiate
    BSDVirtual = FreeBSDVirtualCollector().collect()[0]

    # Then make sure it is FreeBSD
    facts = BSDVirtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:09:31.023179
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:33.090713
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:09:35.933514
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(module=None)
    assert facts.collect()['virtualization_type'] == ''
    assert facts.collect()['virtualization_role'] == ''



# Generated at 2022-06-23 02:09:37.795461
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:41.041263
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fb_virtual = FreeBSDVirtualCollector()
    fb_virtual_platform = fb_virtual.get_platform()
    assert fb_virtual_platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:41.944415
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:47.640650
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd = FreeBSDVirtual()
    assert bsd.platform == 'FreeBSD'
    assert bsd._host_sysctl == ''
    assert bsd._guest_sysctl == ''
    assert bsd._host_vendor == ''
    assert bsd._guest_vendor == ''
    assert bsd._host_product == ''
    assert bsd._guest_product == ''
    assert bsd._virttype == ''

# Generated at 2022-06-23 02:09:49.920621
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd = FreeBSDVirtual()
    assert fbsd.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:55.858735
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c._fact_class is not None
    assert issubclass(c._fact_class, Virtual)
    assert c._fact_class.platform is not None
    assert c._fact_class.platform == 'FreeBSD'
    assert c._platform is not None
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:00.274105
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = FreeBSDVirtual(module=None, facts=facts)
    facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:10:01.881057
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fd_virtual_facts = FreeBSDVirtual({})
    assert fd_virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:06.505101
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert virt.get_virtual_facts() == {'virtualization_role':'', 'virtualization_type':'', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Unit tests for functions of class FreeBSDVirtual

# Generated at 2022-06-23 02:10:08.946947
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert type(virtual_collector).__name__ == 'FreeBSDVirtualCollector'


# Generated at 2022-06-23 02:10:17.047487
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {
        'kernel': 'FreeBSD',
        'product_serial': 'VMware-42 42 42 42 42 42 42 42 - 42 42 42 42 42 42 42 42',
        'hw_model': '',
        'kern_vm_guest': '',
        'security_jail_jailed': '',
        'hw_hv_vendor': '',
        'gather_subset': [],
        'system_vendor': 'VMware Inc.,',
        'facts': {},
        'product_name': 'VMware Virtual Platform',
        'system_product_name': '',
        'ansible_system': 'FreeBSD',
        'distribution_version': '',
        'gather_timeout': 10
    }


# Generated at 2022-06-23 02:10:18.243178
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:21.017355
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:10:32.896253
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:10:38.543412
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instantiate FreeBSDVirtualCollector object
    f = FreeBSDVirtualCollector()
    # Assert the object is created correctly
    assert f.__class__.__name__ == 'FreeBSDVirtualCollector'
    assert f._platform == 'FreeBSD'
    assert f._fact_class.__name__ == 'FreeBSDVirtual'