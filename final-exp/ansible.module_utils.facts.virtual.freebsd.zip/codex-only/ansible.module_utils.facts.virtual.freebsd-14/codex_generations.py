

# Generated at 2022-06-23 02:00:42.021396
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector().collect()
    assert x.keys() == ['virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host']

# Generated at 2022-06-23 02:00:45.570087
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'
    assert fb.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

# Generated at 2022-06-23 02:00:49.360797
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert (virtual_facts.platform == 'FreeBSD')
    assert (virtual_facts.virtualization_type == '')
    assert (virtual_facts.virtualization_role == '')

# Generated at 2022-06-23 02:00:51.656552
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert isinstance(fv, FreeBSDVirtual)


# Generated at 2022-06-23 02:01:03.057406
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsdvirtual = FreeBSDVirtual()

    # Test facts for a FreeBSD host
    assert fbsdvirtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set()
    }

    # Test facts for a FreeBSD jail host
    fbsdvirtual.facts['svr_jail_host'] = True
    assert fbsdvirtual.get_virtual_facts() == {
        'virtualization_role': 'host',
        'virtualization_type': '',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set(['jail'])
    }

    # Test facts for a FreeBSD jail guest
    fbs

# Generated at 2022-06-23 02:01:05.243449
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})

    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:14.587540
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # We have to create instance of FreeBSDSysctlDetectionMixin
    class MixinFactory(FreeBSDSysctlDetectionMixin):
        _platform = 'FreeBSD'

    virtual_factory = FreeBSDVirtual(MixinFactory())
    virtual_factory.collect()
    virtual_facts = virtual_factory.get_virtual_facts()

    # Check if keys are in the dictionary
    assert 'virtualization_type' in virtual_facts

    # Check if virtualization_type is set and virtualization_role is ''
    assert not virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:01:18.601140
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This test will not run in a normal environment because it would need to
    # be running inside a virtualization environment.
    # get_virtual_facts() could not be tested in a unit test without mocking
    # quite a bit of function.
    pass

# Generated at 2022-06-23 02:01:22.642886
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import doctest
    failed, tests = doctest.testmod(FreeBSDVirtual, optionflags=(doctest.ELLIPSIS | doctest.REPORT_NDIFF))
    assert tests == 0

# Generated at 2022-06-23 02:01:23.829514
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.get_virtual_facts() == {}

# Generated at 2022-06-23 02:01:33.331521
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:34.609232
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:37.979346
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == "FreeBSD"


# Generated at 2022-06-23 02:01:39.535432
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f,VirtualCollector)

# Generated at 2022-06-23 02:01:43.084240
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:01:43.641958
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()

# Generated at 2022-06-23 02:01:45.710600
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:50.944476
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Test the constructor of class FreeBSDVirtual
    '''
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual._dist_version == ''



# Generated at 2022-06-23 02:01:56.553948
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialization parameters
    params = {}
    # Create an instance
    testobj = FreeBSDVirtual(params)
    # Test get_virtual_facts
    facts = testobj.get_virtual_facts()
    # Assert virtualization_type == ''
    assert facts['virtualization_type'] == ''
    # Assert virtualization_role == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:01:58.808959
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Code to test the constructor of class FreeBSDVirtualCollector
    '''
    freebsd_virtual = FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:00.651665
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtualClass = FreeBSDVirtual()
    virtual_facts = virtualClass.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:02:11.103132
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # pylint: disable=unused-variable

    # Empty initialized class
    facts = FreeBSDVirtual()

    # dict is passed as a parameter to get_virtual_facts
    facts.get_virtual_fact_interfaces = lambda x: '{}'
    facts.get_virtual_facts({'kern.vm_guest': 'none'})

    # dict is passed as a parameter to get_virtual_fact_interfaces
    facts.get_virtual_fact_interfaces = lambda x: x
    facts_inject = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }
    facts_get_virtual_facts = facts.get_virtual_facts(facts_inject)

# Generated at 2022-06-23 02:02:13.918985
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()

    assert collector.platform == 'FreeBSD'
    assert collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:02:18.776669
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert isinstance(virtual.data, dict)
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''

# Generated at 2022-06-23 02:02:21.831159
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Instantiate FreeBSDVirtualCollector class'''
    collector = FreeBSDVirtualCollector()
    assert collector is not None

    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:32.271967
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = 'ansible.module_utils.facts.virtual.freebsd'
    fake_sysctl = {
        'kern.vm_guest': 'unknown',
        'hw.model': 'test',
        'hw.hv_vendor': 'test',
        'security.jail.jailed': '0'
    }
    fake_sysctl_vendor = {
        'hw.model': 'test',
        'hw.hv_vendor': 'test',
        'security.jail.jailed': '0'
    }

    # Test for product with hw.hv_vendor = 'VMware VMware Virtual Platfo'
    fake_hw_hv_vendor = 'VMware VMware Virtual Platfo'

# Generated at 2022-06-23 02:02:35.751200
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor for class FreeBSDVirtualCollector is
    # FreeBSDVirtualCollector()
    # Checking whether constructor of class FreeBSDVirtualCollector is
    # executed without raising any exceptions
    f_FreeBSDVirtualCollector = FreeBSDVirtualCollector()
    assert f_FreeBSDVirtualCollector is not None

# Generated at 2022-06-23 02:02:37.458629
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.fact_class == collector._fact_class
    assert collector.platform == collector._platform

# Generated at 2022-06-23 02:02:38.512286
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual()
    assert module.platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:39.989475
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_obj = FreeBSDVirtual("/tmp", "/tmp")
    assert virtual_obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:47.246180
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fact = FreeBSDVirtual(dict(), dict())
    fact._module.run_command = lambda x: (1, '', '')
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert fact.get_virtual_facts() == expected_facts

# Generated at 2022-06-23 02:02:51.974981
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    assert fv.get_virtual_facts() == {'virtualization_type': '',
                                      'virtualization_role': '',
                                      'virtualization_tech_guest': set(['']),
                                      'virtualization_tech_host': set([''])}

# Generated at 2022-06-23 02:03:00.106495
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual._detect_virt_product = lambda sysctl: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    freebsd_virtual._detect_virt_vendor = lambda model_string: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    facts = freebsd_virtual.get_virtual_facts()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:03:03.894541
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, FreeBSDVirtualCollector)
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:03:08.277487
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Construct an object of the class FreeBSDVirtualCollector.
    # This is done to get 100% coverage on the FreeBSDVirtualCollector class.
    fv_obj = FreeBSDVirtualCollector()


# Generated at 2022-06-23 02:03:18.802645
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Mocks
    class Mock_FreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, key):
            if key == 'security.jail.jailed':
                return {'virtualization_type': 'jail',
                        'virtualization_role': 'guest',
                        'virtualization_tech_guest': ['jail'],
                        'virtualization_tech_host': []}
            return {'virtualization_type': '',
                    'virtualization_role': '',
                    'virtualization_tech_guest': [],
                    'virtualization_tech_host': []}

    # Test that when /dev/xen/xenstore exists,
    # a guest Xen is detected and the type is xen and the role is guest

# Generated at 2022-06-23 02:03:26.684248
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = Virtual(None).get_virtual_facts()

    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_use_type_id'], bool)
    assert isinstance(virtual_facts['virtualization_use_type_systemd'], bool)
    assert isinstance(virtual_facts['virtualization_use_type_xen'], bool)

# Generated at 2022-06-23 02:03:37.420388
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == "FreeBSD"
    assert isinstance(vc._fact_class(), FreeBSDVirtual)


if __name__ == '__main__':
    # Unit test for class FreeBSDVirtual
    fact_subclass = FreeBSDVirtual
    virtual_detection_mixin = VirtualSysctlDetectionMixin
    get_virtual_facts = fact_subclass().get_virtual_facts

    # Unit test for virtual_detection_mixin.detect_virt_product
    detect_virt_product = virtual_detection_mixin().detect_virt_product
    assert detect_virt_product('kern.vm_guest') == {'virtualization_tech_host': set(),
                                                   'virtualization_tech_guest': set(['kern_vm_guest'])}


# Generated at 2022-06-23 02:03:45.832198
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = Virtual()
    host_tech = ['vmm']
    guest_tech = ['virtualbox']
    vendor_facts = {'virtualization_type': 'virtualbox',
                    'virtualization_role': 'guest',
                    'virtualization_tech_host': host_tech,
                    'virtualization_tech_guest': guest_tech}

    host_tech = ['vmm']
    guest_tech = ['xen']
    product_facts = {'virtualization_type': 'xen',
                     'virtualization_role': 'guest',
                     'virtualization_tech_host': host_tech,
                     'virtualization_tech_guest': guest_tech}

    host_tech = ['xen', 'vmm', 'vmm2']
    guest_tech = ['xen', 'vmm', 'vmm2']

# Generated at 2022-06-23 02:03:54.401166
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # type: () -> None

    class MockFreeBSDVirtual(FreeBSDVirtual):
        @staticmethod
        def detect_virt_product(sysctl_name):
            return {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
            }

        @staticmethod
        def detect_virt_vendor(sysctl_name):
            return {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
            }

    # pylint: disable=unused-variable

    # Test on FreeBSD host

# Generated at 2022-06-23 02:03:56.711037
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts()['ansible_virtualization_type'] == ''

# Generated at 2022-06-23 02:04:02.111639
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts import virtual
    facts = virtual.collector.get_all_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_technologies' in facts
    assert 'virtual_facts' in facts
    assert 'virtual' in facts
    assert facts['virtual'] == facts['virtual_facts']

# Generated at 2022-06-23 02:04:13.260275
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class FreeBSDVirtual.
    :return:
    '''
    virtual = FreeBSDVirtual(module=None)
    virtual._module = MagicMock()

    # Case 1: /dev/xen/xenstore exists
    virtual._module.get_bin_path.return_value = '/usr/sbin/sysadm'
    virtual._module.run_command.return_value = (0, '3', '')
    virtual._module.file_exists.return_value = True
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:04:15.021165
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:04:17.843194
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # This will raise an exception if FreeBSDVirtual fails to instantiate.
    FreeBSDVirtual()

# Generated at 2022-06-23 02:04:22.284268
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module_name = 'ansible.module_utils.facts.virtual.freebsd'
    module = __import__(module_name, globals(), locals(), ['FreeBSDVirtual'])
    instance = module.FreeBSDVirtual()
    assert instance is not None


# Generated at 2022-06-23 02:04:24.366327
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    test_obj = FreeBSDVirtual({})
    assert test_obj.platform == 'FreeBSD'


# Generated at 2022-06-23 02:04:31.457395
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()

    # Test with a non-existent path
    assert f.detect_virt_product({'path': '/nonexistent/path'}) == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    # Test with a string value
    assert f.detect_virt_product({'path': 'security.jail.jailed', 'value': '0'}) == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert f.detect_virt_product({'path': 'security.jail.jailed', 'value': '1'}) == {'virtualization_tech_guest': set(['jail']), 'virtualization_tech_host': set()}

    # Test with a list value

# Generated at 2022-06-23 02:04:34.492556
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Create a class instance object
    freebsd_virtual1 = FreeBSDVirtual()

    # Check if the object is properly created
    assert freebsd_virtual1

# Generated at 2022-06-23 02:04:37.502349
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_object = FreeBSDVirtual()
    facts = freebsd_virtual_object.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:04:40.106691
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert isinstance(virtual.data, dict)


# Generated at 2022-06-23 02:04:40.676420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:44.658358
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:50.213824
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual_inst = FreeBSDVirtual(None)
    assert isinstance(fbsd_virtual_inst, Virtual)
    assert fbsd_virtual_inst.platform == 'FreeBSD'

    assert isinstance(fbsd_virtual_inst, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:04:52.602592
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    platform_virtual = FreeBSDVirtualCollector()
    assert platform_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:53.808248
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:57.129871
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Return an instance of FreeBSDVirtualCollector.

    This test is needed as the constructor of VirtualCollector is
    not automatically executed when importing the file.

    """
    fv_collector = FreeBSDVirtualCollector()
    assert isinstance(fv_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:04:59.983126
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test Constructor of class FreeBSDVirtualCollector
    """
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:06.002450
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This method is a unit test for constructor of class FreeBSDVirtualCollector
    """
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector
    assert freebsd_virtual_collector.platform == 'FreeBSD'
    assert freebsd_virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:08.962573
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    hostvars = {}
    hostvars['ansible_system_vendor'] = 'FreeBSD'
    v = FreeBSDVirtual(hostvars)
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:10.946402
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({},{},{},{})
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:15.740157
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Function to test constructor of class FreeBSDVirtualCollector'''
    fbsd_obj = FreeBSDVirtualCollector()
    assert fbsd_obj._fact_class is FreeBSDVirtual
    assert fbsd_obj._platform is 'FreeBSD'

# Generated at 2022-06-23 02:05:16.804163
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.data['virtualization_type'] == ''

# Generated at 2022-06-23 02:05:17.896507
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(None).platform == 'FreeBSD'



# Generated at 2022-06-23 02:05:22.285994
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector,VirtualCollector)
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:23.730516
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:27.538104
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    facts = FreeBSDVirtual()
    virtual_facts = facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:05:31.844338
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.__class__ == FreeBSDVirtual

# Generated at 2022-06-23 02:05:34.085305
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''
    # This will fail if constructor does not take exactly one argument
    FreeBSDVirtualCollector(None)

# Generated at 2022-06-23 02:05:39.485731
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:05:42.037274
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual._platform == 'FreeBSD'
    assert freebsd_virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:48.457426
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual_facts = FreeBSDVirtual({})
    bsd_virtual_facts.get_virtual_facts()
    facts = bsd_virtual_facts.facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:05:55.533463
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This test will be expanded with more FreeBSD-specific cases
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    assert freebsd_virtual_facts['virtualization_type'] in ['xen', '']
    assert freebsd_virtual_facts['virtualization_role'] in ['guest', '']

    print('Unit test for method get_virtual_facts of class FreeBSDVirtual is successful')

# Generated at 2022-06-23 02:05:58.224644
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Return a dictionary as virtual_facts
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert type(virtual_facts) is dict

# Generated at 2022-06-23 02:06:00.220939
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    info = FreeBSDVirtual()
    assert info is not None

# Generated at 2022-06-23 02:06:06.182338
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('', (), {})()
    fake_module.exit_json = lambda **kwargs: ''

    # Create an instance of FreeBSDVirtual and run the method get_virtual_facts
    # with fake_module as argument
    virtual_freebsd = FreeBSDVirtual(fake_module)
    virtual_freebsd_facts = virtual_freebsd.get_virtual_facts()

    # Asserts
    assert virtual_freebsd_facts['virtualization_type'] or virtual_freebsd_facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:06:08.509252
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ''' Test FreeBSDVirtualCollector(). '''
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:11.471264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:17.518617
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtualization_facts = FreeBSDVirtual(module=None).get_virtual_facts()
    assert 'virtualization_type' in virtualization_facts
    assert 'virtualization_role' in virtualization_facts
    assert 'virtualization_tech_guest' in virtualization_facts
    assert 'virtualization_tech_host' in virtualization_facts
    assert 'virtualization_product' in virtualization_facts
    assert 'virtualization_vendor' in virtualization_facts

# Generated at 2022-06-23 02:06:24.169166
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    return_value = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    bsd_virt = FreeBSDVirtual()
    assert bsd_virt.get_virtual_facts() == return_value

# Generated at 2022-06-23 02:06:31.693279
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    platform = 'FreeBSD'
    fact_subclass = FreeBSDVirtual
    fact_class = Virtual

    fact_subclass.platform = platform

    # Set up a mock sysctl class, since it's hard to make the actual one
    # return predetermined values.

# Generated at 2022-06-23 02:06:32.310646
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:36.596108
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual()
    virtual_facts = facts.get_virtual_facts()
    # import pdb; pdb.set_trace()
    print(virtual_facts)

if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:06:39.261443
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test FreeBSDVirtualCollector class"""
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:43.295188
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}, {}).get_virtual_facts()
    for key in ('virtualization_type', 'virtualization_role',
                'virtualization_tech_host', 'virtualization_tech_guest'):
        assert isinstance(facts[key], (str, set))

# Generated at 2022-06-23 02:06:45.513282
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:48.166822
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:52.643907
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:06:55.187713
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    # Constructor without arguments
    assert FreeBSDVirtual()
    # Constructor with arguments
    set_module_args({})
    assert FreeBSDVirtual(ansible_module_args={})


# Generated at 2022-06-23 02:06:57.875761
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert isinstance(obj, VirtualCollector)
    return True

# Generated at 2022-06-23 02:07:09.367714
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector

    supported_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # constructor of class FreeBSDVirtualCollector
    # works without any errors
    tmp_freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert tmp_freebsd_virtual_collector
    assert tmp_freebsd_virtual_collector._platform == 'FreeBSD'
    assert tmp_freebsd_virtual_collector._fact_class
    assert tmp_freebsd_virtual_collector.supported_facts == supported_facts


# Generated at 2022-06-23 02:07:10.607085
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    # TODO complete the unit test


# Generated at 2022-06-23 02:07:22.116486
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def test_version(capsys):
        version = 'FreeBSD 8.4-RELEASE-p1 #0: Mon Dec 10 10:38:54 PST 2012'
        expected = {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_host': set(),
            'virtualization_tech_guest': set()
        }
        assert version == VirtualCollector._version(capsys)
        assert expected == FreeBSDVirtual().get_virtual_facts()

    # don't print to stdout, but raise an Exception
    # if no version found
    with mock.patch('sys.stdout', new=StringIO()) as fake_stdout:
        with pytest.raises(Exception) as excinfo:
            VirtualCollector._version("")

# Generated at 2022-06-23 02:07:24.042265
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual()
    assert fbv.platform == 'FreeBSD'


# Generated at 2022-06-23 02:07:35.859196
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    expected_virtual_facts = {'virtualization_tech_guest': set(['bhyve', 'kvm', 'xen']),
                              'virtualization_type': '', 'virtualization_tech_host': set(['bhyve', 'kvm', 'xen']),
                              'virtualization_role': ''}
    kern_vm_guest = {'virtualization_tech_guest': ('xen', 'kvm', 'bhyve'),
                     'virtualization_tech_host': ('xen', 'kvm', 'bhyve')}

# Generated at 2022-06-23 02:07:37.122646
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert isinstance(FreeBSDVirtual(), FreeBSDVirtual)



# Generated at 2022-06-23 02:07:48.539686
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a simple class instance
    freebsd_virtual = FreeBSDVirtual({})
    # Create a simple dict with sysctl outputs
    sysctl_data = {
        "hw.model": "VirtualBox",
        "hw.hv_vendor": "KVM",
        "hw.hv_vm_name": "FreeBSD VirtualBox",
        "kern.vm_guest": "other",
        "security.jail.jailed": 0,
        "vm.vmtotal": "",
    }
    # Set the dict as a class attribute
    freebsd_virtual.sysctl_data = sysctl_data
    # Invoke the get_virtual_facts method of the class FreeBSDVirtual
    virtual_facts = freebsd_virtual.get_virtual_facts()
    # Check the resulted dict

# Generated at 2022-06-23 02:07:55.676172
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    # Test get_virtual_facts method of class FreeBSDVirtual
    virtual = FreeBSDVirtualCollector.collect()
    assert 'virtualization_type' in virtual
    assert 'virtualization_role' in virtual
    assert set(virtual['virtualization_tech_guest']) == set(['xen']) \
        or virtual['virtualization_type'] == ''
    assert virtual['virtualization_role'] == 'guest' or virtual['virtualization_role'] == ''

# Generated at 2022-06-23 02:08:03.503479
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test to verify the FreeBSDVirtualCollector
     In newer versions of Ansible, this is done by the test framework
    '''
    fvc = FreeBSDVirtualCollector()
    fv = fvc.collect()
    assert fv.platform == 'FreeBSD'
    assert fv.get_virtual_facts()['virtualization_type'] in ['xen', '', 'bhyve', 'vmware', 'jail', 'paravirtualized', 'kvm', 'virtualbox', 'physical']

# Generated at 2022-06-23 02:08:15.828891
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # We don't care about platform, we will force it
    facts = VirtualCollector().collect(platform='FreeBSD')
    assert sorted(facts.keys()) == [
            'virtualization_role',
            'virtualization_type',
            'virtualization_tech_guest',
            'virtualization_tech_host'
        ]

    # Virtualization_role can be host or guest, depending on
    # if this is a container or a VM
    # Virtualization_type can be kvm, bhyve, xen or jail
    # Virtualization_tech_guest is a list of:
    #    - 'container' if we are in a container
    #    - empty if we aren't in a container
    # Virtualization_tech_host is a list of:
    #    - 'kvm' if kvm is installed
    #    -

# Generated at 2022-06-23 02:08:17.631773
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector != None


# Generated at 2022-06-23 02:08:21.402324
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(False).get_virtual_facts() == {'virtualization_type': '',
                                                         'virtualization_role': '',
                                                         'virtualization_tech_guest': set(),
                                                         'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:08:21.953199
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:33.527502
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('module', (), {
        'exit_json': lambda self, result: None,
        'fail_json': lambda self, msg: None
    })()
    fv = FreeBSDVirtual(fake_module)
    facts = {'ansible_distribution': 'FreeBSD', 'virtual': None}
    host_tech = set()
    guest_tech = set()

    if os.path.exists('/dev/xen/xenstore'):
        guest_tech.add('xen')
        facts['virtualization_type'] = 'xen'
        facts['virtualization_role'] = 'guest'
    else:
        facts['virtualization_type'] = ''
        facts['virtualization_role'] = ''

    kern_vm_guest = {}

# Generated at 2022-06-23 02:08:35.614660
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb = FreeBSDVirtual()
    assert fb.get_virtual_facts() == {}


# Generated at 2022-06-23 02:08:37.299150
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    assert fb.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:38.743579
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:46.001321
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class._platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual
    assert isinstance(x._fact_class, Virtual)
    assert isinstance(x._fact_class, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:08:56.712714
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    fake_sysctl = {'hw.model': 'QEMU Virtual CPU version 1.5.5'}
    fake_sysctl['kern.vm_guest'] = 'other'
    fake_sysctl['hw.hv_vendor'] = 'unknown'
    fake_sysctl['security.jail.jailed'] = 0
    fake_sysctl['kern.vm_guest'] = 'other'
    fake_sysctl['hw.hv_vendor'] = 'unknown'
    fake_sysctl['security.jail.jailed'] = 0
    fake_sysctl_empty = {}
    fake_sysctl_empty['kern.vm_guest'] = 'other'
    fake_sysctl_empty['hw.hv_vendor'] = 'unknown'
    fake_sysctl_

# Generated at 2022-06-23 02:08:59.189795
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual().platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:02.142004
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bv = FreeBSDVirtualCollector()
    assert bv.platform == 'FreeBSD'
    assert bv._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:04.486689
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtualcollector = FreeBSDVirtualCollector()
    assert virtualcollector._platform == 'FreeBSD'
    assert isinstance(virtualcollector._fact_class, type(FreeBSDVirtual))

# Generated at 2022-06-23 02:09:07.030989
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v.data.get('virtualization_type', '') == ''
    assert v.data.get('virtualization_role', '') == ''


# Generated at 2022-06-23 02:09:08.494453
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvirt_collector = FreeBSDVirtualCollector()
    assert fvirt_collector is not None

# Generated at 2022-06-23 02:09:11.033147
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert not v.get_virtual_facts()['virtualization_tech_guest']


# Generated at 2022-06-23 02:09:18.813196
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    instance = FreeBSDVirtual()
    instance.detect_virt_product = lambda sysctl: {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    instance.detect_virt_vendor = lambda sysctl: {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    facts = instance.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host']

# Generated at 2022-06-23 02:09:21.577196
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, {})
    assert virtual
    assert isinstance(virtual,Virtual)
    assert isinstance(virtual,VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:09:24.354900
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result.platform == 'FreeBSD'
    assert result._fact_class is FreeBSDVirtual
    assert result._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:35.630788
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_without_xenstore = FreeBSDVirtual()
    assert virtual_facts_without_xenstore.platform == 'FreeBSD'
    assert virtual_facts_without_xenstore.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Mock out the Xenstore file
    import contextlib
    import tempfile
    @contextlib.contextmanager
    def mocked_open(filename):
        assert filename == '/dev/xen/xenstore'
        yield tempfile.TemporaryFile()

    from ansible.module_utils.facts.virtual.freebsd import open # noqa

# Generated at 2022-06-23 02:09:46.964407
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fixture_data = {
        'sysctl_kern_vm_guest': '',
        'sysctl_hw_hv_vendor': '',
        'sysctl_security_jail_jailed': '',
        'hv_model': '',
        'hv_model_juniper_srx': 'stingray SRX300',
        'hv_model_vmware_esx': 'VMware, Inc.',
    }

    def mock_read_file(filename):
        return fixture_data.get(filename)

    def mock_exists(path):
        return True

    Virtual.read_file = mock_read_file
    Virtual.exists = mock_exists


# Generated at 2022-06-23 02:09:49.191064
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:56.208687
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual(module=None)

    assert fbsd_virtual.platform == 'FreeBSD'
    assert fbsd_virtual._platform == 'FreeBSD'
    assert fbsd_virtual.virtualization_type() == ''
    assert fbsd_virtual.virtualization_role() == ''
    assert fbsd_virtual._guest_tech is None
    assert fbsd_virtual._host_tech is None

# Generated at 2022-06-23 02:09:58.246238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform =='FreeBSD'
    assert isinstance(FreeBSDVirtualCollector._fact_class, FreeBSDVirtual)


# Generated at 2022-06-23 02:10:04.764227
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fBSDInst = FreeBSDVirtual({})
    if fBSDInst.platform != 'FreeBSD':
        raise Exception("Value of FreeBSD.platform not set correctly")
    if 'virtualization_type' not in fBSDInst.virtual_facts:
        raise Exception("FreeBSD.virtual_facts is missing "
                        "'virtualization_type'")
    if 'virtualization_role' not in fBSDInst.virtual_facts:
        raise Exception("FreeBSD.virtual_facts is missing "
                        "'virtualization_role'")


# Generated at 2022-06-23 02:10:12.733096
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    results = dict()
    results['virtualization_type'] = 'xen'
    results['virtualization_role'] = 'guest'
    results['virtualization_tech_guest'] = set(['xen'])
    results['virtualization_tech_host'] = set(['xen'])
    fbsd_virtualization = FreeBSDVirtual()
    # Mock the filesystem for FreeBSDVirtual.get_virtual_facts()
    fbsd_virtualization.os.path.exists = lambda x: True
    virtual_facts = fbsd_virtualization.get_virtual_facts()
    assert virtual_facts == results

# Generated at 2022-06-23 02:10:19.212971
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Test method get_virtual_facts of class FreeBSDVirtual,
    with following mocks:
    - mock_open,
    - mock_contextlib_nested,
    - mock_os_path_exists,
    - mock_get_virtual_facts
    '''
    # Create the mock objects
    class mock_contextlib_nested:
        @staticmethod
        def __exit__(*args, **kwargs):
            pass

        @staticmethod
        def __enter__(*args, **kwargs):
            return '/dev/xen/xenstore'

    class mock_open:
        @staticmethod
        def __exit__(*args, **kwargs):
            pass

        @staticmethod
        def __enter__(*args, **kwargs):
            return ['Xen', '4.2']


# Generated at 2022-06-23 02:10:21.136543
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:26.183229
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Testing constructor for FreeBSDVirtual
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.get_virtual_facts()["virtualization_type"] == ""
    assert virtual_facts.get_virtual_facts()["virtualization_role"] == ""

# Generated at 2022-06-23 02:10:27.770776
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'
    assert virt.get_virtual_facts()

# Generated at 2022-06-23 02:10:28.347783
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    obj = FreeBSDVirtual()

    assert obj.platform == 'FreeBSD'


# Generated at 2022-06-23 02:10:40.145905
# Unit test for method get_virtual_facts of class FreeBSDVirtual