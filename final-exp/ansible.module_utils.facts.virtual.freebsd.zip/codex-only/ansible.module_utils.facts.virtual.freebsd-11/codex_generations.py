

# Generated at 2022-06-23 02:00:41.046522
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:00:42.441451
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:44.312397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:48.584358
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'
    assert fv.virtual == 'FreeBSD'

# Generated at 2022-06-23 02:00:59.993488
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_distro = FreeBSDVirtual(None)
    fake_distro.detect_virt_product = lambda *args: {'virtualization_tech_host': '', 'virtualization_tech_guest': ''}
    fake_distro.detect_virt_vendor = lambda *args: {'virtualization_tech_host': '', 'virtualization_tech_guest': ''}

    # Set sysctl as fake
    fake_kern_bootfile = '/boot/kernel/kernel'
    fake_kern_ostype = 'FreeBSD'
    fake_kern_osrelease = '10.1-RELEASE'
    fake_kern_osrevision = str(261974)

# Generated at 2022-06-23 02:01:04.116533
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockSysctl(object):
        def __init__(self, mock_sysctl_data):
            self.sysctl_values = mock_sysctl_data

        def __call__(self, *args, **kwargs):
            ret = []
            for key in args:
                ret.append(self.sysctl_values[key])
            return ret

    def mock_detect_virt_product(*args):
        if args[0] == 'kern.vm_guest':
            return dict(
                virtualization_tech_guest={'jail'},
                virtualization_tech_host={'jail'}
            )

# Generated at 2022-06-23 02:01:06.149429
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd = FreeBSDVirtual()
    assert fbsd.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:16.129328
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Note: Only the three first statements of get_virtual_facts()
    # are tested.

    # Instantiate a FreeBSDVirtual object
    freebsd_virtual_facts = FreeBSDVirtual({})

    # Update the following dict with the values your system should
    # have.
    expected_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
    }

    # Call method get_virtual_facts()
    virtual_facts = freebsd_virtual_facts.get_virtual_facts()

    # Assert the expected dict and received dict are equal
    assert expected_virtual_facts == virtual_facts

# Generated at 2022-06-23 02:01:19.788861
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # This function is intentionally left as an empty function.
    # It is here for documentation purposes for the above.
    # The code is implemented in the test of the AnsibleModule
    # class.
    return

# Generated at 2022-06-23 02:01:21.101210
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    return FreeBSDVirtual()



# Generated at 2022-06-23 02:01:23.733375
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_col = FreeBSDVirtualCollector()
    assert isinstance(fv_col._fact_class, FreeBSDVirtual)
    assert fv_col._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:24.633910
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual({}).platform == "FreeBSD"

# Generated at 2022-06-23 02:01:29.187494
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:35.557453
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import sys
    import collections

    fact_subclass = FreeBSDVirtualCollector(collections.namedtuple('Facts', ['all_facts']))
    assert fact_subclass._platform == 'FreeBSD'
    assert fact_subclass._fact_class == FreeBSDVirtual
    assert fact_subclass._fact_class.platform == 'FreeBSD'
    assert fact_subclass._fact_class.get_virtual_facts().__class__.__name__ == 'dict'

# Generated at 2022-06-23 02:01:46.275837
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    data = dict()
    data['current_data'] = dict()
    data['current_data']['facts'] = dict()
    data['current_data']['facts']['virtualization_role'] = 'guest' # This should be overwritten
    data['current_data']['facts']['virtualization_type'] = 'guest' # This should be overwritten
    data['current_data']['ansible_facts'] = dict()

    freebsdVirtual = FreeBSDVirtual(data)

    kern_vm_guest = 'kern.vm_guest'
    hw_hv_vendor = 'hw.hv_vendor'
    sec_jail_jailed = 'security.jail.jailed'
    hw_model = 'hw.model'
    freebsdVirtual.set

# Generated at 2022-06-23 02:01:49.080275
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert issubclass(obj._fact_class, Virtual)

# Generated at 2022-06-23 02:01:57.878688
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor of FreeBSDVirtualCollector is expected to be called only once.
    # In order to make sure of this, we set a class-level variable to track the call.
    FreeBSDVirtualCollector.ctor_count = 0
    assert FreeBSDVirtualCollector.ctor_count == 0
    FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector.ctor_count == 1

    # The constructor should set _platform property,
    # and _fact_class property
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:10.767213
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:02:12.759242
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:23.579578
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    # Patch VirtualSysctlDetectionMixin._sysctl_all
    VirtualSysctlDetectionMixin._sysctl_all = (lambda x: {
        'kern.vm_guest': [],
        'hw.hv_vendor': [],
        'hw.hv_vm': [],
        'security.jail.jailed': [],
        'hw.model': [],
    })

    # Create an instance of FreeBSDVirtual
    facts_virtual_instance = FreeBSDVirtual()
    # Test method get_virtual_facts
    result = facts_virtual_instance.get_virtual_facts()

# Generated at 2022-06-23 02:02:28.677353
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    result = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in result.keys()
    assert 'virtualization_role' in result.keys()
    assert 'virtualization_tech_guest' in result.keys()
    assert 'virtualization_tech_host' in result.keys()

# Generated at 2022-06-23 02:02:31.646983
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    # Should include FreeBSDVirtual in the mro
    assert 'FreeBSDVirtual' in v.__class__.__mro__

# Generated at 2022-06-23 02:02:39.698977
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    f = FreeBSDVirtual()
    facts = f.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:02:41.918617
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create an instance of FreeBSDVirtual
    fr = FreeBSDVirtual()
    # call method get_virtual_facts
    facts = fr.get_virtual_facts()
    assert facts is not None

# Generated at 2022-06-23 02:02:46.142071
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._fact_class == FreeBSDVirtual
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:47.375663
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:49.792489
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'



# Generated at 2022-06-23 02:02:51.616805
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:57.601318
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Test constructor for FreeBSDVirtual"""
    # FreeBSDVirtual instantiation
    bsd_virtual_instance = FreeBSDVirtual()
    # Check FreeBSDVirtual instance
    assert isinstance(bsd_virtual_instance, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:59.190374
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert(isinstance(fv, Virtual))

# Generated at 2022-06-23 02:03:01.079595
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:03:05.013903
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Unit test for constructor of class FreeBSDVirtualCollector
    """
    freebsd_obj = FreeBSDVirtualCollector()
    assert freebsd_obj._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:07.724177
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:08.327795
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:03:14.130346
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Getting the FreeBSDVirtual object for testing get_virtual_facts method
    virtual_facts_obj = FreeBSDVirtualFactCollector()

    # Calling the get_virtual_facts method
    virtual_facts = virtual_facts_obj.get_virtual_facts()

    # Asserting the data type of the returned value
    assert type(virtual_facts) is dict
    assert type(virtual_facts['virtualization_type']) is str
    assert type(virtual_facts['virtualization_role']) is str

# Generated at 2022-06-23 02:03:16.535776
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    c_virtual = FreeBSDVirtual()
    c_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:03:19.141603
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(module=None)
    assert facts.get_virtual_facts()['virtualization_type'] == ''
    assert facts.collect()['ansible_virtualization_type'] == ''

# Generated at 2022-06-23 02:03:24.382318
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector(None, None).fetch_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:03:37.352746
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    import io
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

# Generated at 2022-06-23 02:03:39.199751
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual()
    assert fbv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:46.590201
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual({})
    # Mock virtualization_vendor and virtualization_product
    freebsd_virtual.get_virtual_vendor_facts = lambda x: {'virtualization_vendor': 'VMWare', 'virtualization_product': 'ESX'}
    # Mock sysctl_virtual_facts

# Generated at 2022-06-23 02:03:51.272442
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    assert FreeBSDVirtual().get_virtual_facts() == expected_facts

# Generated at 2022-06-23 02:03:56.277077
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    FreeBSDVirtual.get_virtual_facts() Test
    """

    facts = {
        'kernel': 'FreeBSD',
        'virtualization_role': 'none',
        'virtualization_type': 'none'
    }

    mock_sysctl = {
        'hw.model': 'VirtualBox',
        'hw.hv_vendor': 'Virtuozzo',
        'security.jail.jailed': '0',
        'kern.vm_guest': 'unknown'
    }

    freebsd_virtual_collector = FreeBSDVirtualCollector({'_ansible_sysctl': mock_sysctl}, facts)
    get_virtual_facts = freebsd_virtual_collector.get_virtual_facts()


# Generated at 2022-06-23 02:03:58.800295
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''



# Generated at 2022-06-23 02:04:01.905887
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:04:02.948600
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:05.956550
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = dict()
    f = FreeBSDVirtualCollector(facts, None)
    assert f._platform == 'FreeBSD'
    assert f.collect() == {}


# Generated at 2022-06-23 02:04:17.926768
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual({})

    # sysctl_kern_vm_guest
    fbsd_virtual.sysctl_kern_vm_guest = 'vmware'
    fbsd_virtual.sysctl = {
        'hw.hv_vendor': None,
        'security.jail.jailed': 0,
        'kern.vm_guest': 'vmware',
    }
    assert fbsd_virtual.get_virtual_facts() == {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(),
    }
    # sysctl_hw_hv_vendor
    fbsd_virtual.sys

# Generated at 2022-06-23 02:04:20.643987
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:04:28.530587
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_class_instance = FreeBSDVirtual()
    freebsd_virtual_facts = freebsd_virtual_class_instance.get_virtual_facts()
    assert isinstance(freebsd_virtual_facts['virtualization_type'], str)
    assert isinstance(freebsd_virtual_facts['virtualization_role'], str)
    assert isinstance(freebsd_virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(freebsd_virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:04:33.618011
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test with no optional args
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual._platform == 'FreeBSD'
    assert freebsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:04:35.907933
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert instance._platform == 'FreeBSD'
    assert isinstance(instance._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:04:38.085047
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.__class__ == FreeBSDVirtualCollector
    assert x._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:47.178485
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual(None)

    # Set values for FreeBSDVirtual._virtual_facts
    freebsd_virtual._virtual_facts = {
        'hw.model': 'VirtualBox',
        'kern.vm_guest': 'other',
        'security.jail.jailed': '0',
        'hw.hv_vendor': 'Oracle Corporation',
    }

    # Test with empty virtualization_type
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set(['virtualbox'])
    assert virtual_facts['virtualization_tech_host'] == set(['oracle'])

    # Test

# Generated at 2022-06-23 02:04:51.594040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class._platform == 'FreeBSD'



# Generated at 2022-06-23 02:04:54.562025
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance,VirtualCollector)
    assert isinstance(instance._fact_class,FreeBSDVirtual)



# Generated at 2022-06-23 02:04:56.466611
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:05:01.573011
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual({})
    facts = f.get_virtual_facts()

    # Test some random keys
    assert facts['virtualization_type'] in [
        '', 'xen', 'jail']
    assert facts['virtualization_role'] in [
        '', 'guest', 'host']

# Generated at 2022-06-23 02:05:12.078668
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    v = FreeBSDVirtual()
    v.detect_virt_product = fake_detect_virt_product
    v.detect_virt_vendor = fake_detect_virt_vendor
    v.is_sysctl_virtual = fake_is_sysctl_virtual
    v.is_file_virtual = fake_is_file_virtual
    v.get_virtual_facts()

    assert v.virtual_facts['virtualization_type'] == 'xen'
    assert v.virtual_facts['virtualization_role'] == 'guest'
    assert v.virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert v.virtual_facts['virtualization_tech_host'] == set(['xen'])

# fake the is_sysctl_virtual method

# Generated at 2022-06-23 02:05:14.812550
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:21.917457
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.collector import VirtualCollector
    virtual_collectore = VirtualCollector(platform='FreeBSD')
    assert virtual_collectore.platform == 'FreeBSD'
    assert virtual_collectore.platform == virtual_collectore._platform, "platform attr and _platform class var does not match."
    assert isinstance(virtual_collectore._fact_class, FreeBSDVirtual)
    assert isinstance(virtual_collectore._fact_class, Virtual)


# Generated at 2022-06-23 02:05:23.730892
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    my_freebsdvirtual = FreeBSDVirtual()
    assert my_freebsdvirtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:26.921427
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    if os.path.exists('/dev/xen/xenstore'):
        assert not FreeBSDVirtualCollector().facts['virtualization_type']
    else:
        assert FreeBSDVirtualCollector().facts['virtualization_type']

# Generated at 2022-06-23 02:05:32.404662
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual(None)
    assert fb.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:33.691824
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:05:37.400529
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fc = FreeBSDVirtualCollector()
    assert isinstance(fc, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:05:46.918489
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Writing a test would be too hard due to all the `sysctl` calls.
    # This test is just to maintain coverage.
    class FakeFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, product):
            return {}

        def detect_virt_vendor(self, product):
            return {}

    test = FakeFreeBSDVirtual()
    actual = test.get_virtual_facts()

    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert actual == expected

# Generated at 2022-06-23 02:05:53.264657
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts_test = virtual.get_virtual_facts()
    assert virtual_facts_test
    # FreeBSD is not virtualized unless we run under a Xen Dom0
    assert 'virtualization_type' in virtual_facts_test and \
        virtual_facts_test['virtualization_type'] == ''
    assert 'virtualization_role' in virtual_facts_test and \
        virtual_facts_test['virtualization_role'] == ''

# Generated at 2022-06-23 02:06:04.512949
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Make instance of FreeBSDVirtual
    virtual_facts = FreeBSDVirtual()

    # Definition of the testing environment
    x86_env = {'hw.model': 'Intel(R) Xeon(R) CPU E5-2630 v3 @ 2.40GHz',
               'kern.vm_guest': 'other',
               'hw.hv_vendor': 'unknown',
               'security.jail.jailed': '0'}
    vmware_env = {'hw.model': 'VMware Virtual Platform',
                  'kern.vm_guest': 'other',
                  'hw.hv_vendor': 'unknown',
                  'security.jail.jailed': '0'}

# Generated at 2022-06-23 02:06:07.641320
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instantiate FreeBSDVirtualCollector
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:10.337331
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:06:12.236508
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert fv.platform == 'FreeBSD'



# Generated at 2022-06-23 02:06:18.260489
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    # verify that detection methods are part of class
    assert hasattr(FreeBSDVirtual, 'get_virtual_facts')
    assert hasattr(FreeBSDVirtual, 'platform')
    assert hasattr(FreeBSDVirtual, 'detect_virt_product')
    assert hasattr(FreeBSDVirtual, 'detect_virt_vendor')
    assert hasattr(FreeBSDVirtual, 'platform')

# Generated at 2022-06-23 02:06:24.318392
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    facts = FreeBSDVirtualCollector().get_virtual_facts()

    assert facts['virtualization_type'] in ('', 'xen')
    assert facts['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-23 02:06:25.484146
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual()


# Generated at 2022-06-23 02:06:28.064003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)
    assert isinstance(instance._fact_class, FreeBSDVirtual)
    assert isinstance(instance._platform, str)

# Generated at 2022-06-23 02:06:33.650287
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual(dict(), dict())
    assert isinstance(f, FreeBSDVirtual)
    assert isinstance(f, Virtual)
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:37.393561
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert facts._platform == 'FreeBSD'
    assert facts.platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual
    assert facts.get_virtual_facts()['virtualization_type'] in ['', 'xen']

# Generated at 2022-06-23 02:06:40.384916
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c._platform == 'FreeBSD'
    assert isinstance(c._fact_class, type) and issubclass(c._fact_class, Virtual)
    assert c._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:41.865372
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:06:53.852763
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:07:00.966271
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_test = FreeBSDVirtual()
    virtual_facts_test.get_all()
    virtual_facts_test.populate()
    assert virtual_facts_test.data['virtualization_type'] == ''
    assert virtual_facts_test.data['virtualization_role'] == ''
    assert virtual_facts_test.data['virtualization_tech_guest'] == set()
    assert virtual_facts_test.data['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:07:12.293634
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    freebsd_virtual = FreeBSDVirtualCollector.fetch_virtual_facts(None)
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in freebsd_virtual_facts, \
           'FreeBSD virtual_facts dict should have a virtualization_type key'
    assert 'virtualization_role' in freebsd_virtual_facts, \
           'FreeBSD virtual_facts dict should have a virtualization_role key'
    assert 'virtualization_system' in freebsd_virtual_facts, \
           'FreeBSD virtual_facts dict should have a virtualization_system key'

# Generated at 2022-06-23 02:07:17.157334
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual("**kwargs")
    v.collect_platform_subset_facts()
    v_facts = v.get_virtual_facts()
    assert v_facts['virtualization_type'] == 'xen'
    assert v_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:07:19.286133
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.get_virtual_facts()

# Generated at 2022-06-23 02:07:22.296072
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # instantiate a FreeBSDVirtualCollector object
    result = FreeBSDVirtualCollector(None, None)
    # check its vars
    assert result.platform == "FreeBSD"
    assert result.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:32.805321
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_sysv_facts = {
        'security.jail.jailed': '0',
        'hw.hv_vendor': 'QEMU',
        'kern.vm_guest': 'other',
    }


# Generated at 2022-06-23 02:07:36.417013
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:41.587580
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual({})
    # Set empty values as default
    assert freebsd_virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert freebsd_virtual_facts.get_virtual_facts()['virtualization_role'] == ''
    assert freebsd_virtual_facts.get_virtual_facts()['virtualization_technology'] == ''

# Generated at 2022-06-23 02:07:52.586587
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {
        'distribution': 'FreeBSD',
        'kernel': 'FreeBSD',
        'kernel_version': 9
    }
    virtual = FreeBSDVirtual(facts, {})
    virtual_facts = virtual.get_virtual_facts()
    assert sorted(virtual_facts.keys()) == sorted([
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ])
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:07:55.616550
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()

    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:07:58.363217
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['xen', 'kvm', 'jail', 'vmware', 'parallels', 'virtualbox', '']

# Generated at 2022-06-23 02:08:10.104116
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Sample output from sysctl
    xen_sysctl = "kern.vm_guest: xen"

    # Sample output from hw.model
    bhyve_hw = "hw.model: Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz"

    # Sample output from security.jail.jailed
    jailed_sec = "security.jail.jailed: 1"

    # Sample output from hw.hv_vendor
    bhyve_hv = "hw.hv_vendor: bhyve bhyve"

    for sysctl in [xen_sysctl, bhyve_hw, jailed_sec, bhyve_hv]:
        facts = VirtualCollector(sysctl, 'FreeBSD')
        assert isinstance(facts, FreeBSDVirtualCollector)
       

# Generated at 2022-06-23 02:08:12.623084
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Constructor test
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:20.139364
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    facts_dict = virtual_facts.get_virtual_facts()
    assert facts_dict
    assert sorted(facts_dict) == ['virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_type']
    assert facts_dict['virtualization_type'] or \
           facts_dict['virtualization_role'] == ''

# Generated at 2022-06-23 02:08:25.318016
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, VirtualCollector)
    assert isinstance(fvc.platforms, dict)
    assert fvc.platforms['FreeBSD'][0] == 'FreeBSDVirtual'


# Generated at 2022-06-23 02:08:26.560593
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    foo = FreeBSDVirtual({}, {})
    assert foo.platform == 'FreeBSD'
    assert foo.virtualization_type == ''
    assert foo.virtualization_role == ''

# Generated at 2022-06-23 02:08:35.011712
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # prepare the test
    sysctl_kern_vm_guest = {
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'unknown',
        'security.jail.jailed': 0
    }
    sysctl_hw_hv_vendor = {
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'unknown',
        'security.jail.jailed': 0
    }
    sysctl_security_jail_jailed = {
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'unknown',
        'security.jail.jailed': 0
    }

    virtual = FreeBSDVirtual()
    virtual._shell = True
    virtual

# Generated at 2022-06-23 02:08:37.339851
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual(dict(), 'testhost')
    assert freebsd_virtual.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-23 02:08:44.475065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def side_effect_function(function_name):
        if function_name == 'kern.vm_guest':
            return {'virtualization_tech_guest': set([u'xen']), 'virtualization_tech_host': set(), 'virtualization_type': u'xen', 'virtualization_role': u'guest'}
        elif function_name == 'hw.hv_vendor':
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': u'bhyve', 'virtualization_role': u'host'}

# Generated at 2022-06-23 02:08:50.893930
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    This function is used to test FreeBSDVirtual constructor.
    """

    facts_dict = {'virtualization_type': '',
                  'virtualization_role': '',
                  'virtualization_tech_guest': set([]),
                  'virtualization_tech_host': set([])}
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.get_virtual_facts() == facts_dict

# Generated at 2022-06-23 02:08:59.580825
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os_release_content = """
NAME=FreeBSD
"""
    kern_vm_guest_content = """
value: "none"
"""
    hw_hv_vendor_content = """
value: "none"
"""
    sec_jail_jailed_content = """
value: 0
"""
    hw_model_content = """
value: ""
"""
    expected_output = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    def setup_module_mock(self):
        mock_module = type('os')()
        mock_module.run_command = self.run_command_mock()
        sysctl = VirtualSysctlDet

# Generated at 2022-06-23 02:09:07.803499
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    args = dict(
        custom_sysctl_path='/usr/src/tools/test/test_sysctl',
        custom_dmesg_path='/usr/src/tools/test/test_dmesg',
        custom_uname_path='/usr/src/tools/test/test_uname',
    )
    test_get_virtual_facts_output = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
    }

    test_get_virtual_facts = FreeBSDVirtual(**args)
    assert test_get_virtual_facts is not None

    for test_get_virtual_facts_param, test_get_virtual_facts_value in test_get_virtual_facts_output.items():
        assert test_get_virtual_facts.get_virtual_facts

# Generated at 2022-06-23 02:09:09.271496
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:10.376541
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fc = FreeBSDVirtualCollector()
    fc._populate_virtual_subclass()
    assert fc.virtual

# Generated at 2022-06-23 02:09:12.267268
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:13.399301
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:14.377966
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert(virtual_facts.platform == 'FreeBSD')
    assert(virtual_facts.fact_class.platform == 'FreeBSD')

# Generated at 2022-06-23 02:09:15.292371
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:16.611453
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None, None)
    assert isinstance(virtual, FreeBSDVirtual)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:20.242629
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module_name = 'ansible.module_utils.facts.virtual.freebsd'
    module = __import__(module_name, fromlist=['FreeBSDVirtual'])
    if hasattr(module, 'FreeBSDVirtual'):
        assert hasattr(module.FreeBSDVirtual, 'get_virtual_facts')

# Generated at 2022-06-23 02:09:21.659457
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual(None)
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:29.540402
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl = {
        'hw.hv_vendor': 'invalid',
        'hw.model': 'amd64',
        'kern.vm_guest': 'unknown',
    }
    bsd_virtual_obj = FreeBSDVirtual(sysctl)
    assert bsd_virtual_obj.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }


# Generated at 2022-06-23 02:09:32.332901
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert isinstance(v, Virtual)
    assert isinstance(v, VirtualSysctlDetectionMixin)
    assert isinstance(v, FreeBSDVirtual)


# Generated at 2022-06-23 02:09:38.498555
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test the constructor of FreeBSDVirtual
    virtual_obj = FreeBSDVirtual(None)
    assert virtual_obj.platform == 'FreeBSD'
    assert virtual_obj.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(),
                                               'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-23 02:09:40.029392
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-23 02:09:42.386640
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:09:44.173803
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == FreeBSDVirtual().platform

# Generated at 2022-06-23 02:09:47.486852
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts_json = {}
    facts = FreeBSDVirtualCollector(facts_json, None)
    facts.populate()

    assert {'virtualization_type': '', 'virtualization_role': ''} == facts_json['virtualization']

# Generated at 2022-06-23 02:09:50.161902
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:59.278053
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # First, set up a FreeBSDVirtual object.
    virtual_facts = FreeBSDVirtual()

    # Note: we're not testing the following lines at the moment.
    #virtual_facts.sysctl.get_file_lines = MagicMock()
    #virtual_facts.sysctl.get_file_lines.return_value = monolithic_bsd

    # Now call virtual_facts.get_virtual_facts()
    virtual_facts.get_virtual_facts()

    # Now make sure that the results are sensible.
    assert virtual_facts.facts['virtualization_role'] == ''
    assert virtual_facts.facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:10:00.151091
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None, None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:03.850582
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    fbv = FreeBSDVirtual()
    assert isinstance(fbv, FreeBSDVirtual)
    virtual_facts = fbv.get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-23 02:10:05.196592
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:14.887316
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsdVirtual = FreeBSDVirtual()
    freebsdVirtual.populate()

    # If a fact attribute is defined, assert the appropriate attribute is
    # returned by the fact class.
    if hasattr(freebsdVirtual, 'virtualization_type'):
        assert (freebsdVirtual.virtualization_type
                == freebsdVirtual.facts['virtualization_type'])
    if hasattr(freebsdVirtual, 'virtualization_role'):
        assert (freebsdVirtual.virtualization_role
                == freebsdVirtual.facts['virtualization_role'])
    if hasattr(freebsdVirtual, 'virtualization_tech_guest'):
        assert (freebsdVirtual.virtualization_tech_guest ==
                freebsdVirtual.facts['virtualization_tech_guest'])

# Generated at 2022-06-23 02:10:16.052169
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'


# Generated at 2022-06-23 02:10:20.987408
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Case 1: VMware
    expected_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([])
    }
    raw_facts = {'sysctl': {'hw.model': '''Intel(R) Core(TM) i7-4960HQ CPU @ 2.60GHz'''}}
    f = FreeBSDVirtual(raw_facts)
    facts = f.get_virtual_facts()
    assert facts == expected_facts
    # Case 2: VirtualBox

# Generated at 2022-06-23 02:10:24.256718
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:26.916182
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:38.669412
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockFreeBSDVirtual(FreeBSDVirtual):

        def detect_virt_product(self):
            return {'virtualization_tech_host': set(),
                    'virtualization_tech_guest': set(),
                    }

        def detect_virt_type(self):
            return {'virtualization_tech_host': set(),
                    'virtualization_tech_guest': set(),
                    }

    class MockFreeBSDVirtual2(FreeBSDVirtual):

        def detect_virt_product(self):
            return {'virtualization_tech_host': set(),
                    'virtualization_tech_guest': set(['kvm']),
                    }
        def detect_virt_type(self):
            return {'virtualization_tech_host': set(),
                    'virtualization_tech_guest': set(),
                    }
