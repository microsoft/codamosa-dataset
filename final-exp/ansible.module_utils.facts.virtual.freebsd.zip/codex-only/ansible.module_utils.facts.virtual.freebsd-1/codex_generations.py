

# Generated at 2022-06-23 02:00:42.569961
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._fact_class == FreeBSDVirtual
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:44.414506
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    results = FreeBSDVirtualCollector()
    assert isinstance(results, FreeBSDVirtualCollector)


# Generated at 2022-06-23 02:00:45.325255
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc

# Generated at 2022-06-23 02:00:46.755533
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:52.242833
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    for attribute in ('virtualization_type', 'virtualization_role', \
                      'virtualization_system', 'virtualization_role_pretty'):
        assert hasattr(f, attribute)

# Generated at 2022-06-23 02:00:54.272599
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbvirtual = FreeBSDVirtual({})
    assert fbvirtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:00:55.979002
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == 'FreeBSD'


# Generated at 2022-06-23 02:00:58.062720
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:01.521141
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    result = v.get_virtual_facts()
    assert(result['virtualization_type'] == 'xen')

# Generated at 2022-06-23 02:01:03.470668
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual(None)
    assert isinstance(fv, FreeBSDVirtual) is True


# Generated at 2022-06-23 02:01:05.498061
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:01:17.544123
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:21.047997
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert isinstance(virtual, Virtual)
    assert isinstance(virtual, VirtualSysctlDetectionMixin)
    assert isinstance(virtual, FreeBSDVirtual)
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:22.131202
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})

# Generated at 2022-06-23 02:01:23.502120
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc is not None

# Generated at 2022-06-23 02:01:24.757341
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-23 02:01:31.370243
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:01:40.318885
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test: FreeBSD VMware
    virt_facts = {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'VMware'},
        'virtualization_tech_host': set()
    }
    test_facts = {
        'kernel': 'FreeBSD',
        'model': 'VMware Virtual Platform'
    }
    module = MockModule(test_facts)
    virt_facts_class = FreeBSDVirtual(module)
    assert virt_facts == virt_facts_class.get_virtual_facts()

    # Test: FreeBSD VirtualBox

# Generated at 2022-06-23 02:01:41.407132
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:46.211985
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = dict()
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()
    facts_dict['virtual'] = virtual_facts
    assert FreeBSDVirtualCollector(facts_dict).get_facts() == facts_dict

# Generated at 2022-06-23 02:01:47.093981
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert VirtualCollector.show_multiple() is True

# Generated at 2022-06-23 02:01:58.642380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, product):
            return {'virtualization_tech_guest': set()}

        def detect_virt_vendor(self, vendor):
            return {
                'virtualization_type': 'vendor_virtualization_type',
                'virtualization_role': 'vendor_virtualization_role',
                'virtualization_tech_guest': set()
            }

    freebsd_virtual = MockFreeBSDVirtual()
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vendor_virtualization_type'
    assert virtual_facts['virtualization_role'] == 'vendor_virtualization_role'

# Generated at 2022-06-23 02:02:06.043736
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    l = [
        'module_utils.facts.virtual.sysctl.VirtualSysctlDetectionMixin',
        'module_utils.facts.virtual.base.Virtual',
        'module_utils.facts.virtual.base.VirtualCollector'
    ]
    l.sort()
    assert FreeBSDVirtualCollector._bases == tuple(l)
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:13.034478
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    # Only instantiate class FreeBSDVirtual if running on FreeBSD
    if os.uname()[0] == 'FreeBSD':

        # Create the instance
        collect = FreeBSDVirtualCollector()

        # Check the platform
        assert collect.platform == 'FreeBSD'

        # Check the fact class
        assert collect.fact_class == FreeBSDVirtual

        # Check platform_subclass
        assert collect.subclass == collect._platform

        # Check the default collector
        assert collect.default_collector == collect


# Generated at 2022-06-23 02:02:14.773183
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:17.224288
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()

    assert fbc is not None

# Generated at 2022-06-23 02:02:21.148110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    (expected_platform, expected_fact_class) = ('FreeBSD', 'FreeBSDVirtual')
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == expected_platform
    assert virtual_collector._fact_class == expected_fact_class

# Generated at 2022-06-23 02:02:27.690146
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit tests of FreeBSDVirtual.get_virtual_facts'''
    facts = {}
    expected_facts = {'virtualization_type': '',
                      'virtualization_role': '',
                      'virtualization_tech_guest': set(),
                      'virtualization_tech_host': set()}
    virtual = FreeBSDVirtual(facts)
    assert virtual.get_virtual_facts() == expected_facts
    assert facts == expected_facts



# Generated at 2022-06-23 02:02:38.121368
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # This is a FreeBSD-specific subclass of Virtual.  It defines
    # - virtualization_type
    # - virtualization_role
    # - virtualization_tech_guest
    # - virtualization_tech_host
    facts_dict = {}
    virtual = FreeBSDVirtual(facts_dict)
    assert virtual.virtualization_type == '', facts_dict

    facts_dict = {'virtualization_type': 'xen'}
    virtual = FreeBSDVirtual(facts_dict)
    assert virtual.virtualization_type == 'xen', facts_dict

    facts_dict = {'virtualization_role': 'guest'}
    virtual = FreeBSDVirtual(facts_dict)
    assert virtual.virtualization_role == 'guest', facts_dict


# Generated at 2022-06-23 02:02:40.122573
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test FreeBSDVirtualCollector constructor.
    :return:
    '''
    facts = FreeBSDVirtualCollector()
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:46.037038
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''

    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert isinstance(freebsd_virtual_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:49.175964
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.module = object()
    v.module.get_bin_path = lambda _: '/bin/sysctl'
    v.get_virtual_facts()

# Generated at 2022-06-23 02:02:49.750046
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:02:57.847845
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts, FreeBSDVirtualCollector)
    assert isinstance(facts, VirtualCollector)
    assert facts.platform == 'FreeBSD'
    assert facts.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:03.196632
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl_test_results = [
        (['security.jail.jailed'], '0'),
        (['hw.hv_vendor'], 'VMWare'),
        (['hw.model'], 'VirtualBox'),
    ]
    sysctl_test_fixture = {
        'security.jail.jailed': 0,
        'hw.hv_vendor': 'VMWare',
        'hw.model': 'VirtualBox',
    }
    # Error in sysctl Fixtures
    sysctl_error_fixture = {
        'security.jail.jailed': 0,
        'hw.hv_vendor': 'VMWare',
    }

    virtual = FreeBSDVirtual(sysctl_fixture=sysctl_test_fixture)


# Generated at 2022-06-23 02:03:14.763069
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # We need to mock the functions that use sysctl
    import sys
    import __builtin__

    module_name = 'ansible.module_utils.facts.virtual.sysctl'

    class MockedModule:

        def __init__(self, return_value):
            self.return_value = return_value


# Generated at 2022-06-23 02:03:25.017999
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual."""
    # Initialize FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Get virtualization facts
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert that freebsd_virtual_facts is well-formed
    assert isinstance(freebsd_virtual_facts, dict)
    assert 'virtualization_type' in freebsd_virtual_facts
    assert 'virtualization_role' in freebsd_virtual_facts
    assert 'virtualization_tech_guest' in freebsd_virtual_facts
    assert 'virtualization_tech_host' in freebsd_virtual_facts


# Generated at 2022-06-23 02:03:30.076705
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.platform == 'FreeBSD'



# Generated at 2022-06-23 02:03:43.708956
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test the get_virtual_facts() method, on FreeBSD
    # Expected virtual_facts:
    #  - virtualization_type: xen
    #  - virtualization_role: guest
    #  - virtualization_tech_guest: xen
    #  - virtualization_tech_host: xen

    fake_command = 'fake_command'

    # Prepare a fake getcmdoutput but only for freebsd
    def fake_getcmdoutput(self, command, checkrc=True):
        if command == fake_command:
            rc = 0
            stdout = 'FreeBSD fake host'
            stderr = ''
        else:
            raise Exception('this command should not be run')

        return (rc, stdout, stderr)

    # Prepare a fake get_sysctl_product_info but only for freebsd and


# Generated at 2022-06-23 02:03:58.340120
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    # hack for python 2.6 support
    try:
        assertCountEqual = 'assertCountEqual'
    except AttributeError:
        assertCountEqual = 'assertItemsEqual'

    # test 1: bare metal
    fact_module = FreeBSDVirtual()
    virtual_facts = fact_module.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert getattr(virtual_facts['virtualization_tech_guest'], assertCountEqual)(('None',))
    assert getattr(virtual_facts['virtualization_tech_host'], assertCountEqual)(('None',))

    # test 2: pfSense jail
    fact_module = FreeBSD

# Generated at 2022-06-23 02:04:09.333397
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup Facts object
    facts_obj = FreeBSDVirtual()
    virtual_facts = facts_obj.get_virtual_facts()

    # verify returned type
    assert type(virtual_facts) is dict

    # verify returned keys are what we expect
    assert sorted(virtual_facts.keys()) == sorted(['virtualization_role',
                                                   'virtualization_type',
                                                   'virtualization_tech_guest',
                                                   'virtualization_tech_host'])

    # Verify that the values are either of valid values we expect
    assert virtual_facts['virtualization_type'] in ['docker', 'jail', 'kvm',
                                                    'openvz', 'parallels', 'qemu',
                                                    'virtualbox', 'vmware', 'xen',
                                                    '']

# Generated at 2022-06-23 02:04:19.745354
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Check FreeBSDVirtual.get_virtual_facts() method"""
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts
    assert set(virtual_facts.keys()) == set([
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_host',
        'virtualization_tech_guest'
    ])
    assert set(virtual_facts['virtualization_tech_host']) == set(['freebsd'])
    assert virtual_facts['virtualization_role'] in (
        'guest',
        'host',
        'guest,host'
    )

# Generated at 2022-06-23 02:04:22.283503
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert isinstance(FreeBSDVirtual(), Virtual)
    assert isinstance(FreeBSDVirtual(), VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:04:24.624992
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v_facts = v.get_virtual_facts()
    assert isinstance(v_facts, dict)

# Generated at 2022-06-23 02:04:35.078260
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}, {}).get_virtual_facts()
    assert facts['virtualization_type'] in (
        '', 'jail', 'xen', 'vmware', 'hyperv', 'kvm', 'virtualbox', 'qemu', 'linux_vserver', 'vserver',
        'openvz', 'parallels', 'proxmox', 'lxc', 'lxd', 'systemd-nspawn', 'vbox', 'virtualpc', 'bhyve',
        'vz', 'docker'
    )
    assert facts['virtualization_role'] in ('guest', 'host')
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:04:36.891300
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.platform == 'FreeBSD'



# Generated at 2022-06-23 02:04:42.165541
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:04:43.632945
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbi = FreeBSDVirtualCollector()
    assert fbi.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:44.160777
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual({})

# Generated at 2022-06-23 02:04:55.981261
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': ''
    }

    class FreeBSDVirtualTest(FreeBSDVirtual):
        def detect_virt_product(self, sysctl_name):
            virtual_facts_sysctl = {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()
            }
            if sysctl_name == 'kern.vm_guest':
                virtual_facts_sysctl['virtualization_tech_guest'].add('jail')
                virtual_facts_sysctl['virtualization_tech_guest'].add('zones')
                return virtual_facts_sysctl

# Generated at 2022-06-23 02:04:57.537690
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    k = FreeBSDVirtualCollector()
    assert k._platform == 'FreeBSD'
    assert k._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:09.405857
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Create a FreeBSDVirtual object
    freebsd_obj = FreeBSDVirtual(module=None)

    # Load the Collected Facts
    collected_facts = Facts({'ansible_facts': {}, 'ansible_system': '', 'ansible_system_vendor': ''})
    collector = Collector(module=None, collected_facts=collected_facts)
    collector.collect(['virtual'])
    print(collected_facts.get('ansible_facts'))

    # Compare the Collected Facts with the FreeBSDVirtualFacts

# Generated at 2022-06-23 02:05:11.848675
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vp = FreeBSDVirtualCollector()
    assert vp.platform == FreeBSDVirtualCollector._platform
    assert vp.fact_class == FreeBSDVirtualCollector._fact_class

# Generated at 2022-06-23 02:05:17.937380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_facts_obj = FreeBSDVirtual()
    freebsd_facts = freebsd_facts_obj.get_virtual_facts()
    assert 'virtualization_type' in freebsd_facts
    assert 'virtualization_role' in freebsd_facts
    assert 'virtualization_tech_guest' in freebsd_facts
    assert 'virtualization_tech_host' in freebsd_facts

# Generated at 2022-06-23 02:05:26.294225
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    base_facts = dict(
        virtual=True,
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest=set(['xen']),
        virtualization_tech_host=set()
    )

    virtual_fact = FreeBSDVirtual(base_facts)
    virtual_fact.populate()

    assert virtual_fact['virtualization_role'] == 'guest'
    assert virtual_fact['virtualization_type'] == 'xen'



# Generated at 2022-06-23 02:05:35.984544
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    facts = fbsd_virtual.collect()
    assert facts["virtualization_type"] == "", "virtualization_type is empty on FreeBSD"
    assert "virtualization_tech_guest" in facts, "virtualization_tech_guest is in facts"
    assert "virtualization_tech_host" in facts, "virtualization_tech_host is in facts"
    assert type(facts["virtualization_tech_guest"]) is set, "virtualization_tech_guest is a set"
    assert type(facts["virtualization_tech_host"]) is set, "virtualization_tech_host is a set"

# Generated at 2022-06-23 02:05:37.169544
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:40.987750
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()


# Generated at 2022-06-23 02:05:51.962218
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:05:55.868190
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:03.940827
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual({})
    assert hasattr(obj, 'platform')
    assert hasattr(obj, 'get_virtual_facts')
    assert hasattr(obj, '_virtualization_type')
    assert hasattr(obj, '_virtualization_role')
    assert hasattr(obj, '_virtualization_type_facts')
    assert hasattr(obj, '_virtualization_role_facts')
    assert hasattr(obj, '_virtualization_vendor_facts')
    assert hasattr(obj, '_detect_virt_product')
    assert hasattr(obj, '_detect_virt_vendor')

# Generated at 2022-06-23 02:06:16.360329
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """FreeBSDVirtual - get_virtual_facts method unit test"""
    # Arrange
    # We don't need to patch anything for this test, that's why
    # it is written in a separate module: we always want to test
    # the "real" method with the "real" data

    # Act
    facts = FreeBSDVirtual().get_virtual_facts()

    # Assert
    assert type(facts) is dict
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert type(facts['virtualization_tech_guest']) is frozenset
    assert type(facts['virtualization_tech_host']) is frozenset


# Generated at 2022-06-23 02:06:27.864759
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    # Test against FreeBSD, with /dev/xen/xenstore and kern.vm_guest
    with open('/proc/cpuinfo', 'rb') as f:
        cpuinfo = f.read()
    set_module_args({'gather_subset': '!all', 'gather_timeout': 10})
    with open('/proc/cpuinfo', 'wb') as f:
        f.write(cpuinfo)
    with open('/dev/xen/xenstore', 'wb') as f:
        f.write(b'')
    with open('/proc/version', 'wb') as f:
        f.write(b'FreeBSD')
    with open('/proc/meminfo', 'wb') as f:
        f.write(b'')

# Generated at 2022-06-23 02:06:30.021850
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert isinstance(x, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:06:34.854223
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj_test = FreeBSDVirtualCollector()
    assert isinstance(obj_test._fact_class, FreeBSDVirtual)
    assert obj_test._platform == 'FreeBSD'



# Generated at 2022-06-23 02:06:35.982449
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert(FreeBSDVirtualCollector._platform == 'FreeBSD')
    assert(FreeBSDVirtualCollector._fact_class == FreeBSDVirtual)

# Generated at 2022-06-23 02:06:37.255334
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:38.854516
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({}, {})
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:40.199489
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()
    assert fb_virtual.platform == 'FreeBSD'



# Generated at 2022-06-23 02:06:51.235817
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # pylint: disable=unused-argument
    def do_not_call():
        raise RuntimeError("AnsibleModule() should not try to execute this")

    # Constructor of VirtualCollector calls AnsibleModule()
    # AnsibleModule() calls exit_json() or fail_json()
    # Mocking AnsibleModule() with do_not_call function
    # AnsibleModule() would execute do_not_call in constructor
    # if AnsibleModule() is called
    setattr(VirtualCollector, 'AnsibleModule', do_not_call)
    # If constructor of VirtualCollector did not call AnsibleModule(),
    # an exception would be raised by do_not_call
    collector = FreeBSDVirtualCollector()



# Generated at 2022-06-23 02:06:55.252576
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert isinstance(virtual.get_virtual_facts(), dict)

# This is not a test, but it allows us to check the module's docstring.
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 02:06:56.326395
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 02:07:00.088191
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v_facts = v.get_virtual_facts()

    # test specific virtualization facts from FreeBSD
    assert v_facts['virtualization_type'] == ''
    assert v_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:07:05.030717
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # FreeBSDVirtual is instantiated by FreeBSDVirtualCollector
    assert hasattr(FreeBSDVirtualCollector, '_platform')
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert hasattr(FreeBSDVirtualCollector, '_fact_class')
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:07.198350
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert type(fbc._fact_class) is FreeBSDVirtual
    assert fbc._platform is 'FreeBSD'

# Generated at 2022-06-23 02:07:09.968422
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbvc = FreeBSDVirtualCollector()
    assert fbvc.fact_class == FreeBSDVirtual
    assert fbvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:21.434178
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from collections import namedtuple
    TestData = namedtuple(
        'TestData', 'description, kern_vm_guest, hw_hv_vendor, sec_jail_jailed, hw_model, expected'
    )

# Generated at 2022-06-23 02:07:24.084564
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor test of class FreeBSDVirtualCollector
    """
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:27.141553
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.populate()['ansible_facts']['virtual_facts']
    assert virtual_facts.populate()['ansible_facts']['virtual_facts']['virtualization_type'] == ''
    assert virtual_facts.populate()['ansible_facts']['virtual_facts']['virtualization_role'] == ''

# Generated at 2022-06-23 02:07:28.497352
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Just create the object, destructor cleans up
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:07:30.595160
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:32.475966
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == FreeBSDVirtual.platform
    assert virtual.string_facts_type == 'sysctl'

# Generated at 2022-06-23 02:07:39.589016
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    # vm ware facts
    assert 'vmware' not in virtual_facts
    # virtualbox facts
    assert 'virtualbox' not in virtual_facts
    # openstack facts
    assert 'openstack' not in virtual_facts
    # lxc facts
    assert 'lxc' not in virtual_facts
    # systemd facts
    assert 'systemd' not in virtual_facts
    # ansible facts
    assert 'ansible' not in virtual_facts

# Generated at 2022-06-23 02:07:41.917681
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'
    assert fv._platform_fact_class == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:07:45.212174
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Make sure FreeBSDVirtual is the class available on FreeBSD
    freebsd_virt = Virtual.get_platform_subclass('FreeBSD')
    assert freebsd_virt == FreeBSDVirtual

# Generated at 2022-06-23 02:07:51.259470
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    my_virt = FreeBSDVirtual('freebsd', '10.2-RELEASE-p8', 'i386')
    assert my_virt.platform == 'FreeBSD'
    assert my_virt.version == '10.2-RELEASE-p8'
    assert my_virt.architecture == 'i386'
    assert my_virt.virtualization_type == ''
    assert my_virt.virtualization_role == ''

# Generated at 2022-06-23 02:07:54.629028
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """FreeBSDVirtual: constructor"""
    vf = FreeBSDVirtual()
    assert vf.virtualization_type == ''
    assert vf.virtualization_role == ''

# Generated at 2022-06-23 02:07:58.276124
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Test normal construction of class FreeBSDVirtual'''
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == 'FreeBSD'
    assert freebsd.virtualization_type == ''
    assert freebsd.virtualization_role == ''

# Generated at 2022-06-23 02:08:07.504883
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert len(virtual_facts['virtualization_type']) > 0
    assert len(virtual_facts['virtualization_role']) > 0
    assert len(virtual_facts['virtualization_tech_guest']) > 0
    assert len(virtual_facts['virtualization_tech_host']) > 0

# Generated at 2022-06-23 02:08:09.149833
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-23 02:08:21.717809
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbv = FreeBSDVirtual()

    # Set up the facts
    kern_vm_guest = {'kern.vm_guest': 'other'}
    hw_hv_vendor = {'hw.hv_vendor': 'bhyve'}
    sec_jail_jailed = {'security.jail.jailed': '1'}
    hw_model = {'hw.model': 'QEMU Virtual CPU version 1.1.2'}

    facts = {'sysctl': dict(kern_vm_guest.items() + hw_hv_vendor.items() +
                            sec_jail_jailed.items() + hw_model.items())}

    # Call the method get_virtual_facts of FreeBSDVirtual
    # with the facts

# Generated at 2022-06-23 02:08:22.682537
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:33.978013
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def mock_sysctl_lines(input):
        return input.split("\n")

    mock_facts = {'kernel': 'FreeBSD'}
    facts = FreeBSDVirtual(mock_facts).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    mock_facts = {'kernel': 'FreeBSD', 'virtualization_type': 'xen'}
    facts = FreeBSDVirtual(mock_facts).get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()
   

# Generated at 2022-06-23 02:08:35.658214
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:36.360409
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()


# Generated at 2022-06-23 02:08:38.999951
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    facts = fv.get_virtual_facts()
    assert facts.get('virtualization_type') == ''
    assert facts.get('virtualization_role') == ''


# Generated at 2022-06-23 02:08:52.205411
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    # Define fake value for the sysctl
    virtual_facts.get_file_content = lambda x: ''
    virtual_facts.get_file_lines = lambda x: []
    virtual_facts.read_file = lambda x: ''
    virtual_facts.read_file_from_command = lambda x: ''
    # Define fake values for the dmesg
    virtual_facts.get_dmesg = lambda x: []
    # Define fake values for machine_id_file and product_name_file
    virtual_facts.get_file_content = lambda x: ''
    virtual_facts.get_file_lines = lambda x: []
    virtual_facts.read_file = lambda x: ''
    virtual_facts.read_file_from_command = lambda x: ''
    # Define

# Generated at 2022-06-23 02:08:53.744560
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({})
    assert virtual.platform == 'FreeBSD'
    assert virtual.sysctl_all() == []

# Generated at 2022-06-23 02:08:55.983540
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None, None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''

# Generated at 2022-06-23 02:09:00.355316
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    assert isinstance(facts, dict)
    assert not isinstance(facts, list)


# Generated at 2022-06-23 02:09:04.698039
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    test_facts = freebsd_virtual.get_virtual_facts()
    assert type(test_facts) is dict
    assert type(test_facts['virtualization_tech_guest']) is set
    assert type(test_facts['virtualization_tech_host']) is set


# Generated at 2022-06-23 02:09:05.908212
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv == FreeBSDVirtual()


# Generated at 2022-06-23 02:09:07.115900
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()

    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:09.885130
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_type == ''

# Generated at 2022-06-23 02:09:13.677163
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # If a FreeBSD system is not virtualized, then virtualization_type should be empty
    virtual = FreeBSDVirtualCollector().collect()['ansible_facts']['ansible_virtualization_type']
    assert virtual == ''

# Generated at 2022-06-23 02:09:15.453056
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:21.297794
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Unit test: When the file "/dev/xen/xenstore" exists,
    # and other conditions are met, virtualization_type should be set to 'xen'
    # and virtualization_role to 'guest'
    mocked_facts = {'kernel': 'FreeBSD'}
    fbsd_virtual = FreeBSDVirtual(mocked_facts, False)
    setattr(fbsd_virtual, 'os_path_exists', lambda path: True)
    setattr(fbsd_virtual, 'detect_virt_product', lambda path: {'virtualization_tech_guest': ['xen'], 'virtualization_tech_host': []})

# Generated at 2022-06-23 02:09:25.751229
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host_facts = {}
    host_facts['system'] = 'FreeBSD'
    host_facts['distribution'] = 'FreeBSD'
    host_facts['virtualization_role'] = 'guest'
    host_facts['virtual'] = 'xen'
    hf = FreeBSDVirtual(host_facts)
    assert hf.platform == "FreeBSD"

# Generated at 2022-06-23 02:09:29.872945
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual
    '''
    virtual = FreeBSDVirtual()

    result = virtual.get_virtual_facts()

    print (result)


# Generated at 2022-06-23 02:09:38.642213
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sysctl_dict = {'kern.vm_guest': 'none',
                   'hw.hv_vendor': 'untu',
                   'hw.model': 'KVM',
                   'security.jail.jailed': '0'}

    virtual = FreeBSDVirtual(sysctl_dict=sysctl_dict)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'KVM'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'kvm' in virtual_facts['virtualization_tech_host']



# Generated at 2022-06-23 02:09:40.425960
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:41.691011
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import doctest
    doctest.testmod(FreeBSDVirtual)

# Generated at 2022-06-23 02:09:52.906804
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    obj = FreeBSDVirtual()
    obj.sysctl_hardware_product_name = {'hw.model': 'i386'}
    obj.sysctl_virtualization_product_name = {'security.jail.jailed': 0,
                                              'hw.hv_vendor': 'amd',
                                              'kern.vm_guest': 'other'}
    obj.sysctl_virtualization_role_name = {'hw.hv_vendor': 'xen',
                                           'security.jail.jailed': 'none',
                                           'kern.vm_guest': 'unknown'}
    virtual_info = obj.get_virtual_facts()
    assert virtual_info['virtualization_type'] == 'xen'
    assert virtual_info['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:09:58.769397
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.__class__.__name__ == 'FreeBSDVirtual'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:10:00.668934
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # type: () -> None
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:10:04.368133
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    fv.populate()

    assert fv.populate is not None
    assert fv.get_virtual_facts()['virtualization_type'] == ''
    assert fv.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:10:14.274983
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:10:15.817781
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:10:18.355188
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector(None, None)
    assert isinstance(f, VirtualCollector)
    assert isinstance(f, FreeBSDVirtualCollector)
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:24.199478
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''
    assert freebsd_virtual.virtualization_tech_guest == set()
    assert freebsd_virtual.virtualization_tech_host == set()


# Generated at 2022-06-23 02:10:35.136860
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for methods get_virtual_tech, get_virtual_tech_host,
    get_virtual_tech_guest and get_virtual_facts of class FreeBSDVirtual.
    """
    from collections import namedtuple

    VirtualizationSets = namedtuple('VirtualizationSets', ['host', 'guest'])

    class FreeBSDVirtualTest(FreeBSDVirtual):
        """Mock class for FreeBSDVirtual"""
        virtualization_tech_host = None
        virtualization_tech_guest = None

        def detect_virt_vendor(self, _):
            return {}

        def detect_virt_product(self, _):
            VirtualizationSets(host=self.virtualization_tech_host,
                               guest=self.virtualization_tech_guest)

    # Test case 1
    # ------------
    # FreeBSD VM running

# Generated at 2022-06-23 02:10:37.259964
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector, '_fact_class')

# Generated at 2022-06-23 02:10:41.745183
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    import pytest
    from ansible.module_utils.facts.virtual.common import Virtual, VirtualCollector
    v = FreeBSDVirtual()
    assert isinstance(v, FreeBSDVirtual)
    assert isinstance(v, Virtual)
    assert isinstance(v, VirtualCollector)
