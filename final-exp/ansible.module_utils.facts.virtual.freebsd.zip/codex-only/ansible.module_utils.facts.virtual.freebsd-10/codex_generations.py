

# Generated at 2022-06-23 02:00:40.942391
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    dut = FreeBSDVirtualCollector()
    assert dut.platform == FreeBSDVirtualCollector._platform

# Generated at 2022-06-23 02:00:48.200718
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up
    class_ = FreeBSDVirtual
    jail_fcts = {'hw.model' : {'product' : 'Jail'}}
    bhyve_fcts = {'hw.model' : {'product' : 'bhyve'}, 'security.jail.jailed' : False}
    hypervisor_fcts = {'hw.model' : {'product' : 'Hypervisor'}}

# Generated at 2022-06-23 02:00:51.392595
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtual)

# Generated at 2022-06-23 02:00:52.028524
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:00:54.462985
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:06.346511
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    import pytest

    my_obj = FreeBSDVirtual(None, None)
    my_obj.sysctl = {'security.jail.jailed': '1',
                     'kern.vm_guest': 'vmware',
                     'hw.hv_vendor': 'bhyve',
                     'hw.model': 'Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz'}
    my_obj.virt_what = 'kvm\nhvm'
    result = my_obj.get_virtual_facts()
    assert(result['virtualization_type'] == 'kvm')
    assert(result['virtualization_role'] == 'guest')
    # We

# Generated at 2022-06-23 02:01:07.515952
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual({}, None, None)
    assert fb_virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:09.032467
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:13.984367
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual('FreeBSD').get_virtual_facts()
    assert virtual_facts == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}

# Generated at 2022-06-23 02:01:22.845211
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    x = FreeBSDVirtual('fake')
    assert x.platform == 'FreeBSD'
    assert not hasattr(x, '_host_facts')
    assert not hasattr(x, '_guest_facts')
    assert not hasattr(x, '_parsed_facts')


# Unit tests for constructor of class FreeBSDVirtualCollector

# Generated at 2022-06-23 02:01:29.407607
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {'jail', 'vmware', 'xen'},
        'virtualization_tech_host': {'jail', 'vmware', 'xen'},
        'virtualization_type_role': '',
        'virtualization_system': ''
    }

    virtual = FreeBSDVirtual(module=None)
    virtual._detect_virt_product = lambda kern: {
        'virtualization_tech_guest': {'jail', 'vmware', 'xen'},
        'virtualization_tech_host': {'jail', 'vmware', 'xen'}
    }

# Generated at 2022-06-23 02:01:32.004531
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector().collect()
    assert virtual['virtualization_type'] == ''
    assert virtual['virtualization_role'] == ''

# Generated at 2022-06-23 02:01:33.015173
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual({})
    f.get_virtual_facts()


# Generated at 2022-06-23 02:01:34.029847
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()  # Constructor

# Generated at 2022-06-23 02:01:35.675262
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc is not None

# Generated at 2022-06-23 02:01:46.389376
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from . import _get_file_contents
    from . import _get_expected_result
    from . import _get_expected_result_sysctl

    # Prepare FreeBSDVirtual instance for tests
    file_path = os.path.join(os.path.dirname(__file__), 'fake')
    fbsd_virtual_inst = FreeBSDVirtual(file_path)

    # Prepare fake content for sysctl
    kern_vm_guest_content = _get_file_contents('sysctl_kern.vm_guest')
    hw_hv_vendor_content = _get_file_contents('sysctl_hw.hv_vendor')
    sec_jail_jailed_content = _get_file_contents('sysctl_security.jail.jailed')
    hw_model_content

# Generated at 2022-06-23 02:01:49.529319
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()
    out = dict(virtualization_type='', virtualization_role='', virtualization_tech_guest=[], virtualization_tech_host=[])
    assert out == f.get_virtual_facts()

# Generated at 2022-06-23 02:01:51.748137
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facter = FreeBSDVirtualCollector()
    assert facter._platform == 'FreeBSD'
    assert facter._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:02:00.752293
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Let the class setup the environment for the test.
    import sys
    orig_kern_vm_guest = sys.modules['ansible.module_utils.facts.virtual.sysctl'].ANSIBLE_KERN_VM_GUEST
    sys.modules['ansible.module_utils.facts.virtual.sysctl'].ANSIBLE_KERN_VM_GUEST = {0:'Guest'}

    fbsd_virtual = FreeBSDVirtual()
    facts = fbsd_virtual.get_virtual_facts()
    print(facts)

    # Restore the environment
    sys.modules['ansible.module_utils.facts.virtual.sysctl'].ANSIBLE_KERN_VM_GUEST = orig_kern_vm_guest

if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_

# Generated at 2022-06-23 02:02:03.242883
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector) is True


# Generated at 2022-06-23 02:02:06.034618
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual({'ansible_facts': {}})
    assert isinstance(obj, FreeBSDVirtual)


# Generated at 2022-06-23 02:02:07.932292
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert isinstance(fv, FreeBSDVirtual)


# Generated at 2022-06-23 02:02:16.897227
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:02:27.863729
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = {}

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = ''
    virtual_facts['virtualization_tech_host'] = ''

    # If a virtualization_type is set, no detection is done
    virtual_facts['virtualization_type'] = 'vmware'
    vm = FreeBSDVirtual(virtual_facts)
    vm.collect()
    collected_virtual_facts = vm.get_facts()
    expected_virtual_facts = virtual_facts
    assert collected_virtual_facts == expected_virtual_facts

    # If a virtualization_type is set, and detection is done,
    # virtualization_type is overwritten

# Generated at 2022-06-23 02:02:31.748491
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'


if __name__ == '__main__':
    # Unit test for FreeBSDVirtual class
    test_FreeBSDVirtual()

# Generated at 2022-06-23 02:02:35.983670
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:02:40.330071
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._fact_class == FreeBSDVirtual
    assert vc._platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:42.431784
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_class = FreeBSDVirtual()
    test_get_virtual_facts = test_class.get_virtual_facts()
    assert isinstance(test_get_virtual_facts, dict)

# Generated at 2022-06-23 02:02:47.055038
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_virtual_facts()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:57.655929
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class FakeFileForTestFreeBSDVirtual_get_virtual_facts:
        def __init__(self):
            self.content = ''
        def read(self):
            return self.content

    fakeFileForTestFreeBSDVirtual_get_virtual_facts = FakeFileForTestFreeBSDVirtual_get_virtual_facts()

    # Test get_virtual_facts() without virtualization
    fakeFileForTestFreeBSDVirtual_get_virtual_facts.content = ''
    virtual_facts = FreeBSDVirtual(fakeFileForTestFreeBSDVirtual_get_virtual_facts).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0

# Generated at 2022-06-23 02:02:58.976689
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:03.263361
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:10.816436
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()

    # check if virtualization_type is 'xen'
    virtualization_type = fb_virtual.get_virtual_facts()['virtualization_type']
    assert virtualization_type == 'xen'

    # check if virtualization_role is 'guest'
    virtualization_role = fb_virtual.get_virtual_facts()['virtualization_role']
    assert virtualization_role == 'guest'



# Generated at 2022-06-23 02:03:22.221811
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an instance of FreeBSDVirtual
    test_instance = FreeBSDVirtual()

    # Define attributes of FreeBSDVirtual instance
    test_instance.sysctl_results = {'kern.vm_guest': 'other',
                                    'hw.hv_vendor': 'bhyve',
                                    'security.jail.jailed': '0'}
    test_instance.sysctl_detection_mixin_results = {
        'hw.model': 'VirtualBox'}

    # Call method get_virtual_facts of FreeBSDVirtual instance
    test_result = test_instance.get_virtual_facts()

    # Define expected result

# Generated at 2022-06-23 02:03:32.356557
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:03:36.268080
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    d = FreeBSDVirtual({})
    expected = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    assert d.data == expected

# Generated at 2022-06-23 02:03:39.097820
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # First test that the FreeBSDVirtual constructor works
    # without raising an exception
    test_facts = FreeBSDVirtual({}, None)



# Generated at 2022-06-23 02:03:40.861971
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)


# Generated at 2022-06-23 02:03:45.775963
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fs_virtual = FreeBSDVirtual({'ansible_facts': {'kernel': 'FreeBSD'}})
    assert not fs_virtual.is_linux()
    assert fs_virtual.is_freebsd()
    assert not fs_virtual.is_openbsd()
    assert not fs_virtual.is_netbsd()
    assert not fs_virtual.is_kfreebsd()
    assert not fs_virtual.is_sunos()
    assert not fs_virtual.is_dtrace()
    assert fs_virtual.is_supported()


# Generated at 2022-06-23 02:03:47.334074
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-23 02:03:59.026997
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    facter = FreeBSDVirtual()

    facter.sysctl['dev.xen.0.present'] = None
    facter.sysctl['hw.hv_vendor'] = None

    facter.hw_model = 'QEMU Virtual CPU version (cpu64-rhel6)'
    expected_virtual_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
    }
    assert facter.get_virtual_facts() == expected_virtual_facts

    facter.hw_model = None
    facter.sysctl['dev.xen.0.present'] = '1'

# Generated at 2022-06-23 02:04:10.571995
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts_class = FreeBSDVirtual({})

    # Kernel is not aware of any virtualization technology
    virtual_facts_class.uname_result = {'sysname': 'FreeBSD', 'machine': 'x86_64', 'release': '12.0-RELEASE', 'version': 'FreeBSD 12.0-RELEASE r341666'}
    virtual_facts_class.get_file_content = lambda x: ''

    virtual_facts = virtual_facts_class.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set([])
    assert virtual_facts['virtualization_tech_host'] == set([])

    # Model name include 'vmware'
    virtual_facts

# Generated at 2022-06-23 02:04:12.130395
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert isinstance(virtual, FreeBSDVirtual)



# Generated at 2022-06-23 02:04:13.455547
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # If the class is instantiated, we are done
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:14.442536
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    assert facts

# Generated at 2022-06-23 02:04:20.482975
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:04:22.793221
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:04:24.328825
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:25.407262
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_fact = FreeBSDVirtual(dict())
    assert virtual_fact is not None

# Generated at 2022-06-23 02:04:27.950359
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_collector = FreeBSDVirtualCollector()
    freebsd_virtual_facts = freebsd_collector.collect()
    assert 'virtualization_type' in freebsd_virtual_facts

# Generated at 2022-06-23 02:04:29.218675
# Unit test for constructor of class FreeBSDVirtualCollector

# Generated at 2022-06-23 02:04:40.881324
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set()
    )
    fake_sysctl = dict(
        virtualization_type='sysctl_data',
        virtualization_role='sysctl_role',
        virtualization_tech_guest=set(['sysctl_guest1', 'sysctl_guest2']),
        virtualization_tech_host=set(['sysctl_host1', 'sysctl_host2'])
    )

# Generated at 2022-06-23 02:04:42.826805
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector(None)
    assert virtual_collector.virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:46.614390
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    freebsd_expected_dict = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    freebsd_dict = freebsd.get_virtual_facts()
    for key in freebsd_expected_dict:
        assert freebsd_dict[key] == freebsd_expected_dict[key]

# Generated at 2022-06-23 02:04:52.484267
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert isinstance(virtual_facts, FreeBSDVirtual)
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts.virt_type == ''
    assert virtual_facts.virt_role == ''

# Generated at 2022-06-23 02:04:55.738192
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_obj = FreeBSDVirtual()
    assert test_obj.get_virtual_facts()

if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:04:57.006098
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None)._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:58.850636
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:02.351069
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtual()

    # Class variables which should have been set
    assert fbv.platform == 'FreeBSD'



# Generated at 2022-06-23 02:05:03.830026
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.get_virtual_facts() == {'virtualization_type': '',
                                                 'virtualization_role': '',
                                                 'virtualization_tech_host': set(),
                                                 'virtualization_tech_guest': set()}

# Generated at 2022-06-23 02:05:05.644421
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:15.698914
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})

    def exec_os_command(cmd):
        return {
            'security.jail.jailed': 0,
            'hw.model': 'Genuine Intel(R) CPU',
            'hw.hv_vendor': 'QEMU',
            'kern.vm_guest': 'unknown',
        }

    virtual.exec_os_command = exec_os_command
    result = virtual.get_virtual_facts()
    assert result == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:05:26.766955
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_detection = FreeBSDVirtual()

    # Test with a jail running FreeBSD system
    freebsd_virtual_detection._get_file_content = MagicMock(
        return_value='1\n'
    )
    freebsd_virtual_detection._get_file_content_astext = MagicMock(
        return_value='1\n'
    )
    freebsd_virtual_detection._get_cmd_output = MagicMock(
        return_value='FreeBSD'
    )
    facter_data = {
        'kernel': 'FreeBSD',
        'virtual': 'jail',
        'product_name': 'VirtualBox',
        'manufacturer': 'innotek GmbH'
    }

# Generated at 2022-06-23 02:05:33.201185
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_host'] == set(['bhyve'])

# Generated at 2022-06-23 02:05:35.835441
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:47.793823
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:05:56.240762
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    test_virt_guest_product = {'security.jail.jailed': None, 'hw.hv_vendor': 'bhyve', 'kern.vm_guest': 'guest_freebsd'}
    test_virt_host_product = {'security.jail.jailed': None, 'hw.hv_vendor': 'bhyve', 'kern.vm_guest': 'host_freebsd'}

    test_virt_guest_vendor = {'hw.model': 'QEMU Virtual CPU'}

# Generated at 2022-06-23 02:05:59.362908
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    class Test(object):
        def __init__(self, platform="FreeBSD"):
            self.platform = platform

    t = Test()
    FreeBSDVirtualCollector(t)

# Generated at 2022-06-23 02:06:00.818081
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_virtual = FreeBSDVirtual()
    assert isinstance(fbsd_virtual, FreeBSDVirtual)


# Generated at 2022-06-23 02:06:03.940369
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # TODO: This test is not actually testing anything about the class
    # itself, just whether its constructor works.  Preliminary testing
    # that the constructor works on FreeBSD, but it's not yet a real unit
    # test.
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:06:16.366338
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def test_callable(base_class):
        """Test if VirtualCollector._call_detect_func works."""
        class TestClass(base_class):
            def __init__(self, test_dict):
                self.test_dict = test_dict
                self.call_counter = 0
                super(TestClass, self).__init__()

            def _call_detect_func(self, sysctl_key):
                self.call_counter += 1
                return self.test_dict.get(sysctl_key, '')

        # Init the test class. kern.vm_guest is set to 'guest'.
        guest_type = 'guest'
        test_class = TestClass({'kern.vm_guest': guest_type})
        facts = test_class.get_virtual_facts()


# Generated at 2022-06-23 02:06:18.363639
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import virtual
    virtual.collector = FreeBSDVirtualCollector
    assert isinstance(virtual.collector, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:06:29.816488
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'Xen' in virtual_facts['virtualization_tech_host']
    assert 'Xen' in virtual_facts['virtualization_tech_guest']
    assert 'KVM' in virtual_facts['virtualization_tech_host']
    assert 'KVM' in virtual_facts['virtualization_tech_guest']
    assert 'Jail' in virtual_facts['virtualization_tech_host']
    assert 'Jail' in virtual_facts['virtualization_tech_guest']
    assert 'VirtualBox' in virtual_facts['virtualization_tech_host']
   

# Generated at 2022-06-23 02:06:34.351848
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector != None
    assert virtual_collector.virt_collector == None

# Generated at 2022-06-23 02:06:36.286694
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:41.361171
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    result = virtual.get_virtual_facts()
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert result['virtualization_system'] == ''
    assert result['virtualization_product'] == ''
    assert result['virtualization_uuid'] == ''

# Generated at 2022-06-23 02:06:43.804293
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.facts is None

# Generated at 2022-06-23 02:06:47.702587
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.data['virtualization_type'] == ''
    assert virtual_facts.data['virtualization_role'] == ''

# Generated at 2022-06-23 02:06:58.644656
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test case to assert the method 'get_virtual_facts' of class FreeBSDVirtual
    This method is used to determine the virtualization facts of a system
    """
    freebsd_virtual = FreeBSDVirtual()
    test_input_facts = dict(
        kern_vm_guest=[
            'other',
            'jail',
            'vmware',
            'xen'
        ],
        security_jail_jailed='0',
        hw_hv_vendor=[
            ''
        ],
        hw_model='',
    )
    test_expected_facts = dict(
        virtualization_role='',
        virtualization_type='xen',
        virtualization_tech_host=(),
        virtualization_tech_guest=('xen',)
    )
    test_output_facts

# Generated at 2022-06-23 02:07:10.220369
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    class TestVirtSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            pass
        def _get_sysctl(self, sysctl_name):
            if sysctl_name == "hw.hv_vendor":
                return None
            elif sysctl_name == "security.jail.jailed":
                return '0'
            elif sysctl_name == "kern.vm_guest":
                return "other"
            return None

    class TestFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            pass
        def _get_value_from_file(self, filename):
            return None

# Generated at 2022-06-23 02:07:21.710765
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    facter = FreeBSDVirtual()

    # Definition of the content of sysctl output
    kern_value = "0x3\n"
    hw_value = ""

    # Call the function
    facts = facter._get_virtual_facts(kern_value, hw_value)

    # Check the result
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set()
    assert facts['product_name'] == ''
    assert facts['product_version'] == ''
    assert facts['manufacturer'] == ''
    assert facts['uuid'] == ''

# Unit

# Generated at 2022-06-23 02:07:22.785244
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:07:24.308451
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    generated_fact = FreeBSDVirtualCollector()
    assert generated_fact.virtual == FreeBSDVirtual

# Generated at 2022-06-23 02:07:26.492343
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsdvirtual = FreeBSDVirtual()
    assert fbsdvirtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:07:37.678364
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    virt_facts = dict()
    kern_vm_guest_vals = dict()
    hw_hv_vendor_vals = dict()
    sec_jail_jailed_vals = dict()
    hw_model_vals = dict()
    with open('/proc/cpuinfo', 'r') as cpu_info:
        cpu_info = cpu_info.readlines()

    with open('/proc/meminfo', 'r') as mem_info:
        mem_info = mem_info.readlines()

    virt_facts['virtualization_tech_guest'] = set()
    virt_facts['virtualization_tech_host'] = set()


# Generated at 2022-06-23 02:07:38.896617
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual({}, {})
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:48.228781
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_instance = FreeBSDVirtual()
    assert freebsd_virtual_instance.platform == 'FreeBSD'
    assert freebsd_virtual_instance.virtualization_tech_guest == set()
    assert freebsd_virtual_instance.virtualization_tech_host == set()
    assert freebsd_virtual_instance.virtualization_type == ''
    assert freebsd_virtual_instance.virtualization_role == ''
    assert freebsd_virtual_instance.virtualization_subsystem == ''
    assert freebsd_virtual_instance.virtualization_hypervisor_vendor == ''


# Generated at 2022-06-23 02:07:54.300582
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    if virtual_facts._fact_class != FreeBSDVirtual:
        raise AssertionError("Expected: 'FreeBSDVirtual', Result: {0}".format(virtual_facts._fact_class))
    if virtual_facts._platform != 'FreeBSD':
        raise AssertionError("Expected: 'FreeBSD', Result: {0}".format(virtual_facts._platform))

# Generated at 2022-06-23 02:07:57.180763
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():  # pylint: disable=invalid-name
    module = FreeBSDVirtual(dict(), dict())

    assert module.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:08.616829
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f_virt_facts = FreeBSDVirtual({})
    virt_facts = f_virt_facts.get_virtual_facts()

    assert virt_facts['virtualization_type'] in ['xen', '', 'freebsd-jail',
                                                 'vmm']
    assert virt_facts['virtualization_role'] in ['guest', 'host', '', 'guest,host']
    assert virt_facts['virtualization_tech_guest'] in [[], ['vmm', 'freebsd-jail',
                                                            'xen', 'bhyve']]
    assert virt_facts['virtualization_tech_host'] in [[], ['vmm', 'bhyve']]

# Generated at 2022-06-23 02:08:17.307453
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test facts
    test_facts = {
        "virtual": {
            "virtualization_type": "xen",
            "virtualization_role": "guest",
            "virtualization_tech_guest": ["xen"],
            "virtualization_tech_host": []
        }
    }
    module = FakeModule(
        ansible_facts={
            'kernel': 'FreeBSD',
            'kernel_version': '11'
        },
        params={
            'gather_subset': 'all'
        }
    )
    # Reset Virtualizer class
    Virtual.__subclasses__ = ()
    class_ = FreeBSDVirtualCollector(module)
    assert test_facts == class_.get_virtual_facts()


# Generated at 2022-06-23 02:08:19.527495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if os.uname()[0] != 'FreeBSD':
        return
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:20.789765
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert isinstance(virtual, FreeBSDVirtual)

# Generated at 2022-06-23 02:08:22.452112
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector._fact_class, FreeBSDVirtual)


# Generated at 2022-06-23 02:08:33.877779
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual(None)

    # This is the example output in the kernel that we're testing against:
    sysctl_kern_vm_guest_output = \
        """security.jail.jailed: 0
hw.hv_vendor: bhyve
kern.vm_guest: bhyve"""

    # This is the example output of hw.model that we're testing against:
    sysctl_hw_model_output = \
        """FreeBSD bhyve 1.1-BHYVE-20201109-amd64"""

    # This is the example output in the kernel of the data we're testing against:

# Generated at 2022-06-23 02:08:34.492081
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:36.486862
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    facts = fv.collect()
    assert facts == {}


# Generated at 2022-06-23 02:08:39.564073
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """This test ensures that FreeBSDVirtualCollector can be instantiated"""
    bsd_vc = FreeBSDVirtualCollector()
    assert bsd_vc._platform == "FreeBSD"
    assert bsd_vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:52.281338
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = get_module_mock()
    bsd = FreeBSDVirtual(module)
    bsd.module = module
    bsd.module.run_command = run_command_mock

    # Set empty values as default
    virtual_facts = bsd.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test kern.vm_guest

# Generated at 2022-06-23 02:08:54.802323
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvcollector = FreeBSDVirtualCollector()
    assert fvcollector._platform == 'FreeBSD'
    assert fvcollector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:08:57.269590
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual()
    facts = freebsd.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:09:00.355385
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:04.356184
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.facts['virtualization_type'] = 'hvm'
    v.facts['virtualization_role'] = 'guest'
    expected = {'virtualization_type': 'hvm', 'virtualization_role': 'guest'}
    assert v.get_virtual_facts() == expected

# Generated at 2022-06-23 02:09:06.236307
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    f = FreeBSDVirtual()

    assert FreeBSDVirtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:10.096604
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # verify that FreeBSDVirtual has been created
    expected_class_name = 'FreeBSDVirtual'
    actual_class_name = FreeBSDVirtual.__name__
    assert actual_class_name == expected_class_name

    # verify that FreeBSDVirtual has been created
    expected_platform = 'FreeBSD'
    actual_platform = FreeBSDVirtual.platform
    assert actual_platform == expected_platform

# Generated at 2022-06-23 02:09:11.990621
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts, VirtualCollector)
    assert isinstance(facts, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:09:19.415035
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class FakeFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            self.sysctl_virt_data = {
                'kern.vm_guest': 'other',
                'hw.hv_vendor': '',
                'security.jail.jailed': 0,
                'hw.model': '',
            }

    expected_virtual_facts = {
        'virtualization_type': 'other',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    fake_fbsd_virtual_obj = FakeFreeBSDVirtual()
    virtual_facts = fake_fbsd_virtual_obj.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:09:23.382388
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSDVirtualCollector is required for testing get_virtual_facts
    # as the collect method is a class method
    virtual_facts = FreeBSDVirtualCollector.collect()
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:09:34.661848
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = set(['xen'])
    virtual_facts['virtualization_tech_host'] = set([])
    class_params = {'platform': 'FreeBSD', 'paths': {}}
    freebsd_virtual = FreeBSDVirtual(class_params)
    freebsd_virtual._sysctl_get_product_mapping = \
            lambda x: {'virtualization_tech_guest': set(['xen']),
                       'virtualization_tech_host': set([])}

# Generated at 2022-06-23 02:09:45.955573
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virt = FreeBSDVirtual({})
    freebsd_virt.module = Mock()
    mock_module = freebsd_virt.module
    _kernel_product = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    _virtual_vendor_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    mock_module.run_command.return_value = (0, '3.2-RELEASE')

# Generated at 2022-06-23 02:09:48.359153
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual({}, {})
    assert obj.virtualization_type == ''
    assert obj.virtualization_role == ''

# Generated at 2022-06-23 02:09:51.929739
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    subject = FreeBSDVirtualCollector()
    assert subject._platform == 'FreeBSD'
    assert subject._fact_class.platform == 'FreeBSD'
    assert subject._fact_class.get_virtual_facts.__code__.co_argcount == 1

# Generated at 2022-06-23 02:09:58.598045
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})

    virtual._module = MockModule()
    virtual._module.params = {
        'gather_subset': [],
        'gather_timeout': 10,
    }
    virtual.collect()
    virtual.get_virtual_facts()

    # Check if virtualization facts were set
    assert virtual.facts['virtualization_type'] is not None
    assert virtual.facts['virtualization_role'] is not None



# Generated at 2022-06-23 02:10:00.841057
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:03.459029
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:10:10.453486
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == ''
    assert virtual_facts.get('virtualization_role') == ''
    virtualization_tech_guest = virtual_facts.get('virtualization_tech_guest')
    assert 'jail' in virtualization_tech_guest
    virtualization_tech_host = virtual_facts.get('virtualization_tech_host')
    assert 'bhyve' in virtualization_tech_host

# Generated at 2022-06-23 02:10:12.056661
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual(None)
    assert isinstance(v, FreeBSDVirtual)
    assert isinstance(v, Virtual)

# Generated at 2022-06-23 02:10:15.888744
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up a FreeBSDVirtual object and run it
    bsd_virtual = FreeBSDVirtual()

    virtual_facts = bsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:10:16.892393
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual()
    freebsd.get_virtual_facts()

# Generated at 2022-06-23 02:10:18.395227
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual_facts = FreeBSDVirtual()
    fbsd_virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:10:30.384763
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ansible = dict()
    ansible['virtual_facts'] = dict()
    expected = dict()


    # Test for virtualization type
    expected['virtualization_type'] = 'xen'
    ansible['virtual_facts']['hw_model'] = 'Xen HVM domU'
    ansible['virtual_facts']['kern_vm_guest'] = 'xen'
    ansible['virtual_facts']['hw_hv_vendor'] = ''
    ansible['virtual_facts']['security_jail_jailed'] = '0'

    actual = FreeBSDVirtual().get_virtual_facts(ansible)
    assert actual == expected

    expected['virtualization_type'] = 'xen'
    ansible['virtual_facts']['hw_model'] = 'Xen HVM dom0'

# Generated at 2022-06-23 02:10:35.239823
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    gen = FreeBSDVirtual()
    for (virtual_type, virtual_role) in [
        ('', 'guest'),
        ('', '')
    ]:
        assert gen.get_virtual_facts()['virtualization_type'] == virtual_type
        assert gen.get_virtual_facts()['virtualization_role'] == virtual_role


# Generated at 2022-06-23 02:10:40.663286
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Arrange
    # FreeBSDVirtualCollector already tested in virtual.py
    cls = FreeBSDVirtualCollector
    # Act/Assert
    # No error should be raised here
    cls()