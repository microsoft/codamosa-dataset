

# Generated at 2022-06-23 02:00:40.266028
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'


# Generated at 2022-06-23 02:00:42.940040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:00:45.414191
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    #assert v.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'xen'}
    assert v.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-23 02:00:49.928661
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert VirtualCollector.get_platform() == 'Linux'
    collector = VirtualCollector.factory()
    assert isinstance(collector, FreeBSDVirtualCollector)
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:00:51.869268
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc is not None

# Generated at 2022-06-23 02:00:54.710428
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """Test creation of FreeBSDVirtual object with FreeBSD
    virtualization facts."""
    fbsd_virt = FreeBSDVirtual({})
    assert isinstance(fbsd_virt, Virtual)

# Generated at 2022-06-23 02:00:57.831876
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host_facts = FreeBSDVirtual({})
    assert host_facts.platform == 'FreeBSD'
    assert 'virtualization_type' in host_facts.get_virtual_facts()
    assert 'virtualization_role' in host_facts.get_virtual_facts()

# Generated at 2022-06-23 02:01:07.561711
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create FreeBSDVirtual object with fake values
    obj_virtual = FreeBSDVirtual()
    obj_virtual.facts['kernel'] = 'FreeBSD'
    obj_virtual._module = {'run_command': lambda x: ['FreeBSD']}
    virtual_facts = obj_virtual.get_virtual_facts()

    # Verify all expected values are set
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:01:09.077513
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)



# Generated at 2022-06-23 02:01:10.459557
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsdv = FreeBSDVirtual({})
    assert 'FreeBSD' == fbsdv.platform

# Unit tests for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:22.634523
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:24.254206
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:28.555776
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual(None)
    assert facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:33.327123
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts for FreeBSD

    """
    # Create an instance of FreeBSDVirtual class
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:01:35.092268
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f._platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:35.843322
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:01:38.982440
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    bsd_virtual = FreeBSDVirtual()
    assert bsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:39.627001
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:01:41.214677
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert isinstance(v, FreeBSDVirtual)



# Generated at 2022-06-23 02:01:43.981262
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_virtual_facts()
    assert virtual_facts.platform == 'FreeBSD'


# Unit tests for constructor of class FreeBSDVirtualCollector

# Generated at 2022-06-23 02:01:49.095066
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_obj = FreeBSDVirtual({})
    assert freebsd_virtual_obj.platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:55.354947
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['xen', 'jail', '']
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'vbox' in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_role'] in ['guest', '']

# Generated at 2022-06-23 02:01:59.125127
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual is not None

# Generated at 2022-06-23 02:02:02.702599
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    FreeBSDVirtual()

# Generated at 2022-06-23 02:02:05.839584
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:09.331791
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = {}

    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts is not None, 'test_FreeBSDVirtual: get_virtual_facts() is None'

# Unit tests for detect_virt_product

# Generated at 2022-06-23 02:02:10.526886
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    n = FreeBSDVirtual({})
    assert n.platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:15.212529
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Not using mock in this test, as FreeBSDVirtual.get_virtual_facts is
    # doing the fact gathering only by the use of sysctl and data in hw.model.
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:02:18.281672
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc.fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:02:20.372100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:22.853664
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = {}
    fv = FreeBSDVirtual(facts)
    assert fv.platform == FreeBSDVirtual.platform
    assert fv.get_virtual_facts() == {}

# Generated at 2022-06-23 02:02:24.579809
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert isinstance(facts_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:26.358712
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fe = FreeBSDVirtual()
    assert fe.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:28.674404
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsdvc = FreeBSDVirtualCollector()
    assert bsdvc._fact_class == FreeBSDVirtual
    assert bsdvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:33.489869
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    module = FakeModule()
    result = FreeBSDVirtualCollector(module).collect()
    assert result['virtualization_type'] != ''
    assert result['virtualization_role'] != ''
    assert result['virtualization_tech_host'] != ''
    assert result['virtualization_tech_guest'] != ''



# Generated at 2022-06-23 02:02:41.764847
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup mocks to make the method testable
    class MockLinuxVirtual:
        def __init__(self, kernel_name):
            self.kernel = kernel_name

        def detect_virt_product(self, sysctl_name):
            # TODO: This should realistically return something based on the
            #       sysctl_name passed into this function, but the tests do not
            #       make specific enough calls to actually test that yet.
            if self.kernel == 'FreeBSD':
                return {'hw_vendor': '3PARdata',
                        'hw_model': 'VV',
                        'virtualization_role': 'guest',
                        'virtualization_type': 'paravirtual',
                        'virtualization_tech_host': [],
                        'virtualization_tech_guest': []}

# Generated at 2022-06-23 02:02:53.651071
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Virtualization facts returned by Virtual.get_virtual_facts
    # are specific to the Linux-kernel, which are not proper
    # for FreeBSD.
    #
    # Therefore, we use a fake class to make Virtual.get_virtual_facts
    # returns what we want
    class FreeBSDVirtual:
        def detect_virt_product(self, product):
            if product == 'kern.vm_guest':
                virtual_guest_tech = set()
                virtual_host_tech = set()
                if self.facts['hardware']['model'].lower().find('vbox') != -1:
                    virtual_guest_tech.add('vbox')
                    virtual_host_tech.add('vbox')

# Generated at 2022-06-23 02:02:58.318155
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_facts = FreeBSDVirtualCollector().collect()
    assert virt_facts['virtualization_type'] in ('', 'jail', 'xen', 'vmware', 'qemu', 'virtualbox', 'hyperv', 'kvm', 'vserver', 'paralells')
    assert virt_facts['virtualization_role'] in ('guest', 'host', '')

# Generated at 2022-06-23 02:02:59.734605
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbv = FreeBSDVirtualCollector()
    assert fbv is not None

# Generated at 2022-06-23 02:03:01.902626
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual()
    assert module.platform == "FreeBSD"

# Generated at 2022-06-23 02:03:03.351338
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert(isinstance(FreeBSDVirtualCollector().get_fact_class(), FreeBSDVirtual))

# Generated at 2022-06-23 02:03:15.043529
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = FreeBSDVirtual(facts)

    facts['virtualization_type'] = 'kvm'
    facts['virtualization_role'] = 'guest'
    assert virtual.get_virtual_facts() == facts

    facts['virtualization_type'] = 'vmware'
    facts['virtualization_role'] = 'host'
    assert virtual.get_virtual_facts() == facts

    # test_FreeBSDVirtual_kern_vm_guest_virtualbox_guest
    virtual._current_sysctl = {'kern.vm_guest': 'virtualbox'}

# Generated at 2022-06-23 02:03:26.761260
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:03:29.691798
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:33.052335
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj._fact_class, object)

# Generated at 2022-06-23 02:03:36.349762
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_dict = {'virtualization_type': '', 'virtualization_role': ''}

    result = FreeBSDVirtual().get_virtual_facts()
    assert result == test_dict

# Generated at 2022-06-23 02:03:39.197628
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc, VirtualCollector)
    assert isinstance(vc._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:03:41.660269
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd = FreeBSDVirtualCollector()
    assert freebsd._platform == FreeBSDVirtualCollector._platform
    assert freebsd._fact_class == FreeBSDVirtualCollector._fact_class

# Generated at 2022-06-23 02:03:46.806747
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test the creation of an object FreeBSDVirtualCollector
    # check that it is not none
    assert FreeBSDVirtualCollector() is not None

# Generated at 2022-06-23 02:03:51.149585
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:52.483093
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbvirtual = FreeBSDVirtual({})
    assert isinstance(fbvirtual, Virtual)

# Generated at 2022-06-23 02:03:54.594933
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    this = FreeBSDVirtualCollector()
    assert this.platform == 'FreeBSD'
    assert this.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:56.945228
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instantiate FreeBSDVirtualCollector class
    fvc_inst = FreeBSDVirtualCollector()
    assert fvc_inst is not None
    assert fvc_inst._platform is not None

# Generated at 2022-06-23 02:03:57.524784
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:01.319231
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fake_FreeBSD_virtual = FreeBSDVirtual()

    assert fake_FreeBSD_virtual.platform == 'FreeBSD'
    assert fake_FreeBSD_virtual.virtualization_type == ''
    assert fake_FreeBSD_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:04:04.783930
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:06.602974
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert isinstance(virtual, FreeBSDVirtual)



# Generated at 2022-06-23 02:04:11.833472
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    result = virtual.get_virtual_facts()

    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['xen'])
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:04:24.635681
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    gvf_command = 'sysctl -n kern.vm_guest'
    hhvv_command = 'sysctl -n hw.hv_vendor'
    sjj_command = 'sysctl -n security.jail.jailed'
    model_command = 'sysctl -n hw.model'

    def mocked_run_command(cmd, *_):
        if cmd == gvf_command:
            return 'vmware', '', 0
        elif cmd == hhvv_command:
            return 'VMWare', '', 0
        elif cmd == sjj_command:
            return '0', '', 0
        elif cmd == model_command:
            return 'VMware Virtual Platform', '', 0
        else:
            return '', '', 1

    fv = FreeBSDVirtual()



# Generated at 2022-06-23 02:04:26.048593
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(None)
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:04:37.406390
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os.path.exists = lambda x: True
    fake_sysctl_return_values = {
        'hw.hv_vendor': '',
        'hw.model': 'VirtualBox',
        'kern.vm_guest': 'freebsd',
        'security.jail.jailed': 0
    }
    virt = FreeBSDVirtual(None, sysctl_path='/fake/sysctl', sysctl_return_values=fake_sysctl_return_values, detect_pkg=lambda x: False)
    expected_facts = {
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest'
    }
    assert virt.get_virtual_facts()

# Generated at 2022-06-23 02:04:41.226032
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x
    assert x._platform == 'FreeBSD'
    assert x._fact_class._platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:44.255257
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector != None

# Generated at 2022-06-23 02:04:51.636897
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.kernel = 'freebsd'
    actual_output = freebsd_virtual.get_virtual_facts()
    expected_output = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert expected_output == actual_output

# Generated at 2022-06-23 02:04:54.604260
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:57.538270
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """This test case is inplace to overload the test cases of VirtualCollector """
    collector = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:59.512240
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    with FreeBSDVirtual() as r:
        assert r.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:08.017826
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtualCollector.collect()
    assert facts['virtualization_role'] == 'guest', 'FreeBSD virtualization_role fact should be "guest"'
    assert facts['virtualization_type'] == 'xen', 'FreeBSD virtualization_type should be "xen"'
    assert 'xen' in facts['virtualization_tech_guest'], 'FreeBSD virtualization_tech_guest should contain xen'
    assert 'xen' not in facts['virtualization_tech_host'], 'FreeBSD virtualization_tech_host should not contain xen'

# Generated at 2022-06-23 02:05:13.587099
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''
    assert freebsd_virtual.virtualization_tech_host == set()
    assert freebsd_virtual.virtualization_tech_guest == set()


# Generated at 2022-06-23 02:05:15.868715
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform is 'FreeBSD'

# Generated at 2022-06-23 02:05:17.258586
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:28.314420
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def_facts = dict(
        ansible_facts=dict(
            ansible_virtualization_role='guest',
            ansible_virtualization_type='xen',
            ansible_virtualization_tech_guest=['xen']
        )
    )
    # Ensure exception is raised when no path to OsRelease exists (empty dict
    # is returned by read_file)
    assert FreeBSDVirtual({}).get_virtual_facts() == {}

    # Return default facts for a FreeBSD guest VM if /dev/xen/xenstore exists
    freebsd = FreeBSDVirtual({})
    freebsd.read_file = lambda path: {'/dev/xen/xenstore': True}
    assert freebsd.get_virtual_facts() == def_facts

    # Return default facts for a FreeBSD guest VM if KVM host tech

# Generated at 2022-06-23 02:05:31.905268
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual


# Generated at 2022-06-23 02:05:33.083437
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    collection = FreeBSDVirtual()
    assert collection is not None

# Generated at 2022-06-23 02:05:35.487032
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'
    assert not virtual.virtualization_type
    assert not virtual.virtualization_role

# Generated at 2022-06-23 02:05:36.819546
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:38.975447
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'



# Generated at 2022-06-23 02:05:40.478740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    a = FreeBSDVirtualCollector(None, None)
    assert isinstance(a, FreeBSDVirtualCollector)


# Generated at 2022-06-23 02:05:44.864474
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._fact_class == FreeBSDVirtual
    assert virtual_facts._platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:47.874512
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual
    assert repr(x) == '<FreeBSDVirtualCollector(FreeBSD)>'

# Generated at 2022-06-23 02:05:49.746441
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class is FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'


# Generated at 2022-06-23 02:06:01.536713
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '', 'virtualization_role': '',
                     'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    virtual_vendor_facts = {'virtualization_type': 'qemu', 'virtualization_role': 'guest',
                            'virtualization_tech_host': set(),
                            'virtualization_tech_guest': {'kvm', 'qemu', 'emulated'}}
    sysctl_kern_vm_guest_facts = {'virtualization_type': '', 'virtualization_role': '',
                                  'virtualization_tech_host': set(),
                                  'virtualization_tech_guest': {'jail'}}

# Generated at 2022-06-23 02:06:02.891038
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    test = FreeBSDVirtual()
    assert test.platform == 'FreeBSD'


# Generated at 2022-06-23 02:06:04.097389
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual


# Generated at 2022-06-23 02:06:10.432086
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    #object of FreeBSDVirtualCollector
    fbc = FreeBSDVirtualCollector()

    #checking the value of _platform
    assert fbc._platform == 'FreeBSD', "The value of _platform should be 'FreeBSD'"

    #checking the input value of _fact_class
    assert fbc._fact_class == FreeBSDVirtual, "The value of _fact_class should be FreeBSDVirtual"

# Generated at 2022-06-23 02:06:11.777557
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    results = FreeBSDVirtual({})
    assert results.virtualization_type == ''
    assert results.virtualization_role == ''

# Generated at 2022-06-23 02:06:13.058066
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual({})
    assert fb_virtual is not None

# Generated at 2022-06-23 02:06:17.347377
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual({})
    for term in ('virtualization_type', 'virtualization_role',
                 'virtualization_tech_guest', 'virtualization_tech_host'):
        assert term in module._facts
    assert module.platform == 'FreeBSD'



# Generated at 2022-06-23 02:06:18.532203
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:23.821202
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if os.name != "posix":
        return

    test_class = FreeBSDVirtualCollector()
    assert test_class._platform == "FreeBSD"
    assert test_class._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:25.346417
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:27.290825
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bvc = FreeBSDVirtualCollector()
    assert bvc._platform == 'FreeBSD'
    assert bvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:33.927184
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts, FreeBSDVirtualCollector)
    assert isinstance(facts._fact_class, FreeBSDVirtual)
    assert facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:35.304744
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None), VirtualCollector)

# Generated at 2022-06-23 02:06:36.814435
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual({}, {})
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:39.833040
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtualCollector().collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:06:51.544357
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json
    import pytest
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    fact = FreeBSDVirtual()
    # Set empty values as default
    guest_tech = set()
    host_tech = set()

    # Test on real FreeBSD system
    # Virtualization_tech
    virtual_tech = fact.virtualization_tech()
    virtual_tech_expected_keys = set(['virtualization_tech_guest', 'virtualization_tech_host'])
    assert set(virtual_tech.keys()) == virtual_tech_expected_keys
    for key in virtual_tech_expected_keys:
        assert set(virtual_tech[key]) == virtual_tech_expected_keys[key]

    # If a virtual machine

# Generated at 2022-06-23 02:06:59.404412
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
  virtual_facts = FreeBSDVirtual().get_virtual_facts()
  if virtual_facts['ansible_virtualization_type'] != '':
    assert virtual_facts['ansible_virtualization_type'] in ['xen','jail','kvm','vmware','parallels','virtualbox','virtualpc','hyperv','bhyve','qemu','docker','vserver', 'powervm', 'lxc']
  if virtual_facts['ansible_virtualization_role'] != '':
    assert virtual_facts['ansible_virtualization_role'] in ['guest']

# Generated at 2022-06-23 02:07:00.482221
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert True

# Generated at 2022-06-23 02:07:02.249663
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector


# Generated at 2022-06-23 02:07:04.193656
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    print(freebsd_virtual.get_virtual_facts())

# Generated at 2022-06-23 02:07:10.054978
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test creating object with no arguments
    FreeBSDVirtualCollector()
    # Test creating object with a custom _fact_class
    FreeBSDVirtualCollector(fact_class=FreeBSDVirtual)
    # Test creating object with a custom _platform
    FreeBSDVirtualCollector(platform='FreeBSD')
    # Test creating object with custom _fact_class and _platform
    FreeBSDVirtualCollector(fact_class=FreeBSDVirtual, platform='FreeBSD')

# Generated at 2022-06-23 02:07:16.082305
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tester = FreeBSDVirtual({})
    observed_facts = tester.get_virtual_facts()
    assert isinstance(observed_facts['virtualization_role'], str)
    assert isinstance(observed_facts['virtualization_type'], str)
    assert isinstance(observed_facts['virtualization_tech_guest'], set)
    assert isinstance(observed_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:07:17.808085
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None), VirtualCollector)

# Generated at 2022-06-23 02:07:21.617963
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual_constructor = FreeBSDVirtualCollector()
    assert bsd_virtual_constructor._fact_class == FreeBSDVirtual
    assert bsd_virtual_constructor._platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:23.521653
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:07:28.826558
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert isinstance(facts['virtualization_type'], str)
    assert isinstance(facts['virtualization_role'], str)
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:07:31.900741
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    # Check if the results are valid
    assert facts['virtualization_type'] != ''
    assert facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:07:42.884486
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module_name = 'ansible.module_utils.facts.virtual.freebsd.FreeBSDVirtual'
    os_release_content = '''FreeBSD 12.1-RELEASE-p7 GENERIC amd64
    '''
    sysctl_kern_vm_guest = '''vm_guest: vkernel
    '''
    sysctl_hw_hv_vendor = '''hw.hv_vendor:  VMware
    hw.hv_name:  VMware0
    '''
    sysctl_security_jail_jailed = '''security.jail.jailed: 0
    '''
    hw_model = '''QEMU Virtual CPU version 2.5+
    '''

# Generated at 2022-06-23 02:07:48.641121
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:07:50.421754
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual != None


# Generated at 2022-06-23 02:07:58.194700
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:08:00.329602
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual()
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:05.233645
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None, None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technology_guest' in virtual_facts
    assert 'virtualization_technology_host' in virtual_facts

# Generated at 2022-06-23 02:08:10.649047
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict(virtual_facts=dict())
    v = FreeBSDVirtual(facts)
    v.get_virtual_facts()
    assert 'virtualization_tech_guest' in facts['virtual_facts']
    assert 'virtualization_tech_host' in facts['virtual_facts']
    assert 'virtualization_type' in facts['virtual_facts']
    assert 'virtualization_role' in facts['virtual_facts']

# Generated at 2022-06-23 02:08:17.009569
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual({}, {}, {})
    test_facts = freebsd_virtual.get_virtual_facts()
    assert test_facts['virtualization_type'] == 'xen'
    assert test_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:08:25.264719
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    detect = {'kern.vm_guest': ['generic'],
              'hw.hv_vendor': ['BHYVE'],
              'hw.model': ['FreeBSD', 'RackMac'],
              'security.jail.jailed': [1]}
    freebsd_virtual = FreeBSDVirtual(detect)
    assert freebsd_virtual.get_virtual_facts()['virtualization_tech_host'] == set()
    assert freebsd_virtual.get_virtual_facts()['virtualization_tech_guest'] == {'generic', 'bhyve'}
    assert freebsd_virtual.get_virtual_facts()['virtualization_type'] == 'bhyve'
    assert freebsd_virtual.get_virtual_facts()['virtualization_role'] == 'guest'



# Generated at 2022-06-23 02:08:33.529721
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_tech_host': set(),
                     'virtualization_tech_guest': set()}

    # Run get_virtual_facts when kern.vm_guest="none"
    virtual_facts['virtualization_tech_host'] = set(['freebsd_host'])
    kern_vm_guest_none = 'none'
    assert dict(FreeBSDVirtual().get_virtual_facts(kern_vm_guest_none, None, None)) == virtual_facts

    # Run get_virtual_facts when kern.vm_guest="other"
    virtual_facts['virtualization_tech_host'] = set(['freebsd_host'])
    kern_vm_guest_other = 'other'

# Generated at 2022-06-23 02:08:37.087322
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Virtual facts returns None on FreeBSD host
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_type' not in virtual_facts

# Generated at 2022-06-23 02:08:44.362926
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up test input data
    # sysctl test data dictionary
    set_kern_vm_guest = {
        'kern.vm_guest': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }
    set_hw_hv_vendor = {
        'hw.hv_vendor': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }

# Generated at 2022-06-23 02:08:47.120979
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # pylint: disable=invalid-name
    fv = FreeBSDVirtual()
    # pylint: disable=no-member
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:48.347596
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-23 02:08:48.809276
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:51.934312
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test if this class can work
    FreeBSDVirtual()

    # Test the methods of this class
    data = FreeBSDVirtual.get_virtual_facts()
    assert data
    assert data['virtualization_type']
    assert data['virtualization_role']
    assert data['virtualization_tech_guest']
    assert data['virtualization_tech_host']

# Generated at 2022-06-23 02:08:54.761701
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    frebsd_virtual_fact = FreeBSDVirtualCollector()
    assert frebsd_virtual_fact._platform == 'FreeBSD'
    assert frebsd_virtual_fact._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:56.933399
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_vc = FreeBSDVirtualCollector()
    assert freebsd_vc.platform == 'FreeBSD'
    assert freebsd_vc.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:01.572685
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_obj = FreeBSDVirtual(module_arg_spec={})
    assert isinstance(freebsd_virtual_obj.module, dict) is True

# Generated at 2022-06-23 02:09:02.902694
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:03.470733
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:07.993060
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Run method get_virtual_facts from class FreeBSDVirtual
    test_virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Confirm method return expected virtual_facts
    assert test_virtual_facts == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-23 02:09:15.976678
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual({})
    freebsd_virtual.sysctl = dict(
        kern_vm_guest={
            'value': 'other',
        },
        hw_hv_vendor={
            'value': 'jail',
        },
        security_jail_jailed={
            'value': '0',
        },
        hw_model={
            'value': 'VMware, Inc. VMware Virtual Platform',
        }
    )

    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set(('vmware',))

# Generated at 2022-06-23 02:09:18.501752
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class._platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:26.778679
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Ensure that we can use VirtualSysctlDetectionMixin.detect_virt_product
    # with a mock sysctl dictionary and FreeBSDVirtual.get_virtual_facts
    # will not error out.
    facts = Virtual()
    facts.sysctl = {
        'kern.vm_guest': 'vmware',
        'security.jail.jailed': 1,
        'hw.hv_vendor': 'SomeVirtualizationTechnique',
    }

    f = FreeBSDVirtualCollector()
    f.populate()
    assert f.facts is not None
    assert f.facts['virtualization_type'] != ''



# Generated at 2022-06-23 02:09:38.162412
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:09:39.612796
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert FreeBSDVirtual().get_virtual_facts() == {}

# Generated at 2022-06-23 02:09:41.818129
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class is FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:44.353000
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    gv = FreeBSDVirtualCollector()
    assert gv.platform == 'FreeBSD'
    assert gv._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:46.615403
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Initialize class with empty parameters
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:49.608947
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:00.799456
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with no virtualization
    test_freebsd = FreeBSDVirtual({})
    assert test_freebsd.get_virtual_facts() == {'virtualization_type': '',
                                               'virtualization_role': '',
                                               'virtualization_tech_guest': set(),
                                               'virtualization_tech_host': set()}

    # Test Xen domU
    test_freebsd = FreeBSDVirtual({'ansible_product_name': 'Xen domU'})
    assert test_freebsd.get_virtual_facts() == {'virtualization_type': 'xen',
                                               'virtualization_role': 'guest',
                                               'virtualization_tech_guest': {'xen'},
                                               'virtualization_tech_host': set()}

    # Test FreeBSD

# Generated at 2022-06-23 02:10:01.360192
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:10:02.919838
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v.platform == "FreeBSD"

# Generated at 2022-06-23 02:10:03.517385
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:10:04.395626
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector


# Generated at 2022-06-23 02:10:06.999044
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check if FreeBSDVirtualCollector is a subclass of VirtualCollector
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:10:09.672833
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.collector import FactCollector
    assert isinstance(FactCollector(None, None, {}, [FreeBSDVirtualCollector]), FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:10:11.483078
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = Virtual(FreeBSDVirtualCollector)

    assert(virtual_facts._platform == 'FreeBSD')

# Generated at 2022-06-23 02:10:12.052375
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:10:14.125860
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:15.817771
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    _test_virtual = FreeBSDVirtual()
    assert _test_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:17.414249
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual()
    assert fb_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:22.048477
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert not virtual_facts['virtualization_type']
    assert not virtual_facts['virtualization_role']
    assert not virtual_facts['virtualization_tech_guest'] and not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:10:23.648212
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj != None

# Generated at 2022-06-23 02:10:25.755340
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert hasattr(FreeBSDVirtual, 'platform')


# Generated at 2022-06-23 02:10:36.829641
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Method get_virtual_facts of class FreeBSDVirtual
    """
    # Initialize FreeBSDVirtual object for unit test
    facts_obj = FreeBSDVirtual(module=None)

    # Sample data from /sbin/sysctl -a kern.vm_guest
    sysctl_vm_guest_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
    }

    # Sample data from /sbin/sysctl -a hw.hv_vendor

# Generated at 2022-06-23 02:10:42.372661
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtualCollector()
    virtual = collector.collect(None, {})

    freebsd_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }
    assert virtual == freebsd_virtual_facts