

# Generated at 2022-06-23 02:00:43.572215
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = Virtual(None)
    assert v.platform == 'Generic'
    assert not v.collector
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''
    assert not v.virtualization_tech_guest
    assert not v.virtualization_tech_host
    fbsd_v = FreeBSDVirtual(v)
    assert fbsd_v.platform == 'FreeBSD'
    assert fbsd_v.virtualization_type == ''
    assert fbsd_v.virtualization_role == ''
    assert not fbsd_v.virtualization_tech_guest
    assert not fbsd_v.virtualization_tech_host


# Generated at 2022-06-23 02:00:45.050957
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test FreeBSDVirtual constructor
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'


# Generated at 2022-06-23 02:00:47.155340
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)
    assert virtual._platform == 'FreeBSD'
    assert virtual.platform == 'FreeBSD'
    assert not virtual.module

# Generated at 2022-06-23 02:00:49.832519
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-23 02:00:55.530220
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert type(virtual_facts['virtualization_type']) == str
    assert type(virtual_facts['virtualization_role']) == str
    assert type(virtual_facts['virtualization_tech_guest']) == set
    assert type(virtual_facts['virtualization_tech_host']) == set

# Generated at 2022-06-23 02:00:57.246582
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({})
    assert virt.platform == 'FreeBSD'


# Generated at 2022-06-23 02:01:09.418733
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mocked_virtual_facts = {'virtualization_type': 'xen',
                            'virtualization_role': 'guest',
                            'virtualization_tech_guest': ['xen'],
                            'virtualization_tech_host': []}
    fv = FreeBSDVirtual()
    facts = fv.get_virtual_facts()
    print("facts = "+ str(facts))
    assert facts.get('virtualization_type') == mocked_virtual_facts.get('virtualization_type')
    assert facts.get('virtualization_role') == mocked_virtual_facts.get('virtualization_role')
    assert facts.get('virtualization_tech_guest') == mocked_virtual_facts.get('virtualization_tech_guest')
    assert facts.get('virtualization_tech_host') == mocked_virtual_facts.get

# Generated at 2022-06-23 02:01:10.227118
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual('None', 'None').platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:12.500973
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector.collect(), list)

# Unit tests for constructor of class FreeBSDVirtual

# Generated at 2022-06-23 02:01:14.209056
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(dict(), dict())


# Generated at 2022-06-23 02:01:16.186648
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:18.110745
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:01:28.182791
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl_outputs = {
        'kern.vm_guest': 'none',
        'hw.model': 'FreeBSD/amd64',
        'security.jail.jailed': 0
    }
    virtual_facts = FreeBSDVirtual(sysctl_outputs)
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

    sysctl_outputs = {
        'kern.vm_guest': 'none',
        'hw.model': 'Opteron_G4',
        'security.jail.jailed': 0
    }
    virtual_facts = FreeBSDVirtual(sysctl_outputs)
    assert virtual_facts.virtualization_type == 'xen'
    assert virtual_facts.virtualization_role == 'guest'

    sysctl_outputs

# Generated at 2022-06-23 02:01:30.456080
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._fact_class == FreeBSDVirtual
    assert x._platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:39.452892
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import SYSCTL_PRODUCTS, SYSCTL_VALUES, SYSCTL_VENDOR_PRODUCTS, SYSCTL_VENDOR_VALUES

    FreeBSDVirtual.detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product_stub(SYSCTL_PRODUCTS)
    FreeBSDVirtual.detect_virt_vendor = VirtualSysctlDetectionMixin.detect_virt_vendor_stub(SYSCTL_VENDOR_PRODUCTS)

    virt = FreeBSDVirtual()
    virtual_facts = virt.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'hvm'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:01:41.059040
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({'ansible_facts': {}})
    facts_dict = v.get_virtual_facts()
    assert facts_dict['virtualization_role'] in ('guest', 'host')

# Generated at 2022-06-23 02:01:45.290461
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()

    class mock_detect_virt_product_kern_vm_guest(object):
        virtualization_tech_guest = set(['virtualbox'])
        virtualization_tech_host = set()
        virtualization_type = 'virtualbox'
        virtualization_role = 'guest' # This is a guess for a host

    class mock_detect_virt_product_hw_hv_vendor(object):
        virtualization_tech_guest = set(['bhyve'])
        virtualization_tech_host = set(['bhyve'])
        virtualization_type = 'bhyve'
        virtualization_role = 'host'


# Generated at 2022-06-23 02:01:50.118307
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector._platform == 'FreeBSD'
    assert facts_collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:01:53.828061
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_facts = FreeBSDVirtual()
    # assert_equals is deprecated in unit tests
    # https://docs.pytest.org/en/latest/deprecations.html#assert-methods
    assert virt_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:56.417877
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsd_v = FreeBSDVirtual()
    assert FreeBSDVirtual.platform == "FreeBSD"


# Generated at 2022-06-23 02:01:59.759883
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual({})
    vf.get_virtual_facts()

# Generated at 2022-06-23 02:02:03.322174
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_obj = FreeBSDVirtualCollector()
    assert virtual_collector_obj.platform == 'FreeBSD'
    assert virtual_collector_obj._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:04.766086
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector



# Generated at 2022-06-23 02:02:09.217619
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Asserts that FreeBSDVirtualCollector is a subclass of VirtualCollector
    and has populated the right platform and fact_class.
    """
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:18.892306
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_obj = FreeBSDVirtual({})

    # xen virtualization type should be returned
    test_obj.sysctl_dict = {
        'kern.vm_guest': 'xen',
        'hw.hv_vendor': 'None',
        'security.jail.jailed': '1',
        'hw.model': 'Xen 4.2.amazon'
    }
    virtual_facts = test_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert sorted(list(virtual_facts['virtualization_tech_guest'])) == ['xen']
    assert virtual_facts['virtualization_tech_host'] == set()

    # hw.hv_vendor option should be

# Generated at 2022-06-23 02:02:21.917340
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()

    for key in ['virtualization_type', 'virtualization_role']:
        assert virtual_facts[key] != ''

# Generated at 2022-06-23 02:02:24.299312
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsdBVC = FreeBSDVirtualCollector()
    assert freebsdBVC._fact_class == FreeBSDVirtual
    assert freebsdBVC._platform == 'FreeBSD'


# Generated at 2022-06-23 02:02:27.811802
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    first_facts = FreeBSDVirtual().get_virtual_facts()
    second_facts = FreeBSDVirtual().get_virtual_facts()
    assert first_facts == second_facts

# Generated at 2022-06-23 02:02:32.559789
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c, FreeBSDVirtualCollector)
    assert isinstance(c._fact_class, FreeBSDVirtual)
    assert c._platform == 'FreeBSD'
    assert c._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:34.320987
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:36.554834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:02:40.752161
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert v.platform == 'FreeBSD'
    assert v.get_virtual_facts() == dict(
        virtualization_role='')

# Generated at 2022-06-23 02:02:46.358210
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-23 02:02:48.530781
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {'kernel': 'FreeBSD'}
    FreeBSDVirtualCollector(facts, {})


# Generated at 2022-06-23 02:02:58.234881
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts() method of FreeBSDVirtual class
    """
    class MockFreeBSDVirtual(FreeBSDVirtual):
        """
        Mock FreeBSDVirtual class for testing get_virtual_facts() method
        """
        def detect_virt_product(self, value):
            """
            Mocked detect_virt_product() method of FreeBSDVirtual class
            """
            return {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

        def detect_virt_vendor(self, value):
            """
            Mocked detect_virt_vendor() method of FreeBSDVirtual class
            """
            return {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    # Check for VirtualizationType and VirtualizationRole for kvm
    virtual_facts = MockFreeBSDVirtual()


# Generated at 2022-06-23 02:03:03.309634
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is the FreeBSDVirtual object that is instantiated by the
    # FreeBSDVirtualCollector.
    fv = FreeBSDVirtual()

    # This dictionary represents what the FreeBSDVirtual.get_virtual_facts()
    # method will return.  Here it is initialized with empty values.
    facts = dict(
        virtual_facts=dict(
            virtualization_type='',
            virtualization_role='',
        )
    )

    # This is a side-effect of calling the FreeBSDVirtual.get_virtual_facts()
    # method.  This value will be set to "guest" if the machine is detected
    # as a virtual machine.
    facts['virtual_facts']['virtualization_role'] = "guest"

    # This is a side-effect of calling the FreeBSDVirtual.get_virtual_facts()
    # method.  This value will

# Generated at 2022-06-23 02:03:08.553349
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    expected_platform = 'FreeBSD'
    _FreeBSDVirtualCollector = FreeBSDVirtualCollector(None)
    assert _FreeBSDVirtualCollector._platform == expected_platform, \
        "getter for variable '_platform' should return '%s'" % expected_platform


# Generated at 2022-06-23 02:03:10.311608
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:12.996568
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Unit test for constructor of class FreeBSDVirtual.
    '''
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:15.515567
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:03:17.997329
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None, None, None).get_virtual_facts()
    assert (virtual_facts is not None)

# Generated at 2022-06-23 02:03:22.805891
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    assert(issubclass(FreeBSDVirtualCollector, VirtualCollector))
    assert(FreeBSDVirtualCollector._platform == 'FreeBSD')

# Generated at 2022-06-23 02:03:24.891847
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = {'kernel': 'FreeBSD'}
    c = FreeBSDVirtualCollector(facts_dict, None, '')

# Generated at 2022-06-23 02:03:29.130661
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    p = FreeBSDVirtual()
    print(p)

if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-23 02:03:33.287092
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb = FreeBSDVirtual()
    fb = FreeBSDVirtual({})

# Unit test collection of all facts from FreeBSDVirtual class

# Generated at 2022-06-23 02:03:35.596091
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO: Need to set up testing environment with real values.
    # in the meantime, we at least make sure the code runs.
    fbsdvirt = FreeBSDVirtual()
    fbsdvirt.get_virtual_facts()

# Generated at 2022-06-23 02:03:37.134873
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()

    # test FreeBSDVirtual class variables
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:45.803272
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()


# Generated at 2022-06-23 02:03:54.220833
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockModule:
        def __init__(self):
            self.params = {
                'gather_subset': '!all',
                'gather_timeout': 10,
                'filter': '*'
            }
    module = MockModule()
    virt = FreeBSDVirtual(module)

    facts = virt.get_virtual_facts()

    assert facts['virtualization_type'] != ''
    assert facts['virtualization_role'] != ''
    assert facts['virtualization_type'] in facts['virtualization_tech_host']
    assert facts['virtualization_role'] in facts['virtualization_tech_host']
    assert facts['virtualization_type'] in facts['virtualization_tech_guest']
    assert facts['virtualization_role'] in facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:03:57.765954
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert isinstance(result, VirtualCollector)
    assert isinstance(result.platforms, list)
    assert 'FreeBSD' in result.platforms
    assert result.platforms['FreeBSD'] is FreeBSDVirtualCollector._fact_class

# Generated at 2022-06-23 02:04:08.793045
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class test(FreeBSDVirtual):
        def detect_virt_product(self, key):
            if key == 'kern.vm_guest':
                return { 'virtualization_type': 'jail',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': set(['jail']),
                    'virtualization_tech_host': set(['bsd']),
                    }
            if key == 'hw.hv_vendor':
                return { 'virtualization_type': 'openvzhn',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': set(['openvzhn']),
                    'virtualization_tech_host': set(['openvzhn']),
                    }

# Generated at 2022-06-23 02:04:20.890737
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test 1: File /dev/xen/xenstore exists, /proc/xen does not exist
    open('/dev/xen/xenstore', 'a').close()
    assert FreeBSDVirtual().get_virtual_facts() == \
        {'virtualization_type': 'xen', 'virtualization_role': 'guest',
         'virtualization_tech_guest': {},
         'virtualization_tech_host': {}}
    os.remove('/dev/xen/xenstore')

    # Test 2: File /dev/xen/xenstore exists and /proc/xen exists
    open('/dev/xen/xenstore', 'a').close()
    os.mkdir('/proc/xen')

# Generated at 2022-06-23 02:04:22.892081
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:24.327836
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:27.846928
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:39.932100
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self, kernel_version=None, sysctl=None, sysctl_all=None, virtual_vendor=None):
            self.kernel_version = kernel_version
            self.sysctl = sysctl
            self.sysctl_all = sysctl_all
            self.virtual_vendor = virtual_vendor
            self.facts = {}

        def get_kernel_version(self):
            return self.kernel_version

        def get_sysctl(self, name):
            return self.sysctl[name]

        def get_sysctl_all(self):
            return self.sysctl_all

        def get_virtual_vendor(self):
            return self.virtual_vendor

        def collect(self):
            return self.get_virtual_facts()

# Generated at 2022-06-23 02:04:44.200191
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    free_bsd = FreeBSDVirtual({})
    assert free_bsd is not None

# Generated at 2022-06-23 02:04:56.106705
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Test with set values for 'virtualization_type' and 'virtualization_role'
    # as we don't mock these
    platform_virtual = FreeBSDVirtual({'virtualization_type': 'jail', 'virtualization_role': 'host'})
    assert platform_virtual.platform == 'FreeBSD'
    assert platform_virtual.virtualization_type == 'jail'
    assert platform_virtual.virtualization_role == 'host'
    assert platform_virtual.virtualization_tech_guest.issubset(set(['jail', 'bhyve']))
    assert platform_virtual.virtualization_tech_host == set(['bhyve'])

    # Test with empty values for 'virtualization_type' and 'virtualization_role'
    # as we don't mock these

# Generated at 2022-06-23 02:04:57.660132
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_freebsd = FedoraVirtual()
    assert virtual_freebsd.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:59.723673
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector is not None

# Generated at 2022-06-23 02:05:02.855226
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:05:06.413073
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ffreebsdvirtual = FreeBSDVirtualCollector()
    assert ffreebsdvirtual._fact_class == FreeBSDVirtual
    assert ffreebsdvirtual._platform == 'FreeBSD'


# Generated at 2022-06-23 02:05:17.283241
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize the FreeBSDVirtual class
    freebsd_virtual = FreeBSDVirtual()

    # Mock some virtualization facts
    freebsd_virtual.facts = dict(
        hw_model='VirtualBox',
        kern_vm_guest='jail',
        hw_hv_vendor='N/A',
        security_jail_jailed='1'
    )

    # Call get_virtual_facts
    freebsd_virtual.get_virtual_facts()

    # Assert get_virtual_facts returned the expected results
    assert freebsd_virtual.facts['virtualization_type'] == 'jail'
    assert freebsd_virtual.facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:05:21.490032
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert obj.platform == FreeBSDVirtualCollector._platform
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:05:29.779176
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO: fix test to work with Vagrant
    # Check when jail, host
    jail_host_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert jail_host_facts['virtualization_role'] == 'host'
    assert 'jail' in jail_host_facts['virtualization_tech_host']
    assert not jail_host_facts['virtualization_tech_guest']

    # Check when VPS, host
    vps_host_facts = FreeBSDVirtual({'ansible_product_name': 'OpenVZ', 'ansible_system': 'OpenVZ'}).get_virtual_facts()
    assert vps_host_facts['virtualization_role'] == 'host'
    assert 'openvz' in vps_host_facts['virtualization_tech_host']
    assert not vps_host

# Generated at 2022-06-23 02:05:32.008340
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    assert(isinstance(v, FreeBSDVirtual))

# Generated at 2022-06-23 02:05:42.647824
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)

# Generated at 2022-06-23 02:05:54.470288
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    if os.path.exists('/dev/xen/xenstore'):
        guest_tech.add('xen')
        virtual_facts['virtualization_type'] = 'xen'
        virtual_facts['virtualization_role'] = 'guest'
    if 'VMWARE' in os.popen('sysctl -n hw.model').read():
        guest_tech.add('vmware')
        virtual_facts['virtualization_type'] = 'vmware'
        virtual_facts['virtualization_role'] = 'guest'

# Generated at 2022-06-23 02:06:04.653222
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)

    # Check if it's an instance of FreeBSDVirtual
    assert isinstance(virtual_facts, FreeBSDVirtual)

    # Check if it's an instance of Virtual
    assert isinstance(virtual_facts, Virtual)

    # Check if it's an instance of Virtual Sysctl Detection Mixin
    assert isinstance(virtual_facts, VirtualSysctlDetectionMixin)

    # Check attributes of Virtual
    assert virtual_facts.platform == 'FreeBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()
    assert virtual_facts.sysctl_facts == {}


# Generated at 2022-06-23 02:06:16.443016
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    # Test that nothing is set if no sysctl exist
    with open('/dev/null', 'w') as devnull:
        with open('/dev/null', 'w') as devnull2:
            freebsd_virtual_facts = FreeBSDVirtual(devnull, devnull, devnull, devnull2)
            assert freebsd_virtual_facts._facts['virtualization_role'] == ''
            assert freebsd_virtual_facts._facts['virtualization_type'] == ''

    # Test that virtualization_type is set to "xen" if /dev/xen/xenstore exists

# Generated at 2022-06-23 02:06:17.485362
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 02:06:29.211457
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:06:32.942836
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-23 02:06:34.532512
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform == "FreeBSD"

# Generated at 2022-06-23 02:06:41.322086
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    data = {'kern.vm_guest': 'other',
            'hw.model': 'QEMU Virtual CPU version 1.0.0',
            'hw.hv_vendor': '',
            'hw.hv_support': '0'}
    virtual_facts = FreeBSDVirtual(data).get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:06:43.295881
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-23 02:06:46.785908
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:49.823639
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:07:00.837725
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_helper = VirtualTestHelper()

    # Test case with FreeBSD 10, host
    test_helper.add_sysctl_return('security.jail.jailed', 0)
    test_helper.add_sysctl_return('kern.vm_guest', 'none')
    test_helper.add_sysctl_return('hw.hv_vendor', 'N/A')
    test_helper.add_sysctl_return('hw.model', 'FreeBSD')
    os.path.exists = test_helper.mock_path_exists(['/dev/xen/xenstore'])
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role']

# Generated at 2022-06-23 02:07:12.208497
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Arrange
    test_object = FreeBSDVirtual()
    test_object.sysctl = {'kern.vm_guest': 'vmware',
                          'hw.hv_vendor': 'KVM',
                          'security.jail.jailed': 0}
    test_object.sysctl_xen = {'hw.xen.max_vcpus': 0,
                              'hw.xen.nr_nodes': 0,
                              'hw.xen.nr_vcpus': 0,
                              'hw.xen.vcpu': 0}

# Generated at 2022-06-23 02:07:23.876313
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def mock_kern_vm_guest(self):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set([]),
            'virtualization_tech_host': set([]),
        }

    def mock_hw_hv_vendor(self):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set([]),
            'virtualization_tech_host': set([]),
        }


# Generated at 2022-06-23 02:07:31.360840
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.facts = {}
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert freebsd_virtual_facts['virtualization_type'] == ''
    assert freebsd_virtual_facts['virtualization_role'] == ''
    assert isinstance(freebsd_virtual_facts['virtualization_tech_host'], set)
    assert isinstance(freebsd_virtual_facts['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:07:36.649782
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    facts = FreeBSDVirtualCollector.collect()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:07:40.439340
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    allowed_keys = ('virtualization_type', 'virtualization_role', 
                    'virtualization_tech_guest', 'virtualization_tech_host')
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert set(allowed_keys).issubset(virtual_facts.keys())

# Generated at 2022-06-23 02:07:43.091208
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_facts = FreeBSDVirtual({'ansible_facts': {}})
    assert freebsd_virtual_facts.platform == 'FreeBSD'



# Generated at 2022-06-23 02:07:45.766135
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._platform == FreeBSDVirtual._platform

# Generated at 2022-06-23 02:07:49.149205
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'FreeBSD Jails'


# Generated at 2022-06-23 02:07:53.887358
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    virtual = FreeBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is not None
    assert virtual_facts['virtualization_role'] is not None

# Generated at 2022-06-23 02:07:57.881048
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual
# end of test_FreeBSDVirtualCollector()



# Generated at 2022-06-23 02:08:09.635044
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:08:12.429643
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test succeed when virtual_facts is not empty
    assert FreeBSDVirtual().get_virtual_facts() != {}


# Generated at 2022-06-23 02:08:14.234792
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert VirtualCollector.get_platform() == 'FreeBSD'

# Generated at 2022-06-23 02:08:17.576351
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c._fact_class is FreeBSDVirtual
    assert c._platform is 'FreeBSD'

# Generated at 2022-06-23 02:08:24.206874
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys

    # These 'assert' statements are used to show the value of
    # virtual_facts after being processed by the class
    # FreeBSDVirtual.  The assertions are only valid if get_virtual_facts()
    # produces a dictionary.
    FBSD = FreeBSDVirtual(module=sys.modules[__name__])
    virtual_facts = FBSD.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:08:26.645563
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, None, 'FreeBSD')
    assert virtual.platform == "FreeBSD"

# Generated at 2022-06-23 02:08:30.650808
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fd = FreeBSDVirtual()
    assert fd.platform == 'FreeBSD'
    assert fd.guest_num == 0
    assert fd.virtual_facts['virtualization_type'] == ''
    assert fd.virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:08:34.163559
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    lf = FreeBSDVirtualCollector()
    assert isinstance(lf._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-23 02:08:36.534916
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''

# Generated at 2022-06-23 02:08:37.424545
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual()


# Generated at 2022-06-23 02:08:39.527296
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class is FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:48.460316
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_data = {'virtualization_type': '',
                 'virtualization_role': '',
                 'virtualization_tech_guest': set(),
                 'virtualization_tech_host': set()
                 }

    test_obj = FreeBSDVirtual()

    test_obj.get_virtual_facts()

    # Check if all key and values are present in the returned dictionary.
    for key in test_data.keys():
        assert key in test_obj.facts
        assert test_data[key] == test_obj.facts[key]

# Generated at 2022-06-23 02:08:49.486141
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    x = FreeBSDVirtual()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:50.040515
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    FreeBSDVirtual().collect()

# Generated at 2022-06-23 02:08:50.489146
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:08:55.088449
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Testing with an empty dictionary
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    # Testing with an unset instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual({})
    # Testing with a dictionary containing an empty sysctl dict
    freebsd_virtual.sysctl = {}

    # Testing with a dictionary containing an empty sysctl dict
    # and an empty hw_model dict
    freebsd_virtual.hw_model = {}

    result = freebsd_virtual.get_virtual_facts()
    assert result == virtual_facts

# Generated at 2022-06-23 02:08:57.808330
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:09:08.219008
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    fake_sysctl_data = [
        {
            'kern.vm_guest': 'xen',
        },
        {
            'kern.vm_guest': 'none',
            'hw.hv_vendor': 'BHYVE',
        },
        {
            'kern.vm_guest': 'none',
            'security.jail.jailed': '1',
        },
        {
            'kern.vm_guest': 'none',
            'hw.hv_vendor': 'none',
            'hw.model': 'VMWare Virtual Platform',
        },
        {
            'kern.vm_guest': 'none',
            'hw.hv_vendor': 'none',
            'hw.model': 'VirtualBox',
        },
    ]
    expected

# Generated at 2022-06-23 02:09:14.415264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_host = 'freebsdtest.example.com'
    fvc = FreeBSDVirtualCollector(test_host)
    assert fvc.platform == 'FreeBSD'
    assert fvc.fact_class.platform == 'FreeBSD'
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class.platform == 'FreeBSD'
    # The class FreeBSDVirtualCollector inherits from the class VirtualCollector
    # The parentclass VirtualCollector does not have an attribute _fact_class
    assert not hasattr(VirtualCollector, '_fact_class')


# Generated at 2022-06-23 02:09:17.112687
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == FreeBSDVirtual._platform

# Generated at 2022-06-23 02:09:18.924961
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == 'FreeBSD'
    assert len(facts) == 0
    assert facts.data == {}

# Generated at 2022-06-23 02:09:20.345058
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Test if constructor raises no exception
    '''
    virtual = FreeBSDVirtual()
    assert virtual

# Generated at 2022-06-23 02:09:25.262119
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('xen', '')
    assert virtual_facts['virtualization_role'] in ('guest', '')
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:09:29.173189
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c,VirtualCollector)
    assert isinstance(c._fact_class,FreeBSDVirtual)
    assert c._platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:40.779336
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facter = FreeBSDVirtual()
    facter._module = AnsibleModuleMock()

    get_sysctl_map = {
        'kern.vm_guest': 'jail',
        'hw.hv_vendor': '',
        'security.jail.jailed': '0',
    }

    def get_sysctl(key):
        return get_sysctl_map.get(key)

    facter.get_sysctl = get_sysctl

    get_hw_model_map = {
        'OpenBSD': {
            'virtualization_tech_host': ['kvm'],
            'virtualization_tech_guest': ['openbsd'],
            'virtualization_type': 'kvm',
            'virtualization_role': 'host',
        },
    }


# Generated at 2022-06-23 02:09:46.388423
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt_facts = FreeBSDVirtual()
    virtual_facts = virt_facts.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_frame' not in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:09:47.698449
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    module = FreeBSDVirtual()
    assert module.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:51.660364
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector)
    assert isinstance(freebsd_virtual_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:09:55.189779
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_collector = FreeBSDVirtualCollector()
    assert bsd_collector.platform == 'FreeBSD'
    assert bsd_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:57.780552
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:09:58.725611
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:09.337864
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual as fv
    import sys
    import os

    # We use sys.platform for mocking platform name for
    # Python 2.6 and 2.7
    if sys.version_info[0] == 2 and sys.version_info[1] < 7:
        temp = sys.platform
        sys.platform = 'FreeBSD'
        freebsd_virtual = fv()
        sys.platform = temp
    else:
        freebsd_virtual = fv()

    virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': ''
    }

    if os.path.exists('/dev/xen/xenstore'):
        virtual_facts['virtualization_type'] = 'xen'
        virtual_

# Generated at 2022-06-23 02:10:11.177566
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({}, {})
    assert virtual_facts.platform == 'FreeBSD'


# Generated at 2022-06-23 02:10:12.378836
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual().platform == 'FreeBSD'


# Generated at 2022-06-23 02:10:14.421947
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:20.111028
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for get_virtual_facts of class FreeBSDVirtual"""
    # pylint: disable=protected-access
    vm_type = FreeBSDVirtual._get_vm_type(None)
    assert vm_type == '', "get_virtual_facts class FreeBSDVirtual should return '' when the vm_type is None"

    vm_type = FreeBSDVirtual._get_vm_type('kern.vm_guest')
    assert vm_type == 'xen', "get_virtual_facts class FreeBSDVirtual should return 'xen' when the vm_type is 'kern.vm_guest'"

    vm_type = FreeBSDVirtual._get_vm_type('hw.hv_vendor')

# Generated at 2022-06-23 02:10:26.269975
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.sysctl import FreeBSDSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    assert issubclass(FreeBSDVirtual, Virtual)
    assert issubclass(FreeBSDVirtual, FreeBSDSysctlDetectionMixin)


# Generated at 2022-06-23 02:10:37.467235
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Initialize FreeBSDVirtual class
    f_bsd_virtual = FreeBSDVirtual()

    # create a FreeBSDVirtual class object
    x = f_bsd_virtual.get_virtual_facts()

    # check if x is a dictionary
    assert (isinstance(x, dict))

    # check if virtualization_type key is present in x
    assert ('virtualization_type' in x.keys())

    # check if virtualization_role key is present in x
    assert ('virtualization_role' in x.keys())

    # check if virtualization_tech_host key is present in x
    assert ('virtualization_tech_host' in x.keys())

   