

# Generated at 2022-06-23 02:00:45.566467
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_class = FreeBSDVirtual()
    assert virtual_class.platform == 'FreeBSD'
    assert virtual_class.virtualization_type == ''
    assert virtual_class.virtualization_role == ''
    assert virtual_class.virtualization_tech_guest == set()
    assert virtual_class.virtualization_tech_host == set()
    assert virtual_class.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_class.get_virtual_facts()['virtualization_role'] == ''


# Generated at 2022-06-23 02:00:46.998570
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == "FreeBSD"


# Generated at 2022-06-23 02:00:50.294173
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(module=None)
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:00:51.448053
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:01:02.781516
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual as FV
    import json
    import tempfile
    sysctl_file = tempfile.NamedTemporaryFile(delete=False)
    sysctl_file.write(b'hw.hv_vendor: None\nhw.model: Apple Inc. Macmini5,1\nsecurity.jail.jailed: 1\nkern.vm_guest: none\n')
    sysctl_file.close()
    virtual = FV(add_path=[sysctl_file.name])
    os.remove(sysctl_file.name)
    facts = virtual.collect()

# Generated at 2022-06-23 02:01:06.528520
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual


if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:01:09.596167
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class.platform == 'FreeBSD'
    assert collector.priority == 0
    assert collector._fact_class.priority == 0

# Generated at 2022-06-23 02:01:20.250601
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test a FreeBSD guest (virtual machine)
    facts = {
        'kernel': 'FreeBSD',
        'kernel_version': '10.1-RELEASE',
        'sysctl': {
            'kern.vm_guest': 'xen',
            'security.jail.jailed': '0',
            'hw.model': 'QEMU Virtual CPU version 1.0'
        }
    }

    freebsd_virtual_fact_collector = FreeBSDVirtual(facts, None)
    facts = freebsd_virtual_fact_collector.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'xen'
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:01:24.509644
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test constructor of class FreeBSDVirtual"""
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc.__class__.__name__ == 'FreeBSDVirtualCollector'
    assert fbc._fact_class.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-23 02:01:37.900113
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_v = FreeBSDVirtual()
    # Set empty values as default
    fbsd_v.virtual_facts = {'virtualization_type': '',
                            'virtualization_role': ''}
    fbsd_v.virtual_facts['virtualization_tech_guest'] = set()
    fbsd_v.virtual_facts['virtualization_tech_host'] = set()
    fbsd_v.facts['product_name'] = 'VMware7,1'

# Generated at 2022-06-23 02:01:39.124113
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()

# Generated at 2022-06-23 02:01:39.716002
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:01:48.594124
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    test_facts = dict(virtual.get_virtual_facts())
    assert 'virtualization_role' in test_facts
    assert 'virtualization_type' in test_facts
    assert 'virtualization_type_role' in test_facts
    assert 'virtualization_type_role_lxd' not in test_facts
    assert 'virtualization_type_role_kvm' not in test_facts
    assert 'virtualization_type_role_xen' not in test_facts
    assert 'virtualization_type_role_lxc' not in test_facts
    assert 'virtualization_type_role_openvz' not in test_facts
    assert 'virtualization_type_role_zvm' not in test_facts
    assert 'virtualization_type_role_vmware' not in test_facts
   

# Generated at 2022-06-23 02:01:54.585128
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual = FreeBSDVirtual()
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {'jail'},
        'virtualization_tech_host': {'bhyve'},
    }
    assert virtual_facts == bsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:01:59.563145
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    expected = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['kvm']),
    }
    assert expected == virtual.get_virtual_facts()

# Generated at 2022-06-23 02:02:02.319027
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:05.541614
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:02:10.366135
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fb_virtual = FreeBSDVirtual(None)
    result = fb_virtual.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert result['virtualization_tech_guest'] == set([])
    assert result['virtualization_tech_host'] == set([])

    assert isinstance(result, dict)
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    print(result)


if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-23 02:02:12.854007
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None, None, None, None)
    assert isinstance(virtual_facts, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:13.782147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()


# Generated at 2022-06-23 02:02:18.386983
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ is 'FreeBSDVirtualCollector'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:19.780735
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    assert isinstance(v.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:02:23.839587
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test instantiating class FreeBSDVirtualCollector
    """
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'
    assert isinstance(fvc._platform_version, basestring)


# Generated at 2022-06-23 02:02:34.484514
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import sys
    import imp
    import os
    import shutil
    import pytest
    sys.modules.pop('ansible.module_utils.facts.virtual.freebsd', None)
    sys.modules.pop('ansible.module_utils.facts.virtual.base', None)
    sys.path.insert(0, os.path.join(os.path.dirname(
                                           __file__), '../../../'))
    module_path = os.path.join(os.path.dirname(__file__), '../../../')
    open(os.path.join(module_path, 'ansible/module_utils/facts/virtual/freebsd.py'), 'a').close()

# Generated at 2022-06-23 02:02:43.386790
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()
    # Use the method get_virtual_facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] in ('', 'xen', 'chroot', 'jail', 'kvm', 'openvz', 'uml', 'vbox', 'zvm', 'vmware', 'bhyve', 'hyperv')
    assert virtual_facts['virtualization_role'] in ('', 'guest', 'host')


# Generated at 2022-06-23 02:02:49.441586
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert FreeBSDVirtual().get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
    }

# Generated at 2022-06-23 02:02:58.616998
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    from . import VirtualFactsTestConfig

    # Creating a new instance of FreeBSDVirtual
    freebsdvirtual_instance = FreeBSDVirtual()
    # Adding values to sysctl dict
    freebsdvirtual_instance.sysctl['kern.vm_guest'] = 'none'
    freebsdvirtual_instance.sysctl['hw.hv_vendor'] = ''
    freebsdvirtual_instance.sysctl['security.jail.jailed'] = '0'

    # Adding values to the VirtualFactsTestConfig dict
    VirtualFactsTestConfig.freebsdvirtual_get_virtual_facts_expected_dict['virtualization_type'] = ''
    VirtualFactsTestConfig.freebsdvirtual_get_virtual_facts_expected_dict['virtualization_role'] = ''

    result = freebsdvirtual_instance.get_virtual_facts

# Generated at 2022-06-23 02:02:59.990306
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(),VirtualCollector)


# Generated at 2022-06-23 02:03:12.186674
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {
        'kernel': 'FreeBSD',
        'sysctl': {
            'hw.hv_vendor': 'bhyve',
            'kern.vm_guest': 'other',
            'security.jail.jailed': '0'
        },
        'kernel_version': '8.2'
    }
    virtual = FreeBSDVirtual({}, facts)
    virtual_facts = virtual.get_virtual_facts()
    assert sorted(virtual_facts['virtualization_tech_host']) == [
        'bhyve'
    ]
    assert sorted(virtual_facts['virtualization_tech_guest']) == [
        'other'
    ]
    assert virtual_facts['virtualization_type'] == 'bhyve'
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:03:18.973473
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockFact(object):
        def __init__(self, virtualization_product):
            self.virtualization_product = virtualization_product

    fact = MockFact('bhyve')

    fbsd_virtual_facts = FreeBSDVirtual()
    fbsd_virtual_facts.get_virtual_facts(fact)

    assert fbsd_virtual_facts.virtualization_type == 'bhyve'
    assert fbsd_virtual_facts.virtualization_role == 'host'

# Generated at 2022-06-23 02:03:20.562330
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.get_virtual_facts() == {}

# Generated at 2022-06-23 02:03:31.862741
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    sysctl = {
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'other',
        'security.jail.jailed': 'true'
    }

    fv = FreeBSDVirtual(sysctl=sysctl)

    assert fv.platform == 'FreeBSD'

    facts = fv.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

    assert facts['virtualization_type'] == 'other'
    assert facts['virtualization_role'] == 'guest'
    assert set(facts['virtualization_tech_host']) == set(['bhyve'])

# Generated at 2022-06-23 02:03:38.705472
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual()
    # mock the get_file_content function
    FreeBSDVirtual.get_file_content = lambda self, path: None
    assert vf.get_virtual_facts() == {}

    # mock the detect_virt_product function to detect
    FreeBSDVirtual.detect_virt_product = lambda self, sysctl: {'virtualization_type': '', 'virtualization_role': '',
                                                               'virtualization_tech_guest': set(),
                                                               'virtualization_tech_host': set()}
    assert vf.get_virtual_facts() == {}

    # mock the detect_virt_product function to detect hyperv

# Generated at 2022-06-23 02:03:40.465647
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert isinstance(fv, Virtual)



# Generated at 2022-06-23 02:03:43.743738
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = {}
    fact = FreeBSDVirtual(virt_facts)

    virt_facts_output = {
        'virtualization_type': '',
        'virtualization_role': '',
    }
    assert fact.get_virtual_facts() == virt_facts_output

# Generated at 2022-06-23 02:03:52.436943
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set()
    )
    facter_collector = FreeBSDVirtualCollector()
    assert facter_collector.get_virtual_facts() == result

# Generated at 2022-06-23 02:03:53.689608
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert FreeBSDVirtual(None).platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:04.433098
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import sys
    if sys.version_info[0] == 2:
        import mock
        builtin_open = '__builtin__.open'
    elif sys.version_info[0] == 3:
        import unittest.mock as mock
        builtin_open = 'builtins.open'

    with mock.patch(builtin_open) as mock_open:
        mock_open.return_value = mock.MagicMock(spec=file)
        handle = mock_open.return_value.__enter__.return_value
        handle.read.return_value = 'FreeBSD'

        facts_collector = FreeBSDVirtualCollector()

    # Check _fact_class
    assert facts_collector._fact_class == FreeBSDVirtual

    # Check _platform
    assert facts_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:07.050363
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtualCollector()
    v = collector.fetch_virtual_facts()
    assert not v['virtualization_role']
    assert not v['virtualization_type']

# Generated at 2022-06-23 02:04:12.237810
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
        'virtualization_type': '',
        'virtualization_role': ''
    }



# Generated at 2022-06-23 02:04:25.190736
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.sysctl = {
        'hw.hv_vendor': 'VMWare',
        'hw.model': '"Intel(R) Xeon(R) CPU E5-2690 v2 @ 3.00GHz"',
        'kern.vm_guest': 'vmware',
        'security.jail.jailed': '0'
    }
    facts = freebsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == ''
    assert 'vmware' in facts['virtualization_tech_host']
    assert 'vmware' in facts['virtualization_tech_guest']
    assert 'hv' in facts['virtualization_tech_host']
   

# Generated at 2022-06-23 02:04:26.438539
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc, VirtualCollector)

# Generated at 2022-06-23 02:04:30.605325
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual({})
    facts = f.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:04:41.961402
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    host_tech = set()
    guest_tech = set()
    # Set empty values as default
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    if os.path.exists('/dev/xen/xenstore'):
        guest_tech.add('xen')
        virtual_facts['virtualization_type'] = 'xen'
        virtual_facts['virtualization_role'] = 'guest'
    kern_vm_guest = VirtualSysctlDetectionMixin.detect_virt_product('kern.vm_guest')
    guest_tech.update(kern_vm_guest['virtualization_tech_guest'])

# Generated at 2022-06-23 02:04:42.744129
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:04:44.583529
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'
    assert virt.type == ''
    assert virt.role == ''


# Generated at 2022-06-23 02:04:46.100065
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:57.579297
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_facts = {
        'virtual_facts': {'virtualization_type': '', 'virtualization_role': ''}
    }
    facts_values = [
        (
            {'security.jail.jailed': '0'}, {'vendor': 'VirtualBox'},
        ),
        (
            {'security.jail.jailed': '0'}, {'vendor': 'VirtualBox'},
        ),
        (
            {'security.jail.jailed': '0'}, {'vendor': 'VirtualBox'},
        ),
    ]
    for facts, vendor_facts in facts_values:
        test_facts['sysctl'] = facts
        test_facts['virtual_facts'].update(vendor_facts)
        assert FreeBSDVirtual(test_facts).get_virtual_facts() == test

# Generated at 2022-06-23 02:04:58.770786
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fact = FreeBSDVirtual()
    assert fact.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:02.351549
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:04.383883
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:05:10.677539
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_type': 'freebsd-jail',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(['freebsd']),
        'virtualization_tech_guest': set(['freebsd-jail', 'freebsd']),
    }
    bsd_virtual = FreeBSDVirtual()
    result = bsd_virtual.get_virtual_facts()
    assert result == expected_virtual_facts

# Generated at 2022-06-23 02:05:15.469877
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:05:16.064826
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:05:18.084476
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fbsdvirtual = FreeBSDVirtual()
    assert fbsdvirtual._platform == 'FreeBSD'
    assert fbsdvirtual._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:05:23.731259
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = Virtual()
    assert virtual.platform == 'Generic'
    fbsd_virtual = FreeBSDVirtual(virtual)
    assert fbsd_virtual.platform == 'FreeBSD'
    assert fbsd_virtual.get_virtual_facts == FreeBSDVirtual.get_virtual_facts

# Generated at 2022-06-23 02:05:36.444470
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # To make this test we have to mock some modules
    # It is a little bit complicated, but we have to test the Virtual class
    # directly, because here are all the default values.

    # So we use some higher-order-magic:

    # We use global to save the original imports
    # As we do a recursive import, the classes are not defined at that time
    global Virtual, VirtualCollector
    # Import the classes we want to test
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector

    # Import the mocked os.path
    import test.module_utils.facts.virtual.test_freebsd_virtual_mock as mock

    # Save the original os.path
    original_os_path = Virtual.os.path

    # Set the mocked os.path as the current os.path

# Generated at 2022-06-23 02:05:39.834586
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.collect() is None

# Generated at 2022-06-23 02:05:50.937650
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsdvirt = FreeBSDVirtual({}, None)
    virtual_facts = fbsdvirt.get_virtual_facts()

    # Test Xen
    fbsdvirt.module.file_exists = lambda x: True
    virtual_facts = fbsdvirt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test FreeBSD
    fbsdvirt.module.file_exists = lambda x: False
    virtual_facts = fbsdvirt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_

# Generated at 2022-06-23 02:05:52.794244
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual()
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:57.589452
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual('freebsd', 'freebsd')
    assert virtual.platform == 'FreeBSD'
    assert virtual.type == 'freebsd'

# Unit tests for get_virtual_facts()

# Generated at 2022-06-23 02:06:01.117027
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert hasattr(v, 'platform')
    assert v.platform == FreeBSDVirtual.platform
    assert hasattr(v, 'get_virtual_facts')
    assert callable(v.get_virtual_facts)

# Generated at 2022-06-23 02:06:02.326495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    # Tested class is inherited correctly
    assert isinstance(collector, VirtualCollector)

# Generated at 2022-06-23 02:06:04.785539
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:12.556421
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    virtual._module.params = {'gather_subset': [], 'filter': '*'}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:06:13.488448
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    This method checks whether constructor returns object of class FreeBSDVirtual
    """
    assert isinstance(FreeBSDVirtual(), FreeBSDVirtual)

# Generated at 2022-06-23 02:06:17.626575
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_facts = FreeBSDVirtual({})
    facts = host_facts.get_virtual_facts()
    assert facts['virtualization_type'] in ['xen', '', None]
    assert facts['virtualization_role'] in ['guest', '', None]
#

# Generated at 2022-06-23 02:06:18.492269
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:06:29.911558
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts.

    This is how the FreeBSDVirtual class will be used, so this function
    attempts to be a unit test and example of how to use the class together.

    This test is a little more complex than most, as we are testing a few
    different ways to use the same class.  We also want to test if the class
    returns the same dictionary in different situations, so we cannot just
    check for the final result.

    If you run this test with --tb=auto, you can see the output of the
    different tests.

    """

    # If you run this test with --tb=auto, you can see the output of the
    # different tests.
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    import sys
    import os
    import tempfile


# Generated at 2022-06-23 02:06:35.840599
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Construct a new instance of FreeBSDVirtual
    v = FreeBSDVirtual({}, iter([]) )
    assert v.platform == 'FreeBSD'
    assert FreeBSDVirtual.platform == 'FreeBSD'
    assert v.get_virtual_facts() == {}


# Generated at 2022-06-23 02:06:38.855261
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v.platform == 'FreeBSD'
    assert v.fact_class == FreeBSDVirtual

# Only run when invoked directly
if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:06:45.865327
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This function attempts to detect the virtualization type of the FreeBSD
    # host, and look for the virtualization_type attribute in the resulting
    # virtual_facts variable.
    from ansible.module_utils import basic
    facts = basic.AnsibleModule(argument_spec={})
    virtual_facts_collector = FreeBSDVirtualCollector(facts=facts)
    virtual_facts = virtual_facts_collector.collect()['ansible_facts']
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:06:52.248286
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    assert issubclass(FreeBSDVirtual, Virtual)
    assert issubclass(FreeBSDVirtual, VirtualSysctlDetectionMixin)
    assert FreeBSDVirtual.platform == 'FreeBSD'

    assert FreeBSDVirtual().platform == 'FreeBSD'



# Generated at 2022-06-23 02:06:55.935397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:06:57.303797
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:58.926088
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-23 02:07:01.289690
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual({}, {})
    assert virtual.__class__.__name__ == "FreeBSDVirtual"


# Generated at 2022-06-23 02:07:12.692671
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_ret = {}
    virtual_facts_ret['virtualization_type'] = ''
    virtual_facts_ret['virtualization_role'] = ''
    virtual_facts_ret['virtualization_tech_guest'] = set()
    virtual_facts_ret['virtualization_tech_host'] = set()

    virtual_facts_sysctl = {}
    virtual_facts_sysctl['virtualization_type'] = 'xen'
    virtual_facts_sysctl['virtualization_role'] = 'guest'
    virtual_facts_sysctl['virtualization_tech_guest'] = set()
    virtual_facts_sysctl['virtualization_tech_host'] = set()

    kern_vm_guest_ret = {}
    kern_vm_guest_ret['virtualization_tech_guest'] = set()


# Generated at 2022-06-23 02:07:19.750154
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    # Testing the constructors
    assert freebsd._platform == 'FreeBSD', 'Test Failed - Constructor Failed !'
    assert freebsd.platform == 'FreeBSD', 'Test Failed - Constructor Failed !'
    assert freebsd.virtualization_type == '', 'Test Failed - Constructor Failed !'
    assert freebsd.provisioner_type == '', 'Test Failed - Constructor Failed !'

# Generated at 2022-06-23 02:07:21.665050
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts._fact_class(facts), FreeBSDVirtual)

# Generated at 2022-06-23 02:07:32.225893
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    os.environ['VIRTUAL_TYPE'] = 'FreeBSD'
    os.environ['VIRTUAL_FACT'] = 'xenU'
    fbsdvirtual = FreeBSDVirtual()
    fbsdvirtual_facts = fbsdvirtual.get_virtual_facts()
    assert (fbsdvirtual_facts['virtualization_type'], fbsdvirtual_facts['virtualization_role']) == ('xen', 'guest')
    os.environ['VIRTUAL_FACT'] = 'xenP'
    fbsdvirtual = FreeBSDVirtual()
    fbsdvirtual_facts = fbsdvirtual.get_virtual_facts()

# Generated at 2022-06-23 02:07:39.679609
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual_fact = FreeBSDVirtual()
    assert freebsd_virtual_fact.__class__.__name__ == 'FreeBSDVirtual'
    assert freebsd_virtual_fact.platform == 'FreeBSD'
    assert freebsd_virtual_fact.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-23 02:07:51.348380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    my_virtual = FreeBSDVirtual()

    if not hasattr(my_virtual, '_platform_fact_class'):
        setattr(my_virtual, '_platform_fact_class', FreeBSDVirtual)

    if not hasattr(my_virtual, '_platform'):
        setattr(my_virtual, '_platform', 'FreeBSD')

    # Test with no virtualization technology
    setattr(my_virtual, '_sysctl', {})
    setattr(my_virtual, '_platform_virtual_facts', {})

    virtual_facts = my_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:07:58.616597
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with no input
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')

    kern_vm_guest_dict = dict()
    kern_vm_guest_dict['kern.vm_guest'] = 'unknown'
    kern_vm_guest_dict['virtualization_tech_guest'] = set()
    kern_vm_guest_dict['virtualization_tech_host'] = set()

    hw_hv_vendor_dict = dict()
    hw_hv_vendor_dict['hw.hv_vendor'] = 'unknown'
    hw_hv_vendor_dict['virtualization_tech_guest'] = set

# Generated at 2022-06-23 02:08:02.847867
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:04.921146
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    class_name = FreeBSDVirtualCollector.__name__
    assert class_name == 'FreeBSDVirtualCollector'

# Generated at 2022-06-23 02:08:07.505350
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_virtual_collector = FreeBSDVirtualCollector()
    assert facts_virtual_collector._fact_class == FreeBSDVirtual
    assert facts_virtual_collector._platform == "FreeBSD"

# Generated at 2022-06-23 02:08:09.197278
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'

# Generated at 2022-06-23 02:08:12.302330
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = VirtualCollector._parse_virtual_facts(VirtualCollector.get_virtual_facts())
    assert 'FreeBSD' in virtual_facts['ansible_virtualization_type']

# Generated at 2022-06-23 02:08:17.687614
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    # Run the constructor and make sure we get our
    # expected object.
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:08:25.528919
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockModule():
        kern_vm_guest = dict(
            virtualization_tech_guest=set(['kvm']),
            virtualization_tech_host=set(['kvm']),
            virtualization_type='kvm',
            virtualization_role='host'
        )
        hw_hv_vendor = dict(
            virtualization_tech_guest=set(['vmware']),
            virtualization_tech_host=set(['vmware']),
            virtualization_type='vmware',
            virtualization_role='host'
        )

# Generated at 2022-06-23 02:08:26.418724
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.get_all() == facts.get_all_facts()

# Generated at 2022-06-23 02:08:33.910881
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert isinstance(virtual, FreeBSDVirtual)
    assert virtual.platform == 'FreeBSD'
    assert isinstance(virtual.sysctl_virtual_facts(), dict)
    assert isinstance(virtual.get_virtual_facts(), dict)
    assert virtual.get_virtual_facts()['virtualization_type'] == 'xen'
    assert virtual.get_virtual_facts()['virtualization_role'] == 'guest'
    assert virtual.get_virtual_facts()['virtualization_tech_guest'] == {'xen'}
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:08:36.261873
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual({})
    assert len(virtual_facts.get_virtual_facts()) >= 7


# Generated at 2022-06-23 02:08:42.771314
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up virt facts class
    fact_class = FreeBSDVirtual()

    # Set up expected results
    expected = {'virtualization_type': 'xen',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': {'xen'},
                'virtualization_tech_host': set()}

    # Call method get_virtual_facts of class FreeBSDVirtual
    result = fact_class.get_virtual_facts()

    # Assert if expected result equals result of get_virtual_facts of class FreeBSDVirtual
    assert(result==expected)

# Generated at 2022-06-23 02:08:52.842556
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up FreeBSDVirtual instance
    freebsd_virtual_inst = FreeBSDVirtual()
    freebsd_virtual_inst.module_name = "TestFreeBSDModule"

    # Set expected results
    expected_results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_system': '',
        'virtualization_product': '',
    }

    # Get actual results
    actual_results = freebsd_virtual_inst.get_virtual_facts()

    # Test actual results against expected results
    assert(actual_results == expected_results)



# Generated at 2022-06-23 02:08:53.675582
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert not virtual_facts['virtualization_type']

# Generated at 2022-06-23 02:08:55.606793
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()

if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-23 02:09:01.884633
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-23 02:09:03.249894
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vm = FreeBSDVirtual()
    assert vm.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:04.526578
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, VirtualCollector)

# Generated at 2022-06-23 02:09:06.073688
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual('sysname')
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-23 02:09:06.609263
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:09:08.342161
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class(virtual_collector._collector), FreeBSDVirtual)

# Generated at 2022-06-23 02:09:10.489269
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''
    Test FreeBSDVirtual class
    '''

    obj = FreeBSDVirtual()
    assert obj.platform == "FreeBSD"

# Generated at 2022-06-23 02:09:13.598776
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    x = FreeBSDVirtual()
    assert x.get_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:09:15.869172
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts is not None

if __name__ == '__main__':
    # Unit test for FreeBSDVirtual class
    virtual_facts = FreeBSDVirtual()
    print(virtual_facts.get_virtual_facts())

# Generated at 2022-06-23 02:09:17.770438
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._fact_class == FreeBSDVirtual
    assert obj._platform == 'FreeBSD'



# Generated at 2022-06-23 02:09:24.590875
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    virtual_freebsd = FreeBSDVirtual()

    # Set virtual facts
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'chroot'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = set(['chroot'])
    virtual_facts['virtualization_tech_host'] = set()

    # Check if object method get_virtual_facts returns correct value
    assert virtual_freebsd.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:09:27.494553
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector.fetch_virtual_facts()
    assert virtual.platform == 'FreeBSD'
    assert virtual.get_files() == ['/usr/sbin/sysctl', '/sbin/sysctl']

# Generated at 2022-06-23 02:09:39.174534
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Return empty dict as default
    virtual = FreeBSDVirtual()
    virtual.get_sysctl = lambda: dict(kern_vm_guest='',
            hw_hv_vendor='', security_jail_jailed='')
    virtual.get_sysctl_hwmodel = lambda: ''
    virtual.get_dmesg_virt_product = lambda: dict(virtualization_tech_host=set([]),
            virtualization_tech_guest=set([]))
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies_guest'] == set()
    assert virtual_facts['virtualization_technologies_host'] == set()

    # Return

# Generated at 2022-06-23 02:09:49.609158
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_data = {}
    bsdfact = FreeBSDVirtual(mock_data, True)
    bsdfact.detect_virt_product = (lambda sysctl:
                                   {'virtualization_type': 'xen', 'virtualization_role': 'guest'})
    bsdfact.detect_virt_vendor = lambda sysctl: {'virtualization_type': 'xen'}
    mock_data['ansible_facts'] = {'sysctl': {'kern.vm_guest': 'other'}}
    assert bsdfact.get_virtual_facts() == {'virtualization_type': 'xen',
                                           'virtualization_role': 'guest',
                                           'virtualization_technologies': ['xen']}

# Generated at 2022-06-23 02:10:00.800131
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # kern.vm_guest.pc98=0
    kern_vm_guest = {'kern.vm_guest.pc98': ['0']}
    # hw.hv_vendor.qemu=
    hw_hv_vendor = {'hw.hv_vendor.qemu': ['']}
    # security.jail.jailed=1
    sec_jail_jailed = {'security.jail.jailed': ['1']}
    # hw.model=FreeBSD virtual machine
    hw_model = {'hw.model': ['FreeBSD virtual machine']}

    # Create an object of class FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual({})

    # Call the get_virtual_facts method of FreeBSDVirtual

# Generated at 2022-06-23 02:10:02.701732
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    bsd_virtual_obj = FreeBSDVirtual()
    assert bsd_virtual_obj.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:03.256868
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:10:04.945159
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtualCollector(None, None, None)
    assert f._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:06.281638
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtualCollector().get_virtual_facts()

# Generated at 2022-06-23 02:10:09.111456
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module=None)

    assert virtual.platform == 'FreeBSD'


if __name__ == '__main__':
    test_FreeBSDVirtual()

# Generated at 2022-06-23 02:10:15.817766
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsdv = FreeBSDVirtual()
    fbsdv.populate_sysctl_virtual_facts()
    virtual_facts_dict = fbsdv.get_virtual_facts()

    assert isinstance(virtual_facts_dict, dict)
    assert virtual_facts_dict.get('virtualization_type', '') != ''
    assert virtual_facts_dict.get('virtualization_role', '') != ''
    assert virtual_facts_dict.get('virtualization_tech_guest', '') != ''
    assert virtual_facts_dict.get('virtualization_tech_host', '') != ''

# Generated at 2022-06-23 02:10:18.355004
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test FreeBSDVirtualCollector constructor
    """

    virtual = FreeBSDVirtualCollector()
    assert virtual._platform == 'FreeBSD'
    assert virtual._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:10:30.337483
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt.module_name = 'test'

    vv_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_hypervisor': '',
        'virtualization_host': '',
        'virtualization_vendor': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host' : set(),
    }

    virt.get_file_content = lambda x: None

    # Test for no virtual facts
    assert virt.get_virtual_facts() == vv_facts

    # Test for virtualization_type
    virt.get_file_content = lambda x: 'xen0'

# Generated at 2022-06-23 02:10:31.570073
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-23 02:10:36.950517
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert type(virtual_facts) == dict

    # Virtualization type
    assert type(virtual_facts['virtualization_type']) == str

    # Virtualization role
    assert type(virtual_facts['virtualization_role']) == str


# Generated at 2022-06-23 02:10:39.276766
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test the class executing all its methods
    FreeBSDVirtualCollector().collect()