

# Generated at 2022-06-23 02:00:44.073671
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert(FreeBSDVirtual({}).platform == 'FreeBSD')
    assert(FreeBSDVirtual({}).get_virtual_facts()['virtualization_type'] in [
        'xen', '', 'jail', 'bhyve', 'kvm', 'vmware', 'virtualbox', 'hyperv',
        'vbox', 'parallels', 'qemu'])

# Generated at 2022-06-23 02:00:49.792230
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Test the constructor of class FreeBSDVirtual
    """
    fbsdvl = FreeBSDVirtual()
    assert fbsdvl is not None


# Generated at 2022-06-23 02:00:55.841285
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(['non-jail']),
        'virtualization_tech_host': set(['non-host'])
    }
    f = FreeBSDVirtual()
    result = f.get_virtual_facts()
    assert result == expected_virtual_facts

# Generated at 2022-06-23 02:00:57.196311
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:01:01.766276
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).collect()
    assert facts['virtualization_role'] or facts['virtualization_type'] or \
        facts['virtualization_role'] == '' or facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:01:13.890183
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class FreeBSDVirtual '''
    facts = {}

    # Test for the case of empty values
    # Expected result:
    # facts['virtualization_type'] = ''
    # facts['virtualization_role'] = ''
    # facts['virtualization_tech_host'] = ''
    # facts['virtualization_tech_guest'] set()
    facts = FreeBSDVirtual(facts).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    # Test for the case of non-empty values
    # Expected result:
    # facts['virtualization_type'] = 'xen'
   

# Generated at 2022-06-23 02:01:17.645688
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd = FreeBSDVirtualCollector()
    assert bsd._platform == 'FreeBSD'
    assert bsd._fact_class == FreeBSDVirtual

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-23 02:01:25.630298
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    # Load a mocked class and check that the instance exists
    test_virtual = Virtual()
    test_virtual.get_virtual_facts()

    virtual_facts = test_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:01:32.830510
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert facts.get_virtual_facts() == result

# Generated at 2022-06-23 02:01:44.146055
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test
    Test method FreeBSDVirtual.get_virtual_facts
    """
    # Create a FreeBSDVirtual object
    freebsdvirtual = FreeBSDVirtual()
    # We do not have detailed FreeBSD virtualisation facts, so we pass
    # a Python dictionary as as argument for freebsdvirtual_facts.
    # The response of python dictionary contains:
    # 'virtualization_type': '',
    # 'virtualization_role': '',
    # 'virtualization_tech_guest': '',
    # 'virtualization_tech_host': ''
    freebsdvirtual_facts = {}

    # Call method get_virtual_facts
    freebsdvirtual_facts = freebsdvirtual.get_virtual_facts()
    assert freebsdvirtual_facts is not None

# Generated at 2022-06-23 02:01:49.141003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd = FreeBSDVirtualCollector()
    assert bsd.platform == 'FreeBSD'
    assert bsd._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:01:51.944356
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:01:53.784366
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual({}, {})
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-23 02:01:57.475153
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test for constructor of class FreeBSDVirtual'''
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_virtual_facts()
    print(virtual_facts)

# Generated at 2022-06-23 02:02:05.640883
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual is not None
    # Assert that the working directory is set to the system root directory
    assert freebsd_virtual.ROOT_DIR == '/'

# Unit test that empty sets are set as default virtualization_type
# and virtualization_role

# Generated at 2022-06-23 02:02:06.687055
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:10.366708
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual()
    assert freebsd_virtual
    assert freebsd_virtual.virtualization_type == ''
    assert freebsd_virtual.virtualization_role == ''
    assert freebsd_virtual.virtualization_tech_host == set()
    assert freebsd_virtual.virtualization_tech_guest == set()
    assert freebsd_virtual.platform == freebsd_virtual.platform

# Generated at 2022-06-23 02:02:13.622767
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()
    facts = f.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert len(facts['virtualization_tech_guest']) == 0
    assert len(facts['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:02:18.776672
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual
    assert isinstance(virtual, FreeBSDVirtualCollector)
    assert isinstance(virtual._fact_class, FreeBSDVirtual)
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:21.282857
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vfacts = FreeBSDVirtual().get_virtual_facts()
    print(vfacts)

if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:02:22.655022
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bvc = FreeBSDVirtualCollector()
    assert bvc.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:23.710315
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual is not None

# Generated at 2022-06-23 02:02:25.729847
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    obj = FreeBSDVirtual()
    assert VirtualSysctlDetectionMixin in obj.__class__.__bases__

# Generated at 2022-06-23 02:02:30.829236
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    x = FreeBSDVirtual()
    vf = x.get_virtual_facts()
    assert vf['virtualization_type'] != ''
    assert vf['virtualization_role'] != ''
    if 'virtualization_tech_guest' in vf:
        assert vf['virtualization_tech_guest'] != set()
    if 'virtualization_tech_host' in vf:
        assert vf['virtualization_tech_host'] != set()

# Generated at 2022-06-23 02:02:33.630135
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd = FreeBSDVirtual()
    assert freebsd.platform == 'FreeBSD'

# Generated at 2022-06-23 02:02:36.023529
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Testing constructor of FreeBSDVirtualCollector class"""
    fr = FreeBSDVirtualCollector()
    assert fr._platform == 'FreeBSD'
    assert isinstance(fr._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:02:38.014844
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    result = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-23 02:02:49.590678
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virt = FreeBSDVirtual({})

    freebsd_virt._get_sysctl = lambda x: '1'

    freebsd_facts = freebsd_virt.get_virtual_facts()
    assert freebsd_facts['virtualization_type'] == 'xen'
    assert freebsd_facts['virtualization_role'] == 'guest'
    assert set(freebsd_facts['virtualization_tech_guest']) == set(['xen'])
    assert set(freebsd_facts['virtualization_tech_host']) == set([])

    freebsd_virt._get_sysctl = lambda x: 'None'
    freebsd_facts = freebsd_virt.get_virtual_facts()
    assert freebsd_facts['virtualization_type'] == ''
    assert freebs

# Generated at 2022-06-23 02:02:53.095167
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    expected = {'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()}

    assert v.get_virtual_facts() == expected

# Generated at 2022-06-23 02:02:59.027698
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = {
        'virtual': 'physical',
        'virtualization_type': 'physical',
        'virtualization_role': '',
        'virtualization_technology_guest': set(),
        'virtualization_technology_host': set(),
    }

    # Test default
    freebsd_virtual = FreeBSDVirtual({})
    assert freebsd_virtual.get_facts() == facts

    # Test with a specific platform
    freebsd_virtual = FreeBSDVirtual({}, platform="FreeBSD")
    assert freebsd_virtual.get_facts() == facts

# Generated at 2022-06-23 02:03:11.345244
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    vt = FreeBSDVirtual({})
    assert vt.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    # No sysctl
    vt = FreeBSDVirtual({'sysctl': {}})
    assert vt.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    # KVM (virtio) host

# Generated at 2022-06-23 02:03:16.845425
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    fv = FreeBSDVirtual({})
    assert fv.platform == 'FreeBSD'
    assert fv.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:03:20.023926
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facter = FreeBSDVirtual({})
    facter.collect_facts()
    facts = facter.get_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:03:23.604351
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_collector = FreeBSDVirtualCollector()
    assert fv_collector._platform == 'FreeBSD'
    assert fv_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:03:26.105629
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:03:33.813369
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test case 1
    # kern.vm_guest returns: 'none'
    # hw.model returns: 'VirtualBox'
    # security.jail.jailed returns: '0'
    test_case_1 = {
        'FreeBSD': {
            'kern_vm_guest_none': 'none',
            'hw_model_virtualbox': 'VirtualBox',
            'sec_jail_jailed': '0',
        },
        'expected_results': {
            'virtualization_type': 'virtualbox',
            'virtualization_role': '',
            'virtualization_tech_guest': set(['virtualbox']),
            'virtualization_tech_host': set([])
        }
    }

    # Test case 2
    # kern.vm_guest returns: 'none'

# Generated at 2022-06-23 02:03:44.040519
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an instance of FreeBSDVirtual
    test_virtual_facts_inst = FreeBSDVirtual()

    # Set kern.vm_guest to VMWare
    test_virtual_facts_inst.detect_virt_product = lambda x: {'virtualization_tech_guest': {'vmware'}, 'virtualization_tech_host': {'vmware'}}

    # Set hw.model to VMWare
    test_virtual_facts_inst.detect_virt_vendor = lambda x: {'virtualization_tech_guest': {'vmware'}, 'virtualization_tech_host': {'vmware'}}

    # Call method get_virtual_facts
    facts = test_virtual_facts_inst.get_virtual_facts()

    assert facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-23 02:03:51.420959
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact = 'virtualization_type'
    facts = {fact: 'FreeBSD'}
    collector = FreeBSDVirtualCollector(facts=facts)
    assert collector._platform == 'FreeBSD'


# Generated at 2022-06-23 02:03:52.872279
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.get_virtual_facts()


# Generated at 2022-06-23 02:03:56.092961
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.virtualization_type == '', 'Test Failed on FreeBSDVirtual.virtualization_type'
    assert virtual_facts.virtualization_role == '', 'Test Failed on FreeBSDVirtual.virtualization_role'

# Generated at 2022-06-23 02:04:07.149322
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Examples of sysctl strings for different hypervisors
    hypervisor = [
        # KVM
        'QEMU Virtual CPU version (cpu64-rhel6)',
        # VirtualBox
        'VirtualBox',
        # VMware
        'VMware Virtual Platform',
        # Unknown
        'Unknown',
        # None
        None,
    ]
    # Examples of sysctl strings for different virtualization types
    virtualization_type = [
        # Container
        'jail',
        # Paravirtualization
        'xen',
        # Hardware virtualization
        'hvm',
        # Unknown
        'Unknown',
        # None
        None,
    ]
    # Examples of sysctl strings for different virtualization roles

# Generated at 2022-06-23 02:04:13.867953
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v_facts = FreeBSDVirtual({})
    facts = v_facts.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen', 'xen-dom0'])
    assert facts['virtualization_tech_host'] == set(['xen', 'xen-dom0'])

# Generated at 2022-06-23 02:04:18.093349
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test class FreeBSDVirtualCollector"""
    fbvc = FreeBSDVirtualCollector()
    assert fbvc.platform == 'FreeBSD'
    assert fbvc._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:04:23.028472
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mocked_virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(['xen'])
    }

    # Mock class attributes
    def get_sysctl(key):
        return {'kern.vm_guest': 'xen'}[key]

    def os_path_exists(path):
        return path == '/dev/xen/xenstore'

    # Mock Virtual class attributes
    Virtual.get_sysctl = get_sysctl
    Virtual.os_path_exists = staticmethod(os_path_exists)

    virtual = FreeBSDVirtual()
    assert virtual.get_virtual_facts() == mocked_virtual_facts

# Generated at 2022-06-23 02:04:27.957336
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)
    assert isinstance(fv, VirtualCollector)
    assert isinstance(fv, object)
    assert fv._platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:04:33.195224
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:04:41.756364
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    xmlstr = open("unit/modules/utils/facts/virtual/xml/freebsd.xml", "r").read()
    virt = FreeBSDVirtual(xmlstr)
    assert virt.facts['virtualization_tech_guest'] == set(['xen'])
    assert virt.facts['virtualization_tech_host'] == set([])
    assert virt.facts['virtualization_type'] == 'xen'
    assert virt.facts['virtualization_role'] == 'guest'
    assert virt.facts['virtualization_product_name'] == 'xen'
    assert virt.facts['virtualization_product_version'] == '4.4.4'

# Generated at 2022-06-23 02:04:43.877375
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:04:45.770710
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    freebsd_virtual = FreeBSDVirtual(None)
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:47.461256
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector._platform
    assert result == 'FreeBSD'

# Generated at 2022-06-23 02:04:52.484278
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts_module = FreeBSDVirtual()
    assert virtual_facts_module.platform == 'FreeBSD'
    virtual_facts = virtual_facts_module.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:04:54.395445
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:04:55.991840
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bfc = FreeBSDVirtualCollector()
    assert isinstance(bfc, FreeBSDVirtualCollector)


# Generated at 2022-06-23 02:04:58.947679
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    '''Unit test constructor of class FreeBSDVirtual'''
    freebsd_virtual_obj = FreeBSDVirtual(None, None)
    assert freebsd_virtual_obj is not None


# Generated at 2022-06-23 02:05:10.677579
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts import collector

    path = os.path.realpath(__file__)
    sys.modules['ansible.module_utils.facts.virtual.sysctl'] = VirtualSysctlDetectionMixin

    # 'security.jail.jailed' defined
    context = collector.VirtualContext(path, dict(
        security_jail_jailed=1,
        hw_hv_vendor='bhyve',
        kern_vm_guest='',
    ))
    facts = FreeBSDVirtual().get_virtual_facts(context)
    assert facts['virtualization_type'] == 'jail'
    assert 'virtualbox' in facts['virtualization_tech_host']

    # 'kern.vm_guest' defined

# Generated at 2022-06-23 02:05:12.077675
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual({})
    assert v.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:16.061802
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    assert issubclass(FreeBSDVirtual, Virtual)
    assert issubclass(FreeBSDVirtual, VirtualSysctlDetectionMixin)
    assert FreeBSDVirtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:17.187000
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    f = FreeBSDVirtual({})
    assert f.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:19.409266
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:23.101701
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c._platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual
    assert c._fact_class().platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:26.090147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f_input_validate_class = FreeBSDVirtualCollector()
    assert f_input_validate_class.__class__.__name__ == 'FreeBSDVirtualCollector'


# Generated at 2022-06-23 02:05:27.556314
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-23 02:05:33.200695
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, VirtualCollector)
    assert isinstance(f._fact_class, FreeBSDVirtual)
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:34.902932
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:05:38.082045
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None)
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:05:43.777734
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtual()
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])


# Generated at 2022-06-23 02:05:45.471507
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f1 = FreeBSDVirtualCollector()
    assert isinstance(f1, VirtualCollector)

# Generated at 2022-06-23 02:05:47.005708
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert 'FreeBSD' == v.platform

# Generated at 2022-06-23 02:05:49.251947
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual(None, None, None, None)
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-23 02:05:51.366801
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:05:55.910797
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual


# Generated at 2022-06-23 02:05:58.658228
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert isinstance(x, VirtualCollector)
    assert isinstance(x, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:06:02.062800
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class.__name__ == 'FreeBSDVirtual'
    assert collector.fact_class.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:03.322727
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert VirtualCollector._get_platform_fact_class('FreeBSD') == FreeBSDVirtualCollector

# Generated at 2022-06-23 02:06:04.476905
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(module)
    assert virtual.get_virtual_facts()

# Generated at 2022-06-23 02:06:16.402407
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # When FreeBSDVirtual.get_virtual_facts() is called and virtualization_tech_guest is xen
    # Then assert that the correct virtualization_type and virtualization_role is returned
    virt_data = {
        'virtualization_tech_guest': {
            'xen',
        },
    }

    expected_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {
            'xen',
        },
    }
    fv = FreeBSDVirtual(virt_data)
    assert fv.get_virtual_facts() == expected_facts

    # When FreeBSDVirtual.get_virtual_facts() is called and virtualization_tech_guest is kvm
    # Then

# Generated at 2022-06-23 02:06:27.905059
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import Collector

    def collect_sysctl(module_name, sysctl_name, values, platform):
        return [values]
    Collector.collect_sysctl = collect_sysctl

    def collect_file(module_name, file_name, platform):
        return ['']
    Collector.collect_file = collect_file

    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.collect_sysctl = Collector.collect_sysctl
    freebsd_virtual.collect_file = Collector.collect_file


# Generated at 2022-06-23 02:06:40.591538
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    fake_sysctl_return_value = {
        'kern.vm_guest': '',
        'hw.hv_vendor': '',
        'security.jail.jailed': 0,
        'hw.model': '',
    }
    freebsd_virtual.get_sysctl_virt_facts = lambda x: fake_sysctl_return_value[x]
    freebsd_virtual.get_model_virt_facts = lambda: {}

    # Check empty facts
    assert freebsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Check xen

# Generated at 2022-06-23 02:06:41.412451
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:42.433211
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-23 02:06:46.233110
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_facts = FreeBSDVirtual()
    virtual_facts.get_virtual_facts()
    assert type(virtual_facts.virtual_facts) is dict, \
        "test_FreeBSDVirtual: __init__ method failed"

# Generated at 2022-06-23 02:06:49.005589
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert virtual_facts['virtualization_type']
    assert virtual_facts['virtualization_role']

# Generated at 2022-06-23 02:06:51.147912
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector is not None
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-23 02:06:52.601322
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:54.293582
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-23 02:06:56.926470
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc._fact_class, FreeBSDVirtual)
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-23 02:06:58.970435
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, FreeBSDVirtualCollector)

# Generated at 2022-06-23 02:07:04.574790
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()

    assert facts['virtualization_type'] in ['xen']
    assert facts['virtualization_role'] in ['guest']
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:07:09.756636
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Success case
    virtual_facts = {'virtualization_type': '', 'virtualization_role': ''}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual = FreeBSDVirtual()
    tech_fact = virtual._get_virtual_facts()
    assert virtual_facts == tech_fact

# Generated at 2022-06-23 02:07:13.530895
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {'kernel': 'FreeBSD'}
    # Needs a mocked object
    obj = FreeBSDVirtual(module=MockModule(facts=facts))
    result = obj.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'



# Generated at 2022-06-23 02:07:18.310963
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual(None, None, None, {}).get_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:07:22.598558
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtualCollector()
    virtual_facts = v.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_facts_from_sysctl' in virtual_facts

# Generated at 2022-06-23 02:07:24.541114
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-23 02:07:26.706024
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual['virtualization_type'] == 'xen' or ''

# Generated at 2022-06-23 02:07:30.812215
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual._platform, str)
    assert isinstance(freebsd_virtual._fact_class, object)
    assert hasattr(freebsd_virtual._fact_class, 'get_virtual_facts')

# Generated at 2022-06-23 02:07:32.398330
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.platform == 'FreeBSD'
    assert virtual.guest_tech == set()
    assert virtual.host_tech == set()



# Generated at 2022-06-23 02:07:38.387702
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    virtual_facts = virtual.get_virtual_facts()

    assert type(virtual_facts['virtualization_tech_guest']) is set
    assert type(virtual_facts['virtualization_tech_host']) is set
    assert type(virtual_facts['virtualization_type']) is str
    assert type(virtual_facts['virtualization_role']) is str

# Generated at 2022-06-23 02:07:42.228568
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    """
    Test FreeBSDVirtual constructor
    """
    virtual_bsd = FreeBSDVirtual(None)
    assert virtual_bsd.platform == 'FreeBSD'
    assert virtual_bsd.product_name == ''
    assert virtual_bsd.product_version == ''


# Generated at 2022-06-23 02:07:46.989167
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual(None)
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:07:49.345280
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    _facts = FreeBSDVirtual(None, None).get_virtual_facts()
    assert isinstance(_facts, dict)

# Generated at 2022-06-23 02:07:51.923534
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert( fvc._fact_class == FreeBSDVirtual )
    assert( fvc._platform == 'FreeBSD' )


# Generated at 2022-06-23 02:07:54.473608
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:07:59.050619
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None).get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:08:10.606178
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup
    # Instantiate object
    freebsd_virtual = FreeBSDVirtual()

    # Setup mocks that are used as setters in old style Python classes.
    # They aren't needed in this test so they're empty.
    def mock_detect_virt_product(*args, **kwargs):
        return {}

    def mock_detect_virt_vendor(*args, **kwargs):
        return {}

    freebsd_virtual.detect_virt_product = mock_detect_virt_product
    freebsd_virtual.detect_virt_vendor = mock_detect_virt_vendor


# Generated at 2022-06-23 02:08:13.429459
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj._fact_class, FreeBSDVirtual)

# Generated at 2022-06-23 02:08:14.593156
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    print(FreeBSDVirtual())

# Generated at 2022-06-23 02:08:17.947317
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual({})
    assert facts.platform == 'FreeBSD'



# Generated at 2022-06-23 02:08:25.654299
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockSysctl(object):
        def __init__(self, value):
            self._value = value

        def __call__(self, key):
            return self._value

        def __str__(self):
            return self._value

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self, module):
            self.module = module

        def get_file_content(self, path):
            return ''

        def detect_virt_product(self, key):
            if key == 'kern.vm_guest':
                return {'virtualization_tech_guest': ['vmware'],
                        'virtualization_tech_host': ['vmware']}

# Generated at 2022-06-23 02:08:27.247248
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Unit test for class FreeBSDVirtualCollector
    '''
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert hasattr(obj, '_fact_class') and obj._fact_class
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:30.491349
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():

    virtual = FreeBSDVirtual()

    # Test empty initialization
    # We expect empty dicts {}
    assert virtual.facts == {}
    assert virtual.sysctl_facts == {}
    assert virtual.vendor_facts == {}

# Generated at 2022-06-23 02:08:42.178871
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Beginning of the section with facts:
    # These facts are the output of the command "sysctl -a", which has been
    # parsed.
    kern_vm_guest = {
        'kern.vm_guest': 'xen',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'xen',
        'virtualization_role': 'guest'
    }
    hw_hv_vendor = {
        'hw.hv_vendor': 'bhyve',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'bhyve'},
        'virtualization_type': '',
        'virtualization_role': ''
    }
    sec

# Generated at 2022-06-23 02:08:44.862396
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:08:56.026311
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test if virtual_facts is set to default if no files
    # exists which could determine virtualization
    test_facts = FreeBSDVirtual({})
    test_facts.is_file = lambda s: False
    virtual_facts = test_facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 0

    # Test if virtual_facts is set to empty values if given
    # files exist but don't contain expected values
    test_facts = FreeBSDVirtual({})
    test_facts.is_file = lambda s: True
    test_facts.get_file_content = lambda s: ''
    virtual

# Generated at 2022-06-23 02:09:07.630981
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    frbsdvrt = FreeBSDVirtual()
    # Fake a set of sysctl values
    frbsdvrt.sysctl = {
        'kern.vm_guest': '',
        'hw.hv_vendor': '',
        'security.jail.jailed': '0',
        'hw.model': '',
    }
    # Fake the path where xenstore is located
    frbsdvrt.paths = ['/dev/xen/xenstore']
    virtual_facts = frbsdvrt.get_virtual_facts()
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:09:10.449051
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class is FreeBSDVirtual
    assert freebsd_virtual_collector._platform is 'FreeBSD'

# Generated at 2022-06-23 02:09:13.020360
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual = FreeBSDVirtual()
    assert virtual.platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:23.761880
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is the output of sysctl -n hw.model
    hw_model = 'Genuine Intel(R) CPU          T2080  @ 1.73GHz'
    # This is the output of sysctl -n kern.vm_guest
    kern_vm_guest = 'vmware'
    # test_FreeBSDVirtual_get_virtual_facts dict
    virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_guest': ['vmware', 'vmware'],
        'virtualization_tech_host': [],
        'virtualization_product_name': 'vmware',
    }
    # mocked modules
    module = type('FreeBSD', (object,), dict(params=dict()))
    module.get

# Generated at 2022-06-23 02:09:24.992149
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    v = FreeBSDVirtualCollector().collect()
    assert(isinstance(v, dict))

# Generated at 2022-06-23 02:09:29.400158
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    facts['system'] = dict()
    facts['system']['kernel'] = 'FreeBSD'
    collector = FreeBSDVirtualCollector(None, facts, None)
    virtual_facts = collector.collect()
    assert virtual_facts['virtualization_type'] == 'None'
    assert virtual_facts['virtualization_role'] == 'None'

# Generated at 2022-06-23 02:09:33.368320
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert(fv.platform == "FreeBSD")
    assert(fv.fact_class == fv._fact_class)
    assert(isinstance(fv._fact_class("fake"), Virtual))


# Generated at 2022-06-23 02:09:35.095052
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    facts = FreeBSDVirtual()
    assert facts._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:36.018216
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._platform == 'FreeBSD'

# Generated at 2022-06-23 02:09:47.360127
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)

    # Test without any virtualization
    virtual.kern_vm_guest = {}
    virtual.hw_hv_vendor = {}
    virtual.sec_jail_jailed = {}
    virtual.hw_model = {}

    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

    # Test Xen Dom0
    virtual.hw_hv_vendor = {'virtualization_role': 'host', 'virtualization_type': 'xen'}
    facts = virtual.get_virtual_facts()

# Generated at 2022-06-23 02:09:58.941845
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual({}, {}, {}, [])

    virt.tech_to_type = {
        'jail': 'BSD Jail',
        'qemu': 'QEMU',
        'kvm': 'KVM',
        'bhyve': 'Bhyve',
        'parallels': 'Parallels',
        'xen': 'Xen',
    }
    virt.tech_to_role = {
        'jail': 'guest',
    }

# Generated at 2022-06-23 02:10:01.530573
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc_object = FreeBSDVirtualCollector()
    assert vc_object.platform == 'FreeBSD'
    assert vc_object._fact_class == FreeBSDVirtual

# Generated at 2022-06-23 02:10:12.057573
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import unittest
    import sys
    import os

    # We need to add the directory of the VirtualCollector module to the path
    # to be able to import it
    try:
        sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    except NameError:
        sys.path.append('.')

    from FreeBSDVirtual import FreeBSDVirtual

    class TestFreeBSDVirtualFacts(unittest.TestCase):
        def setUp(self):
            self.virtual_facts = FreeBSDVirtual()

        def test_freebsd_virtual_facts(self):
            self.assertEqual(self.virtual_facts.platform, 'FreeBSD')
            facts = self.virtual_facts.get_all_facts()
            self.assertTrue(facts)

# Generated at 2022-06-23 02:10:15.817774
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual()
    testobj.sysctl = {'kern.vm_guest': 'other', 'hw.hv_vendor': 'other',
        'security.jail.jailed': '1'}
    virtual_facts = testobj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'

# Generated at 2022-06-23 02:10:20.159338
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This should fail without FreeBSDVirtual:
    v = Virtual('')
    try:
        v.get_virtual_facts()
    except Exception:
        pass
    else:
        raise Exception("Expected Exception")
    # This should work with FreeBSDVirtual:
    f = FreeBSDVirtual('')
    f.get_virtual_facts()

# Generated at 2022-06-23 02:10:21.911499
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)


# Generated at 2022-06-23 02:10:26.144233
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virt = FreeBSDVirtual()
    assert virt.platform == 'FreeBSD'
    assert virt.product_name is None
    assert virt.product_version is None
    assert virt.product_serial is None


# Generated at 2022-06-23 02:10:27.723949
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    virtual_obj = FreeBSDVirtual()
    assert virtual_obj.platform == 'FreeBSD'


# Generated at 2022-06-23 02:10:32.659841
# Unit test for constructor of class FreeBSDVirtual
def test_FreeBSDVirtual():
    vc = FreeBSDVirtual(module=None)
    assert vc.platform == 'FreeBSD'
    assert vc.guest_tech == {}
    assert vc.host_tech == {}
    assert vc.kern_vm_guest == {}
    assert vc.hw_hv_vendor == {}


# Generated at 2022-06-23 02:10:39.670634
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.get_virtual_facts()

    assert isinstance(facts, dict)
    for k in [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ]:
        assert k in facts
        assert isinstance(facts[k], (str, set))