

# Generated at 2022-06-25 00:54:39.645221
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:42.376711
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class.__name__ == 'FreeBSDVirtual'


# Generated at 2022-06-25 00:54:46.382917
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:54:52.383918
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    #
    # Case 1
    #
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_0.collect()
    assert free_b_s_d_virtual_collector_0.fact_class._platform == 'FreeBSD'


# Generated at 2022-06-25 00:54:54.900309
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 00:55:00.802686
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:06.795161
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert 'FreeBSD' == free_b_s_d_virtual_collector_0._platform, "free_b_s_d_virtual_collector_0._platform != 'FreeBSD'"
    assert FreeBSDVirtual == free_b_s_d_virtual_collector_0._fact_class, "free_b_s_d_virtual_collector_0._fact_class != FreeBSDVirtual"

# Generated at 2022-06-25 00:55:11.688418
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
  assert free_b_s_d_virtual_collector_0.get_all_facts() == {
                'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
            }



# Generated at 2022-06-25 00:55:16.205745
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:18.832608
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:23.804740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:27.214707
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:32.748230
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  float_0 = 5800.0
  free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
  int_0 = free_b_s_d_virtual_collector_0.has_sysctl_support()


# Generated at 2022-06-25 00:55:34.692935
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert callable(FreeBSDVirtual.get_virtual_facts)


# Generated at 2022-06-25 00:55:43.381837
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_tech = {'xen', 'vmware'}
    guest_tech = {'xen', 'vmware'}
    virtual_facts = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_host': host_tech, 'virtualization_tech_guest': guest_tech}
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.detect_virt_product = test_case_0
    free_b_s_d_virtual_0.detect_virt_vendor = test_case_0
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == virtual_facts


# Generated at 2022-06-25 00:55:46.519192
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 3062.0
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0.get_all_facts()


# Generated at 2022-06-25 00:55:48.315552
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:52.315381
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 3062.0
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:55:57.362447
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 3062.0
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:55:59.798634
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:56:09.947808
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:11.360606
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:18.817017
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO: Failure test
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Test for sysctl_product_dict
    found_products = set(virtual_facts.keys())
    required_products = {'virtualization_technology', 'virtualization_role', 'virtualization_type'}
    found_products_diff = found_products - required_products
    required_products_diff = required_products - found_products
    if found_products_diff != set():
        print('Invalid virtualization products found: {}'.format(', '.join(found_products_diff)))
    if required_products_diff != set():
        print('Missing required virtualization products: {}'.format(', '.join(required_products_diff)))

    # Test for virtualization_technology
    found_technologies = virtual_facts['virtualization_technology']


# Generated at 2022-06-25 00:56:25.025703
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class._platform == 'FreeBSD'
    assert VirtualCollector._platform == 'Base'

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:26.664671
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:32.240308
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Empty hw_model
    test_virtual_facts = FreeBSDVirtual({'hw_model': ''})
    expect_virtual_facts = {'virtualization_type': '',
                            'virtualization_role': '',
                            'virtualization_tech_guest': set(),
                            'virtualization_tech_host': set()}
    assert test_virtual_facts.get_virtual_facts() == expect_virtual_facts
    test_virtual_facts = FreeBSDVirtual({'hw_model': 'VMware Virtual Platform'})
    expect_virtual_facts['virtualization_type'] = 'VMware'
    assert test_virtual_facts.get_virtual_facts() == expect_virtual_facts

    test_virtual_facts = FreeBSDVirtual({'sysctl': {'kern.vm_guest': 'vmware'}})
    assert test

# Generated at 2022-06-25 00:56:37.907923
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    free_b_s_d_virtual.get_virtual_facts()



# Generated at 2022-06-25 00:56:39.799553
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass  # Nothing to test

# Generated at 2022-06-25 00:56:41.199808
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:46.667206
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)

# Generated at 2022-06-25 00:57:08.070242
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector() is not None, 'Failed to create FreeBSDVirtualCollector instance.'


# Generated at 2022-06-25 00:57:08.632207
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 00:57:13.308483
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    return (var_1)



# Generated at 2022-06-25 00:57:14.745043
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert type(free_b_s_d_virtual_collector_0) is FreeBSDVirtualCollector


# Generated at 2022-06-25 00:57:20.852850
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:24.483259
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:57:27.472553
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:35.186262
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.facts['virtualization_type'] == 'xen'
    assert free_b_s_d_virtual_collector_0.facts['virtualization_role'] == 'guest'
    assert free_b_s_d_virtual_collector_0.facts['virtualization_technologies_guest'] == {'freebsd-jail'}
    assert free_b_s_d_virtual_collector_0.facts['virtualization_technologies_host'] == {'freebsd-jail', 'freebsd-bhyve'}


# Generated at 2022-06-25 00:57:37.268335
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freeBSDVirtualCollector1 = FreeBSDVirtualCollector()
    assert isinstance(freeBSDVirtualCollector1, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:57:40.934059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:58:15.983105
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector(None)
    assert var_1._fact_class == FreeBSDVirtual
    assert var_1._platform == 'FreeBSD'


# Generated at 2022-06-25 00:58:18.483316
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Assumptions
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 00:58:19.394520
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:28.651773
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Call the constructor of class FreeBSDVirtualCollector
    # Assert the attribute '_fact_class' of class FreeBSDVirtualCollector is equal to 'FreeBSDVirtual'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    # Assert the attribute '_platform' of class FreeBSDVirtualCollector is equal to 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:58:33.236403
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert (free_b_s_d_virtual_collector_1._fact_class == FreeBSDVirtual)
    assert (free_b_s_d_virtual_collector_1._platform == 'FreeBSD')


# Generated at 2022-06-25 00:58:34.100542
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert test_case_0() is None



# Generated at 2022-06-25 00:58:36.356547
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # No input value, return an instance of class FreeBSDVirtualCollector
    var_1 = FreeBSDVirtualCollector()
    assert type(var_1) == FreeBSDVirtualCollector


# Generated at 2022-06-25 00:58:40.847003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_1.platform == 'FreeBSD'


# Generated at 2022-06-25 00:58:43.375380
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:58:45.120564
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:56.154229
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except:
        print("test_FreeBSDVirtualCollector: FAIL - Constructor of class FreeBSDVirtualCollector fails")
    else:
        print("test_FreeBSDVirtualCollector: PASS - Constructor of class FreeBSDVirtualCollector works")



# Generated at 2022-06-25 01:00:00.464342
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert FreeBSDVirtual().get_virtual_facts() == {"virtualization_type": "", "virtualization_role": "", "virtualization_tech_host": set(), "virtualization_tech_guest": set()}

# Generated at 2022-06-25 01:00:05.332931
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)
# Test for method of class FreeBSDVirtualCollector

# Generated at 2022-06-25 01:00:07.569716
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # this executes a whole bunch of code that I don't know how to otherwise avoid
    var_0 = test_case_0()
    assert var_0 is None

# Generated at 2022-06-25 01:00:11.350517
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual.get_virtual_facts()
    print(var_1)

# Generated at 2022-06-25 01:00:13.677866
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:00:16.189014
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_3 = isinstance(free_b_s_d_virtual_collector_0, free_b_s_d_virtual_collector_0.__class__)
    assert var_3 == True


# Generated at 2022-06-25 01:00:18.372199
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:00:25.426147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_1._fact_class
    var_1 = free_b_s_d_virtual_collector_1._platform
    free_b_s_d_virtual_collector_2 = FreeBSDVirtualCollector()
    var_2 = free_b_s_d_virtual_collector_2._fact_class
    var_3 = free_b_s_d_virtual_collector_2._platform
    assert var_0 == 'FreeBSDVirtual'
    assert var_1 == 'FreeBSD'
    assert var_2 == 'FreeBSDVirtual'
    assert var_3 == 'FreeBSD'


# Generated at 2022-06-25 01:00:27.160503
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert(not os.path.exists("ansible_facts/virtual/__init__.py"))


# Generated at 2022-06-25 01:03:01.814005
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 01:03:05.324740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True


# Generated at 2022-06-25 01:03:11.461898
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector.sysctl = {'kern.vm_guest': 'other virtualized guest', 'hw.hv_vendor': 'ax2', 'security.jail.jailed': '0', 'hw.model': 'VMware Virtual Platform'}
    free_b_s_d_virtual_collector.dmi = {'system-product-name': 'VirtualBox'}
    expected = {'virtualization_role': 'guest', 'virtualization_type': 'virtualbox', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'kvm', 'virtualbox'}}
    actual = free_b_s_d_virtual_collector.get_virtual_facts()


# Generated at 2022-06-25 01:03:18.733160
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_role': '',
                     'virtualization_type': '',
                     'virtualization_tech_host': set(),
                     'virtualization_tech_guest': set()}
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert virtual_facts == free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:03:21.543909
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:03:29.660927
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # get_virtual_facts() tests
    #
    # Test with no virtualization facts
    free_b_s_d_virtual_0 = FreeBSDVirtual(dict())

    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1['virtualization_type'] ==  ''
    assert var_1['virtualization_role'] ==  ''
    assert var_1['virtualization_tech_guest'] ==  set([])
    assert var_1['virtualization_tech_host'] ==  set([])

    # Test with xen virtualization facts
    free_b_s_d_virtual_1 = FreeBSDVirtual(dict(hw_model = 'Xen HVM domU'))

    var_1 = free_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:03:35.233927
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test 1
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    test_0 = free_b_s_d_virtual_collector_0.virtual.detect_virt_vendor('hw.model')
    test_1 = free_b_s_d_virtual_collector_0.virtual.detect_virt_product('kern.vm_guest')
    assert test_0['virtualization_type'] == '' and test_1['virtualization_type'] == ''

# Generated at 2022-06-25 01:03:38.729230
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform is 'FreeBSD'


# Generated at 2022-06-25 01:03:43.607039
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test the case where all properties are undefined.
    test_case_0()


if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:03:48.394100
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    current_inst = FreeBSDVirtual()
    current_inst.get_virtual_facts()
