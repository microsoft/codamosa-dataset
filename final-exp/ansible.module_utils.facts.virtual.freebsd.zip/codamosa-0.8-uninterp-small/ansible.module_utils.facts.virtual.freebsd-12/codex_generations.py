

# Generated at 2022-06-25 00:54:39.704582
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector)

# Generated at 2022-06-25 00:54:42.430281
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an object of FreeBSDVirtual
    free_b_s_d_virtual_0 = FreeBSDVirtual()

    # Test get_virtual_facts of class FreeBSDVirtual
    free_b_s_d_virtual_get_virtual_facts_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:54:46.674712
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_ = FreeBSDVirtualCollector()

    assert isinstance(free_b_s_d_virtual_collector_, VirtualCollector)


# Generated at 2022-06-25 00:54:49.320304
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0_ret = free_b_s_d_virtual_0.get_virtual_facts()
    assert free_b_s_d_virtual_0_ret is None

# Generated at 2022-06-25 00:54:50.397446
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:52.064649
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert type(free_b_s_d_virtual_0.get_virtual_facts()) == dict


# Generated at 2022-06-25 00:54:56.357785
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert type(virtual_facts) == dict
    assert type(virtual_facts['virtualization_type']) == str
    assert type(virtual_facts['virtualization_role']) == str

# Generated at 2022-06-25 00:54:58.195240
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    for fact in free_b_s_d_virtual_collector_0.get_virtual_facts(free_b_s_d_virtual_collector_0):
        print(fact)



# Generated at 2022-06-25 00:55:03.145731
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:06.887553
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_virtual = FreeBSDVirtual()
    # TODO: fail on assert here
    fake_virtual.get_virtual_facts()

# Generated at 2022-06-25 00:55:15.152271
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual__facts_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0 is not None


# Generated at 2022-06-25 00:55:24.038681
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = {}

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    kern_vm_guest = {'virtualization_tech_guest': {'jail'}, 'virtualization_tech_host': set()}
    kern_vm_guest = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    kern_vm_guest = {'virtualization_tech_guest': {'jail'}, 'virtualization_tech_host': set()}
    hw_hv_vendor = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 00:55:28.933626
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    virtual_facts = free_b_s_d_virtual_collector_0._fact_class(free_b_s_d_virtual_collector_0).get_virtual_facts()

# Generated at 2022-06-25 00:55:40.391024
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    # Create object for the class 'FreeBSDVirtualCollector'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

    # Check type of the object 'free_b_s_d_virtual_collector_0'
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)

    # Check type of the object attribute '_fact_class'
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, FreeBSDVirtual)


# Generated at 2022-06-25 00:55:43.656343
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:55:44.834372
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    case_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:48.860693
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual({})
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 00:55:53.893280
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    assert free_b_s_d_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-25 00:55:55.654058
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    case_0 = FreeBSDVirtual()
    case_0_get_virtual_facts = case_0.get_virtual_facts()
    assert case_0_get_virtual_facts is not None


# Generated at 2022-06-25 00:55:57.177112
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector), 'Class FreeBSDVirtualCollector is not callable'



# Generated at 2022-06-25 00:56:04.982286
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    assert(free_b_s_d_virtual_collector_0.platform == 'FreeBSD')
    assert(free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual)
    assert(free_b_s_d_virtual_collector_0 == [])


# Generated at 2022-06-25 00:56:06.709988
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:13.049675
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'


# Generated at 2022-06-25 00:56:13.726627
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:18.009339
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(free_b_s_d_virtual_collector_0, '_fact_class')
    assert hasattr(free_b_s_d_virtual_collector_0, '_platform')


# Generated at 2022-06-25 00:56:29.734304
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Testing for constructor of class FreeBSDVirtualCollector
    # Arrange
    kern_vm_guest_0 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}
    hw_hv_vendor_0 = {'virtualization_tech_guest': {'qemu'}, 'virtualization_tech_host': {'qemu'}, 'virtualization_type': '', 'virtualization_role': ''}
    sec_jail_jailed_0 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-25 00:56:37.828103
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    with open("/proc/cpuinfo", 'r') as f:
        output = f.read()
    assert 'processor' in output
    assert 'vendor_id' in output
    assert 'cpu family' in output
    assert 'model' in output
    assert 'model name' in output
    assert 'stepping' in output
    assert 'microcode' in output
    assert 'cpu MHz' in output
    assert 'cache size' in output
    assert 'physical id' in output
    assert 'siblings' in output
    assert 'core id' in output
    assert 'cpu cores' in output
    assert 'apicid' in output
    assert 'initial apicid' in output
    assert 'fpu' in output
    assert 'fpu_exception' in output
    assert 'cpuid level' in output
    assert 'wp'

# Generated at 2022-06-25 00:56:42.226709
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform is 'FreeBSD'


# Generated at 2022-06-25 00:56:46.406397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:56:52.531302
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual('module')
    if os.path.exists('/dev/xen/xenstore'):
        assert free_b_s_d_virtual.get_virtual_facts() == {
            'virtualization_type': 'xen',
            'virtualization_role': 'guest',
        }
    else:
        assert free_b_s_d_virtual.get_virtual_facts() == {
            'virtualization_type': '',
            'virtualization_role': '',
        }

# Generated at 2022-06-25 00:57:02.468780
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert isinstance(test_case_0(), dict)
    assert 'virtualization_role' in test_case_0()
    assert 'guest' in test_case_0()['virtualization_role']

# Generated at 2022-06-25 00:57:05.182177
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    d_v_c_0 = FreeBSDVirtualCollector()
    # Test for instance attributes of class FreeBSDVirtualCollector
    assert d_v_c_0._fact_class == FreeBSDVirtual
    assert d_v_c_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:57:14.566323
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'F\xdf\x1dl\x9c\xab\x85\x1a'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    if (((var_0.get('virtualization_type') == '') and (var_0.get('virtualization_role') == '')) and ((len(var_0.get('virtualization_tech_guest')) == 0) and (len(var_0.get('virtualization_tech_host')) == 0))):
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:57:16.796319
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0._fact_class
    assert var_1 == FreeBSDVirtual

# Generated at 2022-06-25 00:57:24.235832
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xe9\xb1\xbc\xd0\xbb\x00\x10\x81\x1eA\xb6\xe0\xfa'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    var_1 = var_0['virtualization_role']
    assert var_1 == ''
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:57:27.461636
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)
    var_0 = free_b_s_d_virtual_collector_0.get_all()


# Generated at 2022-06-25 00:57:30.644431
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # assert free_b_s_d_virtual_collector_0.fact_class == <class 'ansible.module_utils.facts.virtual.freebsd.FreeBSDVirtual'>
    # assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'

# Generated at 2022-06-25 00:57:36.603873
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

# Generated at 2022-06-25 00:57:37.715060
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:41.274018
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()

# Generated at 2022-06-25 00:57:54.918681
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
	free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
	print(free_b_s_d_virtual_collector_0)
	print(free_b_s_d_virtual_collector_0.platform)


# Generated at 2022-06-25 00:57:56.193968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:03.664525
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0.get('virtualization_type') == ''
    assert var_0.get('virtualization_role') == ''
    assert var_0.get('virtualization_tech_guest') == {'jail', 'chroot'}
    assert var_0.get('virtualization_tech_host') == {'jail', 'chroot'}


# Generated at 2022-06-25 00:58:05.721759
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

# Generated at 2022-06-25 00:58:11.893588
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)
    assert free_b_s_d_virtual_collector_0 is not None

# Generated at 2022-06-25 00:58:16.268284
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:22.140629
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_vars_0 = FreeBSDVirtualCollector(bytes_0)
    var_0 = free_b_s_d_virtual_collector_vars_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:24.043500
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'

    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

# Generated at 2022-06-25 00:58:28.553675
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    data = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual = FreeBSDVirtual(data)
    expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert free_b_s_d_virtual.get_virtual_facts() == expected
    assert free_b_s_d_virtual.virtualization_role == 'guest'
    assert free_b_s_d_virtual.virtualization_type == 'xen'
    assert free_b_s_d_virtual.virtualization_tech_guest == set()
    assert free_b_s_d

# Generated at 2022-06-25 00:58:32.254370
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:01.302587
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-25 00:59:02.944127
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = virtual_collector_0.collect()


if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:05.392067
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test for get_facts
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0.get_facts()



# Generated at 2022-06-25 00:59:07.311037
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
        assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)
    except AssertionError as e:
       print(e)
       raise


# Generated at 2022-06-25 00:59:11.052009
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_type'] == 'xen'
    assert len(var_0['virtualization_tech_guest']) == 1
    assert len(var_0['virtualization_tech_host']) == 0

# Generated at 2022-06-25 00:59:18.165748
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)

test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:59:23.526707
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0.query is not None
    assert free_b_s_d_virtual_collector_0.get_all_facts() is not None


# Generated at 2022-06-25 00:59:28.119865
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-25 00:59:31.075664
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:40.388889
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with bytes
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}, 'Method get_virtual_facts returned an incorrect value'



# Generated at 2022-06-25 01:00:36.494299
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        # Test case for constructor of class FreeBSDVirtualCollector
        free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    except Exception as e:
        var_1 = 'Error: ' + str(e)
        assert False

# Generated at 2022-06-25 01:00:39.380832
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:45.595838
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xc3\x1b\xfb\x8fv\x06"\xb7\x9b\x8d\xae\x81'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)
    var_0 = free_b_s_d_virtual_collector_0._platform
    assert var_0 == 'FreeBSD'
    var_1 = free_b_s_d_virtual_collector_0._fact_class
    assert var_1 == FreeBSDVirtual

# Generated at 2022-06-25 01:00:47.267267
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:47.772597
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 01:00:50.454643
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)
    var_0 = free_b_s_d_virtual_collector_0._fact_class
    var_0 = free_b_s_d_virtual_collector_0._platform

# Generated at 2022-06-25 01:00:51.367754
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:53.708520
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:01:00.949664
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xe0\x17\x8c\xe9\x9d\xdb\x1f\x8c\xa4\x10\xa3\xe4\x19\x9f\xb4\x0b\x90\x8c\xe4\x01\xc3\x83\xc8\x9a\x06\x87\x8a<\xbf\xd2\xdf\xc6'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert 'virtualization_type' in var_0
    var_1 = var_0['virtualization_type']

# Generated at 2022-06-25 01:01:05.995079
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:03:10.248286
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

    # Test get_facts method
    var_0 = free_b_s_d_virtual_collector_0.get_facts()

    # Test get_virtual_facts method
    var_1 = free_b_s_d_virtual_collector_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:03:14.861015
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xb4\xce\xd4\xa5\xf0\x98\x90\xab\xa3\x1b\xf6\x91\x80\x82\xc6\x8b'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)


# Generated at 2022-06-25 01:03:20.795706
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == {'xen_dom0'}


# Generated at 2022-06-25 01:03:26.525202
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:03:32.568692
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert isinstance(var_0, dict)
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_product_guest' in var_0
    assert 'virtualization_product_host' in var_0
    assert 'virtualization_product_version' in var_0
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == {'chroot'}
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_product_guest'] == 'FreeBSD'

# Generated at 2022-06-25 01:03:39.890631
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_data = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual = FreeBSDVirtual(bytes_data)
    var = free_b_s_d_virtual.get_virtual_facts()
    assert 'virtualization_type' == var.get('virtualization_type')
    assert 'virtualization_role' == var.get('virtualization_role')


# Generated at 2022-06-25 01:03:44.813268
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:03:52.223534
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    virtual_facts_0 = free_b_s_d_virtual_0.get_virtual_facts()
    print('virtual_facts_0: ' + str(virtual_facts_0))
    # assert virtual_facts_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}



# Generated at 2022-06-25 01:04:01.503738
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1{m\xf2\xc9K1q\x8b\xd7'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)

    # Test the return value
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    assert var_0 == {'virtualization_role' : '', 'virtualization_type' : '', 'virtualization_tech_guest' : set(), 'virtualization_tech_host' : set()}

# Generated at 2022-06-25 01:04:05.827539
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector({})


if __name__ == '__main__':
    test_case_0()

#     test_FreeBSDVirtualCollector()