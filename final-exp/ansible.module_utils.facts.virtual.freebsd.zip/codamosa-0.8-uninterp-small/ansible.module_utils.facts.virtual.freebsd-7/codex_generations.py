

# Generated at 2022-06-25 00:54:38.627577
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:54:43.275223
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()

    # Check that facts at least contains virtualization_type and virtualization_role keys
    assert free_b_s_d_virtual.get_virtual_facts() is not None
    virtual_facts = free_b_s_d_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    # Check that facts contains virtualization_tech_host and virtualization_tech_guest keys
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-25 00:54:48.967764
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_free_b_s_d_virtual = FreeBSDVirtual()
    results_0 = virtual_free_b_s_d_virtual.get_virtual_facts()

    assert 'virtualization_type' in results_0
    assert 'virtualization_role' in results_0
    assert 'virtualization_tech_guest' in results_0
    assert 'virtualization_tech_host' in results_0
    assert results_0['virtualization_type'] != ''



# Generated at 2022-06-25 00:54:56.132922
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    # Let's fake the sysctl outputs
    free_b_s_d_virtual_0.get_sysctl_output = lambda x: {'hw.hv_vendor': 'NONE', 'kern.vm_guest': 'none', 'security.jail.jailed': 0, 'hw.model': 'Generic'}
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:54:56.830280
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:55:08.285837
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert {'virtual_facts': {'virtualization_role': 'guest',
                              'virtualization_type': 'xen',
                              'virtualization_tech_guest': {'xen'},
                              'virtualization_tech_host': set()}} == FreeBSDVirtual(platform='FreeBSD', data=free_b_s_d_virtual_collector_1.data).get_virtual_facts()
    free_b_s_d_virtual_collector_2 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:18.665886
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test default values
    free_b_s_d_virtual = FreeBSDVirtual()
    assert free_b_s_d_virtual.get_virtual_facts() == \
        dict(virtualization_role='', virtualization_type='', virtualization_tech_guest=set([]), virtualization_tech_host=set([]))

    # Test Xen Dom0

# Generated at 2022-06-25 00:55:20.589672
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert type(free_b_s_d_virtual_0.get_virtual_facts()) is dict


# Generated at 2022-06-25 00:55:26.308269
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual_get_virtual_facts_0 = FreeBSDVirtual()
    ansible_facts = {}
    ansible_facts_0 = FreeBSDVirtual_get_virtual_facts_0.get_virtual_facts(ansible_facts)
    assert ansible_facts_0['virtualization_type'] == ''
    assert ansible_facts_0['virtualization_role'] == ''
    assert ansible_facts_0['virtualization_tech_host'] == set()
    assert ansible_facts_0['virtualization_tech_guest'] == set()
# End of unit test for FreeBSDVirtual.get_virtual_facts()


# Generated at 2022-06-25 00:55:31.446851
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == ''
    assert virtual_facts.get('virtualization_role') == ''

# Generated at 2022-06-25 00:55:41.440580
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:46.766059
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 00:55:54.984839
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()

    # if os.path.exists('/dev/xen/xenstore'):
    #     result = {
    #         'virtualization_type': 'xen',
    #         'virtualization_role': 'guest'
    #     }
    #
    #     assert result == free_b_s_d_virtual.get_virtual_facts()
    # else:
    #     result = {
    #         'virtualization_type': '',
    #         'virtualization_role': ''
    #     }
    #
    #     assert result == free_b_s_d_virtual.get_virtual_facts()

    # Configure the mock scenario with scenario spec

# Generated at 2022-06-25 00:56:01.776077
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector

    temp_file = NamedTemporaryFile(delete=False)
    temp_file.write(b"hw.model: Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz\n")
    temp_file.write(b"hw.machine: amd64\n")
    temp_file.write(b"hw.ncpu: 32\n")
    temp_file.write(b"hw.memsize: 32599678976\n")
    temp_file.write(b"hw.realmem: 33148624896\n")
    temp_file.write(b"hw.availmem: 31477284864\n")

# Generated at 2022-06-25 00:56:02.397076
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True == True


# Generated at 2022-06-25 00:56:03.945779
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:05.047139
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  raise NotImplementedError()


# Generated at 2022-06-25 00:56:07.697665
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:56:10.883015
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    print(free_b_s_d_virtual_collector_0)
    assert isinstance(free_b_s_d_virtual_collector_0._platform, str)



# Generated at 2022-06-25 00:56:12.570481
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbv = FreeBSDVirtualCollector()
    assert fbv._platform == FreeBSDVirtual.platform



# Generated at 2022-06-25 00:56:30.066689
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x14\xff\xc9'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert type(var_0) is dict
    assert var_0 == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech': {'xen'}}
    bytes_1 = b'\x16\x04\xb0'
    free_b_s_d_virtual_1 = FreeBSDVirtual(bytes_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    assert type(var_1) is dict

# Generated at 2022-06-25 00:56:34.834963
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0.platform
    var_2 = free_b_s_d_virtual_collector_0._fact_class
    var_3 = free_b_s_d_virtual_collector_0.get_all()

# Generated at 2022-06-25 00:56:36.183382
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass

# Generated at 2022-06-25 00:56:37.168654
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, 'object')


# Generated at 2022-06-25 00:56:39.958521
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:41.010946
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:44.995446
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor of class FreeBSDVirtualCollector without parameters
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector._platform
    var_1 = free_b_s_d_virtual_collector._fact_class


# Generated at 2022-06-25 00:56:48.461173
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x14\xff\xc9'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:49.845543
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert b'\x14\xff\xc9'


# Generated at 2022-06-25 00:56:51.011310
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:09.578574
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x1c\xab\x94\xaa\xb7\x8b'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 00:57:17.961956
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test case where ansible_machine is an empty string
    ansible_machine_0 = ''
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(ansible_machine_0)
    var_0 = free_b_s_d_virtual_collector_0.get_virtual_facts()
    # Test case where ansible_machine is a string
    ansible_machine_1 = 'string'
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(ansible_machine_1)
    var_0 = free_b_s_d_virtual_collector_1.get_virtual_facts()

# Generated at 2022-06-25 00:57:23.259709
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # This is just a stub test case.  We could detect on FreeBSD, but the
    # virtual public cloud detection doesn't actually work yet, so this
    # would result in a lot of failures.  So we'll just skip it for now.
    assert True

# Generated at 2022-06-25 00:57:27.146913
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True == True

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-25 00:57:30.582212
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x14\xff\xc9'
    # Instantiate test class.
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    # Call method and verify return of method.
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['xen'])
    }



# Generated at 2022-06-25 00:57:36.533044
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x14\xff\xc9'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:38.265146
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect()
    pass

# Generated at 2022-06-25 00:57:39.673391
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:57:40.880700
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freeBSDVirtualCollector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:44.153529
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x14\xff\xc9'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:16.919088
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()

    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    assert (var_0 == {
        'virtualization_role': '', 
        'virtualization_type': '', 
        'virtualization_tech_guest': set(), 
        'virtualization_tech_host': set()
    })


# Generated at 2022-06-25 00:58:18.457311
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'

# Generated at 2022-06-25 00:58:20.607823
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:58:25.941294
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:33.068028
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    if free_b_s_d_virtual_collector_0.__class__ == FreeBSDVirtualCollector:
        assert True
    else:
        assert False



# Generated at 2022-06-25 00:58:34.581512
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:40.705441
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1


# Generated at 2022-06-25 00:58:42.120324
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:47.388791
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual('FreeBSD')
    free_b_s_d_virtual_0.get_virtual_facts()
#     with pytest.raises(AnsibleUndefinedVariable):
#         _ = free_b_s_d_virtual_0.virtualization_tech_guest
#     with pytest.raises(AnsibleUndefinedVariable):
#         _ = free_b_s_d_virtual_0.virtualization_tech_host
#     with pytest.raises(AnsibleUndefinedVariable):
#         _ = free_b_s_d_virtual_0.virtualization_role
#     with pytest.raises(AnsibleUndefinedVariable):
#         _ = free_b_s_d_virtual_0.virtualization_type
# #

# Generated at 2022-06-25 00:58:49.129155
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:43.763613
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(platform='Linux')
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:44.767749
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:47.564275
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    freenas_facts = {'host_platform': 'FreeBSD'}
    # Get instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual(freenas_facts)

    # Check if method get_virtual_facts works properly
    assert freebsd_virtual.get_virtual_facts() == {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set(['xen'])}


# Generated at 2022-06-25 00:59:48.558203
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:52.773170
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'


# Generated at 2022-06-25 00:59:55.725282
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0,FreeBSDVirtualCollector)
    assert not var_0


# Generated at 2022-06-25 01:00:05.717144
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert 'ansible_virtualization_vendor' in test_case_0().keys(), 'Value should be present'
    assert 'ansible_virtualization_role' in test_case_0().keys(), 'Value should be present'
    assert 'ansible_virtualization_type' in test_case_0().keys(), 'Value should be present'
    assert 'ansible_virtualization_type_lower' in test_case_0().keys(), 'Value should be present'
    assert 'ansible_virtualization_type_upper' in test_case_0().keys(), 'Value should be present'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:00:08.543307
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    print(var_1)


# Generated at 2022-06-25 01:00:12.890148
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert (free_b_s_d_virtual_collector_1._fact_class == FreeBSDVirtual)


# Generated at 2022-06-25 01:00:13.991397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:02:12.148341
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_obj = FreeBSDVirtual('/proc/cpuinfo')
    var_1 = free_b_s_d_virtual_obj.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:02:14.587162
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:02:19.022269
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Unit test FreeBSDVirtualCollector.__init__

# Generated at 2022-06-25 01:02:20.579143
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
        var_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:23.099121
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:02:24.597444
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:02:29.923376
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0
    assert free_b_s_d_virtual_collector_0.collect == free_b_s_d_virtual_collector_0.plugin.collect
    assert free_b_s_d_virtual_collector_0.plugin
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'

# Generated at 2022-06-25 01:02:34.688654
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    # test_FreeBSDVirtual_get_virtual_facts()
    print('Test Finished')

# Generated at 2022-06-25 01:02:35.543824
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_2 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:39.745816
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_2 = FreeBSDVirtualCollector()
    # assert var_2._fact_class == type({'virtualization_type': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_role': ''})