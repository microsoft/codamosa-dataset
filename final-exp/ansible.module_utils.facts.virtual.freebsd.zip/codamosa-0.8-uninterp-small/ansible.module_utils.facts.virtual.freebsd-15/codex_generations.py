

# Generated at 2022-06-25 00:54:37.065235
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:40.812560
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()

    # Unit tests for get_virtual_facts:

    assert virtual_facts['virtualization_type'] != '', \
        'Value of <virtual_facts["virtualization_type"]> must not be empty'
    assert set() != set(virtual_facts['virtualization_tech_guest']), \
        'Value of <virtual_facts["virtualization_tech_guest"]> must not be empty'
    assert set() != set(virtual_facts['virtualization_tech_host']), \
        'Value of <virtual_facts["virtualization_tech_host"]> must not be empty'


# Generated at 2022-06-25 00:54:45.328597
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:47.604790
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_1._fact_class is not None


# Generated at 2022-06-25 00:54:55.148286
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-25 00:55:00.483509
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0_object = test_case_0()
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:04.355914
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0,VirtualCollector)



# Generated at 2022-06-25 00:55:08.034124
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Testing class constructor
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:55:11.688476
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()

    assert free_b_s_d_virtual_collector._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector._platform == 'FreeBSD'



# Generated at 2022-06-25 00:55:12.795632
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fBSD = FreeBSDVirtual()
    fBSD.get_virtual_facts()

# Generated at 2022-06-25 00:55:22.884215
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_1


# Generated at 2022-06-25 00:55:27.162110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    sysctl_paths = {
        'hw.model': 'hostname',
        'hw.hv_vendor': 'hostname',
        'kern.vm_guest': 'hostname',
        'security.jail.jailed': 'hostname'
    }
    data_dict = {
        'uname_s': 'FreeBSD',
        # sysctl
        'virtual_facts': {
            'hw_model': 'FreeBSD/SMP: Fri Mar 20 16:00:29 MSK 2015',
            'hw_hv_vendor': 'Bhyve',
            'kern_vm_guest': 'none',
            'security_jail_jailed': '0'
        }
    }

# Generated at 2022-06-25 00:55:31.759266
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert (virtual_facts['virtualization_type'] == 'unknown') or (virtual_facts['virtualization_role'] == 'unknown')

# Generated at 2022-06-25 00:55:35.272281
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:39.180527
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set([])
    }

# Generated at 2022-06-25 00:55:46.764434
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    # - virtualization_type
    assert 'virtualization_type' in virtual_facts
    # - virtualization_role
    assert 'virtualization_role' in virtual_facts
    # - virtualization_tech_host
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    # - virtualization_tech_guest
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)


# Generated at 2022-06-25 00:55:49.919366
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:52.028382
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 00:55:56.366375
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:57.797296
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector), "Class FreeBSDVirtualCollector is not callable"


# Generated at 2022-06-25 00:56:07.093630
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True == True


# Generated at 2022-06-25 00:56:13.317023
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:17.089931
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:56:19.258510
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'


# Generated at 2022-06-25 00:56:21.890768
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:23.299900
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f_r_e_e_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:25.725003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    _fact_class = 'FreeBSDVirtual'
    _platform = 'FreeBSD'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(_fact_class, _platform)


# Generated at 2022-06-25 00:56:28.969734
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:31.660822
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Example 1
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:36.669235
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    _fact_class_0 = None
    _platform_0 = None
    # call to __init__ of class FreeBSDVirtualCollector with arguments _fact_class_0, _platform_0
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(_fact_class_0, _platform_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:56:58.866034
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector('kern.vm_guest')


# Generated at 2022-06-25 00:57:07.463559
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '{0}_name'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    str_1 = 'hw.model'
    var_0 = free_b_s_d_virtual_collector_0.detect_virt_vendor(str_1)
    str_2 = 'hw.hv_vendor'
    var_1 = free_b_s_d_virtual_collector_0.detect_virt_product(str_2)
    str_3 = 'kern.vm_guest'
    var_2 = free_b_s_d_virtual_collector_0.detect_virt_product(str_3)
    str_4 = 'security.jail.jailed'
    var_3 = free_

# Generated at 2022-06-25 00:57:13.308423
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize test variables
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    # Set up test environment
    # Perform test of method get_virtual_facts of class FreeBSDVirtual
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:15.783883
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual and free_b_s_d_virtual_collector_0._platform is 'FreeBSD'


# Generated at 2022-06-25 00:57:16.942333
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:19.105621
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:21.752706
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
  try:
    free_b_s_d_virtual_obj = FreeBSDVirtual('')
    virtual_facts = free_b_s_d_virtual_obj.get_virtual_facts()
  except Exception:
    e = sys.exc_info()[1]
    print(e)
    assert False
  else:
    assert True

# Generated at 2022-06-25 00:57:24.327332
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:29.819027
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:34.746193
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This is a unit test for the constructor of the class
    FreeBSDVirtualCollector.
    """
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0._fact_class
    assert type(var_0) is FreeBSDVirtual
    var_1 = free_b_s_d_virtual_collector_0._platform
    assert var_1 == 'FreeBSD'


# Generated at 2022-06-25 00:58:03.064471
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


if __name__ == "__main__":
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:03.948820
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 00:58:09.281706
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '{0}_name'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.collection
    str_1 = '{0}_name'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_1)
    var_1 = free_b_s_d_virtual_collector_0.collection


# Generated at 2022-06-25 00:58:15.651312
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    try:
        freebsd_virtual_collector_0 = FreeBSDVirtualCollector()
    except Exception as e:
        print("Exception in constructor")
        print(e)
    assert(freebsd_virtual_collector_0)


# Generated at 2022-06-25 00:58:18.374716
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:20.834811
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:27.588901
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if __name__ == '__main__':
        free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
        test_case_0()

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:30.697236
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:58:35.359765
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with 1 argument
    # Test with 1 argument
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:42.224541
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # str_0 = '{0}_name'
    # free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    # var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    pass

# Generated at 2022-06-25 00:59:37.636925
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:40.104569
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Prepare data for test
    _platform = 'FreeBSD'
    _fact_class = FreeBSDVirtual

    # Run test
    obj = FreeBSDVirtualCollector(_platform, _fact_class)

# Generated at 2022-06-25 00:59:45.272668
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:47.622072
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    _fact_class_0 = FreeBSDVirtual
    _platform_0 = 'FreeBSD'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(_fact_class_0, _platform_0)
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:51.661811
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert (var_0['virtualization_role'] == '')
    assert (var_0['virtualization_type'] == '')
    assert (var_0['virtualization_tech_guest'] == set())
    assert (var_0['virtualization_tech_host'] == set())

# Generated at 2022-06-25 00:59:53.160472
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSD_virtual_collector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:59:55.463599
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(str)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:57.867121
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_class = FreeBSDVirtual
    platform = 'FreeBSD'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(fact_class, platform)


# Generated at 2022-06-25 01:00:04.499979
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_1 = '{0}_name'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:00:05.269388
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_1 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:02:06.062458
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual('freebsd_virtual_name')
    expected = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_system': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    actual = free_b_s_d_virtual_0.get_virtual_facts()
    assert expected == actual


# Generated at 2022-06-25 01:02:11.905599
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:02:13.494323
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(test_0='test_value_0')
    assert test_0 == 'test_value_0'

# Generated at 2022-06-25 01:02:14.135558
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 01:02:17.768652
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()
    var_1 = var_0.collect()
    assert var_1['ansible_facts']['virtualization_type'] == 'OpenVZ'
    assert var_1['ansible_facts']['virtualization_role'] == 'guest'
    assert set(var_1['ansible_facts']['virtualization_tech_guest']) == set(['OpenVZ', 'linux-vz'])

# Generated at 2022-06-25 01:02:18.526618
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:20.563603
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
        fbc = FreeBSDVirtualCollector()
        # check the platform of the instance
        assert(fbc._platform == 'FreeBSD')

# Generated at 2022-06-25 01:02:22.436887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:02:24.018954
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.get_all() is not None

# Generated at 2022-06-25 01:02:25.715149
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:04:27.518770
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:04:29.662446
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '{0}_name'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:04:31.003080
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
