

# Generated at 2022-06-25 00:54:40.307772
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual_i = FreeBSDVirtual()
    FreeBSDVirtual_i.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:54:42.146260
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f_collector = FreeBSDVirtualCollector()
    if not isinstance(f_collector, FreeBSDVirtualCollector):
         raise Exception("Failed - FreeBSDVirtualCollector instance")


# Generated at 2022-06-25 00:54:46.533378
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    virtual_facts = free_b_s_d_virtual.get_virtual_facts()

    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-25 00:54:47.652837
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:53.847188
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = 'FreeBSDVirtual'
    function = 'get_virtual_facts'
    test_case = 0

    if test_case == 0:
        free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
        free_b_s_d_virtual_0 = free_b_s_d_virtual_collector_0.collect()
        virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:54:56.833212
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:55:00.839038
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    get_virtual_facts_FreeBSDVirtual_0 = FreeBSDVirtual()
    get_virtual_facts_FreeBSDVirtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:08.384873
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Construct a FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.facts == {}
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0.fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:17.474779
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit: get_virtual_facts
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Case: test_case_0
    test_case_0()
    # Case: test_case_1
    test_case_1()
    # Case: test_case_2
    test_case_2()
    # Case: test_case_3
    test_case_3()
    # Case: test_case_4
    test_case_4()
    # Case: test_case_5
    test_case_5()
    # Case: test_case_6
    test_case_6()
    # Case: test_case_7
    test_case_7()
    # Case: test_case_8
    test_case_8()
    # Case: test

# Generated at 2022-06-25 00:55:22.347672
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 00:55:38.875566
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    result = free_b_s_d_virtual.get_virtual_facts()
    assert result[u'virtualization_role'] == u'' or result[u'virtualization_role'] in (u'guest', u'host', u'zone')
    assert result[u'virtualization_type'] == u'' or result[u'virtualization_type'] in (u'chroot', u'jail', u'lxc', u'lxd', u'openvz', u'parallels', u'virtualbox', u'vmware', u'xen')

# Generated at 2022-06-25 00:55:41.198257
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:46.127379
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert (free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()})


# Generated at 2022-06-25 00:55:48.590597
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert test_case_0() == None, "Constructor for FreeBSDVirtualCollector did not set attribute _platform to 'FreeBSD'"


# Generated at 2022-06-25 00:55:53.863465
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech': set(),
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 00:55:54.881949
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    object_of_FreeBSDVirtualCollector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:56.131753
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:56:05.172524
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_0 = FreeBSDVirtual({}, free_b_s_d_virtual_collector_0)
    free_b_s_d_virtual_collector_0.sysctl = {'kern.vm_guest': '0', 'hw.hv_vendor': '', 'security.jail.jailed': '0', 'hw.model': 'Intel(R) Xeon(R) CPU E7-4820 v2 @ 2.00GHz'}

# Generated at 2022-06-25 00:56:06.030799
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 00:56:07.698439
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:26.749225
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:29.266019
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:32.127240
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except:
        assert False


# Generated at 2022-06-25 00:56:42.298849
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert isinstance(free_b_s_d_virtual_0, dict)
    assert isinstance(free_b_s_d_virtual_0, FreeBSDVirtual)
    assert len(free_b_s_d_virtual_0) == 4
    assert 'virtualization_type' in free_b_s_d_virtual_0
    assert 'virtualization_role' in free_b_s_d_virtual_0
    assert 'virtualization_tech_guest' in free_b_s_d_virtual_0
    assert 'virtualization_tech_host' in free_b_s_d_virtual_0
    assert isinstance(free_b_s_d_virtual_0['virtualization_type'], str)

# Generated at 2022-06-25 00:56:44.060234
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:46.514792
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:50.776904
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert repr(free_b_s_d_virtual_collector_0) == "<ansible.module_utils.facts.virtual.freebsd.FreeBSDVirtualCollector object at 0x7f44b0778d90>"


# Generated at 2022-06-25 00:56:58.418983
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # update sysctl detection mixin to return a new set for test
    VirtualSysctlDetectionMixin.detect_virt_product = lambda s: {
        'virtualization_tech_guest': ['virtualization_tech_guest_test'],
        'virtualization_tech_host': ['virtualization_tech_host_test']
    }

    # update virtual vendor detection mixin to return a new set for test
    VirtualSysctlDetectionMixin.detect_virt_vendor = lambda s: {
        'virtualization_tech_guest': ['virtualization_tech_guest_test'],
        'virtualization_tech_host': ['virtualization_tech_host_test']
    }

    # Test FreeBSDVirtual.get_virtual_facts()
    # Object creation with FreeBSDVirtual()
    free_b_s_d_virtual

# Generated at 2022-06-25 00:57:03.621181
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

    freebd_virtual_0 = FreeBSDVirtual()
    assert(freebd_virtual_0.get_virtual_facts() == test_virtual_facts)

test_case_0()

# Generated at 2022-06-25 00:57:09.904629
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_1._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_1._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-25 00:57:47.072898
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:48.556878
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:57:52.278338
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    if free_b_s_d_virtual_0.get_virtual_facts() is False:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:57:56.866248
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == \
        {'virtualization_type': '', 'virtualization_role': '',
         'virtualization_technology': set()}


# Generated at 2022-06-25 00:57:59.097538
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:00.699106
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:02.938884
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:05.475056
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:58:10.224870
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:18.004809
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if FreeBSDVirtualCollector:
        free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
        assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
        assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
        assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
        assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
        assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'

# Generated at 2022-06-25 00:59:41.183131
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual({"platform": "FreeBSD"})
    free_b_s_d_virtual_0.subsystems = set()
    free_b_s_d_virtual_0.subsystems.add(free_b_s_d_virtual_0)
    dict = free_b_s_d_virtual_0.get_virtual_facts()
    assert dict == {"virtualization_type": "", "virtualization_role": ""} is not True


# Generated at 2022-06-25 00:59:42.857316
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    facts = free_b_s_d_virtual_0.get_virtual_facts()
    assert facts == {}

# Generated at 2022-06-25 00:59:48.903153
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(free_b_s_d_virtual_collector_0, '_platform')
    assert isinstance(free_b_s_d_virtual_collector_0._platform, str)
    assert hasattr(free_b_s_d_virtual_collector_0, '_fact_class')
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, FreeBSDVirtual)


# Generated at 2022-06-25 00:59:52.494293
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert not hasattr(FreeBSDVirtualCollector, '_fact_class')
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'



# Generated at 2022-06-25 01:00:00.973509
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(free_b_s_d_virtual_collector_0, '_fact_class')
    assert free_b_s_d_virtual_collector_0._fact_class is not None
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert hasattr(free_b_s_d_virtual_collector_0, '_platform')
    assert free_b_s_d_virtual_collector_0._platform is not None
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:00:04.540122
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:00:06.588210
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0._platform = 'FreeBSD'
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:08.540888
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0 != None


# Generated at 2022-06-25 01:00:15.340210
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class,
                      FreeBSDVirtual)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:00:22.562968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    ansible_facts = {}
    ansible_facts_1 = {}
    ansible_facts_1['ansible_virtualization_type'] = ''
    ansible_facts_1['ansible_virtualization_role'] = ''
    ansible_facts_1['ansible_virtualization_tech_guest'] = set({'freebsd-jail'})
    ansible_facts_1['ansible_virtualization_tech_host'] = set()
    ansible_facts_1['ansible_virtualization_vendor'] = ''
    ansible_facts_1['ansible_virtualization_product'] = ''
    assert ansible_facts == ansible_facts_1

# Generated at 2022-06-25 01:01:54.749372
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:01:56.326160
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert isinstance(free_b_s_d_virtual_0.get_virtual_facts(), dict)

# Generated at 2022-06-25 01:02:03.309287
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, type(FreeBSDVirtual()))
    assert isinstance(free_b_s_d_virtual_collector_0._platform, str)


# Generated at 2022-06-25 01:02:07.816542
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kern_vm_guest = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    hw_hv_vendor = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    sec_jail_jailed = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    sysctl = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    virtual_vendor_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    host_tech = set()
   

# Generated at 2022-06-25 01:02:10.207709
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_freebsd_virtual = FreeBSDVirtual()
    test_freebsd_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:02:17.642824
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(dict())
    results = free_b_s_d_virtual_0.get_virtual_facts()
    assert results is not None, "Failed to get virtual facts"
    assert results.get('virtualization_type') is not None, "Failed to get virtualization type"
    assert results.get('virtualization_role') is not None, "Failed to get virtualization role"
    assert results.get('virtualization_tech_guest') is not None, "Failed to get virtualization guest tech"
    assert results.get('virtualization_tech_host') is not None, "Failed to get virtualization host tech"

# Generated at 2022-06-25 01:02:20.628264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:02:22.982648
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass # TODO

# Generated at 2022-06-25 01:02:23.624261
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:02:26.288837
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    input_string = 'FreeBSD'
    expected_outpt = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set([])
    }
    assert expected_outpt == FreeBSDVirtual.get_virtual_facts(input_string)



# Generated at 2022-06-25 01:04:05.763180
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_2 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_2, FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:04:10.016376
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:04:15.245178
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test for constructor of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)



# Generated at 2022-06-25 01:04:17.585363
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual



# Generated at 2022-06-25 01:04:20.341519
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:04:22.245219
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        test_case_0()
    except:
        print('Exception encountered in test case 0')

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:04:27.401097
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sysctl = {
        'kern_vm_guest': {
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            'virtualization_type': '',
        },
        'hw_hv_vendor': {
            'virtualization_tech_guest': {'vmware'},
            'virtualization_tech_host': set(),
            'virtualization_type': 'vmware',
        },
        'sec_jail_jailed': {
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            'virtualization_type': '',
        }
    }

    # Test 1: No sysctl info
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_

# Generated at 2022-06-25 01:04:28.975805
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    try:
        FreeBSDVirtualCollector()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 01:04:29.670817
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:04:31.205300
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual({})
    free_b_s_d_virtual.get_virtual_facts()