

# Generated at 2022-06-25 00:54:40.120220
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 4005.34
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    free_b_s_d_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 00:54:44.866956
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 4005.34
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    value = free_b_s_d_virtual_0.get_virtual_facts()
    value_expected = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()}
    assert value == value_expected


# Generated at 2022-06-25 00:54:54.859577
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # 24 cases
    float_1 = 4005.34
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    # FreeBSDVirtual.get_virtual_facts() returned a dictionary
    assert isinstance(free_b_s_d_virtual_1.get_virtual_facts(), dict)
    '''
    # The 1st key of this dictionary is virtualization_type
    assert 'virtualization_type' in free_b_s_d_virtual_1.get_virtual_facts()
    '''
    # The 2nd key of this dictionary is virtualization_role
    assert 'virtualization_role' in free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 00:54:56.907532
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 4005.34
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)



# Generated at 2022-06-25 00:54:59.068584
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 4005.34
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector(float_0)
    free_b_s_d_virtual_collector.collect()


# Generated at 2022-06-25 00:55:02.988495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if __name__ == "__main__":
        free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)

# Generated at 2022-06-25 00:55:09.718665
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_1 = 4005.34
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    dict_3 = free_b_s_d_virtual_1.get_virtual_facts()
    assert dict_3 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(['']), 'virtualization_tech_host': set([''])}
    float_2 = 4005.34
    free_b_s_d_virtual_2 = FreeBSDVirtual(float_2)
    dict_4 = free_b_s_d_virtual_2.get_virtual_facts()

# Generated at 2022-06-25 00:55:12.518323
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 4005.34
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    result_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert result_0 is not None


# Generated at 2022-06-25 00:55:19.599968
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 4005.34
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == 'xen'
    assert virtual_facts.get('virtualization_role') == 'guest'
    assert virtual_facts.get('virtualization_tech_guest') == {'xen'}
    assert virtual_facts.get('virtualization_tech_host') == set()


# Generated at 2022-06-25 00:55:20.883224
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 4005.34
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)

# Generated at 2022-06-25 00:55:27.703839
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
   # Instance the class FreeBSDVirtual
   free_b_s_d_virtual = FreeBSDVirtual()
   # Call get_virtual_facts method of FreeBSDVirtual
   virtual_facts = free_b_s_d_virtual.get_virtual_facts()
   # Assert that virtual_facts is a dict
   assert isinstance(virtual_facts, dict)
   # Assert that virtual_facts is not empty
   assert virtual_facts

# Generated at 2022-06-25 00:55:32.574993
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector, FreeBSDVirtualCollector)



# Generated at 2022-06-25 00:55:36.369460
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:41.095559
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual = FreeBSDVirtualCollector()
    # This assert statement checks if the input for FreeBSDVirtualCollector class for the constructor is
    # empty or not.
    # If an input is provided, then it checks if it is an instance of FreeBSDVirtualCollector class.
    assert ('_fact_class' in vars(free_b_s_d_virtual))
    assert ('_platform' in vars(free_b_s_d_virtual))


# Generated at 2022-06-25 00:55:44.490821
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:55:46.240387
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:50.186270
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test with object from class VirtualCollector
    virtual_collector = VirtualCollector()
    # Test with object from class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:55:52.208240
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-25 00:55:56.366654
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:59.157703
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector, '_platform'), \
        "_platform must be defined in FreeBSDVirtualCollector"
    assert hasattr(FreeBSDVirtualCollector, '_fact_class'), \
        "_fact_class must be defined in FreeBSDVirtualCollector"


# Generated at 2022-06-25 00:56:09.065685
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:12.994731
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(module_facts={})
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:14.179962
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:17.029191
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual()
    virtual_facts = fbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-25 00:56:18.114968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert test_case_0() == None


# Generated at 2022-06-25 00:56:29.767916
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os.path.exists = lambda x: False
    os.path.exists.return_value = True
    kern_vm_guest = {'virtualization_type': 'jail',
                      'virtualization_role': 'guest',
                      'virtualization_tech_guest': set(['jail']),
                      'virtualization_tech_host': set(['jail'])}
    hw_hv_vendor = {'virtualization_type': 'parallel',
                      'virtualization_role': 'host',
                      'virtualization_tech_guest': set(['parallel']),
                      'virtualization_tech_host': set(['parallel'])}

# Generated at 2022-06-25 00:56:31.120176
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_0 = FreeBSDVirtual()
    freebsd_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:32.975531
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual_object = FreeBSDVirtual()
    FreeBSDVirtual_get_virtual_facts_ret_val = FreeBSDVirtual_object.get_virtual_facts()


# Generated at 2022-06-25 00:56:38.181553
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()

##############################################################################
# Main Program #
if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:41.125077
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual(module=dict())
    free_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 00:56:52.838586
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 00:56:56.785039
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f_ree_b_s_d_virtual = FreeBSDVirtual(None)
    assert set(f_ree_b_s_d_virtual.get_virtual_facts()) == set({
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    })

# Generated at 2022-06-25 00:56:57.766705
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:57:00.687721
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    except TypeError:
        pass


# Generated at 2022-06-25 00:57:02.970552
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert not hasattr(free_b_s_d_virtual_collector_0, 'platform')


# Generated at 2022-06-25 00:57:04.565776
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert(test_case_0() == None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:57:05.553832
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:08.537948
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    facts = {}
    # When:
    actual = free_b_s_d_virtual.get_virtual_facts()
    # Then:
    expected = {}
    assert actual == expected


# Generated at 2022-06-25 00:57:12.918551
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.platform == "FreeBSD"


# Generated at 2022-06-25 00:57:15.272896
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:30.025898
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    output_FreeBSDVirtual_get_virtual_facts = {'virtualization_role': 'guest', 'virtualization_type': 'xen'}
    assert FreeBSDVirtual().get_virtual_facts() == output_FreeBSDVirtual_get_virtual_facts


# Generated at 2022-06-25 00:57:33.062488
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_get_virtual_facts_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:35.489846
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    instance = FreeBSDVirtual()
    virtual_facts = instance.get_virtual_facts()
    assert not virtual_facts['virtualization_type']
    assert not virtual_facts['virtualization_role']
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-25 00:57:41.148462
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()

    # From file tests/test_module_utils_facts_virtual/arguments/virtual_facts/FreeBSD/test_case_0.yaml
    # See tests/test_module_utils_facts_virtual/arguments/virtual_facts/FreeBSD/
    output = {
        'virtualization_role': 'guest',
        'virtualization_technologies': [
            'xen'
        ],
        'virtualization_type': 'xen'
    }
    assert (free_b_s_d_virtual_0.get_virtual_facts() == output) or (free_b_s_d_virtual_0.get_virtual_facts() == {})


# Generated at 2022-06-25 00:57:42.358819
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__init__()


# Generated at 2022-06-25 00:57:43.592426
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert test_case_0() is None


# Generated at 2022-06-25 00:57:44.479474
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-25 00:57:48.859743
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual({})
    free_b_s_d_virtual_facts = free_b_s_d_virtual.get_virtual_facts()
    assert (free_b_s_d_virtual_facts['virtualization_type'] == 'xen')
    assert (free_b_s_d_virtual_facts['virtualization_role'] == 'guest')


# Generated at 2022-06-25 00:57:50.843262
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    return_value = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:51.340975
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True

# Generated at 2022-06-25 00:58:01.553940
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:02.762518
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:08.119776
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check if instance FreeBSDVirtualCollector is created
    assert FreeBSDVirtualCollector() is not None
    # Check if class FreeBSDVirtualCollector is subclass of VirtualCollector
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    # Check if instance FreeBSDVirtualCollector is of class FreeBSDVirtualCollector
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)
    # Check if instance FreeBSDVirtualCollector is of class VirtualCollector
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-25 00:58:11.107204
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # We only test constructor for now
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 00:58:12.014373
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # var = FreeBSDVirtualCollector()
    pass


# Generated at 2022-06-25 00:58:13.161258
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsdvirtual_0 = FreeBSDVirtual()
    var_0 = freebsdvirtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:13.705950
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:19.241304
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:58:24.924577
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    return var_0


# Generated at 2022-06-25 00:58:26.902805
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:50.437678
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # There is no module yet to test the FreeBSDVirtual class.
    # This unit test provides some coverage for get_virtual_facts.
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.__setattr__('_get_file_content', get_file_content_fake)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(['test', 'host_vendor']), 'virtualization_tech_guest': set(['test', 'guest_vendor'])}


# Generated at 2022-06-25 00:58:57.177282
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class_FreeBSDVirtual = FreeBSDVirtual()
    var_0 = class_FreeBSDVirtual.get_virtual_facts()
    if os.path.exists('/dev/xen/xenstore'):
        assert var_0 == {'virtualization_technology_host': set(), 'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_technology_guest': {'xen'}}
    else:
        assert var_0 == {'virtualization_technology_host': set(), 'virtualization_technology_guest': set(), 'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-25 00:59:02.500091
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert type(FreeBSDVirtualCollector())



# Generated at 2022-06-25 00:59:05.772989
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a FreeBSD-specific class
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts(free_b_s_d_virtual_0, test_case_0())



# Generated at 2022-06-25 00:59:07.258473
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:10.111169
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:12.982209
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

    assert free_b_s_d_virtual_collector_0
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)

# Generated at 2022-06-25 00:59:14.606927
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:17.864864
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    FreeBSDVirtualCollector.get_virtual_facts(free_b_s_d_virtual_collector_1)


# Generated at 2022-06-25 00:59:22.368598
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # AssertionError: The FreeBSDVirtualCollector._fact_class class attribute is not a subclass of Virtual
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, Virtual) is True


# Generated at 2022-06-25 00:59:57.789547
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:00:05.584657
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        test_case_0()
    except Exception:
        import traceback
        err = traceback.format_exc().splitlines()[-1]
        print('FAIL: test_FreeBSDVirtualCollector(): uncaught exception when calling FreeBSDVirtualCollector.__init__() - %s' % err)
        return False
    else:
        return True


# Generated at 2022-06-25 01:00:08.539084
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual('/')
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:13.559024
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    if isinstance(free_b_s_d_virtual_collector_1, FreeBSDVirtualCollector):
        assert True
    else:
        assert False


# Generated at 2022-06-25 01:00:15.539338
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    a_free_b_s_d_virtual = FreeBSDVirtual()
    var_1 = a_free_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:00:18.898551
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_get_virtual_facts_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_get_virtual_facts_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:23.809016
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    # AssertionError: 'virtualization_tech_host' != set(['hw_virtual'])
    # AssertionError: 'virtualization_tech_guest' != set(['hw_virtual'])
    # AssertionE

# Generated at 2022-06-25 01:00:29.743862
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''


# Generated at 2022-06-25 01:00:32.755479
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:34.256782
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual.get_virtual_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:01:57.780528
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_sd_virtual_collector = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_2 = FreeBSDVirtual()
    var_1 = free_b_sd_virtual_collector.collect(free_b_sd_virtual_collector)
    var_2 = free_b_s_d_virtual_collector_2.get_virtual_facts()
    assert var_1 == var_2


test_case_0()
test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:02:06.510811
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # NOTE: since we can't do a full discovery of the current host, we bypass
    # the VirtualCollector's __init__ call and instead call the __init__ of its
    # parent class directly.
    free_b_s_d_virtual_0 = FreeBSDVirtual(VirtualCollector())

    # Test with no parameters
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:02:12.210343
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)

# Generated at 2022-06-25 01:02:13.782515
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:02:18.905071
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var = u'FreeBSD'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == var


# Generated at 2022-06-25 01:02:23.011293
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    try:
        free_b_s_d_virtual_0.get_virtual_facts()
    except (NameError, AttributeError) as e:
        print(str(e), file=sys.stderr)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:02:23.679931
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert test_case_0() is True

# Generated at 2022-06-25 01:02:25.221595
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(None, None)
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:02:28.096604
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except NameError as error:
        print(error)
        assert False



# Generated at 2022-06-25 01:02:33.031360
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 01:03:59.840883
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:04:05.895460
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    print('In main:')
    test_case_0()
    print('Testing class FreeBSDVirtualCollector')
    test_FreeBSDVirtualCollector()
    print('Done testing FreeBSDVirtualCollector')

# Generated at 2022-06-25 01:04:07.644724
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector) == True


# Generated at 2022-06-25 01:04:12.845065
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  # Test for constructor of class FreeBSDVirtualCollector with args
  # Instantiate a subclass of class FreeBSDVirtualCollector
  free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
  # Test for constructor of class FreeBSDVirtualCollector without args
  free_b_s_d_virtual_collector_2 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:04:13.440824
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    # Constructor without arguments
    # FreeBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:04:15.318843
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual({})
    free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:04:21.030767
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(None)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == ({'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}, {'ansible_virtualization_type': '', 'ansible_virtualization_role': '', 'ansible_virtualization_technologies_host': set(), 'ansible_virtualization_technologies_guest': set()})

# Generated at 2022-06-25 01:04:23.483923
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == "FreeBSD"



# Generated at 2022-06-25 01:04:29.017608
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    assert free_b_s_d_virtual.get_virtual_facts() == {}
