

# Generated at 2022-06-25 00:54:42.078668
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = "&O|>z%c'`Hp]Z"
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(str_0)
    result = repr(free_b_s_d_virtual_collector_1)
    assert result == "<FreeBSDVirtualCollector(/usr/local/etc/ansible/facts.d)>"
    assert isinstance(free_b_s_d_virtual_collector_1, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:54:46.637189
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'e'
    assert FreeBSDVirtualCollector(str_0) is not None

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:47.425546
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()



# Generated at 2022-06-25 00:54:51.564007
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        assert callable(FreeBSDVirtualCollector)
    except AssertionError as e:
        raise AssertionError(e.args)

test_FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:57.754420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = "'j\\%Lf|J59f7)"
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector) is True
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class._platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:06.964690
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = "C'%Bf&0,#J~"
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    str_1 = 'hw.model'
    dict_0 = {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    dict_1 = {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    dict_2 = {'virtualization_tech_host': set(['VMWare', '*']), 'virtualization_tech_guest': set(['VMWare', '*'])}
    dict_3 = {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 00:55:11.051483
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = "'j\\%Lf|J59f7)"
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:14.043672
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # No tests are needed for FreeBSD facts
    pass


# Generated at 2022-06-25 00:55:16.637140
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0_9 = "'j\\%Lf|J59f7)"
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0_9)



# Generated at 2022-06-25 00:55:19.235100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = "'j\\%Lf|J59f7)"
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 00:55:28.391772
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 146.02267
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:33.126812
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 146.02267
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:37.980851
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test for constructor FreeBSDVirtualCollector
    # Input:
    #     platform: str = 'FreeBSD'
    #     data: dict = {}
    # Output:
    #     FreeB_S_D_Virtual_Collector_0: FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:43.275338
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 146.02267
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)


# Generated at 2022-06-25 00:55:45.733921
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 146.02267
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:47.584704
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:53.217304
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    float_0 = 146.02267
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    # Check if instance FreeBSDVirtualCollector() was created
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:55:58.560525
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_1 = 14.964459749
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(float_1)
    assert isinstance(free_b_s_d_virtual_collector_1, FreeBSDVirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_1, VirtualCollector)



# Generated at 2022-06-25 00:56:00.401825
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 146.02267
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)

# Generated at 2022-06-25 00:56:04.094172
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_1 = 146.02267
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 00:56:19.327118
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_1 = 146.02267
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    assert var_1['virtualization_type'] == ''
    assert var_1['virtualization_role'] == ''


# Generated at 2022-06-25 00:56:22.202463
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert test_case_0() == None




# Generated at 2022-06-25 00:56:24.510170
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 146.02267
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:56:25.328494
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 00:56:26.782653
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:56:29.593524
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 00:56:33.910485
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 146.02267
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    var_1 = FreeBSDVirtual(146.02267)
    var_2 = var_1.get_virtual_facts()


# Generated at 2022-06-25 00:56:42.375394
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(146.02267)
    free_b_s_d_virtual_0.detect_virt_product = MagicMock(return_value={'virtualization_tech_guest': {'vboxguest'}, 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''})
    free_b_s_d_virtual_0.detect_virt_vendor = MagicMock(return_value={'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''})
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:43.566414
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 00:56:49.144358
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 7.656527
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    dict_0 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    #assert free_b_s_d_virtual_0.get_virtual_facts() == dict_0


# Generated at 2022-06-25 00:56:58.954876
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__base__ == VirtualCollector

# Generated at 2022-06-25 00:57:01.202221
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:02.294953
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:04.472432
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """ Unit test for method get_virtual_facts of class FreeBSDVirtual """
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    try:
        var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    except Exception:
        raise Exception(str(e))



# Generated at 2022-06-25 00:57:09.121085
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:13.273030
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Verify constructor returns an object of class FreeBSDVirtualCollector
    assert type(FreeBSDVirtualCollector()) is FreeBSDVirtualCollector



# Generated at 2022-06-25 00:57:15.014632
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:17.983059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_1._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_1._platform == 'FreeBSD'


# Generated at 2022-06-25 00:57:23.694079
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 00:57:28.222402
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:46.952998
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    print('Test constructor of class FreeBSDVirtualCollector')
if snet:
    test_case_0()

# Generated at 2022-06-25 00:57:51.305109
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, FreeBSDVirtual)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:57:53.164961
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_1, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:57:56.115391
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:57:57.817090
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:00.434110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)



# Generated at 2022-06-25 00:58:02.012540
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_2 = FreeBSDVirtual()
    virtual_2.get_virtual_facts()


# Generated at 2022-06-25 00:58:03.905885
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:09.872696
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Unit test for instance attribute FreeBSDVirtualCollector.platform
    # Unit test for method FreeBSDVirtualCollector.collect()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 00:58:13.483242
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass # TODO

# Generated at 2022-06-25 00:58:34.058263
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:36.913980
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    case_0 = FreeBSDVirtualCollector()
    assert case_0._fact_class == "FreeBSDVirtual"
    assert case_0._platform == "FreeBSD"
    assert case_0._requirements == ('sysctl',)



# Generated at 2022-06-25 00:58:38.878335
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()

    assert collector
    assert isinstance(collector, VirtualCollector)
    assert isinstance(collector, FreeBSDVirtualCollector)



# Generated at 2022-06-25 00:58:40.583501
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:44.981927
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    provider = 'qemu'
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': [provider],
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
    }
    actual = free_b_s_d_virtual.get_virtual_facts()
    assert actual == expected

# Generated at 2022-06-25 00:58:47.452696
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Initialize instance of FreeBSDVirtualCollector
    # We do not test all attributes here, because they are tested in another module
    var_1 = FreeBSDVirtualCollector()
    assert isinstance(var_1, FreeBSDVirtualCollector) == 1


# Generated at 2022-06-25 00:58:49.192983
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Instance of class 'FreeBSDVirtualCollector' has no attributes
    pass


# Generated at 2022-06-25 00:58:50.251323
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual_instance = FreeBSDVirtual()
    FreeBSDVirtual_instance.get_virtual_facts()

# Generated at 2022-06-25 00:58:53.147364
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    print(var_1)


# Generated at 2022-06-25 00:58:56.184841
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:59:36.896617
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0_1 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0_1, FreeBSDVirtualCollector)

# Generated at 2022-06-25 00:59:38.466707
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:42.751882
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector)



# Generated at 2022-06-25 00:59:46.781565
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:47.467879
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:59:48.687693
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    var_0 = FreeBSDVirtual()
    var_1 = var_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:50.336404
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:56.064269
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)

    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:56.903701
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:00:00.250232
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:25.987723
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(free_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 01:01:27.227527
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_2 = FreeBSDVirtualCollector()
    assert isinstance(var_2, FreeBSDVirtualCollector)

# Generated at 2022-06-25 01:01:28.761777
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_instance_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_instance_0.get_virtual_facts()


# Generated at 2022-06-25 01:01:32.486129
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:01:41.312937
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert isinstance(FreeBSDVirtualCollector._fact_class(), FreeBSDVirtual)
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_0.collect(free_b_s_d_virtual_collector_0)
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:01:46.039983
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:01:49.969549
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    temp_instance = FreeBSDVirtualCollector()
    assert isinstance(temp_instance, FreeBSDVirtualCollector)



# Generated at 2022-06-25 01:01:54.223170
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except:
        assert False



# Generated at 2022-06-25 01:01:56.798503
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:01:58.008241
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()
