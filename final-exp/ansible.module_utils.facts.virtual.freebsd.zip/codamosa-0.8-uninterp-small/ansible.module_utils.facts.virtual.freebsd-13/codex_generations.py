

# Generated at 2022-06-25 00:54:39.495595
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instantiation of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()

    # Assertion of call: get_platform()
    assert free_b_s_d_virtual_collector.get_platform() == 'FreeBSD', 'Instance call: get_platform() did not return correctly'

# Generated at 2022-06-25 00:54:42.851060
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instance creation
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Testing for attribute '_platform'
    assert hasattr(free_b_s_d_virtual_collector_0, "_platform")
    # Testing for attribute '_fact_class'
    assert hasattr(free_b_s_d_virtual_collector_0, "_fact_class")


# Generated at 2022-06-25 00:54:46.420342
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:54:48.837744
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of class FreeBSDVirtual
    free_b_s_d_virtual_0 = FreeBSDVirtual()

    # Call method get_virtual_facts of FreeBSDVirtual
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:54:50.341970
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    assert free_b_s_d_virtual.get_virtual_facts() == {}

# Generated at 2022-06-25 00:54:53.800420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert free_b_s_d_virtual_collector_0.__class__ == FreeBSDVirtualCollector


# Generated at 2022-06-25 00:54:57.070921
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == dict(
        virtualization_type='',
        virtualization_role='',
    ), 'Test Failed'


# Generated at 2022-06-25 00:55:04.006924
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    response_1 = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }

    assert FreeBSDVirtual().get_virtual_facts() == response_1

# Generated at 2022-06-25 00:55:08.430353
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Positive testing
    # Initialize with no argument
    assert True == isinstance(FreeBSDVirtualCollector(),
                              FreeBSDVirtualCollector)



# Generated at 2022-06-25 00:55:17.520190
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    if os.path.exists('/dev/xen/xenstore'):
        guest_tech.add('xen')
        virtual_facts['virtualization_type'] = 'xen'
        virtual_facts['virtualization_role'] = 'guest'

    kern_vm_guest = VirtualSysctlDetectionMixin.detect_virt_product('kern.vm_guest')
    guest_tech.update(kern_vm_guest['virtualization_tech_guest'])

# Generated at 2022-06-25 00:55:22.921630
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_1 = FreeBSDVirtual(6)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    assert isinstance(var_1, dict) == True


# Generated at 2022-06-25 00:55:24.664949
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    float_0 = -459.402473
    var_0 = free_b_s_d_virtual_0.get_virtual_facts(float_0)


# Generated at 2022-06-25 00:55:25.096567
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:28.451206
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Tests for public instance methods of class FreeBSDVirtualCollector

# Generated at 2022-06-25 00:55:34.677331
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_0 = free_b_s_d_virtual_collector_0.collect()

# End of test_FreeBSDVirtualCollector


# Generated at 2022-06-25 00:55:39.509725
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    # AssertionError: {} != {'virtualization_role': '', 'virtualization_type': ''}
    # var_0: {}
    # 'virtualization_role': ''
    # 'virtualization_type': ''

# Generated at 2022-06-25 00:55:50.043090
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -449.209736
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    float_1 = -824.58
    var_0 = free_b_s_d_virtual_collector_0.collect(float_1, 'hw.model')
    float_2 = -725.6
    var_1 = free_b_s_d_virtual_collector_0.collect(float_2, 'hw.model')
    float_3 = -539.8
    var_2 = free_b_s_d_virtual_collector_0.collect(float_3, 'hw.model')
    free_b_s_d_virtual_collector_0.collect(float_3, 'hw.model')
    free_b_

# Generated at 2022-06-25 00:55:55.272577
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -124.314944
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert len(var_0) == 4
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_tech_guest' in var_0


# Generated at 2022-06-25 00:55:57.619630
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:56:03.868776
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 00:56:11.948360
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    #assert var_0 == , msg("get_virtual_facts did not return expected value")


# Generated at 2022-06-25 00:56:16.303673
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Replace var_0 with actual variable to test
    int_0 = -3
    free_b_s_d_virtual_0 = FreeBSDVirtual(int_0)
    free_b_s_d_virtual_1 = FreeBSDVirtual(int_0)
    free_b_s_d_virtual_0.get_virtual_facts()
    assert free_b_s_d_virtual_0.get_virtual_facts() == free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 00:56:19.707685
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_ansible_module_facts_free_b_s_d_virtual_0()
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 00:56:23.752776
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    dict_0 = free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 00:56:26.250920
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect()
# Tests for FreeBSDVirtual class

# Generated at 2022-06-25 00:56:29.412892
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_2 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:33.510685
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.load_platform_subclass()
    free_b_s_d_virtual_collector_0.get_facts()



# Generated at 2022-06-25 00:56:42.358876
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    float_1 = -459.402473
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    assert free_b_s_d_virtual_1.platform == 'FreeBSD'
    assert free_b_s_d_virtual_1.sysctl_hex2int('hw.hv_vendor', '0')

# Generated at 2022-06-25 00:56:45.119062
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -471.907
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:46.053293
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 00:56:59.090219
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    platforms = ['', '', '']
    free_b_s_d_virtual_0 = FreeBSDVirtualCollector(platforms)


# Generated at 2022-06-25 00:57:02.184232
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_2 = 3.5613459629
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_2)
    var_0 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:57:04.934891
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_v_collector_0 = FreeBSDVirtualCollector()
    var_2 = free_b_s_d_v_collector_0._fact_class
    assert isinstance(var_2, FreeBSDVirtual)


# Generated at 2022-06-25 00:57:06.095734
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    pass

# Generated at 2022-06-25 00:57:08.473699
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:18.297537
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_1 = -459.402473
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    var_1 = virtual_facts['virtualization_type']
    var_2 = virtual_facts['virtualization_role']
    var_3 = virtual_facts['virtualization_tech_guest']
    var_4 = virtual_facts['virtualization_tech_host']
    assert var_1 == '', 'Failed assertion, var != 0'
    assert var_2 == '', 'Failed assertion, var != 0'
    assert 'docker' in var_3, 'Failed assertion, docker not in var'

# Generated at 2022-06-25 00:57:22.948526
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1.virtualization_tech_host == {'xen'}


# Generated at 2022-06-25 00:57:30.806455
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:57:34.892207
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_colle_0 = FreeBSDVirtualCollector()
    return


if __name__ == "__main__":
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 00:57:37.762728
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -85.6359762514
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    assert free_b_s_d_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 00:57:51.707810
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    assert '"x"' in var_0
    assert '"virtualization_tech_guest"' in var_0
    assert '"virtualization_tech_host"' in var_0
    assert '"virtualization_type"' in var_0
    assert '"virtualization_role"' in var_

# Generated at 2022-06-25 00:57:55.208183
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBS

# Generated at 2022-06-25 00:57:59.322727
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0._fact_class
    var_1 = free_b_s_d_virtual_collector_0._platform


# Generated at 2022-06-25 00:58:02.595782
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -123.513847
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:58:05.474945
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
  FACT_INFO = {'freebsd': {'virtualization_type': '', 'virtualization_role': ''}}
  facts = FreeBSDVirtual(FACT_INFO)
  assert facts.get_virtual_facts() == FACT_INFO

# Generated at 2022-06-25 00:58:10.005254
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -159.216934
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)


# Generated at 2022-06-25 00:58:18.714974
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class_0 = FreeBSDVirtualCollector()
    # Expected values
    virtual_facts_value = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    virtualization_type_value = ''
    virtualization_role_value = ''
    virtualization_tech_host_value = set()
    virtualization_tech_guest_value = set()
    
    # Call the method

# Generated at 2022-06-25 00:58:24.317986
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -15.471499
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:25.721994
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert "system.sysctl" in VirtualCollector.detect_virtual_facts().keys()

# Generated at 2022-06-25 00:58:32.839653
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:51.738744
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_1 = -459.402473
    float_2 = -459.402473
    float_3 = -459.402473
    float_4 = -459.402473
    float_5 = -459.402473
    float_6 = -459.402473
    float_7 = -459.402473
    float_8 = -459.402473
    float_9 = -459.402473
    float_10 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_1, float_2, float_3, float_4, float_5, float_6, float_7, float_8, float_9, float_10)
    str_0 = free_b_s_d_virtual_collector

# Generated at 2022-06-25 00:58:58.660113
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(False)
    free_b_s_d_virtual_collector_2 = FreeBSDVirtualCollector(int_0=-77)
    free_b_s_d_virtual_collector_3 = FreeBSDVirtualCollector(False, str_0='', float_0=0.20117769523)
    free_b_s_d_virtual_collector_4 = FreeBSDVirtualCollector(True, True, str_0='/usr/share/ansible/freebsd/virtual/facts.d')


# Generated at 2022-06-25 00:59:04.182400
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)


# Generated at 2022-06-25 00:59:08.440789
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 00:59:12.981878
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': [], 'virtualization_tech_host': []}, 'line 42'


# Generated at 2022-06-25 00:59:16.836433
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 844.93
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:19.778433
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()



if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:59:23.401462
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c0 = FreeBSDVirtualCollector()
    assert c0.platform == 'FreeBSD'


# Generated at 2022-06-25 00:59:29.577275
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0._fact_class(float_0)
    var_1 = free_b_s_d_virtual_collector_0._platform


# Generated at 2022-06-25 00:59:36.931662
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    host_0 = FreeBSDVirtualCollector()
    var_0 = host_0.get_all_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:51.764224
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -271.273575
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:55.346902
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    print("\nTesting __init__()")
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float(-459.402473))
    free_b_s_d_virtual_collector_0.get_all_facts()


# Generated at 2022-06-25 01:00:00.292918
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0



# Generated at 2022-06-25 01:00:04.749058
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:06.887082
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    assert free_b_s_d_virtual_collector_0._fact_class._platform == 'FreeBSD'


# Generated at 2022-06-25 01:00:17.773950
# Unit test for constructor of class FreeBSDVirtualCollector

# Generated at 2022-06-25 01:00:22.900377
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -467.440625
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0.get_all()


# Generated at 2022-06-25 01:00:27.520223
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:32.487228
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test instantiation of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Test method get_collector_platform of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0.get_collector_platform()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:33.607261
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    float_0 = -800.2758
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)

# Generated at 2022-06-25 01:01:11.897601
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:01:15.532066
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    _fact_class = FreeBSDVirtual
    _platform = 'FreeBSD'
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(_fact_class, _platform)
    #assertion
    assert free_b_s_d_virtual_collector_1.fact_class is _fact_class
    assert free_b_s_d_virtual_collector_1.platform is _platform


# Generated at 2022-06-25 01:01:16.168909
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:01:22.388238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:01:26.270172
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 != ""
    assert True


# Generated at 2022-06-25 01:01:27.978076
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:01:33.772717
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Case: 0
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:01:37.417484
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_1 = free_b_s_d_virtual_collector_0.get_all_facts()

# Generated at 2022-06-25 01:01:42.107870
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'

# Generated at 2022-06-25 01:01:49.396147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -643.7156637
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0._platform
    float_1 = 487.234891
    var_1 = free_b_s_d_virtual_collector_0.collect(float_1)


# Generated at 2022-06-25 01:02:52.399613
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # No virtual parameters set
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    # Virtual Type is not set
    assert var_0['virtualization_type'] != 'xen', 'Virtualization_type not detected'
    # Virtual Role is not set
    assert var_0['virtualization_role'] != 'guest', 'Virtualization_role not detected'



# Generated at 2022-06-25 01:02:53.868409
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    print('Test Constructor')
    FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:56.121805
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Command execution error for the method get_virtual_facts of class FreeBSDVirtual
    float_1 = -933.078645
    my_FreeBSDVirtual = FreeBSDVirtual(float_1)
    assert my_FreeBSDVirtual.get_virtual_facts() == var_0

test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:03:01.648740
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    free_b_s_d_virtual_0 = FreeBSDVirtual(facts)
    free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:03:09.086773
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0

# Generated at 2022-06-25 01:03:11.288236
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -459.402473
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)

# Generated at 2022-06-25 01:03:12.608534
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'

# Generated at 2022-06-25 01:03:17.745290
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:03:27.079291
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(0.0)
    free_b_s_d_virtual_1 = FreeBSDVirtual(0.0)
    free_b_s_d_virtual_0 = FreeBSDVirtual(0.0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 01:03:31.013038
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -459.402473
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert len(var_0['virtualization_tech_host']) == 0
    assert len(var_0['virtualization_tech_guest']) == 2