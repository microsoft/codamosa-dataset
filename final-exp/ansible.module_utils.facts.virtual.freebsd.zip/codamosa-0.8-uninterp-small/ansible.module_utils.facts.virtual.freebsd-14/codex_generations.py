

# Generated at 2022-06-25 00:54:41.231920
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()

    virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()

    assert virtual_facts == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()}

# Generated at 2022-06-25 00:54:47.463059
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    print(free_b_s_d_virtual_0.get_virtual_facts())

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:54:48.707231
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:52.512984
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_FreeBSDVirtual_get_virtual_facts = FreeBSDVirtual()
    assert fake_FreeBSDVirtual_get_virtual_facts.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 00:54:55.429140
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert callable(FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:55:00.213329
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tmp_free_b_s_d_virtual_1 = FreeBSDVirtual()
    tmp_free_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 00:55:03.353990
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor with no arguments
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual



# Generated at 2022-06-25 00:55:07.157913
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:08.271129
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual_obj = FreeBSDVirtual()
    FreeBSDVirtual_obj.get_virtual_facts()

# Generated at 2022-06-25 00:55:11.854102
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
  assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
  assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:55:18.389034
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-25 00:55:20.914380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    ret_0 = free_b_s_d_virtual_0.get_virtual_facts()
    # assert ret_0['virtualization_type'] == ''


# Generated at 2022-06-25 00:55:21.639867
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:55:22.201202
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert 'FreeBSDVirtualCollector'


# Generated at 2022-06-25 00:55:23.560402
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)

# Generated at 2022-06-25 00:55:26.933457
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 00:55:32.502356
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert(free_b_s_d_virtual_collector._fact_class == FreeBSDVirtual)
    assert(free_b_s_d_virtual_collector._platform == 'FreeBSD')

# Generated at 2022-06-25 00:55:38.626348
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()
    virtual_facts_keys = virtual_facts.keys()
    assert 'virtualization_type' in virtual_facts_keys
    assert 'virtualization_role' in virtual_facts_keys
    assert 'virtualization_tech_guest' in virtual_facts_keys
    assert 'virtualization_tech_host' in virtual_facts_keys


# Generated at 2022-06-25 00:55:41.083834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert test_case_0() == None



# Generated at 2022-06-25 00:55:46.008479
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual({})
    return_value_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert return_value_0 == {
        'virtualization_type': '',
        'virtualization_role': ''
    }



# Generated at 2022-06-25 00:55:53.930023
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    assert 'virtualization_role' not in free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:55.133618
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:04.604181
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech': set(),
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_full': set(),
    }

    bytes_1 = b'\x03\r\xdd\xb1\x15\x90H\xbd\xe4\x8e\x9d'

# Generated at 2022-06-25 00:56:05.419359
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()


# Generated at 2022-06-25 00:56:13.356011
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector._fact_class
    var_1 = free_b_s_d_virtual_collector._platform
    var_2 = free_b_s_d_virtual_collector.collect()
    var_3 = free_b_s_d_virtual_collector.collect()
    var_4 = free_b_s_d_virtual_collector
    var_5 = free_b_s_d_virtual_collector
    var_6 = free_b_s_d_virtual_collector.collect()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:15.150983
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor without parameters
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Constructor with parameters
    dict_0 = dict()
    dict_0['platform'] = 'FreeBSD'
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(dict_0)

# Generated at 2022-06-25 00:56:15.621613
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 00:56:19.663519
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    assert free_b_s_d_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-25 00:56:26.995082
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 00:56:32.779845
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'host', 'virtualization_type': 'physical', 'virtualization_tech_host': set()}


# Generated at 2022-06-25 00:56:42.009700
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'\xa0\x19\x87\xdd\xd2\xc1\xbb\xea\xec\x85\xaa\xd3\x06\xeb\x8c\x99'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

# Generated at 2022-06-25 00:56:43.708461
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    expected = FreeBSDVirtualCollector()
    assert expected._platform == 'FreeBSD'

# Generated at 2022-06-25 00:56:53.221390
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-25 00:57:03.006979
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    with open('tests/unit/module_utils/facts/virtualization/FreeBSD/test_FreeBSDVirtual_get_virtual_facts.txt', 'r') as f:
        test_case = eval(f.read())
    # test_case_0
    bytes_0 = bytes(test_case['test_case_0']['bytes_0'])
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == test_case['test_case_0']['var_0']

# Generated at 2022-06-25 00:57:10.170876
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    # If var_0 is not of type dict, we will assign value for var_0
    if not isinstance(var_0, dict):
        var_0 = {}
    # We will set the virtualization_type key for dict var_0
    var_0['virtualization_type'] = ''

    # We will set the virtualization_role key for dict var_0
    var_0['virtualization_role'] = ''
    assert var_0['virtualization_role'] == ''
   

# Generated at 2022-06-25 00:57:14.417376
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    test_case_0(bytes_0)

# Generated at 2022-06-25 00:57:18.723547
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:57:19.394886
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass


# Generated at 2022-06-25 00:57:25.587691
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    text_0 = '\r\r\r\r\r\r\r\r)$\x89\xad\xdc\x9d\xcc\xb6\xfa\x0e\x1a'
    free_b_s_d_virtual_0 = FreeBSDVirtual(text_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    # assert var_0 ==



# Generated at 2022-06-25 00:57:26.093756
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True

# Generated at 2022-06-25 00:57:40.965252
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_guest'].issubset(set(['vbox', 'vmware', 'xen_pv', 'xen_hvm', 'jail']))
    assert var_0['virtualization_tech_guest'].issubset(set(['vbox', 'vmware', 'xen_pv', 'xen_hvm', 'jail']))

# Generated at 2022-06-25 00:57:43.252797
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert (getattr(FreeBSDVirtualCollector, '_fact_class') == FreeBSDVirtual)
    assert (getattr(FreeBSDVirtualCollector, '_platform') == 'FreeBSD')

# Generated at 2022-06-25 00:57:51.273684
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    var_2 = free_b_s_d_virtual_0.detect_virt_product('hw.model')
    var_3 = free_b_s_d_virtual_0.detect_virt_product('hw.hv_vendor')
    var_4 = free_b_s_d_virtual_0.detect_virt_product('kern.vm_guest')
    var_5 = free_b_s_d_virtual_0.detect_virt

# Generated at 2022-06-25 00:57:56.288922
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict) == True
    assert var_0 == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 00:58:02.980439
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'7\xe0\x05\x09\x97\x9d\x13\xef\x81\x80'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['docker', 'lxc']), 'virtualization_type': 'docker'}, 'get_virtual_facts returned different value than expected'


# Generated at 2022-06-25 00:58:10.869202
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    free_b_s_d_virtual_0.detect_virt_product = lambda x: return_value_1
    free_b_s_d_virtual_0.detect_virt_vendor = lambda x: return_value_2
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_role'] == 'guest'
    assert var_0

# Generated at 2022-06-25 00:58:15.482383
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector(_fact_class=FreeBSDVirtual, _platform='FreeBSD')
    assert result != None
    assert result.fact_class == FreeBSDVirtual
    assert result.platform == 'FreeBSD'

# Generated at 2022-06-25 00:58:20.270991
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert var_0 == {
        'virtualization_type': '',
        'virtualization_role': ''
        }

# Generated at 2022-06-25 00:58:27.979718
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'Y\x0b\x9c\x89\xef\x90\x14\x10\xe1\x04\xa0\xcf\x9c'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:33.812631
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 00:58:51.138365
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)

# Generated at 2022-06-25 00:58:57.279763
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': {},
        'virtualization_type': 'xen'
    }

# Generated at 2022-06-25 00:58:58.590939
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    return

# Generated at 2022-06-25 00:59:01.082547
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_1 = b'\xd0e\x8f\x88\x19\xd7\xea\xa72\x14\xda'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_1)

# Generated at 2022-06-25 00:59:02.498015
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:08.469030
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Testing the __init__ method of class FreeBSDVirtualCollector
    # Initiating a FreeBSDVirtualCollector object
    # assertEqual(first, second, msg=None)
    # first: The first value to compare.
    # second: The second value to compare.
    # msg: Optional message to use on failure instead of a list of differences.
    # Verify that the instance is correctly initiated by checking the _fact_class value
    # The _fact_class key's value should be FreeBSDVirtual
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

if __name__ == "__main__":
    test_FreeBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 00:59:11.596700
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    test_case_0()

# Generated at 2022-06-25 00:59:17.233718
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bytes_0 = b'^Z\x17\x9e\xd7t\xf8\xf6\xa9p\xef\xc4'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bytes_0)


# Generated at 2022-06-25 00:59:22.081180
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    if isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector):
        pass
    else:
        raise Exception('Failed to create instance of class FreeBSDVirtualCollector')


# Generated at 2022-06-25 00:59:31.978069
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x02\xa6\x97\x8e\xdd\xac\xe1\x9b\xfb\xee\x13\x0c\x8a\x88\xdc\xdb\xc3\x1e\x91\xfa\xfd\x7fd\x08\x1d\x01\xfc>\x9a\x8d\x84\x14\x83\x8b\x83\xd0\x03\xb7\x0c\xcc\x90\xf6'
    free_b_s_d_virtual_0 = FreeBSDVirtual(bytes_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:57.790283
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = None


# Generated at 2022-06-25 01:00:01.755680
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:00:03.839085
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == ({'virtualization_role': '', 'virtualization_type': ''}, ['hw_model', 'kern_vm_guest', 'sec_jail_jailed'])


# Generated at 2022-06-25 01:00:05.921478
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert True


# Generated at 2022-06-25 01:00:09.829448
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class FreeBSDVirtual
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:00:11.760143
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:00:15.841727
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

    print('Success!')

# Generated at 2022-06-25 01:00:21.076350
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_data = {
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
    }
    free_b_s_d_virtual_0 = FreeBSDVirtual({})
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == virtual_facts_data


# Generated at 2022-06-25 01:00:23.609436
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

    # Verify the correct FreeBSDVirtual is used
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, FreeBSDVirtual)


# Generated at 2022-06-25 01:00:28.087638
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector == type(
        free_b_s_d_virtual_collector_0)



# Generated at 2022-06-25 01:01:32.461423
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:37.541004
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_virtual_facts = {'virtualization_type': '',
                          'virtualization_role': ''}
    assert FreeBSDVirtual().get_virtual_facts() == fake_virtual_facts

# Generated at 2022-06-25 01:01:38.566306
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:39.459530
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector() is not None


# Generated at 2022-06-25 01:01:43.844065
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0._module = MockFreeBSDModule0()
    free_b_s_d_virtual_0._module.params = {}
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0

# Generated at 2022-06-25 01:01:45.034552
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:01:47.007978
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:49.749223
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:55.911619
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == {'virtualization_role': 'guest',
                     'virtualization_type': 'xen',
                     'virtualization_tech_guest': {'xen'},
                     'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:02:00.768222
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Creating an instance of the class FreeBSDVirtual
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    return True # Returning a boolean value


# Generated at 2022-06-25 01:04:09.551222
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    if free_b_s_d_virtual.sysctl_facts['hw.vendor'] == 'QEMU':
        free_b_s_d_virtual.sysctl_facts['hw.model'] = 'Broadwell-IBRS'
    if free_b_s_d_virtual.sysctl_facts['hw.vendor'] == 'Microsoft':
        free_b_s_d_virtual.sysctl_facts['hw.model'] = 'Virtual Machine'
    if free_b_s_d_virtual.sysctl_facts['hw.vendor'] == 'KVM':
        free_b_s_d_virtual.sysctl_facts['hw.model'] = 'Common KVM processor'

# Generated at 2022-06-25 01:04:14.523398
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)

# Generated at 2022-06-25 01:04:18.458310
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:04:21.291887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': {}, 'virtualization_tech_host': {}}


# Generated at 2022-06-25 01:04:24.279521
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_1, FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:04:29.253952
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_1._platform == 'FreeBSD'
