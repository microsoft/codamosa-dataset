

# Generated at 2022-06-25 00:54:38.850556
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:39.296246
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass

# Generated at 2022-06-25 00:54:40.662346
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    return free_b_s_d_virtual_collector


# Generated at 2022-06-25 00:54:45.350095
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_class_constructor = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:46.745708
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:51.762983
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()

    # Unit tests for method get_virtual_facts of class FreeBSDVirtual
    assert free_b_s_d_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 00:54:56.158021
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:54:57.868453
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:54:58.547968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:08.461650
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_FreeBSDVirtual_get_virtual_facts_data = [
        ('/dev/xen/xenstore')
    ]

    test_FreeBSDVirtual_get_virtual_facts_return = (
        {'virtualization_type': 'xen', 'virtualization_role': 'guest',
            'virtualization_tech_host': set(),
            'virtualization_tech_guest': set(['xen'])}
    )

    for test in test_FreeBSDVirtual_get_virtual_facts_data:
        if test:
            os.path.exists = MagicMock(return_value=True)
            if test == '/dev/xen/xenstore':
                kern_vm_guest = {}
                hw_hv_vendor = {}
                sec_jail_jailed = {}


# Generated at 2022-06-25 00:55:16.599268
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    str_0 = 'sBJuR\x1c6\x9e\x1c.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:55:20.330898
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}



# Generated at 2022-06-25 00:55:25.191582
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # test instantiation of class
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # test __class__ attribute
    assert(type(free_b_s_d_virtual_collector_0.__class__)  == type(FreeBSDVirtualCollector), "test failed")
    # test __doc__ attribute
    assert(type(free_b_s_d_virtual_collector_0.__doc__)  == type(str()), "test failed")
    # test __module__ attribute
    assert(free_b_s_d_virtual_collector_0.__module__  == 'ansible.module_utils.facts.virtual.freebsd', "test failed")
    # test _fact_class attribute

# Generated at 2022-06-25 00:55:27.112487
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert not hasattr(FreeBSDVirtualCollector, '_platform')
    assert not hasattr(FreeBSDVirtualCollector, '_fact_class')
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:35.008977
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:38.414417
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.get_fact_class()


# Generated at 2022-06-25 00:55:44.643790
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


test_case_0()

# Generated at 2022-06-25 00:55:51.204246
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'U"\x19\x1a(29s^\x03\x0e\x0f\x19\x1a!=w^\x19\x1a\x0c\x0f\x03\x0e\x0f\x19\x1a\x19\x1a\x0c\x0f'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:54.512476
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector.get_all()


# Generated at 2022-06-25 00:55:56.496111
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)


# Generated at 2022-06-25 00:56:05.011440
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '8\x1e\x08n\n\x18`\r\x0f\x07\x1f\x1e'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 00:56:13.260837
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-25 00:56:17.374439
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Create an instance of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:56:27.112281
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Initialize a FreeBSDVirtualCollector object
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

if __name__ == '__main__':
    printf("%s\n" % test_case_0(), end=u'')
    printf("%s\n" % test_FreeBSDVirtualCollector(), end=u'')

# Generated at 2022-06-25 00:56:30.755348
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'm\x1fC,\x1e\x1b'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:35.220131
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:56:40.789213
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''

# Generated at 2022-06-25 00:56:48.795987
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''

# Generated at 2022-06-25 00:56:51.732752
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    case_0 = {'virtualization_tech_guest': set(), 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_role': ''}
    assert case_0 == FreeBSDVirtual().get_virtual_facts()

    # case_1 = {'virtualization_tech_host': set(), 'virtualization_type':
    # 'virtualbox', 'virtualization_tech_guest': {'virtualbox'},
    # 'virtualization_role': 'guest'}
    # assert case_1 == FreeBSDVirtual().get_virtual_facts()


# Generated at 2022-06-25 00:56:57.698788
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'Dk.\x1f\x0c\x0f\x1e\x10\x00\x1d\x0b\x13\x1f\x19'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    str_1 = 'host'
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == str_1
    str_2 = 'FreeBSD'
    assert var_0['virtualization_type'] == str_2

# Generated at 2022-06-25 00:57:10.150551
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'E\x15\x17B\x1f\x1e'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_role': ''}

# Generated at 2022-06-25 00:57:15.569032
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'FreeBSD'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:57:19.307922
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()


if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:57:28.480896
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-25 00:57:32.489113
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:36.812724
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:44.996646
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Declare object of FreeBSdVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Assert type of free_b_s_d_virtual_collector_0 is FreeBSDVirtualCollector
    if not isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector):
        raise AssertionError(
            "Expected type is FreeBSDVirtualCollector, actual type is {}".format(
                type(free_b_s_d_virtual_collector_0)))

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()
    print("All tests are passed.")

# Generated at 2022-06-25 00:57:48.400381
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 00:57:50.672806
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)


# Generated at 2022-06-25 00:57:57.859478
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'D\rpX\x17\x05\x0f\x10\x0b\x1f\x1a\x1f\x1a\x0e'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    dict_1 = {'virtualization_tech_guest': set(),
              'virtualization_tech_host': {'unknown'},
              'virtualization_type': 'unknown',
              'virtualization_role': 'guest'}
    assert free_b_s_d_virtual_collector_0.get_virtual_facts() == dict_1

# Generated at 2022-06-25 00:58:06.459291
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:11.389223
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:58:15.516533
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:58:21.890400
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:26.169249
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0.get_all()

# Generated at 2022-06-25 00:58:33.309368
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # invocation
    # constructor of class FreeBSDVirtualCollector
    # assert equality
    assert (FreeBSDVirtualCollector._platform == 'FreeBSD')
    # assert equality
    assert (FreeBSDVirtualCollector._fact_class == FreeBSDVirtual)
    # return the value
    # return the value


# Generated at 2022-06-25 00:58:35.942513
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._sysctl_base_dict is None


# Generated at 2022-06-25 00:58:42.722052
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    host_1 = 'localhost'
    Free_BSD_virtual_collector_0 = FreeBSDVirtualCollector(host_1)
    var_0 = Free_BSD_virtual_collector_0._fact_class
    var_1 = Free_BSD_virtual_collector_0._platform
    var_2 = Free_BSD_virtual_collector_0._virt_subclass
    var_3 = Free_BSD_virtual_collector_0._virt_subclass_init_args
    var_4 = Free_BSD_virtual_collector_0.platform
    var_5 = Free_BSD_virtual_collector_0.get_virtual_facts()
    Free_BSD_virtual_collector_0.collect()

# Generated at 2022-06-25 00:58:48.399240
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_guest'] == \
        set(['virtualbox', 'qemu', 'kvm'])
    assert var_0['virtualization_tech_host'] == \
        set(['vmware', 'hyperv', 'kvm'])

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:58:51.351149
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == None



# Generated at 2022-06-25 00:59:05.128530
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

FactsClass = FreeBSDVirtual
FactsCollectorClass = FreeBSDVirtualCollector

# Generated at 2022-06-25 00:59:14.171785
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test for constructor of class FreeBSDVirtualCollector
    # Unit test for inspection of the private attributes of class FreeBSDVirtualCollector

    # Test for the private attribute _fact_class
    # The _fact_class attribute is initialized in the constructor of the parent class
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector('7G;\x1b/\x1a$')
    var_0 = free_b_s_d_virtual_collector_0._fact_class
    # Test for the private attribute _platform
    # The _platform attribute is initialized in the constructor of the parent class
    var_1 = free_b_s_d_virtual_collector_0._platform

# Generated at 2022-06-25 00:59:17.168578
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 00:59:19.951315
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:59:27.560281
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'f@x'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_guest'].union(var_0['virtualization_tech_host']) == {'unknown'}


# Generated at 2022-06-25 00:59:29.788028
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)



# Generated at 2022-06-25 00:59:33.307609
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    sys_info_0 = {'tmpdir': 'tmpdir'}
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(sys_info_0)

# Generated at 2022-06-25 00:59:34.908118
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)


# Generated at 2022-06-25 00:59:35.308475
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 00:59:41.753707
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Assign values to variables
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0.data = str_0

    # Call function to test
    ret_0 = free_b_s_d_virtual_collector_0._get_fact_class()
    # Verify results

    # Assign values to variables
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_1.data = str_0

    # Call function to test
    ret_1 = free_b_s_d_virtual_collector_1._get_fact_class()
   

# Generated at 2022-06-25 01:00:07.901243
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:00:14.727502
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_inter_0 = str()
    free_b_s_d_virtual_inter_1 = str()
    free_b_s_d_virtual_0 = FreeBSDVirtual(free_b_s_d_virtual_inter_0, free_b_s_d_virtual_inter_1)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:00:20.457567
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_1 = 'D\n\x0c\x0e\x0e\r\x0e\x0e\x0e\x0e\x0e\x0e\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:00:23.649130
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Tests the constructor of FreeBSDVirtualCollector
    # For more details refer constructor of class
    # FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:29.048350
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.get_all_facts()


# Generated at 2022-06-25 01:00:33.928096
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.get_all_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:36.874646
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_1 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:00:45.244826
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    str_1 = 'bv&\x0cU\x0b\x0c\x7f^\n'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:00:46.533659
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:00:47.051155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass

# Generated at 2022-06-25 01:01:27.573467
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    str_0 = 'S"PR8D\tnQ\x0bI.'
    var_0 = free_b_s_d_virtual_collector_0.collect(str_0)
    assert var_0

# Generated at 2022-06-25 01:01:28.752577
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:01:33.035775
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Create an instance of FreeBSDVirtualCollector.
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:42.339699
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # In case of failure, argv[1] is a string containing a line number
    # and a failure message
    if len(sys.argv) > 1:
        sys.exit(int(sys.argv[1]))

    # Example data
    # str_1 = 'S"PR8D\tnQ\x0bI.'
    # free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_1)
    # str_0 = 'S"PR8D\tnQ\x0bI.'
    # free_b_s_d_virtual_1 = FreeBSDVirtual(str_0)
    # free_b_s_d_virtual_collector_0.add_virtual(free_b_s_d_virtual_1)
    # var_0 = free_b_s

# Generated at 2022-06-25 01:01:47.739501
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:01:53.956941
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # check that FreeBSDVirtualCollector instance is created
    assert FreeBSDVirtualCollector()
    # check that exception is not thrown
    try:
        FreeBSDVirtualCollector()
    except Exception:
        assert False, 'Unexpected exception was thrown'

# Generated at 2022-06-25 01:01:55.168843
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert(callable(FreeBSDVirtual.get_virtual_facts))


# Generated at 2022-06-25 01:02:03.573296
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

if __name__ == '__main__':
    # Unit test for class FreeBSDVirtual
    test_case_0()

    # Unit test for constructor of class FreeBSDVirtualCollector
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:02:07.447691
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_0
    assert var_0['virtualization_role'] == ''
    assert str(type(var_0['virtualization_tech_host'])) == "<type 'set'>"
    assert var_0['virtualization_type'] == 'xen'
    assert var_0['virtualization_tech_guest'] == set(['xen'])
# unit test for class FreeBSDVirtualCollector

# Generated at 2022-06-25 01:02:14.296213
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = free_b_s_d_virtual_collector_0.collect(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:02:44.862496
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:02:48.905674
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:02:50.713763
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'h_\x0c\x0b\x14'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 01:02:58.487733
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'H\x0b\x16\x0e\x0b'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

if (__name__ == '__main__'):
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:03:01.789970
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    test_case_0()

# Generated at 2022-06-25 01:03:06.448927
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'y\x90\xc4w'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 01:03:16.980702
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '\x1d\x1e\x1d\x1f\x1e\x1d\x1e\x1d\x1f\x1e\x1d\x1e\x1d\x1f\x1e\x00\x01\x08\x09\x06\x10\x11\x1d\x1f\x1e\x1d\x1e\x1d\x1f\x1e\x1d\x1e\x1d\x1f\x1e\x00\x01\x08\x09\x06\x10\x11'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0

# Generated at 2022-06-25 01:03:26.090258
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    string_0 = 'mK\x14\x13\x18\x0e\x04\x1cgf\x1a"\x0f\r\x0b'
    free_b_s_d_virtual_0 = FreeBSDVirtual(string_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert type(var_0) is dict
    assert len(var_0) == 4
    string_1 = ''
    assert var_0['virtualization_type'] is string_1
    string_2 = '\x1a\x1624\x04\t\x03\x17\x12\x18\x02\x05?\x1dN\x0b7\x18'

# Generated at 2022-06-25 01:03:30.613294
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0._fact_class
    assert (var_0 == FreeBSDVirtual)
    var_1 = free_b_s_d_virtual_collector_0._platform
    assert (var_1 == 'FreeBSD')


# Generated at 2022-06-25 01:03:38.380493
# Unit test for constructor of class FreeBSDVirtualCollector

# Generated at 2022-06-25 01:04:14.669728
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.get_all_facts()

# Generated at 2022-06-25 01:04:22.191357
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-25 01:04:25.945485
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = 'S"PR8D\tnQ\x0bI.'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()
    print(var_0)


# Generated at 2022-06-25 01:04:34.524147
# Unit test for constructor of class FreeBSDVirtualCollector