

# Generated at 2022-06-25 00:54:38.861829
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True == True


# Generated at 2022-06-25 00:54:40.011173
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        test_case_0()
    except:
        print("Failed")

if __name__ == "__main__":
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:41.498818
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    print("Unit test for constructor of class FreeBSDVirtualCollector")
    print(FreeBSDVirtualCollector())


# Generated at 2022-06-25 00:54:50.643076
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_0_dict = dict()
    virtual_facts_0_dict['virtualization_type'] = ''
    virtual_facts_0_dict['virtualization_role'] = ''
    virtual_facts_0_dict['virtualization_tech_host'] = 'set()'
    virtual_facts_0_dict['virtualization_tech_guest'] = 'set()'
    free_b_s_d_virtual_0 = FreeBSDVirtual(virtual_facts_0_dict)
    free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:54:58.208316
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert free_b_s_d_virtual_0.get_virtual_facts().keys() == ['virtualization_type',
                                                   'virtualization_role']


# Generated at 2022-06-25 00:55:07.479527
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class Dummy_FreeBSDVirtual:
        def __init__(self, params):
            self.params = params
            self.platform = 'FreeBSD'
            self.distribution = None

        def detect_virt_product(self, sysctl_name):
            return {u'virtualization_tech_guest': set(),
                    u'virtualization_tech_host': set(),
                    u'virtualization_type': u'',
                    u'virtualization_role': u''}

        def detect_virt_vendor(self, model_name):
            return {u'virtualization_tech_guest': set(),
                    u'virtualization_tech_host': set(),
                    u'virtualization_type': u'',
                    u'virtualization_role': u''}

    x = Dummy_FreeBSDVirtual({})
    assert {}

# Generated at 2022-06-25 00:55:12.402929
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtual_facts': {
            'virtualization_role': '',
            'virtualization_type': '',
            'virtualization_tech_guest': set([]),
            'virtualization_tech_host': set([])
        }
    }

# Generated at 2022-06-25 00:55:14.611714
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:55:16.754623
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0 is not None

# Generated at 2022-06-25 00:55:22.993302
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Test for equality
    assert free_b_s_d_virtual_collector_0.__dict__ == {'_fact_class': FreeBSDVirtual, '_platform': 'FreeBSD', 'cache': False, 'kernel': 'FreeBSD', 'fallback_facts': {}, '__module__': 'ansible.module_utils.facts.virtual.freebsd', '__doc__': None}


# Generated at 2022-06-25 00:55:35.256844
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0, object)


# Generated at 2022-06-25 00:55:39.629556
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_var_1 = ()
    free_b_s_d_virtual_collector_var_1 = FreeBSDVirtualCollector(tuple_var_1)
    assert_true(isinstance(free_b_s_d_virtual_collector_var_1, FreeBSDVirtualCollector))


# Generated at 2022-06-25 00:55:41.113155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    var_1 = FreeBSDVirtualCollector(tuple_0)
    var_2 = var_1.collect()

# Generated at 2022-06-25 00:55:43.145723
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:47.321154
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'

# Generated at 2022-06-25 00:55:51.622722
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass

if __name__ == '__main__':
    test_case_0()

    # Unit test for constructor of class FreeBSDVirtualCollector
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:01.391634
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    # AssertionError: {'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set()}
    #  != {'virtualization_tech_guest': set(), 'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set()}
    # var_0: {'virtualization_tech_guest': set(), 'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set()}


## parse sysctl output
#sys

# Generated at 2022-06-25 00:56:04.020057
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 00:56:07.488447
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    dict_0 = {'virtualization_tech_host': set([]), 'virtualization_type': '', 'virtualization_tech_guest': set([]), 'virtualization_role': ''}
    assert dict_0 == var_0


# Generated at 2022-06-25 00:56:12.640371
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 00:56:21.204085
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == dict(
        virtualization_role='guest',
        virtualization_tech_guest={'xen'},
        virtualization_tech_host={'xen'},
        virtualization_type='xen'
    )


# Generated at 2022-06-25 00:56:24.737988
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:26.665557
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 00:56:29.766425
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:32.379248
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:37.907153
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 00:56:45.771913
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()


# Generated at 2022-06-25 00:56:48.708349
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)

# Generated at 2022-06-25 00:56:51.584996
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert free_b_s_d_virtual_collector_0 is not None


# Generated at 2022-06-25 00:56:53.334631
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 00:57:02.651380
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # noop for now.
    pass

# Generated at 2022-06-25 00:57:07.956156
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 00:57:14.414791
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_techno_guest': set([]), 'virtualization_techno_host': set([])}


# Generated at 2022-06-25 00:57:21.105283
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_1 = FreeBSDVirtual({})
    var_1 = free_b_s_d_virtual_1.get_all_the_facts()


# Generated at 2022-06-25 00:57:23.762904
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:57:30.348908
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    # Constructor of class FreeBSDVirtualCollector without arguments
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:57:32.500544
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:57:33.704711
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 00:57:35.465732
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:37.798903
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    var_0 = free_b_s_d_virtual_collector_0.fetch_all()


# Generated at 2022-06-25 00:58:00.561791
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor: FreeBSDVirtualCollector(...) initializes
    # instance of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    return

# Generated at 2022-06-25 00:58:03.821911
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:09.424901
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_1 = ()
    free_b_s_d_virtual_1 = FreeBSDVirtual(tuple_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {'virtualization_role': '', 'virtualization_tech_guest': set([]),
            'virtualization_tech_host': set([]), 'virtualization_type': ''}, "Return value of method get_virtual_facts of class FreeBSDVirtual: %s" % var_1


# Generated at 2022-06-25 00:58:15.097511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Case 0
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    # Should not raise any exception

# Generated at 2022-06-25 00:58:21.196097
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    var_0 = free_b_s_d_virtual_collector_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:26.086972
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:58:32.304029
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)

    # Assertion 1
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_type' in var_0


# Generated at 2022-06-25 00:58:35.594833
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    print(free_b_s_d_virtual_collector_0.get_all_facts())

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:45.143589
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert len(var_0) == 5
    assert type(var_0) == dict
    assert 'virtualization_role' in var_0
    assert type(var_0['virtualization_role']) == str
    assert 'virtualization_type' in var_0
    assert type(var_0['virtualization_type']) == str
    assert 'virtualization_tech_guest' in var_0
    assert type(var_0['virtualization_tech_guest']) == set
    assert 'virtualization_tech_host' in var_0

# Generated at 2022-06-25 00:58:48.350078
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:59:45.882954
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:59:47.699173
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 00:59:50.634813
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:59:52.229084
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:00:02.496576
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    free_b_s_d_virtual_0._detect_virt_vendor = lambda arg_1: {'virtualization_tech_host': set('virtualization_tech_host'), 'virtualization_type': 'virtualization_type', 'virtualization_tech_guest': set('virtualization_tech_guest'), 'virtualization_role': 'virtualization_role'}

# Generated at 2022-06-25 01:00:06.134881
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:00:07.974898
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 01:00:18.831732
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_1 = ()
    free_b_s_d_virtual_1 = FreeBSDVirtual(tuple_1)
    tuple_2 = ()
    free_b_s_d_virtual_2 = FreeBSDVirtual(tuple_2)
    expected_1 = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    actual_1 = free_b_s_d_virtual_2.get_virtual_facts()
    assert expected_1 == actual_1
    expected_0 = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:00:20.282456
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 01:00:23.551085
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test with no argument
    tuple_1 = ()
    free_b_s_d_virtual_1 = FreeBSDVirtual(tuple_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:01:27.885749
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:01:33.402040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:01:36.011563
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': {'xen'}, 'virtualization_role': 'guest', 'virtualization_type': 'xen'}


# Generated at 2022-06-25 01:01:42.727364
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:01:49.238616
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:01:57.504599
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    free_b_s_d_virtual_0.sysctl = method_0
    free_b_s_d_virtual_0.detect_virt_product = method_1
    free_b_s_d_virtual_0.detect_virt_vendor = method_2
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert "virtualization_tech_host" == var_0['virtualization_tech_host']
    assert "virtualization_tech_guest" == var_0['virtualization_tech_guest']
    assert "virtualization_type" == var_0['virtualization_type']
    assert "virtualization_role" == var

# Generated at 2022-06-25 01:02:00.148474
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)


# Generated at 2022-06-25 01:02:06.037467
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_type'] == 'xen'

# Generated at 2022-06-25 01:02:13.782602
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    tuple_0 = ()
    var_0 = get_virtual_facts(free_b_s_d_virtual_0, tuple_0)
    assert var_0 == {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}

# Generated at 2022-06-25 01:02:20.968687
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    tuple_0 = ()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(tuple_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)


# Generated at 2022-06-25 01:04:28.103232
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert('FreeBSD' == FreeBSDVirtualCollector._platform)
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert(freebsd_virtual_collector._get_vendor_from_sysctl('hw.model') == ['hw.model'])
    assert(freebsd_virtual_collector._get_vendor_from_sysctl('hw.hv_vendor') == ['hw.hv_vendor'])

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:04:31.124801
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    free_b_s_d_virtual_0 = FreeBSDVirtual(tuple_0)
    method_0 = free_b_s_d_virtual_0.get_virtual_facts
    tuple_1 = (method_0,)
    free_b_s_d_virtual_0.get_virtual_facts = lambda : method_0()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:04:34.855658
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_collector = FreeBSDVirtualCollector()
    assert fact_collector.platform == "FreeBSD"
    assert fact_collector._fact_class == FreeBSDVirtual
