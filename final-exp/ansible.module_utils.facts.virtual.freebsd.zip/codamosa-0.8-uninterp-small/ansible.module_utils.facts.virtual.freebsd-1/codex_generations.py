

# Generated at 2022-06-25 00:54:41.737726
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '',
                                                       'virtualization_type': '',
                                                       'virtualization_tech_host': set(),
                                                       'virtualization_tech_guest': set()}


# Generated at 2022-06-25 00:54:48.839683
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    print("##### Unit test for constructor of class FreeBSDVirtualCollector #####")
    # No argument passed
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

    # Non-bool argument passed
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector("abc")

    # Passing bool as argument
    free_b_s_d_virtual_collector_2 = FreeBSDVirtualCollector(True)


# Generated at 2022-06-25 00:54:50.343529
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 00:54:55.082506
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 00:55:02.460900
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_1 = FreeBSDVirtual(False).get_virtual_facts()
    assert virtual_facts_1['virtualization_type'] == 'vbox'
    assert virtual_facts_1['virtualization_role'] == 'guest'
    assert virtual_facts_1['virtualization_tech_guest'] == set(['vbox'])
    assert virtual_facts_1['virtualization_tech_host'] == set()

# Generated at 2022-06-25 00:55:04.004665
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(0)


# Generated at 2022-06-25 00:55:08.809784
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts()
    """
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:11.625193
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:22.276352
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os.path.exists = MagicMock(return_value=True)
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_0.detect_virt_product = MagicMock(return_value={'virtualization_type': 'xenhvm', 'virtualization_role': 'guest', 'virtualization_tech_host': {}, 'virtualization_tech_guest': {'xenhvm'}})
    free_b_s_d_virtual_0.detect_virt_vendor = MagicMock(return_value={'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': {'bhyve'}, 'virtualization_tech_guest': {}})

    #

# Generated at 2022-06-25 00:55:24.283133
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except NameError:
        assert False, "Unit test for constructor of 'FreeBSDVirtualCollector' class failed."
    else:
        assert True, "Unit test for constructor of 'FreeBSDVirtualCollector' class passed."


# Generated at 2022-06-25 00:55:32.359163
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    this_instance = FreeBSDVirtualCollector()
    assert this_instance._platform == 'FreeBSD'
    assert this_instance._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:35.134849
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:40.687093
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Define the dict used to pass to get_virtual_facts
    test_dict = {}
    # Initialise the object used to test
    free_b_s_d_virtual_1 = FreeBSDVirtual()
    # Get the facts using the method
    facts = free_b_s_d_virtual_1.get_virtual_facts()
    # Check that the expected keys are present
    assert 'virtualization_role' in facts \
        and 'virtualization_type' in facts \
        and 'virtualization_tech_guest' in facts \
        and 'virtualization_tech_host' in facts

# Generated at 2022-06-25 00:55:43.612423
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:52.811850
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kern_vm_guest = "3"
    hw_hv_vendor = "VMWare"
    hw_model = "VMWare Virtual Platform"
    sec_jail_jailed = '0'

    free_b_s_d_virtual_0 = FreeBSDVirtual()

    free_b_s_d_virtual_0.detect_virt_product = lambda x: {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    free_b_s_d_virtual_0.detect_virt_vendor = lambda x: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    free_b_s_d_virtual_0.sysctl

# Generated at 2022-06-25 00:55:56.091174
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:57.581782
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
     Unit test for constructor of class FreeBSDVirtualCollector
    """
    assert FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:59.789080
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:02.781607
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:04.755309
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Testing if the class could be instantiated.
    assert FreeBSDVirtualCollector is not None


# Generated at 2022-06-25 00:56:14.900205
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_1 = set()
    free_b_s_d_virtual_1 = FreeBSDVirtual(set_1)
    # Check method get_virtual_facts of class FreeBSDVirtual
    assert free_b_s_d_virtual_1.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(), }

# Generated at 2022-06-25 00:56:17.209234
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)

# Generated at 2022-06-25 00:56:19.940839
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'

# Generated at 2022-06-25 00:56:21.766219
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)


# Generated at 2022-06-25 00:56:28.895294
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert(free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    })

# Generated at 2022-06-25 00:56:34.247040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    free_b_s_d_virtual_collector_0._fact_class = FreeBSDVirtual
    free_b_s_d_virtual_collector_0._platform = 'FreeBSD'
    free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 00:56:38.048974
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    (var_1, var_2) = (test_case_0(), test_case_0())
    assert(var_1 == var_2)

# Generated at 2022-06-25 00:56:40.753547
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)

# Generated at 2022-06-25 00:56:43.706988
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v_virtual_collector_0 = FreeBSDVirtualCollector()
    assert(v_virtual_collector_0.platform == 'FreeBSD')
    assert(v_virtual_collector_0._fact_class == FreeBSDVirtual)

# Generated at 2022-06-25 00:56:50.092818
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_role'] == ''

# Generated at 2022-06-25 00:57:00.872372
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)


# Generated at 2022-06-25 00:57:08.766186
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'hw.model' in var_1
    assert var_0 == var_1
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'security.jail.jailed' in var_1
    assert 'virtualization_tech_host' in var_1
    assert 'virtualization_tech_host' in var_1

# Generated at 2022-06-25 00:57:11.380554
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:14.240884
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  # Instance of class FreeBSDVirtualCollector
  _FreeBSDVirtualCollector_0 = FreeBSDVirtualCollector()
  _FreeBSDVirtualCollector_0.collect()

# Generated at 2022-06-25 00:57:21.592253
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)

# Unit test execution
if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:23.413202
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, (FreeBSDVirtualCollector))

# Generated at 2022-06-25 00:57:29.990350
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:31.980589
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_1 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_1)
    var_1 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:57:36.132809
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    pass

# Generated at 2022-06-25 00:57:39.399721
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_tech_guest' in var_0


# Generated at 2022-06-25 00:57:54.547147
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 00:57:58.969008
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual

# Generated at 2022-06-25 00:58:00.562891
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert(FreeBSDVirtual(set()).get_virtual_facts()['virtualization_type'] == '')

# Generated at 2022-06-25 00:58:03.788479
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_1 = set()
    free_b_s_d_virtual_1 = FreeBSDVirtual(set_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 00:58:08.120305
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    var_0 = free_b_s_d_virtual_collector_0._platform
    assert var_0 == 'FreeBSD'
    var_1 = free_b_s_d_virtual_collector_0.collect()

# Tests for class FreeBSDVirtual

# Generated at 2022-06-25 00:58:09.285093
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)


# Generated at 2022-06-25 00:58:15.378573
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:58:20.264918
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:58:25.943635
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:58:35.621564
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(free_b_s_d_virtual_0)
    var_0 = free_b_s_d_virtual_collector_0._platform
    var_1 = free_b_s_d_virtual_collector_0._fact_class
    var_2 = free_b_s_d_virtual_collector_0._collector

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:59.376534
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-25 00:59:04.978246
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    if True:
        assert isinstance(free_b_s_d_virtual_0.get_virtual_facts(), dict)

test_case_0()

# Generated at 2022-06-25 00:59:10.185304
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    freebsd_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    var_0 = freebsd_virtual_collector_0.collect()

# Generated at 2022-06-25 00:59:14.835931
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)


# Generated at 2022-06-25 00:59:17.593748
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)


# Generated at 2022-06-25 00:59:21.869236
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()

    # Test with argument 0
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector(0)
    assert free_b_s_d_virtual_collector.platform == 'FreeBSD'


# Generated at 2022-06-25 00:59:25.992397
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test for FreeBSD's alias for FreeBSD
    if sysctl_names_0['virtualization_type'] == 'freebsd-xen-domu':
        var_0 = sysctl_names_0['virtualization_type']
        assert var_0 == 'xen'

    # Test for FreeBSD's alias for FreeBSD Jail
    if sysctl_names_0['virtualization_type'] == 'freebsd-jail':
        var_0 = sysctl_names_0['virtualization_type']
        assert var_0 == 'jail'

    # Test for FreeBSD's alias for Linux KVM
    if sysctl_names_0['virtualization_type'] == 'kvm':
        var_0 = sysctl_names_0['virtualization_type']
        assert var_0 == 'linux-kvm'

    # Test for other FreeBSD

# Generated at 2022-06-25 00:59:26.982309
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ex_set = set()
    freebsd_virtual_collector = FreeBSDVirtualCollector(ex_set)

# Generated at 2022-06-25 00:59:29.577208
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:33.336099
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()

if __name__ == __name__:
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:00:29.468318
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is not False


# Generated at 2022-06-25 01:00:38.337515
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_1 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_1)

    facts = {
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'none',
        'security.jail.jailed': '0',
        'hw.model': '',
    }

    for key, value in facts.items():
        assert key in free_b_s_d_virtual_0.get_virtual_facts(), "missing key: %s" % key

# Generated at 2022-06-25 01:00:43.604246
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_1 = set([])
    free_b_s_d_virtual_1 = FreeBSDVirtual(set_1)
    assert free_b_s_d_virtual_1.get_virtual_facts() == {'virtualization_role': '', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([]), 'virtualization_type': ''}, 'Expected different value when calling get_virtual_facts of class FreeBSDVirtual'

# Generated at 2022-06-25 01:00:49.642827
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    arg_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(arg_0)
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 01:00:55.932189
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)
    # Unit test for get_all_facts of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector_0.get_all_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# vim:set ai et sts=4 sw=4 tw=80:

# Generated at 2022-06-25 01:01:01.698099
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    # test with kern.vm_guest = none
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()



# Generated at 2022-06-25 01:01:05.573007
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 01:01:11.872989
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_1 = set()
    free_b_s_d_virtual_1 = FreeBSDVirtual(set_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:01:16.203152
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:01:23.046870
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:02:23.502346
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    var_0 = FreeBSDVirtualCollector(set_0)

# Generated at 2022-06-25 01:02:25.298533
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().__class__.__name__ == "FreeBSDVirtualCollector"
    assert FreeBSDVirtualCollector().__class__.__bases__ == (VirtualCollector,)


# Generated at 2022-06-25 01:02:34.442712
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # http://docs.pytest.org/en/latest/fixture.html
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert ('virtualization_type' in var_0)
    assert ('virtualization_role' in var_0)
    assert ('virtualization_tech_guest' in var_0)
    assert ('virtualization_tech_host' in var_0)

# Generated at 2022-06-25 01:02:35.259169
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:02:36.742614
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)


# Generated at 2022-06-25 01:02:37.169865
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:02:41.563773
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    var_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(var_0)
    # FreeBSDVirtual#get_virtual_facts has no explicit outputs
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 is None

# Generated at 2022-06-25 01:02:43.849289
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_2 = set()
    free_b_s_d_virtual_1 = FreeBSDVirtual(set_2)
    var__1 = free_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:02:45.008362
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:47.560857
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    pass

# Generated at 2022-06-25 01:03:56.976189
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    os.environ = {'PATH': '\x1b\x02\x07\x1a\x1d\x0b', 'PWD': '\x1c\x0f\x0b\x1d\x0c\x1a\x03', 'HOME': '\x11\x1c\x1d\x18\x13\x01\x08\x1d\x14', 'LOGNAME': '\x1f\x1e\x0c\x1a\x0b\x03', '_': '/usr/local/bin/ansible-test', 'OLDPWD': '\x10\x0f\x18\x1a\x05\x1d\x0c'}

# Generated at 2022-06-25 01:04:00.493399
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    var_0 = set()
    var_1 = FreeBSDVirtual(var_0)
    var_2 = var_1.get_virtual_facts()
    assert var_2


# Generated at 2022-06-25 01:04:02.389629
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:04:03.543436
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)

# Generated at 2022-06-25 01:04:05.987287
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 01:04:10.774570
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    set1 = set(['kern_vm_guest'])
    set2 = set(['hw_hv_vendor'])
    set3 = set(['security_jail_jailed'])
    set4 = set(['hw_model'])
    set5 = set()
    set6 = set()
    set7 = set()
    set8 = set()
    set9 = set()
    set10 = set(['security_jail_jailed'])
    set11 = set()
    set12 = set()
    set13 = set()
    set14 = set()
    set15 = set()
    set16 = set()
    set17 = set(['security_jail_jailed'])
    set18 = set()
    set19 = set()

# Generated at 2022-06-25 01:04:15.912036
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(free_b_s_d_virtual_0)
    assert free_b_s_d_virtual_collec

# Generated at 2022-06-25 01:04:22.791638
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
#
# Assuming that the following variables are defined
#
#   set_0
#
    set_0 = set()

    # Check the get_virtual_facts method
    # of class FreeBSDVirtual using the following arguments
    #
    #   set_0
    #
    free_b_s_d_virtual_0 = FreeBSDVirtual(set_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
#
# Test cases
#



# Generated at 2022-06-25 01:04:28.713588
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    set_0 = set()
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(set_0)