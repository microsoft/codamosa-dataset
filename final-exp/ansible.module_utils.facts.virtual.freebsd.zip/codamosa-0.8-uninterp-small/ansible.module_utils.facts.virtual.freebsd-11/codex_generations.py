

# Generated at 2022-06-25 00:54:40.301039
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:54:41.265835
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:46.269823
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:54:50.161519
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 00:54:51.168710
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:54:58.457572
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert not hasattr(free_b_s_d_virtual_collector_0, '__path__')
    assert hasattr(free_b_s_d_virtual_collector_0, '_fact_class')
    assert hasattr(free_b_s_d_virtual_collector_0, '_platform')
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:03.564880
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.__class__ is FreeBSDVirtualCollector


# Generated at 2022-06-25 00:55:06.887439
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-25 00:55:10.424080
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
# Check if FreeBSDVirtualCollector instantiated
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)

# Generated at 2022-06-25 00:55:16.125442
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    expected_results = FreeBSDVirtualCollector
    actual_results = FreeBSDVirtualCollector()
    assert type(actual_results) == expected_results
    assert type(actual_results._fact_class) == FreeBSDVirtual
    assert actual_results._platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:22.197666
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:55:24.389879
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class.__name__ == 'FreeBSDVirtual'


# Generated at 2022-06-25 00:55:25.650490
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # This is verifying the default value of a class variable.
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:55:27.111769
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:31.722198
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() is not None

# Generated at 2022-06-25 00:55:34.619224
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:40.331063
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

if __name__ == '__main__':
    # Test Module - Unit Tests

    # Unit test for method get_virtual_facts of class FreeBSDVirtual
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:55:46.519481
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Check if facts were collected properly.

    Negative test: facts should not be empty.
    """
    # Test the constructor
    test_case_0()
    # Get facts
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.get_facts()['virtualization_type'] != ""
    assert free_b_s_d_virtual_collector.get_facts()['virtualization_role'] != ""

# Generated at 2022-06-25 00:55:48.937391
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    free_b_s_d_virtual_0 = FreeBSDVirtual(virtual_facts)

# Generated at 2022-06-25 00:55:50.292652
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:55.386826
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f_r_e_e_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:55:59.219149
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_guest'] == set()


# Generated at 2022-06-25 00:56:02.990251
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:56:05.227829
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    assert not free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:06.939115
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:12.606304
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 00:56:17.902853
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:24.778849
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # test the constructor of FreeBSDVirtualCollector
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    str_0 = free_b_s_d_virtual_collector_0.get_platform()
    assert(str_0 == 'FreeBSD')

# Generated at 2022-06-25 00:56:29.043639
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = None
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    assert free_b_s_d_virtual_collector_0._fact_class is FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform is 'FreeBSD'

# Generated at 2022-06-25 00:56:33.661277
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 != None

if __name__ == '__main__':
    # Unit test for method get_virtual_facts of class FreeBSDVirtual
    test_FreeBSDVirtual_get_virtual_facts()
    # test_case_0()

# Generated at 2022-06-25 00:56:43.266832
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:47.596735
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 00:56:51.613046
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:54.898065
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except NameError:
        assert False

# Generated at 2022-06-25 00:57:01.405159
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Define test targets
    target_0 = {'virtualization_tech_guest': set(['vmware']), 'virtualization_tech_host': set([]), 'virtualization_type': 'hvm', 'virtualization_role': 'guest'}

    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0._parse_dmesg = mock_method(return_value={'virtualization_tech_guest': set(['vmware']), 'virtualization_tech_host': set([])})
    free_b_s_d_virtual_0._parse_proc_cpuinfo = mock_method(return_value={'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])})
    free_b_s_d_

# Generated at 2022-06-25 00:57:04.799974
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'unknown'
    assert var_0['virtualization_role'] == 'unknown'

# Generated at 2022-06-25 00:57:06.994019
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 00:57:10.569760
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == 'FreeBSD'

# Generated at 2022-06-25 00:57:15.342003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:20.896849
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    test_case_0()



# Generated at 2022-06-25 00:57:38.979106
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:43.893995
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:51.755777
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_1 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_1 = FreeBSDVirtual(bool_0)


# Generated at 2022-06-25 00:57:57.219574
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(
        bool_0, 'jailed', 'vendor', 'vm')
    print(free_b_s_d_virtual_collector_0._fact_class)
    print(free_b_s_d_virtual_collector_0._platform)


# Generated at 2022-06-25 00:57:59.811726
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
  bool_0 = True
  free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
  var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:01.079775
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()
    pass


# Generated at 2022-06-25 00:58:03.656258
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:05.833891
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    _fact_class = FreeBSDVirtual
    _platform = 'FreeBSD'
    obj_FreeBSDVirtualCollector = FreeBSDVirtualCollector(_fact_class, _platform)

# Generated at 2022-06-25 00:58:08.198763
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:10.450066
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:58:56.700426
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'


# Generated at 2022-06-25 00:59:02.994978
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 00:59:05.178622
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:07.454623
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    x = str(free_b_s_d_virtual_collector_0._fact_class)
    x = str(free_b_s_d_virtual_collector_0._platform)



# Generated at 2022-06-25 00:59:08.642590
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 00:59:11.063340
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = True
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:13.859264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:59:18.953683
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_1 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_1)
    var_1 = free_b_s_d_virtual_collector_0._fact_class()
    var_2 = free_b_s_d_virtual_collector_0._platform

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()
    print("done")

# Generated at 2022-06-25 00:59:21.207706
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

test_FreeBSDVirtualCollector()
test_case_0()

# Generated at 2022-06-25 00:59:24.186358
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    fre_b_sd_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    return fre_b_sd_virtual_collector_0

# Generated at 2022-06-25 01:01:18.118836
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)

# Generated at 2022-06-25 01:01:22.711779
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:01:23.757889
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:01:29.090329
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert type(free_b_s_d_virtual_collector_0) == FreeBSDVirtualCollector
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:01:34.205614
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'



# Generated at 2022-06-25 01:01:42.481103
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.detect_virt_product = lambda x: {'virtualization_type':'', 'virtualization_role':'', 'virtualization_tech_guest':set(['xen']), 'virtualization_tech_host':set(['bhyve'])}
    free_b_s_d_virtual_0.detect_virt_vendor = lambda x: {'virtualization_tech_guest':set(), 'virtualization_tech_host':set()}
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert ('xen' == var_0['virtualization_type'])


# Generated at 2022-06-25 01:01:47.546180
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert type(free_b_s_d_virtual_collector_0) == FreeBSDVirtualCollector


# This function returns the tuple (virtualization_type, virtualization_role)

# Generated at 2022-06-25 01:01:53.667732
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert(var_0 == None)

# Generated at 2022-06-25 01:01:55.379689
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:00.396621
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
