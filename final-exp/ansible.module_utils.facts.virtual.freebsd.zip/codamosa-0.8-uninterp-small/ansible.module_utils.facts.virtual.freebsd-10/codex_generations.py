

# Generated at 2022-06-25 00:54:40.408090
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:54:47.087172
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:54:48.121330
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()

# Generated at 2022-06-25 00:54:50.731378
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
       free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    except:
       assert False ,"Constructor of class FreeBSDVirtualCollector raised an exception"


# Generated at 2022-06-25 00:54:54.236010
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:54:57.699034
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == virtual_facts


# Generated at 2022-06-25 00:54:58.633642
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:05.107382
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_1 = FreeBSDVirtual()
    assert free_b_s_d_virtual_1.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-25 00:55:07.003709
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-25 00:55:09.934877
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual({})
    assert free_b_s_d_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 00:55:17.748884
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Testing if the object is initialized properly
    assert free_b_s_d_virtual_collector_0


# Generated at 2022-06-25 00:55:22.963062
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    virtual_facts = free_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 00:55:25.387439
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    # Test with empty values set as default
    free_b_s_d_virtual_0.get_virtual_facts()
    assert free_b_s_d_virtual_0.virtualization_type == ''
    assert free_b_s_d_virtual_0.virtualization_role == ''

# Generated at 2022-06-25 00:55:31.446319
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create an instance of the FreeBSDVirtual class
    free_b_s_d_virtual_obj_0 = FreeBSDVirtual()

    # invoke test on FreeBSDVirtual instance
    free_b_s_d_virtual_obj_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:32.885929
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 00:55:34.509421
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector


# Generated at 2022-06-25 00:55:35.064977
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True

# Generated at 2022-06-25 00:55:35.914532
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass


# Generated at 2022-06-25 00:55:42.977259
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_1 = FreeBSDVirtual()

    # Unit test for simple case
    free_b_s_d_virtual_0_virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()
    assert free_b_s_d_virtual_0_virtual_facts == {}

    # Unit test for complex case
    free_b_s_d_virtual_1_virtual_facts = free_b_s_d_virtual_1.get_virtual_facts()
    assert free_b_s_d_virtual_1_virtual_facts == {}

# Generated at 2022-06-25 00:55:46.765398
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtualCollector.fetch_virtual_facts()
    free_b_s_d_virtual_1 = FreeBSDVirtual()
    assert free_b_s_d_virtual_1.get_virtual_facts() == free_b_s_d_virtual_0


# Generated at 2022-06-25 00:55:52.324734
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = free_b_s_d_virtual_collector_0.collection()

# Generated at 2022-06-25 00:55:55.336958
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass



# Generated at 2022-06-25 00:55:59.189593
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()



if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:56:00.184761
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector() != None

# Generated at 2022-06-25 00:56:03.575044
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:06.749413
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:12.277963
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()
    var_2 = var_1.collect()
    print(var_2)

# Generated at 2022-06-25 00:56:19.004531
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    str_1 = 'ansible.module_utils.facts.virtual.freebsd'
    var_0 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:56:25.945295
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    # Check the returned value
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': ''}


# Generated at 2022-06-25 00:56:29.058967
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:56:41.676629
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == dict()


# Generated at 2022-06-25 00:56:46.667693
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    return free_b_s_d_virtual_collector_0

# Generated at 2022-06-25 00:56:47.519841
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert False

# Generated at 2022-06-25 00:56:49.181836
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:50.338546
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:52.727373
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 00:56:58.719420
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    var_0 = {
        'virtualization_tech_host': set(),
        'virtualization_role': 'guest',
        'virtualization_type': '',
        'virtualization_tech_guest': set()
    }
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == var_1


# Generated at 2022-06-25 00:57:02.511079
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    # Initialize class
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)



# Generated at 2022-06-25 00:57:04.002787
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:09.523740
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:57:32.019231
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 00:57:33.236653
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_1 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_1)

# Generated at 2022-06-25 00:57:38.165299
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_1 = '-NoProfile'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }, 'Expected: {\'virtualization_role\': \'guest\', \'virtualization_type\': \'xen\', \'virtualization_tech_guest\': set([]), \'virtualization_tech_host\': set([])}, but got: {!r}'.format(var_1)


# Generated at 2022-06-25 00:57:42.629184
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    str_0 = '<hInS2Q'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:46.224921
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    str_1 = free_b_s_d_virtual_collector_0._platform
    assert str_1 == 'FreeBSD'



# Generated at 2022-06-25 00:57:48.326546
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)


# Generated at 2022-06-25 00:57:51.681657
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freeBSDVirtualCollector_0 = FreeBSDVirtualCollector()
    assert freeBSDVirtualCollector_0.platform == 'FreeBSD'
    assert freeBSDVirtualCollector_0._platform == 'FreeBSD'
    assert freeBSDVirtualCollector_0.fact_class == FreeBSDVirtual
    assert freeBSDVirtualCollector_0._fact_class == FreeBSDVirtual

# Generated at 2022-06-25 00:57:56.006545
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    return

# Generated at 2022-06-25 00:57:59.729091
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)
    str_1 = '-NoProfile'
    var_0 = free_b_s_d_virtual_collector_0.get_virtual_facts(str_1)

# Generated at 2022-06-25 00:58:02.011665
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)


# Generated at 2022-06-25 00:58:56.373745
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 00:58:57.502817
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:07.455996
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts_obj = dict()
    var_0 = facts_obj['virtualization_role']
    var_1 = facts_obj['virtualization_type']
    var_2 = facts_obj['virtualization_tech_host']
    var_3 = facts_obj['virtualization_tech_guest']
    str_0 = '-NoProfile'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_1.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert var_1 == ''
    assert var_2 == set()
    assert var_3 == set

# Generated at 2022-06-25 00:59:08.428647
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    # Testing default constructor:
    test_0 = FreeBSDVirtualCollector()

    # Testing get_fact_classes():
    test_1 = test_0.get_fact_classes()

# Generated at 2022-06-25 00:59:13.515541
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    assert var_0.get('virtualization_type') == ''
    assert var_0.get('virtualization_role') == ''
    assert var_0.get('virtualization_tech_host') == set()
    assert var_0.get('virtualization_tech_guest') == set()

# Generated at 2022-06-25 00:59:17.401640
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    var_1 = FreeBSDVirtual('-NoProfile')
    var_1.detect_virt_product = lambda x: x
    var_2 = Var_1.get_virtual_facts()
# assert var_2 ==
# assert var_1.get_virtual_facts() ==

# Generated at 2022-06-25 00:59:19.950648
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()
    var_1.collect()


# Generated at 2022-06-25 00:59:23.753409
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(str_0)

# Generated at 2022-06-25 00:59:28.447914
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '-NoProfile'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:29.541977
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 01:01:28.956455
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    #Test without parameters
    assert(isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector))



# Generated at 2022-06-25 01:01:34.607375
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual.get_virtual_facts()
    assert var_1 == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 01:01:36.345202
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 01:01:39.814983
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fr_e_e_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = fr_e_e_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:01:47.441176
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test the return value of `get_virtual_facts` method of FreeBSDVirtual class.
    Importing the class is not required here, as the function is not a class method.
    """
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtu

# Generated at 2022-06-25 01:01:56.361879
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():

    _fact_class = FreeBSDVirtual
    _platform = 'FreeBSD'

    # Instance of class FreeBSDVirtualCollector
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()

    # Testing instance attribute _fact_class and comparing with
    # FreeBSDVirtual.__name__
    assert free_b_s_d_virtual_collector._fact_class.__name__ == FreeBSDVirtual.__name__

    # Testing instance attribute _platform and comparing with 'FreeBSD'
    assert free_b_s_d_virtual_collector._platform == 'FreeBSD'

# Testing method 'collect' in class FreeBSDVirtualCollector

# Generated at 2022-06-25 01:01:57.054553
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-25 01:01:58.580614
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 01:02:05.286044
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:02:09.780505
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    FreeBSDVirtual.get_virtual_facts()