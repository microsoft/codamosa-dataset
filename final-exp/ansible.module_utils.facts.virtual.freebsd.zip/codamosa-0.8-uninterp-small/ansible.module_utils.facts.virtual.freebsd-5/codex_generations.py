

# Generated at 2022-06-25 00:54:39.472673
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:54:42.059492
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:54:51.326694
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0_a = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_0_a = FreeBSDVirtual(str_0_a)
    str_0_b = '#Jb1R+<S2ZmF^u49'
    # kern.vm_guest
    str_1 = 'vm.vmtotal'
    # hw.hv_vendor
    str_2 = 'vm.vmtotal'
    # security.jail.jailed
    str_3 = 'security.jail.jailed'
    str_4 = 'hw.model'
    str_5 = 'vm.vmtotal'
    # hw.model
    str_6 = 'hw.model'
    # hw.model

# Generated at 2022-06-25 00:54:56.486756
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = 'y>I=+7L-%E[8W^2'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:00.366802
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test for class constructor
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:08.984790
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    # Call the method
    result_free_b_s_d_virtual_0 = free_b_s_d_virtual_0.get_virtual_facts()
    str_1 = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_1 = FreeBSDVirtual(str_1)
    # Call the method
    result_free_b_s_d_virtual_1 = free_b_s_d_virtual_1.get_virtual_facts()
    str_2 = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_

# Generated at 2022-06-25 00:55:13.604810
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    data = free_b_s_d_virtual_0.get_virtual_facts()
    assert len(data) == 5
    assert data['virtualization_tech_guest'] == set()
    assert data['virtualization_tech_host'] == set()


# Generated at 2022-06-25 00:55:19.907553
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    str_0 = '0u\\L)K+(=8ZL8/E'
    free_b_s_d_virtual_0 = FreeBSDVirtual(str_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 00:55:21.270759
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    new_FreeBSDVirtualCollector = FreeBSDVirtualCollector()
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 00:55:23.592558
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  # We have to initialize the class since we can't mock anything yet
  free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:28.586551
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert True == True

# Generated at 2022-06-25 00:55:32.098867
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    return


# Generated at 2022-06-25 00:55:35.173017
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except Exception as e:
        print("First test of class FreeBSDVirtualCollector failed!")
        print(e)


# Generated at 2022-06-25 00:55:41.387780
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_1.platform == 'FreeBSD'
    assert type(free_b_s_d_virtual_collector_0) == FreeBSDVirtualCollector
    assert type(free_b_s_d_virtual_collector_0) is type(free_b_s_d_virtual_collector_1)


# Generated at 2022-06-25 00:55:43.770605
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:55:46.561371
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    if free_b_s_d_virtual_collector.platform == 'FreeBSD':
        assert True
    else:
        assert False

# Generated at 2022-06-25 00:55:48.667667
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:52.028573
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._fact_class._platform == 'FreeBSD'


# Generated at 2022-06-25 00:55:58.729701
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_1 = FreeBSDVirtual()
    free_b_s_d_virtual_1.get_virtual_facts()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:59.715057
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # TODO Implement test
    return


# Generated at 2022-06-25 00:56:05.762860
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:56:08.712684
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:10.886346
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:14.570615
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:20.010577
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    bool_1 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    assert not isinstance(free_b_s_d_virtual_collector_0._fact_class, type(None))
    assert free_b_s_d_virtual_collector_0._platform == "FreeBSD"
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(bool_1)
    assert not isinstance(free_b_s_d_virtual_collector_1._fact_class, type(None))
    assert free_b_s_d_virtual_collector_1._platform == "FreeBSD"

# Generated at 2022-06-25 00:56:23.415205
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    var_0 = free_b_s_d_virtual_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:25.897517
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

if __name__ == "__main__":
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:56:29.700654
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    # Asserting the instance of the class
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:56:32.631562
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    assert free_b_s_d_virtual_collector_0._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-25 00:56:38.356198
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:54.292094
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

    str_0 = 'host'
    var_0 = free_b_s_d_virtual_collector_0.get_virtual_facts(str_0)

    str_1 = 'guest'
    var_1 = free_b_s_d_virtual_collector_0.get_virtual_facts(str_1)

    str_2 = 'container'
    var_2 = free_b_s_d_virtual_collector_0.get_virtual_facts(str_2)

    var_3 = free_b_s_d_virtual_collector_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:01.051311
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    # Testing whether virtualization_tech_host is not empty
    assert free_b_s_d_virtual_0.get_virtual_facts()["virtualization_tech_host"]


# Generated at 2022-06-25 00:57:04.177100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    var_0 = isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector)
    assert var_0 == True


# Generated at 2022-06-25 00:57:05.044864
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 00:57:06.898380
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()

test_case_0()
test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:12.116615
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0

# Generated at 2022-06-25 00:57:19.450786
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    std_out_0 = "FreeBSD 10.3-RELEASE"
    std_out_1 = "FreeBSD"
    bool_0 = True
    bool_1 = False
    # test for FreeBSDVirtualCollector(ansible_facts, platform_subclass_override=False)
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(std_out_0, bool_1)
    # test for FreeBSDVirtualCollector(ansible_facts, platform_subclass_override=False)
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector(std_out_1, bool_1)
    # test for FreeBSDVirtualCollector(ansible_facts, platform_subclass_override=False)

# Generated at 2022-06-25 00:57:25.617794
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # set up
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)

    # test
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    # check
    assert var_0 == dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

# Generated at 2022-06-25 00:57:28.181759
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:31.681737
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    var_0 = free_b_s_d_virtual_collector_0.fact_class
    var_1 = free_b_s_d_virtual_collector_0.platform

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:57:58.265224
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    
    # Example file path
    _file_path = os.path.dirname(os.path.abspath(__file__))

    # Example file contents
    _file_contents = ""

    expected_result = {
        'virtualization_tech_host': set(['bhyve']),
        'virtualization_tech_guest': set(['freebsd', 'bhyve']),
        'virtualization_type': '',
        'virtualization_role': 'guest'
    }

    with open(_file_path + '/example_sysctl_virtualization_facts', 'r') as f:
        _file_contents = f.read()

    sysctl_detection = VirtualSysctlDetectionMixin()

# Generated at 2022-06-25 00:57:59.521253
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:03.153316
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(None)
    free_b_s_d_virtual_collector_0._platform = 'FreeBSD'
    free_b_s_d_virtual_collector_0._fact_class = FreeBSDVirtual


# Generated at 2022-06-25 00:58:04.549979
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = False
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 00:58:10.548697
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

    free_b_s_d_virtual_collector_0.collect()

    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)

    assert free_b_s_d_virtual_collector_0._platform == free_b_s_d_virtual_0.platform

    assert free_b_s_d_virtual_collector_0._fact_class == free_b_s_d_virtual_0.__class__


# Generated at 2022-06-25 00:58:18.318238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
  assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
  assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
  # Test that the superclass constructor is called with the correct parameters
  # if the subclass fails to provide all the necessary parameters
  try:
    class BrokenFreeBSDVirtualCollector(FreeBSDVirtualCollector):
      pass
    BrokenFreeBSDVirtualCollector()
    assert False
  except TypeError:
    pass

if __name__ == '__main__':
  test_case_0()
  test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:18.747194
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 00:58:19.424249
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 00:58:25.179717
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:28.977431
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    output = free_b_s_d_virtual_0.get_virtual_facts()
    print(output)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:59:23.152598
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert bool(free_b_s_d_virtual_collector_0._providers) == False


# Generated at 2022-06-25 00:59:28.366549
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup test case
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)

    # Invoke method
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

    # Check results
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}, 'Return values mismatch'


# Generated at 2022-06-25 00:59:32.620221
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freeBSDVirtualCollector = FreeBSDVirtualCollector(0)



# Generated at 2022-06-25 00:59:38.062016
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is None


# Generated at 2022-06-25 00:59:46.929130
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    fail_unless(isinstance(free_b_s_d_virtual_collector_0.fact_class, FreeBSDVirtual))
    fail_unless(free_b_s_d_virtual_collector_0.platform == 'FreeBSD')

from ansible.module_utils.facts.virtual.freebsd import test_case_0, test_FreeBSDVirtualCollector

# Generated at 2022-06-25 00:59:47.724832
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:59:51.818532
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup test case
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)

    # Run unit test
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:53.343183
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector_0 = FreeBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 00:59:55.915705
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bool_0 = False
    free_b_s_d_virtual_0 = FreeBSDVirtual(bool_0)
    assert free_b_s_d_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:00:02.322591
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bool_0 = True
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(bool_0)
    expected = FreeBSDVirtualCollector(bool_0)
    actual = FreeBSDVirtualCollector(bool_0)
    if(expected is not actual):
        print("Expected:", expected, type(expected))
        print("Actual:", actual, type(actual))
        assert expected == actual


# Generated at 2022-06-25 01:02:00.690989
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:05.285526
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    var = free_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:02:10.047907
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:02:13.017386
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()
    assert var_1._platform == 'FreeBSD'
    assert var_1._fact_class == 'FreeBSDVirtual'


# Generated at 2022-06-25 01:02:18.152659
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Declarations
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    # Assertions
    assert isinstance(free_b_s_d_virtual_collector_0, VirtualCollector)
    assert hasattr(free_b_s_d_virtual_collector_0, '_platform')
    assert hasattr(free_b_s_d_virtual_collector_0, '_fact_class')
    assert hasattr(free_b_s_d_virtual_collector_0, '_fact_class')
    # Assert type of attribute '_fact_class'
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, type)


# Generated at 2022-06-25 01:02:22.265430
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert(issubclass(FreeBSDVirtualCollector, VirtualCollector)) # Check if FreeBSDVirtualCollector is subclass of VirtualCollector
    assert(hasattr(FreeBSDVirtualCollector, '_fact_class')) # Check if FreeBSDVirtualCollector has the attribute '_fact_class'
    assert(hasattr(FreeBSDVirtualCollector, '_platform')) # Check if FreeBSDVirtualCollector has the attribute '_platform'


# Generated at 2022-06-25 01:02:27.709307
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_mock = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_hypervisor': ''
    }
    FreeBSDVirtual().get_virtual_facts() == virtual_mock


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:02:29.200055
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if True:
        # Unit test for constructor of class FreeBSDVirtualCollector.
        var_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:32.435602
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:02:35.206478
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_1.get_virtual_facts()
