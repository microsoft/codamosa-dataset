

# Generated at 2022-06-25 00:54:39.796622
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:54:45.857845
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    virtual_facts = free_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts and isinstance(virtual_facts['virtualization_tech_guest'],
                                                                       set)
    assert 'virtualization_tech_host' in virtual_facts and isinstance(virtual_facts['virtualization_tech_host'], set)
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts


if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 00:54:51.164385
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    try:
        obj.populate()
    except Exception:
        raise AssertionError("Creation of FreeBSDVirtualCollector failed")


# Generated at 2022-06-25 00:54:56.908102
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()

    assert isinstance(virtual_collector, FreeBSDVirtualCollector)
    assert virtual_collector._platform == 'FreeBSD'
    assert type(virtual_collector._fact_class) == type(FreeBSDVirtual)
    assert virtual_collector._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-25 00:55:00.829784
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(free_b_s_d_virtual_collector_0, FreeBSDVirtualCollector), "Constructor of class FreeBSDVirtualCollector didn't create instance properly"


# Generated at 2022-06-25 00:55:04.245498
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:08.456844
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:55:13.463903
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:17.145834
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_0 = free_b_s_d_virtual_collector_0._get_virt()

    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:55:20.260383
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0 is not None, 'Failed to instantiate FreeBSDVirtualCollector'



# Generated at 2022-06-25 00:55:31.034967
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 00:55:32.310304
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 00:55:33.770214
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 00:55:38.658010
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0


# Generated at 2022-06-25 00:55:41.468016
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:55:46.160588
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    assert free_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_tech_guest': {}, 'virtualization_tech_host': {}, 'virtualization_role': ''}

# Generated at 2022-06-25 00:55:48.938017
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector is not None


# Generated at 2022-06-25 00:55:51.078761
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-25 00:55:54.967837
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    free_b_s_d_virtual_collector_0.collect()
    assert free_b_s_d_virtual_collector_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual


# Generated at 2022-06-25 00:55:57.509155
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    res = free_b_s_d_virtual_0.get_virtual_facts()
    assert res['virtualization_role'] == ''


# Generated at 2022-06-25 00:56:06.591749
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:56:12.279466
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f._fact_class == FreeBSDVirtual
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-25 00:56:22.340195
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -149.537893625
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == -149.537893625
    assert free_b_s_d_virtual_0.platform == 'FreeBSD'
    assert free_b_s_d_virtual_0.count_cores == -149.537893625
    assert free_b_s_d_virtual_0.count_cpus == -149.537893625
    assert free_b_s_d_virtual_0.count_sockets == -149.537893625

# Generated at 2022-06-25 00:56:24.363495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = 856.602
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)


# Generated at 2022-06-25 00:56:27.228776
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -997.7312
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:56:31.922270
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class, FreeBSDVirtual)
    assert callable(free_b_s_d_virtual_collector_0.collect)


# Generated at 2022-06-25 00:56:35.334689
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -997.7312
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 00:56:40.217229
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -993.5515
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    float_1 = -13.3277
    free_b_s_d_virtual_collector_0.fetch_virtual_facts(float_1)

# Generated at 2022-06-25 00:56:40.721231
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # pass
    pass

# Generated at 2022-06-25 00:56:43.672143
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_0 = free_b_s_d_virtual_collector_0.collection()


# Generated at 2022-06-25 00:57:08.542750
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_1 = -0.691981
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()
    #assert var_1 == expected
    #self.assertEqual(var_1, expected)


# Generated at 2022-06-25 00:57:13.229999
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -996.447
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:57:20.043372
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -350.12
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}  # Updated
    float_1 = -831.99
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    assert free_b_s_d_virtual_0 != free_b_s_d_virtual_1
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 00:57:23.304054
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except Exception as e:
        raise AssertionError("Can't instantiate FreeBSDVirtualCollector: " + str(e))


# Generated at 2022-06-25 00:57:30.572368
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  is_instance_0 = isinstance( FreeBSDVirtualCollector, VirtualCollector )
  assert is_instance_0
  # TODO
  # assert VirtualCollector.platform == 'FreeBSD'
  # assert VirtualCollector._fact_class == FreeBSDVirtual
  # assert VirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-25 00:57:39.745988
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = 694.792
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': '', 'virtualization_role': ''}
    float_1 = -997.7312
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 00:57:42.651056
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_1 = -753.927
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_1)
    var_1 = free_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 00:57:43.435515
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 00:57:44.320695
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_case_0()


# Generated at 2022-06-25 00:57:48.708521
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -997.7312
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 00:58:15.913499
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_0 = -997.7312
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:58:21.256569
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -702.879
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    assert float_0 == float(-702.879)



# Generated at 2022-06-25 00:58:24.882412
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    float_1 = -997.7312
    free_b_s_d_virtual_1 = FreeBSDVirtual(float_1)
    int_1 = 10
    int_0 = 8
    var_1 = free_b_s_d_virtual_1.get_virtual_facts(int_1, int_0)
    assert var_1 == dict([('virtualization_type', ''), ('virtualization_tech_host', set()), ('virtualization_tech_guest', set()), ('virtualization_role', '')])


# Generated at 2022-06-25 00:58:29.163160
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -957.9077
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    print(free_b_s_d_virtual_collector_0)
    free_b_s_d_virtual_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:32.623571
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -997.7312

    # Test for FreeBSDPlatform subclass
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)


# Generated at 2022-06-25 00:58:36.801510
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -72.9492
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    assert free_b_s_d_virtual_collector_0._platform == "FreeBSD"
    assert isinstance(free_b_s_d_virtual_collector_0._fact_class,
                      FreeBSDVirtual)

# Generated at 2022-06-25 00:58:39.719206
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with non-default args
    float_0 = -997.7312
    free_b_s_d_virtual_0 = FreeBSDVirtual(float_0)
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:58:40.814176
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:46.855316
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    float_0 = -0.76805
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector(float_0)
    var_0 = free_b_s_d_virtual_collector_0.get_all()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-25 00:58:50.637312
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = free_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:46.289651
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    assert isinstance(free_b_s_d_virtual_collector_1, FreeBSDVirtualCollector)


# Generated at 2022-06-25 00:59:48.000794
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 00:59:48.937768
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual


# Generated at 2022-06-25 00:59:54.755527
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for when virtualization_type is '' and virtualization_role is ''
    assert FreeBSDVirtual().get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': {'xen'}, 'virtualization_tech_host': {'xen'}}


# Generated at 2022-06-25 00:59:56.590223
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 00:59:57.712021
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:00:07.674144
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Unit test function for test_get_virtual_facts of class FreeBSDVirtual
    '''
    print('Testing get_virtual_facts of class FreeBSDVirtual')
    print('Testing get_virtual_facts of class FreeBSDVirtual')
    print('Testing get_virtual_facts of class FreeBSDVirtual')
    platform = 'FreeBSD'
    #Run the command to get the details of Hypervisor
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    print('Platform: ', virtual_facts['virtualization_type'], 'Role: ', virtual_facts['virtualization_role'])
    if platform == 'FreeBSD':
        assert "virtualization_type" in virtual_facts
        assert "virtualization_role" in virtual_facts
        print('Test passed')
        print('Test passed')
        print('Test passed')
    else:
        print

# Generated at 2022-06-25 01:00:10.073615
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:00:16.174359
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_1 = FreeBSDVirtualCollector()
    var_1 =  FreeBSDVirtualCollector.__doc__
    var_2 =  FreeBSDVirtualCollector.__module__
    var_3 =  FreeBSDVirtualCollector.__name__
    var_4 =  FreeBSDVirtualCollector.__init__.__doc__
    var_5 =  FreeBSDVirtualCollector._fact_class
    var_6 =  FreeBSDVirtualCollector._platform


# Generated at 2022-06-25 01:00:19.686738
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    var_1 = isinstance(free_b_s_d_virtual_collector_0,
                       FreeBSDVirtualCollector)
    assert var_1 == True



# Generated at 2022-06-25 01:02:19.325652
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()


# Generated at 2022-06-25 01:02:29.436830
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    free_b_s_d_virtual_0._detect_virt_product = lambda arg_0: {'virtualization_tech_host': ['kvm'], 'virtualization_tech_guest': set(), 'virtualization_type': 'kvm', 'virtualization_role': 'host'}
    free_b_s_d_virtual_0._detect_virt_vendor = lambda arg_0: {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': '', 'virtualization_role': ''}
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:02:33.173601
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_1 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:02:35.109786
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_1 = free_b_s_d_virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_FreeBSDVirtual_get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 01:02:36.852648
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:02:39.414695
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    var_1 = FreeBSDVirtualCollector()



# Generated at 2022-06-25 01:02:41.411809
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    free_b_s_d_virtual_collector_0 = FreeBSDVirtualCollector()
    assert free_b_s_d_virtual_collector_0._fact_class == FreeBSDVirtual
    assert free_b_s_d_virtual_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-25 01:02:41.958067
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    pass  # nothing to test


# Generated at 2022-06-25 01:02:50.951509
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    pv_virtual = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': 'paravirtual',
        'virtualization_role': 'guest'
    }

    free_b_s_d_virtual_0 = FreeBSDVirtual(pv_virtual)

    pv_virtual_facts_0 = free_b_s_d_virtual_0.get_virtual_facts()

    expected_virtual_facts = {
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'xen',
        'virtualization_role': 'guest'
    }

    assert pv_virtual_facts_0 == expected_virtual_facts


# Generated at 2022-06-25 01:03:00.025899
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with sysctl -n kern.vm_guest: userland
    # Test with sysctl -n hw.hv_vendor: VMware
    # Test with sysctl -n security.jail.jailed: 0
    # Test with sysctl -n hw.model: VirtualBox
    free_b_s_d_virtual_0 = FreeBSDVirtual()
    expected_var_0 = {'virtualization_type': 'vbox', 'virtualization_role': 'guest'}
    var_0 = free_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == expected_var_0
