

# Generated at 2022-06-11 05:31:21.632162
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test if class exists
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:25.952046
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:31:27.951260
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {}
    vc = FreeBSDVirtualCollector(facts, 'FreeBSD')
    assert vc

# Generated at 2022-06-11 05:31:34.147562
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Unit test for constructor of class FreeBSDVirtualCollector
    '''
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert not hasattr(freebsd_virtual_collector, '_fact_class')
    assert not hasattr(FreeBSDVirtualCollector, '_fact_class')


# Generated at 2022-06-11 05:31:34.774617
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-11 05:31:44.943726
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # mock sysctl module methods
    VirtualSysctlDetectionMixin._get_kern_vm_guest = lambda s: 'vmware'
    VirtualSysctlDetectionMixin._get_hw_hv_vendor = lambda s: 'bhyve'
    VirtualSysctlDetectionMixin._get_sec_jail_jailed = lambda s: 1

    test_virtual = FreeBSDVirtual()

    # tests vars against expected values
    assert test_virtual.get_virtual_facts()['virtualization_type'] == 'vmware'
    assert test_virtual.get_virtual_facts()['virtualization_role'] == 'guest'

    # reset virtualization_type and virtualization_role vars
    test_virtual.virtualization

# Generated at 2022-06-11 05:31:55.740954
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    kern_vm_guest = {
        'product_name': 'FreeBSD',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    hw_hv_vendor = {
        'product_name': 'FreeBSD',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set()
    }
    sec_jail_jailed = {
        'product_name': 'FreeBSD',
        'virtualization_tech_guest': set(['bsd-jail']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 05:31:59.138281
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:32:00.767895
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None)._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector(None)._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:32:04.005397
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(None)
    virtual.facts['kernel'] = 'FreeBSD'

    facts = virtual.get_virtual_facts()
    print(facts)
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:32:11.472531
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Unit test function for FreeBSDVirtualCollector
    '''
    fbvc = FreeBSDVirtualCollector()
    assert fbvc.platform == 'FreeBSD'
    assert isinstance(fbvc.facts, FreeBSDVirtual)

# Generated at 2022-06-11 05:32:16.657435
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.__class__.__bases__[0].__name__ == 'VirtualCollector', \
        'FreeBSDVirtualCollector should be subclass of VirtualCollector'
    assert x.__class__.__name__ == 'FreeBSDVirtualCollector', \
        'FreeBSDVirtualCollector should be subclass of VirtualCollector'

# Generated at 2022-06-11 05:32:22.471030
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    virtual_tech = FreeBSDVirtual()._get_virtual_tech_list()
    assert isinstance(virtual_tech, dict)
    assert 'virtualization_tech_guest' in virtual_tech
    assert 'virtualization_tech_host' in virtual_tech
    assert 'virtualization_type' in virtual_tech
    assert 'virtualization_role' in virtual_tech
    # reset the dict to None
    virtual_tech = None


# Generated at 2022-06-11 05:32:24.862174
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test that we can create an instance of FreeBSDVirtualCollector
    '''
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)



# Generated at 2022-06-11 05:32:26.044591
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:32:28.238840
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Class FreeBSDVirtualCollector has no public constructor"""
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)

# Generated at 2022-06-11 05:32:38.302721
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def mock_sysctl(self, name):
        '''
        This mock function returns the value of the sysctl variables
        'hw.hv_vendor', 'security.jail.jailed' and 'kern.vm_guest'
        '''
        if name == 'hw.model':
            return 'VMware Virtual Platform'
        elif name == 'hw.hv_vendor':
            return 'VMware'
        elif name == 'security.jail.jailed':
            return 1
        elif name == 'kern.vm_guest':
            return 'vmware'

    def mock_path_exists(self, path):
        '''
        This mock function returns true if the passed argument is
        '/dev/xen/xenstore'
        '''

# Generated at 2022-06-11 05:32:41.281092
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    this_class = FreeBSDVirtualCollector()
    assert this_class.platform == 'FreeBSD'
    assert this_class._fact_class == FreeBSDVirtual
    assert this_class._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:50.056053
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for a FreeBSD guest on VMware ESXi.
    test_facts = {'hw.model': 'VMware Virtual Platform',
                  'kern.vm_guest': 'freebsd',
                  'security.jail.jailed': '0',
                  'hw.hv_vendor': 'VMware',
                  'hw.hv_version': 'VMware ESXi 5.1.0 build-1065491'}
    fbsd_virtual = FreeBSDVirtual(module_name='ansible.builtin.virtual',
                                  facts=test_facts)
    result = fbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:32:57.584543
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


if __name__ == '__main__':
    # Unit test
    module_args = {}
    result = FreeBSDVirtual(module_args).get_virtual_facts()
    print(result)

# Generated at 2022-06-11 05:33:09.620347
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

    assert 'jail' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-11 05:33:11.551507
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert 'FreeBSD' == facts.platform
    assert FreeBSDVirtual == facts.__class__._fact_class

# Generated at 2022-06-11 05:33:13.337903
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc._fact_class, FreeBSDVirtual)
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:18.026313
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['physical', 'virtualbox', 'vmware', 'docker', 'chroot', 'jail', 'qemu', 'kvm', 'xen']
    assert virtual_facts['virtualization_role'] in ['host', 'guest']

# Generated at 2022-06-11 05:33:24.852687
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()
    }

    bsd_freebsd_virtual = FreeBSDVirtual(module=None,
                                         sysctl_module=None)
    facts = bsd_freebsd_virtual.get_virtual_facts()
    assert facts == expected_facts

# Generated at 2022-06-11 05:33:28.250678
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector(None, None)
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:33:28.822369
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:30.960711
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert (f.platform == 'FreeBSD')
    assert (f._fact_class == FreeBSDVirtual)

# Generated at 2022-06-11 05:33:33.697600
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.key == 'virtual'
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:33:34.066411
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:47.121548
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    # get the fact class from the collector
    factclass = collector.get_fact_class()
    # create an instance of fact class
    factinstance = factclass(collector)
    # compare the name of fact class
    assert factinstance.__class__.__name__ == "FreeBSDVirtual"

# Generated at 2022-06-11 05:33:50.672066
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == "FreeBSD"
    assert virtual_collector._fact_class.platform == "FreeBSD"
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
# end of test



# Generated at 2022-06-11 05:33:55.123084
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector(
        None,
        'hw.model',
        'hw.machine',
        'security.jail.jailed',
        'kern.vm_guest',
        'hw.hv_vendor')
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:03.621858
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    In test_FreeBSDVirtual_get_virtual_facts
    """
    # pylint: disable=protected-access, missing-docstring, invalid-name
    from unittest.mock import Mock
    with Mock(return_value=True):
        virt_module = FreeBSDVirtual()
        virt_module._detect_virt_product = Mock(return_value={'virtualization_type': 'xen', 'virtualization_role': 'guest'})
        virt_module._detect_virt_vendor = Mock(return_value={'virtualization_type': '', 'virtualization_role': ''})
        result = virt_module.get_virtual_facts()
        assert result['virtualization_type'] == 'xen'
        assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:34:06.078617
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """test_FreeBSDVirtualCollector: Test that FreeBSDVirtualCollector returns a FreeBSDVirtual object"""
    assert isinstance(FreeBSDVirtualCollector().collect(), FreeBSDVirtual)

# Generated at 2022-06-11 05:34:16.122675
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    freebsd_virtual.sysctl = {
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': '1',
    }

    freebsd_virtual.hw_model = {
        'QEMU': ['VirtualBox'],
        'KVM': ['VirtualBox'],
        'bhyve': ['bhyve'],
        'Fujitsu': ['FreeBSD'],
    }

    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'bhyve'
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 05:34:18.229345
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-11 05:34:27.175351
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual()

    testobj.collect_sysctl_product_data = lambda x: {'virtualization_tech_guest': set(['paravirtual']),
                                                     'virtualization_tech_host': set(['paravirtual'])}
    testobj.collect_sysctl_vendor_data = lambda x, y: {'virtualization_tech_guest': set(['paravirtual']),
                                                       'virtualization_tech_host': set(['paravirtual'])}
    expected_virtual_facts = {
        'virtualization_type': 'paravirtual',
        'virtualization_role': 'host',
        'virtualization_tech_host': set(['paravirtual']),
        'virtualization_tech_guest': set(['paravirtual'])}
    assert expected_virtual

# Generated at 2022-06-11 05:34:28.854895
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert type(virtual_facts_collector) is FreeBSDVirtualCollector

# Generated at 2022-06-11 05:34:31.405347
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-11 05:34:51.475901
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual._platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:01.106953
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test virtualization_type and virtualization_role.
    #
    # Test on host when there is no jail.
    virt_host = FreeBSDVirtual({})
    virtual_facts_host = virt_host.get_virtual_facts()
    assert virtual_facts_host['virtualization_type'] == ''
    assert virtual_facts_host['virtualization_role'] == ''

    # Test on host when there is a jail.
    virt_host_jailed = FreeBSDVirtual({'security.jail.jailed': 1})
    virtual_facts_host_jailed = virt_host_jailed.get_virtual_facts()
    assert virtual_facts_host_jailed['virtualization_type'] == ''
    assert virtual_facts_host_jailed['virtualization_role'] == ''

    # Test on guest in bhyve VM.
   

# Generated at 2022-06-11 05:35:07.820390
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is only a minimal test for the method get_virtual_facts
    # of class FreeBSDVirtual, more test cases should be implemented
    # in future.
    facts = {'kernel': 'FreeBSD'}
    expected_facts = {'virtualization_role': '', 'virtualization_type': '',
                      'virtualization_tech_guest': set([]),
                      'virtualization_tech_host': set([])}
    fbsdvirtual = FreeBSDVirtual(facts, None)
    assert fbsdvirtual.get_virtual_facts() == expected_facts

# Generated at 2022-06-11 05:35:08.903403
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:35:09.944213
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:11.730531
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt = FreeBSDVirtualCollector()
    assert virt._platform == 'FreeBSD'
    assert virt._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:22.104537
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    v = FreeBSDVirtual(module=None, facts=facts)

    # Test default value
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

    # Test jail
    facts['jails'] = [{
        'jail_host': 'security.jail.jailed',
        'jail_path': '/usr',
        'jail_version': '10.2-RELEASE',
        'jail_name': 'test',
    }]
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Test bhyve

# Generated at 2022-06-11 05:35:25.666908
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v_obj = FreeBSDVirtual()
    result = v_obj.get_virtual_facts()
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_type' in result

# Generated at 2022-06-11 05:35:34.592305
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('', (), {})()
    FreeBSDVirtual.get_virtual_facts(fake_module)
    assert 'virtualization_type' in fake_module.ansible_facts
    assert 'virtualization_role' in fake_module.ansible_facts
    assert 'virtualization_tech_guest' in fake_module.ansible_facts
    assert 'virtualization_tech_host' in fake_module.ansible_facts
    assert fake_module.ansible_facts['virtualization_tech_guest'] == set()
    assert fake_module.ansible_facts['virtualization_tech_host'] == set()
    assert fake_module.ansible_facts['virtualization_type'] == ''
    assert fake_module.ansible_facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:35:36.220508
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._fact_class is FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:11.715003
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    facts['system'] = dict()
    facts['system']['kernel'] = 'FreeBSD'
    kern_vm_guest = dict()
    kern_vm_guest['virtualization_tech_guest'] = set()
    kern_vm_guest['virtualization_tech_host'] = set()
    kern_vm_guest['virtualization_type'] = 'jail'
    kern_vm_guest['virtualization_role'] = 'guest'
    kern_vm_guest['virtualization_tech_guest'].add('jail')
    facts['kern_vm_guest'] = kern_vm_guest
    virtual1 = FreeBSDVirtual(facts, None)
    assert virtual1 is not None

# Generated at 2022-06-11 05:36:13.026994
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:36:15.500672
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:23.867082
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of FreeBSDVirtual class with different
    return values of sysctl command. Test if the method get_virtual_facts
    returns the expected dictionary.
    """
    # Test the case of virtual machine in VMware
    class TestFreeBSDVirtual_get_virtual_facts_1(FreeBSDVirtual):
        VIRTUAL_COMMAND_HW_MODEL = 'GenuineIntel'
        VIRTUAL_COMMAND_KERN_MODEL = '"vmware"'
        VIRTUAL_COMMAND_KERN_VM_GUEST = '"none"'
        VIRTUAL_COMMAND_HW_VENDOR = '"Unknown"'
        VIRTUAL_COMMAND_SEC_JAIL_JAILED = '0'

    virtual_machine = TestFreeBSDVirtual_get_virtual_facts

# Generated at 2022-06-11 05:36:26.296043
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual.platform == 'FreeBSD'
    assert virtual._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:27.742145
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:30.419111
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:34.089989
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual('FreeBSD').get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-11 05:36:43.601146
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_in = {}
    virtual_facts_out = {}
    expected_virtual_facts = {}

    # For virtual_facts_in, the following tests are performed:
    # - If 'virtual_facts_out' exists, checks that it is a dictionary
    # - Check that 'virtual_facts_out' matches expected_virtual_facts
    #
    # For all these tests, we use the '==' operator to compare dictionaries
    #
    # virtual_facts_in = {}
    # - check empty virtual_facts_out
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    virtual_facts_out = FreeBSDVirtual().get_virtual_facts(virtual_facts_in)

    assert virtual_facts_out == expected_virtual_facts

    # virtual

# Generated at 2022-06-11 05:36:45.423338
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Instantiate FreeBSDVirtualCollector() and ensure it is of type VirtualCollector
    FreeBSDVirtualCollector().is_instance(VirtualCollector)

# Generated at 2022-06-11 05:37:31.405766
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:37:33.488618
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Unit test for constructor of class FreeBSDVirtualCollector
    """
    # Test for creation of an object for FreeBSDVirtualCollector class
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:37:36.234057
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import FreeBSDVirtual
    fw = FreeBSDVirtual()
    facts = fw.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:37:37.688997
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsdCollector = FreeBSDVirtualCollector()
    assert freebsdCollector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:39.984965
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual
    assert collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:49.113166
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector.freebsd import FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    xc = FreeBSDVirtualCollector()

    # mocked method
    def f(key):
        fact = dict()
        fact['vendor'] = ' '
        fact['product'] = ' '
        if key == 'hw.hv_vendor':
            fact['vendor'] = 'bhyve'
            fact['product'] = 'bhyve'
            return fact
        if key == 'kern.vm_guest':
            fact['vendor'] = 'bhyve'
            fact['product'] = 'bhyve'
            return fact
        return fact

    xc.VirtualSysctlDetectionMixin.detect_

# Generated at 2022-06-11 05:37:53.481507
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_instance = FreeBSDVirtual()
    virtual_facts = virtual_instance.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is not None
    assert virtual_facts['virtualization_role'] is not None
    assert virtual_facts['virtualization_tech_host'] is not None
    assert virtual_facts['virtualization_tech_guest'] is not None

# Generated at 2022-06-11 05:37:58.991932
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual({})
    # Insert test data for sysctl
    f.sysctl = {'kern.vm_guest': 'freebsd',
                'hw.hv_vendor': '',
                'security.jail.jailed': '0'
                }
    v = f.get_virtual_facts()
    assert v['virtualization_type'] == 'freebsd'
    assert v['virtualization_role'] == 'guest'



# Generated at 2022-06-11 05:37:59.873008
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:38:01.077187
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-11 05:38:48.238714
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:50.504800
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ifaces_object = FreeBSDVirtualCollector()
    assert isinstance(ifaces_object._platform, str)
    assert isinstance(ifaces_object._fact_class, object)

# Generated at 2022-06-11 05:38:53.551469
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """ This function performs unit test for constructor of class FreeBSDVirtualCollector"""
    virtual_collector_object = FreeBSDVirtualCollector()
    assert virtual_collector_object._platform == "FreeBSD"
    assert virtual_collector_object._fact_class.platform == "FreeBSD"

# Generated at 2022-06-11 05:38:58.140309
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Unit test of FreeBSDVirtualCollector class
    """
    test_fact_class = FreeBSDVirtualCollector.__dict__['_fact_class']
    test_platform = FreeBSDVirtualCollector.__dict__['_platform']
    test_fact_class_obj = test_fact_class(module_runtime=None)
    assert test_fact_class_obj is not None
    assert test_fact_class_obj.__class__.__name__ == 'FreeBSDVirtual'
    assert test_platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:04.931628
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This function is used to test the constructor of class FreeBSDVirtualCollector,
    and it will raise an exception if the instantiation of class FreeBSDVirtualCollector
    does not meet the expect result.
    """
    try:
        fact_subclass = FreeBSDVirtualCollector(None, None, None)
        if not fact_subclass._platform == 'FreeBSD':
            raise AssertionError()
        if set(fact_subclass._supported_subclasses) != set(['cgroup']):
            raise AssertionError()
    except Exception:
        raise AssertionError()

# Generated at 2022-06-11 05:39:06.549037
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:10.442067
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:39:15.752625
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    virtual_facts = v.get_virtual_facts()
    assert not virtual_facts['virtualization_type']
    assert not virtual_facts['virtualization_role']
    assert not virtual_facts['virtualization_tech_host']
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_product_host']
    assert not virtual_facts['virtualization_product_guest']

# Generated at 2022-06-11 05:39:17.073127
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert type(collector) == FreeBSDVirtualCollector

# Generated at 2022-06-11 05:39:18.021398
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-11 05:40:07.522768
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:40:08.012325
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:40:09.410288
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collect_class = FreeBSDVirtualCollector()
    assert collect_class._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:40:17.071736
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import (
        FreeBSDVirtual, VirtualCollector)
    from unittest.mock import (
        patch, Mock, PropertyMock)

    # Setup test env
    detection_order = [
        'hw.model',
        'hw.hv_vendor',
        'kern.vm_guest',
        'security.jail.jailed',
    ]
    virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': '',
    }
    hw_model_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }
    hw_hv

# Generated at 2022-06-11 05:40:20.798766
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Unit test for FreeBSDVirtualCollector
    '''
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:40:22.111447
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import FactCollector
    virtual = Free

# Generated at 2022-06-11 05:40:26.749691
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fc = FreeBSDVirtualCollector()
    assert fc._platform == 'FreeBSD'
    assert fc._fact_class.platform == 'FreeBSD'
    assert fc._fact_class.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-11 05:40:28.670528
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual()
    virt_facts.get_virtual_facts()
    assert isinstance(virt_facts.virtual_facts, dict)

# Generated at 2022-06-11 05:40:36.223410
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockModule:
        def run_command(self, args, check_rc=False):
            if args == ['sysctl', '-n', 'kern.vm_guest']:
                return (0, 'hosted', '')
            elif args == ['sysctl', '-n', 'hw.hv_vendor']:
                return (0, 'bhyve', '')
            elif args == ['sysctl', '-n', 'security.jail.jailed']:
                return (0, '0', '')
            elif args == ['sysctl', '-n', 'hw.model']:
                return (0, 'OpenBSD', '')
            elif args == ['sysctl', '-n', 'hw.virtual_avail']:
                return (0, '1', '')

# Generated at 2022-06-11 05:40:41.613016
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # given a FreeBSDVirtualClass instance
    obj = FreeBSDVirtual()
    # when we invoke get_virtual_facts
    result = obj.get_virtual_facts()
    # we should get the expected virtual_facts dictionary
    expected_virtual_facts = {'virtualization_type': '',
                              'virtualization_role': '',
                              'virtualization_tech_guest': set(),
                              'virtualization_tech_host': set()}
    assert(result == expected_virtual_facts)
