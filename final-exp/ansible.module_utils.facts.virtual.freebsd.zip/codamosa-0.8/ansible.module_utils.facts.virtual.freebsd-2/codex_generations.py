

# Generated at 2022-06-11 05:31:31.575155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualFactCollector
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector, VirtualFactCollector)
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector)
    assert freebsd_virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:35.641368
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:31:37.243781
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSDVirtual.get_virtual_facts()
    # Nothing to test in the class
    pass

# Generated at 2022-06-11 05:31:39.331958
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.collector import VirtualCollector
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:31:41.764833
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:31:43.778789
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:46.643993
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector.platform == 'FreeBSD'
    assert facts_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:51.156742
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:31:53.368037
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c._fact_class, FreeBSDVirtual)
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:55.144287
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:59.858258
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == "FreeBSD"

# Generated at 2022-06-11 05:32:00.897522
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fa = FreeBSDVirtual()
    assert fa.get_virtual_facts() == {}

# Generated at 2022-06-11 05:32:04.182047
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Initialize
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform is not None
    assert virtual_collector._fact_class is not None
    assert virtual_collector._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:06.306917
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:07.220096
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:17.703701
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()

# Generated at 2022-06-11 05:32:26.050089
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)
    facts = {}
    # Set some kern.vm_guest values
    facts["sysctl_kern_vm_guest"] = "1"
    facts["sysctl_kern_vm_guest_vmm"] = 'linux'
    facts["sysctl_kern_vm_guest_bhyve"] = "1"
    facts["sysctl_kern_vm_guest_vmm2"] = "bhyve"
    facts["sysctl_security_jail_jailed"] = "0"

    virtual.collect(facts)

# Generated at 2022-06-11 05:32:27.793158
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  fv = FreeBSDVirtualCollector()
  assert fv._platform == "FreeBSD"


# Generated at 2022-06-11 05:32:32.093885
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtualfact = FreeBSDVirtual(dict())
    assert virtualfact.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-11 05:32:33.599174
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc



# Generated at 2022-06-11 05:32:41.069294
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Check if FreeBSDVirtualCollector is valid."""
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert virtual_facts_collector._fact_class == FreeBSDVirtual
    assert virtual_facts_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:43.083067
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = dict()
    fv = FreeBSDVirtualCollector(facts_dict)
    assert(fv is not None)

# Generated at 2022-06-11 05:32:45.817433
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:48.826567
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:49.823950
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()


# Generated at 2022-06-11 05:33:01.737469
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class FreeBSDVirtual '''
    bsd_virtual = FreeBSDVirtual()

    # Return virtual facts with virtualization_type=xen and virtualization_role=guest
    bsd_virtual.XEN_SYSCTL = '''
    security.jail.jailed: 0
    kern.vm_guest: xenhvm
    hw.hv_vendor: bhyve
    '''
    bsd_virtual.HW_MODEL = 'FreeBSD HVM domU 9.2-RELEASE-p3'
    bsd_virtual_facts = bsd_virtual.get_virtual_facts()
    assert bsd_virtual_facts['virtualization_type'] == 'xen'
    assert bsd_virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:33:04.850191
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts, FreeBSDVirtualCollector)
    assert facts._platform == 'FreeBSD'
    assert facts.get_facts() == {}

# Generated at 2022-06-11 05:33:11.340695
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # instantiating the subclass
    FreeBSD_virtual = FreeBSDVirtual()
    # returning a dictionary with the virtual facts
    FreeBSD_virtual_facts = FreeBSD_virtual.get_virtual_facts()
    # setting a variable for the virtual type
    virtual_type = FreeBSD_virtual_facts['virtualization_type']
    # setting a variable for the virtual role
    virtual_role = FreeBSD_virtual_facts['virtualization_role']
    # verifying if virtual_type is empty
    assert virtual_type != ''
    # verifying if virtual_role is empty
    assert virtual_role != ''

# Generated at 2022-06-11 05:33:14.738432
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts


# Generated at 2022-06-11 05:33:16.112310
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:33:31.367815
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class TestFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            self.sysctl = {'hw.hv_vendor': 'OpenBSD',
                           'kern.vm_guest': 'none',
                           'security.jail.jailed': '0'}
            self.vendors_product_facts = {'hw.model': 'OpenBSD'}
            self.is_jail = False

    fv = TestFreeBSDVirtual()
    virtual_facts = fv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies_guest'] == set()

# Generated at 2022-06-11 05:33:33.694949
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f._fact_class, FreeBSDVirtual)
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:35.774002
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert isinstance(vc, VirtualCollector)
    assert vc._fact_class == FreeBSDVirtual
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:41.762604
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    '''
    virtual_facts = FreeBSDVirtual()
    virtual_facts_dict = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts_dict
    assert 'virtualization_role' in virtual_facts_dict
    assert 'virtualization_tech_guest' in virtual_facts_dict
    assert 'virtualization_tech_host' in virtual_facts_dict

# Generated at 2022-06-11 05:33:43.137406
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None, None), VirtualCollector)

# Generated at 2022-06-11 05:33:44.917605
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, FreeBSDVirtualCollector)



# Generated at 2022-06-11 05:33:47.734910
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:51.377060
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    base_collector = FreeBSDVirtualCollector()
    assert base_collector.platform == 'FreeBSD'
    assert base_collector._fact_class.platform == 'FreeBSD'
    assert base_collector._fact_class.get_virtual_facts() == {}

# Generated at 2022-06-11 05:33:57.320621
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class.__name__ == 'FreeBSDVirtual'
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class.get_virtual_facts.__doc__ == '''Get virtualization facts for FreeBSD.'''

# Generated at 2022-06-11 05:34:05.881361
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual(module=None)

    test_facts = {
        # sysctl
        'hw.hv_vendor': '',
        'security.jail.jailed': '0',
        'kern.vm_guest': 'freebsd',
        # hw.model
        'model': 'VirtualBox',
        # /dev/xen/xenstore
        'xenstore': False,
    }

    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

    virtual_facts = freebsd_virtual.get_virtual_facts(test_facts)
    assert virtual_facts == expected_virtual_

# Generated at 2022-06-11 05:34:12.718699
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v._fact_class == FreeBSDVirtual
    assert v._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:23.610919
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            super(MockFreeBSDVirtual, self).__init__(None, None)
            self.facts['product_name'] = ''
            self.facts['product_version'] = 0

    class MockFreeBSDVirtualDetectVirtVendor(MockFreeBSDVirtual):
        def __init__(self):
            super(MockFreeBSDVirtual, self).__init__(None, None)
            self.facts['virtualization_type'] = ''
            self.facts['virtualization_role'] = ''


# Generated at 2022-06-11 05:34:24.027038
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:34:34.662687
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # test FreeBSD inside FreeBSD Jails
    os.environ['security.jail.jailed'] = '1'
    os.environ['hw.model'] = 'FreeBSD'
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['jail'])
    assert virtual_facts['virtualization_tech_host'] == set(['freebsd', 'os'])

    # test FreeBSD inside VMware ESXi
    os.environ['hw.model'] = 'VMware Virtual Platform'
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:34:36.975133
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector(None)
    assert isinstance(v, FreeBSDVirtualCollector)
    assert isinstance(v._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:34:41.762357
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'
    assert (freebsd_virtual_collector.fact_class ==
            FreeBSDVirtual)
    assert freebsd_virtual_collector.fact_class().get_virtual_facts.__module__ == \
        FreeBSDVirtual.get_virtual_facts.__module__

# Generated at 2022-06-11 05:34:44.128841
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''test_FreeBSDVirtual_get_virtual_facts'''
    test_virtual = FreeBSDVirtualCollector()
    test_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:34:49.603327
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sysctl_values = {'kern.vm_guest': 'unknown',
                     'hw.hv_vendor': 'unknown',
                     'security.jail.jailed': '0'}
    virtual_facts = {'virtualization_type': 'jail',
                     'virtualization_role': 'guest',
                     'virtualization_tech_guest': {'jail'},
                     'virtualization_tech_host': set()}
    virtual = FreeBSDVirtual(sysctl_values)
    assert virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-11 05:34:50.459611
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-11 05:34:51.597282
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt.get_virtual_facts()

# Generated at 2022-06-11 05:35:08.086092
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).collect()

    assert facts['virtualization_type'] in ('jail', 'virtualbox', 'chroot', 'xen', 'kvm', 'parallels', '')
    if facts['virtualization_type']:
        assert facts['virtualization_role'] in ('guest', 'host')
    else:
        assert facts['virtualization_role'] == ''
    assert facts['virtualization_use_type_title'] == 'Jailed'

# Generated at 2022-06-11 05:35:09.159756
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:12.664595
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual
    virtual_instance = FreeBSDVirtual()

    # Call method get_virtual_facts()
    virtual_facts = virtual_instance.get_virtual_facts()

    # Check keys in result
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:35:23.017800
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Test the get_virtual_facts method of the FreeBSDVirtual class
    """
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from mock import patch, create_autospec

    # Create a FreeBSDVirtual object
    virtual_facts = FreeBSDVirtual()

    # Create a patch for VirtualSysctlDetectionMixin.detect_virt_product
    patch_detect_virt_product = patch.object(
        VirtualSysctlDetectionMixin,
        'detect_virt_product',
        autospec=True
    )

    # Validate the behaviour of patch_detect_virt_product
    mock_detect_virt_product = patch_detect_virt_product.start()
    mock_det

# Generated at 2022-06-11 05:35:26.169981
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class.platform == 'FreeBSD'

# Unit tests for specific methods of class FreeBSDVirtual

# Generated at 2022-06-11 05:35:26.726583
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:35:29.012416
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:30.367617
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector('foo')
    assert 'foo' == x.name

# Generated at 2022-06-11 05:35:31.580497
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facter = FreeBSDVirtualCollector()
    assert isinstance(facter,VirtualCollector)

# Generated at 2022-06-11 05:35:33.947704
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:35:48.661919
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:49.969591
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.get_virtual_facts()

# Generated at 2022-06-11 05:35:52.464736
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert(virtual_collector._platform == 'FreeBSD')
    assert(virtual_collector._fact_class.platform == 'FreeBSD')

# Generated at 2022-06-11 05:36:02.867708
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_cases = [
        # vt, vr, virtualization_type, virtualization_role,
        # virtualization_tech_guest, virtualization_tech_host
        (True, None, '', '', set(), set()),
        (True, 'vmware', '', '', set(), set()),
        (True, '', '', '', {'vmware'}, set()),
        (True, '', 'vmware', '', set(), set()),
        (False, 'vmware', '', '', set(), set()),
        (False, 'vmware', 'vmware', '', {'vmware'}, set()),
    ]
    for vt, vr, vtype, vrole, vtech_guest, vtech_host in test_cases:
        test_fixture = FreeBSDF

# Generated at 2022-06-11 05:36:05.706176
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbv = FreeBSDVirtualCollector()
    assert fbv._platform == 'FreeBSD'
    assert fbv._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-11 05:36:07.433100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:17.187863
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from sys import platform
    from tests.unit.module_utils.facts.virtual.linux import (
        XEN_VM_GUEST, HW_HV_VENDOR, SEC_JAIL_JAILED, HW_MODEL)
    from tests.unit.module_utils.facts.virtual.sysctl import (
        KERN_VM_GUEST, HW_HV_VENDOR, SEC_JAIL_JAILED)

    xv = FreeBSDVirtual()
    if platform != 'FreeBSD':
        assert not xv.get_virtual_facts()
    else:
        facts = xv.get_virtual_facts()
        assert facts['virtualization_type'] in ('xen', '', None)
        assert facts['virtualization_role'] in ('guest', '', None)

# Generated at 2022-06-11 05:36:22.149368
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test FreeBSDVirtual.get_virtual_facts function on FreeBSD 11.0-RELEASE
    """
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:36:30.870696
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of the FreeBSDVirtual class
    virtual_facts = FreeBSDVirtual()
    # Create a dict of expected virtual_facts
    expected_virtual_facts = dict(
        virtualization_type='',
        virtualization_role=''
    )
    # Create a dict of virtual facts from get_virtual_facts()
    virtual_facts_from_get_virtual_facts = virtual_facts.get_virtual_facts()

    assert virtual_facts_from_get_virtual_facts.get('virtualization_type') == expected_virtual_facts.get('virtualization_type')
    assert virtual_facts_from_get_virtual_facts.get('virtualization_role') == expected_virtual_facts.get('virtualization_role')

# Generated at 2022-06-11 05:36:32.893278
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:12.734285
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {
        'system': 'FreeBSD',
    }
    obj = FreeBSDVirtualCollector(facts, None)
    # We want to fail if FreeBSDVirtualCollector.collect is not defined
    getattr(obj, 'collect')

# Generated at 2022-06-11 05:37:19.169980
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fixture = {}
    fixture['hw_hv_vendor'] = 'Xen'
    fixture['kern_vm_guest'] = 'vmware'
    fixture['sec_jail_jailed'] = '1'
    fixture['hw_model'] = 'FreeBSD/amd64'
    fact_module = FreeBSDVirtual(fixture=fixture)
    facts = fact_module.get_virtual_facts()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['vmware', 'xen'])
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:37:24.457959
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Test for `get_virtual_facts`
    '''
    FreeBSDVirtualCollector = FreeBSDVirtualCollector()
    freebsd_virtual_facts = FreeBSDVirtualCollector.get_virtual_facts()
    freebsd_virtual_facts_keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]
    assert sorted(freebsd_virtual_facts.keys()) == sorted(freebsd_virtual_facts_keys)

# Generated at 2022-06-11 05:37:32.005432
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    This function tests the get_virtual_facts function of the FreeBSDVirtual class.
    """
    # Set up the class
    FreeBSD_Virtual_instance = FreeBSDVirtual(None)

    # Get the facts
    FreeBSD_Virtual_facts = FreeBSD_Virtual_instance.get_virtual_facts()

    # Perform tests
    assert FreeBSD_Virtual_facts['virtualization_type'] in ('xen', 'jail', '', 'bhyve')
    assert FreeBSD_Virtual_facts['virtualization_role'] in ('guest', 'host', '')

    assert FreeBSD_Virtual_facts['virtualization_type'] != 'jail' or FreeBSD_Virtual_facts['virtualization_role'] == 'host'


# Generated at 2022-06-11 05:37:33.148705
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual({})
    virt.get_virtual_facts()



# Generated at 2022-06-11 05:37:34.821314
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:35.451002
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:37:38.312548
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert virtual_facts_collector.platform == 'FreeBSD'
    assert virtual_facts_collector._fact_class == FreeBSDVirtual
    assert virtual_facts_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:40.140093
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector.'''
    # Check instance
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:37:49.313307
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # fake data for unit test
    sysctl_vendor_data = {
        'hw.model': 'VirtualBox (C)',
        'security.jail.jailed': 0,
        'kern.vm_guest': 'other'
    }
    sysctl_kern_vm_guest_data = {
        'virtualization_type': 'other',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['other'])
    }

# Generated at 2022-06-11 05:39:20.854779
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert 'guest' in facts['virtualization_role']


# Generated at 2022-06-11 05:39:22.685705
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._fact_class is not None
    assert FreeBSDVirtualCollector()._platform is not None

# Generated at 2022-06-11 05:39:28.842039
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class FreeBSDVirtual '''
    virtual_facts = {
        'hardware_model': 'amd64',
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(),
    }
    freebsd_virtual_facts = FreeBSDVirtual(None, 'freebsd').get_virtual_facts()
    assert freebsd_virtual_facts == virtual_facts

# Generated at 2022-06-11 05:39:30.511565
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v_c = FreeBSDVirtualCollector()
    assert v_c._fact_class == FreeBSDVirtual
    assert v_c._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:36.582485
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize a FreeBSDVirtual object
    bsdvirtual = FreeBSDVirtual()
    # Call method get_virtual_facts to find virtual facts
    virtual_facts = bsdvirtual.get_virtual_facts()
    # Assert the values of the facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technology_host' in virtual_facts
    assert 'virtualization_technology_guest' in virtual_facts
    assert 'virtualization_products_host' in virtual_facts
    assert 'virtualization_products_guest' in virtual_facts

# Generated at 2022-06-11 05:39:43.404353
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    result = {
      "virtualization_role": "host",
      "virtualization_type": "docker",
      "virtualization_tech_host": {
        "docker"
      },
      "virtualization_tech_guest": set(),
    }

    kern_vm_guest = {
        "kern.vm_guest": "other",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": {
            "docker",
            "linux_container"
        }
    }

    hw_hv_vendor = {
        "hw.hv_vendor": "bhyve",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": {
            "bhyve"
        }
    }

    sec_jail

# Generated at 2022-06-11 05:39:51.262885
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class mock_FreeBSDVirtual(FreeBSDVirtual):
        def __init__(self):
            self.sysctl_facts = {
                'kern.vm_guest': 'freebsd-jail',
                'hw.model': 'FreeBSD/amd64',
                'security.jail.jailed': 0,
                'hw.hv_vendor': 'bhyve',
            }

    mock_freebsd_virtual = mock_FreeBSDVirtual()
    mock_freebsd_virtual.get_virtual_facts()
    assert mock_freebsd_virtual.virtual_facts['virtualization_type'] == ''
    assert mock_freebsd_virtual.virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:39:52.871673
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class is not None


# Generated at 2022-06-11 05:40:00.871993
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] in [
        'kvm', 'xen', 'jail', '', 'vbox', 'vmware', 'parallels',
        'hyperv', 'unknown']
    assert virtual_facts['virtualization_role'] in ['guest', 'host', '']
    assert virtual_facts['virtualization_tech_host'] \
        in [['kvm', 'qemu'], ['xen'], ['jail'], ['jail'], ['jail'], [],
            ['vbox'], ['vmware'], ['parallels'], ['hyperv'],
            ['generic', 'google', 'unknown']]

# Generated at 2022-06-11 05:40:01.940287
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(VirtualCollector._instance, FreeBSDVirtualCollector)