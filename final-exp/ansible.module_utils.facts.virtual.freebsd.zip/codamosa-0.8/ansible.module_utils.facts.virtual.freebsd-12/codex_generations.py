

# Generated at 2022-06-11 05:31:25.792188
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Create an instance of FreeBSDVirtualCollector using the constructor and
    check if result falls into the appropriate class
    """
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:31:29.937040
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create a FreeBSDVirtual object
    v = FreeBSDVirtual()

    # Get the virtual facts using get_virtual_facts
    facts = v.get_virtual_facts()

    # Assert the get_virtual_facts return at least the virtualization_type
    assert (facts['virtualization_type'])

# Generated at 2022-06-11 05:31:31.017834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector, 'collect')

# Generated at 2022-06-11 05:31:38.614222
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:31:39.246035
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:41.716453
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:31:44.554444
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_class = FreeBSDVirtualCollector()
    assert fact_class._fact_class == FreeBSDVirtual
    assert fact_class._platform == 'FreeBSD'


# Generated at 2022-06-11 05:31:55.308787
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Test with no information source
    data = {}
    fv = FreeBSDVirtual(data)
    facts = fv.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    # Test with kern.vm_guest='vmware':
    data = {'kern.vm_guest': 'vmware'}
    fv = FreeBSDVirtual(data)
    facts = fv.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'

    # Test with security.jail.jailed=1:
    data = {'security.jail.jailed': '1'}
    fv = FreeBSDVirtual(data)
    facts = fv.get_

# Generated at 2022-06-11 05:31:57.762517
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-11 05:31:58.601404
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact = FreeBSDVirtual()
    assert fact.platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:06.487614
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import platform
    import sys

    # Initialize FreeBSDVirtualCollector
    if sys.platform != 'FreeBSD':
        try:
            bsd = FreeBSDVirtualCollector()
        except Exception:
            pass
    else:
        bsd = FreeBSDVirtualCollector()
    assert isinstance(bsd, FreeBSDVirtualCollector)
    assert bsd.platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:16.889965
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    #
    # Virtualization type set to 'xen'
    # with virtualization_role set to 'guest'
    #
    assert FreeBSDVirtual(None, {'kernel': 'FreeBSD'}).get_virtual_facts()['virtualization_type'] == 'xen'
    assert FreeBSDVirtual(None, {'kernel': 'FreeBSD'}).get_virtual_facts()['virtualization_role'] == 'guest'

    #
    # Virtualization type set to 'kvm'
    # with virtualization_role set to 'guest'
    #

# Generated at 2022-06-11 05:32:25.594458
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualCollector
    from .test_virtual import TestVirtual, TestVirtualCollector

    class TestFreeBSDVirtual(FreeBSDVirtual, TestVirtual):
        pass

    class TestFreeBSDVirtualCollector(FreeBSDVirtualCollector, TestVirtualCollector):
        pass

    TestVirtual.collector = TestFreeBSDVirtualCollector()
    TestVirtual.platform = 'FreeBSD'
    test_virtual = TestFreeBSDVirtual('')


# Generated at 2022-06-11 05:32:30.486205
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtMod = FreeBSDVirtual()
    virtual_facts = virtMod.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert not virtual_facts['virtualization_type'] and not virtual_facts['virtualization_role'] and not virtual_facts['virtualization_tech_host'] and not virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-11 05:32:33.971760
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    f_module = freebsd_virtual_collector.get_virtual_facts()
    assert f_module['virtualization_type'] != '' or f_module['virtualization_role'] != ''

# Generated at 2022-06-11 05:32:43.677265
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.windows import virtual_test_cases
    freebsd = FreeBSDVirtual()
    freebsd.detected = False
    freebsd.products = {}
    freebsd.facts = {}

    # Test 1: Unset kern.guest, hw.model and security.jail.jailed values
    freebsd.products['kern.vm_guest'] = ['none']
    freebsd.products['hw.hv_vendor'] = []
    freebsd.products['security.jail.jailed'] = []
    freebsd.products['hw.model'] = []

    # Call the get_virtual_facts() method of class FreeBSDVirtual
    freebsd_virtual_facts = freebsd.get_virtual_facts()

    # Assert

# Generated at 2022-06-11 05:32:47.877905
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test whether method get_virtual_facts of class FreeBSDVirtual
    is working properly.
    """
    # Given
    facts = dict()
    # When
    result = FreeBSDVirtual().get_virtual_facts()
    # Then
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

# Generated at 2022-06-11 05:32:50.615601
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:02.586384
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class TestFreeBSDVirtual:
        def __init__(self, **kwargs):
            self.result = {}
            self.params = {}
            self.add_default_facts = kwargs.get('add_default_facts', False)

        def detect_virt_product(self, sysctl):
            return VirtualSysctlDetectionMixin.detect_virt_product(self, sysctl)

        def detect_virt_vendor(self, sysctl):
            return VirtualSysctlDetectionMixin.detect_virt_vendor(self, sysctl)

    f_facts = TestFreeBSDVirtual()
    facts = FreeBSDVirtual().get_virtual_facts()

    tech_guest = {'virt_what_configured_guest_tech', 'virt_what_not_configured_guest_tech'}
    tech_

# Generated at 2022-06-11 05:33:05.697088
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt_collection = FreeBSDVirtualCollector()
    assert(virt_collection.platform == 'FreeBSD')
    assert(virt_collection.fact_class == FreeBSDVirtual)

# Generated at 2022-06-11 05:33:23.424516
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sample = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }
    facts = FreeBSDVirtual(None).get_virtual_facts()
    assert set(facts.keys()) == set(sample.keys())
    assert set(facts['virtualization_tech_guest']) == set(sample['virtualization_tech_guest'])
    assert set(facts['virtualization_tech_host']) == set(sample['virtualization_tech_host'])
    assert facts['virtualization_type'] == sample['virtualization_type']
    assert facts['virtualization_role'] == sample['virtualization_role']

# Generated at 2022-06-11 05:33:25.247149
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:27.387475
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert instance._platform == 'FreeBSD'
    assert instance._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:36.556454
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    # 'virtualization_type': '',
    # 'virtualization_role': '',
    # 'virtualization_tech_guest': set(),
    # 'virtualization_tech_host': set(),
    expected = {'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()}
    assert virtual.get_virtual_facts() == expected

    # set values in _kern_vm_guest_virt_table
    virtual._kern_vm_guest_virt_table = {
        'other' : ('unknown', 'unknown', set(), set()),
        'jail' : ('jail', 'guest', {'jail'}, set()),
    }
    #

# Generated at 2022-06-11 05:33:43.041386
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test FreeBSDVirtualCollector class."""
    virtual_collector = FreeBSDVirtualCollector()
    if virtual_collector.platform != 'FreeBSD':
        raise AssertionError("Virtual collector's platform is set wrong.")
    if not issubclass(virtual_collector._fact_class, Virtual):
        raise AssertionError("Virtual collector's fact class is set wrong.")

    if virtual_collector.platform != virtual_collector._platform:
        raise AssertionError("Virtual collector's platform should equal to it's _platform value.")

# Generated at 2022-06-11 05:33:43.983965
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector(), 'platform')

# Generated at 2022-06-11 05:33:47.561554
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)
    assert hasattr(fv, '_fact_class')
    assert hasattr(fv, '_platform')
    assert fv._platform == 'FreeBSD'


# Generated at 2022-06-11 05:33:49.564030
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  c = FreeBSDVirtualCollector()
  assert isinstance(c,VirtualCollector), 'Object is not of expected class'

# Generated at 2022-06-11 05:33:51.377388
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual_collector = FreeBSDVirtualCollector()
    print(bsd_virtual_collector)

# Generated at 2022-06-11 05:34:00.828221
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test against FreeBSD jail
    jail_keyval = {'kern.vm_guest': 'other', 'hw.hv_vendor': 'bhyve', 'security.jail.jailed': 1}
    jail_test = FreeBSDVirtual()
    jail_test.sysctl_vals = jail_keyval
    jail_test.sysctl_map = {'kern.vm_guest': 'other', 'hw.hv_vendor': 'bhyve', 'security.jail.jailed': 1}
    jail_results = jail_test.get_virtual_facts()
    assert jail_results['virtualization_type'] == 'jail'
    assert jail_results['virtualization_role'] == 'guest'
    assert jail_results['virtualization_tech'] == 'jail'

    # Test against FreeBSD bhy

# Generated at 2022-06-11 05:34:26.442755
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    class VirtualWithKernelVersion(object):
        def kernel_version(self):
            return 'FreeBSD'
    class VirtualWithFact(object):
        def __init__(self):
            self.fact = VirtualWithKernelVersion()
            self.sysctl = {
                'security.jail.jailed': '0',
                'hw.hv_vendor': '',
                'hw.model': 'VMWare Virtual Platform',
                'kern.vm_guest': 'other',
            }

# Generated at 2022-06-11 05:34:30.458733
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-11 05:34:32.451610
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-11 05:34:37.875463
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts is not None
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:34:40.219314
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:48.834718
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils._text import to_bytes

    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in (None, '', 'xen')
    assert virtual_facts['virtualization_role'] in (None, '', 'guest')

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type_role'] == 'xen guest'
    assert virtual_facts['virtualization_hypervisor'] == 'xen'
    assert set(virtual_facts['virtualization_tech_guest']) == set(['xen'])

# Generated at 2022-06-11 05:34:57.937884
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:34:59.652339
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:02.921089
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test FreeBSDVirtualCollector class constructor with expected parameters
    '''
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual._fact_class
    assert freebsd_virtual._platform

# Generated at 2022-06-11 05:35:11.266224
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kern_vm_guest = {'virtualization_tech_host': set(['kern_vm_guest']),
                     'virtualization_tech_guest': set(['vmware']),
                     'virtualization_type': 'vmware',
                     'virtualization_role': 'guest'}
    hw_hv_vendor = {'virtualization_tech_host': set(['hw_hv_vendor']),
                    'virtualization_tech_guest': set(['vmware']),
                    'virtualization_type': 'vmware',
                    'virtualization_role': 'guest'}

# Generated at 2022-06-11 05:35:33.305230
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    detector = FreeBSDVirtualCollector()
    assert detector._platform == 'FreeBSD'
    assert detector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:41.406224
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(module=None).get_virtual_facts()

    # The assert statements below do not catch all possible results.
    # Those tests are just intended as simple sanity checks.
    assert virtual_facts['virtualization_type'] in ('', 'xen', 'virtualbox', 'kvm', 'vsphere', 'esxi', 'hyperv', 'jail')
    assert virtual_facts['virtualization_role'] in ('', 'guest')
    assert virtual_facts['virtualization_tech_host'] == set() or \
        virtual_facts['virtualization_tech_host'].issubset(['xen', 'kvm', 'vsphere', 'esxi', 'hyperv'])

# Generated at 2022-06-11 05:35:43.921038
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:35:46.167963
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facter = FreeBSDVirtualCollector(None, None, None)
    assert facter.platform == 'FreeBSD', 'Platform should be FreeBSD'

# Generated at 2022-06-11 05:35:55.864897
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    p = FreeBSDVirtual({}, None, 'virt-what')

    p._module.run_command.return_value = (1, '', '')
    assert p.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': ''}

    p._module.run_command.return_value = (0, 'VirtualBox', '')
    assert p.get_virtual_facts() == {'virtualization_type': 'virtualbox', 'virtualization_role': ''}

    p._module.run_command.return_value = (0, 'VMware', '')
    assert p.get_virtual_facts() == {'virtualization_type': 'vmware', 'virtualization_role': ''}

    p._module.run_command.return_value = (0, 'KVM', '')
    assert p

# Generated at 2022-06-11 05:35:57.275175
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts is not None

# Generated at 2022-06-11 05:35:58.540908
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert type(obj) == FreeBSDVirtualCollector

# Generated at 2022-06-11 05:35:59.359464
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:01.824335
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:02.868475
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:37:08.945661
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:12.356639
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FV = FreeBSDVirtual()
    actual_FV = FV.get_virtual_facts()
    if actual_FV['virtualization_type'] == '':
        assert not actual_FV['virtualization_role']
    else:
        assert actual_FV['virtualization_role']

# Generated at 2022-06-11 05:37:14.131161
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector,VirtualCollector)

# Generated at 2022-06-11 05:37:14.914900
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:15.747245
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:17.072852
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:37:24.595076
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    import re
    import copy

    class AnsibleModuleMock(basic.AnsibleModule):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

    testcases = list()

    expected = {'virtualization_type': 'xen', 'virtualization_role': 'guest'}

# Generated at 2022-06-11 05:37:27.401922
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.platform == 'FreeBSD'
    assert freebsd_virtual_collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:37:31.676944
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    # Get the instance of class FreeBSDVirtual
    virtual_facts = virtual_collector.collect()

    # Assert that virtual_facts is an instance of class FreeBSDVirtual
    assert isinstance(virtual_facts, FreeBSDVirtual)

    # Assert that platform of the instance is 'FreeBSD'
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:32.552419
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-11 05:40:32.865060
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({})
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-11 05:40:34.251336
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    virtual = FreeBSDVirtual(facts)

    virtual.get_virtual_facts()

# Generated at 2022-06-11 05:40:34.731890
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:40:36.765797
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj_vb = FreeBSDVirtualCollector()
    assert obj_vb._platform == 'FreeBSD'
    assert obj_vb._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:40:43.263242
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of FreeBSDVirtual class
    """
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    f_virtual = FreeBSDVirtual({'ansible_python_version': '2.7.5'})
    assert 'FreeBSD' == f_virtual.platform
    assert f_virtual.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-11 05:40:46.904636
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    # Test if virtualization facts are correct
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-11 05:40:48.787793
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.collect() == obj.fact_class.fetch_virtual_facts()

# Generated at 2022-06-11 05:40:53.192763
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtualCollector()
    facts = collector.collect(None, None)
    assert facts == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(['vbox']),
        'virtualization_tech_guest': set(['vbox']),
    }

# Generated at 2022-06-11 05:40:57.247821
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual(dict()).get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_product_name' in facts
    assert 'virtualization_product_version' in facts

# Generated at 2022-06-11 05:41:01.150532
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual(None, {}, None, None, '/tmp')
    freebsd_virtual_facts.get_virtual_facts()
    param = freebsd_virtual_facts.facts
    for key in param.keys():
        assert param[key] is not ''