

# Generated at 2022-06-11 05:31:34.091386
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mock_module = type('module', (), {})
    mock_module.params = {}

    virtual = FreeBSDVirtual(mock_module)

    # FreeBSD guest on QEMU
    virtual.module.get_bin_path = lambda x: '/sbin'
    virtual._get_file_content = lambda x: 'QEMU Virtual CPU version 2.5+'
    assert virtual.get_virtual_facts() == {
        'virtualization_type': 'hvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm', 'qemu']),
        'virtualization_tech_host': set(['xen', 'kvm', 'qemu', 'jail'])
    }

    # FreeBSD guest on BHyve
    virtual.module.get_bin_path

# Generated at 2022-06-11 05:31:34.625526
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:36.676099
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == "FreeBSD"
    assert virtual_collector._fact_class.platform == "FreeBSD"

# Generated at 2022-06-11 05:31:47.464374
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test empty facts data, nothing is set
    facts = {}
    virtual_facts = FreeBSDVirtual(facts, None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Test facts data with virtualization_type set to 'xen', virtualization_role is set to guest
    facts = {}
    facts['virtualization_type'] = 'xen'
    virtual_facts = FreeBSDVirtual(facts, None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Test facts data with virtualization_role set to 'guest', virtualization_type is set to ''
    facts = {}

# Generated at 2022-06-11 05:31:57.002189
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    fact = FreeBSDVirtual
    fact = fact.get_virtual_facts()
    assert fact['virtualization_type'] == ''
    assert fact['virtualization_role'] == ''
    assert fact['virtualization_tech_guest'] == set()
    assert fact['virtualization_tech_host'] == set()
    assert fact['virtualization_product_guest'] == set()
    assert fact['virtualization_product_host'] == set()


# Generated at 2022-06-11 05:32:02.946336
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    iface = FreeBSDVirtual({})
    res = iface.get_virtual_facts()
    assert res['virtualization_type'] == '' or type(res['virtualization_type']) == str, 'freebsd virtualization_type is not a string'
    assert res['virtualization_role'] == '' or type(res['virtualization_role']) == str, 'freebsd virtualization_role is not a string'
    assert type(res['virtualization_technologies_host']) == set, 'freebsd virtualization_technologies_host is not a set'
    assert type(res['virtualization_technologies_guest']) == set, 'freebsd virtualization_technologies_guest is not a set'

# Generated at 2022-06-11 05:32:05.135695
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert isinstance(virtual_facts, (FreeBSDVirtual, VirtualCollector)) and \
           isinstance(virtual_facts.platform, str)

# Generated at 2022-06-11 05:32:15.337923
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    sysctl_vendor = VirtualSysctlDetectionMixin()
    sysctl_vendor.get_virtual_facts = classmethod(lambda cls:
                                                  {'virtualization_type': 'xen',
                                                   'virtualization_role': 'guest'})
    class FreeBSDVirtual(FreeBSDVirtual, sysctl_vendor):
        pass

    virtual_tech_guest = set(['openvz', 'jail', 'bhyve'])
    virtual_tech_host = set(['openvz-host', 'jail-host', 'bhyve-host'])


# Generated at 2022-06-11 05:32:24.513130
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:32:25.628308
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj is not None


# Generated at 2022-06-11 05:32:36.116243
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:37.231701
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector is not None

# Generated at 2022-06-11 05:32:38.969231
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    print(virtual_collector)



# Generated at 2022-06-11 05:32:39.667023
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:40.641259
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:32:42.285921
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:47.920406
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()
    freebsd_virtual.detect_virt_product('kern.vm_guest')
    freebsd_virtual.detect_virt_product('hw.hv_vendor')
    freebsd_virtual.detect_virt_product('security.jail.jailed')
    freebsd_virtual.detect_virt_vendor('hw.model')

# Generated at 2022-06-11 05:32:51.920685
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).collect()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:32:54.322215
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    myfact = FreeBSDVirtualCollector()
    assert isinstance(myfact, FreeBSDVirtualCollector)
    assert isinstance(myfact.get_facts(), dict)

# Generated at 2022-06-11 05:33:06.505567
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    ## xen
    guest_tech_xen = set(['xen'])
    kern_xen = dict(virtualization_tech_guest=guest_tech_xen,
                    virtualization_tech_host=set(),
                    virtualization_type='',
                    virtualization_role='')
    hw_xen = dict(virtualization_tech_guest=guest_tech_xen,
                  virtualization_tech_host=set(),
                  virtualization_type='',
                  virtualization_role='')
    sec_jail_xen = dict(virtualization_tech_guest=guest_tech_xen,
                        virtualization_tech_host=set(),
                        virtualization_type='',
                        virtualization_role='')
    v_xen = dict

# Generated at 2022-06-11 05:33:17.338571
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:21.330230
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Create an instance of FreeBSDVirtualCollector class and
    if constructor call doesn't fail, then return True
    """
    collector = FreeBSDVirtualCollector()
    assert collector.__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-11 05:33:22.788552
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None, None, None, None)

# Generated at 2022-06-11 05:33:25.049310
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector(None, None)
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:30.350848
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set(['xen'])

# Generated at 2022-06-11 05:33:32.285603
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:36.380768
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_col = FreeBSDVirtualCollector()
    assert hasattr(freebsd_virtual_col, '_fact_class')
    assert FreeBSDVirtual == freebsd_virtual_col._fact_class
    assert hasattr(freebsd_virtual_col, '_platform')
    assert 'FreeBSD' == freebsd_virtual_col._platform


# Generated at 2022-06-11 05:33:39.425955
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fs = FreeBSDVirtual({})
    virtual_facts = fs.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts


# Generated at 2022-06-11 05:33:41.504837
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    newInstance = FreeBSDVirtualCollector('hw.model')
    assert newInstance is not None
    assert newInstance.platform == 'FreeBSD'


# Generated at 2022-06-11 05:33:44.869799
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected = {'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()}
    assert FreeBSDVirtual().get_virtual_facts() == expected

# Generated at 2022-06-11 05:33:57.407086
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtualCollector()
    f.collect()
    assert 'virtualization_type' in f.data['ansible_facts']['virtualization']
    assert 'virtualization_role' in f.data['ansible_facts']['virtualization']

# Generated at 2022-06-11 05:33:58.644816
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-11 05:34:07.377490
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Test stub for get_virtual_facts method of FreeBSDVirtual class.
    '''
    module_name = 'ansible_facts.virtual.FreeBSDVirtual'
    module_args = ''
    results = dict(changed=False)
    results['ansible_facts'] = dict(virtual=dict())

    fbv = FreeBSDVirtual()

    # Set VirtualSysctlDetectionMixin._products in VirtualSysctlDetectionMixin
    virtualsysctldetectionmixin_products = dict()
    virtualsysctldetectionmixin_products['kern.vm_guest'] = ''
    virtualsysctldetectionmixin_products['hw.hv_vendor'] = 'VMware'
    virtualsysctldetectionmixin_products['security.jail.jailed'] = ''
    # Set VirtualSysctlDet

# Generated at 2022-06-11 05:34:09.065664
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts.platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:15.803811
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb_virtual = FreeBSDVirtual()
    facts = fb_virtual.get_virtual_facts()
    assert type(facts) is dict
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-11 05:34:17.946440
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:23.867457
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt.read_sysctl_virtualization_facts()
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:34:25.288309
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-11 05:34:28.386627
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class == FreeBSDVirtual
    assert x.fact_subclasses == dict()
    assert x.fact_order == list()


# Generated at 2022-06-11 05:34:30.614687
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:53.519472
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:56.190290
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    print(v.get_virtual_facts())


if __name__ == '__main__':
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:34:58.304060
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    if not hasattr(FreeBSDVirtualCollector, '_platform'):
        raise Exception('Class FreeBSDVirtualCollector does not have a _platform')

# Generated at 2022-06-11 05:34:58.893780
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:35:02.927377
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, VirtualCollector)
    assert isinstance(fv, VirtualSysctlDetectionMixin)
    assert fv._fact_class == FreeBSDVirtual
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:03.907103
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual._platform == 'FreeBSD'
    assert freebsd_virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:06.450141
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector._platform == 'FreeBSD'
    assert facts_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:07.348833
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(),VirtualCollector)


# Generated at 2022-06-11 05:35:08.506326
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None, None), VirtualCollector)

# Generated at 2022-06-11 05:35:09.474388
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fb = FreeBSDVirtualCollector()
    assert fb is not None

# Generated at 2022-06-11 05:36:07.432544
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create instance of FreeBSDVirtual
    freebsd_virtual = FreeBSDVirtual()

    # Check return value of method get_virtual_facts
    # if no key is set in params
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in freebsd_virtual_facts
    assert not freebsd_virtual_facts['virtualization_type']
    assert 'virtualization_role' in freebsd_virtual_facts
    assert not freebsd_virtual_facts['virtualization_role']

    # Check return value of method get_virtual_facts
    # if virtualization_type key is set to 'xen' in params
    freebsd_virtual.params = {'virtualization_type': 'xen'}
    freebsd_virtual_facts = freebsd_virtual

# Generated at 2022-06-11 05:36:09.836995
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual


# Unit test to verify virtualization facts

# Generated at 2022-06-11 05:36:12.278799
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''
    result = FreeBSDVirtualCollector()
    assert result.platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:14.325137
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    # It's supposed to be a dict
    assert virtual_facts.__class__ is dict

# Generated at 2022-06-11 05:36:17.466304
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_collector = FreeBSDVirtualCollector()
    fv = fv_collector.collect()[0]

    assert (fv.platform == 'FreeBSD')
    assert (fv.get_platform() == 'FreeBSD')

# Generated at 2022-06-11 05:36:18.645297
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:21.672492
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == "FreeBSD"
    assert virtual_collector._fact_class.__name__ == "FreeBSDVirtual"
    assert virtual_collector._fact_class.platform == "FreeBSD"


# Generated at 2022-06-11 05:36:28.227575
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts_dict = {'kernel': 'FreeBSD', 'machine': 'amd64'}
    bsd_virtual_facts = FreeBSDVirtual(module=None, facts=facts_dict)

    # set the facts
    bsd_virtual_facts.get_virtual_facts()

    # get the facts
    facts = bsd_virtual_facts.facts
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 05:36:31.950503
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert isinstance(fbc, FreeBSDVirtualCollector)
    assert issubclass(fbc.__class__, VirtualCollector)
    assert issubclass(fbc._fact_class, Virtual)
    assert fbc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:36.572964
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:37:56.768861
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_type'] in ['xen', '', 'jail', 'vmware', 'parallels', 'virtualbox', 'kvm']
    assert virtual_facts['virtualization_role'] in ['guest', 'host', '']
    # 'virtualization_tech_guest' and 'virtualization_tech_host' contain a list of virtualization technologies
    # and should not be empty, but they can be empty.

# Generated at 2022-06-11 05:37:58.702205
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._fact_class == FreeBSDVirtual
    assert x._platform == 'FreeBSD'


# Generated at 2022-06-11 05:38:00.629001
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # this will raise an exception if the test fails
    # TODO: add some better tests
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:38:03.511315
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == "FreeBSD"
    assert FreeBSDVirtualCollector()._platform == "FreeBSD"
    assert FreeBSDVirtualCollector()._fact_class.platform == "FreeBSD"

# Generated at 2022-06-11 05:38:06.530117
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'


# Generated at 2022-06-11 05:38:15.967520
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""
    # Create FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()
    # Set attributes of class FreeBSDVirtual
    freebsd_virtual.detect_virt_product = test_detect_virt_product_func
    freebsd_virtual.detect_virt_vendor = test_detect_virt_vendor_func
    # Run method get_virtual_facts of class FreeBSDVirtual
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()
    # Verify if we get the exptected virtual facts
    assert freebsd_virtual_facts['virtualization_type'] == 'xen'
    assert freebsd_virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:38:18.163666
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:26.671988
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_freebsd_virtual = FreeBSDVirtual(None)

# Generated at 2022-06-11 05:38:30.377494
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    freebsd_virtual_data = freebsd_virtual_collector._get_virtual_facts()
    assert 'virtualization_type' in freebsd_virtual_data
    assert 'virtualization_role' in freebsd_virtual_data

# Generated at 2022-06-11 05:38:34.597928
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    FreeBSDVirtual().get_facts(facts)
    virtual_facts = FreeBSDVirtual().get_virtual_facts(facts)

    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:41:22.285129
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    facts = fv.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_technologies'] == set()
    assert facts['virtualization_technologies_guest'] == set()
    assert facts['virtualization_technologies_host'] == set()
    # This file doesn't exist on FreeBSD
    assert 'product_name' not in facts
    # We don't know this for sure for FreeBSD
    assert 'virtualization_system' not in facts
