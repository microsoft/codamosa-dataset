

# Generated at 2022-06-11 05:31:33.148956
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    def run_test(kern_vm_guest, hw_hv_vendor, sec_jail_jailed, hw_model):

        obj = FreeBSDVirtual({'ansible_kernel': 'FreeBSD', 'sysctl': {
                              'kern.vm_guest': kern_vm_guest,
                              'hw.hv_vendor': hw_hv_vendor,
                              'security.jail.jailed': sec_jail_jailed,
                              'hw.model': hw_model}})

        return obj.get_virtual_facts()

    # test when we are running on a host system
    result = run_test("unknown", "", 0, "ABC123")
    assert result['virtualization_type'] == ""
    assert result['virtualization_role'] == ""



# Generated at 2022-06-11 05:31:34.491397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:37.293688
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    hv_info = {'virtualization_type': 'xen',
               'virtualization_role': 'guest'}
    virtual_facts = FreeBSDVirtual(hv_info).get_virtual_facts()
    assert virtual_facts == hv_info

# Generated at 2022-06-11 05:31:48.220226
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'unit/module_utils/facts/virtual/sysctl')
    sample_sysctl_path = os.path.join(data_dir, 'sample_sysctl.conf')
    test_facts = FreeBSDVirtual()
    test_facts._get_sysctl_facts = lambda: {'hw.hv_vendor': 'bhyve', 'kern.vm_guest': 'other',
                                            'security.jail.jailed': '0'}
    test_facts._get_sysctl_conf = lambda: sample_sysctl_path
    test_facts._get_model = lambda: 'Apollo Lake'
    virtual_facts = test

# Generated at 2022-06-11 05:31:51.030747
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:00.092582
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json
    fbsd_virtual = FreeBSDVirtual()

    # Test with emtpty data
    assert fbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Test with data from linux (should be ignored)

# Generated at 2022-06-11 05:32:02.527206
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:11.519935
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Arrange
    class TestFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, sysctl):
            return { 'virtualization_type': 'vbox' }

        def detect_virt_vendor(self, model):
            return { 'virtualization_type': 'hyperv' }

    # Act
    virtual = TestFreeBSDVirtual()
    facts = virtual.get_virtual_facts()

    # Assert
    assert 'virtualization_type' in facts
    assert 'virtualization_type' in facts['virtualization_type']
    assert 'virtualization_role' in facts
    assert 'virtualization_role' in facts['virtualization_role']
    assert facts['virtualization_type'] == 'hyperv'
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:32:18.597732
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import Virtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    virtual_facts = Virtual()
    freebsd_virtual_facts = FreeBSDVirtual()
    assert isinstance(freebsd_virtual_facts, Virtual)
    assert isinstance(freebsd_virtual_facts, VirtualSysctlDetectionMixin)
    assert isinstance(freebsd_virtual_facts, FreeBSDVirtual)

# Generated at 2022-06-11 05:32:19.216405
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:32:32.331428
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, {})
    virtual.module = {'kernel': 'FreeBSD'}

    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    VirtualSysctlDetectionMixin.get_sysctl = lambda x: None
    VirtualSysctlDetectionMixin.get_sysctl_all = lambda: None

    # Test on FreeBSD host with no virtualization
    assert virtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    # Test on FreeBSD host with bhyve

# Generated at 2022-06-11 05:32:34.437621
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:44.147959
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual.freebsd
    import ansible.module_utils.facts.virtual.sysctl

    # Mock FreeBSDVirtualSysctlDetectionMixin
    sysctl_mixin = ansible.module_utils.facts.virtual.sysctl.VirtualSysctlDetectionMixin()

# Generated at 2022-06-11 05:32:45.453572
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector is not None


# Generated at 2022-06-11 05:32:47.121803
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_object = FreeBSDVirtualCollector()
    assert fv_object.platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:50.395080
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:33:02.376062
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setting the following variables to test the method get_virtual_facts of class FreeBSDVirtual
    # lsb_product_name will be set to 'xen', 'kvm', 'jail' or any other string
    lsb_product_name = 'xen'
    # proc_xen_capabilities will be set to 'control_d', 'xen-3.0-x86_64' or any other string
    proc_xen_capabilities = 'xen-3.0-x86_64'
    # lsb_product_version will be set to '7.0-RELEASE', '15.1-RELEASE' or any other string
    lsb_product_version = '7.0-RELEASE'
    # kern_guest_os will be set to 'FreeBSD/amd64', 'NetBSD/i386' or

# Generated at 2022-06-11 05:33:03.069354
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:03.705063
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:13.265390
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual

    class CheckFreeBSDVirtual(Virtual, VirtualSysctlDetectionMixin, FreeBSDVirtual):
        def __init__(self, module):
            Virtual.__init__(self, module)
            VirtualSysctlDetectionMixin.__init__(self, module)

    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')

    freebsd_virtual = CheckFreeBSDVirtual(mock_module)
    freebsd_virtual_facts = freebsd_virtual.get_virtual_facts()

    assert freebsd

# Generated at 2022-06-11 05:33:27.961486
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # On some FreeBSD system, the 'sysctl' program does not exist so just skip
    # the test when it does not exist
    try:
        os.stat("/sbin/sysctl")
    except OSError:
        return
    # On some FreeBSD system, the 'jail' program does not exist so just skip
    # the test when it does not exist
    try:
        os.stat("/sbin/jail")
    except OSError:
        return
    # On some FreeBSD system, the /dev/xen/xenstore file does not exist so just skip
    # the test when it does not exist
    try:
        os.stat("/dev/xen/xenstore")
    except OSError:
        return
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_

# Generated at 2022-06-11 05:33:30.124324
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freeBSD = FreeBSDVirtualCollector()
    assert freeBSD._platform == 'FreeBSD'
    assert freeBSD._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:30.723851
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:33.476828
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    assert VirtualSysctlDetectionMixin in FreeBSDVirtualCollector.__mro__

# Generated at 2022-06-11 05:33:35.597574
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual()
    facts = f.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:33:37.853183
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:39.798953
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:40.405700
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    VirtualCollector()

# Generated at 2022-06-11 05:33:49.962234
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual()
    freebsd.collection_mapping = {
        'hw.model': {
            'xenserver': 'xen-hvm',
            'VMWare': 'vmware'
        },
        'hw.hv_vendor': {
            'Xen': 'xen',
            'VMWare': 'vmware'
        },
        'security.jail.jailed': {
            '0': 'jail',
            '1': 'jail',
        },
        'kern.vm_guest': {
            'none': 'none',
            'xen': 'xen',
            'bhyve': 'bhyve',
            'vmware': 'vmware',
        },
    }
    facts = freebsd.get_virtual_facts()
   

# Generated at 2022-06-11 05:33:53.060997
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert isinstance(fbc, FreeBSDVirtualCollector)
    assert isinstance(fbc._fact_class, FreeBSDVirtual)
    assert fbc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:04.559801
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    collector = FreeBSDVirtualCollector()
    result = collector.get_virtual_facts()

    # We must have virtualization_type
    assert 'virtualization_type' in result.keys()

    # We must have virtualization_role
    assert 'virtualization_role' in result.keys()

    # Virtualization techs are optional, but we get them when possible.
    assert 'virtualization_tech_host' in result.keys()
    assert 'virtualization_tech_guest' in result.keys()

# Generated at 2022-06-11 05:34:07.056788
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:34:07.590341
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:34:09.283741
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector), 'Constructor of class VirtualCollector failed'


# Generated at 2022-06-11 05:34:15.664175
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    print("Test FreeBSDVirtual - get_virtual_facts")
    v = FreeBSDVirtual()
    # Ensure that the system is detected as physical and not virtual
    assert v.get_virtual_facts()['virtualization_type'] == ''
    assert v.get_virtual_facts()['virtualization_role'] == ''
    assert not v.get_virtual_facts()['virtualization_tech_guest']
    assert not v.get_virtual_facts()['virtualization_tech_host']

# Generated at 2022-06-11 05:34:18.827155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = []
    facts = {'kernel': 'FreeBSD'}
    collect_virtual = FreeBSDVirtualCollector(None, facts, virtual_facts)
    assert collect_virtual

# Generated at 2022-06-11 05:34:22.710220
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts) == 5


# Generated at 2022-06-11 05:34:25.241190
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Unit test for the constructor of class FreeBSDVirtualCollector."""
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert isinstance(x._fact_class, type(FreeBSDVirtual))

# Generated at 2022-06-11 05:34:30.866990
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {'virtualization_role': 'guest',
             'virtualization_type': 'xen',
             'virtualization_tech_host': {'xen'},
             'virtualization_tech_guest': {'xen'}}

    freebsdv = FreeBSDVirtualCollector()
    assert freebsdv.platform == 'FreeBSD'
    assert freebsdv.get_all() == facts

# Generated at 2022-06-11 05:34:33.512431
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:34:54.362581
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['xen', '', 'vmm']


# Generated at 2022-06-11 05:34:59.031590
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {}

    fbsd_virtual = FreeBSDVirtualCollector()
    facts.update(fbsd_virtual.collect(facts))
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-11 05:35:00.584985
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:35:02.456100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:08.086733
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    facts['ansible_virtualization_type'] = 'xen'
    facts['ansible_virtualization_role'] = 'guest'
    facts['ansible_virtualization_tech_guest'] = {'xen'}
    facts['ansible_virtualization_tech_host'] = set()
    fvd = FreeBSDVirtual(facts)
    got_facts = fvd.get_virtual_facts()
    assert got_facts == facts

# Generated at 2022-06-11 05:35:13.894265
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # The following code is for unit test of method get_virtual_facts of class FreeBSDVirtual
    # mock the facts dict
    facts = dict()
    # mock the FreeBSDVirtual instance: instance of FreeBSDVirtual
    bsd = FreeBSDVirtual(facts)
    # mock the detection of xen product
    bsd.detect_virt_product = lambda x: {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': [],
        'virtualization_tech_host': []}
    # mock the detection of xen vendor

# Generated at 2022-06-11 05:35:16.536575
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:19.159040
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_info = FreeBSDVirtualCollector()
    assert virtual_info.platform == 'FreeBSD'
    assert virtual_info._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:29.531031
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:35:31.167669
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c,FreeBSDVirtualCollector)


# Generated at 2022-06-11 05:35:58.852874
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    try:
        assert(virtual_facts_collector.platform == 'FreeBSD')
        assert(virtual_facts_collector._fact_class is not None)
    except AssertionError as e:
        print(e)

# Generated at 2022-06-11 05:36:04.314257
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''test_FreeBSDVirtualCollector.py
    Unit test for constructor of class FreeBSDVirtualCollector.
    '''
    FreeBSD_virtual_fact_collector = FreeBSDVirtualCollector()
    assert FreeBSD_virtual_fact_collector.platform == 'FreeBSD'
    assert FreeBSD_virtual_fact_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:06.617157
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:36:11.450451
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_product_name' in facts
    assert 'virtualization_product_version' in facts

# Generated at 2022-06-11 05:36:13.150356
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    foo = FreeBSDVirtualCollector()
    assert foo._platform == 'FreeBSD'
    assert foo._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:15.628459
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    f = v.get_virtual_facts()
    assert 'virtualization_type' in f
    assert 'virtualization_role' in f

# Generated at 2022-06-11 05:36:17.311624
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:36:19.493361
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, VirtualCollector)
    assert issubclass(fv._fact_class, Virtual)


# Generated at 2022-06-11 05:36:21.266061
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts is not None
    assert facts._fact_class == FreeBSDVirtual
    assert facts._platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:30.871691
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test the FreeBSDVirtual class method get_virtual_facts using mocked values.
    """
    module_mock = {'kern.vm_guest': '', 'hw.hv_vendor': '', 'security.jail.jailed': '', 'hw.model': ''}
    module_mock_xen = {'kern.vm_guest': '', 'hw.hv_vendor': '', 'security.jail.jailed': '', 'hw.model': ''}
    module_mock_lx = {'kern.vm_guest': 'lx', 'hw.hv_vendor': '', 'security.jail.jailed': '', 'hw.model': ''}

# Generated at 2022-06-11 05:37:50.653946
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    test_class = FreeBSDVirtual({})
    test_class.module = type('module', (object,), {})
    test_class.module.get_bin_path = lambda x: x
    test_class.module.run_command = lambda x: {'rc': 0, 'stdout': 'xen'}

    result = test_class.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['xen'])
    assert result['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:37:52.215018
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c,FreeBSDVirtualCollector)


# Generated at 2022-06-11 05:37:53.828495
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:55.807757
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:56.362382
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:38:05.466808
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Check when virtualization_type is set to 'xen'
    with open('/dev/xen/xenstore', 'w') as f:
        f.write('xen')
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'xen'
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    # Check when virtualization_type is not set
    os.remove('/dev/xen/xenstore')
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:38:14.383729
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    fv.sysctl_products = {
        'kern.vm_guest': 'none',
        'hw.hv_vendor': 'none',
        'security.jail.jailed': '0',
    }
    fv.model = "QEMU Virtual CPU version 0.9.1"

    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert expected_virtual_facts == fv.get_virtual_facts()

# There are several similar cases.
# Simulating various virtualization_type values is enough.

# Generated at 2022-06-11 05:38:15.235537
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:19.830080
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_class = FreeBSDVirtual({'ansible_facts': {'kernel': 'FreeBSD'}})
    assert test_class.get_virtual_facts() == {'virtualization_type': '',
                                              'virtualization_role': '',
                                              'virtualization_tech_guest': set(),
                                              'virtualization_tech_host': set()
                                             }

# Generated at 2022-06-11 05:38:28.352536
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with an empty 'sysctl' command output, no virtualization_type nor
    # virtualization_role must be gotten
    virtual_facts = {'virtualization_type': '', 'virtualization_role': ''}
    collector = FreeBSDVirtualCollector([], lambda x, y, z: '', lambda x, y: '')
    assert collector.get_virtual_facts() == virtual_facts

    # Test with a XEN 'sysctl' command output, virtualization_type and
    # virtualization_role must be 'XEN'
    virtual_facts = {'virtualization_type': 'xen',
                     'virtualization_role': 'guest',
                     'virtualization_tech_guest': set(['xen']),
                     'virtualization_tech_host': set([])}

# Generated at 2022-06-11 05:41:20.237176
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd = FreeBSDVirtual()
    freebsd.sysctl = {
        'hw.hv_vendor': 'woot!',
        'security.jail.jailed': None,
        'kern.vm_guest': 'none'
    }
    freebsd.hw_model = 'VirtualBox'
    expected_attrs = dict(
        virtualization_type='virtualbox',
        virtualization_role='guest',
        virtualization_tech_guest={'virtualbox'},
        virtualization_tech_host=set())
    freebsd.get_virtual_facts()
    for attr, value in expected_attrs.items():
        assert getattr(freebsd, attr) == value

    freebsd = FreeBSDVirtual()