

# Generated at 2022-06-11 05:31:21.971682
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:24.291606
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v_c = FreeBSDVirtualCollector()
    assert v_c.platform == 'FreeBSD'
    assert v_c.fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:31:26.509821
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'


# Generated at 2022-06-11 05:31:36.237026
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    facts_dict = {
        'virtualization_type': "",
        'virtualization_role': "",
        'virtualization_techniques': set(),
        'virtualization_type_role': "",
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    # Test if the get_virtual_facts() method of FreeBSDVirtual class works
    # well with no underlying virtualization technology
    freebsd_virtual = FreeBSDVirtual(module=None)
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts == facts_dict

    # Test if the get_virtual_facts() method of FreeBSDVirtual class works
    # well with underlying virtualization technology
    freebsd_virtual = FreeBSDVirtual(module=None)
    freebsd_virtual.sys

# Generated at 2022-06-11 05:31:38.642502
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:40.407998
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:45.078501
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_facts = FreeBSDVirtual("fake_data").get_virtual_facts()
    assert test_facts['virtualization_type'] == ''
    assert test_facts['virtualization_role'] == ''
    assert 'virtualization_tech_guest' in test_facts
    assert 'virtualization_tech_host' in test_facts

# Generated at 2022-06-11 05:31:47.971947
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:31:50.428599
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class is FreeBSDVirtual
    assert fvc._platform is 'FreeBSD'

# Generated at 2022-06-11 05:31:51.496328
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:59.982210
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Use the Virtual class to generate test facts
    FreeBSDVirtual_instance = FreeBSDVirtual()
    FreeBSDVirtual_facts = FreeBSDVirtual_instance.get_virtual_facts()

    assert FreeBSDVirtual_facts['virtualization_type'] == ''
    assert FreeBSDVirtual_facts['virtualization_role'] == ''
    assert FreeBSDVirtual_facts['virtualization_tech_host'] == set()
    assert FreeBSDVirtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:32:01.047725
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None)._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:10.237603
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # info.xml content when the host is a VMWare VM
    info_xml = b"""<?xml version='1.0' encoding='UTF-8' standalone='yes'?>
<rpc-reply>
<data>
<value>
<struct>
<member>
<name>hw.model</name>
<value>
<string>VMware Virtual Platform</string>
</value>
</member>
<member>
<name>kern.vm_guest</name>
<value>
<string>VMware</string>
</value>
</member>
<member>
<name>security.jail.jailed</name>
<value>
<string>0</string>
</value>
</member>
</struct>
</value>
</data>
</rpc-reply>"""
    # info

# Generated at 2022-06-11 05:32:11.615059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v is not None

# Generated at 2022-06-11 05:32:20.225882
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    obj = VirtualSysctlDetectionMixin()
    obj.get_sysctl_data = lambda x: {
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': 1,
    }
    facts = FactCollector.collect(obj, {'ansible_system': 'FreeBSD'}, {})
    assert facts['virtualization_type'] == 'other'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:32:24.997836
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_module = type('module', (object,), {'params': {}})()
    freebsd_virtual = FreeBSDVirtual(fake_module)
    facts = freebsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'FreeBSD Jails'
    assert 'jail' in facts['virtualization_tech_guest']
    assert 'FreeBSD' in facts['virtualization_tech_host']

# Generated at 2022-06-11 05:32:27.726789
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fake_platform = 'FreeBSD'
    fvc = FreeBSDVirtualCollector(fake_platform)
    assert fvc.platform == fake_platform
    assert len(fvc._collectors) > 0

# Generated at 2022-06-11 05:32:30.000627
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test for constructor of class FreeBSDVirtualCollector'''
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:32:30.991462
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()


# Generated at 2022-06-11 05:32:32.485436
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, VirtualCollector)

# Generated at 2022-06-11 05:32:47.336031
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_fact_data = {
        'hw.hv_vendor': 'Bhyve',
        'kern.vm_guest': 'other',
        'security.jail.jailed': 0
    }
    freebsd = FreeBSDVirtual(fact_data=fake_fact_data)
    result = freebsd.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result



# Generated at 2022-06-11 05:32:58.695184
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_obj = FreeBSDVirtual()

    class FakeSysctl(object):
        def __init__(self, facts):
            self.facts = facts

        def get(self, fact):
            return self.facts[fact]

    test_facts = {
        'hw.model': 'Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz',
        'hw.hv_vendor': 'bhyve',
        'kern.vm_guest': 'other',
        'security.jail.jailed': 0}
    fake_sysctl = FakeSysctl(test_facts)
    virtual_facts = virtual_facts_obj._get_virtual_facts(fake_sysctl)
    assert not virtual_facts['virtualization_role']

# Generated at 2022-06-11 05:33:01.899293
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:33:11.970441
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from mock import patch, Mock
    facts = FreeBSDVirtual()
    mock_sysctl = {'kern.vm_guest': 'none', 'hw.hv_vendor': 'None', 'security.jail.jailed': '0'}
    mock_sysctl_result = {'kern.vm_guest': 'vmm', 'hw.hv_vendor': 'VMWare',
                          'security.jail.jailed': '1'}
    with patch('ansible.module_utils.facts.virtual.FreeBSDVirtual.get_sysctl_facts', return_value=mock_sysctl):
        with patch.object(FreeBSDVirtual, 'get_sysctl_facts', return_value=mock_sysctl_result):
            result = facts.get_virtual_facts()

# Generated at 2022-06-11 05:33:15.923318
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({})
    virtual_facts_facts = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts_facts
    assert 'virtualization_role' in virtual_facts_facts

# Generated at 2022-06-11 05:33:23.534299
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # This is a FreeBSD-specific subclass of Virtual
    virtual_facts = FreeBSDVirtual({})
    fact_subset = virtual_facts.get_virtual_facts()

    # Checking the existence of the results
    assert fact_subset is not None

    # Checking the existence of the results
    assert 'virtualization_type' in fact_subset
    assert 'virtualization_role' in fact_subset
    assert 'virtualization_tech_guest' in fact_subset
    assert 'virtualization_tech_host' in fact_subset


# Generated at 2022-06-11 05:33:25.861543
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    my_fact = FreeBSDVirtualCollector()
    assert my_fact._platform == 'FreeBSD'
    assert my_fact._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:29.168295
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:37.556074
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:33:39.565740
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:57.024797
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert FreeBSDVirtualCollector.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-11 05:33:59.240494
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """This test case is for constructor of class FreeBSDVirtualCollector"""

    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:05.364091
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Define a kern.vm_guest (will be updated later)
    freebsd_virtual.sysctl = {'kern.vm_guest': 'vmware'}

    # Define a hw.hv_vendor (will be updated later)
    freebsd_virtual.sysctl = {'hw.hv_vendor': ''}

    # Define a security.jail.jailed (will be updated later)
    freebsd_virtual.sysctl = {'security.jail.jailed': 0}

    # Call get_virtual_facts method
    kern_vm_guest = {'kern.vm_guest': 'vmware'}

# Generated at 2022-06-11 05:34:09.322406
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # simplest case: no virtualisation
    assert FreeBSDVirtual({}).get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:34:10.384219
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:12.577663
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:23.437057
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    TEST_VIRT_FACTS = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

    def get_sysctl_mock(key):
        """
        Mock sysctl.filter(key).stdout
        """
        sysctl_mock = dict(
            # Virtualisation role & type
            kern_vm_guest='',
            hw_hv_vendor='',

            # Virtualisation technology
            hw_model='',
        )

        if key in sysctl_mock:
            return sysctl_mock[key]
        else:
            raise ValueError('Unsupported key %s' % key)


# Generated at 2022-06-11 05:34:23.796095
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:34:25.541830
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert FreeBSDVirtual is fvc._fact_class
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:29.137647
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Constructor of FreeBSDVirtualCollector class.
    '''
    facter_ins = FreeBSDVirtualCollector()
    assert facter_ins._platform == 'FreeBSD'
    assert facter_ins._fact_class == FreeBSDVirtual



# Generated at 2022-06-11 05:34:55.117926
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert(virtual_facts.platform == 'FreeBSD')
    assert(virtual_facts.fact_class == FreeBSDVirtual)

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:34:57.212206
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:34:58.983739
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:35:08.643709
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    result = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set()
    }

    virtual_facts = FreeBSDVirtual()
    virtual_facts.platform = 'FreeBSD'
    virtual_facts.sysctl_data = [{
        'kern.vm_guest': 'none',
        'hw.hv_vendor': 'None',
        'security.jail.jailed': '0',
        'hw.model': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz'
    }]
    result.update(virtual_facts.get_virtual_facts())


# Generated at 2022-06-11 05:35:17.858997
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.bsd import Virtual
    freebsd_virtual_facts = Virtual().get_virtual_facts()

    test_virtual_facts = {}
    test_virtual_facts['virtualization_role'] = ''
    test_virtual_facts['virtualization_type'] = ''
    test_virtual_facts['virtualization_tech_guest'] = set()
    test_virtual_facts['virtualization_tech_host'] = set()

    if os.path.exists('/dev/xen/xenstore'):
        test_virtual_facts['virtualization_role'] = 'guest'
        test_virtual_facts['virtualization_type'] = 'xen'

    return test_virtual_facts

# Generated at 2022-06-11 05:35:22.523937
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    ret = virtual_facts.get_virtual_facts()
    assert isinstance(ret, dict)
    assert 'virtualization_type' in ret
    assert 'virtualization_role' in ret
    assert 'virtualization_tech_guest' in ret
    assert 'virtualization_tech_host' in ret

# Generated at 2022-06-11 05:35:25.713184
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsdvcs = FreeBSDVirtualCollector()
    assert bsdvcs.platform == 'FreeBSD'
    assert bsdvcs._fact_class == FreeBSDVirtual

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 05:35:27.944297
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c._platform == 'FreeBSD'

# Unit test the method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:35:30.085173
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:33.748332
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:36:30.417913
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_facts = FreeBSDVirtual({})
    host_facts_result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert host_facts.get_virtual_facts() == host_facts_result

# Generated at 2022-06-11 05:36:32.054639
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:41.566796
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    _ = ({
        'virtualization_type': '',
        'virtualization_role': ''
    })

    def _run(kern_vm_guest, hw_hv_vendor, sec_jail_jailed, hw_model, expected):
        _ = ({
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()
        })

        v = FreeBSDVirtual()
        v.detect_virt_product = lambda sysctl_key: {
            'kern.vm_guest': kern_vm_guest,
            'hw.hv_vendor': hw_hv_vendor,
            'security.jail.jailed': sec_jail_jailed,
        }[sysctl_key]
        v.detect_virt_v

# Generated at 2022-06-11 05:36:50.232706
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Setup module
    module = ansible.module_utils.facts.virtual.FreeBSDVirtual({})
    # Setup facts
    facts = dict(
        virtualization_type='',
        virtualization_role='',
    )

    # Setup mocks
    mock_detect_virt_product = unittest.mock.Mock()
    module.detect_virt_product = mock_detect_virt_product
    mock_detect_virt_product.return_value = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set()
    )

    # Test with empty host

# Generated at 2022-06-11 05:36:51.915591
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    # TODO: Write facts collection unit test
    pass

# Generated at 2022-06-11 05:36:53.348738
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert isinstance(facts.fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:37:01.925878
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This can be used for testing the get_virtual_facts method of
    # a FreeBSDVirtual object. The FreeBSDVirtual object is created
    # with an argument of None, to satisfy the parent class requirements.
    #
    # To run unit tests type:
    # > python -m test.unit.module_utils.facts.virtual.freebsd_virtual
    #
    # To run a specific unit test type:
    # > python -m test.unit.module_utils.facts.virtual.freebsd_virtual test_FreeBSDVirtual_get_virtual_facts

    test_facts = FreeBSDVirtual(None)
    test_results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

   

# Generated at 2022-06-11 05:37:04.199465
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_collector = FreeBSDVirtualCollector()
    assert bsd_collector._fact_class == FreeBSDVirtual
    assert bsd_collector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:37:09.764836
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual_obj = FreeBSDVirtual(None, None)

    # Define a mock for method detect_virt_product
    def mock_detect_virt_product(sysctl):
        if sysctl == 'security.jail.jailed':
            return {'virtualization_tech_guest': set(['bsd_jail']), 'virtualization_tech_host': set(['bsd_jail']), 'virtualization_type': 'bsd_jail', 'virtualization_role': 'guest'}
        elif sysctl == 'hw.hv_vendor':
            return {'virtualization_tech_guest': set(['vbox']), 'virtualization_tech_host': set([]), 'virtualization_type': 'vbox', 'virtualization_role': 'guest'}

# Generated at 2022-06-11 05:37:11.888386
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual(None).get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:38:39.053986
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    facts = v.get_virtual_facts()
    assert not facts


# Generated at 2022-06-11 05:38:42.065108
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:43.497227
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Unit test constructor of class FreeBSDVirtualCollector'''
    facts = FreeBSDVirtualCollector.collect()
    assert True

# Generated at 2022-06-11 05:38:45.980903
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fc = FreeBSDVirtualCollector()
    assert fc._platform == FreeBSDVirtualCollector._platform
    assert fc._fact_class == FreeBSDVirtualCollector._fact_class

# Generated at 2022-06-11 05:38:46.531012
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:38:54.989622
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from unittest.mock import MagicMock

    # We need to patch method 'get_file_content'
    FreeBSDVirtual.get_file_content = MagicMock(return_value='')
    FreeBSDVirtual._parse_version = MagicMock(return_value='')

    # Mock attribute that is otherwise set by platform.py
    FreeBSDVirtual.platform = 'FreeBSD'

    # Prepare an instance of FreeBSDVirtual
    obj = FreeBSDVirtual()

    actual_virtual_facts = obj.get_virtual_facts()

    expected_virtual_facts = {'virtualization_type': '',
                              'virtualization_role': '',
                              'virtualization_tech_guest': set(),
                              'virtualization_tech_host': set()}

    assert actually_virtual_facts == expected_virtual_facts

# Generated at 2022-06-11 05:38:56.659277
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(bsd_virtual_collector, VirtualCollector)

# Generated at 2022-06-11 05:39:05.940326
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Patch AnsibleModule (class imported by VirtualCollector)
    # in order to mock it's constructor.
    # The return value of the mock will be assigned to the virtual_facts variable
    # when a VirtualCollector object is created.
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import virtual
    from mock import patch

    _virtual_facts = {}

    def _mock_init(self, argument_spec, bypass_checks=False, no_log=False,
                   check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                   required_one_of=None, add_file_common_args=False, supports_check_mode=False,
                   required_if=None, required_by=None):
        return


# Generated at 2022-06-11 05:39:08.208178
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:10.110139
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:40:43.226542
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test for virtual FreeBSD virtualization collector
    """
    facts_collector = FreeBSDVirtualCollector()
    assert hasattr(facts_collector, "_fact_class")
    assert facts_collector._fact_class == FreeBSDVirtual
    assert hasattr(facts_collector, "_platform")
    assert facts_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:40:47.416689
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    data = {
        'ansible_facts': {
            'virtualization_role': 'guest',
            'virtualization_type': 'xen',
            'virtualization_tech_host': ['xen_hypervisor'],
            'virtualization_tech_guest': ['xen_domU']
        }
    }
    FreeBSDVirtualCollector().populate()
    assert data.items() <= FreeBSDVirtualCollector().data.items()

# Generated at 2022-06-11 05:40:48.604843
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:40:50.165232
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:40:51.859314
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:41:00.727718
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual import freebsd as freebsd_virtual

    # The results of these tests are compared to the output of facter
    # In order to ensure the consistency of the tests, the following
    # environment variable is set
    os.environ['LANG'] = 'C'
    ###################################################################
    # Test 1: FreeBSD host running in Jails (virtualization_role = host)
    ###################################################################
    # Set environment variable
    os.environ['ANSIBLE_FREEBSD_JAIL_1'] = '1'

# Generated at 2022-06-11 05:41:05.061260
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_tech_host'] == set()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:41:06.927132
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == "FreeBSD"
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:41:16.298004
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test case 1 - kern.vm_guest.product=BHYVE
    virtual_facts = {
        'virtualization_type': 'bhyve',
        'virtualization_tech_guest': set(['bhyve']),
        'virtualization_tech_host': set(['bhyve']),
        'virtualization_role': 'guest'
    }
    assert(FreeBSDVirtual({}).get_virtual_facts() == virtual_facts)

    # Test case 2 - hw.hv_vendor.product=BHYVE