

# Generated at 2022-06-11 05:31:31.522044
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys

    if sys.version_info.major == 2:
        import mock
        import __builtin__ as builtins  # pylint: disable=import-error

    else:
        import unittest.mock as mock
        import builtins

    my_freebsd_virtual_facts = FreeBSDVirtual()

    def my_mock_os_path_exists(path_string):
        return os.path.exists(path_string)

    m_os_path_exists = mock.Mock(side_effect=my_mock_os_path_exists)
    m_get_sysctl = mock.Mock()
    m_get_sysctl_kern = {'vm_guest': 'VM_VKERNEL'}

# Generated at 2022-06-11 05:31:32.458311
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual()
    virtual_facts = freebsd_virtual_facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:31:33.868892
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector._platform == 'FreeBSD'
    assert facts_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:35.357944
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:45.962062
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    import sys
    import tempfile
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    from ansible.module_utils.facts import collector

    # Define some sysctl output (in StringIO objects)

# Generated at 2022-06-11 05:31:49.556081
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    f = FreeBSDVirtual({})
    virtual_facts = f.get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_type'], str)

# Generated at 2022-06-11 05:31:52.690053
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = dict()
    virtual_collector = FreeBSDVirtualCollector(facts_dict, None)

    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:32:00.369843
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = FreeBSDVirtual()
    virtual_facts.data = {
        'sysctl_kern_vm_guest': 'jail',
        'sysctl_hw_hv_vendor': 'bhyve',
        'sysctl_security_jail_jailed': '0',
        'sysctl_hw_model': 'HP ProLiant MicroServer',
    }
    expected = {
        'virtualization_type': 'other',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['jail', 'bhyve']),
        'virtualization_tech_host': set(),
    }
    assert expected == virtual_facts.get_virtual_facts()

# Generated at 2022-06-11 05:32:09.450854
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # call the method get_virtual_facts with no parameter
    # we get back a dictionary
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    # in the dictionary we should have virtualization_type key
    assert 'virtualization_type' in virtual_facts
    # and virtualization_role key
    assert 'virtualization_role' in virtual_facts
    # and virtualization_tech_guest key
    assert 'virtualization_tech_guest' in virtual_facts
    # and virtualization_tech_host key
    assert 'virtualization_tech_host' in virtual_facts
    # the value of virtualization_type should be a string
    assert isinstance(virtual_facts['virtualization_type'], str)
    # the value of virtualization_role should be a string
   

# Generated at 2022-06-11 05:32:13.077234
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': [],
        'virtualization_tech_host': [],
    }
    assert FreeBSDVirtualCollector().collect() == virtual_facts

# Generated at 2022-06-11 05:32:20.998325
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in [
        '',
        'xen',
        'kvm',
        'jail',
        'bhyve',
        'virtualbox',
        'vmware',
        'parallels',
    ]

# Generated at 2022-06-11 05:32:22.289983
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert not virtual_collector._platform

# Generated at 2022-06-11 05:32:31.651103
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    lines_kern_vm_guest = "kern.vm_guest: user\n"
    lines_hw_hv_vendor = "hw.hv_vendor: FreeBSD\n"
    lines_sec_jail_jailed = "security.jail.jailed: 0\n"
    lines_hw_model = "hw.model: Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz\n"

    class MockFreeBSDVirtual(FreeBSDVirtual):
        @staticmethod
        def detect_virt_product(sysctl_name):
            if sysctl_name == 'kern.vm_guest':
                return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(('vmm',))}

# Generated at 2022-06-11 05:32:33.877981
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:41.067722
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Construct a fake module so that we can pass it to FreeBSDVirtual methods
    module = type('', (), {'params': {}})

    # Construct an instance of FreeBSDVirtual
    virtual_obj = FreeBSDVirtual(module)

    # Invoke the get_virtual_facts method of FreeBSDVirtual
    virtual_facts = virtual_obj.get_virtual_facts()

    # Assert that virtualization_tech_guest returns a set
    assert virtual_facts['virtualization_tech_guest']

    # Assert that virtualization_tech_host returns a set
    assert virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:32:43.084152
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c._fact_class(), FreeBSDVirtual)
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:43.968879
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:46.787888
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)


# Generated at 2022-06-11 05:32:48.668927
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:49.237289
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:56.879613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    VirtualCollector.collector = FreeBSDVirtualCollector
    # We don't want to actually make any network calls when unit testing
    VirtualCollector._platform = 'FreeBSD'
    VirtualCollector.collect()

# Generated at 2022-06-11 05:32:58.525057
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj._platform == FreeBSDVirtualCollector._platform

# Generated at 2022-06-11 05:33:03.947155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This unittest is to test the constructor of class FreeBSDVirtualCollector
    """
    fact = FreeBSDVirtualCollector()
    result = fact.collect()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_system' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-11 05:33:13.415889
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class SubFreeBSDVirtual(FreeBSDVirtual):
        def detect_virt_product(self, sysctl_mib):
            return {'virtualization_type': '',
                    'virtualization_role': '',
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}
        def detect_virt_vendor(self, sysctl_mib):
            return {'virtualization_type': '',
                    'virtualization_role': '',
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}
    v = SubFreeBSDVirtual()

# Generated at 2022-06-11 05:33:18.553514
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual({}, {})
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:33:21.159763
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._fact_class.platform == 'FreeBSD'
    assert collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:23.471974
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:32.104925
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    frbsd = FreeBSDVirtual()

    frbsd.sysctls = {
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'N/A',
        'security.jail.jailed': '0',
        'hw.model': 'FreeBSD virtual machine',
    }

    expected_facts = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert frbsd.get_virtual_facts() == expected_facts

# Generated at 2022-06-11 05:33:34.227868
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None)._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector(None, None)._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:35.992903
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert isinstance(x._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:33:47.434236
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert FreeBSDVirtual(None).get_virtual_facts() == expected

# Generated at 2022-06-11 05:33:48.662668
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:33:50.867020
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test FreeBSDVirtualCollector's constructor"""
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:53.156750
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc._platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:55.493348
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:58.238045
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_collector = FreeBSDVirtualCollector(None, None)
    freebsd_virtual_object = freebsd_virtual_collector.collect()[0]
    facts_result = freebsd_virtual_object.get_virtual_facts()
    assert 'virtualization_type' in facts_result
    assert 'virtualization_role' in facts_result

# Generated at 2022-06-11 05:34:02.489359
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Setup the class
    virtual = FreeBSDVirtual(module=None)

    # test virtual_facts['virtualization_type']
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'jail'

    # test virtual_facts['virtualization_role']
    assert result['virtualization_role'] == 'guest'


if __name__ == "__main__":
    test_FreeBSDVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:34:04.071268
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test: create object
    fc = FreeBSDVirtualCollector()
    assert isinstance(fc, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:34:06.967494
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:34:11.335552
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test FreeBSDVirtualCollector constructor
    '''
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc,VirtualCollector)
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual
# end of test_FreeBSDVirtualCollector()


# Generated at 2022-06-11 05:34:21.266755
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:34:28.628636
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import __ansible_module__
    facts = {}
    __ansible_module__.params = facts
    __ansible_module__.exit_json = lambda: False
    __ansible_module__.fail_json = lambda: False

    virtual_facts_test = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
    }

    file_path = os.path.dirname(os.path.realpath(__file__))
    data_dir = os.path.join(file_path, '..', '..', 'unit', 'data', 'facts', 'virtual')
    data_dir = os.path.abspath(data_dir)

    #sysctl_kern_vm_guest = os.path.join(data

# Generated at 2022-06-11 05:34:34.755472
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_collector = FreeBSDVirtualCollector()
    virtual_facts = virtual_collector.collect()

    # Simple sanity tests
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:34:37.426261
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual
    assert obj.custom_virtual_facts == []

# Generated at 2022-06-11 05:34:46.401875
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    F = FreeBSDVirtual()

    # Virtualization technologies: virtualbox, vmware, linux_vserver, lxc
    # Virtualization roles: guest, host

    model = b'scaleway Z1-30 (Bionic Beaver)'
    model_facts = {'virtualization_type': 'virtualbox',
                   'virtualization_type_role': 'guest'}

    jail = 1
    jail_facts = {'virtualization_type': 'jail',
                  'virtualization_type_role': 'guest'}

    xen = 1
    xen_facts = {'virtualization_type': 'xen',
                 'virtualization_type_role': 'guest'}

    kvm = 1
    kvm_facts = {'virtualization_type': 'kvm',
                 'virtualization_type_role': 'guest'}



# Generated at 2022-06-11 05:34:52.286045
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:34:53.476946
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert VirtualCollector.platforms['FreeBSD'] == FreeBSDVirtualCollector

# Generated at 2022-06-11 05:35:03.702210
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize the FreeBSDVirtual class
    virtual_fbsd_instance = FreeBSDVirtual()

    # Testing using the virtual.py 'product' field in the 'fixtures' subfolder:
    # 'fixtures/virtual.py'. This fixture sets a different virtualization type
    # and role for each test case.

    # Set the test case 'qemu'
    virtual_fbsd_instance.sysctl_product_fields = {
        'kern.vm_guest': 'qemu',
        'hw.hv_vendor': 'none',
        'security.jail.jailed': '0'
    }
    virtual_facts_qemu = virtual_fbsd_instance.get_virtual_facts()
    # Assert the virtualization_type
    assert virtual_facts_qemu['virtualization_type']

# Generated at 2022-06-11 05:35:11.730731
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Delete existing file and create a empty new one
    # to start with a clean file
    open('/tmp/test_virtual', 'w').close()

    # Add a new entry to the file
    entry = 'kern.vm_guest: zfs\n'
    with open('/tmp/test_virtual', 'a') as fp:
        fp.write(entry)

    # Instantiate the class
    fv = FreeBSDVirtual()

    # Set the facter_file as the one we created above
    fv.facter_file = '/tmp/test_virtual'

    # Check the result
    virtual_facts = fv.get_virtual_facts()
    assert {'virt_type': 'zfs', 'virt_type_full': 'zfs/ZFS filesystem', 'virt_what': None} == virtual_facts

# Generated at 2022-06-11 05:35:22.104060
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual.facts_from_cache = dict(
        runner_data=dict(
            sysctl={
                'kern.vm_guest': 'other',
                'hw.hv_vendor': 'FreeBSD',
                'security.jail.jailed': '0',
            },
            host_data=dict(
                ansible_device_links=dict(
                    dev_xen_xenstore='/dev/xen/xenstore'
                )
            )
        )
    )
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_

# Generated at 2022-06-11 05:35:38.668736
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c,VirtualCollector)

# Generated at 2022-06-11 05:35:47.583091
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create FreeBSDVirtual instance
    f = FreeBSDVirtual()

    # pylint: disable=protected-access
    # Get test input data.
    test_inputs = f._read_facts_from_file(
        '../../module_utils/facts/virtual/FreeBSDVirtual/test_inputs.json'
    )
    # Get expected output data.
    test_outputs = f._read_facts_from_file(
        '../../module_utils/facts/virtual/FreeBSDVirtual/test_outputs.json'
    )
    # pylint: enable=protected-access

    # Test FreeBSDVirtual.get_virtual_facts() method
    for test_input, test_expected_output in zip(test_inputs, test_outputs):
        test_output = f.get_virtual_facts(test_input)


# Generated at 2022-06-11 05:35:49.826220
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == "FreeBSD"
    assert collector._fact_class == FreeBSDVirtual
    assert collector._platform == "FreeBSD"

# Generated at 2022-06-11 05:35:51.289076
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd = FreeBSDVirtual()
    bsd.get_virtual_facts()

# Generated at 2022-06-11 05:35:53.401068
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector is not None


# Generated at 2022-06-11 05:35:55.769315
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform is 'FreeBSD'
    assert result._fact_class is FreeBSDVirtual


# Generated at 2022-06-11 05:35:58.623571
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:08.976636
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual()

    # Set the sysctl kern.vm_guest
    fbsd_virtual.sysctl = {'kern.vm_guest': 'vmware'}
    virtual_facts = fbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'

    # Set the sysctl security.jail.jailed
    fbsd_virtual.sysctl = {'security.jail.jailed': 1}
    virtual_facts = fbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'jail'

    # Set the sysctl hw.hv_vendor
    fbsd_virtual.sysctl = {'hw.hv_vendor': 'KVM'}


# Generated at 2022-06-11 05:36:13.150623
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])

# Generated at 2022-06-11 05:36:18.440235
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
    }
    test_virtual = FreeBSDVirtual(module=None)
    virtual_facts = test_virtual.get_virtual_facts()
    assert virtual_facts == virt_facts

# Generated at 2022-06-11 05:37:06.248011
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    import shutil

    os_type = os.uname()[0]
    os_version = os.uname()[2]

    if not os_type == 'FreeBSD':
        return 'Skip test because we are not on FreeBSD system'

    # Pretend to be a XEN guest
    if not os.path.exists('/dev/xen'):
        os.mkdir('/dev/xen')
    if not os.path.exists('/dev/xen/xenstore'):
        os.mkfifo('/dev/xen/xenstore')

# Generated at 2022-06-11 05:37:08.408773
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual({})
    assert vf.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-11 05:37:14.050724
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    guest_tech_expected = set()
    host_tech_expected = {'hypervisor'}

    assert len(guest_tech_expected | virtual_facts['virtualization_tech_guest']) == len(guest_tech_expected)
    assert len(host_tech_expected | virtual_facts['virtualization_tech_host']) == len(host_tech_expected)

# Generated at 2022-06-11 05:37:16.072433
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_collector = FreeBSDVirtualCollector()
    assert freebsd_collector._platform == 'FreeBSD'
    assert freebsd_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:17.147015
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-11 05:37:19.060052
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == FreeBSDVirtualCollector._platform
    assert fv.fact_class == FreeBSDVirtualCollector._fact_class

# Generated at 2022-06-11 05:37:19.621870
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:37:23.665620
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Call FreeBSDVirtualCollector with argument ''
    # FreeBSDVirtualCollector() should be instance of FreeBSDVirtualCollector
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)
    # VirtualCollector.__init__('') is called
    # VirtualCollector.__init__() should be called with argument 'FreeBSD'
    assert VirtualCollector.__init__.call_args[0][0] == 'FreeBSD'

# Generated at 2022-06-11 05:37:25.973445
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert isinstance(collector, VirtualCollector)


# Generated at 2022-06-11 05:37:34.359937
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    result_no_vm = {
        "virtualization_role": "",
        "virtualization_type": "",
        "virtualization_tech_host": [],
        "virtualization_tech_guest": []
    }
    assert FreeBSDVirtual().get_virtual_facts() == result_no_vm

    result_no_vm = {
        "virtualization_role": "guest",
        "virtualization_type": "xen",
        "virtualization_tech_host": [],
        "virtualization_tech_guest": ['xen']
    }
    facts_xen_guest = FreeBSDVirtual()
    facts_xen_guest.file_exists_results['/dev/xen/xenstore'] = True
    assert facts_xen_guest.get_virtual_facts() == result_no

# Generated at 2022-06-11 05:39:20.892268
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert virtual_facts_collector is not None
    assert virtual_facts_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:39:23.506046
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_collector = FreeBSDVirtualCollector()
    assert freebsd_collector._fact_class == FreeBSDVirtual
    assert freebsd_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:27.347820
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create an instance of FreeBSDVirtual class
    freebsd_virtual = FreeBSDVirtual()

    # Set a boolean variable to False
    freebsd_virtual.is_jail = False

    # We expect this to return an empty dictionary
    assert freebsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:39:28.481608
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    p = FreeBSDVirtualCollector()
    assert p._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:39:31.273097
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_obj = FreeBSDVirtualCollector()
    assert virtual_collector_obj._fact_class is not None
    assert virtual_collector_obj._fact_class.platform == 'FreeBSD'
    assert virtual_collector_obj._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:33.600992
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class.platform == 'FreeBSD'
    assert isinstance(f._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-11 05:39:35.221587
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:39:37.666298
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Check for class constructor"""
    my_obj = FreeBSDVirtualCollector()
    my_obj.collect()
    assert my_obj.platform == 'FreeBSD'
    assert my_obj._fact_class == 'FreeBSDVirtual'

# Generated at 2022-06-11 05:39:42.321364
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    fixture_file = os.path.join(fixtures_path, 'freebsd_virtual_facts.txt')
    with open(fixture_file, 'r') as fd:
        facts = FreeBSDVirtual().get_virtual_facts()
        lines = fd.readlines()
        for line in lines:
            key = line.split(':')[0]
            assert facts[key] == line.split(':')[1].strip()

# Generated at 2022-06-11 05:39:43.608855
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual