

# Generated at 2022-06-11 05:31:33.106900
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts import ModuleFacts

    class MockSysModule:
        def __init__(self, kern_vm_guest, hw_hv_vendor, sec_jail_jailed, hw_model):
            self.kern_vm_guest = kern_vm_guest
            self.hw_hv_vendor = hw_hv_vendor
            self.sec_jail_jailed = sec_jail_jailed
            self.hw_model = hw_model


# Generated at 2022-06-11 05:31:33.663309
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:39.763749
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import unittest
    import mock

    class FakeModule(object):
        def fail_json(self, *args, **kwargs):
            raise Exception(kwargs['msg'])

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

    virtual = FreeBSDVirtual(FakeModule())

    # not virtual
    with mock.patch.object(virtual, 'run_command') as run_command:
        run_command.return_value = (1, '1', None)
        virtual_facts = virtual.get_virtual_facts()
        assert set(virtual_facts.keys()) == set(['virtualization_type',
                                                 'virtualization_role',
                                                 'virtualization_tech_guest',
                                                 'virtualization_tech_host'])

# Generated at 2022-06-11 05:31:43.258381
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)
    assert isinstance(fvc._facts, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:45.802621
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector({})
    assert isinstance(virtual, VirtualCollector)
    assert isinstance(virtual, FreeBSDVirtual)

# Generated at 2022-06-11 05:31:48.023812
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None)._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector(None, None)._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:56.429841
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts,\
        "Missing 'virtualization_type' fact in virtual_facts"
    assert 'virtualization_role' in virtual_facts,\
        "Missing 'virtualization_role' fact in virtual_facts"
    assert 'virtualization_tech_guest' in virtual_facts,\
        "Missing 'virtualization_tech_guest' fact in virtual_facts"
    assert 'virtualization_tech_host' in virtual_facts,\
        "Missing 'virtualization_tech_host' fact in virtual_facts"

# Generated at 2022-06-11 05:31:57.287172
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    VirtualCollector()

# Generated at 2022-06-11 05:31:58.775235
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Creating object of base class
    vc = FreeBSDVirtualCollector('bsd_virtual')


# Generated at 2022-06-11 05:32:03.035351
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test object.
    freebsd = FreeBSDVirtual(module=None)

    # Virtualization facts
    virtual_facts = freebsd.get_virtual_facts()
    # Test virtualization related fact keys.
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:32:09.971409
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_object = FreeBSDVirtual()
    result = test_object.get_virtual_facts()
    print('result: {0}'.format(result))



# Generated at 2022-06-11 05:32:11.336663
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:17.700952
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_collector = FreeBSDVirtualCollector()
    assert isinstance(fv_collector._fact_class, FreeBSDVirtual)
    assert fv_collector._platform == 'FreeBSD'

if __name__ == '__main__':
    # Unit test for FreeBSDVirtual
    fv = FreeBSDVirtual()
    virtual_facts = fv.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-11 05:32:20.225508
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Get instance of FreeBSDVirtual
    bsd_virtual = FreeBSDVirtual()
    facts = bsd_virtual.get_virtual_facts()
    assert facts is not None

# Generated at 2022-06-11 05:32:23.835009
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import sys
    f = FreeBSDVirtualCollector(sys.modules[__name__])
    assert f.__class__.__name__ == 'FreeBSDVirtualCollector'
    assert f._fact_class.__name__ == 'FreeBSDVirtual'
    assert f._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:25.812404
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_collector = FreeBSDVirtualCollector()
    assert facts_collector._platform == 'FreeBSD'
    assert facts_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:35.844767
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    This test verifies that get_virtual_facts() of FreeBSDVirtual
    class returns correct values for known FreeBSD virtual instances.
    """
    import os
    import tempfile
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Save original value of detect_virt_product
    original_detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product

    # Make sure that detect_virt_product returns known values
    def fake_detect_virt_product(*args, **kwargs):
        return {'virtualization_tech_host': set(),
                'virtualization_tech_guest': {'jail'},
                'virtualization_type': 'jail',
                'virtualization_role': 'guest'}

    VirtualSysctlDetectionMix

# Generated at 2022-06-11 05:32:38.067986
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert isinstance(collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:32:39.559109
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:32:40.178693
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:50.052268
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj is not None

# Generated at 2022-06-11 05:32:52.797318
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test the constructor of class FreeBSDVirtualCollector
    '''

    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:55.480288
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:07.361318
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """This will test the get_virtual_facts method of class FreeBSDVirtual
    """
    # To test the functioning of get_virtual_facts, we need FreeBSD-specific
    # data to be returned by detect_virt_product. Hence, we are using a
    # subclass of FreeBSDVirtual, which overrides detect_virt_product

# Generated at 2022-06-11 05:33:08.387410
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c, VirtualCollector)

# Generated at 2022-06-11 05:33:10.356265
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:15.618639
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = FreeBSDVirtual()
    expected_results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),

    }
    assert vf.get_virtual_facts() == expected_results, \
           "Unexpected results for get_virtual_facts"

# Generated at 2022-06-11 05:33:26.056434
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    with open('/proc/cpuinfo') as cpuinfo:
        data = cpuinfo.read()

    virtual = FreeBSDVirtual({'ansible_facts': {'data': data}})
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == '', "virtualization_type should be ''"
    assert result['virtualization_role'] == '', "virtualization_role should be ''"
    assert len(result['virtualization_tech_guest']) == 0, "virtualization_tech_guest should be of length 0"
    assert len(result['virtualization_tech_host']) == 0, "virtualization_tech_host should be of length 0"


# Generated at 2022-06-11 05:33:28.159243
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert virtual_facts_collector is not None

# Generated at 2022-06-11 05:33:33.566089
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    mocked_module = type('module', (object,), {})
    mocked_module.params = {}
    virt = FreeBSDVirtual(mocked_module)
    virt._module = mocked_module
    facts = virt.get_virtual_facts()
    assert type(facts) is dict
    assert type(facts['virtualization_tech_host']) is set
    assert type(facts['virtualization_tech_guest']) is set

# Generated at 2022-06-11 05:33:52.922948
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector().get_all_facts(), dict)


# Generated at 2022-06-11 05:33:56.850259
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.data == {}
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

test_FreeBSDVirtualCollector()

__all__ = [
    'FreeBSDVirtualCollector'
]

# Generated at 2022-06-11 05:33:59.392844
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None).collect()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 05:34:08.238581
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:34:13.470595
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    This test is only for constructor of class FreeBSDVirtualCollector.
    It checks if the object (dummy) is created as expected.
    """
    # Create FreeBSDVirtualCollector object for test.
    dummy = FreeBSDVirtualCollector()
    # Check if the object (dummy) is created as expected.
    assert dummy._platform == 'FreeBSD'
    assert dummy._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:16.308699
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == 'FreeBSD'

if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:34:20.152137
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f,VirtualCollector)
    assert isinstance(f,FreeBSDVirtualCollector)
    assert f._platform == 'FreeBSD'
    assert f._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:34:23.865294
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual()
    virt_facts.populate_virtual_facts()
    virtual_facts = virt_facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:34:25.886299
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:30.783196
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector('fake_data')
    assert obj.virtual_facts['virtualization_type'] == ''
    assert obj.virtual_facts['virtualization_role'] == ''
    assert obj.virtual_facts['virtualization_tech_guest'] == set()
    assert obj.virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:35:18.052217
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:28.424281
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual = FreeBSDVirtual()
    result_sysctl_kern_vm_guest = set(['linux-kvm'])
    result_sysctl_hw_hv_vendor = set([])
    result_sysctl_sec_jail_jailed = set(['jail'])
    result_virtual_vendor_facts = set(['virtualbox'])
    result_guest_tech = set(['linux-kvm', 'jail', 'virtualbox'])
    result_host_tech = set(['linux-kvm', 'virtualbox'])

    assert result_sysctl_kern_vm_guest \
        == bsd_virtual.detect_virt_product('kern.vm_guest')['virtualization_tech_guest']
    assert result_sysctl_hw_hv_

# Generated at 2022-06-11 05:35:32.602620
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = VirtualCollector().get_virtual_facts()

    assert len(virtual_facts) > 0
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:35:36.508740
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Check for some keys in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    # Check for expected values
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:35:38.550633
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # test constructor of FreeBSDVirtual
    obj = FreeBSDVirtualCollector()
    assert hasattr(obj, '_fact_class')
    assert obj._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:41.405043
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-11 05:35:50.675221
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:35:52.280725
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.get_virtual_facts()


# Generated at 2022-06-11 05:36:02.689546
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class FakeVirtual(FreeBSDVirtual):
        def detect_virt_product(self, node):
            if node == 'kern.vm_guest':
                return {
                    'virtualization_tech_guest': {'kvm'},
                    'virtualization_tech_host': set(),
                }
            elif node == 'hw.hv_vendor':
                return {
                    'virtualization_tech_guest': {'openvz'},
                    'virtualization_tech_host': {'openvz'},
                }
            elif node == 'security.jail.jailed':
                return {
                    'virtualization_tech_guest': {'jail'},
                    'virtualization_tech_host': set(),
                }

# Generated at 2022-06-11 05:36:06.665738
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts._fact_class is not None
    instance = virtual_facts._fact_class()
    assert isinstance(instance, FreeBSDVirtual)
    assert instance.platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:48.150958
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)
    assert isinstance(obj._fact_class, type(FreeBSDVirtualCollector._fact_class))
    assert obj._platform == 'FreeBSD'



# Generated at 2022-06-11 05:38:56.319170
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Prepare the mock of `get_file_content` method
    class MockModuleUtils(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_file_content(self, file_path, raw=True):
            # If the file is hw.model
            if file_path == '/var/run/dmesg.boot':
                return "FreeBSD/amd64 (...)\nFreeBSD/amd64 (...)\nFreeBSD/amd64 (...)\n" \
                       "FreeBSD/amd64 (...)\nFreeBSD/amd64 (...)\n"
            # If the file is kern.vm_guest

# Generated at 2022-06-11 05:38:57.603401
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None, None)._platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:59.211612
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_collector = FreeBSDVirtualCollector()
    assert isinstance(fv_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:39:01.591361
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:02.159268
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:39:06.060553
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ''' test constructor of FreeBSDVirtualCollector class '''
    frbsdc = FreeBSDVirtualCollector()
    assert frbsdc.platform == 'FreeBSD'
    assert frbsdc._fact_class == FreeBSDVirtual
    assert frbsdc._platform == 'FreeBSD'
    assert frbsdc.collect() == {}

# Generated at 2022-06-11 05:39:07.934970
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:39:11.256023
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Make a FreeBSDVirtualCollector object,
    and make sure it has the correct class'''
    # pylint: disable=protected-access
    fvc = FreeBSDVirtualCollector()
    assert fvc.__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-11 05:39:13.332155
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtual)
    assert isinstance(obj.collect(), FreeBSDVirtual)