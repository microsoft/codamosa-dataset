

# Generated at 2022-06-11 05:31:24.916832
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    _facts = FreeBSDVirtual({}, {}, {}).get_virtual_facts()
    assert 'virtualization_type' in _facts
    assert 'virtualization_role' in _facts
    assert 'virtualization_tech_guest' in _facts
    assert 'virtualization_tech_host' in _facts

# Generated at 2022-06-11 05:31:29.023222
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsdv = FreeBSDVirtual()
    # Only set sysctl values when they are correctly detected
    fbsdv.supported_sysctl_virt_facts = {'kern.vm_guest': 'xen',
                                         'hw.hv_vendor': 'bhyve',
                                         'security.jail.jailed': 'jail'}
    assert fbsdv.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['xen']),
    }
    # If a BSD is running in a FreeBSD jail, virtualization_type is 'jail'.

# Generated at 2022-06-11 05:31:35.298747
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Initialize FreeBSDVirtualCollector instance
    freebsd_virtual_collector = FreeBSDVirtualCollector()

    # Get virtual facts
    virtual_facts = freebsd_virtual_collector.get_virtual_facts()

    # Assert FreeBSDVirtualCollector instance
    assert(isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector))

    # Assert virtualization_tech_guest property
    assert(virtual_facts['virtualization_tech_guest'] == set(['vbox']))

# Generated at 2022-06-11 05:31:38.787771
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:31:40.170448
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:31:43.256875
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert isinstance(vc._fact_class(vc._platform), FreeBSDVirtual)

# Generated at 2022-06-11 05:31:45.079306
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:48.445385
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert virtual_facts_collector.platform == 'FreeBSD'
    assert virtual_facts_collector._fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:50.434467
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    VirtualCollector._init_test(FreeBSDVirtualCollector, 'FreeBSD')


# Generated at 2022-06-11 05:31:51.033397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:59.026754
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()

    # check the instance of class
    assert isinstance(fv, FreeBSDVirtualCollector)

    # check the platform.
    assert fv.platform == 'FreeBSD'

    # check the fact_class
    assert fv._fact_class == FreeBSDVirtual


if __name__ == '__main__':
    test_FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:00.370078
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:01.580548
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:10.800311
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:32:21.032358
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}
    host_tech.add('xen')
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    kern_vm_guest = {'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    hw_hv_vendor = {'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}
    sec_jail_jailed = {'virtualization_tech_guest': set(),
                       'virtualization_tech_host': set()}
    guest_tech.update(kern_vm_guest['virtualization_tech_guest'])
    host

# Generated at 2022-06-11 05:32:22.263843
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:23.132149
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:23.937135
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test constructor
    assert FreeBSDVirtualCollector(None);

# Generated at 2022-06-11 05:32:29.956187
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up the class we are testing
    fbsd_virtual = FreeBSDVirtual()
    output = fbsd_virtual.get_virtual_facts()

    # Test that the method returns a dict
    assert isinstance(output, dict)

    # Test that the dict has the correct keys
    required_keys = ['virtualization_type', 'virtualization_role',
                     'virtualization_tech_guest', 'virtualization_tech_host']
    for key in required_keys:
        assert key in output


# Generated at 2022-06-11 05:32:31.830718
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'



# Generated at 2022-06-11 05:32:45.134635
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import json
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils import modules
    import pytest

    test_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data')
    test_data_file = 'FreeBSDVirtual_get_virtual_facts.json'
    test_data_path = os.path.join(test_data_dir, test_data_file)
    with open(test_data_path, "r") as test_data_file_obj:
        test_data = json.load(test_data_file_obj)

    for test_case in test_data:
        test_case_id = test_case['id']
        test_case_hwinfo = test_

# Generated at 2022-06-11 05:32:46.542121
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, VirtualCollector)

# Generated at 2022-06-11 05:32:47.294793
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:32:58.694393
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()

    facts['kernel'] = 'FreeBSD'
    facts['os_family'] = 'FreeBSD'

    kern_vm_guest = None
    hw_hv_vendor = None
    hw_model = None
    security_jail_jailed = None

    results = dict()

    expected_results = dict()
    expected_results['virtualization_type'] = ''
    expected_results['virtualization_role'] = ''
    expected_results['virtualization_tech_host'] = set()
    expected_results['virtualization_tech_guest'] = set()

    # test no virtualization
    kern_vm_guest = dict(kern_vm_guest='none')
    hw_hv_vendor = dict(hw_hv_vendor='')
    h

# Generated at 2022-06-11 05:33:07.255724
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual()

    # Call method get_virtual_facts
    virtual_facts = freebsd_virtual.get_virtual_facts()

    # Assert expected results
    assert virtual_facts['virtualization_type'] in ('xen', '')
    assert virtual_facts['virtualization_role'] in ('guest', '')
    assert virtual_facts['virtualization_tech_guest'] in (set(), set(['xen']))
    assert virtual_facts['virtualization_tech_host'] in (set(), set(['xen']))

# Generated at 2022-06-11 05:33:15.419916
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    import os
    import errno
    fname = '/tmp/ansible_test_FreeBSDVirtual'
    data = """
hw.model: VirtualBox
hw.machine: amd64
hw.machine_arch: amd64
kern.vm_guest: none
security.jail.jailed: 0
"""
    os.makedirs('/tmp', exist_ok=True)

# Generated at 2022-06-11 05:33:26.256343
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # pylint: disable=import-error, no-name-in-module, unused-variable
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    import ansible.module_utils.facts.virtual.freebsd

    # pylint: disable=attribute-defined-outside-init
    class MockFreeBSDVirtual(FreeBSDVirtual):
        def __init__(self, module):
            self.module = module

        def detect_virt_product(self, sysctl_key):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

        def detect_virt_vendor(self, sysctl_key):
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-11 05:33:29.168438
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:33:30.960756
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector(None).collect()
    assert virtual_facts is not None

# Generated at 2022-06-11 05:33:34.066899
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv_collector = FreeBSDVirtualCollector()
    assert fv_collector._platform == 'FreeBSD'
    assert fv_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:33:42.042385
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''Check that FreeBSDVirtualCollector() create an instance of VirtualCollector
    '''
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, VirtualCollector)


# Generated at 2022-06-11 05:33:43.803051
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:44.404806
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:48.662790
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Code to test constructor of class FreeBSDVirtualCollector
    '''
    fake_os_platform = 'FreeBSD'
    fvc = FreeBSDVirtualCollector(fake_os_platform)
    assert fvc.platform == "FreeBSD"
    assert fvc.fact_class._platform == "FreeBSD"


# Generated at 2022-06-11 05:33:50.437003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Void test. Just to avoid pylint complains.
    fb = FreeBSDVirtualCollector()
    print(fb)

# Generated at 2022-06-11 05:33:52.016261
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-11 05:34:01.240611
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class my_platform(object):
        platform = 'FreeBSD'

    class my_virtual(FreeBSDVirtual, my_platform):
        def detect_virt_product(self, product, name, module=None, sysctl=None):
            if name == 'hw.model':
                if module == 'xen':
                    return {
                        'virtualization_type': 'xen',
                        'virtualization_role': 'guest'
                    }
                if product == 'kern.vm_guest':
                    return {
                        'virtualization_tech_guest': set(),
                        'virtualization_tech_host': set()
                    }
                elif product == 'hw.hv_vendor':
                    return {
                        'virtualization_tech_guest': set(),
                        'virtualization_tech_host': set()
                    }


# Generated at 2022-06-11 05:34:03.400764
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:13.151781
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtualization_type = 'virtualbox'
    virtualization_role = 'host'
    virtual_facts = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set()
    }

    f = FreeBSDVirtual({'ansible_facts': virtual_facts})
    f.get_virtual_facts()

    assert f._facts['virtualization_type'] == virtualization_type
    assert f._facts['virtualization_role'] == virtualization_role
    assert 'vmware' in f._facts['virtualization_tech_host']
    assert 'virtualbox' in f._facts['virtualization_tech_host']
    assert 'parallels' in f._facts['virtualization_tech_host']

# Generated at 2022-06-11 05:34:23.989938
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_freebsd = FreeBSDVirtual()
    test_freebsd.collect_sysctl_product_info = lambda: {
        'kern.vm_guest': 'other',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': 0
    }

    test_freebsd.collect_sysctl_vendor_info = lambda: {'hw.model': 'bhyve'}

    test_freebsd.get_virtual_facts()

    assert test_freebsd.virtual_facts['virtualization_type'] == 'other'
    assert test_freebsd.virtual_facts['virtualization_role'] == 'guest'
    assert test_freebsd.virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:34:34.306933
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Check instance creation
    fact_obj = FreeBSDVirtualCollector()
    assert fact_obj
    assert isinstance(fact_obj, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:34:36.974441
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector_class = FreeBSDVirtualCollector
    assert collector_class._fact_class == FreeBSDVirtual
    assert collector_class._platform == 'FreeBSD'


# Generated at 2022-06-11 05:34:38.203035
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual.get_virtual_facts()

# Generated at 2022-06-11 05:34:39.884221
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:48.557142
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible_collections.freebsd.facts.plugins.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    import os
    class FreeBSDVirtualTester(FreeBSDVirtual,VirtualSysctlDetectionMixin):
        platform = 'FreeBSD'

# Generated at 2022-06-11 05:34:50.775089
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:00.319834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Test the initial state of the class
    assert hasattr(FreeBSDVirtualCollector, '_fact_class')
    assert hasattr(FreeBSDVirtualCollector, '_platform')
    assert (FreeBSDVirtualCollector._platform == 'FreeBSD')
    assert (FreeBSDVirtualCollector._fact_class == FreeBSDVirtual)
    assert not hasattr(FreeBSDVirtualCollector, '_fact_class_obj')

    # Test the constructor
    test_platform = FreeBSDVirtualCollector()

    assert hasattr(test_platform, '_fact_class')
    assert hasattr(test_platform, '_platform')
    assert (test_platform._platform == 'FreeBSD')
    assert (test_platform._fact_class == FreeBSDVirtual)
    assert (type(test_platform._fact_class_obj) == FreeBSDVirtual)

# Generated at 2022-06-11 05:35:09.522386
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:35:13.677023
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, {})
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert not facts['virtualization_role']
    assert not facts['virtualization_tech_guest']
    assert not facts['virtualization_tech_host']

# Generated at 2022-06-11 05:35:14.769342
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert type(FreeBSDVirtualCollector) == type

# Generated at 2022-06-11 05:35:34.138984
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:35.815205
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bf = FreeBSDVirtualCollector()
    assert bf._platform == 'FreeBSD'
    assert bf._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:37.249060
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x._fact_class == FreeBSDVirtual
    assert x._platform == 'FreeBSD'


# Generated at 2022-06-11 05:35:46.001210
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.detect_virt_product = lambda k: {'virtualization_type': '', 'virtualization_role': ''}
    freebsd_virtual.detect_virt_vendor = lambda k: {'virtualization_type': '', 'virtualization_role': ''}
    freebsd_virtual.sysctl = {}
    freebsd_virtual.sysctl.get_all = lambda: {'hw.model': '', 'security.jail.jailed': '', 'kern.vm_guest': '', 'hw.hv_vendor': ''}
    virtual_facts = freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:35:47.962356
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts.platform == 'FreeBSD'
    assert facts.__class__.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-11 05:35:49.886348
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    sut = FreeBSDVirtualCollector()
    assert sut._platform is not None
    assert sut._fact_class is not None

# Generated at 2022-06-11 05:35:50.679085
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:36:00.451993
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import re
    import sys
    path = os.path.dirname(os.path.realpath(__file__)) + '/test_FreeBSDVirtual_get_virtual_facts.py'
    sys.path.append(path)
    from test_FreeBSDVirtual_get_virtual_facts import TEST_DATA_FreeBSDVirtual
    for data in TEST_DATA_FreeBSDVirtual:
        facts_virtual = FreeBSDVirtual(data['sysname'])
        virtual_facts = facts_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:36:10.817069
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with a clean environment, check that it sets empty defaults
    fbv = FreeBSDVirtual()
    assert fbv.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

    # Test if it detects a FreeBSD jail correctly
    fbv = FreeBSDVirtual()
    fbv.sysctl = {'security.jail.jailed': '1'}

# Generated at 2022-06-11 05:36:15.027887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_class = FreeBSDVirtual({})
    assert fake_class.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_technologies': set(), 'virtualization_tech_guest': set(), 'virtualization_tech_host': set() }


# Generated at 2022-06-11 05:37:22.602091
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, VirtualCollector)
    assert isinstance(fv, FreeBSDVirtualCollector)
    assert fv._platform == 'FreeBSD'
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:37:24.249403
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class.__name__ == 'FreeBSDVirtual'

# Generated at 2022-06-11 05:37:27.682003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtual, Virtual)
    assert issubclass(FreeBSDVirtual, VirtualSysctlDetectionMixin)
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._fact_class is FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:31.554525
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()

    # Should return empty values if FreeNAS isn't running
    freebsd_virtual_facts = {}
    freebsd_virtual_facts['virtualization_type'] = ''
    freebsd_virtual_facts['virtualization_role'] = ''
    assert virtual.get_virtual_facts() == freebsd_virtual_facts

# Generated at 2022-06-11 05:37:32.744403
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert(fv is not None)

# Generated at 2022-06-11 05:37:41.300022
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class TestFreeBSDVirtual(FreeBSDVirtual):
        sysctl_result = {
            '/proc/cpuinfo': '',
            'hw.model': '',
            'hw.hv_vendor': '',
            'hw.hv_vendor_id': '',
            'hw.hv_version': '',
            'kern.vm_guest': '',
            'security.jail.jailed': '',
            'security.jail.host_hostname': '',
        }

    x = TestFreeBSDVirtual()
    assert x.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

    x

# Generated at 2022-06-11 05:37:43.601742
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class is FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:52.643745
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from stat import S_ISCHR
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    assert issubclass(FreeBSDVirtualCollector._fact_class, FreeBSDVirtual)
    # The FreeBSDVirtual class inherits from the Virtual class and from the
    # VirtualSysctlDetectionMixin class
    assert issubclass(FreeBSDVirtual, Virtual)
    assert issubclass(FreeBSDVirtualCollector._fact_class, VirtualSysctlDetectionMixin)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class.platform == 'FreeBSD'
    # Testing _search_string

# Generated at 2022-06-11 05:38:01.538150
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up a dictionary of expected return values.
    expected = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest=set(['xen']),
        virtualization_tech_host=set(['kvm', 'vbox']),
    )
    # Patch FreeBSDVirtual.get_file_contents so it returns pre-canned data.
    FreeBSDVirtual.get_file_contents = lambda self, path: test_data[path]
    v = FreeBSDVirtual()
    assert v.get_virtual_facts() == expected

# The data used to patch in FreeBSDVirtual.get_file_contents

# Generated at 2022-06-11 05:38:02.651337
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector(None, None, None)

# Generated at 2022-06-11 05:40:53.728957
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    my_fact_class = FreeBSDVirtualCollector()
    assert my_fact_class._fact_class == FreeBSDVirtual
    assert my_fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:40:56.136286
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'
    assert freebsd_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:40:58.303848
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:41:07.092030
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_facts = {}
    guest_facts = {}
    guest_facts['virtualization_type'] = 'xen'
    guest_facts['virtualization_role'] = 'guest'
    host_facts['virtualization_type'] = 'xen'
    host_facts['virtualization_role'] = 'host'
    host_facts['virtualization_tech_host'] = ['xen']
    host_facts['virtualization_tech_guest'] = []
    guest_facts['virtualization_tech_guest'] = ['xen']
    guest_facts['virtualization_tech_host'] = []
    if os.path.exists('/dev/xen/xenstore'):
        facts = FreeBSDVirtual(host_facts).get_virtual_facts()
        assert facts == guest_facts

    host_facts = {}
   

# Generated at 2022-06-11 05:41:09.248214
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:41:13.514540
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:41:23.023762
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
        Unit test for method get_virtual_facts of class FreeBSDVirtual
    '''
    # test dictionary of sysctl facts
    sysctl_facts = {
        'hw.model': 'VMWare Virtual Platform',
        'hw.machine': 'amd64',
        'hw.product': 'VMWare Virtual Platform',
        'security.jail.jailed': 0,
        'kern.vm_guest': 'vmware',
        'hw.hv_vendor': 'VMware, Inc.'
    }
    # test dictionary of sysctl facts on jail host