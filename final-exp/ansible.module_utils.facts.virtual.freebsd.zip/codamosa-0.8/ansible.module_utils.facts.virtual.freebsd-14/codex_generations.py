

# Generated at 2022-06-11 05:31:26.886310
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test get_virtual_facts method."""
    virtual_facts = FreeBSDVirtual({}, {}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('', 'xen')
    assert virtual_facts['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-11 05:31:27.949334
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:37.103017
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_module = FreeBSDVirtual()
    test_virtual = test_module.get_virtual_facts()
    if test_module.is_jailed():
        assert test_virtual['virtualization_type'] == 'jail'
        assert test_virtual['virtualization_role'] == 'guest'
        assert 'jail' in test_virtual['virtualization_tech_guest']

    if test_module.is_xen():
        assert test_virtual['virtualization_type'] == 'xen'
        assert test_virtual['virtualization_role'] == 'guest'
        assert 'xen' in test_virtual['virtualization_tech_guest']

    if test_module.is_kvm():
        assert test_virtual['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 05:31:42.786199
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create instance of FreeBSDVirtual and invoke get_virtual_facts method
    freebsd_virtual = FreeBSDVirtual({})
    facts = freebsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-11 05:31:53.683117
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    class MockSysModule(object):
        '''Mock of sys module'''

        def __init__(self):
            self.platform = 'FreeBSD'
            self.real_prefix = '/usr'
            self.prefix = ''

    class MockPopen(object):
        '''Mock of subprocess.Popen'''

        def __init__(self):
            self.returncode = 0
            self.stdout = b'/dev/xen/xenstore'

# Generated at 2022-06-11 05:32:01.687942
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual('FreeBSD')
    virtual.HARDWARE = {'model': 'pcengines apu2'}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'pcengines_apu2'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'pcengines_apu2' in virtual_facts['virtualization_tech_host']

    virtual = FreeBSDVirtual('FreeBSD')
    virtual.HARDWARE = {'model': 'pcengines apu2'}
    virtual.SYSCTL = {
        'security.jail.jailed': 0,
        'hw.hv_vendor': 'BHYVE',
        'kern.vm_guest': 'bhyve'
    }
    virtual_

# Generated at 2022-06-11 05:32:10.935298
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:32:21.124299
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    fact_class = FreeBSDVirtual
    fact_class.detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product
    fact_class.detect_virt_vendor = VirtualSysctlDetectionMixin.detect_virt_vendor

    fake_sysctl_kern_vm_guest = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-11 05:32:22.676653
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsdvirtual = FreeBSDVirtual()
    freebsdvirtual.get_virtual_facts()


# Generated at 2022-06-11 05:32:31.881139
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test FreeBSDVirtual.get_virtual_facts()
    """
    # Base/Generic platform
    platform = VirtualCollector(None, None).__class__.platform
    facts = FreeBSDVirtual(platform).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    # FreeBSD on VMware ESXi
    platform = 'FreeBSD'
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                 }
    virtual_vendor_facts = {'virtualization_type': '',
                            'virtualization_role': '',
                            'virtualization_tech_guest': set(['vmware']),
                            'virtualization_tech_host': set(),
                        }

# Generated at 2022-06-11 05:32:39.760848
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(None)
    virtual.collect()
    assert virtual.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}

# Generated at 2022-06-11 05:32:42.922765
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fd = FreeBSDVirtual({})
    virtual_facts = fd.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:32:45.217731
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:32:46.953705
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj._fact_class(), FreeBSDVirtual)

# Generated at 2022-06-11 05:32:48.204699
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_platform = FreeBSDVirtualCollector.platform
    assert virtual_platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:50.319002
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert not virtual_collector.facts

# Generated at 2022-06-11 05:32:52.287295
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert facts._platform == 'FreeBSD'
    assert facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:04.577411
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import facts
    fact_module = facts.get_facts(module_name='setup')
    fact_module.populate()
    fact_caches = fact_module._fact_cache._fact_caches
    virtual_facts = fact_caches['virtual'].get_virtual_facts()
    assert 'virtual' in virtual_facts
    assert 'role' in virtual_facts
    assert virtual_facts['virtual'].startswith(
        ('fullvirt', 'hvm', 'jail', 'paravirt', 'zone'
        )), 'unexpected virtualization type: %s' % virtual_facts['virtual']
    assert virtual_facts['role'].startswith(
        ('guest', 'host')), 'unexpected virtualization role: %s' % virtual_facts['role']


# Generated at 2022-06-11 05:33:05.231476
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:08.199232
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_get_file_content = lambda x: ""

    virtual_facts = FreeBSDVirtual(None, fake_get_file_content).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:33:13.791332
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:16.026113
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance_of_FreeBSDVirtualCollector = FreeBSDVirtualCollector()
    assert isinstance(instance_of_FreeBSDVirtualCollector, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:33:16.628557
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:27.859450
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_sysctl_data = {}
    import types
    import sys
    import json
    import os
    from ansible.module_utils.facts.virtual.sysctl import (
            VirtualSysctlDetectionMixin, VirtualSysctlDetector)

    class FakeVirtualSysctlDetector(VirtualSysctlDetector):
        # Expose the internal _sysctl_data property so we can set it.
        def set_sysctl_data(self, sysctl_data):
            self._sysctl_data = sysctl_data
        def _get_sysctl_data(self):
            return self._sysctl_data
        def get_sysctl_value(self, key):
            return self._sysctl_data.get(key, None)


# Generated at 2022-06-11 05:33:30.031888
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:32.326518
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert instance.platform == 'FreeBSD'
    assert instance._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:33:37.085303
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt = FreeBSDVirtual()
    virt.module = MockModule()
    facts = virt.get_virtual_facts()
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'


from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-11 05:33:40.957088
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSD_virtual_facts = FreeBSDVirtual({})
    expected_virtual_facts = dict(
        virtualization_type='xen',
        virtualization_role='guest'
    )
    assert expected_virtual_facts == FreeBSD_virtual_facts.get_virtual_facts()

# Generated at 2022-06-11 05:33:45.930948
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:33:55.912427
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    virtual.set_sysctl_path('/sbin/sysctl')
    virtual.set_file_paths('/sbin/sysctl', '/bin/grep', '/bin/cat')
    virtual.collect()
    vs = virtual.get_virtual_facts()
    assert isinstance(vs, dict)
    assert 'virtualization_type' in vs
    assert 'virtualization_role' in vs
    assert 'virtualization_tech_host' in vs
    assert 'virtualization_tech_guest' in vs
    assert isinstance(vs['virtualization_tech_host'], set)
    assert isinstance(vs['virtualization_tech_guest'], set)
    assert len(vs['virtualization_tech_host']) >= 0

# Generated at 2022-06-11 05:34:07.237378
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbv = FreeBSDVirtualCollector()
    assert fbv._fact_class == FreeBSDVirtual
    assert fbv._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:17.710279
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    FreeBSDVirtual.get_virtual_facts() Test
    '''
    ut_facts = {}
    test_virtual = FreeBSDVirtual(ut_facts)

    # Test empty output
    ut_facts = test_virtual.get_virtual_facts()
    assert ut_facts['virtualization_type'] == ''
    assert ut_facts['virtualization_role'] == ''
    assert ut_facts['virtualization_tech_guest'] == set()
    assert ut_facts['virtualization_tech_host'] == set()

    # Test some output
    ut_facts = {
        'kern.vm_guest': 'xen',
        'hw.hv_vendor': 'Xen',
        'security.jail.jailed': '0',
        'hw.model': 'Intel Xeon',
    }
    test_

# Generated at 2022-06-11 05:34:18.278474
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:34:27.176921
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Compatibility testing between get_virtual_facts of class FreeBSDVirtual
    and its superclass Virtual.
    For further details, see:
    http://docs.python-guide.org/en/latest/writing/gotchas/#mutable-default-arguments
    """
    # pylint: disable=protected-access
    import pytest
    from ansible.module_utils.facts.virtual.virtual import Virtual
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from copy import deepcopy

    # Create Virtual object
    virtual = Virtual({})
    # Create FreeBSDVirtual object
    freebsd_virtual = FreeBSDVirtual({})
    # Assert that superclass method get_virtual_facts returns a dictionary
    assert isinstance(virtual.get_virtual_facts(), dict)
    # Assert that subclass method get

# Generated at 2022-06-11 05:34:29.230445
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:40.262815
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts_out = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': ['kvm'],
        'virtualization_tech_host': ['kvm'],
    }

    kern_vm_guest_out = {
        'virtualization_tech_guest': ['kvm'],
        'virtualization_tech_host': ['kvm'],
    }
    hw_hv_vendor_out = {
        'virtualization_tech_guest': ['kvm'],
        'virtualization_tech_host': ['kvm'],
    }

# Generated at 2022-06-11 05:34:45.070757
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Create FreeBsdVirtualCollector instance,
    check its class and name
    '''
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)
    assert obj.__class__.__name__ == 'FreeBSDVirtualCollector'
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:47.852581
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)
    assert isinstance(fvc._fact_class, FreeBSDVirtual)
    assert fvc._platform == 'FreeBSD'


# Generated at 2022-06-11 05:34:50.415884
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_inst = FreeBSDVirtualCollector()
    assert isinstance(virtual_inst, VirtualCollector)
    assert virtual_inst.platform == "FreeBSD"
    assert virtual_inst._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:51.556029
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == "FreeBSD"

# Generated at 2022-06-11 05:35:24.391442
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Test FreeBSDVirtual.get_virtual_facts()."""
    fake_module = type('module', (), {})()
    # When hw.model returns value that includes 'VMware'
    fake_module.get_file_content = lambda x: 'VMware Virtual Platform'
    fake_module.get_mount_size = lambda x: "0"
    facts_instance = FreeBSDVirtual(fake_module)
    virtual_facts = facts_instance.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' not in virtual_facts

# Generated at 2022-06-11 05:35:27.105581
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert (facts['virtualization_type'] == '' and
            facts['virtualization_role'] == '')

# Generated at 2022-06-11 05:35:36.049617
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialise the class object
    obj = FreeBSDVirtual({})

    # set the values for sysctl_param_data
    obj.sysctl_param_data = [
        ('hw.model', 'QEMU Virtual CPU version 2.5+'),
        ('hw.machine', 'amd64'),
        ('security.jail.jailed', '0'),
        ('kern.vm_guest', 'other'),
        ('hw.hv_vendor', 'None'),
        ('hw.cpu_arch', 'amd64'),
        ('hw.physmem', '1610612736'),
    ]

    # create a dictionary for virtual_facts

# Generated at 2022-06-11 05:35:37.728102
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:35:41.891061
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    module_name = 'ansible_test'
    try:
        freebsd_virtual_collector = FreeBSDVirtualCollector(module_name)
    except Exception as e:
        assert False, 'Could not instantiate FreeBSDVirtualCollector: %s' % e
    assert freebsd_virtual_collector is not None, 'Failed to instantiate FreeBSDVirtualCollector'

# Generated at 2022-06-11 05:35:44.413754
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x._fact_class._platform == 'FreeBSD'
    assert isinstance(x._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:35:48.049749
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector, '_platform')
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

    assert hasattr(FreeBSDVirtualCollector, '_fact_class')
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:35:49.302287
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'


# Generated at 2022-06-11 05:35:52.136510
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    _facts = {'system': 'FreeBSD'}
    collector = FreeBSDVirtualCollector(_facts)
    virtual = collector.collect()
    if virtual['system'] != "FreeBSD":
        raise Exception(virtual)

# Generated at 2022-06-11 05:35:57.231308
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Arrange
    from ansible.module_utils.facts import Virtual
    facts = Virtual('qemu:///system')

    # Act
    virtual_facts = facts.get_virtual_facts()

    # Assert
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 05:37:02.122222
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.collector.freebsd import FreeBSDVirtualCollector
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)
    assert instance._platform == 'FreeBSD'
    assert instance._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:03.099264
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:37:03.782212
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:37:10.744482
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_processor_nodes = ('1', '2')

    class TestModule(object):
        def __init__(self, processor_nodes=fake_processor_nodes):
            self.params = {
                'gather_subset': [],
                'gather_timeout': 10,
            }
            self.facts = {
                'processor': [{'count': len(processor_nodes), 'role': 'CPU'}],
            }
            self.ansible_facts = {
                'processor': [{'count': len(processor_nodes), 'role': 'CPU'}],
                'ansible_processor_vcpus': len(processor_nodes),
            }
            self.fail_json = fake_fail_json


# Generated at 2022-06-11 05:37:16.000413
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert issubclass(FreeBSDVirtualCollector._fact_class, Virtual)
    assert issubclass(FreeBSDVirtualCollector._fact_class, VirtualSysctlDetectionMixin)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:37:17.912436
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    obj = FreeBSDVirtual()
    facts = obj.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:37:20.208100
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert isinstance(c, FreeBSDVirtualCollector)
    assert isinstance(c._fact_class, FreeBSDVirtual)
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:22.455120
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Test if virtual_facts has mandatory keys
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:37:30.782597
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:37:39.044823
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Testing when jail is defined
    test = FreeBSDVirtual({})
    test.get_virtual_sysctl_facts = lambda: {'security.jail.jailed': '1'}
    test.get_virtual_vendor_facts = lambda: {'virtualization_tech_guest': set(['jail']), 'virtualization_tech_host': set([])}
    test.get_virtual_sysctl_facts = lambda: {'hw.hv_vendor': '', 'security.jail.jailed': '1', 'kern.vm_guest': 'none'}
    facts = test.get_virtual_facts()
    assert 'jail' in facts['virtualization_tech_guest']
    assert 'jail' in facts['virtualization_type']

# Generated at 2022-06-11 05:39:10.570910
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:39:20.085628
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest
    f = FreeBSDVirtual({})

    f.get_file_content = lambda x: ''
    f.get_mount_size = lambda x: ''
    f.get_file_content = lambda x: ''
    f.get_cmd_output = lambda x: ''
    assert {} == f.get_virtual_facts()

    f.get_file_content = lambda x: 'Xen Classified OS\n'
    f.get_mount_size = lambda x: ''
    f.get_file_content = lambda x: ''
    f.get_cmd_output = lambda x: ''
    assert {'virtualization_role': 'guest',
            'virtualization_type': 'xen'} == f.get_virtual_facts()


# Generated at 2022-06-11 05:39:26.005345
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import argparse
    import inspect

    arg_spec = inspect.getargspec(FreeBSDVirtualCollector.__init__)
    assert len(arg_spec.args) == 1 + len(arg_spec.defaults or [])

    parser = argparse.ArgumentParser()
    FreeBSDVirtualCollector.add_parser_options(parser)

    options = parser.parse_args([])
    collector = FreeBSDVirtualCollector(options=options)
    assert collector.options == options

# Generated at 2022-06-11 05:39:26.821722
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'


# Generated at 2022-06-11 05:39:34.556036
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:39:36.653564
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    vc = FreeBSDVirtualCollector()
    assert (vc.platform == 'FreeBSD')

# Generated at 2022-06-11 05:39:43.474172
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    v = FreeBSDVirtual()

    fake_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    assert v.get_virtual_facts() == fake_facts

    v.module.get_bin_path.return_value = '/bin/sysctl'

    v.module.run_command.side_effect = [
        (0, 'hw.hv_vendor: "Bhyve"', ''),
        (0, 'kern.vm_guest: "bhyve"', ''),
        (0, 'security.jail.jailed: 0', '')
    ]


# Generated at 2022-06-11 05:39:51.325221
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class mock_open():

        def __init__(self, path):
            self._path = path

        def __call__(self, path):
            return self

        def read(self):
            if self._path == '/dev/xen/xenstore':
                return ''
            else:
                return '67'

        def close(self):
            pass

    fake_sysctl_results = {
        'hw.hv_vendor': 'FreeBSD',
        'security.jail.jailed': '0',
        'kern.vm_guest': 'other'
    }

    fake_model_result = {
        'hw.model': 'VMware Virtual Platform'
    }

    def mock_detect_virt_product(product_name):
        return fake_sysctl_results[product_name]



# Generated at 2022-06-11 05:39:52.365238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert(f.platform == 'FreeBSD')

# Generated at 2022-06-11 05:39:54.070906
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_facts_collector, FreeBSDVirtualCollector)
