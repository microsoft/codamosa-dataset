

# Generated at 2022-06-11 05:31:27.396482
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:31:30.141176
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual
    assert fbc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:32.831376
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test class FreeBSDVirtual.get_virtual_facts.'''
    # TODO find a way to test it
    true = True
    false = False
    assert true

# Generated at 2022-06-11 05:31:36.559514
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v._platform == 'FreeBSD'
    assert isinstance(v._fact_class, type)
    assert issubclass(v._fact_class, Virtual)
    assert v._fact_class.__name__ == 'FreeBSDVirtual'
    assert v._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:37.076508
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:38.035493
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:31:41.664003
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_module_utils = FreeBSDVirtualCollector()
    assert freebsd_module_utils.platform == 'FreeBSD'
    assert freebsd_module_utils._fact_class == FreeBSDVirtual

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 05:31:49.764822
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector().collect()
    assert type(facts) is dict, "Returned facts must be of type == dict"
    assert 'virtualization_type' in facts, "Returned facts must contain 'virtualization_type'"
    assert 'virtualization_role' in facts, "Returned facts must contain 'virtualization_role'"
    assert 'virtualization_tech_guest' in facts, "Returned facts must contain 'virtualization_tech_guest'"
    assert 'virtualization_tech_host' in facts, "Returned facts must contain 'virtualization_tech_host'"

# Generated at 2022-06-11 05:31:59.214518
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Build a mock FreeBSDVirtual object
    class FreeBSDVirtualMock(FreeBSDVirtual):
        def __init__(self):
            super(FreeBSDVirtualMock, self).__init__()
            self.facts = {'virtual': {}}

        def detect_virt_product(self, sysctl_name):
            if sysctl_name == 'kern.vm_guest':
                if os.path.exists('/dev/vmm/netbsd'):
                    return {'virtualization_tech_guest': set(['netbsd']),
                            'virtualization_tech_host': set(['bhyve']),
                            'virtualization_type': 'bhyve',
                            'virtualization_role': 'guest'}

# Generated at 2022-06-11 05:32:07.348455
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with null output of sysctl -a
    # Here the output of sysctl -a is empty, so virtualization_role
    # should be 'guest'
    output_sysctl = ''
    facts = VirtualCollector.get_facts(platform='FreeBSD',
                                       sysctl_output=output_sysctl,
                                       model_output='',
                                       dmidecode_output='',
                                       module=None)
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_technologies_host'] == set()
    assert facts['virtualization_technologies_guest'] == set()

    # Test with a sample output of sysctl -a
    # Here the output of sysctl -a contains kern.vm_guest=other,


# Generated at 2022-06-11 05:32:11.986319
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:13.299937
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v is not None

# Generated at 2022-06-11 05:32:23.253076
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # We want to test the full virtual_facts dict
    import pytest
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    # Mock sysctl so we can test each helper method
    __builtins__.open = mock_open
    read_mock = MagicMock(return_value="fake")
    file_mock = MagicMock(spec=file)
    file_mock.read = read_mock
    open_mock = MagicMock(return_value=file_mock)
    __builtins__.open = open_mock

    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    # Test helper methods
    open_mock.assert_called()
    assert virtual_facts.get('virtualization_sysctl_kern_vm_guest') == 'fake'

# Generated at 2022-06-11 05:32:24.330491
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bc = FreeBSDVirtualCollector()
    assert bc is not None

# Generated at 2022-06-11 05:32:34.109751
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    modules_mock = {
        '_load_params': lambda: {},
        'params': {},
    }
    stdin_mock = {
        'read': lambda: '',
    }
    facts_module = FreeBSDVirtual('facts.FreeBSDVirtual', modules_mock, stdin_mock)
    facts_module.read_file = lambda x: ''
    facts_module.get_all_subclasses = lambda x: [FreeBSDVirtual]
    facts_module.sysctl = lambda x: ''
    facts_module.detect_virt_product = lambda x: {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-11 05:32:43.804085
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mocking kern_vm_guest
    kern_vm_guest = {'virtualization_tech_guest': ['kvm'], 'virtualization_tech_host': ['qemu'], 'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    # Mocking hw_hv_vendor
    hw_hv_vendor = {'virtualization_tech_guest': [], 'virtualization_tech_host': [], 'virtualization_type': '', 'virtualization_role': ''}

    # Mocking sec_jail_jailed
    sec_jail_jailed = {'virtualization_tech_guest': [], 'virtualization_tech_host': [], 'virtualization_type': '', 'virtualization_role': ''}

    # Mocking virtual

# Generated at 2022-06-11 05:32:45.092803
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual.get_virtual_facts(None)
    # TODO: test the output

# Generated at 2022-06-11 05:32:52.341454
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {
        'kernel': 'FreeBSD',
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
        'sysctl': {
            'kern.vm_guest': 'other',
            'hw.hv_vendor': 'Bhyve',
            'security.jail.jailed': True,
            'hw.model': 'VirtualBox'
        },
        'file_exists': {
            '/dev/xen/xenstore': False,
        }
    }


# Generated at 2022-06-11 05:32:57.799519
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This is FreeBSD virtual.
    virtual = FreeBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 05:33:02.809977
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:33:16.889124
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facter_facts = {'kernel': 'FreeBSD', 'product_name': 'VirtualBox', 'product_serial': '0', 'system_manufacturer': 'innotek GmbH', 'system_product': 'VirtualBox', 'virtual': 'virtualbox', 'virtualization_role': 'guest', 'virtualization_type': 'xen'}
    freebsd_virtual_module = FreeBSDVirtual()
    virtual_facts = freebsd_virtual_module.get_virtual_facts(facter_facts)
    assert virtual_facts == {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['virtualbox', 'xen'])}

# Generated at 2022-06-11 05:33:18.813534
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb_virtual = FreeBSDVirtual(None)
    fb_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:33:21.426982
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:31.182715
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Patch the file '/dev/xen/xenstore'
    monkeypatch.setattr('os.path.exists', lambda x: True)
    # Virtualization facts must be equal to this dict
    virtual_facts = {'virtualization_role': 'guest',
                     'virtualization_type': 'xen',
                     'virtualization_tech_guest': set(['xen']),
                     'virtualization_tech_host': set()}
    # Test FreeBSDVirtual class
    freebsd_virtual = FreeBSDVirtual()
    # Get virtualization facts
    facts = freebsd_virtual.get_virtual_facts()
    # Asserts
    assert dict_to_set(facts) == dict_to_set(virtual_facts)


# Generated at 2022-06-11 05:33:33.180013
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'



# Generated at 2022-06-11 05:33:33.738054
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:36.756070
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    if virtual_facts['virtualization_type'] == 'xen':
        assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type']


# Generated at 2022-06-11 05:33:41.709851
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, 'amd64', ['hw.machine_arch', 'kern.vm_guest', 'hw.hv_vendor', 'security.jail.jailed', 'hw.model']).collect()
    assert 'ansible_facts' in facts
    assert 'virtual' in facts['ansible_facts']
    # No assertion on values

# Generated at 2022-06-11 05:33:43.516795
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert facts == {}

# Generated at 2022-06-11 05:33:46.484718
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert isinstance(obj, FreeBSDVirtualCollector)
    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:33:56.892879
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ''' Unit test for constructor of class FreeBSDVirtualCollector '''
    assert isinstance(FreeBSDVirtualCollector()._fact_class, FreeBSDVirtual)
    assert FreeBSDVirtualCollector()._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:59.164947
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert not hasattr(FreeBSDVirtualCollector, '_platform')
    assert not hasattr(FreeBSDVirtualCollector, '_fact_class')


# Generated at 2022-06-11 05:34:07.981111
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual_facts = FreeBSDVirtual()

    # Create a class that can tell FreeBSDVirtual what
    # sysctl, dmesg and kldstat retrieve
    class FreeBSDVirtualMockSysctlDmesgKldstat(object):
        def __init__(self):
            self.kldstat_returncode = 0
            self.kldstat_stdout = []
            self.sysctl_returncode = 0
            self.sysctl_stdout = []
            self.dmesg_returncode = 0
            self.dmesg_stdout = []
            self.sysctl_kern_vm_guest_stdout = []
            self.sysctl_hw_hv_vendor_stdout = []
            self.sysctl_security_jail_jailed_stdout = []
            self.sysctl_

# Generated at 2022-06-11 05:34:18.731779
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd = FreeBSDVirtual()
    # This would normally be done in either the base class constructor or in
    # setup of a unittest
    fbsd.sysctl = {'kern.vm_guest': 'other',
                   'hw.hv_vendor': '',
                   'security.jail.jailed': '0',
                   'hw.model': 'QEMU Virtual CPU version (cpu64-rhel6) (dtb client lpae)'}
    virtual_facts = fbsd.get_virtual_facts()

# Generated at 2022-06-11 05:34:21.266810
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:24.824667
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    assert v.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:34:26.475082
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._fact_class == FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:28.111624
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fb_vc = FreeBSDVirtualCollector()
    assert isinstance(fb_vc, VirtualCollector)


# Generated at 2022-06-11 05:34:39.119856
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    v = FreeBSDVirtual()

    # Test Xen/HVM
    v.sysctl_exists = lambda x: True
    v.sysctl_get = lambda x: 1
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test VirtualBox
    v.sysctl_exists = lambda x: False
    v.os_path_exists = lambda x: False

# Generated at 2022-06-11 05:34:42.564998
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual(None).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 05:35:07.896935
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockSubprocess(object):
        def __init__(self, output):
            self.output = output

        def Popen(self, args, **kwargs):
            class MockProcess(object):
                def __init__(self, output):
                    self.output = output

                def communicate(self):
                    return self.output

            if args == ['sysctl', 'security.jail.jailed']:
                return MockProcess(self.output)

    # Linux kernel running on physical machine
    mock = MockSubprocess('security.jail.jailed: 0\n')
    facts = FreeBSDVirtual(mock).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:35:10.480035
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsd_virtual_collector = FreeBSDVirtualCollector()
    assert bsd_virtual_collector.platform == 'FreeBSD'
    assert bsd_virtual_collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:35:11.388809
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual.get_virtual_facts()

# Generated at 2022-06-11 05:35:21.697820
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Init object, and assign value to sysctl return
    virtual_object = FreeBSDVirtual(None, None)
    virtual_object.sysctl_ret = {
        "kern.vm_guest": "unknown",
        "hw.hv_vendor": "whatever",
        "security.jail.jailed": "1",
        "hw.model": "FreeBSD",
    }
    # Execute method, and apply fixture
    virtual_facts = virtual_object.get_virtual_facts()
    # Check expected result
    assert virtual_facts['virtualization_type'] == "freebsd-jail"
    assert virtual_facts['virtualization_role'] == "guest"
    assert virtual_facts['virtualization_tech_guest'] == set(['freebsd-jail'])

# Generated at 2022-06-11 05:35:22.394581
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:35:32.318206
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test with not virtualized
    fbsd_virtual = FreeBSDVirtual({'kernel': 'FreeBSD'})
    fbsd_virtual.get_virtual_facts()
    assert fbsd_virtual.facts['virtualization_type'] == ''
    assert fbsd_virtual.facts['virtualization_role'] == ''
    assert fbsd_virtual.facts['virtualization_tech_guest'] == set()
    assert fbsd_virtual.facts['virtualization_tech_host'] == set()

    # Test with virtualized but not guest
    fbsd_virtual = FreeBSDVirtual()
    fbsd_virtual.facts['kernel'] = 'FreeBSD'
    fbsd_virtual.facts['model'] = 'VirtualBox'
    fbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:35:36.300244
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vf = {}
    vf['virtualization_type'] = ''
    vf['virtualization_role'] = ''
    vf['virtualization_tech_guest'] = set(['freebsd_jail'])
    vf['virtualization_tech_host'] = set(['bsd_kernel'])
    assert FreeBSDVirtual().get_virtual_facts() == vf

# Generated at 2022-06-11 05:35:44.652049
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    Virtual.detect_virt_product = lambda self, kern_vm_guest_glue: {
        'virtualization_type': 'product_virt',
        'virtualization_role': 'product_role',
        'virtualization_tech_guest': set(['product_virt_guest']),
        'virtualization_tech_host': set(['product_virt_host'])
    }

    Virtual.detect_virt_vendor = lambda self, hw_model_glue: {
        'virtualization_type': 'vendor_virt',
        'virtualization_role': 'vendor_role',
        'virtualization_tech_guest': set(['vendor_virt_guest']),
        'virtualization_tech_host': set(['vendor_virt_host'])
    }

    freebs

# Generated at 2022-06-11 05:35:48.295887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = AnsibleModuleMock({})
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:35:50.562692
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:18.804373
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def do_assertions(test_data, expected_response):
        virtual_facts = FreeBSDVirtual(given_facts={'ansible_output': test_data}).get_virtual_facts()

        assert virtual_facts == expected_response

    # Test a FreeBSD Jail host
    test_data = {'ansible_facts': {'ansible_virtualization_type': '',
                                   'ansible_virtualization_role': ''},
                 'ansible_sysctl_security_jail_jailed': '0',
                 'ansible_sysctl_hw_model': 'Intel(R) Xeon(R) CPU E5-2650 v3 @ 2.30GHz',
                 'ansible_sysctl_kern_vm_guest': 'freebsd'}

# Generated at 2022-06-11 05:36:22.418814
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = VirtualCollector.fetch_virtual_facts('FreeBSD')
    assert(type(virtual_facts) == dict)
    assert(type(virtual_facts['virtualization_tech_guest']) == set)
    assert(type(virtual_facts['virtualization_tech_host']) == set)



# Generated at 2022-06-11 05:36:31.912794
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # We can't really initialize _module that Virtual needs, because it expects
    # quite a lot of modules to be present, so we'll mock and patch the needed
    # parts for this test only.
    mock_module = type('module', (object,), {})()
    mock_module.params = {}
    mock_module.params['gather_subset'] = Virtual.gather_subset

    freebsd_virtual = FreeBSDVirtual(mock_module)
    virtual_facts = freebsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:36:35.974738
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert (sorted(virtual_facts.keys()) == sorted(['virtualization_type', 'virtualization_role',
                                                    'virtualization_technologies_guest',
                                                    'virtualization_technologies_host']))

# Generated at 2022-06-11 05:36:43.644394
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Tests FreeBSDVirtual.get_virtual_facts()."""
    # Just assume we're running on FreeBSD for now.
    fb = FreeBSDVirtual()
    assert isinstance(fb, FreeBSDVirtual)
    assert fb.get_virtual_facts()['virtualization_type'] in (
        '', 'xen', 'jail', 'vmware', 'xen', 'hyperv')
    if fb.get_virtual_facts()['virtualization_type']:
        assert fb.get_virtual_facts()['virtualization_role'] in ('host', 'guest')
    else:
        assert fb.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-11 05:36:44.286580
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None


# Generated at 2022-06-11 05:36:45.716433
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    class_object = VMwareVirtualCollector()
    assert class_object.platform == "VMware ESXi"

# Generated at 2022-06-11 05:36:46.998400
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:36:55.631665
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    with open('tests/unit/module_utils/facts/virtual/FreeBSD_vm.product') as f:
        fake_cat_f_output = f.read()

    with open('tests/unit/module_utils/facts/virtual/FreeBSD_vm.vendor') as f:
        fake_cat_v_output = f.read()

    mock_execute_freebsd_vm_product = (1, fake_cat_f_output, None)
    mock_execute_freebsd_vm_vendor = (1, fake_cat_v_output, None)


# Generated at 2022-06-11 05:37:00.993635
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Test case for get_virtual_facts method of FreeBSDVirtual class
    '''
    virtual = FreeBSDVirtual()
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }
    virtual_facts_update = virtual.get_virtual_facts()
    assert virtual_facts.items() <= virtual_facts_update.items()

# Generated at 2022-06-11 05:38:24.827760
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector.__call__(), FreeBSDVirtual)

# Generated at 2022-06-11 05:38:25.628613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # this should not error
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:38:34.124408
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    # Set values for modules.virtual.sysctl.detect_virt_product
    # and modules.virtual.sysctl.detect_virt_vendor to simulate
    # a response to a call to sysctl
    kern_vm_guest_data = {
        'hw.hv_guest': '',
        'kern.vm_guest': '',
        'vm.pseries.lparcfg.vmx.enabled': '0',
        'vm.pmap.pg_ps_enabled': '1',
        'security.jail.jailed': '0'
    }

# Generated at 2022-06-11 05:38:35.849006
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc._platform == "FreeBSD"
    assert vc._fact_class.platform == "FreeBSD"

# Generated at 2022-06-11 05:38:37.909797
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    inst = FreeBSDVirtualCollector()
    assert isinstance(inst._platform, str)
    assert isinstance(inst._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:38:40.146549
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)
    assert instance._platform == 'FreeBSD'
    assert instance._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:38:42.442392
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform == 'FreeBSD'
    assert result.platform == 'FreeBSD'
    assert isinstance(result._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:38:44.907547
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:38:46.326361
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:38:54.804912
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    v.module_execname = 'ansible_module'
    s = sysctl_all_info_example()
    v.sysctl = lambda x: s[x]
    v.get_file_content = lambda x: None
    f = v.get_virtual_facts()
    assert f['virtualization_type'] == 'xen'
    assert f['virtualization_role'] == 'guest'
    assert f['virtualization_tech_guest'] == set(['xen', 'vmware'])
    assert f['virtualization_tech_host'] == set(['vmware'])

