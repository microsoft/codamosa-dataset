

# Generated at 2022-06-11 05:31:30.336121
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    def _read_file(filename):
        with open(os.path.join(os.path.dirname(__file__), filename), 'r') as f:
            data = f.read()
        return data

    # Populate sysctl_output
    sysctl_output = _read_file("FreeBSD_sysctl.output")

    test_facts = FreeBSDVirtual({'module_args': {}})
    test_facts._read_sysctl = lambda x: sysctl_output

    test_facts._read_file = _read_file

    test_facts.get_virtual_facts()

    assert test_facts.facts['virtualization_type'] == 'kvm'
    assert test_facts.facts['virtualization_role'] == 'guest'



# Generated at 2022-06-11 05:31:36.487379
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up
    data = {
        'os_family': 'freebsd',
        'ansible_system': 'FreeBSD',
    }
    BSDVirtualFact = FreeBSDVirtual(data)

    # Test
    facts = BSDVirtualFact.get_virtual_facts()

    # Assertion
    assert facts == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(['freebsd']),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-11 05:31:37.802980
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:31:39.888202
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:31:43.356697
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbsd_virtual_collector = FreeBSDVirtualCollector()
    assert fbsd_virtual_collector._fact_class == FreeBSDVirtual
    assert fbsd_virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:44.801229
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:48.549624
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = FreeBSDVirtualCollector.get_facts()
    assert list(facts_dict.keys()) == ['virtual']
    assert list(facts_dict['virtual'].keys()) == ['type', 'system', 'role']

# Generated at 2022-06-11 05:31:49.659184
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    return FreeBSDVirtualCollector().collect()

# Generated at 2022-06-11 05:31:59.144606
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    virtual = FreeBSDVirtual(module=None, facts=facts)

    # We have no virtual facts yet
    assert not any([v for k, v in facts.items() if k.startswith('virtual')])

    result = virtual.get_virtual_facts()
    assert result == {
        'virtualization_role': '',
        'virtualization_type': '',
    }

    kern_vm_guest_facts = dict(
        kern_vm_guest='guest',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )
    virtual = FreeBSDVirtual(module=None, facts=facts,
                             kern_vm_guest=kern_vm_guest_facts)

    result = virtual.get_virtual_facts()
   

# Generated at 2022-06-11 05:32:01.620254
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_class = FreeBSDVirtual
    fact_collector = FreeBSDVirtualCollector()
    assert isinstance(fact_collector._fact_class, fact_class)
    assert fact_collector._platform == fact_class.platform

# Generated at 2022-06-11 05:32:07.057403
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.__class__.__name__ == 'FreeBSDVirtualCollector'

# Generated at 2022-06-11 05:32:17.515138
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    hv_vendor = {'sysctl_values': [{'hw.hv_vendor': 'bhyve bhyve'}]}
    jail_jailed = {'sysctl_values': [{'security.jail.jailed': 0}]}
    vm_guest = {'sysctl_values': [{'kern.vm_guest': 'none'}]}
    model = {'hw.model': 'Intel(R) Xeon(R) CPU E3-1245 v3 @ 3.40GHz'}
    fail_facts = {'virtual_facts_module': 'ansible.module_utils.virtual.facts.freebsd'}
    fv = FreeBSDVirtual({}, {'freebsd': {}}, fail_facts)

# Generated at 2022-06-11 05:32:25.951246
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Init
    vm = FreeBSDVirtual()
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Test case 1: the host-fact-file does not exist
    virtual_facts = vm.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test case 2: the host is a xen guest
    # The host-fact-file should be a file called '/dev/xen/xenstore'
    # This

# Generated at 2022-06-11 05:32:31.788744
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] in ('', 'xen')
    assert virtual_facts['virtualization_role'] in ('', 'guest')
    assert virtual_facts['virtualization_tech_guest'] in (set(), {'xen'})
    assert virtual_facts['virtualization_tech_host'] in (set(), {'xen'})

# Generated at 2022-06-11 05:32:32.381354
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:35.667738
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = dict()
    virtual_facts_collector = FreeBSDVirtualCollector(facts_dict, None)
    assert virtual_facts_collector.platform == 'FreeBSD'
    assert virtual_facts_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:38.629656
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:39.795236
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()


# Generated at 2022-06-11 05:32:41.820058
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 05:32:48.440013
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    # Given that FreeBSDVirtual is instantiated
    freebsd = FreeBSDVirtual()
    # When I call get_virtual_facts
    facts = freebsd.get_virtual_facts()
    # Then I should see it returns the expected dictionary of facts
    assert(facts == {
        'virtual': True,
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    })

# Generated at 2022-06-11 05:32:58.525173
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:06.319669
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up FreeBSDVirtual instance
    fb_virtual = FreeBSDVirtual()

    # Run get_virtual_facts
    fb_virtual_facts = fb_virtual.get_virtual_facts()

    # Check expected results
    assert 'virtualization_type' in fb_virtual_facts
    assert 'virtualization_role' in fb_virtual_facts
    assert 'virtualization_tech_guest' in fb_virtual_facts
    assert 'virtualization_tech_host' in fb_virtual_facts

# Generated at 2022-06-11 05:33:10.528965
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {
        'kernel': 'FreeBSD',
        'kernel_version': '11.1-RELEASE',
        'virtualization_role': 'guest'
    }

    sut = FreeBSDVirtualCollector(None, facts, None)

    assert 'virtualization_tech_guest' in sut.get_virtual_facts().keys()

# Generated at 2022-06-11 05:33:11.761820
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt = FreeBSDVirtualCollector()
    assert virt.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:15.829893
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fake_freebsd = FreeBSDVirtualCollector()
    assert fake_freebsd.platform == 'FreeBSD'
    assert fake_freebsd._fact_class == FreeBSDVirtual
    assert fake_freebsd._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:17.523393
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ffx = FreeBSDVirtualCollector()
    assert isinstance(ffx, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:33:28.684016
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    facts = freebsd_virtual.get_virtual_facts()

    assert facts['virtualization_tech_guest'] == set() or set(['vmware']), \
        'test_FreeBSDVirtual_get_virtual_facts failed'
    assert facts['virtualization_tech_host'] == set(['vmware']) or set() or set(['vmware', 'kvm']), \
        'test_FreeBSDVirtual_get_virtual_facts failed'
    assert facts['virtualization_vendor'] == 'vmware' or 'vmware' or 'vmware' or 'vmware' or '', \
        'test_FreeBSDVirtual_get_virtual_facts failed'

# Generated at 2022-06-11 05:33:31.826037
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    ret = FreeBSDVirtualCollector()
    assert isinstance(ret, FreeBSDVirtualCollector)
    assert ret.platform == 'FreeBSD'
    assert ret._fact_class == FreeBSDVirtual
    assert ret._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:33.982908
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:39.352969
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def test_json(json_file):
        with open(json_file) as f:
            return json.load(f)

    import json
    import os
    import pytest
    import shutil
    import stat
    import tempfile
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    facts_dir = tempfile.mkdtemp()
    temp_sysctl_file = os.path.join(facts_dir, 'sysctl.json')
    temp_dmesg_file = os.path.join(facts_dir, 'dmesg.json')
    temp_devd_file = os.path.join(facts_dir, 'devd.json')

    # Setup the fixtures

# Generated at 2022-06-11 05:34:05.169705
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create FreeBSDVirtual object
    frbsd_virtual_object = FreeBSDVirtual()

    # Create a dictionary to return with expected virtual facts

# Generated at 2022-06-11 05:34:07.674833
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:11.718362
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector.collect(None, None)
    assert "virtualization_type" in facts.keys()
    assert "virtualization_role" in facts.keys()
    assert "virtualization_tech_guest" in facts.keys()
    assert "virtualization_tech_host" in facts.keys()

# Generated at 2022-06-11 05:34:14.175059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert issubclass(x._fact_class,Virtual)

# Generated at 2022-06-11 05:34:16.354121
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'

# Unit testing for method get_virtual_facts() of class FreeBSDVirtual

# Generated at 2022-06-11 05:34:19.412757
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test the default constructor of class FreeBSDVirtualCollector"""
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'


# Generated at 2022-06-11 05:34:20.784158
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None), VirtualCollector)

# Generated at 2022-06-11 05:34:21.816600
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None), VirtualCollector)

# Generated at 2022-06-11 05:34:29.413887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual
    """
    import unittest.mock as mock

    def _mocked_detect_virt_product(key):
        """
        This function mocks the detect_virt_product method of FreeBSDVirtual class
        """

        if key == 'hw.model':
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}
        else:
            return {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-11 05:34:40.430274
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    import os
    # Mock sysctl and hw.model
    path = os.path.join(os.path.dirname(__file__), 'data/')
    sysctl = os.path.join(path, 'sysctl.txt')
    hw_model = os.path.join(path, 'hw.model.txt')

    def mock_open(self, filename):
        if filename == '/sbin/sysctl':
            return open(sysctl, 'r')
        elif filename == '/usr/bin/kvm-ok' or filename == '/usr/bin/virt-what':
            return open(os.devnull, 'r')
        elif filename == '/var/run/dmesg.boot':
            return open(hw_model, 'r')

# Generated at 2022-06-11 05:35:30.877866
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:35:39.162495
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""

    # Set up the test data
    kern_vm_guest = {'virtualization_tech_guest': '', 'virtualization_tech_host': ''}
    hw_hv_vendor = {'virtualization_type': '', 'virtualization_role': '',
                    'virtualization_tech_guest': '', 'virtualization_tech_host': ''}
    sec_jail_jailed = {'virtualization_tech_guest': '', 'virtualization_tech_host': ''}
    virtual_vendor_facts = {'virtualization_tech_guest': '', 'virtualization_tech_host': ''}

    # Test data for VirtualSysctlDetectionMixin

# Generated at 2022-06-11 05:35:48.092018
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}

    # Test when kern.vm_guest == none
    data = {'kern.vm_guest': 'none',
            'hw.model': 'QEMU Virtual CPU version 0.9.0',
            'security.jail.jailed': '0'}
    virtual_facts_expected = {'virtualization_type': '',
                              'virtualization_role': '',
                              'virtualization_tech_guest': set(['qemu']),
                              'virtualization_tech_host': set(['qemu'])}
    f = FreeBSDVirtual(data=data)
    virtual_

# Generated at 2022-06-11 05:35:58.040039
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_prov_paths = {
        'hw.model': ['/sbin/sysctl', 'hw.model'],
        'hw.hv_vendor': ['/sbin/sysctl', 'hw.hv_vendor'],
        'security.jail.jailed': ['/sbin/sysctl', 'security.jail.jailed'],
        'kern.vm_guest': ['/sbin/sysctl', 'kern.vm_guest']
    }
    virtual = FreeBSDVirtual(virt_prov_paths=virt_prov_paths)

    facts = virtual.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'xen'

# Generated at 2022-06-11 05:36:01.689924
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
    Check FreeBSDVirtual.get_virtual_facts method return values
    '''

    # Create an instance of FreeBSDVirtual
    virtual_provider = FreeBSDVirtual()

    # Check expected return values for VirtualBox and for KVM/QEMU
    expected_return_dict_virtualbox = {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'virtualbox'}, 'virtualization_tech_host': set()}
    expected_return_dict_kvm = {'virtualization_type': '', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'kvm', 'qemu'}, 'virtualization_tech_host': {'kvm', 'qemu'}}

    # Get virtual facts on a FreeBSD machine running in VirtualBox

# Generated at 2022-06-11 05:36:12.373760
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    # Patch methods get_sysctl_info and get_hw_model_info
    # (get_sysctl_info is used in VirtualSysctlDetectionMixin)
    virtual.get_sysctl_info = lambda: {'kern.vm_guest': 'xen',
                                       'hw.hv_vendor': 'bhyve',
                                       'security.jail.jailed': '1',
                                       'dev.xen.xenbus.state': '',
                                       }
    virtual.get_hw_model_info = lambda: {'hw.model': 'i386'}
    # Assert method get_virtual_facts

# Generated at 2022-06-11 05:36:21.229557
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.virt.freebsd import FreeBSDVirtual

# Generated at 2022-06-11 05:36:30.834285
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Case 1: FreeBSD VH that is running a jail on it.
    # Set up target class
    class_params = {
        'ansible_facts': {
            'kern_vm_guest': 'other',
            'hw_hv_vendor': '',
            'sec_jail_jailed': '1'
        }
    }
    fv = FreeBSDVirtual(**class_params)

    # Get the results
    results = fv.get_virtual_facts()

    # Check the results
    assert results['virtualization_type'] == 'jail'
    assert results['virtualization_role'] == 'guest'
    assert results['virtualization_tech_guest'] == set(['jail'])
    assert results['virtualization_tech_host'] == set(['jail'])

# Generated at 2022-06-11 05:36:40.458737
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize FreeBSDVirtual class instance
    fbsd_virtual_instance = FreeBSDVirtual()

    # Initialize return_dict in which we store FreeBSDVirtual class methods output
    return_dict = {}

    # Set return_dict['result'] to 'success' as default
    return_dict['result'] = 'success'

    # call get_virtual_facts method of FreeBSDVirtual class instance
    freebsd_virtual_facts = fbsd_virtual_instance.get_virtual_facts()

    # Initialize expect_result dict in which we store our expected result
    expect_result = {}
    expect_result['virtualization_type'] = ''
    expect_result['virtualization_role'] = ''
    expect_result['virtualization_tech_guest'] = set()
    expect_result['virtualization_tech_host'] = set()

    # Compare expect

# Generated at 2022-06-11 05:36:49.183168
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    with open('../files/sysctl-kern.vm_guest.xen') as f:
        kern_vm_guest = f.read()
    with open('../files/sysctl-hw.hv_vendor.xen') as f:
        hw_hv_vendor = f.read()
    with open('../files/sysctl-security.jail.jailed.0') as f:
        sec_jail_jailed = f.read()
    with open('../files/sysctl-hw.model.qemu') as f:
        hw_model = f.read()

# Generated at 2022-06-11 05:38:15.011973
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, FreeBSDVirtualCollector)
    assert virtual_collector._fact_class is FreeBSDVirtual



# Generated at 2022-06-11 05:38:16.949611
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj1 = FreeBSDVirtualCollector()
    assert obj1.platform == 'FreeBSD'
    assert obj1._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:38:18.014558
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:38:20.253382
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual()
    facts = fv.get_virtual_facts()

    assert 'virtualization_type' in facts, facts
    assert 'virtualization_role' in facts, facts

# Generated at 2022-06-11 05:38:21.383772
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c._fact_class is not None

# Generated at 2022-06-11 05:38:23.727126
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual().get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:38:32.227575
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }
    bsdv = FreeBSDVirtual()
    assert virtual_facts == bsdv.get_virtual_facts()

    # Test virtualization_role as guest
    bsdv.sysctl_vm_guest = {'value': 'bhyve'}
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {'bhyve'},
        'virtualization_tech_host': {},
    }
    assert virtual_facts == bsdv.get_virtual_facts()

    # Test virtualization_role

# Generated at 2022-06-11 05:38:40.578160
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSD Virtualization facts with sysctl data
    # Valid sysctl output for virtualization type
    kern_vm_guest = ['none', 'other', 'xen', 'vmware', 'jail', 'virtualbox']
    kern_vm_guest_output = ['', '0', '3', '3', '3']
    hw_hv_vendor = ['bhyve', 'none', 'other']
    hw_hv_vendor_output = ['BHYVE', '', '0']
    sec_jail_jailed = ['jailed', 'not_jailed']
    sec_jail_jailed_output = ['YES', 'NO']
    # Invalid sysctl output for virtualization type
    kern_vm_guest_invalid_output = ['0']
    hw_hv_

# Generated at 2022-06-11 05:38:44.108003
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({})
    virtual_facts = facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:38:45.981427
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert 'FreeBSD' == virtual_collector._platform

# Generated at 2022-06-11 05:40:23.578961
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    this_dir, this_filename = os.path.split(__file__)
    sysctl_dir = os.path.join(this_dir, 'sysctl_fixtures')
    test_obj = FreeBSDVirtual({}, sysctl_dir=sysctl_dir)
    sysctl = test_obj.get_virtual_facts()
    assert type(sysctl) is dict
    assert sysctl['virtualization_role'] == 'guest'
    assert sysctl['virtualization_type'] == 'vmware'

# Generated at 2022-06-11 05:40:25.634913
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert virtual_facts is not None
    assert virtual_facts['ansible_facts']['virtualization_type'] != ""

# Generated at 2022-06-11 05:40:33.089377
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class MockFreeBSDVirtual(FreeBSDVirtual):

        def __init__(self):
            self.facts = {}

        def detect_virt_product(self, virtual_type):
            return {
                'virtualization_tech_guest': set(['jail']),
                'virtualization_tech_host': set(['BHYVE']),
                'virtualization_type': 'jail'
            }

        def detect_virt_vendor(self, virtual_type):
            return {
                'virtualization_tech_guest': set(['BHYVE']),
                'virtualization_tech_host': set(['BHYVE']),
                'virtualization_type': 'bhyve'
            }

    bsd_

# Generated at 2022-06-11 05:40:34.181905
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector()
    assert 'virtualization' in facts.collect().keys()

# Generated at 2022-06-11 05:40:42.360106
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec={},
    )

    # Set virtual facts values to allow us to test the FreeBSDVirtual class
    module.ansible_facts['ansible_virtualization_type'] = 'xen'
    module.ansible_facts['ansible_virtualization_role'] = 'guest'
    module.ansible_facts['ansible_virtualization_technologies_guest'] = {'xen'}
    module.ansible_facts['ansible_virtualization_technologies_host'] = {'hv', 'vmware'}

    # Create object to test against
    freebsd_virtual = FreeBSDVirtual(module)

    # Call get_virtual_facts to get the facts from the Virtual class
    freebsd_virtual.get_virtual_facts()

    # Check results
    assert freebsd

# Generated at 2022-06-11 05:40:44.944047
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Constructor of class FreeBSDVirtualCollector can be called without
    error and returns an object of class FreeBSDVirtualCollector.
    """
    my_object = FreeBSDVirtualCollector()
    assert type(my_object) is FreeBSDVirtualCollector

# Generated at 2022-06-11 05:40:46.324168
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:40:55.190460
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kern_vm_guest = dict(
        kern_vm_guest_vbox='VBOX',
        kern_vm_guest_vbox_id='vbox',
        kern_vm_guest_vmm='KVM',
        kern_vm_guest_vmm_id='kvm',
        kern_vm_guest_xen='XEN',
        kern_vm_guest_xen_id='xen',
    )


# Generated at 2022-06-11 05:41:04.205950
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for default FreeBSD virtualization
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualbox' not in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' not in virtual_facts['virtualization_tech_host']
    # Test for FreeBSD virtualbox vm
    virtual_facts = FreeBSDVirtual({'ansible_product_name': 'VirtualBox',
                                    'ansible_system_vendor': 'innotek GmbH',
                                    'ansible_kern_vm_guest': 'bsd'}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-11 05:41:13.383584
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    virtualf = FreeBSDVirtual()
    facts = virtualf.get_virtual_facts()
    assert "virtualization_type" in facts
    assert "virtualization_role" in facts
    assert "virtualization_tech_guest" in facts
    assert "virtualization_tech_host" in facts

    assert facts["virtualization_type"] in ("xen", "", "vmware", "hyperv", "kvm")
    assert facts["virtualization_role"] in ("guest", "", "host")
    assert facts["virtualization_tech_guest"] == set(["xen", "vmware", "hyperv", "kvm"])
    assert facts["virtualization_tech_host"] == set(["vmware", "hyperv", "kvm"])