

# Generated at 2022-06-11 05:31:23.831191
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_class = FreeBSDVirtualCollector()
    assert virtual_facts_class._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:26.938028
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    c = FreeBSDVirtualCollector()
    assert c.platform == 'FreeBSD'
    assert c._fact_class == FreeBSDVirtual
    assert c._platform == 'FreeBSD'

# Generated at 2022-06-11 05:31:30.141323
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = FreeBSDVirtualCollector(None, None, None, None).collect()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:31:36.894913
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class FreeBSDVirtual"""

    cfg = dict(
        ansible_facts=dict(
            virtualization_tech_guest=set([]),
            virtualization_tech_host=set([]),
        )
    )

    fd = FreeBSDVirtual(cfg=cfg)

    data = fd.get_virtual_facts()

    assert data['virtualization_type'] == ''
    assert data['virtualization_role'] == ''
    assert data['virtualization_tech_guest'] == set([])
    assert data['virtualization_tech_host'] == set([])

# Generated at 2022-06-11 05:31:47.757230
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_virtual_facts = {'hw_model': 'QEMU Virtual CPU version 1.1.2',
                          'kern_vm_guest': 'xen',
                          'security_jail_jailed': '0',
                          'virtualization_role': 'guest',
                          'virtualization_type': 'xen',
                          'virtualization_tech_guest': set(['xen']),
                          'virtualization_tech_host': set([])}

    virtual_facts_obj = FreeBSDVirtual()
    virtual_facts = virtual_facts_obj.get_virtual_facts()

    assert test_virtual_facts['hw_model'] == virtual_facts['hw_model']
    assert test_virtual_facts['kern_vm_guest'] == virtual_facts['kern_vm_guest']


# Generated at 2022-06-11 05:31:48.867753
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:31:53.275062
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None, None).get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)


# Generated at 2022-06-11 05:31:55.047219
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class is FreeBSDVirtual

# Generated at 2022-06-11 05:31:56.918867
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # test class is created
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:03.832524
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    def sysctl_side_effect(arg):
        if arg == 'kern.vm_guest':
            return 'none'
        elif arg == 'hw.hv_vendor':
            return 'KVM'
        elif arg == 'security.jail.jailed':
            return 1
        elif arg == 'hw.model':
            return 'QEMU Virtual CPU version 2.5+'

    def os_path_exists_side_effect(path):
        if path == '/dev/xen/xenstore':
            return True
        else:
            return False


# Generated at 2022-06-11 05:32:18.171512
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    fbsd = FreeBSDVirtual()
    # Test conditions when /dev/xen/xenstore does not exist
    res = fbsd.get_virtual_facts()
    assert (res == virtual_facts)
    # Test conditions when /dev/xen/xenstore exist
    fbsd.detect_virt_product = lambda x: {'virtualization_tech_guest': set(['xen']),
                                          'virtualization_tech_host': set('xen'),
                                          'virtualization_type': 'xen',
                                          'virtualization_role': 'guest'}
    f

# Generated at 2022-06-11 05:32:21.411511
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test FreeBSDVirtualCollector class
    """
    fv_collector = FreeBSDVirtualCollector()
    assert fv_collector._platform == 'FreeBSD'
    assert fv_collector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:32:25.324830
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Create FreeBSDVirtualCollector object
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    # Check object name
    assert freebsd_virtual_collector.__class__.__name__ == 'FreeBSDVirtualCollector'
    # Check object of class FreeBSDVirtualCollector
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:32:27.356701
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvcp = FreeBSDVirtualCollector()
    assert fvcp.platform == 'FreeBSD'
    assert fvcp.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:32.049082
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}
    for key in facts.keys():
        assert FreeBSDVirtual(None).get_virtual_facts()[key] == facts[key]

# Generated at 2022-06-11 05:32:33.547073
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtual('bsd') == FreeBSDVirtualCollector('bsd').collect()[0]

# Generated at 2022-06-11 05:32:37.976367
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirt = FreeBSDVirtual({})
    virt_facts = FreeBSDVirt.get_virtual_facts()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_tech_host' in virt_facts

# Generated at 2022-06-11 05:32:40.594442
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector(None, None).collect()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-11 05:32:43.009092
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, VirtualCollector)



# Generated at 2022-06-11 05:32:44.594452
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector(None, None)
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:32:50.504970
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:56.762715
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # If a constructor is called without arguments then it must return a
    # VirtualCollector object which is an instance of VirtualCollector class and
    # it must have all required attributes in it.
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance, FreeBSDVirtualCollector)
    assert instance.platform == 'FreeBSD'
    assert instance._fact_class == FreeBSDVirtual
    assert instance._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:01.408876
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert issubclass(FreeBSDVirtualCollector._fact_class, Virtual)

# Unit tests for get_virtual_facts in class FreeBSDVirtual

# Generated at 2022-06-11 05:33:04.959767
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsd_virtual = FreeBSDVirtual()
    bsd_virtual.collect_facts = Mock()
    bsd_virtual.get_virtual_facts()
    assert bsd_virtual.collect_facts.called is True

# Generated at 2022-06-11 05:33:06.414407
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:33:08.525076
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:11.374978
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    vfacts = FreeBSDVirtual()
    parsed_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
    }
    assert vfacts.get_virtual_facts() == parsed_facts


# Generated at 2022-06-11 05:33:12.208231
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:23.423619
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    test_object = FreeBSDVirtual()

    def mock_detect_virt_product(a):
        # Mock detect_virt_product method
        # Function replicates the behaviour of detect_virt_product() method
        # for FreeBSD system
        # TODO: patches the function globally - not a good practice (although
        # module is not a library)
        if a == 'kern.vm_guest':
            return {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()
            }
        elif a == 'hw.hv_vendor':
            return {
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()
            }

# Generated at 2022-06-11 05:33:25.754397
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts import VirtualFactCollector
    assert issubclass(FreeBSDVirtualCollector, VirtualFactCollector)


# Generated at 2022-06-11 05:33:37.763639
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-11 05:33:47.693273
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    kern_vm_guest = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    hw_hv_vendor = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    sec_jail_jailed = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    virtual_vendor_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    fake = FreeBSDVirtual({}, dict())
    fake.detect_virt_product = lambda x: eval(x)
    virtual_facts = fake.get_virtual_facts()
   

# Generated at 2022-06-11 05:33:48.249088
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:33:58.300086
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Fake object
    class EmptyDict(dict):
        def __init__(self):
            pass

    test_FreeBSDVirtual = FreeBSDVirtual()

    # Test with kern.vm_guest = userland
    test_set = EmptyDict()
    test_set.sysctl_output = """security.jail.jailed: 0
kern.vm_guest: userland
hw.hv_vendor:""".splitlines()
    test_set.expected_facts = {'virtualization_type': '',
                               'virtualization_role': '',
                               'virtualization_tech_host': set(),
                               'virtualization_tech_guest': set(['jail'])}
    test_set.expected_output = ""
    test_set.expected_return = True
    test_FreeBSDVirtual

# Generated at 2022-06-11 05:34:07.011360
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Imports
    from ansible.module_utils.facts.virtual.sysctl import mock_sysctl

    # Tests
    # Test case 1
    mock_facts = {
        'kernel': 'FreeBSD',
        'virtualization_type': '',
    }
    mock_sysctl = {
        'kern.vm_guest': 'none',
    }

    fact = FreeBSDVirtual({'ansible_facts': mock_facts}, mock_sysctl)
    virtual_facts = fact.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Test case 2
    mock_facts = {
        'kernel': 'FreeBSD',
        'virtualization_type': '',
    }

# Generated at 2022-06-11 05:34:09.408409
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:13.193461
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual(None).get_virtual_facts()
    assert set(virtual_facts.keys()) == set([
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_type',
        'virtualization_tech_host',
    ])

# Generated at 2022-06-11 05:34:15.663950
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc.platform == 'FreeBSD'
    assert fbc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:20.398058
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert len(facts) == 4
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-11 05:34:24.852294
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    report = {
            'virtualization_role': '',
            'virtualization_type': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()
        }
    freebsd_virtual = FreeBSDVirtual(report)
    freebsd_virtual.get_virtual_facts()
    assert report == {
                'virtualization_role': '',
                'virtualization_type': '',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()
            }

# Generated at 2022-06-11 05:34:42.950330
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:34:45.301255
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_obj = FreeBSDVirtualCollector()
    assert virtual_facts_obj._fact_class == FreeBSDVirtual
    assert virtual_facts_obj._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:51.824199
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    _freebsdvirt = FreeBSDVirtual(None, None)
    _freebsdvirt.collect_platform_facts = lambda: {'virtualization_type': '',
                                                  'virtualization_role': ''}
    _freebsdvirt.sysctl.get = lambda x: 'jail' if x == 'security.jail.jailed' else ''
    _freebsdvirt.uname_result = {'machine': ''}

    # Example output:
    # {
    #      'virtualization_type': 'xen',
    #      'virtualization_role': 'guest',
    #      'virtualization_tech_guest': set(['xen']),
    #      'virtualization_tech_host': set(['virtualbox']),
    #  }
    facts = _freebsdvirt.get_virtual

# Generated at 2022-06-11 05:34:54.362359
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector_obj = FreeBSDVirtualCollector()
    assert virtual_collector_obj.platform == 'FreeBSD'
    assert virtual_collector_obj._fact_class.platform == 'FreeBSD'


# Generated at 2022-06-11 05:34:56.707968
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vc = FreeBSDVirtualCollector()
    assert vc.platform == 'FreeBSD'
    assert vc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:01.305165
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_class = FreeBSDVirtual()
    results = test_class.get_virtual_facts()
    assert type(results) == dict
    assert results['virtualization_type'] == 'xen'
    assert results['virtualization_role'] == 'guest'
    assert results['virtualization_technologies_guest'] == 'xen'

# Generated at 2022-06-11 05:35:05.659312
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }



# Generated at 2022-06-11 05:35:07.194504
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._fact_class == FreeBSDVirtual
    assert collector._platform == FreeBSDVirtual._platform

# Generated at 2022-06-11 05:35:08.644336
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:14.969292
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsdvirt = FreeBSDVirtual()
    virtual_facts = bsdvirt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('xen', 'kvm', 'virtualbox', 'vmware', 'hyperv', 'parallels')
    assert virtual_facts['virtualization_role'] in ('guest', 'host', 'container')
    assert type(virtual_facts['virtualization_tech_guest']) is set
    assert type(virtual_facts['virtualization_tech_host']) is set

# Generated at 2022-06-11 05:35:39.122270
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fact_class = FreeBSDVirtualCollector()
    assert fact_class._platform == 'FreeBSD'
    assert fact_class._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:35:40.633257
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()

    assert result._fact_class is not None
    assert result._platform is not None

# Generated at 2022-06-11 05:35:43.152831
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector, FreeBSDVirtualCollector)
    assert isinstance(collector._fact_class, FreeBSDVirtual)
    assert collector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:35:44.372391
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual = FreeBSDVirtualCollector()
    assert virtual._platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:45.915705
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector.platform == 'FreeBSD'


# Generated at 2022-06-11 05:35:47.160050
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:35:47.713854
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:35:49.626944
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts_collector = FreeBSDVirtualCollector()
    assert virtual_facts_collector.platform == 'FreeBSD'


# Generated at 2022-06-11 05:35:52.136992
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f
    assert f._platform == 'FreeBSD'
    assert f._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:36:02.309887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()

    # GIVEN a FreeBSD virtual class
    # WHEN calling get_virtual_facts
    freebsd_facts = freebsd_virtual.get_virtual_facts()

    # THEN we get a dict with the correct keys and values
    assert "virtualization_role" in freebsd_facts
    assert "virtualization_type" in freebsd_facts
    assert "virtualization_role" in freebsd_facts
    assert "virtualization_type" in freebsd_facts
    assert "virtualization_tech_host" in freebsd_facts
    assert "virtualization_tech_guest" in freebsd_facts

    # WHEN calling get_virtual_facts with existing sysctl's
    freebsd_facts = freebsd_virtual.get_virtual_facts()
    # THEN the

# Generated at 2022-06-11 05:37:08.910108
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvcr = FreeBSDVirtualCollector()
    assert fvcr.platform == "FreeBSD"

# Generated at 2022-06-11 05:37:10.995328
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Unit tests for FreeBSDVirtual class

# Generated at 2022-06-11 05:37:15.633011
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test the method get_virtual_facts of class FreeBSDVirtual
    """
    virtual_facts = FreeBSDVirtual().get_virtual_facts()

    assert type(virtual_facts['virtualization_type']) is str
    assert type(virtual_facts['virtualization_role']) is str
    assert type(virtual_facts['virtualization_tech_host']) is set
    assert type(virtual_facts['virtualization_tech_guest']) is set

# Generated at 2022-06-11 05:37:23.150232
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    bsdVirtualFact = FreeBSDVirtual()
    output = bsdVirtualFact.get_virtual_facts()
    assert (output['virtualization_role'] == 'guest' or
            output['virtualization_role'] == 'host'), \
        "Invalid virtualization_role"
    assert (output['virtualization_type'] == 'xen' or
            output['virtualization_type'] == ''), \
        "Invalid virtualization_type"
    for elem in output['virtualization_tech_guest']:
        assert (elem == 'kvm' or elem == 'lxc' or elem == 'openvz' or
                elem == 'vserver' or elem == 'xen' or elem == 'jail'), \
            "Invalid virtualization_tech_guest"

# Generated at 2022-06-11 05:37:24.212991
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:37:32.669739
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import sysctl

    sysctl_mock = sysctl.VirtualSysctlDetectionMixin()

# Generated at 2022-06-11 05:37:34.035082
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:37:36.230302
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:44.987568
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    import sys
    import os
    import json

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual

    class TestFreeBSDVirtual(FreeBSDVirtual):
        _platform = 'FreeBSD'

# Generated at 2022-06-11 05:37:46.578226
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-11 05:40:55.074858
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # FreeBSDVirtual is not a concrete class so we instantiate a subclass
    virtual_facts = FreeBSDVirtual()

    # Returned dictionary from get_virtual_facts()
    virtual_facts_dict = virtual_facts.get_virtual_facts()

    # Check the returned dict against a 'reference'
    # Newly added keys are no problem, old keys absent from the reference
    # will trigger an assertion error
    virtual_facts_reference = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    assert virtual_facts_dict == virtual_facts_reference


# Generated at 2022-06-11 05:40:55.584616
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:40:59.804038
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test if variable '_fact_class' is set to 'FreeBSDVirtual'
    and variable '_platform' is set to 'FreeBSD', which are class
    attributes of class FreeBSDVirtualCollector.
    """
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:41:01.021683
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector([])
    assert fvc

# Generated at 2022-06-11 05:41:08.232846
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set up and run fact collecter
    shared_vars = {'ansible_facts': {}, 'ansible_modules': {}}
    fbsd_virtual_fact_collector = FreeBSDVirtualCollector(shared_vars)
    fbsd_virtual_fact_collector.collect()

    assert 'virtualization_type' in shared_vars['ansible_facts']
    assert 'virtualization_role' in shared_vars['ansible_facts']
    assert 'virtualization_tech_guest' in shared_vars['ansible_facts']
    assert 'virtualization_tech_host' in shared_vars['ansible_facts']

# Generated at 2022-06-11 05:41:14.636037
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert type(virtual_facts['virtualization_tech_guest']) == set
    assert type(virtual_facts['virtualization_tech_host']) == set

# Generated at 2022-06-11 05:41:15.909581
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert type(v) == FreeBSDVirtualCollector