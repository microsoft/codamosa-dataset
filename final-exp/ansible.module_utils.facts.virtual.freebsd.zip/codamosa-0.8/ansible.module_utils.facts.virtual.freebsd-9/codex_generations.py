

# Generated at 2022-06-11 05:31:21.592955
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Make sure we can create an instance of FreeBSDVirtualCollector
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector
    # Make sure we can call get_virtual_facts() method of
    # FreeBSDVirtualCollector
    virtual_collector.get_virtual_facts()

# Generated at 2022-06-11 05:31:31.060712
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initialize the class
    freebsd = FreeBSDVirtual({})
    virtual_facts = freebsd.get_virtual_facts()

    # Check keys, virtualization_type, virtualization_role, virtualization_tech_guest, virtualization_tech_host
    assert len(virtual_facts) == 4
    assert virtual_facts['virtualization_type'] in ['xen', '', 'docker', 'container']
    assert virtual_facts['virtualization_role'] in ['guest', 'host']
    assert isinstance(virtual_facts['virtualization_tech_guest'], frozenset)
    assert isinstance(virtual_facts['virtualization_tech_host'], frozenset)

# Generated at 2022-06-11 05:31:32.868916
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector().collect()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:31:36.440923
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    freebsd_virtual = FreeBSDVirtual()
    freebsd_virtual.get_virtual_facts()
    assert freebsd_virtual.facts == virtual_facts

# Generated at 2022-06-11 05:31:47.268951
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Test the method get_virtual_facts of class FreeBSDVirtual
    """
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    freebsd_virtual = freebsd_virtual_collector._fact_class(freebsd_virtual_collector)

    # Test whether the methods _detect_virt_product and _detect_virt_vendor are
    # called and the result is right.
    freebsd_virtual._detect_virt_product = lambda k: {"virtualization_type": "", "virtualization_role": "", "virtualization_tech_guest": set(), "virtualization_tech_host": set()}

# Generated at 2022-06-11 05:31:57.447086
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # create a dummy FreeBSDVirtual object
    hardcoded_facts = {
        'freebsd_version': '10.0-RELEASE-p12',
    }

    class FakeModule(object):
        def __init__(self, hardcoded_facts):
            self.params = {}
            for key, value in hardcoded_facts.items():
                self.params[key] = value

    module = FakeModule(hardcoded_facts)

    freebsd_virtual = FreeBSDVirtual(module)

    # create a guest
    guest_facts = freebsd_virtual.get_virtual_facts()

    # check
    assert guest_facts['virtualization_type'] == 'xen'
    assert guest_facts['virtualization_role'] == 'guest'

    # cleanup
    del module
    del freebsd_virtual

# Generated at 2022-06-11 05:32:04.654856
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    fake_sysctl_results = {
        'kern.vm_guest': 'none',
        'hw.hv_vendor': 'bhyve',
        'security.jail.jailed': '0',
        'hw.model': 'Intel(R) Xeon(R) CPU E5-2697 v4 @ 2.30GHz'
    }
    data_dir = os.path.dirname(__file__) + '/../../../../lib/ansible/module_utils/facts/virtual'
    fake_sysctl_file = data_dir + '/freebsd_sysctl_data'
    fact_under_test = FreeBSDVirtual(sysctl_data=fake_sysctl_file)
    fact_under_

# Generated at 2022-06-11 05:32:08.267225
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(defined_virtual_facts={})
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-11 05:32:10.977238
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facter_virtual_collector = FreeBSDVirtualCollector()
    assert facter_virtual_collector.supported
    assert facter_virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:32:12.365762
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:32:21.586370
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    try:
        FreeBSDVirtualCollector()
    except Exception as e:
        assert False, 'Unhandled exception during instantiation of class ' \
                      'FreeBSDVirtualCollector.'

# Generated at 2022-06-11 05:32:23.131044
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert isinstance(collector._fact_class, Virtual)

# Generated at 2022-06-11 05:32:25.744059
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    bsxv = FreeBSDVirtualCollector()
    assert bsxv._fact_class == FreeBSDVirtual
    assert bsxv._platform == 'FreeBSD'
    assert bsxv._virtual_facts == {}


# Generated at 2022-06-11 05:32:28.286373
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:32:31.374425
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # input:
    #   platform: FreeBSD
    # output:
    #   instance of FreeBSDVirtualCollector
    assert isinstance(FreeBSDVirtualCollector(None, 'FreeBSD'),
                      FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:32:41.317609
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Mocks
    class MockSysctl:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def get(self):
            return self.value

    class MockSubProcess:
        def __init__(self, cmd, output):
            self.cmd = cmd
            self.output = output

        def Popen(self, cmd, stdout=None, stderr=None, shell=None):
            assert self.cmd == cmd
            return self

        def communicate(self):
            return self.output

    # Tests
    virtual = FreeBSDVirtual()

    # Test with host model `VMware, Inc. VMware Virtual Platform'

# Generated at 2022-06-11 05:32:43.000841
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector == virtual_collector


# Generated at 2022-06-11 05:32:47.881301
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Set all expected values
    expected_virtual_facts = dict(
        virtualization_role='',
        virtualization_type='')

    # Create the object which will be tested
    object_to_test = FreeBSDVirtual()

    # Get virtual_facts using get_virtual_facts and compare with expected values
    virtual_facts = object_to_test.get_virtual_facts()

    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-11 05:32:59.509235
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fake_sysctl = {'kern.vm_guest': 'other',
                   'hw.hv_vendor': 'bhyve',
                   'security.jail.jailed': 0}

# Generated at 2022-06-11 05:33:02.586388
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert virtual_facts._platform == 'FreeBSD'
    assert virtual_facts._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:16.693806
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual(module=None)
    virtual.sysctl = lambda x: False
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    virtual.sysctl = lambda x: 'guest'
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == 'guest'

    virtual.sysctl = lambda x: 'vmware'
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'

    virtual.sysctl = lambda x: 'virtualbox'


# Generated at 2022-06-11 05:33:22.273591
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = FreeBSDVirtual(module=None)
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] in ('virtualbox', 'vmware', 'parallels', 'qemu', 'xen', 'kvm', '')
    assert result['virtualization_role'] in ('guest', 'host', '')


# Generated at 2022-06-11 05:33:24.156942
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert isinstance(instance._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:33:26.489540
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    my_test = FreeBSDVirtualCollector(None, 'FreeBSD')
    assert isinstance(my_test, VirtualCollector)


# Generated at 2022-06-11 05:33:29.781637
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # get instance of FreeBSDVirtualCollector class
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == 'FreeBSD'
    assert fvc._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:32.059088
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector is not None
    assert collector._fact_class == FreeBSDVirtual
    assert collector._platform ==  'FreeBSD'

# Generated at 2022-06-11 05:33:34.503177
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:35.991556
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:38.181709
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(None), FreeBSDVirtualCollector)

# Unit test to check value of _platform variable in class FreeBSDVirtualCollector

# Generated at 2022-06-11 05:33:39.936900
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._fact_class is FreeBSDVirtual
    assert collector._platform is 'FreeBSD'

# Generated at 2022-06-11 05:33:48.539127
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:33:49.080004
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:33:55.220223
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtualCollector
    facts = FreeBSDVirtualCollector({}, {}).collect()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert set(facts['virtualization_tech_guest']) == set(['xen'])
    assert set(facts['virtualization_tech_host']) == set(['xen'])

# Generated at 2022-06-11 05:34:00.562887
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    is_virt = FreeBSDVirtual(module=None)

    expected_virtual_facts = {
        'virtualization_type': 'hvm',
        'virtualization_role': 'host',
        'virtualization_tech_host': {
            'kvm',
            'hvm'
        },
        'virtualization_tech_guest': set()
    }

    virtual_facts = is_virt.get_virtual_facts()
    assert expected_virtual_facts == virtual_facts

# Generated at 2022-06-11 05:34:04.049168
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    class MockRet(object):
        rc = 0
    class MockModule(object):
        def __init__(self, params):
            self.params = params
        def run_command(self, params):
            return MockRet()
    facts = dict()
    params = dict()
    obj = FreeBSDVirtual(module=MockModule(params))
    obj.get_virtual_facts()


# Generated at 2022-06-11 05:34:05.330782
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:34:06.793862
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:34:08.456972
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Test constructor of class FreeBSDVirtualCollector."""
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:34:12.961614
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({}, None)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:34:23.825777
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual()
    testobj.module = 'testmodule'

    # Test when no virtualization technology is detected
    testobj.get_sysctl = MagicMock(side_effect=[
            {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()},
            {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()},
            {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()},
    ])
    testobj.get_sysctl_hw = MagicMock(side_effect=[
            {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    ])

    testres = testobj.get_virtual_facts()
    assert 'virtualization_type' not in test

# Generated at 2022-06-11 05:34:41.208888
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual(None)

    # Set empty values as default
    assert v.facts['virtualization_type'] == ''
    assert v.facts['virtualization_role'] == ''

    v.facts['kern.vm_guest'] = 'freebsd'
    v.facts['hw.hv_vendor'] = 'qemu'
    v.facts['security.jail.jailed'] = '1'

    v.get_virtual_facts()

    # check virtualization_type and virtualization_role results for FreeBSD jails
    assert v.facts['virtualization_type'] == 'jail'
    assert v.facts['virtualization_role'] == 'guest'

    # check virtualization_tech_guest results
    # virtualization_tech_guest set must contain virtualization_type

# Generated at 2022-06-11 05:34:42.765110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert freebsd_virtual_collector is not None

# Generated at 2022-06-11 05:34:45.271301
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = dict()
    facts['distribution'] = 'FreeBSD'
    facts['distribution_version'] = '11.3-RELEASE-p8'

    obj = FreeBSDVirtual(facts=facts)
    virtual_facts = obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:34:49.693766
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = FreeBSDVirtual(facts, None)
    virtual_facts = virtual.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')
    assert(virtual_facts['virtualization_tech_guest'] == set())
    assert(virtual_facts['virtualization_tech_host'] == set())


# Generated at 2022-06-11 05:34:51.832520
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class is FreeBSDVirtual
    assert fvc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:53.028217
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-11 05:35:03.199244
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()

    f = dict(virtualization_type='kvm', virtualization_role='guest')

    os.environ['KERN_VM_GUEST'] = 'KVM'
    assert f == v.get_virtual_facts()

    os.environ['KERN_VM_GUEST'] = 'OTHER'
    os.environ['HW_HV_VENDOR'] = 'kvm'
    assert f == v.get_virtual_facts()

    os.environ['HW_HV_VENDOR'] = 'OTHER'
    os.environ['HW_MODEL'] = 'KVM'
    assert f == v.get_virtual_facts()

    os.environ['HW_MODEL'] = 'OTHER'
    assert {} == v.get_virtual_facts()

   

# Generated at 2022-06-11 05:35:06.839203
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd.freebsd_virtual import FreeBSDVirtualCollector
    facts = {'kernel': 'FreeBSD'}
    freebsd = FreeBSDVirtualCollector(facts, None)
    assert freebsd._platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:10.292663
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_obj = FreeBSDVirtual()
    result = {'virtualization_type': 'xen',
              'virtualization_role': 'guest',
              'virtualization_tech_guest': {'xen'},
              'virtualization_tech_host': set()}
    assert test_obj.get_virtual_facts() == result

# Generated at 2022-06-11 05:35:19.115835
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create an instance of FreeBSDVirtual class
    freebsd_virtual_facts = FreeBSDVirtual()

    # Get virtual facts using get_virtual_facts() method
    virtual_facts = freebsd_virtual_facts.get_virtual_facts()

    # Get expected results
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_product_host': '',
        'virtualization_product_guest': '',
        'virtualization_service_host': ''
    }

    # Assert expected results
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-11 05:35:29.142757
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_facts = FreeBSDVirtualCollector()
    assert isinstance(virtual_facts, FreeBSDVirtualCollector)

# Generated at 2022-06-11 05:35:34.218525
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Create class object
    bsd_virtual = FreeBSDVirtual()

    # Create a dict with expected results
    expected_results = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set([]),
        virtualization_tech_host=set([])
    )

    # Test empty results
    result = bsd_virtual.get_virtual_facts()
    assert expected_results == result

# Generated at 2022-06-11 05:35:40.345381
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    VM_VIRTUAL_FACTS = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set()
    )

    VM_VIRTUAL_FACTS_VMWARE = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(['vmware']),
        virtualization_tech_host=set(['vmware'])
    )

    VM_VIRTUAL_FACTS_VBOX = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(['virtualbox']),
        virtualization_tech_host=set(['virtualbox'])
    )

    VM_V

# Generated at 2022-06-11 05:35:41.566330
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-11 05:35:43.060152
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:35:46.645640
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert isinstance(virtual_collector._platform, str)
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:35:51.252491
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """
    Test FreeBSDVirtualCollector and VirtualCollector constructor
    """
    freebsd_virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(freebsd_virtual_collector._fact_class, FreeBSDVirtual)
    assert isinstance(freebsd_virtual_collector, FreeBSDVirtualCollector)
    assert isinstance(freebsd_virtual_collector, VirtualCollector)

# Generated at 2022-06-11 05:36:00.689528
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    import sys

    # Construct virtual facts manager
    fact_class = FreeBSDVirtual(module=None)

    # Virtual facts dict, should be filled
    virtual_facts = {}

    # Generate virtual facts
    fact_class.get_virtual_facts(virtual_facts)

    # Check virtualization_type
    virtualization_type = virtual_facts.get('virtualization_type', '')

    if sys.platform.startswith('freebsd'):
        # This is a FreeBSD host, so virtualization_type is a string, but empty
        assert virtualization_type == ''
    else:
        # This is a non-FreeBSD host, so virtualization_type is None
        assert virtualization_type is None

# Generated at 2022-06-11 05:36:07.082571
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual({})
    # TODO(william.lei@gmail.com): Add more tests
    #assert('virtualization_type' in virtual.get_virtual_facts())
    #assert('virtualization_role' in virtual.get_virtual_facts())
    #assert('virtualization_tech_guest' in virtual.get_virtual_facts())
    #assert('virtualization_tech_host' in virtual.get_virtual_facts())

# Generated at 2022-06-11 05:36:09.491970
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_virtual = FreeBSDVirtualCollector()
    assert freebsd_virtual.platform == 'FreeBSD'
    assert freebsd_virtual._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:36:42.039180
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import sys
    from ansible.module_utils.facts.virtual.freebsd import VirtualCollector
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    from ansible.module_utils.facts.virtual.freebsd import _platform
    import ansible.module_utils.facts.virtual.freebsd
    # Run constructor of class FreeBSDVirtualCollector
    f_virtual = FreeBSDVirtualCollector()
    # Assert that virtual facts class is Virtual
    assert Virtual is f_virtual.fact_class
    # Assert that platform is FreeBSD
    assert f_virtual.platform == _platform

# Generated at 2022-06-11 05:36:42.617438
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:36:51.176281
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Initializing virtual object
    virtual_object = FreeBSDVirtual()

    # Defining variables
    platform = 'FreeBSD'
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
    }

    # Defining data
    data = {
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
        'virtualization_product': '',
    }

    # Defining test data for get_virtual_facts

# Generated at 2022-06-11 05:36:54.061336
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''
        test module to test params input to get_virtual_facts method
    '''
    my_virtual_facts = FreeBSDVirtual({})
    my_virtual_facts.get_virtual_facts()
    assert my_virtual_facts.virtual_facts == {}

# Generated at 2022-06-11 05:37:02.567125
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class FreeBSDVirtual.
    """
    import sys
    import json
    import pytest
    #### If cannot create file in current directory, set to tmp
    if not os.access('.', os.W_OK):
        tmp_path="/tmp"
    else:
        tmp_path="."
    ###
    test_data_file=open(tmp_path + "/test_data.json", "r")
    test_data=json.load(test_data_file)
    test_data_file.close()
    sysctl_kern_vm_guest_obj=FreeBSDVirtual(module=None, collected_facts=None)
    sysctl_kern_vm_guest_obj.platform='FreeBSD'
    sysctl_kern_vm_guest_

# Generated at 2022-06-11 05:37:05.729937
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector._platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual
    assert virtual_collector._virt_what == [
        '/usr/sbin/virt-what',
        '/usr/bin/virt-what',
        '/usr/local/sbin/virt-what',
        '/usr/local/bin/virt-what',
        '/sbin/virt-what',
        '/bin/virt-what'
    ]



# Generated at 2022-06-11 05:37:07.080617
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:37:09.907708
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert set(virtual_facts.keys()) == {'virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host'}

# Generated at 2022-06-11 05:37:14.244106
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:37:15.373690
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    v.get_virtual_facts()

# Generated at 2022-06-11 05:38:42.329110
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    with open('/proc/cpuinfo', 'r') as f:
        cpuinfo = f.read()
    with open('/proc/meminfo', 'r') as f:
        meminfo = f.read()
    freebsd_virtual = FreeBSDVirtualCollector(cpuinfo, meminfo)
    assert freebsd_virtual._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:38:43.764849
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:38:45.096534
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-11 05:38:45.786446
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:38:53.058532
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    testobj = FreeBSDVirtual({})
    result = {'virtualization_type': '',
              'virtualization_role': '',
              'virtualization_tech_host': set(),
              'virtualization_tech_guest': set()}
    assert result == testobj.get_virtual_facts()

    testobj = FreeBSDVirtual({'kernel': 'FreeBSD'})
    result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }
    assert result == testobj.get_virtual_facts()


# Generated at 2022-06-11 05:38:59.509681
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = Virtual()

    class MockFreeBSDVirtual(FreeBSDVirtual):
        CACHED_VIRT_PRODUCTS = {
            'hw.model': {'hw_model': 'mock_hw_model'},
            'kern.vm_guest': {'kern_vm_guest': 'mock_kern_vm_guest'},
            'hw.hv_vendor': {'hw_hv_vendor': 'mock_hw_hv_vendor'},
            'security.jail.jailed': {'security_jail_jailed': 'mock_security_jail_jailed'}
        }

    virtual_facts = MockFreeBSDVirtual().get_virtual_facts()

    assert virtual_facts.get('virtualization_type') == 'xen'


# Generated at 2022-06-11 05:39:01.590106
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)


# Generated at 2022-06-11 05:39:03.184063
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:39:11.989573
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # Set up our class, as we normally would when invoking a module
    module = FreeBSDVirtual()
    # Set some sysctl string return values, since that's what we're actually
    # testing
    module.sysctl_all = {'kern.vm_guest': '', 'hw.hv_vendor': '', 'security.jail.jailed': '', 'hw.model': ''}

    # Call get_virtual_facts to populate the virtual facts
    virtual_facts = module.get_virtual_facts()

    # Verify that what we receive is what we expect
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set(['kvm'])
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:39:14.780670
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)
    assert virtual_collector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:40:46.802468
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  obj = FreeBSDVirtualCollector()
  assert obj.fact_class == FreeBSDVirtual
  assert obj.platform == 'FreeBSD'

# Generated at 2022-06-11 05:40:47.281817
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:40:52.101676
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)
    assert FreeBSDVirtualCollector._platform == FreeBSDVirtual.platform
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector.platform == FreeBSDVirtual.platform
    assert FreeBSDVirtualCollector.fact_class == FreeBSDVirtual
    assert isinstance(FreeBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-11 05:40:53.642419
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector.platform == "FreeBSD"
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:40:54.802001
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector()
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-11 05:40:56.616405
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v.platform == 'FreeBSD'
    assert v._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:41:04.366212
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors.virtual.freebsd import FreeBSDVirtualCollector

    class TestFreeBSDVirtualCollector(unittest.TestCase):
        def setUp(self):
            self.collector = FreeBSDVirtualCollector()

        def test_virtual_type(self):
            """Testing FreeBSDVirtualCollector.virt_type"""
            self.assertEqual(self.collector.virt_type, 'FreeBSD')

    unittest.main()



# Generated at 2022-06-11 05:41:05.535744
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    result = FreeBSDVirtualCollector()
    assert result._platform == 'FreeBSD'

# Generated at 2022-06-11 05:41:07.052834
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    v = FreeBSDVirtualCollector()
    assert v.platform == 'FreeBSD'


# Generated at 2022-06-11 05:41:10.673345
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual({})
    assert v.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }