

# Generated at 2022-06-11 05:31:30.092775
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    host_facts = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    handler = FreeBSDVirtual(host_facts, {})
    handler.detect_virt_product = lambda sysctl_name: {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    handler.detect_virt_vendor = lambda sysctl_name: {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    handler.get_virtual_facts()
    assert handler.virtual_facts['virtualization_type'] == ''
    assert handler.virtual_facts['virtualization_role'] == ''


# Generated at 2022-06-11 05:31:34.132527
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_bsd_facts = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}
    assert FreeBSDVirtual().get_virtual_facts() == virtual_bsd_facts

# Generated at 2022-06-11 05:31:43.830494
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:31:47.118334
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_dict = dict()
    virtual_collector = FreeBSDVirtualCollector(None, facts_dict)
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:31:57.327295
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_input = {'virtualization_type': '',
                  'virtualization_role': '',
                  'virtualization_tech_guest': set(),
                  'virtualization_tech_host': set()}
    test_instance = FreeBSDVirtual(test_input)

    test_output = test_instance.get_virtual_facts()
    assert test_output
    assert test_output['virtualization_type'] == ''
    assert test_output['virtualization_role'] == ''

    test_instance.facts = {'virtualization_type': 'kvm',
                           'virtualization_role': 'guest',
                           'virtualization_tech_guest': set(['kvm']),
                           'virtualization_tech_host': set()}
    test_output = test_instance.get_virtual_facts()
    assert test_

# Generated at 2022-06-11 05:31:58.341967
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert hasattr(FreeBSDVirtualCollector, '_fact_class'), \
        'Cannot find _fact_class'

# Generated at 2022-06-11 05:31:59.886171
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    from ansible.module_utils.facts.collector import VirtualCollector
    test = FreeBSDVirtualCollector()
    assert type(test) is VirtualCollector


# Generated at 2022-06-11 05:32:08.498926
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    # First test with a FreeBSD jail
    class FakeJailed(object):
        def readline(self):
            return None
    fake_jailed = FakeJailed()
    fake_jailed.readline = lambda: None
    virtual = FreeBSDVirtual(fake_jailed, fake_jailed)
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'jail'
    assert facts['virtualization_technologies_guest'] == set(['jail'])
    assert facts['virtualization_technologies_host'] == set()

    # Then test with a FreeBSD domU
    class FakeXen(object):
        def readline(self):
            return None
    fake_xenstore = FakeXen()
    fake_xen

# Generated at 2022-06-11 05:32:10.106953
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert issubclass(FreeBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-11 05:32:11.850414
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual({}).get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 05:32:22.926513
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {
        # Introduced in set_virtual_facts
        'virtualization_type': '',
        'virtualization_role': '',
        # Introduced in detect_virt_product
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        # Introduced in detect_virt_vendor
        'virtualization_vendor': '',
        'virtualization_product_name': '',
    }
    result = FreeBSDVirtual(None).get_virtual_facts()
    virtual_facts.update(result)
    assert result == virtual_facts

# Generated at 2022-06-11 05:32:24.597723
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert isinstance(fv, FreeBSDVirtual)
    assert isinstance(fv, Virtual)

# Generated at 2022-06-11 05:32:26.766850
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    instance = FreeBSDVirtualCollector()
    assert instance.platform == 'FreeBSD'
    assert instance._facts == {}
    assert isinstance(instance.fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:32:30.497284
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    # test virtualization_type
    assert virtual_facts['virtualization_type'] == 'xen'
    # test virtualization_role
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 05:32:40.596806
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """ Test the method get_virtual_facts of class FreeBSDVirtual
    """

    # Create a FreeBSDVirtual object
    fb_virtual = FreeBSDVirtual()

    # one patch for each test

# Generated at 2022-06-11 05:32:49.519770
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    module_name = 'ansible_fact'
    module_args = ''
    tmpdir = os.path.realpath(os.tmpnam())
    collections_path = os.path.join(tmpdir, 'collections')
    os.makedirs(collections_path)
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'plugins', 'module_utils', 'facts')
    collection = 'ansible_collections.sat_utils.test'
    collection_path = os.path.join(collections_path, collection.replace('.', os.sep))
    os.makedirs(collection_path)
    dest = os.path.join(collection_path, 'plugins')
    os.makedirs(dest)
    src = os.path.join

# Generated at 2022-06-11 05:32:50.096911
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:32:56.217392
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Unit test for constructor of class FreeBSDVirtualCollector"""
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.virtual == FreeBSDVirtual
    assert FreeBSDVirtualCollector.virtual.platform == 'FreeBSD'
    assert FreeBSDVirtualCollector.virtual.virtualization_type == ''
    assert FreeBSDVirtualCollector.virtual.virtualization_role == ''

# Generated at 2022-06-11 05:33:01.405049
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 05:33:07.394313
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Test constructor of class FreeBSDVirtualCollector
    '''
    # Test with valid inputs
    FreeBSDVirtualCollector()

    # Test with invalid inputs
    try:
        FreeBSDVirtualCollector(['fact_class'])
    except TypeError as e:
        assert "__init__() takes 1 positional argument but 2 were given" == str(e)
    except Exception as e:
        assert TypeError == type(e)

# Generated at 2022-06-11 05:33:22.676300
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Test for VMware ESXi hypervisor
    vf = FreeBSDVirtual({'ansible_system': 'FreeBSD'})
    vf.get_file_content = lambda x: b'"VMware ESXi"\n'
    assert vf.get_virtual_facts() == {
        'virtualization_type': 'VMware',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmware_esxi'}
    }

    # Test for Microsoft Hyper-V hypervisor
    vf = FreeBSDVirtual({'ansible_system': 'FreeBSD'})
    vf.get_file_content = lambda x: b'"Microsoft Hv"\n'

# Generated at 2022-06-11 05:33:28.108518
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert set(virtual_facts['virtualization_tech_guest']) == set()
    assert set(virtual_facts['virtualization_tech_host']) == set()


# Generated at 2022-06-11 05:33:34.542375
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual import freebsd_sysctl, freebsd_model

    col = collector.Collector()

    # Setup a FreeBSDVirtual object
    fb_virt = FreeBSDVirtual(col)

    # Define virtualization_type and virtualization_role based on
    # existing files, which should be empty.

# Generated at 2022-06-11 05:33:36.024857
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'

# Generated at 2022-06-11 05:33:39.094770
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f, VirtualCollector)
    assert isinstance(f._fact_class, type) and issubclass(f._fact_class, Virtual)

# Generated at 2022-06-11 05:33:40.830860
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    '''
    Check if FreeBSDVirtualCollector class is defined
    '''
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:33:50.437203
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Create test data
    # 1. sysctl kern.vm_guest
    empty_kern_vm_guest = 'none'
    xen_kern_vm_guest = 'xen'
    bhyve_kern_vm_guest = 'bhyve'

    # 2. sysctl hw.hv_vendor
    empty_hw_hv_vendor = ''
    xen_hw_hv_vendor = 'Xen'
    bhyve_hw_hv_vendor = 'BHyVe'

    # 3. sysctl security.jail.jailed
    not_jailed_sec_jail_jailed = '0'
    jailed_sec_jail_jailed = '1'

    # 4. sysctl hw.model
    empty_hw_model = ''

# Generated at 2022-06-11 05:33:56.103537
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    v = FreeBSDVirtual()
    facts = v.get_virtual_facts()
    assert 'virtualization_type' in facts.keys()
    assert 'virtualization_role' in facts.keys()
    assert 'virtualization_tech_guest' in facts.keys()
    assert 'virtualization_tech_host' in facts.keys()
    assert 'virtualization_product_name' in facts.keys()

# Generated at 2022-06-11 05:33:58.396948
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    facts = virtual.collect()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:33:59.526775
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    res = FreeBSDVirtualCollector()
    assert res



# Generated at 2022-06-11 05:34:13.152046
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Set facts
    freebsd_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    
    # Set values for test
    # Virtualization type
    # hw.model

# Generated at 2022-06-11 05:34:23.989663
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fbsd_virtual = FreeBSDVirtual(None)

    # On a BSD host, hw.model can returns "VirtualBox"
    fbsd_virtual.sysctls = {'hw.model': 'VirtualBox'}
    virtual_facts = fbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert fbsd_virtual.sysctls['hw.model'] == 'VirtualBox'

    # On a BSD host, hw.model can returns "VMware Virtual Platform"
    fbsd_virtual.sysctls = {'hw.model': 'VMware Virtual Platform'}
    virtual_facts = fbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:34:25.438316
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
  collector = FreeBSDVirtualCollector()
  assert('FreeBSDVirtual' == collector.__class__.__name__)

# Generated at 2022-06-11 05:34:28.625931
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    # Constructor FreeBSDVirtualCollector takes one parameter: module
    module = {}
    v_collector = FreeBSDVirtualCollector(module)
    assert v_collector._fact_class == FreeBSDVirtual
    assert v_collector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:34:35.507424
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set(),
                     'virtualization_product_guest': '',
                     'virtualization_product_host': ''}
    virtual = FreeBSDVirtual(collect_executable=None)
    assert virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-11 05:34:44.837213
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    """Tests for the method get_virtual_facts of class FreeBSDVirtual."""
    import unittest
    import sys
    import os

    # class MockOpen:
    #     def __init__(self, name):
    #         self.name = name
    #
    #     def __enter__(self):
    #         return self
    #
    #     def __exit__(self, *args):
    #         pass
    #
    #     def read(self):
    #         return 'FreeBSD'

    # class MockPlatform:
    #     def __init__(self, system, release, version, machine):
    #         """Mock the system/release/version/machine information returned by platform.system_alias()"""
    #         self.system = system
    #         self.release = release
    #         self.

# Generated at 2022-06-11 05:34:51.577680
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual_facts = {}

    # case 1: vm_guest = Jails   hv_vendor = None     jailed = 0       model = QEMU Virtual CPU version 2.0.0+
    virtual_facts['kern.vm_guest'] = 'jails'
    virtual_facts['hw.hv_vendor'] = None
    virtual_facts['security.jail.jailed'] = 0
    virtual_facts['hw.model'] = 'QEMU Virtual CPU version 2.0.0+'
    virtual = FreeBSDVirtual(virtual_facts)
    virtual_facts_result = virtual.get_virtual_facts()
    assert 'vmware' == virtual_facts_result['virtualization_type']
    assert 'guest' == virtual_facts_result['virtualization_role']
    assert 'vmware' in virtual_facts_

# Generated at 2022-06-11 05:34:53.068453
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert isinstance(f._collectors[0], FreeBSDVirtual)

# Generated at 2022-06-11 05:34:55.307489
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd = FreeBSDVirtualCollector()
    assert freebsd.platform == 'FreeBSD'
    assert freebsd._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:34:58.119039
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)
    assert fvc.platform == 'FreeBSD'
    assert fvc._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:35:06.407419
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts = {}
    # instantiate FreeBSDVirtualCollector
    virtual_obj = FreeBSDVirtualCollector(facts, None)
    # Assert test_class is instance of VirtualCollector
    assert isinstance(virtual_obj, VirtualCollector)
    # Assert os to be FreeBSD
    assert virtual_obj.os == 'FreeBSD'

# Generated at 2022-06-11 05:35:07.046560
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector('')



# Generated at 2022-06-11 05:35:16.490519
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class FreeBSDVirtual'''
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    fixture_sysctl_vm_guest_jail = os.path.join(fixture_path, 'sysctl_vm_guest_jail')

    # Set-up the class that we want to test
    fact = FreeBSDVirtual()

    result = fact.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result

    # Virtualization type
    assert result['virtualization_type'] == 'xen'

    # Virtualization role

# Generated at 2022-06-11 05:35:18.289354
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, FreeBSDVirtual)

# Generated at 2022-06-11 05:35:19.615291
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    x = FreeBSDVirtualCollector
    assert isinstance(x, object)

# Generated at 2022-06-11 05:35:22.014203
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsd_fact_class = FreeBSDVirtualCollector()
    assert freebsd_fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:24.202126
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-11 05:35:33.908668
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    from ansible.module_utils import basic

    # override sys.modules so we can import module
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # Setting up the mock
    mock_module = VirtualSysctlDetectionMixin()
    mock_module.get_file_content = lambda x: (
        'security.jail.jailed: 0'
        'hw.hv_vendor: bhyve'
        'kern.vm_guest: bhyve'
    )
    vm = FreeBSDVirtual(module)
    vm.get_file_content = mock_module.get_file_content
    virtual_facts = vm.get_virtual_facts()

    # Asserting the return type
    assert(type(virtual_facts) is dict)

# Generated at 2022-06-11 05:35:40.390429
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj1 = FreeBSDVirtualCollector()
    assert obj1
    assert isinstance(obj1, VirtualCollector)
    assert issubclass(obj1.__class__, VirtualCollector)
    assert obj1.platform == 'FreeBSD'
    obj1 = FreeBSDVirtualCollector(gather_subset=['!all'], gather_timeout=10,
                                   filter_spec=dict(type='command', patterns=['*']))
    assert obj1
    assert isinstance(obj1, VirtualCollector)
    assert issubclass(obj1.__class__, VirtualCollector)
    assert obj1.platform == 'FreeBSD'



# Generated at 2022-06-11 05:35:49.388643
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:35:55.064841
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:35:57.274644
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    obj = FreeBSDVirtualCollector()
    assert (obj.platform == 'FreeBSD')
    assert (obj._fact_class == obj._platform)

# Generated at 2022-06-11 05:36:07.602467
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    test_data = dict()
    test_data['xen'] = dict()
    test_data['xen']['result'] = dict()
    test_data['xen']['result']['virtualization_type'] = 'xen'
    test_data['xen']['result']['virtualization_role'] = 'guest'
    test_data['xen']['result']['virtualization_tech_guest'] = set(['xen'])
    test_data['xen']['result']['virtualization_tech_host'] = set()
    test_data['xen']['input_data'] = dict()
    test_data['xen']['input_data']['xenstore'] = {'path': '/dev/xen/xenstore'}
    test

# Generated at 2022-06-11 05:36:09.670772
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
   assert FreeBSDVirtualCollector._fact_class is FreeBSDVirtual
   assert FreeBSDVirtualCollector._platform == 'FreeBSD'


# Generated at 2022-06-11 05:36:14.282623
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    freebsd_virtual = FreeBSDVirtual(None)
    virtual_facts = freebsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'].startswith('xen') or \
        (virtual_facts['virtualization_type'] == '' and virtual_facts['virtualization_role'] == '')

# Generated at 2022-06-11 05:36:22.785204
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virt_facts = FreeBSDVirtual({})
    res = virt_facts.get_virtual_facts()
    assert res.get('virtualization_type') in ['',
                                              'xen',
                                              'vmware',
                                              'kvm',
                                              'hyperv',
                                              'jail']
    assert res.get('virtualization_role') in ['',
                                              'guest',
                                              'host']

    assert 'virtualization_tech_guest' in res
    assert res['virtualization_tech_guest']
    guest_tech = res['virtualization_tech_guest']
    assert isinstance(guest_tech, set)

    assert 'virtualization_tech_host' in res
    assert res['virtualization_tech_host']

# Generated at 2022-06-11 05:36:32.725468
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():

    class MockFreeBSDVirtual(Virtual, VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.facts = {'virtualization_type': '',
                          'virtualization_role': '',
                          'virtualization_tech_guest': set(),
                          'virtualization_tech_host': set()}


# Generated at 2022-06-11 05:36:35.072363
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virtual_collector = FreeBSDVirtualCollector()
    assert virtual_collector.platform == 'FreeBSD'
    assert virtual_collector.fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:36:37.897992
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'
    assert FreeBSDVirtualCollector._fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:36:43.563464
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    virtual = FreeBSDVirtual()
    virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-11 05:36:56.317353
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # import FreeBSDVirtual only once, because VirtualCollector is imported as
    # well.
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    test_object = FreeBSDVirtual()
    test_object._module = None
    facts = test_object.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:37:00.659172
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    import sys
    sys.modules['_freebsd_version'] = sys.modules.pop('ansible.module_utils.facts.virtual.freebsd.freebsd_version')
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f._fact_class.platform == 'FreeBSD'
    del sys.modules['_freebsd_version']

# Generated at 2022-06-11 05:37:05.046035
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    facts = FreeBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    for key in VirtualSysctlDetectionMixin.SYSCTL_VIRTUAL_PRODUCT_KEYS:
        assert key in facts
    for key in VirtualSysctlDetectionMixin.SYSCTL_VIRTUAL_VENDOR_KEYS:
        assert key in facts

# Generated at 2022-06-11 05:37:05.804296
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert isinstance(FreeBSDVirtualCollector(),VirtualCollector)

# Generated at 2022-06-11 05:37:09.761613
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'
    assert fv.fact_class == FreeBSDVirtual
    assert fv.collect()['virtualization_type']
    assert fv.collect()['virtualization_role']
    assert fv.collect()['virtualization_tech_host']
    assert fv.collect()['virtualization_tech_guest']

# Generated at 2022-06-11 05:37:11.286830
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector().platform == 'FreeBSD'


# Generated at 2022-06-11 05:37:15.890449
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fb_virtual = FreeBSDVirtual({})
    facts = fb_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'full' or 'paravirtualization' or 'hardware' or 'hvm' or 'xen' or 'other'
    assert facts['virtualization_role'] == 'guest' or 'host'
    assert facts['virtualization_tech_guest'] and facts['virtualization_tech_host']

# Generated at 2022-06-11 05:37:17.497443
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()

    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDVirtual


# Generated at 2022-06-11 05:37:22.164931
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    os_version = '10.4-RELEASE-p4'
    f = FreeBSDVirtualCollector(os_version)
    assert f.os_version == os_version
    assert f.platform == 'FreeBSD'
    assert f.facts['virtualization_type'] == ''
    assert f.facts['virtualization_role'] == ''
    assert f.facts['virtualization_tech_guest'] == set()
    assert f.facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:37:29.802142
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # This test checks the virtual facts returned by FreeBSDVirtual
    # instance.

    class FreeBSDVirtual_for_test(FreeBSDVirtual):
        def __init__(self, module):
            self.module = module

        def get_virtual_facts(self):
            return self.module.params['virtual_facts']

    class Module:
        params = {
            'virtual_facts': {
                'virtualization_type': 'virtualbox',
                'virtualization_role': 'guest'
            }
        }

    freebsd_virtual = FreeBSDVirtual_for_test(Module())

    assert freebsd_virtual.get_virtual_facts() == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest'
    }

# Generated at 2022-06-11 05:37:51.373192
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert fbc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:37:53.989570
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    """Unit test module FreeBSDVirtualCollector"""
    _obj = FreeBSDVirtualCollector()
    assert _obj.platform == 'FreeBSD'
    assert _obj.virtual in ('FreeBSDVirtual', 'Virtual')

# Generated at 2022-06-11 05:37:54.885796
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()



# Generated at 2022-06-11 05:38:03.984720
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import os
    import copy
    import pytest

    default_freebsd_virtual_facts = dict(
        ansible_virtualization_type='',
        ansible_virtualization_role='',
        ansible_virtualization_technology_guest=set(),
        ansible_virtualization_technology_host=set()
    )

    @pytest.fixture(autouse=True)
    def restore_os_environ(monkeypatch, os_environ):
        yield
        monkeypatch.setitem(os.environ, 'VMWARE_GUEST_VAR_SYSTEM_UUID', os_environ['VMWARE_GUEST_VAR_SYSTEM_UUID'])


# Generated at 2022-06-11 05:38:05.912990
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    vm = FreeBSDVirtualCollector()
    assert vm.platform == 'FreeBSD'
    assert hasattr(vm, 'get_all_facts')

# Generated at 2022-06-11 05:38:06.496983
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:38:08.289086
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert fvc._platform == "FreeBSD"
    assert fvc._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:38:14.542895
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    fv = FreeBSDVirtual({})
    facts = {}
    facts['product_uuid'] = 'HexStringHere'
    expected_facts = {'virtualization_type': 'vmware',
                      'virtualization_role': 'guest',
                      'virtualization_tech_guest': set(['vmware']),
                      'virtualization_tech_host': set(['vmware'])}
    assert fv.get_virtual_facts(facts) == expected_facts

# Generated at 2022-06-11 05:38:16.006078
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fvc = FreeBSDVirtualCollector()
    assert isinstance(fvc, FreeBSDVirtualCollector)


# Generated at 2022-06-11 05:38:24.758930
# Unit test for method get_virtual_facts of class FreeBSDVirtual

# Generated at 2022-06-11 05:39:08.017555
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    f = FreeBSDVirtualCollector()
    assert f.platform == 'FreeBSD'
    assert f.fact_class.platform == 'FreeBSD'
    assert f.fact_class().platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:09.267450
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fv = FreeBSDVirtualCollector()
    assert fv.platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:10.148439
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    FreeBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:39:12.132534
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    fbc = FreeBSDVirtualCollector()
    assert isinstance(fbc._fact_class, FreeBSDVirtual)
    assert fbc._platform == 'FreeBSD'

# Generated at 2022-06-11 05:39:15.627475
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    freebsdcollector = FreeBSDVirtualCollector()
    assert freebsdcollector.platform == "FreeBSD"
    assert freebsdcollector._fact_class == FreeBSDVirtual

# Use the FreeBSDVirtualCollector class to parse the output of
# kern.vm_guest

# Generated at 2022-06-11 05:39:25.360278
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Create a FreeBSDVirtual object and a corresponding FreeBSDVirtualCollector
    # object, and replace their respective get_virtual_facts methods with
    # the one we want to test.
    # We also patch VirtualSysctlDetectionMixin._get_sysctl_facts()
    # to avoid making actual calls to sysctl.

    test_fbsd = FreeBSDVirtual()
    test_fbsd_collector = FreeBSDVirtualCollector()
    test_fbsd.get_virtual_facts = FreeBSDVirtual.get_virtual_facts
    test_fbsd_collector.get_virtual_facts = FreeBSDVirtualCollector.get_virtual_facts
    Virtual

# Generated at 2022-06-11 05:39:27.596702
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    facts_virt = FreeBSDVirtualCollector()
    assert facts_virt._platform == 'FreeBSD'
    assert facts_virt._fact_class == FreeBSDVirtual
    facts_virt.collect()

# Generated at 2022-06-11 05:39:28.110168
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector

# Generated at 2022-06-11 05:39:35.904121
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    platform_virtual = FreeBSDVirtual(None)
    virtual_facts = platform_virtual.get_virtual_facts()
    assert virtual_facts is not None, \
        "get_virtual_facts should return a dictionary, got None instead"
    if 'virtualization_type' in virtual_facts:
        assert isinstance(virtual_facts['virtualization_type'], str), \
            "virtualization_type should be a string, got %s instead" % \
            type(virtual_facts['virtualization_type'])
    if 'virtualization_role' in virtual_facts:
        assert isinstance(virtual_facts['virtualization_role'], str), \
            "virtualization_role should be a string, got %s instead" % \
            type(virtual_facts['virtualization_role'])

# Generated at 2022-06-11 05:39:36.689323
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector()

# Generated at 2022-06-11 05:41:04.086063
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    FreeBSDVirtualCollector()


# Generated at 2022-06-11 05:41:05.635297
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    collector = FreeBSDVirtualCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDVirtual

# Generated at 2022-06-11 05:41:06.839780
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    virt = FreeBSDVirtualCollector()
    assert virt is not None

# Generated at 2022-06-11 05:41:07.854475
# Unit test for constructor of class FreeBSDVirtualCollector
def test_FreeBSDVirtualCollector():
    assert FreeBSDVirtualCollector._platform == 'FreeBSD'

# Generated at 2022-06-11 05:41:17.184802
# Unit test for method get_virtual_facts of class FreeBSDVirtual
def test_FreeBSDVirtual_get_virtual_facts():
    # Override virtual functions
    VirtualSysctlDetectionMixin.detect_virt_product = lambda self, mib: {
        'virtualization_type': 'vbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    VirtualSysctlDetectionMixin.detect_virt_vendor = lambda self, mib: {
        'virtualization_type': 'vbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vbox']),
        'virtualization_tech_host': set(),
    }

    virtual_facts = FreeBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vbox'