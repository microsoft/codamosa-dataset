

# Generated at 2022-06-23 03:37:36.378999
# Unit test for function main
def test_main():
    from units.modules.utils import AnsibleExitJson
    from units.modules.utils import AnsibleFailJson
    import ansible.module_utils.action_common_attributes
    import ansible.module_utils.action_common_attributes.facts
    import ansible.module_utils.facts

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Fail the module with just a message
    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFail

# Generated at 2022-06-23 03:37:46.633297
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:37:55.385347
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils import basic
    from ansible.module_utils.common.dict_transformations import dict_merge
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six
    import re

    ########
    # Mock #
    ########

    # Mock ansible.module_utils.six.moves
    class MockSixMoves:
        StringIO = StringIO
    mock_six_moves = MockSixMoves()

    # Mock ansible.module_utils.six.PY2
    class MockSix():
        PY2 = True
    mock_six = MockSix()

    # Mock ansible.module_utils.six

# Generated at 2022-06-23 03:38:06.756745
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    module = get_module_mock(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    config = dict(database='passwd')
    module.params.update(config)
    func_name = 'ansible.module_utils.facts.system.getent.main'
    with patch(func_name) as mock_main:
        main()
        assert mock_main.called


# Generated at 2022-06-23 03:38:07.386182
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:38:09.168527
# Unit test for function main
def test_main():
    print ("unit tests for getent module")
    assert main()


# Generated at 2022-06-23 03:38:18.014103
# Unit test for function main
def test_main():
    modules_mock = {
        "ansible.module_utils.basic.AnsibleModule": AnsibleModule,
        "ansible.module_utils.basic.to_native": to_native,
    }

    main_mock = {
        "ansible.module_utils.basic.AnsibleModule.run_command": (0, "0\n1\n2\n3\n4\n5\n6", ""),
    }


# Generated at 2022-06-23 03:38:28.397330
# Unit test for function main
def test_main():
    # getent_bin not present
    def test_no_getent_bin():
        module = AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str', no_log=False),
                service=dict(type='str'),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )

        def get_bin_path_side_effect(path, required):
            raise Exception('no %s in PATH' % path)
        module.get_bin_path = mock.MagicMock(side_effect=get_bin_path_side_effect)


# Generated at 2022-06-23 03:38:40.413488
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.network import ModuleStub
    # Monkey patch module so it doesn't try to run commands
    basic._ANSIBLE_ARGS = ImmutableDict(
        connection='local',
        module_name='test_getent',
        module_args={},
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        verbosity=3,
        start_at_task=None,
    )
    basic._ANSIBLE_CHECKS = 1
    basic._ANSIBLE_MODULE_COMMON_AR

# Generated at 2022-06-23 03:38:52.863329
# Unit test for function main
def test_main():
    # skip test if getent is not available
    import os
    if os.system("getent > /dev/null 2>&1") != 0:
        return

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(required=True, type='str'),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock


# Generated at 2022-06-23 03:39:01.725428
# Unit test for function main
def test_main():
    # Mock module
    #
    # Note: the following lines could be replaced by the add_mock_arguments() call
    #
    # # The mock_module fixture provides an instance of the module class,
    # # with the common AnsibleModule boilerplate already taken care of.
    mock_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # This replaces:
    #   module = AnsibleModule(
    #       argument_spec=dict(
    #           # original arguments

# Generated at 2022-06-23 03:39:05.332615
# Unit test for function main
def test_main():
    # Test: module_utils.basic.ANSIBLE_VERSION is 2.4
    module_utils.basic.ANSIBLE_VERSION = 2.4
    # Test: Command rc == 0 and results as expected
    module_utils.basic.run_command = MagicMock(return_value=({'rc': 0, 'out': 'test1\ntest2', 'err': 'error'}))
    main()
    # Test: Command rc == 0
    module_utils.basic.run_command = MagicMock(return_value=({'rc': 0}))
    main()
    # Test: Command rc == 1
    module_utils.basic.run_command = MagicMock(return_value=({'rc': 1}))
    main()
    # Test: Command rc == 2
    module_utils.basic.run_command = MagicM

# Generated at 2022-06-23 03:39:19.371144
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
    )

    import os
    import tempfile
    import filecmp
    import shutil
    import json

    def rmfile(path):
        if os.path.exists(path):
            os.unlink(path)

    file_path = '/tmp/ansible_getent_file'

    test_module.params['database'] = file_path

# Generated at 2022-06-23 03:39:29.974874
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
    )

    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    for database in ['passwd', 'shadow', 'group', 'gshadow']:
        module.params['database'] = database
        main()
        assert module.exit_json.call_count == 1
        assert module.exit_json.call_args == mock.call

# Generated at 2022-06-23 03:39:31.373424
# Unit test for function main
def test_main():
    """
    Unit tests for function main
    """

    main()
test_main()

# Generated at 2022-06-23 03:39:43.611932
# Unit test for function main
def test_main():
  def getent_module_mock(module_params, check_mode=False, **kwargs):
    class ModuleResult(object):
      def __init__(self):
        self.rc = None
        self.out = b''
        self.err = b''
        self.changed = False
        self.failed = False
        self.msg = ''
        self.module_stdout = ''
        self.module_stderr = ''
        self.ansible_facts = {}

      def exit_json(self, **kwargs):
        self.ansible_facts = kwargs['ansible_facts']

      def fail_json(self, **kwargs):
        self.failed = True
        self.msg = kwargs['msg']


# Generated at 2022-06-23 03:39:44.753576
# Unit test for function main
def test_main():
    # TODO
    pass

# Generated at 2022-06-23 03:39:51.319964
# Unit test for function main
def test_main():
    import sys
    sys.path.append("/home/davidwhited/github/ansible/lib/ansible/module_utils/basic.py")
    sys.path.append("/home/davidwhited/github/ansible/lib/ansible/module_utils/_text.py")
    sys.path.append("/home/davidwhited/github/ansible/test/units/module_utils/test_getent.py")
    import test_getent
    assert test_getent.test_main()

# Generated at 2022-06-23 03:39:53.675190
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        if e.args[0] == 0:
            return
        raise

# Generated at 2022-06-23 03:40:04.957082
# Unit test for function main
def test_main():
    # main() method
    class AModule:
        def __init__(self):
            self.params = { 'database':'passwd',
                            'key':None,
                            'service':'foo-service',
                            'split':None,
                            'fail_key':True,
                         }
            self.exit_json_args = {'ansible_facts':{'getent_passwd':{}}}

# Generated at 2022-06-23 03:40:07.262741
# Unit test for function main
def test_main():
    # Getent should return 0 if passwd database exists
    assert main() == 0


# Generated at 2022-06-23 03:40:14.751834
# Unit test for function main
def test_main():
    # Test if getent_bin is defined
    getent_bin = module.get_bin_path('getent', True)

    # Test if cmd is defined
    cmd = [getent_bin, database, key]

    # create fake function
    def module_run_command(cmd):
        cmd
        return true
    # Set module.run_command to my fake function
    module.run_command = module_run_command
    # run main function
    main()

# Generated at 2022-06-23 03:40:24.232561
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:40:35.530310
# Unit test for function main
def test_main():
    args = dict(
        database='group',
        key='admin',
        service='LDAP',
        split=':',
        fail_key=False
    )
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)

    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, args['database'], args['key'], '-s', args['service']]

    dbtree = 'getent_%s' % args['database']
    results = {dbtree: {}}

    seen = {}

# Generated at 2022-06-23 03:40:45.937771
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:40:55.348162
# Unit test for function main
def test_main():
    import platform

    # Always stub load_platform_subclass
    import ansible.module_utils.facts.system.getent as getent_module
    getent_module.load_platform_subclass = lambda self, class_path, *args, **kwargs: dict()

    from ansible.module_utils.facts.system import getent
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 03:41:08.141029
# Unit test for function main
def test_main():
    dbtree = 'getent_passwd'
    results = {dbtree: {}}
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, 'passwd', 'root']
    seen = {}

# Generated at 2022-06-23 03:41:17.538650
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', defaul=True),
        ),
        supports_check_mode=True,
    )
    class MockPopen:
        def __init__(self, cmd, rc=0, out='', err=''):
            self.cmd = cmd
            self.rc = rc
            self.out = out
            self.err = err
        def communicate(self):
            return self.out, self.err
        def poll(self):
            return self.rc

# Generated at 2022-06-23 03:41:29.545936
# Unit test for function main
def test_main():

    # Test dict for command line arguments
    args = dict(
        database='group',
        key='wheel',
        split=':',
        fail_key=False,
    )

    # Dict for passing to AnsibleModule
    module_args = dict(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # AnsibleModule object
    module = AnsibleModule(**module_args)


# Generated at 2022-06-23 03:41:39.709974
# Unit test for function main
def test_main():

    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_module.run_command = MagicMock(return_value=(0, 'root:x:0:0:root:/root:/bin/bash', ""))
    test_module.params = {'database': 'passwd', 'key': 'root'}

    test_module.get_bin_path = MagicMock(return_value="/bin/getent")

    main()

    fact_list = test_module

# Generated at 2022-06-23 03:41:45.881345
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    main()
    main()

# Generated at 2022-06-23 03:41:58.987566
# Unit test for function main
def test_main():
    import json
    import tempfile
    import os.path

    main_test_file = tempfile.NamedTemporaryFile(prefix='ansible_getent_unit_test')

    records = (
        'spongebob:x:1001:1000::/home/spongebob:/bin/bash',
        'patrick:x:1002:1000::/home/patrick:/bin/bash',
        'squidward:x:1003:1000::/home/squidward:/bin/bash')

    for record in records:
        main_test_file.write(record + '\n')

    main_test_file.flush()


# Generated at 2022-06-23 03:42:08.160186
# Unit test for function main

# Generated at 2022-06-23 03:42:08.777319
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:42:18.601889
# Unit test for function main
def test_main():
    import sys
    import os
    import re

    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_text(args)

    def exit_json(*args, **kwargs):
        sys.exit(0)

    def fail_json(*args, **kwargs):
        sys.exit(1)

# Generated at 2022-06-23 03:42:28.596398
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str'),
            service = dict(type='str'),
            split = dict(type='str'),
            fail_key = dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    assert database == "passwd"
    assert key == "root"
    assert split == None
    assert service == None
    assert fail_key == "yes"

    assert database == "group"

# Generated at 2022-06-23 03:42:39.872109
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split = ':'


# Generated at 2022-06-23 03:42:50.674132
# Unit test for function main
def test_main():
    # Arguments from module
    module_args = dict(
        database='group',
        key='root',
        split=':',
        fail_key=True
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    ret_val = main()

    assert ret_val['ansible_facts']['getent_group']['wheel'] == ['root']
    assert ret_val['changed'] == False

# Generated at 2022-06-23 03:42:52.169329
# Unit test for function main
def test_main():
    #FIXME:
    pass

# Generated at 2022-06-23 03:43:07.111229
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
    )

    module.get_bin_path = lambda x, y: '/bin/getent'

    module.run_command = lambda x: (0, "root:x:0:0:root:/root:/bin/bash\n" +
                                    "user1:x:1001:1001::/home/user1:/bin/bash", '')

    module.exit_json = lambda x: x
    result = main()

# Generated at 2022-06-23 03:43:18.479296
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:43:25.586150
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        #supports_check_mode=True,
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    main()

# Generated at 2022-06-23 03:43:26.459175
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:43:38.578970
# Unit test for function main
def test_main():

    getent_bin = '/usr/bin/getent'

    pass_getent_bin = '/usr/bin/getent'

    fail_getent_bin = '/usr/bin/getent'

    fail_database = 'passwd'

    fail_key_database = 'passwd'

    fail_rc = 1

    fail_msg = "Missing arguments, or database unknown."

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:43:50.954163
# Unit test for function main
def test_main():
    import ansible.module_utils.facts.getent as getent
    ansible.module_utils.facts.getent = None
    args = {'database': 'passwd', 'key': 'root', '_ansible_module': None}
    try:
        getent.main()
    except Exception as e:
        print(e)
    args = {'database': 'group', 'key': 'root', '_ansible_module': None}
    try:
        getent.main()
    except Exception as e:
        print(e)
    args = {'database': 'group', 'key': 'root', 'split': ':', '_ansible_module': None}
    try:
        getent.main()
    except Exception as e:
        print(e)

# Generated at 2022-06-23 03:44:01.148296
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
    ))


# Generated at 2022-06-23 03:44:12.547747
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    cmd = [get_bin_path('getent')]
    if get_bin_path('getent') != None:
        # TODO: improve me
        rc, out, err = main({
            'database': 'passwd',
            'key': None,
            'split': None,
            'service': None
        })
        print(to_bytes(json.dumps(rc)))
    else:
        print("Cannot find getent executable in path")

# Generated at 2022-06-23 03:44:14.516738
# Unit test for function main
def test_main():
    assert callable(main)

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-23 03:44:25.669991
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-23 03:44:26.441530
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:44:32.288154
# Unit test for function main
def test_main():
    print("test_main")

    # Create variables like the one returned by AnsibleModule
    module = {}

    # Create variables like the ones passed to the main() function
    params = {}
    params['database'] = 'passwd'
    params['key'] = 'root'
    params['service'] = ''
    params['split'] = ''

    # Call main()
    main(module, params)

# Generated at 2022-06-23 03:44:44.911520
# Unit test for function main
def test_main():
    import inspect
    import re
    globals_dict = globals()

    # Python 3 has unicode, Python 2 doesn't
    unicode_type = type(to_native(''))
    module = globals_dict.get('module')

    def to_bytes(s):
        if isinstance(s, unicode_type):
            s = s.encode('utf-8')
        return s

    f_module = inspect.getmembers(module, inspect.isfunction)
    for (k, v) in f_module:
        if re.match("^_ansiballz_", k):
            continue
        elif k in ('basic', 'AnsibleModule'):
            continue

        _vv = v
        argspec = inspect.getargspec(v)
        args = argspec[0]

# Generated at 2022-06-23 03:44:54.258075
# Unit test for function main
def test_main():
    # test missing args
    module = Mock(
        params=dict(
            database='passwd',
            key="brian",
        ),
        run_command=Mock(
            return_value=(1, "", "")
        ),
        check_mode=False,
        exit_json=Mock(),
        fail_json=Mock()
    )
    main()
    module.fail_json.assert_called_once_with(msg='Missing arguments, or database unknown.')

    # test key missing

# Generated at 2022-06-23 03:44:58.820402
# Unit test for function main
def test_main():
    src = dict(database='passwd', key='root')
    out = dict(ansible_facts=dict(getent_passwd=dict(root=['x', '0', '0', 'root', '/root', '/bin/bash'])))
    module = AnsibleModule(argument_spec=src, supports_check_mode=True)
    assert True == main()(module, src, out)

# Generated at 2022-06-23 03:45:07.080335
# Unit test for function main
def test_main():
    try:
        args = {
            'database': 'passwd',
            'key': 'root',
            'service': None,
            'split' : ':',
            'check_mode' : False
        }
        module = AnsibleModule(argument_spec=args)
        m = module_getent.ActionModule(module)
        m.run(tmp=None, task_vars=dict(vars=args))
    except Exception as e:
        print('Exception: %s\n' % e)

# Generated at 2022-06-23 03:45:18.611524
# Unit test for function main
def test_main():
    # Test module argument_spec
    module_spec = {'database': {'required': True, 'type': 'str'},
                   'key': {'no_log': False, 'type': 'str'},
                   'service': {'type': 'str'},
                   'split': {'type': 'str'},
                   'fail_key': {'default': True, 'type': 'bool'},
                   '_ansible_check_mode': {'type': 'bool'},
                   '_ansible_diff': {'type': 'bool'},
                   '_ansible_verbosity': {'type': 'int'}
                   }

    # Test module argument_spec

# Generated at 2022-06-23 03:45:26.914555
# Unit test for function main
def test_main():
    # this might seem a bit of an odd test but its here to ensure the function executes
    # and the outputs match the expected values from the getent man page
    getent_bin = module.get_bin_path('getent', True)
    getent_cmd = [getent_bin, 'alias']

    # for now just test non-interactive, we do not support interactive data collection yet
    module = AnsibleModule(argument_spec={'interactive': {'type': 'bool', 'default': False}})

    action = importlib.import_module('ansible.modules.system.getent').ActionModule(module)
    action.run(task_vars=dict(ansible_facts=dict()))

# Generated at 2022-06-23 03:45:30.951470
# Unit test for function main
def test_main():
    # pylint: disable=import-error
    from ansible.modules.system import getent
    getent.main()

# Generated at 2022-06-23 03:45:44.168389
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-23 03:45:52.442965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-23 03:45:53.402824
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:54.286400
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:46:06.968940
# Unit test for function main
def test_main():
    run_result = []
    cmd_result = [0, "root:x:0:0:root:/root:/bin/bash\nroot:x:0:0:root:/tmp:/bin/bash\n", ""]
    mock_module = Mock(argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    mock_module.run_command = Mock(return_value=cmd_result)
    mock_module.exit_json = Mock()
    mock_module.fail_json = Mock()


# Generated at 2022-06-23 03:46:18.285173
# Unit test for function main
def test_main():
    """
    Test getent.main()
    """
    test_args = {
        "database": "passwd",
        "key": "root",
        "split": None,
        "_ansible_check_mode": False,
        "_ansible_diff": False,
        "_ansible_module": "test_main",
        "_ansible_version": "v2.7.0.dev0",
        "_ansible_no_log": False,
        "_ansible_verbosity": 0,
        "changed": False,
    }
    getent_bin = "/usr/bin/getent"

# Generated at 2022-06-23 03:46:27.593224
# Unit test for function main

# Generated at 2022-06-23 03:46:34.901830
# Unit test for function main
def test_main():
    class AnsibleModule:
        pass
    module = AnsibleModule()
    module.params = {'database': 'passwd', 'key': 'root', 'service': 'passwd', 'split': ':', 'fail_key': 'yes'}
    module.check_mode = False
    import os
    class ModuleUtils:
        def get_bin_path(self, command, required):
            return os.path.join(os.path.abspath(os.getcwd()), command)
    module.get_bin_path = ModuleUtils().get_bin_path
    import mock
    args = [os.path.join(os.path.abspath(os.getcwd()), 'getent'), 'root']
    rc = 0

# Generated at 2022-06-23 03:46:42.834756
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params['database'] = 'services'
    module.params['key'] = 'foo'
    module.params['service'] = 'tcp'
    module.params['split'] = ' '
    module.params['fail_key'] = False
    main()

# Generated at 2022-06-23 03:46:52.720946
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.python import AnsiblePythonModule

    module = AnsiblePythonModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ),
        supports_check_mode=True,
    )
    setattr(module, 'run_command', lambda x: (0, 'user:x:0:0:root:/root:/bin/bash', None))
    main()

# Generated at 2022-06-23 03:47:07.672096
# Unit test for function main
def test_main():
    import os
    import sys
    import imp
    import mock

    def run_command_mock(module, cmd, check_rc=True):
        """mock the module.run_command() method"""
        rc = 0
        out = err = ''
        return rc, out, err

    def get_bin_path_mock(module, name, required=True):
        """mock the module.get_bin_path() method"""
        return '/usr/bin/getent'

    sys.modules['ansible.module_utils.basic'] = imp.new_module('basic')
    sys.modules['ansible.module_utils.basic'].AnsibleModule = mock.Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.run_command = run_command_mock
   

# Generated at 2022-06-23 03:47:19.320079
# Unit test for function main

# Generated at 2022-06-23 03:47:27.025135
# Unit test for function main
def test_main():
    host_vars = {}
    reader = MockFileReader('passwd.txt')
    module_args = {'database': 'passwd', 'key': 'bcoca','split': ':'}
    ansible = AnsibleActionModule(reader, {}, host_vars, module_args)
    results = main()
    assert(results['ansible_facts']['getent_passwd']['bcoca']['shell'] == '/bin/bash')


# Generated at 2022-06-23 03:47:28.861274
# Unit test for function main
def test_main():
    test_module = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )
    main()
    assert True

# Generated at 2022-06-23 03:47:38.745444
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str', required=False),
            split=dict(type='str', required=False),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path