

# Generated at 2022-06-23 03:37:30.348719
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:37:39.009672
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils import action
    import sys

    # hackish:
    sys.modules['ansible.module_utils.action'] = action

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')

# Generated at 2022-06-23 03:37:42.629615
# Unit test for function main
def test_main():
    import tempfile


# Generated at 2022-06-23 03:37:49.465834
# Unit test for function main
def test_main():

    # import getent
    module = AnsibleModule(
            argument_spec=dict(
                database=dict(type='str'),
                key=dict(type='str'),
                service=dict(type='str'),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )

    # getent.main()
    module.exit_json(changed=False, meta={
        'some': 'meta'
    })


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:37:59.293981
# Unit test for function main
def test_main():
    """
    Ansible return values and arguments look like:
    {
        "ansible_facts": {"test_result": []},
        "changed": True,
        "invocation": {
            "module_args": {
                "key": None,
                "split": None,
                "service": None,
                "database": "passwd"
            }
        },
        "failed": True,
        "msg": "foo"
    }
    {'ansible_facts': {"test_result": []},
        'failed': True,
        'invocation': {'module_args': {
            'key': None,
            'split': None,
            'service': None,
            'database': 'passwd'
        }},
        'msg': 'foo'}
    """

    # Fails:
    # Skip

# Generated at 2022-06-23 03:38:03.418092
# Unit test for function main
def test_main():
    monkeypatch.setattr("os.path.exists", lambda x: True)
    monkeypatch.setattr("os.access", lambda x, y: True)
    monkeypatch.setattr("os.geteuid", lambda *args, **kwargs: os.getuid())
    res = main()
    assert res == None

# Generated at 2022-06-23 03:38:13.981646
# Unit test for function main
def test_main():
    import pytest
    import sys
    from ansible.modules.system.getent import getent_bin


# Generated at 2022-06-23 03:38:15.480584
# Unit test for function main
def test_main():
    # import getent
    # print(getent.mai)
    pass

# Generated at 2022-06-23 03:38:23.506743
# Unit test for function main
def test_main():

    key = 'test.com'
    database = 'hosts'

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
        ),
    )

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    test_values = module.run_command(cmd)

    assert test_values[0] == 0

# Generated at 2022-06-23 03:38:33.657366
# Unit test for function main
def test_main():
    import sys
    import os

    # Make sure we are running as root
    if os.geteuid() != 0:
        sys.exit("This test must be run as root")

    import inspect
    import datetime

    # Save current system state for later recovery
    backup_path = '/tmp/%s-%s-%d.yaml' % (inspect.stack()[0][3],
                                          os.path.basename(__file__),
                                          os.getpid())

# Generated at 2022-06-23 03:38:44.085967
# Unit test for function main
def test_main():
    # prepare variables
    class module:

        class exit_json:
            def __init__(self, facts, msg=''):
                # return facts as results
                self.facts = facts

        def run_command(self, command):
            return 0, '', ''

        def get_bin_path(self, command, required):
            return '/bin/' + command

        def fail_json(self, msg, exception):
            self.failure_msg = msg
            self.faiure_exception = exception

    module = module()

    # run function main
    main()

    # check results
    assert module.facts['getent_hosts'] == {}

    # prepare variables
    module.params = dict()
    module.params['database'] = 'hosts'
    module.params['key'] = 'localhost'

   

# Generated at 2022-06-23 03:38:46.693496
# Unit test for function main
def test_main():
    assert getent_bin == '/usr/bin/getent'
    assert key == None
    assert split == None
    assert database == 'hosts'

# Generated at 2022-06-23 03:38:57.726186
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.facts import Facts

    # prepare the test input data
    arguments = {
        'database': 'passwd',
        'key': '',
        'service': '',
        'split': None,
        'fail_key': 'yes'
    }

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:39:05.802702
# Unit test for function main
def test_main():
    import ansible.errors
    from ansible.module_utils._text import to_bytes

    class ModuleStub(object):

        def __init__(self, params):
            self.params = params
            self.fail_json = self.fail

        def fail(self, msg):
            raise ansible.errors.AnsibleModuleError(msg)

        def get_bin_path(self, arg, required):
            if arg != 'getent':
                raise AssertionError('Unexpected arg value %s' % arg)
            return '/usr/bin/getent'

        @staticmethod
        def run_command(cmd):
            """Fake run_command
            :param cmd: the command to run
            :return: (rc, out, err)
            """

            # Note: The command passed to run_command will be bytes b

# Generated at 2022-06-23 03:39:19.643889
# Unit test for function main
def test_main():
    import re
    import StringIO

    # First mock ansible module and its properties
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

   

# Generated at 2022-06-23 03:39:29.163576
# Unit test for function main
def test_main():
    import tempfile
    import os
    import sys

    test_args = type('args', (object,), {"database": "test",
                     "key": "key",
                     "service": "",
                     "split": None,
                     "fail_key": False,
                     })

    test_rc = 0
    test_out = "test:test:test:test:test"
    test_err = None

    test_dbtree = "getent_test"
    test_results = {test_dbtree: {}}
    test_results[test_dbtree]["test"] = ["test", "test", "test", "test"]


# Generated at 2022-06-23 03:39:40.240031
# Unit test for function main
def test_main():
    import tempfile
    from ansible.module_utils import basic
    from ansible_collections.ansible.community import tests

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    with tempfile.TemporaryFile('w+') as tmp:
        #set up a temp file with values
        tmp.write('# this is a testfile\n')
        tmp.write('one:two:three:four:five:six:seven:eight\n')
        tmp.write('one:two:three:four:five:six:seven:eight2\n')

# Generated at 2022-06-23 03:39:42.160551
# Unit test for function main
def test_main():
    # Arrange
    import sys, os
    sys.argv = ['getent', '-h']
    # Act
    main()

# Generated at 2022-06-23 03:39:52.734843
# Unit test for function main
def test_main():
    #Module import
    from ansible.modules.system.getent import getent_module

    # Test a valid command
    module = getent_module({
        "database": "passwd",
        "key": "root"
    })
    db_name = 'getent_%s' % module.params['database']
    assert module.run_command([module.get_bin_path('getent', True), module.params['database'], module.params['key']]) == module.run_command(module.cmd) # Test function from module_utils/basic.py and run_command from module_utils/basic.py of ansible
    assert module.result['ansible_facts'][db_name] == {'root': ['x', 0, '0', 'root', '/root', '/bin/bash']}
    assert module.result

# Generated at 2022-06-23 03:40:04.103507
# Unit test for function main
def test_main():
    import getent
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = lambda *args, **kwargs: (0, "", "")
    module.get_bin_path = lambda *args, **kwargs: "/bin/getent"

    result = getent.main()
    assert result['ansible_facts']['getent_localhost'].keys() == ['localhost']
   

# Generated at 2022-06-23 03:40:16.198966
# Unit test for function main
def test_main():
    #from ansible.module_utils import basic
    #import ansible.module_utils.common
    #import ansible.module_utils.basic
    #from ansible.module_utils._text import to_native, to_bytes
    #import ansible.module_utils.action_common
    #from ansible.module_utils.action_common import EnvDict
    #import ansible.module_utils.facts
    #import ansible.module_utils.facts
    #from ansible.module_utils.facts import cacheable
    #from ansible.plugins.action import ActionBase
    from ansible.utils.boolean import boolean
    #import ansible.module_utils.six.moves.builtins
    #from ansible.vars.hostvars import HostVars
    #from ansible.vars.manager import

# Generated at 2022-06-23 03:40:18.643912
# Unit test for function main
def test_main():
    # run main() to test the getent module
    main()

# Generated at 2022-06-23 03:40:27.185395
# Unit test for function main
def test_main():
    class TestModule():
        def __init__(self):
            self.check_mode = False
            self.exit_json = print
            self.fail_json = print
            self.params = {'database': 'passwd',
                           'key': 'root',
                           'fail_key':'True',
                           'service': None}

    module = TestModule()
    getent_bin = module.get_bin_path('getent', True)
    if not getent_bin:
        print('getent_bin not found')
        return

    main()

# Generated at 2022-06-23 03:40:35.866706
# Unit test for function main
def test_main():
    test_getent_bin = '/usr/bin/getent'
    test_database = 'passwd'
    test_key = 'grep'
    test_split = ':'
    test_result = {'ansible_facts' : {'getent_passwd' : {'grep': ['grep', '15', '0', 'group', '/', '/bin/grep']}}}
    rc, out, err = main(test_getent_bin, test_database, test_key, test_split)
    assert rc is not None
    assert out is not None
    assert err is not None
    assert result == test_result
    return 0


# Generated at 2022-06-23 03:40:46.176391
# Unit test for function main
def test_main():
    getent_service_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if service is not None:
        cmd.extend(['-s', service])

    if split is None and database in colon:
        split = ':'

    try:
        rc, out, err = module.run_command(cmd)
    except Exception as e:
        module.fail_json(msg=to_native(e), exception=traceback.format_exc())

    msg = "Unexpected failure!"
    dbtree = 'getent_%s' % database
    results = {dbtree: {}}

    if rc == 0:
        seen = {}

# Generated at 2022-06-23 03:40:55.530845
# Unit test for function main
def test_main():
    result = {}
    # Test execution
    module = AnsibleModule(dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
    ))
    is_error, has_changed, result = main()
    assert not is_error
    assert has_changed
    assert result['getent_passwd'] == {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}
    assert result['getent_hosts'] == {'127.0.0.1': ['localhost.localdomain', 'localhost'], '::1': ['localhost.localdomain', 'localhost']}

# Generated at 2022-06-23 03:41:08.309065
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type = 'str', required = True),
            key = dict(type = 'str', no_log = False),
            service = dict(type = 'str'),
            split = dict(type = 'str'),
            fail_key = dict(type = 'bool', default = True),
        ),
        supports_check_mode = True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-23 03:41:15.220813
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def _getent_bin(path, required):
        return 'getent'

    with mock.patch.object(module, 'get_bin_path', _getent_bin):
        result = main()

# Generated at 2022-06-23 03:41:23.684923
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    my_basic = basic.AnsibleBasic()
    basic._ANSIBLE_ARGS = None

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params['database'] = 'hosts'
    module.params['key'] = None
    module.params['split'] = None

# Generated at 2022-06-23 03:41:34.689529
# Unit test for function main
def test_main():

    result = {
        'ansible_facts': {
            'getent_passwd': {
                'root': ['x', '0', '0', 'root', '/root', '/bin/bash']
            }
        },
        'changed': False
    }

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
    )

    module.run_command = lambda cmd, **kwargs: (0, 'root:x:0:0:root:/root:/bin/bash', '')

    module.params['database'] = 'passwd'
    module.params['key']

# Generated at 2022-06-23 03:41:35.267411
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:41:45.933527
# Unit test for function main
def test_main():
    # Usecase 1
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        )
    )
    module.run_command = MagicMock(return_value=(0, 'a:a\nb:b', ''))
    main()

    # Usecase 2

# Generated at 2022-06-23 03:41:58.976687
# Unit test for function main
def test_main():
    # This test only works when run under ansible test
    import ansible.utils.module_docs as mod_docs
    from ansible.module_utils import basic

    test_data = dict(
        database='passwd', key='root', split=' ', fail_key=True
    )
    module_args = mod_docs.AnsibleDocs._normalize_module_arguments(basic.AnsibleModule, test_data)
    module_args['database'] = 'passwd'
    module_args['key'] = 'root'
    module_args['split'] = ' '
    module_args['fail_key'] = True

    module = AnsibleModule(**module_args)

    getent_bin = module.get_bin_path('getent', True, ['/bin', '/usr/bin'])


# Generated at 2022-06-23 03:42:08.122697
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # we fake we are on a posix machine
    module.platform = "posix"
    # we fake the getent binaries path
    module.get_bin_path = lambda x,y: "/bin/getent"
    # we fake the command module call to only get the results
    # and not trigger any side effects

# Generated at 2022-06-23 03:42:17.980312
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # create the module
    module = AnsibleModule(
        dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
    )

    # create a dummy class to hold module 'self'
    class Q(object):
        def __init__(self, a_module):
            self.module = a_module

        def run_command(self, command_string, check_rc=True):
            import subprocess

            # handle old version of subprocess

# Generated at 2022-06-23 03:42:20.104987
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        main()
    assert 'Unexpected failure!' in str(excinfo.value)

# Generated at 2022-06-23 03:42:29.845954
# Unit test for function main
def test_main():
    import ansible.module_utils.facts.getent as getent
    reload(getent)

    content = """root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/bin/bash
daemon:x:2:2:daemon:/sbin:/bin/bash
http:x:33:33:http:/var/www:/bin/bash"""
    getent.getent_bin = '/bin/getent'
    m = getent.AnsibleModule(dict(database='passwd', split=':'))
    m.run_command = lambda cmd: (0, content, '')
    try:
        results = getent.main()
        assert False
    except SystemExit as ex:
        assert ex.code == 0


# Generated at 2022-06-23 03:42:41.535396
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_native

    # mock module run_command
    def command_run_command(cmd):
        results = [
            # 0 - unknown database
            (0, '', 'Unexpected failure'),
            # 1 - ok
            (1, 'a\tb\tc\n', ''),
            # 2 - key not found
            (2, '', 'One or more supplied key could not be found in the database.'),
            # 3 - unknown database
            (3, '', 'Enumeration not supported on this database.'),
        ]
        return results[0]

    module = Ans

# Generated at 2022-06-23 03:42:51.215224
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.cloud.common.utils import AnsibleCloudModule
    from ansible.module_utils.cloud.common.process import AnsibleCloudProcess

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    exit_args = dict(
        ansible_facts=dict(
            test=True
        )
    )
    res_args = dict(
        changed=False
    )

    cloud

# Generated at 2022-06-23 03:42:52.057965
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:43:06.928315
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible.module_utils import getent
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text
    import sys

    # getent.py - test cases

# Generated at 2022-06-23 03:43:18.334293
# Unit test for function main
def test_main():
    # missing argument
    def test_missing_arg(module):
        fixtures = [
            (1, "Missing arguments, or database unknown.", "", "Missing arguments, or database unknown.\n"),
            (2, "One or more supplied key could not be found in the database.", "", "One or more supplied key could not be found in the database.\n")
        ]

    def test_arg(module, database, key, fail_key=True, split=None, service=None, ret_answer=[]):
        fixtures = [
            (0, "", "", ""),
        ]

        mock_getent_bin = MagicMock(return_value=True)
        mock_run_command = MagicMock(return_value=(0, "", ""))
        # moqing out the module object is necessary since it's used as a


# Generated at 2022-06-23 03:43:25.828246
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'database': {'required': True, 'type': 'str'}, 'key': {'no_log': False, 'type': 'str'}, 'service': {'type': 'str'}, 'split': {'type': 'str'}, 'fail_key': {'type': 'bool', 'default': True}})
    module.exit_json = lambda x: x
    assert 'getent_' in module.run_command(main())['ansible_facts'].keys()[0]

# Generated at 2022-06-23 03:43:33.773905
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-23 03:43:37.784588
# Unit test for function main
def test_main():
    # This is a test stub to make sure ansible is properly setup to run testing
    # on the platform.
    #
    # This will cause the module to exit with a failure.
    assert False


# Generated at 2022-06-23 03:43:49.652491
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic

    module_args = dict(
        database='passwd',
        key='root',
        fail_key=True,
    )
    basic._ANSIBLE_ARGS = ['-m', 'getent', '-a', module_args]

    m = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = m.get_bin_path('getent', True)


# Generated at 2022-06-23 03:44:00.830071
# Unit test for function main
def test_main():
    from ansible.main import main as ansible_main
    from ansible.module_utils.basic import AnsibleModule

    def run_command_mock(cmd, **kwargs):
        if cmd[-1] == 'hosts':
            return (0, '127.0.0.1\tlocalhost', '')
        elif cmd[-1] == 'passwd':
            return (0, 'root:x:0:0:root:/root:/bin/bash', '')

# Generated at 2022-06-23 03:44:07.488443
# Unit test for function main
def test_main():
    test_args = {
        "database": "/etc/passwd",
    }
    test_ansible_facts = {
    }
    module = AnsibleModule(argument_spec=test_args)
    results = main()
    assert type(results['changed']) == type(False)
    assert type(results['failed']) == type(False)
    assert type(results['ansible_facts']) == type({})
    assert results['ansible_facts'] == test_ansible_facts

# Generated at 2022-06-23 03:44:19.035430
# Unit test for function main
def test_main():
    import subprocess
    import sys
    import os
    import tempfile

    # get tempfile from the system
    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd)

    # get system's getent
    try:
        getent_bin = subprocess.check_output(['which', 'getent']).strip()
    except Exception as e:
        # no getent binary, skip test
        print('Cannot find getent, skipping tests', file=sys.stderr)

# Generated at 2022-06-23 03:44:25.669591
# Unit test for function main
def test_main():
    args = dict(
        database='passwd'
    )
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=args)
    main()
    m.fail_json = Mock()
    m.run_command = Mock(side_effect=[
        (0, 'test\n', None)
    ])
    try:
        main()
    except AssertionError:
        pass

# Generated at 2022-06-23 03:44:32.493417
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    getent_bin = module.get_bin_path('getent')
    assert getent_bin


# Generated at 2022-06-23 03:44:45.150669
# Unit test for function main
def test_main():

    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from cStringIO import StringIO

    from ansible.module_utils.basic import AnsibleModule, ModuleStub
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import from_module

    FAKE_OUTPUT = """
reva:x:501:501::/home/reva:/bin/bash
alex:x:502:502::/home/alex:/bin/bash
"""

    # Set up ModuleStub and create a default AnsibleModule
    module_stub = ModuleStub()
    sys.modules['ansible.module_utils.basic'] = module_stub
    module = AnsibleModule(argument_spec=dict())
    module.exit

# Generated at 2022-06-23 03:44:57.334056
# Unit test for function main
def test_main():

    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils._text as to_native
    from ansible.module_utils.basic import ModuleFileDeprecatedWarning

    # Force only the second option to be selcted:
    database='passwd'
    key = 'toor'
    split = None
    service = None
    fail_key = None

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if service is not None:
        cmd.extend(['-s', service])

    if split is None and database in colon:
        split = ':'

   

# Generated at 2022-06-23 03:45:00.016429
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:09.918274
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-23 03:45:22.030152
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:45:22.572248
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:45:26.262002
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    from ansible.module_utils.six import PY2

    pytest.main(args=[os.path.join(os.path.dirname(__file__), 'unit/unit_getent.py')])

    if PY2:
        os.remove('unit/unit_getent.py')

# Generated at 2022-06-23 03:45:42.097101
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    sys.modules['__main__'].__file__ = 'test'
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:45:51.908078
# Unit test for function main

# Generated at 2022-06-23 03:46:02.509783
# Unit test for function main
def test_main():
    '''
    Test main
    '''
    # test_main.py
    module = AnsibleModule({
        'database': 'passwd',
        'key': 'root'
    })

    msg = 'Unexpected failure!'

    results = {
        "ansible_facts": {
            "getent_passwd": {
                "root": ["x", "0", "0", "root", "/root", "/bin/bash"]
            }
        }
    }

    assert main() == results
    assert main() is not msg

# Generated at 2022-06-23 03:46:14.676267
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test.get_bin_path = lambda *args: '/usr/bin/getent'

    test.run_command = lambda *args: (0, 'test:test:123', '')

    res = main()
    assert res['ansible_facts']['getent_test']['test'] == ['test', '123']

# Generated at 2022-06-23 03:46:18.590299
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    return module.exit_json(ansible_facts={})

# Generated at 2022-06-23 03:46:30.916140
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)
    

# Generated at 2022-06-23 03:46:41.967954
# Unit test for function main
def test_main():
    import sys
    sys.path.append(".")

    def fake_command(*_):
        return (0, "aaa:111:111:a:/tmp/a:/bin/sh\nbbb:222:222:b:/tmp/b:/bin/sh\nccc:333:333:c:/tmp/c:/bin/sh", "")

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda a: sys.exit(1)
            self.exit_json = lambda a: sys.exit(0)

        def run_command(self, *_):
            return fake_command(*_)

        def get_bin_path(self, *_):
            return '/bin/getent'


# Generated at 2022-06-23 03:46:53.254866
# Unit test for function main
def test_main():
    # Import test requirements here
    import os

    class AnsibleModuleFake:
        params = {}
        check_mode = False
        no_log = False

        class Failure: pass
        class SkipAnsibleModuleExit: pass

        def __init__(self, *args, **kwargs):
            return

        def __getattr__(self, *args, **kwargs):
            return

        def __call__(self, *args, **kwargs):
            return


        def exit_json(self, *args, **kwargs):
            return

        def fail_json(self, *args, **kwargs):
            raise self.Failure()

        def skip_ansible(self, *args, **kwargs):
            raise self.SkipAnsibleModuleExit()


    class AnsibleModuleExitJson: pass

# Generated at 2022-06-23 03:47:01.332857
# Unit test for function main
def test_main():
    test_cases = [
        {
            "database": "passwd",
            "key": 'root',
            "result": {
                "getent_passwd": {
                    "root": ["x",0,"0","0","root","/root","/bin/bash"]
                }
            }
        },
        {
            "database": "passwd",
            "key": 'johndoe',
            "result": {
                "getent_passwd": {
                    "johndoe": ["x",1001,1001,1001,"John Doe","/home/johndoe","/bin/bash"]
                }
            }
        }
    ]
    import json
    import tempfile
    import os
    import subprocess
    import sys

    tmpdir = tempfile.mkdtemp()

    # create a small

# Generated at 2022-06-23 03:47:05.616158
# Unit test for function main
def test_main():
    data = {}

    data['database'] = 'passwd'
    data['key'] = 'admin'

    with mock.patch('ansible.module_utils.basic.AnsibleModule') as am:
        am.params = data
        module = am
        main()

# Generated at 2022-06-23 03:47:11.522460
# Unit test for function main
def test_main():
    HTML = """
<html>
    <body>
        <h1 id="main">
            Hello ansible
        </h1>
    </body>
</html>
"""
    soup = BeautifulSoup(HTML, "html.parser")

    main()

# Generated at 2022-06-23 03:47:26.396020
# Unit test for function main
def test_main():
    def ansible_module_run_command_test(cmd, check_rc=True):
        if cmd[0] == '/usr/bin/getent' and cmd[1] == 'passwd':
            return (0, 'root:x:0:0:root:/root:/bin/bash\n', '')
        else:
            return (1, '', 'error')

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    module.run_command = ansible_module_run_command_test
    main()

# Generated at 2022-06-23 03:47:36.632389
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule
    class AnsibleModule(object):
        def __init__(self, argument_spec={}, **kwargs):
            self.params = {}
            self.params.update(argument_spec)
            self.params.update(kwargs)

        def fail_json(self, *args, **kwargs):
            print("FAIL:" + args[0])
            exit(1)

        def exit_json(self, *args, **kwargs):
            print("OK")
            exit(0)

        def get_bin_path(self, *args, **kwargs):
            return "getent"
