

# Generated at 2022-06-23 03:37:42.083025
# Unit test for function main
def test_main():
    import json
    import shutil
    import tempfile
    import subprocess

    def run_module(*args, **kw):
        if 'CHECKMODE' in os.environ:
            del os.environ['CHECKMODE']

        module_args = {
            'database': '__unit_test__',
            'key': 'some_key',
            'fail_key': True,
            'split': ':',
        }
        module_args.update(kw)
        set_module_args(module_args)
        result = AnsibleModule(argument_spec={"database": dict(type='str', required=True), "key": dict(type='str'), "split": dict(type='str')}, supports_check_mode="yes").exit_json(changed=False, ansible_facts=dict(k=1))
        return

# Generated at 2022-06-23 03:37:51.397841
# Unit test for function main
def test_main():
    import sys
    import os
    import io
    import unittest

    sys.stdout = io.StringIO()

    args = dict(
        database='database',
    )
    dicts = dict(
        getent_database={}
    )

    local_argv = ['getent', 'database']
    local_rc = 1

    return_values = dict(
        ansible_facts=dicts
    )

    original_run_command = AnsibleModule.run_command
    def run_command_mock(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        return local_rc, '', ''

    Ans

# Generated at 2022-06-23 03:38:01.163722
# Unit test for function main
def test_main():
    def run_command(module, cmd):
        return 0, '127.0.0.1 localhost\n::1 localhost6', None

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = run_command
    module.params = {'database': 'hosts'}

    main()

    result = module.exit_json

# Generated at 2022-06-23 03:38:07.947904
# Unit test for function main
def test_main():
    data = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
    }
    module = AnsibleModule(argument_spec={
        "database": {"type": "str", "required": True},
        "key": {"type": "str", "no_log": False},
        "split": {"type": "str"},
        "fail_key": {"type": "bool", "default": None}
    })
    for key, val in data.items():
        setattr(module.params, key, val)
    main()

# Generated at 2022-06-23 03:38:16.478842
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    test_dir = os.path.dirname(__file__)
    unit_test_dir = os.path.join(test_dir, 'unit')
    sys.path.insert(0, unit_test_dir)
    from ansible_collections.community.general.tests.unit.compat import unittest, mock
    from ansible_collections.community.general.plugins.modules import getent

    with open(os.path.join(unit_test_dir, 'fixtures', 'getent.json')) as f:
        fixture_data = json.loads(f.read())
    print(fixture_data)

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._

# Generated at 2022-06-23 03:38:17.002965
# Unit test for function main
def test_main():
    return True

# Generated at 2022-06-23 03:38:29.969491
# Unit test for function main
def test_main():
    ''' Test the module '''
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'database': dict(type='str', required=True),
            'key': dict(type='str', no_log=False),
            'split': dict(type='str'),
            'fail_key': dict(type='bool', default=True),
        },
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin

# Generated at 2022-06-23 03:38:41.777078
# Unit test for function main
def test_main():
    import platform
    import sys
    import os

    # generate the test environment
    # for getent

    USER = "alice"
    # generate the passed context
    class Context():
        def __init__(self):
            from io import StringIO
            self.ansible_facts = {}
            self.stdout = StringIO()
            self.stderr = StringIO()
            self.call_args = {"database": "passwd", "key": USER}
            self.rc = 0
            self.platform = platform.system()
            self.system = self.platform

    # generate the decision vars
    class Vars():
        def __init__(self):
            self.ansible_facts = {}
            self.getent_bin = "/usr/bin/getent"

# Generated at 2022-06-23 03:38:53.820736
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=False,
    )
    print("Testing module=%s" % module)

    main()
    # test module args
    data = module.params

    if data['database'] == 'passwd':
        main()
        assert data['database'] == 'passwd'
        assert data['key'] == ''
        assert data['split'] == ':', "passwd should split by colon"
        assert data['fail_key'] == False, "should return user bob"

    if data['database'] == 'group':
        main()
        assert data['database']

# Generated at 2022-06-23 03:39:02.082576
# Unit test for function main
def test_main():
    # First test when the module is called with all the arguments provided
    # and the expected result is returned
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True, default='passwd'),
            key=dict(type='str', no_log=False, default='root'),
            service=dict(type='str'),
            split=dict(type='str', default=':'),
            fail_key=dict(type='bool', default=True),
            ),
        supports_check_mode=True,
        )
    assert main() == 0

# Generated at 2022-06-23 03:39:11.195096
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    
    getent_bin = module.get_bin_path('getent', True)

    # Unit test: getent_bin
    assert getent_bin == '/usr/bin/getent'


    module.fail_json(msg=msg)
    module.exit_json(ansible_facts=results)

# Generated at 2022-06-23 03:39:22.702676
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    my_args = dict(
        database='passwd',
        key='root',
        service=None,
        split=None,
        fail_key=True
    )
    my_mock_module = basic.AnsibleModule({}, **my_args)
    my_mock_module.params = my_args
    assert main() == {
        "ansible_facts": {
            "getent_passwd": {
                "root": [
                    "x",
                    "0",
                    "0",
                    "root",
                    "/root",
                    "/bin/bash"
                ]
            }
        }
    }


# Generated at 2022-06-23 03:39:32.241395
# Unit test for function main
def test_main():

    import os

    import ansible.module_utils.basic

    from ansible_collections.community.general.tests.unit.compat.mock import patch

    def mock_get_bin_path(name, required):
        return 'getent'

    class AnsibleFailJson(Exception): pass
    class AnsibleExitJson(Exception): pass


# Generated at 2022-06-23 03:39:41.739308
# Unit test for function main
def test_main():
    db = 'passwd'
    test_key = 'root'
    data = dict(
        key = test_key,
        database = db,
        split = ':',
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    result = main()
    assert result['ansible_facts']['getent_%s'%db][test_key] == ['x', '0', '0', 'root', '/root', '/bin/bash']

# Generated at 2022-06-23 03:39:50.690897
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil

    # Temp dir for test files
    cwd = tempfile.mkdtemp()

    # Paths to files we create
    ex = os.path.join(cwd, "test")

    # Fake files
    f = open(ex, "w")
    f.write("Hello\n")
    f.close()

    f = open(ex, "r")
    result = f.read()
    f.close()
    assert result == "Hello\n"

    # Remove temp files
    shutil.rmtree(cwd)
    assert os.path.isdir(cwd) == False

# Generated at 2022-06-23 03:39:51.800651
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:39:52.477367
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:40:00.539413
# Unit test for function main
def test_main():
    def get_user_confirmation(question,response_list=False,default=False):
        return True

    from ansible.utils.path import which
    from ansible.module_utils.basic import AnsibleModule

    if which('getent'):
        testdata = {
            'database': 'aliases',
            'key': 'root',
            'fail_key': False,
            'split': ':'
        }

        x = AnsibleModule(argument_spec=testdata)
        x.params.update(testdata)
        main()


# Generated at 2022-06-23 03:40:02.046792
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)

# Generated at 2022-06-23 03:40:02.951392
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:40:13.584750
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "database": "passwd",
        "key": "root",
    },  check_invalid_spec=True)
    test_module.exit_json = exit_json
    test_module.fail_json = fail_json

    tmp_path = tempfile.mkdtemp()
    bin_path = os.path.join(tmp_path, "bin")
    os.mkdir(bin_path)

    getent_path = os.path.join(bin_path, "getent")
    with open(getent_path, "w") as getent_file:
        getent_file.write("#!/bin/sh\ncat /etc/passwd | grep $2")
    os.chmod(getent_path, 0o777)

# Generated at 2022-06-23 03:40:16.198257
# Unit test for function main
def test_main():

    with pytest.raises(SystemExit):
        import ansible.modules.system.getent as getent
        getent.main()


# Generated at 2022-06-23 03:40:28.395285
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:40:37.134544
# Unit test for function main
def test_main():
    def test_run_command(self):
        return_code = self['rc']
        out = "::%s::" % self['stdout']
        err = "::%s::" % self['stderr']
        return (return_code, out, err)

    # Mock the getent command
    getent_bin = "/usr/bin/getent"
    import ansible.module_utils.basic

    current = './ansible/module_utils/basic.py'
    old = './tests/support/basic.py'
    ansible.module_utils.basic = __import__('basic')

    ansible.module_utils.basic.get_bin_path = lambda x, y: getent_bin
    ansible.module_utils.basic.run_command = test_run_command

    # Mock Ansible

# Generated at 2022-06-23 03:40:42.860250
# Unit test for function main
def test_main():
    test_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )

    module = AnsibleModule(argument_spec=test_spec)

    main()

# Generated at 2022-06-23 03:40:46.654184
# Unit test for function main
def test_main():
    testargs = ['-v']
    main(testargs[1])

# Generated at 2022-06-23 03:40:56.061143
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Save the original get_bin_path method
    original_bin_path = module.get_bin_path

    # Mock the module.get_bin_path method
    def get_bin_path(path, required=True):
        return "/bin/getent"

    # Replace the module.get_bin_path method with our mock_get_bin_path method
    module.get_bin_path = get_bin_path

# Generated at 2022-06-23 03:41:09.338507
# Unit test for function main
def test_main():
    test_data = {
        'database': 'passwd',
        'key': 'root',
        'service': '',
        'split': None,
        'fail_key': True,
    }

    # test with rc == 0
    module = AnsibleModule(argument_spec={'database': {'type': 'str', 'required': True}, 'key': {'type': 'str', 'no_log': False}, 'service': {'type': 'str'}, 'split': {'type': 'str'}, 'fail_key': {'type': 'bool', 'default': True}})
    module.exit_json = exit_json
    module.run_command = run_command
    module.params = test_data
    main()

    # test with rc == 1
    test_data['key'] = None
    module.params

# Generated at 2022-06-23 03:41:25.694857
# Unit test for function main
def test_main():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    from action_plugins.getent import main

    global module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    global mock_getbin
    mock_getbin = lambda x: "/bin/getent"

    global mock_command

# Generated at 2022-06-23 03:41:26.047709
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:41:36.837289
# Unit test for function main
def test_main():
    # Test all databases, one key, split and no split
    testargs = [
        {'database': 'services', 'key': 'http', 'split': '\t'},
    ]

    for args in testargs:
        module = AnsibleModule(argument_spec=args)

        getent_bin = module.get_bin_path('getent', True)
        cmd = [getent_bin, args['database'], args['key']]

        if args.get('service'):
            cmd.extend(['-s', arg['service']])

        rc, out, err = module.run_command(cmd)

        dbtree = 'getent_%s' % args['database']
        result = {dbtree: {args['key']: out.split(args['split'])}}

        assert rc == 0


# Generated at 2022-06-23 03:41:38.725015
# Unit test for function main
def test_main():
    print("TODO")

# Generated at 2022-06-23 03:41:49.598323
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(required=True),
            key=dict(no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    dbtree = 'getent_%s' % database
    if key is not None:
        if database in ['passwd']:
            results = {"getent_passwd": {"root": ["x", "0", "0", "root", "/root", "/bin/bash"]}}
       

# Generated at 2022-06-23 03:42:01.326575
# Unit test for function main
def test_main():
    import os
    import sys

    # below is to make sure a fake path is not in PYTHONPATH
    os.environ['PYTHONPATH'] = ''

    # add library for unittest
    library_path = os.path.realpath(os.path.dirname(os.path.realpath(__file__)) + '/../library')
    sys.path.append(library_path)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.pycompat24 import get_exception



# Generated at 2022-06-23 03:42:14.260872
# Unit test for function main
def test_main():
    def run_command(module, cmd):
        class RC:
            def __init__(self, code):
                self.code = code

            def __int__(self):
                return self.code

        class Out:
            def __init__(self, lines):
                self.stdout = '\n'.join(lines)

        class module_run_command:
            def __init__(self, rc, out):
                self.rc = rc
                self.out = out

            @staticmethod
            def run_command(cmd):
                return self.rc, self.out, ""

        class module_fail_json:
            def __init__(self, rc, out):
                self.rc = rc
                self.out = out


# Generated at 2022-06-23 03:42:26.610663
# Unit test for function main
def test_main():

    class TestException(Exception):
        pass

    module_name = 'getent'
    module_args = {
        "database": "passwd",
        "key": None,
        "fail_key": True,
    }

    module_check_mode = False

    # create a dummy class to test against
    class MyModule():
        def __init__(self):
            self.params = module_args
            self.check_mode = module_check_mode

        def fail_json(self, **kwargs):
            raise TestException(kwargs)

        def run_command(self, args, check_rc=True):
            if args[-1] == "root":
                return 0, "root:x:0:0:root:/root:/bin/bash", ""
            else:
                return 2, "", ""

       

# Generated at 2022-06-23 03:42:31.955929
# Unit test for function main
def test_main():
    assert (main() == ("Missing arguments, or database unknown.", None))

# Generated at 2022-06-23 03:42:38.595760
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import ansible.module_utils.facts
    m = basic.AnsibleModule(argument_spec={})
    m.params['database'] = 'passwd'
    m.params['key']='trees'
    ansible.module_utils.facts.ansible_facts = {}
    main()
    assert m.params['key'] in ansible.module_utils.facts.ansible_facts['getent_passwd']

# Generated at 2022-06-23 03:42:50.094505
# Unit test for function main
def test_main():
    run_ansible_module(module_name='getent', module_args={'database': 'passwd', 'key': 'root'})

    results = run_ansible_module(module_name='getent', module_args={'database': 'group'})
    assert results.get('changed') is False

    results = run_ansible_module(module_name='getent', module_args={'database': 'passwd'})
    assert results.get('changed') is False
    assert results.get('ansible_facts') is not None

    results = run_ansible_module(module_name='getent', module_args={'database': 'passwd', 'key': 'root'})
    assert results.get('changed') is False
    assert results.get('ansible_facts') is not None

# Generated at 2022-06-23 03:43:04.713372
# Unit test for function main
def test_main():
    '''
    Ansible module main unit test
    '''
    # This function is not really testable as it depends on external commands
    # and the module execution depends on system, but at least we can check
    # the module fail without errors
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    rc, out, err = module.run_command([module.get_bin_path('false', True), 'foo'])
    module.exit_json(rc=rc, out=out, err=err)

if __name__ == '__main__':
    test_main

# Generated at 2022-06-23 03:43:06.737879
# Unit test for function main
def test_main():
    # TODO: implement functional tests
    assert True == True

# Generated at 2022-06-23 03:43:18.530862
# Unit test for function main
def test_main():
    # Test main() with valid parameters
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = 'group'
    key = None
    split = ':'
    service = None
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-23 03:43:31.725965
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as ansible_basic
    import ansible.module_utils.action as ansible_action

    main_backup = ansible_action.__dict__['action_plugins']['getent']
    ansible_action.__dict__['action_plugins']['getent'] = main

    module = ansible_basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:43:42.863379
# Unit test for function main

# Generated at 2022-06-23 03:43:53.701466
# Unit test for function main
def test_main():
    def mock_exit_json(ansible_facts, msg):
        assert isinstance(ansible_facts, dict)
        assert 'ansible_facts' in ansible_facts
        assert isinstance(ansible_facts['ansible_facts'], dict)
        assert 'getent_passwd' in ansible_facts['ansible_facts']
        assert isinstance(ansible_facts['ansible_facts']['getent_passwd'], dict)
        assert 'root' in ansible_facts['ansible_facts']['getent_passwd']
        assert isinstance(ansible_facts['ansible_facts']['getent_passwd']['root'], list)

    def mock_fail_json(ansible_facts, msg):
        assert isinstance(ansible_facts, dict)

# Generated at 2022-06-23 03:43:56.924998
# Unit test for function main
def test_main():
    test_params = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
        'service': '',
    }

    print(main(test_params))

# Generated at 2022-06-23 03:44:08.428542
# Unit test for function main
def test_main():
    # DummyModule implements the basic funtions of a AnsibleModule.
    # it is a helper class in test fixtures to mock the behavior of AnsibleModule
    class DummyModule():
        def __init__(self, argument_spec, supports_check_mode=False):
            self.params = None
            self.argument_spec = argument_spec

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def exit_json(self, **kwargs):
            return True

        def run_command(self, cmd):
            return 0, "", ""


# Generated at 2022-06-23 03:44:19.635121
# Unit test for function main
def test_main():
    test_module_1 = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
        'fail_key': True,
    }


# Generated at 2022-06-23 03:44:20.399897
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 03:44:30.852615
# Unit test for function main
def test_main():
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        with mock.patch('ansible.module_utils.basic.get_bin_path', return_value=True):
            with mock.patch('ansible.module_utils.connection.Connection') as mock_connection:
                import ansible.modules.system.getent as getent
                with mock.patch.object(getent, 'AnsibleModule') as mock_amodule:
                    instance = mock_amodule.return_value
                    instance.exit_json.return_value = True
                    instance.run_command.return_value = (0, '', '')
                    getent.main()

# Generated at 2022-06-23 03:44:36.990273
# Unit test for function main
def test_main():
    commands = ['getent passwd root', 'getent group', 'getent hosts', 'getent services http',
        'getent shadow www-data']
    (rc, out, err) = main(['database=passwd', 'key=root', 'service=nss'])
    assert commands[0] == out, "Expected %s, got %s" % (commands[0], out)

# Generated at 2022-06-23 03:44:49.518652
# Unit test for function main
def test_main():
    import os
    import shlex

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    chdir = os.path.dirname(module.params['database'])
    getent_bin = module.get_bin_path('getent', True)
    cmd = module.params['database']
    rc = 0
    out = ''
    err = ''


# Generated at 2022-06-23 03:44:50.482032
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:45:00.785490
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, database, key]
    if service is not None:
        cmd.extend(['-s', service])

    if split is None and database in colon:
        split = ':'

    dbtree = 'getent_%s' % database
    seen = {}
    for line in out.splitlines():
        record = line.split(split)

        if record[0] in seen:
            if seen[record[0]] == 1:
                results[dbtree][record[0]] = [results[dbtree][record[0]]]

            results[dbtree][record[0]].append(record[1:])
            seen[record[0]] += 1

# Generated at 2022-06-23 03:45:01.698755
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:07.443401
# Unit test for function main
def test_main():
    # add test coverage
    arguments = dict(
        database='passwd',
        key='root',
        split='\t',
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        )
    )

    main()

# Generated at 2022-06-23 03:45:18.905913
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = mock.Mock(return_value=(0, 'root:x:0:0:root:/root:(split_char):/bin/bash', None))

    main()

    results = module.exit_json.call_args[1]['ansible_facts']


# Generated at 2022-06-23 03:45:29.577696
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str', default=':'),
            fail_key=dict(type='bool', required=False)
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    if module.params.get('key') is not None:
        cmd = [getent_bin, module.params.get('database'), module.params.get('key')]
    else:
        cmd = [getent_bin, module.params.get('database')]


# Generated at 2022-06-23 03:45:43.849216
# Unit test for function main
def test_main():
    import ast

    # Use directive from default ansible.cfg
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True)

    # Get all user information
    module.params = {'database': 'passwd'}
    assert main()['ansible_facts']['getent_passwd'] == ast.literal_eval('{}')

    # 'root' is always present
    module.params = {'database': 'passwd', 'key': 'root'}

# Generated at 2022-06-23 03:45:52.233411
# Unit test for function main
def test_main():

    class AnsibleModuleStub(object):

        def __init__(self, parms, **kwargs):
            self.parms = parms
            self.ansible_facts = {}

        def run_command(self, cmd):
            print('run_command: %s' % cmd)
            if self.parms['database'] not in ('passwd', 'group', 'gshadow'):
                if self.parms['service'] is not None:
                    raise Exception('Service flag is not available on this system')
            return (0, '\n'.join([line1, line2, line3]), '')

        def fail_json(self, msg="failed", **kwargs):
            print('fail_json: %s' % msg)
            raise Exception(msg)


# Generated at 2022-06-23 03:46:05.549528
# Unit test for function main
def test_main():
    class ModuleStub(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.exit_json = self.exit_json_stub


# Generated at 2022-06-23 03:46:17.362135
# Unit test for function main
def test_main():
    # Example of a getent output
    getent_hosts_output = '''127.0.0.1  localhost localhost loghost
::1         localhost ip6-localhost ip6-loopback
fe00::0     ip6-localnet
ff00::0     ip6-mcastprefix
ff02::1     ip6-allnodes
ff02::2     ip6-allrouters'''


# Generated at 2022-06-23 03:46:29.377402
# Unit test for function main
def test_main():
    import sys
    import io
    import mock

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            sys.exit(1)

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            sys.exit(0)

        def run_command(self, command):
            self.command = command
            return 1, "", "error"

        def get_bin_path(self, name, required):
            return "/usr/bin/%s" % name


# Generated at 2022-06-23 03:46:31.746632
# Unit test for function main
def test_main():
   main()

# Generated at 2022-06-23 03:46:42.111210
# Unit test for function main
def test_main():
    args = dict(
        database='passwd',
        key=None,
        split=':',
        service=None,
        fail_key=True,
    )


# Generated at 2022-06-23 03:46:43.138322
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:46:50.173652
# Unit test for function main

# Generated at 2022-06-23 03:46:58.125563
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    def run_command(cmd, **kwargs):
        return (0, "", "")

    def get_bin_path(name, required):
        return '/usr/bin/getent'

    module = basic.AnsibleModule(argument_spec={
        'database': dict(default=None, type='str'),
        'key': dict(default=None, type='str'),
        'split': dict(default=None, type='bool'),
        'service': dict(default=None, type='str'),
        'fail_key': dict(default=True, type='bool')})
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    main()

# Generated at 2022-06-23 03:47:08.842878
# Unit test for function main
def test_main():
    import ansible.module_utils.common.json as json
    from ansible.module_utils.common.collections import ImmutableDict

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
        ),
        supports_check_mode=True,
    )

    def run_command(args, check_rc=True):
        if args[-1] == 'root':
            return (0, json.dumps({'0': 'root', '1': 'x', '2': 0, '3': 0, '4': 'root', '5': '/root', '6': '/bin/bash'}), '')

# Generated at 2022-06-23 03:47:21.803626
# Unit test for function main
def test_main():
    import tempfile
    import json
    import os
    import os.path
    from ansible.module_utils import basic

    fd, test_file = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as fp:
        fp.write(json.dumps({
            'changed': False,
            'failed': True,
            'msg': 'Unexpected failure!'
        }))

    fd, temp_file = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as fp:
        cwd = os.getcwd()

# Generated at 2022-06-23 03:47:27.420752
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Empty args
    module.params = {}
    main()
    # Bad database
    module.params = {'database': 'not_a_db'}
    main()
    # Unsupported database
    #main(module)
    # Bad key
    #main(module)
    # Supported key
    #main(module)
    # Module fail
    #main(module)

# Generated at 2022-06-23 03:47:29.857966
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    # Test with no options
    assert 1 == main('', '')
    # Test with required options
    assert 1 == main('foo', 'bar')

# Generated at 2022-06-23 03:47:39.202761
# Unit test for function main
def test_main():
    def mock_module_run_command(cmd):
        class MockRC:
            def __init__(self):
                self.rc = 0
            def close(self):
                pass
            def isatty(self):
                return False
            def read(self, count=-1):
                return ''
            def readlines(self):
                return []
            def write(self, value):
                pass
            def writelines(self, value):
                pass
            def flush(self):
                return MockRC()
            def fileno(self):
                return 0
            def seek(self, offset, whence):
                return MockRC()
            def truncate(self, size):
                return MockRC()

        class MockSTD:
            def __init__(self):
                self.err = []
                self.out = []