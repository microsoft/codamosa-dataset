

# Generated at 2022-06-23 03:37:38.832611
# Unit test for function main
def test_main():
    # We must import the ansible module to get AnsibleModule mock
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import EnvironmentError
    # Here we create a mock for ansible module
    am = ansible.module_utils.basic.AnsibleModule
    # This is the first argument to AnsibleModule constructor
    # We use a dict to represent the argument
    argument_spec = {
        "database": {"required": True},
        "key": {"no_log": False},
        "service": {},
        "split": {},
        "fail_key": {"default": True}
    }
    # We create a mock instance of AnsibleModule
    mock_am = am(argument_spec=argument_spec)
    # We set

# Generated at 2022-06-23 03:37:44.590261
# Unit test for function main
def test_main():
    module = AnsibleModule(params={'database': 'group'})

    class ActionBase:
        def __init__(self):
            self.check_mode = False
            self.module_args = {"database":"group"}
            self.params = {'database': 'group'}
            self.params['run_check'] = False
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')
        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

# Generated at 2022-06-23 03:37:48.596160
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    # Import module for testing
    module = basic._ANSIBLE_ARGS
    module.update(dict(action="getent", database="passwd", split=":"))

    # Generate result for testing

# Generated at 2022-06-23 03:37:58.388814
# Unit test for function main
def test_main():
    """
    Test to see if main will return a dictionary of results
    """
    from ansible.module_utils import getent
    basic_module = imp.new_module('ansible.module_utils.basic')
    basic_module.AnsibleModule = getent.AnsibleModule
    getent.sys = imp.new_module('sys')
    getent.os = imp.new_module('os')
    getent.AnsibleModule = basic_module.AnsibleModule
    getent.run_command = MagicMock(return_value=[0," passwd:x:0:0:root:/root:/bin/bash\n "," "])


# Generated at 2022-06-23 03:38:07.868128
# Unit test for function main
def test_main():
    import json
    import os
    import tempfile
    import shutil
    from mock import patch, MagicMock, ANY

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', default=''),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'getent')

# Generated at 2022-06-23 03:38:16.415779
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-23 03:38:27.231168
# Unit test for function main
def test_main():
    # Test no params
    test_module = AnsibleModule({},
        supports_check_mode=True)
    assert main() is None, "Empty parameters should fail with msg"

    # Test bad parameters
    test_module = AnsibleModule({
        'database': 'unknowndb',
        },
        supports_check_mode=True)
    assert main() is None, "Unknown database should fail"

    # Test no key, should get a list of results
    test_module = AnsibleModule({
        'database': 'passwd',
        },
        supports_check_mode=True)
    assert main() is None, "Bad parameters should fail"

# Generated at 2022-06-23 03:38:38.942927
# Unit test for function main

# Generated at 2022-06-23 03:38:40.158972
# Unit test for function main
def test_main():
    print('Function main not implemented')
    pass # TODO: Implement test

# Generated at 2022-06-23 03:38:52.603127
# Unit test for function main
def test_main():
    import ansible.module_utils.action_plugin
    import ansible.module_utils.action
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.action.AnsibleModule(argument_spec={}, supports_check_mode=True)

    if module._name == 'main':
        del module
        module = ansible.module_utils.action_plugin.ActionModule(argument_spec={}, supports_check_mode=True)
        module.deprecate("The 'main' module has been renamed to 'action'", version=2.14)

    # see dependencies in docstring
    dummy_passwd = 'root:x:0:0:root:/root:/bin/bash'
    dummy_group = 'root:x:0:'

# Generated at 2022-06-23 03:39:01.546265
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:39:11.774486
# Unit test for function main
def test_main():
    import sys
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    # Load the params
    with open(sys.argv[1]) as f:
        params = json.load(f)

    # Create the AnsibleModule object
    module = AnsibleModule(argument_spec=params)

    # Set the fake exit function
    def exit_json(**kwargs):
        print(json.dumps(kwargs))

    # Set the fake fail function
    def fail_json(**kwargs):
        kwargs['failed'] = True
        print(json.dumps(kwargs))

    # Set the fake AnsibleModule object's exit_json and fail_json
    module.exit_json = exit_json
    module.fail_json

# Generated at 2022-06-23 03:39:22.126970
# Unit test for function main
def test_main():
    from units.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class GetentTestCase(ModuleTestCase):
        def test_fail_key(self, *args, **kwargs):
            set_module_args(dict(database='passwd', key='root', fail_key=True))
            with self.assertRaises(AnsibleFailJson):
                self.execute_module()
            set_module_args(dict(database='passwd', key='root', fail_key=False))
            result = self.execute_module()
            self.assertEqual(result['ansible_facts']['getent_passwd']['root'], None)

# Generated at 2022-06-23 03:39:29.913703
# Unit test for function main

# Generated at 2022-06-23 03:39:30.596609
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 03:39:37.514798
# Unit test for function main
def test_main():
    import ansible
    from ansible.module_utils._text import to_bytes

    module = ansible.module_utils.basic.AnsibleModule
    module.run_command = lambda x: (0, to_bytes('a:x:0:0::/root:/bin/sh\nb:x:1:1::/home:/bin/sh'), '')
    module.params = {
        'database': 'passwd',
    }
    main()

# Generated at 2022-06-23 03:39:41.318966
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True)
        ),
        supports_check_mode=True,
    )

    module.exit_json(changed=False)

# Generated at 2022-06-23 03:39:51.938130
# Unit test for function main
def test_main():
    import os

    class MockModule(object):
        def __init__(self, database, key, split=None, service=None, fail_key=True):
            self.params = {
                "database": database,
                "key": key,
                "split": split,
                "service": service,
                "fail_key": fail_key,
            }
        def get_bin_path(self, name, required):
            if required:
                return os.path.abspath('./getent')
            else:
                return None

        def run_command(self, cmd):
            if cmd == ['/usr/bin/getent', 'passwd', 'root']:
                return 0, 'root:x:0:0:root:/root:/bin/bash', None

# Generated at 2022-06-23 03:40:03.119764
# Unit test for function main

# Generated at 2022-06-23 03:40:13.019085
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule({
        'database': 'foo',
        'key': 'bar',
        'service': 'baz',
        'split': 'qux',
        'fail_key': True,
        'ansible_facts': {},
    }, supports_check_mode=False)
    getent_bin = module.get_bin_path('getent', True)
    rc, out, err = module.run_command([getent_bin, 'foo', 'bar'])
    if rc == 0:
        module.exit_json(ansible_facts={"getent_foo": [["qux"]]})

# Generated at 2022-06-23 03:40:23.107956
# Unit test for function main
def test_main():
    import ansible.utils.unsafe_proxy
    import ansible.constants

    test_command_outputs = '''
root:x:0:0:root:/root:/bin/bash
'''

    test_command_outputf = '''
nobody:x:65534:65534:nobody:/nonexistent:/bin/sh
'''

    test_command_outputg = '''
root:x:0:
admin:x:1:
'''

    def test_basic_run_command(cmd, input):
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_native
        from ansible.module_utils.basic import RunCommand
        import ansible.constants


# Generated at 2022-06-23 03:40:34.425775
# Unit test for function main
def test_main():
    import os
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            self.data = result._result

    os.chdir("/")

# Generated at 2022-06-23 03:40:44.038698
# Unit test for function main
def test_main():
    # Required for test environment
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # define the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Build the facts objects
    module.ansible_facts = Facts(module).get_facts()

    # Set up return dictionary

# Generated at 2022-06-23 03:40:55.108281
# Unit test for function main
def test_main():
    import sys, os
    import unittest
    import difflib
    import tempfile
    import json

    saved_args = sys.argv
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

# Generated at 2022-06-23 03:40:59.697016
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # TODO write unit tests


# Generated at 2022-06-23 03:41:11.220041
# Unit test for function main
def test_main():

    # Mock init module
    def _init_module():
        return dict(argument_spec = dict(database = dict(type = 'str', required = True), key = dict(type = 'str', no_log = False), split = dict(type = 'str'), fail_key = dict(type = 'bool', default = True)), supports_check_mode = True)

    # Mock run_command
    def _run_command(command):

        cmd, database, key = command

        if database == 'passwd' and key == 'root':
            return 0, 'root:x:0:0:root:/root:/bin/bash\n', ''
        elif database == 'group' and key is None:
            return 0, 'root:x:0:root\n', ''
        elif database == 'hosts' and key is None:
            return

# Generated at 2022-06-23 03:41:25.975444
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import getent
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import facts
    import os
    tmpdir = "/tmp/%s" % os.path.basename(__file__)
    if not os.path.isdir(tmpdir):
        os.makedirs(tmpdir)

    m = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:41:36.439770
# Unit test for function main
def test_main():
    import tempfile
    import json
    import subprocess

    def run_module(module_name, options):
        cmd = '%s %s' % (module_name, ' '.join(options))
        if subprocess.mswindows:
            cmd = 'python -c "%s"' % cmd.replace('"', '\\"')
        if os.path.isfile(module_name) and not os.access(module_name, os.X_OK):
            cmd = 'sh -c "%s"' % cmd.replace('"', '\\"')
        return subprocess.Popen(cmd,
            stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)

    # test the getent module can be loaded on a posix system

# Generated at 2022-06-23 03:41:46.601375
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:41:59.662625
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:42:11.722643
# Unit test for function main
def test_main():
    # Success
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    set_module_args(dict(
        database='passwd',
        key='root'
    ))

    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, 'passwd', 'root']

# Generated at 2022-06-23 03:42:17.971791
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          database=dict(type='str', required=True),
          key=dict(type='str', no_log=False),
          service=dict(type='str'),
          split=dict(type='str'),
          fail_key=dict(type='bool', default=True),
      ),
      supports_check_mode=True,
  )

  colon = ['passwd', 'shadow', 'group', 'gshadow']

  database = module.params['database']
  key = module.params.get('key')
  split = module.params.get('split')
  service = module.params.get('service')
  fail_key = module.params.get('fail_key')

  getent_bin = module.get_bin_path('getent', True)

 

# Generated at 2022-06-23 03:42:28.170817
# Unit test for function main
def test_main():
    getent_bin = "/usr/bin/getent"
    class FakeAnsibleModule:
        argument_spec = dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
        supports_check_mode=True

        def __init__(self, *args):
            self.exit_json = mock.Mock()
            self.fail_json = mock.Mock()

        @staticmethod
        def get_bin_path(binaryname, required=False):
            # For now we can ignore the required flag
            return getent_bin


# Generated at 2022-06-23 03:42:42.488287
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    import pytest
    class Options: pass
    class Args: pass
    module = pytest.Mock(return_value=Options())
    module.get_bin_path = pytest.Mock(return_value='/bin/getent')
    module.run_command = pytest.Mock(return_value=(0, b'', ''))
    module.exit_json = pytest.Mock()
    module.fail_json = pytest.Mock()
    args = Args()
    args.database = 'group'
    args.key = None
    args.split = None
    args.service = None
    args.fail_key = True

    main()


# Generated at 2022-06-23 03:42:44.194514
# Unit test for function main
def test_main():
    assert 2 == 2

# Generated at 2022-06-23 03:42:45.059504
# Unit test for function main
def test_main():
  assert True

# Generated at 2022-06-23 03:42:50.485028
# Unit test for function main
def test_main():
    print('===> Test MODULE "getent" with function "main"')
    cmd = [getent_bin, 'passwd', 'telnet']
    rc, out, err = module.run_command(cmd)
    assert rc == 0

# Generated at 2022-06-23 03:43:00.297541
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:43:13.116503
# Unit test for function main
def test_main():
    testargs = [
        "getent",
        "--database=passwd",
        "--key=root",
        "--split=:",
    ]

# Generated at 2022-06-23 03:43:14.319516
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:43:15.134487
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:43:16.164599
# Unit test for function main
def test_main():
    print('Test main')
    exit(1)

# Generated at 2022-06-23 03:43:17.112033
# Unit test for function main
def test_main():
    #assert main == 1
    assert True

# Generated at 2022-06-23 03:43:17.924756
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:43:31.151699
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params = {}
    module.params['database'] = 'aliases'
    module.params['key'] = 'nobody'
    module.params['split'] = ':'

    # Should fail, missing getent bin
    assert 'ansible_facts' not in main(module)

# Generated at 2022-06-23 03:43:42.466811
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule, is_executable_file

    current_dir = os.path.dirname(os.path.realpath(__file__))

    module = AnsibleModule()
    module.exception_handling = 'pluggable'

    # set up valid getent binary
    module.debug(os.path.join(current_dir, 'getent_bin.py'))
    os.environ['PATH'] = '%s:%s' % (current_dir, os.environ['PATH'])
    if not is_executable_file(os.path.join(current_dir, 'getent_bin.py')):
        module.fail_json(msg='getent_bin.py is not executable on the PATH!')

    # Set module args
   

# Generated at 2022-06-23 03:43:53.459268
# Unit test for function main
def test_main():
    class AnsibleModule(object):

        def __init__(self, argument_spec=None, supports_check_mode=None):
            self.argument_spec = argument_spec
            self.check_mode = supports_check_mode

        def get_bin_path(self, arg=None, required=None):
            return "/usr/bin/getent"

        def run_command(self, cmd):
            return 0, '', ''

        def fail_json(self, **kwargs):
            raise Exception('fail')

        def exit_json(self, **kwargs):
            raise Exception('exit')

    def getent_setup(database='passwd', key=None, split=None, service=None, fail_key=True):
        getent_bin = AnsibleModule.get_bin_path(None, None)


# Generated at 2022-06-23 03:44:02.250615
# Unit test for function main
def test_main():
    import sys
    import __builtin__

    sys.argv = ['ansible-test', '--connection=local', '--become',
        'getent', '--db=passwd', '--key=root']

    getent_bin = '/usr/bin/getent'

    __builtin__.__dict__['__salt__'] = {'cmd.run': cmd_run_mock}

    main()

    result = None

    try:
        __builtin__.__dict__['__salt__'] = {'cmd.run': cmd_run_mock_fail_key}
        main()
    except Exception as e:
        result = e.message

    assert result == "One or more supplied key could not be found in the database."


# Mock the cmd.run function to test the function main

# Generated at 2022-06-23 03:44:15.447322
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    tempdir = tempfile.mkdtemp()
    os.chmod(tempdir, 0o777)
    # Use tempfile.NamedTemporaryFile to be able to close it,
    # else the file will remain open and prevent the tempdir
    # from being removed.

# Generated at 2022-06-23 03:44:26.235896
# Unit test for function main
def test_main():
    import os
    import sys
    module = AnsibleModule(argument_spec=dict(database=dict(required=True, type='str'), key=dict(type='str', no_log=False), service=dict(type='str'), split=dict(type='str'), fail_key=dict(type='bool', default=True)), supports_check_mode=True)
    sys.modules['__builtin__'].__dict__['getent_bin'] = getent_bin = os.path.join('/home', 'user', 'testdir', 'test_file')

    class Temp(object):
        pass
    getent_bin_result = Temp()
    getent_bin_result.rc = 0
    getent_bin_result.stdout = 'stdout'

# Generated at 2022-06-23 03:44:26.912715
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:44:38.714806
# Unit test for function main
def test_main():
    # Arguments and result
    database = 'passwd'
    key = 'root'
    database = ''

    passwd = {u'results': [u'root', u'x', u'0', u'0', u'System Administrator', u'/var/root', u'/bin/sh'],
              u'rc': 0,
              u'cmd': ['getent', 'passwd', 'root']}

    passwd_missing_db = {'rc': 1,
                         'cmd': ['getent', 'nonexistentdb', 'root'],
                         'results': []}

    passwd_missing_key = {'rc': 2,
                          'cmd': ['getent', 'passwd', 'nonexistentkey'],
                          'results': []}


# Generated at 2022-06-23 03:44:50.514813
# Unit test for function main
def test_main():
    test_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )

    test_module = AnsibleModule(
        argument_spec=test_spec,
        supports_check_mode=True,
    )
    database = "passwd"
    key = "root"
    split = ":"
    fail_key = True
    # try the true path first process_common_info()
    # command was run successfully
    test_module.run_command = MagicMock(return_value=(0, "test out", "test err"))
    # hopefully this would be the case every time
   

# Generated at 2022-06-23 03:45:00.816670
# Unit test for function main
def test_main():
    # NOTE: Since we don't actually have a getent binary we'll mock it
    # and test our functions
    import sys
    sys.modules['ansible.module_utils.basic'] = MockBasic()
    sys.modules['ansible.module_utils.action'] = MockAction()
    sys.modules['ansible.module_utils._text'] = MockText()
    sys.modules['ansible.module_utils.action.core'] = MockCore()
    sys.modules['ansible.module_utils.action.network'] = MockNetwork()
    sys.modules['ansible.module_utils.action.system'] = MockSystem()
    sys.modules['ansible.module_utils.facts.system'] = MockFactsSystem()
    sys.modules['ansible.module_utils.facts.network'] = MockFactsNetwork()

# Generated at 2022-06-23 03:45:01.260244
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:06.244525
# Unit test for function main
def test_main():
    sample_results = {'getent_passwd': {'root': ['x', 0, 0, 'root', '/root', '/bin/bash']}}
    sample_results['getent_passwd']['foo'] = ['x', 0, 0, 'foo', '/foo', '/bin/bash']
    assert main(key="root") == sample_results

# Generated at 2022-06-23 03:45:17.936342
# Unit test for function main
def test_main():
    # Test module argument parsing

    module = AnsibleModule(
        argument_spec = {
            'database': {'type': 'str', 'required': True},
            'key': {'type': 'str', 'required': False},
            'service': {'type': 'str'},
            'split': {'type': 'str'},
            'fail_key': {'type': 'bool', 'default': True},
        },
        supports_check_mode=True,
    )

    assert module.params['database'] == 'passwd'
    assert module.params['key'] == 'root'
    assert module.params['split'] == None
    assert module.params['fail_key'] == True
    assert module.params['service'] == None


# Generated at 2022-06-23 03:45:27.284237
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
     )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:45:28.898720
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:43.469834
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import os
    getent_bin = module.get_bin_path('getent', True)
    os.environ["PATH"] = "%s:%s" %("/usr/bin",os.environ["PATH"])

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')


# Generated at 2022-06-23 03:45:49.766205
# Unit test for function main
def test_main():
    print("Testing ansible_facts")

    results = {
        "ansible_facts": {
            "getent_database": [
                1,
                6,
                "y"
            ]
        }
    }
    assert(results["ansible_facts"] == "y")

    results = {
        "ansible_facts": {
            "getent_database": 1
        }
    }
    assert(results["ansible_facts"] == "y")

    print("Test Completed Successfully")

# Generated at 2022-06-23 03:45:53.914591
# Unit test for function main
def test_main():
    # Test no arguments
    module = AnsibleModule(argument_spec={})

    rc, out, err = module.run_command(["/bin/sh","tests/test1.sh"])

    assert rc == 1
    assert module.fail_json.called

# Unit tests for function main_passwd

# Generated at 2022-06-23 03:45:54.749927
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:46:07.220952
# Unit test for function main
def test_main():

    # A bit naive but works on my debian 10
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')
    getent_bin = module.get

# Generated at 2022-06-23 03:46:18.462170
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    database = 'services'
    key = 'http'
    split = ':'
    service = None
    fail_key = True

    if key is not None:
        cmd = ['/usr/bin/getent', database, key]
    else:
        cmd = ['/usr/bin/getent', database]

    if service is not None:
        cmd.extend(['-s', service])

    if split is None and database in []:
        split = ':'

    try:
        rc, out, err = module.run_command(cmd)
    except Exception as e:
        module.fail_json(msg=to_native(e), exception=traceback.format_exc())

    msg = "Unexpected failure!"

# Generated at 2022-06-23 03:46:25.750818
# Unit test for function main
def test_main():
    # Testing for argument_spec
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    module.exit_json(msg="Unit test success.", success=True)


# Generated at 2022-06-23 03:46:33.386829
# Unit test for function main
def test_main():
    import ansible.module_utils.getent as getent

    cmd = ['getent', 'passwd', 'root']
    rc, out, err = getent.module.run_command(cmd)
    assert rc == 0

    cmd = ['getent']
    rc, out, err = getent.module.run_command(cmd)
    assert rc == 1

    cmd = ['getent', 'services', 'doesnotexist']
    rc, out, err = getent.module.run_command(cmd)
    assert rc == 2

    cmd = ['getent', 'someweirddatabase']
    rc, out, err = getent.module.run_command(cmd)
    assert rc == 2

# Generated at 2022-06-23 03:46:43.063865
# Unit test for function main
def test_main():
    test_args = dict(database='passwd', key='bobby', split='m')
    with patch.object(AnsibleModule, 'run_command', return_value=(0, '0\n', '')):
        with patch.object(AnsibleModule, 'exit_json'):
            with patch.object(AnsibleModule, 'get_bin_path', return_value='/usr/bin/getent'):
                main()
                assert AnsibleModule.get_bin_path.call_count == 1
                assert AnsibleModule.run_command.call_count == 1
                assert AnsibleModule.exit_json.call_count == 1
                assert AnsibleModule.run_command.call_args[0][1] == ['/usr/bin/getent', 'passwd', 'bobby']
                assert AnsibleModule

# Generated at 2022-06-23 03:46:53.797996
# Unit test for function main
def test_main():

    global module, getent_bin, key, split
    class MockArgs(object):
        module = None
        key = None
        split = None
        fail_key = None
    class MockModule(object):
        def __init__(self):
            self.params = MockArgs()
        def fail_json(self, msg):
            raise AssertionError(msg)

    global module
    module = MockModule()

    import mock
    import tempfile
    class MockPopen(object):
        def __init__(self, cmd, *args, **kwargs):
            self.stdout = tempfile.StringIO()
            self.stdout.write('key1:val1\nkey2:val2')
            self.stdout.seek(0)
            self.stderr = tempfile.StringIO()

# Generated at 2022-06-23 03:47:01.664796
# Unit test for function main
def test_main():

    # simple test, didn't have time to make more
    class options:
        database = 'group'
        key = 'root'
        split = ':'
        service = None
        fail_key = True

    class module(object):

        class run_command(object):

            def __init__(self, cmd):
                self.cmd = cmd
                return self.cmd

        class fail_json(object):

            def __init__(self, msg):
                self.msg = msg
                return self.msg

        class exit_json(object):

            def __init__(self, results):
                self.results = results
                return self.results

    main(options, module)

    #Test fail_key parameter when key found
    options.fail_key = False
    main(options, module)

# Generated at 2022-06-23 03:47:11.423505
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os

    test_passwd = '''
root:x:0:0:root:/root:/bin/bash
daniel:x:1000:1000:daniel,,,:/home/daniel:/bin/bash
'''

    test_group = '''
root:x:0:
daniel:x:1000:
'''

    tmp = tempfile.mkdtemp()

# Generated at 2022-06-23 03:47:15.406759
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:47:22.107359
# Unit test for function main
def test_main():
    s = dict(database = 'passwd',
             key = 'root',
             split = ':',
             fail_key = True,
             )
    a = main(s)
    #assert a is not None
    #assert a > 0

# Generated at 2022-06-23 03:47:22.857855
# Unit test for function main
def test_main():
    # TODO: add unit tests for main
    assert True

# Generated at 2022-06-23 03:47:33.275631
# Unit test for function main
def test_main():
    # Test results with a mock:
    # > getent hosts localhost
    # 127.0.0.1 localhost.localdomain localhost

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
            _ansible_get_bin_path=dict(type='str', default='/usr/bin/getent'),
        ),
    )

    class RunCommand(object):
        def __init__(self, module):
            self.module = module

        def __call__(self, *args, **kwargs):
            cmd = args[0]
            rc = 0
           