

# Generated at 2022-06-23 03:37:32.297678
# Unit test for function main
def test_main(): # no coverage
    main()

# Generated at 2022-06-23 03:37:42.395226
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-23 03:37:51.688955
# Unit test for function main
def test_main():
    ###################
    # Tests from here #
    ###################
    import logging, os
    from systemd import journal
    from ansible.module_utils.basic import AnsibleModule

    class RunCmd:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class Shell:
        def __init__(self):
            self.rc = 0
            self.out = ''
            self.err = ''

        def run_command(self, cmd):
            return self.rc, self.out, self.err

        def dump_results(self, msg, rc=0, out='', err=''):
            msg = msg
           

# Generated at 2022-06-23 03:37:55.610045
# Unit test for function main
def test_main():
    # Example to get root user info
    module = AnsibleModule(database='passwd', key='root')
    exit_args = {'ansible_facts': {'getent_passwd': {'root': ['x','0','0','root','/root','/bin/bash']}}}
    module.exit_json(**exit_args)

# Generated at 2022-06-23 03:38:00.460790
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main(module)

# Generated at 2022-06-23 03:38:09.446914
# Unit test for function main
def test_main():
    # mock module class
    class Module(object):
        def __init__(self):
            self.params = {
                'database': 'services',
                'key': 'http',
                'fail_key': True,
                'check_mode': False,
                'split': None,
                'service': None
            }
            self.run_command = lambda x, **kwargs: (0, 'http\t\t80/tcp\nldap\t\t389/udp', '')
            self.get_bin_path = lambda x, required: '/bin/getent'
            self.fail_json = lambda **kwargs: None
            self.exit_json = lambda **kwargs: None

    module = Module()
    rc = main()

# Generated at 2022-06-23 03:38:15.496816
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
          database=dict(type='str', required=True),
          key=dict(type='str', no_log=False),
          split=dict(type='str'),
          fail_key=dict(type='bool', default=True),
            ),
        supports_check_mode=True,
    )
    assert module.params['database']
    assert module.params['key']
    assert module.params['split']
    assert module.params['fail_key']

# Generated at 2022-06-23 03:38:21.766400
# Unit test for function main
def test_main():
    # New getent module args
    module_args = dict(
        database='hosts',
        key='google.com',
    )

    result = dict(
        changed=False,
        ansible_facts=dict(
            getent_hosts=['216.58.204.238']
        ),
        rc=0,
        stderr='',
        stdout='',
        stderr_lines=[],
        stdout_lines=[],
    )

    # GetentModule is a subclass of AnsibleModule,
    # so we can use it to test main()
    # We have to patch, the action plugin loader loads this as a real action plugin
    from ansible.modules.system import getent
    getent.AnsibleModule = AnsibleModule

# Generated at 2022-06-23 03:38:33.064533
# Unit test for function main
def test_main():
    class FakeModule(object):
        params = {}
        fail_json = lambda msg: msg
        exit_json = lambda msg: msg
    fake = FakeModule()
    fake.params['database'] = 'passwd'
    fake.params['key'] = 'root'
    fake.params['fail_key'] = True
    fake.params['service'] = None
    fake.params['split'] = None
    fake.run_command = lambda cmd: (0,'0:root:0:0:root:/root:/bin/bash', '')
    fake.check_mode = False
    fake.get_bin_path = lambda cmd, req: cmd

# Generated at 2022-06-23 03:38:43.758944
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True, default='hosts'),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str', default=':'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params['database'] = 'hosts'
    module.params['key'] = 'localhost'
    module.params['split'] = ' '
    results = main()

    assert('ansible_facts' in results)
    assert('getent_hosts' in results['ansible_facts'])

# Generated at 2022-06-23 03:38:47.248010
# Unit test for function main
def test_main():
    module_args = dict(database='passwd', key='root', split=':', fail_key=False)
    rc, out, err = module.run_command(cmd)
    assert rc == 0

# Generated at 2022-06-23 03:38:47.898198
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:38:58.617073
# Unit test for function main
def test_main():
    # To warn if run with an unsupported python version
    import sys
    import os

    if sys.version_info[0] != 2:
        msg = "This test would not run on Python version different than 2.x"
        if os.environ.get('GATHERING_FACTS'):
            return msg, False
        else:
            import pytest
            pytest.skip(msg)

    # this is needed to avoid "unhashable type: 'dict'" exception
    # during the test
    os.environ['GATHERING_FACTS'] = '1'

    from ansible.module_utils import basic


# Generated at 2022-06-23 03:38:59.164329
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:39:09.381831
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    if not basic.AnsibleModule.HAS_GETENT:
        pytest.skip("getent not found", allow_module_level=True)

    mymodule = basic.AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str'),
            service = dict(type='str'),
            split = dict(type='str'),
            fail_key = dict(type='bool', default=True),
        ),
    )

    # TODO: mock run_command
    assert True == False

# Generated at 2022-06-23 03:39:10.084834
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:39:21.735195
# Unit test for function main
def test_main():
    def get_bin_path(arg1, arg2):
        return "/bin/getent"

    def get_bin_path_expect_fail(arg1, arg2):
        return ""

    def run_command(cmd):
        return 0, '127.0.0.1 localhost', ''

    class TestParams(object):
        def __init__(self,database,key,split,service=None, fail_key=True):
            self.database = database
            self.key = key
            self.split = split
            self.service = service
            self.fail_key = fail_key

    class TestModule(object):
        def __init__(self,params):
            self.params = params

# Generated at 2022-06-23 03:39:32.032765
# Unit test for function main
def test_main():
    import sys
    import pytest

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.action import ActionBase

    from ansible.module_utils.actions import getent

    class ActionModule(getent.ActionModule):

        def run(self, tmp=None, task_vars=None):
            return super(ActionModule, self).run(tmp, task_vars)

    class AnsibleModule(basic.AnsibleModule):

        def __init__(self, *args, **kwargs):
            if 'argument_spec' not in kwargs:
                kwargs['argument_spec'] = dict()
            kwargs['argument_spec'].update(getent.ActionModule.ARG_SPEC)


# Generated at 2022-06-23 03:39:44.063064
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = 'passwd'
    key = 'root'
    module.params['database'] = database
    module.params['key'] = key
    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    service = module.params.get

# Generated at 2022-06-23 03:39:53.464438
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = 'passwd'
    key = 'root'
    split = None
    service = 'foo'
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-23 03:39:54.617248
# Unit test for function main
def test_main():
    assert None is None

# Generated at 2022-06-23 03:40:05.753535
# Unit test for function main

# Generated at 2022-06-23 03:40:12.215220
# Unit test for function main
def test_main():
    #sys.path.append(os.path.dirname(__file__) + '/../../../tests/system/')
    print("Executing tests")
    #import module_utils.basic
    #import system.test_utils
    #system.test_utils.run_tests(module_utils.basic)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:40:18.152405
# Unit test for function main
def test_main():
    print("Running unit test for function main")
    import tempfile
    import os

    filename = tempfile.mkstemp()[1]

    try:
        with open(filename, 'w') as myfile:
            myfile.write("42")
        with open(filename, 'r') as myfile:
            assert myfile.read() == "42"
    finally:
        os.remove(filename)

# Generated at 2022-06-23 03:40:19.200650
# Unit test for function main
def test_main():
    print("Running unit test for function main")
    assert True

# Generated at 2022-06-23 03:40:20.559364
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:40:23.938420
# Unit test for function main
def test_main():
    # Test module headers
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
        ),
        supports_check_mode=True,
    )

    # Check module has no errors
    assert module.check_mode is True

# Generated at 2022-06-23 03:40:35.284529
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-23 03:40:44.785087
# Unit test for function main
def test_main():
    import json
    import os
    import sys
    import tempfile
    import pytest
    from ansible.module_utils import basic

    cwd = os.getcwd()
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create test database, save output in a dict
    dbtree = 'passwd'
    database = {
        'root': 'root:x:0:0:root:/root:/bin/bash',
        'nobody': 'nobody:x:65534:65534:nobody:/nonexistent:/bin/bash',
        'foo': 'foo:x:65534:65534:foo:/nonexistent:/bin/bash',
    }
    fname = '%s.db' % dbtree

# Generated at 2022-06-23 03:40:54.366718
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # module.run_command() takes a list as a command.
    # module.get_bin_path is defined in ansible.module_utils.basic
    getent_bin = module.get_bin_path('getent', True)

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')

# Generated at 2022-06-23 03:41:06.102033
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import filecmp

    def get_temp_dir():
        tmp_dir = tempfile.mkdtemp()
        os.chmod(tmp_dir, 0o0777)

        return tmp_dir

    def cleanup(dir):
        if os.path.exists(dir):
            shutil.rmtree(dir)

    ##################################################
    # getent.py
    ##################################################

    # Copy files to temporary directory (for both ansible and jinja2 templating)
    temp_dir = get_temp_dir()
    temp_path = tempfile.mkdtemp(dir=temp_dir)

    # Create ansible.cfg (needed to run modules via ansible-playbook)
    ansible_cfg_path = tempfile.mkstemp

# Generated at 2022-06-23 03:41:15.876549
# Unit test for function main
def test_main():
    # following variables are defined in top level scope
    # but are undefined here and are used in the function
    global module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # ansible.module_utils.basic.AnsibleModule.rc = None
    # ansible.module_utils.basic.AnsibleModule.stdout = None
    # ansible.module_utils.basic.AnsibleModule.stdout_lines = None
    # ansible.module_utils.

# Generated at 2022-06-23 03:41:18.111853
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleModuleFail) as e:
        main()
        assert e == 'The following modules failed to execute: getent'

# Generated at 2022-06-23 03:41:22.213197
# Unit test for function main
def test_main():
    a = AnsibleModule({'database': 'passwd', 'key': 'root'})
    assert main() == a.run_command(['getent', 'passwd', 'root'])

# Generated at 2022-06-23 03:41:29.515196
# Unit test for function main
def test_main():
    test_data = {
        'database': 'passwd',
        'key': 'root',
        'service': '',
        'split': None
    }

    module = AnsibleModule(
        argument_spec={
            'database': dict(type='str', required=True),
            'key': dict(type='str', no_log=False),
            'service': dict(type='str'),
            'split': dict(type='str'),
            'fail_key': dict(type='bool', default=True),
        },
        supports_check_mode=True
    )

    module.params.update(test_data)
    main()

# Generated at 2022-06-23 03:41:39.709918
# Unit test for function main
def test_main():
    import sys
    import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    modulename = 'getent'

    if sys.version_info[0] < 3:
        input = raw_input

    # Correct response
    print("Correct response")
    cmd = ['/bin/getent', 'passwd', 'root']
    rc = 0
    out = 'root:x:0:0:root:/root:/bin/bash'
    err = ''
    basic._ANSIBLE_ARGS = None

# Generated at 2022-06-23 03:41:46.489764
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import ansible.module_utils.action_plugins.action.getent

    module = basic.AnsibleModule(
        argument_spec=dict(
            database = dict(
                type = 'str',
                required = True
            ),
            key = dict(
                type = 'str',
                required = False
            ),
            fail_key = dict(
                type = 'bool',
                required = False
            )
        ),
        supports_check_mode = True
    )

    if __name__ == '__main__':
        ansible.module_utils.action_plugins.action.getent.main(module)

# Generated at 2022-06-23 03:41:47.888183
# Unit test for function main
def test_main():
    # Do nothing, only coverage
    main()

# Generated at 2022-06-23 03:42:00.560611
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'state'     : 'present',
        'fail_key'  : False,
        'database'  : 'shadow',
        'key'       : '',
        'split'     : None,
        'service'   : '',
    }, check_invalid_arguments = False)
    assert module.params['state'] == "present", "state should be present"
    assert module.params['fail_key'] == False, "fail_key should be false"
    assert module.params['database'] == "shadow", "database should be shadow"
    assert module.params['key'] == "", "key should be empty"
    assert module.params['split'] == None, "split should be None"
    assert module.params['service'] == "", "service should be empty"

# Generated at 2022-06-23 03:42:12.852332
# Unit test for function main
def test_main():
    import sys
    import os
    import inspect
    import mock
    import __builtin__ as builtins

    CUR_DIR = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    mock_paths = os.path.join(CUR_DIR, 'mock')
    sys.path.insert(0, mock_paths)
    sys.path.insert(0, CUR_DIR)

    with mock.patch('ansible.module_utils.basic.AnsibleModule') as am:
        import ansible.modules.system.getent
        am_inst = am.return_value
        am_inst.run_command.return_value = (0, "", "")

# Generated at 2022-06-23 03:42:22.611874
# Unit test for function main
def test_main():
    class ansible_module_getent_class:
        def __init__(self):
            pass
        def fail_json(self, *args, **kwargs):
            raise Exception("failing with specified arguments")
        def exit_json(self, *args, **kwargs):
            raise Exception("exiting with specified arguments")
        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/echo"
        def run_command(*args, **kwargs):
            class data:
                pass
            ret = data()
            ret.rc = 0
            ret.stdout = "a\nb"
            return ret, "", ""

    m = ansible_module_getent_class()
    main(m)

    m = ansible_module_getent_class()
    m.params

# Generated at 2022-06-23 03:42:23.115325
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:42:32.131511
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.urls import url_argument_spec
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes

    argument_spec = url_argument_spec()

# Generated at 2022-06-23 03:42:44.265870
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=False),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
        ),
    )

    class AnsibleModuleMock(object):
        def __init__(self, module_args):
            self.params = module_args

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-23 03:42:52.184564
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import io

    def _getent_bin(path, required=False):
        return './fake_bin'

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.params['database'] = 'passwd'
            self.params['key'] = 'root'

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            raise Exception('FAIL')

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False


# Generated at 2022-06-23 03:42:53.061190
# Unit test for function main
def test_main():
    assert True # no error, test passed

# Generated at 2022-06-23 03:43:07.910525
# Unit test for function main
def test_main():
    import os
    import errno
    import tempfile
    import textwrap
    import StringIO
    import sys
    import syslog
    import signal
    import pty
    import time
    import termios
    import fcntl
    import select
    import re

    try:
        import pexpect
    except ImportError:
        print('Skipping unit tests, pexpect is not installed')
        sys.exit(0)

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True
    )

    getent_bin

# Generated at 2022-06-23 03:43:20.502246
# Unit test for function main
def test_main():
    import os
    import shutil
    import sys

    # import getent module under test
    sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
    from lib.actions import getent

    # create fake ansible module and arguments
    module = AnsibleModule(dict(database='group'))

    # create our fake getent binary
    fake_bin = '''#!/usr/bin/python
import sys
import os

sys.exit(int(os.environ.get('GETENT_EXITCODE', '0')))

'''

    with open('/usr/bin/getent', 'w') as f:
        f.write(fake_bin)


# Generated at 2022-06-23 03:43:30.115712
# Unit test for function main
def test_main():
    # Test module parameters and exit condition
    args = dict(database='passwd', split=' ')
    ret = dict(ansible_facts=dict(getent_passwd=dict(root=['0', '0', '0', '0', '/root', '/bin/bash'])))
    test_module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True),
                                                   key=dict(type='str', no_log=False),
                                                   split=dict(type='str'),
                                                   service=dict(type='str'),
                                                   fail_key=dict(type='bool', default=True)))
    test_module.run_command = Mock(return_value=(0, 'root 0 0 0 0 /root /bin/bash', ''))
    the_result = test_module.exit

# Generated at 2022-06-23 03:43:34.603413
# Unit test for function main
def test_main():
    # import pdb; pdb.set_trace()
    cmd = "echo bar|base64"
    out, err = module.run_command(cmd)
    module.fail_json(msg=err)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:43:47.819425
# Unit test for function main

# Generated at 2022-06-23 03:44:00.433218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = "passwd"
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-23 03:44:05.507845
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params['key'] = 'root'
    module.params['database'] = 'passwd'
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-23 03:44:18.916522
# Unit test for function main
def test_main():
    import tempfile
    import json
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_

# Generated at 2022-06-23 03:44:30.747086
# Unit test for function main
def test_main():
    import os
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.platform import get_platform
    from ansible.module_utils.six import PY2
    from tempfile import mkstemp
    from shutil import copyfileobj
    import json
    import sys
    import os.path
    import os


# Generated at 2022-06-23 03:44:33.721924
# Unit test for function main
def test_main():
    test_dict = {}
    main(test_dict)
    assert test_dict['ansible_facts']['getent_passwd']['root'][1] == '0'

# Generated at 2022-06-23 03:44:46.412803
# Unit test for function main
def test_main():

    # Test logic getent_bin not found
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def _get_bin_path(name, required=False):
        raise OSError

    module.get_bin_path = _get_bin_path
    try:
        main()
    except OSError:
        pass

    # Test logic getent_bin runs

# Generated at 2022-06-23 03:44:55.446464
# Unit test for function main
def test_main():
    # Unit test for function main
    global module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main() is None

# Generated at 2022-06-23 03:45:05.114325
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    
    if not basic.HAS_PYTHON26:
        pytest.skip('Test requires python 2.6 or greater')

    def exec_command(self, cmd, in_data=None, sudoable=True):
        return 0, 'root:x:0:0:root:/root:/bin/bash\nadmin:x:1:1:admin:/:/bin/sh\n', ''


# Generated at 2022-06-23 03:45:07.716643
# Unit test for function main
def test_main():
  import mock
  import sys

  with mock.patch.object(sys, "argv", ["command"]):
    main()

# Generated at 2022-06-23 03:45:19.574412
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Good Arguments
    test_module.params['database'] = 'passwd'
    test_module.params['key'] = 'root'
    test_module.params['service'] = 'systemd'
    test_module.params['split'] = ':'
    test_module.params['fail_key'] = True
    main()
    test_module.params['database'] = 'group'
    test_module

# Generated at 2022-06-23 03:45:20.215123
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:45:28.257070
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    # Define required arguments
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        service=dict(type='str'),
        fail_key=dict(type='bool', default=True)
    )


# Generated at 2022-06-23 03:45:29.032730
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:43.551632
# Unit test for function main
def test_main():
    import os
    import ansible.module_utils.basic
    getentDebug = False
    class MockModule:
        params = dict()

        def get_bin_path(self, path, required=True):
            if getentDebug: print(path)
            return '/bin/getent'

        def fail_json(self, msg, exception=None):
            assert exception is None
            raise ansible.module_utils.basic.AnsibleError(msg)

        def run_command(self, args):
            if getentDebug: print(args)

            if args[0] == '/bin/getent':
                if args[1] == 'unknown':
                    return 1, '', ''

                if args[1] == 'notenumerate':
                    return 3, '', ''


# Generated at 2022-06-23 03:45:53.508379
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """

    #
    #  make test module
    #
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    #
    #  make mock module
    #
    class MockModule(object):
        """
        Class used to replace AnsibleModule for unit testing
        """

        def __init__(self):
            self.params = {}
            self.facts = {}


# Generated at 2022-06-23 03:46:06.086047
# Unit test for function main
def test_main():
    getent_bin = to_native('/bin/getent')
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:46:17.738450
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    import sys

    # Getter for module parameters
    def get_param(name):
        if name == "database":
            return 'group'
        elif name == "key":
            return 'root'
        elif name == "fail_key":
            return True
        else:
            raise Exception('Invalid module parameter specified')

    # Setter for module parameters
    def set_param(name, value):
        if name == "database":
            self.database = value
        elif name == "key":
            self.key = value
        elif name == "fail_key":
            self.fail_key = value
        else:
            raise Exception('Invalid module parameter specified')

    # Implements Ans

# Generated at 2022-06-23 03:46:29.851566
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    class AnsibleModule_fake(object):
        class ExitJson(object):
            arguments = {}
        class FailJson(object):
            arguments = {}

    module.exit_json = AnsibleModule_fake.ExitJson
    module.fail_json = AnsibleModule_fake.FailJson
    module.run_command = lambda a, b, c=None, d=None: (1, '', '')


# Generated at 2022-06-23 03:46:40.198910
# Unit test for function main
def test_main():

    fake_module = dict()
    fake_module['get_bin_path'] = lambda program, required_follow_on_mode=None: 'getent'

    class FakeModule:
        def __init__(self, module):
            self.fail_json = lambda a, b=None, c=None: None
            self.params = module
            self.exit_json = lambda a, b=None, c=None: None

        def run_command(self, cmd):
            return (0, 'test:123', '')

    with open('getent.py', 'r') as f:
        exec(f.read())
    main()

# Generated at 2022-06-23 03:46:52.890341
# Unit test for function main
def test_main():
    # Mock
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_native

    from mocker import Mocker
    from mocker import ANY
    from mocker import MATCH
    from mocker import KWARGS

    from io import StringIO

    # Constants
    getent_bin = ("/usr/bin/getent")

    # Variables
    mocker = Mocker()
    module = mocker.mock()
    module.params = {
            'database': 'passwd',
            'key': 'root',
            'split': ':',
            'service': None,
            'fail_key': True
        }


# Generated at 2022-06-23 03:47:01.047705
# Unit test for function main
def test_main():
    import imp
    import os

    sample_out = """passwd:x:0:0:root:/root:/bin/bash
passwd:x:1000:1000:user:/home/user:/bin/sh
passwd:x:1001:1001:user1:/home/user1:/bin/sh"""

    # create and change to work dir
    workdir = 'test_getent'
    os.mkdir(workdir)
    os.chdir(workdir)

    # create a fake module
    f_module = open('ansible/module_utils/fact.py', 'w')
    f_module.write('def exit_json(params):\n return 0\n')
    f_module.write('def fail_json(params):\n return -1\n')
    f_module.close()

    # create a fake

# Generated at 2022-06-23 03:47:11.135201
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = 'passwd'
    key = 'root'
    split = ':'
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-23 03:47:12.321353
# Unit test for function main
def test_main():
    """Unit test for function main"""
    pass

# Generated at 2022-06-23 03:47:27.768984
# Unit test for function main
def test_main():

    getent_bin = 'getent'

    def mock_run_command(module, cmd):
        rc = 0

        if cmd[1] == 'passwd':
            out = 'root:x:0:0:root:/root:/bin/bash\n' \
                  'daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n' \
                  'bin:x:2:2:bin:/bin:/usr/sbin/nologin\n' \
                  'sys:x:3:3:sys:/dev:/usr/sbin/nologin\n' \
                  'sync:x:4:65534:sync:/bin:/bin/sync\n'
        elif cmd[1] == 'group':
            out = 'root:x:0:root\n'

# Generated at 2022-06-23 03:47:35.146674
# Unit test for function main
def test_main():
    # Check that positional arguments are set
    with pytest.raises(Exception):
        main()

    # Check that required positional argument is set
    with pytest.raises(Exception):
        main({"database": "passwd"})

    # Check that required positional argument is set
    with pytest.raises(Exception):
        main({"database": "passwd", "key": "root"})

    # Check that data is returned
    ret = main({"database": "passwd", "key": "root"})
    assert ret