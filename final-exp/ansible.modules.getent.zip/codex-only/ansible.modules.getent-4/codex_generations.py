

# Generated at 2022-06-23 03:37:41.998189
# Unit test for function main
def test_main():
    # FYI: The source code for the test framework is at:
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/basic.py

    module = None # this will be filled-in by the test framework
    module.get_bin_path = lambda *args: "/usr/bin/getent"

    # Getent returns 1 when the database or key is not valid
    # Sadly, databases are different per OS, so we'll just check the return code
    # Key was not supplied
    # module.run_command = lambda *args: (1, "", "")
    # Key was supplied
    # module.run_command = lambda *args: (1, "", "")

    # Getent returns 2 when the key is not found
    # Key was not supplied
    module.run_

# Generated at 2022-06-23 03:37:51.313576
# Unit test for function main
def test_main():
    import json
    import os
    import subprocess
    import tempfile
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class FakeModule():
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False, no_log=True, check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False, supports_diff=True):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.bypass_checks = bypass_checks
            self.no_log = no_log

# Generated at 2022-06-23 03:37:52.785220
# Unit test for function main
def test_main():
    print("testing main")
    assert True == True


# Generated at 2022-06-23 03:37:59.829050
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    def run_command(cmd):
        return 1, '', 'Missing arguments, or database unknown.'

    module.run_command = run_command
    main()



# Generated at 2022-06-23 03:38:08.755438
# Unit test for function main
def test_main():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from test.unit import AnsibleModuleTestCase

    def run_module(*args, **kwargs):
        """
        Wrapper to allow for running directly for test purposes
        """
        module_args = dict(
            database='passwd',
            key='root'
        )
        module_args.update(kwargs)
        module = AnsibleModule(**module_args)
        main()

    class Test(AnsibleModuleTestCase):
        def test_root_passwd_record(self):
            run_module(database='passwd', key='root')

# Generated at 2022-06-23 03:38:17.061356
# Unit test for function main
def test_main():
    import ast
    import copy

    with open('getent.txt', 'r') as f:
        myfile = f.read()
    from ansible.modules.system.getent import *
    module2 = AnsibleModule(argument_spec={"database": {"required": True, "type": "str"}, "split": {"required": False, "default": None, "type": "str"}, "key": {"required": False, "default": None, "type": "str"}, "fail_key": {"required": False, "default": True, "type": "bool"}, "service": {"required": False, "default": None, "type": "str"}}, supports_check_mode=True)
    module2.run_command = lambda *args, **kwargs: (0, "", "")

# Generated at 2022-06-23 03:38:28.860252
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )

    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, 'passwd', 'root']

    rc, out, err = module.run_command(cmd)

    assert(rc == 0)
    assert(len(out) > 0)

# Generated at 2022-06-23 03:38:35.977546
# Unit test for function main
def test_main():
    # From the examples
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-23 03:38:45.640486
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params.get('database')
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    main()

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

# Generated at 2022-06-23 03:38:56.960496
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    module.run_command = MagicMock(return_value=(1, None, None))
    with pytest.raises(AnsibleExitJson) as exc:
        main()
    result = exc.value.args[0]
    assert not result['changed']

# Generated at 2022-06-23 03:39:01.113136
# Unit test for function main
def test_main():
    import sys
    import json

    with open("tests/getent/key.json") as open_file:
        key_json = json.load(open_file)

        for key in key_json:
            main(sys.argv[1:], key)
        sys.exit(0)

# Generated at 2022-06-23 03:39:10.512992
# Unit test for function main
def test_main():
    class MockModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path, required):
            return required

        def fail_json(self, msg):
            raise AssertionError(msg)

        def exit_json(self, **kwargs):
            return kwargs

        def run_command(self, cmd):
            return 0, "", ""

    def mock_failer(self):
        raise AssertionError

    class MockAnsibleModule:
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 03:39:22.082694
# Unit test for function main
def test_main():
    import os
    import sys

    # Imports required for testing
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.pycompat24 import get_exception
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args, exit_json, fail_json, AnsibleExitJson, AnsibleFailJson

    # Generate a test path
    testlib_path = 'ansible_collections.ansible.community.tests/unit/modules/' \
        'ansible_collections/ansible/community/plugins/modules/getent'
    testlib_full_path = unfrackpath(testlib_path, prepend=False)

    # Generate a fake module for testing

# Generated at 2022-06-23 03:39:32.064494
# Unit test for function main
def test_main():

    #Test err handling
    def run_command(params):
        cmd = params[0]
        rc = 1
        out = 'message'
        err = 'error'
        return rc, out, err

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        ),
        supports_check_mode=True,
    )

    module.run_command = run_command

    #Test no split err
    rc = 1
    dbtree = 'getent_%s' % 'database'
    results = {dbtree: {}}


# Generated at 2022-06-23 03:39:44.043448
# Unit test for function main
def test_main():
    import os
    import sys
    import re
    import shutil
    import tempfile

    try:
        from ansible.module_utils.six import StringIO
        from ansible.module_utils.six.moves import cPickle # pylint: disable=wrong-import-order

        HAS_SIX = True
    except:
        HAS_SIX = False

    if not HAS_SIX:
        print("TEST SKIP: python-six required for this test")
        exit(0)

    if shutil.which('getent') is None:
        print("TEST SKIP: getent not found")
        exit(0)

    real_stdout = sys.stdout
    real_stdin = sys.stdin
    real_stderr = sys.stderr

    sys.stdin = StringIO

# Generated at 2022-06-23 03:39:53.658655
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import io

    getent_bin = '/usr/bin/getent'

    module_args = dict(
            database='passwd',
            key='root',
            split=':'
    )
    db_results = "%s:*:0:0:root:/root:/bin/bash\n" % to_native(module_args['key'])

    module = AnsibleModule(argument_spec=dict(
        database=dict(required=True),
        key=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True)
    ))


# Generated at 2022-06-23 03:40:00.055375
# Unit test for function main
def test_main():
    # Unit test with no arg
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
    )
    main()



# Generated at 2022-06-23 03:40:04.800530
# Unit test for function main
def test_main():
    # GIVEN a list of kwargs
    kwargs = dict(
        database='database',
        key='key',
        #split='split',
        service='service',
        fail_key=False,
    )

    # WHEN the function is called
    main(**kwargs)