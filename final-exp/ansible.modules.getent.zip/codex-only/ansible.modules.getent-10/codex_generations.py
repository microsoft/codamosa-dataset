

# Generated at 2022-06-23 03:37:33.843125
# Unit test for function main
def test_main():
    # Note
    # - Add unit tests in the future if possible
    pass

# Generated at 2022-06-23 03:37:44.514660
# Unit test for function main
def test_main():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


    m = TestModule(database='passwd', key='root', fail_key=False)
    try:
        main()
    except Exception as e:
        pass
    assert m.exit_args[1]['ansible_facts']['getent_passwd']['root'][0] == 'x'

# Generated at 2022-06-23 03:37:44.861679
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:37:48.838527
# Unit test for function main
def test_main():
    import os
    import sys

    #TODO: need to update the test for extra args
    test_file_path = os.path.abspath(os.path.dirname(__file__))
    test_data_path = os.path.join(test_file_path, '..', 'unit', 'data')
    test_data = open(os.path.join(test_data_path, 'getent_shadow.txt'), 'r').read()
    if sys.version_info[0] < 3:
        test_data = test_data.decode('utf-8')

    with open('/tmp/ansible_getent_module.sock', 'w') as stdin_sock:
        stdin_sock.write(test_data)
        stdin_sock.flush()


# Generated at 2022-06-23 03:37:58.666582
# Unit test for function main
def test_main():
    fail_json = {"invocation": {"module_name": "getent"}}
    test_bin_path = "ansible/test/unit/utils/test_module_utils_basic/test_bin_path"
    getent_bin = "path/to/getent/bin"
    mock_run_command = "ansible.module_utils._text.mock_run_command"


# Generated at 2022-06-23 03:38:08.107432
# Unit test for function main
def test_main():
    # Mock module
    class Module(object):
        def __init__(self, database, key=None, split=None, service=None, fail_key=None):
            self.params = {'database': database, 'key': key, 'split': split, 'service': service, 'fail_key': fail_key}

        def get_bin_path(self, bin, required):
            pass

        def run_command(self, cmd):
            pass

        def fail_json(self):
            pass

        def exit_json(self):
            pass

    # Mock run_command
    # esult codes, stdout, and stderr
    #rc, out, err = 0, 'abc:abc\ndef:def', ''
    rc, out, err = 2, '', ''

# Generated at 2022-06-23 03:38:17.284552
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-23 03:38:20.564485
# Unit test for function main
def test_main():
    assert True

# Unit test helper
# create a fixture to use in unit test

# Generated at 2022-06-23 03:38:30.857526
# Unit test for function main
def test_main():
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    getent_bin = '/usr/bin/getent'
    module_mock = AnsibleModule(argument_spec, supports_check_mode=True)
    module_mock.run_command = MagicMock(return_value=(0, 'root:x::::::\nbin:x:1:1:bin:/bin:/bin/sh\n', ''))
    module_mock.get_bin_path = MagicMock(return_value=getent_bin)

    main()


# Generated at 2022-06-23 03:38:42.374611
# Unit test for function main
def test_main():
    import json

    db_name = 'passwd'
    key = 'root'
    expected_keys = ['uid', 'gid', 'gecos', 'home', 'shell']

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', default=db_name),
            key=dict(type='str', no_log=False, default=key),
            split=dict(type='str', default=':'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    results = main()
    results_json = json.loads(results)

    # has fields
    assert results_json['ansible_facts']['getent_{}'.format(db_name)][key]
    # correct fields
   

# Generated at 2022-06-23 03:38:54.442510
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:38:56.693042
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:39:03.813540
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-23 03:39:13.009113
# Unit test for function main
def test_main():
    # if getent is not available or does not work, we won't run the tests
    # this will cause the test to error out
    try:
        getent_bin = module.get_bin_path('getent', True)
        rc, out, err = module.run_command([getent_bin])
        assert rc == 0
    except:
        return

    module_arg_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    # populate the args
    set_module_args(dict(database='passwd',key='root',split=':'))
    # the command to run

# Generated at 2022-06-23 03:39:20.908107
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.facts import Facts
    module_utils = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    facts = Facts(module_utils=module_utils)

    keys = ['getent_passwd', 'getent_group', 'getent_hosts', 'getent_services']

    # passwd
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # default action is to return all database

# Generated at 2022-06-23 03:39:21.447956
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:39:29.578555
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import *

    try:
        from unittest.mock import patch, Mock
    except:
        from mock import patch, Mock


    ################
    # argument setup
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    ################
    # function call
    main()

# Generated at 2022-06-23 03:39:30.255562
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:39:40.809902
# Unit test for function main
def test_main():
    test_parameters = dict(
        database="aliases",
        key="root"
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params = test_parameters

    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, test_parameters["database"], test_parameters["key"]]

    rc, out, err = module.run_command(cmd)

    msg = "Unexpected failure!"

# Generated at 2022-06-23 03:39:41.398599
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:39:52.004655
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
        ),
        supports_check_mode=True,
    )

    database = module.params.get('database')

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ModuleFailException(Exception):
        pass

    class ExitModule(object):
        @staticmethod
        def exit_json(**kwargs):
            if 'changed' not in kwargs:
                kwargs['changed'] = False
            raise AnsibleExitJson(kwargs)

        @staticmethod
        def fail_json(**kwargs):
            raise AnsibleFailJson(kwargs)


# Generated at 2022-06-23 03:39:57.305277
# Unit test for function main
def test_main():
    import os
    import json
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m_path = os.path.join(os.path.dirname(__file__), '..', '..', 'hacking', 'test_module.py')
    args = dict(
        database='passwd',
        key='root',
    )
    with open(m_path, 'rb') as f:
        basic._ANSIBLE_ARGS = to_bytes(json.dumps(args))
        main()

# Generated at 2022-06-23 03:40:09.041108
# Unit test for function main
def test_main():
    # import python hooks
    import sys, os

    # import ansible testing hooks
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    # make sure the testing framework is available
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib'))
    import tests

    # initialize base class

# Generated at 2022-06-23 03:40:17.739343
# Unit test for function main
def test_main():
    import sys
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    main()
    out=sys.stderr.getvalue()
    assert to_bytes(out) == to_bytes("")
    # main()
    # out = sys.stdout.getvalue()
    # print(out)
    # out = json.loads(out)
    # assert out['ansible_facts']['getent_passwd'] == 'root'

# Generated at 2022-06-23 03:40:28.885030
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import stat

    orig_module_utils = None


# Generated at 2022-06-23 03:40:33.619452
# Unit test for function main
def test_main():
    with open('/etc/group') as f:
        try:
            for line in f:
                if line.startswith('sudo'):
                    return True
        except Exception as e:
            traceback.print_exc()
            return False

# Generated at 2022-06-23 03:40:34.408012
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:40:35.042199
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:40:45.547204
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    class AnsibleModuleMock(basic.AnsibleModule):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['fail_key'] = True
            self.bin_path = lambda x: '/bin/getent'
            self.run_command_environ_update = {}

        def fail_json(self, **kwargs):
            raise SystemExit(kwargs['msg'])

        def exit_json(self, **kwargs):
            raise SystemExit

        def get_bin_path(self, exe, required=True):
            return get_bin_path(exe, required=required)


# Generated at 2022-06-23 03:40:48.791341
# Unit test for function main
def test_main():
    # Unit test getent module
    args = {'database': 'passwd', 'key': 'root'}
    module = AnsibleModule(**args)
    main()

# Generated at 2022-06-23 03:41:01.704097
# Unit test for function main
def test_main():
    import sys
    sys.path.append('/usr/lib64/python2.7/site-packages/ansible/module_utils/')
    import ansible.module_utils.action
    import ansible.module_utils.facts
    import ansible.module_utils.basic
    import imp
    import os
    import shutil
    import tempfile
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.facts

    import getent as m
    test_module = imp.load_source('module', '../getent')

    # just in case
    assert test_module.main() is None


    def run_module():
        sys.modules.pop('ansible.module_utils.basic')

# Generated at 2022-06-23 03:41:12.337011
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    module.run_command = mock.Mock(return_value=(0, "foo:bar", ""))
    main()
    assert module.exit_json.called

    module.run_command = mock.Mock(return_value=(2, "", ""))
    main()
    assert module.fail_json.called

# Generated at 2022-06-23 03:41:20.786387
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    test_module.params.update({ 'database': 'passwd', })
    test_module.get_bin_path = lambda x, y: ""
    test_module.run_command = lambda x: (0, "root:x:0:0:root:/root:/bin/bash", "")

    main()
    assert test_module.exit_json_called

# Generated at 2022-06-23 03:41:32.054720
# Unit test for function main
def test_main():
    # Called from ansible module_utils module.debug(msg) function
    def debug(msg):
        module.debug(msg)

    # Called from ansible module_utils module.fail_json(msg) function.
    # Fails execution.
    def fail_json(msg):
        module.fail_json(msg=msg)

    # Called from ansible module_utils module.get_bin_path(module, required=True) function.
    def get_bin_path(module, required=True):
        return module

    # Called from ansible module_utils module.run_command(cmd) function.
    # Fakes running of command on host.
    def run_command(cmd):
        if cmd[-1] == 'gshadow':
            raise Exception('', '', '')

# Generated at 2022-06-23 03:41:38.787805
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    # set up our module object
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    print(main().ansible_facts.getent_passwd)
    return basic.AnsibleModule;

# Generated at 2022-06-23 03:41:49.637084
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = lambda *args: [0, '0:1:2:3:4:5:6:7:8:9', None]
    out = main()
    assert out.get('ansible_facts') == {'getent_str': {'0': ['1', '2', '3', '4', '5', '6', '7', '8', '9']}}


# Generated at 2022-06-23 03:41:55.219534
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.exit_json(ansible_facts=dict(
        getent_passwd=dict(
            user='user',
        ),
    ))


# Generated at 2022-06-23 03:41:57.248910
# Unit test for function main
def test_main():
    cmd = ['/bin/getent', 'passwd', 'root']
    assert_equal(main(cmd), "0")

# Generated at 2022-06-23 03:42:07.001885
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:42:16.251986
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    database = 'passwd'
    key = 'root'
    split = ':'
    service = None
    fail_key = True
    module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True),
    key=dict(type='str', no_log=False),
    service=dict(type='str'),
    split=dict(type='str'),
    fail_key=dict(type='bool', default=True)))

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    module.params['database'] = database
    module.params['key'] = key
    module.params['split'] = split
    module.params['service'] = service
    module.params['fail_key'] = fail_key

   

# Generated at 2022-06-23 03:42:27.380632
# Unit test for function main
def test_main():
    # Local import to speed test
    def run_command(*args, **kwargs):
        if args[0] == ['/bin/getent', 'passwd', 'root']:
            return (0, 'root:x:0:0:root:/root:/bin/bash\n', '')
        if args[0] == ['/bin/getent', 'group', 'root', '-s', 'files']:
            return (0, 'root:x:0:\n', '')
        if args[0] == ['/bin/getent', 'hosts', 'localhost', '-s', 'files']:
            return (0, '127.0.0.1\tlocalhost localhost.localdomain\n', '')
        return (0, '', '')


# Generated at 2022-06-23 03:42:37.889649
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile

    if not os.path.exists('/usr/bin/getent'):
        return

    src_test_file = tempfile.NamedTemporaryFile()
    src_test_file.write(b'''
[defaults]
gathering = fact
fact_caching = ./facts

[myhost]
localhost
''')
    src_test_file.flush()

    sys.argv = ['ansible-playbook', '--inventory-file={0}'.format(
        src_test_file.name), '--connection=local', '--timeout=60',
        'examples/getent.yml']

    from ansible.cli import CLI
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-23 03:42:49.676454
# Unit test for function main
def test_main():
    # Test #1
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-23 03:43:01.740902
# Unit test for function main
def test_main():
    import sys

# Generated at 2022-06-23 03:43:15.078494
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    # Need to mock get_bin_path
    main_mod = main
    main_mod._username = None
    main_mod._password = None

    def get_bin_path(name, required):
        return name

    main_mod.get_bin_path = get_bin_path
    main_mod._ansible_debug = False

    # Need to mock AnsibleModule

# Generated at 2022-06-23 03:43:27.312627
# Unit test for function main
def test_main():
    import sys
    sys.path.append('/home/ansible/ansible_source/modules/actions')
    from getent import main

    fake_module = object()
    setattr(fake_module, 'run_command',
            lambda args: (0, 'root:x:0:0::/root:/bin/sh\ndocker:x:1000:1000:,,,:/home/docker:/bin/bash', ''))
    setattr(fake_module, 'params', {'database': 'passwd', 'key': 'docker'})
    setattr(fake_module, 'exit_json', lambda **kwargs: print(kwargs))
    setattr(fake_module, 'fail_json', lambda **kwargs: print(kwargs))
    try:
        main(fake_module)
    except SystemExit as e:
        print

# Generated at 2022-06-23 03:43:39.181375
# Unit test for function main
def test_main():

    return_test_results_no_key = {"msg": "Missing arguments, or database unknown.", "failed": True, "changed": False, "rc": 1}
    return_test_results_passwd = {"ansible_facts": {
        "getent_passwd": {"root": ["x", "0", "0", "root", "/root", "/bin/bash"], "brian": ["x", "1000", "1000", "brian", "/home/brian", "/bin/zsh"]}
    }}
    return_test_results_group = {"ansible_facts": {
        "getent_group": {"root": ["x", "0", "root"], "brian": ["x", "1000", "brian", "coca"]}
    }}

# Generated at 2022-06-23 03:43:51.291615
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)
    key = 'root'

# Generated at 2022-06-23 03:44:03.359993
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    import textwrap
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils._text import to_bytes

    # This is the most basic test for calling a module
    # It is using the 'system' module as an example

# Generated at 2022-06-23 03:44:04.137056
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:44:13.322325
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = Mock(return_value=(0, "foo", ""))

    main()

# Generated at 2022-06-23 03:44:16.821820
# Unit test for function main
def test_main():
  args = {'service': None, 'key': u'root', 'split': None, 'database': u'passwd'}
  main(args)

# Generated at 2022-06-23 03:44:28.788674
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Params
    database = 'passwd'
    key = 'root'
    split = None
    service = None
    fail_key = True

    # Mock @Basic
    # Params
    check_mode = False
    diff_mode = False
    no_log = False
    verbosity = 3
    # Setup
    basic._ANSIBLE_ARGS = None
    # Module creation

# Generated at 2022-06-23 03:44:38.344965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    #module.get_bin_path('getent')
    module.run_command = Mock(return_value=(0, 'test', ''))
    module.exit_json(ansible_facts={'test': 'test'})


# Generated at 2022-06-23 03:44:45.101176
# Unit test for function main
def test_main():

    # key found in database
    test_params = {
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': ':',
        'fail_key': True,
    }

    import ansible.module_utils.basic
    res = main()
    print(res)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:44:54.376452
# Unit test for function main
def test_main():
    import platform, os

    # getent module on FreeBSD is missing -s option so we skip the test
    if platform.system() == 'FreeBSD':
        return

    # Check importing and function main
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )

    # Run with main arguments
    main_args = dict(
        database='passwd',
        key='root',
        service=None,
        split=None,
        fail_key=True,
    )
    setattr

# Generated at 2022-06-23 03:44:55.027066
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:45:00.688340
# Unit test for function main
def test_main():
    # arguments is a dict containing both the arguments passed via **kwargs and all the required
    # args that are documented above in the documentation string
    arguments = dict(database='passwd')
    module = AnsibleModule(**arguments)
    main()


# Generated at 2022-06-23 03:45:07.901381
# Unit test for function main
def test_main():
    class AnsibleModuleMock(object):
        exit_json = lambda self, ansible_facts: False
        fail_json = lambda self, msg: False
        param = lambda self: False
        run_command = lambda self, cmd: (0, '', '')
        get_bin_path = lambda self, binary, required=False: ''

    am = AnsibleModuleMock()
    dbtree = 'getent_%s' % 'passwd'

    assert main(am) == {dbtree: {}}

# Generated at 2022-06-23 03:45:19.784501
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rc = 0
    out = 'root:x:0:0:root:/root:/bin/bash'
    err = None

    module.run_command = MagicMock(return_value=(rc, out, err))
    getent_bin = '/usr/bin/getent'

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-23 03:45:21.317546
# Unit test for function main
def test_main():
    exit_code, out, err = main()
    assert exit_code == 2

# Generated at 2022-06-23 03:45:28.813684
# Unit test for function main
def test_main():
    import sys
    import ansible.constants as C
    import ansible.module_utils.facts.system.getent as getent_funcs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic import AnsibleModuleMock

    sys.modules['ansible'] = AnsibleModuleMock()

    # use the module as if it was called as an action plugin on ansible 2.9
    ansible_config = ImmutableDict({'config_file': C.DEFAULT_CONFIG_FILE})
    sys.modules['ansible'].AnsibleModule = getent_funcs.AnsibleModule
    sys.modules['ansible'].CONSTANTS = ansible_config

    #

# Generated at 2022-06-23 03:45:37.724470
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    try:
        # Tests
        main()
    except SystemExit:
        pass
    except Exception:
        import traceback
        print(traceback.format_exc())
        raise AssertionError('Unhandled exception')

# Generated at 2022-06-23 03:45:46.533092
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.six.moves import StringIO
    with basic.create_fake_module(sys.modules[__name__]) as fake_module:
        fake_module.main()

# Generated at 2022-06-23 03:45:47.450098
# Unit test for function main
def test_main():
    os.system('touch getent')
    main()

# Generated at 2022-06-23 03:45:55.931800
# Unit test for function main
def test_main():
    # Mock module class
    class AnsibleModuleMock:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {'key': 'root', 'database': 'passwd'}

        def get_bin_path(self, arg1, arg2):
            return '/usr/bin/getent'


# Generated at 2022-06-23 03:46:08.030363
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    failed = True
    test_module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_module.params['database'] = 'passwd'
    test_module.params['key'] = 'root'
    test_module.params['fail_key'] = True

    test_getent_bin = test_module.get_bin_path('getent', True)


# Generated at 2022-06-23 03:46:08.875625
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:46:13.987242
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
    )

    # Mock the args from AnsibleModule
    args = {
        'key': 'root',
        'database': 'passwd',
        'fail_key': True,
        'service': None,
        'split': ':',
    }

    return_value = main()
    print(return_value)
    module.exit_json(**return_value)



# Generated at 2022-06-23 03:46:22.222194
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main

    module = AnsibleModule(argument_spec={
        'database': {'type': 'str', 'required': True},
        'key': {'type': 'str', 'no_log': False},
        'split': {'type': 'str'},
        'service': {'type': 'str'},
        'fail_key': {'type': 'bool', 'default': True},
    }, supports_check_mode=True)

    main()

# Generated at 2022-06-23 03:46:23.737916
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:46:30.269874
# Unit test for function main
def test_main():
    # Test fail cases
    assert main({
        'database': 'passwd',
        'key': 'root',
        'state': 'present',
        'provider': '{{login_provider}}',
        'check_mode': True
    }) == {
        'failed': True,
        '_ansible_verbose_override': False,
        'msg': 'Missing arguments, or database unknown.'
    }

    # Test success cases

# Generated at 2022-06-23 03:46:36.100168
# Unit test for function main
def test_main():
    getent_module = AnsibleModule(argument_spec=dict(
        database=dict(required=True, type='str'),
        key=dict(required=False, no_log=False, type='str'),
        service=dict(required=False, type='str'),
        split=dict(required=False, type='str'),
        fail_key=dict(required=False, type='bool', default=False),
    ), supports_check_mode=True)

    getent_module.get_bin_path = MagicMock(return_value='/usr/bin/getent')
    getent_module.run_command = MagicMock(return_value=(0, '0:root:x:0:0::/root:/bin/bash\n0:root:x:0:0::/root:/bin/bash', ''))

   

# Generated at 2022-06-23 03:46:44.767797
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-23 03:46:45.717233
# Unit test for function main
def test_main():
    run_cmd = lambda: main()
    assert True == True

main()

# Generated at 2022-06-23 03:46:52.066740
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'database': dict(type='str', required=True),
        'key': dict(type='str', no_log=False),
        'service': dict(type='str'),
        'split': dict(type='str'),
        'fail_key': dict(type='bool', default=True)
    },
                           supports_check_mode=True)
    class MockPexpect():
        def __init__(self, command):
            pass
        
        def run(self, command):
            if command[1] == 'passwd':
                return 0, 'test:x:24:24::test:/test:/test\nroot:x:0:', ''

# Generated at 2022-06-23 03:47:07.227860
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils._text as to_text

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get

# Generated at 2022-06-23 03:47:19.019958
# Unit test for function main
def test_main():
    res = {}

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.return_values = {}
            self.run_command_values = {}
            self.exit_json_values = {}
            self.fail_json_values = {}
            self.command = None

        def run_command(self, command):
            self.command = command
            return self.return_values[command]

        def exit_json(self, **kwargs):
            self.exit_json_values = kwargs

        def fail_json(self, **kwargs):
            self.fail_json_values = kwargs

        def get_bin_path(self, path, default=None):
            self.path = path
            return default


# Generated at 2022-06-23 03:47:32.746351
# Unit test for function main
def test_main():
    import sys
    import os

    # Run integration test
    if os.path.isdir('test/integration/output'):
        module_args = {}
        module_args.update(
            dict(
                database='passwd',
                key='root'
            )
        )
        result = {}

        def do_exit(rc=0, msg='', **kwargs):
            result['rc'] = rc
            result['msg'] = msg
            result['kwargs'] = kwargs

            sys.exit(0)

        class FakeModule(object):
            params = module_args

            def fail_json(self, **args):
                do_exit(**args)

            def exit_json(self, **args):
                do_exit(**args)
