

# Generated at 2022-06-23 03:37:40.074124
# Unit test for function main
def test_main():
    MODULE_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                               '../../lib/ansible/modules/system/getent.py')
    module = imp.load_source('getent', MODULE_PATH)
    rc, out, err = module.main({'fail_key': 'yes', 'database': 'passwd', 'key': 'root'})
    assert rc == 0
    assert out



# Generated at 2022-06-23 03:37:45.739745
# Unit test for function main
def test_main():
    module = AnsibleModule(
    argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ),
    supports_check_mode=True,
    )
    rc = main()
    assert rc == rc

# Generated at 2022-06-23 03:37:56.423926
# Unit test for function main
def test_main():
    import shutil
    import tempfile

    # Test 1:
    # Test run with getent that returns and exit code of 2
    # which is the code for when a key is not found.  This should
    # return "One or more supplied key could not be found in the database."
    test_result = _test_temp_main(rc=2,
                                  cmd=['getent', '-s', 'test', '-k', 'blah'],
                                  expected_rc=1,
                                  expected_msg="One or more supplied key could not be found in the database.")
    # Test 2:
    # Test run with getent that returns an exit code of 0
    # and returns test data.  This should return True.

# Generated at 2022-06-23 03:38:07.643168
# Unit test for function main
def test_main():
    import sys
    sys.modules.clear()
    import json
    import inspect
    import ansible.module_utils.basic
    import ansible.module_utils._text
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic
    sys.modules['ansible.module_utils._text'] = ansible.module_utils._text

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native


# Generated at 2022-06-23 03:38:10.197697
# Unit test for function main
def test_main():
    my_dict = {'getent_passwd' : {'a': []}}
    assert(main() == my_dict)

# Generated at 2022-06-23 03:38:21.193540
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_getent_module import main
    from ansible import context
    import sys

    context._init_global_context(load_plugins=False)
    #context.CLIARGS = ImmutableDict(connection='local', module_path=['/to/mymodules'], forks=10, become=None,
                                    #become_method=None, become_user=None, check=False, diff=False)
    #context.CLIARGS = ImmutableDict({'connection': 'local', 'module_path': ['/to/mymodules'], 'forks': 10, 'become': None, 'become_method': None, 'become_user': None, 'check': False, 'diff': False})

# Generated at 2022-06-23 03:38:29.301614
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(database='hosts', key='localhost', split='\t', fail_key=True, no_log=True)

    module.run_command = Mock(return_value=(0, "127.0.0.1\tlocalhost\n", ""))
    module.get_bin_path = Mock(return_value="/usr/bin/getent")

    main()
    assert module.exit_json.called is True
    assert module.exit_json.call_args[0][0]['changed'] == False


# Generated at 2022-06-23 03:38:41.214346
# Unit test for function main
def test_main():
    # test getent returns keys and values
    rc, out, err = main(['passwd', 'root'])
    assert rc == 0, "Unexpected failure!"
    assert out.get("getent_passwd").get("root") == ['x', '0', '0', 'root', '/root', '/bin/bash'], "Unexpected failure!"

    # test getent should fail if key is not present
    rc, out, err = main(['passwd', 'root'])
    assert rc == 0, "Unexpected failure!"
    assert out.get("getent_passwd").get("root") == ['x', '0', '0', 'root', '/root', '/bin/bash'], "Unexpected failure!"

    # test getent returns all keys and values and fails if key is not present

# Generated at 2022-06-23 03:38:53.323750
# Unit test for function main
def test_main():
    import sys
    import json
    import platform

    from ansible.module_utils.facts import ansible_posix_facts

    # unit test provides the os_facts
    facts = ansible_posix_facts()

# Generated at 2022-06-23 03:39:02.005490
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    import json

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_

# Generated at 2022-06-23 03:39:11.977279
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping, Sequence
    assert hasattr(main(), 'ansible_facts')
    assert isinstance(main().ansible_facts, Mapping)
    assert hasattr(main().ansible_facts, 'getent_hosts')
    assert hasattr(main().ansible_facts, 'getent_group')
    assert hasattr(main().ansible_facts, 'getent_passwd')
    assert hasattr(main().ansible_facts, 'getent_services')
    assert hasattr(main().ansible_facts, 'getent_shadow')
    assert isinstance(main().ansible_facts['getent_hosts'], Mapping)
    assert isinstance(main().ansible_facts['getent_group'], Mapping)

# Generated at 2022-06-23 03:39:23.376978
# Unit test for function main
def test_main():
    import sys
    import imp
    from ansible.module_utils.basic import AnsibleModule
    import unittest

    # hack used to setup the testing environment
    # by creating a fake ansible module
    __name__ = 'test_getent'
    main = imp.new_module('ansible.modules.identity.getent')
    main.AnsibleModule = AnsibleModule
    main.main()
    sys.modules['ansible.modules.identity.getent'] = main

    class TestGetent(unittest.TestCase):
        def test_main(self):
            # FIXME: implement utests
            import doctest
            import inspect
            failures, tests = doctest.testmod(
                    inspect.getmodule(main)
            )
            assert failures == 0, 'Doctests have failed'
   

# Generated at 2022-06-23 03:39:24.260536
# Unit test for function main
def test_main():
    function_name = 'main'
    args = {}

# Generated at 2022-06-23 03:39:26.680451
# Unit test for function main
def test_main():

    main()

    return {'changed': False, 'failed': False, 'skipped': False}

# Generated at 2022-06-23 03:39:33.939625
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:39:42.951582
# Unit test for function main
def test_main():
    test_input = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_input.run_command = MagicMock(return_value=(0, '', ''))
    test_input.get_bin_path = MagicMock(return_value='')

    main()

# Generated at 2022-06-23 03:39:48.647045
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:40:01.803946
# Unit test for function main
def test_main():
    test_class = getent()
    argv = ['-m', 'ansible.module_utils.basic', '-a', '{"database":"database_param","key":"key_param","split":"split_param","service":"service_param","fail_key":"fail_key_param", "AN_BOOL": "yes", "AN_STR": "Hello"}']
    b_json, shebang, dummy_bin = test_class.debug(argv=argv)

    assert b_json['database'] == 'database_param'
    assert b_json['key'] == 'key_param'
    assert b_json['split'] == 'split_param'
    assert b_json['service'] == 'service_param'
    assert b_json['fail_key'] == 'fail_key_param'

# Generated at 2022-06-23 03:40:12.683326
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-23 03:40:22.825693
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    import pytest
    import os
    import sys
    import re

    with pytest.raises(SystemExit):
        with pytest.raises(AssertionError):
            main()

    main_path = os.path.join(sys.path[0], 'getent.py')


# Generated at 2022-06-23 03:40:34.272850
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.pycompat24 import get_exception_type
    from ansible.module_utils.pycompat24 import set_module_args
    from ansible.module_utils.pycompat24 import unittest
    import ansible.modules.system.getent

    module = ansible.modules.system.getent
    module.__name__ = 'ansible.modules.system.getent'

    if not hasattr(unittest.TestCase, 'assertIn'):
        def assertIn(self, member, container, msg=None):
            if member not in container:
                standardMsg = '%s not found in %s' % (member, container)

# Generated at 2022-06-23 03:40:35.273046
# Unit test for function main
def test_main():
    result = None
    assert result == False

# Generated at 2022-06-23 03:40:45.727320
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.action import ActionBase
    import sys

    sys.path.insert(0, '../')

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params

# Generated at 2022-06-23 03:40:55.554471
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-23 03:40:56.089443
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:41:09.338133
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = "passwd"
    key = "root"
    split = ":"
    service = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-23 03:41:18.152443
# Unit test for function main
def test_main():
    import sys
    if 'lib' not in sys.path:
        sys.path.append('lib')
    try:
        from ansible.module_utils import basic
        from ansible.module_utils.common.process import get_bin_path
    except ImportError as e:
        print(e)
        raise SkipTest

    class AnsibleModuleMock():
        def __init__(self, argument_spec, check_mode, supports_check_mode):
            self.argument_spec = argument_spec
            self.check_mode = check_mode
            self.supports_check_mode = supports_check_mode
            self.params = {
                'database': 'group',
                'service': '',
                'key': 'samba',
                'split': '',
                'fail_key': False
            }
           

# Generated at 2022-06-23 03:41:30.288910
# Unit test for function main
def test_main():
    import os
    import sys
    import subprocess

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    if 'GETENT_DB' not in os.environ:
        print("Skipping unit test for getent, no $GETENT_DB defined")
        sys.exit(0)

    db = os.environ['GETENT_DB']

    output = b'a:x:0:0:root:/root:/bin/bash\n'

# Generated at 2022-06-23 03:41:34.881623
# Unit test for function main
def test_main():
    params = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
        'fail_key': True
    }
    m = AnsibleModule(argument_spec=params)
    rc, out, err = main()
    assert rc == 0


# Generated at 2022-06-23 03:41:44.394990
# Unit test for function main
def test_main():

  data = dict(
    database='passwd',
    split=":",
    service=None
  )

  module = AnsibleModule(
    argument_spec=dict(
      database=dict(type='str', required=True),
      key=dict(type='str', no_log=False),
      service=dict(type='str'),
      split=dict(type='str'),
      fail_key=dict(type='bool', default=True),
    ),
    supports_check_mode=True,
  )
  module.params.update(data)
  res,out,err = main()
  assert res['changed'] is True

# Generated at 2022-06-23 03:41:57.032094
# Unit test for function main
def test_main():
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    module = type('', (), {})
    module.params = {"service": "ntp"}
    module.run_command = lambda params: (0, "a:b\n", "")
    module.get_bin_path = lambda x, y: "/bin/getent"
    module._ansible_debug = True

# Generated at 2022-06-23 03:42:06.831467
# Unit test for function main
def test_main():
    import ansible_getent
    kwargs = {}
    kwargs['database'] = 'passwd'
    kwargs['key'] = 'root'
    kwargs['service'] = None
    kwargs['split'] = None
    kwargs['fail_key'] = True
    results = ansible_getent.main(**kwargs)
    print(results)
    kwargs['database'] = 'group'
    kwargs['key'] = None
    kwargs['service'] = None
    kwargs['split'] = ':'
    kwargs['fail_key'] = True
    results = ansible_getent.main(**kwargs)
    print(results)