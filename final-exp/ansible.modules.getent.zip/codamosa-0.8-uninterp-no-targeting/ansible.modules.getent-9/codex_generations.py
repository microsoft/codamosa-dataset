

# Generated at 2022-06-20 21:51:13.012155
# Unit test for function main
def test_main():
    import json
    import tempfile

    with tempfile.NamedTemporaryFile('wt+') as tf:
        tf.write("""3\ta,b,c\n4\td,e,f
5\tg,h,i""")
        tf.seek(0, 0)
        args = dict(
            _ansible_debug=True,
            ansible_module_args=dict(
                database='group',
                split='\t',
                key='3',
                _ansible_remote_tmp='/tmp',
                _ansible_check_mode=False,
                _ansible_socket='/tmp/ansible.sock',
            )
        )

# Generated at 2022-06-20 21:51:23.339826
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile

    # test 1:
    # passwd
    user = "user"
    expected_result = {'getent_passwd':
                            {user: ['x', '123', '123', 'User', '/home/user', '/bin/bash']}}

# Generated at 2022-06-20 21:51:37.855740
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True)

    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.main()
    test_module.run_command.assert_called_with(['getent', 'passwd', 'root'])

    test_module.params = {'database': 'passwd', 'key': 'root'}
    test_module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-20 21:51:44.380791
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import pdb; pdb.set_trace()

# Generated at 2022-06-20 21:51:44.914797
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:51:49.973250
# Unit test for function main
def test_main():
    
    # input arguments used by the ansible module
    module_args = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )

    # Get amodule object
    module = AnsibleModule(module_args)
    
    # invoke main function
    main()

# Generated at 2022-06-20 21:51:50.955126
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:51:57.559094
# Unit test for function main
def test_main():
    import sys
    import subprocess
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 21:52:01.802607
# Unit test for function main
def test_main():
    test_params = {
        'database': 'group',
        'key': 'root'
    }
    module = AnsibleModule(argument_spec={})
    module.params = test_params
    result = main()
    assert result['changed']

# Generated at 2022-06-20 21:52:10.486605
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    global main, getent_bin
    main = lambda: None
    import sys
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = open("/tmp/stdout", "w")
    sys.stderr = open("/tmp/stderr", "w")

    # Asserts

# Generated at 2022-06-20 21:52:27.378556
# Unit test for function main
def test_main():
    import sys
    sys.path.append("./test/")
    import test_ansible_module_getent as test_getent
    test_getent.main()

# Generated at 2022-06-20 21:52:34.363393
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          database=dict(type='str', required=True),
          key=dict(type='str', no_log=False),
          service=dict(type='str'),
          split=dict(type='str'),
          fail_key=dict(type='bool', default=True),
      ),
      supports_check_mode=True,
  )
  database = module.params['database']

  cmd = ['/usr/bin/getent', database]
  rc, out, err = module.run_command(cmd)

  msg = "Unexpected failure!"
  dbtree = 'getent_%s' % database
  results = {dbtree: {}}
  if rc == 0:
    seen = {}
    for line in out.splitlines():
      record = line

# Generated at 2022-06-20 21:52:49.447810
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', default='passwd'),
        key=dict(type='str', default='root'),
        split=dict(type='str', default=':'),
    ))

    import sys
    try:
        sys.argv.remove('--supports-check-mode')
    except ValueError:
        pass

    try:
        sys.argv.remove('--connection=local')
    except ValueError:
        pass

    try:
        sys.argv.remove('--diff')
    except ValueError:
        pass

    sys.argv.insert(1, 'ansible-doc')
    sys.argv.insert(2, 'getent')

    main()

# Generated at 2022-06-20 21:52:57.217775
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    test._ansible_module_commands = {'getent': '/usr/bin/getent'}

    test.param = {'database': 'passwd', 'key': 'foo'}
    results = main()
    assert results['failed']
    assert 'missing arguments' in results['msg']
    assert 'database unknown' in results['msg']

    test.param['database'] = 'passwd'
    test.param

# Generated at 2022-06-20 21:53:06.874701
# Unit test for function main

# Generated at 2022-06-20 21:53:19.843962
# Unit test for function main
def test_main():
    event = {}
    event['params'] = {}
    event['params']['database'] = "testdatabase"
    event['params']['key'] = "testkey"
    event['params']['split'] = "testsplit"
    event['params']['fail_key'] = True
    event['params']['service'] = "testservice"

    rc = 1
    out = "test output"
    err = "test error"

    # basic test
    module = FakeModule(event, rc, out, err)
    module.get_bin_path.return_value = "/bin/getent"

    try:
        main()
    except SystemExit:
        pass

    # test rc=0
    rc = 0
    module = FakeModule(event, rc, out, err)
    module.get_

# Generated at 2022-06-20 21:53:34.599817
# Unit test for function main
def test_main():
    from ansible.module_utils.getent import main

    class AnsibleModule(object):
        class ModuleFailJsonException(Exception):
            pass

        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

        def fail_json(self, msg, **kwargs):
            raise self.ModuleFailJsonException()

    class FakeShellResult(object):
        def __init__(self, exit_code, stdout=None, stderr=None):
            self.rc = exit_code
            self.stdout = stdout or ''
            self.stderr = stderr or ''

        def __nonzero__(self):
            return not bool(self.rc)


# Generated at 2022-06-20 21:53:43.043859
# Unit test for function main
def test_main():
    """test main function"""
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    setattr(module, 'run_command', lambda *args: (0, "", ""))
    res = main()
    assert(res['ansible_facts']['getent_shadow'] != {})

# Generated at 2022-06-20 21:53:58.464584
# Unit test for function main
def test_main():
    class MockModuleReturn(object):
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.stdout = out
            self.stderr = err
    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = None

        def fail_json(*args, **kwargs):
            self.fail_json = kwargs['msg']

        def exit_json(self, **kwargs):
            if 'ansible_facts' not in kwargs:
                return self.fail_json({})
            return kwargs['ansible_facts']

        def run_command(*args, **kwargs):
            self.rc = MockModuleReturn()
            return self.rc


# Generated at 2022-06-20 21:54:04.221647
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule, ModuleFailException
    import pytest
    from ansible.module_utils._text import to_text
    from ansible_collections.t_systems.enterprise_linux.plugins.module_utils.getent import dict_from_pipe
    from ansible_collections.t_systems.enterprise_linux.plugins.module_utils.getent import escape_getent_key
    import os
    import sys
    import textwrap

    def _create_getent_data_file(name, data):
        tmp_file = basic.AnsibleModule._create_tmp_path()
        with open(tmp_file, 'w') as handle:
            handle.write(data)
        return tmp_file

    getent_

# Generated at 2022-06-20 21:54:30.650000
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:54:31.300817
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:54:46.170311
# Unit test for function main
def test_main():
    import tempfile
    import io
    import sys
    import os

    # Get the directory of the test file
    # https://stackoverflow.com/a/6098238/3931488
    dir_path = os.path.dirname(os.path.realpath(__file__))

    # Mock getent output
    mock_getent_output_file = '{0}/files/mock_getent_output.txt'.format(dir_path)

# Generated at 2022-06-20 21:54:47.267001
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-20 21:54:59.653105
# Unit test for function main
def test_main():
    # Importing module(s) locally
    import sys
    from ansible.module_utils.facts import ansible_check_mode
    from ansible.module_utils.facts import ansible_diff_mode
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_platform
    from ansible.module_utils.facts import ansible_system
    from ansible.module_utils.facts import ansible_version

    try:
        main()
    except SystemExit as e:
        if e.code == 0:
            # There is errors, but the error is acceptable
            # (an example is getent_shadow, which needs root privilege)
            sys.exit(0)


# Generated at 2022-06-20 21:55:07.527089
# Unit test for function main
def test_main():
    facts = {
        'getent_passwd': {
            'root': ['x', '0', '0', 'root', '/root', '/bin/bash']
        },
        'getent_hosts': {
            'localhost': ['127.0.0.1', '::1', 'localhost']
        },
    }
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:55:13.857688
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest

    with pytest.raises(SystemExit):
        _module = __import__('ansible.modules.system.getent', fromlist=['main'])
        result = _module.main()

    assert False



# Generated at 2022-06-20 21:55:14.705947
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:55:25.941864
# Unit test for function main
def test_main():
    # Attempt to get the root password hash
    args = {
        'database': 'shadow',
        'key': 'root',
        'split': ':'
    }
    module = AnsibleModule(argument_spec=args)
    results = {}
    results['getent_shadow'] = None

    # Assign the return code and expected results
    code = 0
    ret = {'exception': None, 'msg': '', 'changed': False, 'ansible_facts': results}

    # Get the values we expect from the system
    import crypt
    import pwd

    root_pwd = pwd.getpwnam("root")
    results['getent_shadow'] = [root_pwd.pw_passwd.split("$")[1:]]

    # Attempt to get the hash
    main()

    # Test that

# Generated at 2022-06-20 21:55:36.725724
# Unit test for function main
def test_main():
    import os
    import pytest
    from ansible.module_utils.facts.system.getent import main
    from ansible.errors import AnsibleError
    ansible_facts = {}

    ansible_facts['getent_passwd'] = {}
    getent_passwd = {}
    getent_passwd['root'] = [
        'x',
        '0',
        '0',
        'root',
        '/root',
        '/bin/bash'
    ]

    ansible_facts['getent_shadow'] = {}
    getent_shadow = {}

# Generated at 2022-06-20 21:56:48.213904
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:56:49.505095
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:56:56.317494
# Unit test for function main
def test_main():
    class TestAnsibleModule(object):
        def __init__(self):
            self.check_mode = False
            self.debug = True
            self.fail_json = lambda **args: args
            self.exit_json = lambda **args: args

        @staticmethod
        def fail_json(**args):
            print(args)

        @staticmethod
        def get_bin_path(name, required=True, opt_dirs=[]):
            return '/bin/' + name

    class TestAnsibleModuleModule(object):
        def __init__(self):
            return None

        # I don't know why this is needed, but it is
        def __call__(self):
            return None

        @staticmethod
        def run_command(cmd):
            if cmd[2] == 'root':
                return

# Generated at 2022-06-20 21:57:06.132350
# Unit test for function main
def test_main():
    # Mock the module class
    class MockModule(object):
        def __init__(self):
            self.ansible_facts = {}

        def get_bin_path(self, name, required):
            return None

        def run_command(self, arg):
            return (0, "", "")

        def exit_json(self, ansible_facts, msg=""):
            self.ansible_facts = ansible_facts

    mock = MockModule()

    # Run the code
    main()

    # Show the results

# Generated at 2022-06-20 21:57:15.951339
# Unit test for function main
def test_main():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    from ansible.module_utils.basic import AnsibleModule

    def run_command_mock(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        return 0, "", ""

    setattr(AnsibleModule, 'run_command', run_command_mock)


# Generated at 2022-06-20 21:57:21.282448
# Unit test for function main
def test_main():
    test_commands = '''getent passwd'''
    test_rc_pass = '''0'''
    test_rc_fail = '''1'''
    test_rc_expected = 0

# Generated at 2022-06-20 21:57:29.967857
# Unit test for function main
def test_main():
    # Mock classes
    class Params(object):
        def __init__(self, database=None, key=None, split=None):
            self.database = database
            self.key = key
            self.split = split

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

        def __ne__(self, other):
            return not self.__eq__(other)

    class ModuleArgs(object):
        def __init__(self, argument_spec=None, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

        def __ne__(self, other):
            return

# Generated at 2022-06-20 21:57:38.226949
# Unit test for function main
def test_main():
    import __main__
    import sys
    import os

    test_val = {
        'database': "testdb",
        'key': "testkey",
        'split': ":",
        'fail_key': True,
    }


# Generated at 2022-06-20 21:57:44.532202
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    assert False

# Generated at 2022-06-20 21:57:52.888006
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split = ':'



# Generated at 2022-06-20 22:00:23.288418
# Unit test for function main
def test_main():
    module = AnsibleModule(
           argument_spec=dict(
               database=dict(type='str', required=True),
               key=dict(type='str', no_log=False),
               service=dict(type='str'),
               split=dict(type='str'),
               fail_key=dict(type='bool', default=True),
           ),
           supports_check_mode=True,
       )

    module.exit_json(msg="Unit test OK")

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:00:23.758478
# Unit test for function main
def test_main():
  assert main() == 3

# Generated at 2022-06-20 22:00:24.634408
# Unit test for function main
def test_main():
    # Check for correct syntax
    assert "function" in main.__code__.co_code

# Generated at 2022-06-20 22:00:29.839671
# Unit test for function main
def test_main():
    import json
    import sys
    import os

    # test loading basic modules
    module_utils_path = os.path.join(os.path.dirname(__file__), '..', 'module_utils')
    sys.path.append(module_utils_path)

    # save the env for testing
    orig_environ = os.environ.copy()
    # fail if we don't have getent
    if not os.path.exists('/usr/bin/getent'):
        raise Exception("Could not find getent, can't run tests")

    # our test

# Generated at 2022-06-20 22:00:39.968762
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "test_out", "")
    module.exit_json = MagicMock()
    module.exit_json.return_value = 0
    module.fail_json = MagicMock()
    module.fail_json.return_value = 1

    main()