

# Generated at 2022-06-20 21:51:15.777579
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:51:24.601204
# Unit test for function main
def test_main():
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    os.environ['PATH'] = os.pathsep.join(('/usr/sbin', '/sbin', os.environ['PATH']))
    args = dict(
        database='passwd',
        key='root',
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )


# Generated at 2022-06-20 21:51:27.549152
# Unit test for function main
def test_main():
    s = module_getent()
    assert service == "dummy"
    assert s.main() == "done"

# Generated at 2022-06-20 21:51:31.780167
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-20 21:51:32.490570
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-20 21:51:43.101087
# Unit test for function main
def test_main():
    """
    function main()
    """
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
    )

    class FakeGetEnt(object):

        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err


# Generated at 2022-06-20 21:51:50.976764
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:52:01.229843
# Unit test for function main
def test_main():
    pass
    # TODO: stop using 'ansible-base' as import module
    # from ansible_base.modules.system.getent import main
    # from ansible_base.utils.display import Display
    # import sys
    #
    # display = Display()
    #
    # for x in range(1, len(sys.argv)):
    #     display.debug("sys.argv[%d]: %s" % (x, sys.argv[x]))
    #
    # with pytest.raises(SystemExit) as error:
    #     main()
    #
    # assert error.value.code == 0

# Generated at 2022-06-20 21:52:06.495449
# Unit test for function main
def test_main():
    test_data = {
        'database' : 'group',
        'key' : 'root'
    }
    module = AnsibleModule(argument_spec=test_data.keys())
    test_results = {'getent_group': {'root': ['0', 'root']}}
    input = dict(module.params, **test_data)
    result = main(module, input)
    assert result['ansible_facts'] == test_results

# Generated at 2022-06-20 21:52:19.428356
# Unit test for function main
def test_main():
    import datetime
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import EnvironmentDump
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # getent function does not work in python 2.6
    if sys.version_info[:2] == (2, 6):
        return

    # Read in the test data
    test_data = {}
    with open('getent.json') as json_data:
        test_data = json.load(json_data)

    # Loop over all tests and run main()
    for test in test_data:
        # Create test environment
        set_module

# Generated at 2022-06-20 21:52:35.872406
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit

# Generated at 2022-06-20 21:52:43.743362
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # test main function
    main()


# Generated at 2022-06-20 21:52:45.709490
# Unit test for function main
def test_main():
    test_main.__name__ = __name__

    # Test error conditions
    assert main() == 1

# Generated at 2022-06-20 21:52:52.922880
# Unit test for function main
def test_main():
    import shlex
    import sys

    assert sys.version_info >= (2, 7)

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-20 21:53:05.324170
# Unit test for function main
def test_main():
    import module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.facts
    import ansible.module_utils.shell
    import ansible.module_utils.system
    import ansible.module_utils.urls
    import platform
    import sys
    import textwrap

    mock_params = {
        'database': 'passwd',
        'service': '',
        'key': 'root',
        'split': None,
        'fail_key': True,
    }

    if sys.version_info[0] == 2:
        mock_params['ansible_python_interpreter'] = '/usr/bin/python2.7'

    if platform.system() == 'Linux':
        mock_params['ansible_kernel'] = 'Linux'

# Generated at 2022-06-20 21:53:06.247610
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-20 21:53:15.865434
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import action
    from ansible.module_utils.basic import AnsibleModule

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    action.AnsibleModule = AnsibleModule
    main()

# Generated at 2022-06-20 21:53:17.463957
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 21:53:29.537788
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import json


    def fake_system_exit(sys_ex_code=0):
        class SysExit(Exception):
            pass

        raise SysExit


    def fake_run_command(cmd):
        class PseudoFile(object):
            def __init__(self, name):
                self.name = name
                self.closed = False

            def write(self, data):
                pass

            def readlines(self):
                data = {'passwd': 'root:x:0:0:root:/root:/bin/sh\n'
                                   'daemon:x:1:1:daemon:/usr/sbin:/bin/sh\n'
                                   'bin:x:2:2:bin:/bin:/bin/sh'}
                return data[self.name]

# Generated at 2022-06-20 21:53:32.312718
# Unit test for function main

# Generated at 2022-06-20 21:53:59.201643
# Unit test for function main
def test_main():
    getent = __import__('ansible.modules.system.getent')
    getent.main()

# Generated at 2022-06-20 21:54:05.371871
# Unit test for function main
def test_main():

    # Stub module class for this test
    class StubModule:
        def __init__(self, params):
            self.params = params
            self.run_command_results = [0, "", ""]

        def get_bin_path(self, arg, arg2):
            return arg

        def run_command(self, arg):
            self.run_command_command = arg
            return self.run_command_results

        def fail_json(self, **kwargs):
            self.failed = True
            self.fail_json_kwargs = kwargs

        def exit_json(self, **kwargs):
            self.exited = True
            self.exit_json_kwargs = kwargs

    # Testing passwd with root

# Generated at 2022-06-20 21:54:06.772168
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-20 21:54:18.851976
# Unit test for function main
def test_main():
    import os
    import sys
    import datetime
    import unittest
    import tempfile
    import subprocess
    import shutil
    import random
    import getpass
    from time import time

    class TestVerifyGetent(unittest.TestCase):

        def setUp(self):
            self.is_posix = True if os.name == 'posix' else False
            self.current_user = getpass.getuser()

            # if posix, generate a test file or use the existing one
            if self.is_posix:
                test_file = tempfile.gettempdir() + '/ansible_test_file_' + str(random.randrange(100000)) + '_' + str(int(time()))

# Generated at 2022-06-20 21:54:20.469354
# Unit test for function main
def test_main():
    # FIXME: This test needs to be a functional unit test
    pass

# Generated at 2022-06-20 21:54:31.441731
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec=dict(database=dict(type='str', required=True),
                                                    key=dict(type='str', no_log=False),
                                                    service=dict(type='str'),
                                                    split=dict(type='str'),
                                                    fail_key=dict(type='bool', default=True),))


# Generated at 2022-06-20 21:54:46.249520
# Unit test for function main
def test_main():
    args = {'key': 'test', 'database': 'test', 'fail_key': True}
    module = AnsibleModule(argument_spec=args)
    rc_code = 1
    out = 'Missing arguments, or database unknown.'
    err = ''
    module.run_command = lambda x: (rc_code, out, err)
    # It should fail with rc = 1
    try:
        main()
    except:
        pass
    else:
        assert False, "Should have failed"
    rc_code = 2
    # It should fail with rc = 2
    try:
        main()
    except:
        pass
    else:
        assert False, "Should have failed"
    args['fail_key'] = False
    # It should succeed with fail_key = False and rc = 2
    rc = main()


# Generated at 2022-06-20 21:54:59.037678
# Unit test for function main
def test_main():
  module = AnsibleModule(
            argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:55:11.878658
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible.module_utils import basic
    import os

    # FIXME: use a mock
    getent_bin = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    ).get_bin_path('getent', True)

    class TestGetent(ModuleTestCase):
        def test_getent_group_split(self):
            set_module_args(dict(
                database='group',
                split=':',
            ))

            module = basic.AnsibleModule(
                argument_spec={},
                supports_check_mode=True,
            )

# Generated at 2022-06-20 21:55:22.525324
# Unit test for function main
def test_main():
    import os
    import os.path
    import sys
    import subprocess

    try:
        from unittest import mock

    except ImportError:
        import mock

    import collections

    from ansible.errors import AnsibleError
    from ansible.module_utils.facts import is_file_contents_identical

    module_mock = mock.MagicMock()

    module_mock.params = collections.namedtuple('params', ['database',
                                                           'key',
                                                           'split',
                                                           'service',
                                                           'fail_key'])

    module_mock.params.database = 'passwd'
    module_mock.params.key = 'root'
    module_mock.params.split = ':'
    module_mock.params.service = ''


# Generated at 2022-06-20 21:56:24.136500
# Unit test for function main
def test_main():
    print("hahahah")
    module = AnsibleModule(argument_spec={
        "database": {"required": True, "type": "str"},
        "key": {"default": None, "type": "str"},
        "service": {"default": None, "type": "str"},
        "split": {"default": None, "type": "str"},
        "fail_key": {"default": True, "type": "bool"},
    }, supports_check_mode=True)
    database = 'passwd'
    key = 'root'
    split = ':'
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')
    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:56:34.474234
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:56:38.736356
# Unit test for function main
def test_main():
    # Mock module args and params
    module_args = dict(
        database='passwd',
        key='root',
        service=None,
        split=None,
        fail_key=False
    )

    module_params = dict(
        ansible_facts={}
    )

    # Mock module as something that can access 'module._ansible_no_log_values'
    class MockModule(object):
        def __init__(self, module_args, module_params):
            self.module_args = module_args
            self.module_params = module_params
            self._ansible_no_log_values = []
            self._ansible_selection = None

    # Mock commands and responses

# Generated at 2022-06-20 21:56:43.311818
# Unit test for function main
def test_main():
    print("Unit test for function main")

    test_param = {
        "database": "hosts"
    }

    with AnsibleModule(argument_spec=test_param) as module:
        main()

    assert False

# Generated at 2022-06-20 21:56:45.416209
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-20 21:56:55.635052
# Unit test for function main
def test_main():
    import platform
    platform.system.return_value = 'Linux'
    main_getent_passwd = main()
    main_getent_group = main()
    main_getent_hosts = main()
    main_getent_services = main()
    main_getent_shadow = main()
    assert main_getent_passwd['ansible_facts']['getent_passwd'] == {}
    assert main_getent_group['ansible_facts']['getent_group'] == {}
    assert main_getent_hosts['ansible_facts']['getent_hosts'] == {}
    assert main_getent_services['ansible_facts']['getent_services'] == {}
    assert main_getent_shadow['ansible_facts']['getent_shadow'] == {}

# Generated at 2022-06-20 21:57:05.757136
# Unit test for function main
def test_main():
    # Setup the arguments for the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_

# Generated at 2022-06-20 21:57:11.039961
# Unit test for function main
def test_main():
    # Import monkeypatch to be able to mock functions
    from _pytest.monkeypatch import MonkeyPatch
    import pytest

    # Create a patched version of the module to be able to
    # mock a function
    class PatchedModule(AnsibleModule):
        def run_command(self, args, check_rc=True, cwd=None, executable=None,
                        data=None, binary_data=False, path_prefix=None,
                        environ_update=None, umask=None, encoding=None):
            """Mocks run_command, because we don't want to call anything"""
            return 0, "test", ""

    # Create a monkeypatch instance
    monkeypatch = MonkeyPatch()

    # Patch AnsibleModule and return the patched class instead of the original

# Generated at 2022-06-20 21:57:12.043860
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:57:26.870129
# Unit test for function main
def test_main():
    class TestAnsibleModule(AnsibleModule):
        def __init__(self, argument_spec, supports_check_mode):
            AnsibleModule.__init__(self, argument_spec, supports_check_mode)

        def run_command(self, cmd):
            results = {"out": "", "err": "", "rc": 0}
            if cmd == ['getent', 'passwd', 'root']:
                results = {"out": "root:x:0:0:root:/root:/bin/bash", "err": "", "rc": 0}
            elif cmd == ['getent', 'group']:
                results = {"out": "root:x:0:\nbin:x:1:\ndialout:x:20:", "err": "", "rc": 0}

# Generated at 2022-06-20 21:59:45.465136
# Unit test for function main
def test_main():
    global results

# Generated at 2022-06-20 21:59:54.299781
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import shutil
    import sys
    import tempfile

    def makeTestFile(content):
        """
        Takes a string and creates a temporary file with that contents.
        Returns the filename of the file created.
        """
        tmpdir = tempfile.mkdtemp()
        tmpfile = os.path.join(tmpdir, 'testfile.txt')
        open(tmpfile, 'w').write(content)
        return tmpfile


# Generated at 2022-06-20 22:00:03.307369
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock part of module.run_command
    def run_command(args, check_rc=True):
        if args == ['getent', 'passwd', 'root']:
            return 0, "root:x:0:0:root:/root:/bin/bash\n", ''

# Generated at 2022-06-20 22:00:16.284211
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

    module_args=dict(
        database='passwd',
        key='root',
    )

    result_facts = dict(
        getent_passwd=dict(
            root=['x', '0', '0', 'root', '/root', '/bin/bash'],
        )
    )

    # in order to get the results we would like to test we need to set 'from_file' to False
    # otherwise the module will try to run getent based on which ever system it is testin on
    basic._ANSIBLE_ARGS = ImmutableDict(from_file=False)
    module = basic.AnsibleModule(**module_args)

    main()

# Generated at 2022-06-20 22:00:19.202607
# Unit test for function main
def test_main():
    args = dict(
        database='some_db',
        key='some_key',
        split=':',
        fail_key=True,
    )
    rc, out, err = main(args)
    print (rc, out, err)

# Generated at 2022-06-20 22:00:26.754663
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    getent_bin = basic.AnsibleModule(argument_spec={}).get_bin_path('getent', True)

    # getent_bin[0] is the path to getent,
    # getent_bin[1:] are the arguments split into list
    bin = to_bytes(getent_bin[0])
    args = getent_bin[1:]

    # the first argument of getent is the database
    # since we're going to test all the databases,
    # we're going to need to iterate over them
    args.remove(to_bytes('database'))

    # we need to know the binary path to
    # set the env PATH in the child process
    import os
    import subprocess
   

# Generated at 2022-06-20 22:00:37.297697
# Unit test for function main
def test_main():
    ''' mock version of getent: getent passwd root '''

    import mock
    '''
    Mocked arguments:
    - database = passwd
    - key = root
    '''
    import sys
    with mock.patch('sys.path', sys.path + ['/usr/local/lib']):
        module = AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str', no_log=False),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
                service=dict(type='str'),
            ),
            supports_check_mode=True,
        )

    import os
    with open(os.devnull, 'w') as devnull:
        run_command

# Generated at 2022-06-20 22:00:42.261186
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=False),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=False,
    )
    #module.params['database'] = 'passwd'
    #module.params['key'] = 'test'
    #module.params['service'] = 'test'
    #module.params['split'] = 'test'
    main()

# Generated at 2022-06-20 22:00:43.141319
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:00:56.570038
# Unit test for function main
def test_main():
    args = dict(
        database='passwd',
        key='root',
    )

    module = AnsibleModule(argument_spec=args)
    module.debug = True
    results = {'getent_passwd': {}}
    results['getent_passwd']['root'] = 'x:0:0:root:/root:/bin/bash'.split(':')

    module.run_command = mock_run_command(results)
    module.exit_json = mock_exit_json(results)
    module.fail_json = mock_fail_json(results)

    main()

    assert(True)

# vim: set et ts=4 sw=4 :