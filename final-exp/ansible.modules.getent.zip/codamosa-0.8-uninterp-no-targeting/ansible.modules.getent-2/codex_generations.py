

# Generated at 2022-06-20 21:51:11.724792
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import traceback
    import os
    import shutil
    temp_dir = tempfile.mkdtemp()
    ansible_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    group = os.path.join(ansible_dir, 'lib/ansible/modules/system/files/test/test-group')
    shutil.copyfile(group, os.path.join(temp_dir, 'group'))
    os.environ["PATH"] += os.pathsep + temp_dir
    import tempfile

# Generated at 2022-06-20 21:51:20.925826
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ),
                           supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, 'passwd:x:0:0:root:/root:/bin/bash\ngroup:x:0:\ngshadow:x:0:\n')
                                   )
    main()



# Generated at 2022-06-20 21:51:34.740663
# Unit test for function main
def test_main():
    '''
    ansible python module for getent
    '''
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_

# Generated at 2022-06-20 21:51:44.035776
# Unit test for function main
def test_main():
    # Example module invocation
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rc_map = {
        "passwd": 0,
        "shadow": 3,
    }


# Generated at 2022-06-20 21:51:49.500204
# Unit test for function main
def test_main():
    args = dict(
        database="passwd",
        key="root",
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params = args
    main()

# Generated at 2022-06-20 21:51:55.371915
# Unit test for function main
def test_main():

    # Unit test for function main
    def test_main():
        mymodule = AnsibleModule({
            'database': 'group',
            'key': 'wheel',
            'split': ':',
        },  supports_check_mode=True)

        print(main())

    test_main.py

# Generated at 2022-06-20 21:52:06.025318
# Unit test for function main
def test_main():
    import os
    import ntpath
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    class FakeModule(object):
        arguments = {}
        params = {}
        fail_json = exit_json = msg = None

        def __init__(self, *args, **kwargs):
            self.arguments = kwargs.get('argument_spec', {})
            self.params = {
                'database': database,
                'key': key,
                'split': split,
                'service': service,
                'fail_key': fail_key,
            }

        def get_bin_path(self, name, required):
            if name == 'getent':
                return ntpath.join(script_dir, 'getent')

# Generated at 2022-06-20 21:52:14.782295
# Unit test for function main
def test_main():
    import sys
    import datetime
    import ansible.module_utils.facts.system.getent as getent
    sys.modules["ansible"] = type('obj')()
    sys.modules["ansible.module_utils"] = type('obj')()
    sys.modules["ansible.module_utils.facts"] = type('obj')()
    sys.modules["ansible.module_utils.facts.system"] = type('obj')()
    sys.modules["ansible.module_utils.basic"] = type('obj')()
    sys.modules["ansible.module_utils.basic"].AnsibleModule = type('obj')()
    sys.modules["ansible.module_utils.facts"].SystemFacts = type('obj')()
    sys.modules["ansible.module_utils.facts"].SystemFacts.populate

# Generated at 2022-06-20 21:52:24.013849
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:52:24.805126
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:52:49.631618
# Unit test for function main
def test_main():
    """
    Syntax: python -m pytest [file]
    """

    # check_mode supports_check_mode
    # diff_mode supports_diff_mode
    # facts supports_facts

    # platform
    #  - FreeBSD
    #  - Linux
    #  - OpenBSD
    #  - NetBSD

    # version_added
    # version_removed

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:53:03.648211
# Unit test for function main
def test_main():
    # Unit test for function main

    # Create the test module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    class MockAnsibleModule(object):
        def __init__(self, module, params):
            self.module = module
            self.params = params
            self.run_command = module.run_command

        def fail_json(self, msg, exception=''):
            self.module.fail_json(msg=msg, exception=exception)


# Generated at 2022-06-20 21:53:16.061725
# Unit test for function main
def test_main():

    # Getent is just a wrapper around builtin module_utils, so just test the
    # exit parameters here.

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
        ),
    )

    rc = 0
    results = []

    # Getent run was successful, module should exit with a
    # result and an empty msg
    results.append({'changed': False, 'result': [], 'msg': ''})

    # Getent run was unsuccessful. module should exit with
    # a msg and a None result.
    results.append({'msg': 'error: key not found', 'result': None})

    # Getent run was successful, but key not found.
    # module should exit with a None result and empty msg
    results

# Generated at 2022-06-20 21:53:28.397556
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils import basic
    from ansible.module_utils.getent import main

    # Get a file object so we can use readline()
    fd = os.open('/etc/passwd', os.O_RDONLY)
    fd_passwd = os.fdopen(fd)
    passwd_lines = fd_passwd.readlines()
    fd_passwd.close()

    fd = os.open('/etc/group', os.O_RDONLY)
    fd_group = os.fdopen(fd)
    group_lines = fd_group.readlines()
    fd_group.close()


# Generated at 2022-06-20 21:53:36.098969
# Unit test for function main
def test_main():

    import sys
    import os
    import tempfile
    import subprocess
    import getpass

    class TmpPath(object):
        def __init__(self):
            self._tmp = None
            self.path = ''

        def __enter__(self):
            self._tmp = tempfile.TemporaryDirectory()
            self.path = self._tmp.__enter__()
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            self._tmp.__exit__(exc_type, exc_value, traceback)

        def __rshift__(self, other):
            return os.path.join(self.path, other)

        def __str__(self):
            return self.path

    with TmpPath() as t:
        path = t

# Generated at 2022-06-20 21:53:46.963323
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-20 21:53:57.446568
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    #Test for the passwd database
    #Check for the root user
    module.params['database'] = 'passwd'
    module.params['key'] = 'root'

    result = main()
    assert(len(result['getent_passwd']) == 1)
    assert(result['getent_passwd']['root'][0] == 'x')

    #Check for non-existing user

# Generated at 2022-06-20 21:54:01.340153
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-20 21:54:08.835066
# Unit test for function main
def test_main():
    ''' test_main '''
    # test1: key: 'root', database: passwd
    # result: list of root user record '0 root 1 0 May 23 06:20 /root /bin/bash'
    result = main()
    assert result == [0, 'root', 1, 0, 'May 23 06:20', '/root', '/bin/bash']

    # test2: key: 'root', database: group
    # result: list of root group record '0 root root'
    result = main()
    assert result == [0, 'root', 'root']

    # test3: key: 'root', database: hosts
    # result: list of root host record '127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain4'
    result = main()
    assert result

# Generated at 2022-06-20 21:54:16.977875
# Unit test for function main
def test_main():
    # Testing on the expectation that it will fail without a root permission
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    try:
        main()
    except Exception as e:
        traceback.print_exc()

# Testing getent.py
# python getent.py
# test_main()

# Generated at 2022-06-20 21:54:49.977766
# Unit test for function main
def test_main():
    import os
    import re
    from ansible.module_utils.basic import AnsibleModule

    script_path = os.path.dirname(os.path.realpath(__file__))
    fixture_path = os.path.join(script_path, 'fixtures', 'solaris_getent_passwd.out')
    with open(fixture_path, 'r') as f:
        data = f.read()
        results = {'getent_passwd': {}}
        seen = {}
        for line in data.splitlines():
            record = re.split(r':', line)
            if record[0] in seen:
                # more than one result for same key, ensure we store in a list
                if seen[record[0]] == 1:
                    results['getent_passwd'][record[0]]

# Generated at 2022-06-20 21:55:00.374864
# Unit test for function main
def test_main():
    # Test load module
    module_mock = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    module_mock.params['database'] = "passwd"
    module_mock.params['key'] = None
    module_mock.params['split'] = None
    module_mock.params['fail_key'] = False

    assert module_mock.fail_json.call_count == 0
    assert module_mock.exit_json

# Generated at 2022-06-20 21:55:11.993681
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:55:17.466518
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible.module_utils.common.dicts import is_iterable

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self._ansible_check_mode = False
            self._ansible_debug = False
            self._ansible_diff = False

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            raise Exception('FAIL')

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False

        def run_command(self, args, **kwargs):
            self.last_command = args

# Generated at 2022-06-20 21:55:28.825120
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:55:38.693995
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-20 21:55:49.759113
# Unit test for function main
def test_main():
    # Construct module instance
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    assert main() == (False, ['msg', 'rc'])
    module.exit_json = MagicMock(side_effect=SystemExit)
    with pytest.raises(SystemExit):
        main()
    module.run_command = MagicMock(return_value=(1, '', ''))


# Generated at 2022-06-20 21:55:57.503221
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:56:09.245712
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-20 21:56:14.914729
# Unit test for function main
def test_main():
    module_args = dict(
        database="passwd",
        key="root",
    )
    module = AnsibleModule(argument_spec=module_args)
    results = main()
    assert results['ansible_facts']['getent_passwd']['root'] == ['x', 0, 0, 'root', '/root', '/bin/bash']


# Generated at 2022-06-20 21:57:28.144858
# Unit test for function main
def test_main():

    testdata = '''
    # testdata for functions within main
    # only keep the functions you need
    '''

    mock_module = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str', no_log=False),
            service = dict(type='str'),
            split = dict(type='str'),
            fail_key = dict(type='bool', default=True)
        ),
        supports_check_mode = True
    )

    mock_module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    mock_module.get_bin_path = MagicMock(return_value='getent')

    # this creates a record for each function and takes parameters so the
    # testcases can make

# Generated at 2022-06-20 21:57:35.528657
# Unit test for function main
def test_main():
    mock_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    if isinstance(mock_module, AnsibleModule):
        mock_module.run_command = MagicMock(return_value=0)
        main()
    else:
        assert False
    pass

# Generated at 2022-06-20 21:57:36.281077
# Unit test for function main
def test_main():
    assert False, "test_main() not implemented"

# Generated at 2022-06-20 21:57:47.954749
# Unit test for function main
def test_main():
    # HACK: disable json/jsonrpc debug loggers
    import logging
    logging.getLogger("requests").propagate = False
    logging.getLogger("urllib3").propagate = False
    logging.getLogger('jsonrpc').propagate = False

    mod = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'root'
   

# Generated at 2022-06-20 21:57:48.501311
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:57:50.294720
# Unit test for function main
def test_main():
    # Test with no argument
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    msg = "Missing required arguments: key, database"
    assert module.fail_json(msg=msg) == msg

# Generated at 2022-06-20 21:58:02.015070
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str', no_log=False),
            split = dict(type='str'),
            fail_key = dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    colon = ['passwd', 'shadow', 'group', 'gshadow']
    args = {
        'database': 'passwd',
        'key': 'cli',
        'split': None,
        'fail_key': True,
        'check_mode': False,
        'diff_mode': False,
    }

    module.params = args

    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-20 21:58:13.641553
# Unit test for function main
def test_main():

    def main_mocked(module):
        module.run_command = mock.Mock(return_value=(0, 'foo\nbar\nbaz', ''))

        if getent_bin:
            module.get_bin_path = mock.Mock(return_value=getent_bin)
        else:
            module.get_bin_path = mock.Mock(return_value=None)

        return _getent.main()

    mock = MagicMock()

    # test search with key
    mock.params = {
        'database': 'test',
        'key': 'test',
        'split': None
    }

    main_mocked(mock)

    # test search without key

# Generated at 2022-06-20 21:58:20.436751
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:58:23.385635
# Unit test for function main
def test_main():
    assert True
