

# Generated at 2022-06-20 21:51:13.826400
# Unit test for function main
def test_main():
    import json

    test_dict = {"passwd": {"root": ["x", 0, 0, "root", "/root", "/bin/bash"]}}

    module = AnsibleModule({'database': 'passwd', 'key': 'root'})
    rc, out, err = module.run_command('printf "root:x:0:0:root:/root:/bin/bash"')
    assert rc == 0

    results = {}

    def ex__json(data, status=None, changed=False):
        results.update(data)

    module.exit_json = ex__json
    module.run_command = lambda a: (0, 'root:x:0:0:root:/root:/bin/bash', '')
    main()

    # check the structure of output in results
    assert isinstance(results, dict)

# Generated at 2022-06-20 21:51:23.635283
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        add_file_common_args=True,
        bypass_checks=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module

# Generated at 2022-06-20 21:51:34.085459
# Unit test for function main
def test_main():
    import sys, os

    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), ".."))
    import test_utils

    module = test_utils.MockModule()

    def getent_get_bin_path():
        def mock_run_command(cmd, **kwargs):
            if cmd[0] == 'true':
                return (0, 'trued', '')
            elif cmd[0] == 'false':
                return (1, 'falsed', '')
            else:
                return (1, 'fake out', '')

        def mock_fail_json(msg, **kwargs):
            return "FAILED"

        def mock_exit_json(**kwargs):
            return "EXIT"

        module.run_command

# Generated at 2022-06-20 21:51:34.627880
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:51:43.967729
# Unit test for function main
def test_main():
    import os
    import tempfile
    import subprocess
    import pytest
    import shutil
    from ansible.module_utils._text import to_bytes

    mydb_content=b"""#comment
firstvalue:firstkey:
secondvalue:secondkey:
thirdvalue:secondkey:
"""
    mycurdir = os.getcwd()
    testdir = tempfile.mkdtemp()
    os.chdir(testdir)
    # create a fake getent for the tests
    with open(os.path.join(testdir, "getent"), "w") as getent:
        getent.write("#!/usr/bin/python\n")
        getent.write("import sys\n")
        getent.write("if len(sys.argv) > 2:\n")

# Generated at 2022-06-20 21:51:54.373408
# Unit test for function main
def test_main():

    # import pytest
    from ansible.module_utils.basic import AnsibleModule

    args = dict(
        database='passwd',
        key='root',
        split=':',
    )

    getent_module = AnsibleModule(argument_spec=args)
    sys_module = dict(
        run_command=getent_passwd,
    )

    getent_module.run_command = getent_module.get_bin_path('getent', True)
    main()



# Generated at 2022-06-20 21:52:05.093476
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest
    from ansible import constants as C

    class args(object):
        def __init__(self):
            self.database = 'test-services'
            self.service = None
            self.split = None
            self.key = None
            self.fail_key = False
            self.check = False

    class FakeModule(object):
        def __init__(self):
            self.params = args()
            self.check_mode = False
            self.no_log = False
            self.debug =  False
            self.run_command_environ_update = {}


# Generated at 2022-06-20 21:52:05.662007
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:52:06.909258
# Unit test for function main
def test_main():
    print ("Running: test_main")
    # 
    # 
    #

# Generated at 2022-06-20 21:52:16.117550
# Unit test for function main
def test_main():
    # mock stubs as imported functions
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModuleArgs
    from ansible.module_utils.six import string_types
    from copy import deepcopy
    module_stub = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module_stub.exit_json = exit_json
    module_stub.fail_json = fail_json
    module_stub.get_bin_path = get_bin_path

    # mock parameter values
    args = {}
    args['database'] = 'shadow'
    args['key'] = 'root'
    args['split'] = ':'
    args['service'] = None

# Generated at 2022-06-20 21:52:38.149622
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:52:45.508237
# Unit test for function main
def test_main():
    import random
    import string

    random_key = ''.join(random.choice(string.ascii_lowercase) for i in range(10))

    assert main({'database': 'passwd', 'key': 'root'}) == "key is valid"
    assert main({'database': 'passwd', 'split': ':'}) == "key is valid"
    assert main({'database': 'passwd', 'key': random_key}) == "key is invalid"

# Generated at 2022-06-20 21:52:46.110459
# Unit test for function main
def test_main():

    pass

# Generated at 2022-06-20 21:52:53.097493
# Unit test for function main
def test_main():
    from mock import patch, MagicMock
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = MagicMock(return_value=(0, 'out', 'err'))
    module.exit_json = MagicMock()

    with patch('ansible.module_utils._text.to_native', return_value='err_msg'):
        main()
        assert module.get_bin_

# Generated at 2022-06-20 21:52:55.960816
# Unit test for function main
def test_main():

    # TODO: Write unit tests for main()

    return

# Generated at 2022-06-20 21:53:06.101543
# Unit test for function main
def test_main():
    import sys
    import pytest

# Generated at 2022-06-20 21:53:17.793439
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    os.environ['ANSIBLE_RETRY_FILES_ENABLED'] = '0'
    os.environ['ANSIBLE_STRICT_MODE'] = '1'
    write_file = tempfile.NamedTemporaryFile(mode='w+t', dir='/tmp', delete=False)

    import sys
    write_file.write('a00000000001:x:0:0:root:/root:/bin/sh\n')
    write_file.write('a00000000002:x:0:0:root:/root:/bin/sh\n')
    write_file.flush()
    write_file.seek(0)

    # Wrap sys.stdin to make it read from tempfile
    stdin = sys.stdin


# Generated at 2022-06-20 21:53:29.709084
# Unit test for function main
def test_main():
    import json

    # test execution
    # run only why test flag is set
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
    )

    # database = module.params['database']
    key = module.params.get('key')
    # split = module.params.get('split')
    service = module.params.get('service')

    database = 'passwd'
    key = 'root'
    service = None
    if service is not None:
        database = 'services'
        key = 'http'
    elif key is not None:
        database = 'shadow'

    database = 'shadow'
   

# Generated at 2022-06-20 21:53:34.817019
# Unit test for function main
def test_main():
    args = dict(
        database="passwd",
        key="root",
    )
    getent_return = dict(
      stdout="root:x:0:0:root:/root:/bin/bash",
      stderr="",
      rc = 0,
      start = "",
      end = "",
      delta = "",
      cmd = "getent passwd root"
    )
    ran_command = dict(
        return_value = getent_return
    )
    with patch.object(AnsibleModule, 'run_command') as mock_run_command, patch.object(AnsibleModule, 'get_bin_path') as get_bin_path:
        mock_run_command.side_effect = ran_command
        get_bin_path.return_value = "/bin/getent"
       

# Generated at 2022-06-20 21:53:37.060930
# Unit test for function main
def test_main():
    cmd = [getent_bin, "group"]
    rc, out, err = module.run_command(cmd)
    assert rc == 0

# Generated at 2022-06-20 21:54:12.079122
# Unit test for function main
def test_main():
    args = dict(database='passwd', key='root', fail_key=False)
    cmd = ['/bin/getent', 'passwd', 'root']

    mod = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ),
        supports_check_mode=True)
    mod.get_bin_path = lambda x, y: '/bin/getent'
    mod.run_command = lambda x: (0, '/bin/root:x:0:0:root:/root:/bin/bash\n', '')

    main()

# Generated at 2022-06-20 21:54:22.359680
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-20 21:54:28.228830
# Unit test for function main
def test_main():
    import tempfile

    # getent requires files or running service to work, we mock that
    with tempfile.NamedTemporaryFile() as temp:
        temp.write('foo:*:1:0:0:0:0:0:')
        temp.flush()

        module = AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str', no_log=False),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
            supports_check_mode=False,
        )

        module.run_command = lambda *args, **kwargs: (0, 'foo:foo\nbar:bar', '')

        rc, out, err = main()

# Generated at 2022-06-20 21:54:40.012614
# Unit test for function main
def test_main():
    # Test case #1 - Fail
    test_case = dict(
        database='test'
        , key='test'
        , split='test'
        , service='test'
        , fail_key=True
    )
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str'),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    test_data = dict(
        rc=2
        , out=None
        , err=None
    )
    test_global_vars = dict(
        getent_bin='getent'
    )
    test_results = dict

# Generated at 2022-06-20 21:54:47.229473
# Unit test for function main
def test_main():
    for database in ['', 'passwd', 'group']:
        for key in ['', 'root']:
            for split in [None, ':', '\t']:
                for fail_key in [True, False]:
                    for result_type in ['ansible_facts', 'msg']:
                        module = AnsibleModule(argument_spec=dict(
                            database=dict(type='str', required=True),
                            key=dict(type='str', no_log=False),
                            split=dict(type='str'),
                            service=dict(type='str'),
                            fail_key=dict(type='bool', default=True),
                            ))

                        module.params.update(dict(database=database, key=key, split=split))
                        ret_main = main()

                        assert result_type in ret_main

# Generated at 2022-06-20 21:54:59.652825
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # this test is module specific and not supported by test-module
    # so just return if module is not equal to getent
    if test.module == 'getent':
        return

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = test.params['database']
    key = test.params.get('key')
    split = test.params.get('split')
    service = test.params

# Generated at 2022-06-20 21:55:11.918701
# Unit test for function main
def test_main():
    def run_command_fail(*args, **kwargs):
        raise Exception('test')

    def run_command_success(cmd, **kwargs):
        if 'shadow' in cmd:
            return 0, '\n'.join(['dell:x:500:500:Dell,,,:/home/dell:/bin/bash',
                                 'biadmin:x:501:501:BI Admin,,,:/home/biadmin:/bin/bash',
                                 'wmsadmin:x:502:502:WMS Admin,,,:/home/wmsadmin:/bin/bash',
                                 'wms:x:503:503:WMS,,,:/home/wms:/bin/bash',
                                 'oracle:x:504:504:Oracle,,,:/home/oracle:/bin/bash']), None

# Generated at 2022-06-20 21:55:22.684630
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'root'
    split = ':'
    service = 'service'
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd

# Generated at 2022-06-20 21:55:29.690710
# Unit test for function main
def test_main():
    import json
    import ansible.module_utils.basic as basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # answers for database hosts
    database = 'hosts'
    rc = 0
    out = 'localhost\t127.0.0.1\nlocalhost\t127.0.1.1\n'
    err = ''


    results = {'getent_hosts': {}}

# Generated at 2022-06-20 21:55:45.162166
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

# Generated at 2022-06-20 21:56:53.066350
# Unit test for function main
def test_main():
    function = main
    arg1 = 'passwd'
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None

    results = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
    assert type(results) == dict
    assert 'ansible_facts' in results


# Generated at 2022-06-20 21:57:02.959886
# Unit test for function main
def test_main():
    import sys

    # prefix default args
    sys.argv.insert(1, '-')
    result = sys.modules['__main__'].main()
    assert result['rc'] == 1
    result = sys.modules['__main__'].main()
    assert result['rc'] == 2
    result = sys.modules['__main__'].main()
    assert result['rc'] == 3
    result = sys.modules['__main__'].main()
    assert result['rc'] == 0


# Generated at 2022-06-20 21:57:14.301248
# Unit test for function main
def test_main():
    check_mode = False
    split = None
    fail_key = True
    exit_json = None
    fail_json = None

    # Getent expects a colon in some cases
    global colon
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    class MyModule(object):
        def get_bin_path(self, program, required):
            return '/usr/bin/getent'

        def run_command(self, program):
            return 0, "dummy:x:0:0::/root:/bin/bash\n", ""

        def exit_json(self, ansible_facts={}, msg=None):
            global exit_json
            exit_json = True
            return ansible_facts


# Generated at 2022-06-20 21:57:24.724287
# Unit test for function main
def test_main():
    module = AnsibleModule(
    argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.check_mode = True
    module.params = {'database': 'passwd', 'key': 'root'} 
    assert main() == True

# Generated at 2022-06-20 21:57:33.770098
# Unit test for function main
def test_main():
    ansible_facts = dict(
        ansible_facts=dict(
            getent_service=dict(
                ssh=["22", "tcp", "", "", ""],
                http=["80", "tcp", "", "", "", "www", "www-data", "", "", ""],
                https=["443", "tcp", "", "", "", "www", "www-data", "", "", ""],
                ftp=["21", "tcp", "wodim", "cdrom", "", "", "", "", "", ""],
            )
        )
    )

    assert main() == ansible_facts

# Generated at 2022-06-20 21:57:35.569360
# Unit test for function main
def test_main():
    # Called without required args, should fail.
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-20 21:57:47.014612
# Unit test for function main
def test_main():
    print("Unit test for function main")

    # Unit test for function main - return error
    # Test with invalid database
    test_params = {'database': 'invalid', 'input': None, 'output': None, 'split': None, 'fail_key': True}
    rc, stdout, stderr = main(test_params)
    if not (rc == 1 and stderr == "Missing arguments, or database unknown."):
        print("Failed unit test for function main - return error")
        return 1

    # Unit test for function main - return success, no split
    # Test with valid parameters
    test_params = {'database': 'passwd', 'input': None, 'output': None, 'split': None, 'fail_key': True}
    rc, stdout, stderr = main(test_params)

# Generated at 2022-06-20 21:57:47.910808
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 21:57:55.388614
# Unit test for function main

# Generated at 2022-06-20 21:58:06.715383
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils.six import iteritems

    # create a mock module for the unit test
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    module.exit_json = lambda args: None

    # As AnsibleModule is monkey patched to use imp, can't just pass in our fake one above
    getent_module = getent.main(module)

    # set up some test results

# Generated at 2022-06-20 22:00:27.842320
# Unit test for function main
def test_main():
    main()
    pass

# Generated at 2022-06-20 22:00:28.298370
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:00:34.134063
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    assert main() is None

# Generated at 2022-06-20 22:00:38.825979
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 22:00:41.115406
# Unit test for function main
def test_main():
    test_dict = dict(
        database='passwd',
        key=None,
        split=None,
        service='',
        fail_key=True
    )

    main(test_dict)