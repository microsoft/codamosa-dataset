

# Generated at 2022-06-20 21:51:15.032999
# Unit test for function main
def test_main():
    # getent.py
    assert main("/usr/bin/getent", "passwd", "root", None, None, None)
    assert main("/usr/bin/getent", "group", "root", ":", None, None)
    assert main("/usr/bin/getent", "hosts", "localhost", None, None, None)
    assert main("/usr/bin/getent", "services", "http", None, False, None)
    assert main("/usr/bin/getent", "shadow", "www-data", ":", None, None)
    assert main("/usr/bin/getent", "network", "loopback", None, None, None)
    assert main("/usr/bin/getent", "netgroup", "admins", None, None, None)

# Generated at 2022-06-20 21:51:17.439480
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as excinfo:
        assert main() == True
    assert 'Unexpected failure!' in str(excinfo.value)

# Generated at 2022-06-20 21:51:31.876214
# Unit test for function main
def test_main():
    import sys
    import os

    import unittest
    import unittest.mock

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict(
                    database=dict(type='str', required=True),
                    key=dict(type='str', no_log=False),
                    service=dict(type='str'),
                    split=dict(type='str'),
                    fail_key=dict(type='bool', default=True),
                ),
                supports_check_mode=True,
            )
            self.mock_module = unittest.mock.MagicMock()
            self.mock_module.params = self.module.params
            self.mock_module.check_mode = self.module.check_mode

# Generated at 2022-06-20 21:51:42.733554
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'ONE:1:ONE\nTWO:2:TWO\nONE:3:ONE\n', ''))
    module.run_command.__str__ = MagicMock(return_value="(0, 'ONE:1:ONE\\nTWO:2:TWO\\nONE:3:ONE\\n', '')")
    module.get_

# Generated at 2022-06-20 21:51:49.864101
# Unit test for function main
def test_main():
    # Create an AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Set module arguments
    module.params['database'] = ''
    module.params['key'] = ''
    module.params['service'] = ''
    module.params['split'] = ''
    module.params['fail_key'] = ''

    # Run main()
    main()

# Generated at 2022-06-20 21:51:57.270110
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
    )

    module.exit_json(ansible_facts=dict(test = dict(test=["test"],fail=None)))

# Generated at 2022-06-20 21:52:08.287465
# Unit test for function main
def test_main():
    '''
    Tests for function main.
    '''
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:52:10.909775
# Unit test for function main
def test_main():
    # default args
    args = dict(
        database='passwd',
        key='root',
        split=None,
        fail_key=True
    )
    rc, out, err = main(args)
    assert rc == 0
    pass

# Generated at 2022-06-20 21:52:19.874144
# Unit test for function main
def test_main():
    key = 'root'
    database = 'passwd'
    rc = 0
    out = "root:x:0:0:root:/root:/bin/bash"
    err = ''
    getent_bin = 'getent'
    cmd = [getent_bin, database, key]

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    results = {}
    for record in out.splitlines():
        record_list = record.split(':')
        results[record_list[0]] = record_list[1:]


# Generated at 2022-06-20 21:52:20.815072
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:52:49.654373
# Unit test for function main
def test_main():
    args = dict(
        database='test_database',
        key='test_key',
        split=':',
        fail_key=True,
    )
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Test fail_key == True and rc == 2
    rc = 2
    out = ''
    err = 'test_err'
    results = {'getent_test_database': {}}

# Generated at 2022-06-20 21:53:03.647681
# Unit test for function main
def test_main():
    import sys
    if not hasattr(sys.modules['__main__'], '__file__'):
        import __main__
        __file__ = __main__.__file__
    import os
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import mock_open, patch
    from ansible_collections.notstdlib.moveitallout.plugins.modules import getent as getent_m

    # Try to use the system getent if possible, but mock it if we can't
    getent_m.getent_bin = getent_m.module.get_bin_path('getent', True) or '/bin/getent'


# Generated at 2022-06-20 21:53:15.245327
# Unit test for function main
def test_main():
    '''
    ansible-test units --python -v getent
    ansible-test units --python -v getent | id -nu

    ansible-test units -v --python --color no --requirements --group-by
    ansible-test units -v --python --color no --inventory --group-by
    ansible-test units -v --python --color no --group-by --collect
    '''
    run_module(dict(
        database='foo',
        key='bar',
        split='baz',
        fail_key=False,
    ))
    run_module(dict(
        database='foo',
        key='bar',
        split='baz',
        fail_key=True,
    ))


# Generated at 2022-06-20 21:53:22.592784
# Unit test for function main
def test_main():
  test_getent_bin = '/usr/bin/getent'
  test_params = {
    'database': 'test_database',
    'key': 'test_key',
    'split': 'test_split',
    'service': 'test_service',
    'fail_key': False,
  }
  inc_params = {
    'database': 'test_database',
  }
  exc_params = {
    'database': '',
  }

  def mock_get_bin_path(name, required):
    return test_getent_bin


# Generated at 2022-06-20 21:53:29.730292
# Unit test for function main
def test_main():
    import StringIO
    import sys

    try:
        from ansible.modules.system import getent
        from ansible.module_utils import basic
        from ansible.module_utils._text import to_bytes
    except ImportError:
        print("failed=True msg='ansible is required for this test'")
        sys.exit(1)

    def run_ansible(module_args, task_vars=None, check_mode=False, **kwargs):
        if task_vars is None:
            task_vars = dict()

        if 'ANSIBLE_MODULE_ARGS' in os.environ:
            del os.environ['ANSIBLE_MODULE_ARGS']

        setattr(getent.AnsibleModule, '_ansible_version', basic.__version__)

# Generated at 2022-06-20 21:53:39.924501
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import os
    import pytest
    import subprocess

    path = get_bin_path('getent')
    if not path:
        pytest.skip('getent not found')

    test_param = {
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': True,
    }

    test_string = """root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/usr/bin/nologin
"""
    test_rc = 0


# Generated at 2022-06-20 21:53:41.306077
# Unit test for function main
def test_main():
    assert 0 == main()
# Test function main()

# Generated at 2022-06-20 21:53:50.098201
# Unit test for function main
def test_main():
    import sys
    import os.path

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    ansible_module = AnsibleModule
    getent_bin = '/usr/bin/getent'
    out_test = "root:x:0:0:root:/root:/bin/bash\n"
    cmd = [getent_bin, 'passwd', 'root']
    rc_test = 0
    err_test = ''

    class TestAnsibleModule():
        def __init__(self):
            pass

        def _check_for_check_mode(self, a, b):
            return 0

        def get_bin_path(self, binary, required=True):
            return getent_bin


# Generated at 2022-06-20 21:53:50.992372
# Unit test for function main
def test_main():
    assert True == False

# Generated at 2022-06-20 21:54:03.741184
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )

    try:
        main()
    except SystemExit as e:
        assert e.code == 0
        module.exit_json(msg="Exit without fail")
    except Exception as e:
        module.fail_json(msg="Fail with message: %s" % (str(e)))

# Generated at 2022-06-20 21:54:29.679684
# Unit test for function main
def test_main():
    assert main() is True

# Generated at 2022-06-20 21:54:33.330458
# Unit test for function main
def test_main():
    command = '-m getent -a database=passwd'
    rc, out, err = module.run_command(command)
    assert rc == 0

# Generated at 2022-06-20 21:54:46.007827
# Unit test for function main
def test_main():
    import sys
    import json

    module_args = dict(
        database='passwd',
        key='root',
    )

    with open('test_getent_passwd.json') as f:
        expected_result = json.load(f)

    print('EXPECTED:', expected_result)

    module = AnsibleModule(
        argument_spec=module_args,
    )

    actual_result = main()

    print('ACTUAL:', actual_result.get('ansible_facts'), file=sys.stderr)

    assert actual_result.get('ansible_facts') == expected_result

    print('Success!')


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 21:54:58.922496
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            fail_key=dict(type='bool', default=True),
            split=dict(type='str'),
        ),
    )
    getent_bin = module.get_bin_path('getent', True)

    database = 'passwd'

    file_path = os.path.dirname(os.path.realpath(__file__))
    getent_data = os.path.join(file_path, database)
    module.run_command([getent_bin, database, 'root'])
    module.run_command([getent_bin, database, 'www-data'])
    assert main() == 0
    assert module.exit_json.called

# Generated at 2022-06-20 21:55:11.762096
# Unit test for function main
def test_main():
    import sys
    # we mock the main function since the module takes arguments we can't send
    # and it's easier to test other functions
    getent_bin = 'path/to/bin/getent'
    sys.modules['ansible.module_utils.basic'] = Mock(get_bin_path=Mock(return_value=getent_bin))
    sys.modules['ansible.module_utils.action'] = Mock(ModuleBase=Mock())

    from ansible.module_utils import basic
    from ansible.module_utils.action import ModuleBase
    from ansible.modules.system import getent
    ansible_module = AnsibleModule({
        'database':'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': False
    })



# Generated at 2022-06-20 21:55:19.236425
# Unit test for function main
def test_main():
    p = dict(
        database = 'services',
        key = 'http',
    )
    m = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True)
    m.params = p
    main()
    assert m.exit_json.called

# Generated at 2022-06-20 21:55:31.274396
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)
    rc = 0

    def run_command(my_cmd):
        print("Running command " + " ".join(my_cmd))
        stdout = subprocess.check_output(
            my_cmd,
            stdin=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=False
        )
        return rc, stdout, ""

    modulestub = type('modulestub', (object,), dict(run_command=run_command))

# Generated at 2022-06-20 21:55:45.697998
# Unit test for function main
def test_main():
    import sys
    import os

    try:
        import json
    except ImportError:
        import simplejson as json
        print("FALLBACK: import simplejson as json")

    # Save the Original Arguments so we can restore them.
    ORIGINAL_ARGV = list(sys.argv)

    # Make sure the environment is sane
    os.environ['ANSIBLE_MODULE_ARGS'] = ''
    os.environ['ANSIBLE_MODULE_RETVAL'] = ''

    class AnsibleModuleMock():
        ''' AnsibleModuleMock Class'''
        class fail_json(Exception):
            def __init__(self, key, argument=None, **kwargs):
                self.key = key
                self.argument = argument

        # __new__ is a special method, the first one to be called when the

# Generated at 2022-06-20 21:55:47.348677
# Unit test for function main
def test_main():

    # Getent module has not provided a unit test as it requires extensive mocking and testing to be effective
    pass

# Generated at 2022-06-20 21:55:57.191225
# Unit test for function main
def test_main():
    # Test error condition
    rc = main()
    assert rc == 1

    # Test with only database provided
    getent_bin = "/usr/bin/getent"
    database = "passwd"
    key = None
    split = None
    service = None
    fail_key = True
    getent_args = [getent_bin, database]

    # Test db = passwd
    rc = main(getent_args)
    assert rc == 0

    # Test db = group
    database = "group"
    getent_args = [getent_bin, database]
    rc = main(getent_args)
    assert rc == 0

    # Test db = hosts
    database = "hosts"
    getent_args = [getent_bin, database]
    rc = main(getent_args)
   

# Generated at 2022-06-20 21:57:03.807812
# Unit test for function main
def test_main():
    args = dict(
        database='group',
        split=':',
    )

    module = AnsibleModule(argument_spec=args)
    results = main()
    assert module.ansible_facts == results['ansible_facts']

# Generated at 2022-06-20 21:57:15.642167
# Unit test for function main
def test_main():
    import os.path
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule, Environment

    if not os.path.exists('/usr/bin/getent'):
        print('Skipping getent tests, binary not available')
        return

    test_env = Environment([os.path.join(os.path.dirname(__file__), '../utils/test_data.json')])
    os.environ = test_env
    module_name = 'getent'
    module_args = dict(database='passwd', key='root', fail_key=True)

# Generated at 2022-06-20 21:57:27.307236
# Unit test for function main
def test_main(): # run -m ansible_collections.community.general.plugins.modules.getent_tests -- -v
    import os
    import shutil
    import tempfile
    from ansible_collections.community.general.plugins.modules.getent import main
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.action.action import AnsibleModule

    # noinspection PyShadowingNames

# Generated at 2022-06-20 21:57:35.143313
# Unit test for function main
def test_main():
    import io
    import json
    import sys
    from collections import namedtuple

    module_args = {}
    module_args.update(
        dict(
            database='passwd',
            key=None,
            split=None,
            fail_key=True,
        )
    )

    module = namedtuple("AnsibleModule", ["params", "run_command"])

    module.params = module_args


# Generated at 2022-06-20 21:57:46.462114
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:57:50.325935
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.getent import _main as main
    import sys
    import os
    import pytest

    with pytest.raises(SystemExit) as exception_info:
        main(['--database=', 'foo'])
    assert exception_info.match(r"UNSUPPORTED_PLATFORM")

# Generated at 2022-06-20 21:57:55.821037
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-20 21:58:07.204964
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'

    # Test passwd
    rc, out, err = ansible_module.run_command([getent_bin, 'passwd'])
    assert out.find('root') != -1
    assert out.find('ninja') != -1

    # Test group
    rc, out, err = ansible_module.run_command([getent_bin, 'group'])
    assert out.find('root') != -1
    assert out.find('ninja') != -1

    # Test hosts
    rc, out, err = ansible_module.run_command([getent_bin, 'hosts'])
    assert out.find('127.0.0.1') != -1
    assert out.find('127.0.1.1') != -1

    #

# Generated at 2022-06-20 21:58:09.239524
# Unit test for function main
def test_main():
    # Test the return of an empty record set
    assert main() == False

# Generated at 2022-06-20 21:58:17.923285
# Unit test for function main
def test_main():
    # Tests:
    # getent passwd root
    # getent group
    # getent hosts
    # getent services
    # getent shadow www-data
    # getent missing-database
    # getent hosts invalid-key
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main(module) == None