

# Generated at 2022-06-20 21:51:14.171611
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    import os

    ansible_options = basic._ANSIBLE_ARGS
    arguments = {}
    if os.path.exists('/etc/services'):
        arguments = dict(
            database='services',
            split=':'
        )
    else:
        # use a POSIX compatible database
        arguments = dict(
            database='passwd',
            key='root',
            split=':',
        )

    (rc, out, err) = basic.run_command("%s %s" % (get_bin_path('getent', required=True), arguments['database']), None, None)

# Generated at 2022-06-20 21:51:20.739750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class FakeAnsibleModule(object):
        def __init__(self, module_data):
            self.module_data = module_data
            for k in ["check_mode", "no_log", "changed", "diff", "warnings"]:
                setattr(self, k, None)

        def run_command(self, cmd):
            return self.module_data["rc"], self.module_data["out"],

# Generated at 2022-06-20 21:51:24.712963
# Unit test for function main
def test_main():
    # If a supplied key is missing this will make the task fail if C(yes).
    # This test case tests the module with fail_key value 'yes' and checks
    # if the module worked
    class args:
        database = "services"
        key = "http"
        split = ':'
        fail_key = True
        service = "service"
    rc = main(args)
    assert rc['msg'] == 'One or more supplied key could not be found in the database.'
    # This test case tests the module with fail_key value 'no' and checks if
    # the module worked
    class args:
        database = "services"
        key = "http"
        split = ':'
        fail_key = False
        service = "service"
    rc = main(args)

# Generated at 2022-06-20 21:51:34.301512
# Unit test for function main
def test_main():
    # These are 'mock' arguments for the module which are handled in the AnsibleModule
    # constructor and results in a fully populated module object
    args = { 'database': 'passwd', 'key' : 'root', 'check_mode' : False }

    def mocked_run_command(module):
        # N.B. This is the function being tested, but the way it is mocked out is the
        #   important part of this test.
        cmd = '/usr/bin/getent passwd root'
        rc = 0
        out = 'root:x:0:0:root:/root:/bin/bash'
        err = ''
        return rc, out, err

    # N.B. We must initialize the module object with a mocked version of the run_command
    #   method so it is easy to test different scenarios and error conditions

# Generated at 2022-06-20 21:51:41.942461
# Unit test for function main
def test_main():
    f = open('test_main.txt', 'w')
    f.write('1\n')
    f.write('10.22.21.1\n')
    f.write('2\n')
    f.write('10.22.21.2\n')
    f.close()

    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    main()
    sys.stdout = old_stdout
    assert mystdout.getvalue() == '\n{}\nchanged=false\nfailed=false\n'

# Generated at 2022-06-20 21:51:49.359008
# Unit test for function main
def test_main():
    # Setup
    results, module_args, expected = setup_main()

    # Mocking
    monkeypatch.setattr(ansible.module_utils.basic, 'get_bin_path', Mock(return_value='/bin'))
    monkeypatch.setattr(ansible.module_utils.basic, 'run_command', Mock(return_value=(0, '', '')))

    # Execute function main()
    main()

    # Validate
    ansible.module_utils.basic.get_bin_path.assert_called_with(None, True)
    ansible.module_utils.basic.run_command.assert_called_with(None, False,None, True, None)
    assert results == expected


# Generated at 2022-06-20 21:51:58.806040
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main() == 0

# Generated at 2022-06-20 21:52:12.014455
# Unit test for function main
def test_main():
    """ Unit test for function main """
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.params['service'] = None
    module.params['split'] = None
    module.params['fail_key'] = True

    main()

# Generated at 2022-06-20 21:52:21.944205
# Unit test for function main

# Generated at 2022-06-20 21:52:22.793345
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:53:04.125570
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.getent import main
    from ansible.module_utils.six import PY3
    if not PY3:
        import __builtin__ as builtins
    else:
        import builtins

    # simulate module args
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = 'passwd'
    key = 'root'
    split = ':'
    fail_key = True


# Generated at 2022-06-20 21:53:11.056815
# Unit test for function main
def test_main():
    args = dict(
       database='passwd',
       key='root',
       fail_key=False,
       split=':',
       service='passwd')
    module = get_module(args)
    rc, out, err = module.run_command("cat /etc/passwd")
    assert rc == 0
    results, dbtree = main()
    assert results['ansible_facts'][dbtree]['root'][0] == 'x'

# Generated at 2022-06-20 21:53:21.304517
# Unit test for function main
def test_main():
    import tempfile
    fd, tmpfile = tempfile.mkstemp()
    os.write(fd, b"hello world\n")
    os.close(fd)

    fd, tmpfile2 = tempfile.mkstemp()
    os.write(fd, b"hello world2\n")
    os.close(fd)

    fd, tmpfile3 = tempfile.mkstemp()
    os.write(fd, b"hello world3\n")
    os.close(fd)

    # Create a mock module

# Generated at 2022-06-20 21:53:31.027636
# Unit test for function main

# Generated at 2022-06-20 21:53:37.762119
# Unit test for function main
def test_main():
    # Import needed modules
    import os
    import tempfile
    import subprocess
    import shutil
    import sys
    # Make a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Make a temporary ansible.cfg
    ansible_cfg = os.path.join(temp_dir, "ansible.cfg")
    with open(ansible_cfg, 'w') as f:
        f.write("defaults\n")

    open("/tmp/test_file", "w").close()
    os.chmod("/tmp/test_file", 0o700)

    # Create a temporary environment that we can modify that ansible-playbook
    # will subsequently use.
    orig_environ = os.environ.copy()

    # We need some variables to pass on the command line.  We're going to

# Generated at 2022-06-20 21:53:48.121691
# Unit test for function main
def test_main():
    # These are the tests expected to fail and why
    fail_tests = [
        {'key': 'nobody', 'msg': 'One or more supplied key could not be found in the database.'}
    ]
    # These are all the tests to be run
    # The expected value for each test is the terminal value after all calls to main, ex
    # return ansible_facts[dbtree] = 'val'

# Generated at 2022-06-20 21:53:52.177639
# Unit test for function main
def test_main():
    print("getent module test")
    print("trying to import module")
    if not os.path.exists('/usr/bin/getent'):
        module.fail_json(msg="getent not on system path")
    module.exit_json(ansible_facts=results, msg=msg)


# Generated at 2022-06-20 21:53:54.383487
# Unit test for function main
def test_main():
    # Just checking that it doesn't fail
    main()



# Generated at 2022-06-20 21:54:01.360506
# Unit test for function main
def test_main():
    # Mock for AnsibleModule.run_command
    class run_command_mock:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def return_values(self):
            return (self.rc, self.out, self.err)

    # Mock for get_bin_path
    def get_bin_path_mock(return_value):
        return return_value
    # Mock for AnsibleModule
    class AnsibleModule_mock:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.fail_json = self.exit_json = self.params = None

       

# Generated at 2022-06-20 21:54:01.829559
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:54:40.013536
# Unit test for function main
def test_main():
    # import modules involved in the testing
    import os
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback

    m_args = dict(
        database='passwd',
        key='root',
        split=None,
        service=None,
        fail_key=True,
    )
    m_args.update(dict(ANSIBLE_MODULE_ARGS={
        "database": "passwd",
        "key": "root",
        "split": None,
        "service": None,
        "fail_key": True,
    }, ANSIBLE_MODULE_RETVALS={
        'icount': '2',
    }))


# Generated at 2022-06-20 21:54:49.058906
# Unit test for function main
def test_main():
    import subprocess
    import os
    rc, out, err = subprocess.Popen([os.getcwd() + "/getent.py", "passwd", "no_such_user"], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    if rc != '2':
        assert False, "Unexpected exit code from getent!"
    rc, out, err = subprocess.Popen([os.getcwd() + "/getent.py", "services", "no_such_service", "--fail_key=False"], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    if rc != '0':
        assert False, "Unexpected exit code from getent!"

if __name__ == '__main__':
    test_

# Generated at 2022-06-20 21:55:00.145972
# Unit test for function main

# Generated at 2022-06-20 21:55:02.020068
# Unit test for function main
def test_main():
    assert main() == 'success'

# Generated at 2022-06-20 21:55:12.848209
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main

    module = AnsibleModule(argument_spec={
        'database': {'type': 'str', 'required': True},
        'key': {'type': 'str', 'no_log': False},
        'split': {'type': 'str'},
        'fail_key': {'type': 'bool', 'default': True},
    },
        supports_check_mode=True
    )

    class TestModule(object):
        """Object so we can mock functions that require self"""
        def __init__(self):
            self.params = module.params
            self.exit_json = fake_exit_json
            self.fail_json = fake_fail_json
            self.run_command = fake_run_command
            self.get_bin_path = fake_get

# Generated at 2022-06-20 21:55:22.071166
# Unit test for function main
def test_main():
    # simple test for fact gathering with a single value
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = Mock(return_value=(0, 'test_user:x:1000:1000:test user,,,:/home/test_user:/bin/bash', ''))

    main()
    pass



# Generated at 2022-06-20 21:55:30.538305
# Unit test for function main
def test_main():
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    check_mode = True
    ansible_module = AnsibleModule(argument_spec=argument_spec, check_mode=check_mode)
    test_main_obj = main()
    return test_main_obj

# Generated at 2022-06-20 21:55:39.861276
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    import pytest
    from pytest import raises

    if not PY2:
        pytestmark = pytest.mark.skip("Skip python2 specific tests")

    test_module = 'getent'

# Generated at 2022-06-20 21:55:51.082331
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
    )
    module.run_command = lambda *args, **kwargs: (0, 'foo root:x:0:0:root:/root:/bin/bash\nbar:x:1000:1000:,,,:/home/bar:/bin/bash', '')

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-20 21:55:52.654736
# Unit test for function main
def test_main(): # test in ansible_test/test_action/test_modules/test_getent.py
    pass

# Generated at 2022-06-20 21:57:05.252522
# Unit test for function main
def test_main():
    module = AnsibleModule({'database': 'passwd', 'key': 'root'})
    out = {'getent_passwd': {'root': None}}
    assert main() == (module.exit_json(ansible_facts=out))


# Generated at 2022-06-20 21:57:15.816578
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module_params = {'database' : 'passwd', 'key' : True, 'service' : None, 'split' : None, 'fail_key': True}
    main(module_params)

    module_params = {'database' : 'hosts', 'key' : False, 'service' : 'test', 'split' : None, 'fail_key': True}
    main(module_params)

    module_params

# Generated at 2022-06-20 21:57:21.282540
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    dbs = ['passwd', 'group', 'shadow', 'hosts', 'hosts.equiv', 'services', 'networks', 'protocols', 'rpc', 'ethers', 'netmasks', 'bootparams', 'aliases', 'netgroup', 'automount']
    keys = ['root', 'wheel', 'admin', 'nobody', 'mail', 'apache', 'www-data', 'www']
    database = dbs[0]
    key = keys[0]
    print("Unit test database: %s" % database)
    print("Unit test key: %s" % key)

# Generated at 2022-06-20 21:57:28.198376
# Unit test for function main
def test_main():
    out = '''
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
dbus:x:81:81:System message bus:/:/sbin/nologin
systemd-bus-proxy:x:999:998:systemd Bus Proxy:/:/sbin/nologin
systemd-journal-gateway:x:190:190:systemd Journal Gateway:/run/systemd:/sbin/nologin
'''

    r = main()
    assert r['rc'] == 0


# Generated at 2022-06-20 21:57:37.272757
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-20 21:57:48.093635
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    data = {'database': 'shadow'}
    module = AnsibleModule(argument_spec=data, supports_check_mode=True)
    if PY2:
        module.no_log_values = to_bytes("BECOME_PASS")
    else:
        module.no_log_values = "BECOME_PASS"

    stdout = StringIO()
    exc = None
    try:
        main()
    except Exception as e:
        exc = get_exception()

# Generated at 2022-06-20 21:57:52.987980
# Unit test for function main
def test_main():
    #from ansible.module_utils import basic
    #from ansible.module_utils._text import to_native
    from ansible.module_utils import ansible_facts

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def run_command(cmd):
        return dict(rc=0, out='', err='')

    module.run_command = run_command


# Generated at 2022-06-20 21:58:05.476699
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'database': 'hosts',
        'key': '',
        'service': '',
        'split': '',
        'fail_key': 'yes',
    })

    try:
        import yaml
    except ImportError as e:
        assert False, "Unable to import yaml module"

    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, 'hosts']

    try:
        rc, out, err = module.run_command(cmd)
    except Exception as e:
        assert False, "Unable to run command: %s" % cmd

    results = {}

    if rc == 0:
        for line in out.splitlines():
            record = line.split('\t')

# Generated at 2022-06-20 21:58:16.582754
# Unit test for function main
def test_main():
    def test_failure(msg, rc=1, fail_key=False):
        class AnsibleModuleMock(object):
            def __init__(self, params):
                self.params = params

            def fail_json(self, *args, **kwargs):
                self.fail_args = args
                self.fail_kwargs = kwargs

            def run_command(self, cmd):
                raise Exception(msg) if params['database'] == 'fail' else None
                return (0, '1:2\n3:4', '')

            def exit_json(self, *args, **kwargs):
                self.exit_args = args
                self.exit_kwargs = kwargs


# Generated at 2022-06-20 21:58:23.386115
# Unit test for function main
def test_main():
    import datetime
    test = {
        'database': ['database', 'passwd'],
        'key': ['key', 'root'],
        'split': ['split', ':'],
        'fail_key': ['fail_key', True],
    }
    now = datetime.datetime.now()
    test_time = now.strftime("%Y-%m-%d-%H-%M-%S")
    test_file = "test_"+test_time+".txt"
    open(test_file,"w+")
    with open(test_file, "a") as myfile:
        myfile.write("root:x:0:0:root:/root:/bin/bash\n")
        myfile.write("a:b:c:d\n")