

# Generated at 2022-06-20 21:51:07.635052
# Unit test for function main
def test_main():
    test_module = AnsibleModule(dict(database='passwd', key='root'))
    result = main()
    assert 0 == result['rc']
    assert 'getent_passwd' in result['ansible_facts']
    assert result['ansible_facts']['getent_passwd']['root'] == ['x', 0, 0, 'root', '/root', '/bin/bash']


# Generated at 2022-06-20 21:51:17.738633
# Unit test for function main
def test_main():
    # Test for invalid database name
    args = {'database': 'cplorg.txt',
            'key': None,
            'split': None,
            'service': None,
            'fail_key': True,
            '_ansible_check_mode': False,
            '_ansible_diff': False,
            '_ansible_module_name': 'getent',
            '_ansible_version': 200000,
            '_ansible_module_args': {'database': 'cplorg.txt',
                                     'key': None,
                                     'split': None,
                                     'service': None,
                                     'fail_key': True}}

    tmodule = AnsibleModule(**args)

    rc = 1


# Generated at 2022-06-20 21:51:22.857620
# Unit test for function main
def test_main():

    test_dict = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )

    main(module_args=test_dict)

# Generated at 2022-06-20 21:51:36.173124
# Unit test for function main
def test_main():

    test_cases = [
        {
            'params': {
                'database':'passwd',
                'key':'root',
            },
            'result': {
                'ansible_facts': {
                    'getent': {
                        'root': [
                            '0',
                            '0',
                            'root',
                            '/root',
                            '/bin/bash',
                        ],
                    },
                },
            },
        },
    ]

    def getent_main(params, fail=True):

        getent_bin = '/usr/bin/getent'
        cmd = [getent_bin, params['database'], params['key']]

        if fail:
            rc = 1
        else:
            rc = 0

        return rc, '', ''


# Generated at 2022-06-20 21:51:46.463632
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class MockRunCommand(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)


# Generated at 2022-06-20 21:52:00.517327
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    database_name = 'passwd'
    key = 'root'
    #rc, out, err = module.run_command(cmd)
    rc = 0

# Generated at 2022-06-20 21:52:01.124610
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:52:09.835983
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def run_command_mock(module, cmd, check_rc=True):
        '''mock run_command_function'''
        if 'passwd' in cmd:
            return (0, 'root:x:0:0::/root:/bin/bash\nbcoca:x:1000:1000::/home/bcoca:/bin/bash\n', None)
        if 'passwd root' in cmd:
            return (0, 'root:x:0:0::/root:/bin/bash\n', None)
        return (1, '', 'Fake stdout, stderr and rc')

    def load_file_common_mock(path):
        '''mock load_file_common_function'''

# Generated at 2022-06-20 21:52:17.965929
# Unit test for function main
def test_main():
    import ansible.modules.system.getent as getent
    import ansible.module_utils.basic as basic
    import ansible.module_utils.system as system
    import ansible.module_utils.six.moves.builtins as builtins
    import tempfile
    import os

    (outfd, outfile) = tempfile.mkstemp()
    (infd, infile) = tempfile.mkstemp()

    builtins.__dict__['open'] = os.fdopen

    basic.ANSIBLE_MODULE_ARGS = {'database' : '', 'key' : '', 'split' : '', 'fail_key' : True}
    basic.ANSIBLE_MODULE_RETVALS = {'ansible_facts' : {}}

# Generated at 2022-06-20 21:52:19.170940
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:52:44.783162
# Unit test for function main
def test_main():
    import tempfile
    import os

    # Create a temporary file
    tmp = tempfile.NamedTemporaryFile()

    temp_file_path = tmp.name

    # Write some test content
    tmp.write('hello world')
    tmp.seek(0)

    # read the contents
    temp_file_contents = tmp.read()

    # Close the file, the directory itself will be removed later
    tmp.close()

    with open(temp_file_path) as f:
        read_content = f.read()
    assert temp_file_contents == read_content

    # Assert that the temporary file exists
    assert os.path.exists(temp_file_path)

    # Now remove the directory that the temporary file is contained in, which will remove the file

# Generated at 2022-06-20 21:52:52.553685
# Unit test for function main
def test_main():
    import tempfile
    import os

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_

# Generated at 2022-06-20 21:53:05.322336
# Unit test for function main
def test_main():
  print("Testing main")
  test_cases = [
      {
          'args':
          {
              'database': 'hosts',
              'key': 'localhost',
              'fail_key': True
          },
          'return_code': 2,
          'msg': "One or more supplied key could not be found in the database."
      },
      {
          'args':
          {
              'database': 'unknown'
          },
          'return_code': 1,
          'msg': "Missing arguments, or database unknown."
      }
  ]
  for test_case in test_cases:
    m = AnsibleModule(test_case['args'], supports_check_mode=True)
    if test_case['return_code'] == 0:
      response = m.run_command(['/bin/true'])


# Generated at 2022-06-20 21:53:16.616020
# Unit test for function main
def test_main():
    import mock
    with mock.patch.dict(__opts__, {'pki_dir': '/etc/ssl/certs'}):
        import getent
        with mock.patch('ansible.module_utils.basic.AnsibleModule', autospec=True) as mock_module:
            mock_getent_module = mock_module.return_value
            mock_getent_module.params = {'database': 'passwd', 'key': 'root'}
            mock_getent_module.get_bin_path.return_value = 'getent'
            mock_getent_module.run_command.return_value = [0, '', '']
            getent.main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 21:53:28.709710
# Unit test for function main
def test_main():
    # Setup mock module
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', required=False),
        service=dict(type='str', required=False),
        split=dict(type='str', required=False),
        fail_key=dict(type='bool', default=True),
    ),
    supports_check_mode=True)

    # Setup mock module results
    results = {
        'changed': False,
        'failed': False,
        'ansible_facts': {},
    }

    # Setup getent mock responses
    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-20 21:53:36.298630
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    args = dict(
        database='services',
        key='http',
    )
    res = basic.AnsibleModule(argument_spec=args).run_command('/usr/bin/getent services http')
    returned_results = dict()
    returned_results['getent_services'] = dict()
    returned_results['getent_services']['http'] = '80/tcp'
    assert res[1] == returned_results

    args = dict(
        database='services',
    )
    res = basic.AnsibleModule(argument_spec=args).run_command('/usr/bin/getent services')
    returned_results = dict()
    returned_results['getent_services'] = dict()
    assert res[1] == returned_results


# Generated at 2022-06-20 21:53:36.755122
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:53:47.441219
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    import os
    import os.path
    import tempfile

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')
    getent_bin = module.get_bin_path('getent', True)

    #

# Generated at 2022-06-20 21:53:52.029032
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'database': {'required': True, 'type': 'str'},
                                         'key': {'required': False, 'type': 'str'},
                                         'split': {'required': False, 'type': 'str'},
                                         'fail_key': {'required': False, 'type': 'bool', 'default': True} })
    module.get_bin_path = lambda _, executable: os.path.realpath(__file__)
    module.run_command = lambda cmd: (1, '', '')
    main()

# Generated at 2022-06-20 21:53:53.849786
# Unit test for function main
def test_main():
    # TODO: Complete function test for function main
    pass

# Generated at 2022-06-20 21:54:31.343043
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import action
    import platform

    def get_bin_path(name, required=False):
        return 'getent'

    module = basic.AnsibleModule(argument_spec={'database': {'required': False, 'type': 'str'}, 'key': {'required': False, 'type': 'str', 'no_log': False}, 'split': {'required': False, 'type': 'str'}}, supports_check_mode=True)
    module.get_bin_path = get_bin_path

    def run_command(cmd):
        import json

# Generated at 2022-06-20 21:54:32.409314
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:54:46.634208
# Unit test for function main
def test_main():

    # Mock module argument spec, provide helper to validate arguments
    mod = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str'),
            fail_key = dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock run_command()
    import subprocess

    class MockProcess(object):
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

    def mock_run_command(cmd):
        process = MockProcess()

        database = mod.params['database']
        key = mod.params.get('key')

# Generated at 2022-06-20 21:54:59.258501
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    database = module.params['database'],
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-20 21:55:11.880288
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils import basic
    # test_main() function is parametrized to call main with different values
    # for demo purposes i've extracted the constants for the different sets of parameters
    # and the expected result

    #test_case1_main()
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = 'shadow'
    key = None
    split = None
    service = None
    fail_key = True

   

# Generated at 2022-06-20 21:55:22.524480
# Unit test for function main
def test_main():
    from ansible.modules.remote_management.os import getent

    # Set args
    args = dict()
    args['database'] = 'passwd'
    args['key'] = 'root'
    args['service'] = None

    # Set up return values
    rc = 0;
    out = """root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin"""
    err = None

    # Run getent with known return values
    results = dict(rc=rc, out=out, err=err)
    values = getent.main(args, results)

    assert values['ansible_facts'] != None

# Generated at 2022-06-20 21:55:23.547839
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:55:27.504504
# Unit test for function main
def test_main():
    test_cases = ['test_database', 'test_key', 'test_service', 'test_split']
    for test_case in test_cases:
        print(test_case)
        exec(test_case)


# Generated at 2022-06-20 21:55:32.234899
# Unit test for function main
def test_main():
    data = [
        # expected, input
        ('foo', 'foo'),
        ('foobar', 'foobar'),
    ]

    for exp, input in data:
        assert exp == main(input)

# Generated at 2022-06-20 21:55:46.045369
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, "passwd"]

    class RunException(Exception):
        pass

    class Command:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            if cmd[1] == "passwd":
                return self.rc, self.out, self.err


# Generated at 2022-06-20 21:56:51.263510
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:56:52.359748
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:57:07.736190
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-20 21:57:16.620809
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:57:27.423398
# Unit test for function main
def test_main():
    run_me = 'not_called'
    class AnsibleModule:
        
        def __init__(self, *args, **kwargs):
            pass
        
        def get_bin_path(self, bin_path, required=False):
            return bin_path
        
        def run_command(self, cmd):
            global run_me
            run_me = cmd[0]
            return [0, 'test']
        
        def fail_json(self, *args, **kwargs):
            global run_me
            run_me = 'failed'
            raise Exception(kwargs['msg'])
        
        def exit_json(self, *args, **kwargs):
            global run_me
            run_me = 'success'
    
    # getent with default params

# Generated at 2022-06-20 21:57:33.534647
# Unit test for function main
def test_main():
    # Test with a key in the database
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = "passwd"
    key = 'root'
    split = ':'
    service = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:57:39.951237
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    try:
        import getent
    except:
        print("SKIP: Requires getent module available")
        return

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params['key']
    split = module.params['split']

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-20 21:57:49.563317
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')
    database = database
    key = key
    split = split
    service = service
    fail_key = fail_key


# Generated at 2022-06-20 21:57:55.827249
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest

    # exit_json return
    res = { 'ansible_facts': { 'getent_passwd': { 'root': ['x', '0', '0', 'root', '/root', '/bin/bash'] } } }

    try:
        from ansible.modules.system import getent
    except ImportError:
        this_path = os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(__file__)))
        sys.path.append(os.path.normpath(os.path.join(this_path, '../../')))
        from ansible.modules.system import getent

    getent.main()

# Generated at 2022-06-20 21:57:57.927877
# Unit test for function main
def test_main():
    cmd = ['getent', 'passwd', 'sync']
    rc, out, err = module.run_command(cmd)
    assert rc == 0

# Generated at 2022-06-20 22:00:26.753255
# Unit test for function main
def test_main():
    # Test that the module loads the following in ansible_facts:
    # {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}

    module = AnsibleModule(**{
        'argument_spec': {
            'database': {'type': 'str', 'required': True},
            'key': {'type': 'str', 'no_log': False},
            'service': {'type': 'str'},
            'split': {'type': 'str'},
            'fail_key': {'type': 'bool', 'default': True},
        },
        'supports_check_mode': True,
    })

    rc = 0
    out = 'root:x:0:0:root:/root:/bin/bash'
    err = ''

# Generated at 2022-06-20 22:00:35.939472
# Unit test for function main
def test_main():
    module_args = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False)
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    getent_bin = module.get_bin_path('getent', True)
    rc, out, err = module.run_command(getent_bin)
    if rc == 0:
        pass
    elif rc == 1:
        pass
    elif rc == 2:
        pass
    elif rc == 3:
        pass
    else:
        pass

# Generated at 2022-06-20 22:00:43.581768
# Unit test for function main
def test_main():
    # Test python 2.6
    from ansible.module_utils import basic
    import sys
    import StringIO

    if sys.version_info[:2] < (2, 7):
        output = StringIO.StringIO()
        sys.stdout = output

    module = AnsibleModule(argument_spec={
        "database": { "type": "str", "required": True },
        "key": { "type": "str", "no_log": False},
        "service": { "type": "str"},
        "split": { "type": "str"},
        "fail_key": { "type": "bool", "default": True }
    }, supports_check_mode=True)
    cmd = ["/bin/getent", "passwd", "root"]
    rc, out, err = module.run_command(cmd)