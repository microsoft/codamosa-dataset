

# Generated at 2022-06-20 21:51:14.909512
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *
    ANSIBLE_ARGS = dict(
        module_args=dict(
            database='passwd',
            key='root',
            split='root',
            fail_key=True,
        )
    )

    m = AnsibleModule(**ANSIBLE_ARGS)
    m.run_command = MagicMock(return_value=(0, "root:x:0:0:root:/root:/bin/bash", ""))
    m.run_command.return_value = (0, "root:x:0:0:root:/root:/bin/bash", "")
    main()
    assert m.exit_json.called

    m = AnsibleModule(**ANSIBLE_ARGS)

# Generated at 2022-06-20 21:51:23.576720
# Unit test for function main
def test_main():

    # You can use the test run to import a different module or test a specific function
    # To test a specific function, comment the following 2 lines:
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # And uncomment this one:

    # import ansible.modules.system.getent as getent
    # getent.main()

    module.params = {'database': 'passwd', 'key': 'root'}

    main()

# Generated at 2022-06-20 21:51:36.541293
# Unit test for function main
def test_main():
    import os
    import sys
    import mock
    import re

    from ansible.module_utils.basic import AnsibleModule

    passwd_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking', 'test_module.py')
    group_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'module_common.py')
    host_path = os.path.join(os.path.dirname(__file__), '..', 'lookup', '__init__.py')

# Generated at 2022-06-20 21:51:46.535016
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    module_args = {
        'database': 'passwd',
        'key': 'www-data',
        'split': ':'
    }
    module_return_value = {
        'getent_passwd': {
            'www-data': ['x', '48', '48', 'www-data', 'www-data', '/var/www', '/usr/sbin/nologin'],
            'www': ['x', '48', '48', 'www-data', 'www-data', '/var/www', '/usr/sbin/nologin']
        }
    }


# Generated at 2022-06-20 21:52:00.571035
# Unit test for function main
def test_main():
    test_cases = [
        {
            'database': 'passwd',
            'key': 'root',
            'rc': 0,
            'out': """root:x:0:0:root:/root:/bin/bash
testuser:x:1000:1000:Test User,,,:/home/testuser:/bin/bash
""",
        },
    ]
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:52:01.222721
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:52:09.301225
# Unit test for function main
def test_main():
    '''
    Simple test for function main
    This is to catch coverage for the function itself, not intended to test all
    options/possibilities
    '''

    # imports
    from ansible.module_utils.basic import AnsibleModule

    # set up class
    mod = AnsibleModule({'database': 'passwd',})

    mod.run_command = lambda args: (0, 'root:x:0:0:root:/root:/bin/bash', b'')

    # call function
    mod.main()

    # verify results
    assert mod.result['changed'] == False
    assert len(mod.result['ansible_facts']['getent_passwd']) == 1


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 21:52:16.117058
# Unit test for function main
def test_main():
    """test getent with various params"""

    test_dict = dict(
        database='aliases',
        key='ansible',
        service='systemd-resolve',
    )
    getent_bin = '/usr/bin/getent'

    cmd_list = [getent_bin, 'aliases', 'ansible', '-s', 'systemd-resolve']

    test_rc = 0
    test_out = 'ansible:\troot\n'
    test_err = ''

    main(test_dict, test_rc, test_out, test_err, cmd_list)

# Generated at 2022-06-20 21:52:16.933668
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:52:32.013997
# Unit test for function main
def test_main():
    # Mock module
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self):
            self.params = {
                'database': 'testdb',
                'key': 'testkey',
                'fail_key': True,
            }
            self.run_command_result_ok = (0, 'testdb:testkey\n', '')
            self.run_command_result_fail = (2, 'testdb:testkey\n', '')


# Generated at 2022-06-20 21:52:52.373691
# Unit test for function main
def test_main():
    # Getent example return
    GETENT_HOST_OUTPUT = """127.0.0.1 localhost
127.0.1.1 james-desktop
192.168.0.1 gateway.home.lan gateway

# The following lines are desirable for IPv6 capable hosts
::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
ff02::3 ip6-allhosts
"""


# Generated at 2022-06-20 21:53:05.280460
# Unit test for function main
def test_main():

    import json
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Avoid pylint errors
    assert AnsibleModule

    # Test with invalid database
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = 'unknown'
    key = 'root'
    fail_key = True
    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-20 21:53:05.857333
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:53:17.549241
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    rc = 1
    out = "Missing arguments, or database unknown."
    err = ""
    rc, out, err = module.run_command(getent_bin)

    assert rc == 1
    assert out == "Missing arguments, or database unknown."
    assert err == ""

    rc = 1

# Generated at 2022-06-20 21:53:29.579415
# Unit test for function main
def test_main():
    class AnsibleModuleStub:
        class ArgumentSpec:
            def __init__(self):
                self.key = "test_main"
                self.value = ""

        def __init__(self, args, supports_check_mode=True):
            self.params = args.copy()
            self.params['database'] = args['database']
            self.params['key'] = args['key']
            self.params['split'] = args['split']
            self.params['fail_key'] = args['fail_key']
            self.params['service'] = args['service']
            self.argument_spec = self.ArgumentSpec()
            self.supports_check_mode = supports_check_mode
            self.fail_json_output = []
            self.exit_json_output = []


# Generated at 2022-06-20 21:53:36.882493
# Unit test for function main
def test_main():
    import sys
    import json
    # Importing here to reuse code
    from ansible.module_utils.facts import get_distribution

    class MockModule(object):
        def __init__(self):
            self._name = 'getent'
            self.params = dict()

        def get_bin_path(self, name, required=True):
            return '/usr/bin/' + name

        def run_command(self, cmd):
            class RunResult(object):
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.stdout = out
                    self.stderr = err

# Generated at 2022-06-20 21:53:47.541151
# Unit test for function main
def test_main():
    args = dict(database='passwd',
                key='root',
                split=':',
                service=None,
                fail_key=True)
    from ansible.module_utils.facts.collector import base_resolve_facts, Collector

    # override the ansible module class, to properly handle ansible_facts.getent_passwd
    class GetEntModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(GetEntModule, self).__init__(*args, **kwargs)
            self.base_resolve_facts = base_resolve_facts


# Generated at 2022-06-20 21:53:52.928081
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:54:00.468289
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import time

    class AnsibleModuleStub(object):
        def __init__(self):
            self.run_command_returns = ''
            self.run_command_args = []
            self.fail_json_called = False
            self.fail_json_msg = None
            self.exit_json_called = False
            self.exit_json_msg = None
            self.get_bin_path_called = 0
            self.params = dict(
                database='passwd',
                key='root',
                fail_key=True,
            )
            self._tmp_dir = None
            self._tmp_path = None


# Generated at 2022-06-20 21:54:08.556528
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    sys.modules['__main__'] = basic
    sys.modules['ansible.module_utils.basic'] = basic
    sys.modules['ansible.module_utils.facts'] = basic
    sys.modules['ansible.module_utils._text'] = basic

    if sys.version_info[0] == 3 and sys.version_info[1] >= 4:
        stdout = StringIO()
    else:
        stdout = StringIO()
        string_type = str
        integer_types = (int,)

# Generated at 2022-06-20 21:54:47.038481
# Unit test for function main
def test_main():
    class FakeModule():

        def __init__(self):
            self.params = dict(
                database=dict(type='str', required=True),
                key=dict(type='str', no_log=False),
                split=dict(type='str'),
                module_default_arguments=dict(
                    supports_check_mode=True,
                )
            )

    class FakeExec():

        def __init__(self):
            self.rc = 0
            self.stdout = ''
            self.stderr = ''

        def run_command(self):
            return self.rc, self.stdout, self.stderr

    class FakeFile():

        def __init__(self):
            self.readlines = []

        def read(self):
            return self.readlines

    fake_module = FakeModule

# Generated at 2022-06-20 21:54:51.227478
# Unit test for function main
def test_main():
    # Make sure module does not throw an exception
    try:
        main()
    # Catch all other exceptions
    except Exception as e:
        print(e.message)

# Generated at 2022-06-20 21:55:05.200450
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:55:06.579726
# Unit test for function main
def test_main():
  # This is just an example of how unit tests can be written.
  # Replace with actual test
  assert 1 == 1

# Generated at 2022-06-20 21:55:21.977482
# Unit test for function main
def test_main():
    '''
    import os
    import sys
    import getent
    import traceback

    sys.path.insert(0, os.path.dirname(getent.__file__))
    fixture = os.path.join(os.path.dirname(getent.__file__), 'fixtures')
    config = dict(
        executable = {
            "getent": "id -u",
            },
        )
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
        ))
    main()
    '''
    pass

# Generated at 2022-06-20 21:55:34.405364
# Unit test for function main
def test_main():
    import json
    import os
    import tempfile
    import pytest
    from ansible.module_utils.basic import AnsibleModule, json

    hosts_content = ""
    hosts_content += "localhost\tlocalhost localhost.localdomain 127.0.0.1\n"
    hosts_content += "localhost\tlocalhost localhost.localdomain ::1\n"
    hosts_content += "127.0.0.1\tlocalhost localhost.localdomain localhost\n"
    hosts_content += "127.0.0.1\tlocalhost localhost.localdomain localhost\n"

    group_content = ""
    group_content += "root:x:0:\n"
    group_content += "daemon:x:1:\n"

# Generated at 2022-06-20 21:55:46.785422
# Unit test for function main
def test_main():
    #from ansible.module_utils.basic import *
    from ansible.module_utils import basic
    from ansible.module_utils import action

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    action.ANSIBLE_METADATA['supported_by'] = "core"
    action.ANSIBLE_METADATA[dbtree] = {'forks': 1}

    colon = ['passwd', 'shadow', 'group', 'gshadow']


# Generated at 2022-06-20 21:55:54.429704
# Unit test for function main
def test_main():
    print("Testing main")
    # Just a smoke test, real tests are done in testinfra
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-20 21:56:08.400928
# Unit test for function main
def test_main():
    import json
    import subprocess

    # mock ansible module
    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params
            self.results = None

        def fail_json(self, *args, **kwargs):
            self.results = {
                'failed': True,
                'params': self.params,
                'args': args,
                'kwargs': kwargs,
            }

        def exit_json(self, ansible_facts={}):
            self.results = {
                'failed': False,
                'changed': False,
                'ansible_facts': ansible_facts
            }


# Generated at 2022-06-20 21:56:19.527783
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', required=False),
            split=dict(type='str', required=False),
            fail_key=dict(type='bool', required=False, default=True)
        ),
        supports_check_mode=True
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:57:28.854733
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:57:37.533376
# Unit test for function main
def test_main():
    import json
    import tempfile
    import filecmp
    import os
    import shutil
    import mock

    class MyModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.result = dict()
            self.check_mode = False
            self.args = ["test"]

        def fail_json(self, **kwargs):
            self.result.update(**kwargs)
            return False

        @staticmethod
        def get_bin_path(name, required):
            return "/bin/true"

        def run_command(self, cmd):
            return 0, "", ""

    # Create temp dir for test

# Generated at 2022-06-20 21:57:48.246511
# Unit test for function main
def test_main():
  # make data available for tests
  import os
  import ansible.module_utils.action
  mod_path = os.path.dirname(ansible.module_utils.action.__file__)
  conf_path = os.path.join(mod_path, '../../module_utils/facts')
  test_data_path = os.path.join(conf_path, 'fixtures')
  test_data_file = os.path.join(test_data_path, 'getent_test.out')

  with open(test_data_file) as f:
    out = f.read()

  # test function
  from ansible.module_utils.facts import getent

  rc = 0
  err = ''

  module = {'params': {}}
  module['params']['database'] = 'group'



# Generated at 2022-06-20 21:58:00.113896
# Unit test for function main
def test_main():
    print("*** test_main ***")
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = "passwd"
    key = "root"
    split = ":"
    service = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:58:01.775688
# Unit test for function main
def test_main():
    with patch('ansible.modules.system.getent.AnsibleModule'):
        assert main() is None

# Generated at 2022-06-20 21:58:02.615509
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:58:14.045666
# Unit test for function main
def test_main():
    import unittest
    from ansible.module_utils.getent import main
    from ansible.module_utils import action
    import sys, os
    import tempfile
    
    class TestClass:
        def __init__(self, **kwargs):
            self.params = {'database': 'group', 'key': 'root', 'split': ':', 'service': None}

        def get_bin_path(self, cmd, required=False):
            return '/usr/bin/getent'

        def run_command(self, cmd):
            return 0, "root:x:0:0:root:/root:/bin/bash", ''

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def exit_json(self, **kwargs):
            pass


# Generated at 2022-06-20 21:58:20.683375
# Unit test for function main
def test_main():

    test_cases = [
        ['getent passwd root', {
                'ansible_facts': {
                    'getent_passwd': {
                        'root': ['x', '0', '0', 'root', '/root', '/bin/bash']
                    }
                }
            }
        ],
        ['getent group root', {
                'ansible_facts': {
                    'getent_group': {
                        'root': ['x', '0']
                    }
                }
            }
        ],
        ['getent group', {
                'ansible_facts': {
                    'getent_group': {
                        'root': ['x', '0'],
                        'app': ['x', '1000'],
                        'postgres': ['x', '90']
                    }
                }
            }
        ]
    ]

# Generated at 2022-06-20 21:58:22.443416
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:58:32.264397
# Unit test for function main
def test_main():
    __salt__ = {}
    __context__ = {}

    __opts__ = {}

    __pillar__ = {}

    __utils__ = {}

    ansible_module_getent = {
        'run_command': lambda cmd, cwd=None, runas=None, shell=False, env=None, clean_env=True, template=None, umask=None, timeout=None, stdin=None, quiet=False, data=None: (0, 'root:x:0:0:root:/root:/bin/bash', '')
    }

    # start test
    module = AnsibleModule(ansible_module_getent)
    module.exit_json = lambda **kwargs: kwargs
    module.params = {'database': 'passwd', 'key': 'root', 'split': ':'}
    assert main