

# Generated at 2022-06-20 21:51:12.126085
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec = dict(
            database = dict(required=True, type='str'),
            key = dict(required=False, type='str')
        ),
        supports_check_mode=True
    )

    # Save the original stdin and stdout
    sys.stdout = sys.__stdout__
    sys.stdin = sys.__stdin__

    # Set to bytes
    m.params['database'] = to_bytes(m.params['database'])
    m.params['key'] = to_bytes(m.params['key'])

    main()

# Generated at 2022-06-20 21:51:13.266957
# Unit test for function main
def test_main():
    #Testing main function
    assert False

# Generated at 2022-06-20 21:51:24.601051
# Unit test for function main
def test_main():
    # Importing in module context
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping

    getent_bin = basic.AnsibleModule.get_bin_path('getent')
    getent_bin = getent_bin if getent_bin is not None else 'getent'

    # Key that doesn't exist in the database
    fake_key = "this_key_should_not_exist"
    expected_msg = "One or more supplied key could not be found in the database."

    # Define a fake ansible module
    class MockModule:
        # This is a subset of the parameters we expect to get
        def __init__(self):
            self.params = {}
            self.params

# Generated at 2022-06-20 21:51:34.263902
# Unit test for function main
def test_main():
    # Open up stdout/stderr from end of module execution
    from ansible.module_utils.basic import _AnsibleModule
    m = _AnsibleModule({})
    m.fail_json = lambda: None
    m.exit_json = lambda: None
    m.get_bin_path = lambda x, y: x
    m.run_command = lambda x: x[0:2]
    sys.modules["ansible.module_utils.basic"]._ANSIBLE_ARGS = None
    sys.argv = [sys.argv[0]]

    # --------------------------------------------------------------------------------
    # Successful case
    # --------------------------------------------------------------------------------
    return_values = [0, 1, 2, 3]
    for rc in return_values:
        m.run_command = lambda x: [rc, "Out", "Err"]



# Generated at 2022-06-20 21:51:39.673327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main() is None

# Generated at 2022-06-20 21:51:46.038055
# Unit test for function main
def test_main():
    print("Testing function main")

    input_params = { 'database': 'passwd', 'key': 'root' }
    output_params = {}
    output_params['ansible_facts'] = { 'getent_passwd': { 'root': ['x','0','0'] } }
    output_params['msg'] = ''
    output_params['rc'] = 0

    from ansible_collections.ansible.community.plugins.action.getent import main
    main(input_params, output_params)

# Generated at 2022-06-20 21:51:54.578457
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dicts import merge_hash
    import json
    import subprocess
    import sys
    import os

    # create 'ansible_' facts from the given test_data
    module = AnsibleModule({})
    setattr(module, '_ansible_facts', dict())
    for key in test_data:
        if isinstance(test_data[key], dict):
            module._ansible_facts[key] = module.params[key] = test_data[key]
        else:
            module._ansible_facts[key] = module.params[key] = test_data[key]

    # set up the module to return a particular argument set and add other attributes
    test_

# Generated at 2022-06-20 21:52:09.601067
# Unit test for function main
def test_main():
    global module_args, module, action, msg, results
    module_args = getent_args = {
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': True,
        'check_mode': False,
        'path': ['/usr/bin'],
    }
    module = AnsibleModule(getent_args)
    main()
    assert module.exit_json.called_with == {'ansible_facts': {'getent_passwd': {'root': ['x', 0, 0, 'root', '/root', '/bin/bash']}}}
    # Test the check mode does not have any failure, it may have a side effect of adding a fact though
    module.params['check_mode'] = True
    main()
   

# Generated at 2022-06-20 21:52:14.906538
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.exit_json(annotate=m)

# Generated at 2022-06-20 21:52:24.135800
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import tempfile

    #
    # Setup a mocked getent for testing.
    #
    # This will mock out the getent utility in /usr/bin with a version that
    # returns some faked out output for testing.
    #
    test_getent = tempfile.NamedTemporaryFile(mode='w+t')

# Generated at 2022-06-20 21:52:41.601242
# Unit test for function main
def test_main():
    args = dict(database='passwd', key='')
    ret = main()
    assert ret is not None
    assert ret['stdout'] is not None
    assert ret['changed'] is True

# Generated at 2022-06-20 21:52:43.888259
# Unit test for function main
def test_main():
    argv = ['database=hosts']
    main()


# Generated at 2022-06-20 21:52:53.375976
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'services'
    key = 'http'
    split = ':'
    service = 'services'
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:53:05.399154
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    out = """
    """.strip()

    if PY3:
        out = to_bytes(out)

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:53:07.495449
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        print(type(e))
        print(e)
        return
    assert False

# Generated at 2022-06-20 21:53:18.726792
# Unit test for function main
def test_main():
    import tempfile
    import os
    from ansible.module_utils.six import PY2

    if not PY2:
        from io import StringIO
        from io import UnsupportedOperation
    else:
        from StringIO import StringIO
        UnsupportedOperation = Exception

    def delete_file(filename):
        try:
            os.remove(filename)
        except OSError:
            pass
        except Exception as e:
            raise e

    getent_bin = '/usr/bin/getent'

    tmpdir = tempfile.gettempdir()

    outfile = os.path.join(tmpdir, 'out.txt')
    errfile = os.path.join(tmpdir, 'err.txt')

    delete_file(outfile)
    delete_file(errfile)

    test_dict = {}



# Generated at 2022-06-20 21:53:33.574051
# Unit test for function main
def test_main():
    test_module_dir = 'tests/modules/action'
    test_module_name = 'test_action_getent.py'
    test_module_path = '%s/%s' % (test_module_dir, test_module_name)

    test_component_name = 'action_plugins'
    test_component_path = 'lib/ansible/plugins/%s' % test_component_name

    # Step 1: Find the path to this ansible script
    ansible_script_path = os.path.realpath(__file__)

    # Step 2: Find the path to the Ansible module_utils directory
    parts = ansible_script_path.split(os.path.sep)
    module_utils_dir_index = parts.index('module_utils')

# Generated at 2022-06-20 21:53:44.841778
# Unit test for function main
def test_main():
    module_name = "__main__"
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_

# Generated at 2022-06-20 21:53:45.783032
# Unit test for function main
def test_main():
    assert False, "No tests written"

# Generated at 2022-06-20 21:53:57.260607
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'bob'
    split = ':'
    if database in colon:
        split = ':'

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

   

# Generated at 2022-06-20 21:54:24.710516
# Unit test for function main
def test_main():
    '''
    ansible/test/units/modules/extras/system/getent.py
    '''

# Generated at 2022-06-20 21:54:29.543320
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import os

    if os.uname()[4].startswith("arm"):
        module.exit_json(changed=False)
    else:
        getent_bin = module.get_bin_path('getent')

        if getent_bin:
            rc, out, err = module.run_command([getent_bin, 'passwd', 'root'])

# Generated at 2022-06-20 21:54:40.635728
# Unit test for function main
def test_main():
    class Args(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    class Module(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
        def fail_json(self, **kwargs):
            raise Exception(kwargs["msg"])

    module_args = {
        'database': 'passwd',
        'key': 'root',
    }
    p = Args(**module_args)
    m = Module(argument_spec={})
    m.params = p

    #test 1 - missing split
    getent_bin = "./test/test_getent"
    class Run_command(object):
        def __init__(self, cmd):
            self.cmd = cmd


# Generated at 2022-06-20 21:54:49.218214
# Unit test for function main
def test_main():
    """Unit testing"""

    # getent: command not found

    # RC 0, empty result
    cmd = ['getent', 'database']
    rc = 0
    out = ''
    err = ''
    results = {'getent_database': {}}

    # RC 0, full result
    cmd = ['getent', 'database']
    rc = 0
    out = 'key:value'
    err = ''
    results = {'getent_database': {'key': ['value']}}

    # RC 0, full result, multiple lines
    cmd = ['getent', 'database']
    rc = 0
    out = 'key:value\nkey2:value2'
    err = ''
    results = {'getent_database': {'key': ['value'], 'key2': ['value2']}}

    # RC >

# Generated at 2022-06-20 21:55:00.174418
# Unit test for function main
def test_main():
    # First element is a string, second is a list
    # Print the string, then print each element of the list on its own line
    def pprint(l):
        print(l[0])
        for item in l[1]:
            print(item)

    import sys
    sys.argv.append('--database=services')
    main()
    sys.argv[-1] = '--database=shadow'
    main()
    sys.argv[-1] = '--database=group'
    main()
    sys.argv[-1] = '--database=passwd'
    main()
    sys.argv[-1] = '--database=hosts'
    main()
    sys.argv[-1] = '--database=nonesuch'
    main()

# Generated at 2022-06-20 21:55:08.466876
# Unit test for function main

# Generated at 2022-06-20 21:55:24.763477
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.modules.system.getent import main
    import os

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_os = os.environ.get('TEST_GETENT')
    class TestGetent:
        def __init__(self, test_os):
            self.binpath = os.path.dirname(os.path.abspath(__file__)) + '/getent'

# Generated at 2022-06-20 21:55:25.763555
# Unit test for function main
def test_main():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-20 21:55:36.617113
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import pickle
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # make a tmp dir
    test_dir_path = tempfile.mkdtemp()

    # make a temp install directory
    install_dir = os.path.join(test_dir_path, '.ansible_module_utils')
    os.mkdir(install_dir)

    # create a dummy get

# Generated at 2022-06-20 21:55:47.474292
# Unit test for function main
def test_main():
    ''' Unitary test for getent module '''
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.basic import AnsibleModule, env_fallback

    check_mode = True
    result = {'failed': False, 'ansible_facts': {}}
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=check_mode,
    )

    # Mock module input parameters

# Generated at 2022-06-20 21:56:54.908751
# Unit test for function main
def test_main():
    module = get_module_mock({'database': 'shadow', 'key': 'root'})
    cmd = [module.get_bin_path('getent', True), 'shadow', 'root']
    rc, out, err = module.run_command(cmd)
    module.exit_json(ansible_facts={'getent_shadow': {'root': ['x', 0, 99]}})


# Generated at 2022-06-20 21:57:05.488519
# Unit test for function main
def test_main():
    """ Unit tests for main """
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:57:15.849945
# Unit test for function main
def test_main():
    import os
    os.environ['IS_ANSIBLE_UNIT_TEST'] = '1'

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:57:21.305176
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Test with parameters that would normally work
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Fail with non-zero return code
    rc = 1
    out = to_bytes("""foo
bar
""")
    err = to_bytes('')

    module.run_command.side_effect = [(rc, out, err)]

# Generated at 2022-06-20 21:57:25.086909
# Unit test for function main
def test_main():
    t = None
    module = ansible_module_getent.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module

# Generated at 2022-06-20 21:57:35.796529
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    #key = module.params.get('key')
    split = module.params.get('split')
    #service = module.params.get('service')
    #fail_key = module.params.get('fail_key')


# Generated at 2022-06-20 21:57:47.312282
# Unit test for function main
def test_main():
    import sys
    import json
    import tempfile
    import os
    import traceback
    import mock

    class FakeModule:
        def __init__(self):
            self.check_mode = False
            self.debug = False
            self.run_command_sum = 0
            self.run_command_rc = 0
            self.run_command_out = ""
            self.run_command_err = ""
            self.run_command_key = ""

        def fail_json(self, **kwargs):
            print(json.dumps(kwargs, sort_keys=True, indent=4))
            self.exit_args = kwargs
            sys.exit(1)


# Generated at 2022-06-20 21:57:52.410789
# Unit test for function main
def test_main():

    import tempfile
    import os

    module_args = dict(
        database='passwd',
        key='root'
    )

    # I'd prefer for these to be tempfile.TemporaryDirectory's but the
    # destruction of those doesn't seem to be working the way I think it
    # should, and this way makes the code more self-contained.
    def create_temp_file(contents):
        f = tempfile.NamedTemporaryFile(delete=False, mode='w+')
        f.write(contents)
        f.close()
        return f.name

    passwd_path = create_temp_file('root:x:0:0:root:/root:/bin/bash')
    def cleanup_passwd():
        os.unlink(passwd_path)

    # construct a module with our defined args


# Generated at 2022-06-20 21:57:54.877047
# Unit test for function main
def test_main():
    # TODO: unit test for main function
    main()

# Generated at 2022-06-20 21:57:56.140719
# Unit test for function main
def test_main():
  res = main()
  assert(res.get('rc') == 0)

# Generated at 2022-06-20 22:00:26.127942
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main() == None


# Generated at 2022-06-20 22:00:37.232703
# Unit test for function main
def test_main():
    print('Test: main')

    # Import needed packages
    import logging
    import tempfile
    import json
    import sys, os
    import imp
    import ansible.module_utils.basic

    # Load Module
    module = imp.load_source('getent', 'action_plugins/getent.py')
    main = module.main

    # Create a logger
    output_file = tempfile.mkstemp()
    log = logging.getLogger('unittest')
    outHandler = logging.StreamHandler(open(output_file[1], 'w'))
    outHandler.setFormatter(logging.Formatter('%(message)s'))
    log.addHandler(outHandler)
    log.setLevel(logging.DEBUG)

    # Create an AnsibleModule

# Generated at 2022-06-20 22:00:43.581689
# Unit test for function main
def test_main():
    def run_command(module):
        return (0, 'db:host:host user:127.0.0.1\ndb:host:host user:10.1.1.1\ndb:host:host user:10.2.2.2\ndb:host:host user:2001::1', '')
    module.run_command = run_command
    assert module.run_command is not None

    module.params = {'database':'db','key': 'host','split':':'}

    main()
    assert module.exit_json['ansible_facts']['getent_db']['host'][0][0] == 'host user'