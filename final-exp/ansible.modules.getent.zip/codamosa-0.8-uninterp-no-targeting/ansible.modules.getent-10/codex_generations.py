

# Generated at 2022-06-20 21:51:11.643940
# Unit test for function main
def test_main():
    import json
    import subprocess
    import shlex
    import pytest

    db_name = 'passwd'
    module_path = 'ansible.modules.system.getent'
    my_getent = '/usr/bin/getent'
    module_name = 'main'

# Generated at 2022-06-20 21:51:22.382154
# Unit test for function main
def test_main():
    # Test 1, getent passwd root
    # ==========================
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = "passwd"
    key = "root"
    split = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-20 21:51:31.536148
# Unit test for function main
def test_main():
    # add fake modules
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import sys
    sys.modules['ansible.module_utils.basic'] = module
    assert main() is None

# Generated at 2022-06-20 21:51:42.264518
# Unit test for function main
def test_main():
    # Test with default params
    module = AnsibleModule(dict(
        database='nsswitch',
        key=None
    ))
    results = main()
    assert results

    # Test with service
    module = AnsibleModule(dict(
        database='services',
        key='http',
        service='files'
    ))
    results = main()
    assert results

    # Test with split
    module = AnsibleModule(dict(
        database='protocols',
        key=None,
        split=':'
    ))
    results = main()
    assert results

    # Test with fail_key
    module = AnsibleModule(dict(
        database='protocols',
        key=None,
        fail_key=True
    ))
    results = main()
    assert results

# Generated at 2022-06-20 21:51:46.368717
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
                'database': dict(type='str', required=True),
                'key': dict(type='str', no_log=False),
                'service': dict(type='str'),
                'split': dict(type='str'),
                'fail_key': dict(type='bool', default=True),
            },
            supports_check_mode=True,
        )

    m_run_command = module.run_command
    m_get_bin_path = module.get_bin_path

    class RunCommandResult:
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr


# Generated at 2022-06-20 21:51:56.318177
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    result = main()
    print(result)


# Generated at 2022-06-20 21:52:08.286686
# Unit test for function main
def test_main():
    import os
    import tempfile

    file_name = tempfile.mkstemp()[1]

    os.system('''echo "testuser:x:0:0::/root:/bin/bash" > %s''' % file_name)

    result = main({
        "database": file_name,
        "key": "testuser"
    })

    os.remove(file_name)
    assert type(result['ansible_facts']['getent_' + file_name]) is list

    assert len(result['ansible_facts']['getent_' + file_name]) == 6

    assert result['ansible_facts']['getent_' + file_name][0] == 'testuser'

# Generated at 2022-06-20 21:52:16.829597
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.getent import main
    from ansible.module_utils.facts.system.getent.getent import GetentModule
    from ansible.module_utils.basic import AnsibleModule

    # set up module
    module = AnsibleModule(argument_spec={
        "database": {"type": "str"},
        "key": {"type": "str"}
    })

    # mock module
    with GetentModule.patch(module):
        with GetentModule.patch(module) as getent:

            # Test 1
            getent.run_command.return_value = 0, "line1\nline2", ""
            main()

            results = module.exit_json.call_args_list[0][0]['ansible_facts']

# Generated at 2022-06-20 21:52:31.957743
# Unit test for function main
def test_main():
    import sys
    import os

    script_dir = os.path.dirname(os.path.realpath(__file__))

    m = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    # Set module parameters
    database = 'passwd'
    key = 'root'
    split = ':'
    service = 'test-service'
    fail_key = False


# Generated at 2022-06-20 21:52:37.179576
# Unit test for function main
def test_main():
    with patch.object(os.path, 'isfile', return_value=True):
        with patch.object(os, 'environ', {'PATH':'/bin:/usr/bin'}):
            with patch.object(module_loader.AnsibleModule, 'run_command') as run_command:
                run_command.return_value = (0, '', '')
                res = main()
                assert res == {'ansible_facts': {'getent_group': {'root': ['0', 'root', '/root', '/bin/bash']}}}

# Generated at 2022-06-20 21:53:16.012958
# Unit test for function main
def test_main():
    test_args = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )
    module = AnsibleModule(argument_spec=test_args)
    module.run_command = create_ansible_mock(True, 0, 'root:x:0:0:root:/root:/bin/bash\nbin:x:1:1:bin:/bin:/sbin/nologin')

    main()
    assert module.exit_json.called

    test_args = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )
    module = AnsibleModule(argument_spec=test_args)

# Generated at 2022-06-20 21:53:22.936980
# Unit test for function main
def test_main():

    module = AnsibleModule({
        'database': 'passwd',
        'key': 'bob'
    }, check_invalid_arguments=False)

    import os
    import sys

    # set the PATH so ansible module helper can find our getent mock
    os.environ['PATH'] = os.path.dirname(__file__)

    # load our passwd test file
    sys.modules['etc'] = type('fake_etc', (object,), {})
    etc = sys.modules['etc']
    setattr(etc, 'passwd', [])
    with open('passwd', 'r') as f:
        for user in f.readlines():
            etc.passwd.append(user.strip().split(':'))

    # run module
    main()


# Generated at 2022-06-20 21:53:31.617455
# Unit test for function main
def test_main():
    # We need to create a dummy module and set all its arguments
    module = AnsibleModule(argument_spec={
        'database': {'type': 'str', 'required': True},
        'key': {'type': 'str', 'no_log': False},
        'service': {'type': 'str'},
        'split': {'type': 'str'},
        'fail_key': {'type': 'bool', 'default': True},
    })

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    module.params = {
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': True,
    }

    main()

# Generated at 2022-06-20 21:53:38.067661
# Unit test for function main
def test_main():
    input_dict = {
        'database': 'passwd',
        'key': 'root',
    }
    input_str = '{"database": "passwd", "key": "root"}'
    cmd = ['getent', 'passwd', 'root']
    rc = 0
    out = 'root:x:0:0:root:/root:/bin/bash'
    err = ''
    results = {
        'getent_passwd': {
            'root': ['x', '0', '0', 'root', '/root', '/bin/bash']
        },
    }


# Generated at 2022-06-20 21:53:48.324056
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    class _module():
        def __init__(self, **kwargs):
            self.params = kwargs
            self.args = []

        def fail_json(self, **kwargs):
            self.result = kwargs
            self.result['failed'] = True
            raise SystemExit()

        def exit_json(self, **kwargs):
            self.result = kwargs
            raise SystemExit()

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/getent'

        def run_command(self, *args, **kwargs):
            self.called = args
            return 0, 'test', 'err'


# Generated at 2022-06-20 21:53:57.565045
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-20 21:54:03.319833
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:54:09.606557
# Unit test for function main
def test_main():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            self.fail_args = kwargs

        def get_bin_path(self, args):
            return args

        def run_command(self, args):
            if args[1] == "not_found":
                return 2, "", ""
            elif args[1] == "unsupported_db":
                return 3, "", ""
            elif args[1] == "empty":
                return 0, "", ""
            elif args[1] == "service_db":
                return 0, "proto name portaliases", ""
            elif args[1] == "db":
                return 0, "name proto portaliases", ""


# Generated at 2022-06-20 21:54:21.554387
# Unit test for function main
def test_main():
    import json

    import ansible.modules.system.getent as getent


# Generated at 2022-06-20 21:54:33.540540
# Unit test for function main
def test_main():
    test1 = AnsibleModule({"database":"passwd", "key":"root"})
    test2 = AnsibleModule({"database":"group", "split":"\t"})
    test3 = AnsibleModule({"database":"hosts"})
    test4 = AnsibleModule({"database":"services", "key":"http", "fail_key":False})
    test5 = AnsibleModule({"database":"shadow", "key": "www-data", "split":"\t"})

    test1.run_command = mock_run_command([0, "root:x:0:0:root:/root:/bin/bash", None, None])

# Generated at 2022-06-20 21:55:10.290501
# Unit test for function main
def test_main():
    import subprocess
    from ansible.module_utils._text import to_bytes

    args = [''.join(['getent', ' ', 'services', ' ', 'http'])]

    proc = subprocess.Popen(args, stdout=subprocess.PIPE)
    out, _ = proc.communicate()

    assert out == to_bytes('http\t80/tcp\twww\n')

    args = [''.join(['getent', ' ', 'services', ' ', 'does_not_exist'])]

    proc = subprocess.Popen(args, stdout=subprocess.PIPE)
    out, _ = proc.communicate()

    assert out == to_bytes('')

# Generated at 2022-06-20 21:55:20.920637
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.dict_transformations import _to_omit, _to_list, _to_simple_value, dict_diff
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    assert DistributionFactCollector.name == "Distribution"


# Generated at 2022-06-20 21:55:33.476034
# Unit test for function main
def test_main():
    # Unit test for function main

    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True))

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True)

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.params['split'] = ':'
    module.run_command = mock.Mock(return_value=(0, 'root:x:0:0:root:/root:/bin/bash', ''))
    module.run_command.reset_mock()
    main

# Generated at 2022-06-20 21:55:46.508931
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, env_fallback

    module = AnsibleModule({
        'database': dict(type='str', required=True),
        'key': dict(type='str', no_log=False),
        'service': dict(type='str'),
        'split': dict(type='str'),
        'fail_key': dict(type='bool', default=True),
    },
    supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    # check if getent is available

# Generated at 2022-06-20 21:55:56.301065
# Unit test for function main
def test_main():

    # Unsupported database
    module = AnsibleModule(
        argument_spec={
          'database' : dict(type='str', required=False),
        },
        supports_check_mode=False
    )
    module.params['database'] = 'unknown'
    main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0]['failed']
    assert module.exit_json.call_args[0]['msg'] == "Missing arguments, or database unknown."

    # No keys to search for
    module = AnsibleModule(
        argument_spec={
          'database' : dict(type='str', required=False),
        },
        supports_check_mode=False
    )
    module.params['database'] = 'passwd'
    main()
    assert module.exit_json

# Generated at 2022-06-20 21:56:09.470059
# Unit test for function main
def test_main():
    import inspekt_mocks


# Generated at 2022-06-20 21:56:20.369148
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True,)

    dbname = "test_database"
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:56:25.940018
# Unit test for function main

# Generated at 2022-06-20 21:56:34.275997
# Unit test for function main
def test_main():
    argv = ['-D']
    argv.append('{"ANSIBLE_MODULE_ARGS": {"database": "passwd", "key": "root", "_ansible_check_mode": false, "_ansible_diff": false, "_ansible_verbosity": 0}}')
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule._ansible_argument_spec = dict(database=dict(type='str'), key=dict(type='str', no_log=False), service=dict(type='str'), split=dict(type='str'), fail_key=dict(type='bool', default=True),)
    AnsibleModule._ansible_module = None
    main()
    assert True == True

# Generated at 2022-06-20 21:56:42.667585
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-20 21:57:47.882378
# Unit test for function main
def test_main():
    # mock import
    import sys
    sys.modules['ansible.module_utils.facts'] = 'facts'

    # mock module
    module = AnsibleModule(argument_spec={'database':{'type':'str', 'required':True},
                                          'key':{'type':'str'},
                                          'service':{'type':'str'},
                                          'split':{'type':'str'},
                                          'fail_key':{'type':'bool', 'default':True}})

    # mock input
    module.params['database'] = 'passwd'
    module.params['key'] = 'root'

    class MockRunCommand:
        def __init__(self):
            self.result = 0


# Generated at 2022-06-20 21:57:52.886439
# Unit test for function main
def test_main():
    import sys
    import os

    test_file = os.path.join(os.path.dirname(__file__), "getent_test.py")

    if not os.path.exists(test_file):
        print("No test file found.  Skipping")
        return

    sys.path += [os.path.join(os.path.dirname(__file__), "..")]

    __import__('action_plugin.getent_test')

# Generated at 2022-06-20 21:58:05.477035
# Unit test for function main
def test_main():

    def fake_run_command(module, cmd):
        class FakeCmdResult:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = self.stderr = ''
                self.stdout = out
                self.stderr = err

        if cmd == ['/usr/bin/getent', 'passwd', 'root']:
            return (0, 'root:x:0:0:root:/root:/bin/bash\n', '')
        if cmd == ['/usr/bin/getent', 'passwd', 'root', '-s', 'does-not-exist']:
            return (1, '', '')

# Generated at 2022-06-20 21:58:12.408310
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.exit_json(msg="OK")

# Generated at 2022-06-20 21:58:13.632528
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:58:28.869201
# Unit test for function main
def test_main():
    import json
    import os
    import sys
    import pytest
    from ansible.module_utils import basic

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # setup for test
    argv = sys.argv
    sys.argv = [os.path.basename(argv[0]),
                'database=test',
                '--variables={"test":"test"}',
                '--tags', 'test',
                '--extra-vars', 'var=test',
                '--environment=test']

    # run test function
    module_args = {'database': 'test',
                   'key': 'test',
                   'split': 'test',
                   'output': 'test',
                   'fail_key': 'test'}
   

# Generated at 2022-06-20 21:58:39.319394
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import inspect
    import pytest
    from ansible_collections.ansible.community.plugins.module_utils.facts import getent as m_getent

    module_path = os.path.dirname(os.path.abspath(inspect.getfile(m_getent)))
    getent_bin = os.path.join(module_path, '../../../../../bin/getent')


# Generated at 2022-06-20 21:58:44.780536
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:58:54.489264
# Unit test for function main
def test_main():

    # Test case for main
    def mainTest(self):
        # Test for main

        # Get options from module_utils/basic.py
        self.mock_module.params = self.get_module_params()
        self.mock_module.params['database'] = 'passwd'

        # Return code, stdout and stderr given by getent
        self.mock_run_commands_result = [0, b"root:x:0:0:root:/root:/bin/bash", None]

        # Run main()
        main()

        # Check that module.exit_json() is called.

# Generated at 2022-06-20 21:58:58.583206
# Unit test for function main
def test_main():
    test_cases = [
        {
            'database': 'hosts',
            'key': '',
            'split': '',
            'fail_key': True,
        },
        {
            'database': 'group',
            'key': 'root',
            'split': ':',
            'fail_key': True,
        }
    ]

    for test_case in test_cases:
        main = test_main.__wrapped__
        results = main(test_case)

        assert results['ansible_facts']['getent_%s' % test_case['database']] is not None