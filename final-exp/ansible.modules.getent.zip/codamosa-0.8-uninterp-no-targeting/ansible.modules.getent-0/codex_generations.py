

# Generated at 2022-06-20 21:51:11.867391
# Unit test for function main
def test_main():
    #import platform
    #if platform.system() == 'FreeBSD':
    #    return
    #if platform.system() == 'Darwin':
    #    return

    module = AnsibleModule(dict(
        database=dict(type='str', required=True),
        key=dict(type='str', required=True),
        split=dict(type='str'),
    ))
    try:
        main()
    except SystemExit as e:
        pass
    except Exception as e:
        raise e

# Generated at 2022-06-20 21:51:20.479155
# Unit test for function main
def test_main():
    import pytest

    # generate test data with method
    def get_test_input(test_input_value):
        module_args = dict(
            database=test_input_value,
            key='root',
        )
        return dict(module_args=module_args, check_mode=False, no_log=False)

    test_input = 'passwd'

    # get the test data
    test_data = get_test_input(test_input)

    # test
    with pytest.raises(SystemExit):
        main()



# Generated at 2022-06-20 21:51:33.173066
# Unit test for function main
def test_main():
    l_cmd = ['/usr/bin/getent', 'hosts', 'localhost']
    l_rc = 0
    l_out = '127.0.0.1\tlocalhost\n::1\tlocalhost\n'
    l_err = ''

    import mock
    module_mock = mock.MagicMock()
    module_mock.params = {'database': 'hosts'}
    module_mock.get_bin_path.return_value = '/usr/bin/getent'
    module_mock.run_command.return_value = (l_rc, l_out, l_err)

    main()
    module_mock.run_command.assert_called_with(l_cmd)

# Generated at 2022-06-20 21:51:34.740597
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-20 21:51:44.023347
# Unit test for function main
def test_main():

    # Arrange
    module_args = {
        'database': 'passwd',
        'key': 'root',
        'split': None,
        'fail_key': True,
    }

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
   

# Generated at 2022-06-20 21:51:50.853175
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import platform

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    return module.exit_json(
        ansible_facts=dict(),
        changed=False
    )


# Command line test

# Generated at 2022-06-20 21:52:03.008285
# Unit test for function main
def test_main():

    class Args(object):
        """Fake args object"""
        module_name = 'getent'
        module_path = 'ansible.modules.system.getent.py'
        module_args = dict(database='group', split=None, key=None, service=None, fail_key=True)
        check_mode = False
        diff_mode = False

        def get(self, item):
            return self.module_args[item]

    class Run(object):
        """Fake run object"""
        return_value = (0, '', '')
        called = False

        def __call__(self, cmd, check_rc=False):
            self.called = True
            self.cmd = cmd
            return self.return_value

    class Module(object):
        """Fake module object"""


# Generated at 2022-06-20 21:52:04.644912
# Unit test for function main
def test_main():
    import sys
    sys.path.append('.')
    from getent import main


# Generated at 2022-06-20 21:52:12.080314
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # getent passwd root
    # root:x:0:0:root:/root:/bin/bash
    appsdba_passwd = "appsdba::1002:1003::/apps/app/appadm/appsdba:/bin/ksh"
    # getent group appadm
    # appadm:x:1003:appadm
    appadm_group = "appadm:x:1003"


# Generated at 2022-06-20 21:52:21.977701
# Unit test for function main
def test_main():
    import unittest

# Generated at 2022-06-20 21:52:48.034834
# Unit test for function main
def test_main():
    module_args = {}
    module_args['database'] = 'passwd'
    module_args['key'] = 'root'

    module_object = AnsibleModule(
        argument_spec=module_args, supports_check_mode=True)

    # If not running on a remote target host, then fail
    if not module_object.params['remote_user']:
        module_object.fail_json(msg='Running getent on a remote host is not supported')

    # If database is not supported, then fail
    if module_object.params['database'] not in ['passwd', 'shadow', 'group']:
        module_object.fail_json(msg='Database not supported')

    # If key is empty, then fail

# Generated at 2022-06-20 21:52:56.891583
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import action
    import os

    def _execute_module(module_name, module_args, tmp=None):
        module_args['ANSIBLE_MODULE_ARGS'] = module_args
        m = basic.AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str', no_log=False),
                service=dict(type='str'),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )
        m._load_params()
        module_args = m.params

# Generated at 2022-06-20 21:53:02.015811
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # We need to set these so run_command has something
    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.params['split'] = ':'
    module.params['service'] = 'ldap'
    module.params['fail_key'] = 'yes'

# Generated at 2022-06-20 21:53:17.532388
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:53:29.579277
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, json
    import sys
    sys.modules['ansible'] = None

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # first test, getent passwd, but 'root'
    module.params = {'database': 'passwd', 'key': 'root'}

    main()

# Generated at 2022-06-20 21:53:34.684829
# Unit test for function main
def test_main():
    '''
    Ansible getent module, function main
    Unit Tests
    '''
    import sys
    import os
    import json
    import shlex
    from mock import Mock
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Cache

    # Read in test file(s)
    data_dir = os.path.dirname(__file__) or '.'
    data_dir = os.path.join(data_dir, 'unit/')
    data_dir = os.path.abspath(data_dir)
    sys.path.append(os.path.dirname(data_dir))

    # Mock module
    module = type('ansible_module', (object,), dict())
    module.run_command = Mock()

# Generated at 2022-06-20 21:53:45.828119
# Unit test for function main
def test_main():
    # Prepare some mocks
    class MockModule:
        def __init__(self):
            self.argument_spec = {
                "database": {
                    "required": True,
                    "type": "str"
                },
                "key": {
                    "no_log": False,
                    "required": False,
                    "type": "str"
                },
                "service": {
                    "required": False,
                    "type": "str"
                },
                "split": {
                    "required": False,
                    "type": "str"
                },
                "fail_key": {
                    "default": True,
                    "required": False,
                    "type": "bool"
                }
            }
            self.fail_json = self.fail
            self.exit_json = self.exit
            self.failures

# Generated at 2022-06-20 21:53:57.259860
# Unit test for function main
def test_main():

    # Test empty arguments
    test_args = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
    )

    module = AnsibleModule(
        argument_spec=test_args,
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    # Test empty arguments
    test_args = dict(
        database='',
        key='',
        service='',
        split='',
    )

    module.params = test_args

    module.run_command = MagicMock(return_value=(1, '', ''))

# Generated at 2022-06-20 21:54:03.603316
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class ModuleFailException(Exception):
        def __init__(self):
            pass
    module.fail_json = lambda *args, **kwargs: ModuleFailException()
    module.run_command = lambda *args, **kwargs: (0, '', '')

    try:
        main()
    except Exception as e:
        assert type(e).__name__ == 'ModuleFailException'

    # test valid input

# Generated at 2022-06-20 21:54:08.162628
# Unit test for function main
def test_main():
    "Test function main"
    from ansible.modules.system import getent

    # Set up a fake module object
    class Arguments:
        def __init__(self, database, key, split, service, fail_key):
            self.database = database
            self.key = key
            self.split = split
            self.service = service
            self.fail_key = fail_key

    class FakeModule:
        def __init__(self):
            self.params = Arguments('group', 'root', ':', None, True)
            self.check_mode = True
            self.run_command = lambda cmd, check_rc=True: ([0, 'root:x:0:\n', ''], 0, '')
            self.get_bin_path = lambda binary, required=False: 'getent'


# Generated at 2022-06-20 21:54:35.078622
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:54:47.347554
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-20 21:54:59.684007
# Unit test for function main
def test_main():
    test_spec = {
        "argument_spec": {
            'database': dict(type='str', required=True),
            'key': dict(type='str', no_log=False),
            'service': dict(type='str'),
            'split': dict(type='str'),
            'fail_key': dict(type='bool', default=True),
        },
        'supports_check_mode': True,
    }

    module = get_module_mock(params={})
    module.get_bin_path = lambda x,y: '/sbin/getent'
    module.run_command = lambda x: (0, 'root:x:0:0:root:/root:/bin/bash')
    module.params = {'database': 'passwd'}
    main()
    assert module.exit_json.called

# Generated at 2022-06-20 21:55:07.853634
# Unit test for function main
def test_main():
    """
    Test module main

    :return:
    """
    # getent_shadow.py
    # DictTest = dict(
    #     module_name = 'hosts',
    #     database = 'hosts',
    #     key = 'test-key',
    #     split = 'tab',
    #     fail_key = True
    # )
    #
    # TestModule = getent_shadow.main(DictTest)

# Generated at 2022-06-20 21:55:18.167837
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'database':{'required':True, 'type':'str'},
                                         'key':{'no_log':False, 'type':'str'},
                                         'service':{'type':'str'},
                                         'split':{'type':'str'},
                                         'fail_key':{'default':True, 'type':'bool'},
                                        })


    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-20 21:55:27.165989
# Unit test for function main
def test_main():
    try:
        import __builtin__ as builtins  # pylint: disable=import-error
    except ImportError:
        import builtins  # pylint: disable=import-error
    builtins.open = fake_open

    argv = [
        'getent.py',
        '',
        '-a',
        'passwd=root',
    ]
    argv_bak = sys.argv
    sys.argv = argv
    try:
        main()
    except SystemExit:
        pass
    finally:
        sys.argv = argv_bak


# Generated at 2022-06-20 21:55:37.482651
# Unit test for function main
def test_main():
    def _prepare_mock_module(module_params, check_mode=False):
        module = AnsibleModule(
            argument_spec=module_params['argument_spec'],
            supports_check_mode=check_mode
        )
        module.exit_json = _module_exit_json
        module.fail_json = _module_fail_json
        return module

    def _module_exit_json(*args, **kwargs):
        global module_exit_json_result
        module_exit_json_result = dict(*args, **kwargs)

    def _module_fail_json(*args, **kwargs):
        global module_fail_json_result
        module_fail_json_result = dict(*args, **kwargs)


# Generated at 2022-06-20 21:55:44.391414
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rc = 0
    out = ":".join(["root","x","0","0","root","/root","/bin/bash"])
    err = ""

    class AnsibleFailJson:
        def __init__(self):
            self.results = {}
            self.msg = ""
            self.rc = 0


# Generated at 2022-06-20 21:55:52.708150
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    fake_response = 'foo:bar:baz:quux'
    results = {'getent_foo': {'bar': ['baz', 'quux']}}

    # Should split by line
    m = AnsibleModule(dict(database='foo', key='bar'))
    m._executable_paths = {'getent': '/bin/getent'}
    m.run_command = lambda x: (0, fake_response, '')
    main()
    assert m.exit_json.called
    assert m.exit_json.call_args[0][0] == dict(ansible_facts=results)

    # Should split by :

# Generated at 2022-06-20 21:56:07.566928
# Unit test for function main
def test_main():
    # Test case #1: single key (which exists)
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_module.exit_json = module_exit_json
    test_module.run_command = mock_run_command
    test_module.get_bin_path = module_get_bin_path
    test_module.params = dict(database='passwd')
    test_module.params['key'] = 'root'

# Generated at 2022-06-20 21:57:25.845967
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', default='passwd'),
            key=dict(type='str', default='root'),
            split=dict(type='str', default=':'),
            fail_key=dict(type='bool', default=True),
        ),
    )

    getent_bin = module.get_bin_path('getent', True)

    key = module.params['key']
    database = module.params['database']
    split = module.params['split']
    fail_key = module.params['fail_key']

    def run_command_mock(args, **kwargs):
        """Mock run_command to return fake output"""

# Generated at 2022-06-20 21:57:36.353056
# Unit test for function main
def test_main():
    import os
    import getent
    # Dummy host
    os.environ['HOSTNAME'] = 'localhost'

    test_module = getent.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True
         )
    ))

    test_module.params['database'] = 'passwd'
    test_module.params['key'] = 'root'
    test_module.main()
    assert 'getent_passwd' in test_module.ansible_facts
    assert len(test_module.ansible_facts['getent_passwd']) == 1
    assert test_module.ans

# Generated at 2022-06-20 21:57:47.997814
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    import sys
    import json

    results = {}
    results['changed'] = False
    results['ansible_facts'] = {}
    results['ansible_facts']['getent_group'] = {}
    results['ansible_facts']['getent_group']['root'] = ('root', 'x', '0', '')
    results['ansible_facts']['getent_group']['bin'] = ('bin', 'x', '1', '')
    results['ansible_facts']['getent_group']['daemon'] = ('daemon', 'x', '2', '')
    results['ansible_facts']['getent_group']['sys'] = ('sys', 'x', '3', '')

# Generated at 2022-06-20 21:57:55.507529
# Unit test for function main
def test_main():
    import shlex
    import datetime
    # This will fail on Windows, but is a unit test
    module = AnsibleModule(dict(database='group'), supports_check_mode=False)

    for database in ['passwd', 'group', 'hosts', 'services', 'protocols', 'rpc']:
        args = dict(database=database)

        getent_bin = module.get_bin_path('getent')
        if getent_bin:
            for key in ['root', 'wheel']:
                args['key'] = key
                rc, out, err = module.run_command([getent_bin, database, key])
                if rc == 0:
                    args['split'] = ':' if database in ['passwd', 'group', 'shadow', 'gshadow'] else None

# Generated at 2022-06-20 21:58:04.180037
# Unit test for function main
def test_main():
    # Don't run test if we don't have the requirements
    from importlib import util
    if not util.find_spec("mock"):
        return
    import mock
    mock_module = mock.MagicMock()
    mock_module.params = dict(
        database="passwd",
        service=None,
        split=None,
        fail_key=True
    )
    mock_module.get_bin_path.return_value = "getent"
    mock_module.run_command.return_value = 0, "", ""
    main()

# Generated at 2022-06-20 21:58:09.239751
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

# Generated at 2022-06-20 21:58:18.866971
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    class MockPopen:
        def __init__(self, rc, cmd, stdout, stderr, stdin=None):
            self.rc = rc
            self.cmd = cmd
            self.stdout = stdout
            self.stderr = stderr
            self.stdin = stdin
        def communicate(self, input=None):
            return (self.stdout, self.stderr)


# Generated at 2022-06-20 21:58:23.386028
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:58:32.549209
# Unit test for function main
def test_main():

    def test_argument_spec():
        args = dict(
            database='passwd',
            key='root',
            split=':'
        )
        supports_check_mode = True
        return AnsibleModule(argument_spec=args, supports_check_mode=supports_check_mode).argument_spec

    def test_run_command():
        rc = 0
        out = 'root:x:0:0:root:/root:/bin/bash'
        err = ''
        return rc, out, err

    def test_exit_json():
        results = dict(
            changed=False,
            ansible_facts=dict(
                getent_passwd=dict(
                    root='x:0:0:root:/root:/bin/bash'
                )
            )
        )
        return results


# Generated at 2022-06-20 21:58:34.889662
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        assert False, 'An unhandled exception occurred: {0}'.format(e)