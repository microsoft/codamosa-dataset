

# Generated at 2022-06-20 21:51:10.097886
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import types

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    facts = module.getent()
    assert type(facts) is types.DictType
    assert len(facts) > 0

# Generated at 2022-06-20 21:51:18.740626
# Unit test for function main
def test_main():
    args = dict(
        database='passwd',
        key='root',
    )
    out_results = dict(
        ansible_facts=dict(
            getent_passwd=dict(
                root = ['x', '0', '0', 'root', '', '/root', '/bin/bash'],
            ),
        ),
    )
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        service=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True)


# Generated at 2022-06-20 21:51:19.831229
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 21:51:30.795065
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module_args = dict(
        database='passwd',
        split=':',
        key='',
    )

    module = basic.AnsibleModule(argument_spec=None,
                                 supports_check_mode=True,
                                 **module_args)

    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, module_args['database']]
    rc, out, err = module.run_command(cmd)

    assert rc == 0

# Generated at 2022-06-20 21:51:38.258237
# Unit test for function main
def test_main():
    import ansible.module_utils.facts
    import ansible.module_utils.urls
    import ansible.module_utils.six

    facts_mod = ansible.module_utils.facts.get_module()
    facts_mod.run()
    print("Collecting getent facts")
    for d in ['passwd', 'group']:
        for k in ['root', 'sudo']:
            print("Collecting getent %s %s" % (d, k))
            main()


# Generated at 2022-06-20 21:51:49.277161
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ))

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.params['split'] = ':'

    rc, out, err = main()

    assert rc == 0
    assert err == []

# Generated at 2022-06-20 21:52:02.129108
# Unit test for function main
def test_main():
    class AnsibleExitJson(Exception):
        def __init__(self, value):
            self.value = value

    class AnsibleFailJson(Exception):
        def __init__(self, value):
            self.value = value

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    def set_module_args(**kwargs):
        pass

    def get_bin_path(arg, required=False):
        return '/bin/getent'


# Generated at 2022-06-20 21:52:10.580112
# Unit test for function main

# Generated at 2022-06-20 21:52:21.127906
# Unit test for function main
def test_main():
   data_in = {
      "ansible_module_args":{
         "database":"passwd",
         "key":None,
         "service":None,
         "split":"",
         "fail_key":True
      },
      "ansible_facts":{

      },
      "_ansible_check_mode":False
   }

   data_out = {
      "ansible_module_args":{
         "database":"passwd",
         "key":None,
         "service":None,
         "split":":",
         "fail_key":True
      },
      "ansible_facts":{

      },
      "_ansible_check_mode":False
   }

   assert main(data_in) == data_out


# Generated at 2022-06-20 21:52:29.427738
# Unit test for function main
def test_main():
    # Arrange
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Act
    main()

# Generated at 2022-06-20 21:52:51.944330
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class ModuleExit(Exception):
        pass

    try:
        result = main()
        raise Exception('main() does not raise module.fail_json nor module.exit_json')
    except ModuleExit:
        pass

    assert result == { 'ansible_facts': { 'getent_group': {'root': ['x', '0']} } }

    result = main(module=module, key='Service not found')
   

# Generated at 2022-06-20 21:53:04.542672
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-20 21:53:16.767549
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import ProcessCommon
    from ansible.module_utils.shell import ShellModule

    # Params in call to module_utils.shell.ShellModule:
    # (self, args=None, bin_filename=None, executable=None, runas=None,
    #  cwd=None, forward_agent=False, use_tty=None, prompt_regex=None,
    #  encoding=None, environ_update=None, no_log=False, shell_type='csh')


# Generated at 2022-06-20 21:53:28.929458
# Unit test for function main
def test_main():

    import os
    import platform
    import pytest
    import sys

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.params['database'] = 'group'
            self.params['key'] = 'admin'
            self.params['fail_key'] = True

        def fail_json(self, msg, **kwargs):
            raise AssertionError('AnsibleModule.fail_json: %s' % msg)

        def exit_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, app, required=False, opt_dirs=[]):
            return os.path.join('tests', 'support', 'bin', platform.system(), app)
            #return os.path.join(

# Generated at 2022-06-20 21:53:36.434676
# Unit test for function main
def test_main():
    # Test case for getent with all the required params.
    module_args = {
        "database": "passwd",
        "key": "root"
    }
    set_module_args(module_args)
    main()
    # Test case for getent with no key.
    module_args = {
        "database": "passwd"
    }
    set_module_args(module_args)
    main()
    # Test case for getent with service.
    module_args = {
        "database": "passwd",
        "key": "root",
        "service": "sshd"
    }
    set_module_args(module_args)
    main()
    # Test case for getent with split.

# Generated at 2022-06-20 21:53:47.230446
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    module = basic.AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x, y: '/usr/bin/getent'
    module.run_command = lambda x: (0, 'root:x:0:0:root:/root:/bin/bash\nbin:x:1:1:bin:/bin:/sbin/nologin', '')

    results = main()
    assert type(results) is dict

# Generated at 2022-06-20 21:53:48.813283
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:54:03.950657
# Unit test for function main
def test_main():
    '''
    Test function main()
    '''
    from ansible.module_utils import basic
    from ansible.module_utils.facts import AnsibleFactCollector

    # Setup
    m = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = m.params['database']
    key = m.params.get('key')
    split = m.params.get('split')


# Generated at 2022-06-20 21:54:18.804490
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = test_module.params['database']
    key = test_module.params.get('key')
    split = test_module.params.get('split')
    service = test_module.params.get('service')
    fail_key = test_module.params.get('fail_key')

    getent_bin = test_module

# Generated at 2022-06-20 21:54:24.710896
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        bypass_checks=True
    )
    # Get the function used by the main function
    get_bin_path = test_module.get_bin_path
    if sys.platform == 'win32':
        test_module.run_command = MagicMock(return_value=(0, u'', u''))
        get_bin_path.return_value = True
    else:
        test_module.run_command = Magic

# Generated at 2022-06-20 21:55:05.124567
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    import sys
    if sys.version_info[:2] == (2, 6):
        pytest.skip("Skip getent testing on Python 2.6")

    def getent_mock(self, *args, **kwargs):
        mock_result = basic.AnsibleModuleResult(dict(cmd='/usr/bin/getent', stdout=u'root:x:0:0:root:/root:/bin/bash',
                                                     stderr=u'', rc=0, changed=False))
        return mock_result


# Generated at 2022-06-20 21:55:13.175757
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True)))

    module.params = dict(database='passwd', key='root')
    main()

# Generated at 2022-06-20 21:55:24.714467
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'database': dict(type='str', required=True),
        'key': dict(type='str', no_log=False),
        'service': dict(type='str'),
        'split': dict(type='str'),
        'fail_key': dict(type='bool', default=True),
    }, supports_check_mode=True)
    module.run_command = _run_command
    module.exit_json = _exit_json
    module.fail_json = _fail_json
    rc = 0
    out = "root:x:0:0:root:/root:/bin/bash"
    err = ""

    try:
        main()
    except SystemExit as e:
        rc = e.code
        assert rc == 1

# Generated at 2022-06-20 21:55:35.748716
# Unit test for function main
def test_main():
    """Unit tests for function main"""
    
    # Import Python libs
    import tempfile
    import shutil
    import os
    from random import randint
    from subprocess import Popen, PIPE

    # Get test path
    fd, test_file = tempfile.mkstemp()
    os.close(fd)
    os.remove(test_file)

    # Create temporary directory
    test_dir = tempfile.mkdtemp()

    # Make sure to remove the directory after the test
    request.addfinalizer(lambda: shutil.rmtree(test_dir))

    # Generate file content
    content = '\n'.join(['%d:%d' % (randint(0, 9999), randint(0, 9999999)) for _ in range(100)])

    # Write content to

# Generated at 2022-06-20 21:55:47.225889
# Unit test for function main
def test_main():
    import sys
    import inspect
    import getent
    from ansible.module_utils import basic
    from ansible.module_utils import ansible_facts

    module_args = {'database': {'type': 'str', 'required': True}, 'key': {'type': 'str', 'no_log': False}, 'service': {'type': 'str'}, 'split': {'type': 'str'}, 'fail_key': {'type': 'bool', 'default': True}}
    argument_spec = {'database': {'type': 'str', 'required': True}, 'key': {'type': 'str', 'no_log': False}, 'service': {'type': 'str'}, 'split': {'type': 'str'}, 'fail_key': {'type': 'bool', 'default': True}}
    getent_bin

# Generated at 2022-06-20 21:55:57.113859
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class MockModule(object):
        def __init__(self, module):
            self.params = module.params
            self.exit_json = module.exit_json
            self.fail_json = module.fail_json

# Generated at 2022-06-20 21:56:07.857532
# Unit test for function main
def test_main():

    # Get the module arguments from the example section of the docstring
    example_args = inspect.getdoc(main)['examples'][0]['arguments']
    module_args = dict((k, v) for k, v in example_args.items() if k != 'module')

    module = AnsibleModule(argument_spec=module_args)

    # stub the module with fake results
    module.run_command = lambda x: (0, 'Present\tPresent', '')

    main()
    assert module.exit_json['ansible_facts']['getent_passwd'] == {'root': ['x','0','0','root','root','','/root','/bin/bash']}

# Generated at 2022-06-20 21:56:08.344546
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:56:21.450282
# Unit test for function main
def test_main():

    std_main_data = {
        'database': 'passwd',
        'key': 'root',
        'service': '',
        'split': None,
        'fail_key': True
    }
    std_main_out = '{"ansible_facts": {"getent_passwd": {"root": ["x", "0", "0", "root", "/root", "/bin/bash"]}}}'

    std_main_data = {
        'database': 'passwd',
        'key': 'not_found',
        'service': '',
        'split': None,
        'fail_key': True
    }
    std_main_out = '{"msg": "One or more supplied key could not be found in the database.", "failed": true}'

# Generated at 2022-06-20 21:56:27.435297
# Unit test for function main
def test_main():
    # just a place holder for now since action_plugins aren't easy to
    # unit test, maybe convert to a normal plugin.
    pass

# Generated at 2022-06-20 21:57:37.532052
# Unit test for function main
def test_main():
    # Module requires the formats module to be able to run
    # Should be able to add it's own
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    results = {'changed': False, 'rc': 0, 'stderr': '', 'stderr_lines': [],
               'stdout': '', 'stdout_lines': []}

    MOCK_RETURN = [None, "FAKE OUTPUT"]

# Generated at 2022-06-20 21:57:38.873822
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:57:48.746465
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-20 21:57:53.064300
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    assert main() is None

# Generated at 2022-06-20 21:58:02.947907
# Unit test for function main
def test_main():

    # Test module import error (no getent command)
    import os
    import shutil
    import sys

    try:
        shutil.rmtree('/tmp/ansible_test')
    except:
        pass

    os.makedirs('/tmp/ansible_test/ansible')
    os.makedirs('/tmp/ansible_test/ansible/module_utils')

    fp = open('/tmp/ansible_test/ansible/module_utils/basic.py', 'w')

# Generated at 2022-06-20 21:58:14.279064
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    import json

    # Define keys to delete from result
    keys_delete = ['changed', 'invocation', 'warnings']

    # Read module_utils/basic.py from the Ansible source
    exec(compile(open("/tmp/ansible_getent_utils").read(), "/tmp/ansible_getent_utils", 'exec'), locals(), globals())

    # Load the module

# Generated at 2022-06-20 21:58:20.808240
# Unit test for function main
def test_main():
    stub_result = {
        'ansible_facts': {
            'getent_aliases': {
                'postmaster': ['root']
            }
        }
    }
    ansible_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )
    ansible_module.run_command = MagicMock(return_value=(0, "", None))
    ansible_module.exit_json = MagicMock(return_value=stub_result)

    assert main() == stub

# Generated at 2022-06-20 21:58:25.569625
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    # Set key to nonexistent user to force return code 2
    module.params['database'] = 'passwd'
    module.params['key'] = 'nonexistentuser'
    rc, out, err = module.run_command([getent_bin, module.params['database'], module.params['key']], check_rc=True)

   

# Generated at 2022-06-20 21:58:31.222327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def getent_side_effect(args):
        if args[1] == 'hosts':
            return 0, 'host1\t10.10.10.1', ''
        elif args[1] == 'group':
            return 0, 'group1:x:1000:', ''
        elif args[1] == 'fail':
            return 2, '', ''

# Generated at 2022-06-20 21:58:40.323371
# Unit test for function main
def test_main():
    import os
    import shutil

    FNULL = open(os.devnull, 'w')
    getent_bin = shutil.which('getent')

    # Setup fake getent
    fake_bin = "/tmp/fake_getent_bin"

    # Setup test paths
    getent_path = getent_bin
    fake_path = fake_bin
    os.environ['PATH'] += os.pathsep + os.path.dirname(fake_path)
    os.environ['ANSIBLE_GETENT_PATH'] = getent_path

    # Copy real getent to the fake name
    shutil.copy(getent_bin, fake_path)

    def fake_getent(cmd, split):
        results = {}