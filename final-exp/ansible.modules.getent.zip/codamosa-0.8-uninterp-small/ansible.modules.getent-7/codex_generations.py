

# Generated at 2022-06-25 02:33:01.788127
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print('Unexpected error : exit with ' + str(inst))
    except Exception as err:
        print('Unexpected error : ' + str(err))
    else:
        pass
#
#
# unit test for test_case_0
#
#

# Generated at 2022-06-25 02:33:02.792833
# Unit test for function main
def test_main():
    assert var_0 == ''

# Generated at 2022-06-25 02:33:11.396762
# Unit test for function main
def test_main():
    try:
        assert (var_0 != None)
    except AssertionError as e:
        print("Test case #0 failed at line #43, %s" % e.args[0])
    try:
        assert True
    except AssertionError as e:
        print("Test case #1 failed at line #44, %s" % e.args[0])
    try:
        assert True
    except AssertionError as e:
        print("Test case #2 failed at line #45, %s" % e.args[0])
    try:
        assert True
    except AssertionError as e:
        print("Test case #3 failed at line #46, %s" % e.args[0])

# Generated at 2022-06-25 02:33:12.704977
# Unit test for function main
def test_main():
  assert (main() == None )
test_main()


# Generated at 2022-06-25 02:33:22.697744
# Unit test for function main
def test_main():
    try:
        var_1 = getent_bin
    except:
        var_1 = None
    assert var_1 == None
    try:
        var_2 = key
    except:
        var_2 = None
    assert var_2 == None
    try:
        var_3 = split
    except:
        var_3 = None
    assert var_3 == None
    try:
        var_4 = service
    except:
        var_4 = None
    assert var_4 == None
    try:
        var_5 = fail_key
    except:
        var_5 = None
    assert var_5 == None
    try:
        var_6 = cmd
    except:
        var_6 = None
    assert var_6 == None

# Generated at 2022-06-25 02:33:23.421771
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'main'

# Generated at 2022-06-25 02:33:24.884343
# Unit test for function main
def test_main():
    func_0 = main
    var_0 = test_case_0()


# Generated at 2022-06-25 02:33:25.935494
# Unit test for function main
def test_main():
    # Test case 0
    main_0 = main()
    assert main_0 is None


main()

# Generated at 2022-06-25 02:33:28.617035
# Unit test for function main
def test_main():
    # Unit test for function main
    assert not main()



# Generated at 2022-06-25 02:33:29.531522
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:33:43.628834
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert(False)


# Generated at 2022-06-25 02:33:44.501001
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:33:47.936877
# Unit test for function main
def test_main():

    #test_case_0
    var_0 = main()
    print("Function result", var_0)

    #test_case_1
    var_1 = main()
    print("Function result", var_1)

# Generated at 2022-06-25 02:33:48.767949
# Unit test for function main
def test_main():
    var_0 = main()


test_main()

# Generated at 2022-06-25 02:33:49.739726
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 02:33:50.586590
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:33:51.382667
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:33:52.765675
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as err:
        assert False, format(err)

# Generated at 2022-06-25 02:33:55.374081
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except Exception as e:
        print("test_case_0 failed: " + str(e))
        assert False


# Test case 0
test_main()
print ("Tests passed!")

# Generated at 2022-06-25 02:34:01.547912
# Unit test for function main
def test_main():
    # Create mock module and results
    mod = MockModulePath(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database_0 = 'passwd'
    key_0 = 'root'
    database_1 = 'group'
    database_2 = 'hosts'
    database_3 = 'services'
    database_4 = 'shadow'
    database_5 = 'gshadow'

    cmd_0 = ['/usr/bin/getent', database_1]

# Generated at 2022-06-25 02:34:28.315023
# Unit test for function main
def test_main():
    var_0 = test_case_0()
    return var_0

# Generated at 2022-06-25 02:34:29.446475
# Unit test for function main
def test_main():
    assert main()

# vim: ansible-syntax-auto-gen:1

# Generated at 2022-06-25 02:34:30.628338
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None  # not supported by getent

# Generated at 2022-06-25 02:34:31.152484
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:34:32.588783
# Unit test for function main
def test_main():
    var_0 = {'getent_database': {'key': [0]}}
    if var_0 != main():
        raise Error('Test Case Failed.')


# Generated at 2022-06-25 02:34:35.176924
# Unit test for function main
def test_main():
    assert callable(main)
    assert isinstance(main(), dict)
    assert main()['rc'] == 0




# Generated at 2022-06-25 02:34:36.984401
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except Exception as e:
        print("Unable to test main due to exception:", e)


# Generated at 2022-06-25 02:34:38.912831
# Unit test for function main
def test_main():
    out, err = capsys.readouterr()
    assert out == "True\n"

# Generated at 2022-06-25 02:34:41.747764
# Unit test for function main
def test_main():

    # Arrange
    database = 'passwd'
    key = 'root'
    split = ':'

    # Act
    var_2 = main(database, key, split)

    # Assert
    assert var_2 == 'getent_passwd'

# Generated at 2022-06-25 02:34:45.025696
# Unit test for function main
def test_main():
    # Setup test environment
    #Test clean-up
    try:
        print('\nTesting function main')
        test_case_0()
    except Exception:
        var = 42
        assert var == 42
        return
    else:
        var = 42
        assert var == 42
        return



# Generated at 2022-06-25 02:35:52.405529
# Unit test for function main
def test_main():
    args = {"database": "passwd", "key": "root"}
    # Changing the global variable __tracebackhide__.
    __tracebackhide__ = True
    with pytest.raises(SystemExit):
        main(args)
    args = {"database": "group", "split": ":"}
    # Changing the global variable __tracebackhide__.
    __tracebackhide__ = True
    with pytest.raises(SystemExit):
        main(args)
    args = {"database": "hosts"}
    # Changing the global variable __tracebackhide__.
    __tracebackhide__ = True
    with pytest.raises(SystemExit):
        main(args)
    args = {"database": "services", "key": "http", "fail_key": "False"}
    # Changing the global variable __tracebackhide__

# Generated at 2022-06-25 02:35:53.519415
# Unit test for function main
def test_main():
    # Call function main
    function_name = main()
    assert function_name is not None


# Generated at 2022-06-25 02:35:55.438425
# Unit test for function main
def test_main():
    # Ensure the output is a dictionary.
    assert type(main()) is dict
    # Ensure the output dictionary has the proper keys.
    assert "ansible_facts" in main().keys()


# Generated at 2022-06-25 02:35:55.890515
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:35:57.723245
# Unit test for function main
def test_main():
    print("[*] Starting test for function main")

    for i in range(1):
        test_case_0()

    print("[*] Completed test for function main")

# Generated at 2022-06-25 02:35:58.466860
# Unit test for function main
def test_main():
    assert main()

# Test Case 0

# Generated at 2022-06-25 02:36:03.849644
# Unit test for function main
def test_main():
    # Popen
    import subprocess

    popen_param_1 = ['getent']
    popen_param_2 = 'r'
    popen_param_3 = 0
    popen_param_4 = None
    popen_param_5 = 'getent_passwd'
    popen_param_6 = ':'

    # Call to open(...): implicit coercion from 'list' to 'bytes' is not supported in 3.8
    # Need to explicitly encode the bytes()
    with open(b'getent') as f: # noqa: F841
        pass
    # Popen instance passed as parameter 1

    # Popen instance passed as parameter 1
    # Call to subprocess.Popen(...): implicit coercion from 'list' to 'bytes' is not supported in 3.8
    # Need to explicitly encode the bytes

# Generated at 2022-06-25 02:36:04.689742
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == 0

# Generated at 2022-06-25 02:36:13.747037
# Unit test for function main
def test_main():
    assert var_0 == None
    assert var_1 == None
    assert var_2 == None
    assert var_3 == None
    assert var_4 == None
    assert var_5 == None
    assert var_6 == None
    assert var_7 == None
    assert var_8 == None
    assert var_9 == None
    assert var_10 == None
    assert var_11 == None
    assert var_12 == None
    assert var_13 == None
    assert var_14 == None
    assert var_15 == None
    assert var_16 == None
    assert var_17 == None
    assert var_18 == None
    assert var_19 == None
    assert var_20 == None
    assert var_21 == None
    assert var_22 == None
    assert var_23 == None
    assert var_24 == None

# Generated at 2022-06-25 02:36:15.277169
# Unit test for function main
def test_main():
    assert callable(main)
    expected_0 = main()
    assert expected_0 == var_0

# Generated at 2022-06-25 02:38:27.511894
# Unit test for function main
def test_main():
    var_0 = AnsibleModule()
    var_1 = var_0.get_bin_path('getent',True)

    var_2 = var_0.params['database']
    var_3 = var_0.params.get('key')
    var_4 = var_0.params.get('split')
    var_5 = var_0.params.get('service')
    var_6 = var_0.params.get('fail_key')

    var_7 = ['passwd','shadow','group','gshadow']


# Generated at 2022-06-25 02:38:35.380118
# Unit test for function main
def test_main():
    class ModuleStub:
        def __init__(self, params={}):
            self.params = params

        def get_bin_path(self, path, required=False, opt_dirs=()):
            return "C:\Python27\Scripts\getent"

        def run_command(self, command):
            return 0, "", ""

        def fail_json(self, msg, exception=None):
            raise Exception(msg)

    class AnsibleModuleStub:
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

        def fail_json(self, **kwargs):
            raise Exception("An unexpected result has been returned.")


# Generated at 2022-06-25 02:38:43.696586
# Unit test for function main

# Generated at 2022-06-25 02:38:44.881054
# Unit test for function main
def test_main():
    var_0 = main()
    # var_0 = None
    assert var_0 == None

# Generated at 2022-06-25 02:38:45.529694
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:38:46.436711
# Unit test for function main
def test_main():
  try:
    assert True
  except:
    print("1")
    raise

# Generated at 2022-06-25 02:38:47.018819
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:38:48.083488
# Unit test for function main
def test_main():
    test_case_0()

# End of test_main

# Generated at 2022-06-25 02:38:48.730428
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:38:49.181303
# Unit test for function main
def test_main():
    pass