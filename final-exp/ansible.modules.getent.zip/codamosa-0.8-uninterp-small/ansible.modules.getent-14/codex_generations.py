

# Generated at 2022-06-25 02:33:08.771960
# Unit test for function main
def test_main():
    mock_module_0 = MagicMock()
    mock_module_0.params = {'split': None, 'key': 'tcp', 'database': 'services', 'fail_key': True}
    mock_run_command = MagicMock(return_value=(0, 'tcp        6       stream\n', ''))
    mock_get_bin_path = MagicMock(return_value='/usr/bin/getent')
    with patch.multiple(builtins, run_command=mock_run_command, get_bin_path=mock_get_bin_path):
        res = main()
        assert res['ansible_facts']['getent_services'] == {'tcp': ['6', 'stream']}


# Generated at 2022-06-25 02:33:09.647252
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:33:10.537473
# Unit test for function main
def test_main():
    assert main() == True


# Generated at 2022-06-25 02:33:12.096280
# Unit test for function main
def test_main():
    var_1 = test_case_0()

    assert var_1 == None

# Generated at 2022-06-25 02:33:22.155131
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec={
            'service': {
                'type': 'str'
            },
            'split': {
                'type': 'str'
            },
            'key': {
                'type': 'str',
                'no_log': False
            },
            'database': {
                'type': 'str',
                'required': True
            },
            'fail_key': {
                'type': 'bool',
                'default': True
            }
        },
        supports_check_mode=True
    )
    var_2 = var_1.get_bin_path('getent', True)
    var_3 = None
    var_4 = None
    var_5 = 'getent_%s' % var_3
    var_6 = {}
    var

# Generated at 2022-06-25 02:33:23.037386
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error while executing function main")

# Generated at 2022-06-25 02:33:23.729008
# Unit test for function main
def test_main():
    # noinspection PyUnusedLocal
    var_0 = main()

# Generated at 2022-06-25 02:33:24.271103
# Unit test for function main
def test_main():
    assert main() == 'Argumentos incorrectos.'

# Generated at 2022-06-25 02:33:24.861080
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:33:25.486379
# Unit test for function main
def test_main():
    print("test_main")
    assert True



# Generated at 2022-06-25 02:33:59.127834
# Unit test for function main
def test_main():
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    pass
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
    # Assigning to dict variable results[dbtree][key]
   

# Generated at 2022-06-25 02:34:00.744518
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:34:05.284776
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print('main EXIT[%s]' % (inst.args[0]))
        pass
    except Exception as inst:
        print('EXCEPT %s' % (inst))


# Generated at 2022-06-25 02:34:13.940991
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    getent_bin = module.get_bin_path('getent', True)

    database = "passwd"
    key = "root"
    database = database
    key = key

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-25 02:34:24.524005
# Unit test for function main
def test_main():
    ansible_module_getent = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = ''
    split = None
    service = None
    fail_key = True

    getent_bin = 'getent'

    if key is not None:
        cmd = 'getent passwd key'
    else:
        cmd = 'getent passwd'


# Generated at 2022-06-25 02:34:25.356457
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 02:34:26.213162
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:34:30.322897
# Unit test for function main
def test_main():
    output = main()
    assert "getent_passwd" in globals().keys()
    assert "values" in globals().keys()
    assert "getent_group" in globals().keys()
    assert "split" in globals().keys()
    assert "results" in globals().keys()
    assert "value" in globals().keys()


# Generated at 2022-06-25 02:34:31.146092
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:34:32.250095
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-25 02:35:02.898449
# Unit test for function main
def test_main():
    import sys
    import os
    # Save the current base path and make a temp one
    saved_path = os.getcwd()
    os.chdir('./')
    try:
        assert test_case_0()
    finally:
        # Restore path
        os.chdir(saved_path)

# Generated at 2022-06-25 02:35:03.803864
# Unit test for function main
def test_main():
    m_0 = main()

# Generated at 2022-06-25 02:35:05.011783
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == 0

# Generated at 2022-06-25 02:35:09.526758
# Unit test for function main

# Generated at 2022-06-25 02:35:18.392006
# Unit test for function main
def test_main():
    assert_equals(main(), None)

# def test_case_1():
#     var_1 = {'database': 'passwd', 'split': ':', 'key': 'root'}
#     var_2 = {'database': 'passwd', 'key': 'root'}
#     var_3 = (0, 'The database contains the following database record(s)', '')
#     var_4 = var_3[0]
#     var_5 = var_3[1]
#     var_6 = var_3[2]
#     var_7 = 'getent_passwd'
#     var_8 = {var_7: {'root': ['0', '0', 'root', 'root', '/root', '/bin/bash']}}
#     assert_equals(main(var_1,var

# Generated at 2022-06-25 02:35:21.429848
# Unit test for function main
def test_main():
     try:
         main()
     except SystemExit as e:
         if e.code == 0:
             return True
         else:
             return False


from ansible.module_utils.basic import AnsibleModule

from ansible.module_utils._text import to_native

from ansible.module_utils.action import ActionBase


# Generated at 2022-06-25 02:35:24.828074
# Unit test for function main
def test_main():
    # default values
    assert main() == 'main'
    # Pre-defined argument values
    # class 'dict'
    nested_args = {'database': 'database', 'key': 'key', 'service': 'service', 'split': 'split', 'fail_key': 'fail_key'}
    assert main(nested_args=nested_args) == 'main'



# Generated at 2022-06-25 02:35:25.264644
# Unit test for function main
def test_main():

    pass # Nothing to test

# Generated at 2022-06-25 02:35:27.087100
# Unit test for function main
def test_main():
    out, err = capsys.readouterr()
    assert  (1, 'foo') == main(1, 'foo')

# Generated at 2022-06-25 02:35:28.144817
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)

# Generated at 2022-06-25 02:36:37.087289
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:36:45.685931
# Unit test for function main
def test_main():

    # Mock the arguments
    args = {'database': 'hosts',
            'key': 'www.example.com',
            'split': ':',
            'service': '',
            'fail_key': True}
    with patch.object(builtins, '__build_class__') as mock_builtins___build_class__:
        with patch.object(tempfile, 'SpooledTemporaryFile') as mock_SpooledTemporaryFile:
            with patch.object(module_utils.basic, 'AnsibleModule') as mock_AnsibleModule:
                with mock.patch.object(module_utils.basic, 'get_bin_path',return_value='getent'):
                    mock_AnsibleModule_instance = mock.Mock()
                    mock_AnsibleModule.return_value = mock_Ans

# Generated at 2022-06-25 02:36:48.343083
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0
    assert main() == 0

# Generated at 2022-06-25 02:36:49.698488
# Unit test for function main
def test_main():
    from unittest import mock

    # Calls to main()
    var_0 = main()

# Generated at 2022-06-25 02:36:51.717521
# Unit test for function main
def test_main():
    var = "Hello World!"
    assert var == "Hello World!"


# Generated at 2022-06-25 02:36:54.864108
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule.run_command', return_value=(0, '', '')):
        assert main() is None

# Generated at 2022-06-25 02:36:56.462393
# Unit test for function main
def test_main():
    try:
        assert (main())
    except NameError as error:
        print(error)



# Generated at 2022-06-25 02:37:02.892765
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )
    var_2 = var_1.params['database']
    var_3 = var_1.params.get('key')
    var_4 = var_1.params.get('split')
    var_5 = var_1.params.get('service')
    var_6 = var_1.params.get('fail_key')
    var_7 = var_1.get_bin_path('getent', True)

# Generated at 2022-06-25 02:37:04.878212
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Error while processing')
        raise

# Generated at 2022-06-25 02:37:10.183160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    var_0 = module.params['database']
    var_1 = module.params.get('key')
    var_2 = module.params.get('split')
    var_3 = module.params.get('service')
    var_4 = module.params.get('fail_key')
    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-25 02:39:36.646581
# Unit test for function main
def test_main():
    var_0 = main()


tuple(main())



# Generated at 2022-06-25 02:39:37.757476
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-25 02:39:39.350936
# Unit test for function main
def test_main():
    try:
        main()
    except NameError as e:

        print(e)


# Generated at 2022-06-25 02:39:40.114657
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:39:41.518627
# Unit test for function main
def test_main():
    print("Testing main()")
    assert test_case_0() == None

# Function to test main method

# Generated at 2022-06-25 02:39:47.119841
# Unit test for function main
def test_main():
    var_0 = AnsibleModule()
    var_1 = {"database": "passwd", "key": "root"}
    var_0.params = var_1
    var_2 = var_0.get_bin_path('getent', True)
    assert var_2 != "", "var_2"
    var_1 = {"database": "group", "key": "", "split": ":"}
    var_0.params = var_1
    var_3 = var_0.get_bin_path('getent', True)
    assert var_3 != "", "var_3"
    var_1 = {"database": "hosts", "key": ""}
    var_0.params = var_1
    var_4 = var_0.get_bin_path('getent', True)
    assert var_4

# Generated at 2022-06-25 02:39:50.823320
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print("\nUnit test for function main")
        print("Uncaught exception: " + str(e))
        print("\nTraceback: ")
        print(traceback.format_exc())
        print("\n")
        assert False


# Generated at 2022-06-25 02:40:00.216699
# Unit test for function main
def test_main():
    pass
    # class NestedException(Exception):
    #     def __init__(self, *args, **kwargs):
    #         Exception.__init__(self, *args, **kwargs)
    #
    # # Set up function parameters and expected results
    # rc = 1
    # out = ''
    # err = 'Expected error'
    # exception = NestedException('Test exception')
    # msg = 'Unexpected failure!'
    # database = 'passwd'
    # dbtree = 'getent_%s' % database
    # key = ''
    # split = None
    # service = None
    # fail_key = True
    # results = {dbtree:{}}
    #
    # # Invoke method
    # try:
    #     rc, out, err = main()
    # except

# Generated at 2022-06-25 02:40:00.655149
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:40:01.358488
# Unit test for function main
def test_main():
    assert(not var_0)