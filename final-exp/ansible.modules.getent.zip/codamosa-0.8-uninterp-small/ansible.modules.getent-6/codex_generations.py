

# Generated at 2022-06-25 02:33:08.531581
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str', no_log=False),
            service = dict(type='str'),
            split = dict(type='str'),
            fail_key = dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-25 02:33:09.068076
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:33:12.323977
# Unit test for function main
def test_main():
    result = main()
    assert result == {'getent_passwd': {'root': ['x', 0, 0, 'root', '/root', 
    '/bin/bash'], 'brian': ['x', 1000, 1000, 'Brian Coca', 
    '/home/brian', '/bin/bash']}}


# Generated at 2022-06-25 02:33:13.833780
# Unit test for function main
def test_main():
    function_name = 'main'

    main()

# Generated at 2022-06-25 02:33:14.419818
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:33:16.328508
# Unit test for function main
def test_main():
    var_1 = None
    var_0 = main()
    assert var_0 == var_1

# Generated at 2022-06-25 02:33:17.533381
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == (0, 'Success')

# Generated at 2022-06-25 02:33:18.831220
# Unit test for function main
def test_main():
    var_1 = main()
    assert isinstance(var_1, dict) == True
    assert var_1[key_0] == ansible_facts

# Generated at 2022-06-25 02:33:27.002030
# Unit test for function main
def test_main():
    var_0 = {}
    var_0['argument_spec'] = {"service": {"type": "str"}, "database": {"required": True, "type": "str"}, "key": {"no_log": False, "type": "str"}, "split": {"type": "str"}, "fail_key": {"default": True, "type": "bool"}}
    var_0['check_mode'] = True
    var_0['get_bin_path'] = lambda x: {}
    var_0['module'] = var_0
    var_0['params'] = {"service": None, "database": "passwd", "key": None, "split": ":", "fail_key": True}
    var_0['run_command'] = lambda x: (0, "", "")
    var_0['set_fact'] = lambda x: {}


# Generated at 2022-06-25 02:33:27.991217
# Unit test for function main
def test_main():
    try:
        var_0 = main()
        assert var_0
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-25 02:34:03.075432
# Unit test for function main
def test_main():
    """Function main"""
    try:
        with mock.patch('ansible_collections.bcoca.ansible_facts.plugins.getent.AnsibleModule') as _mock_module:
            _mock_module.get_bin_path = MagicMock()
            _mock_module.run_command = MagicMock()
            main()
    except Exception as e:
        assert False, 'Exception raised: {}'.format(e)

    # Test Cases
    _ansible_module = _mock_module.return_value
    assert _ansible_module.params['database'] == main.database
    assert _ansible_module.params['key'] == main.key
    assert _ansible_module.params['service'] == main.service
    assert _ansible_module.params['split'] == main.split
   

# Generated at 2022-06-25 02:34:04.944585
# Unit test for function main
def test_main():
    # run unit tests
    TestCase = test_case0()
    TestCase.test_main()

# Generated at 2022-06-25 02:34:11.799609
# Unit test for function main
def test_main():
    module_0 = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Store the result of function 'main' in a local variable 'var_1'.
    var_1 = main()
    return



# Generated at 2022-06-25 02:34:12.771332
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == 0


# Generated at 2022-06-25 02:34:14.234086
# Unit test for function main
def test_main():
    # tested function call
    test_case_0()


# Generated at 2022-06-25 02:34:15.423794
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:34:18.240936
# Unit test for function main
def test_main():
    var_0 = None

    try:
        var_0 = main()
    except :
        print('Exception occurred when executing main(): ' + str(sys.exc_info()[0]))

    assert var_0 == None

test_main()

# Generated at 2022-06-25 02:34:18.856291
# Unit test for function main
def test_main():
    assert not main()

# Generated at 2022-06-25 02:34:20.423756
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:34:22.313877
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == 'getent_passwd', 'Function return does not match the expected!'


# Generated at 2022-06-25 02:34:49.733962
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:34:50.794733
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:34:53.285758
# Unit test for function main
def test_main():
    var_0 = main()
    # Expecting ["/usr/bin/getent"] as input for get_bin_path
    assert 1 == 1

# Generated at 2022-06-25 02:34:57.455149
# Unit test for function main
def test_main():
    db_0 = 'passwd'
    key_0 = 'root'
    split_0 = ':'

    assert(var_0.get('ansible_facts').get('getent_passwd').get('root') == [u'x', u'0', u'0', u'root', u'/root', u'/bin/bash'])

# Generated at 2022-06-25 02:34:59.676193
# Unit test for function main
def test_main():
    args = {
    }
    results = main(args)
    return results

# Generated at 2022-06-25 02:35:00.929313
# Unit test for function main
def test_main():
    assert 1


# Generated at 2022-06-25 02:35:01.801616
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 02:35:04.388156
# Unit test for function main
def test_main():
    assert var_0 == True

# print(getent_bin)
# print(cmd)
# print(out)
# print(err)
# print(rc)
# print(dbtree)
# print(results)

# Generated at 2022-06-25 02:35:05.848267
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None



# Generated at 2022-06-25 02:35:07.590095
# Unit test for function main
def test_main():
    # no argument
    with pytest.raises(TypeError):
        main()


# Generated at 2022-06-25 02:36:27.576059
# Unit test for function main
def test_main():
    with patch('getent.AnsibleModule') as mock_AnsibleModule:
         with patch('getent.module.run_command') as mock_run_command:
             mock_AnsibleModule_instance = Mock()
             mock_AnsibleModule.return_value = mock_AnsibleModule_instance
             type(mock_AnsibleModule_instance).params = PropertyMock(return_value={'database': 'passwd'})

             getent_main()


# Generated at 2022-06-25 02:36:28.378683
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:36:28.925057
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:36:32.783180
# Unit test for function main
def test_main():
    # Arguments used for testing
    database = 'passwd'
    key = 'root'
    split = ':'
    service = None
    fail_key = True

    # Function block's expected output
    expected_output = False

    # Call function and verify returns
    #assert main(database, key, split, service, fail_key) == expected_output


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:36:43.087194
# Unit test for function main
def test_main():
    args = {}
    args['database'] = unittest.mock.Mock()
    args['key'] = unittest.mock.Mock()
    args['split'] = unittest.mock.Mock()
    args['service'] = unittest.mock.Mock()
    args['fail_key'] = unittest.mock.Mock()
    res = main(**args)

    with open("test/test_main_input.json") as json_file:
        test_input = json.load(json_file)
        for case_input in test_input["test"]:
            args = {}
            for x in case_input:
                args[x] = case_input[x]