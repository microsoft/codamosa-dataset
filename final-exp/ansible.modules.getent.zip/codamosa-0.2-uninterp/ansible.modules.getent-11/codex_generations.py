

# Generated at 2022-06-17 04:34:09.998916
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock module.run_command
    def run_command(cmd):
        return 0, '', ''

    module.run_command = run_command

    # Mock module.get_bin_path
    def get_bin_path(name, required):
        return 'getent'

    module.get_bin_path = get_bin_path

    # Mock module.exit_json

# Generated at 2022-06-17 04:34:19.976694
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:30.642706
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:41.302602
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:46.615119
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:58.388529
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # Mock module args
    args = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )

    # Mock module input parameters
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-17 04:35:09.358863
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:11.315566
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    assert module.fail_json.called


# Generated at 2022-06-17 04:35:22.075026
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import json

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    module_name = os.path.join(tmpdir, 'ansible_module_getent.py')
    with open(module_name, 'wb') as f:
        f.write(to_bytes(basic.__file__.replace('/__init__.py', '/basic.py')))
        f.write(to_bytes(__file__))

    # Create a temporary shell script that emulates getent
    getent_name = os.path.join(tmpdir, 'getent')

# Generated at 2022-06-17 04:35:32.743210
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")
    with open(cfgfile, 'wb') as f:
        f.write(to_bytes("[defaults]\nroles_path = %s" % os.path.join(tmpdir, 'roles')))

    # Create a temporary roles directory
    os.mkdir(os.path.join(tmpdir, 'roles'))

    # Create a temporary inventory

# Generated at 2022-06-17 04:36:10.005377
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_iterable

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # import test snippets
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass


# Generated at 2022-06-17 04:36:21.009057
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_iterable

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module.run_command

# Generated at 2022-06-17 04:36:31.888365
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:42.785352
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:48.422781
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike
    from ansible.module_utils.common.collections import is_setlike
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_string
    from ansible.module_utils.common.collections import is_binary
    from ansible.module_utils.common.collections import is_text

# Generated at 2022-06-17 04:36:57.564348
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:09.148934
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path2 = tempfile.mkstemp()
    os.close(fd)

    # This sets the module args
    args = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )

    # Create a dummy module
    module = Ans

# Generated at 2022-06-17 04:37:19.195448
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['getent'])
    assert rc == 1
    assert out == ''
    assert err == 'Usage: getent [OPTION]... DATABASE [KEY]...\n'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    rc, out, err = module.run_command(['getent', 'invalid'])
    assert rc == 1
    assert out == ''
    assert err == 'getent: invalid: database unknown\n'

    # Test with valid database
    module = AnsibleModule(argument_spec={'database': 'passwd'})

# Generated at 2022-06-17 04:37:25.856247
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import json
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.system.getent import main

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a group file
    group_file = os.path.join(tmpdir, 'group')

# Generated at 2022-06-17 04:37:33.605941
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:13.030661
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import json

    # Save the original sys.argv
    orig_argv = sys.argv

    # Make a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpsrc = tempfile.mkstemp(dir=tmpdir)

    # Write something to the temporary file
    os.write(fd, b"#!/usr/bin/python\n")
    os.close(fd)

    # Change to the temporary directory
    oldcwd = os.getcwd()
    os.chdir(tmpdir)

    # Make the temporary file executable
    os.chmod(tmpsrc, 0o755)

    # Create a temporary module
    fd, tmpdest = tempfile.mk

# Generated at 2022-06-17 04:38:24.159904
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:35.750279
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Test with arguments

# Generated at 2022-06-17 04:38:44.289725
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest

    # Make sure we don't try to use the system getent
    os.environ['PATH'] = ''

    # Create a fake getent

# Generated at 2022-06-17 04:38:54.506078
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
   

# Generated at 2022-06-17 04:39:05.020636
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['getent'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    rc, out, err = module.run_command(['getent', 'invalid'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid key
    module = AnsibleModule(argument_spec={'database': 'passwd', 'key': 'invalid'})

# Generated at 2022-06-17 04:39:18.697595
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iterable

    # import module
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from library.getent import main as getent_main

    # import test data
    from . import test_data

    # define test data
    test_data = test_data.test_data

    # define test function
    def test_getent(test_data):
        # create mock module
        module = Ansible

# Generated at 2022-06-17 04:39:30.714460
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary environment
    tmpenv = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Write environment file
    tmpenv.write(b'{"ANSIBLE_GETENT_BIN": "/usr/bin/getent"}')
    tmpenv.flush()

    # Write configuration file
    tmpfile.write(b'{"database": "passwd", "key": "root"}')
    tmpfile.flush()

    # Run module

# Generated at 2022-06-17 04:39:39.826573
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    os.chmod(path, 0o600)

    # Create a temporary module
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    os.chmod(path, 0o600)

    # Create a temporary module
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

# Generated at 2022-06-17 04:39:47.609671
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    import os
    import sys

    if not os.path.exists('/usr/bin/getent'):
        print('Skipping as getent is not installed')
        sys.exit(0)

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 04:40:59.022756
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    assert module.fail_json.called
    assert 'Missing required arguments' in module.fail_json.call_args[0]['msg']

    # Test with required arguments
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ))
    assert module.fail_json.called
    assert 'Missing required arguments' in module.fail_json.call_args[0]['msg']

    # Test with all arguments

# Generated at 2022-06-17 04:41:06.685208
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module file
    module_file = os.path.join(tmpdir, 'test_module.py')

# Generated at 2022-06-17 04:41:21.273630
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:32.205163
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:40.437628
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Mock module args
    sys.argv = [sys.argv[0]]
    current_dir = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-17 04:41:50.502977
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:00.523571
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-17 04:42:08.714119
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    # import module snippets
    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import ansible_facts

    # prep required data

# Generated at 2022-06-17 04:42:20.675292
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import tempfile
    import shutil
    import subprocess
    import json

    # This is a hack to make sure that the test can find the getent module
    # even if it is not installed in the system.
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # This is a hack to make sure that the test can find the getent module
    # even if it is not installed in the system.
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))


# Generated at 2022-06-17 04:42:28.765697
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment
    fake_env = os.path.join(tmpdir, 'fake_env.sh')
    with open(fake_env, 'a') as env_fd:
        env_fd.write("#!/bin/sh\n")
        env_fd.write("echo fake_env_var=fake_env_value\n")
        env_fd.write("exit 0\n")
    os.chmod(fake_env, 0o755)

    # Create a temporary python module
    fake_module = os.path.join(tmpdir, 'fake_utils.py')