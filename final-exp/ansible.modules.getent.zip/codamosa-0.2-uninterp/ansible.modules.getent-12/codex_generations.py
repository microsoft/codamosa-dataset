

# Generated at 2022-06-17 04:34:09.675598
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:19.709617
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:29.878945
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import tempfile
    import shutil
    import json
    import subprocess
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()

    # Create a temporary environment
    old_env = os.environ.copy()
    os.environ['ANSIBLE_MODULE_UTILS'] = tmpdir

    # Create a temporary module

# Generated at 2022-06-17 04:34:40.566712
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 04:34:49.479862
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a fake getent
    getent_path = os.path.join(tmpdir, 'getent')
    with open(getent_path, 'w') as f:
        f.write("""#!/bin/sh
echo "$@"
""")
    os.chmod(getent_path, 0o755)

    # create a fake ansible module
    module_path = os.path.join(tmpdir, 'ansible_module.py')

# Generated at 2022-06-17 04:34:59.826558
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import pytest
    import json
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path2 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path3 = tempfile.mkstemp()
    os.close(fd)

    # This is the expected return value for the ansible_facts

# Generated at 2022-06-17 04:35:06.043240
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:20.688928
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    fd, temp_file = tempfile.mkstemp(dir=tmpdir)

    # Write data to the temporary file
    os.write(fd, b"data")

    # Close the file descriptor
    os.close(fd)

    # Open the file using the path
    with open(temp_file, "r") as f:
        # Read the data from the file
        data = f.read()

    # Assert that the data is equal to the string "data"
    assert data == "data"

    # Create a temporary directory
    tmpdir = tempfile.mk

# Generated at 2022-06-17 04:35:32.172204
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:39.930588
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-17 04:36:09.509274
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module.run_command

# Generated at 2022-06-17 04:36:20.330609
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment
    old_path = os.environ['PATH']
    os.environ['PATH'] = tmpdir
    os.environ['ANSIBLE_MODULE_ARGS'] = json.dumps({
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': True,
    })

    # Create a temporary module

# Generated at 2022-06-17 04:36:31.390299
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:42.301617
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file2 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file3 = tempfile.mkstemp()
    os.close(fd)

    # Write data to a temporary file
    with open(temp_file, 'w') as f:
        f.write('foo:x:1000:1000::/home/foo:/bin/bash\n')

# Generated at 2022-06-17 04:36:48.131434
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_text
    from ansible.module_utils.common.text.formatters import to_nice_text_list
    from ansible.module_utils.common.text.formatters import to_nice_text_list_from_dict

# Generated at 2022-06-17 04:36:57.303414
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:09.115750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:19.908120
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if not PY3:
        from ansible.module_utils.six import iteritems
        from ansible.module_utils.six.moves import cStringIO as StringIO
    else:
        from ansible.module_utils.six.moves import cStringIO as StringIO
        from ansible.module_utils.six.moves import zip as iteritems

    # Ansible 2.8 imports
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unitt

# Generated at 2022-06-17 04:37:31.749561
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    class AnsibleModuleMock(object):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.params = kwargs

        def run_command(self, cmd):
            return 0, '', ''

        def get_bin_path(self, name, required):
            return get_bin_path(name)

    class AnsibleModuleTest(AnsibleModuleMock):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.params = kwargs
            self.exit_args = {}


# Generated at 2022-06-17 04:37:42.597834
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module.run_command

# Generated at 2022-06-17 04:38:23.436944
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.exit_json = lambda x: x
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'Missing required arguments: database'

    # Test with missing database

# Generated at 2022-06-17 04:38:35.238140
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import os
    import sys
    import pytest

    # Mock the module input parameters
    sys.argv = ['getent', 'group', 'root']
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module exit_json function
    def exit_json(*args, **kwargs):
        return True

    module.exit_json

# Generated at 2022-06-17 04:38:47.571505
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['getent'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    rc, out, err = module.run_command(['getent', 'invalid'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid key
    module = AnsibleModule(argument_spec={'database': 'passwd', 'key': 'invalid'})

# Generated at 2022-06-17 04:38:57.589076
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import tempfile
    import shutil
    import subprocess
    import json
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # set up temp dir
    tmpdir = tempfile.mkdtemp()
    # set up temp files
    (fd, test_file) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    (fd, test_file2) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    (fd, test_file3) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    (fd, test_file4) = tempfile.mkstemp(dir=tmpdir)


# Generated at 2022-06-17 04:39:06.930141
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Write to the temporary file
    with open(tmpfile, 'w') as f:
        f.write('foo')

    # Create a temporary environment
    old_env = os.environ.copy()
    os.environ['ANSIBLE_GETENT_TEST_DIR'] = tmpdir
    os.environ['ANSIBLE_GETENT_TEST_FILE'] = tmpfile

    # Test the module

# Generated at 2022-06-17 04:39:14.867539
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:20.915805
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:32.046266
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest

    # Save the original sys.argv
    orig_sys_argv = list(sys.argv)

    # Setup the command line arguments so that ansible thinks we are a task
    sys.argv = [orig_sys_argv[0], '-vvvv', '-m', 'getent', '-a', 'database=passwd', '-a', 'key=root']

    # Run the main function
    main()

    # Restore the original sys.argv
    sys.argv = orig_sys_argv

    # Check the results
    assert 'ansible_facts' in globals()
    assert 'getent_passwd' in globals()['ansible_facts']

# Generated at 2022-06-17 04:39:40.884238
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:47.724846
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:40:59.378628
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:10.332535
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.process import get_bin_path

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module.run_command

# Generated at 2022-06-17 04:41:18.858677
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path

    # Test with no key
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = lambda cmd, check_rc=True: (0, '', '')

# Generated at 2022-06-17 04:41:28.823000
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:37.367844
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:48.817758
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Mock module args
    sys.argv = ['ansible-test', '-vvv', '-b', 'getent', '-a', 'database=passwd', '-a', 'key=root']

    # Mock module input
    module_input = {
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': True,
    }

    # Mock module output

# Generated at 2022-06-17 04:42:00.320367
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:08.522902
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:20.628871
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:28.729161
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key