

# Generated at 2022-06-17 04:34:09.675203
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # sys.argv = ['getent.py', 'passwd', 'root']
    sys.argv = ['getent.py', 'passwd']
    if PY3:
        sys.argv = list(map(to_bytes, sys.argv))

    # Setup mock objects

# Generated at 2022-06-17 04:34:19.701975
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path

# Generated at 2022-06-17 04:34:29.879037
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:38.661418
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")
    with open(cfgfile, 'w') as f:
        f.write("[defaults]\nstdout_callback = json\n")

    # Create a temp ansible module
    module_path = os.path.join(tmpdir, "library")
    os.mkdir(module_path)
    module_file = os.path.join(module_path, "getent.py")
    shutil.copyfile("getent.py", module_file)

    # Create a temp ansible playbook
   

# Generated at 2022-06-17 04:34:44.932113
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:57.278211
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file2 = tempfile.mkstemp()
    os.close(fd)

    # This is the default ansible params
    defaults = {}

    # This is the ansible params we are testing

# Generated at 2022-06-17 04:35:04.181483
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import tempfile
    import shutil
    import subprocess
    import json
    import re

    # create a temp directory
    tmpdir = tempfile.mkdtemp()

    # create a temp hosts file
    hosts_file = os.path.join(tmpdir, 'hosts')

# Generated at 2022-06-17 04:35:15.159367
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:26.406147
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary ansible.cfg
    fd, temp_ansible_cfg = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary playbook
    fd, temp_playbook = tempfile.mkstemp()
    os.close(fd)

    # Write a temporary playbook

# Generated at 2022-06-17 04:35:35.772160
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike
    from ansible.module_utils.common.collections import is_setlike
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_sequence_of
    from ansible.module_utils.common.collections import is_iterable_of
    from ansible.module_utils.common.collections import is_listlike_of


# Generated at 2022-06-17 04:36:02.476276
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:11.388928
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format
    from ansible.module_utils.common.text.formatters import format_module_args
    from ansible.module_utils.common.text.formatters import format_values
    from ansible.module_utils.common.text.formatters import safe_repr

# Generated at 2022-06-17 04:36:20.205804
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment
    old_sys_path = list(sys.path)
    old_cwd = os.getcwd()
    old_env = dict(os.environ)
    os.chdir(tmpdir)
    sys.path.append(tmpdir)
    os.environ['PATH'] = tmpdir

    # Create a temporary module

# Generated at 2022-06-17 04:36:31.346702
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:42.261985
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['getent'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    rc, out, err = module.run_command(['getent', 'invalid'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with valid database
    module = AnsibleModule(argument_spec={'database': 'passwd'})
    rc, out, err = module.run_command(['getent', 'passwd'])

# Generated at 2022-06-17 04:36:53.122347
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:01.514206
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()

    # Create a temporary environment
    old_env = os.environ.copy()
    os.environ['ANSIBLE_MODULE_ARGS'] = json.dumps({
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': None,
        'fail_key': True,
    })

# Generated at 2022-06-17 04:37:12.419410
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module.run_command
    def mock_run_command(cmd):
        return 0, '', ''

    module.run_command = mock_run_command

    # Mock the module.get_bin_

# Generated at 2022-06-17 04:37:21.776345
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path2 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path3 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path4 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_path5 = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-17 04:37:32.593479
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path

    # Mock get_bin_path
    get_bin_path_orig = get_bin_path
    def get_bin_path_mock(arg, required=False):
        if arg == 'getent':
            return '/usr/bin/getent'
        else:
            return get_bin_path_orig(arg, required)
    get_bin_path = get_bin_path_mock

    # Mock run_command
    run_command_orig = AnsibleModule

# Generated at 2022-06-17 04:38:12.482545
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path

# Generated at 2022-06-17 04:38:18.662056
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:31.496659
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:43.831584
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3

    if not PY3:
        from ansible.module_utils.pycompat24 import get_exception

    # inject some fake ansible params

# Generated at 2022-06-17 04:38:54.393137
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.process import get_bin_path

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the get_bin_path function

# Generated at 2022-06-17 04:39:05.781548
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module input parameters

# Generated at 2022-06-17 04:39:19.294901
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:31.593956
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:40.530710
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:47.658032
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:40:57.981955
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'Missing required arguments: database'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'Unexpected failure!'

    # Test with valid database
    module = AnsibleModule(argument_spec={'database': 'passwd'})
    result = main()
    assert result['failed'] == False
    assert result['ansible_facts']['getent_passwd'] != {}

# Generated at 2022-06-17 04:41:09.285984
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment
    old_env = os.environ
    os.environ = {}
    os.environ['PATH'] = tmpdir

    # Create a temporary module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a temporary getent command
    getent_bin = os

# Generated at 2022-06-17 04:41:22.177817
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Write a file to the temporary file
    os.write(fd, b"foo")

    # Close the file
    os.close(fd)

    # Create a temporary file in the temporary directory
    fd, tmpfile2 = tempfile.mkstemp(dir=tmpdir)

    # Write a file to the temporary file
    os.write(fd, b"foo")

   

# Generated at 2022-06-17 04:41:27.428554
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:37.819887
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:49.251292
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 04:42:00.393657
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:08.587584
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:20.651942
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    import tempfile
    import shutil
    import subprocess
    import platform
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("py3 only", allow_module_level=True)

    # create a temp dir to store the test files
    tmpdir = tempfile.mkdtemp()

    # create a temp ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")

# Generated at 2022-06-17 04:42:28.728924
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   