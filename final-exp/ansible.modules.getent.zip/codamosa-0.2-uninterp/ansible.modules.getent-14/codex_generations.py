

# Generated at 2022-06-17 04:34:07.309901
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    fd, temp_file = tempfile.mkstemp(dir=tmpdir)

    # Write data to the temporary file
    os.write(fd, b'foo')

    # Close the file descriptor
    os.close(fd)

    # Open the file in read-only mode
    f = open(temp_file, 'r')

    # This is the expected result of the module

# Generated at 2022-06-17 04:34:18.957721
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike

    # Mock module

# Generated at 2022-06-17 04:34:29.850016
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Save the current working directory
    cwd = os.getcwd()

    # Create a temporary directory
    tmp = tempfile.mkdtemp()

    # Create a temporary playbook
    filename = os.path.join(tmp, 'test.yml')

# Generated at 2022-06-17 04:34:40.508777
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    # set up the test data
    test_data = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
        'service': None,
        'fail_key': True,
        'ansible_facts': {
            'getent_passwd': {
                'root': ['x', '0', '0', 'root', '/root', '/bin/bash']
            }
        }
    }

    # set up the test module

# Generated at 2022-06-17 04:34:49.654804
# Unit test for function main
def test_main():
    import sys
    import os
    import subprocess
    import tempfile
    import shutil
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file2 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file3 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file4 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file5 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file6 = tempfile.mkstemp()

    # Create a temporary

# Generated at 2022-06-17 04:34:59.773441
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:09.925405
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:16.757442
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Save the current working directory
    cwd = os.getcwd()

    # Create a temporary directory
    tmp = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('[defaults]\nroles_path=%s' % tmp)

    # Create a temporary role
    role_path = os.path.join(tmp, 'role')
    os.mkdir(role_path)
    with open(os.path.join(role_path, 'meta'), 'w') as f:
        f.write('{}')

    # Create a temporary playbook
    f

# Generated at 2022-06-17 04:35:27.474078
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:35.214580
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:02.306572
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import json
    import subprocess
    import tempfile
    import shutil
    import time
    import copy
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("getent module only works with Python 3")


# Generated at 2022-06-17 04:36:11.205679
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:22.823467
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module file
    module_file = os.path.join(tmpdir, 'test_getent.py')
    with open(module_file, 'w') as f:
        f.write('''#!/usr/bin/python
import sys
sys.path.insert(0, '%s')
from getent import *
if __name__ == '__main__':
    main()
''' % tmpdir)

    # Create a temporary ansible.cfg
    cfg_file = os

# Generated at 2022-06-17 04:36:31.067749
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:41.931160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:48.381071
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:57.564668
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:09.148438
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('[defaults]\nroles_path=%s' % tmpdir)

    # Create a temp role
    role_path = os.path.join(tmpdir, 'role')
    os.mkdir(role_path)

    # Create a temp module
    module_path = os.path.join(role_path, 'library')
    os.mkdir(module_path)

# Generated at 2022-06-17 04:37:19.932573
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Save the current working directory
    cwd = os.getcwd()

    # Create a temporary directory
    tmp = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('[defaults]\nroles_path=%s' % tmp)

    # Create a temporary role
    role_path = os.path.join(tmp, 'role')
    os.mkdir(role_path)

    # Create a temporary module
    module_path = os.path.join(role_path, 'library')
    os.mkdir(module_path)

# Generated at 2022-06-17 04:37:31.781334
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Test with a valid database
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'

    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, 'passwd', 'root']

    rc

# Generated at 2022-06-17 04:38:11.570366
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:23.718031
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:30.241157
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:42.884447
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp module file
    module_path = os.path.join(tmpdir, 'ansible_module_getent.py')

# Generated at 2022-06-17 04:38:52.705273
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:58.510156
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()

    # Create a temporary ansible config
    fd, ansible_cfg = tempfile.mkstemp()

    # Create a temporary ansible inventory
    fd, inventory = tempfile.mkstemp()

    # Create a temporary ansible module
    fd, temp_module = tempfile.mkstemp()

    # Create a temporary ansible module
    fd, temp_args = tempfile.mkstemp()

    # Write data to temporary file

# Generated at 2022-06-17 04:39:08.548482
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:20.316668
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:31.985257
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:40.815006
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    # Mock the module
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the module input parameters

# Generated at 2022-06-17 04:40:54.439796
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:01.246829
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:11.193668
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file2 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file3 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file4 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file5 = tempfile.mkstemp()

    # Create a temporary file
    fd, temp_file6 = tempfile.mkstemp()

    # Create a temporary

# Generated at 2022-06-17 04:41:19.770837
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:28.876024
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:37.401890
# Unit test for function main
def test_main():
    # Test with a valid database and key
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.run_command = MagicMock(return_value=(0, 'root:x:0:0:root:/root:/bin/bash', ''))
    main()
    assert module.exit_json.called

# Generated at 2022-06-17 04:41:48.894861
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")
    with open(cfgfile, 'w') as f:
        f.write("[defaults]\n")
        f.write("roles_path = %s\n" % os.path.join(tmpdir, 'roles'))
        f.write("library = %s\n" % os.path.join(tmpdir, 'library'))
        f.write("module_utils = %s\n" % os.path.join(tmpdir, 'module_utils'))

   

# Generated at 2022-06-17 04:42:00.322507
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:08.524531
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json

    # Make sure we can import the module
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from library.getent import main

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temp directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Write data to the file
    os.write(fd, b'foo')

    # Close the file
    os.close(fd)

    # Create a module argument spec

# Generated at 2022-06-17 04:42:20.628527
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   