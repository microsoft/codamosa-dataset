

# Generated at 2022-06-17 04:34:10.328975
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'test', ''))
    main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ansible_facts']['getent_test'] == {'test': None}

    # Test with key

# Generated at 2022-06-17 04:34:20.338867
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:34:31.261155
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Mock module args
    sys.argv = [sys.argv[0]]
    currentdir = os.path.dirname(os.path.realpath(__file__))
    sys.argv.append("-a")
    sys.argv.append("database=passwd")
    sys.argv.append("-a")
    sys.argv.append("key=root")
    sys.argv.append("-a")
    sys.argv.append("service=sshd")
    sys.argv.append("-a")
    sys.argv.append("split=:")
    sys.argv.append("-a")

# Generated at 2022-06-17 04:34:40.852015
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import builtins

    if not PY3:
        builtin_open = '__builtin__.open'
    else:
        builtin_open = 'builtins.open'

    # getent_bin = module.get_bin_path('getent', True)
    getent_bin = get_bin_

# Generated at 2022-06-17 04:34:46.455807
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path

# Generated at 2022-06-17 04:34:58.351082
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:07.245650
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:14.605414
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:25.934407
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:35:35.132767
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:02.540444
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:11.426817
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.action import ActionBase
    from ansible.module_utils.action import ActionModule
    from ansible.module_utils.action import AnsibleAction
    from ansible.module_utils.action import AnsibleModuleBase
    from ansible.module_utils.action import AnsibleModuleCommon
    from ansible.module_utils.action import AnsibleModuleProcess
    from ansible.module_utils.action import AnsibleModuleProcessCommon
    from ansible.module_utils.action import AnsibleModuleProcessText
    from ansible.module_utils.action import AnsibleModuleText


# Generated at 2022-06-17 04:36:23.144425
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:36:34.281963
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-17 04:36:43.542945
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['getent'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    rc, out, err = module.run_command(['getent', 'invalid'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with valid database
    module = AnsibleModule(argument_spec={'database': 'passwd'})
    rc, out, err = module.run_command(['getent', 'passwd'])

# Generated at 2022-06-17 04:36:52.701295
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import json

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp module file
    module_path = os.path.join(tmpdir, 'ansible_module_getent.py')

# Generated at 2022-06-17 04:37:01.132283
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest

    # save the current path
    cur_path = os.getcwd()

    # create a temp directory
    tmp_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'tmp'))
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    # change to the temp directory
    os.chdir(tmp_dir)

    # create a temp file
    tmp_file = os.path.join(tmp_dir, 'test_getent.py')

# Generated at 2022-06-17 04:37:10.973295
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:21.368498
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:37:32.567804
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['getent'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': 'invalid'})
    rc, out, err = module.run_command(['getent', 'invalid'])
    assert rc == 1
    assert out == ''
    assert err == 'Missing arguments, or database unknown.\n'

    # Test with invalid key
    module = AnsibleModule(argument_spec={'database': 'passwd', 'key': 'invalid'})

# Generated at 2022-06-17 04:38:12.509586
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:38:18.685276
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.getent import main

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as f:
        f.write("[defaults]\nstdout_callback = yaml")

    # Create a temporary 'hosts' file

# Generated at 2022-06-17 04:38:31.490244
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary file

# Generated at 2022-06-17 04:38:43.830840
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()

    # Create a temporary environment
    oldenv = os.environ.copy()
    os.environ['PATH'] = tmpdir + ':' + os.environ['PATH']

    # Create a temporary module

# Generated at 2022-06-17 04:38:54.389785
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:05.782250
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:19.295740
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:31.633572
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:39:40.530947
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Mock the module arguments
    module_args = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )

    # Mock the module input parameters
    sys.argv = ['getent', 'passwd', 'root']

    # Mock the AnsibleModule object
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )

    # Mock the getent binary
    module.get_bin_path = lambda x, y: os.path.join(os.path.dirname(__file__), 'getent')

    # Mock the run_command function

# Generated at 2022-06-17 04:39:47.658679
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-17 04:40:59.171344
# Unit test for function main
def test_main():
    # Test case 1
    # Test case 1
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params = {'database': 'passwd', 'key': 'root'}
    main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ansible_facts']['getent_passwd']['root'][0] == 'x'

    # Test case 2
    module = AnsibleModule

# Generated at 2022-06-17 04:41:10.216424
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Mock module input parameters
    options = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
        'fail_key': True,
    }

    # Mock AnsibleModule input parameters

# Generated at 2022-06-17 04:41:18.710068
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:41:28.796108
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import traceback
    import os
    import sys

    # Mock module
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda x: sys.exit(1)
            self.exit_json = lambda x: sys.exit(0)
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x, y: '/bin/getent'

    # Mock module
    class MockModuleFail(object):
        def __init__(self, **kwargs):
            self.params = kwargs

# Generated at 2022-06-17 04:41:38.367448
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    # Ansible 2.8 imports
    try:
        from ansible.module_utils.common.process import get_bin_path
    except ImportError:
        from ansible.module_utils.facts.system.platform import get_bin_path

    # Ansible 2.9 imports

# Generated at 2022-06-17 04:41:49.317532
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    # Save the original sys.argv
    orig_sys_argv = sys.argv

    # Generate a test passwd file

# Generated at 2022-06-17 04:41:57.639481
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['failed'] is True
    assert result['msg'] == 'Missing required arguments: database'

    # Test with valid arguments
    module = AnsibleModule(argument_spec={'database': {'type': 'str', 'required': True}})
    result = main()
    assert result['failed'] is False
    assert result['msg'] == 'Unexpected failure!'

    # Test with invalid database
    module = AnsibleModule(argument_spec={'database': {'type': 'str', 'required': True}})
    result = main()
    assert result['failed'] is True
    assert result['msg'] == 'Missing arguments, or database unknown.'

# Generated at 2022-06-17 04:42:04.861103
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:11.755460
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-17 04:42:21.119209
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path