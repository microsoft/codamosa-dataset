

# Generated at 2022-06-11 07:10:52.523440
# Unit test for function main
def test_main():
    print("Test_main")
    # Make sure the module can be loaded
    cmd = "sudo -H pip install ansible"
    rc, out, err = os.system(cmd)
    assert rc == 0
    # Test - happy path
    cmd = "ansible-playbook -i localhost, -e 'myvar=myvalue' tests/test_getent.yml"
    rc, out, err = os.system(cmd)
    assert rc == 0
    # Test - conflict with existing var
    cmd = "ansible-playbook -i localhost, -e 'ansible_hosts=myvalue' tests/test_getent.yml"
    rc, out, err = os.system(cmd)
    assert rc != 0
    # Test - invalid DB

# Generated at 2022-06-11 07:11:04.805096
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.params = dict(
        database='passwd',
        key='root',
    )
    main()


    module.params = dict(
        database='group',
        split=':',
    )
    main()


    module.params = dict(
        database='hosts',
        split='\t',
    )
    main()



# Generated at 2022-06-11 07:11:08.714644
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)

    if not os.path.isfile(getent_bin):
        raise unittest.SkipTest('getent not installed on this machine.')

# Generated at 2022-06-11 07:11:17.752480
# Unit test for function main
def test_main():
    # Test setup
    getent_bin = module.get_bin_path('getent', True)

    # Test 1, normal case
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.basic import AnsibleModule
    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {
                'database': 'passwd',
                'key': None,
                'split': None,
                'fail_key': None,
                'service': None,
            }
            self._debug = False
            self._ansible_selinux_special_fs = set()

# Generated at 2022-06-11 07:11:18.514465
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:19.251244
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:11:24.699755
# Unit test for function main
def test_main():
    """Setup"""
    module = AnsibleModule(argument_spec={'database': {'required': False, 'type': 'str'}}, supports_check_mode=True)
    module.params = {'database': 'passwd'}

    """Testing"""
    main()

    """Teardown"""

# Generated at 2022-06-11 07:11:32.307272
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts

    import os
    import time
    import json

    # mock the facts module
    fake_facts = Facts({})
    fake_facts.populate()
    fake_facts.pre_facts_populate()
    fake_facts.post_facts_populate()
    facts = fake_facts.facts
    facts['ansible_env'] = {}
    facts['ansible_env']['PATH'] = '/usr/bin/:/bin'
    facts['ansible_env']['PYTHONPATH'] = ':'.join(sys.path)

    def getent_hosts():
        return [['localhost', '', '127.0.0.1'], ['localhost', '', '127.0.1.1']]

    # mock the getent functio
   

# Generated at 2022-06-11 07:11:37.818973
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )
    result = main()

    assert result == 0

# Generated at 2022-06-11 07:11:43.450826
# Unit test for function main
def test_main():
    #make unit test work
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    pass

# Generated at 2022-06-11 07:11:57.023328
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:12:06.898987
# Unit test for function main
def test_main():
    # Note: The test directory can be outside of the same directory as this
    # test. If this is not the case, the following needs to be adjusted.
    # module_path = '<path_to_tests>/ansible_collections/community/system'
    module_path = './'

    # Load the module to test
    mod = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Set module args for test

# Generated at 2022-06-11 07:12:17.610953
# Unit test for function main
def test_main():
    import inspect
    import os
    import sys
    import unittest

    # Mock the AnsibleModule class and set the module args to the required args
    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('AnsibleModule.fail_json: %s' % kwargs['msg'])

        def run_command(self, args):
            return (0, '', '')

        def get_bin_path(self, app, required=False):
            return ''


# Generated at 2022-06-11 07:12:28.632671
# Unit test for function main
def test_main():
    import json
    import os
    import sys
    import tempfile

    cmd = ['foo.bar:*:80:80:Apache User:/var/empty:/usr/bin/false', 'baz:*:81:81:Baz User:/var/empty:/usr/bin/false']
    cmd.append(':*:82:82:Empty User:/var/empty:/usr/bin/false')
    out = '\n'.join(cmd) + '\n'

    fd, tmpfile = tempfile.mkstemp()
    os.write(fd, to_bytes(out))
    os.close(fd)

    fd, tmpfile2 = tempfile.mkstemp()
    os.write(fd, to_bytes(out))
    os.close(fd)

    fd, tmpfile3 = tempfile.mkstemp

# Generated at 2022-06-11 07:12:29.993204
# Unit test for function main
def test_main():
    import ansible.module_utils.getent as getent
    assert getent.main() == None

# Generated at 2022-06-11 07:12:32.050696
# Unit test for function main
def test_main():
    try:
        print("Executing getent")
    except Exception:
        print("Executing getent failed")


# Generated at 2022-06-11 07:12:43.085887
# Unit test for function main
def test_main():
    def ansible_run_command(cmd, **kwargs):
        if 'group' in cmd:
            return 0, "name:*:1:root\nwheel:*:10:root", ""
        if 'group' in cmd and 'root' in cmd:
            return 0, "name:*:1:root", ""
        if 'group' not in cmd:
            return 1, "", ""
        else:
            return 0, "some_err", ""

    class AnsibleModule(object):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.params = {
                'database': 'group',
                'key': None,
                'service': None
            }

# Generated at 2022-06-11 07:12:51.817197
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.exit_json(value="<some value>")

#####param_validate######
#####param_check######
#####param_convert######

# Generated at 2022-06-11 07:13:01.996387
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-11 07:13:11.502757
# Unit test for function main
def test_main():
    import subprocess
    import sys
    import os
    import re

    facts = {}
    getent_bin = './helpers/getent'

    # test passing in valid databases
    databases = ['passwd', 'group', 'protocols', 'ethers', 'rpc', 'services', 'netgroup', 'networks', 'hosts']

    for db in databases:
        proc = subprocess.Popen([getent_bin, db], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = proc.communicate()
        if proc.returncode != 0:
            print("Couldn't run getent: %s" % err)
            sys.exit(1)
        facts['getent_%s' % db] = {}

# Generated at 2022-06-11 07:13:36.892867
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:13:44.673603
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec={
            'database': {'type': 'str', 'required': False},
            'key': {'type': 'str', 'no_log': False, 'required': False},
            'split': {'type': 'str', 'required': False},
            'fail_key': {'type': 'bool', 'default': True, 'required': False},
        },
        supports_check_mode=False,
    )
    test_module_params = {'database': 'protocols', 'key': '', 'split': ':', 'fail_key': True}
    test_module.params = test_module_params
    main()

# Generated at 2022-06-11 07:13:45.202099
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:13:54.009846
# Unit test for function main
def test_main():

    data = dict(
        database='passwd',
        key='root'
    )
    module = AnsibleModule(argument_spec=data)

    # Mock the result dict
    module.get_bin_path = lambda *args, **kwargs: 'FAKE_PATH'
    module.run_command = lambda *args, **kwargs: (0, 'fake results', '')

    main()
    result = module.exit_json.call_args[0][0]

    assert result is not None
    assert result['ansible_facts']['getent_passwd']['root'][0] == 'x'
    assert result['ansible_facts']['getent_passwd']['root'][1] == '0'

# Generated at 2022-06-11 07:14:03.435827
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule as AM
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.io import IOReader

    class FakePopen(object):
        def __init__(self, return_code=0, out='', err=''):
            self.return_code = return_code
            self.out = StringIO(out)
            self.err = StringIO(err)
            self.commands = []

        def __call__(self, *args, **kwargs):
            self.commands.append(args)
            return self

        @property
        def stdout(self):
            return IOReader(self.out)


# Generated at 2022-06-11 07:14:10.868469
# Unit test for function main
def test_main():
    print("test start")
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    print(module.params)
    print(main())
    print("test end")
    return

# Generated at 2022-06-11 07:14:21.482752
# Unit test for function main
def test_main():
    g_getent_bin = "./test_getent"
    # Test with no key parameter passed and split set to : which should be colon
    # for the shadow database.
    args = {
        'database': 'passwd',
        'key': None,
        'service': None,
        'split': ":",
        'fail_key': True,
    }

# Generated at 2022-06-11 07:14:32.832617
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible.module_utils.actions import _configparser as configparser
    from ansible.module_utils.basic import AnsibleModule

    import platform
    import sys

    class MockModule(object):
        """
        Mock class to simulate the behavior of a AnsibleModule
        """
        class RunCommandResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        def __init__(self, arg_spec, bypass_checks=False):
            self.argument_spec = arg_spec
            self.params = {}
            self.check_mode = False
            self.bypass_checks = bypass_checks
            self._connected = False

# Generated at 2022-06-11 07:14:43.291198
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:14:53.675309
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-11 07:16:03.475344
# Unit test for function main
def test_main():
    # Some output from 'getent passwd' on a Ubuntu 14.04 system
    # 'x:x:0:0:x:x:x:/home/x:/bin/sh'
    # 'y:x:1000:1000::/home/y:/bin/bash'
    # 'z:x:10:10::/home/z:/bin/false'

    # Test getting all records
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    getent_bin = module

# Generated at 2022-06-11 07:16:04.011622
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:10.489343
# Unit test for function main
def test_main():
    # Make sure we have the function available
    assert main

    # Replace get_bin_path to always return the current binary path
    get_bin_path_orig = AnsibleModule.get_bin_path

    def get_bin_path(self, arg, required=False):
        return __file__

    AnsibleModule.get_bin_path = get_bin_path

    # Replace run_command to always return a valid output
    run_command_orig = AnsibleModule.run_command

    def run_command(self, *args, **kwargs):
        return 0, 'test:test:test\ntest2:test2:test2\n', ''

    AnsibleModule.run_command = run_command

    # Remove the module since we are mocking everything
    global main

# Generated at 2022-06-11 07:16:20.060833
# Unit test for function main
def test_main():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'lib'))
    from ansible.module_utils.basic import AnsibleModule, get_distribution
    from ansible.module_utils.action_plugins import _get_temp_dir
    from ansible.module_utils.facts import is_ansible_version
    from ansible.module_utils.facts.system.platform import get_platform
    from ansible.module_utils.facts.system.distribution import get_distribution
    from ansible.module_utils.facts.system import getent_facts

# Generated at 2022-06-11 07:16:28.993759
# Unit test for function main
def test_main():

    try:
        import getpass
        my_user = getpass.getuser()
    except ImportError:
        my_user = "root"

    my_group = os.getegid()

    # Get user info
    results = {}
    results['ansible_facts'] = {'getent_passwd': {my_user: ['x', my_group, '1000', '1000', '', '/home/%s' % my_user, '/bin/bash']}}
    assert main() == results

    # Get group info
    results = {}
    results['ansible_facts'] = {'getent_group': {str(my_group): ['x', my_user]}}
    assert main() == results

    # Get host info
    results = {}

# Generated at 2022-06-11 07:16:29.943746
# Unit test for function main
def test_main():
  print('Test for main')

# Generated at 2022-06-11 07:16:39.914082
# Unit test for function main
def test_main():
    # The ansible_facts dict contains everything the module returns
    ansible_facts = {}

    # the client machine's state with keys of the value of getent_passwd
    result = {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}

    # mock the object returned by run_command(), which returns rc, out & err
    # This is not necessary for the test, but without this you get an error from ansible.
    # An exception is raised in the try block if either of the following is true:
    #  - rc does not match the expected_rc
    #  - out does not match the expected_out
    #  - err does not match the expected_out

# Generated at 2022-06-11 07:16:41.342497
# Unit test for function main
def test_main():
    # Check that the function main works
    main()

# Generated at 2022-06-11 07:16:43.302858
# Unit test for function main
def test_main():
    # import unit test modules
    from ansible.modules.utility.getent import main
    
test_main()

# Generated at 2022-06-11 07:16:43.991798
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:18:58.874469
# Unit test for function main
def test_main():
    load_fixture = main.__globals__['load_fixture']
    AnsibleModule = main.__globals__['AnsibleModule']
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main.__globals__['module'] = module

    # load getent output from fixture
    getent_passwd = load_fixture('getent_passwd')
    getent_group = load_fixture('getent_group')
    getent

# Generated at 2022-06-11 07:19:06.864514
# Unit test for function main
def test_main():
    # fail the module without required database
    arguments = dict(
        database='',
        key=None,
        split=None,
        fail_key=True,
    )
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rc, out, err = module.run_command([module.get_bin_path('getent', True), 'passwd', 'billy'])
    assert rc == 0
    assert 'billy' in out.splitlines()[-1]

# Generated at 2022-06-11 07:19:07.775930
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    main()

# Generated at 2022-06-11 07:19:11.289951
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    # m = Mapping()
    module = get_module(dict(
        database='passwd',
        key='',
        split=':'
    ))
    assert module.run_command == ['getent', 'passwd']

# Generated at 2022-06-11 07:19:11.789453
# Unit test for function main
def test_main():
	
	pass

# Generated at 2022-06-11 07:19:17.419823
# Unit test for function main
def test_main():

    from ansible.module_utils import basic

    arguments = dict(database='passwd', key='root', split=':', fail_key=False)
    ansible_facts = dict()

    module_mock = basic.AnsibleModule(
        argument_spec=dict(), supports_check_mode=True
    )
    module_mock.params = arguments
    module_mock.exit_json = lambda x: x
    module_mock.run_command = lambda x: (0, '0', '')

    main()
    assert 'getent_passwd' in ansible_facts

# Generated at 2022-06-11 07:19:25.163507
# Unit test for function main
def test_main():
    # ansible-playbook -i tests/inventory tests/test.yml --connection=local -vvv
    # ansible-playbook -i tests/inventory tests/test.yml --connection=local -vvv
    # ansible-playbook -i tests/inventory tests/test.yml --connection=local -vvv --extra-vars="@tests/test_getent.json"
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from copy import deepcopy
    from getent import main
    import json
    import pytest

    basic._ANSIBLE_ARGS = deepcopy(basic._ANSIBLE_ARGS)


# Generated at 2022-06-11 07:19:29.112337
# Unit test for function main
def test_main():
    import sys
    import doctest
    try:
        import unittest2 as unittest
    except:
        import unittest
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(sys.modules['__main__']))
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-11 07:19:29.903503
# Unit test for function main
def test_main():
  assert True


# Generated at 2022-06-11 07:19:38.482787
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'database' : { 'type' : 'str', 'required' : True},
        'key' : { 'type' : 'str', 'required' : False},
        'split' : { 'type' : 'str', 'required' : False},
        'fail_key' : { 'type' : 'bool' , 'required' : False, 'default' : True}},
        supports_check_mode=True)
    module.exit_json(changed=False)

# Run unit tests with python2.7 -m unittest tests/test_getent.py
# Run unit tests with python3 -m unittest tests/test_getent.py
# Run unit tests with PYTHONPATH=. ansible-test units --python 2.7 units/module_utils/
#