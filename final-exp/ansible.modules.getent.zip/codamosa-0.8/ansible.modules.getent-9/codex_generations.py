

# Generated at 2022-06-11 07:10:52.522837
# Unit test for function main
def test_main():
    # Create the module mock
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Get parameters
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    # Set up mock
    cmd = ['getent', 'passwd', 'root']
    # Make sure it's

# Generated at 2022-06-11 07:10:53.557021
# Unit test for function main
def test_main():
    assert main() == 'test'

# Generated at 2022-06-11 07:11:06.066621
# Unit test for function main
def test_main():
    # Test for correct output
    return_msg = 'SYS_NOT_IMPLEMENTED_FOR_LINUX'
    results = {'changed': False, 'invocation': {'module_args': {'fail_key': False, 'service': '', 'split': None, 'key': None, 'database': 'passwd'}}, 'ansible_facts': {'getent_passwd': {}}}
    module = AnsibleModule(argument_spec={'database': {'type': 'str', 'required': True}, 'key': {'no_log': False, 'type': 'str'}, 'service': {'type': 'str'}, 'split': {'type': 'str'}, 'fail_key': {'default': True, 'type': 'bool'}}, supports_check_mode=True)

# Generated at 2022-06-11 07:11:16.535269
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    import os
    import sys

    # Check python version
    if sys.version_info < (2, 7):
        pytest.skip(msg="Requires Python 2.7 or higher")

    # Check if getent is available
    if not os.path.exists('/usr/bin/getent'):
        pytest.skip(msg="Requires getent")

    # Test case

# Generated at 2022-06-11 07:11:28.381734
# Unit test for function main
def test_main():
    import os
    import sys
    import getent
    import tempfile

    # Create a temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False)

    # path to the getent module
    module_path = os.path.abspath(getent.__file__)
    module_name = os.path.splitext(os.path.basename(module_path))[0]
    py_version = '%s.%s' % (sys.version_info[0], sys.version_info[1])
    module_version = '%s.%s.%s' % (module_name, py_version, sys.platform)

    # Export a fake getent command

# Generated at 2022-06-11 07:11:39.645832
# Unit test for function main
def test_main():
    import os
    import sys
    import shutil
    import tempfile
    import unittest
    from ansible import context
    script_dir = os.path.dirname(os.path.realpath(__file__))
    module_dir = os.path.dirname(script_dir)
    test_dir = os.path.join(module_dir, "tests")
    sys.path.insert(0, test_dir)
    from test_module import TestModule  # noqa: E402
    from test_module import TestAction
    context._init_global_context(load_default_config=False)
    module_utils_dir = os.path.join(script_dir, "module_utils")
    sys.path.insert(0, module_utils_dir)

    temp_dir = tempfile.gettempdir()

# Generated at 2022-06-11 07:11:40.273631
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:41.040956
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:11:42.942346
# Unit test for function main
def test_main():

    assert main()

# Generated at 2022-06-11 07:11:53.499695
# Unit test for function main
def test_main():

    import sys
    import subprocess
    import tempfile
    import os

    def __mock_get_bin_path(path, required):
        return path

    class MockModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, path, required):
            return __mock_get_bin_path(path, required)

        def run_command(self, cmd):
            return 0, '', None

        def fail_json(self, msg, **kwargs):
            sys.stderr.write(msg)
            sys.exit(-1)

        def exit_json(self, **kwargs):
            sys.exit(0)

    def __mock_open(path, *args):
        return open(path, *args)

# Generated at 2022-06-11 07:12:17.672474
# Unit test for function main
def test_main():

    getent_out = """
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin

"""
    expected_results = {
        'getent_passwd':
            {'root': ['x', '0', '0', 'root', '/root', '/bin/bash'],
             'bin': ['x', '1', '1', 'bin', '/bin', '/sbin/nologin']}}


# Generated at 2022-06-11 07:12:19.496694
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as exc:
        print(exc)

# Generated at 2022-06-11 07:12:29.532401
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(
           database=dict(type='str'),
           key=dict(type='str'),
           service=dict(type='str'),
           split=dict(type='str'),
           fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    
    if get_bin_path('getent') is None:
        module.fail_json(msg='Failed to find getent binary.')

    with basic.mocked_getent(module):
        main()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 07:12:35.196933
# Unit test for function main
def test_main():
    # as we are not running this in a command context we need to
    # monkeypatch the module to look like it is
    import os
    import sys
    module = type('Args', (), {})
    module.params = {'database': 'passwd', 'key': 'root', 'split': None}
    module.run_command = lambda x, **kw: (0, 'root:x:0:0:root:/root:/bin/bash\n', '')
    module.get_bin_path = lambda x, y: x
    sys.modules['ansible.module_utils.basic'] = type('Args', (), {'AnsibleModule': module})
    sys.modules['ansible.module_utils._text'] = type('Args', (), {'to_native': lambda x: x})
    main()

# Generated at 2022-06-11 07:12:46.685085
# Unit test for function main
def test_main():
    expected = dict(ansible_facts=dict(getent_passwd={u'www-data': [u'x', u'33', u'33', u'www-data', u'/var/www', u'/usr/sbin/nologin']}))
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = run_command
    module.params = dict(database='passwd', key='www-data', split=':')
    result = main()

# Generated at 2022-06-11 07:12:56.152776
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class DummyModule(object):
        def __init__(self):
            self.params = {
                'database': 'testdb',
                'key': None,
                'split': None
            }

        def fail_json(self, msg=None, **kwargs):
            print(msg)
            exit(1)

        def run_command(self, cmd):
            return 0, 'a:b\nc:d', ''

        def get_bin_path(self, cmd, required):
            return cmd

    m = DummyModule()
    main()

    m = DummyModule()
    m.params['key'] = 'test'
    main()

# Generated at 2022-06-11 07:13:07.821998
# Unit test for function main
def test_main():
    import pytest
    from ansible.modules.system.getent import main
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import os
    import tempfile
    import yaml

    fixtures = os.path.join (
        os.path.dirname(__file__),
        'fixtures',
    )
    with open(os.path.join(fixtures, 'passwd.yml')) as f:
        passwd_fixture_data = yaml.load(f)

    passwd_temp = tempfile.TemporaryFile()

    with open(os.path.join(fixtures, 'group.yml')) as f:
        group_fixture

# Generated at 2022-06-11 07:13:19.113986
# Unit test for function main
def test_main():
    from ansible.module_utils.common.json_utils import json

    class FakeModule(object):
        """ Simulate AnsibleModule command line formatter
        """
        class FakeModule_params(object):
            def __init__(self, **kwargs):
                self.argument_spec = {}
                self.__dict__.update(kwargs)

            def get(arg):
                if arg in self.__dict__:
                    return self.__dict__[arg]
                return None

        def __init__(self, **kwargs):
            self.params = self.FakeModule_params(**kwargs)
            self.fail_json = lambda **kwargs: None


# Generated at 2022-06-11 07:13:29.847040
# Unit test for function main
def test_main():
    # Failed run (getent returns 1)
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(1, '', ''))

    main()
    assert module.fail_json.called
    assert module.exit_json.called == False
    module.run_command.assert_called_with(['getent', module.params['database']])

# Generated at 2022-06-11 07:13:38.265812
# Unit test for function main
def test_main():
    import tempfile
    getent_bin = "/usr/bin/getent"
    database = "passwd"
    key = "root"
    service = None
    split = ": "
    fail_key = True
    filename = tempfile.NamedTemporaryFile(mode='r')
    os.system("echo '" + getent_bin + " " + database + " " + key + " ' >" + filename.name)

    rc, out, err = module.run_command()
    assert rc == 0
    out_split = out.split(split)
    assert out_split[0] == key
    assert out_split[1] == "x"
    assert out_split[2] == "0"
    assert out_split[3] == "0"
    assert out_split[4] == "Root"

# Generated at 2022-06-11 07:14:20.881433
# Unit test for function main
def test_main():
    import os
    import tempfile
    import json

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    path = os.path.dirname(os.path.realpath(__file__))
    test_path = os.path.join(path, '../../unit/module_utils/tests/')
    module.get_bin_path = lambda x, y: os.path.join(test_path, 'getent')

# Generated at 2022-06-11 07:14:32.257692
# Unit test for function main
def test_main():
    """
    Unit test for main function.
    """
    # Test case 1
    # Test when database is not in colon
    database = 'foo'
    key = None
    split = None
    service = None
    fail_key = None

    sync = ""

# Generated at 2022-06-11 07:14:42.815349
# Unit test for function main

# Generated at 2022-06-11 07:14:49.464488
# Unit test for function main
def test_main():
    import copy
    import os

    import pytest

    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    from ansible.module_utils.basic import AnsibleModule

    signal_args = dict(
        database='passwd',
        key='root',
    )

    check_mode_args = signal_args.copy()
    check_mode_args['check_mode'] = True

    success_args = signal_args.copy()

    module_return_value = dict(
        ansible_facts=dict(
            getent_passwd=dict(
                root=['x','0','0','root','/root','/bin/bash'],
            ),
        ),
    )


# Generated at 2022-06-11 07:15:00.478678
# Unit test for function main
def test_main():
    ##############
    # Setup
    ##############
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock()
    ##############
    # Run
    ##############
    # example of success getent run
    mockrc = 0

# Generated at 2022-06-11 07:15:07.468163
# Unit test for function main
def test_main():
    with patch('__main__.getent_bin', lambda x: True):
        with patch('__main__.module', Mock(params=dict(database='test',
                                                       key='test',
                                                       service='test',
                                                       split=':',
                                                       fail_key=True
                                                       ))):
            with patch('__main__.module.run_command', Mock(return_value=(0, 'test', 'test'))):
                with pytest.raises(SystemExit):
                    __main__.main()



# Generated at 2022-06-11 07:15:17.767932
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', required=False),
            split=dict(type='str', required=False),
            fail_key=dict(type='bool', required=False),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

   

# Generated at 2022-06-11 07:15:27.013336
# Unit test for function main
def test_main():
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()

    # Simple test - no error
    class Options():
        def __init__(self):
            self.database = 'test'
            self.key = ''
            self.split = ':'
            self.fail_key = True
            self.service = None

    class Module():
        def __init__(self):
            self.check_mode = False
            self.params = Options()

        def get_bin_path(self, arg1, arg2):
            return tmpfile.name

        def run_command(self, arg1):
            return 0, "test:test\ntest:test", ''

    f = open(tmpfile.name, 'w')

# Generated at 2022-06-11 07:15:32.348226
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = mock.Mock()
    module.run_command.return_value = (0, 'key1:value1', '')
    main()

    module.exit_json.assert_called_once()

# Generated at 2022-06-11 07:15:41.943063
# Unit test for function main
def test_main():
	from ansible.module_utils import basic
	from ansible.module_utils import action_common_attribute
	from ansible.module_utils.facts import ansible_facts


# Generated at 2022-06-11 07:16:55.106323
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = MagicMock(return_value=(0, "", ""))
    main()
    module.run_command = MagicMock(return_value=(2, "", ""))
    main()
    module.run_command = MagicMock(return_value=(1, "", ""))
    main()
    module.run_command = MagicMock(return_value=(3, "", ""))
   

# Generated at 2022-06-11 07:17:03.876087
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import OrderedDict
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    if sys.version_info[0] == 2:
        # Python 2.x
        reload(sys)
        sys.setdefaultencoding('utf8')

        module = basic.AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str'),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )


# Generated at 2022-06-11 07:17:15.272147
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:24.550866
# Unit test for function main
def test_main():
    import sys
    import inspect
    import ansible_facts.test_runner
    from ansible.module_utils import basic

    module, path = ansible_facts.test_runner.setup_module_loader()

    # This is the correct path to the module
    module.__name__ = "ansible_facts.system.getent"
    module.__file__ = path

    def my_run_command(cmd):
        return 0, 'a:b', ''

    def dummy_module_init():
        module.run_command = my_run_command
        for argument in module.argument_spec:
            if argument == 'database':
                module.params[argument] = 'foo'
            elif argument == 'key':
                module.params[argument] = 'bar'
            elif argument == 'split':
                module.params

# Generated at 2022-06-11 07:17:34.465893
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    import sys
    if sys.version_info[0] >= 3:
        result = {'changed': False, 'ansible_facts': {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}}

# Generated at 2022-06-11 07:17:42.338822
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule, _load_params
    from ansible.module_utils.actions import ActionBase

    # fake values for testing

# Generated at 2022-06-11 07:17:47.424715
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test.exit_json(changed=False, ansible_facts=dict(test='test'))


# Generated at 2022-06-11 07:17:56.261828
# Unit test for function main
def test_main():
    import os
    import sys
    import json
    import subprocess

    test_dict = dict(
        database='passwd',
        key='root',
        fail_key=True
    )

    test_dict_2 = dict(
        database='group',
        key='root',
        fail_key=True
    )

    test_dict_3 = dict(
        database='group',
        split=':',
        fail_key=True
    )

    if os.getuid():
        subprocess.check_call(['sudo', sys.executable, '-m', 'ansible.modules.commands.getent', 'test_main'])

# Generated at 2022-06-11 07:18:01.959292
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_getent_module import main
    from ansible.module_utils.basic import AnsibleModule

    # Input data for the AnsibleModule object
    class AnsibleModuleArguments(object):
        def __init__(self):
            self.database = 'passwd'
            self.key = None
            self.service = None
            self.split = None
            self.fail_key = True

    # Set up the AnsibleModule object
    module_args = AnsibleModuleArguments()

# Generated at 2022-06-11 07:18:11.031522
# Unit test for function main
def test_main():
    import os
    import sys

    # Disable logging to increase test speed
    sys.stdout.write('[localhost]\nlocalhost ansible_connection=local ansible_python_interpreter=/usr/bin/python\n')
    os.environ['ANSIBLE_CONFIG'] = 'test/ansible.cfg'

    # Load module and add arguments
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params