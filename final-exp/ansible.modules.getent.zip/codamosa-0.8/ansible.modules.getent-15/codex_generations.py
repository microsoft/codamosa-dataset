

# Generated at 2022-06-11 07:10:49.337593
# Unit test for function main
def test_main():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self._args = args

        def run_command(self, cmd, *args, **kwargs):
            return {"cmd": cmd, "args": args, "kwargs": kwargs}
    

# Generated at 2022-06-11 07:10:50.540493
# Unit test for function main
def test_main():
    test_main.__doc__ = main.__doc__
    main()

# Generated at 2022-06-11 07:11:02.602795
# Unit test for function main
def test_main():

    # Setup Module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Setup Module arguments
    database = 'passwd'
    key = 'root'
    split = None
    service = None
    fail_key = True

    # Successful run
    results = {'ansible_facts': {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}}

    # Call main

# Generated at 2022-06-11 07:11:14.152951
# Unit test for function main
def test_main():
    import sys
    import platform
    import random
    import string
    import tempfile
    import os

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # First the simple test cases
    assert test_getent(ansible_module_args={'database': 'passwd'}) == 0
    assert test_getent(ansible_module_args={'database': 'passwd', 'service': 'passwd'}) == 0

    # create a random group, fake /etc/group
    group = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(8))
    etc_group = tempfile.NamedTemporaryFile(delete=False)
    etc

# Generated at 2022-06-11 07:11:26.998783
# Unit test for function main
def test_main():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Setup test environment
    sys.path.append(os.path.join(os.getcwd(), 'library/'))

    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ),
    supports_check_mode=True,
    )
    module.get_bin_path = lambda x, y: "/bin/getent"


# Generated at 2022-06-11 07:11:38.242716
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    import os
    import tempfile
    import json
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.common._collections_compat import Counter
    from ansible.module_utils._text import to_bytes

    def run_test(database, key=None, split=None, service=None,
                 fail_key=False):
        '''
        Generic test runner for getent
        '''
        with tempfile.NamedTemporaryFile(dir=os.path.dirname(__file__), delete=False) as tmp:
            tmp.write(to_bytes('ts\t1.1.1.1\n'))

# Generated at 2022-06-11 07:11:39.697850
# Unit test for function main
def test_main():
    rc, out, err = main()
    print(rc, out, err)

# Generated at 2022-06-11 07:11:48.293796
# Unit test for function main
def test_main():
    import sys
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 07:11:58.308459
# Unit test for function main
def test_main():
    def run_command(self, args, check_rc=True, close_fds=True, executable=None,  data=None, binary_data=False):
        print (args)
        return (0, "", "")

    def get_bin_path(self, arg, required=False):
        return arg

    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}
        def fail_json(self, **kwargs):
            print (kwargs)
            raise Exception("fail")
        def exit_json(self, **kwargs):
            print (kwargs)


# Generated at 2022-06-11 07:12:07.988578
# Unit test for function main
def test_main():
    """Test function main"""
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:12:30.906697
# Unit test for function main
def test_main():
    from random import randint
    from random import choice
    from string import ascii_letters

    # Create random strings
    database = ''.join(choice(ascii_letters) for i in range(randint(5, 15)))
    key = ''.join(choice(ascii_letters) for i in range(randint(5, 15)))
    split = ''.join(choice(ascii_letters) for i in range(randint(5, 15)))
    service = ''.join(choice(ascii_letters) for i in range(randint(5, 15)))

    # Create class object
    module_args = dict(
        database=database,
        key=key,
        split=split,
        service=service,
        fail_key='yes'
    )


# Generated at 2022-06-11 07:12:41.833725
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = "passwd"
    key = None
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd

# Generated at 2022-06-11 07:12:53.412877
# Unit test for function main
def test_main():
    import os
    import sys
    import shutil
    import subprocess

    if os.geteuid() != 0:
        print("Skipping tests for getent, as it requires root privileges")
        sys.exit(0)

    # make sure we can actually call getent on this system before trying to test it
    if not shutil.which('getent'):
        print("Skipping tests for getent, as it appears to not be installed")
        sys.exit(0)

    testdir = '/tmp/ansible-test-getent'
    testfilename = testdir + '/testgetent.py'
    testpass = '/tmp/ansible-test-getent.pass'
    testfail = '/tmp/ansible-test-getent.fail'


# Generated at 2022-06-11 07:12:58.701184
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'database': 'passwd',
        'split': ':',
        'key': 'root',
    })

    getent_bin = module.get_bin_path('getent', True)

    if getent_bin != '/bin/getent':
        module.fail_json(msg='getent_bin is not /bin/getent')

    main()

# Generated at 2022-06-11 07:13:09.733155
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import argspec

    arg_spec = argspec.ArgumentSpec()
    arg_spec.add_argument('database', type='str', required=True)
    arg_spec.add_argument('key', type='str', no_log=False)
    arg_spec.add_argument('service', type='str')
    arg_spec.add_argument('split', type='str')
    arg_spec.add_argument('fail_key', type='bool', default=True)

    module = basic.AnsibleModule(arg_spec=arg_spec)
    module.get_bin_path = lambda x, bool: 'getent'

# Generated at 2022-06-11 07:13:21.350463
# Unit test for function main
def test_main():
    test_rc = -1
    test_out = "test"
    test_err = ""
    test_exception = None

    class TestException(Exception):
        pass

    class TestModule(AnsibleModule):
        # Override AnsibleModule.run_command() to return our testing values.
        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            if args == ['/usr/bin/getent', 'passwd', 'root']:
                return (0, 'root:x:0:0:root:/root:/bin/bash', '')

# Generated at 2022-06-11 07:13:28.360876
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )
    test.exit_json(msg="success", ansible_facts={"test": True})

# EOF

# Generated at 2022-06-11 07:13:30.905404
# Unit test for function main
def test_main():

    getent_bin = '/usr/bin/getent'
    assert_module.assert_equal(getent_bin, getent_bin, 'Test getent binary path')

# Generated at 2022-06-11 07:13:31.514159
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:13:32.150964
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:13.029149
# Unit test for function main
def test_main():
    class AnsibleModuleMock():
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}

        def fail_json(self, msg, exception):
            print(to_native(msg))
            print(exception)

        def get_bin_path(self, path, opt_dirs=[]):
            return path

        def run_command(self, cmd):
            return 0, "test_db:\tfoo\n\ttest_field\nbar", ''

    # No split param, and db is in colon

# Generated at 2022-06-11 07:14:13.667315
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:24.646554
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    database = 'passwd'
    key = 'root'
    cmd = [getent_bin, database, key]
    rc, out, err = module.run_command(cmd)
    assert rc == 0
    record = out.split(':')
    assert record[0] == 'root'

# Generated at 2022-06-11 07:14:35.712769
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import os
    class MockGetentBinModule(object):
        def get_bin_path(self, module, required):
            if required:
                return os.path.realpath('./unit_tests/getent')
            else:
                return None
    module.get_bin_path = MockGetentBinModule().get_bin_path

# Generated at 2022-06-11 07:14:45.513292
# Unit test for function main
def test_main():
    import json
    import shlex
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.dicts import merge_hash

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def split_command(command):
        command = to_bytes(command)

# Generated at 2022-06-11 07:14:56.453285
# Unit test for function main
def test_main():
    """Tests for basic sanity for the module"""

    class FakeModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self):
            return ''

        def run_command(self, cmd):
            return 0, ":test:test", ''

        def fail_json(self, msg, exception=None):
            raise Exception("Module failure: %s, %s" % (msg, exception))

        def exit_json(self, ansible_facts, msg=None):
            return {"ansible_facts": ansible_facts, "msg": msg}

    # Simple test
    module = FakeModule("passwd")
    main(module)

    # test with service
    module = FakeModule("passwd", "root", service="systemd")
    main(module)

    #

# Generated at 2022-06-11 07:15:05.158105
# Unit test for function main
def test_main():
    import sys
    import os
    import subprocess
    import shutil
    import tempfile
    import stat
    import json
    import filecmp
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import Mapping as BaseMapping

    class Mapping(BaseMapping):
        def __init__(self, *args, **kwargs):
            self.update(*args, **kwargs)

        def __setitem__(self, key, value):
            if key == 'module_stderr':
                self.__dict__['module_stderr'] = value

# Generated at 2022-06-11 07:15:15.475321
# Unit test for function main
def test_main():
  from copy import deepcopy
  module_args = dict(
    database='passwd'
  )
  expected_results = dict(
    ansible_facts=dict(
      getent_passwd=dict(
        root=['x', '0', '0', 'root', '/root', '/bin/bash']
      )
    )
  )


# Generated at 2022-06-11 07:15:24.940617
# Unit test for function main
def test_main():
    # Path to getent, different on most systems
    getent_bin = "/usr/bin/getent"

    # Mimic module object
    module = type("AnsibleModule", (object,), {
        "run_command": run_command,
        "get_bin_path": lambda self, path, require_executable: getent_bin
    })

    # Mimic AnsibleModule.fail_json({})
    fail_json = type("fail_json", (object,), {
        "__call__": lambda self, kwargs: fail_json.exception(kwargs['msg'])
    })

    # Mimic AnsibleModule.exit_json({})

# Generated at 2022-06-11 07:15:27.830396
# Unit test for function main
def test_main():
    # Initialise mocks
    module = AnsibleModule({}, False)

    # Mock all methods
    module.exit_json = lambda: None
    module.fail_json = lambda: None

    # Start the actual method
    main()

# Generated at 2022-06-11 07:16:40.400376
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    m_ansible_module_get_bin_path = module.get_bin_path

    module.get_bin_path = Mock(return_value='/usr/bin/getent')

    def side_effect_run_command(mod, command, check_rc=False, environ_update=None, data=None, binary_data=False):
        return 0, 'testdb:x:foo', ''

    m_ansible_module_run_command = module

# Generated at 2022-06-11 07:16:51.856111
# Unit test for function main
def test_main():
    # pylint: disable=no-self-use
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    class Result:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
    module.run_command = lambda x: Result(rc=0, out='a:b:c', err='')
    module.exit_json = lambda x: x

# Generated at 2022-06-11 07:17:01.758403
# Unit test for function main
def test_main():
    import os
    import mock
    import pytest
    import json

    names = '''
    service_a    service_a_name    service_a_port
    service_b    service_b port
    service_c    service_c_port
    '''
    os.environ['PATH'] = os.environ['PATH'].split(':')[:-1]
    os.environ['PATH'] = ':'.join(os.environ['PATH'])

    mock_run_command = mock.MagicMock(return_value=(0, names, None))

    with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command', mock_run_command):
        with pytest.raises(SystemExit):
            main()


# Generated at 2022-06-11 07:17:13.383454
# Unit test for function main
def test_main():
    # Test argument_spec
    arg_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )

    # Test module dependencies
    module_deps = ['getent']
    # Test module import
    module = AnsibleModule(
        argument_spec=arg_spec,
        supports_check_mode=True
    )

    # Test module execution
    # Ensure empty getent_passwd is returned
    # Test module import
    module = AnsibleModule(
        argument_spec=arg_spec,
        supports_check_mode=True
    )

    # Test module execution
    #

# Generated at 2022-06-11 07:17:23.409229
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:33.750533
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:41.836778
# Unit test for function main
def test_main():
    import inspect
    import os
    import shutil
    import sys
    import tempfile

    # if not hasattr(sys, 'real_prefix'):
    #     pytest.skip('Virtualenv not loaded')

    # Hack to add the current dir to the module path
    module_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    sys.path.insert(0, module_path)

    from plugin_test_lib import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    test_case = ModuleTestCase('test_getent', os.path.dirname(__file__))

    def setUpModule():
        shutil.copytree('testdata/', test_case.testdata_path)
        #

# Generated at 2022-06-11 07:17:49.191357
# Unit test for function main
def test_main():

    import os

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.fail_json = AnsibleFailJson


# Generated at 2022-06-11 07:17:57.602752
# Unit test for function main

# Generated at 2022-06-11 07:18:05.131463
# Unit test for function main
def test_main():
    # Test with no key, key is none, split is none
    getent_bin = '/usr/bin/getent'
    rc = 0
    out = 'one:two:three\none:two\none:two'
    err = ''
    database = 'passwd'
    key = None
    split = None
    service = None

    ansible_facts = {'getent_passwd': {'one': ['two', 'two', 'two'], 'three': ['one']}}
    assert main(getent_bin, rc, out, err, database, key, split, service) == ansible_facts

    # Test with a key and service, split is none
    getent_bin = '/usr/bin/getent'
    rc = 0
    out = 'one:two:three\none:two\none:two'
