

# Generated at 2022-06-11 07:10:41.751118
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:10:48.386821
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.Basic(dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ))
    module.run_command = lambda cmd, tmp=None, check_rc=True: (0, "foo:bar\nqux:norf\nfoo:bar:norf", None)
    main()

# Generated at 2022-06-11 07:10:48.890967
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:10:57.919431
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str'),
            split=dict(type='str'),
        ),
    )
    module.run_command = mock.Mock(return_value=(0, '', ''))
    rc = main()
    module.run_command.assert_called_once_with(['getent', 'passwd', 'root'])
    assert rc == {'ansible_facts': {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}}


# Generated at 2022-06-11 07:11:09.980879
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_module.run_command = MagicMock(return_value=(0, None, None))
    test_module.exit_json = MagicMock()
    test_module.fail_json = MagicMock()

    main()

    assert test_module.run_command.called
    assert test_module.exit_json.called
    assert not test_module.fail_json.called

# Generated at 2022-06-11 07:11:18.443630
# Unit test for function main
def test_main():
    # Import test_getent module within the same directory of the getent module.
    from . import test_getent
    # Initialize module_utils with the default values used.
    module_utils = AnsibleModule(
        supports_check_mode=True
    )
    # Use importlib function to import the getent module dynamically
    getent = importlib.import_module('ansible.module_utils.facts.system.getent')
    cmd = ['cat', '/etc/passwd']
    # run_command method of module_utils is mocked to return desired parameters
    # and it is called to execute getent module.
    module_utils.run_command = MagicMock()

# Generated at 2022-06-11 07:11:19.197912
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-11 07:11:29.911102
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.six import StringIO

    module_args = {}

    def fail_json_mock(*args, **kwargs):
        raise Exception('fail_json')

    def run_command_mock(*args, **kwargs):
        return 0, 'linux:x:0:0:root:/root:/bin/bash\ndebian-tor:x:118:130::/var/lib/tor:/bin/false', ''


# Generated at 2022-06-11 07:11:36.465133
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)
    assert getent_bin is not None
    assert getent_bin.endswith('/getent')

    assert task.run(task=main)

    # Only run the idempotence check on platforms supporting check mode
    if task.__supports__['check_mode']:
        assert task.run(task=main).changed is False



# Generated at 2022-06-11 07:11:46.446446
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-11 07:11:59.891959
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-11 07:12:10.028430
# Unit test for function main
def test_main():
    import os
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    from ansible.module_utils import action_plugins
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

    # test getent_passwd

# Generated at 2022-06-11 07:12:20.349332
# Unit test for function main
def test_main():
    class AnsibleModuleMock(object):

        def run_command(self, command):
            pass

        def get_bin_path(self, command, required):
            return "getent"

        def fail_json(self, msg):
            return msg

        def exit_json(self, ansible_facts, msg):
            return ansible_facts, msg

    class TestArgs(object):

        def __init__(self):
            self.database = 'passwd'
            self.key = 'root'
            self.split = None
            self.service = None
            self.fail_key = True

    test_module = AnsibleModuleMock()
    test_args = TestArgs()
    main(test_module, test_args)

# Generated at 2022-06-11 07:12:30.557065
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'

# Generated at 2022-06-11 07:12:36.411335
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    f, p, ds = ansible.module_utils.basic.AnsibleModule.run_command.call_args

    assert f[0][0] == 'getent'
    assert f[0][1] == 'passwd'
    assert f[0][2] == 'root'
    assert f[0][3] == '-s'
    assert f[0][4] == 'service'

# Generated at 2022-06-11 07:12:47.954069
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:12:56.963780
# Unit test for function main
def test_main():
    # Test getent with missing database
    class TestArgs(object):
        database = None
        key = None
        split = None
        service = None
        fail_key = None

    module = AnsibleModule(argument_spec=TestArgs.__dict__)
    rc, out, err = main()
    assert rc == 2
    assert out == "Missing arguments, or database unknown."

    # Test getent working with passwd database
    class TestArgs(object):
        database = "passwd"
        key = None
        split = None
        service = None
        fail_key = None

    module = AnsibleModule(argument_spec=TestArgs.__dict__)
    rc, out, err = main()
    assert rc == 0

# Generated at 2022-06-11 07:13:08.497516
# Unit test for function main
def test_main():
    # Test with a valid database and key
    module = AnsibleModule(
        dict(
            database='passwd',
            key='root',
        ),
        supports_check_mode=True,
    )

    dbtree = 'getent_passwd'
    results = {dbtree: {}}
    results[dbtree]['root'] = ['x', '0', '0', 'root', '/root', '/bin/bash']
    assert main() == dict(ansible_facts=results)

    # Test with a valid database and invalid key
    module = AnsibleModule(
        dict(
            database='passwd',
            key='not-a-valid-key'
        ),
        supports_check_mode=True,
    )

    msg = "One or more supplied key could not be found in the database."

# Generated at 2022-06-11 07:13:19.980712
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    test_modules = {'getent' : True, 'getent.py' : True}

    class AnsibleModule_run_command(AnsibleModule):
        def run_command(self, cmd, check_rc=True):

            rc = 0
            cmd = cmd[0].split(' ')
            command = cmd[0]
            args = cmd[1:]

            if command in test_modules:
                rc = 4
                out = "out"
               

# Generated at 2022-06-11 07:13:30.551325
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # Test basic import
    module = basic.AnsibleModule(add_custom_success=True, argument_spec={}, supports_check_mode=True)
    module.exit_json = custom_exit_json
    module.run_command = custom_run_other

    # Test basic arg requirements
    with pytest.raises(SystemExit):
        main()
        assert module.params['database'] != ''

    # Test failure cases
    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.params['split'] = ':'
    module.params['fail_key'] = True
    module.params['check_mode'] = False
    ret = main()
    assert ret == None

    module.params['key'] = 'someuser'

# Generated at 2022-06-11 07:14:07.027854
# Unit test for function main
def test_main():
    test_result = {'ansible_facts': {'getent_passwd': [], 'getent_group': [], 'getent_hosts': [], 'getent_services': [], 'getent_shadow': []}}
    assert main() == test_result

# Generated at 2022-06-11 07:14:07.968791
# Unit test for function main
def test_main():
    assert True == False

# Generated at 2022-06-11 07:14:15.740354
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    fail_key = test_module.params.get('fail_key')

    getent_bin = test_module.get_bin_path('getent', True)

    test_module.run_command = MagicMock(return_value=(0, "", ""))
    test_module.exit_json = MagicMock()

    main()

    test_module.exit_json.assert_called_once()

   

# Generated at 2022-06-11 07:14:16.377085
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:14:27.776720
# Unit test for function main
def test_main():
    # Unit test case with valid data

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    data = dict(
        database='passwd',
        key='',
        service='',
        split=':',
        fail_key=True
    )
    module.params = data

    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, data['database'], data['key']]


# Generated at 2022-06-11 07:14:28.526022
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:39.278729
# Unit test for function main
def test_main():
    # Function 'main' call arguments
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_

# Generated at 2022-06-11 07:14:47.769976
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['database'] = 'passwd'
            self.params['key'] = 'root'

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            raise AnsibleExitJson(**self.exit_args)

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False
            raise AnsibleExitJson(**self.exit_args)


# Generated at 2022-06-11 07:14:58.773932
# Unit test for function main
def test_main():

    import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class AnsibleModule(object):

        def __init__(self, argument_spec, supports_check_mode=False, **kwargs):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_

# Generated at 2022-06-11 07:15:01.022839
# Unit test for function main
def test_main():
    ansible_facts = main()
    assert ansible_facts is not None

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:16:11.086366
# Unit test for function main
def test_main(): 
    import random
    import string
    import sys
    import shutil
    
    # Hack to make this unit test work for python 2 and 3.
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_collector_script
    from ansible.module_utils.facts.collector.system import getent as ansible_getent
    
    # getent returns different results across systems, so we need to mock it

# Generated at 2022-06-11 07:16:20.567428
# Unit test for function main
def test_main():
    import mock
    module = mock.Mock()

    # getent_bin = module.get_bin_path('getent', True)
    getent_bin = 'getent'

    # cmd = [getent_bin, 'passwd', 'root']
    cmd = [getent_bin, 'passwd']

    # rc, out, err = module.run_comma nd(cmd)
    rc = 0

# Generated at 2022-06-11 07:16:25.321673
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-11 07:16:34.898444
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),

    )
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(1, '',  ''))
    main()
    assert module.fail_json.called

# Generated at 2022-06-11 07:16:44.594867
# Unit test for function main
def test_main():
  class MockAnsibleModule(object):
    class RunCommandResult(object):
      def __init__(self, rc, stdout, stderr):
        self.rc = rc
        self.stdout = stdout
        self.stderr = stderr

    def __init__(self, params):
      self.params = params

    def fail_json(self, **kwargs):
      self.result = {'failed': True, 'msg': kwargs['msg']}

    def exit_json(self, **kwargs):
      self.result = {'failed': False}
      self.result.update(kwargs)

    def get_bin_path(self, prog, required):
      return './bin/' + prog

    def run_command(self, cmd):
      rc = 0


# Generated at 2022-06-11 07:16:45.222624
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:16:56.442442
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type = 'str', required = True),
            key = dict(type = 'str', no_log = False),
            service = dict(type = 'str'),
            split = dict(type = 'str'),
            fail_key = dict(type = 'bool', default = True)
        ),
        supports_check_mode = True
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-11 07:17:04.555409
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:08.987355
# Unit test for function main
def test_main():
    # Mock class to make a module function
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd):
            if cmd[0] == '/usr/bin/getent':
                if cmd[1] == 'passwd' and 'root' in cmd:
                    return 0, 'root:x:0:0:root:/root:/bin/bash\n', ''
                elif cmd[1] == 'passwd' and cmd[2] == 'root':
                    return 0, 'root:x:0:0:root:/root:/bin/bash\n', ''
                elif cmd[1] == 'group':
                    return 0, 'adm:x:4:syslog,bob\ngdm:x:112:root\n',

# Generated at 2022-06-11 07:17:19.956573
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-11 07:19:51.031032
# Unit test for function main
def test_main():

    # Tests argument_spec
    assert main.argument_spec == dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )

    # Tests supports_check_mode
    assert main.supports_check_mode

    # Tests colon
    assert colon == ['passwd', 'shadow', 'group', 'gshadow']

# Generated at 2022-06-11 07:19:57.664715
# Unit test for function main
def test_main():
    mock = {
        'run_command.return_value': (0, '1\n2\n3\n', None),
        'get_bin_path.return_value': 'getent',
        'params': {'database': 'passwd', 'key': 'root'}
    }

    with patch.multiple('ansible.module_utils.basic.AnsibleModule', **mock):
        rc, out, err = main()

    assert rc == 0
    assert out == {'ansible_facts': {'getent_passwd': {'1': ['2']}}}
    assert err is None

# Generated at 2022-06-11 07:20:00.567808
# Unit test for function main
def test_main():
    # no error
    content = dict(
        changed=False,
        ansible_facts=dict(
            getent_test_db=dict(some_key=['somedata', 'moredata']))
    )
    assert main() == content


# Generated at 2022-06-11 07:20:09.197942
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test = {
        'database': 'passwd',
        'key': 'root',
        'service': 'service',
        'split': 'split',
        'fail_key': True
    }
    module.params = test
    main()

# Generated at 2022-06-11 07:20:20.403495
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   