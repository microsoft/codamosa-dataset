

# Generated at 2022-06-11 07:10:52.188869
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rc = module.run_command(['getent', 'passwd', 'root'])
    assert rc == (0, 'root:x:0:0:root:/root:/bin/bash\\n', '')
    module.exit_json(msg='the function main has been tested')

# Generated at 2022-06-11 07:11:04.418955
# Unit test for function main
def test_main():
    class MockModule:
        def __init__(self):
            self.params = params
            self.check_mode = check_mode
            self.run_command = run_command
            self.fail_json = fail_json
            self.exit_json = exit_json
            self.get_bin_path = get_bin_path

        def run_command(self, cmd, check_rc=True):
            if cmd == ['getent', database, key]:
                return (rc, '', '')
            elif cmd == ['getent', database]:
                return (rc, out, '')
            else:
                return (1, 'Unexpected call to run_command', '')

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)


# Generated at 2022-06-11 07:11:15.541052
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_facts

    # key missing
    with pytest.raises(basic.AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['failed'] == False
    assert result.value.args[0]['ansible_facts']['getent_passwd']['root'][0] == 'x'
    assert result.value.args[0]['ansible_facts']['getent_passwd']['root'][2] == '0'

    # key found
    with pytest.raises(basic.AnsibleExitJson) as result:
        main(dict(database = 'passwd', key = 'root'))
    assert result.value

# Generated at 2022-06-11 07:11:27.960678
# Unit test for function main
def test_main():
    this_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    key_values = [
        'root',
        'ansible-detect',
        '-s',
    ]

    key_value = key_values[0]

    split_values = [
        ':',
        '\t',
        None,
        ''
    ]

    split_value = split_values[0]


# Generated at 2022-06-11 07:11:39.132504
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        instance = mock_module.return_value

        # Create a MagicMock to mock out the run_command() method.
        mock_run_command = mock_module.run_command = MagicMock(return_value=(0, '', ''))

        main()

        # Ensure run_command() was called with the proper keyword arguments.
        mock_run_command.assert_called_with(['/usr/bin/getent', 'passwd', 'root'])

        # Ensure the instance attributes were set properly.
        assert instance.exit_json.called
        assert instance.exit_json.call_args[0][0]["ansible_facts"]["getent_passwd"]["root"][0] == 'x'



# Generated at 2022-06-11 07:11:48.019321
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    # Mock module.run_command to fake the output and return code
    def test_run_command(cmd, cwd=None):
        if 'fail' in cmd:
            return 1, '', ''
        return 0, 'a:x:1:1:1:1:1\nb:x:2:2:2:2:2\nc:x:3:3:3:3:3', ''

    module.run_command = test_run_command

    results = main()


# Generated at 2022-06-11 07:11:58.276256
# Unit test for function main
def test_main():
    # Getent module basics
    args = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True,
    )
    res = dict(
        ansible_facts=dict(
            getent_passwd=dict(
                root=['0', '0', 'root', '/root', '/bin/bash'],
            ),
        ),
    )

    # getent module basics empty
    args = dict(
        database='passwd',
        key='noexist',
        split=':',
        fail_key=False,
    )

# Generated at 2022-06-11 07:12:02.612210
# Unit test for function main
def test_main():
    args = dict(database='passwd', key=None, split=None,
                fail_key=None)
    module = AnsibleModule(argument_spec=args)
    main()
    db = 'getent_passwd'
    assert db in module.ansible_facts
    assert isinstance(module.ansible_facts[db], dict)

# Generated at 2022-06-11 07:12:12.826697
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:12:13.470588
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:12:31.412017
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'database': 'passwd',
        'key': 'root',
        'split': ':'
    })
    class A:
        pass
    module.run_command=A()
    module.run_command.return_code=0
    module.run_command.stdout="root:x:0:0:root:/root:/bin/bash"
    if not main():
        raise AssertionError

# Generated at 2022-06-11 07:12:32.484844
# Unit test for function main
def test_main():
    import pytest
    print ('Test for getent functions')

# Generated at 2022-06-11 07:12:43.608105
# Unit test for function main
def test_main():
    ansible_dict = dict()
    ansible_dict['ANSIBLE_MODULE_ARGS'] = {'service':None,'database':'group','fail_key':True,'key':None,'split':' '}
    ansible_dict['ANSIBLE_MODULE_RETVALS'] = {'rc': 3, 'out': '', 'msg': 'Enumeration not supported on this database.', 'err': '', 'rc':3}


# Generated at 2022-06-11 07:12:54.732446
# Unit test for function main
def test_main():
    """ Check the validity of the output of the main function """
    class AnsibleModuleMock:
        """ Mocks the class AnsibleModule """
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.argument_spec["database"] = "passwd"
            self.argument_spec["key"] = "root"
            self.argument_spec["split"] = ":"

        def get_bin_path(self, name, required):
            return "getent"

        def run_command(self, command):
            return 0, "root:x:0:0:root:/root:/bin/bash\nbin:x:1:1:bin:/bin:/sbin/nologin", None


# Generated at 2022-06-11 07:13:06.202972
# Unit test for function main
def test_main():
    # module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True), key=dict(type='str', required=False), split=dict(type='str', required=False)))
    # rc, out, err = module.run_command(['getent', '-V'])
    # if rc == 0:
    #    rc, out, err = module.run_command(['getent', 'passwd', 'root'])
    #    module.exit_json(changed=False, meta={"out": out, "err": err, "rc": rc})
    test_dict = {
        'database': 'passwd',
        'key': 'root',
        'split': ':'
    }
    main(module_args=test_dict)

# Generated at 2022-06-11 07:13:06.823453
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:13:17.548474
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'database': {'type': 'str', 'required': True},
            'key': {'type': 'str', 'no_log': False},
            'split': {'type': 'str'},
            'fail_key': {'type': 'bool', 'default': True}
        },
        supports_check_mode=False,
    )

    # Mock cmd outputs

# Generated at 2022-06-11 07:13:28.406537
# Unit test for function main
def test_main():
    import json
    import os.path
    import subprocess
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    passwd_file = os.path.join(tmp_dir, 'passwd')
    group_file = os.path.join(tmp_dir, 'group')
    shadow_file = os.path.join(tmp_dir, 'shadow')
    gshadow_file = os.path.join(tmp_dir, 'gshadow')

    subprocess.check_call("getent passwd > '%s'" % passwd_file, shell=True)
    subprocess.check_call("getent group > '%s'" % group_file, shell=True)
    subprocess.check_call("getent shadow > '%s'" % shadow_file, shell=True)
   

# Generated at 2022-06-11 07:13:29.021545
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:13:35.067568
# Unit test for function main
def test_main():
    test_ansible_module = dict(
        database='passwd',
        key='root',
    )
    assert main(test_ansible_module) == dict(
        ansible_facts=dict(
            getent_passwd=dict(
                root=[
                    "x",
                    "0",
                    "0",
                    "root",
                    "/root",
                    "/bin/bash"
                ]
            ),
        )
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:14:10.028588
# Unit test for function main
def test_main():
    class args:
        database = 'passwd'
        key = None
        split = ':'
        service = None
        fail_key = True
    assert main(args)

# Generated at 2022-06-11 07:14:16.367185
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:14:25.482710
# Unit test for function main
def test_main():
    arg_msg = 'Missing required arguments!'
    argspec = dict(
        database=dict(type='str'),
        key=dict(type='str'),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    module = AnsibleModule(
        argument_spec=argspec,
        supports_check_mode=True,
    )

    if module.params['database'] is None:
        assert_msg(module.fail_json, arg_msg)

    assert_msg(module.exit_json, 'Unexpected failure!')

# Generated at 2022-06-11 07:14:26.692974
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-11 07:14:37.627846
# Unit test for function main
def test_main():
    # create the module object
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:14:46.788390
# Unit test for function main
def test_main():
#- name: Get root user info
#  getent:
#    database: passwd
#    key: root

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-11 07:14:47.444295
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:58.583305
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=True),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:15:06.251410
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:15:16.715036
# Unit test for function main
def test_main():
    args = {
        'database': 'passwd',
        'key': 'root',
    }

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
        ),
        supports_check_mode=True,
    )

    results = main()

    assert(results['ansible_facts']['getent_passwd']['root'])

    args['key'] = 'bob'

    results = main()

    assert(results['ansible_facts']['getent_passwd']['bob'])

    args['fail_key'] = False
    args['key'] = 'notreal'

    results = main()


# Generated at 2022-06-11 07:16:37.302865
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from mock import patch, MagicMock
    import ansible.module_utils.basic as basic

    # Set version numbers
    ansible_version = os.environ.get('ANSIBLE_VERSION', '2.7')
    module_version = os.environ.get('VERSION', '1.0.0')

    # Load requirements
    sys.path.insert(0, os.path.join(os.getcwd(), 'library/'))
    import getent

    # Set up requirements
    sys.modules['ansible.module_utils.basic'] = basic
    sys.modules['ansible.module_utils.basic.AnsibleModule'] = basic.AnsibleModule

# Generated at 2022-06-11 07:16:48.857382
# Unit test for function main
def test_main():
    import os
    import tempfile
    import time
    import pytest
    from contextlib import contextmanager

    from ansible import constants as C
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule

    @contextmanager
    def chdir(dirname):
        old_dir = os.getcwd()
        os.chdir(dirname)
        try:
            yield
        finally:
            os.chdir(old_dir)

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_bytes(args)

    def _touch(path):
        with open(path, 'a'):
            os.utime

# Generated at 2022-06-11 07:16:49.864926
# Unit test for function main
def test_main():
    assert False, "Need implemented"

# Generated at 2022-06-11 07:16:54.545488
# Unit test for function main
def test_main():
    import json
    import unittest

    module = AnsibleModule(database=dict(type='str', required=True), key=dict(type='str', no_log=False))
    module.exit_json = lambda x: True
    module.fail_json = lambda x: False
    module.run_command = lambda cmd, cwd=None, use_unsafe_shell=False, executable=None, data=None: True, json.dumps({dbtree: {key: "val"}}), ""

    main()

    module.run_command = lambda cmd, cwd=None, use_unsafe_shell=False, executable=None, data=None: False, "", ""
    main()



# Generated at 2022-06-11 07:17:03.543100
# Unit test for function main
def test_main():
    """
    Unit test for main function
    """
    import os
    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_file_name = "unit_test.tmp"
    test_root = tempfile.gettempdir()
    test_file_path = os.path.join(test_root, test_file_name)

    fd, fname = tempfile.mkstemp()
    os.write(fd, b"root:x:0:0:\nbin:x:1:1:\n")
    os.close(fd)

    test_defaults = {'ANSIBLE_GETENT_BIN': 'cat'}
    test_args = {'database': 'passwd', 'key': 'root'}

# Generated at 2022-06-11 07:17:14.836664
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:15.585192
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:17:24.725447
# Unit test for function main
def test_main():
    getent_passwd = {'root': ['x', 0, 0, 'root', '/root', '/bin/bash']}
    getent_group = {'root': ['x', 0, []]}
    getent_hosts = {'127.0.0.1': ['localhost', 'localhost.localdomain'],
                    '::1': ['ip6-localhost', 'ip6-loopback']}


# Generated at 2022-06-11 07:17:34.533839
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import crud

    db = crud.getentdb()

    passwd = db.get('passwd')
    myenv = { 'LANG': 'C' }

    rc, out, err = basic.run_command([passwd.path, passwd.db],
                                     data=passwd.data,
                                     binary_data=True,
                                     check_rc=True,
                                     environ_update=myenv)

    rc, out, err = basic.run_command([passwd.path, passwd.db, 'root'],
                                     data=passwd.data,
                                     binary_data=True,
                                     check_rc=True,
                                     environ_update=myenv)


# Generated at 2022-06-11 07:17:42.392974
# Unit test for function main
def test_main():
    import json
    import subprocess
    import sys
    #import pytest

    # check to make sure we don't get an exception (because of getent)
    # This fails on pytest 5.4.1. Workaround is to add exit_code=3 in ansible-test sanity --test unit
    #pytest.exit("Skipping test until pytest 5.4.2 is fixed")

    cmd = [sys.executable, '-m', 'ansible.modules.system.getent']
    cmd += ['database=passwd', 'key=root']

    pm = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = pm.communicate()
    out = json.loads(stdout)


# Generated at 2022-06-11 07:20:06.660413
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:20:18.098046
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        to_str = MagicMock()
        attrs = {'run_command.return_value': (0, '', ''),
                 'get_bin_path.return_value': to_str}
        module = AnsibleModule(argument_spec=dict(database=dict(type='str'),
                                                  key=dict(type='str'),
                                                  service=dict(type='str'),
                                                  split=dict(type='str'),
                                                  fail_key=dict(type='bool')),
                               supports_check_mode=True)
        with patch.multiple(module, **attrs):
            main()

    assert result.value.args[0]['ansible_facts']['getent_database'] == {}

# Generated at 2022-06-11 07:20:20.320471
# Unit test for function main
def test_main():
    import sys
    import getent
    reload(sys)
    sys.setdefaultencoding('utf-8')
    getent.main()

# Generated at 2022-06-11 07:20:27.480495
# Unit test for function main
def test_main():
    getent_main_test1 = {
        "ansible_module_args": {
            "database": "passwd",
            "key": "test-user",
        },
        "file_exists": True,
        "file_exists_path": "/usr/bin/getent",
        "run_command_rc": 0,
        "run_command_stdout": "test-user:x:1004:1004:test user,,,:/home/test-user:/bin/bash\n",
        "run_command_stderr": "",
    }

    expected_result = {"ansible_facts": {"getent_passwd": {"test-user": ["x", "1004", "1004", "test user,,,", "/home/test-user", "/bin/bash"]}}}

    results = main_for