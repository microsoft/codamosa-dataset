

# Generated at 2022-06-11 07:10:50.430649
# Unit test for function main
def test_main():
    import os
    import tempfile

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    with tempfile.NamedTemporaryFile() as module_getent:
        # add some example service records
        with open(module_getent.name, "w") as fp:
            fp.write("\n")
            fp.write("# comment line\n")
            fp.write("http          80/tcp                    www            # World Wide Web HTTP\n")
            fp.write("\n")


# Generated at 2022-06-11 07:10:51.498582
# Unit test for function main
def test_main():
    print("test_test")

test_main()

# Generated at 2022-06-11 07:11:03.537425
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:11:04.314371
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:15.464504
# Unit test for function main
def test_main():
    import sys
    import ansible.module_utils._text as text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest

    def execute_module():
        sys.argv = ['/bin/ansible-test', 'getent', 'database=passwd', 'key=root']
        module = AnsibleModule(argument_spec={
            'database': {'required': True, },
            'key': {},
            'split': {},
            'fail_key': {'default': True, }
        }, supports_check_mode=True, )
        return module

    ##########################################
    # getent import tests
    ##########################################


# Generated at 2022-06-11 07:11:27.873053
# Unit test for function main
def test_main():
    module_name = 'getent'
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin

# Generated at 2022-06-11 07:11:34.191162
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    params = {"database": "services"}
    main()


# Generated at 2022-06-11 07:11:45.260477
# Unit test for function main
def test_main():
  from unittest import TestCase
  # an actual object is returned and cannot be compared exactly
  # this should be improved in Ansible
  class Result(object):
    def __eq__(self, other):
      return self.__dict__ == other.__dict__

  class AnsibleModuleMock(AnsibleModule):
    def __init__(self):
      self.params = {
        'database': 'group',
        'key': 'root',
        'fail_key': True,
      }
      self.result = Result()
      self.fail_json = lambda msg : msg

    def get_bin_path(self, executable, required=True, opt_dirs=[]):
      return '/usr/bin/getent'


# Generated at 2022-06-11 07:11:56.039939
# Unit test for function main
def test_main():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from units.modules.utils import set_module_args
    from units.modules.getent import main
    from ansible.module_utils import basic

    m = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:11:56.939851
# Unit test for function main
def test_main():
    main()
    main()
    main()

# Generated at 2022-06-11 07:12:16.429464
# Unit test for function main
def test_main():
    print("starting test")
    getent_bin = module.get_bin_path('getent', True)
    print("getent_bin = ", getent_bin)
    cmd = [getent_bin, 'services']
    print("cmd = ", cmd)
    rc, out, err = module.run_command(cmd)
    print("rc = ", rc)
    print("out = ", out)
    print("err = ", err)
    print("Finished test")

# Generated at 2022-06-11 07:12:27.759775
# Unit test for function main
def test_main():
    getent_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'getent')
    with open(getent_path, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('cat "$0"\n')
        f.write('echo "NO_SUCH_VALUE: just: some: garbage: data"\n')
        f.write('echo "FIRST_VALUE: this is: some: more: garbage: data"\n')
        f.write('echo "FIRST_VALUE: this is: another: line: of: garbage: data"\n')
        f.write('echo "SECOND_VALUE: this is: the: second: line: of: data"\n')

# Generated at 2022-06-11 07:12:36.412137
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.getent import main
    from ansible.module_utils.basic import AnsibleModule, to_bytes
    data = '''foo:x:1234:1234:Foo Bar:/baz:/bin/baz
bar:x:4321:4321:Bar Baz:/baz:/bin/baz
'''
    module = AnsibleModule(dict(database='test', split=':'))
    module.run_command = lambda cmd, data=None: (0, data, '')
    main()
    r = module.exit_json.call_args[0][0]
    print(r, type(r))
    assert type(r['ansible_facts']['getent_test']) is dict

# Generated at 2022-06-11 07:12:47.954519
# Unit test for function main
def test_main():
    import contextlib
    import os
    import sys

    # simulate arguments for the module
    sys.argv = [sys.argv[0], "--database", "group", "--key", "root"]

    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleFake(AnsibleModule):
        '''AnsibleModule mock.
        '''

        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False, required_if=None, required_by=None,
                     aliases=None,
                     **kwargs
                     ):
            self

# Generated at 2022-06-11 07:12:53.185075
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_getent_module as getent
    import sys
    sys.modules['ansible'] = None
    sys.modules['ansible.module_utils.ansible_getent_module'] = None
    sys.modules['ansible.module_utils.facts'] = None
    getent.main()

# Generated at 2022-06-11 07:13:04.289995
# Unit test for function main
def test_main():
    import os
    import pwd
    import tempfile
    import textwrap
    import pytest
    import os.path as path
    from test.support import EnvironmentVarGuard
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    tmp_dir = tempfile.gettempdir()
    tmp_file = os.path.join(tmp_dir, 'getent_test.txt')
    tmp_file_b = path.join(tmp_dir, b'getent_test.txt')


# Generated at 2022-06-11 07:13:12.662879
# Unit test for function main
def test_main():
    os.chdir(HERE)
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-11 07:13:24.617786
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:13:29.871358
# Unit test for function main
def test_main():
    # It's too hard to test run_command with mocks
    # We'll just do the parts of main() that are easy to test
    # and leave the hard stuff for an integration test.

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main_result = main()

# Generated at 2022-06-11 07:13:38.266952
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:14:21.356770
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-11 07:14:22.125303
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:14:23.268416
# Unit test for function main

# Generated at 2022-06-11 07:14:23.951371
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:35.006382
# Unit test for function main
def test_main():
    from ansible.module_utils.command import ansible_posix_command_mock
    from ansible.module_utils import basic


# Generated at 2022-06-11 07:14:45.042019
# Unit test for function main

# Generated at 2022-06-11 07:14:55.796784
# Unit test for function main
def test_main():

    # Test database not supported
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = 'nosuchthing'
    key = None
    split = None
    service = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]


# Generated at 2022-06-11 07:15:04.795675
# Unit test for function main
def test_main():
    import sys
    sys.modules['ansible.module_utils.basic'] = __import__('ansible.module_utils.basic')
    sys.modules['ansible.module_utils.facts'] = __import__('ansible.module_utils.facts')
    sys.modules['ansible.module_utils._text'] = __import__('ansible.module_utils._text')

    class AnsibleModuleFake(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

        def run_command(self, cmd):
            return (0, '1:x:0:\nfakeuser:x:1000:\n', '')

        def get_bin_path(self, cmd, required=False):
            return '/bin/%s'

# Generated at 2022-06-11 07:15:05.395963
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:15:15.713188
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:16:23.446116
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:16:31.162695
# Unit test for function main
def test_main():
    import json
    import socket
    import os.path

    test_dir = os.path.dirname(os.path.abspath(__file__))
    module_utils_path = os.path.join(test_dir, '../../')
    module_utils_path = os.path.abspath(module_utils_path)
    module_path = os.path.abspath(os.path.join(test_dir, '../'))

    getent_bin = '/usr/bin/getent'

    facts_path = os.path.join(test_dir, '../../ansible_collections/ansible_local/plugins/modules/action')
    facts_path = os.path.abspath(facts_path)

    m_name = 'action'


# Generated at 2022-06-11 07:16:39.661159
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = MagicMock(return_value=(0, '', ''))

    main()
    module.run_command.assert_any_call(['getent', 'passwd', 'root'])

# Generated at 2022-06-11 07:16:41.193106
# Unit test for function main
def test_main():
    test_module.exit_json(changed=True)

# Generated at 2022-06-11 07:16:52.442874
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.pycompat24 import get_exception

    from ansible.compat.tests import unittest

    test_data = """# TEST DATA
root:x:0:0:root:/root:/bin/bash
mail:*:8:12:mail:/var/spool/mail:/bin/sh
postfix:*:89:89::/var/spool/postfix:/bin/false
nobody:*:99:99:Unprivileged User:/var/empty:/bin/false
"""

    test_data = StringIO(test_data)


# Generated at 2022-06-11 07:16:57.597059
# Unit test for function main
def test_main():
    import os
    import sys
    import json
    import tempfile
    try:
        from unittest import mock
    except ImportError:
        import mock


# Generated at 2022-06-11 07:17:02.686311
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    assert main() == 1

# Generated at 2022-06-11 07:17:03.435403
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:17:06.682484
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    getent_bin = ansible.module_utils.basic.AnsibleModule.get_bin_path('getent', True)

    assert getent_bin != None

# Generated at 2022-06-11 07:17:18.040768
# Unit test for function main
def test_main():
    '''
    Test module.

    functions: main

    '''

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'root'
    split = ':'
    service = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:19:56.961880
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = "ansible_test"
    key = "test_key"
    service = "test_service"
    split = "test_split"
    fail_key = False
    results = {
        database: {
            "test_key": ["key1", "key2"]
        }
    }

    rc = 0
    out = "test_key:key1:key2"

# Generated at 2022-06-11 07:20:05.859438
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.collector import get_file_lines
    from ansible.module_utils.facts.collector import strip_comments
    from ansible.module_utils.facts.collector import strip_empty_lines
    import json
    res = {}
    def exit_json(*args, **kwargs):
        res['changed'] = False
        res['ansible_facts'] = kwargs['ansible_facts']
        return json.dumps(res)
    def fail_json(*args, **kwargs): res['failed'] = True
    def run_command(*args, **kwargs): return 0, b'foo bar', b''

# Generated at 2022-06-11 07:20:17.357713
# Unit test for function main
def test_main():
    os.environ['PATH'] = os.pathsep.join((os.environ['_ANSIBLE_TEST_GETENT_PATH'], os.environ['PATH']))

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = None
    split = ':'
    service = None
    fail_key = True


# Generated at 2022-06-11 07:20:25.917003
# Unit test for function main
def test_main():
    # The following test case will fail
    # To run the test case you need to install mock:
    # $ pip install mock
    # In the project directory you can run the test case:
    # $ python -m pytest
    import mock
    import os

    test_mock = {
        'database': 'passwd',
        'key': 'root'
    }
    with mock.patch.object(os.path, 'exists') as mock_method:
        mock_method.return_value = True
        with mock.patch.object(os, 'access') as mock_access:
            mock_access.return_value = True
            with mock.patch.object(os, 'getuid') as mock_getuid:
                mock_getuid.return_value = 0