

# Generated at 2022-06-11 07:10:49.260526
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split = ':'


# Generated at 2022-06-11 07:11:00.732640
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import action
    import json

    class AnsibleExitJson(Exception):
        def __init__(self, value):
            self.value = value

    mod = action.ActionModule(argument_spec={'database': dict(type='str', required=True),
                                             'key': dict(type='str', no_log=False),
                                             'service': dict(type='str'),
                                             'split': dict(type='str'),
                                             'fail_key': dict(type='bool', default=True)}, supports_check_mode=True)
    mod.exit_json = lambda a: AnsibleExitJson(a)

# Generated at 2022-06-11 07:11:12.537737
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:11:13.113162
# Unit test for function main
def test_main():
    import sys
    sys.exit(main())

# Generated at 2022-06-11 07:11:25.069808
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str', default='root'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:11:32.476968
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys

    if sys.version_info[:2] != (2, 6):
        pytestmark = pytest.mark.skip("getent is not supported on python3")

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
       

# Generated at 2022-06-11 07:11:44.066892
# Unit test for function main
def test_main():
    import datetime
    import os
    import time
    import mock
    import ansible.utils
    from ansible.module_utils import basic
    from ansible.module_utils.facts import containing_dir
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get

# Generated at 2022-06-11 07:11:49.137357
# Unit test for function main
def test_main():
    # Test with no options
    test_data = dict(
        database='passwd',
        fail_key=True,
        key=None,
        split=":",
    )
    module = AnsibleModule(argument_spec=test_data)
    module.params = test_data
    main()


# pylama:ignore=W0401,W0614

# Generated at 2022-06-11 07:11:58.707805
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-11 07:12:08.511264
# Unit test for function main
def test_main():
    import ansible.module_utils.common.process
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import PY3

    ansible_version = __version__

    getent_bin = ansible.module_utils.common.process.get_bin_path('getent')
    assert getent_bin is not None
    assert "/usr/bin/getent" in getent_bin

    # Test getent passwd
    out = ansible.module_utils.basic.run_command([getent_bin, "passwd", "root"], check_rc=True)
    if PY3:
        assert out == "0:\nroot:x:0:0:root:/root:/bin/bash\n"

# Generated at 2022-06-11 07:12:31.166925
# Unit test for function main
def test_main():
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule

    # TODO: add tests for most known errors and corner cases
    tmp_file = tempfile.NamedTemporaryFile(mode='w+', delete=False)
    tmp_file.write('test1:1\ntest2:2\ntest3:3')
    tmp_file.close()

    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True)

    module.params['database'] = os.path.basename(tmp_file.name)

# Generated at 2022-06-11 07:12:42.148985
# Unit test for function main
def test_main():
    mock_unix_command = Mock(return_value=(0, 'output', 'error'))
    with patch.multiple(
        'ansible.module_utils.basic',
        get_bin_path=DEFAULT,
        run_command=mock_unix_command,
    ):
        module = Mock()
        module.params = {
            'database': 'passwd',
            'key': 'root',
            'split': None,
            'fail_key': True,
        }
        dbtree = 'getent_%s' % module.params['database']
        module.exit_json = Mock()
        module.fail_json = Mock()
        main()
        assert dbtree not in module.exit_json.call_args_list[0][1]['ansible_facts']

# Generated at 2022-06-11 07:12:43.713906
# Unit test for function main
def test_main():
    try:
        pass
    except Exception as e:
        raise e


# Generated at 2022-06-11 07:12:54.806598
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    print(test_main.__doc__)
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-11 07:12:56.713294
# Unit test for function main
def test_main():
    declare_module()
    result = main()
    assert 'ansible_facts' in result


# Generated at 2022-06-11 07:13:08.289006
# Unit test for function main
def test_main():
    import textwrap
    import shutil
    import tempfile
    import platform
    import subprocess
    import os
    import sys

    # test defaults
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import dictpath

    getent_bin = shutil.which('getent')

    if not getent_bin:
        raise Exception("could not find getent")

    def test_get(database, key=None, split=None, service=None, fail_key=False):
        '''
        Runs the module to fetch a given database, return result if successfull
        '''
        test_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 07:13:19.684759
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import os

    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type = 'str', required = True),
            key = dict(type = 'str', no_log = False),
            split = dict(type = 'str'),
            fail_key = dict(type = 'bool', default = True),
        ),
        supports_check_mode = True
    )

    try:
        getent_bin = get_bin_path('getent', required=True)
    except ValueError as e:
        return dict(
            failed = True,
            msg = "Error: getent binary not found"
        )

    database = module.params['database']
   

# Generated at 2022-06-11 07:13:30.329621
# Unit test for function main
def test_main():
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    path = tempfile.gettempdir()
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-11 07:13:38.551879
# Unit test for function main

# Generated at 2022-06-11 07:13:43.200042
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-11 07:14:12.018832
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
    )
    getent_bin = get_bin_path('getent')
    if getent_bin:
        module.run_command = basic.run_command
        module.get_bin_path = basic.get_bin_path
        main()
    else:
        module.exit_json(skipped=True, msg='getent not installed')

# Generated at 2022-06-11 07:14:22.637016
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    import types
    import os
    test_module.get_bin_path = types.MethodType(lambda s, x, y: os.path.dirname(__file__) + '/../../../../bin/getent',
                                                test_module)

    exit_json = test_module.exit_json
    fail_json = test_module.fail_json

    # Make sure no failure on missing key
   

# Generated at 2022-06-11 07:14:33.898600
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import EnvironmentConfig, module_common
    from ansible.module_utils import action_common
    from ansible.module_utils.action.core import ActionModule

    config = EnvironmentConfig()
    config.module_name = 'getent'
    config.module_args = dict(database='passwd')

    # we need to fake the module parse args to avoid calling the parser
    def fake_parse_arguments():
        class obj(object):
            pass
        return obj()

    class fake_module(object):
        """Fake module to return facts"""
        def __init__(self):
            self.params = dict(database='passwd')
            self.check_mode = False
            self.exit_json = lambda x: print(x)

# Generated at 2022-06-11 07:14:39.122895
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False)
        ),
        supports_check_mode=True
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    main()

# Generated at 2022-06-11 07:14:47.682523
# Unit test for function main
def test_main():
    # Create the module object
    set_module_args(dict(
        database='database_test',
    ))
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Create a class mock object
    getent_bin_mock = Mock(return_value='/path/to/getent')
    # Override the get_bin_path method
    module.get_bin_path = getent_bin_mock
    # Create another class mock object
    run_command

# Generated at 2022-06-11 07:14:58.723807
# Unit test for function main
def test_main():
    mock_args = {
        "database": "passwd",
        "check_mode": False,
        "diff_mode": False,
        "key": None,
        "service": None,
        "split": None,
        "fail_key": True,
        "_ansible_diff": False,
        "_ansible_debug": False,
        "_ansible_verbosity": 0,
    }

    def run_command_mock(cmd, module):
        if cmd == ['getent', 'passwd']:
            output = 'root:x:0:0:root:/root:/bin/bash\n'
            return 0, output, ""
        else:
            raise AssertionError('unexpected run_command invocation: '
                                 'expected="%s", actual="%s"' % ('getent passwd', cmd))

# Generated at 2022-06-11 07:15:06.298295
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    results = main()

    #assert results['args']['database'] == 'passwd'
    #assert results['ansible_facts']['getent_passwd']['root'][0] == 'x'

    assert results['ansible_facts']['getent_passwd']['root'][0] == 'x'
    assert results['ansible_facts']['getent_passwd']['root'][2] == '0'


# Generated at 2022-06-11 07:15:06.875582
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:15:17.285641
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.common._collections_compat as collections
    import sys

    # create a fake module object
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    results = {}

    # set module args
    module.params = {}
    module.params['database'] = 'testdb'
    module.params['key'] = 'key'
    module.params['service'] = ''
   

# Generated at 2022-06-11 07:15:21.652703
# Unit test for function main
def test_main():
    # Check simple invocation
    assert main() == "It Works!"

    ## Check invocation with options:
    #assert main(['--verbose']) == 'It Works!\nOption: Verbose'
    #assert main(['--verbose', '--option2']) == 'It Works!\nOption: Verbose\nOption: Option2'

# Generated at 2022-06-11 07:16:06.906832
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')
    
    getent_bin = module.get_bin_path('getent', True)
    

# Generated at 2022-06-11 07:16:11.784719
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['ansible_facts']['getent_passwd'] == dict
    assert result.value.args[0]['ansible_facts']['getent_group'] == dict
    assert result.value.args[0]['ansible_facts']['getent_hosts'] == dict

# Generated at 2022-06-11 07:16:21.270563
# Unit test for function main
def test_main():
    import sys
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from getent import main

    def execute_module(module):
        basic._ANSIBLE_ARGS = to_bytes('')
        setattr(basic, 'USE_PERSISTENT_CONNECTION', False)
        setattr(basic, 'DEFAULT_LOCAL_TMP', to_bytes('/tmp'))
        setattr(basic, 'HAS_ATTRIBUTE_HAS_PERSISTENT_CONNECTION', True)
        setattr(basic._AnsibleModule, '_load_params', lambda x: x)

        return basic

# Generated at 2022-06-11 07:16:21.826407
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:30.259259
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    get

# Generated at 2022-06-11 07:16:40.160993
# Unit test for function main
def test_main():
    from ansible.module_utils.facts import ansible_facts

    # Remove facts from memory, if any
    for key in list(ansible_facts.keys()):
        if key.startswith("getent_"):
            del ansible_facts[key]

    #
    # Calls to main()
    #
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params = {
        'database': 'passwd',
        'key': 'root'
    }
    main()

# Generated at 2022-06-11 07:16:51.767856
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule, _load_params
    sys.modules["ansible_module_getent"] = sys.modules["__main__"]


# Generated at 2022-06-11 07:16:52.448228
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:55.106420
# Unit test for function main
def test_main():
    test_dict = dict(
        database='passwd',
        key='root',
        split='\n',
        )
    test_main(test_dict)

# Generated at 2022-06-11 07:17:03.875883
# Unit test for function main
def test_main():
    from ansible.module_utils.six import PY2
    import sys

    # Python 2
    if PY2:
        module_utils = {
            "run_command.run_command":
            lambda module, cmd, check=True, binary_data=True, environ_update=None, cwd=None, use_unsafe_shell=None,
            encoding=None, errors=None, data=None, binary_data=False,
            path_prefix=None: ["passwd:x:123:123:,,,:/tmp:/usr/bin/python","group:x:123:group"],
        }

# Generated at 2022-06-11 07:18:07.437779
# Unit test for function main
def test_main():
    '''
    Unit test for the main function.
    '''
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Assume that the module is correctly initialized with all arguments provided.
    # Simple return when in check mode:
    if module.check_mode:
        module.exit_json(changed=False)

    # Call the main function:
    main()

# Generated at 2022-06-11 07:18:14.998575
# Unit test for function main
def test_main():
    # Mock class for args
    class Args():
        fail_key = True
        split = None
        service = None
        key = None
        database = None

    args = Args()

    # Mock class for module parameter
    class Module():
        argument_spec = None
        check_mode = False
        def get_bin_path(self, arg, arg2):
            return 'getent'

# Generated at 2022-06-11 07:18:22.140795
# Unit test for function main
def test_main():
    # pylint: disable=protected-access
    module_patch = mock.patch.multiple(basic.AnsibleModule, run_command=mock.DEFAULT,
                                       get_bin_path=mock.DEFAULT)
    module_mock = module_patch.start()
    module_mock['get_bin_path'].return_value = 'getent'
    module_mock['run_command'].return_value = (0, 'test1:1:1\ntest2:2:2', None)
    # pylint: disable=unused-variable
    # skipcq: BAN-B404
    from ansible.modules.system import getent
    getent.main()
    getent.main.exit_json.assert_called()
    module_patch.stop()

    module_patch

# Generated at 2022-06-11 07:18:25.982485
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    module.params['split'] = None
    module.run_command = MagicMock(return_value=(0, 'root:x:0:0:root:/root:/bin/bash', None))
    main()


# Generated at 2022-06-11 07:18:26.437738
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:18:35.398554
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import get_exception

    # Test fail_json
    def fail_json(*args, **kwargs):
        module.exit_json(changed=False)

    # Test get_bin_path
    def get_bin_path(*args, **kwargs):
        return '/bin/getent'

    # Test load_platform_subclass
    def load_platform_subclass(*args, **kwargs):
        return None

    # Test run_command
    def run_command(*args, **kwargs):
        return 0, '', ''

    # Test import_module
    def import_module(*args, **kwargs):
        return None

    # Test add_path

# Generated at 2022-06-11 07:18:42.795987
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    dbtree = {'group': {'root': ['daemon', 'root']}, 'services': {'root': ['daemon', 'root']}}
    try:
        assert(dbtree == main())
    except Exception as e:
        print(e)

# Generated at 2022-06-11 07:18:50.847110
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main

    import os
    import tempfile

    def test_main_domain():
        test_hosts = os.path.join(tempfile.mkdtemp(), 'hosts')
        with open(test_hosts, 'w') as f:
            f.write("""
# This is an /etc/hosts-like file with only one host in it.
127.0.0.1 localhost
""")


# Generated at 2022-06-11 07:18:51.561390
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-11 07:18:54.291449
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'state': {'required': False, 'choices': ['present'], 'type': 'str'}})
    rc, out, err = main()