

# Generated at 2022-06-11 07:10:52.491527
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    import ansible.module_utils.action
    from ansible.module_utils.action import AnsibleActionFail
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts._common

    def _run_command(self, cmd, tmp_path, encode_errors='strict', check_rc=True, executable=None):
        results = {}
        results['rc'] = 0
        results['stdout'] = ''
        results['stderr'] = ''
        results['start'] = ''
        results['end'] = ''
        results['delta'] = ''
        results['cmd'] = ['/bin/false']
        results['stdin'] = ''

# Generated at 2022-06-11 07:11:04.805653
# Unit test for function main
def test_main():
    import imp
    module = imp.load_source('getent_module', 'getent')
    from ansible.module_utils.basic import AnsibleModule

    class MyModule(AnsibleModule):

        def run_command(self, cmd):
            return 0, 'root:x:0:0:root:/root:/bin/bash\nwww-data:x:33:33:www-data:/var/www:/bin/sh\n', ''

    sample = MyModule({
        'database': 'passwd',
        'split': ':'
    }, check_mode=True)

    try:
        module.main()
    except SystemExit as e:
        if e.args[0] == 0:
            print('%s: SUCCESS' % __file__)
        else:
            raise

    return

# Generated at 2022-06-11 07:11:15.822454
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:11:28.130997
# Unit test for function main
def test_main():
    # Import the module, and use mock.MagicMock to mock out AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import map

    # Create a MagicMock object and save it as AnsibleModule

# Generated at 2022-06-11 07:11:33.984867
# Unit test for function main
def test_main():
    import getent

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    assert getent.main()

# Generated at 2022-06-11 07:11:45.144912
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:11:45.686841
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:11:56.507398
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:12:06.252568
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'database': dict(type='str', required=True),
            'key': dict(type='str', no_log=False),
            'service': dict(type='str'),
            'split': dict(type='str'),
            'fail_key': dict(type='bool', default=True)
        },
        supports_check_mode=True
    )
    from ansible.module_utils._text import to_native
    import traceback

    # fakestdin, fakestdout, fakestderr = StringIO(), StringIO(), StringIO()
    # sys.stdin, sys.stdout, sys.stderr = fakestdin, fakestdout, fakestderr
    # try:
    #     main()
    #

# Generated at 2022-06-11 07:12:16.692119
# Unit test for function main
def test_main():
    import os
    import shutil

    # Change current directory to the test dir
    test_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(test_dir)

    # Our test directory will be in test/test_dir
    test_dir = 'test/test_dir'

    # Create test dir
    os.makedirs(test_dir)

    # Add a backup marker, so we can later restore the config file
    shutil.copy2('../../../lib/ansible/module_utils/facts/system/getent.py', test_dir + '/getent_backup.py')

    # Copy necessary files to our test dir
    shutil.copy2('__init__.py', test_dir + '/__init__.py')

# Generated at 2022-06-11 07:12:39.979431
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split = ':'



# Generated at 2022-06-11 07:12:41.191932
# Unit test for function main
def test_main():
    assert None == main("Fail - No params")

# Generated at 2022-06-11 07:12:52.835221
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    import re

    current_path = os.path.realpath(os.path.dirname(__file__))
    sys.path.append(os.path.join(current_path, '../..'))

    # mock the args
    args = json.loads("""
        {
            "check_mode": false,
            "database": "passwd",
            "key": "",
            "service": "",
            "split": null
        }
    """)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback

    d = sys.modules.copy()
    d.update(locals())
    module = AnsibleModule(**args)
    d['module'] = module

    # install the

# Generated at 2022-06-11 07:13:03.704961
# Unit test for function main
def test_main():
    database = 'passwd'
    key = 'root'
    split = ':'
    fail_key = True
    getent_bin = ''

    cmd = [getent_bin, database, key]

    if database in colon:
        split = ':'

    try:
        rc, out, err = module.run_command(cmd)
    except Exception as e:
        module.fail_json(msg=to_native(e), exception=traceback.format_exc())

    msg = "Unexpected failure!"
    dbtree = 'getent_%s' % database
    results = {dbtree: {}}

    if rc == 0:
        seen = {}
        for line in out.splitlines():
            record = line.split(split)


# Generated at 2022-06-11 07:13:12.376627
# Unit test for function main
def test_main():
    # Swap out for mock version of the module
    from ansible.modules.system.getent import main as mock_main
    from ansible.modules.system.getent import AnsibleModule as mock_AnsibleModule
    from ansible.module_utils.basic import AnsibleModule as mock_AnsibleModule_basic
    import sys

    class AnsibleFailJson(Exception):
        pass

    class ModuleTestException(Exception):
        pass

    m_AnsibleModule_basic = mock_AnsibleModule_basic
    m_AnsibleModule = mock_AnsibleModule
    m_AnsibleFailJson = AnsibleFailJson
    m_ModuleTestException = ModuleTestException

    def mock_exit_json(*args, **kwargs):
        raise m_AnsibleFailJson(args, kwargs)

# Generated at 2022-06-11 07:13:24.165408
# Unit test for function main
def test_main():
    import ast
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'root'
    split = ':'
    service = None
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-11 07:13:30.595952
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:13:32.049237
# Unit test for function main
def test_main():
    assert 'ansible_facts' in main(dict(mock_module='yes'))

# Generated at 2022-06-11 07:13:32.640209
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:13:34.903624
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)
    assert os.path.exists(getent_bin)


# Generated at 2022-06-11 07:14:15.517898
# Unit test for function main
def test_main():

    # We need to pretend to be a system that has getent
    getent_bin = '/usr/bin/getent'
    modules_args = {
        'getent_bin': getent_bin,
        'state': 'present',
        'database': 'group',
        'key': 'root',
        'split': ':',
        'service': None,
        'fail_key': True
    }
    # Set up dummy module class to pass in
    class DummyModule(object):
        """Class to pass in instead of AnsibleModule"""
        def __init__(self, modules_args):
            self.params = modules_args
        def fail_json(self, **kwargs):
            """fail_json is called when a module fails"""
            print(kwargs)
            self.fail_args = kwargs


# Generated at 2022-06-11 07:14:24.597998
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    m.params['database'] = 'passwd'
    m.params['key'] = None
    m.params['split'] = ':'
    m.params['service'] = None
    m.params['fail_key'] = True

    main()

# Generated at 2022-06-11 07:14:35.662006
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native

    mod = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    res = {}
    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = mod.params['database']
    key = mod.params.get('key')

# Generated at 2022-06-11 07:14:45.474444
# Unit test for function main
def test_main():
    # mock out main function

    main = my_main

    # create instance of the module, as it would be ran by Ansible
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True, choices=['passwd', 'shadow']),
            key=dict(type='str', required=False, default='root'),
            split=dict(type='str', required=False, default=':'),
        ),
        supports_check_mode=True,
    )

    # mock out the return values from calling module.run_command
    module.run_command = my_run_command

    # call the main function
    main()


# This function is called in place of main() when using unit tests. Code
# coverage will not work in this mode.

# Generated at 2022-06-11 07:14:48.442253
# Unit test for function main
def test_main():
    args = (
        dict(
            database='passwd',
            key='root',
        ),
    )
    for arg in args:
        module = AnsibleModule(**arg)
        assert main(module) == None

# Generated at 2022-06-11 07:14:59.634183
# Unit test for function main
def test_main():

    module_class = getent_wrapper

    #  mock module input parameters
    # args = {'database': 'passwd', 'key': 'root', 'fail_key': True, 'split': None, 'service': None}
    args = {'database': 'passwd', 'key': 'root', 'fail_key': True, 'split': ':', 'service': None}


    #  mocking module
    mock_module = mocker.MagicMock(spec=AnsibleModule)
    mock_module.params = args

    #  mocking run_command
    mock_run_command = mocker.MagicMock(return_value=(0, 'root:x:0:0:root:/root:/bin/bash', ''))
    mock_module.run_command = mock_run_command

    #  mocking module.exit_json


# Generated at 2022-06-11 07:15:01.865595
# Unit test for function main
def test_main():
    (rc, out, err) = main()
    assert rc == 1
    assert out == None, out
    assert err == None, err

# Generated at 2022-06-11 07:15:12.310469
# Unit test for function main
def test_main():
    #Test with invalid database
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module_params = {
        'database': 'invalid_database',
        'key': None,
        'service': None,
        'split': None,
        'fail_key': True
    }
    module.params = module_params
    try:
        main()
    except SystemExit as e:
        assert(e.code == 1)

    # Test with invalid key

# Generated at 2022-06-11 07:15:18.868931
# Unit test for function main
def test_main():
    args = dict(
        database='passwd',
        key=None,
        split=':',
        fail_key=False,
    )
    module = AnsibleModule(
        argument_spec=args,
    )
    try:
        main()
    except SystemExit as e:
        assert e.code == 0
    except Exception as e:
        print("Unexpected Exception: %s" % e)
        raise
    else:
        print("No exception raised")
    finally:
        module = None

# Generated at 2022-06-11 07:15:22.406668
# Unit test for function main

# Generated at 2022-06-11 07:16:39.062905
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest

    sys.path.append(os.path.dirname(__file__) + "/../lib")
    sys.argv[1:] = [ '-m', 'getent', 'dummy', 'passwd' ]
    del os.environ['ANSIBLE_LIBRARY']
    del os.environ['ANSIBLE_MODULE_UTILS']
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str', no_log=False),
            service = dict(type='str'),
            split = dict(type='str'),
            fail_key = dict(type='bool', default=True),
        ),
        supports_check_mode = True,
    )

# Generated at 2022-06-11 07:16:50.826223
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import copy
    import os
    import shutil
    import stat
    import tempfile
    import textwrap

    def _execute_module(module, params, is_idempotent=True):
        tmpdir = tempfile.mkdtemp(dir=os.environ.get('TEST_TMPDIR', None))
        curr_dir = os.getcwd()
        os.chdir(tmpdir)
        f, p, descr = basic._load_params(params)

        # ensure we clean up after
        old_path = os.environ['PATH']
        old_ansible_module_generated_dir = os.environ.get('ANSIBLE_MODULE_GENERATED_DIR', None)



# Generated at 2022-06-11 07:16:56.098065
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    args = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    module = basic.AnsibleModule(
        argument_spec=args,
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

   

# Generated at 2022-06-11 07:17:04.386081
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "database": "passwd",
        "key": "root",
        "split": None,
        "service": None,
        "fail_key": True
    })
    rc = 0
    out = 'root:x:0:0:root:/root:/bin/bash'
    err = ''
    module.run_command = MagicMock(return_value=(rc, out, err))
    results = main()
    module.exit_json.assert_called_with(ansible_facts={'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}})

# Generated at 2022-06-11 07:17:15.860031
# Unit test for function main

# Generated at 2022-06-11 07:17:16.484489
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:17:17.147552
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:17:25.596370
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'testuser'
    split = ':'
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-11 07:17:35.167604
# Unit test for function main
def test_main():
    '''
    getent module function unit tests
    '''

    # Mock the options and arguments used in the actual module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the function, that runs the module code, so we can run it independently
    # and cause it to return it's results
    def run_module():
        module.run_command = lambda cmd: (0, 'key:value\nkey2:value2', None)
        module.get_bin_

# Generated at 2022-06-11 07:17:42.786448
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    from ansible.utils.color import ANSIBLE_COLOR, stringc
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):

        def run_command(self, cmd):
            return 0, "", ""

        @staticmethod
        def get_bin_path(name, required):
            return 'getent'

    m = TestModule(argument_spec={
        'database': dict(type='str', required=True),
        'key': dict(type='str', no_log=False),
        'service': dict(type='str'),
        'split': dict(type='str'),
        'fail_key': dict(type='bool', default=True),
        },
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:20:20.109104
# Unit test for function main
def test_main():
    '''
    if the project under tests is a class, a unit test can be written like this.
    '''

    # create a module for the unit test
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # make sure that the module under test can be instantiated.
    getent = getent(module.params)
    assert getent

    # test the "foo" method
    assert getent.foo() == "foo"

    # test the "bar" method
   

# Generated at 2022-06-11 07:20:20.658781
# Unit test for function main
def test_main():
  assert main() == None

# Generated at 2022-06-11 07:20:27.630790
# Unit test for function main
def test_main():
    import pytest
    import os
    import subprocess

    def getent_data(database, key):
        cmd = ['getent' ,database, key]
        return subprocess.check_output(cmd).strip()

    def run_cmd(module, cmd):
        rc, out, err = module.run_command(cmd, check_rc=False)
        return rc, out, err

    # run with no argument
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # run with arguments