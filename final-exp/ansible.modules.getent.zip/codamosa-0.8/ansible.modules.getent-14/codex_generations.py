

# Generated at 2022-06-11 07:10:49.705288
# Unit test for function main
def test_main():
    # Only function main needs to be unit tested
    # All other methods only need functional tests
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
    )
    main()

# Generated at 2022-06-11 07:11:01.564657
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', default="root"),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/getent')
    module.run_command = MagicMock(return_value=(0, '', ''))


# Generated at 2022-06-11 07:11:13.262270
# Unit test for function main
def test_main():
    from __main__ import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils import action_common_facts
    import sys

    # Instantiate the AnsibleModule object we will use to pass to the module
    # being tested
    # Note: we remove all arguments so the module does not process them
    ansible_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    ans

# Generated at 2022-06-11 07:11:25.019991
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'database': 'passwd',
        'key': 'root',
        'split': ':'
    }, supports_check_mode=True)

    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, 'passwd', 'root']

    rc, out, err = module.run_command(cmd)

    dbtree = 'getent_passwd'

    results = {}
    results[dbtree] = {}
    results[dbtree]['root'] = out.split(':')[1:];

    assert rc == 0
    assert results == { 'getent_passwd': { 'root': ['x', '0', '0', 'root', '/root', '/bin/bash'] } }

# Generated at 2022-06-11 07:11:32.454157
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rc, out, err = module.run_command(['/bin/getent', 'passwd', 'root'])
    assert rc == 0
    rc, out, err = module.run_command(['/bin/getent', 'passwd', 'roota'])
    assert rc == 2
    rc, out, err = module.run_command(['/bin/getent', 'passwd'])

# Generated at 2022-06-11 07:11:44.023049
# Unit test for function main
def test_main():

    class AnsibleModuleMock(object):

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, binary_name, required):
            return binary_name

        def run_command(self, cmd):
            return cmd

    # database is required
    assert_raises(SystemExit, main, AnsibleModuleMock({}))

    # database must be valid
    assert_raises(SystemExit, main, AnsibleModuleMock({'database': 'foo'}))

    # return code 0, test with no split
    assert_equals(main(AnsibleModuleMock({'database': 'passwd'})), {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}})

    # return

# Generated at 2022-06-11 07:11:44.565163
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:46.146838
# Unit test for function main
def test_main():
    # This modules does not support check mode
    assert not hasattr(main, 'CHECK_MODE_SUPPORTED')

# Generated at 2022-06-11 07:11:56.940263
# Unit test for function main
def test_main():

    # Patch AnsibleModule
    class AnsibleModuleMock(object):

        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.params = {}
            self.check_mode = False

        def fail_json(self, msg, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            self.exit_args['msg'] = msg
            raise SystemExit(kwargs['msg'])

    class RunCommandMock(object):
        def __init__(self, rc=None, out='', err='', failed=True):
            self.rc = rc
            self.out = out
            self.err = err
            self.failed = failed


# Generated at 2022-06-11 07:12:03.778178
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    import sys
    import json

    if len(sys.argv) < 2:
        module.fail_json(msg="Error: test_main uses json arguments")
    else:
        main()



# Generated at 2022-06-11 07:12:27.908763
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts import ansible_virtualization_type
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.virtual.qemu import virtual_qemu

    setattr(basic.AnsibleModule, 'run_command', lambda x: (0, 'split:value', ''))
    setattr(basic.AnsibleModule, 'get_bin_path', lambda x,y: '')
    setattr(ansible_virtualization_type, "virtual_qemu", lambda x: None)

# Generated at 2022-06-11 07:12:36.832573
# Unit test for function main
def test_main():

    import tempfile
    import os

    temp = tempfile.TemporaryDirectory()
    path = os.path.join(temp.name, "test_file.txt")
    print(path)
    fobj = None
    try:
        fobj = open(path, "w")
        fobj.write("Content")
    finally:
        fobj.close()

    # Create the object that runs tests
    m = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create

# Generated at 2022-06-11 07:12:45.655024
# Unit test for function main
def test_main():
    ansible_facts = {'getent-passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash'], 'www-data': ['x', '33', '33', 'www-data', '/var/www', '/usr/sbin/nologin']}}

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str'),
            split=dict(type='str'),
        )
    )
    module.exit_json(ansible_facts=ansible_facts)

# Generated at 2022-06-11 07:12:54.536005
# Unit test for function main
def test_main():

    from ansible.modules.system.getent import main

    result = {"ansible_facts": {"getent_group": {"test": ['*', '', '', '150']}}}

    def run_command(cmd, *_):
        return 0, 'test:*:150:::', ''

    module = ansible.modules.system.getent.AnsibleModule
    module.run_command = run_command
    module.platform = 'posix'

    try:
        main()
    except SystemExit as e:
        assert result == e.code
        return

    assert False, "Test should not reach this line, system exit didn't happen"

# Generated at 2022-06-11 07:12:56.029862
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:13:07.692816
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
   

# Generated at 2022-06-11 07:13:14.733865
# Unit test for function main
def test_main():
    import sys
    import os

    # save the original sys.argv
    orig_sys_argv = list(sys.argv)

    # make a separate copy of sys.argv
    sys.argv = list(orig_sys_argv)

    # add a command line argument to sys.argv
    sys.argv.append('-v')

    # call our main function
    main()

    # restore the original sys.argv
    sys.argv = orig_sys_argv

# Generated at 2022-06-11 07:13:26.031326
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.dict_transformations import _exclude_undefined_values
    from ansible.compat.tests import unittest

    module = AnsibleModule({
        'database': 'passwd',
        'key': 'root',
    })

    results = {'ansible_facts': {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}}
    assert _exclude_undefined_values(results) == basic.AnsibleModule(module).run()[0]


# Generated at 2022-06-11 07:13:32.344224
# Unit test for function main

# Generated at 2022-06-11 07:13:39.538722
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    getent_test_dir = tempfile.mkdtemp(prefix='getent_test.')
    getent_test_files = {
        'group': '''foo:x:1002:
        bar:x:1004:
        ''',
        'passwd': '''foo:x:1001:1001:Mr Foo:/home/foo:/bin/sh
        bar:x:1003:1003:Mr Bar:/home/bar:/bin/sh
        ''',
    }
    file_links = ['getent', 'getent.py']
    os.chmod(getent_test_dir, 0o777)


# Generated at 2022-06-11 07:14:22.068813
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    import sys
    import os

    test_mock = TestAnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False, default=None),
            service=dict(type='str', default=None),
            split=dict(type='str', default=None),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # set up for function return
    sys.argv = ['getent']
    sys.argv.append('--database=passwd')
    sys.argv.append('--key=root')
    sys.argv.append('--service=getent')

# Generated at 2022-06-11 07:14:33.448782
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    m_run_command = module.run_command
    m_get_bin_path = module.get_bin_path

    def run_command(cmd, **kwargs):
        return (0, '', '')

    def get_bin_path(cmd, **kwargs):
        return '/bin/getent'

    module.run_command = run_command
    module.get_bin_path = get_bin_

# Generated at 2022-06-11 07:14:43.722443
# Unit test for function main

# Generated at 2022-06-11 07:14:54.180303
# Unit test for function main
def test_main():
    ''' Unit Tests for function main '''

    getent_bin = '../../../bin/getent'

    source = dict(
        database='test',
        key=None,
        split=None
    )

    # Initialize the module
    getent_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # mock run_command and update params
    getent_module.run_command = mock_run_command
    getent_module.params = source

    #

# Generated at 2022-06-11 07:15:03.864156
# Unit test for function main
def test_main():
    def getent_return_value(invocation_args, out, err, rc):
        if invocation_args[1] == 'passwd':
            return 'root:x:0:0:root:/root:/bin/bash\nobody:x:65534:65534:nobody:/nonexistent:/bin/sh\n'
        elif invocation_args[1] == 'group':
            return 'root:x:0:\n'

# Generated at 2022-06-11 07:15:05.759580
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 07:15:06.385661
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:15:16.839683
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.getent import main as getent_function
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)

    database = "passwd"
    key = "root"

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd

# Generated at 2022-06-11 07:15:26.066117
# Unit test for function main
def test_main():
    to_bytes = getattr(__builtins__, 'unicode', str)

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
    )

    task = module.map_to_ansible_module(getent_module)
    def run_command_mock(module, cmd, check_rc=False, **kwargs):
        if cmd[1:] == [to_bytes(task['database']), task['key'].encode('utf-8'), '-s', task['service']]:
            return 0, task['success_msg'], ''

# Generated at 2022-06-11 07:15:26.970929
# Unit test for function main
def test_main():
    res = main()
    assert res is not None

# Generated at 2022-06-11 07:16:41.692359
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:16:53.016100
# Unit test for function main
def test_main():
    import ansible.module_utils
    import json

    # Unit test for function main
    tmpfd, tmpfile = tempfile.mkstemp()

# Generated at 2022-06-11 07:16:58.991818
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    return_dict = main()
    module.exit_json(**return_dict)

# Generated at 2022-06-11 07:17:00.357239
# Unit test for function main
def test_main():
    """
    test_main()

    Unit test.
    """
    # run main()
    main()

# Generated at 2022-06-11 07:17:01.101812
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:17:01.911742
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-11 07:17:07.866351
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:17:18.983439
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class mock_run_command:
        def __init__(self, rc, out, err):
            self.rc=rc
            self.out=out
            self.err=err

        def __call__(self, cmd):
            return (self.rc, self.out, self.err)

    rc, out, err = 0, 'bar        :x:', ''
    module.run_command = mock_run_

# Generated at 2022-06-11 07:17:19.650549
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:17:26.713073
# Unit test for function main
def test_main():
    import sys
    import shlex
    import subprocess
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import env_fallback
    test_args = dict(
        database='passwd',
        key='root',
        service='',
        split=':',
    )
    test_args_missing_keys = dict(
        database='passwd',
        service='',
        split=':',
    )
    test_args_root_missing = dict(
        database='passwd',
        key='foo',
        service='',
        split=':',
    )

# Generated at 2022-06-11 07:20:00.870192
# Unit test for function main
def test_main():
  with mock.patch('ansible.modules.system.getent.getent_bin', fake_getent_bin):
    with mock.patch('ansible.modules.system.getent.AnsibleModule', fake_ansible_module):
      with mock.patch('ansible.module_utils.basic.run_command', fake_run_command):
        fake_module = AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str'),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )

# Generated at 2022-06-11 07:20:05.615146
# Unit test for function main
def test_main():
    import tempfile
    import sys
    import os
    import subprocess

    (out, err) = subprocess.Popen("echo hi", stdout=subprocess.PIPE, shell=True).communicate()
    assert(out == "hi\n")

# vi: ts=4 et sw=4 sts=4

# Generated at 2022-06-11 07:20:06.344530
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-11 07:20:14.716488
# Unit test for function main
def test_main():
    def mock_run_command(cmd, check_rc=False):
        return 0, '', ''
    test_module = AnsibleModule(argument_spec={
        'database': dict(type='str', required=True),
        'key': dict(type='str'),
        'split': dict(type='str')
    })
    test_module.run_command = mock_run_command
    result = main()

    assert result['ansible_facts'] == {
        'getent_passwd': {},
        'getent_group': {},
    }

# Generated at 2022-06-11 07:20:15.370161
# Unit test for function main
def test_main():
    print("hello world")

# Generated at 2022-06-11 07:20:15.982280
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:20:25.101749
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils._text import to_bytes, to_text

    module_path = os.path.join(os.path.dirname(__file__), '../../library/getent.py')
    module_args = {}
    set_module_args(module_args)
    module = basic._AnsibleModule(
        argument_spec=common.COMMON_ARGUMENT_SPEC,
        supports_check_mode=True,
        )
    module.run_command = MagicMock(return_value=(0, "this is the test output", ""))
    frm = inspect.stack()[0]
    mod = inspect.getmodule(frm[0])

    assert module.main() == 'OK'