

# Generated at 2022-06-11 07:10:52.491601
# Unit test for function main
def test_main():
    import shutil
    import tempfile

    db = tempfile.mkdtemp()
    path = shutil.which('getent')
    shutil.copy(path, db)

    #
    # Test defaults
    #

    # Test missing database
    module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True)))
    rc, out, err = module.run_command([os.path.join(db, 'getent')])
    assert rc == 1
    assert json.loads(out) == {'failed': True, 'msg': 'Missing arguments, or database unknown.'}

    # Test bad database
    module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True)))

# Generated at 2022-06-11 07:11:00.607083
# Unit test for function main
def test_main():
    argv = [
        'getent',
        '-m',
        'getent',
        '-a',
        'database=passwd',
        '-a',
        'key=root',
        '-a',
        'split=:',
        '-a',
        'fail_key=yes',
        '-a',
        'service=none',
        '--args',
    ]

    with mock.patch.object(sys, 'argv', argv):
        main()

# Generated at 2022-06-11 07:11:12.538739
# Unit test for function main
def test_main():
    import json

    from ansible.modules.system.getent import main

    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True, choices=['password']),
        key=dict(type='str', default=None, required=False),
        service=dict(type='str', default=None, required=False),
        split=dict(type='str', default=None, required=False),
        fail_key=dict(type='bool', default=False, required=False),
    ))

    try:
        out = main()
    except Exception as e:
        out = dict(failed=True, msg=to_native(e), exception=traceback.format_exc())

    print(json.dumps({'rc': 0, 'results': out}))


# Generated at 2022-06-11 07:11:23.297641
# Unit test for function main
def test_main():
    """
    Unit test to test the functions in main
    """

    ansible_return = {
        'ansible_facts': {
            'getent_passwd': {
                'root': ['x', '0', '0', 'root', '/root', '/bin/bash'],
                 'nobody': ['x', '65534', '65534', 'nobody', '/', '/bin/false']
                 }
            }
        }

    getent_bin = '/bin/getent'

    rc = 0
    out = '''root:x:0:0:root:/root:/bin/bash
nobody:x:65534:65534:nobody:/:bin/false'''
    err = None

    # Create a mock module

# Generated at 2022-06-11 07:11:31.870798
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import shutil

    test_getent = "tests/module_utils/getent.py"
    test_output = "tests/module_utils/ansible_test.out"
    test_err = "tests/module_utils/ansible_test.err"
    test_cmd = "ANSIBLE_GETENT_BIN=%s %s" % (test_getent, test_getent)

    rc, out, err = None, None, None


# Generated at 2022-06-11 07:11:43.316881
# Unit test for function main
def test_main():
    # Test single result missing key
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = 'passwd'
    key = 'root'
    split = ':'

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    rc = 2

# Generated at 2022-06-11 07:11:53.977340
# Unit test for function main
def test_main():
    # Test case 1
    #
    # Inputs
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


if __name__ == '__main__':
    from ansible.module_utils.basic import *


# Generated at 2022-06-11 07:11:54.863714
# Unit test for function main
def test_main():
    # test for function main()
    pass

# Generated at 2022-06-11 07:12:01.538431
# Unit test for function main
def test_main():
    import os
    import tempfile
    import filecmp
    import shutil
    import sys
    import textwrap
    import io
    import json

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # import test snippets
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_native(args)

    def exit_json(*args, **kwargs):
        print(json.dumps(dict(changed=False, *args, **kwargs)))
        sys.exit(0)


# Generated at 2022-06-11 07:12:05.672041
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:12:29.322201
# Unit test for function main
def test_main():
    import ansible.constants as C
    import os
    import tempfile

    from ansible.utils.path import unfrackpath

    from ansible.module_utils.basic import AnsibleModule

    fixtures = [
        {'database': 'passwd', 'key': 'root'},
        {'database': 'group'},
        {'database': 'hosts'},
        {'database': 'services', 'key': 'http', 'fail_key': False},
        {'database': 'shadow', 'key': 'www-data', 'split': ':'},
    ]

    tmpdir = tempfile.gettempdir()

    def setUpModule():
        '''
        This function is run one time, before anything else in this unit test script
        Create a fake getent command, that echoes the database name
        '''

# Generated at 2022-06-11 07:12:30.526118
# Unit test for function main
def test_main():
    '''
    Test the main function module
    '''
    pass

# Generated at 2022-06-11 07:12:41.301139
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence
    import json

    module = basic.AnsibleModule({
        'database': 'passwd',
        'key': 'root',
    }, basic._ANSIBLE_ARGS)

    results = {
        'getent_passwd': [
            'root', 'x', '0', '0', 'root', '/root', '/bin/bash'
        ],
    }

    class FakeModule(object):
        def __init__(self, results, module):
            self.results = results
            self.module = module

        def exit_json(self, **kwargs):
            assert 'ansible_facts' in kwargs
            assert 'getent_passwd' in kwargs['ansible_facts']


# Generated at 2022-06-11 07:12:50.658331
# Unit test for function main
def test_main():
    args = [
        {
            "database": "passwd",
            "key": "root"
        },
        {
            "database": "group",
            "key": "root"
        },
        {
            "database": "group",
            "split": ":"
        },
        {
            "database": "hosts"
        },
        {
            "database": "services",
            "key": "http"
        },
        {
            "database": "services",
            "key": "missing",
            "fail_key": False
        }
    ]

    for arg in args:
        main()


# Generated at 2022-06-11 07:12:58.064353
# Unit test for function main
def test_main():
    # Test getent_passwd
    module_params = {'database': 'passwd', 'key': 'root', 'split': None, 'service': None, 'fail_key': True}
    getent_passwd = main(module_params)
    assert getent_passwd == {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}

    # Test getent_group
    module_params = {'database': 'group', 'key': '', 'split': ':', 'service': None, 'fail_key': True}
    getent_group = main(module_params)
    assert getent_group == {'getent_group': {'root': ['x', '0'], 'sudo': ['x', '27']}}

    # Test get

# Generated at 2022-06-11 07:13:09.286708
# Unit test for function main
def test_main():
    import json
    import tempfile
    import os
    global module
    import ansible
    import ansible.module_utils
    import ansible.module_utils.basic
    class_args = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    )

# Generated at 2022-06-11 07:13:16.750802
# Unit test for function main
def test_main():
    """ Test getent module """
    argv = []
    argv.append('database=group')
    argv.append('key=wheel')
    argv.append('split=:')
    argv.append('fail_key=no')
    module = AnsibleModule(argument_spec={})
    module.params = dict(argv)
    data = main()
    assert data['ansible_facts']['getent_group']['wheel'] == ['0', 'root,daemon']

# Generated at 2022-06-11 07:13:27.812820
# Unit test for function main
def test_main():
    import sys
    import ansible
    from ansible.module_utils.six import PY3

    if PY3:
        import io
        from io import StringIO
    else:
        from StringIO import StringIO

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # save original stdout/stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    out = StringIO()
    err = StringIO

# Generated at 2022-06-11 07:13:36.914527
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import json

    os.environ['ANSIBLE_REMOVE_MODULE_RESULT'] = '1'
    os.environ['ANSIBLE_MODULE_NO_JSON'] = '1'


# Generated at 2022-06-11 07:13:45.306960
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:14:24.054827
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.exit_json(**main())


# Generated at 2022-06-11 07:14:30.956719
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        dict(
            database = dict(type='str', required=True),
            key = dict(type='str', no_log=False),
            service = dict(type='str'),
            split = dict(type='str'),
            fail_key = dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main() == None

# Generated at 2022-06-11 07:14:41.541838
# Unit test for function main
def test_main():
    import tempfile
    import textwrap
    import subprocess

    with tempfile.NamedTemporaryFile() as passwd:
        passwd.write(textwrap.dedent("""
            root:x:0:0:root:/root:/bin/bash
            bin:x:1:1:bin:/bin:/sbin/nologin
            daemon:x:2:2:daemon:/sbin:/sbin/nologin
            adm:x:3:4:adm:/var/adm:/sbin/nologin
        """).encode("utf-8"))
        passwd.flush()


# Generated at 2022-06-11 07:14:50.046441
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, 'out', 'err'))

    getent_bin = module.get_bin_path('getent', True)
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-11 07:14:50.701942
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:14:53.725111
# Unit test for function main
def test_main():
    args = dict(database='shadow', key='root')
    module = AnsibleModule(argument_spec={})
    module.params.update(args)
    main()

# Generated at 2022-06-11 07:15:03.518631
# Unit test for function main
def test_main():
    #Skip if library is not installed
    module = 'getpass'
    try: 
        importlib.import_module(module)        
    except:
        print('Tests require the module '+module+' to be installed')
        return 
    module = 'termcolor'
    try: 
        importlib.import_module(module)        
    except:
        print('Tests require the module '+module+' to be installed')
        return 
    
    # Create a mock module to run tests

# Generated at 2022-06-11 07:15:14.297725
# Unit test for function main
def test_main():
    import sys
    import types
    import os
    import tempfile
    import shutil
    from ansible.module_utils import basic

    # Save the original sys.argv
    orig_argv = sys.argv

    # Generate a temporary directory to store the csv file
    tmpdir = tempfile.mkdtemp()

    # create a csv file for the test
    fd, path = tempfile.mkstemp(dir=tmpdir, prefix='ansible_test_getent_', suffix='.csv')
    f = os.fdopen(fd, 'wb')
    f.write('''
test,testuser,group1,group2,group3
test2,testuser2,group2,group3,group4
''')
    f.close()

    # create a yaml file for the test
   

# Generated at 2022-06-11 07:15:23.928212
# Unit test for function main
def test_main():

    import unittest

    import ansible.module_utils.six as six

    class FakeModule(object):
        def param(self, key):
            return {}[key]

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs['msg'])

        def run_command(*args, **kwargs):
            return [3, "Enumeration not supported on this database.", ""]

        def exit_json(*args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return ''

    def call_main(*args, **kwargs):
        main(module=FakeModule())

    class TestCase(unittest.TestCase):
        def test_case_success(self):
            call_main()


# Generated at 2022-06-11 07:15:31.554067
# Unit test for function main
def test_main():
    import os
    os.environ['LANG'] = 'C'
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
            ),
        )
    setattr(module, 'check_mode', False)
    setattr(module, 'run_command', lambda *args: [0, '1', ''])

    # database = module.params['database']
    # key = module.params.get('key')
    # split = module.params.get('split')
    # fail_key = module.params.get('fail_key')

    assert main() == 0
    # assert database

# Generated at 2022-06-11 07:16:44.709196
# Unit test for function main
def test_main():
    import os
    import re

    import pytest

    @pytest.fixture
    def AnsibleModule(self):
        # the mock module follows the original module calling convention
        # which returns (rc, stdout, stderr)
        def run_command(self_, cmd):
            if 'passwd' in cmd:
                if 'root' in cmd:
                    return (
                        os.EX_OK,
                        b'root:x:0:0:root:/root:/bin/bash\n',
                        b'',
                    )

# Generated at 2022-06-11 07:16:55.929144
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:04.284089
# Unit test for function main
def test_main():

    import os
    import re
    import shutil
    import tempfile
    import ansible.module_utils.getent as getent

    temp_dir = tempfile.mkdtemp()

    # passwd database
    # root:x:0:0:root:/root:/bin/bash
    file = open(os.path.join(temp_dir, 'passwd'), 'w')
    file.write('root:x:0:0:root:/root:/bin/bash\n')
    file.write('bob:x:1000:1000:bob,,,:/home/bob:/bin/bash\n')
    file.close()

    # group database
    # root:x:0:root
    file = open(os.path.join(temp_dir, 'group'), 'w')

# Generated at 2022-06-11 07:17:11.859588
# Unit test for function main
def test_main():
    # Test args
    module_args = {
        'database': 'passwd',
        'key': 'root',
        'service': '',
        'split': '',
        'fail_key': '',
    }

    # Test variables
    getent_passwd = [
    ]

    # Test module execution
    rc, results, err = main()

    # Module should succed
    assert rc == 0

    # Facts should match
    assert results['getent_passwd'] == getent_passwd

# Generated at 2022-06-11 07:17:22.283352
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    database = 'passwd'
    key = 'root'
    split = ':'
    cmd = [getent_bin, database, key]
    export = {'database': database, 'key': key, 'split': split}
    module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True),
                                              key=dict(type='str', no_log=False),
                                              split=dict(type='str'),
                                              fail_key=dict(type='bool', default=True)
                                              ),
                           supports_check_mode=True,
                           )
    module.params.update(export)
    main()
    import sys

# Generated at 2022-06-11 07:17:22.758268
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:17:32.979993
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split = ':'



# Generated at 2022-06-11 07:17:41.162030
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:48.795157
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']
    database = 'passwd'
    key = 'root'
    split = ':'
    fail_key = True

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split

# Generated at 2022-06-11 07:17:57.277693
# Unit test for function main
def test_main():
    database = 'hosts'
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    m = MagicMock()
    m.run_command.return_value = (0, "localhost localhost\n", '')
    with patch.multiple('ansible.module_utils.basic.AnsibleModule',
                        get_bin_path=MagicMock(return_value='/potato'),
                        run_command=m) as mock_dict:
        with unittest.TestCase().assertRaises(SystemExit) as cm:
            main()
        # pprint.pprint(mock_dict)
        mock_dict

# Generated at 2022-06-11 07:20:25.392658
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = mod.params['database']
    key = mod.params.get('key')
    split = mod.params.get('split')
    service = mod.params