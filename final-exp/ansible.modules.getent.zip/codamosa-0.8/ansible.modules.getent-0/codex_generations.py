

# Generated at 2022-06-11 07:10:52.264042
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = 'passwd'
    key = None
    split = None
    service = None
    fail_key = True
    cmd = [getent_bin, database, key]

    rc, out, err = module.run_command(cmd)
    m = "Unexpected failure!"
    dbtree = 'getent_%s' % database
    results = {dbtree: {}}


# Generated at 2022-06-11 07:11:04.575608
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    cmd = []
    stdout = ''
    stderr = 'getent: warning: no hosts entry for 192.168.100.202'
    rc = 0
    module.run_command = MagicMock(return_value=(rc, stdout, stderr))
    main()

    assert module.run_command.called
    assert_equal(module.run_command.call_args, call(cmd))


# Generated at 2022-06-11 07:11:15.664622
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:11:25.402728
# Unit test for function main
def test_main():
    import mock
    import __builtin__

    # Mock the module using a mock open function
    def mock_open(filename):
        return mock.MagicMock()

    with mock.patch.object(__builtin__, 'open', mock_open):
        main()
        # make sure we ran
        assert main.run_command.called
        # make sure we ran with what we expected
        assert main.run_command.call_args[0][0] == ['/usr/bin/getent', 'passwd', 'root']
        assert main.exit_json.called

# Generated at 2022-06-11 07:11:26.165934
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:26.704753
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:11:32.409623
# Unit test for function main
def test_main():
  import tempfile
  import os

  (osf, osfile) = tempfile.mkstemp()
  os.write(osf, "test1:x:1:1:test1:/test1:/bin/sh\ntest2:x:2:2:test2:/test2:/bin/sh")
  os.close(osf)
  out = main()
  os.remove(osfile)

# Generated at 2022-06-11 07:11:34.817618
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    main()

# Generated at 2022-06-11 07:11:45.700886
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import ansible.module_utils.basic as _basic

# Generated at 2022-06-11 07:11:46.286296
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:12:09.130800
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:12:20.299469
# Unit test for function main
def test_main():
  import sys
  import os
  sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
  import unittest
  import ansible.constants as constants
  class MockModule:
    def __init__(self):
      self.params = {'database':'passwd', 'key':'root', 'split':':', 'fail_key':True}
    def get_bin_path(self, exe_name, required=False):
      return '/usr/bin/getent'

# Generated at 2022-06-11 07:12:24.451876
# Unit test for function main
def test_main():
    ansible_facts = {'getent_shadow': {'root': ['x', '15259', '0', '99999', '7', '', '', '']}}
    fact_result = main()
    assert fact_result == ansible_facts

# Generated at 2022-06-11 07:12:28.082367
# Unit test for function main
def test_main():
    """Test for function main"""
    import getent as getent_module
    # Test 1, test_no_key
    # set up
    params = {'fail_key': True, 'database': 'passwd'}
    module = getent_module.AnsibleModule(argument_spec = params,
                                            supports_check_mode = True)
    def run_command(self, cmd, check_rc=False):
        """Mock ansible.module_utils.basic.AnsibleModule.run_command"""
        assert cmd == ['/usr/bin/getent', 'passwd']
        return 1, "", ""
    module.run_command = run_command
    # run test
    getent_module.main()
    # assert results
    assert module.fail_json.call_count == 1
    assert module

# Generated at 2022-06-11 07:12:28.639083
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 07:12:38.548657
# Unit test for function main
def test_main():
    """ Unit test for main function"""

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if service is not None:
        cmd.extend(['-s', service])

    if split is None and database in colon:
        split = ':'

    try:
        rc, out, err = module.run_command(cmd)
    except Exception as e:
        module.fail_json(msg=to_native(e), exception=traceback.format_exc())

    msg = "Unexpected failure!"
    dbtree = 'getent_%s' % database
    results = {dbtree: {}}


# Generated at 2022-06-11 07:12:50.238595
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main

    # Test with a simple passwd database

# Generated at 2022-06-11 07:12:53.541695
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str')
    ))
    assert 'getent_passwd' in module.run_command(['getent', 'passwd'])

# Generated at 2022-06-11 07:13:04.764250
# Unit test for function main
def test_main():
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # Get the module parameters
    args = dict(
        database='passwd',
        key='root',
        split='',
        fail_key=True,
    )

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Set the module parameters
    module.params = args

# Generated at 2022-06-11 07:13:12.909042
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type = 'str', required = True),
            key = dict(type = 'str', no_log = False),
            split = dict(type = 'str'),
            fail_key = dict(type = 'bool', default = True),
        ),
        supports_check_mode = True
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:13:39.454600
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:13:48.030768
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.return_value = dict()
            self.call_args = dict()
            self.fail_json = dict()
            self.run_command = dict()
            self.check_mode = False
            self.diff = False
            self.runner = None
            self.invocation = basic.AnsibleModule.DEFAULT_INVOCATION

        def fail_json(self, *args, **kwargs):
            self.fail_json = dict(*args, **kwargs)


# Generated at 2022-06-11 07:13:57.498290
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True)

    module.run_command = MagicMock(return_value=(0, "", ""))
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    main()
    rc, out, err = module.run_command.call_args[0]
    assert rc == [module.get_bin_path('getent', True), 'passwd']

    module.params['key'] = 'root'
    module.run_command = MagicM

# Generated at 2022-06-11 07:14:00.682259
# Unit test for function main
def test_main():

    # Test getent facts generation
    getent_facts = main(dict(database='passwd', split=':', key=None))
    assert getent_facts['ansible_facts']['getent_passwd']['root'][0] == 'x'

# Generated at 2022-06-11 07:14:01.288348
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:14:11.628909
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils.common._collections_compat import Mapping
    import ansible.module_utils.six as six

    cmd = ['/usr/bin/getent', 'group', 'root']

    # run the command and capture output
    with patch('ansible.modules.system.getent.module_utils.basic.AnsibleModule.run_command') as mock:
        mock.return_value = 0, 'root:x:0:root', ''
        main()

    # verify getent command called correctly

# Generated at 2022-06-11 07:14:22.319229
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = kwargs['fail_json']
            self.run_command = kwargs['run_command']
            self.exit_json = kwargs['exit_json']

        def get_bin_path(self, bin, required=False):
            return 'getent'

    class MockRunCommand(object):
        def __init__(self, **kwargs):
            self.rc = kwargs['rc']
            self.out = kwargs['out']
            self.err = kwargs['err']

        def __call__(self, cmd, *args, **kwargs):
            return self.rc, self.out, self.err


# Generated at 2022-06-11 07:14:23.028787
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:14:34.302688
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def getent_bin(module):
        return True, 'passwd', ''

    def check_output(module):
        return 0, 'root:x:0:0:root:/root:/bin/bash', ''

    module.run_command = check_output
    module.get_bin_path = getent_bin

    rc, out, err = check_output(module)


# Generated at 2022-06-11 07:14:35.763392
# Unit test for function main
def test_main():
    """ This is a unit test to check the function main
    """
    assert 1 == 1

# Generated at 2022-06-11 07:15:37.316112
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    (mocked_module, input_data) = basic._mock_module_passed(basic.AnsibleModule)
    mocked_module.run_command = basic._mock_run_command(basic.AnsibleModule)

    rc = {
        'passwd': 0,
        'shadow': 2,
        'group': 3,
        'gshadow': 0,
        'hosts': 0,
        'services': 1,
    }

    def test_run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
    #    self.fail_json(rc=rc[args[1]], cmd=args)
        return rc[args[1]], None, None

    mocked_

# Generated at 2022-06-11 07:15:46.579702
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'database': 'hosts',
        'key': None,
        'service': None,
        'split': None,
        'fail_key': True
    })


# Generated at 2022-06-11 07:15:54.620167
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = MagicMock()

# Generated at 2022-06-11 07:15:55.551183
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:16:04.584722
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
        )

    res_mock = dict(
        changed=False,
        ansible_facts={},
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-11 07:16:10.406100
# Unit test for function main
def test_main():
    import sys,os
    import subprocess

    # Known database and user/key
    database = 'passwd'
    key = 'root'

    # Build a custom module and args
    mock = [sys.executable, os.path.join(os.getcwd(), __file__), '-s',
            '-a', "database=%s" % database, "key=%s" % key]

    # If a database is not available on the system, that's ok
    rc = subprocess.call(mock)
    assert rc in (0, 3)

    # TODO: Inject an existing database (e.g. /etc/passwd) for a test.
    # Currently this won't work as the system database will be used by the module.

# Generated at 2022-06-11 07:16:19.977609
# Unit test for function main
def test_main():
    """ Test if main fails for invalid database """
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = 'invalid-database'
    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, database]
    try:
        rc, out, err = module.run_command(cmd)
    except Exception as e:
        module.fail_json(msg=to_native(e), exception=traceback.format_exc())

# Generated at 2022-06-11 07:16:28.924596
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-11 07:16:39.100232
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:16:43.459298
# Unit test for function main
def test_main():
    import json

    with open('getent.json', 'r') as getent_data:
        data = json.load(getent_data)

    for test in data['new_tests']:
        results = main()
        assert results == test


# Generated at 2022-06-11 07:18:57.406189
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile

    try:
        # Prepare a temporary file for testing
        fd, temp_path = tempfile.mkstemp()
        os.close(fd)

        # Save original argv
        orig_argv = sys.argv
        sys.argv = [orig_argv[0]] + ['-m', 'getent', '-a',
                                     'database=passwd',
                                     'key=root',
                                     'split="\\t"',
                                     '--json',
                                     temp_path
                                     ]

        # Execute the main function
        main()

    finally:
        # Delete the temporary file
        os.unlink(temp_path)

        # Restore original argv
        sys.argv = orig_argv

# Generated at 2022-06-11 07:19:05.203473
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:19:13.364880
# Unit test for function main
def test_main():
    import os

    test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                             'getent.yml')
    print (test_file)
    test_vars = dict(
        test_file=test_file,
        key="ansible",
        split=":",
    )

    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-11 07:19:21.305553
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible_collections.community.general.tests.unit.compat import unittest

    class AnsibleExitJson(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class AnsibleFailJson(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson

# Generated at 2022-06-11 07:19:29.146142
# Unit test for function main

# Generated at 2022-06-11 07:19:29.645618
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:19:33.239866
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str')
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 07:19:33.773422
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:19:43.175102
# Unit test for function main
def test_main():
    import ansible.modules.extras.system.getent as getent
    import ansible.module_utils.basic as basic
    import ansible.module_utils.action as action

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = action.run_command

    db = 'hosts'
    key = 'example.com'
    split = ':'
    service = 'test'
    fail_key = True


# Generated at 2022-06-11 07:19:52.891571
# Unit test for function main
def test_main():
    argument_spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True)
    )

    module = AnsibleModule(argument_spec=argument_spec)

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)
