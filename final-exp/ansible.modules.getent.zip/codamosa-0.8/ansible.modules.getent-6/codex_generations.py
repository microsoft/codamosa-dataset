

# Generated at 2022-06-11 07:10:42.480674
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:10:43.031728
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:10:52.396745
# Unit test for function main
def test_main():
    import sys
    import imp
    import os
    import tempfile
    import pytest
    import ansible.module_utils.basic as basic
    import ansible.module_utils.action as action
    from ansible.module_utils._text import to_bytes, to_native

    # create our temp files
    passwd_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    shadow_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    group_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    gshadow_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    hosts_file = tempfile.NamedTemporaryFile(mode='w', delete=False)

# Generated at 2022-06-11 07:11:04.694376
# Unit test for function main
def test_main():
    import os
    import tempfile

    my_env = os.environ.copy()
    my_env['PATH'] = ':'.join([
        tempfile.mkdtemp(),
        '%s/../test/ansible/module_utils' % tempfile.gettempdir(),
        os.environ['PATH']
    ])
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'database': dict(type='str', required=True),
                                          'key': dict(type='str'),
                                          'split': dict(type='str'),
                                          'fail_key': dict(type='bool', default=True)})
    module.params = {'database': 'passwd'}

# Generated at 2022-06-11 07:11:11.994864
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.exit_json(ansible_facts=[{"testing": "this"}])

# Generated at 2022-06-11 07:11:18.797025
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec=dict(database=dict(type='str', required=True), key=dict(type='str', no_log=False), 
    service=dict(type='str'), split=dict(type='str'), fail_key=dict(type='bool', default=True)))
    test_module.run_command = MagicMock(return_value=(0, 'root:x:0:0:root:/root:/bin/bash', ''))
    test_module.params = {'database': 'passwd', 'key': 'root', 'service': None}
    test_main()
    assert test_module.exit_json.call_count == 1


# Generated at 2022-06-11 07:11:29.755678
# Unit test for function main
def test_main():
    # Mock module
    class MockedModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.exit_json = None
            self.fail_json = None

        def run_command(self, cmd):
            if cmd == [getent_bin, 'passwd', 'root']:
                return 0, 'root:x:0:0:root:/root:/bin/bash', ''
            elif cmd == [getent_bin, 'group']:
                return 0, 'root:x:0:', ''
            elif cmd == [getent_bin, 'hosts']:
                return 0, '192.168.1.1    localhost', ''
            else:
                return 0, '', ''

    module = MockedModule()


# Generated at 2022-06-11 07:11:41.190902
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible.module_utils._text import to_bytes

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class AnsibleModule(basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

       

# Generated at 2022-06-11 07:11:46.368619
# Unit test for function main
def test_main():
    test_dict = {}

    test_dict['database'] = 'hosts'
    test_dict['key'] = 'ansible.com'
    test_dict['split'] = ':'
    test_dict['service'] = None
    test_dict['fail_key'] = True

    main()
    assert False

test_main()

# Generated at 2022-06-11 07:11:57.110334
# Unit test for function main
def test_main():
    for key in ['hosts', 'passwd', 'group']:
        module = AnsibleModule(
            argument_spec=dict(
                database=dict(type='str', required=True),
                key=dict(type='str', no_log=False),
                split=dict(type='str'),
                fail_key=dict(type='bool', default=True),
            ),
        )

        getent_bin = module.get_bin_path('getent', True)
        if key == 'hosts':
            database = 'hosts'
            cmd = [getent_bin, database]
            rc = 0
            out = '127.0.0.1 localhost\n192.168.122.1 testbox testbox.localdomain'
        else:
            database = key

# Generated at 2022-06-11 07:12:20.592197
# Unit test for function main
def test_main():
    # file to contain output from getent
    output_file = tempfile.mkstemp(prefix='ansible-test-getent')


# Generated at 2022-06-11 07:12:30.791093
# Unit test for function main
def test_main():
    # patching is needed for unit tests for modules that run custom code
    # like this one
    from ansible.module_utils.basic import AnsibleModule, get_module_path
    from ansible.module_utils import basic
    from ansible.module_utils import action
    from tempfile import NamedTemporaryFile

    # this fixes the import problem from C modules like the one happening
    # here with the getent module, they don't exist in the path and the
    # import crashes when the module is not found in the test path.
    old_importer = basic._ANSIBLE_ARGS

    basic._ANSIBLE_ARGS = namedtuple('AnsibleArgs', ['connection'])('local')

    # also patch action so that we can test the module without having
    # to copy it to the test path
    action.MODULE_CACHE

# Generated at 2022-06-11 07:12:41.677484
# Unit test for function main
def test_main():
    def getent_run_command(cmd):
        if 'passwd' in cmd:
            out = 'root:x:0:0:root:/root:/bin/bash'
            return 0, out, ''
        elif 'group' in cmd:
            out = 'root:x:0:'
            return 0, out, ''
        elif 'hosts' in cmd:
            out = '127.0.0.1 localhost'
            return 0, out, ''
        else:
            return 1, None, None

    class getent_module:
        class run_command:
            returncode = 0
            stdout = ''
            stderr = ''
            def __init__(self, cmd):
                self.returncode, self.stdout, self.stderr = getent_run_command(cmd)

       

# Generated at 2022-06-11 07:12:53.280491
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)



# Generated at 2022-06-11 07:13:04.449078
# Unit test for function main
def test_main():
    import argparse
    import sys
    from ansible.module_utils.basic import AnsibleModule

    # All we can do is test the stdout and stderr logic
    # since the getent program is a shell program

    # last field is mode
    passwd_exp = ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
    passwd_output = ('root:x:0:0:root:/root:/bin/bash')
    passwd_rc = 0

    # no results
    group_exp = ['nogroup', 'x', '65534']
    group_output = ('nogroup:x:65534')
    group_rc = 0

    # last field is mode

# Generated at 2022-06-11 07:13:12.746632
# Unit test for function main
def test_main():
    """Unit test for the main function"""
    import ansible.module_utils.action as action
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.getent import main

    modules = action.module_loader.all(path=[])

    for name, module in modules.items():

        if name == 'getent':

            # Loop over the different databases
            for database in ['passwd', 'group', 'hosts', 'services', 'shadow']:

                # Test with a non existant key
                module = AnsibleModule({'database': database, 'key': 'non-existant-key'}, {})
                main()
                assert module.fail_json.called is True

# Generated at 2022-06-11 07:13:22.248304
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(argument_spec={'database': dict(type='str', required=True), 'key': dict(type='str', no_log=False), 'service': dict(type='str'), 'split': dict(type='str'), 'fail_key': dict(type='bool', default=True)})
    ansible_module.run_command = MagicMock()
    ansible_module.fail_json = MagicMock()
    ansible_module.exit_json = MagicMock()
    ansible_module.params = {"database": "passwd"}
    ansible_module.get_bin_path = MagicMock()
    main()

# Generated at 2022-06-11 07:13:28.916363
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    return main()

# Generated at 2022-06-11 07:13:37.694329
# Unit test for function main
def test_main():
    # Import the module
    import ansible.modules.system.getent as getent
    # Set the right arguments
    args = dict(
        database='passwd',
        key=None,
        split=':',
        fail_key=None,
    )
    # Set the values that should be returned from the module
    results = dict(
        rc=0,
        ansible_facts=dict(
            getent_passwd=['root:x:0:0:root:/root:/bin/bash', 'bin:x:1:1:bin:/bin:/sbin/nologin']
        ),
        msg='Unexpected failure!'
    )
    # Set the module args and run the module
    getent.main()
    # Check the result

# Generated at 2022-06-11 07:13:42.593244
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rc = main()
    return rc

# Generated at 2022-06-11 07:14:22.638341
# Unit test for function main
def test_main():
    import os
    import sys
    import inspect
    import warnings

    # import mock
    import getent

    module_path = os.path.dirname(inspect.getabsfile(getent))
    src_path = os.path.join(module_path, '..')

    sys.path.insert(0, src_path)

    warnings.simplefilter("ignore")
    #mock.patch('ansible.module_utils._text.to_native', return_value=True)
    #mock.patch('ansible.module_utils.basic.AnsibleModule', spec=True, return_value=True)
    #mock.patch('ansible.module_utils.basic.module_common_argspec', spec=True, return_value=True)
    #mock.patch('ansible.module_utils.basic

# Generated at 2022-06-11 07:14:23.274189
# Unit test for function main
def test_main():
    assert main() is undefined

# Generated at 2022-06-11 07:14:34.416444
# Unit test for function main
def test_main():
    mod = AnsibleModule(argument_spec={'database': {'required': True, 'type': 'str'}, 'key': {'no_log': False, 'type': 'str'}, 'service': {'type': 'str'}, 'split': {'type': 'str'}, 'fail_key': {'default': True, 'type': 'bool'}})
    mod.run_command = MagicMock(return_value=(0, b'root:x:0:0:root:/root:/bin/bash\n', b''))
    mod.exit_json = MagicMock(return_value=None)
    mod.get_bin_path = MagicMock(return_value='/bin/getent')

    # getent_passwd:
    #  - - root
    #    - x
    #    - 0
   

# Generated at 2022-06-11 07:14:44.563000
# Unit test for function main
def test_main():
    import json
    import os
    import pytest
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.community.general.plugins.modules.getent import main as getent_main


# Generated at 2022-06-11 07:14:55.277582
# Unit test for function main
def test_main():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts import is_special_var
    import sys
    import ansible.module_utils.facts
    import ansible.module_utils.action
    from ansible.playbook.play_context import PlayContext

    old_run_command = ansible.module_utils.action.run_command
    ansible.module_utils.action.run_command = lambda *args, **kwargs: (0, "test", "")
    old_is_special_var = ansible.module_utils.facts.is_special_var

# Generated at 2022-06-11 07:15:02.852355
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    rc = main()
    assert rc['ansible_facts']['getent_passwd']['root'][0][3] == '0'

# Generated at 2022-06-11 07:15:13.456240
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:15:14.146586
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:15:23.766473
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule

    # Mock module arguments
    module_args = dict(
        database='passwd',
        fail_key='True',
        key=None,
        split=None,
        service='True'
    )
    # Fail condition
    if module_args['database'] == 'passwd':
        module_args['database'] = 'fake_database'
    # Fail condition
    if module_args['fail_key'] == 'True':
        module_args['key'] = 'fake_key'
    # Fail condition
    if module_args['service'] == 'True':
        module_args['service'] = 'fake_service'

    # Mock module

# Generated at 2022-06-11 07:15:30.975051
# Unit test for function main
def test_main():
    def run_command(module, cmd, check_rc=True, close_fds=True, executable=None,
                    data=None, binary_data=False):
        pass

    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
    ), supports_check_mode=True, )

    module.run_command = run_command
    module.params = {'database': '', 'key': '', 'split': '', 'fail_key': True}
    main()

# Generated at 2022-06-11 07:16:41.716043
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import shlex_quote
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2
    import sys

    # set up module args
    args = dict(
        database='passwd',
        key='root',
        split=None,
    )
    args_unicode = dict(
        database='passwd',
        key=u'root',
        split=None,
    )

    # set up return values
    rc = 0
    out = b'root:\x00:0:0:root:/root:/bin/bash'
    err = b''

    # set up ansible args

# Generated at 2022-06-11 07:16:53.068774
# Unit test for function main
def test_main():
    import json
    import os
    import pytest
    import ansible.module_utils.basic
    from ansible.module_utils.six import PY3
    import shutil
    import tempfile

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    fixture_data = {}

    def load_fixture(name):
        path = os.path.join(fixture_path, name)

        if path in fixture_data:
            return fixture_data[path]

        with open(path) as f:
            data = f.read()

        try:
            data = json.loads(data)
        except Exception:
            pass

        fixture_data[path] = data
        return data


# Generated at 2022-06-11 07:17:02.612561
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os


    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class AnsibleModuleFake(object):
        def __init__(self, *args, **kwargs):
            self.run_command_called = False
            self.params = {}

        def run_command(self, *args, **kwargs):
            self.run_command_

# Generated at 2022-06-11 07:17:11.303338
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)

    cmd = [getent_bin, "passwd"]

    rc, out, err = module.run_command(cmd)

    msg = "Unexpected failure!"
    dbtree = 'getent_passwd'
    results = {dbtree: {}}

    if rc == 0:
        for line in out.splitlines():
            elems = line.split(':')

            results[dbtree][elems[0]] = elems[1:]

        return results
    else:
        return False


print(test_main())

# Generated at 2022-06-11 07:17:21.999383
# Unit test for function main
def test_main():
    import os
    import sys
    import mock
    # run module in check mode to get proper output, otherwise we get 'rc: 1'
    tmp = dict(sys.argv)
    sys.argv.append('--check')
    # mock a os.getuid() and os.geteuid()
    mock_os = mock.MagicMock()
    mock_os.getuid.return_value = 0
    mock_os.geteuid.return_value = 0
    sys.modules['os'] = mock_os
    try:
        __salt__ = dict()
        main()
    except SystemExit as e:
        assert e.code == 0
    finally:
        # restore sys.argv
        sys.argv = tmp
    # Unit test against other than default return code

# Generated at 2022-06-11 07:17:31.917405
# Unit test for function main
def test_main():
    import sys
    import os
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(current_dir, '..'))
    import run_commands
    sys.modules['ansible.module_utils.basic'] = run_commands

    import ansible.module_utils.basic
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic

    import ansible.module_utils._text
    sys.modules['ansible.module_utils._text'] = ansible.module_utils._text

    import ansible.module_utils
    sys.modules['ansible.module_utils'] = ansible.module_utils

    import ansible.module_utils.facts

# Generated at 2022-06-11 07:17:32.521643
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:17:40.593557
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.system.getent as getent
    import ansible.module_utils.facts.system.getent as getent2
    getent.socket.socket = MagicMock()
    getent.getent.getent = MagicMock()
    getent.getent.getent.return_value = [["a", "b","c"],["d","e","f"]]
    getent2.socket.socket = MagicMock()
    getent2.getent.getent = MagicMock()
    getent2.getent.getent.return_value = [["a", "b","c"], ["d","e","f"]]
    result = getent.main()

# Generated at 2022-06-11 07:17:48.331484
# Unit test for function main
def test_main():
  # ansible-playbook --syntax-check test.yml
  yaml = '''
  ---
  - hosts: all

    tasks:
      - name: Get root user info
        getent:
          database: passwd
          key: root

      - name: Get http service info, no error if missing
        getent:
          database: services
          key: http
          fail_key: False

      - name: Get all hosts, split by tab
        getent:
          database: hosts

      - name: Get root user info
        getent:
          database: passwd
          key: root

  '''

# Generated at 2022-06-11 07:17:56.756235
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)


# Generated at 2022-06-11 07:20:21.489407
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'database': {'required': True, 'type': 'str'}, 'key': {'required': False, 'type': 'str'}, 'service': {'required': False, 'type': 'str'}, 'split': {'required': False, 'type': 'str'}, 'fail_key': {'required': False, 'type': 'bool'}}, supports_check_mode=True)
    getent_bin = module.get_bin_path('getent', True)
    assert getent_bin is not None
    assert module.run_command([getent_bin, '--version'])[0] == 0

# Generated at 2022-06-11 07:20:22.424645
# Unit test for function main
def test_main():
    assert main() == None
