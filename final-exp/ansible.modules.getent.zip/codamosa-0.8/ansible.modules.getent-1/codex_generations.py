

# Generated at 2022-06-11 07:10:50.726017
# Unit test for function main
def test_main():

    # Test 1:
    # This test should return no new facts.
    # It should return an error.
    getent_bin = '/usr/bin/getent'
    cmd_list = [getent_bin]
    test_1_rc = 0
    test_1_out = ''
    test_1_err = "test"
    test_1_return_message = "test"
    test_1_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    Test1_1 = "run_command"

# Generated at 2022-06-11 07:10:56.188183
# Unit test for function main
def test_main():
    mock = MagicMock(return_value=0)
    with patch.dict(getent.__salt__, {'cmd.run_all': mock}):
        assert getent.main() == {
            'ansible_facts': {
                'getent_database': {
                    'key': ['value']
                }
            }
        }

# Generated at 2022-06-11 07:11:04.467969
# Unit test for function main
def test_main():
    #pylint: disable=import-error
    import sys
    import os

    # set up required env variables
    os.environ["AN_ANSIBLE_MOD_ARGS"] = '{"database":"passwd","key":"root"}'

    # module is expected to fail due to missing required parameter
    sys.argv = ['ansible-test', 'getent']
    with pytest.raises(SystemExit):
        main()

    # run main function
    sys.argv = ['ansible-test', 'getent']
    main()

# Generated at 2022-06-11 07:11:15.582761
# Unit test for function main

# Generated at 2022-06-11 07:11:16.755973
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:28.503534
# Unit test for function main
def test_main():
    test_result = dict(
            rc=0,
            out='root:x:0:0:root:/root:/bin/bash\nusername:x:1000:1000:User Name,,,:/home/username:/bin/bash\n',
            err=''
    )
    test_database = 'passwd'
    test_key = None
    test_split = ':'

    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
    )
    test_module.run_command = MagicMock(return_value=test_result)

# Generated at 2022-06-11 07:11:31.566605
# Unit test for function main
def test_main():
    pass
    # Run test with getent_bin = '/bin/getent'
    # Run test with getent_bin = 'does_not_exist'
    # assert_fail()
    # Return function result

# Generated at 2022-06-11 07:11:42.622676
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type="str", required=True),
            key=dict(type="str", no_log=False),
            service=dict(type="str"),
            split=dict(type="str"),
            fail_key=dict(type="bool", default=True),
        ),
        supports_check_mode=True,
    )
    json_output = {
        "_ansible_verbose_override": False,
        "ansible_facts": {
            "getent_shadow": {
                "root": ["", "", "", "", "", "", "", "", "", ""],
            },
        },
        "changed": False,
    }
    module.exit_json(**json_output)

# Generated at 2022-06-11 07:11:53.120481
# Unit test for function main
def test_main():

    # String IO to capture the module output
    from StringIO import StringIO
    from ansible.module_utils._text import to_bytes

    output = StringIO()
    sys.stdout = output

    # The arguments to the program are passed in via sys.argv.
    # For testing the program is always run with just the arguments
    # the user would have entered on the command line
    program_argv = ['/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/runpy.py',
                    'ansible/modules/system/getent.py',
                    '-m',
                    'ansible/module_utils.basic',
                    '-a',
                    'database=passwd',
                    'key=root']

    # The arguments to the program are passed in via sys.argv.
    #

# Generated at 2022-06-11 07:11:53.731889
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:12:16.876050
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import action

    import ansible.module_utils.facts as facts
    import ansible.module_utils.common.collections as collections

    import ansible.module_utils.getent as getent
    import ansible.module_utils.getent.getent as getent_getent
    import ansible.module_utils.getent.gshadow as getent_gshadow
    import ansible.module_utils.getent.shadow as getent_shadow
    import ansible.module_utils.getent.passwd as getent_passwd
    import ansible.module_utils.getent.group as getent_group
    import ansible.module_utils.getent.hosts as getent_hosts
    import ansible.module_utils.getent

# Generated at 2022-06-11 07:12:28.136364
# Unit test for function main
def test_main():

    class Args(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    class Module(object):
        def __init__(self):
            self.check_mode = False
            self.run_command_warnings = []

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def exit_json(self, **kwargs):
            return kwargs

        def get_bin_path(self, *args):
            return '/usr/bin/getent'

        def run_command(self, cmd):
            return rc, out, err

    main_mock = Module()

    rc = 0
    out = '''
    testuser:x:1000:1000::/home/testuser:/bin/bash
    '''
   

# Generated at 2022-06-11 07:12:37.282029
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_module.run_command = MagicMock(return_value=(0, 'one:two:three', None))
    test_module.exit_json = MagicMock()
    test_module.fail_json = MagicMock()
    test_module.fail_json.side_effect = SystemExit

    rc=0
    out='one:two:three'
    err=None
    test_module.run

# Generated at 2022-06-11 07:12:48.852670
# Unit test for function main
def test_main():
    """
    basic unit test for module
    """
    import os
    import json
    import sys
    import pytest
    from units.compat import unittest
    from units.compat import mock

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    def function_fail_json(msg):
        print(json.dumps({
            'failed': True,
            'msg': msg
        }))
        sys.exit(1)

    def function_run_command(cmd, check_rc=True):
        return 0, 'ok\n', ''

    def function_exit_json(msg):
        print(json.dumps({
            'failed': False,
            'msg': msg
        }))
        sys.exit(0)

   

# Generated at 2022-06-11 07:12:54.843179
# Unit test for function main
def test_main():
    # Test if getent actually runs
    # Test if error code 1 returns an error message
    # Test if error code 2 returns an error message
    # Test if error code 3 returns an error message
    # Test if getent can return passwd
    # Test if getent can return group
    # Test if getent can return hosts
    # Test if getent can return services
    # Test if getent can return shadow
    # Test if getent can return gshadow
    pass

# Generated at 2022-06-11 07:13:06.665789
# Unit test for function main
def test_main():
    import syslog

    class NewSyslog:
        def init(self):
            pass
        def syslog(self, level, msg):
            syslog.syslog(level, msg)

    syslog = NewSyslog()
    # Build command line arguments

# Generated at 2022-06-11 07:13:17.278556
# Unit test for function main
def test_main():
    # Setup the module parameters and return values
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin

# Generated at 2022-06-11 07:13:28.157569
# Unit test for function main
def test_main():
    import os
    import sys
    import shlex
    import subprocess

    # Mock getent
    def mock_run_command(cmd, *args, **kwargs):
        # Mock getent to return some result
        out = "users:x:100:101:User,,,:/home/users:/bin/sh\n"

        return (0, out, "")


# Generated at 2022-06-11 07:13:37.120956
# Unit test for function main
def test_main():
    import platform
    (distro, version, id) = platform.linux_distribution()
    from ansible.module_utils.facts import ansible_facts, ansible_os_family

    ansible_facts_module = module_upload(
        path = 'ansible/module_utils/facts.py',
        name = 'ansible_facts.py'
    )

    ansible_os_family_module = module_upload(
        path = 'ansible/module_utils/facts.py',
        name = 'ansible_os_family.py'
    )

    ansible_distribution_module = module_upload(
        path = 'ansible/module_utils/facts/%s.py' % ansible_os_family,
        name = 'ansible_distribution.py'
    )
    
    ansible

# Generated at 2022-06-11 07:13:45.487173
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    import subprocess
    import tempfile
    import yaml

    test_vars = {
        'ansible_facts': {'getent_passwd': {}},
        'changed': True,
        'failed': False,
        'invocation': {'module_args': {'database': 'passwd', 'fail_key': False, 'key': 'root'}},
        'rc': 0,
        'stderr': '',
        'stderr_lines': [],
        'stdout': '',
        'stdout_lines': []
    }

    # Return True if ansible_facts match what test_vars expect.

# Generated at 2022-06-11 07:14:27.354325
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    database = 'passwd'
    split = ':'
    key = 'root'

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is not None and database in ['passwd', 'shadow', 'group', 'gshadow']:
        cmd.append('-s' + split)

    results = {'getent_' + database: {}}

    record = ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
    results['getent_passwd'][record[0]] = record[1:]

    assert record == run_command(cmd)


# Generated at 2022-06-11 07:14:28.043557
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:14:38.858237
# Unit test for function main
def test_main():
    from ansible.module_utils import arguments
    from ansible.module_utils import basic
    from ansible.module_utils.action import ActionBase

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        )
    )

    def get_bin_path(path, required=False):
        return path

    module.get_bin_path = get_bin_path

    def run_command(cmd):
        print(cmd)

    module.run_command = run_command


# Generated at 2022-06-11 07:14:39.491330
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:14:47.883214
# Unit test for function main
def test_main():
    #from ansible.module_utils import basic 
    #from ansible.module_utils.basic import AnsibleModule
    #from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils import action_plugins

    import sys
    #import json
    #import copy
    #import os

    fake_module_args = {
        u'database': u'passwd',
        u'key': u'root'
    }
    fake_module_return = {
        u'changed': False,
        u'invocation': {
            u'module_args': fake_module_args
        },
        u'result': True
    }

# Generated at 2022-06-11 07:14:58.927323
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type = 'str', required = True),
            key = dict(type = 'str', no_log = False),
            split = dict(type = 'str'),
            fail_key = dict(type = 'bool', default = True),
        ),
        supports_check_mode = True,
    )
    setattr(module, 'run_command', mock_run_command)
    setattr(module, 'get_bin_path', mock_get_bin_path)

    def dummy_fail_json(msg):
        assert False, msg

    setattr(module, 'fail_json', dummy_fail_json)

    # Testing nsswitch.conf returns results

# Generated at 2022-06-11 07:15:06.365570
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, basic_plugin_args
    import io
    import os
    import sys

    stdin = sys.stdin
    stdout = sys.stdout
    stderr = sys.stderr

    module_sock = os.path.join(os.path.dirname(__file__), 'getent.sock')
    loaded_args = dict((k, v) for k, v in basic_plugin_args().items() if v is not None)
    loaded_args.update(json_args={'param': 'value'})
    module = AnsibleModule(**loaded_args)
    sys.stdin = open(module_sock)
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    test_module

# Generated at 2022-06-11 07:15:07.840601
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-11 07:15:18.135428
# Unit test for function main
def test_main():
    # Empty arguments
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    m_args = module.params
    m_args['database'] = ''
    m_args['split'] = ':'
    m_args['key'] = ''
    rc, out, err = module.run_command(['getent', ''])
    assert rc == 1
    assert out == ""
    assert "Missing arguments, or database unknown." in err
    # No result
    m_args['database'] = 'passwd'
    m_args['split'] = ':'
    m_args['key'] = 'nouser'
    rc, out, err = module.run_command(['getent', 'passwd', 'nouser'])
    assert rc == 2
    assert out == ""

# Generated at 2022-06-11 07:15:27.260762
# Unit test for function main
def test_main():
    # Needs more tests
    # Expected return value
    ansible_facts = {'getent_passwd': {'root': [u'x', u'0', u'0', u'root', u'', u'/root', u'/bin/bash']}}
    # Expected parameters to module.run_command
    cmd = ['getent', 'passwd', 'root']

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    def run_command(cmd):
        return

# Generated at 2022-06-11 07:16:32.822947
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:34.149294
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-11 07:16:41.953617
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    return_msg = "Unexpected failure!"
    colon = ['passwd', 'shadow', 'group', 'gshadow']
    err = ""
    rc = 0
    out = ""


# Generated at 2022-06-11 07:16:44.272081
# Unit test for function main
def test_main():
    '''
    AnsibleActionModule(getent)
    '''
    result = getent.main()
    assert result == 1, "main failed"

# Generated at 2022-06-11 07:16:55.520833
# Unit test for function main
def test_main():
    from ansible.utils.path import unfrackpath

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=False,
    )

    # ansible_facts can be set by another module so don't remove it
    module.ansible_facts = { 'ansible_facts': {} }
    results = {}

    def mock_run_command(cmd, check_rc=True):
        out = b'root:x:0:0:root:/root:/bin/bash\n' + b'nouser:x:42:42:No Account for this user:/var/empty:/usr/bin/false'
        return [0, out, '']


# Generated at 2022-06-11 07:17:04.069463
# Unit test for function main
def test_main():
    fields = ['database', 'key', 'split', 'fail_key']
    module_args = dict(
        database='passwd',
        key='root',
        split='splitme',
        fail_key='yes'
    )
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params.update(module_args)

    m_run_command = MagicMock(return_value=(0, 'out', 'err'))

# Generated at 2022-06-11 07:17:15.480764
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.system.base import get_module_params
    from ansible.module_utils.facts.system.base import run_command
    from ansible.module_utils import basic
    from ansible.module_utils.facts.system.base import get_bin_path

    # mock basic.AnsibleModule to handle arguments and return values
    class AnsibularyModule(basic.AnsibleModule):
        def __init__(self, argument_spec):
            super(AnsibularyModule, self).__init__(
                argument_spec=argument_spec,
                supports_check_mode=True
            )

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def fail_json(self, **kwargs):
            self.fail_args

# Generated at 2022-06-11 07:17:21.406325
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert main(module)


# Generated at 2022-06-11 07:17:26.614259
# Unit test for function main
def test_main():
    with AnsibleExitJson(dict(
            ansible_facts=dict(
                getent_hosts=None,
            )
        )) as m, pytest.raises(AnsibleFailJson) as ex:
        m._execute_module(dict(
            database='hosts',
        ))
    assert ex.value.msg == 'Unexpected failure!'
    assert m.exit_json.call_count == 0


# Generated at 2022-06-11 07:17:35.909190
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import sys
    import pickle
    import os

    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    # create password database
    f = open(path, 'wb')
    data = [
        {'name': 'user1', 'key': '1234', 'group': 'user1'},
        {'name': 'user2', 'key': '1235', 'group': 'user2'},
        {'name': 'user3', 'key': '1236', 'group': 'user3'},
    ]
    pickle.dump(data, f, 2)
    f.close()

    # create module args
    module_args = {}
    module_args.update(database=path, key='user2')

    # create a

# Generated at 2022-06-11 07:20:14.307205
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import pytest
    print("test_main")

    print("test_module_utils_basic")
    test_args = ["getent", "passwd", "root"]
    if test_args[0] in sys.argv:
        del sys.argv[1:]
        sys.argv += test_args
        main()

    # capture output
    with pytest.raises(SystemExit):
        capturedOutput = StringIO.StringIO()
        sys.stdout = capturedOutput
        main()
        sys.stdout = sys.__stdout__
        #print capturedOutput
        assert True

# Generated at 2022-06-11 07:20:24.022314
# Unit test for function main
def test_main():
    import mock
    import os

    def test_fail_json(msg):
        raise Exception(msg)

    def test_exit_json(msg):
        raise Exception(msg)

    def test_run_command(cmd):
        return 0, "test\n", None

    mock_module = mock.MagicMock()
    mock_module.params = {'database': 'test',
                          'key': None,
                          'split': None,
                          'fail_key': True}
    mock_module.run_command.side_effect = test_run_command
    mock_module.fail_json.side_effect = test_fail_json
    mock_module.exit_json.side_effect = test_exit_json

    res = main()
    # assert(res == {})
    # res = main()
   