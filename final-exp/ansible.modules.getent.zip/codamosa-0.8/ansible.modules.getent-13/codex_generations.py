

# Generated at 2022-06-11 07:10:44.248340
# Unit test for function main
def test_main():
    from ansible.module_utils.facts.virt.getent import main
    #print(main())

# Generated at 2022-06-11 07:10:52.696462
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:11:05.137210
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import os

    module = AnsibleModule(argument_spec=dict(
        database=dict(type='str', required=False),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True)
    ),
        supports_check_mode=True,
    )

    module.params['database'] = 'passwd'
    module.params['key'] = 'root'
    getent_bin = module.get_bin_path('getent', True)

# Generated at 2022-06-11 07:11:07.084805
# Unit test for function main
def test_main():
    rc = main()
    assert rc == 0

# vim: ts=4 sw=4 et

# Generated at 2022-06-11 07:11:15.117244
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    results = main(module)
    assert results['ansible_facts']['getent_passwd'] == {'root': ['x', 0, 0]}



# Generated at 2022-06-11 07:11:24.807075
# Unit test for function main
def test_main():
    arguments = dict(
        database='passwd',
        key='root',
        split=':',
        fail_key=True)
    module = AnsibleModule(argument_spec=arguments)
    # uncomment next line, to test error conditions
    #module.params['key'] = 'unknown'
    results = main()
    # uncomment next line, to test error conditions
    #results['failed'] = False
    assert results['ansible_facts'] == {'getent_passwd': {'root': ['x', 0, 0, 'root', '/root', '/bin/bash']}}

# Generated at 2022-06-11 07:11:29.041608
# Unit test for function main
def test_main():
    from ansible_collections.misc.not_a_real_collection.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    set_module_args({
        'database': 'passwd',
        'key' : 'root',
    })
    main()



# Generated at 2022-06-11 07:11:40.556103
# Unit test for function main
def test_main():
    Mock = type('Mock', (object,), {})
    module = Mock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    module.fail_json = fail_json
    module.exit_json = exit_json

    module.params = {
        'database': 'passwd',
        'key': 'root',
        'split': ':',
        'fail_key': True,
    }

    #good usage
    main()

    #bad database
    module.params['database'] = 'invalid'
    main()

    #no key in database
    module.params['database'] = 'passwd'
    module.params['key'] = 'invalid'
    main()

    #fail_key=False

# Generated at 2022-06-11 07:11:41.196582
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:11:52.917249
# Unit test for function main
def test_main():
    my_args = {
        'database': 'shadow',
        'key': 'root',
        'fail_key': 'yes',
        'service': '',
        'split': ':',
    }
    FAIL_JSON = {
        'changed': False,
        'failed': True,
    }
    EXIT_JSON = {
        'changed': False,
        'failed': False,
    }

# Generated at 2022-06-11 07:12:06.900304
# Unit test for function main
def test_main():
    db = main()
    assert db is not None

# Generated at 2022-06-11 07:12:15.127577
# Unit test for function main
def test_main():
    getent_state = {'key': 'root', 'database': 'passwd'}
    ansible_module = AnsibleModule(argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    ansible_module.params = getent_state
    #print(getent_state)
    main()

# Generated at 2022-06-11 07:12:15.783426
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:12:25.093870
# Unit test for function main
def test_main():
    import os
    action_mocker = ActionModuleMocker({'getent': 'getent'})
    test = AnsibleModule(argument_spec={'database': {'type': 'str', 'required': True}, 'key': {'type': 'str', 'log': False}, 'split': {'type': 'str'}}, supports_check_mode=True)
    result = test.getent(database='passwd', key='root')
    assert result.get('ansible_facts') == {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']}}


# Test playbook

# Generated at 2022-06-11 07:12:33.229533
# Unit test for function main
def test_main():
    import sys
    import json
    import os

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    import ansible.module_utils.basic
    from ansible.module_utils.basic import *
    from ansible.module_utils._text import to_bytes

    def exec_command(self, cmd, tmp_path, environ_update=None, persist_files=False, data=None):
        arg_string = ''
        for arg in cmd:
            arg_string += ' ' + arg
        print(arg_string)


# Generated at 2022-06-11 07:12:44.578492
# Unit test for function main
def test_main():
    import os
    import copy
    import ansible.module_utils.posix
    import ansible.module_utils.basic
    os.environ = {
        'PATH': '/usr/bin:/bin',
        'ANSIBLE_MODULE_ARGS': '{}',
        'ANSIBLE_MODULE_RETRIES': '0'
    }

# Generated at 2022-06-11 07:12:45.240162
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:12:55.664366
# Unit test for function main
def test_main():
    # Create the module object
    module = AnsibleModule(
        argument_spec = dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Create the ansible module_utils object for ansible module calls
    m_ansible = AnsibleModuleUtils(module)
    # Create the MockModule object
    mm = MockModule(module)
    # Create the MockCommand object
    mc = MockCommand(module)
    # Set the MockModule command value
    mm.values['command'] = 'getent'
    # Set the MockCommand rc

# Generated at 2022-06-11 07:13:07.383008
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')
    #rc = module.params['rc']

    getent_bin = module.get_

# Generated at 2022-06-11 07:13:10.297577
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={
        'database': {'type': 'str', 'required': True},
    })
    module.exit_json = lambda x: x
    assert 'ansible_facts' in main().keys()

# Generated at 2022-06-11 07:13:44.064668
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    import sys
    import os

    def myrun_command(cmd, env, cwd):
        class MockPopen(object):
            def __init__(self, cmd, env=None, cwd=None):
                self.cmd = cmd
                self.pid = '123'
                self.returncode = 0
                self.stdout = "::1\tlocalhost\n127.0.0.1\tlocalhost\n"
                self.stderr = ""

            def communicate(self, input=None):
                return (self.stdout, self.stderr)


# Generated at 2022-06-11 07:13:52.372549
# Unit test for function main
def test_main():

    # importing pdb to give opportunity to attach debugger in case somthing goes wrong
    import pdb
    import sys

    # mocking module.run_command as it is not needed for unit testing
    # but we want to keep covering % as a whole

    import module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    def run_command(module, cmd, check_rc=True):
        rc = 0

        # empty output is expected for which we will be mocked pdb
        out = ''
        err = ''

        return rc, out, err

    def exit_json(module, *args, **kwargs):
        print('exit_json called')
        print(str(args))
        print(str(kwargs))
        sys.exit(0)


# Generated at 2022-06-11 07:14:01.963539
# Unit test for function main
def test_main():
    """
    Test for main
    """
    import sys
    import os
    import pytest

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    to_patch = "ansible.module_utils.getent.getent_bin"


# Generated at 2022-06-11 07:14:12.209166
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'root'
    split = ':'

    getent_bin = module.get_bin_path('getent', True)

    if key is not None:
        cmd = [getent_bin, database, key]
    else:
        cmd = [getent_bin, database]

    if split is None and database in colon:
        split = ':'


# Generated at 2022-06-11 07:14:22.847397
# Unit test for function main
def test_main():

    class Args(object):
        def __init__(self, database, key=None, split=None, fail_key=False):
            self.database = database
            self.key = key
            self.split = split
            self.fail_key = fail_key

    class Module(object):
        def __init__(self, fail_json_function, exit_json_function):
            self.fail_json = fail_json_function
            self.exit_json = exit_json_function
            self.params = Args(database, key, split, fail_key)

        def get_bin_path(self, bin_path, required):
            if bin_path == 'getent':
                return DummyGetent()


# Generated at 2022-06-11 07:14:34.103018
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO
    from os import path
    from sys import argv

    argv.append('--ignore-plugin-errors=mystdout,mystderr')
    argv.append('--ignore-plugin-errors-filters=' + path.realpath(__file__))
    argv.append('--ignore-deprecations')

    stdout = StringIO()
    stderr = StringIO()
    mystdout = basic._AnsibleStdout(stdout=stdout)
    mystderr = basic._AnsibleStderr(stderr=stderr)


# Generated at 2022-06-11 07:14:40.940905
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str'),
            key=dict(type='str'),
            service=dict(type='str'),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    args = {
        'database': 'passwd',
        'key': 'root',
        'service': None,
        'split': ':'
    }
    module.params = args
    main()

# Generated at 2022-06-11 07:14:47.364921
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
                                            database=dict(type='str', required=True),
                                            key=dict(type='str', no_log=False),
                                            service=dict(type='str'),
                                            split=dict(type='str'),
                                            fail_key=dict(type='bool', default=True),
                                            ),
                           supports_check_mode=True)
    json_output = {"ansible_facts": {"getent_aliases": {}}}
    module.exit_json(**json_output)



# Generated at 2022-06-11 07:14:50.998902
# Unit test for function main
def test_main():
    # Test with no params
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command('echo test')
    assert rc == 0
    assert out == "test\n"
    assert err == ''

# Generated at 2022-06-11 07:14:51.798998
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:15:54.515062
# Unit test for function main
def test_main():
    raise NotImplementedError

# Generated at 2022-06-11 07:16:04.970320
# Unit test for function main
def test_main():

    # Unit test for function main
    def test_main():
        # Module arguments
        arguments = dict(
            database='passwd',
            key='root',
            split=':',
            fail_key=True,
        )

        # Module positioning args
        from ansible.compat.tests import unittest
        from ansible.compat.tests.mock import MagicMock, patch

        # AnsibleModule Mock object
        module = MagicMock(AnsibleModule)
        module.params = arguments

        # Getent return values
        rc = 0
        out = '''root:x:0:0:root:/root:/bin/zsh
bin:x:1:1:bin:/bin:/bin/false
daemon:x:2:2:daemon:/sbin:/bin/false
'''
        err = ''

# Generated at 2022-06-11 07:16:05.512740
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:16:06.588585
# Unit test for function main
def test_main():

    print("Unit test for function main")
    print("Not implemented")

# Generated at 2022-06-11 07:16:15.945529
# Unit test for function main
def test_main():
    # Mock the class AnsibleModule
    class Module:
        def __init__(self, argument_spec_dict, supports_check_mode, no_log):
            self.argument_spec_dict = argument_spec_dict
            self.supports_check_mode = supports_check_mode
            self.no_log = no_log

        def get_bin_path(self, getent, required):
            return "/usr/bin/getent"

        def run_command(self, cmd):
            return (0, "a:x:500:500:a:/home/a:/bin/bash\nb:x:501:501:b:/home/b:/bin/bash\n", "")

        def fail_json(self, msg, exception):
            print(msg)
            print(exception)


# Generated at 2022-06-11 07:16:25.370256
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Encoding must be a string type
    if sys.version_info[0] > 2:
        a = "string"
    else:
        a = unicode("string")


# Generated at 2022-06-11 07:16:37.346413
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:16:48.910472
# Unit test for function main
def test_main():
    rc = 0 # return code
    out = "foo bar baz" # output
    err = "Nothing"
    args = ['foo','bar','baz']

    test_module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )
    test_module.get_bin_path = lambda x,y: 'getent_bin'
    test_module.run_command = lambda x: (rc, out, err)

    split = None
    database = 'passwd'
    key = None
    fail_key = True


# Generated at 2022-06-11 07:16:59.299769
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:10.132914
# Unit test for function main
def test_main():
    import os
    import shlex
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    if "DUMMY_GETENT" not in os.environ:
        os.environ['DUMMY_GETENT'] = '1'
        os.system("gcc -o tests/dummy_getent tests/dummy_getent.c")
        os.environ['PATH'] = ".:./tests:" + os.environ['PATH']


# Generated at 2022-06-11 07:19:42.259208
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path

    import os
    import sys
    import pytest

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Only run the tests if getent is present

# Generated at 2022-06-11 07:19:52.081351
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    # Populate test data
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.run_command = lambda cmd: (0, ''.join([to_bytes(s) + str.encode('\n') for s in cmd]), '')

    getent_bin = module.get

# Generated at 2022-06-11 07:19:53.818069
# Unit test for function main
def test_main():
    import getent
    os.path.exists('/root/devops-python/ansible/module_utils')

# Generated at 2022-06-11 07:19:58.164943
# Unit test for function main
def test_main():
    spec = dict(
        database=dict(type='str', required=True),
        key=dict(type='str', no_log=False),
        service=dict(type='str'),
        split=dict(type='str'),
        fail_key=dict(type='bool', default=True),
        )

    module = AnsibleModule(argument_spec=spec)
    rc, out, err = main()

# Generated at 2022-06-11 07:20:08.013234
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        )
    )

    module._ansible_no_log = False
    getent_bin = module.get_bin_path('getent', True)
    module.run_command = MagicMock()
    rc = 1

    if getent_bin:
        if rc == 1:
            module.run_command.side_effect = OSError("Error")

# Generated at 2022-06-11 07:20:08.677138
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:20:19.974916
# Unit test for function main
def test_main():
    from ansible.modules.system.getent import main
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    if float(ansible_version) < 2.11:
        results = {'ansible_facts': {'getent_passwd': {'root': ['x', '0', '0', 'root', '/root', '/bin/bash']},'getent_group': {'root': ['x', '0', 'root']}}}

        # check results with only one record

# Generated at 2022-06-11 07:20:27.298222
# Unit test for function main
def test_main():
    import os
    import pytest
