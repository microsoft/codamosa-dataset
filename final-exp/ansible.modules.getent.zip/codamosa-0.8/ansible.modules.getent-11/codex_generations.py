

# Generated at 2022-06-11 07:10:44.989026
# Unit test for function main
def test_main():
  assert False

# Generated at 2022-06-11 07:10:53.139277
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
            )
    )

    rc = 0
    out = ''
    err = ''
    # rc = 1
    # out = ''
    # err = 'Missing arguments, or database unknown.'
    # rc = 2
    # out = ''
    # err = 'One or more supplied key could not be found in the database.'
    # rc = 3
    # out = ''
    # err = 'Enumeration not supported on this database.'

    module.run_command = mock.Mock(return_value=(rc, out, err))



# Generated at 2022-06-11 07:11:05.649531
# Unit test for function main
def test_main():
    # Mock functions
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    setattr(module,'get_bin_path',lambda x,y: '/usr/bin/getent')


    # Mock function calls

# Generated at 2022-06-11 07:11:12.744185
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            database = dict(type='str', required=True),
            key = dict(type='str', no_log=False),
            split = dict(type='str', default=None),
            fail_key = dict(type='bool', default=True),
        ),
    )
    module.exit_json(changed=False, ansible_facts=dict(getent_passwd='abc'))


# Generated at 2022-06-11 07:11:14.815552
# Unit test for function main
def test_main():
    getent_bin = module.get_bin_path('getent', True)
    cmd = [getent_bin, database, key]

# Generated at 2022-06-11 07:11:25.977332
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    getent_bin = module.get_bin_path('getent', True)
    database = 'passwd'
    cmd = [getent_bin, database]
    rc, out, err = module.run_command(cmd)
    assert rc == 0
    assert out is not ''

# Generated at 2022-06-11 07:11:34.406908
# Unit test for function main
def test_main():
    record = {
        "ansible_facts": {
            "getent_passwd": {
                "root": [
                    "x",
                    "0",
                    "0",
                    "root",
                    "/root",
                    "/bin/bash",
                ],
                "www-data": [
                    "x",
                    "33",
                    "33",
                    "www-data",
                    "/var/www",
                    "/usr/sbin/nologin",
                ],
            },
        },
    }
    # FIXME
    #assert main(argv=["hello", "bob", "--test"]) == record



# Generated at 2022-06-11 07:11:45.407827
# Unit test for function main
def test_main():

    import sys
    import os
    import shutil
    import json
    import copy
    import time

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import _load_params
    from ansible.module_utils.basic import _get_bin_path
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.basic import set_fs_attributes_if_different
    from ansible.module_utils.basic import _get_parsable_value

    sys.path.insert(0, 'utils')
    sys.path.insert(0, os.path.dirname(__file__))
    from getent import main as getent_main

    os.chdir(os.path.dirname(__file__))

    # Over

# Generated at 2022-06-11 07:11:56.195743
# Unit test for function main
def test_main():
    parameters = {'_ansible_check_mode': False, '_ansible_diff': False, '_ansible_debug': False, '_ansible_verbosity': 1, 'database': 'passwd', 'fail_key': True, 'key': 'root', '_ansible_version': '2.4.2.0', 'service': None, 'split': None}
    module = AnsibleModule(argument_spec = {'key': {'no_log':True,'type':'str'}, 'split': {'type': 'str'}, 'database': {'required':True,'type':'str'}, 'service': {'type':'str'}, 'fail_key': {'default':True,'type':'bool'}}, supports_check_mode=True)

# Generated at 2022-06-11 07:12:06.167802
# Unit test for function main
def test_main():

    # Import ansible.module_utils.basic so that we can mock the return values
    # of module_utils functions
    import ansible.module_utils.basic

    module_args = dict(
        database='passwd',
        key='root'
    )

    def exec_command_mock(self, *args, **kwargs):
        return 0, 'test\nreturn\nstring', ''

    ansible.module_utils.basic.AnsibleModule.run_command = exec_command_mock

    #mock_getent_bin = mock.Mock()
    #mock_getent_bin.return_value = 'test'
    #mock_getent_bin.get_bin_path.return_value = '/usr/bin/getent'

    #with mock.patch('ansible_collections.

# Generated at 2022-06-11 07:12:29.489660
# Unit test for function main
def test_main():
    import sys
    import tempfile
    main_rc = main()
    # we have to do it this way as AnsibleModule has
    # a caching mechanism where it remembers any args
    # passed in to AnsibleModule.run_command
    # so we have to clear it out by creating a new
    # instance of AnsibleModule
    del main.module
    main.module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    out = tempfile.SpooledTemporaryFile()
    sys.stdout = out

    main_rc = main()
    print(main_rc)


# Generated at 2022-06-11 07:12:31.540890
# Unit test for function main
def test_main():
    os.environ = {'ANSIBLE_MODULE_ARGS': '{"database":"passwd","key":"brian","fail_key":True}'}
    main()

# Generated at 2022-06-11 07:12:42.523379
# Unit test for function main
def test_main():
    import sys
    import getent
    
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)


# Generated at 2022-06-11 07:12:43.217133
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:12:46.814777
# Unit test for function main
def test_main():
    from ansible.compat.tests import unittest

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ExitJsonError(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        raise AnsibleFailJson(kwargs)

    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(kwargs)


# Generated at 2022-06-11 07:12:56.428640
# Unit test for function main
def test_main():
    import os
    import subprocess
    import sys
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    database = module.params['database']
    database_file = module.params['database']
    key = module.params.get('key')
    output = ""
    if database == 'group':
        database_file = database_file.replace('group','group-')
    database_file = database_file.replace(':','_')

# Generated at 2022-06-11 07:12:57.110905
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:13:08.615502
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import pytest
    # FIXME:
    # - handle this in a more sensible way
    # - get getent test data
    class ModuleStub:
        def __init__(self, **kwargs):
            self.params = kwargs.get('params', {})
            self.bin_path = kwargs.get('bin_path', {})
            self.run_params = {}

        def get_bin_path(self, cmd, required=False, opt_dirs=None):
            if cmd in self.bin_path:
                return self.bin_path[cmd]
            return cmd

        def run_command(self, cmd):
            assert cmd == self.run_params['cmd']
            return self.run_params['rc'], self.run_params

# Generated at 2022-06-11 07:13:20.136535
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'database': {
                'type': 'str',
                'required': True
            },
            'key': {
                'type': 'str',
                'no_log': False
            },
            'split': {
                'type': 'str'
            },
            'service': {
                'type': 'str'
            },
            'fail_key': {
                'type': 'bool',
                'default': True
            }
        },
        supports_check_mode=True
    )
    setattr(module, 'run_command', lambda *args, **kwargs: (0, 'zaphod beeblebrox', None))
    setattr(module, 'get_bin_path', lambda *args, **kwargs: '/usr/bin/getent')

# Generated at 2022-06-11 07:13:30.681514
# Unit test for function main
def test_main():
    getent_bin = '/usr/bin/getent'
    module_dict = {
        'run_command': run_command,
        'get_bin_path': get_bin_path,
        'fail_json': fail_json,
        'exit_json': exit_json,
        'params': {
            'database': 'hosts',
        },
    }

    # Test positive
    cmd = [getent_bin, 'hosts']
    out = '127.0.0.1 localhost\n127.1.1.1 foo'
    rc = 0
    res = {'getent_hosts': {'localhost': ['127.0.0.1'], 'foo': ['127.1.1.1']}}
    res_rc = 0
    res_out = None
    res_err = None

# Generated at 2022-06-11 07:14:12.393040
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    module.get_bin_path = get_bin_path

    module.run_command = run_command

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')

# Generated at 2022-06-11 07:14:16.416601
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(database=dict(type="str", required=True)))
    module.get_bin_path = lambda module, executable, required=False: ('/bin/' + executable)
    module.run_command = lambda params: (0, "", "")
    main()

# Generated at 2022-06-11 07:14:27.827375
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        # We wait for check_mode to fail, then re-enable it
        supports_check_mode=False,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_

# Generated at 2022-06-11 07:14:38.704221
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True)
        ),
        supports_check_mode=True,
    )

    test_results = {'getent_passwd': {}}

    test_results['getent_passwd']['root'] = 'x:0:0:root:/root:/bin/bash'.split(':')
    test_results['getent_passwd']['nobody'] = 'x:65534:65534:nobody:/nonexistent:/bin/sh'.split(':')


# Generated at 2022-06-11 07:14:45.586218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Set params
    #module.params = {}

    ##########################################################################
    # Call main() function here
    ##########################################################################
    main()

# Generated at 2022-06-11 07:14:48.164187
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    module.exit_json(ansible_facts={})


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:14:49.741762
# Unit test for function main
def test_main():
    # Unit test for ansible fact gathering for getent
    pass

# Generated at 2022-06-11 07:15:00.346824
# Unit test for function main
def test_main():
    res = module_main()
    assert res == {'msg': 'Unexpected failure!', 'failed': True}
    # Check that the command is properly built and executed
    assert module.run_command.called
    # Check that rc, out and err vars are set
    assert module.rc
    assert module.out
    assert module.err

    # Make the subprocess exit with OK (0)
    module.subprocess.call.return_value = 0
    # Make the subprocess output something
    module.subprocess.check_output.return_value = 'foo:bar'
    res = module_main()
    assert res == {'ansible_facts': {'getent_foo': {'foo': ['bar']}}, 'changed': False, 'failed': False}

# Generated at 2022-06-11 07:15:05.759918
# Unit test for function main
def test_main():
    inp_args = []
    inp_args.append(('database','passwd'))
    inp_args.append(('key','root'))
    inp_args.append(('fail_key','True'))
    # inp_args.append(('split','None'))

    module = AnsibleModule(argument_spec = inp_args)

    main()


# Generated at 2022-06-11 07:15:16.038821
# Unit test for function main
def test_main():
    import tempfile

    test_hosts = """127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain4
::1 localhost localhost.localdomain localhost6 localhost6.localdomain6
""".splitlines()
    test_passwd = """root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
nobody:x:65534:65534:nobody:/nonexistent:/sbin/nologin
""".splitlines()

# Generated at 2022-06-11 07:16:30.870719
# Unit test for function main
def test_main():
    import sys
    import inspect
    from ansible.module_utils.six import PY2

    is_py2 = PY2

    # Mock input params
    class Entry(object):
        '''
        Class representing some object, we will assign a dict to it's member dict
        '''

        def __init__(self):
            self.dict = dict()

    # Get function arguments
    arg_spec = inspect.getargspec(main)
    func_args = [attr for attr in arg_spec[0] if attr != 'self']

    # Mock AnsibleModule
    am = Entry()
    am.params = dict()

    # Mock AnsibleModule function return values
    rc = 0
    out = 'foo'
    err = None

    # Create our mock object

# Generated at 2022-06-11 07:16:40.513692
# Unit test for function main
def test_main():
    getent_bin = "/usr/bin/getent"
    def exec_command_mock(args, check_rc=True):
        if args == [getent_bin, 'group', '0']:
            return 0, 'root:x:0:', ''

# Generated at 2022-06-11 07:16:51.941731
# Unit test for function main

# Generated at 2022-06-11 07:16:57.132696
# Unit test for function main
def test_main():
    # Setup actions
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')


# Generated at 2022-06-11 07:17:05.086192
# Unit test for function main
def test_main():
    """
    Unit test to test function main
    """
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    getent_bin = module.get_bin_path('getent', True)
    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')

    if key is not None:
        cmd = [getent_bin, database, key]

# Generated at 2022-06-11 07:17:16.392046
# Unit test for function main
def test_main():
    from ansible.module_utils import getent
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            split=dict(type='str'),
            service=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = 'passwd'
    key = 'root'
    split = ':'

    getent_bin = module.get_bin_path('getent', True)



# Generated at 2022-06-11 07:17:22.201901
# Unit test for function main
def test_main():
    source = {
        'check_mode': False,
        'database': 'passwd',
        'key': 'root',
        'module_args': {
            'database': 'passwd',
            'key': 'root',
        },
        'module_name': 'getent',
        'play_hosts': ['host'],
        'split': None,
    }
    module = AnsibleModule(**source)
    main()

# Generated at 2022-06-11 07:17:32.189762
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    colon = ['passwd', 'shadow', 'group', 'gshadow']

    database = module.params['database']
    key = module.params.get('key')
    split = module.params.get('split')
    service = module.params.get('service')
    fail_key = module.params.get('fail_key')

    getent_bin = module.get_bin_path('getent', True)

   

# Generated at 2022-06-11 07:17:38.674345
# Unit test for function main
def test_main():
    #save the current getent module
    saved_getent = __import__('getent')
    import sys
    #create a mock getent module and insert it in the module search path
    sys.modules['getent'] = __import__('ansible.module_utils.basic')
    sys.modules['getent'].run_command = lambda *args, **kwargs: (0, 'a b c\nd\te\tf', None)
    main()
    main()
    main()
    main()
    main()
    main()
    #restore the original getent
    sys.modules['getent'] = saved_getent

# Generated at 2022-06-11 07:17:44.352919
# Unit test for function main
def test_main():
    argv = ['getent', 'passwd', 'root']

    rc, out, err = module.run_command(cmd)
    rc = 0
    err = ''

# Generated at 2022-06-11 07:20:14.416711
# Unit test for function main
def test_main():
    # assert False # to see the traceback
    assert True

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 07:20:24.073100
# Unit test for function main
def test_main():
    import getpass

    if getpass.getuser() == 'root':
        # Test system from root user
        root_modules = ['gshadow', 'shadow', 'group', 'passwd']
        nonroot_modules = ['hosts', 'services', 'protocols', 'netgroup', 'rpc', 'networks', 'ethers', 'bootparams', 'aliases', 'ethers', 'automount', 'networks', 'protocols', 'rpc', 'services']
        all_modules = root_modules + nonroot_modules
    else:
        # Test system from non-root user
        nonroot_modules = ['hosts', 'protocols', 'netgroup', 'networks', 'ethers', 'automount', 'networks', 'protocols', 'services']
        all_modules = nonroot_modules


# Generated at 2022-06-11 07:20:33.882502
# Unit test for function main
def test_main():
    """
    A simple test of module main.
    """
    # Create a temporary test file
    module = AnsibleModule(
        argument_spec=dict(
            database=dict(type='str', required=True),
            key=dict(type='str', no_log=False),
            service=dict(type='str'),
            split=dict(type='str'),
            fail_key=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # This is what the internal variable look like
    test = dict(
        database = 'passwd',
        key = 'root',
        service = '',
        split = '',
        fail_key = True
    )
    # Set internal variable
    module.params = test
    # Perform the test
    results = main()