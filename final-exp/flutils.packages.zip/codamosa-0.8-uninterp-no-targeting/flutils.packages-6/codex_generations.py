

# Generated at 2022-06-21 12:56:02.023836
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # type: () -> None
    """Test the constructor of class _VersionInfo."""
    from flutils.testing import UnitTester

    ver_info = _VersionInfo('1.2.3',
                            _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                                         pre_num=-1, name='major'),
                            _VersionPart(pos=1, txt='2', num=2, pre_txt='',
                                         pre_num=-1, name='minor'),
                            _VersionPart(pos=2, txt='3', num=3, pre_txt='',
                                         pre_num=-1, name='patch'),
                            -1)

# Generated at 2022-06-21 12:56:10.315988
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    check = _build_version_info('1.2.3')
    assert check.version == '1.2.3'
    assert check.major.pos == 0
    assert check.major.txt == '1'
    assert check.major.num == 1
    assert check.major.pre_txt == ''
    assert check.major.pre_num == -1
    assert check.major.name == 'major'
    assert check.minor.pos == 1
    assert check.minor.txt == '2'
    assert check.minor.num == 2
    assert check.minor.pre_txt == ''
    assert check.minor.pre_num == -1
    assert check.minor.name == 'minor'
    assert check.patch.pos == 2
    assert check.patch.txt == '3'
   

# Generated at 2022-06-21 12:56:22.277827
# Unit test for function bump_version
def test_bump_version():
    print('Test function bump_version')

    # pylint: disable=R0204

    def _compare(ver, expected):
        actual = bump_version(ver)
        if actual != expected:
            print('\tERROR: %r != %r' % (actual, expected))
        else:
            print('\tGood: %r' % actual)

    # pylint: disable=E1101
    print('\tTest no pre-release')

    _compare('1.2.2', '1.2.3')
    _compare('1.0.0', '1.0.1')
    _compare('1.2.3', '1.2.4')
    _compare('1.2.9', '1.2.10')

# Generated at 2022-06-21 12:56:30.229110
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert part.txt in ('1', '2', '3')
        assert part.num in (1, 2, 3)
        assert part.pre_txt in ('', '', '')
        assert part.pre_num in (-1, -1, -1)
        assert part.name in ('major', 'minor', 'patch')

    ver_obj = StrictVersion('1.2.3a4')
    for part in _each_version_part(ver_obj):
        if part.pos == 0:
            assert part.pre_txt in ('', '', '')

# Generated at 2022-06-21 12:56:42.779823
# Unit test for function bump_version

# Generated at 2022-06-21 12:56:48.411518
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0613,W0612
    from flutils.packages import bump_version


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-21 12:57:00.486368
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ['1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3', 3, '', -1, 'patch'), -1]
    assert _build_version_info('1.2.3') == _VersionInfo(*args)

    args = ['1.2.3b2', _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3b2', 3, 'b', 2, 'patch'), 2]
    assert _build_version_info('1.2.3b2') == _VersionInfo

# Generated at 2022-06-21 12:57:12.432830
# Unit test for function bump_version
def test_bump_version():
    """Test function bump version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:57:24.284944
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    def _test_set(version, position, pre_release, expect):
        bump = bump_version(version, position, pre_release)
        assert bump == expect, "Got (%r) expected (%r)" % (bump, expect)

    default = 2

    _test_set('1.2.2', default, None, '1.2.3')
    _test_set('1.2.3', default, None, '1.2.4')
    _test_set('1.2.3', default, 'a', '1.2.4a0')
    _test_set('1.2.4a0', default, 'a', '1.2.4a1')

# Generated at 2022-06-21 12:57:33.273575
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # noinspection PyUnusedLocal
    def _print(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        out = bump_version(version=version, position=position,
                           pre_release=pre_release)
        print(out)

    # noinspection PyUnusedLocal
    def _test(
            version: str,
            expected: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        out = bump_version(version=version, position=position,
                           pre_release=pre_release)
        if out != expected:
            print('***FAIL***')
            print(version)

# Generated at 2022-06-21 12:58:00.763697
# Unit test for function bump_version

# Generated at 2022-06-21 12:58:08.415064
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.2') == '0.0.3'

    assert bump_version('0.0.0', position=1) == '0.1'
    assert bump_version('0.0.1', position=1) == '0.1'
    assert bump_version('0.0.2', position=1) == '0.1'
    assert bump_version('0.1.0', position=1) == '0.2'
    assert bump_version('0.1.1', position=1) == '0.2'

# Generated at 2022-06-21 12:58:16.064589
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # 0.1.0
    ver_info = _build_version_info('0.1.0')
    assert ver_info.version == '0.1.0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '1'
    assert ver_info.minor.num == 1
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver

# Generated at 2022-06-21 12:58:21.229653
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.2')
    bump_version('1.2.2', 0, 'a')
    bump_version('1.2.2', 0, 'b')
    bump_version('1.2.2', 0)
    bump_version('1.2.2', 1)
    bump_version('1.2.2', 1, 'a')
    bump_version('1.2.2', 1, 'b')
    bump_version('1.2.2', 2)
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

# Generated at 2022-06-21 12:58:31.952202
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=protected-access
    assert _VersionInfo('0.0',
                        _VersionPart(pos=0, txt='0', num=0, pre_txt='',
                                     pre_num=-1, name='major'),
                        _VersionPart(pos=1, txt='0', num=0, pre_txt='',
                                     pre_num=-1, name='minor'),
                        _VersionPart(pos=2, txt='', num=0, pre_txt='',
                                     pre_num=-1, name='patch'),
                        -1) == _build_version_info('0.0')


# Generated at 2022-06-21 12:58:37.097972
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    The unit tests are in: ``tests/packages/test_bump_version.py``

    """
    # pylint: disable=W0612
    __func = bump_version


if __name__ == '__main__':
    # imported package, don't execute
    test_bump_version()

# Generated at 2022-06-21 12:58:47.057850
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    maj = _VersionPart(0, '1', 1, '', -1, 'major')
    assert isinstance(maj, _VersionPart) is True
    assert maj.pos == 0
    assert maj.txt == '1'
    assert maj.num == 1
    assert maj.pre_txt == ''
    assert maj.pre_num == -1
    assert maj.name == 'major'

    min_alpha = _VersionPart(1, '2a0', 2, 'a', 0, 'minor')
    assert isinstance(min_alpha, _VersionPart) is True
    assert min_alpha.pos == 1
    assert min_alpha.txt == '2a0'
    assert min_alpha.num == 2
    assert min_alpha.pre_txt == 'a'
    assert min_alpha.pre_num == 0


# Generated at 2022-06-21 12:59:00.470747
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    a_ver_info = _VersionInfo(
        version='0.0.2',
        major=_VersionPart(
            pos=0,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    b_ver_info = _build_version_info

# Generated at 2022-06-21 12:59:11.455207
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test function for class _VersionPart.

    (*New in version 0.3*)
    """

    # Load the class to test
    from flutils.packages import _VersionPart

    # Construct object
    obj = _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='a',
        pre_num=2,
        name='minor'
    )

    assert obj.pos == 1
    assert obj.txt == '2'
    assert obj.num == 2
    assert obj.pre_txt == 'a'
    assert obj.pre_num == 2
    assert obj.name == 'minor'

    # Delete object
    del (obj)


# Generated at 2022-06-21 12:59:25.347784
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=R0914
    """Test for constructor for class _VersionInfo.

    :return:
        ``None``

    """
    from flutils.packages import _VersionInfo, _VersionPart
    from flutils.testingutils import msg, testcast

    StartTesting = False
    with msg('Test:', '_VersionInfo'):
        StartTesting = True
        ver_str = '1.2.3'
        ver_info = _VersionInfo(
            ver_str,
            _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3', 3, '', -1, 'patch'),
            -1,
        )