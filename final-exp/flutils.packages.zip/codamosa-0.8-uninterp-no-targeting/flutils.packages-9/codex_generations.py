

# Generated at 2022-06-21 12:55:58.452101
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 12:56:09.502965
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('0.1.2b3')
    assert info.version == '0.1.2b3'
    assert info.major.pos == 0
    assert info.major.txt == '0'
    assert info.major.num == 0
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '1b3'
    assert info.minor.num == 1
    assert info.minor.pre_txt == 'b'
    assert info.minor.pre_num == 3
    assert info.minor.name == 'minor'
    assert info.patch.pos == 2

# Generated at 2022-06-21 12:56:19.701359
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('0.1.1',
                        _VersionPart(0, '0', 0, '', 0, 'major'),
                        _VersionPart(1, '1', 1, '', 0, 'minor'),
                        _VersionPart(2, '1', 1, '', 0, 'patch'),
                        -1) == _build_version_info('0.1.1')
    assert _VersionInfo('0.1.1a0',
                        _VersionPart(0, '0', 0, '', 0, 'major'),
                        _VersionPart(1, '1a0', 1, 'a', 0, 'minor'),
                        _VersionPart(2, '1', 1, '', 0, 'patch'),
                        -1) == _build_version_info('0.1.1a0')

# Generated at 2022-06-21 12:56:27.280377
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    version = _build_version_info('1.2.3')
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert version.major == part
    part = _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )
    assert version.minor == part

# Generated at 2022-06-21 12:56:32.912936
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ('1.2.3', _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
            _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
            _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'), -1)
    _VersionInfo(*args)


# Generated at 2022-06-21 12:56:44.419114
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), -1) == \
        _build_version_info('1.2.3')
    assert _VersionInfo('1.2.3a4', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, 'a', 4, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), 1) == \
        _build_version_info('1.2.3a4')

# Generated at 2022-06-21 12:56:53.716495
# Unit test for function bump_version
def test_bump_version():

    def _test_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> str:
        """Unit test helper function.

        *New in version 0.3*
        """
        actual = bump_version(version, position, pre_release)
        assert actual == expected, (
            "bump_version('%s', position=%s, pre_release=%r) should be "
            "%r not %r" % (
                version,
                position,
                pre_release,
                expected,
                actual
            )
        )
        return actual

    _test_version('1.2.2', 2, None, expected='1.2.3')

# Generated at 2022-06-21 12:57:03.385532
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3a0'
    parts: List[_VersionPart] = list(_each_version_part(StrictVersion(version)))
    assert parts == [
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major',
        ),
        _VersionPart(
            pos=1,
            txt='2a0',
            num=2,
            pre_txt='a',
            pre_num=0,
            name='minor',
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch',
        ),
    ]
    version

# Generated at 2022-06-21 12:57:14.576982
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:57:25.890144
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major == _VersionPart(0, '1', 1, '', -1, 'major')
    assert ver_info.minor == _VersionPart(1, '2', 2, '', -1, 'minor')
    assert ver_info.patch == _VersionPart(2, '3', 3, '', -1, 'patch')
    assert ver_info.pre_pos == -1
    ver_info = _build_version_info('1.2.3b1')
    assert ver_info.version == '1.2.3b1'

# Generated at 2022-06-21 12:57:49.296782
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120
    from os import path
    from unittest import TestCase

    from flutils.packages import bump_version, verify_version

    test_dir, _ = path.split(__file__)
    test_data_dir = path.join(test_dir, 'data', 'version')
    versions_file = path.join(test_data_dir, 'versions.txt')

    with open(versions_file) as fp:
        versions = fp.readlines()

    versions = [ver.split(' -> ') for ver in versions]
    versions = [ver for ver in versions if len(ver) == 2]

    # Tests that are expected to fail

# Generated at 2022-06-21 12:57:59.811652
# Unit test for function bump_version
def test_bump_version():
    "Test that bump_version works well"
    import pytest
    from flutils.packages import bump_version
    from distutils.version import StrictVersion
    # Test that bump_version works well
    v = bump_version('1.2.3')
    assert v == '1.2.4'
    v = bump_version('1.2.3', position=1)
    assert v == '1.3'
    v = bump_version('1.3.4', position=0)
    assert v == '2.0'
    v = bump_version('1.2.3', prerelease='a')
    assert v == '1.2.4a0'
    v = bump_version('1.2.4a0', pre_release='a')
    assert v == '1.2.4a1'


# Generated at 2022-06-21 12:58:07.803335
# Unit test for function bump_version
def test_bump_version():
    from textwrap import dedent
    from flutils.tests import capture_output


# Generated at 2022-06-21 12:58:17.182610
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    print(':: Testing function bump_version')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:58:27.939018
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    assert_ = namedtuple_testing.NamedTupleAssertion(
        _VersionInfo,
        'version, major, minor, patch, pre_pos',
        '1.2.3, major=0, minor=1, patch=2, position=-1'
    )
    assert_.assertEqual(
        _build_version_info('1.2.3'),
        _VersionInfo(
            '1.2.3',
            _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3', 3, '', -1, 'patch'),
            -1
        )
    )
    assert_.assertE

# Generated at 2022-06-21 12:58:41.218284
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=R0201
    assert _build_version_info('1.2')
    assert _build_version_info('1.2.0')
    assert _build_version_info('1.2.0a0')
    assert _build_version_info('1.2.0a1')
    assert _build_version_info('1.2.0b0')
    assert _build_version_info('1.2.0b1')
    assert _build_version_info('1.2.0')
    assert _build_version_info('1.2.1a0')
    assert _build_version_info('1.2.1b0')
    assert _build_version_info('1.2.1a1')

# Generated at 2022-06-21 12:58:44.271907
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert str(_VersionPart(0, '1', '1', '', '', '')) ==\
        "VersionPart(pos=0, txt='1', num='1', pre_txt='', pre_num='', name='')"



# Generated at 2022-06-21 12:58:57.985578
# Unit test for function bump_version
def test_bump_version():
    """PyTest for the function bump_version."""
    import pytest
    from os.path import abspath
    from sys import path
    path.insert(0, abspath('./flutils'))

    from flutils.packages import bump_version


# Generated at 2022-06-21 12:59:10.008926
# Unit test for function bump_version
def test_bump_version():
    """
    Test version bumping.
    """
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:59:19.018738
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test_version_part = _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert test_version_part.pos == 0
    assert test_version_part.txt == '1'
    assert test_version_part.num == 1
    assert test_version_part.pre_txt == ''
    assert test_version_part.pre_num == -1
    assert test_version_part.name == 'major'



# Generated at 2022-06-21 12:59:35.407504
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo.

    Args:
        None

    Returns:
        None

    """
    # pylint: disable=W0212
    # pylint: disable=W0212
    # pylint: disable=invalid-name
    from _flutils_packages import _test__VersionInfo
    # pylint: enable=W0212
    # pylint: enable=W0212
    # pylint: enable=invalid-name
    _test__VersionInfo()



# Generated at 2022-06-21 12:59:38.973376
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(
        pos=2,
        txt='5',
        num=5,
        pre_txt='',
        pre_num=-1,
        name=''
    )
    assert obj.pos == 2
    assert obj.txt == '5'
    assert obj.num == 5
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == ''



# Generated at 2022-06-21 12:59:45.535412
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.2')
    assert ver_info.version == '1.2.2'
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '2'



# Generated at 2022-06-21 12:59:54.773851
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Unit test for bump_version function."""
    # pylint: disable=W0612
    # Ignore "Unused variable 'rv'" and "Unused variable 'unit'" warnings
    unit, rv = True, None
    should_be = None
    unit = True

# Generated at 2022-06-21 13:00:03.342929
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3'
    ver_obj = StrictVersion(version)
    for pos, num in enumerate(ver_obj.version):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kwargs: Dict[str, Any] = {
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': '',
            'pre_num': -1,
            'name': _BUMP_VERSION_POSITION_NAMES[pos]
        }
        data = _each_version_part(ver_obj)
        assert next(data) == _VersionPart(**kwargs)



# Generated at 2022-06-21 13:00:14.558012
# Unit test for function bump_version
def test_bump_version():
    import sys
    import pathlib
    import unittest
    from unittest.mock import patch, mock_open, call
    from importlib import resources
    from typing import List

    from flutils.packages import (
        bump_version,
        _each_version_part,
        _build_version_info,
    )

    # noinspection PyUnresolvedReferences
    from . import examples as exmpls

    class TestBump(unittest.TestCase):
        """Unit tests for the ``bump_version`` function."""


# Generated at 2022-06-21 13:00:23.499520
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v = _VersionInfo(version="1.2.3a1",
                     major=_VersionPart(pos=0, txt='1', num=1, pre_txt='',
                                        pre_num=-1, name='major'),
                     minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='a',
                                        pre_num=1, name='minor'),
                     patch=_VersionPart(pos=2, txt='3a1', num=3, pre_txt='a',
                                        pre_num=1, name='patch'),
                     pre_pos=1)
    assert v.version == "1.2.3a1"

# Generated at 2022-06-21 13:00:36.103723
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    part0 = _VersionPart(0, '1', 1, '', -1, 'major')
    assert part0 == (0, '1', 1, '', -1, 'major')
    part1 = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert part1 == (1, '2', 2, '', -1, 'minor')
    part2 = _VersionPart(2, '3', 3, '', -1, 'patch')
    assert part2 == (2, '3', 3, '', -1, 'patch')
    part3 = _VersionPart(1, '2a0', 2, 'a', 0, 'minor')

# Generated at 2022-06-21 13:00:47.326005
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(  # NOQA
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    assert _VersionInfo(  # NOQA
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-21 13:00:48.254857
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pass


# Generated at 2022-06-21 13:01:15.260209
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo

    Raises:
        AssertionError: if all of the conditions are not met

    """
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
   

# Generated at 2022-06-21 13:01:27.138028
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.minor.pos == 1
    assert ver_info.patch.pos == 2
    assert ver_info.major.name == 'major'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.name == 'patch'
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '3'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver

# Generated at 2022-06-21 13:01:41.808955
# Unit test for function bump_version
def test_bump_version():
    import pytest

    with pytest.raises(ValueError, match="Invalid version number"):
        bump_version('foobar')

    with pytest.raises(ValueError, match="Invalid position"):
        bump_version('1.1.1', position=10)

    with pytest.raises(ValueError, match="Invalid position"):
        bump_version('1.1.1', position=-4)

    with pytest.raises(ValueError, match="Invalid pre-release"):
        bump_version('1.1.1', pre_release='foo')

    with pytest.raises(ValueError, match="Major"):
        bump_version('1.1.1', position=0, pre_release='alpha')

    with pytest.raises(ValueError, match="Alpha to Beta"):
        bump

# Generated at 2022-06-21 13:01:50.232420
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    print('Testing flutils.packages.bump_version()')
    ver = '1.2.2'
    assert bump_version(ver) == '1.2.3'
    ver = '1.2.3'
    assert bump_version(ver, position=1) == '1.3'
    ver = '1.3.4'
    assert bump_version(ver, position=0) == '2.0'
    ver = '1.2.3'
    assert bump_version(ver, prerelease='a') == '1.2.4a0'
    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'

# Generated at 2022-06-21 13:01:53.838165
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.0')
    for part in _each_version_part(ver_obj):
        print(part)


# Generated at 2022-06-21 13:01:58.662475
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '0', 0, '', -1, '')
    assert part.pos == 0
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'


# Generated at 2022-06-21 13:02:06.442296
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    assert isinstance(ver_info, _VersionInfo)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1

# Generated at 2022-06-21 13:02:17.823404
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for function :func:`flutils.packages.bump_version`.
    """
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_

# Generated at 2022-06-21 13:02:29.460108
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info
    info = _build_version_info('1.2.3a4')
    assert info.major.num == 1
    assert str(info.major) == '1'
    assert info.major.pos == 0
    assert info.minor.num == 2
    assert str(info.minor) == '2'
    assert info.minor.pos == 1
    assert info.patch.num == 3
    assert str(info.patch) == '3'
    assert info.patch.pos == 2
    assert info.pre_pos == 1
    assert info.version == '1.2.3a4'

    info = _build_version_info('1.2a3')
    assert info.major.num == 1

# Generated at 2022-06-21 13:02:41.588103
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    def _test(ver, position=2, prerelease=None):
        return bump_version(ver, position, prerelease)

    assert _test('1.0') == '1.0.1'
    assert _test('1.0', position=0) == '2.0'
    assert _test('1.0', position=1) == '1.1'
    assert _test('1.0', position=1, prerelease='a') == '1.1a0'
    assert _test('1.0', position=1, prerelease='alpha') == '1.1a0'
    assert _test('1.0', position=1, prerelease='b') == '1.1b0'
    assert _test('1.0a0') == '1.0.1'

# Generated at 2022-06-21 13:03:18.997709
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from doctest import testmod
    results = testmod(verbose=False)
    assert not results.failed

# Generated at 2022-06-21 13:03:21.179166
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3a0')

# Generated at 2022-06-21 13:03:24.453847
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    except Exception:
        assert False, 'test for __VersionPart failed'



# Generated at 2022-06-21 13:03:28.803876
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(1, '1', 1, 'a', 0, 'minor')
    assert obj.pos == 1
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == 'a'
    assert obj.pre_num == 0
    assert obj.name == 'minor'


# Generated at 2022-06-21 13:03:35.805311
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for the bump_version() function.
    """

# Generated at 2022-06-21 13:03:42.033111
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'


# Generated at 2022-06-21 13:03:53.226638
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version, major, minor, patch, pre_pos = _build_version_info('1.2.3')
    assert version == '1.2.3'
    assert major == _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                                 pre_num=-1, name='major')
    assert minor == _VersionPart(pos=1, txt='2', num=2, pre_txt='',
                                 pre_num=-1, name='minor')
    assert patch == _VersionPart(pos=2, txt='3', num=3, pre_txt='',
                                 pre_num=-1, name='patch')
    assert pre_pos == -1

    version, major, minor, patch, pre_pos = _build_version_info('1.2')

# Generated at 2022-06-21 13:04:02.097686
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function"""
    import unittest

    class BumpVersionTest(unittest.TestCase):
        """Test the bump_version function"""

        def _run_test(
                self,
                version: str,
                position: int,
                pre_release: Union[str, None],
                expected: str
        ) -> None:
            """Run the base test"""
            self.assertEqual(
                bump_version(version, position, pre_release),
                expected
            )

        def test_version_01(self) -> None:
            """Test the bump_version function"""
            self._run_test('1.2.2', 2, None, '1.2.3')

        def test_version_02(self) -> None:
            """Test the bump_version function"""
            self

# Generated at 2022-06-21 13:04:09.685281
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest.mock import patch


# Generated at 2022-06-21 13:04:18.169079
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pytest import raises
    from random import randint

    args = (randint(0, 100), 'ABC', randint(0, 100), 'XYZ', randint(0, 100), 'LMN')
    inst = _VersionPart(*args)
    assert inst.pos == args[0]
    assert inst.txt == args[1]
    assert inst.num == args[2]
    assert inst.pre_txt == args[3]
    assert inst.pre_num == args[4]
    assert inst.name == args[5]

    with raises(TypeError):
        _VersionPart(randint(0, 100), 'ABC', randint(0, 100), 'XYZ')
