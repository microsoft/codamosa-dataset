

# Generated at 2022-06-21 12:55:59.607931
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pos = 2
    txt = '2'
    num = 2
    pre_txt = 'b'
    pre_num = 1
    name = 'patch'
    tester = _VersionPart(
        pos=pos, txt=txt, num=num, pre_txt=pre_txt,
        pre_num=pre_num, name=name
    )
    assert tester.pos == pos
    assert tester.txt == txt
    assert tester.num == num
    assert tester.pre_txt == pre_txt
    assert tester.pre_num == pre_num
    assert tester.name == name



# Generated at 2022-06-21 12:56:09.546864
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from .data_builder import build_bump_version_data
    from .data_builder import build_bump_version_data_full
    from functools import reduce

    data = build_bump_version_data()
    assert all(
        map(lambda x: bump_version(x['version'], **x['kwargs']) == x['expect'],
            data)
    )

    data = build_bump_version_data_full()
    assert reduce(
        lambda x, y: x and y,
        map(lambda x: bump_version(x['version'], **x['kwargs']) == x['expect'],
            data)
    )

# Generated at 2022-06-21 12:56:19.737650
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises
    from flutils.packages import bump_version

    # Test that bumping works as expected
    versions = {
        '1.2.3': '1.2.4',
        '1.3': '1.4',
        '2.0': '3.0',
        '1.2.3': '1.2.4a0',
        '1.2.4a0': '1.2.4a1',
        '1.2.4a1': '1.2.4b0',
        '2.1.3': '2.2a0',
        '1.2b0': '1.2.1',
    }
    for version in versions:
        assert bump_version(version) == versions[version]

    # Test that pre_release bumps work as expected


# Generated at 2022-06-21 12:56:24.246400
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '1', 1, 'a', 1, 'major')
    assert part.pos == 0
    assert part.num == 1
    assert part.txt == '1'
    assert part.pre_txt == 'a'
    assert part.pre_num == 1



# Generated at 2022-06-21 12:56:29.715487
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart.

    """
    required_keys = _VersionPart.__annotations__.keys()
    obj = _VersionPart(1, 2, 3, 4, 5, 6)
    assert all([hasattr(obj, k) for k in required_keys])
    assert obj.pos == 1
    assert obj.txt == 2
    assert obj.num == 3
    assert obj.pre_txt == 4
    assert obj.pre_num == 5
    assert obj.name == 6


# Generated at 2022-06-21 12:56:42.210274
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0903
    # pylint: disable=R0201
    """Unit test for function bump_version."""
    from flutils.packages import bump_version

    class TestCase(object):
        """Test case object."""

        # pylint: disable=R0913
        # noinspection PyMethodMayBeStatic
        def call_test(
                self,
                version: str,
                position: int,
                pre_release: Optional[str],
                expected: str
        ) -> None:
            """Test method for function bump_version."""
            out = bump_version(version, position, pre_release)
            assert out == expected

    tests = (
        TestCase(),
    )


# Generated at 2022-06-21 12:56:47.277061
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'a',
        'pre_num': 0,
        'name': 'major'
    }
    part = _VersionPart(**kwargs)
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'major'



# Generated at 2022-06-21 12:56:56.388941
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _VersionInfo(version = '2.3.4', major = _VersionPart(0, '2', 2, '', 0, 'major'), minor = _VersionPart(1, '3', 3, '', 0, 'minor'), patch = _VersionPart(2, '4', 4, '', 0, 'patch'), pre_pos = -1)
    assert ver.version == '2.3.4'
    assert ver.major.pos == 0
    assert ver.major.txt == '2'
    assert ver.major.num == 2
    assert ver.major.pre_txt == ''
    assert ver.major.pre_num == 0
    assert ver.major.name == 'major'
    assert ver.minor.pos == 1
    assert ver.minor.txt == '3'
    assert ver.minor.num

# Generated at 2022-06-21 12:57:04.728705
# Unit test for function bump_version
def test_bump_version():
    """Test the flutils.packages.bump_version function.

    :return:
        :obj:`bool`

        * Only ``True`` is returned if all tests pass.
    """
    import os
    import sys
    import unittest

    class Test_bump_version(unittest.TestCase):
        """Test the flutils.packages.bump_version function."""

        def __init__(self, *args, **kwargs):
            """Initialize the test case."""
            super(Test_bump_version, self).__init__(*args, **kwargs)

            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.data_dir = os.path.join(self.test_dir, 'data')


# Generated at 2022-06-21 12:57:15.323845
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from nose.tools import (
        assert_equal,
        assert_raises
    )

    from flutils.packages import bump_version

    # Patch a version number
    assert_equal(bump_version('1.2.2'), '1.2.3')
    assert_equal(bump_version('1.2.3'), '1.2.4')
    assert_equal(bump_version('1.2.3', position=2), '1.2.4')
    # Patch a version number from a pre-release version
    assert_equal(bump_version('1.2.3a1'), '1.2.3')
    assert_equal(bump_version('1.2.3b1'), '1.2.3')

# Generated at 2022-06-21 12:57:45.328670
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        _VersionPart(
            pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major'
        )
    except TypeError:
        assert False

# Generated at 2022-06-21 12:57:53.702600
# Unit test for function bump_version
def test_bump_version():
    def _test(
            version: str,
            position: int,
            pre_release: str,
            expect_out: str
    ):
        args = [version, position]
        if pre_release == 'None':
            args.append(None)
        else:
            args.append(pre_release)
        out = bump_version(*args)
        assert out == expect_out, \
            '\n%r\n%r\n%r\n%r\n%r\n%r' % (
                version,
                position,
                pre_release,
                expect_out,
                out,
                out == expect_out
            )

    _test('1.2.2', 2, 'None', '1.2.3')

# Generated at 2022-06-21 12:58:03.358520
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    import os

    from flutils.pathutils import cwd_to_root

    from . import (
        assert_equal,
        find_file,
        FunctionUnit,
        func_add_doc_inline_examples,
        read_file,
    )

    import flutils

    filepath = find_file('flutils', 'tests/data')

# Generated at 2022-06-21 12:58:09.975961
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert ver_info.version == '1.2.3'

# Generated at 2022-06-21 12:58:20.007840
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.3.4', position=0) == '2.0.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-21 12:58:24.999229
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3a0')
    assert isinstance(_VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart)
    result = []
    for part in _each_version_part(ver_obj):
        result.append(part)
    assert isinstance(result[0], _VersionPart)
    assert isinstance(result[1], _VersionPart)
    assert isinstance(result[2], _VersionPart)



# Generated at 2022-06-21 12:58:30.493767
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = [
        '0.1.0',
        _VersionPart(
            pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major'
        ),
        _VersionPart(
            pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor'
        ),
        _VersionPart(
            pos=2, txt='0', num=0, pre_txt='', pre_num=-1, name='patch'
        ),
        -1
    ]

# Generated at 2022-06-21 12:58:41.557973
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        -1
    )


# Generated at 2022-06-21 12:58:54.695986
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from tests.helpers import random_str
    from tests.helpers import random_int
    from tests.helpers import random_sequence

    version = random_str(max_len=100)
    major_num = random_int(0, 1000000000)
    minor_num = random_int(0, 1000000000)
    patch_num = random_int(0, 1000000000)

    args: List[Tuple[Any, ...]] = []
    args.append((version, ))

    all_args: List[Tuple[Any, ...]] = []
    all_args.append(args[0])
    for pos, num in enumerate((major_num, minor_num, patch_num)):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kw

# Generated at 2022-06-21 12:59:03.035660
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class :obj:`_VersionPart`."""
    # pylint: disable=W0603
    # noinspection PyUnusedLocal
    kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': '0',
        'num': 0,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major',
    }
    _VersionPart(**kwargs)
    return True



# Generated at 2022-06-21 12:59:45.589956
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    _VersionPart(0, '0', 0, '', -1, 'major')
    _VersionPart(1, '1', 1, '', -1, 'minor')
    _VersionPart(2, '2', 2, '', -1, 'patch')
    _VersionPart(1, '1a5', 1, 'a', 5, 'minor')
    _VersionPart(2, '2b6', 2, 'b', 6, 'patch')



# Generated at 2022-06-21 12:59:52.788826
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    a = _build_version_info('1.2.3')
    assert a.version == '1.2.3'
    assert a.major.pos == 0
    assert a.major.txt == '1'
    assert a.major.num == 1
    assert a.major.pre_txt == ''
    assert a.major.pre_num == -1
    assert a.major.name == 'major'

    d = _build_version_info('1.2.3a1')
    assert d.version == '1.2.3a1'
    assert d.major.pos == 0
    assert d.major.txt == '1'
    assert d.major.num == 1
    assert d.major.pre_txt == ''
    assert d.major.pre_num == -1
    assert d.major.name

# Generated at 2022-06-21 13:00:00.989931
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import unittest
    import unittest.mock

    support = unittest.mock.Mock()

    class TestCase(unittest.TestCase):
        def test_01(self):
            Name = '_VersionPart'
            msg = '%s needs to be a subclass of: NamedTuple' % Name
            self.assertIsSubclass(support.cls, tuple, msg=msg)
            msg = "%s needs to be a subclass of: 'NamedTuple'" % Name
            self.assertIsSubclass(support.cls, NamedTuple, msg=msg)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestCase))
    unittest.TextTestRunner().run(suite)


# Generated at 2022-06-21 13:00:12.501814
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """

# Generated at 2022-06-21 13:00:22.400821
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version.
    """
    # pylint: disable=import-outside-toplevel,redefined-outer-name,unused-import
    import sys

    from pytest import fixture
    from pypandoc import __version__ as pypandoc_version

    @fixture()
    def pypandoc_ver(request):
        """
        Fixture to return the PyPandoc verion number string
        """
        return pypandoc_version

    # noinspection PyUnusedLocal,PyShadowingNames
    def _test_bump(version, position=1, pre_release=None):
        assert bump_version(version, position=position,
                            pre_release=pre_release) == '1.3'


# Generated at 2022-06-21 13:00:35.050030
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:00:46.841003
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    assert _VersionInfo(*args) == args
    args = ('1.2.3a0', _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3', 3, 'a0', 0, 'patch'), 2)
    assert _VersionInfo(*args) == args

# Generated at 2022-06-21 13:00:52.914531
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    """
    Unit test for function bump_version
    """
    from flutils.packages import bump_version
    import os.path
    from io import StringIO
    from nose.tools import ok_, eq_


# Generated at 2022-06-21 13:00:59.402133
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _VersionPart(0, '1', 1, 'a', 2, 'major') == _VersionPart(pos=0, txt='1a2', num=1, pre_txt='a', pre_num=2, name='major')
    assert _VersionPart(0, '1', 1, 'a', 2, 'major') != _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')

# Generated at 2022-06-21 13:01:11.945539
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:01:44.723698
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    :rtype:
        None

    """
    import os

    here = os.path.dirname(__file__)
    xlsx_file = os.path.join(here, 'test_version_bump.xlsx')
    from flutils.importexport import import_xlsx_as_dict
    test_cases: Dict[str, Dict[str, Any]] = import_xlsx_as_dict(
        xlsx_file,
        header_row=1,
        key_column='test_case',
        unique_by='test_case',
        to_lower=True
    )
    for test_case in test_cases:
        test_data = test_cases[test_case]

# Generated at 2022-06-21 13:01:56.431064
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from hypothesis import given
    from tests.utils import (
        int_values_except,
        valid_strict_version_strings,
    )

    @given(valid_strict_version_strings())
    def test_can_construct(ver_str):
        for part in _each_version_part(ver_str):
            assert isinstance(part, _VersionPart)
            assert isinstance(part.pos, int)
            assert isinstance(part.txt, str)
            assert isinstance(part.num, int)
            assert isinstance(part.pre_txt, str)
            assert isinstance(part.pre_num, int)
            assert isinstance(part.name, str)

    test_can_construct()


# Generated at 2022-06-21 13:02:05.261917
# Unit test for function bump_version
def test_bump_version():
    """Test the function: flutils.packages.bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:02:17.167589
# Unit test for function bump_version
def test_bump_version():
    """Test :func:`flutils.packages.bump_version`."""
    from flutils.packages import bump_version

    # Test regular bumps
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test alpha bumps
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-21 13:02:29.363105
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.encodingutils import encode_data

# Generated at 2022-06-21 13:02:41.587399
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ori_str = '1.2.3'
    ver_info = _build_version_info(ori_str)
    assert ver_info.version == ori_str
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.num == 3

# Generated at 2022-06-21 13:02:49.120849
# Unit test for function bump_version
def test_bump_version():
    r"""Test bump\_version."""

# Generated at 2022-06-21 13:03:01.198982
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:11.460612
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '', 0, '', -1, 'minor'),
                        _VersionPart(2, '', 0, '', -1, 'patch'), -1) == _build_version_info('1')
    assert _VersionInfo('1.2', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '', 0, '', -1, 'patch'), -1) == _build_version_info('1.2')

# Generated at 2022-06-21 13:03:23.457993
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for class: `_VersionInfo`."""
    from flutils.packages import __private__

# Generated at 2022-06-21 13:03:39.738283
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(
        0,
        '0',
        0,
        '',
        -1,
        'major'
    )
    assert vp.pos == 0
    assert vp.txt == '0'
    assert vp.num == 0
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'
    assert (
        str(vp) ==
        '_VersionPart(pos=0, txt=\'0\', num=0, pre_txt=\'\', pre_num=-1, '
        'name=\'major\')'
    )



# Generated at 2022-06-21 13:03:50.804503
# Unit test for function bump_version
def test_bump_version():
    """
    Execute unit tests for the :py:func:`bump_version` function.
    """
    from unittest import TestCase, TestLoader, TextTestRunner

    class TestBumpVersion(TestCase):
        """
        """

        def test_bump_versions(self):
            """
            """

# Generated at 2022-06-21 13:03:52.938287
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '2', 3, 'a', 4, 'major').num == 3


# Generated at 2022-06-21 13:04:01.895385
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo('1.2.3',
                                                        _VersionPart(pos=0, txt='1', num=1,
                                                                     pre_txt='', pre_num=-1,
                                                                     name='major'),
                                                        _VersionPart(pos=1, txt='2', num=2,
                                                                     pre_txt='', pre_num=-1,
                                                                     name='minor'),
                                                        _VersionPart(pos=2, txt='3', num=3,
                                                                     pre_txt='', pre_num=-1,
                                                                     name='patch'),
                                                        -1)

# Generated at 2022-06-21 13:04:05.577849
# Unit test for function bump_version
def test_bump_version():  # noqa
    # pylint: disable=C0116,W0612,W0613
    from flutils.testing import run_doctest
    return run_doctest(__name__, __file__)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-21 13:04:07.194102
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # TODO: Create unit test
    return True



# Generated at 2022-06-21 13:04:16.889109
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('0.2.3a0')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0
        assert part.txt == '0'
        assert part.num == 0
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name == 'major'

        assert part.pos == 1
        assert part.txt == '2'
        assert part.num == 2
        assert part.pre_txt == 'a'
        assert part.pre_num == 0
        assert part.name == 'minor'

        assert part.pos == 2
        assert part.txt == '3a0'
        assert part.num == 3
        assert part.pre_txt == ''
        assert part.pre_num == -1


# Generated at 2022-06-21 13:04:19.273970
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0612
    ver_info = _build_version_info('1.2.3')



# Generated at 2022-06-21 13:04:30.787925
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.4.0')
    assert ver_info.version == '1.4.0'
    assert ver_info.pre_pos == 1
    assert ver_info.major.pos == 0
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.num == 4
    assert ver_info.minor.txt == '4'
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 13:04:42.111579
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_1 = _build_version_info('1.2.3')
    assert ver_1.version == '1.2.3'
    assert ver_1.major.txt == '1'
    assert ver_1.major.num == 1
    assert ver_1.minor.txt == '2'
    assert ver_1.minor.num == 2
    assert ver_1.patch.txt == '3'
    assert ver_1.patch.num == 3
    assert ver_1.pre_pos is -1

    ver_2 = _build_version_info('1.2.3a1')
    assert ver_2.version == '1.2.3a1'
    assert ver_2.major.txt == '1'
    assert ver_2.major.num == 1

# Generated at 2022-06-21 13:05:07.486442
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # fmt: off
    result = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1,
    )
    # fmt: on
    assert result.version == '1.2.3'
    assert result.major.pos == 0
    assert result.major.txt == '1'
    assert result.major.num == 1
    assert result.major.pre_txt == ''
    assert result.major.pre_num == -1
    assert result.major.name == 'major'
    assert result.minor.pos == 1

# Generated at 2022-06-21 13:05:12.416548
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo."""
    ver_info = _build_version_info('10.20.30')
    assert ver_info.version == '10.20.30'
    assert ver_info.major.num == 10
    assert ver_info.minor.num == 20
    assert ver_info.patch.num == 30
    assert ver_info.pre_pos == -1



# Generated at 2022-06-21 13:05:24.580269
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    obj = _VersionInfo(
        version='1.0.0',
        major=_VersionPart(
            pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
        ),
        minor=_VersionPart(
            pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'
        ),
        patch=_VersionPart(
            pos=2, txt='0', num=0, pre_txt='', pre_num=-1, name='patch'
        ),
        pre_pos=-1
    )

    assert obj.version == '1.0.0'
    assert obj.major.pos == 0
    assert obj.major.txt == '1'
    assert obj.major.num == 1
   