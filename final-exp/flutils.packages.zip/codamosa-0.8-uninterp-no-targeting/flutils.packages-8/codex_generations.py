

# Generated at 2022-06-21 12:56:01.550191
# Unit test for function bump_version

# Generated at 2022-06-21 12:56:10.675996
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    test_values = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    ver_part = _VersionPart(**test_values)
    assert ver_part.pos == 0
    assert ver_part.txt == '1'
    assert ver_part.num == 1
    assert ver_part.pre_txt == ''
    assert ver_part.pre_num == -1
    assert ver_part.name == 'major'
    return ver_part


# Unit tests for _each_version_part()

# Generated at 2022-06-21 12:56:22.736167
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert _build

# Generated at 2022-06-21 12:56:31.262566
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import sys
    from contextlib import suppress
    from flutils.packages import bump_version

    class TestVersions(unittest.TestCase):

        def test_bump_version(self) -> None:
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-21 12:56:43.247085
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 12:56:54.909934
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import sys

    class TestBumpVersion(unittest.TestCase):
        objstr = 'TestBumpVersion'

        def test_01_bump_version(self):
            ver = bump_version('1.2.3')
            self.assertEqual(ver, '1.2.4')
        def test_02_bump_version(self):
            ver = bump_version('1.2.3', position=1)
            self.assertEqual(ver, '1.3')
        def test_03_bump_version(self):
            ver = bump_version('1.2.3', position=0)
            self.assertEqual(ver, '2.0')

# Generated at 2022-06-21 12:57:04.174306
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Tests the constructor of class _VersionPart."""
    # noinspection SpellCheckingInspection,PyUnresolvedReferences
    """Tests the constructor of class _VersionPart."""
    import flutils.packages

    pos: int = 1
    txt: str = '2'
    num: int = 2
    pre_txt: str = 'b'
    pre_num: int = 0
    name: str = 'minor'
    kwargs: Dict[str, Any] = {
        'pos': pos, 'txt': txt, 'num': num,
        'pre_txt': pre_txt, 'pre_num': pre_num,
        'name': name
    }
    vpart = flutils.packages._VersionPart(**kwargs)
    assert vpart.pos == pos

# Generated at 2022-06-21 12:57:15.059485
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    kwargs = {
        'version': '1.2.3a1',
        'major': _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        'minor': _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='a',
            pre_num=1,
            name='minor'
        ),
        'patch': _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        'pre_pos': 1,
    }

# Generated at 2022-06-21 12:57:26.160264
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 12:57:34.546856
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    parts = list(_each_version_part(StrictVersion('1.3.3.post3')))
    assert parts[0] == _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert parts[1] == _VersionPart(
        pos=1,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )

# Generated at 2022-06-21 12:58:07.958359
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit tests for the _VersionPart constructor.
    """
    from unittest import TestCase
    from unittest.mock import patch

    kwargs = dict(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    ver = _VersionPart(**kwargs)

    kwargs['txt'] = '1a0'
    kwargs['pre_txt'] = 'a'
    kwargs['pre_num'] = 0
    kwargs['name'] = 'minor'
    ver2 = _VersionPart(**kwargs)

    kwargs['pos'] = 2
    kwargs['name'] = 'patch'
    ver3 = _VersionPart(**kwargs)



# Generated at 2022-06-21 12:58:15.768658
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    base_args = ['1.2.3', '1', '2', '3', -1]
    kwargs: Dict[str, Any] = {
        'pos': 0, 'txt': '1', 'num': 1, 'pre_txt': '', 'pre_num': -1
    }
    ver_info = _VersionInfo(*base_args, _VersionPart(**kwargs))
    assert ver_info.major.num == 1
    # Test the alpha version bump
    ver_info = _VersionInfo(
        '1.2a0',
        _VersionPart(0, '1', 1, '', -1),
        _VersionPart(1, '2a0', 2, 'a', 0),
        _VersionPart(2, '0', 0, '', -1), 1
    )
    assert ver

# Generated at 2022-06-21 12:58:24.576173
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    # Arrange
    version = '1.2.3'
    ver_obj = StrictVersion(version)
    version_str = version
    major_str = '1'
    minor_str = '2'
    patch_str = '3'
    parts = list(_each_version_part(ver_obj))
    pre_pos = len(parts) - 1

    # Act
    ver_info = _VersionInfo(
        version = version_str,
        major = parts[0],
        minor = parts[1],
        patch = parts[2],
        pre_pos = pre_pos
    )

    # Assert
    assert ver_info.version == version
    assert ver_info.major.txt == major_str
    assert ver_info.minor.txt == minor_str
    assert ver_info.patch

# Generated at 2022-06-21 12:58:30.870272
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for function 'bump_version'"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-21 12:58:37.141629
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [0, '0', 0, '', -1, 'major']
    vp = _VersionPart(*args)

    assert vp.pos == 0
    assert vp.txt == '0'
    assert vp.num == 0
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'


# Generated at 2022-06-21 12:58:49.269553
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.name == 'major'
    assert ver_info.major.num == 1
    assert ver_info.minor.name == 'minor'
    assert ver_info.minor.num == 2
    assert ver_info.patch.name == 'patch'
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2a0')
    assert ver_info.version == '1.2a0'
    assert ver_info.major.name == 'major'
    assert ver_info.major.num == 1

# Generated at 2022-06-21 12:59:02.213689
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2a0'
    ver_obj = StrictVersion(version)
    assert [x.txt for x in _each_version_part(ver_obj)] == ['1.2a0', '1', '2', '']
    assert [x.pre_num for x in _each_version_part(ver_obj)] == [-1, -1, -1, 0]
    version = '1.2.3.4'
    ver_obj = StrictVersion(version)
    assert [x.txt for x in _each_version_part(ver_obj)] == ['1.2.3.4', '1', '2', '3']
    assert [x.pre_num for x in _each_version_part(ver_obj)] == [-1, -1, -1, -1]

# Generated at 2022-06-21 12:59:07.422407
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the bump_version function."""
    # Run doctest and unit tests
    import doctest
    import flutils.packages
    doctest.testmod(flutils.packages)

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-21 12:59:14.654689
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3.4')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
        assert part.pos in (0, 1, 2)
        assert part.txt in ('1', '2', '', '3.4')
        assert part.num in (1, 2, 0, 3)
        assert part.pre_txt in ('', '.4')
        assert part.pre_num in (-1, 4)
        assert part.name in ('major', 'minor', 'patch')



# Generated at 2022-06-21 12:59:27.677681
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:00:01.220254
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import pytest  # type: ignore
    from flutils.packages import bump_version

    version = '1.2.3'
    assert bump_version(version) == '1.2.4'

    version = '1.2.3'
    position = 1
    assert bump_version(version, position=position) == '1.3'

    version = '1.3.4'
    position = 0
    assert bump_version(version, position=position) == '2.0'

    version = '1.2.3'
    pre_release = 'a'
    assert bump_version(version, pre_release=pre_release) == '1.2.4a0'

    version = '1.2.4a0'
    pre_release = 'a'

# Generated at 2022-06-21 13:00:12.695123
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""
    # noinspection SpellCheckingInspection
    import pytest
    from flutils.packages import bump_version

    # noinspection DuplicatedCode

# Generated at 2022-06-21 13:00:22.542623
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    vi = _VersionInfo("1.2.3", _VersionPart(0, '1', 1, '', -1, ''),
                      _VersionPart(1, '2', 2, '', -1, ''),
                      _VersionPart(2, '3', 3, '', -1, ''),
                      -1)
    assert vi == _build_version_info('1.2.3')
    vi = _VersionInfo("1.2a3", _VersionPart(0, '1', 1, '', -1, ''),
                      _VersionPart(1, '2a3', 2, 'a', 3, 'alpha'),
                      _VersionPart(2, '0', 0, 'a', 3, 'alpha'),
                      1)
    assert vi == _build_version_info('1.2a3')
    vi = _VersionInfo

# Generated at 2022-06-21 13:00:35.226017
# Unit test for function bump_version
def test_bump_version():
    """Tests function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:00:44.926811
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3a0'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.num == 1
    assert ver_info.minor.pos == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.pos == 2
    assert ver_info.patch.num == 3
    assert ver_info.patch.pre_txt == 'a'
    assert ver_info.patch.pre_num == 0
    assert ver_info.pre_pos == 2

# Generated at 2022-06-21 13:00:49.342532
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    try:
        _ = _VersionPart(
            pos=0,
            txt='',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='major'
        )
        assert True
    except TypeError:
        assert False


# Generated at 2022-06-21 13:01:01.565398
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:01:08.233050
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0212
    my_version = _VersionInfo('1.2.3-alpha.4', _VersionPart(0, '1', 1, '', -1, 'major'), 
                              _VersionPart(1, '2', 2, 'alpha', 4, 'minor'), 
                              _VersionPart(2, '3', 3, '', -1, 'patch'), 1)
    assert my_version.version == '1.2.3-alpha.4'
    assert my_version.major == _VersionPart(0, '1', 1, '', -1, 'major')
    assert my_version.minor == _VersionPart(1, '2alpha4', 2, 'alpha', 4, 'minor')

# Generated at 2022-06-21 13:01:17.561970
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '1', '1', '', -1, 'minor').pos == 1
    assert _VersionPart(1, '1', '1', '', -1, 'minor').txt == '1'
    assert _VersionPart(1, '1', '1', '', -1, 'minor').num == '1'
    assert _VersionPart(1, '1', '1', '', -1, 'minor').pre_txt == ''
    assert _VersionPart(1, '1', '1', '', -1, 'minor').pre_num == -1
    assert _VersionPart(1, '1', '1', '', -1, 'minor').name == 'minor'

# Generated at 2022-06-21 13:01:27.899998
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('0.1.2')
    assert ver_info.version == '0.1.2'
    assert ver_info.major.num == 0
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 2
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('0.1a0')
    assert ver_info.version == '0.1a0'
    assert ver_info.major.num == 0
    assert ver_info.minor.num == 1
    assert ver_info.pre_pos == 1

    ver_info = _build_version_info('0.1b0')
    assert ver_info.version == '0.1b0'
    assert ver_info.major

# Generated at 2022-06-21 13:01:40.243257
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:01:46.563928
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of class _VersionPart."""
    part = _VersionPart(0, '1', 1, 'a', 0, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'major'


# Generated at 2022-06-21 13:01:59.281766
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('2.0.0')
    assert ver_info.major.num == 2
    assert ver_info.minor.num == 0
    assert ver_info.patch.num == 0
    ver_info = _build_version_info('2.1.0')
    assert ver_info.major.num == 2
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 0
    ver_info = _build_version_info('2.1.3')
    assert ver_info.major.num == 2
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 3
    ver_info = _build_version_info('2.1.4a0')

# Generated at 2022-06-21 13:02:11.576406
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.name == 'major'
    assert ver_info.major.pos == 0
    assert ver_info.major.num == 1
    assert ver_info.minor.name == 'minor'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.name == 'patch'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.num == 3

    ver_info = _build_version_info('1.2a0')
    assert ver_info.version == '1.2a0'

# Generated at 2022-06-21 13:02:22.526280
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    version = bump_version('1.2.2')
    assert version == '1.2.3'

    version = bump_version('1.2.3', position=1)
    assert version == '1.3'

    version = bump_version('1.3.4', position=0)
    assert version == '2.0'

    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'

    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'

    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'

   

# Generated at 2022-06-21 13:02:31.242242
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    #: pylint: disable=W0613
    import unittest
    import sys
    import warnings

    import flutils.packages

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        class _Tester(unittest.TestCase):  # pylint: disable=R0903
            _GOOD_VERSIONS: List[str] = [
                '1.1.1',
                '1.1.0',
                '1.0.0',
                '1',
                '1a1.1b2.0.6',
                '1.0a1.0b2.0.6',
                '1.0a1.1b2.0',
            ]

# Generated at 2022-06-21 13:02:38.548266
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('0.3.0')
    assert ver_info.version == '0.3.0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '3'
    assert ver_info.minor.num == 3
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 13:02:46.270902
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version
    """

    def _run(ver, pos=2, prerel='a'):
        return bump_version(ver, position=pos, pre_release=prerel)

    assert _run('1.2.2') == '1.2.3'
    assert _run('1.2.3', position=1) == '1.3'
    assert _run('1.3.4', position=0) == '2.0'
    assert _run('1.2.3', prerelease='a') == '1.2.4a0'
    assert _run('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert _run('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:02:47.108621
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')

# Generated at 2022-06-21 13:02:58.988532
# Unit test for function bump_version
def test_bump_version():
    """ Test the function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:20.545920
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version"""
    from flutils.packages import bump_version

    def _test_it(test_data, test_func):
        for ver_before, ver_after in test_data.items():
            ver_before = str(ver_before)
            ver_after = str(ver_after)
            ver_bumped = test_func(ver_before)
            assert ver_after == ver_bumped, '%r != %r (%r)' % (
                ver_after, ver_bumped, ver_before
            )

    # Test 'patch' bumps

# Generated at 2022-06-21 13:03:29.429259
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('0.0.2') == _VersionInfo(
        '0.0.2',
        _VersionPart(0, '0', 0, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '2', 2, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-21 13:03:36.133738
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:44.678366
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    obj = _VersionPart(
        pos=0, txt='10', num=10, pre_txt='', pre_num=-1, name='major'
    )
    assert obj.pos == 0
    assert obj.num == 10
    assert obj.txt == '10'
    assert repr(obj) == (
        "VersionPart(pos=0, txt='10', num=10, "
        "pre_txt='', pre_num=-1, name='major')"
    )



# Generated at 2022-06-21 13:03:55.493951
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo."""
    class tests(object):
        class test(NamedTuple):
            version: str
            major: _VersionPart
            minor: _VersionPart
            patch: _VersionPart
            pre_pos: int

        def __init__(self):
            self._curr_test = None
            self._tests: List[tests.test] = []

        def add(
                self,
                version: str,
                major: _VersionPart,
                minor: _VersionPart,
                patch: _VersionPart,
                pre_pos: int
        ) -> None:
            self._tests.append(tests.test(
                version=version,
                major=major,
                minor=minor,
                patch=patch,
                pre_pos=pre_pos
            ))


# Generated at 2022-06-21 13:04:02.376292
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    t = _VersionPart
    # Test __init__
    part = t(0, '0', 0, 'a', 0, 'major')
    assert part.pos == 0
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'major'
    assert repr(part) == '_VersionPart(pos=0, txt=\'0\', num=0, pre_txt=\'a\', ' \
                          'pre_num=0, name=\'major\')'


# Generated at 2022-06-21 13:04:05.616947
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pprint
    from distutils.version import StrictVersion
    ver_obj = StrictVersion('1.2.3a4')
    for part in _each_version_part(ver_obj):
        pprint(dict(part._asdict()))


# Generated at 2022-06-21 13:04:16.035106
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3').version == '1.2.3'
    assert _build_version_info('1.2.3').major.num == 1
    assert _build_version_info('1.2.3').minor.num == 2
    assert _build_version_info('1.2.3').patch.num == 3
    assert _build_version_info('1.2.3').pre_pos == -1
    assert _build_version_info('1.2').version == '1.2'
    assert _build_version_info('1.2').major.num == 1
    assert _build_version_info('1.2').minor.num == 2
    assert _build_version_info('1.2').patch.num == 0

# Generated at 2022-06-21 13:04:27.329063
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

    # Test bump without pre-release
    test_version_1: Tuple[str, str, int] = ('1.2.3', '1.2.4', 2)
    test_version_2: Tuple[str, str, int] = ('1.2.3', '1.3', 1)
    test_version_3: Tuple[str, str, int] = ('1.2.3', '2.0', 0)

    for idx, (in_version, out_version, pos) in enumerate((
            test_version_1,
            test_version_2,
            test_version_3
    )):
        msg = 'Error with test version {}.'.format(idx + 1)

# Generated at 2022-06-21 13:04:38.605557
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3',
                        _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), -1,)
    assert _VersionInfo('1.2.3a0',
                        _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, 'a0', 0, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), 1,)

# Generated at 2022-06-21 13:04:57.303556
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:05:09.202889
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""

    import unittest
    import sys

    class Test_bump_version(unittest.TestCase):
        """Unit tests for function bump_version."""

        def test_bump_version(self) -> None:
            """Test correct version number bump."""
            from flutils.packages import bump_version

            version = bump_version('0.1.2', position=2)
            self.assertEqual(version, '0.1.3')
    
            version = bump_version('0.1.2', position=1)
            self.assertEqual(version, '0.2')
    
            version = bump_version('0.1.2', position=0)
            self.assertEqual(version, '1.0')
    
            version = bump_

# Generated at 2022-06-21 13:05:16.958974
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:05:27.146860
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'