

# Generated at 2022-06-21 12:56:01.136909
# Unit test for function bump_version
def test_bump_version():
    """Tests flutils.packages.bump_version()."""
    import pytest
    from flutils.packages import bump_version


# Generated at 2022-06-21 12:56:10.232996
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0212,C,R0201
    import unittest
    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-21 12:56:20.127350
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo
    case = _VersionInfo(
        "0.0.0",
        _VersionPart(0, '0', 0, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '0', 0, '', -1, 'patch'),
        -1
    )
    assert case == _VersionInfo("0.0.0", 0, 0, 0, "", -1, -1, -1, -1, "", -1, -1, -1, -1, -1, "major", "minor", "patch", -1)
    assert case.version == "0.0.0"
    assert isinstance(case.major, _VersionPart)

# Generated at 2022-06-21 12:56:30.059564
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 12:56:34.907445
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor')


# Generated at 2022-06-21 12:56:44.691326
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``."""
    from flutils.packages import bump_version
    from flutils.testhelpers import (
        CallAssertion,
        CallAssertionError,
        FunctionAssertion,
        FunctionAssertionError,
    )
    from flutils.toolhelpers import raise_from

    try:
        bump_version('1.2.2')
    except Exception:
        raise_from(
            None,
            "bump_version('1.2.2') should not raise an exception."
        )

    try:
        bump_version('1.2.3', position=1)
    except Exception:
        raise_from(
            None,
            "bump_version('1.2.3', position=1) should not raise an exception."
        )



# Generated at 2022-06-21 12:56:52.899420
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info
    _build_version_info(version='0.4.3')
    _build_version_info(version='1.2')
    _build_version_info(version='1.2.0')
    _build_version_info(version='1.2a0')
    _build_version_info(version='1.2a1')
    _build_version_info(version='1.2b0')
    _build_version_info(version='1.2b1')
    print('Passed')


# Generated at 2022-06-21 12:57:02.704646
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3.4'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '2', 2, '', -1, 'minor')
    patch = _VersionPart(2, '3.4', 3, '4', 4, 'patch')
    pre_pos = 2
    result = _VersionInfo(version, major, minor, patch, pre_pos)
    assert result is not None
    assert result == _VersionInfo(  # nosec
        version,
        major,
        minor,
        patch,
        pre_pos,
    )
    assert result != _VersionInfo(  # nosec
        version,
        major,
        minor,
        patch,
        -2,
    )


# Generated at 2022-06-21 12:57:13.163968
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.22.3b3'
    info = _build_version_info(version)
    assert info.version == version
    assert info.major.num == 1
    assert info.major.txt == '1'
    assert info.major.pos == 0
    assert info.minor.num == 22
    assert info.minor.txt == '22'
    assert info.minor.pre_txt == 'b'
    assert info.minor.pre_num == 3
    assert info.minor.pos == 1
    assert info.patch.txt == ''
    assert info.patch.num == 3
    assert info.patch.pos == 2
    assert info.pre_pos == 1


# Generated at 2022-06-21 12:57:20.253085
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [1234, '1234', 1234, '', -1, 'test']
    obj = _VersionPart(*args)
    assert obj.pos == args[0]
    assert obj.txt == args[1]
    assert obj.num == args[2]
    assert obj.pre_txt == args[3]
    assert obj.pre_num == args[4]
    assert obj.name == args[5]



# Generated at 2022-06-21 12:57:53.524672
# Unit test for function bump_version
def test_bump_version():
    import pytest  # type: ignore
    # Major bumps
    assert bump_version('1.0', 0) == '2'
    assert bump_version('1.0.0', 0) == '2'
    # Minor bumps
    assert bump_version('1.0') == '1.1'
    assert bump_version('1.0.0') == '1.1'
    assert bump_version('1.0', 1) == '1.1'
    assert bump_version('1.0.0', 1) == '1.1'
    assert bump_version('1.2.0', 1) == '1.3'
    assert bump_version('1.2.3', 1) == '1.3'
    # Patch bumps
    assert bump_version('1.0.8') == '1.0.9'

# Generated at 2022-06-21 12:58:03.190801
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test_names: List[str] = [
        '0.1',
        '0.1.1',
        '0.2.1',
        '0.2.2',
        '0.2.3dev1',
        '0.3a1',
        '0.3b1',
        '0.3dev1',
        '1.0',
        '1.1',
        '1.2.1',
        '1.2.1dev1',
        '1.2.2',
        '1.2.3a1',
        '1.2.3b1',
        '1.2.3dev1',
    ]
    for name in test_names:
        ver_info = _build_version_info(name)

# Generated at 2022-06-21 12:58:12.577752
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 12:58:18.888254
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    x = _VersionPart(
        pos = 1,
        txt = '2',
        num = 2,
        pre_txt = '',
        pre_num = -1,
        name = 'minor'
    )
    assert x.pos == 1
    assert x.txt == '2'
    assert x.num == 2
    assert x.pre_txt == ''
    assert x.pre_num == -1
    assert x.name == 'minor'



# Generated at 2022-06-21 12:58:27.991500
# Unit test for function bump_version

# Generated at 2022-06-21 12:58:41.218114
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test_cases = [
        (
            {
                'pos': 0,
                'num': 1,
                'pre_txt': '',
                'pre_num': -1
            },
            _VersionPart(0, '1', 1, '', -1, 'major'),
            'Create with default values.'
        ),
        (
            {
                'pos': 1,
                'num': 2,
                'pre_txt': 'a',
                'pre_num': 0
            },
            _VersionPart(1, '2a0', 2, 'a', 0, 'minor'),
            'Create with a pre-release part.'
        )
    ]
    for kwargs, out, msg in test_cases:
        _VersionPart(**kwargs) == out
        print(msg)

# Unit test

# Generated at 2022-06-21 12:58:54.282917
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.23.45')
    assert ver_info.version == '1.23.45'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '23'
    assert ver_info.minor.num == 23
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 12:59:07.477025
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=unused-variable
    from flutils.packages import (
        bump_version,
    )
    assert bump_version('1.2.5a0', 0) == '2.0'
    assert bump_version('1.2.5a0', 1) == '1.3'
    assert bump_version('1.2.5a0', 2) == '1.2.6'
    assert bump_version('1.2.5a0', 3) == '1.3.0a0'
    assert bump_version('1.2.5a0', 4) == '1.3.0b0'
    assert bump_version('1.2.5a0', -1) == '1.2.5a1'

# Generated at 2022-06-21 12:59:15.208209
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the constructor of the class _VersionPart."""
    args = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'pre_txt',
        'pre_num': 1,
        'name': 'name'
    }
    instance = _VersionPart(**args)
    assert instance.pos == args['pos']
    assert instance.txt == args['txt']
    assert instance.num == args['num']
    assert instance.pre_txt == args['pre_txt']
    assert instance.pre_num == args['pre_num']
    assert instance.name == args['name']



# Generated at 2022-06-21 12:59:27.767761
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    version = '1.2.2'
    output = bump_version(version)
    assert output == '1.2.3'

    version = '1.2.3'
    position = 1
    output = bump_version(version, position)
    assert output == '1.3'

    version = '1.3.4'
    position = 0
    output = bump_version(version, position)
    assert output == '2.0'

    version = '1.2.3'
    pre_release = 'a'
    output = bump_version(version, pre_release=pre_release)
    assert output == '1.2.4a0'

    version = '1.2.4a0'
    pre_release = 'a'
    output = bump_version

# Generated at 2022-06-21 12:59:51.873435
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 12:59:57.375482
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-21 13:00:05.619803
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 13:00:16.241399
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:00:22.506842
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    tup = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert isinstance(tup, _VersionPart)
    assert tup.pos == 0
    assert tup.txt == '1'
    assert tup.num == 1
    assert tup.pre_txt == ''
    assert tup.pre_num == -1
    assert tup.name == 'major'



# Generated at 2022-06-21 13:00:35.182593
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import unittest

    class _bump_version_Tester(unittest.TestCase):
        """Test function bump_version."""

        def test_bump_version(self):
            """Test function bump_version."""
            with self.subTest(msg='normal'):
                self.assertEqual(bump_version('1.2.2'), '1.2.3')
                self.assertEqual(bump_version('1.2.3', position=1), '1.3')
                self.assertEqual(bump_version('1.3.4', position=0), '2.0')

# Generated at 2022-06-21 13:00:46.131741
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1'
    major = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                         name='major')
    minor = _VersionPart(pos=1, txt='', num=0, pre_txt='', pre_num=-1,
                         name='minor')
    patch = _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1,
                         name='patch')
    pre_pos = -1
    args = [version, major, minor, patch, pre_pos]
    out = _VersionInfo(*args)
    assert(out == _VersionInfo(version, major, minor, patch, pre_pos))



# Generated at 2022-06-21 13:00:54.307769
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    # noinspection PyUnusedLocal
    def _get_methods(cls_obj):
        """Get the methods of a class object."""
        return [
            m for m in cls_obj.__dict__.keys() if not m.startswith('__')
        ]

    def _get_pairs(cls_obj):
        """Get the pairs of methods, and their docstrings, of a class object."""
        methods = _get_methods(cls_obj)
        return zip(methods, map(getattr(cls_obj, m).__doc__ for m in methods))

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
   

# Generated at 2022-06-21 13:01:00.125598
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.name == 'patch'
    assert ver_info.pre_pos == -1


# Generated at 2022-06-21 13:01:12.315123
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    pos_min = -3
    pos_max = 2
    versions = [
        '1.2.3',
        '1.2.3a0',
        '1.2.3a1',
        '1.2.3a2',
        '1.2.3b0',
        '1.2.3b1',
        '1.2.3b2',
        '1.2.3.4',
        '1.2.0',
    ]
    for version in versions:
        try:
            out = _build_version_info(version)
        except ValueError:
            out = None

        assert out is not None, "'%s'" % version

        if version.find('.') < 0:
            assert out.version == version
            assert out.major.num == version

# Generated at 2022-06-21 13:01:40.121564
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo('1.2.3a0', _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
                            _VersionPart(pos=1, txt='2', num=2, pre_txt='a', pre_num=0, name='minor'),
                            _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
                            1)
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.pos == 0
    assert ver_info.minor.pos == 1
    assert ver_info.patch.pos == 2
    assert ver_info.major.pre_txt == ''
    assert ver

# Generated at 2022-06-21 13:01:44.158730
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    return _VersionPart(
        pos=2,
        txt='23',
        num=23,
        pre_txt='',
        pre_num=-1,
        name='patch'
    )



# Generated at 2022-06-21 13:01:56.573422
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0')
    assert ver_info == _VersionInfo(
        version='1.0',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1
    )
    ver_info = _build_version_info('1.0a0')

# Generated at 2022-06-21 13:02:05.359100
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests the constructor of class _VersionInfo.

    """
    ver_info = _build_version_info('1.2')
    assert ver_info == _VersionInfo('1.2', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '', 0, '', -1, 'patch'), -1)
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos

# Generated at 2022-06-21 13:02:17.211959
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """
    # pylint: disable=C0103
    import pytest


# Generated at 2022-06-21 13:02:29.363998
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit tests for the constructor of _VersionPart.

    This is used by _each_version_part().

    """
    assert str(_VersionPart(0, '1', 1, '', -1, 'major')) == \
        '_VersionPart(pos=0, txt=\'1\', num=1, pre_txt=\'\', pre_num=-1, ' \
        'name=\'major\')'
    assert str(_VersionPart(1, '2', 2, 'b', 0, 'minor')) == \
        '_VersionPart(pos=1, txt=\'2b0\', num=2, pre_txt=\'b\', pre_num=0, ' \
        'name=\'minor\')'

# Generated at 2022-06-21 13:02:41.589321
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert ver_info.major.num == 1

    ver_

# Generated at 2022-06-21 13:02:47.925825
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,C0116,W0621,W0612,C0413

    from flutils.debugging import debug_print

    __name__ = 'bump_version unit test'
    __author__ = 'Jacob Griffiths <jacob_griffiths@yahoo.com'

    debug_print("Running the unit test for bump_version():\n")

    def _run_test(
            version: str,
            expected_result: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            _minor: int = 1
    ) -> None:
        try:
            actual_result = bump_version(
                version=version,
                position=position,
                pre_release=pre_release
            )
        except Exception as exc:
            print

# Generated at 2022-06-21 13:02:54.812590
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.0') == _VersionInfo('1.0',
                                                      _VersionPart(0, '1', 1, '', -1, 'major'),
                                                      _VersionPart(1, '0', 0, '', -1, 'minor'),
                                                      _VersionPart(2, '', 0, '', -1, 'patch'),
                                                      -1)

# Generated at 2022-06-21 13:02:59.558732
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo
    """
    ver_info = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major',
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor',
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch',
        ),
        pre_pos=-1
    )


# Generated at 2022-06-21 13:03:24.708005
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:32.919877
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info
    assert _build_version_info("1.2.3") == _VersionInfo(
        '1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(
            2, '3', 3, '', -1, 'patch'
        ),
        -1
    )

# Generated at 2022-06-21 13:03:43.970500
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:03:54.832917
# Unit test for function bump_version
def test_bump_version():
    """Run the unit test for function bump_version."""
    from flutils.packages import bump_version
    version = '1.2.2'
    assert bump_version(version) == '1.2.3'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'
    version = '1.2.3'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'


# Generated at 2022-06-21 13:04:01.894842
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # Test a version with a pre-release
    args = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    obj = _VersionPart(**args)
    assert obj.pos == args['pos']
    assert obj.txt == args['txt']
    assert obj.num == args['num']
    assert obj.pre_txt == args['pre_txt']
    assert obj.pre_num == args['pre_num']
    assert obj.name == args['name']


# Generated at 2022-06-21 13:04:09.612322
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart

    # Basic
    args = {'pos': 1, 'txt': '2', 'num': 2, 'pre_txt': 'a', 'pre_num': 1, 'name': 'minor'}
    part = _VersionPart(**args)
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == 'a'
    assert part.pre_num == 1
    assert part.name == 'minor'

    # Positional
    part = _VersionPart(1, '2', 2, 'a', 1, 'minor')
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == 'a'
    assert part

# Generated at 2022-06-21 13:04:18.143606
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '2.1.0'
    ver_obj = StrictVersion(version)
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert part.txt in ('2', '1', '')
        assert part.num in (2, 1, 0)

    version = '2.1.0b0'
    ver_obj = StrictVersion(version)
    for part in _each_version_part(ver_obj):
        if part.pos == 0:
            assert part.txt == '2'
            assert part.num == 2
        if part.pos == 1:
            assert part.txt == '1b0'
            assert part.num == 1
        if part.pos == 2:
            assert part.txt == '0'
           

# Generated at 2022-06-21 13:04:29.711326
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    """Unit test for function bump_version."""

    def _build_version_list(
            ver_list: List[str],
            pre_release: Optional[str]
    ) -> Tuple[List[str], List[str], str, str]:
        _pre_release = pre_release
        if _pre_release is None:
            _pre_release = ''
        else:
            _pre_release = _pre_release.strip().lower()
        if _pre_release == '':
            _pre_release = None
        ver_list = ver_list.copy()
        num_list = []
        for val in ver_list:
            if val == '':
                num_list.append(0)
            else:
                num_list.append(int(val))


# Generated at 2022-06-21 13:04:41.155053
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3',
                        _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), -1).version == '1.2.3'
    assert _VersionInfo('1.2c0',
                        _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2c0', 2, 'c', 0, 'minor'),
                        _VersionPart(2, '', 0, '', -1, 'patch'), 1).version == '1.2c0'

# Generated at 2022-06-21 13:04:49.567817
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:05:12.596022
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    ) == _build_version_info('1.2.3')

# Generated at 2022-06-21 13:05:24.698315
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests for constructor of class _VersionInfo"""

    # noinspection PyUnusedLocal
    hold: List[Union[int, str]] = []

    assert _build_version_info('2.6.1').version == '2.6.1'
    assert _build_version_info('2.6.1').major == _VersionPart(
        0, '2', 2, '', -1, 'major'
    )
    assert _build_version_info('2.6.1').minor == _VersionPart(
        1, '6', 6, '', -1, 'minor'
    )
    assert _build_version_info('2.6.1').patch == _VersionPart(
        2, '1', 1, '', -1, 'patch'
    )