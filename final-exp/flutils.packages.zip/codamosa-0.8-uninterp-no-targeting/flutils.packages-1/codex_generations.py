

# Generated at 2022-06-21 12:55:51.341789
# Unit test for function bump_version
def test_bump_version():
    from flutils.tests.helpers import (
        run_test,
        string_test,
    )
    #  Versions without pre-releases

# Generated at 2022-06-21 12:56:04.877519
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        2
    )
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.name == 'major'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.min

# Generated at 2022-06-21 12:56:14.636453
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo.

    *New in version 0.3.1*

    """
    # Version bump
    # '1.2.2'
    # pylint: disable=C0103

# Generated at 2022-06-21 12:56:22.958846
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    assert _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch')
    assert _VersionPart(pos=1, txt='2', num=2, pre_txt='a', pre_num=1, name='minor')
    assert _VersionPart(pos=1, txt='2', num=2, pre_txt='b', pre_num=1, name='minor')

# Generated at 2022-06-21 12:56:31.561786
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function in the packages module."""
    expected_out = '2.0'
    ver = bump_version('1.2.3', position=0)
    assert ver == expected_out

    expected_out = '2.2.0'
    ver = bump_version('2.1.3', position=1)
    assert ver == expected_out

    expected_out = '1.2.4'
    ver = bump_version('1.2.3')
    assert ver == expected_out

    expected_out = '1.2.4a0'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == expected_out

    expected_out = '1.2.4a1'

# Generated at 2022-06-21 12:56:43.500262
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:54.908410
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    def assert_version(version: str, expected: str):
        assert bump_version(version) == expected
        assert bump_version(version, 2) == expected
        assert bump_version(version, '2') == expected
    assert_version('1.2.3', '1.2.4')
    assert_version('1.2.0', '1.2.1')
    assert_version('1.2.3', '1.2.4')
    assert_version('1.2.3', '1.2.4')
    assert_version('1.2.3', '1.2.4')
    assert_version('1.2.3', '1.2.4')
    assert_version('1.2.0', '1.2.1')
   

# Generated at 2022-06-21 12:57:04.174328
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    class __VersionPart(NamedTuple):
        pos: int
        txt: str
        num: int
        pre_txt: str
        pre_num: int
        name: str
    tp = __VersionPart
    major = tp(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    minor = tp(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    patch = tp(pos=2, txt='0', num=0, pre_txt='', pre_num=-1, name='patch')

# Generated at 2022-06-21 12:57:15.055439
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the constructor of class _VersionPart.

    (flutils.packages._VersionPart)

    """
    msg = ''

# Generated at 2022-06-21 12:57:26.159916
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )


# Generated at 2022-06-21 12:57:51.651374
# Unit test for function bump_version
def test_bump_version():
    """Test ``bump_version`` function.

    *New in version 0.3*

    """
    def _test_bump(
            version: str,
            position: int = 2,
            pre_release: Union[str, None] = None,
            expected: str = '',
    ) -> None:
        _actual = bump_version(version, position, pre_release)
        msg = '\nGiven values: %r, %r, %r\nExpected: %r\nActual: %r' % (
            version, position, pre_release, expected, _actual
        )
        assert _actual == expected, msg

    _test_bump('1.2.2', expected='1.2.3')

# Generated at 2022-06-21 12:58:01.939282
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    assert _build_version_info('1.2a3') == _VersionInfo('1.2a3', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2a3', 2, 'a', 3, 'minor'), _VersionPart(2, '', 0, '', -1, 'patch'), 1)

# Generated at 2022-06-21 12:58:06.056261
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    expected = _VersionPart(
        pos=0, txt="1", num=1, pre_txt="", pre_num=-1, name="major"
    )
    assert _VersionPart(pos=0, txt="1", num=1, pre_txt="", pre_num=-1, name="major") == expected


# Unit tests for method _each_version_part

# Generated at 2022-06-21 12:58:14.644154
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    # pylint: disable=R0914
    ver_obj = StrictVersion('1.2.3')
    parts = list(_each_version_part(ver_obj))
    part = parts[0]

    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    part = parts[1]
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'

    part = parts[2]

# Generated at 2022-06-21 12:58:23.874981
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the 'bump_version' function.

    """
    from flutils.packages import bump_version

    ver_range = range(10)
    position_range = [pos * -1 for pos in range(-1, 2)]
    pre_range = ['alpha', 'a', 'beta', 'b']
    nope_range = ['c', 'd']

    # Part 1: Basic major, minor, patch tests
    for ver_num in ver_range:
        for pos_num in position_range:
            for pre_type in pre_range:
                version = '1.%s.0' % ver_num
                expected = '.'.join(map(str, (1, ver_num + 1, 0)))
                result = bump_version(version, position=pos_num)

# Generated at 2022-06-21 12:58:27.657123
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    rec_args: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    obj = _VersionPart(**rec_args)
    for key, val in rec_args.items():
        assert getattr(obj, key) == val



# Generated at 2022-06-21 12:58:41.042968
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3*

    """
    import pytest

    def test_each_version_part(
            version: str,
            expected: str
    ) -> None:
        """Test _each_version_part.

        Args:
            version: The version to test.
            expected: The expected out.

        :rtype: None

        """
        ver_obj = StrictVersion(version)
        out = ''.join(
            map(
                lambda x: '%s[%s/%s]' % (x.txt, x.pre_txt, x.pre_num),
                _each_version_part(ver_obj)
            )
        )
        assert out == expected


# Generated at 2022-06-21 12:58:53.760465
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = _VersionPart(
        pos=0,
        txt='',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == ''
    assert part.num == 1
    assert part.pre_

# Generated at 2022-06-21 12:59:07.157843
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart as _UUT_VersionPart


# Generated at 2022-06-21 12:59:16.022570
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '0.0.1'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name

# Generated at 2022-06-21 13:00:04.974060
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 13:00:12.187781
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version()."""
    _ver = '1.2.3'
    bump_version(_ver)
    _ver = '1.2.0'
    bump_version(_ver)
    _ver = '1.0.0'
    bump_version(_ver)
    _ver = '0.2.3'
    bump_version(_ver)
    _ver = '0.0.3'
    bump_version(_ver)

# Generated at 2022-06-21 13:00:22.292100
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.name == 'major'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.minor.name == 'minor'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2a0'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'a'
    assert ver

# Generated at 2022-06-21 13:00:27.926109
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '1', 1, 'a', 0, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'major'


# Generated at 2022-06-21 13:00:39.146567
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info("0.0.0") == _VersionInfo("0.0.0", _VersionPart(0, "0", 0, "", -1, "major"), _VersionPart(1, "0", 0, "", -1, "minor"), _VersionPart(2, "", 0, "", -1, "patch"), -1)
    assert _build_version_info("1.2.3") == _VersionInfo("1.2.3", _VersionPart(0, "1", 1, "", -1, "major"), _VersionPart(1, "2", 2, "", -1, "minor"), _VersionPart(2, "3", 3, "", -1, "patch"), -1)

# Generated at 2022-06-21 13:00:49.801840
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.0.0'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.0.0'

    version = '1.2.0'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.0'

    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3'

    version = '1.2.3b0'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3b0'

    version = '1.2.3b1'
    ver_info = _build_version_info(version)

# Generated at 2022-06-21 13:01:01.660508
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3a4')
    for part in _each_version_part(ver_obj):
        assert part == _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        )
        assert part == _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='a',
            pre_num=4,
            name='minor'
        )
        assert part == _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        )
        break


# Unit test

# Generated at 2022-06-21 13:01:06.943526
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from .tests import get_caller_module_name
    from .testing import _get_test_var

    caller_module = get_caller_module_name()
    expected = _get_test_var(caller_module, '_EXPECTED', caller_module)
    ver_part_def = _get_test_var(caller_module, 'VER_PART_DEF', caller_module)

    assert isinstance(ver_part_def, tuple)
    assert expected == _VersionPart(*ver_part_def)._asdict()



# Generated at 2022-06-21 13:01:16.086015
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from types import SimpleNamespace
    from argparse import Namespace

    for obj in (
            SimpleNamespace(version=(0, 2, 0)),
            SimpleNamespace(version=(1, 2, 0)),
            SimpleNamespace(version=(1, 2, 1)),
            SimpleNamespace(version=(1, 2, 0), prerelease=('a', 0)),
            SimpleNamespace(version=(1, 2, 0), prerelease=('alpha', 0)),
            SimpleNamespace(version=(1, 2, 0), prerelease=('b', 0)),
            SimpleNamespace(version=(1, 2, 0), prerelease=('beta', 0)),
    ):
        for part in _each_version_part(obj):
            assert isinstance(part, _VersionPart)



# Generated at 2022-06-21 13:01:27.455607
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2')
    assert ver_info.version == '1.2'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == ''
    assert ver_info.patch.num == 0
    assert ver_info.pre_pos == -1
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info

# Generated at 2022-06-21 13:02:17.297045
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '2', 2, '3', 3, 'patch').pos == 1
    assert _VersionPart(1, '2', 2, '3', 3, 'patch').txt == '2'
    assert _VersionPart(1, '2', 2, '3', 3, 'patch').num == 2
    assert _VersionPart(1, '2', 2, '3', 3, 'patch').pre_txt == '3'
    assert _VersionPart(1, '2', 2, '3', 3, 'patch').pre_num == 3
    assert _VersionPart(1, '2', 2, '3', 3, 'patch').name == 'patch'


# Generated at 2022-06-21 13:02:21.606554
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    Test the private class _VersionInfo
    """
    _build_version_info(version='1.2.3')


# Generated at 2022-06-21 13:02:23.337285
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('')



# Generated at 2022-06-21 13:02:31.608650
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 13:02:38.799019
# Unit test for function bump_version
def test_bump_version():
    """Test flutils.packages.bump_version"""


# Generated at 2022-06-21 13:02:48.359744
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2')
    _build_version_info('1')
    _build_version_info('1.2.3.a0')
    _build_version_info('1.2.3.b0')
    _build_version_info('1.2.a0')
    _build_version_info('1.2.b0')
    got_err = False
    try:
        _build_version_info('1.')
    except ValueError:
        got_err = True
    assert got_err is True



# Generated at 2022-06-21 13:03:00.313567
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major')
    assert _VersionPart(1, '2', 2, '', -1, 'minor')
    assert _VersionPart(2, '', 0, '', -1, 'patch')
    assert _VersionPart(1, '2a1', 2, 'a', 1, 'minor')
    assert _VersionPart(0, '1a0', 1, 'a', 0, 'major')
    assert _VersionPart(2, '1a1', 1, 'a', 1, 'patch')
    assert _VersionPart(1, '1a0', 1, 'a', 0, 'minor')
    assert _VersionPart(2, '1b1', 1, 'b', 1, 'patch')

# Generated at 2022-06-21 13:03:03.338729
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages._bumpversion import _VersionInfo
    return _VersionInfo('1.2.3', '1', '2', '3', -1)



# Generated at 2022-06-21 13:03:04.383377
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    pass



# Generated at 2022-06-21 13:03:13.373219
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('')
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name == 'minor'

    assert ver_info.patch.pos == 2
    assert ver

# Generated at 2022-06-21 13:04:45.992761
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914,C0103
    from flutils.packages import bump_version
    from flutils.testing.helpers import run_shell_command

    # Test to make sure the bump_version function does what we expect it to do

# Generated at 2022-06-21 13:04:55.921998
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from . import unit
    unit.assert_is_instance(
        _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart
    )
    unit.assert_equal(_VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor'),
                      _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor'))


# Generated at 2022-06-21 13:05:08.334775
# Unit test for function bump_version
def test_bump_version():
    """Tests the bump_version function."""
    def _check_bump(
            ver: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expect: str = '?'
    ) -> None:
        out = bump_version(ver, position, pre_release)
        assert expect == out

    # Uses a variety of version numbers,
    #   positions, and pre release strings
    # Uses asserts for verifying results
    _check_bump('1.2.2', expect='1.2.3')
    _check_bump('1.2.3', position=1, expect='1.3')
    _check_bump('1.3.4', position=0, expect='2.0')

# Generated at 2022-06-21 13:05:09.292425
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart()
    pass


# Generated at 2022-06-21 13:05:17.009775
# Unit test for function bump_version
def test_bump_version():
    """Tests the function :func:`flutils.packages.bump_version`."""
    # pylint: disable=C0116,C0115,W0212

    # Import, as needed, here to not slow down the documentation
    # noinspection PyUnresolvedReferences,PyPackageRequirements
    import pytest

    # Run tests for each version