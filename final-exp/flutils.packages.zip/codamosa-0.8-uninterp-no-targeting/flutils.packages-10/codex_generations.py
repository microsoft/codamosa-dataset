

# Generated at 2022-06-21 12:55:56.622354
# Unit test for function bump_version
def test_bump_version():
    """ Test bump_version function """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:08.422510
# Unit test for function bump_version
def test_bump_version():
    """Tests for bump_version()"""
    from flutils.packages import bump_version
    import pytest


# Generated at 2022-06-21 12:56:13.726121
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    assert _VersionPart(**args)



# Generated at 2022-06-21 12:56:22.166663
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120
    import sys

# Generated at 2022-06-21 12:56:24.521496
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    return (
        ('pos', int), ('txt', str), ('num', int), ('pre_txt', str),
        ('pre_num', int), ('name', str)
    )


# Generated at 2022-06-21 12:56:33.185741
# Unit test for function bump_version

# Generated at 2022-06-21 12:56:37.800289
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.patch.pre_txt == 'a'
    assert ver_info.patch.pre_num == 0
    assert ver_info.pre_

# Generated at 2022-06-21 12:56:38.804019
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:56:47.141743
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = StrictVersion('1.2.3')
    prerelease = version.prerelease
    assert prerelease is None
    for pos, num in enumerate(version.version):
        assert _VersionPart(pos, '%s' % num, num, '', -1, 'patch') == next(
            _each_version_part(version)
        )
    version = StrictVersion('1.2.3a0')
    prerelease = version.prerelease
    assert prerelease is not None
    assert prerelease == ('a', 0)
    for pos, num in enumerate(version.version):
        assert _VersionPart(
            pos, '%s%s%s' % (num, prerelease[0], prerelease[1]),
            num, prerelease[0], prerelease[1], 'patch'
        ) == next

# Generated at 2022-06-21 12:56:59.480403
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    # Test valid inputs
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', position=2) == '1.2.3'
    # Test 'major' bumping
    assert bump_version('1.2.3', position=3) == '2.0'
    assert bump_version('1.2.3', position=0) == '2.0'
    # Test 'minor' bumping
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=4) == '1.3'
    # Test 'patch' bumping

# Generated at 2022-06-21 12:57:36.000309
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.0')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0
        assert part.txt == '1'
        assert part.num == 1
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name == 'major'

    ver_obj = StrictVersion('1.2.5')
    for part in _each_version_part(ver_obj):
        if part.pos == 0:
            assert part.txt == '1'
            assert part.num == 1
        elif part.pos == 1:
            assert part.txt == '2'
            assert part.num == 2
        else:
            assert part.pos == 2
            assert part.txt == '5'
            assert part

# Generated at 2022-06-21 12:57:46.653696
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for ver_str, part_text in [
            ('1.2', '1'),
            ('1.2b0', '1.2b0'),
            ('1.2a0', '1.2a0'),
            ('1.2.3', '1.2'),
            ('1.2.1b0', '1.2.1b0'),
            ('1.2.1a0', '1.2.1a0'),
            ('1.0.0', '1')
    ]:
        part_list = list(_each_version_part(StrictVersion(ver_str)))
        part_list_text = map(lambda x: x.txt, part_list)
        part_text_computed = '.'.join(part_list_text)
        assert part_text_computed == part_text

# Generated at 2022-06-21 12:57:49.915846
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo"""
    _build_version_info('1.2.3')
    _build_version_info('1.2a1')
    _build_version_info('1')


# Generated at 2022-06-21 12:58:00.763065
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2')
    assert ver_info.version == '1.2'
    assert ver_info.pre_pos == -1
    assert ver_info.major.name == 'major'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.minor.name == 'minor'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.patch.name == 'patch'
    assert ver_info.patch.num == 0
    assert ver_info.patch.pre_txt == ''


# Generated at 2022-06-21 12:58:10.607831
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '4.5.6'
    major = _VersionPart(0, '4', 4, '', -1, 'major')
    minor = _VersionPart(1, '5', 5, '', -1, 'minor')
    patch = _VersionPart(2, '6', 6, '', -1, 'patch')
    pre_pos = -1
    ver_info = _VersionInfo(version, major, minor, patch, pre_pos)
    assert ver_info.version == '4.5.6'
    assert ver_info.major == _VersionPart(0, '4', 4, '', -1, 'major')
    assert ver_info.minor == _VersionPart(1, '5', 5, '', -1, 'minor')

# Generated at 2022-06-21 12:58:20.605538
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart.

    Args:
        None

    Returns:
        None

    """
    # Initialize key variables
    expected = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }

    # Create object
    ver_obj = _VersionPart(**expected)

    # Test instance variables
    assert ver_obj.pos == expected['pos']
    assert ver_obj.txt == expected['txt']
    assert ver_obj.num == expected['num']
    assert ver_obj.pre_txt == expected['pre_txt']
    assert ver_obj.pre_num == expected['pre_num']
    assert ver_obj.name

# Generated at 2022-06-21 12:58:30.321015
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version()"""

# Generated at 2022-06-21 12:58:34.470219
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = {}
    kwargs = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'b',
        'pre_num': 2,
        'name': 'major'
    }
    try:
        _VersionPart(*args, **kwargs)
    except Exception as err:
        raise AssertionError(
            "Failed to instantiate class '_VersionPart' "
            "with args: (%r) and kwargs: (%r).  Error: %s"
            "" % (args, kwargs, err)
        )



# Generated at 2022-06-21 12:58:46.321234
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 12:58:55.865965
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.1.1a1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.1.1b1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.1.0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)



# Generated at 2022-06-21 12:59:14.814671
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestCase(unittest.TestCase):

        def test_bump_version(self):
            import random
            from itertools import chain

            def build_ver() -> Tuple[int, int, int]:
                return (
                    random.randint(5, 8),
                    random.randint(0, 9),
                    random.randint(0, 9)
                )

            # noinspection PyTypeChecker

# Generated at 2022-06-21 12:59:19.162372
# Unit test for function bump_version
def test_bump_version():
    """ Test function bump_version.

    Returns:
        None
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'


# Generated at 2022-06-21 12:59:30.325622
# Unit test for function bump_version
def test_bump_version():  # noqa
    versions = [
        '1.0.0',
        '1.1.0',
        '1.1.1',
        '1.2b2',
        '1.2a2',
        '1.2.1',
        '1.2a1',
        '1.2b1',
        '1.3.0',
        '1.3.0b2',
        '1.3.0b1',
        '1.3.0a2',
        '1.3.0a1',
        '1.4.0',
        '1.4.1',
    ]
    for version in versions:
        print('|-')
        print('|| %s || %s ||' % (version, bump_version(version)))


# Run the test function, if

# Generated at 2022-06-21 12:59:36.679974
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart

    try:
        _VersionPart(0, 'aa', 0, '', 0, 'aa')
    except BaseException as exc:
        if not isinstance(exc, TypeError):
            raise
    else:
        raise TypeError('Failed to catch invalid constructor arguments.')

    try:
        _VersionPart(0, 'aa', 0, 'aa', 0, 'aa')
    except BaseException as exc:
        if not isinstance(exc, TypeError):
            raise
    else:
        raise TypeError('Failed to catch invalid constructor arguments.')

# Generated at 2022-06-21 12:59:43.192607
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert repr(_VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )) == (
        "VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, "
        "name='major')"
    )


# Generated at 2022-06-21 12:59:53.771402
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import just
    from hypothesis.strategies import text

    @given(
        text(min_size=0, max_size=15),
        integers(min_value=0, max_value=10000),
        text(min_size=0, max_size=15),
        integers(min_value=0, max_value=10000),
        just('major'),
        just('minor'),
        just('patch')
    )
    def _test(txt, num, pre_txt, pre_num, name1, name2, name3):
        part = _VersionPart(-1, txt, num, pre_txt, pre_num, name1)
        assert part.pos == -1
        assert part.txt == txt
       

# Generated at 2022-06-21 12:59:59.949283
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    ver_info = _VersionInfo('1.2.3',
                            _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3', 3, '', -1, 'patch'),
                            -1)
    print("'test__VersionInfo' output:{}".format(ver_info))
    assert ver_info is not None


# Generated at 2022-06-21 13:00:06.910249
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212

    # Test a full version number
    test_num = 10
    obj = _VersionPart(
        _BUMP_VERSION_MAJOR,
        '%s' % test_num,
        test_num,
        '',
        -1,
        _BUMP_VERSION_POSITION_NAMES[_BUMP_VERSION_MAJOR],
    )
    assert obj.pos == 0
    assert obj.txt == '10'
    assert obj.num == 10
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'

    # Test a minor version number
    test_num = 20

# Generated at 2022-06-21 13:00:18.137272
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args: Dict[str, Any] = {
        'pos': 2,
        'txt': '3',
        'num': 3,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'patch'
    }
    vr = _VersionPart(**args)
    assert vr.pos == args['pos']
    assert vr.txt == args['txt']
    assert vr.num == args['num']
    assert vr.pre_txt == args['pre_txt']
    assert vr.pre_num == args['pre_num']
    assert vr.name == args['name']

# Generated at 2022-06-21 13:00:25.469771
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function."""
    from flutils.packages import bump_version

# Generated at 2022-06-21 13:01:02.301354
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def test_case(info):
        args = info.version, info.major, info.minor, info.patch, info.pre_pos
        out = _VersionInfo(*args)
        assert out.version == info.version
        assert out.major == info.major
        assert out.minor == info.minor
        assert out.patch == info.patch
        assert out.pre_pos == info.pre_pos


# Generated at 2022-06-21 13:01:08.660097
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(
        pos=5,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='patch'
    )
    assert part.pos == 5
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'patch'



# Generated at 2022-06-21 13:01:17.864412
# Unit test for function bump_version
def test_bump_version():
    from sys import version_info
    from distutils.version import StrictVersion

    # We need Python 3.3 or newer
    if version_info < (3, 3):
        raise RuntimeError(
            "The function, 'flutils.packages.bump_version', has been tested "
            "only on Python 3.3 and newer.  Python 2.x is no longer "
            "supported."
        )

    # Test: Built-in function
    assert bump_version.__name__ == 'bump_version'
    assert bump_version.__doc__ is not None

    # Test: Each version part

# Generated at 2022-06-21 13:01:28.086819
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    def _dump(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> List[Any]:
        """Debug function for this unit test
        """
        ver_info = _build_version_info(version)
        position = _build_version_bump_position(position)
        bump_type = _build_version_bump_type(position, pre_release)
        return [
            version,
            bump_type,
            [ver_info.major, ver_info.minor, ver_info.patch],
            pre_release
        ]


# Generated at 2022-06-21 13:01:33.542572
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test = _each_version_part(StrictVersion('1.2.3a0'))
    assert test.__next__().pos == 0
    assert test.__next__().pos == 1
    assert test.__next__().pos == 2
    assert test.__next__().pos == 2
    with pytest.raises(StopIteration):
        test.__next__()



# Generated at 2022-06-21 13:01:46.796730
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test 1
    version = StrictVersion('1.2.3')
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num

# Generated at 2022-06-21 13:01:59.421434
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2') == _VersionInfo(
        '1.2',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    )
    assert _build_version_info('1.2a0') == _VersionInfo(
        '1.2a0',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2a0', 2, 'a', 0, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        1
    )

# Generated at 2022-06-21 13:02:11.935331
# Unit test for function bump_version

# Generated at 2022-06-21 13:02:20.827210
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    class Tester(object):
        def test_1(self):
            # Test where a pre-release is set
            parts = [
                ('0a0', ('a', 0)), ('0b0', ('b', 0)),
                ('0a1', ('a', 1)), ('0b1', ('b', 1)),
                ('0a2', ('a', 2)), ('0b2', ('b', 2)),
            ]
            for pre in parts:
                kwargs: Dict[str, Any] = {
                    'pos': 0,
                    'txt': '0',
                    'num': 0,
                    'pre_txt': '',
                    'pre_num': -1,
                    'name': 'foo',
                }
                kwargs['pre_txt'] = pre[1][0]

# Generated at 2022-06-21 13:02:30.328611
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3').version == '1.2.3'
    assert _build_version_info('1.2.3').major == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _build_version_info('1.2.3').minor == _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    assert _build_version_info('1.2.3').patch == _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch')
    assert _build_version_info('1.2.3').pre_pos == -1


# Generated at 2022-06-21 13:03:09.637361
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.0.0') == _VersionInfo(
        '1.0.0',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'),
        -1
    )

# Generated at 2022-06-21 13:03:16.481535
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args_test: Dict[str, List[Any]] = {
        'txt': ['1', '1'],
        'num': [1, 1],
        'pre_txt': [None, ''],
        'pre_num': [-1, -1],
        'pos': [1, 1],
        'name': ['minor', 'minor']
    }
    res: _VersionPart = _VersionPart(**args_test)
    assert res.txt == '1'
    assert res.num == 1
    assert res.pre_txt == ''
    assert res.pre_num == -1
    assert res.pos == 1
    assert res.name == 'minor'

    args_test['pre_txt'] = ['a', 'a']
    args_test['pre_num'] = [0, 0]
   

# Generated at 2022-06-21 13:03:27.280790
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3a1')
    _build_version_info('1.2.3b1')
    _build_version_info('1.2.3a1.dev')
    _build_version_info('1.2.0')
    _build_version_info('1.2')
    _build_version_info('1b1')
    _build_version_info('1a1')
    _build_version_info('1')
    _build_version_info('1a1.dev')
    _build_version_info('1.dev')
    _build_version_info('1.2.dev')
    _build_version_info('1.2.3.dev')


# Generated at 2022-06-21 13:03:36.098398
# Unit test for function bump_version
def test_bump_version():
    from collections import namedtuple
    from pprint import pformat as pf
    from flutils.packages import bump_version
    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str,
    ) -> None:
        result = bump_version(version, position, pre_release)
        assert result == expected, '_test values:\n%s' % pf((version, position,
                                                            pre_release,
                                                            expected,
                                                            result))

    _Test = namedtuple('_Test', 'version, position, pre_release, expected')

# Generated at 2022-06-21 13:03:47.870878
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # type: () -> None
    kwargs = dict(
        version='1.2.0',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )


# Generated at 2022-06-21 13:03:58.052847
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests the constructor of class _VersionInfo."""
    assert _build_version_info('1.2').version == '1.2'
    assert _build_version_info('1.2').major.num == 1
    assert _build_version_info('1.2').minor.num == 2
    assert _build_version_info('1.2').patch.num == -1
    assert _build_version_info('1.2').pre_pos == -1

    assert _build_version_info('1.2.3').version == '1.2.3'
    assert _build_version_info('1.2.3').major.num == 1
    assert _build_version_info('1.2.3').minor.num == 2

# Generated at 2022-06-21 13:04:04.513270
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        version='1.2.5a0',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='a', pre_num=0, name='minor'),
        patch=_VersionPart(pos=2, txt='5', num=5, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=1
    ) == _build_version_info('1.2.5a0')

# Generated at 2022-06-21 13:04:14.926331
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    v = _VersionPart(pos=0, txt='2', num=2, pre_txt='', pre_num=-1, name='major')
    assert (v.pos == 0 and v.txt == '2' and v.num == 2
            and v.pre_txt == '' and v.pre_num == -1 and v.name == 'major')
    v = _VersionPart(
        pos=1, txt='5', num=5, pre_txt='a', pre_num=0, name='minor'
    )
    assert (v.pos == 1 and v.txt == '5a0' and v.num == 5
            and v.pre_txt == 'a' and v.pre_num == 0 and v.name == 'minor')


# Generated at 2022-06-21 13:04:26.443727
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:04:33.656558
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    vpart = _VersionPart(1, '1', 1, 'a', 0, 'minor')
    assert isinstance(vpart, _VersionPart)
    assert vpart.pos == 1
    assert vpart.txt == '1'
    assert vpart.num == 1
    assert vpart.pre_txt == 'a'
    assert vpart.pre_num == 0
    assert vpart.name == 'minor'
