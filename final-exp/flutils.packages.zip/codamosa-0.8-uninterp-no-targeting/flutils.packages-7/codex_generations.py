

# Generated at 2022-06-21 12:56:08.729473
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:18.647313
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = (1, 'a', 'b', 'c')
    obj = _VersionPart(*args)
    assert isinstance(obj, _VersionPart)
    assert obj[0] == 1
    assert obj[1] == 'a'
    assert obj[2] == 'b'
    assert obj[3] == 'c'
    args = (1, 'a', 'b', 'c', 1)
    obj = _VersionPart(*args)
    assert isinstance(obj, _VersionPart)
    assert obj[0] == 1
    assert obj[1] == 'a'
    assert obj[2] == 'b'
    assert obj[3] == 'c'
    assert obj[4] == 1


# Generated at 2022-06-21 12:56:28.792477
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pragma: no cover
    _VersionPart  # type: ignore
    assert _VersionPart(  # type: ignore
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert _VersionPart(  # type: ignore
        pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
    )
    assert _VersionPart(  # type: ignore
        pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
    )
    assert _VersionPart(  # type: ignore
        pos=0, txt='2', num=2, pre_txt='a', pre_num=1, name='major'
    )


# Generated at 2022-06-21 12:56:41.256992
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _test_info = _build_version_info('1.2.5')
    assert _test_info.version == '1.2.5'
    assert _test_info.major.pos == 0
    assert _test_info.major.txt == '1'
    assert _test_info.major.num == 1
    assert _test_info.minor.pos == 1
    assert _test_info.minor.txt == '2'
    assert _test_info.minor.num == 2
    assert _test_info.patch.pos == 2
    assert _test_info.patch.txt == '5'
    assert _test_info.patch.num == 5
    assert _test_info.pre_pos == -1
    _test_info = _build_version_info('1.2.0')

# Generated at 2022-06-21 12:56:53.385273
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.4') == _VersionInfo(
        version='1.2.4',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='4',
            num=4,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )

    assert _build

# Generated at 2022-06-21 12:57:03.102114
# Unit test for function bump_version
def test_bump_version():
    """Unit tests the :func:`flutils.packages.bump_version` function."""
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Tests the flutils.packages.bump_version module"""
        @classmethod
        def setUpClass(cls):
            """Performs module level setup needed by the tests."""
            from flutils.packages import bump_version
            cls.bvf = bump_version

        def test_bump_version(self):
            """Bumps the version number."""
            bvf = self.bvf
            self.assertEqual(bvf('1.2.3'), '1.2.4')
            self.assertEqual(bvf('1.2.3', position=1), '1.3')
           

# Generated at 2022-06-21 12:57:14.385759
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:57:20.416819
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {
        'pos': None,
        'txt': None,
        'num': None,
        'pre_txt': None,
        'pre_num': None,
        'name': None,
    }
    for key, val in kwargs.items():
        kwargs[key] = key
    _VersionPart(**kwargs)


# Generated at 2022-06-21 12:57:30.381962
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""

    import pytest

    pos_vals = (
        ('minor', 1),
        ('patch', 2),
        ('patch', -1),
        ('major', 0),
        ('major', -2),
        ('minor', 1, 'alpha'),
        ('patch', 2, 'alpha'),
        ('patch', -1, 'alpha'),
        ('minor', 1, 'beta'),
        ('patch', 2, 'beta'),
        ('patch', -1, 'beta'),
    )


# Generated at 2022-06-21 12:57:41.125103
# Unit test for function bump_version
def test_bump_version():
    from flutils.tests import show_repr, show_test_start, show_test_done
    from flutils.tests import assert_true, assert_false, assert_equal

    show_test_start('bump_version', 'test_bump_version')
    is_ok = True
    msg_list: List[str] = []

    # Value err
    ver = '1.2.3'
    pos = 1
    pref = 'a'
    try:
        bump_version(ver, position=pos, pre_release=pref)
    except ValueError:
        pass
    else:
        is_ok = False

# Generated at 2022-06-21 12:58:04.262971
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.num == 2
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.num == 3
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.name == 'patch'
    version

# Generated at 2022-06-21 12:58:10.356267
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    gen = _each_version_part(ver_obj)

    next(gen)
    part_002 = next(gen)
    assert _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor',
    ) == part_002

    next(gen)
    part_003 = next(gen)
    assert _VersionPart(
        pos=2,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='patch',
    ) == part_003



# Generated at 2022-06-21 12:58:16.767039
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [0, '0', 0, '', -1, 'major']
    obj = _VersionPart(*args)
    assert isinstance(obj, _VersionPart)
    assert obj.pos == args[0]
    assert obj.txt == args[1]
    assert obj.num == args[2]
    assert obj.pre_txt == args[3]
    assert obj.pre_num == args[4]
    assert obj.name == args[5]


# Generated at 2022-06-21 12:58:27.674463
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    expected = _VersionInfo('1.2.3', _VersionPart(
        0,
        '1',
        1,
        '',
        -1,
        'major'
    ),
        _VersionPart(
            1,
            '2',
            2,
            '',
            -1,
            'minor'
        ),
        _VersionPart(
            2,
            '3',
            3,
            '',
            -1,
            'patch'
        ),
        -1)
    obj = _build_version_info('1.2.3')
    assert obj == expected

# Generated at 2022-06-21 12:58:41.043044
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """

    """
    print('Testing Constructor _VersionPart')
    arg1 = 0
    arg2 = '5'
    arg3 = 5
    arg4 = ''
    arg5 = -1
    arg6 = 'major'
    kwargs = {
        'pos': arg1,
        'txt': arg2,
        'num': arg3,
        'pre_txt': arg4,
        'pre_num': arg5,
        'name': arg6
    }
    obj = _VersionPart(**kwargs)

    assert obj.pos == arg1
    assert obj.txt == arg2
    assert obj.num == arg3
    assert obj.pre_txt == arg4
    assert obj.pre_num == arg5
    assert obj.name == arg6



# Generated at 2022-06-21 12:58:53.805737
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.minor.num == 2
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.num == 3
    assert ver_info.patch.txt == '3'

    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.minor.num == 2

# Generated at 2022-06-21 12:59:02.555995
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:59:13.774033
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:59:26.998832
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = [
        '1.2.0',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    ]
    ver_info = _VersionInfo(*args)
    assert ver_info.version == '1.2.0'
    assert ver_info.major == _VersionPart(0, '1', 1, '', -1, 'major')
    assert ver_info.minor == _VersionPart(1, '2', 2, '', -1, 'minor')
    assert ver_info.patch == _VersionPart(2, '', 0, '', -1, 'patch')

# Generated at 2022-06-21 12:59:37.141753
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    ver_obj = StrictVersion('1.2.3.dev1')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    ver_obj = StrictVersion('1.2.dev3')
    ver_obj.version = (1, 2, 0)
    part = next(_each_version_part(ver_obj))
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1


# Generated at 2022-06-21 13:00:15.227952
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version()"""
    # Test examples
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', prerelease='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-21 13:00:23.886767
# Unit test for function bump_version
def test_bump_version():
    def _compare_parts_equal(
            version: str,
            parts_info: Tuple[Tuple[_VersionInfo, ...], ...]
    ):
        ver_info = _build_version_info(version)
        for part in parts_info:
            check_version, hold_version = part
            if check_version != hold_version:
                raise AssertionError(
                    "ERROR: The version parts for version, %r are:\n"
                    "Expected: %r\n"
                    "Received: %r" % (version, hold_version, check_version)
                )


# Generated at 2022-06-21 13:00:36.384288
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    # pylint: disable=C0103
    # pylint: disable=R0914
    # pylint: disable=R0915
    # pylint: disable=W0212
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-21 13:00:47.545674
# Unit test for function bump_version
def test_bump_version():
    import random

    # Make sure bump_version, when called with a valid version number, returns
    # a valid version number
    def _foo(
            ver: str,
            position: int,
            pre_release: Optional[str]
    ) -> None:
        new_ver = bump_version(ver, position, pre_release)
        StrictVersion(new_ver)

    # Build a list of version numbers, scramble the order, then bump all of
    # them.  This will ensure we have a random sampling of version numbers
    # that get passed to StrictVersion above.

# Generated at 2022-06-21 13:00:55.268488
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:01:04.845980
# Unit test for function bump_version
def test_bump_version():
    from . import assert_equals, assert_raises

    assert_equals(bump_version('1.2.2'), '1.2.3')
    assert_equals(bump_version('1.2.3', position=1), '1.3')
    assert_equals(bump_version('1.3.4', position=0), '2.0')
    assert_equals(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
    assert_equals(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')
    assert_equals(bump_version('1.2.4a1', pre_release='b'), '1.2.4b0')
    assert_equ

# Generated at 2022-06-21 13:01:09.865591
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '1', 1, '', -1, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-21 13:01:18.356542
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:01:28.364715
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    # pylint: disable=line-too-long
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:01:31.325113
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '1', 1, '', 0, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == 0
    assert part.name == 'major'


# Generated at 2022-06-21 13:01:45.716518
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Unit test for function bump_version"""
    import doctest
    doctest.testmod()


if __name__ == '__main__':  # pragma: no cover
    test_bump_version()

# Generated at 2022-06-21 13:01:58.391150
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

# Generated at 2022-06-21 13:02:05.045867
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(1, '2', 2, 'a', 0, 'minor')
    assert isinstance(vp, _VersionPart)
    assert isinstance(vp.pos, int)
    assert isinstance(vp.txt, str)
    assert isinstance(vp.num, int)
    assert isinstance(vp.pre_txt, str)
    assert isinstance(vp.pre_num, int)
    assert isinstance(vp.name, str)



# Generated at 2022-06-21 13:02:16.993894
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version.
    """

    # pylint: disable=R0204,R0914
    import pytest
    from pytest import approx
    import os
    import sys

    sys.modules['_flutils_packages'] = sys.modules['flutils.packages']

    # Test each version part and the resulting value
    tests: List[Tuple[str, ...]] = []
    # Patch size zero
    tests.append(('0.1.0', approx(0.0), approx(1.0), approx(0.0)))
    tests.append(('0.1.0', approx(0.0), approx(1.0), approx(1.0)))
    tests.append(('0.1.0', approx(1.0), approx(0.0), approx(0.0)))

# Generated at 2022-06-21 13:02:24.846403
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        target = _VersionPart(1, 2, 3, 4, 5, 6)
        assert target.pos == 1
        assert target.txt == 2
        assert target.num == 3
        assert target.pre_txt == 4
        assert target.pre_num == 5
        assert target.name == 6
    except Exception:
        assert False


# Generated at 2022-06-21 13:02:36.576611
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function, bump_version.

    *New in version 0.3*

    Args:
        None

    Raises:
        AssertionError: if the unit test fails.

    Returns:
        :obj:`None`

    """

    def _test_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        actual = bump_version(version, position, pre_release)

# Generated at 2022-06-21 13:02:45.164732
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    expected = '1.2.4'

# Generated at 2022-06-21 13:02:55.516905
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    class MyError(Exception):
        pass
    version = '1.2.3a4'
    expected_part = _VersionPart(pos=0, txt='1', num=1,
                                 pre_txt='', pre_num=-1, name='major')
    info = _build_version_info(version)
    if info is None:
        raise MyError("Expected _VersionInfo, not None")
    if info.version != version:
        raise MyError("Expected version '%s', but got '%s'" % (version, info.version))
    part = info.major
    if part is None:
        raise MyError("Expected _VersionPart, not None")
    if part != expected_part:
        raise MyError("Expected '%s', but got '%s'" % (expected_part, part))

# Generated at 2022-06-21 13:03:06.461256
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from flutils.packages import _build_version_info

    ver_info = _build_version_info('1.2.3a1')
    ver_part = ver_info.minor
    assert ver_part.name == 'minor'
    assert ver_part.num == 2
    assert ver_part.txt == '2a1'
    assert ver_part.pre_txt == 'a'
    assert ver_part.pre_num == 1

    ver_part = ver_info.patch
    assert ver_part.name == 'patch'
    assert ver_part.num == 3
    assert ver_part.txt == '3'
    assert ver_part.pre_txt == ''
    assert ver_part.pre_num == -1

# Generated at 2022-06-21 13:03:12.035124
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') == \
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name="major")
    assert _VersionPart(1, '2', 2, '', -1, 'minor') == \
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name="minor")
    assert _VersionPart(2, '3', 3, '', -1, 'patch') == \
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name="patch")



# Generated at 2022-06-21 13:03:45.872365
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint:disable=E1101

    _build_version_info('0.0.0')
    _build_version_info('0.0.0a0')
    _build_version_info('0.0.0b0')
    _build_version_info('0.0.0b0')
    _build_version_info('1.0.0')
    _build_version_info('1.1.1')
    _build_version_info('1.2.2')
    _build_version_info('1.2.2a0')
    _build_version_info('1.2.2b0')
    _build_version_info('2.0.0a0')
    _build_version_info('2.1.0a0')

# Generated at 2022-06-21 13:03:50.805158
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    value = _VersionPart(1, '2', 3, '4', 5, 6)
    assert value.pos == 1
    assert value.txt == '2'
    assert value.num == 3
    assert value.pre_txt == '4'
    assert value.pre_num == 5
    assert value.name == '6'



# Generated at 2022-06-21 13:03:58.527491
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    e_args = (0, '0', 0, '', -1, 'major')
    e_kwargs = {
        'pos': e_args[0],
        'txt': e_args[1],
        'num': e_args[2],
        'pre_txt': e_args[3],
        'pre_num': e_args[4],
        'name': e_args[5]
    }
    e = _VersionPart(*e_args)
    assert e_kwargs == e._asdict()  # pylint: disable=no-member



# Generated at 2022-06-21 13:04:06.554198
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from textwrap import dedent

    from flutils.tests import assert_raises_str

    # noinspection PyShadowingNames
    def _assert(
            expect_obj: _VersionPart,
            **kwargs: Any
    ) -> None:
        with assert_raises_str(
                ValueError,
                dedent('''\
                    The required argument(s) ['pos', 'txt', 'num', 'pre_txt', \
'pre_num', 'name'] are missing.''').strip()
        ):
            _VersionPart(**kwargs)  # pylint: disable=E1128
        out = _VersionPart(**kwargs)  # pylint: disable=E1128
        assert isinstance(out, tuple)
        assert len(out) == 6

# Generated at 2022-06-21 13:04:16.795235
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=E1101
    ver_info = _build_version_info('1.2.3')
    assert isinstance(ver_info.version, str)
    assert ver_info.version == '1.2.3'
    assert isinstance(ver_info.major, _VersionPart)
    assert isinstance(ver_info.minor, _VersionPart)
    assert isinstance(ver_info.patch, _VersionPart)
    assert ver_info.pre_pos == -1
    ver_info = _build_version_info('1.2.3a0')
    assert isinstance(ver_info.version, str)
    assert ver_info.version == '1.2.3a0'
    assert isinstance(ver_info.major, _VersionPart)

# Generated at 2022-06-21 13:04:28.213975
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info("0.0.0")
    assert info.version == "0.0.0"
    assert info.major.pos == 0
    assert info.major.txt == "0"
    assert info.major.num == 0
    assert info.major.pre_txt == ""
    assert info.major.pre_num == -1
    assert info.major.name == "major"
    assert info.minor.pos == 1
    assert info.minor.txt == "0"
    assert info.minor.num == 0
    assert info.minor.pre_txt == ""
    assert info.minor.pre_num == -1
    assert info.minor.name == "minor"
    assert info.patch.pos == 2
    assert info.patch.txt == "0"
   

# Generated at 2022-06-21 13:04:39.562227
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:04:48.813576
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    ver_obj = StrictVersion('1.2.3')
    gen = _each_version_part(ver_obj)
    part = next(gen)
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = next(gen)
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'
    part = next(gen)
    assert part.pos == 2

# Generated at 2022-06-21 13:04:51.361236
# Unit test for function bump_version
def test_bump_version():
    # Use pytest ...
    pass


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-21 13:05:05.256108
# Unit test for function bump_version
def test_bump_version():
    """Unit test for ``bump_version``."""
    # Major version
    assert bump_version('2.3.0') == '3'
    assert bump_version('2.3.0', position=0) == '3'
    assert bump_version('2.3.0', position=0, pre_release='a') == '3'
    # Minor version
    assert bump_version('2.3.0') == '2.4'
    assert bump_version('2.3.0', position=1) == '2.4'
    assert bump_version('2.3.0', position=1, pre_release='a') == '2.4a0'
    # Patch version
    assert bump_version('2.3.0') == '2.3.1'