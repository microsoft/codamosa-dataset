

# Generated at 2022-06-21 12:55:51.651141
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('1.2.1a0', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '1', 1, 'a0', 0, 'patch'), 0)
    _VersionInfo('1.2.1a1', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '1', 1, 'a1', 1, 'patch'), 0)

# Generated at 2022-06-21 12:56:05.339239
# Unit test for function bump_version
def test_bump_version():
    """
    Tests the function, bump_version.

    :return: None
    """

    result = bump_version('1.2.2')
    assert result == '1.2.3'

    result = bump_version('1.2.3', position=1)
    assert result == '1.3'

    result = bump_version('1.3.4', position=0)
    assert result == '2.0'

    result = bump_version('1.2.3', prerelease='a')
    assert result == '1.2.4a0'

    result = bump_version('1.2.4a0', pre_release='a')
    assert result == '1.2.4a1'

    result = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-21 12:56:14.802892
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ['2.0.0',
            _VersionPart(pos=0,
                         txt='2',
                         num=2,
                         pre_txt='',
                         pre_num=-1,
                         name='major'),
            _VersionPart(pos=1,
                         txt='0',
                         num=0,
                         pre_txt='',
                         pre_num=-1,
                         name='minor'),
            _VersionPart(pos=2,
                         txt='',
                         num=0,
                         pre_txt='',
                         pre_num=-1,
                         name='patch'),
            -1]

# Generated at 2022-06-21 12:56:26.833626
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2')
    assert _build_version_info('1.2.3')
    assert _build_version_info('1.2.3a0')
    assert _build_version_info('1.2.3b0')
    assert _build_version_info('0.9a1')
    assert _build_version_info('0.9b1')
    assert _build_version_info('1.3.4')
    assert _build_version_info('1.2.3a0')
    assert _build_version_info('1.2.3a1')
    assert _build_version_info('1.2.3b0')
    assert _build_version_info('1.2.3b1')

# Generated at 2022-06-21 12:56:38.395237
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    args: Dict[str, Any] = {
        'version': '1.2.2',
        'expected': '1.2.3',
        'args': {},
        'kwargs': {}
    }
    test_bump_version_func(args)

    args['version'] = '1.2.3'
    args['expected'] = '1.3'
    args['kwargs']['position'] = 1
    test_bump_version_func(args)

    args['version'] = '1.3.4'
    args['expected'] = '2.0'
    args['kwargs']['position'] = 0
    test_bump_version_func(args)

    args['version'] = '1.2.3'

# Generated at 2022-06-21 12:56:45.372730
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from nose.tools import assert_equal

    args: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'a',
        'pre_num': 0,
    }
    part = _VersionPart(**args)

    assert_equal(part.num, 1)
    assert_equal(part.txt, '1')
    assert_equal(part.pre_txt, 'a')
    assert_equal(part.pre_num, 0)
    assert_equal(part.name, 'major')



# Generated at 2022-06-21 12:56:47.144667
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    build_version_info(version)

# Generated at 2022-06-21 12:56:52.737886
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pformat as pf
    args: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    p = _VersionPart(**args)
    assert pf(args) == pf(p._asdict())



# Generated at 2022-06-21 12:57:01.931255
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(
        pos=1, txt='1', num=1, pre_txt='x', pre_num=2, name='minor'
    )
    print(obj)
    print(len(obj))
    print(obj._fields, obj._field_defaults)
    print(obj.pos, obj.txt, obj.num)
    print(obj[0], obj[2])
    print(obj.minor, obj.name)
    print(obj.asdict())
    print(obj.replace(num=2))
    print(obj._asdict())
    print(obj._replace(num=2))
    print(obj.__dict__)
    print(obj.__slots__)



# Generated at 2022-06-21 12:57:13.522527
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('2.0') == _VersionInfo(
        version='2.0',
        major=_VersionPart(
            pos=0,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )


# Generated at 2022-06-21 12:57:52.212703
# Unit test for function bump_version
def test_bump_version():
    """
    Tests for function bump_version.
    """
    # pylint: disable=W0631
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_

# Generated at 2022-06-21 12:58:02.160918
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=C0111
    # pylint: disable=W0212
    test_version = _build_version_info('1.2.3')

# Generated at 2022-06-21 12:58:11.694598
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: nocover
    def _test(given: str, expected: str) -> None:
        if expected is None:
            ex_major = None
            ex_minor = None
            ex_patch = None
            ex_pre_pos = None
        else:
            ex_major = cast(
                _VersionPart, _VersionInfo(*expected).major
            ).name
            ex_minor = cast(
                _VersionPart, _VersionInfo(*expected).minor
            ).name
            ex_patch = cast(
                _VersionPart, _VersionInfo(*expected).patch
            ).name
            ex_pre_pos = cast(int, _VersionInfo(*expected).pre_pos)
        actual = _VersionInfo(*_build_version_info(given))

# Generated at 2022-06-21 12:58:21.797074
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: no cover
    from pprint import pprint

    for inp, expect in (
            ('0a0', '0a0'),
            ('0.0a0', '0.0a0'),
            ('0.0.0', '0.0.0'),
            ('0.0.0a0', '0.0.0a0'),
            ('0.1', '0.1'),
            ('0.1a0', '0.1a0'),
            ('0.1.0', '0.1.0'),
            ('0.1.0a0', '0.1.0a0'),
    ):
        obj = _build_version_info(inp)

# Generated at 2022-06-21 12:58:32.995518
# Unit test for function bump_version
def test_bump_version():
    """Test unit for function bump_version."""
    # pylint: disable=E1101
    # pylint: disable=W0612
    from unittest import TestCase, main

    from flutils.packages import bump_version

    class _BumpVersionTest(TestCase):
        """Unit test for function bump_version."""


# Generated at 2022-06-21 12:58:37.053871
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=C0103,W0613
    _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='major'
    )



# Generated at 2022-06-21 12:58:47.057543
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:59:00.470842
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                        pre_num=-1, name='major').pos == 0
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                        pre_num=-1, name='major').txt == '1'
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                        pre_num=-1, name='major').num == 1
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                        pre_num=-1, name='major').pre_txt == ''

# Generated at 2022-06-21 12:59:10.692578
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    ver_info = _VersionInfo(version,
                            _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    assert ver_info.version == version
    assert ver_info.major == ver_info.major
    assert ver_info.minor == ver_info.minor
    assert ver_info.patch == ver_info.patch
    assert ver_info.pre_pos == -1

# Generated at 2022-06-21 12:59:24.342890
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: no cover
    """Unit test for constructor of class _VersionInfo."""
    ver_info = _build_version_info('1.2.3')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '3'
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.3a4')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3

# Generated at 2022-06-21 12:59:41.146045
# Unit test for function bump_version
def test_bump_version():
    """Test :func:`flutils.packages.bump_version`."""
    from flutils.packages import bump_version

    def _test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = ''
    ):
        out = bump_version(version, position, pre_release)
        assert out == expected

    _test('1.2.2', expected='1.2.3')
    _test('1.2.3', 1, expected='1.3')
    _test('1.3.4', 0, expected='2.0')
    _test('1.2.3', pre_release='a', expected='1.2.4a0')

# Generated at 2022-06-21 12:59:52.110960
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('0.1.0a1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('0.1.0b1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.0.0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.1.1a1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.1.1b1')

# Generated at 2022-06-21 12:59:58.378032
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '0.1.2'
    obj = _VersionInfo(version, None, None, None, -1)
    assert obj.version == version
    assert obj.pre_pos == -1
    obj = _VersionInfo(version, None, None, None, None)
    assert obj.pre_pos == -1
    version = '0.1.2-a0.b1'
    obj = _VersionInfo(version, None, None, None, 1)
    assert obj.pre_pos == 1



# Generated at 2022-06-21 13:00:03.901458
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.etc import (
        FunctionTestHelper,
    )

    test_helper = FunctionTestHelper(bump_version)

    test_helper.add_test_case(
        function_args=['1.2.2'],
        expected_return='1.2.3',
    )

# Generated at 2022-06-21 13:00:15.023677
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0511
    txt = '1.2.3'
    ver_obj = StrictVersion(txt)
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            assert part.pre_num >= 0
        else:
            assert part.pre_num == -1

    txt = '1.2'
    ver_obj = StrictVersion(txt)
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            assert part.pre_num >= 0
        else:
            assert part.pre_num == -1

    txt = '1'
    ver_obj = StrictVersion(txt)

# Generated at 2022-06-21 13:00:23.759363
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""

    assert bump_version('1.2.2') == '1.2.3', 'error #1'
    assert bump_version('1.2.3', position=1) == '1.3', 'error #2'
    assert bump_version('1.3.4', position=0) == '2.0', 'error #3'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0', 'error #4'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1', 'error #5'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0', 'error #6'

# Generated at 2022-06-21 13:00:28.687149
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    with pytest.raises(TypeError):
        _VersionPart(**{
            'pos': 1, 'txt': '2', 'num': 3,
            'pre_txt': 'a', 'pre_num': 4, 'name': 'major'
        })



# Generated at 2022-06-21 13:00:39.625998
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0612

    # noinspection PyUnusedLocal
    def _test(
            pos: int,
            txt: str,
            num: int,
            pre_txt: str,
            pre_num: int,
            name: str
    ) -> None:
        """Unit testing function for _VersionPart.

        Args:
            pos (int): Version part position.
            txt (str): Version part text.
            num (int): Version part numeric value.
            pre_txt (str): Version part prerelease text.
            pre_num (int): Version part prerelease numeric value.
            name (str): Version part name.

        """

# Generated at 2022-06-21 13:00:50.156984
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """
    # pylint: disable=W0123
    # pylint: disable=R0903
    # pylint: disable=C0111
    # pylint: disable=R0914
    # pylint: disable=W0104
    # pylint: disable=W0105

    import os
    import sys
    import unittest

    class Test_bump_version(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None


# Generated at 2022-06-21 13:01:01.731430
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '2.0rc0'
    obj = _build_version_info(version)
    assert obj.version == version
    assert obj.major.num == 2
    assert obj.major.name == 'major'
    assert obj.major.pre_txt == ''
    assert obj.major.pre_num == -1
    assert obj.major.pos == 0
    assert obj.major.txt == '2'
    assert obj.minor.num == 0
    assert obj.minor.name == 'minor'
    assert obj.minor.pre_txt == 'rc'
    assert obj.minor.pre_num == 0
    assert obj.minor.pos == 1
    assert obj.minor.txt == '0rc0'
    assert obj.patch.num == 0

# Generated at 2022-06-21 13:01:29.919587
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def verify(version, pre_pos, major, minor, patch):
        ver_info = _build_version_info(version)
        assert ver_info.version == version
        assert ver_info.pre_pos == pre_pos
        assert ver_info.major == major
        assert ver_info.minor == minor
        assert ver_info.patch == patch

    verify('13.0.2', -1,
           _VersionPart(0, '13', 13, '', -1, 'major'),
           _VersionPart(1, '0', 0, '', -1, 'minor'),
           _VersionPart(2, '2', 2, '', -1, 'patch'))


# Generated at 2022-06-21 13:01:44.158267
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = StrictVersion('1.2.3a0')
    pre_release = (
        'a0',
        'alpha0',
        'b0',
        'beta0',
        'beta1',
        'a1',
        'alpha1',
        'b1',
    )
    for prefix in pre_release:
        ver_obj = StrictVersion('%s' % version)
        ver_obj.prerelease = (prefix, 0)
        part = next(_each_version_part(ver_obj))
        assert part.pos == 2
        assert part.txt == '3%s0' % prefix[:1]
        assert part.pre_num == 0
        assert part.pre_txt == prefix[:1]


# Generated at 2022-06-21 13:01:56.574497
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('0.2.4') == _VersionInfo('0.2.4',
                                                        _VersionPart(0, '0', 0, '', -1, 'major'),
                                                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                                                        _VersionPart(2, '4', 4, '', -1, 'patch'),
                                                        -1)

# Generated at 2022-06-21 13:02:06.971175
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1')
    _build_version_info('1.0')
    _build_version_info('1.0.0')
    _build_version_info('1.0.0a1')
    _build_version_info('1.0.0b2')
    _build_version_info('1.0a5')
    _build_version_info('1.0b6')
    _build_version_info('1.0-alpha')
    _build_version_info('1.0-alpha1')
    _build_version_info('1.0-alpha.1')
    _build_version_info('1.0-alpha1.0')
    _build_version_info('1.0-beta')
    _build_version_info('1.0-beta1')

# Generated at 2022-06-21 13:02:18.185062
# Unit test for function bump_version
def test_bump_version():
    """Run the unit tests for :class:`bump_version`."""
    # Major release bumps
    assert bump_version('1.2.2') == '1.2.3'
    # Minor release bumps
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=1) == '1.4'
    # Patch release bumps
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.4', position=2) == '1.2.5'
    assert bump_version('1.3.4', position=2) == '1.3.5'
    # Major release bumps with pre-release

# Generated at 2022-06-21 13:02:29.518880
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:02:36.528677
# Unit test for function bump_version
def test_bump_version():

    def run_test(version, position, pre_release, exp_result):
        print(
            '\nBumping version: %r, position: %r, pre_release: %r ...'
            % (version, position, pre_release)
        )
        result = bump_version(version, position, pre_release)
        assert result == exp_result, (
            'The result should be: %r, not: %r' % (exp_result, result)
        )
        print('...bumps to: %r' % result)
        print('Success!!')

    run_test('1.2.2', 2, None, '1.2.3')
    run_test('1.2.3', 1, None, '1.3')

# Generated at 2022-06-21 13:02:45.135868
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from djutils.testutils import (
        assert_equal,
        assert_raises,
        assert_true,
    )

    # Function tests
    assert_equal(
        bump_version('1.2.2'),
        '1.2.3'
    )
    assert_equal(
        bump_version('1.2.3', position=1),
        '1.3'
    )
    assert_equal(
        bump_version('1.3.4', position=0),
        '2.0'
    )
    assert_equal(
        bump_version('1.2.3', pre_release='a'),
        '1.2.4a0'
    )

# Generated at 2022-06-21 13:02:53.059856
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:04.985262
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnresolvedReferences
    version = '1.2.3'
    # noinspection PyUnresolvedReferences
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    # noinspection PyUnresolvedReferences
    minor = _VersionPart(1, '2', 2, '', -1, 'minor')
    # noinspection PyUnresolvedReferences
    patch = _VersionPart(2, '3', 3, '', -1, 'patch')
    # noinspection PyUnresolvedReferences
    pre_pos = -1
    # noinspection PyUnresolvedReferences
    obj = _VersionInfo(version, major, minor, patch, pre_pos)
    assert obj.version == '1.2.3'
    assert obj.major == major

# Generated at 2022-06-21 13:03:23.680264
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyProtectedMember
    from flutils.tests import TEST_PARAM_DOT_VERSION_INFO
    for version in TEST_PARAM_DOT_VERSION_INFO:
        ver_info = _build_version_info(version)
        assert isinstance(ver_info, _VersionInfo)



# Generated at 2022-06-21 13:03:32.639654
# Unit test for function bump_version
def test_bump_version():
    "Unit test for function bump_version."
    # Deliberately exclude hyphenated version numbers to ensure that
    # those are not accidentally processed.

# Generated at 2022-06-21 13:03:43.587288
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    from flutils.packages import _VersionPart  # pylint: disable=W0212
    ver_obj = StrictVersion('1.3.0')

    out = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert next(_each_version_part(ver_obj)) == out

    out = _VersionPart(
        pos=1,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )
    assert next(_each_version_part(ver_obj)) == out


# Generated at 2022-06-21 13:03:54.439331
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    import pytest
    from flutils.packages import bump_version

    def _test(ver_str, position, pre_release, expected):
        actual = bump_version(ver_str, position, pre_release)
        assert actual == expected, 'Version string: %r' % ver_str

    # Tests for position
    for pos_min in range(-3, -1):
        pytest.raises(
            ValueError,
            bump_version,
            '1.2.3',
            position=pos_min
        )
    for pos_max in range(3, 5):
        pytest.raises(
            ValueError,
            bump_version,
            '1.2.3',
            position=pos_max
        )

    # Test for invalid pre_release


# Generated at 2022-06-21 13:04:02.855793
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('0.1.0', _VersionPart(0, '0', 0, '', -1, 'major'),
                 _VersionPart(1, '1', 1, '', -1, 'minor'),
                 _VersionPart(2, '0', 0, '', -1, 'patch'), -1)
    _VersionInfo('0.1.0a1', _VersionPart(0, '0', 0, '', -1, 'major'),
                 _VersionPart(1, '1', 1, 'a', 1, 'minor'),
                 _VersionPart(2, '0', 0, '', -1, 'patch'), -1)

# Generated at 2022-06-21 13:04:14.033171
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # noqa: D103

    def do_test(version, major, minor, patch, pre_pos):
        # noinspection PyUnusedLocal
        ver_info = _VersionInfo(version, major, minor, patch, pre_pos)

    # pylint: disable=W0122
    eval(compile(
        "do_test('1.2.4', _VersionPart(0, '1', 1, '', -1, 'major'), "
        "         _VersionPart(1, '2', 2, '', -1, 'minor'), "
        "         _VersionPart(2, '4', 4, '', -1, 'patch'), -1)",
        "<string>",
        "exec"
    ))

# Generated at 2022-06-21 13:04:25.470647
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    assert _build_version_info('1.2.0') == _VersionInfo('1.2.0', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '', 0, '', -1, 'patch'), -1)

# Generated at 2022-06-21 13:04:37.234347
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:04:47.585904
# Unit test for function bump_version
def test_bump_version():
    from pprint import pformat
    from textwrap import dedent

    from flutils.packages import bump_version

    def fix(txt: str) -> str:
        return dedent(txt).strip()

    def show(expected: str, result: str, version: str, position: int,
             pre_release: Optional[str] = None) -> None:
        args = {
            'pre_release': pre_release,
            'position': position,
            'version': version
        }
        if pre_release:
            args['pre_release'] = repr(pre_release)
        print("""
            bump_version(**{args})
            Expected: {expected}
            Got:      {result}
            """.format(expected=expected, result=result, args=pformat(args))
        )

    got = bump

# Generated at 2022-06-21 13:05:01.962595
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    print('Testing: bump_version')