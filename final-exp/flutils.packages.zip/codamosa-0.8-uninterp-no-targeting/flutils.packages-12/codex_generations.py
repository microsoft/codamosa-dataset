

# Generated at 2022-06-21 12:55:51.375421
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for the constructor of class :obj:`_VersionInfo`."""
    from flutils.packages import _VersionInfo

    # Single major version
    ver_info = _VersionInfo('1', '1', '', '', '', '')
    assert ver_info.version == '1'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 0
    assert ver_info.patch.num == 0

    # Single major version with pre-release
    ver_info = _VersionInfo(
        '1a9',
        '1',
        'a9', 'a',
        9,
        'a'
    )
    assert ver_info.version == '1a9'
    assert ver_info.major.num == 1

# Generated at 2022-06-21 12:55:59.240366
# Unit test for function bump_version
def test_bump_version():
    bumped = bump_version('1.2.2')
    assert bumped == '1.2.3'

    bumped = bump_version('1.2.2', position=1)
    assert bumped == '1.3'

    bumped = bump_version('1.2.2', position=0)
    assert bumped == '2.0'

    bumped = bump_version('1.2.2', prerelease='a')
    assert bumped == '1.2.3a0'

    bumped = bump_version('1.2.3a0', pre_release='a')
    assert bumped == '1.2.3a1'

    bumped = bump_version('1.2.3a1', pre_release='b')
    assert bumped == '1.2.3b0'


# Generated at 2022-06-21 12:56:08.501577
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version


# Generated at 2022-06-21 12:56:16.251961
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    test = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert test.pos == 0
    assert test.txt == '1'
    assert test.num == 1
    assert test.pre_txt == ''
    assert test.pre_num == -1
    assert test.name == 'major'


# Generated at 2022-06-21 12:56:24.029447
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')

# Generated at 2022-06-21 12:56:33.744793
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(
        pos=3,
        txt='3alpha0',
        num=3,
        pre_txt='alpha',
        pre_num=0,
        name='minor'
    )
    assert str(vp) == "VersionPart(pos=3, txt='3alpha0', num=3, " \
                      "pre_txt='alpha', pre_num=0, name='minor')"
    assert vp.pos == 3
    assert vp.txt == '3alpha0'
    assert vp.num == 3
    assert vp.pre_txt == 'alpha'
    assert vp.pre_num == 0
    assert vp.name == 'minor'

# Generated at 2022-06-21 12:56:41.833886
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 12:56:53.889998
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of the _VersionInfo class.

    Arguments:
    - version (str): A version name

    Returns:
    - _VersionInfo: the _VersionInfo object for that version
    """
    import datetime
    start_time = datetime.datetime.now()
    print("Running unit tests...")


# Generated at 2022-06-21 12:57:03.517377
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.0'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '', 0, '', -1, 'minor')
    patch = _VersionPart(2, '', 0, '', -1, 'patch')
    pre_pos = -1
    args = _build_version_info(version)
    # Check positional arguments
    assert args[:3] == (version, major, minor)
    # Check keyword arguments
    assert args.patch == patch
    assert args.pre_pos == pre_pos
    # Test variations
    version = '1.0alpha'
    major = _VersionPart(0, '1', 1, '', -1, 'major')

# Generated at 2022-06-21 12:57:14.661154
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

    # pylint: disable=W0105
    '''Disabling docstring checking'''

    from .testdata import (
        INVALID_ARG_TYPES,
        VALID_ARG_TYPES,
        VALID_ARG_VALUES,
        VALID_BUMP_VERSIONS
    )

    from flutils.general import loop_test_data

    from .packages import bump_version

    for args, data in loop_test_data(VALID_BUMP_VERSIONS):
        assert bump_version(*args) == data

    for args in INVALID_ARG_TYPES:
        print(args)
        loop_test_data(args, VALID_ARG_TYPES)


# Generated at 2022-06-21 12:58:05.861391
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # noqa: F811
    """Test constructor of class _VersionInfo."""

# Generated at 2022-06-21 12:58:14.518559
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    ) == _each_version_part(StrictVersion('1.2.3'))[0]
    assert _VersionPart(
        pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
    ) == _each_version_part(StrictVersion('1.2.3'))[1]
    assert _VersionPart(
        pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
    ) == _each_version_part(StrictVersion('1.2.3'))[2]

# Generated at 2022-06-21 12:58:23.778537
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import capture_output
    # Build a list of test case data

# Generated at 2022-06-21 12:58:30.182700
# Unit test for function bump_version
def test_bump_version():
    version: str = '0.0.0'
    new_version: str = bump_version(version)
    assert new_version == '0.0.1'

    version = '0.1.1'
    new_version = bump_version(version)
    assert new_version == '0.1.2'

    version = '0.1.1'
    new_version = bump_version(version, position=1)
    assert new_version == '0.2'

    version = '1.2.0'
    new_version = bump_version(version, position=0)
    assert new_version == '2.0'

    version = '1.2.0'
    new_version = bump_version(version, position=0, pre_release='a')

# Generated at 2022-06-21 12:58:39.960471
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    ) == _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    ) != _VersionPart(
        pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )



# Generated at 2022-06-21 12:58:47.317536
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.2')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-21 12:59:00.688471
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """
    Test for class _VersionPart

    *New in version 0.3*
    """

    from flutils.testing import run_unittest

    if run_unittest(__name__) is False:
        return

    version = '1.2.3'
    ver_obj = StrictVersion(version)

# Generated at 2022-06-21 12:59:12.332188
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == \
        _VersionInfo(
            version='1.2.3',
            major=_VersionPart(
                pos=0,
                txt='1',
                num=1,
                pre_txt='',
                pre_num=-1,
                name='major'
            ),
            minor=_VersionPart(
                pos=1,
                txt='2',
                num=2,
                pre_txt='',
                pre_num=-1,
                name='minor'
            ),
            patch=_VersionPart(
                pos=2,
                txt='3',
                num=3,
                pre_txt='',
                pre_num=-1,
                name='patch'
            ),
            pre_pos=-1
        )
   

# Generated at 2022-06-21 12:59:26.135988
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major').pos == 0
    assert _VersionPart(0, '1', 1, '', -1, 'major').txt == '1'
    assert _VersionPart(0, '1', 1, '', -1, 'major').num == 1
    assert _VersionPart(0, '1', 1, '', -1, 'major').pre_txt == ''
    assert _VersionPart(0, '1', 1, '', -1, 'major').pre_num == -1
    assert _VersionPart(0, '1', 1, '', -1, 'major').name == 'major'
    assert _VersionPart(1, '5', 5, '', -1, 'minor').pos == 1

# Generated at 2022-06-21 12:59:36.787172
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '3', 3, '',
        -1, 'patch'), -1)
    assert ver.version == '1.2.3'
    assert ver.major.pos == 0
    assert ver.major.txt == '1'
    assert ver.major.num == 1
    assert ver.major.pre_txt == ''
    assert ver.major.pre_num == -1
    assert ver.major.name == 'major'
    assert ver.minor.pos == 1
    assert ver.minor.txt == '2'
    assert ver.minor.num == 2

# Generated at 2022-06-21 12:59:48.487731
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '1', 1, '', -1, 'minor')


# Generated at 2022-06-21 12:59:56.442417
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.0')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    ver_obj = StrictVersion('1.2.3')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    ver_obj = StrictVersion('1.2.3')

# Generated at 2022-06-21 13:00:02.324916
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    assert str(_VersionPart(0, '', 0, '', 0, 'major')) == '(0, \'\', 0, \'\', ' \
        '0, \'major\')'
    assert str(_VersionPart(1, '1', 1, '', -1, 'minor')) == '(1, \'1\', 1, ' \
        '\'\', -1, \'minor\')'


# Generated at 2022-06-21 13:00:13.846895
# Unit test for function bump_version

# Generated at 2022-06-21 13:00:22.822793
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor') == _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor')
    assert _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor') != _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor')
    assert str(_VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor')) == 'minor: 0. Pre-release: .  Position: 1'

# Unit test

# Generated at 2022-06-21 13:00:35.396473
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:00:47.072895
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:00:51.529864
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:01:00.524470
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from collections import namedtuple
    from unittest.mock import patch
    with patch.object(__name__ + '.NamedTuple', '__new__') as mock:
        _VersionPart(1, 'x', 2, 'y', 3, 'z')
        mock.assert_called_once_with(
            (__name__ + '._VersionPart')[0],
            (1, 'x', 2, 'y', 3, 'z'),
            False
        )
    assert mock == namedtuple('_VersionPart', 'pos txt num pre_txt pre_num name')


# Generated at 2022-06-21 13:01:07.692655
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test_version = 'test_version'
    part = _VersionPart(test_version, test_version, test_version,
                        test_version, test_version, test_version)
    assert part.pos == test_version
    assert part.txt == test_version
    assert part.num == test_version
    assert part.pre_txt == test_version
    assert part.pre_num == test_version
    assert part.name == test_version

# Generated at 2022-06-21 13:01:31.356519
# Unit test for function bump_version
def test_bump_version():
    from .utils import test_equals

    def run(
            version: str,
            expected: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        ret = bump_version(version, position, pre_release)
        test_equals(ret, expected)

    run('1.2.2', '1.2.3')
    run('1.2.3', '1.3', position=1)
    run('1.3.4', '2.0', position=0)
    run('1.2.3', '1.2.4a0', pre_release='a')
    run('1.2.4a0', '1.2.4a1', pre_release='a')

# Generated at 2022-06-21 13:01:36.219893
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version_info = _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '3', 3, '', -1, 'patch'), 2)
    assert version_info.version == '1.2.3'
    assert version_info.major.pos == 0
    assert version_info.major.txt == '1'
    assert version_info.major.num == 1
    assert version_info.major.pre_txt == ''
    assert version_info.major.pre_num == -1
    assert version_info.major.name == 'major'
    assert version_info.minor.pos == 1

# Generated at 2022-06-21 13:01:48.079924
# Unit test for function bump_version
def test_bump_version():
    """
    Tests the bump_version function
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-21 13:01:59.956639
# Unit test for function bump_version
def test_bump_version():
    def _test_bump_version(func, version, expected_output, msg=None, **kwargs):
        output = func(version, **kwargs)
        assert output == expected_output, msg

    _test_bump_version(bump_version, '1.2.2', '1.2.3', msg='Bump patch, default')
    _test_bump_version(bump_version, '1.2.3', '1.3', position=1,
                       msg='Bump minor')
    _test_bump_version(bump_version, '1.3.4', '2.0', position=0,
                       msg='Bump major')

# Generated at 2022-06-21 13:02:12.397189
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '3', 3, '', -1, 'major') == _VersionPart(
        pos=0,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert _VersionPart(
        pos=1,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=1,
        name='minor'
    ) == _VersionPart(
        1,
        '1a1',
        1,
        'a',
        1,
        'minor'
    )

# Generated at 2022-06-21 13:02:21.079730
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0613
    """Test class: `._VersionInfo`

    *New in version 0.3*"""

# Generated at 2022-06-21 13:02:28.199568
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    version = '1.2.2'
    bumped = bump_version(version)
    assert bumped == '1.2.3'

    bumped = bump_version(version, position=0)
    assert bumped == '2.0'

    bumped = bump_version(version, position=1)
    assert bumped == '1.3'

    bumped = bump_version(version, pre_release='a')
    assert bumped == '1.2.3a0'

    bumped = bump_version(bumped, pre_release='a')
    assert bumped == '1.2.3a1'

    bumped = bump_version(bumped)
    assert bumped == '1.2.4'

    bumped = bump_version(bumped, pre_release='b')
    assert bumped

# Generated at 2022-06-21 13:02:40.719481
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import BasicTestCase

    class TestCase(BasicTestCase):
        def test_case(self):
            for inp, out in self.data:
                with self.subTest(inp=inp, out=out):
                    self.assertEqual(bump_version(*inp), out)


# Generated at 2022-06-21 13:02:50.571910
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    class TestCase(NamedTuple):
        version: str
        part: _VersionPart


# Generated at 2022-06-21 13:03:02.363404
# Unit test for function bump_version
def test_bump_version():
    """Test for flutils.packages.bump_version()"""

    def test():
        """Test for flutils.packages.bump_version()"""
        from nose.tools import assert_equal, assert_raises

        def assert_ex_num(ex, ex_num):
            # type: (Exception, int) -> None
            """assert that the exception number is correct

            Args:
                ex (Exception): The exception that was thrown.
                ex_num (int): The error number that was expected.

            Raises:
                :obj:`AssertionError`:
                    * If the expected and actual error numbers are not
                      equal.

            """
            ex_num_actual = ex.__repr__()[1:ex_num + 1]
            assert_equal(ex_num, int(ex_num_actual))



# Generated at 2022-06-21 13:04:16.038855
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 13:04:19.273738
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    with open('metadata.json') as f:
        metadata = json.load(f)
    v = _build_version_info(metadata['version'])
    print(v)


# Generated at 2022-06-21 13:04:25.517347
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of the class :class:`flutils.version.bump_version._VersionPart`."""
    from flutils.testutils import (
        Timer,
        assert_raises,
        assert_repr,
        assert_str,
        assert_type_str,
    )
    from flutils import version

    assert_type_str(version.bump_version._VersionPart)

    msg = r"^__init__\(\): incompatible constructor arguments\. " \
          r"The following argument types are supported: \(int, str, int, str, int, str\)$"
    assert_raises(
        TypeError,
        msg,
        version.bump_version._VersionPart,
    )


# Generated at 2022-06-21 13:04:37.288423
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test_ok_0 = _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert test_ok_0.pos == 0
    assert test_ok_0.txt == '1'
    assert test_ok_0.num == 1
    assert test_ok_0.pre_txt == ''
    assert test_ok_0.pre_num == -1
    assert test_ok_0.name == 'major'

    test_ok_1 = _VersionPart(
        pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
    )
    assert test_ok_1.pos == 1
    assert test_ok_1.txt == '2'
   

# Generated at 2022-06-21 13:04:47.603873
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = ('pos', 'txt', 'num', 'pre_txt', 'pre_num', 'name')
    func_args = ('ver_obj',)
    msg = 'Function {0}() did not create a valid instance of class {1}'
    _VersionPart.__new__.__defaults__ = (None,) * len(args)
    inst = _VersionPart(*(None,) * len(args))
    assert isinstance(inst, _VersionPart) is True, msg.format(
        '__new__', '_VersionPart'
    )
    _VersionPart.__new__.__defaults__ = None
    inst = _VersionPart(*args)
    assert isinstance(inst, _VersionPart) is True, msg.format(
        '__new__', '_VersionPart'
    )
    inst = _VersionPart

# Generated at 2022-06-21 13:05:02.036271
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:05:12.288589
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase
    from unittest.mock import patch

    class Test(_VersionPart):  # type: ignore
        def __init__(  # pylint: disable=W0231
                self,
                ver_obj: StrictVersion,
                expect: Dict[str, Any],
                pos: int
        ):
            self.ver = ver_obj
            self.pos = pos
            self.p = expect

        def _test(self):
            part = next(_each_version_part(self.ver))
            self.assertEqual(part.pos, self.pos)
            self.assertEqual(part.txt, self.p['txt'])
            self.assertEqual(part.num, self.p['num'])

# Generated at 2022-06-21 13:05:24.580487
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):

        """
        Unit test for function bump_version.
        """

        def test_bump_version_defaults(self):
            self.assertEqual(bump_version('1.0.0'), '1.0.1')
            self.assertEqual(bump_version('1.0.1'), '1.0.2')
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3'), '1.2.4')
            self.assertEqual(bump_version('1.2.3-alpha.1'), '1.2.3-alpha.2')