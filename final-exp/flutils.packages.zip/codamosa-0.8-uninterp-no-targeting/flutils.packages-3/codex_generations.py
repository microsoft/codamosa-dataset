

# Generated at 2022-06-21 12:55:53.197219
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_obj = _build_version_info('1.2')
    assert ver_obj.version == '1.2'
    assert ver_obj.major.pos == 0
    assert ver_obj.major.num == 1
    assert ver_obj.major.name == 'major'
    assert ver_obj.minor.pos == 1
    assert ver_obj.minor.num == 2
    assert ver_obj.minor.name == 'minor'
    assert ver_obj.patch.pos == 2
    assert ver_obj.patch.num == 0
    assert ver_obj.patch.name == 'patch'
    assert ver_obj.pre_pos == -1

    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.version == '1.2.3'

# Generated at 2022-06-21 12:56:06.744298
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    :rtype:
        :obj:`None`
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 12:56:17.078159
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-21 12:56:27.783296
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import GenericTester


# Generated at 2022-06-21 12:56:33.168344
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    known = (
        ('1.0.0', 1, 0, 0),
        ('1.2.3', 1, 2, 3),
        ('1.2.3a0', 1, 2, 3),
        ('1.2.3a1', 1, 2, 3),
        ('1.2.3a1', 1, 2, 3),
        ('1.2.3b0', 1, 2, 3),
        ('1.2.3b1', 1, 2, 3),
        ('0.2.3', 0, 2, 3),
        ('0.0.0', 0, 0, 0),
        ('1.2.3b0', 1, 2, 3),
    )
    for ver, maj, min, pat in known:
        ver_info = _build_version_info(ver)
       

# Generated at 2022-06-21 12:56:40.773888
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnresolvedReferences
    assert _VersionInfo('1.0.0', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '0', 0, '', -1, 'minor'),
                        _VersionPart(2, '0', 0, '', -1, 'patch'), -1) == \
            _build_version_info('1.0.0')

# Generated at 2022-06-21 12:56:48.216263
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3b0')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0
        assert part.num == 1
        assert part.txt == '1'
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name == 'major'
    for part in _each_version_part(ver_obj):
        assert part.pos == 1
        assert part.num == 2
        assert part.txt == '2'
        assert part.pre_txt == 'b'
        assert part.pre_num == 0
        assert part.name == 'minor'
    for part in _each_version_part(ver_obj):
        assert part.pos == 2
        assert part.num == 3
       

# Generated at 2022-06-21 12:57:00.273950
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    parts = [
        (0, '1', 1, '', -1, 'major'),
        (1, '2', 2, 'alpha', 0, 'minor'),
        (2, '2', 2, '', -1, 'patch'),
        (2, '2', 2, 'alpha', 0, 'patch'),
        (2, '', 0, 'alpha', 0, 'patch'),
        (1, '17.0b0', 17, 'beta', 0, 'minor'),
        (2, '17.0b0', 0, 'beta', 0, 'patch'),
    ]
    for pos, txt, num, pre_txt, pre_num, name in parts:
        part = _VersionPart(pos, txt, num, pre_txt, pre_num, name)
        assert part.pos == pos
       

# Generated at 2022-06-21 12:57:12.266468
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from os.path import dirname, abspath
    from pathlib import Path
    from sys import path
    from flutils.packages import get_package_version
    from flutils.testing import data_file_path

    version = get_package_version('flutils')
    ver_info = _build_version_info(version)

    assert ver_info.version == '0.9.11'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt

# Generated at 2022-06-21 12:57:24.152530
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
        ),
        minor=_VersionPart(
            pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
        ),
        patch=_VersionPart(
            pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
        ),
        pre_pos=-1,
    )

# Generated at 2022-06-21 12:57:51.467415
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test_ver = '1.2.3'
    version = StrictVersion(test_ver)
    out = None
    for part in _each_version_part(version):
        if part.name == 'major':
            out = part
            break

    assert part.name == 'major'
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1


# Generated at 2022-06-21 12:58:01.896070
# Unit test for function bump_version
def test_bump_version():
    expected_err_exc = ValueError
    expected_err_msg = 'The given value for'
    func = bump_version

    err_msg = "Only the 'minor' or 'patch' parts of the version number can " \
              "get a prerelease bump."
    err_data = (func, -1, None, expected_err_exc, err_msg)
    yield err_data

    err_msg = "The given value for 'pre_release', %r, can only be one of: " \
              "'a', 'alpha', 'b', 'beta', None."
    err_data = (func, 1, 'on', expected_err_exc, err_msg)
    yield err_data


# Generated at 2022-06-21 12:58:09.101969
# Unit test for function bump_version

# Generated at 2022-06-21 12:58:13.942578
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:58:19.555655
# Unit test for function bump_version
def test_bump_version():

    """
    Unit test for function bump_version
    """

    print(bump_version('1.2.2'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-21 12:58:26.156485
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of class _VersionPart."""
    kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'a',
        'pre_num': 0,
        'name': 'major'
    }
    version = _VersionPart(**kwargs)
    assert version.pos == 0
    assert version.txt == '1'
    assert version.num == 1
    assert version.pre_txt == 'a'
    assert version.pre_num == 0
    assert version.name == 'major'



# Generated at 2022-06-21 12:58:32.101547
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """
    import pytest
    from flutils.packages import get_version

    from .test_data import (
        VERSION_LIST,
    )

    vnum_list = VERSION_LIST[:]
    vnum_list.append('1.0.0')
    for vnum in vnum_list:
        assert bump_version(vnum) == get_version(vnum, 1)
        assert bump_version(vnum, 1) == get_version(vnum, 1, 1)
        assert bump_version(vnum, 0) == get_version(vnum, 0)
        assert bump_version(vnum, 0, 'a') == get_version(vnum, 0, 'a')

# Generated at 2022-06-21 12:58:43.663633
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1') == _VersionInfo(
        '1',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    )
    assert _build_version_info('10') == _VersionInfo(
        '10',
        _VersionPart(0, '10', 10, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    )
    assert _build_version_info('1.0') == _

# Generated at 2022-06-21 12:58:57.127848
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 12:58:59.746366
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    v = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major',
    )


# Generated at 2022-06-21 12:59:26.598954
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    import sys
    import time
    import unittest

    from flutils.packages import bump_version


# Generated at 2022-06-21 12:59:36.855163
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import pytest  # pylint: disable=E0401

    with pytest.raises(TypeError):
        _VersionPart()  # pylint: disable=W0631

    with pytest.raises(TypeError):
        _VersionPart(1, '1')  # pylint: disable=W0631

    with pytest.raises(TypeError):
        _VersionPart(1, '1', 2)  # pylint: disable=W0631

    with pytest.raises(TypeError):
        _VersionPart(1, '1', 2, 'a')  # pylint: disable=W0631

    with pytest.raises(TypeError):
        _VersionPart(1, '1', 2, 'a', 3)  # pylint: disable=W0631


# Generated at 2022-06-21 12:59:49.351417
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:59:50.568779
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(0, '4', 4, '', -1, 'major')


# Generated at 2022-06-21 12:59:55.852547
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor')
    assert vp.pos == 1
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'minor'


# Generated at 2022-06-21 13:00:04.690114
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function"""
    from flutils.packages import bump_version
    # Testing the main functionality
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', 3) == '1.2.2'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.3.4', 0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-21 13:00:09.243675
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3.4')
    for part in _each_version_part(ver_obj):
        print(part)

if __name__ == '__main__':
    test__VersionPart()

# Generated at 2022-06-21 13:00:18.215323
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major') == _VersionPart(
        **_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                       name='major')._asdict()
    )
    assert _VersionPart._make(
        [0, '1', 1, '', -1, 'major']
    ) == _VersionPart._make(
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                     name='major')
    )

# Generated at 2022-06-21 13:00:25.526814
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    if _build_version_info('1.2.3') != _VersionInfo(
            version='1.2.3', major=_VersionPart(
                pos=0, txt='1',
                num=1, pre_txt='', pre_num=-1, name='major'
            ),
            minor=_VersionPart(
                pos=1, txt='2',
                num=2, pre_txt='', pre_num=-1, name='minor'
            ),
            patch=_VersionPart(
                pos=2, txt='3',
                num=3, pre_txt='', pre_num=-1, name='patch'
            ),
            pre_pos=-1
    ):
        raise AssertionError(
            'Expected to not get an assertion error.'
        )

# Generated at 2022-06-21 13:00:38.142443
# Unit test for function bump_version

# Generated at 2022-06-21 13:01:05.532892
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-21 13:01:15.482110
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=I0011,W0122,C0103
    import sys
    import os
    import flutils.packages as pkg
    here = os.path.dirname(os.path.realpath(__file__))
    src = os.path.join(here, 'packages_test_data')
    with open(os.path.join(src, 'ver_bump_01.in')) as fh:
        data = list(map(str.strip, fh.readlines()))
    data = list(map(lambda x: x.split('|'), data))
    data = list(map(lambda x: [x[0].strip(), x[1].strip()], data))

# Generated at 2022-06-21 13:01:27.289222
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _VersionPart(1, '2', 2, '', -1, 'minor')
    assert _VersionPart(2, '3', 3, '', -1, 'patch')
    assert _VersionPart(1, '3a0', 3, 'a', 0, 'minor')
    assert _VersionPart(1, '3b0', 3, 'b', 0, 'minor')
    assert _VersionPart(2, '4a0', 4, 'a', 0, 'patch')
    assert _VersionPart(2, '4b0', 4, 'b', 0, 'patch')

# Generated at 2022-06-21 13:01:42.365587
# Unit test for function bump_version
def test_bump_version():
    import pytest

# Generated at 2022-06-21 13:01:54.738213
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_obj = _VersionInfo('1.2.3', '0', '1', '2', '3', 2)

    assert ver_obj.version == '1.2.3'
    assert ver_obj.major.pos == 0
    assert ver_obj.major.txt == '0'
    assert ver_obj.major.num == 0
    assert ver_obj.major.pre_txt == ''
    assert ver_obj.major.pre_num == -1
    assert ver_obj.major.name == 'major'

    assert ver_obj.minor.pos == 1
    assert ver_obj.minor.txt == '1'
    assert ver_obj.minor.num == 1
    assert ver_obj.minor.pre_txt == ''
    assert ver_obj.minor.pre_num == -1


# Generated at 2022-06-21 13:01:57.580254
# Unit test for function bump_version
def test_bump_version():
    for version in ('0.0.1', '1.2.3'):
        result = bump_version(version)
        assert result.startswith('1.')

# Generated at 2022-06-21 13:02:05.845652
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = '1.2.3'
    version, major, minor, patch, pre_pos = _build_version_info(ver)
    assert version == '1.2.3'
    assert major.num == 1
    assert major.pre_num == -1
    assert major.pre_txt == ''
    assert major.txt == '1'
    assert major.name == 'major'
    assert minor.num == 2
    assert minor.pre_num == -1
    assert minor.pre_txt == ''
    assert minor.txt == '2'
    assert minor.name == 'minor'
    assert patch.num == 3
    assert patch.pre_num == -1
    assert patch.pre_txt == ''
    assert patch.txt == '3'
    assert patch.name == 'patch'
    assert pre_pos

# Generated at 2022-06-21 13:02:17.590083
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of the _VersionInfo class.

    *New in version 0.3*

    """
    from six import add_metaclass

    from flutils.packages import _VersionInfo

    # noinspection PyClassHasNoInit
    @add_metaclass(type)
    class _VersionInfoTester(type):
        """Class for testing the _VersionInfo class."""

        def __new__(
                mcs,
                name,
                bases,
                attrs
        ):
            """Overridden `__new__` method for the class."""

# Generated at 2022-06-21 13:02:29.428510
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: no cover
    from _test._test_packages import _TestBase
    from flutils.packages import _build_version_info, _VersionInfo

# Generated at 2022-06-21 13:02:41.588525
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    # pylint: disable=W0105

    # noinspection PyUnresolvedReferences,PyCallByClass
    from sys import version_info

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-21 13:03:03.707219
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function "bump_version"."""
    from pytest import mark  # pylint: disable=E0401
    from pytest import approx  # pylint: disable=E0401


# Generated at 2022-06-21 13:03:10.814787
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0612
    class TestClass(object):
        def test_class_init(self):
            args = {
                'pos': 1,
                'txt': '1',
                'num': 1,
                'pre_txt': 'a',
                'pre_num': 2,
                'name': 'minor'
            }
            out = _VersionPart(**args)
            for arg in args:
                assert out.__getattribute__(arg) == args[arg]
    TestClass().test_class_init()



# Generated at 2022-06-21 13:03:22.320861
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    def _assert_equal(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        version = bump_version(version, position, pre_release)
        assert version == expected


# Generated at 2022-06-21 13:03:31.084934
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '3'
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '3a0'
    assert ver_info.pre_pos == 1

    ver_info = _build_version_info('1.2.3b0')
    assert ver_info.major.txt == '1'

# Generated at 2022-06-21 13:03:41.229497
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    major_pos = 0
    major_txt = '1'
    major_num = 1
    major_pre_txt = ''
    major_pre_num = -1
    major_name = 'major'
    minor_pos = 1
    minor_txt = '2'
    minor_num = 2
    minor_pre_txt = ''
    minor_pre_num = -1
    minor_name = 'minor'
    patch_pos = 2
    patch_txt = '3'
    patch_num = 3
    patch_pre_txt = ''
    patch_pre_num = -1
    patch_name = 'patch'
    pre_pos = -1
    version = _build_version_info(version)

# Generated at 2022-06-21 13:03:52.503477
# Unit test for function bump_version
def test_bump_version():
    versions = [
        '1.0.1',
        '1.1.0',
        '1.1.1',
        '1.1a0',
        '1.1a1',
        '1.1b0',
        '1.1b1',
        '1.2.0',
        '1.2.1',
        '1.2a0',
        '1.2a1',
        '1.2b0',
        '1.2b1'
    ]
    for version in versions:
        assert bump_version(version) == StrictVersion(version).\
            _spec_version_cmp(version, bump_version(version))


if __name__ == '__main__':
    # Test the function bump_version
    test_bump_version()

# Generated at 2022-06-21 13:03:54.617518
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # 1.0.0a0
    _each_version_part(StrictVersion('1.0.0a0'))


# Generated at 2022-06-21 13:03:57.156409
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(2, 3, 4, 5, 6, 7) == _VersionPart(2, 3, 4, 5, 6, 7)



# Generated at 2022-06-21 13:04:04.921192
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    import unittest

    class TestClass(unittest.TestCase):
        """Unit test for function bump_version."""

        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-21 13:04:15.432589
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:04:39.608577
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # Arrange
    args = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    class_name = 'flutils.packages._VersionPart'
    # Act
    i = _VersionPart(**args)
    # Assert
    assert isinstance(i, _VersionPart)
    assert isinstance(i, tuple)
    assert i.pos == args['pos']
    assert i.txt == args['txt']
    assert i.num == args['num']
    assert i.pre_txt == args['pre_txt']
    assert i.pre_num == args['pre_num']
    assert i.name == args['name']
    assert repr(i)

# Generated at 2022-06-21 13:04:43.851971
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=C0116,C0115
    from flutils.packages import _VersionInfo
    from pytest import raises
    from .utils import assert_raises, assert_raises_regex

    # A valid version number
    assert (_VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    ) is not None)

    # A version number with a pre-release part

# Generated at 2022-06-21 13:04:57.176978
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def _run(
            version: str,
            major: Tuple[int, str, int, str, int, str],
            minor: Tuple[int, str, int, str, int, str],
            patch: Tuple[int, str, int, str, int, str],
            pre_pos: int
    ) -> None:
        cmp_info = _VersionInfo(version, *major, *minor, *patch, pre_pos)
        res_info = _build_version_info(version)
        assert res_info == cmp_info

# Generated at 2022-06-21 13:04:59.464887
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(0, '2', 2, '', -1, 'major')



# Generated at 2022-06-21 13:05:10.648928
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.3'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-21 13:05:17.782280
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function `bump_version()`.
    """
    from flutils.packages import bump_version

    ver = bump_version('0.0.1')
    assert ver == '0.0.2'

    ver = bump_version('0.0.2', pre_release='a')
    assert ver == '0.0.2a0'

    ver = bump_version('0.0.2a0', pre_release='a')
    assert ver == '0.0.2a1'

    ver = bump_version('0.0.2a0', pre_release='b')
    assert ver == '0.0.2b0'

    ver = bump_version('0.0.2a1', pre_release='b')
    assert ver == '0.0.2b0'

   