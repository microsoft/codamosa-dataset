

# Generated at 2022-06-21 12:55:58.524178
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:09.546403
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version"""
    func_name: str = 'bump_version'

    def _do_test(
            given_args: Tuple[str, ...],
            expected: str,
    ) -> None:
        given_args = cast(Tuple[str], given_args)
        given_kwargs: Dict[str, Any] = {}
        if len(given_args) > 1:
            given_kwargs = given_args[1]
        given_args = given_args[0]
        if callable(given_args) is True:
            given_args = given_args()
        elif isinstance(given_args, (list, tuple)) and len(given_args) == 1:
            given_args = given_args[0]

# Generated at 2022-06-21 12:56:19.738164
# Unit test for function bump_version

# Generated at 2022-06-21 12:56:24.521556
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ['1.2.3',
            _VersionPart(0, '1', 1, '', -1, 'major'),
            _VersionPart(1, '2', 2, '', -1, 'minor'),
            _VersionPart(2, '3', 3, '', -1, 'patch'),
            -1]
    obj1 = _VersionInfo(*args)
    obj2 = _build_version_info('1.2.3')
    assert obj1.__eq__(obj2) is True

# Generated at 2022-06-21 12:56:35.465074
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:45.007465
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    # Tests when bump type is a major release
    a = bump_version('1.2.3')
    assert a == '1.2.4'
    a = bump_version('1.2.3', position=0)
    assert a == '2.0'
    a = bump_version('1.2.3', position=0, pre_release='a')
    assert a == '2.0a0'
    a = bump_version('1.2.3', position=1)
    assert a == '1.3'
    a = bump_version('1.2.3', position=1, pre_release='a')
    assert a == '1.3a0'
    a = bump_version('1.2.3', position=2)

# Generated at 2022-06-21 12:56:49.554344
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart.

    """
    obj = _VersionPart(0, '1', 1, '', -1, 'major')
    assert isinstance(obj, _VersionPart)



# Generated at 2022-06-21 12:57:01.109324
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test flutils.packages._VersionInfo constructor.

    *New in version 0.3*

    """
    ver_info = _build_version_info('0.2.3')
    assert ver_info.version == '0.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
   

# Generated at 2022-06-21 12:57:12.881338
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('2.1.3a0')
    _build_version_info('2b3')
    _build_version_info('3')
    _build_version_info('2.5.0')
    _build_version_info('1.2.4a1')
    _build_version_info('1.2.4b0')
    _build_version_info('2.1.3')
    _build_version_info('2.1.3a1')
    _build_version_info('2.1.3b0')
    _build_version_info('1.2.3')
    _build_version_info('2.1.0')
    _build_version_info('1.2')
    _build_version_info('3.3.0')
    _

# Generated at 2022-06-21 12:57:24.583835
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: no cover
    ver_info = _build_version_info('3.0.0-rc1')
    assert ver_info.version == '3.0.0-rc1'
    assert ver_info.major.pos == 0, '%r' % ver_info.major.pos
    assert ver_info.major.num == 3
    assert ver_info.major.txt == str(3)
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.num == 0
    assert ver_info.minor.txt == '0-rc1'
    assert ver_info.minor.pre_txt

# Generated at 2022-06-21 12:57:52.015995
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo

    version = str

    major = _VersionPart(
        pos = int,
        txt = str,
        num = int,
        pre_txt = str,
        pre_num = int,
        name = str
    )

    minor = _VersionPart(
        pos = int,
        txt = str,
        num = int,
        pre_txt = str,
        pre_num = int,
        name = str
    )

    patch = _VersionPart(
        pos = int,
        txt = str,
        num = int,
        pre_txt = str,
        pre_num = int,
        name = str
    )

    pre_pos = int

    v = _VersionInfo(version, major, minor, patch, pre_pos)


# Generated at 2022-06-21 12:58:02.025896
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:58:11.653801
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, name='major',
                        pre_txt='', pre_num=-1)
    assert _VersionPart(pos=1, txt='2', num=2, name='minor',
                        pre_txt='', pre_num=-1)
    assert _VersionPart(pos=2, txt='3', num=3, name='patch',
                        pre_txt='', pre_num=-1)
    assert _VersionPart(pos=1, txt='2a0', num=2, name='minor',
                        pre_txt='a', pre_num=0)
    assert _VersionPart(pos=1, txt='2b0', num=2, name='minor',
                        pre_txt='b', pre_num=0)
    assert _VersionPart

# Generated at 2022-06-21 12:58:17.730075
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch')



# Generated at 2022-06-21 12:58:21.924635
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    expect = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    actual = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert expect == actual


# Generated at 2022-06-21 12:58:23.109336
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.0.1a0')


# Generated at 2022-06-21 12:58:28.865085
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    import pytest
    from flutils.packages import bump_version

    # Get test data
    from tests.testdata import testdata

    func_name = bump_version.__name__
    test_name = 'test_{0}'.format(func_name)

    # Iter over testdata for tests
    for data in testdata:
        test_id = data['id']
        msg = 'Function: {func}\nTest: {test}\nTest ID: {id}'
        msg = msg.format(
            func=func_name, test=test_name, id=test_id
        )
        # Handle except
        if 'exception' in data:
            with pytest.raises(Exception) as err_info:
                bump_version(**data['kwargs'])

# Generated at 2022-06-21 12:58:40.690595
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {
        'pos': 1,
        'txt': '2',
        'num': 2,
        'pre_txt': 'a',
        'pre_num': 3,
        'name': 'minor'
    }
    vers_part = _VersionPart(**kwargs)
    assert vers_part.pos == kwargs['pos']
    assert vers_part.txt == kwargs['txt']
    assert vers_part.num == kwargs['num']
    assert vers_part.pre_txt == kwargs['pre_txt']
    assert vers_part.pre_num == kwargs['pre_num']
    assert vers_part.name == kwargs['name']


# Generated at 2022-06-21 12:58:50.494312
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.version == '1.2.3'
    ver_obj = _build_version_info('1.3.0')
    assert ver_obj.version == '1.3'
    ver_obj = _build_version_info('1.2.3a0')
    assert ver_obj.version == '1.2.3a0'
    ver_obj = _build_version_info('1.3.0a0')
    assert ver_obj.version == '1.3a0'



# Generated at 2022-06-21 12:59:03.556906
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    out = _build_version_info('0.0.0')
    assert out.version == '0.0.0'
    assert out.major.pos == 0
    assert out.major.txt == '0'
    assert out.major.num == 0
    assert out.major.pre_txt == ''
    assert out.major.pre_num == -1
    assert out.major.name == 'major'

    assert out.minor.pos == 1
    assert out.minor.txt == '0'
    assert out.minor.num == 0
    assert out.minor.pre_txt == ''
    assert out.minor.pre_num == -1
    assert out.minor.name == 'minor'

    assert out.patch.pos == 2
    assert out.patch.txt == '0'
   

# Generated at 2022-06-21 12:59:30.503800
# Unit test for constructor of class _VersionPart
def test__VersionPart():

    from collections import namedtuple

    version_part = namedtuple(
        'version_part',
        [
            'pos',
            'txt',
            'num',
            'pre_txt',
            'pre_num',
            'name',
        ],
    )
    assert version_part(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    ) == _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )



# Generated at 2022-06-21 12:59:39.065783
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""

    def _check_bump_version(
            ver: str,
            pos: int,
            pre_rel: Optional[str],
            exp: str
    ):
        """Runs a test against the bump_version function."""
        got = bump_version(version=ver, position=pos, pre_release=pre_rel)
        assert got == exp, (
            "The bump_version function should have returned a '%s' from "
            "the version number: %r, at the position: %r, and the "
            "pre_release value: %r.  Instead, it returned: %r." %
            (exp, ver, pos, pre_rel, got)
        )


# Generated at 2022-06-21 12:59:51.072607
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Test version bumping functions."""
    from pprint import pprint
    from os.path import expanduser


# Generated at 2022-06-21 12:59:59.981611
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from random import choice
    from string import ascii_lowercase

    for i_ in range(100):
        pos = i_ % 3
        txt = ''.join(choice(ascii_lowercase)
                      for _ in range(i_ % 10))
        if pos < 2:
            num = i_
        else:
            num = i_ % 10
        pre_txt = ''.join(choice(ascii_lowercase)
                          for _ in range(i_ % 5))
        pre_num = i_ % 10

        test_ = _VersionPart(pos, txt, num, pre_txt, pre_num, '')

        assert test_.pos == pos
        assert test_.txt == txt
        assert test_.num == num
        assert test_.pre_txt == pre_txt

# Generated at 2022-06-21 13:00:11.733846
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    class Test:
        def __init__(self, version, major, minor, patch, pre_pos):
            self.version = version
            self.major = major
            self.minor = minor
            self.patch = patch
            self.pre_pos = pre_pos

        def __eq__(self, other):
            if (isinstance(other, Test) is False):
                return False
            return (
                self.version == other.version and
                self.major == other.major and
                self.minor == other.minor and
                self.patch == other.patch and
                self.pre_pos == other.pre_pos
            )

        def __repr__(self):
            return '%s(%s)' % (self.__class__.__name__, self.version)


# Generated at 2022-06-21 13:00:22.220950
# Unit test for function bump_version
def test_bump_version():
    "Unit test for ``bump_version``"

# Generated at 2022-06-21 13:00:34.873872
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection DuplicatedCode
    from flutils.packages import _VersionPart
    from datetime import datetime

    ver_time = int(datetime.now().timestamp())
    for i in range(-1, 7):
        for j in range(-1, 5):
            for k in range(-1, 3):
                for l in range(-1, 2):
                    for m in range(-1, 2):
                        txt = 'Unit Test {}'.format(ver_time)
                        part = _VersionPart(i, txt, j, k, l, m)
                        ver_time += 1
                        assert part.pos == i
                        assert part.txt == txt
                        assert part.num == j
                        assert part.pre_txt == k
                        assert part.pre_num == l
                        assert part.name == m


# Unit

# Generated at 2022-06-21 13:00:46.793401
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '23', 23, '', -1, 'minor') == _VersionPart(
        1, '23', 23, '', -1, 'minor'
    )
    assert _VersionPart(1, '23', 23, '', -1, 'minor') != _VersionPart(
        2, '23', 23, '', -1, 'minor'
    )
    assert _VersionPart(1, '23', 23, '', -1, 'minor') != _VersionPart(
        1, '21', 23, '', -1, 'minor'
    )
    assert _VersionPart(1, '23', 23, '', -1, 'minor') != _VersionPart(
        1, '23', 24, '', -1, 'minor'
    )
    assert _

# Generated at 2022-06-21 13:00:49.085129
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=W0613
    """Unit test for constructor of class _VersionPart.

    """
    _VersionPart(0, '1', 1, '', -1, 'major')

# Generated at 2022-06-21 13:00:54.296027
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1,
    )
    assert _build_version_info('1.2') == _VersionInfo(
        '1.2',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1,
    )


# Generated at 2022-06-21 13:01:06.244392
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(2, 3, 2, '', 0, 'patch')
    assert part.pos == 2
    assert part.txt == '3'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == 0
    assert part.name == 'patch'



# Generated at 2022-06-21 13:01:15.907625
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v_info = _build_version_info('1.2.3')
    assert v_info.version == '1.2.3'
    assert v_info.major.txt == '1'
    assert v_info.major.num == 1
    assert v_info.minor.txt == '2'
    assert v_info.minor.num == 2
    assert v_info.patch.txt == '3'
    assert v_info.patch.num == 3
    assert v_info.pre_pos == -1

    v_info = _build_version_info('1.2.3a0')
    assert v_info.version == '1.2.3a0'
    assert v_info.major.txt == '1'
    assert v_info.major.num == 1

# Generated at 2022-06-21 13:01:24.967390
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo."""
    try:
        _build_version_info('1.2.3')
        _build_version_info('1.2.3a0')
        _build_version_info('1.2.3b0')
        _build_version_info('1.2.3a1')
        _build_version_info('1.2.3b1')
    except Exception as exc:  # pylint: disable=W0703
        raise AssertionError(str(exc)) from exc



# Generated at 2022-06-21 13:01:32.147826
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '2', 2, '', -1, 'minor')
    patch = _VersionPart(2, '3', 3, '', -1, 'patch')

    version = '1.2.3a0'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '2', 2, 'a', 0, 'minor')
    patch = _VersionPart(2, '3a0', 3, '', -1, 'patch')

    version = '1.2a1.3b1'

# Generated at 2022-06-21 13:01:45.852742
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('0.0.0')
    assert ver_info.version == '0.0.0'
    assert vars(ver_info.major) == {
        'name': 'major',
        'num': 0,
        'pre_num': -1,
        'pre_txt': '',
        'pos': 0,
        'txt': '0'
    }
    assert vars(ver_info.minor) == {
        'name': 'minor',
        'num': 0,
        'pre_num': -1,
        'pre_txt': '',
        'pos': 1,
        'txt': '0'
    }

# Generated at 2022-06-21 13:01:58.564827
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import unittest

    class BumpVersionTests(unittest.TestCase):
        """Class for unit testing bump_version."""

        example = '1.2.3'

        def test_bump_version(self):
            """Test the bump_version function."""
            from flutils.packages import bump_version

            actual = bump_version('1.2.2')
            self.assertEqual(
                actual, '1.2.3',
                "'1.2.2' bumped by default to: '%s' "
                "but should have bumped to: '1.2.3'."
                "" % actual
            )

            actual = bump_version('1.2.2', position=1)

# Generated at 2022-06-21 13:02:02.685102
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    instance = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert instance.pos == 1
    assert instance.txt == '2'
    assert instance.num == 2
    assert instance.pre_txt == ''
    assert instance.pre_num == -1
    assert instance.name == 'minor'



# Generated at 2022-06-21 13:02:15.132627
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0212
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-21 13:02:27.806622
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3a3'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.name == 'major'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_num == -1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.minor.name == 'minor'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_num == 3
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pos == 1

# Generated at 2022-06-21 13:02:40.409126
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert _build

# Generated at 2022-06-21 13:03:03.553087
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:12.870145
# Unit test for function bump_version
def test_bump_version():
    def _test_bump_version(in_version: str, out_version: str,
                           position: int, prerelease: Optional[str]) -> None:
        try:
            result = bump_version(in_version, position, prerelease)
        except ValueError as exc_info:
            raise RuntimeError(
                "Tried to bump version, %r, with '%r' at position (%s). "
                "Got the exception: %r" % (
                    in_version, prerelease, position,
                    exc_info
                )
            ) from exc_info

# Generated at 2022-06-21 13:03:25.429175
# Unit test for function bump_version
def test_bump_version():
    """Test bumping a version number."""

# Generated at 2022-06-21 13:03:27.218549
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(pos=0, txt='0', num=0, pre_txt='a', pre_num=2, name='major')



# Generated at 2022-06-21 13:03:36.053053
# Unit test for function bump_version
def test_bump_version():
    import unittest
    res = bump_version('1.3.4', position=1)
    assert res == '1.4'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3a1', prerelease='a') == '1.2.3a2'
    assert bump_version('1.2.3a1', prerelease='b') == '1.2.3b0'
    assert bump_version('1.2.3a0', prerelease='a') == '1.2.3a1'

# Generated at 2022-06-21 13:03:47.815123
# Unit test for function bump_version
def test_bump_version():
    basic = (
        ('1.2.3', 2, None, '1.2.4'),
        ('1.2.3', 1, None, '1.3'),
        ('1.2.3', 0, None, '2.0'),
    )

# Generated at 2022-06-21 13:03:58.011423
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version
    """

# Generated at 2022-06-21 13:04:05.999077
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == _BUMP_VERSION_POSITION_NAMES[0]
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 13:04:16.359663
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version for all possible cases"""

    # Test bumping the major
    assert bump_version('1.2.3') == '1.2.3'
    assert bump_version('1.2.3', position=2) == '1.2.3'

    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('2.2.4', position=0) == '3.0'
    assert bump_version('2.0.0', position=0) == '3.0'

    # Test bumping the minor
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=1) == '1.3'

# Generated at 2022-06-21 13:04:27.271536
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.2a1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.2.3a1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.2.3.4')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)



# Generated at 2022-06-21 13:05:18.187161
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version.
    """

    # Simplest case that does not specify a bump type
    out = bump_version('1.2.3')
    assert out == '1.2.4'

    # Specify a bump type of 'minor'
    out = bump_version('1.2.3', position=1)
    assert out == '1.3'

    # Specify a bump type of 'major'
    out = bump_version('1.2.3', position=0)
    assert out == '2.0'

    # Specify a bump type of 'minor alpha'
    out = bump_version('1.2.3', position=1, pre_release='a')
    assert out == '1.3a0'

    # Specify a bump type of 'minor alpha'
    out

# Generated at 2022-06-21 13:05:27.805501
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    fake_version_info = _VersionInfo(
        version='0.0.1a1',
        major=_VersionPart(
            pos=0,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='0',
            num=0,
            pre_txt='a',
            pre_num=1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=1
    )