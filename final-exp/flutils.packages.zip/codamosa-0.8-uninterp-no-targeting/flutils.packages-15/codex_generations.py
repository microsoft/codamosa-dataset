

# Generated at 2022-06-21 12:55:54.304383
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'), \
            _VersionPart(1, '2', 2, '', -1, 'minor'), \
            _VersionPart(2, '3', 3, '', -1, 'patch'), -1) == \
            _build_version_info('1.2.3')
    assert _VersionInfo('1.2.3a0', _VersionPart(0, '1', 1, '', -1, 'major'), \
            _VersionPart(1, '2', 2, 'a', 0, 'minor'),
            _VersionPart(2, '3', 3, '', -1, 'patch'), 1) == \
            _build_version_info('1.2.3a0')
    assert _

# Generated at 2022-06-21 12:56:07.713855
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def helper(inval: str, expect: Tuple[int, ...]):
        ver_info = _build_version_info(inval)
        if expect[0] != ver_info.major.num:
            return 'major'

        if expect[1] != ver_info.minor.num:
            return 'minor'

        if (len(expect) > 2 and
                expect[2] != ver_info.patch.num):
            return 'patch'

        if (len(expect) > 3 and
                expect[3] != ver_info.pre_pos):
            return 'pre'

        return 'ok'

    assert helper('1.2.3', (1, 2, 3)) == 'ok'
    assert helper('1.2', (1, 2, 0, -1)) == 'ok'


# Generated at 2022-06-21 12:56:18.549943
# Unit test for function bump_version
def test_bump_version():
    # "The major version of the version string was increased by one"
    assert bump_version('1.2.3') == '1.2.3'
    # "The minor version of the version string was increased by one"
    assert bump_version('1.2.3', position=1) == '1.3'
    # "The patch version of the version string was increased by one"
    assert bump_version('1.4.4', position=2) == '1.4.5'
    # "The major version of the version string was increased by one"
    assert bump_version('1.4.4', position=0) == '2.0'
    # "The minor version of the version string was increased by one with an
    # alpha release"

# Generated at 2022-06-21 12:56:25.674718
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0613,W0612
    _VersionInfo('1.2.3a0', _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'), _VersionPart(pos=1, txt='2', num=2, pre_txt='a', pre_num=0, name='minor'), _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'), 1)


# Generated at 2022-06-21 12:56:30.017033
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '', 0, '', 0, 'x')
    assert part.pos == 0
    assert part.txt == ''
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == 0
    assert part.name == 'x'



# Generated at 2022-06-21 12:56:41.848304
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the contructor of class _VersionPart.

    Test the contructor of class _VersionPart by creating
    a _VersionPart object and making sure the attributes are correct.

    """
    test_object = _VersionPart(
        pos = 0,
        txt = '1',
        num = 1,
        pre_txt = '',
        pre_num = -1,
        name = 'major',
    )
    assert test_object.pos == 0
    assert test_object.txt == '1'
    assert test_object.num == 1
    assert test_object.pre_txt == ''
    assert test_object.pre_num == -1
    assert test_object.name == 'major'



# Generated at 2022-06-21 12:56:47.011504
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart._fields == (
        'pos',
        'txt',
        'num',
        'pre_txt',
        'pre_num',
        'name',
    )



# Generated at 2022-06-21 12:56:55.902139
# Unit test for constructor of class _VersionInfo
def test__VersionInfo(): # pylint: disable=W0613
    """Unit test for constructor of class _VersionInfo."""
    ver_info = _build_version_info('1.2.3.4.5.6.7.8.9.10')
    assert ver_info.version == '1.2.3.4.5.6.7.8.9.10'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver

# Generated at 2022-06-21 12:57:02.781709
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    actual = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    expected = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert actual == expected
    assert actual.txt == expected.txt
    assert actual.num == expected.num
    assert actual.pre_txt == expected.pre_txt
    assert actual.pre_num == expected.pre_num
    assert actual.name == expected.name



# Generated at 2022-06-21 12:57:14.153360
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.3b0')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == 2

    ver_info = _build_version_info('1.2a0')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 0
    assert ver_

# Generated at 2022-06-21 12:57:35.582153
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

# Generated at 2022-06-21 12:57:46.515693
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:57:54.382154
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit Test:  constructor of class _VersionInfo"""

    _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                          _VersionPart(1, '2', 2, '', -1, 'minor'),
                          _VersionPart(2, '3', 3, '', -1, 'patch'),
                          -1)

    _VersionInfo('1.3.0', _VersionPart(0, '1', 1, '', -1, 'major'),
                          _VersionPart(1, '3', 3, '', -1, 'minor'),
                          _VersionPart(2, '', 0, '', -1, 'patch'),
                          -1)


# Generated at 2022-06-21 12:58:04.021233
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major') == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _VersionPart(pos=0, txt='2', num=2, pre_txt='', pre_num=-1, name='major') != _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')

# Generated at 2022-06-21 12:58:07.773880
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(pos=0, txt='', num=0, pre_txt='', pre_num=-1, name='')
    assert obj.pos == 0
    assert obj.txt == ''
    assert obj.num == 0
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == ''


# Unit tests for method each_version_part

# Generated at 2022-06-21 12:58:13.946679
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    non_numbers = ('', 'a', 'b', 'α', 'β')

    for num, non_number in enumerate(non_numbers):
        version = _VersionPart(
            pos=num, txt=non_number, num=0, pre_txt='', pre_num=0, name=''
        )
        assert version.pos == num
        assert version.txt == non_number
        assert version.num == 0
        assert version.pre_txt == ''
        assert version.pre_num == 0
        assert version.name == ''



# Generated at 2022-06-21 12:58:23.365365
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.0')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0 or part.pos == 1
        assert part.txt and isinstance(part.txt, str)
        assert isinstance(part.num, int)
        assert isinstance(part.pre_txt, str)
        if part.pre_txt != '':
            assert isinstance(part.pre_num, int)
        assert part.name.lower() in ('major', 'minor', 'patch')

    ver_obj = StrictVersion('1.2.0b7')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0 or part.pos == 1
        assert part.txt and isinstance(part.txt, str)

# Generated at 2022-06-21 12:58:29.821361
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function.

    """
    # noinspection PyUnusedLocal
    def _bump_version(
            version: str,
            position: int,
            prerelease: Optional[str] = None
    ) -> str:
        return bump_version(
            version=version,
            position=position,
            pre_release=prerelease
        )

    # Tests for ValueErrors
    with pytest.raises(ValueError):
        _bump_version(version='1.2a3', position=0)

    with pytest.raises(ValueError):
        _bump_version(version='1.2', position=3)

    with pytest.raises(ValueError):
        _bump_version(version='1.2', position=-4)


# Generated at 2022-06-21 12:58:34.916454
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 12:58:46.420395
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '7.3.3'
    assert (_build_version_info(version) ==
            _VersionInfo(version,
                         _VersionPart(pos=0, txt='7', num=7,
                                      pre_txt='', pre_num=-1, name='major'),
                         _VersionPart(pos=1, txt='3', num=3,
                                      pre_txt='', pre_num=-1, name='minor'),
                         _VersionPart(pos=2, txt='3', num=3,
                                      pre_txt='', pre_num=-1, name='patch'),
                         -1))
    version = '7.3.3a1'

# Generated at 2022-06-21 12:59:15.993916
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    class _Test:
        def __init__(self, pos, name, txt, num, pre_num, pre_txt):
            self.pos = pos
            self.name = name
            self.txt = txt
            self.num = num
            self.pre_txt = pre_txt
            self.pre_num = pre_num


# Generated at 2022-06-21 12:59:28.372310
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.0')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 0
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.0')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 0
    assert ver_info

# Generated at 2022-06-21 12:59:37.984840
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.0') == _VersionInfo('1.0',
                                                      _VersionPart(0, '1', 1, '', -1, 'major'),
                                                      _VersionPart(1, '0', 0, '', -1, 'minor'),
                                                      _VersionPart(2, '', 0, '', -1, 'patch'), -1)
    assert _build_version_info('1.0.0') == _VersionInfo('1.0.0',
                                                        _VersionPart(0, '1', 1, '', -1, 'major'),
                                                        _VersionPart(1, '0', 0, '', -1, 'minor'),
                                                        _VersionPart(2, '', 0, '', -1, 'patch'), -1)

    assert _build_

# Generated at 2022-06-21 12:59:50.111457
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=I0011,C0103
    assert _build_version_info('0.0.0').version == '0.0.0'
    assert _build_version_info('0.0.0').minor.num == 0
    assert _build_version_info('0.0.0').minor.name == 'minor'
    assert _build_version_info('0.0.0').minor.pre_num == -1
    assert _build_version_info('0.0.0').minor.pre_txt == ''
    assert _build_version_info('0.0.0').minor.txt == '0'
    assert _build_version_info('0.0.0').patch.num == 0

# Generated at 2022-06-21 12:59:58.965513
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from unittest import TestCase
    import unittest


# Generated at 2022-06-21 13:00:06.324342
# Unit test for function bump_version

# Generated at 2022-06-21 13:00:17.943119
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:00:25.292879
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from sys import version_info
    from os.path import basename, dirname, realpath
    from importlib import import_module

    flutils_name = 'flutils'
    flutils_dir = dirname(realpath(__file__))
    flutils_dir = dirname(flutils_dir)
    flutils_path = '%s.%s' % (flutils_dir, flutils_name)
    if version_info >= (3, 8):
        import_module(flutils_name, flutils_dir)
    else:
        importlib.import_module(flutils_name, flutils_dir)

    version_file_name = basename(realpath(__file__))
    version_file_name = version_file_name[:-3]

# Generated at 2022-06-21 13:00:37.992698
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:00:48.841894
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
        if part.pos == 0:
            assert part.txt == '1'
            assert part.num == 1
            assert part.pre_num == -1
            assert part.pre_txt == ''
        if part.pos == 1:
            assert part.txt == '2'
            assert part.num == 2
            assert part.pre_num == -1
            assert part.pre_txt == ''
        if part.pos == 2:
            assert part.txt == ''
            assert part.num == 0
            assert part.pre_num == -1
            assert part.pre_txt == ''

# Generated at 2022-06-21 13:01:29.951620
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'
    """
    # noinspection PyUnusedLocal

# Generated at 2022-06-21 13:01:44.573326
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    _VersionInfo('1.2.3-dev', _VersionPart(0, '1', 1, 'dev', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '3', 3, '', -1, 'patch'), -1)

# Generated at 2022-06-21 13:01:57.190471
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    # noinspection PyUnusedLocal
    exp = _VersionInfo(
        '1.2.3',
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        -1,
    )

# Generated at 2022-06-21 13:02:05.654280
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('2.0') == _VersionInfo('2.0', major=_VersionPart(pos=0, txt='2', num=2, pre_txt='', pre_num=-1, name='major'), minor=_VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'), patch=_VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'), pre_pos=-1)

# Generated at 2022-06-21 13:02:17.469112
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:02:22.478470
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit tests for constructor of class _VersionPart.

    Passes if assertion is not raised.

    """
    with pytest.raises(TypeError):
        _VersionPart()  # missing positional arguments



# Generated at 2022-06-21 13:02:31.228629
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # type: () -> None
    from flutils.misc import xstr
    from flutils.testing import BaseTestCase
    from tempfile import NamedTemporaryFile

    class TestVersionInfo(BaseTestCase):
        """Test the constructor for :class:`_VersionInfo`"""

        def test_raise_error(self):
            # type: () -> None
            """Test to see if raising ValueError when given version number
            is invalid"""
            self.assertRaises(ValueError, _build_version_info, 'a')

        def test_store_values(self):
            # type: () -> None
            """Test to see if storing values in :class:`_VersionInfo`
            property 'version'"""
            ver_info = _build_version_info('1.0.0')

# Generated at 2022-06-21 13:02:42.206887
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:02:51.496870
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '2.1a2'
    out = _build_version_info(version)
    assert out.version == '2.1a2'
    assert out.major.name == 'major'
    assert out.major.num == 2
    assert out.minor.name == 'minor'
    assert out.minor.num == 1
    assert out.patch.name == 'patch'
    assert out.patch.num == 0
    assert out.pre_pos == 1
    assert out.minor.pre_txt == 'a'
    assert out.minor.pre_num == 2

    version = '2.1'
    out = _build_version_info(version)
    assert out.version == '2.1'
    assert out.major.name == 'major'

# Generated at 2022-06-21 13:02:56.309136
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    No unit test

    Args:
        None

    Returns:
        str: The string 'Not Implemented'

    """
    ver_obj = _VersionInfo()
    assert ver_obj is not None
    return 'Not Implemented'


# Generated at 2022-06-21 13:03:52.502938
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo
    expected = (
        '1.2.3',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        -1
    )
    assert _VersionInfo(*expected) == _VersionInfo('1.2.3')

# Generated at 2022-06-21 13:03:58.335859
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from inspect import signature
    from unittest.mock import MagicMock, patch

    p: signature = signature(_VersionPart.__init__)
    p_expected = '<Signature (pos, txt, num, pre_txt, pre_num, name)>'
    assert str(p) == p_expected

    args: List[Any] = [0, '0', 0, '', -1, '']
    vp = _VersionPart(*args)
    args_exp = ['pos', 'txt', 'num', 'pre_txt', 'pre_num', 'name']
    assert vp._fields == args_exp
    args_exp = [0, '0', 0, '', -1, '']

# Generated at 2022-06-21 13:04:02.513122
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'),
                        -1) == _build_version_info('1.2.3')



# Generated at 2022-06-21 13:04:09.866564
# Unit test for function bump_version

# Generated at 2022-06-21 13:04:14.034642
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from .testutils import (
        assert_test_case_has_test_as_test_case,
    )
    assert_test_case_has_test_as_test_case(
        bump_version.__name__,
        bump_version
    )

# Generated at 2022-06-21 13:04:25.467912
# Unit test for function bump_version

# Generated at 2022-06-21 13:04:37.235069
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version from flutils.packages module."""

    # Invalid version number
    args = '1.2'
    exp_exc_str = (
        "invalid version number '{}'".format(args)
    )
    with pytest.raises(ValueError):
        bump_version(args)

    # Invalid pre_release
    args = [('1.2.3', None, 'x'), ('1.2.3', -1, 'y')]
    exp_exc_str = (
        "The given value for 'pre_release', "
        "{}, can only be one of: 'a', 'alpha', 'b', 'beta', None."
    )

# Generated at 2022-06-21 13:04:42.572970
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion  # pylint: disable=E0611,E0401
    ver_obj = StrictVersion('10.4.0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    assert 0 == 0



# Generated at 2022-06-21 13:04:50.156194
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion

    ver_obj = StrictVersion('1.2.3')
    parts = list(_each_version_part(ver_obj))
    assert parts[0].num == 1
    assert parts[1].num == 2
    assert parts[2].num == 3

    ver_obj = StrictVersion('1.2.0')
    parts = list(_each_version_part(ver_obj))
    assert parts[0].num == 1
    assert parts[1].num == 2
    assert parts[2].num == 0
    assert parts[2].txt == ''

    ver_obj = StrictVersion('1.2a2')
    parts = list(_each_version_part(ver_obj))
    assert parts[0].num == 1
    assert parts[1].num == 2

# Generated at 2022-06-21 13:05:04.043786
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2') == _VersionInfo(
        version='1.2',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'),
        patch=_VersionPart(
            pos=2,
            txt='',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch'),
        pre_pos=-1
    )

    assert _build_version_info('1.2a5') == _Version