

# Generated at 2022-06-21 12:55:59.608548
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    assert _build_version_info('0.0.0') == _VersionInfo(
        '0.0.0',
        _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'),
        -1,
    )

# Generated at 2022-06-21 12:56:08.765350
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    _VERSION_INPUT = '1.2.3'
    _VERSION_OUTPUT = '1.2.4'
    _VERSION_INPUT_POSITION = '1.3'
    _VERSION_OUTPUT_POSITION = '1.4'
    _VERSION_INPUT_POSITION_2 = '2.0'
    _VERSION_OUTPUT_POSITION_2 = '3.0'
    _VERSION_INPUT_PRERELEASE = '1.2.4a0'
    _VERSION_OUTPUT_PRERELEASE = '1.2.4a1'
    _VERSION_INPUT_PRERELEASE_2 = '1.2.4a1'

# Generated at 2022-06-21 12:56:19.309773
# Unit test for function bump_version
def test_bump_version():
    "pytest for function bump_version."

    version = '1.2.3'
    exp = '1.3'
    got = bump_version(version, position=1)
    assert got == exp

    version = '1.2.3'
    exp = '1.2.4'
    got = bump_version(version, position=2, pre_release='a')
    assert got == exp

    version = '1.2.3'
    exp = '1.4'
    got = bump_version(version, position=1, pre_release='b')
    assert got == exp

    version = '4.5.6'
    exp = '4.6'
    got = bump_version(version, position=1, pre_release='a')
    assert got == exp


# Generated at 2022-06-21 12:56:26.911804
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``."""
    import flutils.packages

    def _run(version: str, position: int, pre_release: Optional[str],
             expected: str) -> None:
        actual = flutils.packages.bump_version(version, position, pre_release)
        assert actual == expected

    _run('1.2.2', position=2, pre_release=None, expected='1.2.3')
    _run('1.2.3', position=1, expected='1.3')
    _run('1.3.4', position=0, expected='2.0')
    _run('1.2.3', pre_release='a', expected='1.2.4a0')

# Generated at 2022-06-21 12:56:34.540796
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pytest import raises
    with raises(TypeError):
        _ = _VersionPart()
    assert _VersionPart(0, '0', 0, '', -1, 'major').pos == 0
    assert _VersionPart(0, '0', 0, '', -1, 'major').txt == '0'
    assert _VersionPart(0, '0', 0, '', -1, 'major').num == 0
    assert _VersionPart(0, '0', 0, '', -1, 'major').pre_txt == ''
    assert _VersionPart(0, '0', 0, '', -1, 'major').pre_num == -1
    assert _VersionPart(0, '0', 0, '', -1, 'major').name == 'major'


# Generated at 2022-06-21 12:56:37.381478
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    cls = _VersionPart
    assert cls._fields == ('pos', 'txt', 'num', 'pre_txt', 'pre_num', 'name')



# Generated at 2022-06-21 12:56:46.300748
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function.

    """
    # pylint: disable=C0103,C0116

    from .fixtures.pkgs import dicts_versions

    for ver_dict in dicts_versions:
        ver_txt = ver_dict['version']
        for pos_idx, pos_txt in enumerate(ver_txt.split('.')):
            assert bump_version(ver_txt, position=pos_idx) == (
                ver_dict['bump']['pos'][pos_idx]
            )

    for ver_dict in dicts_versions:
        ver_txt = ver_dict['version']
        assert bump_version(ver_txt, pre_release='a') == (
            ver_dict['bump']['pre']['a']
        )
        assert bump_

# Generated at 2022-06-21 12:56:55.634833
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Unit test for function bump_version."""
    import collections
    import doctest
    from flutils.packages import bump_version
    from flutils.packages import _VERSION as __version__

    TestResults = collections.namedtuple('TestResults', 'failed attempted')

    results = TestResults(*doctest.testmod(
        bump_version, optionflags=doctest.NORMALIZE_WHITESPACE
    ))
    print(
        '%s v.%s' % (
            bump_version.__name__,
            __version__
        )
    )
    print('Failed: %s' % (results.failed))
    print('Attempted: %s' % (results.attempted))

if __name__ == '__main__':
    test_bump_

# Generated at 2022-06-21 12:57:00.349674
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:57:12.349608
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    print(
        '\nTesting constructor of class _VersionInfo...',
        end='',
        flush=True
    )
    _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'), \
                 _VersionPart(1, '2', 2, '', -1, 'minor'), \
                 _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    _VersionInfo('1.2.3a4', _VersionPart(0, '1', 1, '', -1, 'major'), \
                 _VersionPart(1, '2', 2, 'a', 4, 'minor'), \
                 _VersionPart(2, '3', 3, '', -1, 'patch'), -1)

# Generated at 2022-06-21 12:57:29.362985
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('0.1.2')
    _build_version_info('0.1.2a3')
    _build_version_info('0.1.2b3')
    _build_version_info('0.1.0')



# Generated at 2022-06-21 12:57:36.288298
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version()`` function."""

    def _bump_version(
            version: str,
            position: int = 2,
            pre_release: Union[str, None] = None
    ) -> str:
        """Shortcut for the ``bump_version()`` function."""
        return bump_version(version, position, pre_release)

    ext = [1, 2, 3]
    assert _bump_version('1.2.2') == '.'.join(map(str, ext))
    ext = [1, 3]
    assert _bump_version('1.2.3', position=1) == '.'.join(map(str, ext))
    ext = [2, 0]

# Generated at 2022-06-21 12:57:46.948697
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:57:54.683508
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version.
    """
    from io import StringIO
    import os
    from unittest.mock import patch
    from tests.utils.print import print_output

    src = '1.2.2'
    dst = bump_version(src)
    assert dst == '1.2.3'

    src = '1.2.3'
    dst = bump_version(src, position=1)
    assert dst == '1.3'

    src = '1.3.4'
    dst = bump_version(src, position=0)
    assert dst == '2.0'

    src = '1.2.3'
    dst = bump_version(src, pre_release='a')
    assert dst == '1.2.4a0'


# Generated at 2022-06-21 12:58:02.031310
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """
    Run the unit tests against the constructor of the class
    :class:`flutils.packages._VersionPart`.
    """
    class_ = _VersionPart
    obj = class_('pos', 'txt', 'num', 'pre_txt', 'pre_num', 'name')

    # Test the properties
    assert obj.pos == 'pos', 'The "pos" property is broken.'
    assert obj.txt == 'txt', 'The "txt" property is broken.'
    assert obj.num == 'num', 'The "num" property is broken.'
    assert obj.pre_txt == 'pre_txt', 'The "pre_txt" property is broken.'
    assert obj.pre_num == 'pre_num', 'The "pre_num" property is broken.'
    assert obj.name == 'name', 'The "name" property is broken.'

# Generated at 2022-06-21 12:58:09.180154
# Unit test for function bump_version
def test_bump_version():
    from flutils import change_log, packages
    from flutils.change_log import (
        ChangeLog
    )
    from flutils.logging import PostLogHandler
    from flutils.packages import (
        PackageInfo
    )
    from flutils.testing import capture_stdout_stderr
    from pprint import pformat
    from flutils.testing.utils import (
        get_test_data_file
    )

    test_labels: List[str] = [
        "bump_version_with_no_increase",
        "bump_version_with_increase",
        "bump_version_with_increase_and_prerelease",
        "bump_version_with_no_increase_and_prerelease",
    ]

# Generated at 2022-06-21 12:58:16.550809
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914,R0912,R0915

    def assert_bump(version, position, pre_release, expected):
        actual = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert actual == expected

    assert_bump(
        version='1.2.2',
        position=2,
        pre_release=None,
        expected='1.2.3'
    )
    assert_bump(
        version='1.2.3',
        position=1,
        pre_release=None,
        expected='1.3'
    )

# Generated at 2022-06-21 12:58:17.967859
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    if _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name=''):
        return
    raise Exception



# Generated at 2022-06-21 12:58:27.766631
# Unit test for function bump_version
def test_bump_version():
    from flutils.tests.helpers import func_tester
    from flutils.packages import bump_version

    def test_position(
            input_val: int,
            should_be: int,
            should_raise: Optional[bool] = None
    ) -> bool:
        """
        Test function _build_version_bump_position.

        Args:
            input_val:
            should_be:
            should_raise:

        Returns:

        """
        if should_raise is None:
            should_raise = False

        if should_raise is not True:
            val = _build_version_bump_position(input_val)
            err_msg = 'Position should be: "%s", but got: "%s"' % (
                should_be,
                val
            )
            return should_be == val

# Generated at 2022-06-21 12:58:41.090544
# Unit test for function bump_version

# Generated at 2022-06-21 12:59:00.335822
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ve = _build_version_info('1.2.3')
    assert ve.version == '1.2.3'
    assert ve.major.pos == 0
    assert ve.major.txt == '1'
    assert ve.major.num == 1
    assert ve.minor.pos == 1
    assert ve.minor.txt == '2'
    assert ve.minor.num == 2
    assert ve.patch.pos == 2
    assert ve.patch.txt == '3'
    assert ve.patch.num == 3

    ve = _build_version_info('1.2')
    assert ve.version == '1.2'
    assert ve.major.pos == 0
    assert ve.major.txt == '1'
    assert ve.major.num == 1
    assert ve.minor.pos == 1

# Generated at 2022-06-21 12:59:11.989815
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version: Tuple[int, int, int] = (0, 0, 0)
    prerelease: Tuple[str, int] = ('a', 0)
    prerelease_built = False
    for pos, num in enumerate(version):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kwargs: Dict[str, Any] = {
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': '',
            'pre_num': -1,
            'name': 'zero'
        }
        if (prerelease_built is False and
                pos > 0 and
                prerelease is not None):
            prerelease = cast(Tuple[str, int], prerelease)
            should_

# Generated at 2022-06-21 12:59:25.698948
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert hasattr(_VersionPart, '_fields'), \
        "Class '_VersionPart' does not have '_fields' attribute."
    assert hasattr(_VersionPart, '_field_defaults'), \
        "Class '_VersionPart' does not have '_field_defaults' attribute."
    expected_fields = (
        'pos',
        'txt',
        'num',
        'pre_txt',
        'pre_num',
        'name',
    )
    assert _VersionPart._fields == expected_fields, \
        (
            "Class '_VersionPart' has unexpected fields: "
            "'%s' (expected: '%s')." % (
                repr(_VersionPart._fields),
                repr(expected_fields),
            )
        )

# Generated at 2022-06-21 12:59:33.538366
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=invalid-name
    a = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert a.pos == 0
    assert a.txt == '1'
    assert a.num == 1
    assert a.pre_txt == ''
    assert a.pre_num == -1
    assert a.name == 'major'



# Generated at 2022-06-21 12:59:40.828109
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for :any:`bump_version`.

    """

    # noinspection PyUnresolvedReferences
    """
    .. code-block:: python

        from flutils.packages import bump_version
        from flutils.packages.tests.test_bump_version import test_bump_version

    """

    # Simple version bumps
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

# Generated at 2022-06-21 12:59:51.940995
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 12:59:56.663853
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3a0'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == 2


# Generated at 2022-06-21 12:59:59.313068
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major')


# Unit tests for function _build_version_info

# Generated at 2022-06-21 13:00:06.516542
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def build(ver: str) -> _VersionInfo:
        nonlocal ret
        ret = _VersionInfo(*[ver] + list(_each_version_part(
            StrictVersion(ver)
        )))
    # pylint: disable=W0612
    ver_info: _VersionInfo
    ret: _VersionInfo
    # 0.1.0
    build('0.1.0')
    assert ret.version == '0.1.0'
    assert ret.major.pos == 0
    assert ret.major.txt == '0'
    assert ret.major.num == 0
    assert ret.major.pre_txt == ''
    assert ret.major.pre_num == -1
    assert ret.major.name == 'major'
    assert ret.minor.pos == 1

# Generated at 2022-06-21 13:00:18.098828
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    res = _build_version_info('1.2.3-4')
    assert res.version == '1.2.3-4'
    assert res.major.pos == 0
    assert res.major.txt == '1'
    assert res.major.num == 1
    assert res.major.pre_txt == ''
    assert res.major.pre_num == -1
    assert res.major.name == 'major'
    assert res.minor.pos == 1
    assert res.minor.txt == '2'
    assert res.minor.num == 2
    assert res.minor.pre_txt == '-'
    assert res.minor.pre_num == 4
    assert res.minor.name == 'minor'
    assert res.patch.pos == 2

# Generated at 2022-06-21 13:00:46.593543
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    ver_obj = StrictVersion('1.2.3')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = next(_each_version_part(ver_obj))
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'
    part = next(_each_version_part(ver_obj))
    assert part.pos == 2


# Generated at 2022-06-21 13:00:52.691407
# Unit test for function bump_version
def test_bump_version():
    import os
    import sys
    import unittest
    from flutils.packages import bump_version
    from flutils.misc import get_script_path

    def _test_except(e):
        msg = '\n\nReceived the following exception:  %r' % e
        msg += '\nVersion:  %s\nPosition:  %s\nPre-Release:  %s' % (
            tests['version'], tests['position'], tests['pre_release']
        )
        if tests['expected_error'] is not None:
            msg += '\nExpected an exception containing:  %s' % (
                tests['expected_error']
            )
        else:
            msg += '\nDid not expect an exception.'
        raise AssertionError(msg)


# Generated at 2022-06-21 13:01:03.214467
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('0.0.1')
    part_list = []
    for part in _each_version_part(ver_obj):
        part_list.append(part)

    assert part_list[0].pos == 0
    assert part_list[0].txt == ''
    assert part_list[0].num == 0
    assert part_list[0].pre_txt == ''
    assert part_list[0].pre_num == -1
    assert part_list[0].name == 'major'

    assert part_list[1].pos == 1
    assert part_list[1].txt == '0'
    assert part_list[1].num == 0
    assert part_list[1].pre_txt == ''
    assert part_list[1].pre_num == -1
    assert part_

# Generated at 2022-06-21 13:01:13.702864
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: no cover
    """Tests to ensure the the private constructor :func:`_build_version_info`
    works as expected.

    *New in version 0.3*

    """
    assert _build_version_info('2.0.0').version == '2.0.0'
    assert _build_version_info('2.0.1a1').version == '2.0.1a1'
    assert _build_version_info('1.1.0').version == '1.1.0'
    assert _build_version_info('1.1.1a1').version == '1.1.1a1'
    assert _build_version_info('3.2.1a2').version == '3.2.1a2'

# Generated at 2022-06-21 13:01:25.650656
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    >>> test__VersionInfo()
    version : 0.0.1a0
    part A : 0
    part B : 0
    part C : 1
    pre_release : a
    pre_release_num : 0
    """
    version = '0.0.1a0'

# Generated at 2022-06-21 13:01:39.938933
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    tst = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert tst.num == 1
    assert tst.pos == 0
    assert tst.pre_num == -1
    assert tst.pre_txt == ''
    assert tst.txt == '1'
    assert tst.name == 'major'
    assert repr(tst) == '_VersionPart(pos=0, txt=\'1\', num=1, ' \
        'pre_txt=\'\', pre_num=-1, name=\'major\')'
    assert str(tst) == "Version part: pos=(0), txt=('1'), num=(1), " \
       

# Generated at 2022-06-21 13:01:49.645641
# Unit test for function bump_version
def test_bump_version():
    """Unit tests of bump_version."""


# Generated at 2022-06-21 13:02:01.031327
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0613
    assert _build_version_info('0.0.0') == _VersionInfo(
        '0.0.0',
        _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1,
                     name='major'),
        _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1,
                     name='minor'),
        _VersionPart(pos=2, txt='0', num=0, pre_txt='', pre_num=-1,
                     name='patch'),
        -1
    )

# Generated at 2022-06-21 13:02:13.501869
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    output: list = []

# Generated at 2022-06-21 13:02:21.688080
# Unit test for function bump_version
def test_bump_version():
    """ Test function bump_version.
    """
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'

    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'
    assert bump_version(ver, pre_release='b') == '1.2.4b0'
    assert bump_version(ver) == '1.2.4'

    ver = '1.2.4b0'
    assert bump_version(ver) == '1.2.4'

    ver = '2.1.3'

# Generated at 2022-06-21 13:02:34.263659
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    pass

# Generated at 2022-06-21 13:02:43.796928
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-21 13:02:52.429576
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.tests.helpers import random_bytes
    from flutils.tests.helpers import random_string
    for i in range(1000):
        version = random_string(
            char_set='numbers',
            length=random.randint(1, 12)
        )
        if random.randint(0, 100) > 50:
            version = '.%s' % version
        if random.randint(0, 100) > 50:
            version = '%sa' % version
            if random.randint(0, 100) > 50:
                version = '%s0' % version
        ver_info = _build_version_info(version)
        major, minor, patch = (
            ver_info.major, ver_info.minor, ver_info.patch
        )
        # Determine if we

# Generated at 2022-06-21 13:03:04.594668
# Unit test for function bump_version
def test_bump_version():
    """ Unit tests for function :any:`bump_version`.
    """
    print('Testing: bump_version')

# Generated at 2022-06-21 13:03:13.480174
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3a1'
    ver_obj = StrictVersion(version)
    for part in _each_version_part(ver_obj):
        assert part.pos in (-1, 0, 1, 2)
        assert part.num in (-1, 0, 1, 2, 3)
        assert part.pre_num in (-1, 0, 1)
        assert part.txt in ('', '1', '2', '3', 'a1')
        assert part.pre_txt in ('', 'a')
        assert part.name in ('major', 'minor', 'patch')
    part_tuple = _VersionPart(1, '1', 1, 'a', 1, 'minor')
    assert part_tuple.pos == 1
    assert part_tuple.txt == '1'
    assert part_

# Generated at 2022-06-21 13:03:22.010524
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v = '0.2.3a0'
    ver_obj = StrictVersion(v)
    pre_pos = -1
    args: List[Any] = [v]
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            pre_pos = part.pos
        args.append(part)
    args.append(pre_pos)
    print(_VersionInfo(*args))

# Generated at 2022-06-21 13:03:25.796825
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert part == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')

# Generated at 2022-06-21 13:03:29.205737
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    exp = _VersionPart(
        pos=1,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='minor',
    )
    act = _VersionPart(1, '0', 0, '', -1, 'minor')
    assert act == exp


# Generated at 2022-06-21 13:03:36.042973
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 13:03:47.823971
# Unit test for function bump_version
def test_bump_version():
    """Test function: bump_version"""

# Generated at 2022-06-21 13:04:17.893018
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from random import randint
    from unittest import TestCase
    from unittest.mock import Mock

    class MockVerObj:
        version = (randint(1, 10), randint(1, 10), randint(1, 10))
        prerelease = (
            ('a', randint(1, 10))
            if randint(0, 1) == 0 else
            None
        )


# Generated at 2022-06-21 13:04:24.734045
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart

    vp = _VersionPart(pos=0, txt='1', num=1, pre_txt='b', pre_num=2, name='one')

    assert vp.pos == 0
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == 'b'
    assert vp.pre_num == 2
    assert vp.name == 'one'



# Generated at 2022-06-21 13:04:25.763499
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    StrictVersion('1.2.3')

# Generated at 2022-06-21 13:04:37.531718
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyUnresolvedReferences
    """

    :return:
    """
    from pprint import pformat
    from flutils.dotdict import DotDict
    # noinspection PyPep8Naming,PyUnresolvedReferences
    VersionPart = _VersionPart
    ver_obj = StrictVersion('2.0.0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, VersionPart)
        assert isinstance(part.pos, int)
        assert isinstance(part.txt, str)
        assert isinstance(part.num, int)
        assert isinstance(part.pre_txt, str)
        assert isinstance(part.pre_num, int)
        assert isinstance(part.name, str)

# Generated at 2022-06-21 13:04:47.733042
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages._packages import _VersionPart
    assert _VersionPart is not None
    # assert _VersionPart.__init__([1, 2, 3, 4, 5, 'name'])
    assert _VersionPart(1, 2, 3, 4, 5, 'name').pos == 1
    assert _VersionPart(1, 2, 3, 4, 5, 'name').txt == '2'
    assert _VersionPart(1, 2, 3, 4, 5, 'name').num == 3
    assert _VersionPart(1, 2, 3, 4, 5, 'name').pre_txt == '4'
    assert _VersionPart(1, 2, 3, 4, 5, 'name').pre_num == 5
    assert _VersionPart(1, 2, 3, 4, 5, 'name').name == 'name'

# Unit

# Generated at 2022-06-21 13:05:02.155511
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.name == 'patch'
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2')

# Generated at 2022-06-21 13:05:12.415358
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:05:24.579739
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.4')
    assert ver_info.version == '1.2.4'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == '4'