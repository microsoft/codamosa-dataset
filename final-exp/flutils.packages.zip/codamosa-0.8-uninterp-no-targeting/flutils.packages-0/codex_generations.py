

# Generated at 2022-06-21 12:55:59.938514
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v = _VersionInfo('1.3.0a0', _VersionPart(0, '1', 1, '', -1, 'major'),
                     _VersionPart(1, '3', 3, '', -1, 'minor'),
                     _VersionPart(2, '', 0, '', -1, 'patch'),
                     -1)
    if v.version != '1.3.0a0':
        raise AssertionError()
    if v.major != _VersionPart(0, '1', 1, '', -1, 'major'):
        raise AssertionError()
    if v.minor != _VersionPart(1, '3', 3, '', -1, 'minor'):
        raise AssertionError()

# Generated at 2022-06-21 12:56:10.440789
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for function bump_version."""

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:13.454257
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1,
                        pre_txt='', pre_num=-1, name='major')



# Generated at 2022-06-21 12:56:14.375538
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    return _build_version_info



# Generated at 2022-06-21 12:56:21.401807
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    Test the constructor of class VersionInfo
    """
    test_obj = _build_version_info(
        '1.2.3a0'
    )
    assert test_obj.major.txt == '1'
    assert test_obj.minor.pre_txt == 'a'
    assert test_obj.pre_pos == 1
    test_obj = _build_version_info(
        '1.2.3b0'
    )
    assert test_obj.major.txt == '1'
    assert test_obj.minor.pre_txt == 'b'
    assert test_obj.pre_pos == 1

# Generated at 2022-06-21 12:56:29.021290
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:56:32.114716
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test valid input
    # noinspection SpellCheckingInspection
    _VersionInfo('1.2.3a0')
    # Test invalid input
    try:
        _VersionInfo('')
    except ValueError:
        pass
    else:
        raise ValueError()



# Generated at 2022-06-21 12:56:43.986477
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    def _check_bump(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            new_version: str = ''
    ) -> None:
        if not new_version:
            new_version = version
        assert new_version == bump_version(
            version,
            position=position,
            pre_release=pre_release
        )

    _check_bump(version='1.2.2', new_version='1.2.3')
    _check_bump(version='1.2.3', position=1, new_version='1.3')
    _check_bump(version='1.3.4', position=0, new_version='2.0')

# Generated at 2022-06-21 12:56:55.035575
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    from flutils.packages import bump_version
    # Raise an error if version string is an invalid version number
    try:
        bump_version('1.2.3.a')
    except ValueError:
        assert True
    else:
        assert False
    # Raise an error if the given position value does not exist
    try:
        bump_version('1.2.3', position=4)
    except ValueError:
        assert True
    else:
        assert False
    # Raise an error if the given position is a pre-release bump and
    # the major version bump
    try:
        bump_version('1.2.3', position=0, pre_release='a')
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 12:57:04.262856
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Objects used in this unit test
    ver_info = _VersionInfo('1.2.3', '1', '2', '3', -1)
    actual = repr(ver_info)
    expected = "_VersionInfo(version='1.2.3', major=_VersionPart(pos=0, " \
               "txt='1', num=1, pre_txt='', pre_num=-1, name='major'), " \
               "minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', " \
               "pre_num=-1, name='minor'), patch=_VersionPart(pos=2, txt='3', " \
               "num=3, pre_txt='', pre_num=-1, name='patch'), pre_pos=-1)"

    # Test for exception handling


# Generated at 2022-06-21 12:57:34.426134
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3b4'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3b4'
    assert ver_info.major.name == 'major'
    assert ver_info.patch.name == 'patch'
    assert ver_info.patch.num == 3
    assert ver_info.patch.pre_txt == 'b'
    assert ver_info.patch.pre_num == 4
    assert ver_info.pre_pos == 2
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.txt == '2'


# Unit tests for method _build_version_b

# Generated at 2022-06-21 12:57:45.381580
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.version == '1.2.3'
    assert ver_obj.major.pos == 0
    assert ver_obj.major.txt == '1'
    assert ver_obj.major.num == 1
    assert ver_obj.major.pre_txt == ''
    assert ver_obj.major.pre_num == -1
    assert ver_obj.major.name == 'major'
    assert ver_obj.minor.pos == 1
    assert ver_obj.minor.txt == '2'
    assert ver_obj.minor.num == 2
    assert ver_obj.minor.pre_txt == ''

# Generated at 2022-06-21 12:57:52.014407
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart

    *New in version 0.4*
    """
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-21 12:58:02.027383
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1
    )

# Generated at 2022-06-21 12:58:06.802835
# Unit test for function bump_version
def test_bump_version():
    """ Tests for function: bump_version()"""

    # Basic usage
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:58:15.036172
# Unit test for function bump_version
def test_bump_version():
    """Tests for `bump_version()`."""

# Generated at 2022-06-21 12:58:24.120587
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    # pylint: disable=C0325
    # pylint: disable=W0612
    import unittest

    class TestCase(unittest.TestCase):

        def test_build_version_info_basic(self) -> None:
            """Test function _build_version_info with a basic version str"""
            vers = '0.0.1'

# Generated at 2022-06-21 12:58:36.436383
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    fields = ('version', 'major', 'minor', 'patch', 'pre_pos')
    args = ('1.2.3.4', '1.2.3.4', '1.2.3.4', '1.2.3.4', '1.2.3.4')

    with pytest.raises(TypeError):
        _VersionInfo()

    res = _VersionInfo(*args)
    assert isinstance(res, _VersionInfo)
    assert tuple(res) == args
    res_fields = tuple(res._fields)
    assert res.version == args[0]
    assert res.major.num == 1
    assert res.minor.num == 2
    assert res.patch.num == 3
    assert res.pre_pos == 3


# Generated at 2022-06-21 12:58:47.024286
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 12:58:58.239049
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )
    assert _VersionPart(
        pos=2,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='patch'
    )



# Generated at 2022-06-21 12:59:32.041460
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), -1) == _build_version_info('1.2.3')

# Generated at 2022-06-21 12:59:39.955825
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.4', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 12:59:51.669852
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 12:59:55.182244
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart.
    """
    _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )

# Unit tests for function _each_version_part

# Generated at 2022-06-21 13:00:02.279329
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    """Test function bump_version."""
    from random import choice
    from flutils.packages import bump_version
    BUMP_POSITIONS: List[int] = [0, 1, 2, -1, -2, -3]
    BUMP_PRERELEASES: List[Union[str, None]] = ['a', 'alpha', 'b', 'beta', None]

# Generated at 2022-06-21 13:00:13.804748
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0912,R0914,W0613
    """Unit test for :func:flutils.packages.bump_version

    .. seealso::
        :func:flutils.packages.bump_version

    """
    from random import choice

    # noinspection PyUnreachableCode
    if True:  # pragma: no cover
        # start with a version string
        version = '2.0.1'

        # get the version info object
        ver_info = _build_version_info(version)

        # build position incrementer function
        def get_inc(position):
            """Return a function to increase the given position."""

            def _inc():
                """Return the incremented value."""
                return bump_version(version, position)

            return _inc

        #
        # test

# Generated at 2022-06-21 13:00:23.107138
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    import io

    output = io.StringIO()

    def _print(*args, **kwargs):
        """Wrapper for print() that adds a line-feed"""
        kwargs.update({'file': output})
        print(*args, **kwargs)
        output.write('\n')

    # Major
    _print(bump_version('0.0.1', position=0))
    _print(bump_version('1.0.1', position=0))
    _print(bump_version('1.2.1', position=0))
    # Minor
    _print(bump_version('0.0.1', position=1))

# Generated at 2022-06-21 13:00:35.691828
# Unit test for function bump_version
def test_bump_version():
    from flutils.tests.helpers import RunState
    from flutils.packages import bump_version

    empty_list = []
    results = {
        0: empty_list,
        1: empty_list,
    }

    def _ut_bump_version(
            ver: str,
            pos: int,
            pre: Optional[str],
            has_err: bool,
    ):
        state = RunState()
        state.pos = pos
        state.pre = pre
        state.has_err = has_err
        try:
            out = bump_version(ver, state.pos, state.pre)
        except Exception as err:
            if state.has_err:
                return True

# Generated at 2022-06-21 13:00:47.280435
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3.4')
    assert _build_version_info('1.2.3.4a')
    assert _build_version_info('1.2.3.4a5')
    assert _build_version_info('1.2.3.4b')
    assert _build_version_info('1.2.3.4b5')
    assert _build_version_info('1.2.3.4rc')
    assert _build_version_info('1.2.3.4rc5')
    assert _build_version_info('1.2.3.4.5')
    assert _build_version_info('1.2.3.4.5a')
    assert _build_version_info('1.2.3.4.5a6')
   

# Generated at 2022-06-21 13:00:55.075994
# Unit test for function bump_version
def test_bump_version():
    """Tests for function bump_version."""
    from flutils.packages import bump_version
    from random import choice
    from string import ascii_lowercase
    from unittest import TestCase

    class TestBumpVersion(TestCase):
        def test_bump_version(self):
            for i in range(100):
                bump = choice(ascii_lowercase)
                if bump in 'ab':
                    pre_release = bump
                else:
                    pre_release = None
                pos = choice(range(3))
                if pos == 0 and pre_release is not None:
                    continue

# Generated at 2022-06-21 13:01:48.301600
# Unit test for function bump_version

# Generated at 2022-06-21 13:01:59.998390
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version

# Generated at 2022-06-21 13:02:12.450292
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import call

    # Create a version tuple: MagicMock(), MagicMock(), MagicMock()
    m_ver_tup = MagicMock(), MagicMock(), MagicMock()
    # Create the pre-release tuple: MagicMock(), MagicMock()
    m_pre_tup = MagicMock(), MagicMock()

    # Create the version object
    m_ver = MagicMock()
    m_ver.version = m_ver_tup
    m_ver.prerelease = m_pre_tup

    # Patch the import for the StrictVersion
    with patch.object(__name__, 'StrictVersion') as m_ver_cls:
        m_ver_cls

# Generated at 2022-06-21 13:02:21.109528
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('5.5.5', _VersionPart(pos=0, txt='5', num=5, pre_txt='', pre_num=-1, name='major'), _VersionPart(pos=1, txt='5', num=5, pre_txt='', pre_num=-1, name='minor'), _VersionPart(pos=2, txt='5', num=5, pre_txt='', pre_num=-1, name='patch'), -1)
    assert info.version == '5.5.5'
    assert info.major.pos == 0
    assert info.major.txt == '5'
    assert info.major.num == 5
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'


# Generated at 2022-06-21 13:02:22.172933
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(*[0, '', 0, '', -1, 'major'])


# Generated at 2022-06-21 13:02:31.610282
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert _VersionPart(
        pos=1,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )
    assert _VersionPart(
        pos=2,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='patch'
    )

# Generated at 2022-06-21 13:02:42.461752
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:02:45.569841
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, '') == _VersionPart(0, '1', 1, '', -1, '')


# Generated at 2022-06-21 13:02:53.370377
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'

    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-21 13:03:05.220284
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0621
    from flutils.packages import bump_version as bump_version_orig
    from flutils.packages import bump_version
    from flutils.tests.dummies import Dummy

    version_increase = Dummy(
        version='1.2.2',
        position=2,
        pre_release=None,
        expected_val='1.2.3'
    )
    assert bump_version_orig(
        version_increase.version,
        position=version_increase.position,
        pre_release=version_increase.pre_release
    ) == version_increase.expected_val

# Generated at 2022-06-21 13:03:47.390083
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0613
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos

# Generated at 2022-06-21 13:03:57.644809
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """
    unit testing for function `bump_version` 
    
    Examples:
        >>> from flutils.packages import bump_version
    """

    target_str = "1.2.2"
    target_str1 = "1.2.3"
    target_str2 = "1.2.4"
    target_str3 = "3.0"
    target_str4 = "1.3"
    target_str5 = "2.1.3a0"
    target_str6 = "2.2a0"
    target_str7 = "1.2.4a0"
    target_str8 = "1.2.4a1"
    target_str9 = "1.2.4.b1"

# Generated at 2022-06-21 13:04:05.499080
# Unit test for function bump_version
def test_bump_version():
    """Test flutils.packages.bump_version

    Since it is used in the version number of the package and that cannot be
    changed while testing, these tests are only run at the command line.

    """
    import flutils

    print(flutils.packages.bump_version('1.2.3', position=1))
    print(flutils.packages.bump_version('1.2.3', position=0))
    print(flutils.packages.bump_version('1.2.3', prerelease='a'))
    print(flutils.packages.bump_version('1.2.4a0', pre_release='a'))
    print(flutils.packages.bump_version('1.2.4a1', pre_release='b'))

# Generated at 2022-06-21 13:04:15.962120
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('3.4.4') == _VersionInfo('3.4.4', _VersionPart(0, '3', 3, '', -1, 'major'), _VersionPart(1, '4', 4, '', -1, 'minor'), _VersionPart(2, '4', 4, '', -1, 'patch'), -1)
    assert _build_version_info('1.2.0') == _VersionInfo('1.2.0', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '', 0, '', -1, 'patch'), -1)

# Generated at 2022-06-21 13:04:27.276747
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:04:37.762071
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart

    args = {'pos': 0, 'txt': '1', 'num': 1, 'pre_txt': '', 'pre_num': -1, 'name': 'major'}
    ver_part = _VersionPart(**args)
    assert ver_part == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert ver_part.pos == 0
    assert ver_part.txt == '1'
    assert ver_part.num == 1
    assert ver_part.pre_txt == ''
    assert ver_part.pre_num == -1
    assert ver_part.name == 'major'



# Generated at 2022-06-21 13:04:47.856643
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    # noinspection PyUnresolvedReferences
    parts = list(_each_version_part(ver_obj))
    assert len(parts) == 1
    assert parts[0].pos == 2
    assert parts[0].txt == '3'
    assert parts[0].num == 3
    assert parts[0].pre_txt == ''
    assert parts[0].pre_num == -1
    ver_obj = StrictVersion('1.2.3a1')
    # noinspection PyUnresolvedReferences
    parts = list(_each_version_part(ver_obj))
    assert len(parts) == 2
    assert parts[0].pos == 2
    assert parts[0].txt == '3a1'
    assert parts[0].num == 3

# Generated at 2022-06-21 13:05:02.250110
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    with pytest.raises(TypeError):
        _VersionPart()
    with pytest.raises(TypeError):
        _VersionPart(1)
    with pytest.raises(TypeError):
        _VersionPart(1, 2)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3, 4)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3, 4, 5)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3, 4, 5, 6, 7)
    result = _VersionPart(1, 2, 3, 4, 5, 6)
    assert result[0] == 1


# Generated at 2022-06-21 13:05:08.553429
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '2.2'
    args = ['2', '2.0', '2.0.0']
    out = _build_version_info(version)
    assert isinstance(out, _VersionInfo)
    assert out.version == version
    assert out.major.num == 2
    assert out.minor.num == 2
    assert out.patch.num == 0
    assert out.pre_pos == 1


# Generated at 2022-06-21 13:05:16.545450
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    import pytest
    with pytest.raises(ValueError):
        _build_version_info('1.2.3.4.5')
    with pytest.raises(ValueError):
        _build_version_info('1.2.3')
    with pytest.raises(ValueError):
        _build_version_info('1')

    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major == _VersionPart(0, '1', 1, '', -1, 'major')
    assert ver_info.minor == _VersionPart(1, '2', 2, '', -1, 'minor')