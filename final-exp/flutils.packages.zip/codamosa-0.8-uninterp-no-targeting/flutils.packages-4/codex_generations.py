

# Generated at 2022-06-21 12:56:01.976914
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613
    from flutils.packages import bump_version
    # No pre-release bump
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    # Alpha bumps
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 12:56:10.315450
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    verObj = _build_version_info('1.2.3')
    assert verObj.version == '1.2.3'
    assert verObj.major.pos == 0
    assert verObj.major.txt == '1'
    assert verObj.major.num == 1
    assert verObj.major.name == 'major'
    assert verObj.major.pre_txt == ''
    assert verObj.major.pre_num == -1

    assert verObj.minor.pos == 1
    assert verObj.minor.txt == '2'
    assert verObj.minor.num == 2
    assert verObj.minor.name == 'minor'
    assert verObj.minor.pre_txt == ''
    assert verObj.minor.pre_num == -1


# Generated at 2022-06-21 12:56:20.126773
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=R0201, C0103
    from flutils.packages import _VersionPart  # pylint: disable=E0401

    with pytest.raises(TypeError):
        _VersionPart()

    tpl = _VersionPart(0, '0', 0, '', -1, 'major')
    assert tpl.pos == 0
    assert tpl.txt == '0'
    assert tpl.num == 0
    assert tpl.pre_txt == ''
    assert tpl.pre_num == -1
    assert tpl.name == 'major'

    tpl = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert tpl.pos == 1
    assert tpl.txt == '2'
    assert tpl.num == 2
    assert t

# Generated at 2022-06-21 12:56:30.016945
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 12:56:42.561573
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for class _VersionPart"""
    part = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    part = _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1,
                        name='minor')
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1

# Generated at 2022-06-21 12:56:54.614857
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert _VersionPart(
        pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
    )
    assert _VersionPart(
        pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
    )
    assert _VersionPart(
        pos=1, txt='2b0', num=2, pre_txt='b', pre_num=0, name='minor'
    )

# Generated at 2022-06-21 12:57:03.992046
# Unit test for function bump_version
def test_bump_version():
    """Test 'bump_version' function."""
    # pylint: disable=R0914,W0612
    import tempfile
    import shutil
    import os.path as osp
    import pytest
    from flutils.packages import bump_version
    from flutils.path_utils import Path

    with pytest.raises(ValueError) as excinfo:
        bump_version('A')
    assert str(excinfo.value) == (
        "invalid version number 'A'"
    )

    with pytest.raises(ValueError) as excinfo:
        bump_version('1.2.3', position=-2)

# Generated at 2022-06-21 12:57:14.936532
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-21 12:57:21.807699
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test_data: Dict[str, str] = {
        '1.2': "1.2",
        '1.2.3': "1.2.3",
        '1.2.3alpha1': "1.2.3a1",
    }
    for key in test_data:
        ver_info = _build_version_info(key)
        assert ver_info.version == test_data[key]


# Generated at 2022-06-21 12:57:31.456235
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.
    """

# Generated at 2022-06-21 12:58:08.004129
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    parts = list(_each_version_part(
        StrictVersion('1.3.4.dev1'))
    )
    assert parts[0].pos == 0
    assert parts[0].txt == '1'
    assert parts[0].pre_txt == ''
    assert parts[0].pre_num == -1
    assert parts[0].num == 1
    assert parts[0].name == 'major'

    assert parts[1].pos == 1
    assert parts[1].txt == '3'
    assert parts[1].pre_txt == ''
    assert parts[1].pre_num == -1
    assert parts[1].num == 3
    assert parts[1].name == 'minor'

    assert parts[2].pos == 2
    assert parts[2].txt == '4'
    assert parts[2].pre

# Generated at 2022-06-21 12:58:17.546956
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version`` in module ``flutils.packages``."""
    # pylint: disable=W0612,C0115
    import flutils.packages
    flutils.packages.bump_version('1.2.2')
    flutils.packages.bump_version('1.2.3', position=1)
    flutils.packages.bump_version('1.3.4', position=0)
    flutils.packages.bump_version('1.2.3', prerelease='a')
    flutils.packages.bump_version('1.2.4a0', pre_release='a')
    flutils.packages.bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-21 12:58:27.717083
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Tests for the constructor of class VersionInfo
    from pymaptools.functools import wrap_with_repr
    from flutils.packages import _VersionInfo
    from pymaptools.functools import curry_method
    from pymaptools.functools import curry_partial

    import sys
    import os
    import unittest

    class Test__VersionInfo(unittest.TestCase):
        # Disable to allow the tests that call "print" to work.
        @staticmethod  # type: ignore
        def no_print(s: str) -> str:
            return ''

        def setUp(self):
            # Disable to allow the tests that call "print" to work.
            sys.stdout.write = self.no_print  # type: ignore
            sys.stdout.flush = self.no_print

# Generated at 2022-06-21 12:58:39.021468
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pos = 0
    txt = '1'
    num = 1
    pre_txt = 'a'
    pre_num = 1
    name = 'major'
    args = [pos, txt, num, pre_txt, pre_num, name]
    kwargs = dict(zip('pos,txt,num,pre_txt,pre_num,name'.split(','), args))
    obj = _VersionPart(*args)
    for i in range(len(args)):
        assert getattr(obj, obj._fields[i]) == args[i]
        assert getattr(obj, obj._fields[i]) == kwargs[obj._fields[i]]


# Generated at 2022-06-21 12:58:47.857861
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version"""
    # pylint: disable=W0106,C0103
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1')

# Generated at 2022-06-21 12:59:00.957825
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from datetime import datetime
    from unittest import mock
    from unittest.mock import AsyncMock, mock_open, patch
    from pytest import raises
    args = {
        'pos': 0,
        'txt': 'txt',
        'num': 0,
        'pre_txt': 'pre_txt',
        'pre_num': 0,
        'name': 'name'
    }
    ver_obj = mock.Mock(spec=['version', 'prerelease'])
    ver_obj.version = (0, 0, 0)
    ver_obj.prerelease = None
    out_iter = _each_version_part(ver_obj)
    out = next(out_iter)
    assert out._asdict() == args

    args['pos'] = 1

# Generated at 2022-06-21 12:59:12.587126
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from nose.tools import assert_raises

    ver_info = _build_version_info('1.0')
    assert ver_info.version == '1.0'
    assert ver_info.major.pos == 0
    assert ver_info.major.num == 1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.num == 0
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.num == 0
    assert ver_info.patch.name == 'patch'
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.0a0')
    assert ver_info.version

# Generated at 2022-06-21 12:59:16.648450
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)



# Generated at 2022-06-21 12:59:28.898793
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0212
    # pylint: disable=W0612
    import pytest

    ver = '1.2.3'
    info = _build_version_info(ver)
    assert info.version == ver
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'

    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2
    assert info.minor.pre_txt == ''
    assert info.minor.pre_num == -1

# Generated at 2022-06-21 12:59:31.143158
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    global _build_version_info
    _build_version_info('1.0.0')

# Generated at 2022-06-21 12:59:56.862547
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:00:03.246679
# Unit test for function bump_version
def test_bump_version():
    """Test the flutils.packages.bump_version function."""

    # noinspection PyUnresolvedReferences
    import unittest

    class UnitTest(unittest.TestCase):
        """Test the flutils.packages.bump_version function."""

        # noinspection PyUnresolvedReferences
        def test_bump_version_01(self):
            """Test the flutils.packages.bump_version function.
            """

            # noinspection PyUnresolvedReferences
            from flutils.packages import bump_version

            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')

# Generated at 2022-06-21 13:00:14.476223
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:00:21.241928
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '2', 2, '', -1, 'minor')
    patch = _VersionPart(2, '3', 3, '', -1, 'patch')
    pre_pos = -1
    args = [version, major, minor, patch, pre_pos]
    assert _VersionInfo(*args) == _build_version_info(version)


# Generated at 2022-06-21 13:00:34.407637
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert _VersionPart(
        pos=1,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )
    assert _VersionPart(
        pos=1,
        txt='1a0',
        num=1,
        pre_txt='a',
        pre_num=0,
        name='minor'
    )

# Generated at 2022-06-21 13:00:46.543076
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    print(list(_each_version_part(ver_obj)))
    ver_obj = StrictVersion('1.2.3a1')
    print(list(_each_version_part(ver_obj)))
    ver_obj = StrictVersion('1.2.3b1')
    print(list(_each_version_part(ver_obj)))
    ver_obj = StrictVersion('1.2a1')
    print(list(_each_version_part(ver_obj)))
    ver_obj = StrictVersion('1.2b1')
    print(list(_each_version_part(ver_obj)))
    ver_obj = StrictVersion('1.0.0a0')
    print(list(_each_version_part(ver_obj)))
   

# Generated at 2022-06-21 13:00:52.666592
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-21 13:01:03.182172
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo(
        version='0.1.1',
        major=_VersionPart(
            pos=0,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert ver_info.version == '0.1.1'

# Generated at 2022-06-21 13:01:07.702501
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for txt in ('1.2.4', '1.1.1'):
        for pos in range(3):
            for pre_txt in ('', 'a', 'b'):
                for pre_num in range(3):
                    if pre_num is 0 and pre_txt == '':
                        continue
                    _VersionPart(
                        pos=pos,
                        txt=txt,
                        num=2,
                        pre_txt=pre_txt,
                        pre_num=pre_num,
                        name='test'
                    )



# Generated at 2022-06-21 13:01:17.109584
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.2.3')
    assert isinstance(info, _VersionInfo)
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2
    assert info.patch.pos == 2
    assert info.patch.txt == '3'
    assert info.patch.num == 3
    assert info.pre_pos == -1

    info = _build_version_info('1.2.0')
    assert isinstance(info, _VersionInfo)
    assert info.version == '1.2.0'
    assert info

# Generated at 2022-06-21 13:01:43.724684
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:01:53.376923
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        _VersionPart(**{'pos': -1, 'num': 1, 'txt': 'a'})
    except ValueError:
        pass
    _VersionPart(**{'pos': 0, 'num': 1, 'txt': 'a'})
    try:
        _VersionPart(**{'pos': 1, 'num': 1, 'txt': 'a'})
    except ValueError:
        pass
    try:
        _VersionPart(**{'pos': 2, 'num': 1, 'txt': 'a'})
    except ValueError:
        pass


# Generated at 2022-06-21 13:02:02.289588
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1,
    )
    assert info.version == '1.2.3'
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.major.pos == 0

    assert info.minor.txt == '2'
    assert info.minor.num == 2
    assert info

# Generated at 2022-06-21 13:02:14.844818
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.2.3')
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2
    assert info.minor.pre_txt == ''
    assert info.minor.pre_num == -1
    assert info.minor.name == 'minor'
    assert info.patch.pos == 2
    assert info.patch.txt == '3'
   

# Generated at 2022-06-21 13:02:27.425815
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of class _VersionPart.

    *New in version 0.3*

    """

# Generated at 2022-06-21 13:02:40.004891
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version_parts = tuple(
        _each_version_part(
            StrictVersion('1.2.3')
        )
    )
    assert version_parts == (
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
    )

# Generated at 2022-06-21 13:02:45.526838
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    func = _VersionPart(1, '2', 2, 'a', 1, 'minor')
    assert str(func) == "VersionPart(pos=1, txt='2', num=2, pre_txt='a', " \
                        "pre_num=1, name='minor')"


# Generated at 2022-06-21 13:02:53.338643
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.testing import UnitTester
    import os
    import sys

    BASEPATH = os.path.join(os.path.dirname(__file__), 'test_packages')
    tester = UnitTester(
        module_name=__name__,
        module_root_path=BASEPATH,
        ignore_classes=[],
        cache=True
    )

# Generated at 2022-06-21 13:03:05.217005
# Unit test for function bump_version
def test_bump_version():
    """
    Bump version unit tests
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:03:13.858619
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version

    positional_vectors = [
        ('1.2.2', 2, None),
        ('1.2.3', 1, None),
        ('1.3.4', 0, None),
    ]

    @pytest.mark.parametrize('version, position, pre_release',
                             positional_vectors)
    def test_bump_version_positional(version, position, pre_release):
        out = bump_version(version, position, pre_release)
        expected = StrictVersion(out)
        cur = StrictVersion(version)
        bump = _build_version_bump_position(position)


# Generated at 2022-06-21 13:03:58.070517
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=fixme

    # TODO: Add the following version number formats.
    # 1.3.4.5.6   # not supported
    # 1.3.4.5b    # not supported
    # 1.3.4a      # not supported
    # 1.3b        # not supported

    # pylint: disable=C0116,W0122,C0103,R0914

    from copy import copy

    from packaging.version import parse as parse_ver

    import pytest

    # Tuples of the following:
    #  * the version number to be bumped
    #  * the kwargs to be passed to bump_version
    #  * the expected output from bump_version
    #  * the expected version number object from bump_version
    #  * the expected version number object from bump

# Generated at 2022-06-21 13:04:06.072641
# Unit test for function bump_version
def test_bump_version():
    """Tests for function: bump_version - from module: flutils.packages."""
    def test_ex_01():
        """Test function: bump_version - ex. 01."""
        assert bump_version('1.2.2') == '1.2.3'

    def test_ex_02():
        """Test function: bump_version - ex. 02."""
        assert bump_version('1.2.3', position=1) == '1.3'

    def test_ex_03():
        """Test function: bump_version - ex. 03."""
        assert bump_version('1.3.4', position=0) == '2.0'

    def test_ex_04():
        """Test function: bump_version - ex. 04."""

# Generated at 2022-06-21 13:04:16.432115
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from six import StringIO
    try:
        _VersionPart()
    except TypeError:
        pass
    else:
        raise Exception('Did not get TypeError')

    args = [0, 'a', 1, 'b', 2, 'c']
    part = _VersionPart(*args)
    if args != part:
        raise Exception('Failed to get instance of _VersionPart')

    out = StringIO()
    part.dump(out)
    test = out.getvalue()
    if test != '_VersionPart(pos=0, txt=\'a\', num=1, pre_txt=\'b\', pre_num=2, name=\'c\')':
        raise Exception('Failed to get expected value from _VersionPart.dump()')


# Generated at 2022-06-21 13:04:27.881301
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import unittest
    try:
        from flutils.test import utils
    except ImportError:
        from flutils import utils
    from flutils.packages import BumpVersionTestCase

    class Test__VersionPart(BumpVersionTestCase):
        def test__init(self):
            self.assertRaises(ValueError, _VersionPart, 'a', 2, 3)
            self.assertRaises(ValueError, _VersionPart, 1, 'b', 3)
            self.assertRaises(ValueError, _VersionPart, 1, 2, 'c')

            self.assertEqual(
                _VersionPart(1, 2, 3).pos, 1
            )
            self.assertEqual(
                _VersionPart(1, 2, 3).txt, '2'
            )

# Generated at 2022-06-21 13:04:32.309455
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-21 13:04:39.280705
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {'pos': 1, 'txt': '3', 'num': 3, 'pre_txt': '', 'pre_num': -1, 'name': 'minor'}
    inst = _VersionPart(**kwargs)
    assert inst.pos == 1
    assert inst.txt == '3'
    assert inst.num == 3
    assert inst.pre_txt == ''
    assert inst.pre_num == -1
    assert inst.name == 'minor'


# Generated at 2022-06-21 13:04:48.676755
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0111
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-21 13:05:03.026586
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert(ver_info.major.pos == 0 and ver_info.major.num == 1 and ver_info.major.pre_txt == '')
    assert(ver_info.minor.pos == 1 and ver_info.minor.num == 2 and ver_info.minor.pre_txt == '')
    assert(ver_info.patch.pos == 2 and ver_info.patch.num == 3 and ver_info.patch.pre_txt == '')
    ver_info = _build_version_info('1.3a1')
    assert(ver_info.major.pos == 0 and ver_info.major.num == 1 and ver_info.major.pre_txt == '')

# Generated at 2022-06-21 13:05:12.895366
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from sys import version_info as py_version
    if py_version < (3, 7):
        def check_error(
                error: Exception,
                exc_type: type,
                exc_msg: str
        ):
            tmp = 'type: %s, msg: %s' % (exc_type, exc_msg)
            assert isinstance(error, exc_type), tmp
            assert str(error) == exc_msg, tmp

        def test_bump_version_error():
            """Test proper error handling in bump_version."""

# Generated at 2022-06-21 13:05:25.045175
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from pprint import pformat

    version = '1.2.3a0'

    got = _each_version_part(StrictVersion(version))
    out = list(got)
    assert len(out) == 3
    assert isinstance(out[0], _VersionPart) is True
    assert isinstance(out[1], _VersionPart) is True
    assert isinstance(out[2], _VersionPart) is True