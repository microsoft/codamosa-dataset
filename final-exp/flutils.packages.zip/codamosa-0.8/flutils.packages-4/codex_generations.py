

# Generated at 2022-06-11 22:25:59.012375
# Unit test for function bump_version
def test_bump_version():
    """Test function for function ``bump_version``."""

    # Test all possible values of 'position', 'pre_release' and
    # pre-release type
    versions = [
        '1.2.0',
        '1.2.1',
        '1.2.0a0',
        '1.2.0b0',
        '1.2.0a1',
        '1.2.0b1',
        '1.2.1a0',
        '1.2.1b0',
        '1.2.1a1',
        '1.2.1b1',
    ]

# Generated at 2022-06-11 22:26:09.380236
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:20.531373
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:28.889924
# Unit test for function bump_version
def test_bump_version():
    """Run the "bump_version" function unit test."""

# Generated at 2022-06-11 22:26:36.904414
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:48.001462
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    # pylint: disable=import-outside-toplevel
    from flutils.pkg import _testing
    # Test a standard version bump
    assert bump_version('1.2.2') == '1.2.3'
    # Test a minor version bump
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test a major version bump
    assert bump_version('1.3.4', position=0) == '2.0'
    # Test an non-existing position bump
    _testing.assert_err(
        ValueError,
        bump_version, '1.2.3', position=3
    )
    # Test an invalid pre_release value

# Generated at 2022-06-11 22:27:01.211105
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.3.4', position=-1) == '1.3.5'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:27:10.813044
# Unit test for function bump_version
def test_bump_version():
    """Function: flutils.packages.bump_version"""
    import sys
    import pytest
    import test.flutils_packages_tests

    # noinspection PyProtectedMember
    args = [
        sys.executable,
        test.flutils_packages_tests.__file__,
        '--collect-only',
        '--collect-in-virtualenv'
    ]
    output = pytest.main(args=args, exit=False)
    print()
    if output.ret != 0:
        pytest.main(args=[test.flutils_packages_tests.__file__])
        raise SystemExit(1)

# Generated at 2022-06-11 22:27:20.159331
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """

    from flutils.misc import capture_stdout

    def _compare_versions(orig: str, bumped: str) -> None:
        with capture_stdout() as io:
            bumped_actual = bump_version(orig)
        assert bumped_actual == bumped
        io.seek(0)
        io.truncate()

    _compare_versions('1.2.2', '1.2.3')
    _compare_versions('1.2.3', '1.2.4')
    _compare_versions('1.2.3', '1.3.0')
    _compare_versions('1.2.3', '2.0.0')

# Generated at 2022-06-11 22:27:31.777524
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    ver_info = _build_version_info('1.2.4')
    assert ver_info.version == '1.2.4'
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.minor.num == 2
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.num == 4
    assert ver_info.patch.txt == '4'

    ver_info = _build_version_info('1.0.0')
    assert ver_info.version == '1.0.0'
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.minor.num == 0

# Generated at 2022-06-11 22:28:00.008179
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # pylint: disable=C0325,C0301
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1')

# Generated at 2022-06-11 22:28:06.277138
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:13.539094
# Unit test for function bump_version
def test_bump_version():
    from .test import assert_test

    assert_test(
        '1.2.3',
        bump_version,
        '1.2.2'
    )
    assert_test(
        '1.2.4',
        bump_version,
        '1.2.2',
        position=2
    )
    assert_test(
        '1.3.0',
        bump_version,
        '1.2.3',
        position=1
    )
    assert_test(
        '2.0.0',
        bump_version,
        '1.2.3',
        position=0
    )
    assert_test(
        '1.2.4a0',
        bump_version,
        '1.2.3',
        pre_release='a'
    )


# Generated at 2022-06-11 22:28:20.559332
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:31.414065
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914
    ver: str
    version: str
    try:
        bump_version(1)
        assert False
    except ValueError:
        pass
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', prerelease='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
   

# Generated at 2022-06-11 22:28:44.202435
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function :func:`bump_version`."""
    from flutils.packages import bump_version

    # (version, position, pre_release, expected)

# Generated at 2022-06-11 22:28:57.195040
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    position = 2
    pre_release = None

    def _test_bump_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> Tuple[str, Optional[str]]:
        out = bump_version(version, position, pre_release)
        assert out == expected, (
            "bump_version(%r, %r, %r) should be: %r, not: %r"
            % (version, position, pre_release, expected, out)
        )
        return out

    out = _test_bump_version('1.2.2', position, pre_release, '1.2.3')

# Generated at 2022-06-11 22:29:06.315101
# Unit test for function bump_version
def test_bump_version():
    """Test the function:
        :func:`bump_version`
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:29:17.026804
# Unit test for function bump_version
def test_bump_version():
    assert bump_version("1.2.3") == "1.2.4"

    assert bump_version("1.2.3", position=1) == "1.3"

    assert bump_version("1.3.4", position=0) == "2.0"

    assert bump_version("1.2.3", pre_release="a") == "1.2.4a0"

    assert bump_version("1.2.4a0", pre_release="a") == "1.2.4a1"

    assert bump_version("1.2.4a1", pre_release="b") == "1.2.4b0"

    assert bump_version("1.2.4a1") == "1.2.4"


# Generated at 2022-06-11 22:29:27.564610
# Unit test for function bump_version

# Generated at 2022-06-11 22:29:43.012053
# Unit test for function bump_version
def test_bump_version():
    """Test for the function `bump_version`.

    """
    # noinspection PyPep8Naming
    Args = NamedTuple('Args', (
        ('version', str),
        ('position', int),
        ('expected', str),
        ('pre_release', Optional[str]),
    ))

# Generated at 2022-06-11 22:29:54.936203
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from flutils.misc import build_dot_dict
    from flutils.packages import get_package_version

    failures = []
    for n, v in get_package_version().items():
        d = build_dot_dict({'version': v})
        if n == 'bump_version':
            continue
        for p in (n.split('.'), ) + [('', )]:
            for b in ('', 'a', 'alpha', 'b', 'beta'):
                try:
                    d.bump_version(pre_release=b, position=-len(p))
                except ValueError as e:
                    failures.append((n, e))
        if failures:
            break

    if failures:
        raise AssertionError(failures)
    return



# Generated at 2022-06-11 22:30:06.219413
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    import unittest

    class _TestBumpVersion(unittest.TestCase):
        """Test case for function bump_version"""

        def test_bump(self):
            """Test to increase the version number from a version number
            string
            """
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-11 22:30:16.973985
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase
    from unittest import main

    from flutils.packages import bump_version


# Generated at 2022-06-11 22:30:25.742229
# Unit test for function bump_version

# Generated at 2022-06-11 22:30:35.214837
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import run_tests

    def temp_test_bump_version(version):
        return bump_version(version)


# Generated at 2022-06-11 22:30:42.963984
# Unit test for function bump_version
def test_bump_version():
    from version import version_info
    __version__ = '0.3.1'
    if version_info >= (3, 7, 0):
        assert bump_version('0.2.2') == '0.2.3'
        assert bump_version('0.2.3', position=1) == '0.3'
        assert bump_version('0.3.4', position=0) == '1.0'
        assert bump_version('0.2.3', prerelease='a') == '0.2.4a0'
        assert bump_version('0.2.4a0', pre_release='a') == '0.2.4a1'
        assert bump_version('0.2.4a1', pre_release='b') == '0.2.4b0'

# Generated at 2022-06-11 22:30:55.766274
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    from flutils.packages import bump_version

    # No changes
    assert bump_version('1.2.3') == '1.2.3'

    # Increase minor
    assert bump_version('1.2.2', position=1) == '1.3'

    # Increase major
    assert bump_version('1.2.3', position=0) == '2.0'

    # Add alpha to patch
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Increase alpha on patch
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Increase beta on patch

# Generated at 2022-06-11 22:31:05.906981
# Unit test for function bump_version
def test_bump_version():
    try:
        bump_version('1.2.3')
    except Exception:
        assert False
    try:
        bump_version('1.2.3', position=1)
    except Exception:
        assert False
    try:
        bump_version('1.3.4', position=0)
    except Exception:
        assert False
    try:
        bump_version('1.2.3', prerelease='a')
    except Exception:
        assert False
    try:
        bump_version('1.2.4a0', pre_release='a')
    except Exception:
        assert False
    try:
        bump_version('1.2.4a1', pre_release='b')
    except Exception:
        assert False

# Generated at 2022-06-11 22:31:18.599124
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=C0301,C0116

# Generated at 2022-06-11 22:31:34.926995
# Unit test for function bump_version
def test_bump_version():
    """
    Test the function ``bump_version``.
    """
    from os import linesep

    from flutils.packages import bump_version

    pkg = 'flutils.tests'
    current_version = bump_version.__version__

# Generated at 2022-06-11 22:31:47.877127
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:54.899435
# Unit test for function bump_version
def test_bump_version():
    import os

    from flutils.packages import bump_version as bump

    # Test: version number with an alpha pre-release version
    test_ver = bump('1.2.3a1', position=0)
    if test_ver != '2':
        raise ValueError(
            "The string returned when bumping (1.2.3a1) in the major "
            "position, %r, should be: '2'" % test_ver
        )

    test_ver = bump('1.2.3a1', position=1)
    if test_ver != '1.3':
        raise ValueError(
            "The string returned when bumping (1.2.3a1) in the minor "
            "position, %r, should be: '1.3'" % test_ver
        )

    test_ver = bump

# Generated at 2022-06-11 22:32:04.397498
# Unit test for function bump_version
def test_bump_version():
    if (True):
        assert bump_version('1.2.2') == '1.2.3'
        assert bump_version('1.2.3', position=1) == '1.3'
        assert bump_version('1.3.4', position=0) == '2.0'
        assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
        assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
        assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
        assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:15.973950
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:28.755322
# Unit test for function bump_version
def test_bump_version():
    """Function to unit test 'bump_version'"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='a') == '1.2.4a2'

# Generated at 2022-06-11 22:32:35.960966
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version

# Generated at 2022-06-11 22:32:47.430984
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function {0}.{1}.bump_version()."""
    msg_base = '({0}) Function {1}.{2}.bump_version()'
    expected = '1.7.5a0'
    actual = bump_version('1.7.4', 2, 'a')
    msg = msg_base.format('Failed', 'flutils', 'packages')
    assert actual == expected, msg
    expected = '1.7.5b0'
    actual = bump_version('1.7.4', 2, 'b')
    msg = msg_base.format('Failed', 'flutils', 'packages')
    assert actual == expected, msg
    expected = '1.7.5b1'
    actual = bump_version('1.7.5b0', 2, 'b')
    msg

# Generated at 2022-06-11 22:32:53.457545
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:03.132211
# Unit test for function bump_version
def test_bump_version():
    """ Test the function bump_version """
    import random
    import string

    random.seed(0)
    alpha_chars = string.ascii_letters[:26]

    def _fuzz_a_patch_version(
            version_list: List[int],
            build: int = 0
    ) -> str:
        if build:
            try:
                build_int = int(build)
            except ValueError:
                raise ValueError(
                    "The 'build' option can only be an 'int'.  Got: "
                    "%r" % build
                ) from None

            build = '.' + str(build_int)
        else:
            build = ''
        out = '{}.{}.{}{}'.format(*version_list)
        return out


# Generated at 2022-06-11 22:33:19.106800
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:31.169699
# Unit test for function bump_version
def test_bump_version():
    import pytest  # type: ignore

    # 0.2 bump major
    assert bump_version('0.2') == '1.0'
    # 0.2 bump minor
    assert bump_version('0.2', 1) == '0.3'
    # 0.2 bump patch
    assert bump_version('0.2', 2) == '0.2.1'
    # 0.2-alpha7 bump major
    assert bump_version('0.2-alpha7') == '1.0'
    # 0.2-alpha7 bump minor
    assert bump_version('0.2-alpha7', 1) == '0.3'
    # 0.2-alpha7 bump patch
    assert bump_version('0.2-alpha7', 2) == '0.2.1'
    # 0.2-alpha7 bump

# Generated at 2022-06-11 22:33:38.306979
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:50.225868
# Unit test for function bump_version
def test_bump_version():
    print('Starting unit test for function bump_version')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:58.105859
# Unit test for function bump_version
def test_bump_version():
    import pytest

    # Test with valid input and some edge cases.
    def tst(version: str, **kwargs: Any) -> None:
        actual = bump_version(version, **kwargs)
        expected = kwargs['expected']
        assert actual == expected

    # Test with valid input and some edge cases.
    tst('1.2.2', expected='1.2.3')
    tst('1.2.3', position=1, expected='1.3')
    tst('1.3.4', position=0, expected='2.0')
    tst('1.2.3', prerelease='a', expected='1.2.4a0')
    tst('1.2.4a0', pre_release='a', expected='1.2.4a1')

# Generated at 2022-06-11 22:34:11.131340
# Unit test for function bump_version
def test_bump_version():
    """Test ``bump_version``."""

    # pylint: disable=E0611,E0401
    from flutils.packages import _build_version_info
    from flutils.packages import bump_version

    # Testing:
    #       bump_version('1.2.2')
    #       bump_version('1.2.3', position=1)
    #       bump_version('1.3.4', position=0)
    #       bump_version('1.2.3', prerelease='a')
    #       bump_version('1.2.4a0', pre_release='a')
    #       bump_version('1.2.4a1', pre_release='b')
    #       bump_version('1.2.4a1')
    #       bump_version('1.2.4

# Generated at 2022-06-11 22:34:23.122422
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', prerelease='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')
    assert ver == '1.2.4b0'

# Generated at 2022-06-11 22:34:37.377540
# Unit test for function bump_version
def test_bump_version():
    """Tests for the function bump_version."""
    # pylint: disable=W0612,W0613

# Generated at 2022-06-11 22:34:48.342596
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import hypothesis
    import hypothesis.strategies as st

    class Test_bump_version(unittest.TestCase):
        # noinspection PyPep8Naming
        @hypothesis.given(
            ver=st.text(st.characters(min_codepoint=0x30,
                                      max_codepoint=0x39),
                         max_size=15),
            pos=st.integers(-3, 2),
            pre=st.text(alphabet=[c for c in ['a', 'alpha', 'b', 'beta']],
                        min_size=1, max_size=5),
        )
        def test_bump_version(self, ver: str, pos: int, pre: str):
            ver = ver.strip()

# Generated at 2022-06-11 22:35:00.029808
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function: bump_version"""


    print('--- start test ---')
    import pprint
    pp = pprint.PrettyPrinter(indent=4)

    def get_expected(position, pre_release, version, expected):
        text = str()
        if position == -2:
            text += "('"
        elif position == -1:
            text += '(None, '
        else:
            text += '(%s, ' % position
        if pre_release is None:
            text += 'None, '
        else:
            text += '%r, ' % pre_release
        text += '%r) => %r' % (version, expected)
        return text


# Generated at 2022-06-11 22:35:16.620167
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Class for testing bump_version function."""


# Generated at 2022-06-11 22:35:26.643161
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'