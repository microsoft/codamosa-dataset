

# Generated at 2022-06-11 22:25:52.849871
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613
    from flutils.packages import bump_version
    from pytest import raises

    def major_cases():
        # noinspection PyUnusedLocal
        def run(
                version: str,
                position: int,
                pre_release: Union[str, None],
                result: str
        ):
            assert bump_version(
                version, position, pre_release
            ) == result

        yield run, '1.2.5', 0, None, '2.0'
        yield run, '1.2.0', 0, None, '2.0'
        yield run, '2.2.5', 0, None, '3.0'
        yield run, '2.0.0', 0, None, '3.0'

# Generated at 2022-06-11 22:26:04.183956
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""

    # Test types
    test_vals = [
        (1, ValueError),
        ("1.2.3.4", ValueError),
        ("1.2.3", ValueError),
        ("1.2", ValueError),
        ("1", ValueError),
        (1.2, ValueError),
        ("1.2.3", 1.0, ValueError),
        ("1.2.3", 0, ValueError),
        ("1.2.3", -1, ValueError),
        ("1.2.3", -2, ValueError),
        ("1.2.3", -3, ValueError),
        ("1.2.3", -4, ValueError),
        ("1.2.3", 2, 1, ValueError),
    ]


# Generated at 2022-06-11 22:26:13.730962
# Unit test for function bump_version
def test_bump_version():
    """Does not return a value.

    *New in version 0.3*
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:26:22.456555
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0912,R0914,R0915,unused-argument,unused-variable
    major_bump_test_data: List[Tuple[str, str]] = [
        ('1.2.0', '2.0'),
        ('1.2.1', '2.0'),
        ('1.2.1a1', '2.0'),
        ('1.2.3b3', '2.0'),
    ]

# Generated at 2022-06-11 22:26:34.029571
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase

    class _Test(TestCase):
        def test_bump_version_1(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')

        def test_bump_version_2(self):
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')

        def test_bump_version_3(self):
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

        def test_bump_version_4(self):
            self.assertEqual(bump_version('1.2.3', pre_release='a'), '1.2.4a0')


# Generated at 2022-06-11 22:26:46.731970
# Unit test for function bump_version
def test_bump_version():
    import pytest
    try:
        bump_version('1.2.2')
        assert True
    except ValueError:
        pytest.fail(
            "bump_version('1.2.2') raised ValueError unexpectedly!"
        )
    try:
        bump_version('1.3.4', position=0)
        assert True
    except ValueError:
        pytest.fail(
            "bump_version('1.3.4', position=0) raised ValueError unexpectedly!"
        )
    try:
        bump_version('1.2.4a0', pre_release='a')
        assert True
    except ValueError:
        pytest.fail(
            "bump_version('1.2.4a0', pre_release='a') raised "
            "ValueError unexpectedly!"
        )
   

# Generated at 2022-06-11 22:27:00.299549
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    assert bump_version(ver, position=1) == '1.3'
    assert bump_version(ver, position=0) == '2.0'
    ver = '1.2.3'
    assert bump_version(ver, prerelease='a') == '1.2.4a0'
    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'
    assert bump_version(ver, pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:27:08.793805
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    print(bump_version('1.2.2'))
    print(bump_version('1.2.2', position=1))
    print(bump_version('1.2.2', position=0))
    print(bump_version('1.2.2', prerelease='a'))
    print(bump_version('1.2.2a0', pre_release='a'))
    print(bump_version('1.2.2a1', pre_release='b'))
    print(bump_version('1.2.2a1'))
    print(bump_version('1.2.2b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-11 22:27:18.918344
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # noinspection PyUnusedLocal

# Generated at 2022-06-11 22:27:30.840226
# Unit test for function bump_version
def test_bump_version():
    # (str, int, Optional[str], Optional[str]) -> str
    def _test_bump_version(
            ver: str,
            pos: int,
            pre_rel: Union[str, None],
            expected_output: Optional[str] = None
    ) -> None:
        if expected_output is None:
            actual = bump_version(ver, position=pos, pre_release=pre_rel)
            expected = ver
            point = ''
        else:
            actual = bump_version(ver, position=pos, pre_release=pre_rel)
            expected = expected_output
            point = '.'

# Generated at 2022-06-11 22:28:08.247163
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:17.967677
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    # Bump major
    assert bump_version('1.2.3') == '1.2.4'
    # Bump minor
    assert bump_version('1.2.3', position=1) == '1.3'
    # Bump major
    assert bump_version('1.3.4', position=0) == '2.0'
    # Bump patch with alpha
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Bump patch with alpha increase
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Bump patch with beta

# Generated at 2022-06-11 22:28:29.347684
# Unit test for function bump_version
def test_bump_version():
    """Unit test for ``bump_version``.

    *Added in version 0.3*

    Tests the ``bump_version`` function against a list of known values.
    """

# Generated at 2022-06-11 22:28:42.079337
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    ver = bump_version('1.2.3', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', position=-1)
    assert ver == '1.2.4'
    ver = bump_version('1.2.4', position=-2)
    assert ver == '1.3'
    ver = bump_version('1.2.4', position=-3)
    assert ver == '2.0'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_

# Generated at 2022-06-11 22:28:47.430142
# Unit test for function bump_version
def test_bump_version():
    import sys
    import logging
    from flutils.loghandler import ColoredLogHandler

    handler = ColoredLogHandler(sys.stderr, logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)


# Generated at 2022-06-11 22:28:59.020695
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    test_versions = [
        '1.2.2',
        '1.2.3',  # Major and minor have test pre release parts
        '1.2.3a0',
        '1.2.3a1',
        '1.2.3b0',
        '1.2.3b1',
        '1.3.0',
        '1.3.0a0',
        '1.3.0a1',
        '1.3.0b0',
        '1.3.0b1',
        '1.3.1',
        '1.3.1a0',
        '1.3.1a1',
        '1.3.1b0',
        '1.3.1b1',
    ]


# Generated at 2022-06-11 22:29:06.965384
# Unit test for function bump_version
def test_bump_version():
    import unittest

    from flutils.tests.decorators import skip_if_matches

    SKIPPED: List[str] = [
        # Your skipped test case strings would go here.
        # SKIPPED.append('skip this test')
    ]

    class TestBumpVersion(unittest.TestCase):
        @skip_if_matches(SKIPPED)
        def test_basic(self) -> None:
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

# Generated at 2022-06-11 22:29:17.339953
# Unit test for function bump_version
def test_bump_version():   # pylint: disable=R0912
    """Unit-test for function bump_version."""
    def test(
            ver_in: Optional[str],
            pos: Optional[int],
            pre_release: Optional[str],
            ver_out: Optional[str]
    ) -> None:
        """Unit-test for function bump_version."""
        if ver_in is not None:
            ver_in = cast(str, ver_in)
            if pos is None:
                res = bump_version(ver_in, pre_release=pre_release)
            else:
                pos = cast(int, pos)
                res = bump_version(ver_in, position=pos, pre_release=pre_release)
            assert res == ver_out

# Generated at 2022-06-11 22:29:27.721587
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    def _bump_version(
            version: str,
            position: int,
            pre_release: str,
            expected: str,
    ) -> None:
        actual = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert actual == expected

    _bump_version(
        version='1.2.2',
        position=2,
        pre_release=None,
        expected='1.2.3'
    )
    _bump_version(
        version='1.2.3',
        position=1,
        pre_release=None,
        expected='1.3'
    )

# Generated at 2022-06-11 22:29:38.920567
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    def _do_test(version: str, position: int = 2,
                 pre_release: Optional[str] = None) -> None:
        try:
            bump_version(version, position, pre_release)
        except Exception as exc:
            print("%s -> %s" % (
                version,
                exc
            ))
            raise

    _do_test('1.2.2')
    _do_test('1.2.3', position=1)
    _do_test('1.3.4', position=0)
    _do_test('1.2.3', prerelease='a')
    _do_test('1.2.4a0', pre_release='a')

# Generated at 2022-06-11 22:30:16.844071
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.pkgutils import version_info

    TEST_VERSION = '%s.%s.%s' % version_info.VERSION_INFO[:3]

    def _test(version, position, pre_release):
        """Local function for test_bump_version"""
        out = bump_version(version, position, pre_release)
        print("{:>15}  {:>15}  {}".format(
            version, out, "PASS" if out != version else "FAIL"))

    print("{:>15}  {:>15}  {}".format("current", "updated", "status"))
    print("-" * 45)
    _test(TEST_VERSION, 2, None)
    _test(TEST_VERSION, 0, None)

# Generated at 2022-06-11 22:30:19.482751
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages._tests.test_version import _test_bump_version
    return _test_bump_version(bump_version)

# Generated at 2022-06-11 22:30:32.146072
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1101
    # pylint: disable=C0111
    # pylint: disable=C0103
    # pylint: disable=C0413
    # pylint: disable=C0411
    import unittest
    import random

    class _TestBumpVersion(unittest.TestCase):
        # pylint: disable=R0201
        def setUp(self):
            self.major_version_max = random.randint(3, 9)
            self.minor_version_max = random.randint(1, 9)
            self.patch_version_max = random.randint(1, 9)

            self.version_dict = {}

# Generated at 2022-06-11 22:30:41.833967
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-11 22:30:54.011041
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = bump_version('1.2.2')
    assert version == '1.2.3'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'
   

# Generated at 2022-06-11 22:31:04.798133
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:17.381556
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:30.719194
# Unit test for function bump_version
def test_bump_version():
    """Test the function for changing a version number.

    :rtype: None

    """
    from flutils.packages import bump_version
    from flutils.testing import (
        function_exception_test,
        function_return_test,
        is_list_test,
    )


# Generated at 2022-06-11 22:31:39.755470
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('4.4.4') == '4.4.5'
    assert bump_version('4.4.4', position=1) == '4.5'
    assert bump_version('4.4.4', position=0) == '5.0'
    assert bump_version('4.4.4', pre_release='a') == '4.4.5a0'
    assert bump_version('4.4.4a0', pre_release='a') == '4.4.4a1'
    assert bump_version('4.4.4a1', pre_release='b') == '4.4.4b0'
    assert bump_version('4.4.4a1') == '4.4.4'

# Generated at 2022-06-11 22:31:51.327887
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version.

    No return value.  Raises AssertionError if any tests fail.

    """
    from . import utils
    # Suppress warning about no assertion test
    # pylint: disable=W0106

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:32:52.323310
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    .. seealso::
        :func:`bump_version`
    """

# Generated at 2022-06-11 22:33:02.210508
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:13.582934
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    from sys import version_info
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:33:26.773576
# Unit test for function bump_version

# Generated at 2022-06-11 22:33:34.742094
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:33:46.680459
# Unit test for function bump_version
def test_bump_version():
    import os
    import shutil
    import sys
    import tempfile

    pkg_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), os.pardir
    )
    sys.path.insert(0, pkg_path)
    from flutils.packages import bump_version  # noqa

    def bump(*args, **kwargs):
        return bump_version(*args, **kwargs)

    assert bump('1.2.3') == '1.2.4'
    assert bump('1.2.4', position=1) == '1.3'
    assert bump('1.2.4', position=0) == '2.0'

# Generated at 2022-06-11 22:33:55.828498
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:01.469364
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""

# Generated at 2022-06-11 22:34:13.006260
# Unit test for function bump_version
def test_bump_version():
    """ Run the unit tests for :func:`flutils.packages.bump_version`.

    This function is meant to be run via pytest.
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_

# Generated at 2022-06-11 22:34:23.894176
# Unit test for function bump_version
def test_bump_version():
    """Quick sanity test for function ``bump_version``."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'