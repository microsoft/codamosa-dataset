

# Generated at 2022-06-11 22:25:56.944429
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613,C0103
    """Unit test for function bump_version."""
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version_no_params(self):
            """Test bump_version with no params."""
            version = bump_version('1.2.3')
            self.assertEqual(version, '1.2.4')

        def test_bump_version_position_0(self):
            """Test bump_version with position = 0."""
            version = bump_version('1.2.3', position=0)
            self.assertEqual(version, '2.0')

            version = bump_version('0.2.3', position=0)

# Generated at 2022-06-11 22:26:08.264111
# Unit test for function bump_version

# Generated at 2022-06-11 22:26:18.655303
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

# Generated at 2022-06-11 22:26:28.202219
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for :func:`bump_version`.
    """

    version = '1.2.2'
    result = bump_version(version)
    assert result == '1.2.3'

    result = bump_version(version, position=1)
    assert result == '1.3'

    result = bump_version(version, position=0)
    assert result == '2.0'

    result = bump_version(version, pre_release='a')
    assert result == '1.2.4a0'

    result = bump_version(result, pre_release='a')
    assert result == '1.2.4a1'

    result = bump_version(result, pre_release='b')
    assert result == '1.2.4b0'


# Generated at 2022-06-11 22:26:36.533393
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    assert(version == bump_version(version))
    assert('0.0.1' == bump_version(version, position=2))
    assert('0.1' == bump_version(version, position=1))
    assert('1' == bump_version(version, position=0))
    version = '0.0.0'
    assert('0.0.0a0' == bump_version(version, pre_release='a'))
    version = '0.0.0a0'
    assert('0.0.0a1' == bump_version(version, pre_release='a'))
    version = '0.0.0a1'
    assert('0.0.0b0' == bump_version(version, pre_release='b'))

# Generated at 2022-06-11 22:26:47.815518
# Unit test for function bump_version
def test_bump_version():

    # Function bump_version
    args = ['1.2.2']
    expected = '1.2.3'
    actual = bump_version(*args)
    assert actual == expected

    args = ['1.2.3']
    kwargs = {'position': 1}
    expected = '1.3'
    actual = bump_version(*args, **kwargs)
    assert actual == expected

    args = ['1.3.4']
    kwargs = {'position': 0}
    expected = '2.0'
    actual = bump_version(*args, **kwargs)
    assert actual == expected

    args = ['1.2.3']
    kwargs = {'pre_release': 'a'}
    expected = '1.2.4a0'

# Generated at 2022-06-11 22:27:01.061552
# Unit test for function bump_version
def test_bump_version():
    """ Test Function bump_version """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:12.775941
# Unit test for function bump_version
def test_bump_version():
    """Test the function ``bump_version``."""
    base_versions = [
        '1.2.3',
        '1.2',
        '1.2.3a1',
        '1.2.3b1',
        '1.2.3a0',
        '1.2.3.4',
    ]
    for version in base_versions:
        assert bump_version(version) == '1.2.4'
        assert bump_version(version, position=1) == '1.3'
        assert bump_version(version, position=0) == '2.0'
        assert bump_version(version, prerelease='a') == '1.2.4a0'
        assert bump_version(version, prerelease='b') == '1.2.4b0'
        assert bump

# Generated at 2022-06-11 22:27:21.123303
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:31.953568
# Unit test for function bump_version
def test_bump_version():
    NON_VER_VALS = (
        None,
        0,
        1,
        [],
        {},
        [0],
        {0: 1},
        'a',
        'b',
        'c',
        'd',
    )
    # pylint: disable=W0603
    global NON_VER_VALS
    global NON_VER_VALS

    # Validate that the given value for position is in fact a number
    for pos in ('a', 'b', 'c', 'd'):
        err = None
        try:
            bump_version('1.0.0', position=pos)
        except Exception as err:
            pass
        assert isinstance(err, ValueError) is True

    # Validate that the given value for pre-release is a valid value

# Generated at 2022-06-11 22:28:03.122996
# Unit test for function bump_version
def test_bump_version():
    """
    Test the function bump_version.
    """
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-11 22:28:15.649489
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.3a0'
    assert bump_version('1.2.3a0', pre_release='a') == '1.2.3a1'
    assert bump_version('1.2.3a1', pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3a1') == '1.2.3'

# Generated at 2022-06-11 22:28:26.881276
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:34.628854
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Unit test for function :func:`bump_version`."""

    # noinspection PyUnresolvedReferences
    """
    .. code-block:: python

        if __name__ == '__main__':
            import os
            import sys
            sys.path.insert(0,
                    os.path.abspath(
                            os.path.join(os.path.dirname(__file__), os.pardir)
                    )
            )

            import test_bump_version
            test_bump_version.test_bump_version()

    .. code-block:: none

        Ran 1 test in 0.001s

        OK

    """
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:28:39.020774
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Unit test for the function bump_version."""
    import sys
    sys.path.insert(0, '.')
    from flutils.packages import bump_version

# Generated at 2022-06-11 22:28:45.284358
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-few-public-methods
    class _TestCase(object):
        def __init__(
                self,
                version: str,
                position: int,
                pre_release: Optional[str],
                expected_output: str
        ) -> None:
            self.version = version
            self.position = position
            self.pre_release = pre_release
            self.expected_output = expected_output


# Generated at 2022-06-11 22:28:57.831860
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=I0011,C0111,W0612,R0904
    # pylint: disable=R0201,W0613
    func_name = 'flutils.packages.bump_version'
    version: str

    version = '1.2.2'
    assert bump_version(version) == '1.2.3'

    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'

    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'

    version = '1.2.3'
    assert bump_version(version, pre_release='a') == '1.2.4a0'

    version = '1.2.4a0'


# Generated at 2022-06-11 22:29:06.432530
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,C0330
    ver_info = _build_version_info('1.0.0')

    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.major.pos == 0
    assert ver_info.major.pre_txt == ''

    assert ver_info.minor.num == 0
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.pre_txt == ''

    assert ver_info.patch.num == 0
    assert ver_info.patch.txt == ''
    assert ver_info.patch.pos == 2
    assert ver_info.patch.pre_txt == ''


# Generated at 2022-06-11 22:29:17.092789
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.2.3', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', pre_release='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'

# Generated at 2022-06-11 22:29:27.597881
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``."""
    funcs = (
        bump_version,
    )

# Generated at 2022-06-11 22:29:49.742126
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint
    from flutils.packages import bump_version
    from flutils.tests.base import TestCase
    import re

    rx = re.compile(r'^\d+\.\d+(?:\.\d+)?(?:a\d+|b\d+)?$')

    class Test_bump_version(TestCase):

        def test_bump_version_1(self):
            tests = [
                ('1.2', 2),
                ('1.2', 1),
                ('1.2', 0),
                ('1.2.0', 2),
                ('1.2.3', 2),
                ('1.2.3', 1),
                ('1.2.3', 0),
                ('1.2.3', -1),
            ]

# Generated at 2022-06-11 22:29:59.132722
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for ``bump_version`` function."""
    import sys
    import unittest

    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version_default(self):
            version = bump_version('1.2.2')
            self.assertEqual(version, '1.2.3')

        def test_bump_version_minor(self):
            version = bump_version('1.2.3', position=1)
            self.assertEqual(version, '1.3')

        def test_bump_version_major(self):
            version = bump_version('1.3.4', position=0)
            self.assertEqual(version, '2.0')


# Generated at 2022-06-11 22:30:08.662394
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:18.604585
# Unit test for function bump_version
def test_bump_version():
    def get_fmt1(
            version: str,
            position: int,
            pre_release: Optional[str],
            result: str
    ) -> None:
        return 'bump_version("{}", position={}, pre_release="{}") => "{}"'.format(
            version, position, pre_release, result
        )

    def get_fmt2(expected: Union[str, type]) -> str:
        return 'Expected: {}'.format(expected)

    def get_fmt3(exc_class: type) -> str:
        return 'Exception type: {}'.format(exc_class.__name__)

    def get_fmt4(msg: str) -> str:
        return 'Exception message: {}'.format(msg)


# Generated at 2022-06-11 22:30:31.050318
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version."""
    from flutils.packages import bump_version
    import sys


# Generated at 2022-06-11 22:30:41.291327
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=3)
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=-1)
    with pytest.raises(ValueError):
        bump_version('1.2.3', pre_release='a', position=0)
    with pytest.raises(ValueError):
        bump_version('1.2.3', pre_release='c')
    with pytest.raises(ValueError):
        bump_version('1.2.3', pre_release='')
    with pytest.raises(ValueError):
        bump_version('h.2.3')


# Generated at 2022-06-11 22:30:53.315199
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function.

    """
    from flutils.packages import (
        bump_version,
        normalize_version
    )

# Generated at 2022-06-11 22:31:04.281552
# Unit test for function bump_version

# Generated at 2022-06-11 22:31:17.176637
# Unit test for function bump_version
def test_bump_version():
    test_ok = True
    # noinspection PyUnusedLocal
    func_name = 'bump_version'
    try:
        import unittest
    except ImportError:
        return False
    else:
        from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        """Unit test for the function bump_version."""

        def test_pos_arg(self):
            """Test all position values."""
            # noinspection SpellCheckingInspection

# Generated at 2022-06-11 22:31:30.404940
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    func_name = '%s.test_bump_version' % __name__
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:32:12.100741
# Unit test for function bump_version
def test_bump_version():
    tests: List[Tuple[str, int, Optional[str], str]] = [
        ('1.2.3', 2, None, '1.2.4'),
        ('1.3.4', 1, 'a', '1.4a0'),
        ('1.2.4a0', 1, None, '1.3'),
        ('1.2.4a1', 2, 'a', '1.2.4a2'),
        ('1.2.4a1', 2, None, '1.2.4'),
        ('1.2.4b0', 2, None, '1.2.4'),
        ('1.2.4b0', 2, 'b', '1.2.4b1'),
        ('2.1.3', 1, 'a', '2.2a0'),
    ]

# Generated at 2022-06-11 22:32:20.814608
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:32.419776
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    import pytest  # pylint: disable=E0401


# Generated at 2022-06-11 22:32:44.273064
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # pylint: disable=C0103
    import pytest
    from flutils.packages import bump_version
    from distutils.version import StrictVersion

    _VERSION = '1.2.0'
    _VERSION_INFO = _build_version_info(_VERSION)

    # Valid position, valid pre_release

# Generated at 2022-06-11 22:32:51.659143
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version for class Version."""

    # noinspection PyUnresolvedReferences
    from flutils.packages import bump_version

    def _test_common(
            version: str,
            position: int,
            pre_release: Optional[str],
            result: str
    ) -> None:
        """Test the common version numbers."""
        assert bump_version(version, position, pre_release) == result
        assert bump_version(version, position, pre_release.upper()) == result
        assert bump_version(version, position, pre_release.capitalize()) == result


# Generated at 2022-06-11 22:33:01.665397
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """ Test bump_version function """
    # pylint: disable=E1101
    from flutils.packages import bump_version
    from flutils.tester import AssertEqual

    def test_version_exception(version, position, pre_release):
        """ Test bump_version exception """
        try:
            bump_version(version, position, pre_release)
        except Exception as exc:
            return exc
        raise Exception('No exception was returned.')
    #
    # Basic use case
    #
    ver = bump_version('1.2.2')
    AssertEqual(ver, '1.2.3')
    ver = bump_version('1.2.3', position=1)
    AssertEqual(ver, '1.3')
    ver = bump_version

# Generated at 2022-06-11 22:33:13.229387
# Unit test for function bump_version

# Generated at 2022-06-11 22:33:26.336209
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:34.534149
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """
    func = bump_version

    # --------------------
    # Default position
    # --------------------
    err_msg = "position test #1 failed"
    assert func("1.2.2") == "1.2.3", err_msg
    err_msg = "position test #2 failed"
    assert func("1.2.3") == "1.2.4", err_msg

    # --------------------
    # Position 1
    # --------------------
    err_msg = "minor test #1 failed"
    assert func("1.2.3", position=1) == "1.3", err_msg
    err_msg = "minor test #2 failed"
    assert func("1.3.4", position=1) == "1.4", err_msg

    # --------------------
    # Position

# Generated at 2022-06-11 22:33:46.410953
# Unit test for function bump_version

# Generated at 2022-06-11 22:34:16.073927
# Unit test for function bump_version
def test_bump_version():
    import sys
    import contextlib
    from io import StringIO

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    print('bump_version(%s) == %s' % ('1.2.2', '1.2.3'))
    assert bump_version('1.2.2') == '1.2.3'

# Generated at 2022-06-11 22:34:23.270547
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-11 22:34:30.917057
# Unit test for function bump_version
def test_bump_version():
    """
    Test the version bumping.

    Test the version bumping.

    Args:
        None

    Returns:
        None

    Functionality:
        The test will fail if the main functionality of the ``bump_version``
        function is not executed properly.

    """
    # pylint: disable=R0914
    if bump_version('1.2.2') != '1.2.3':
        raise AssertionError(
            'Incorrect version bump for 1.2.2 (major) : %s' % (
                bump_version('1.2.2', position=0)
            )
        )

# Generated at 2022-06-11 22:34:37.665403
# Unit test for function bump_version
def test_bump_version():
    """Unit test for :func:`~flutils.packages.bump_version`

    Raises:
        ValueError: if tests fail

    """

# Generated at 2022-06-11 22:34:48.598370
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0116
    def _test_version_bump(version: str, expected_version: str):
        out = bump_version(version)
        assert out == expected_version

    _test_version_bump('1.2.3', '1.2.4')
    _test_version_bump('1.2.3', '1.2.4')
    _test_version_bump('1.2.3', '1.2.4')
    _test_version_bump('1.2.3a0', '1.2.4a0')
    _test_version_bump('1.2.4a0', '1.2.4a1')

# Generated at 2022-06-11 22:35:00.334230
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from flutils.common import get_caller_params
    from flutils.common import unit_test
    from pprint import pprint

    record = {
        'version': '1.2.3',
        'position': 2,
        'pre_release': None,
        'out': '1.2.4'
    }
    assert bump_version(**record) == record['out']

    kwargs = record.copy()
    kwargs['position'] = 1
    record['out'] = '1.3'
    assert bump_version(**record) == record['out']

    kwargs = record.copy()
    kwargs['position'] = 0
    record['out'] = '2.0'
    assert bump_version(**record) == record['out']

    k

# Generated at 2022-06-11 22:35:03.538223
# Unit test for function bump_version
def test_bump_version():
    from . import doctest
    assert doctest.testmod(
        bump_version
    )[0] == 0



# Generated at 2022-06-11 22:35:14.539470
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3*

    """
    ver_cases = [
        ('1.2.3', 0, '2.0'),
        ('1.2.3', 1, '1.3'),
        ('1.2.3', 2, '1.2.4'),
        ('2.1.3', 1, '2.2'),
        ('1.2b0', 2, '1.2.1'),
        ('1.2.4a1', 'a', '1.2.5a0'),
        ('1.2.4a1', 'b', '1.2.4b0'),
    ]
    for version, pos, result in ver_cases:
        assert bump_version(version, position=pos) == result



# Generated at 2022-06-11 22:35:26.218851
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:35:35.451295
# Unit test for function bump_version
def test_bump_version():
    """
    """
    # pylint: disable=I0011,C0324
    from typing import Tuple

    print("beg: test_bump_version")