

# Generated at 2022-06-11 22:25:55.691162
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:07.837718
# Unit test for function bump_version
def test_bump_version(): # pylint: disable=R0914
    """
    Unit test for function bump_version
    """
    import unittest


    class CodeTestCase(unittest.TestCase):
        """
        Unit test class
        """

        def test_func(self):
            """
            Test the function
            """
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-11 22:26:18.280586
# Unit test for function bump_version
def test_bump_version():
    """Test the function 'bump_version'."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:26:28.090473
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from pytest import raises
    from flutils.packages import bump_version
    # noinspection PyUnusedLocal
    parts = []
    parts.append(('1.2.2', '1.2.3'))
    parts.append(('1.2.3', '1.3', 1))
    parts.append(('1.3.4', '2.0', 0))
    parts.append(('1.2.3', '1.2.4a0', None, 'a'))

# Generated at 2022-06-11 22:26:28.676192
# Unit test for function bump_version
def test_bump_version():
    pass

# Generated at 2022-06-11 22:26:36.799288
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase
    from unittest.mock import patch, mock_open

    with patch('sys.stdout', new=mock_open()) as mock_print:
        # Standard bump
        assert bump_version('1.2.2') == '1.2.3'

        # Minor bump
        assert bump_version('1.2.3', position=1) == '1.3'

        # Major bump
        assert bump_version('1.3.4', position=0) == '2.0'

        # Alpha bump
        assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

        # Alpha bump increase
        assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

       

# Generated at 2022-06-11 22:26:47.976842
# Unit test for function bump_version
def test_bump_version():
    r"""Unit test for function bump_version.

    Run a unit test for function bump_version.

    Examples:
        >>> from flutils.packages import test_bump_version
        >>> test_bump_version()

    """
    import pytest

# Generated at 2022-06-11 22:27:01.159821
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    assert bump_version(version, pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:09.206308
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:19.154086
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # noinspection PyShadowingNames
    def _test_bump_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        bump_info = 'version: %r, position: %r, pre_release: %r' % (
            version, position, pre_release
        )
        # noinspection PyBroadException
        try:
            out = bump_version(version, position, pre_release)
        except Exception as err:
            out = err
        if isinstance(out, Exception):
            out = '%s: %s' % (type(out).__name__, out)

# Generated at 2022-06-11 22:27:50.782701
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from hypothesis import (  # type: ignore
        assume,
        given,
        settings,
    )
    from hypothesis.strategies import (  # type: ignore
        integers,
        lists,
        one_of,
        sampled_from,
        text,
    )

    # pylint: disable=E1101
    numbers = integers(min_value=0, max_value=3)
    letters = sampled_from(['a', 'b', 'alpha', 'beta'])
    numbers_and_letters = one_of(numbers, letters)
    bumped_vers = lists(
        numbers_and_letters, min_size=3, max_size=3
    ).map(lambda x: '.'.join(map(str, x)))
    # pylint:

# Generated at 2022-06-11 22:28:00.113657
# Unit test for function bump_version
def test_bump_version():
    import pylint.testutils
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:28:08.065067
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import unittest

    class UnitTest(unittest.TestCase):
        """."""

        def test(self):
            """Test."""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
            self.assertEqual(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-11 22:28:15.051407
# Unit test for function bump_version
def test_bump_version():
    # Major
    assert bump_version('1.2.3', position=0) == '2.0'
    # Minor
    assert bump_version('1.2.3', position=1) == '1.3'
    # Patch
    assert bump_version('1.2.3') == '1.2.4'
    # Pre-release
    #   Minor version, Alpha (no pre-release)
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    #   Minor version, Alpha (with pre-release)
    assert bump_version('1.2.3a0', position=1, pre_release='a') == '1.3a0'
    #   Minor version, Alpha (with pre-release), again

# Generated at 2022-06-11 22:28:21.253164
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:31.860069
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
   

# Generated at 2022-06-11 22:28:44.356979
# Unit test for function bump_version
def test_bump_version():
    import unittest.mock

    from flutils.packages import bump_version

    with unittest.mock.patch('flutils.packages.bump_version') as mck:
        bump_version('1.2.3', position=1)
        mck.assert_called_with('1.2.3', position=1, pre_release=None)
        bump_version('1.2.3', position=1, pre_release='a')
        mck.assert_called_with('1.2.3', position=1, pre_release='a')
        bump_version('1.2.3', position=1, pre_release='b')
        mck.assert_called_with('1.2.3', position=1, pre_release='b')

    assert bump_version('1.2.3')

# Generated at 2022-06-11 22:28:57.238174
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    from flutils.packages import bump_version
    from flutils.pytest_helpers import assert_nothing_raised

    # Test bumps to major version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.1.3') == '1.2'
    assert bump_version('1.0.3') == '2'
    assert bump_version('3') == '4'

    # Test bumps to minor and  pre-release versions
    assert bump_version('1.2.3', position=1) == '1.3'

# Generated at 2022-06-11 22:29:00.400719
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=unused-import
    from flutils.packages import bump_version


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:29:02.918662
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('0.1.2') == '0.1.3'



# Generated at 2022-06-11 22:29:14.310201
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    assert bump_version('1.2.3') == '1.2.4'



# Generated at 2022-06-11 22:29:21.101743
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:30.514465
# Unit test for function bump_version
def test_bump_version():
    ver_str = '1.2.3'
    assert bump_version(ver_str) == '1.2.4'
    assert bump_version(ver_str, position=0) == '2.0'
    assert bump_version(ver_str, position=1) == '1.3'
    assert bump_version(ver_str, pre_release='a') == '1.2.3a0'
    ver_str = '1.2.3a0'
    assert bump_version(ver_str, position=0, pre_release='a') == '1.3a0'
    ver_str = '1.2.3a0'
    assert bump_version(ver_str, position=1) == '1.3'
    ver_str = '1.2.3a0'
    assert bump

# Generated at 2022-06-11 22:29:40.849309
# Unit test for function bump_version
def test_bump_version():
    """Test flutils.packages.bump_version()."""

# Generated at 2022-06-11 22:29:48.212219
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function ``bump_version``. """
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    assert bump_version(version, pre_release='A') == '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:29:58.293203
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:08.067428
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from tests.helper import print_version_info

    pre_lookup = {
        'a': 'a',
        'alpha': 'a',
        'b': 'b',
        'beta': 'b',
    }


# Generated at 2022-06-11 22:30:18.242699
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # noinspection PyUnusedLocal
    def _bump_test(
            ver_in: str,
            pos: int,
            pre_release: Optional[str],
            ver_out: str
    ):
        """Test the bump_version function"""
        ver_out_tst = bump_version(ver_in, position=pos, pre_release=pre_release)
        assert ver_out_tst == ver_out

    _bump_test('1.2.2', 2, None, '1.2.3')
    _bump_test('1.2.3', 1, None, '1.3')
    _bump_test('1.3.4', 0, None, '2.0')

# Generated at 2022-06-11 22:30:26.200375
# Unit test for function bump_version
def test_bump_version():
    import sys
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Unit tests for the bump_version function."""

        def test_no_major_and_patch_is_0(self):
            """Test a simple no-bump patch."""

            self.assertEqual(
                bump_version('1.2.3'),
                '1.2.3'
            )

        def test_no_major_and_patch_is_not_0(self):
            """Test a simple no-bump patch."""

            self.assertEqual(
                bump_version('1.2.4'),
                '1.2.4'
            )

        def test_bump_no_major(self):
            """Test a simple patch bump."""


# Generated at 2022-06-11 22:30:35.722846
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version"""
    def _test_assert_correct(
            ver: str,
            position: int,
            prerelease: Optional[str] = None,
            expected: str = '',
    ) -> None:
        if expected == '':
            expected = ver
        result = bump_version(ver, position, prerelease)
        assert result == expected, (
            "Version %r did not get bumped correctly (%r). "
            "It should have been (%r), but instead received (%r)." % (
                ver, bump_type, expected, result
            )
        )


# Generated at 2022-06-11 22:30:55.308953
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version

    func = bump_version
    func_args: Dict[str, Any] = {
        'version': '1.2.2',
    }
    func_exp = '1.2.3'
    func_ret = func(**func_args)
    assert func_ret == func_exp, \
        "bump_version(**%r), returned: %r, expected: %r" % (
            func_args, func_ret, func_exp
        )

    func_args = {'version': '1.2.3', 'position': 1}
    func_exp = '1.3'
    func_ret = func(**func_args)

# Generated at 2022-06-11 22:31:05.757299
# Unit test for function bump_version
def test_bump_version():
    """Test function: flutils.packages.bump_version()"""

    from flutils.packages import bump_version
    from flutils.testing import assert_equal

    assert_equal(bump_version('1.2.2'), '1.2.3')
    assert_equal(bump_version('1.2.3', position=1), '1.3')
    assert_equal(bump_version('1.3.4', position=0), '2.0')
    assert_equal(bump_version('1.2.3', pre_release='a'), '1.2.4a0')
    assert_equal(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-11 22:31:18.467514
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:31.786671
# Unit test for function bump_version

# Generated at 2022-06-11 22:31:40.049297
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version."""

    def _test_bump_version(
            version: str,
            should_be: str,
            position: int = 2,
            pre_release: str = ''
    ) -> None:
        """Test the function: bump_version."""
        res = bump_version(version, position, pre_release)
        assert res == should_be, (
            "bump_version('%s', %s, %s) "
            "should be: %s, not: %s" % (
                version,
                position,
                repr(pre_release),
                repr(should_be),
                repr(res)
            )
        )


# Generated at 2022-06-11 22:31:51.389493
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'

# Generated at 2022-06-11 22:32:02.906554
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:15.709047
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    import random
    random.seed(0)
    from pathlib import Path
    from flutils.configutils import ConfigFileContainer
    from flutils.strings import safe_split

    def _compare_versions(a, b):  # pylint: disable=R0911
        a_parts = safe_split(a, sep='.', limit=3)
        b_parts = safe_split(b, sep='.', limit=3)
        for a_part, b_part in zip(a_parts, b_parts):
            if a_part == b_part:
                continue
            a_pre = safe_split(a_part, sep='a', limit=1)
            b_pre = safe_split(b_part, sep='a', limit=1)

# Generated at 2022-06-11 22:32:28.423269
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    """Unit test for function bump_version."""
    assert bump_version('') == '1.0'
    assert bump_version('', position=0) == '1.0'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:32:38.304951
# Unit test for function bump_version
def test_bump_version():
    """Tests the ``bump_version`` function."""
    # pylint: disable=E1120,W0703,R0201
    # noinspection PyUnusedLocal
    def _temp_call(
            in_arg: Tuple[Union[str, int, None], ...],
            out_arg: str
    ) -> None:
        ver = bump_version(*in_arg)
        assert ver == out_arg
        return None

    _temp_call(('1.2.2',), '1.2.3')
    _temp_call(('1.2.3', 1), '1.3')
    _temp_call(('1.3.4', 0), '2.0')

# Generated at 2022-06-11 22:33:04.930148
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Verify the bump_version function works when run as a script."""
    import sys
    try:
        version = sys.argv[1]
    except IndexError:
        version = '1.2.3'
        try:
            prerelease = sys.argv[2]
        except IndexError:
            prerelease = 'a'
        try:
            position = int(sys.argv[3])
        except IndexError:
            position = 2
    print('bump_version(%r, position=%r, pre_release=%r)' % (
        version,
        position,
        prerelease,
    ))
    print(bump_version(version, position, prerelease))


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:33:15.328583
# Unit test for function bump_version
def test_bump_version():
    """
    :return:
    """
    import collections
    import flutils.packages
    import importlib
    import sys
    import traceback

    if 'sphinx' not in sys.modules:
        import doctest
        import unittest
        runner = unittest.TextTestRunner()
        runner.run(doctest.DocTestSuite(
            flutils.packages,
            optionflags=doctest.ELLIPSIS
        ))

    version = flutils.packages._Version('1.2.3')
    assert version.version == '1.2.3'
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.major_txt == '1'
    assert version.minor_txt == '2'

# Generated at 2022-06-11 22:33:27.811562
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function :func:`bump_version`"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:37.706622
# Unit test for function bump_version
def test_bump_version():
    """Tests :func:`flutils.packages.bump_version`"""
    major = '1.2.2'
    minor = '1.2.3'
    patch = '1.2.4'
    alpha = '1.2.3a0'
    beta = '1.2.3b0'
    assert bump_version(major) == '1.2.3'
    assert bump_version(minor, position=1) == '1.3'
    assert bump_version(patch, position=0) == '2.0'
    assert bump_version(patch, prerelease='a') == '1.2.4a0'
    assert bump_version(alpha, pre_release='a') == '1.2.3a1'

# Generated at 2022-06-11 22:33:49.644961
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1101
    import pytest

    class _TestCase(NamedTuple):
        name: str
        version: str
        position: int
        prerelease: Optional[str]
        result: str
        raises: bool


# Generated at 2022-06-11 22:33:57.725864
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0115,W0621,W0612
    from . import assert_equal, assert_raises
    assert_equal(bump_version('1.2.2'), '1.2.3')
    assert_equal(bump_version('1.2.3', 1), '1.3')
    assert_equal(bump_version('1.3.4', 0), '2.0')
    assert_equal(bump_version('1.2.3', pre_release='a'), '1.2.4a0')
    assert_equal(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-11 22:34:10.861766
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0116
    def _test(name: str, call: str, expect: str):
        call = call.rstrip()
        result = eval(call)
        if result != expect:
            raise AssertionError(
                "Test (%s) failed.  Result: (%s)  Expected: (%s)" %
                (name, result, expect)
            )

    _test('bump_version_1', 'bump_version("1.4.3")', '1.4.4')
    _test('bump_version_2', 'bump_version("1.4.3", position=1)', '1.5')
    _test('bump_version_3', 'bump_version("1.4.3", position=0)', '2.0')
    _

# Generated at 2022-06-11 22:34:22.943825
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0201,R0904,W0212,C0103,W0621
    """Unit test for function: :obj:`bump_version`"""
    from os.path import split
    import sys
    import unittest

    from flutils.packages import bump_version

    class TestVersionBump(unittest.TestCase):
        """Unit test for function: :obj:`bump_version`."""

        def test_bump_version(self):
            """Test for function: :obj:`bump_version`."""

# Generated at 2022-06-11 22:34:37.336966
# Unit test for function bump_version
def test_bump_version():
    ver_no = '1.2.3'
    assert bump_version(ver_no) == '1.2.4'
    assert bump_version(ver_no, position=1) == '1.3'
    assert bump_version(ver_no, position=0) == '2.0'
    assert bump_version(ver_no, prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0')

# Generated at 2022-06-11 22:34:48.344715
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:35:28.063809
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint
    from textwrap import dedent
    from pytest import raises
    # noinspection SpellCheckingInspection