

# Generated at 2022-06-11 22:26:01.226468
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    *New in version 0.3*

    """
    from flutils.packages import bump_version

    def test_one(
            ver: str,
            pos: int,
            pre_release: Optional[str],
            out: str
    ):
        """Handle a single test."""
        val = bump_version(ver, position=pos, pre_release=pre_release)
        assert (val == out), (val, out)


# Generated at 2022-06-11 22:26:10.268060
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    # pylint: disable=protected-access
    check_version = _build_version_info

    # Valid no pre-release
    assert check_version('1.2.2').version == check_version(bump_version('1.2.2'))
    assert check_version('0.3.3').version == check_version(bump_version('0.3.3'))
    assert check_version('1.2.3').version != check_version(bump_version('1.2.2'))
    assert check_version('1.2.3').version == check_version(bump_version('1.2.2', position=2))

# Generated at 2022-06-11 22:26:20.830101
# Unit test for function bump_version
def test_bump_version():
    """
    Test the bump_version function.
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-11 22:26:29.036171
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    Runs on:
        - Python 3.5
        - Python 3.6
        - Python 3.7
        - PyPy3.5 7.3.0-beta0
        - PyPy3 7.3.1
        - PyPy3 7.3.2
        - Pypy3.5 7.3.2

    """
    # noinspection PyUnresolvedReferences
    import flutils
    from flutils.packages import __version__
    from flutils.packages import bump_version
    import sys
    # noinspection PyUnresolvedReferences
    from flutils.common import get_text_type
    ver_info = _build_version_info(__version__)

# Generated at 2022-06-11 22:26:36.976981
# Unit test for function bump_version
def test_bump_version():
    # Test a 'patch' bump
    assert bump_version('1.0.0') == '1.0.1'
    # Test a 'minor' bump
    assert bump_version('1.0.0', position=1) == '1.1.0'
    # Test a 'major' bump
    assert bump_version('1.0.0', position=0) == '2.0.0'
    # Test a 'minor' bump with an alpha value
    assert (
        bump_version('1.0.0', position=1, pre_release='a') ==
        '1.1a0'
    )
    # Test a 'minor' bump adding to a previous minor alpha version

# Generated at 2022-06-11 22:26:48.048154
# Unit test for function bump_version
def test_bump_version():
    # Test error handling
    ver_bad_pos = '1.2.3'
    for pos in (3, 100, -4, -100):
        try:
            bump_version(ver_bad_pos, position=pos)
        except ValueError:
            pass
        else:
            raise RuntimeError(
                'bump_version(pos=%s) should raise ValueError.' % pos
            )

    ver_bad_pre = '1.2.3'
    for pre in ('c', 'hello', '', ' ', '  ', 'bad', 'a1'):
        try:
            bump_version(ver_bad_pre, pre_release=pre)
        except ValueError:
            pass

# Generated at 2022-06-11 22:27:01.206754
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    # pylint: disable=W0212

# Generated at 2022-06-11 22:27:13.039566
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    import sys
    import unittest
    # Do not set ``__name__ = '__main__```` here, otherwise the unit test
    #  module name will be ``'__main__'`` due to the rest of the lines
    #  in this file.

    class TestBumpVersion(unittest.TestCase):
        """Unit test class for function bump_version"""

        def test_bump_version(self):
            """Unit test for function bump_version"""
            from flutils.packages import bump_version
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')

# Generated at 2022-06-11 22:27:21.263586
# Unit test for function bump_version
def test_bump_version():
    print('Testing function "bump_version"')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:31.988038
# Unit test for function bump_version
def test_bump_version(): # pylint: disable=R0914
    """Test the flutils.packages.bump_version function.

    """
    # pylint: disable=C0103
    from flutils.testing import CaptureOutput


# Generated at 2022-06-11 22:28:07.110128
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:14.273800
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    Raises:
        AssertionError: on test failure

    Returns:
        None

    """
    pos_map = {
        0: 2,
        1: 1,
        2: 0
    }

    def _do_test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected_out: Optional[str] = None
    ) -> None:
        out = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        if expected_out is None:
            expected_out = version

# Generated at 2022-06-11 22:28:20.902444
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:31.622606
# Unit test for function bump_version
def test_bump_version():
    """
    This contains some unit tests for the ``bump_version`` function.

    *New in version 0.3*

    """
    # pylint: disable=R0912,R0914,R1705,C0103
    def _build_test_case(
            version: str,
            pos_br: int,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> Tuple[str, int, int, Optional[str], str]:
        """
        Pos BR: position, bump type, pre-release
        """
        return (version, pos_br, position, pre_release, expected)


# Generated at 2022-06-11 22:28:44.355071
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version in module ``bump_version``."""
    from flutils.packages import bump_version
    test_intro: str = 'Test version bumping:'
    print(test_intro)

    test_count: int = 0
    test_fail_count: int = 0

# Generated at 2022-06-11 22:28:57.239689
# Unit test for function bump_version
def test_bump_version():
    """
    Test for function bump_version.
    """
    # noinspection PyUnresolvedReferences
    import pytest  # pylint: disable=E0401

    with pytest.raises(ValueError):
        bump_version('2.0')

    with pytest.raises(ValueError):
        bump_version('2.0', pre_release='a')

    with pytest.raises(ValueError):
        bump_version('2.0', pre_release='b')

    with pytest.raises(ValueError):
        bump_version('2.0', pre_release='x')

    with pytest.raises(ValueError):
        bump_version('2.0', position=-4)

    with pytest.raises(ValueError):
        bump_version('2.0', position=3)

# Generated at 2022-06-11 22:29:06.314161
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the ``bump_version()`` function."""

    def _test(
            expected: str,
            actual: str,
            error_msg: str,
            should_pass: bool = True
    ) -> None:
        should_pass_txt = 'should pass' if should_pass is True else 'should fail'
        condition = actual == expected
        if should_pass is True:
            condition = condition is True
        assert condition, '%s: %s' % (should_pass_txt, error_msg)

    # tests for version bumping
    _test(
        '1.2.3',
        bump_version('1.2.2'),
        'bump_version("1.2.2") != "1.2.3".'
    )

# Generated at 2022-06-11 22:29:17.027753
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version
    """
    from flutils.packages import bump_version

    def run_bump_version(
            *args: Any,
            expected: str = '',
            expected_exc: bool = False,
    ) -> bool:
        """Run bump version with the given arguments and return True if
        the result or error matches expectations or False if they don't.
        """
        try:
            result = bump_version(*args)
        except ValueError:
            if expected_exc is True:
                return True
            print(
                "Expected a result of '%s' -- got an error instead!" %
                expected
            )
            return False

# Generated at 2022-06-11 22:29:22.593465
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """
    Unit test class for the :func:`~flutils.configs.bump_version` function.

    """
    import sys
    import unittest

    from . import CapturingTestCase

    class Test(CapturingTestCase):
        """
        Base unit test class.

        """
        def test_bump(self):
            """
            Test the :func:`~flutils.configs.bump_version` function.

            """
            with self.assertRaises(ValueError) as cm:
                bump_version('1.2.3', position=0, pre_release='a')

# Generated at 2022-06-11 22:29:30.989000
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    ver = '1.2.0'
    expected = '1.2.1'
    result = bump_version(ver)
    assert result == expected
    ver = '1.2.0'
    expected = '1.3'
    result = bump_version(ver, position=1)
    assert result == expected
    ver = '1.3.4'
    expected = '2.0'
    result = bump_version(ver, position=0)
    assert result == expected
    ver = '1.2.3'
    pre_release_type = 'a'
    expected = '1.2.4a0'
    result = bump_version(ver, pre_release=pre_release_type)
    assert result == expected

# Generated at 2022-06-11 22:29:59.570306
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version
    """
    # Test _build_version_bump_position()
    test_list = [
        (-3, 2),
        (-2, 1),
        (-1, 0),
        (0, 0),
        (1, 1),
        (2, 2),
        (3, 3)
    ]
    for test in test_list:
        assert _build_version_bump_position(test[0]) == test[1]

    # Test _build_version_bump_type()

# Generated at 2022-06-11 22:30:05.243512
# Unit test for function bump_version
def test_bump_version():
    """Run all tests for function bump_version."""
    from flutils.packages import bump_version

    # noinspection PyUnusedLocal
    def _test_variables(
            version: str,
            position: int,
            prerelease: Optional[str],
            expected: str
    ) -> None:
        result = bump_version(version, position, prerelease)
        assert result == expected

    # Test with a valid position number with no prerelease
    _test_variables('1.2.3', 1, None, '1.3')
    # Test with a negative position number with no prerelease
    _test_variables('1.2.3', -2, None, '1.2.3')
    # Test with a invalid position number with no prerelease

# Generated at 2022-06-11 22:30:16.386032
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

# Generated at 2022-06-11 22:30:25.561752
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914,R0915
    from pytest import raises
    from os.path import dirname, join

    test_file = join(dirname(__file__), 'bump_version.txt')
    with open(test_file, 'r') as i_fh:
        lines = i_fh.readlines()

    version_end = len(lines[0].strip().split('=')) - 1

    # TODO: add test cases that break bump_version()
    # (incomplete data or bad data)
    # e.g.
    #
        # with raises(ValueError, match=r'major'):
        #     bump_version('1.2.3', position=0, pre_release='a')
        #
        # with raises(ValueError, match=r'pre_

# Generated at 2022-06-11 22:30:35.126215
# Unit test for function bump_version

# Generated at 2022-06-11 22:30:44.245808
# Unit test for function bump_version
def test_bump_version():
    from colorama import Fore, Style

    # NOTE: Used to generate test cases.  Remove after tests are written.
    # from random import randint

    # NOTE: Used to generate test cases.  Remove after tests are written.
    # builds: List[Tuple[str, str, str]] = []

    # NOTE: Used to generate test cases.  Remove after tests are written.
    # for _ in range(1000):
    #     ver = '%s.%s.%s' % (
    #         randint(0, 10000),
    #         randint(0, 10000),
    #         randint(0, 10000),
    #     )
    #     pre = None
    #     pre_ops = ['a', 'alpha', 'b', 'beta']
    #     if randint(0, 1) == 1:
    #

# Generated at 2022-06-11 22:30:47.318579
# Unit test for function bump_version
def test_bump_version():
    """Runs all the tests for the 'bump_version' function."""
    import doctest
    from . import bump_version
    doctest.testmod(bump_version)

# Generated at 2022-06-11 22:30:56.172393
# Unit test for function bump_version
def test_bump_version():

    version = '1.2.2'
    assert bump_version(version) == '1.2.3'
    version = '1.3.4'
    assert bump_version(version, position=1) == '1.4'
    version = '2.1.3'
    assert bump_version(version, position=2, pre_release='a') == '2.1.4a0'
    version = '1.2b0'
    assert bump_version(version, position=2) == '1.2.1'

# Generated at 2022-06-11 22:31:06.086246
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:18.814176
# Unit test for function bump_version
def test_bump_version():

    def do_test(
            func: str,
            inp: str,
            exp: str
    ) -> None:
        got: str = eval(func)(inp)
        print('')
        print('func: %r' % func)
        print('input: %r' % inp)
        print('expected: %r' % exp)
        print('     got: %r' % got)
        assert got == exp

    print('')
    print('Testing "bump_version"')
    do_test('bump_version', '1.2.2', '1.2.3')
    do_test('bump_version', '1.2.3', '1.2.4')
    do_test('bump_version', '1.2.3', '1.2.4')


# Generated at 2022-06-11 22:31:34.789482
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages.discovery import get_version

# Generated at 2022-06-11 22:31:39.560131
# Unit test for function bump_version
def test_bump_version():
    '''Test bump_version

    Tested with: Python 3.7.3
    '''
    # Test each position to bump
    # Test the no pre-release bump
    # Test the minor pre-release bump
    # Test the patch pre-release bump
    # Test the blank version
    raise

# Generated at 2022-06-11 22:31:51.159466
# Unit test for function bump_version
def test_bump_version():
    from .testing_utils import print_test_header
    print_test_header(__name__, bump_version.__name__)

    # Test a major bump
    version = '1.2.3'
    out = bump_version(version, position=0)
    assert out == '2.0'

    # Test a minor bump
    version = '1.2.3'
    out = bump_version(version, position=1)
    assert out == '1.3'

    # Test a patch bump
    version = '1.2.3'
    out = bump_version(version, position=2)
    assert out == '1.2.4'

    version = '1.2.0'
    out = bump_version(version, position=2)
    assert out == '1.2.1'

   

# Generated at 2022-06-11 22:32:02.768723
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.
    """
    from flutils.packages import bump_version

# Generated at 2022-06-11 22:32:15.710695
# Unit test for function bump_version
def test_bump_version():
    """Run unit tests for function bump_version.

    *New in version 0.3*

    """

# Generated at 2022-06-11 22:32:28.467712
# Unit test for function bump_version
def test_bump_version():
    print('testing function bump_version ...', end='')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.2.2', position=0) == '2.0'
    assert bump_version('1.2.2', prerelease='a') == '1.2.3a0'
    assert bump_version('1.2.3a0', pre_release='a') == '1.2.3a1'
    assert bump_version('1.2.3a1', pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3a1') == '1.2.3'
    assert bump_

# Generated at 2022-06-11 22:32:35.812999
# Unit test for function bump_version
def test_bump_version():
    """Tests for function bump_version"""
    # pylint:disable=W0612
    # pylint:disable=W0621
    import sys, os
    this = sys.modules[__name__]
    this_path = os.path.abspath(__file__)
    this_dir = os.path.dirname(this_path)
    test_dir = os.path.join(this_dir, 'test_files')
    # pylint:enable=W0621

    print('\nTesting function: bump_version')
    print('==============================')

    from flutils.packages import bump_version
    from pprint import pprint

    # Testing valid version numbers
    for n in range(1, 10):
        s = '1.%s.0' % n

# Generated at 2022-06-11 22:32:47.288853
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    """Unit-test for function :func:`bump_version`."""


# Generated at 2022-06-11 22:32:51.869502
# Unit test for function bump_version
def test_bump_version():
    results1 = bump_version('1.2.2')
    assert results1 == '1.2.3'
    results2 = bump_version('1.2.3', position=1)
    assert results2 == '1.3'
    results3 = bump_version('1.3.4', position=0)
    assert results3 == '2.0'
    results4 = bump_version('1.2.3', pre_release='a')
    assert results4 == '1.2.4a0'
    results5 = bump_version('1.2.4a0', pre_release='a')
    assert results5 == '1.2.4a1'
    results6 = bump_version('1.2.4a1', pre_release='b')
    assert results6 == '1.2.4b0'

# Generated at 2022-06-11 22:33:01.874408
# Unit test for function bump_version
def test_bump_version():
    print('Running unit test for bump_version.')

# Generated at 2022-06-11 22:33:16.677264
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1120
    for (
            version,
            position,
            pre_release,
            expected
    ) in _BUMP_VERSION_TEST_DATA:
        out = bump_version(
            version,
            position=position,
            pre_release=pre_release
        )
        assert out == expected



# Generated at 2022-06-11 22:33:28.634865
# Unit test for function bump_version

# Generated at 2022-06-11 22:33:37.959006
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version func.

    *New in version 0.3*

    """

# Generated at 2022-06-11 22:33:49.910265
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0912,R0915
    def xform(version, position=2, pre_release=None):
        return bump_version(
            version, position=position, pre_release=pre_release
        )
    assert xform('1.2.2') == '1.2.3'
    assert xform('1.2.3', position=1) == '1.3'
    assert xform('1.3.4', position=0) == '2.0'
    assert xform('1.2.3', pre_release='a') == '1.2.4a0'
    assert xform('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:33:57.905076
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version()."""
    import sys
    import os
    import unittest
    import warnings

    try:
        from unittest import mock  # pylint: disable=E0611,E0401
    except ImportError:
        import mock

    UNKNOWN: int = -1
    py2: int = 2
    py3: int = 3
    py34: int = 34
    py35: int = 35
    py36: int = 36
    py37: int = 37
    py38: int = 38
    py_ver: int = UNKNOWN
    if hasattr(sys, 'hexversion'):
        py_ver = sys.hexversion >> 24
    elif hasattr(sys, 'version_info'):
        if sys.version_info[0] == 2:
            py

# Generated at 2022-06-11 22:33:59.437278
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the function bump_version."""
    raise NotImplementedError()

# Generated at 2022-06-11 22:34:12.066496
# Unit test for function bump_version
def test_bump_version():
    """Tests the bump_version function.

    """
    bump_version('1.1.1')
    bump_version('1.1.1', position=2)
    bump_version('1.1.1', position=1)
    bump_version('1.1.1', position=0)
    bump_version('1.1.1', position=-1)
    bump_version('1.1.1', position=-2)
    bump_version('1.1.1', position=-3)
    bump_version('1.1.1', position=-4)
    bump_version('1.1.1', pre_release='a')
    bump_version('1.1.1', pre_release='b')
    bump_version('1.1.1', position=0, pre_release='a')
    bump_

# Generated at 2022-06-11 22:34:23.292651
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from textwrap import dedent
    from flutils.packages import bump_version
    from flutils.packages import _compare_versions


# Generated at 2022-06-11 22:34:30.905503
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """ Test flutils.packages module """
    import unittest

    # Test python version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:34:40.856915
# Unit test for function bump_version
def test_bump_version(): # pragma: no cover
    ver_str = '0.1.1'
    print('=' * 79)
    print('Version string: %r' % ver_str)
    ver_info = _build_version_info(ver_str)
    print(ver_info)
    print('=' * 79)
    print('Bumping position 0')
    print('-' * 79)
    ver_new = bump_version(ver_str, 0)
    print('Version new: %r' % ver_new)
    print('-' * 79)
    print('Version string: %r' % ver_str)
    print('-' * 79)
    print('Bumping position 1')
    print('-' * 79)
    ver_new = bump_version(ver_str, 1)

# Generated at 2022-06-11 22:35:02.912743
# Unit test for function bump_version
def test_bump_version():
    # Patch function sleep()
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('time.sleep') as patch_sleep:

        from flutils import _testinghelpers

        # ---------------------------
        # -- Patch pylint messages --
        # ---------------------------
        patch_sleep.return_value = True

        # noinspection PyUnresolvedReferences
        def _showWarning(
                message: str,
                category: Any,
                filename: str,
                lineno: int,
                file: Any = None,
                line: Optional[str] = None
        ) -> None:
            """Patch for pylint false positive error messages.

            *New in version 0.3*

            """

# Generated at 2022-06-11 22:35:14.128165
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=C0111
    """Unit test"""
    import pytest
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:35:26.160300
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version. """
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:35:35.407115
# Unit test for function bump_version
def test_bump_version():
    """Test module function ``bump_version``."""

    from sys import version_info

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=-3) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'