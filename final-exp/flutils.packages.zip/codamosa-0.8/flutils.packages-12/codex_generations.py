

# Generated at 2022-06-11 22:25:54.601818
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:06.871907
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-branches
    from flutils.packages import bump_version
    from flutils.testing import capture_stdout
    from flutils.testing import unittest_refresh
    from flutils.testing import unittest_reload

    unittest_reload = unittest_refresh(unittest_reload)

    # noinspection PyUnusedLocal
    def _call_func(
            version: str,
            position: Optional[int] = None,
            prerelease: Optional[str] = None
    ) -> Tuple[str, Any]:
        with capture_stdout() as (out, err):
            if (position is None or prerelease is None) is False:
                return bump_version(version, position, prerelease), None

# Generated at 2022-06-11 22:26:17.636790
# Unit test for function bump_version
def test_bump_version():  # noqa pylint: disable=missing-function-docstring
    from flutils.tests.utils import check_output

    def _check_bump_version(v, p, pr, e):
        out = bump_version(v, p, pr)
        check_output(out, e)

    _check_bump_version('1.2.3', 2, None, '1.2.4')
    _check_bump_version('1.2.4', 1, None, '1.3')
    _check_bump_version('1.3.4', 0, None, '2.0')
    _check_bump_version('1.2.3', 2, 'a', '1.2.4a0')

# Generated at 2022-06-11 22:26:27.689883
# Unit test for function bump_version

# Generated at 2022-06-11 22:26:36.182748
# Unit test for function bump_version
def test_bump_version():
    """Unit test for ``bump_version``.

    """
    print('Testing bump_version()')

# Generated at 2022-06-11 22:26:47.761646
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:01.011732
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

    # pylint: disable=unnecessary-lambda

# Generated at 2022-06-11 22:27:05.777437
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function."""

    from random import randrange

    from flutils.packages import bump_version

    version = '1.2.3'
    result = bump_version(version)
    assert result == '1.2.4'

    version = '1.2.3'
    result = bump_version(version, 1)
    assert result == '1.3'

    version = '1.3.4'
    result = bump_version(version, 0)
    assert result == '2.0'

    version = '1.2.3'
    result = bump_version(version, pre_release='a')
    assert result == '1.2.4a0'

    version = '1.2.4a0'
    result = bump_version(version, pre_release='a')

# Generated at 2022-06-11 22:27:16.989329
# Unit test for function bump_version
def test_bump_version():
    """Tests for function bump_version.

    :return:
        ``None``
    """
    from flutils._testing import skip_on_travis_ci
    from flutils.packages import bump_version as _bump_version

    skip_on_travis_ci('No need to test on Travis CI.')


# Generated at 2022-06-11 22:27:29.515242
# Unit test for function bump_version

# Generated at 2022-06-11 22:27:57.097652
# Unit test for function bump_version
def test_bump_version():
    """ Ensure bump_version() works as expected """
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:28:06.521860
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:13.797934
# Unit test for function bump_version
def test_bump_version():
    from datetime import datetime
    from flutils.tests.helpers import (
        log_setup,
        TODO,
    )
    from flutils.textutils import exctype_errmsg
    from flutils.packages import bump_version, ScriptInfo
    from os import getcwd
    from os.path import dirname, join
    from sys import exit, exc_info
    from textwrap import dedent

    here = dirname(__file__)
    log_setup(join(here, 'test_bump_version.log'))

    info = ScriptInfo(__file__)
    info.load(join(here, 'test_bump_version.yaml'))

    assert bump_version('1.2.1') == '1.2.2'

# Generated at 2022-06-11 22:28:22.712517
# Unit test for function bump_version
def test_bump_version():
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')
    assert ver == '1.2.4b0'

# Generated at 2022-06-11 22:28:32.819274
# Unit test for function bump_version
def test_bump_version():

    def _some_test(ver: str, pos: int, pre: Optional[str]) -> str:
        return bump_version(ver, pos, pre)

    # We are not using tox since tox is being used to test the entire
    # package.
    #
    # This is only being used to see if the unit test works.
    out = _some_test('1.2.2', 2, None)
    assert out == '1.2.3'
    out = _some_test('1.2.3', 1, None)
    assert out == '1.3'
    out = _some_test('1.3.4', 0, None)
    assert out == '2.0'
    out = _some_test('1.2.3', 2, 'a')

# Generated at 2022-06-11 22:28:44.427896
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:57.237933
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:06.684609
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump

# Generated at 2022-06-11 22:29:11.251472
# Unit test for function bump_version
def test_bump_version():
    '''Unit test for function `bump_version`.'''
    # TODO: Add unit test for function bump_version
    pass


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:29:14.338485
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('2.0.0') == '2.0.1'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:29:38.160906
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function."""
    from itertools import product
    from flutils.packages import bump_version
    from functools import reduce

    def build_product(*args):
        return list(product(*args))

    def build_all_versions(
            versions: List[str],
            positions: List[int] = [2],
            pre_releases: List[Optional[str]] = [None]
    ) -> List[Tuple[str, int, str, str]]:
        return [
            (
                v, p, pr, bump_version(v, p, pr)
            )
            for v, p, pr in build_product(
                versions, positions, pre_releases
            )
        ]


# Generated at 2022-06-11 22:29:46.527744
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the :func:`bump_version <flutils.packages.bump_version>`
    function.  This function is a unit test for the
    :func:`bump_version <flutils.packages.bump_version>` function.
    """
    from flutils.packages import bump_version
    from sys import modules

    from pytest import mark, raises

    module = modules[__name__]

# Generated at 2022-06-11 22:29:57.087637
# Unit test for function bump_version
def test_bump_version():
    import sys
    import unittest
    from unittest import mock

    from flutils.packages import bump_version
    from flutils.helpers import env

    # pylint: disable=W0105

# Generated at 2022-06-11 22:30:07.374624
# Unit test for function bump_version

# Generated at 2022-06-11 22:30:17.739290
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    See also:
        * :func:`bump_version`

    """
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "version",
        action='store',
        type=str,
        help="The version you want to bump"
    )
    parser.add_argument(
        "-p",
        "--position",
        action='store',
        type=int,
        default=2,
        help="The position (starting with zero) of the version number "
             "component to be increased."
    )

# Generated at 2022-06-11 22:30:26.065183
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    def run_test(version, position, pre_release, expected):
        assert bump_version(version, position, pre_release) == expected

    run_test('1.2.2', position=1, pre_release='a', expected='1.3a0')
    run_test('1.2.2', position=1, pre_release='b', expected='1.3b0')
    run_test('1.2.4a1', position=1, pre_release='b', expected='1.3b0')
    run_test('1.2.4b0', position=1, pre_release='a', expected='1.3a0')

# Generated at 2022-06-11 22:30:35.619871
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
            self.assertEqual(
                bump_version('1.2.4a0', pre_release='a'), '1.2.4a1'
            )

# Generated at 2022-06-11 22:30:44.510233
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""

    def _bump_version_test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        """Helper function for bump_version tests."""

        result = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert result == expected, (
            "The version number, {}, was not successfully bumped.  Got "
            "({}) instead of expected ({}).".format(version, result, expected)
        )

    #  Basic tests
    _bump_version_test(version='1.2.2', position=2, pre_release='',
                       expected='1.2.3')

# Generated at 2022-06-11 22:30:57.406613
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function.

    .. versionadded:: 0.3

    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.1'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:31:06.727656
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    #: :type: any
    """
    >>> test_bump_version()
    True
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_

# Generated at 2022-06-11 22:31:23.970665
# Unit test for function bump_version

# Generated at 2022-06-11 22:31:31.708163
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

# Generated at 2022-06-11 22:31:40.022951
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:31:51.394474
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version.
    """

    print('Running unit tests for function: bump_version.')


# Generated at 2022-06-11 22:32:02.906649
# Unit test for function bump_version

# Generated at 2022-06-11 22:32:15.709243
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for function bump_version."""
    # pylint: disable=W0212
    # noinspection PyUnresolvedReferences
    from flutils.packages import _BUMP_VERSION_MAJOR, _BUMP_VERSION_MINOR
    # noinspection PyUnresolvedReferences
    from flutils.packages import _BUMP_VERSION_PATCH
    # noinspection PyUnresolvedReferences
    from flutils.packages import _BUMP_VERSION_PATCH_ALPHA

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', 0) == '2.0'
    assert bump_version('1.2.3', 1) == '1.3'

# Generated at 2022-06-11 22:32:28.423269
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:35.787440
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the :class:`flutils.packages.bump_version` function."""

# Generated at 2022-06-11 22:32:47.288956
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from flutils.packages import bump_version
    print(bump_version('1.2.3'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', pre_release='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))

# Generated at 2022-06-11 22:32:51.870567
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the function: ``bump_version()``"""
    from flutils.packages import bump_version

    version = '1.2.2'
    out = bump_version(version)
    assert(out == '1.2.3'), out

    version = '1.2.3'
    out = bump_version(version, position=1)
    assert(out == '1.3'), out

    version = '1.3.4'
    out = bump_version(version, position=0)
    assert(out == '2.0'), out

    version = '1.2.3'
    out = bump_version(version, prerelease='a')
    assert(out == '1.2.4a0'), out

    version = '1.2.4a0'

# Generated at 2022-06-11 22:33:19.489629
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version."""
    # pylint: disable=W0612,W0613
    out_check: List[Tuple[str, str, Optional[str], str]] = []
    in_args: List[Tuple[str, int, Optional[str]]] = []
    in_args.append(('1.2.3', 2, None))
    in_args.append(('1.2.3', 1, None))
    in_args.append(('1.2.3', 0, None))
    in_args.append(('1.2.3', 2, None))
    in_args.append(('1.2.4a0', 2, 'a'))
    in_args.append(('1.2.4a1', 2, 'a'))
    in_args

# Generated at 2022-06-11 22:33:31.384921
# Unit test for function bump_version
def test_bump_version():
    """Tests for the function: bump_version."""
    # noinspection PyShadowingNames
    def _bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        return bump_version(version, position, pre_release)

    assert _bump_version('1.2.2') == '1.2.3'
    assert _bump_version('1.2.3', position=1) == '1.3'
    assert _bump_version('1.3.4', position=0) == '2.0'
    assert _bump_version('1.2.3', prerelease='a') == '1.2.4a0'

# Generated at 2022-06-11 22:33:38.374076
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:50.314487
# Unit test for function bump_version
def test_bump_version():
    """
    Test for function bump_version
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-11 22:33:58.162083
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:11.130984
# Unit test for function bump_version
def test_bump_version():
    """Tests function 'bump_version'."""
    from unittest.mock import patch

    from flutils.packages import _BUMP_VERSION_MAJOR
    from flutils.packages import _BUMP_VERSION_MINOR
    from flutils.packages import _BUMP_VERSION_PATCH

    with patch('flutils.packages.StrictVersion') as mock_sv:
        inst = mock_sv.return_value
        inst.version = (1, 2, 3)
        inst.prerelease = None
        exp = '1.2.3'
        out = bump_version('1.2.1')
        assert exp == out

        exp = '1.2.3'
        out = bump_version('1.2.3')
        assert exp == out

        exp = '1.3'
        out = bump

# Generated at 2022-06-11 22:34:23.133857
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
            self.assertEqual(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-11 22:34:37.376472
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version function."""
    # noinspection PyDictCreation

# Generated at 2022-06-11 22:34:48.342307
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:35:00.031596
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    import os

    os.environ['FLUTILS_PACKAGES_VERSION'] = '1.1.1a0'

    # Functions to test
    def _test_bump_version(
            version: str,
            position: int,
            pre_release: str,
            should_be: str
    ) -> None:
        out = bump_version(version, position, pre_release)
        assert out == should_be, (
            "The given value for 'version', %r, 'position', %r, and "
            "'pre_release', %r, should be, %r; got %r." % (
                version, position, pre_release, should_be, out
            )
        )

    # Begin tests

# Generated at 2022-06-11 22:35:28.269657
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version
    with pytest.raises(ValueError, match='.*only the \'minor\' or \'patch\' parts.*'):
        bump_version('1.2.3', position=0, pre_release='a')
    with pytest.raises(ValueError, match='.*invalid version number.*'):
        bump_version('invalid_version')
    with pytest.raises(ValueError, match='.*invalid version number.*'):
        bump_version('1.0.0a2.2')
    with pytest.raises(ValueError, match='.*invalid version number.*'):
        bump_version('1.0.0alpha')