

# Generated at 2022-06-11 22:25:58.937553
# Unit test for function bump_version
def test_bump_version():
    """
    py.test
        -s
        --cov=flutils.packages
        --cov-report=term
        --cov-report=html
        --cov-report=xml:coverage.xml
        --cov-fail-under=100
        -p no:cacheprovider
        --strict
        tests/unit/packages/test_bump_version.py
    """
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

# Generated at 2022-06-11 22:26:04.590417
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version.
    """
    from flutils.packages import bump_version
    import pytest

    version = '1.2.0'
    position = 0
    pre_release = None
    with pytest.raises(ValueError):
        bump_version(version, position, pre_release)

# Generated at 2022-06-11 22:26:14.577053
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'."""

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:26:22.751817
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for the bump_version function."""
    # pylint: disable=line-too-long

# Generated at 2022-06-11 22:26:34.029421
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3*

    """
    from flutils.packages import bump_version
    if bump_version('1.2.3') != '1.2.3':
        raise AssertionError("Failed on: '1.2.3'")
    if bump_version('1.2.3', position=1) != '1.3':
        raise AssertionError("Failed on: '1.2.3', position=1")
    if bump_version('1.3.4', position=0) != '2.0':
        raise AssertionError("Failed on: '1.3.4', position=0")
    if bump_version('1.2.3', prerelease='a') != '1.2.4a0':
        raise Ass

# Generated at 2022-06-11 22:26:46.694503
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""
    from . import TestCase

# Generated at 2022-06-11 22:27:00.247954
# Unit test for function bump_version
def test_bump_version():
    """Unit test for test_bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:27:11.021314
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    msg_fail = 'bump_version result %r not equal to %r'
    assert bump_version('1.2.2') == '1.2.3', msg_fail % ('1.2.3', '1.2.3')
    assert bump_version('1.2.3', position=1) == '1.3', msg_fail % (
        '1.3', '1.3'
    )
    assert bump_version('1.3.4', position=0) == '2.0', msg_fail % (
        '2.0', '2.0'
    )

# Generated at 2022-06-11 22:27:20.304267
# Unit test for function bump_version
def test_bump_version():
    """Test :func:`flutils.packages.bump_version`."""
    # pylint: disable=W0621

    from .tests import (
        assert_exception,
        assert_exception_message,
        assert_regex,
    )

    # Exceptions
    test_exception_message = (
        "The given value for 'position', %r, must be an 'int' "
        "between (%r) and (%r)." % (-4, -3, 2)
    )

    # Insertion
    assert_exception(ValueError, bump_version, '1.2.3', position=3)
    assert_exception(ValueError, bump_version, '1.2.3', position=14)

# Generated at 2022-06-11 22:27:31.847580
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:08.934369
# Unit test for function bump_version
def test_bump_version():
    from click.testing import CliRunner

    runner = CliRunner(mix_stderr=False)
    result = runner.invoke(
        bump_version,
        ('1.2.2',),
        catch_exceptions=False
    )
    assert result.exit_code == 0
    assert result.exception is None
    assert result.output == '1.2.3\n'

    result = runner.invoke(
        bump_version,
        ('1.2.2', '-p', '1'),
        catch_exceptions=False
    )
    assert result.exit_code == 0
    assert result.exception is None
    assert result.output == '1.3\n'


# Generated at 2022-06-11 22:28:18.407954
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:29.740912
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:42.638083
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-locals
    import random
    version_list = [
        '1.2.0a0',
        '1.2.0a1',
        '1.2.0b0',
        '1.2.0b1',
        '1.2.0',
        '1.2.1',
        '1.2.3a0',
        '1.2.3a1',
        '1.2.3b0',
        '1.2.3b1',
        '1.2.2',
        '1.2.4',
    ]

# Generated at 2022-06-11 22:28:46.226124
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    """
    import pytest
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=0, prerelease='a')
    with pytest.raises(ValueError):
        bump_version('1.2.3', prerelease='x')


test_bump_version()

# Generated at 2022-06-11 22:28:58.473981
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=missing-docstring, no-self-use
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
   

# Generated at 2022-06-11 22:29:06.800175
# Unit test for function bump_version
def test_bump_version():
    """ For testing function 'bump_version'
    """
    print('Testing function: bump_version')

    # Testing with: '1.2.2'
    print('\nTesting with: 1.2.2')
    _version = '1.2.2'
    _position = 2
    _prerelease = None
    _output = bump_version(_version, _position, _prerelease)
    print('input: %r | position: %r | pre_release: %r | output: %r' % (
        _version, _position, _prerelease, _output)
    )
    assert _output == '1.2.3'

    # Testing with: '1.2.3'
    print('\nTesting with: 1.2.3')
    _version = '1.2.3'
    _position

# Generated at 2022-06-11 22:29:17.276205
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from .compat import reduce
    from .compat import TrueFunc

    # Simple major bump

# Generated at 2022-06-11 22:29:27.690928
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """

# Generated at 2022-06-11 22:29:38.921988
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version"""
    from flutils.packages import bump_version

    def get_test_version(
            base_major: int,
            base_minor: int,
            base_patch: int,
            pre_release_type: Optional[str] = None,
            pre_release_number: int = 0
    ) -> str:
        base_version: List[int] = [
            base_major,
            base_minor,
            base_patch
        ]
        if pre_release_type is not None:
            base_version.append(pre_release_type)
            base_version.append(pre_release_number)
        return '.'.join(map(str, base_version))

    #
    test_cases: List[Tuple[str, int, Optional[str], str]]

# Generated at 2022-06-11 22:29:56.277560
# Unit test for function bump_version
def test_bump_version():
    # Start unit testing
    from flutils.packages import bump_version
    from flutils.packages import get_package_name
    
    # Helper function
    def compare_version(
            ver_string: str,
            pos: int,
            pre: Union[str, None],
            expected: str,
    ):
        ver = bump_version(ver_string, position=pos, pre_release=pre)
        assert ver == expected, (
            '%s produces an incorrect version number: %s.' % (
                ver_string,
                ver
            )
        )

    # Get the version number to be bumped
    ver_string = get_package_name(__name__).split('.')[-1]
    ver_info = _build_version_info(ver_string)
    # Test the version number
    compare_

# Generated at 2022-06-11 22:30:06.735230
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-11 22:30:17.316533
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4', bump_version('1.2.3')
    assert bump_version('1.2.3', position=1) == '1.3', \
        bump_version('1.2.3', position=1)
    assert bump_version('1.3.4', position=0) == '2.0', \
        bump_version('1.3.4', position=0)
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0', \
        bump_version('1.2.3', prerelease='a')

# Generated at 2022-06-11 22:30:25.911414
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    """
    from datetime import datetime

    from flutils.packages import bump_version

    func_name = 'bump_version'

# Generated at 2022-06-11 22:30:35.376792
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914
    """Function to unit test function 'bump_version'.

    *New in version 0.3*

    """
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.pre_pos == -1
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '3'

    ver_info = _build_version_info('1.2.3a4')
    assert ver_info.version == '1.2.3a4'
    assert ver_info.pre_pos == 2
    assert ver_info.major.txt == '1'
    assert ver_info

# Generated at 2022-06-11 22:30:44.365229
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0612
    import sys
    import os.path
    if sys.platform.startswith('win'):
        # Tests require this env var to be set to run.
        os.environ['LOCALAPPDATA'] = \
            'C:\\Users\\%s\\AppData\\Local' % os.getlogin()
    # noinspection PyPackageRequirements
    import pytest
    # noinspection PyPackageRequirements
    import hypothesis.strategies as st
    # noinspection PyPackageRequirements
    from hypothesis import given

    @given(st.text())
    def _try(version):
        """Test bumping a version that should raise a ValueError."""
        with pytest.raises(ValueError):
            bump_version(version)

    _try()

# Generated at 2022-06-11 22:30:57.266358
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:06.639580
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

# Generated at 2022-06-11 22:31:08.460539
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function ``bump_version``."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:31:20.354156
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:34.758251
# Unit test for function bump_version
def test_bump_version():
    """Unit-test for function ``bump_version``."""
    from flutils.textutils import rand_str

    def _build_version_bump(version: str, position: int) -> str:
        return bump_version(version, position)

    def _build_version_bump_pre(
            version: str,
            position: int,
            pre_release: str
    ) -> str:
        return bump_version(version, position, pre_release)

    # Make sure the format 'major' section of the version number and is an
    # integer.
    assert _build_version_bump('1.2.3', position=0) == '2.0'
    assert _build_version_bump('1.2.3', position=1) == '1.3'

    # Test the pre-release words

# Generated at 2022-06-11 22:31:47.796054
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    out = bump_version('1.2.2')
    assert out == '1.2.3'
    out = bump_version('1.2.3', position=1)
    assert out == '1.3'
    out = bump_version('1.3.4', position=0)
    assert out == '2.0'
    out = bump_version('1.2.3', prerelease='a')
    assert out == '1.2.4a0'
    out = bump_version('1.2.4a0', pre_release='a')
    assert out == '1.2.4a1'
    out = bump_version('1.2.4a1', pre_release='b')
    assert out == '1.2.4b0'
   

# Generated at 2022-06-11 22:31:54.856868
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:04.368188
# Unit test for function bump_version
def test_bump_version():
    """Unit tests function bump_version"""

    rtn = bump_version('1.2.2')
    assert rtn == '1.2.3'

    rtn = bump_version('1.2.3', position=1)
    assert rtn == '1.3'

    rtn = bump_version('1.3.4', position=0)
    assert rtn == '2.0'

    rtn = bump_version('1.2.3', prerelease='a')
    assert rtn == '1.2.4a0'

    rtn = bump_version('1.2.4a0', pre_release='a')
    assert rtn == '1.2.4a1'

    rtn = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-11 22:32:15.922315
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class Testbump_version(unittest.TestCase):
        def runTest(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
            self.assertEqual(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-11 22:32:28.656716
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""


# Generated at 2022-06-11 22:32:35.926897
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3.5*

    Examples:
        >>> from flutils.packages import test_bump_version
        >>> test_bump_version()  # doctest: +ELLIPSIS
        Running unit tests for function bump_version...
        ...

    """
    from unittest import TestCase
    from unittest.mock import Mock
    from unittest.mock import patch
    import doctest
    import os
    import sys
    import warnings

    class TestClass(TestCase):
        """Unit test class for function bump_version."""

        def setUp(self):
            """Set up test."""
            super().setUp()
            self._warnings_store = warnings.filters[:]


# Generated at 2022-06-11 22:32:47.393474
# Unit test for function bump_version
def test_bump_version():
    """Validate the bump_version function."""


# Generated at 2022-06-11 22:32:53.435691
# Unit test for function bump_version
def test_bump_version():
    """
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:03.133622
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:33:15.327467
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:20.333889
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump version function"""
    # pylint: disable=W0613
    def _assert_version(
            version_in: str,
            position: int,
            pre_release: str,
            version_out: str
    ) -> None:
        version = bump_version(version_in, position, pre_release)
        assert version == version_out

    _assert_version('1.2.2', 2, None, '1.2.3')
    _assert_version('1.2.3', 1, None, '1.3')
    _assert_version('1.3.4', 0, None, '2.0')
    _assert_version('1.2.3', 2, 'a', '1.2.4a0')

# Generated at 2022-06-11 22:33:32.001222
# Unit test for function bump_version
def test_bump_version():
    """SCons: ...
    """
    def do_test(version, position, pre_release) -> None:
        """Do the test.

        Args:
            version (str): The version number to be bumped.
            position (int, optional): The position (starting with zero) of the
                version number component to be increased.  Defaults to: ``2``
            pre_release (str, Optional): A value of ``a`` or ``alpha`` will
                create or increase an alpha version number.  A value of ``b`` or
                ``beta`` will create or increase a beta version number.

        """
        desc = 'version: "%s", position:' % version
        if position is None:
            desc += ' None'
        else:
            desc += ' %s' % position
        desc += ', pre_release:'

# Generated at 2022-06-11 22:33:38.665014
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0201
    def _test_bump(
            version: str,
            expected: str,
            position: int = 0,
            pre_release: Optional[str] = None,
    ):
        actual = bump_version(version, position, pre_release)
        assert actual == expected

        # Test pre-release to non-pre-release
        if pre_release is not None:
            _test_bump(
                actual,
                '.'.join(map(str, expected.split('.')[:2])),
                position=position
            )

    _test_bump('1.2.3', '1.2.4')
    _test_bump('1.2.3', '2.0', position=0)

# Generated at 2022-06-11 22:33:50.582748
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``

    Args:
        None

    Returns:
        None

    """
    #
    # test_bump_version_patch_to_minor
    #
    for i in range(1, 20):
        version = '1.0.%s' % i
        out = '1.1'
        actual = bump_version(version, position=1)
        assert out == actual, "Failed: %s to %s" % (
            version, out
        )
    #
    # test_bump_version_patch_to_minor
    #
    for i in range(1, 20):
        version = '1.0.%s' % i
        out = '1.1.0'

# Generated at 2022-06-11 22:34:00.952877
# Unit test for function bump_version
def test_bump_version():
    """ Test function bump_version. """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:12.649966
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from pprint import pprint
    from itertools import product


# Generated at 2022-06-11 22:34:23.680283
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.testing import runtests

# Generated at 2022-06-11 22:34:37.487051
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function.

    """
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """The ``TestBumpVersion`` class.

        """
        def test_version_basic(self):
            """Test version bumping on basic version numbers.

            """
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

        def test_version_pre_release(self):
            """Test version bumping on pre-release version numbers.

            """

# Generated at 2022-06-11 22:34:44.135679
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'
    version = '1.2.3'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'
    assert bump_version(version, pre_release='b')

# Generated at 2022-06-11 22:35:02.013746
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import _VersionPart, _build_version_bump_position
    from flutils.packages import _build_version_bump_type, bump_version

    ver_part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    res = bump_version(
        '1.2.3',
        position=ver_part.pos,
        pre_release=ver_part.pre_txt,
    )
    assert res == '2.0'


# Generated at 2022-06-11 22:35:13.432611
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import sys
    from os import path as op
    sys.path.insert(0, op.abspath(op.join(op.dirname(__file__), '..')))
    from flutils.packages import bump_version

    class BumpVersionTestCase(unittest.TestCase):
        class TestException(Exception):
            pass

        def setUp(self):
            self._startTime = time.time()

        def tearDown(self):
            t = time.time() - self._startTime
            print('%s: %.3f' % (self.id(), t))

        def test__bump_version(self):
            # Simple version bump
            version = '1.2.2'
            self.assertEqual(bump_version(version), '1.2.3')

# Generated at 2022-06-11 22:35:26.009966
# Unit test for function bump_version

# Generated at 2022-06-11 22:35:35.544283
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'