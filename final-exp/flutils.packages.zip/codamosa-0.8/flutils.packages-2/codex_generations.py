

# Generated at 2022-06-11 22:25:56.562282
# Unit test for function bump_version
def test_bump_version():
    # from flutils.packages import (
    #     bump_version
    # )
    from .test import base as test_base
    # from .test import utils as test_utils

    test_func = bump_version

    # noinspection PyUnusedLocal
    def test_method(*args, **kwargs):
        """Unit test method for bump_version."""
        out = test_func(*args, **kwargs)
        return out


# Generated at 2022-06-11 22:26:04.146338
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from itertools import product
    from functools import partial

    def test_version_number(o_v, b_v, p, pr):
        return bump_version(o_v, position=p, pre_release=pr) == b_v

    def test_version_number_ex(o_v, ex_type, p, pr):
        try:
            bump_version(o_v, position=p, pre_release=pr)
        except ex_type:
            return True
        return False


# Generated at 2022-06-11 22:26:11.546195
# Unit test for function bump_version
def test_bump_version():

    from flutils.packages import bump_version

    # noinspection PyTypeChecker
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'


# Generated at 2022-06-11 22:26:13.478033
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)

# Generated at 2022-06-11 22:26:22.312901
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version()`` function.

    Examples:
        >>> from flutils.packages import bump_version
        >>> test_bump_version()

    """
    import sys
    from flutils.logging import setup_logging
    from flutils.pkgutils import get_package_version
    from flutils.testing import init_test

    def _do_test():
        settings = init_test()
        setup_logging(settings[0])
        for x in range(0, 3):
            if x == 0:
                old_ver = get_package_version('flutils')
                new_ver = bump_version(old_ver)
            elif x == 1:
                old_ver = new_ver
                new_ver = bump_version(old_ver)

# Generated at 2022-06-11 22:26:33.990522
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``."""
    major = '2.0.0'
    minor = '1.2.0'
    patch = '1.2.3'
    minor_alpha = '1.2a0'
    alpha = '1.2.3a0'
    minor_beta = '1.2b0'
    beta = '1.2.3b0'
    p_major = _build_version_bump_position(0)
    p_minor = _build_version_bump_position(1)
    p_patch = _build_version_bump_position(2)
    p_minor_n = _build_version_bump_position(-1)
    p_patch_n = _build_version_bump_position(-2)
    p_

# Generated at 2022-06-11 22:26:46.657052
# Unit test for function bump_version
def test_bump_version():
    """ Test the bump_version function.

          Test cases:
            #1 Test first position
            #2 Test middle position label
            #3 Test middle position number
            #4 Test middle position pre_release label
            #5 Test middle position pre_release number
            #6 Test last position
            #7 Test last position pre_release label
            #8 Test last position pre_release number
            #9 Test last position with zero pre_release number

          Results:
            0 failures

    """
    print('test_bump_version()')

# Generated at 2022-06-11 22:27:00.248150
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:11.020810
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # pylint: disable=R0914,R0915
    # Need to keep to validate inputs.
    #
    # noinspection PyUnresolvedReferences
    import flutils.packages
    from flutils.testhelpers import (
        ensure_raises,
        temp_dir,
        temp_file,
    )
    from textwrap import dedent

    #
    # Test 1
    #
    _test_version = '0.1'
    expect = '0.2'
    bump_version(_test_version, 1)
    res = bump_version(_test_version, 1)
    assert res == expect

    #
    # Test 2
    #
    _test_version = '0.2.3'
    expect = '0.2.4'


# Generated at 2022-06-11 22:27:20.274423
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:00.006999
# Unit test for function bump_version
def test_bump_version():
    """Unit test function for the function: :func:`bump_version`.

    *New in version 0.3*

    """
    import pytest  # pylint: disable=import-error

# Generated at 2022-06-11 22:28:08.038701
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    version = bump_version('1.2.2')
    assert version == '1.2.3'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'
   

# Generated at 2022-06-11 22:28:17.825796
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:24.145489
# Unit test for function bump_version
def test_bump_version():
    filename = 'bump_version.txt'
    with open(filename, 'rb') as openfh:
        lines = openfh.read().decode()
    lines = lines.splitlines()

    for line in lines:
        if line.startswith('#'):
            continue
        assert line == bump_version(line)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:28:33.174785
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    """Validate the bump_version() function."""
    def _inner(version, position, pre_release, expected):
        assert bump_version(
            version,
            position,
            pre_release
        ) == expected

    _inner(
        '1.2.2',
        2,
        None,
        '1.2.3'
    )
    _inner(
        '1.2.3',
        1,
        None,
        '1.3'
    )
    _inner(
        '1.3.4',
        0,
        None,
        '2.0'
    )
    _inner(
        '1.2.3',
        2,
        'a',
        '1.2.4a0'
    )

# Generated at 2022-06-11 22:28:44.466648
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    """Unit test for function bump_version."""
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:28:57.278787
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    References:
        * http://docs.python.org/library/unittest.html

    """
    import unittest

    class TestValues(unittest.TestCase):
        """Test function bump_version.

        References:
            * http://docs.python.org/library/unittest.html#class-and-module-fixtures

        """

        def setUp(self):
            """Set up each test."""

# Generated at 2022-06-11 22:29:06.815280
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4b0', pre_release='b') == '1.2.4b1'

# Generated at 2022-06-11 22:29:17.276804
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for ``bump_version``."""
    from flutils.pytest_helpers import func_helpers

# Generated at 2022-06-11 22:29:27.695092
# Unit test for function bump_version
def test_bump_version():
    '''
    Used to test the bump_version function.

    :return:
    Retuns nothing, but will raise an exception if the test fails.
    '''
    import pytest

    # Test that we can bump a basic version
    version = '0.1.1'
    assert bump_version(version) == '0.1.2'

    # Test that we can bump a minor version
    version = '0.1.1'
    assert bump_version(version, position=1) == '0.2'

    # Test that we can bump a major version
    version = '0.1.1'
    assert bump_version(version, position=0) == '1.0'

    # Test that we can bump an alpha version
    version = '0.1.1'

# Generated at 2022-06-11 22:29:47.754836
# Unit test for function bump_version
def test_bump_version():
    """Run the unit tests for function ``bump_version``."""
    # pylint: disable=C0103,C0111,C0103
    import doctest
    opts = (doctest.ELLIPSIS |
            doctest.NORMALIZE_WHITESPACE |
            doctest.REPORT_ONLY_FIRST_FAILURE)
    err, _ = doctest.testmod(
        optionflags=opts,
        verbose=True,
        name='bump_version',
        globs={
            'bump_version': bump_version,
        }
    )
    assert err == 0

# Generated at 2022-06-11 22:29:50.622251
# Unit test for function bump_version
def test_bump_version():
    version, position, pre_release, expected = bump_version_test_cases()
    out = bump_version(version, position, pre_release)
    assert out == expected


# Generated at 2022-06-11 22:29:59.569638
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:08.922168
# Unit test for function bump_version
def test_bump_version():
    print('Test: bump_version(..)')
    assert bump_version('1.2.2') == '1.2.3', '1.2.2 to 1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3', '1.2.3 to 1.3'
    assert bump_version('1.3.4', position=0) == '2.0', '1.3.4 to 2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0', '1.2.3 to 1.2.4a0'

# Generated at 2022-06-11 22:30:18.644118
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version'."""


# Generated at 2022-06-11 22:30:31.092180
# Unit test for function bump_version
def test_bump_version():
    """
    Just a way to unit test the function bump_version.
    """
    print()
    print('Testing bump_version()')
    print('======================')
    test_version = '1.2.2'
    print('  Testing version:', test_version)
    print('   Testing:', bump_version(test_version))
    print('   Testing:', bump_version(test_version, position=1))
    print('   Testing:', bump_version(test_version, position=2))
    print('   Testing:', bump_version(test_version, position=1, prerelease='a'))
    print('   Testing:', bump_version(test_version, position=1, prerelease='b'))

# Generated at 2022-06-11 22:30:41.291285
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    ver = '1.2.3'
    bumped = bump_version(ver)
    if bumped != '1.2.4':
        msg = 'The version number did not get bumped as expected.'
        raise RuntimeError(msg)

    bumped = bump_version(ver, position=1)
    if bumped != '1.3':
        msg = 'The minor version number did not get bumped as expected.'
        raise RuntimeError(msg)

    bumped = bump_version(ver, position=0)
    if bumped != '2.0':
        msg = 'The major version number did not get bumped as expected.'
        raise RuntimeError(msg)

    ver = '1.2.3'
    bumped = bump_version(ver, pre_release='a')

# Generated at 2022-06-11 22:30:53.314558
# Unit test for function bump_version
def test_bump_version():
    from flutils.testhelpers import (
        assert_in,
        assert_equal,
        assert_not_equal,
        assert_gt,
        assert_true,
        assert_false,
        assert_raises,
        assert_not_raises,
    )

    def _test_bump_version_type(ver: str):
        assert_raises(
            ValueError,
            bump_version,
            ver
        )
        assert_raises(
            ValueError,
            bump_version,
            ver,
            position=3
        )

    with assert_raises(ValueError):
        bump_version('1.2.3', position=-4)
    with assert_raises(ValueError):
        bump_version('1.2.3', position=3)

    _test_bump

# Generated at 2022-06-11 22:31:04.250428
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:17.126873
# Unit test for function bump_version
def test_bump_version():
    """Run a unit test on the bump_version function.

    Returns:
        bool:

            * :obj:`True` if all tests pass.
            * :obj:`False` if one or more tests fail.

    """
    import unittest
    import sys
    from io import StringIO
    from unittest.mock import patch
    from logging import getLogger

    log = getLogger(__name__)

    class Test(unittest.TestCase):
        def test_init(self):
            self.assertIsNotNone(bump_version('1.3.4'))
            self.assertIsNotNone(
                bump_version('1.2.0', pre_release='a')
            )


# Generated at 2022-06-11 22:31:34.565073
# Unit test for function bump_version
def test_bump_version():
    """Test for the bump_version function"""
    # pylint: disable=R0914
    # pylint: disable=C0103

# Generated at 2022-06-11 22:31:40.942048
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version' in module 'flutils.packages'.

    :return:
        * ``True`` if all the tests pass.
        * ``False`` if the tests fail.

    """
    from flutils.packages import bump_version

    msg = 'Must be a package version string, got: %r'
    for vers in ('0', '0.1', '0.1.2', '0.1.2a0', '0.1.2b0'):
        if not isinstance(bump_version(vers), str):
            raise AssertionError(msg % vers)


# Generated at 2022-06-11 22:31:51.766106
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.testing import (
        assert_raises_from_error,
        ensure_str,
        ensure_str_no_space,
        is_in
    )
    from flutils.textutils import start_with_vowel
    from flutils.packages import bump_version

    allowed_pre_releases = ('a', 'alpha', 'b', 'beta')
    # noinspection PyUnusedLocal,PyShadowingNames

# Generated at 2022-06-11 22:32:03.143923
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3*

    """
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:32:08.152641
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:13.765619
# Unit test for function bump_version
def test_bump_version():
    """Run the unit test for function bump_version."""

    # Import standard modules
    import sys

    # Import local modules
    # sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'flutils')))
    from flutils.packages import bump_version

    # Import test modules
    from . import unitutils

    # Create a unit tester
    tester = unitutils.UnitTester()

    # Build a list of tuples of test cases.

# Generated at 2022-06-11 22:32:25.630818
# Unit test for function bump_version

# Generated at 2022-06-11 22:32:34.891250
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    from flutils.testhelpers import \
        assert_true, \
        assert_equal

    def t(version, position, pre_release, expected, description):
        # noinspection PyUnusedLocal
        e_str = 'assert_equal(bump_version(%r, position=%r, pre_release=%r),' \
            ' %r, %r)' % (
                version,
                position,
                repr(pre_release),
                expected,
                repr(description)
            )
        assert_equal(bump_version(version, position=position, pre_release=pre_release),
            expected, description)


# Generated at 2022-06-11 22:32:47.088574
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # pylint: disable=E1101

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:32:51.619223
# Unit test for function bump_version
def test_bump_version():
    # TODO: Include above examples as unit test
    from flutils.packages import bump_version
    import pytest


# Generated at 2022-06-11 22:33:04.644355
# Unit test for function bump_version
def test_bump_version():

    from sys import version_info
    from time import time

    from flutils.packages import bump_version

    # Test for function bump_version

    print('Testing the function bump_version.')

    start_time = time()


# Generated at 2022-06-11 22:33:15.103579
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:20.822610
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyProtectedMember
    mod = sys.modules[__name__]
    print("Testing function [bump_version]")
    func = mod.bump_version
    old = '1.2.3'
    new = '1.2.4'
    assert func(old) == new, "Functions do not match!"
    print("Testing passed!")

# Generated at 2022-06-11 22:33:32.289817
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    """
    from flutils.testing import run_with_coverage

    print('Testing function bump_version ...')

# Generated at 2022-06-11 22:33:38.759311
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:50.664367
# Unit test for function bump_version
def test_bump_version():
    print('Testing function bump_version')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:58.318847
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    # noinspection PyUnresolvedReferences
    """
    :type orig_version: str
    :type expected: str
    :type err: bool
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:34:02.894820
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    """Unit test for function bump_version."""
    import pytest  # pylint: disable=import-outside-toplevel

    from flutils.packages import bump_version


# Generated at 2022-06-11 22:34:13.755444
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import suppress_stdout

    with suppress_stdout():
        # pylint: disable=protected-access
        assert bump_version('1.2.2') == '1.2.3'
        assert bump_version('1.2.3', position=1) == '1.3'
        assert bump_version('1.3.4', position=0) == '2.0'
        assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
        assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
        assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:34:24.359986
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'."""

# Generated at 2022-06-11 22:34:40.856723
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version()."""
    try:
        bump_version('2')
    except ValueError as err:
        assert isinstance(err, ValueError)
        try:
            bump_version('2.1')
        except ValueError as err:
            assert isinstance(err, ValueError)
            try:
                bump_version('1.2m')
            except ValueError as err:
                assert isinstance(err, ValueError)
                try:
                    bump_version('1.2.3.4')
                except ValueError as err:
                    assert isinstance(err, ValueError)
                    try:
                        bump_version('1.2.3', position=-4, pre_release='A')
                    except ValueError as err:
                        assert isinstance(err, ValueError)

# Generated at 2022-06-11 22:34:49.825737
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0')

# Generated at 2022-06-11 22:35:01.436085
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``."""
    from . import _utilities
    from . import _utilities as utils

# Generated at 2022-06-11 22:35:13.359943
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    # pylint: disable=too-many-locals

# Generated at 2022-06-11 22:35:25.979519
# Unit test for function bump_version
def test_bump_version():
    # Test the normal version bumping
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test the alpha version bumping
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'


# Generated at 2022-06-11 22:35:35.361653
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'