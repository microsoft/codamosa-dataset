

# Generated at 2022-06-11 22:25:55.459784
# Unit test for function bump_version
def test_bump_version():
    """Test ``flutils.packages.bump_version()``.

    .. versionadded:: 0.3

    """
    # pylint: disable=missing-docstring
    def _compare(
            arg1: Tuple[str, int, Optional[str]],
            version: str
    ) -> None:
        bump = bump_version(arg1[0], position=arg1[1], pre_release=arg1[2])
        assert bump == version, (
            "For (%r, %r, %r) expected (%r) not (%r)" % (
                arg1[0],
                arg1[1],
                arg1[2],
                version,
                bump,
            )
        )


# Generated at 2022-06-11 22:26:07.638247
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version.

    *New in version 0.3*

    """
    # fmt: off

# Generated at 2022-06-11 22:26:18.085636
# Unit test for function bump_version
def test_bump_version():
    from os import path

    from flutils.commonutils import get_module_functions
    from flutils.packages import get_local_package_version

    # noinspection PyUnresolvedReferences
    from . import __file__ as thisfile  # pylint: disable=E0611

    def get_test_version():
        basepath = path.abspath(path.dirname(path.join(path.normpath(thisfile))))
        modpath = path.abspath(path.join(basepath, path.normpath('__init__.py')))
        package_info = get_local_package_version(modpath)
        return package_info.version


# Generated at 2022-06-11 22:26:27.972528
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:36.391586
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:47.760534
# Unit test for function bump_version
def test_bump_version():
    import unittest
    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):

        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-11 22:26:50.833015
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-11 22:27:03.213972
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Test the function bump_version."""
    def _test(
            test_version: str,
            test_version_pos: int,
            test_version_pre: Optional[str],
            result_version: str,
    ):
        out = bump_version(
            test_version,
            position=test_version_pos,
            pre_release=test_version_pre
        )
        if out != result_version:
            raise ValueError(
                "The call to 'bump_version(%r, position=%r, "
                "pre_release=%r) did not return the expected result: "
                "%r" % (
                    test_version,
                    test_version_pos,
                    test_version_pre,
                    result_version,
                )
            )

   

# Generated at 2022-06-11 22:27:14.598754
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:26.759667
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('9.2.0') == '9.2.1'
    assert bump_version('9.2.2') == '9.2.3'
    assert bump_version('9.2.0', position=1) == '9.3'
    assert bump_version('9.2.2', position=1) == '9.3'
    assert bump_version('9.2.2', position=2) == '9.2.3'
    assert bump_version('9.2.2', position=0) == '10.0'
    assert bump_version('9.2.2', position=-1) == '9.2.3'
    assert bump_version('9.2.2', position=-2) == '9.3'

# Generated at 2022-06-11 22:27:53.169012
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version'."""
    import unittest
    import doctest
    import tempfile

    class TestBumpVersion(unittest.TestCase):
        """Test case for function 'bump_version'."""

        def test_bump_version(self):
            """Test function 'bump_version' in case:
            'bump_version'
            """

# Generated at 2022-06-11 22:28:03.239711
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0111
    # pylint: disable=R0914
    # pylint: disable=R0915
    # pylint: disable=W0106
    from flutils.packages import bump_version

    def run(case):
        print('\n')
        print('-' * 80)
        print(case.__doc__)
        print('INPUT:')
        print('version: {}'.format(case.version))
        print('position: {}'.format(case.position))
        print('prerelease: {}'.format(case.prerelease))
        print()
        out = bump_version(
            case.version,
            position=case.position,
            pre_release=case.prerelease
        )
        print('OUTPUT:')

# Generated at 2022-06-11 22:28:09.636498
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import unittest
    import sys
    from unittest.mock import patch

    # noinspection PyUnresolvedReferences
    from flutils.packages import bump_version as function

    get_traceback_patch = patch('traceback.print_exc', autospec=True)
    with get_traceback_patch as print_exc:
        get_traceback_patch = patch('traceback.print_tb', autospec=True)
        with get_traceback_patch as print_tb:
            print_exc.side_effect = print
            print_tb.side_effect = print
            runner = unittest.TextTestRunner(stream=sys.stderr)
            runner.run(unittest.makeSuite(TestVersionBumping))



# Generated at 2022-06-11 22:28:18.795545
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function: ``flutils.packages.bump_version()``"""
    try:
        import unittest2 as unittest  # pylint: disable=F0401
    except ImportError:
        import unittest  # pylint: disable=F0401

    class TestBumpVersion(unittest.TestCase):
        def test_basic(self):
            """Test basic functionality"""
            rv = bump_version('1.2.2')
            self.assertEqual(rv, '1.2.3')
            rv = bump_version('1.2.3', position=1)
            self.assertEqual(rv, '1.3')
            rv = bump_version('1.3.4', position=0)

# Generated at 2022-06-11 22:28:30.040801
# Unit test for function bump_version
def test_bump_version():
    from six.moves import unittest
    from flutils.packages import bump_version

    class TestUtils(unittest.TestCase):
        """Unit tests for the :class:`utils <flutils.utils.Utils>` class."""

        def setUp(self):
            """Called before each test."""
            pass

        def tearDown(self):
            """Called after each test."""
            pass

        def test_bump_version(self) -> None:
            """Tests for :obj:`bump_version <flutils.packages.bump_version>`."""
            self.assertEqual(
                bump_version(
                    '1.2.2'
                ),
                '1.2.3'
            )

# Generated at 2022-06-11 22:28:43.000988
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:55.662846
# Unit test for function bump_version
def test_bump_version():
    """Test bumping the version number when passed a version number string."""

    def _test(
            version: str,
            result: str,
            position: int,
            pre_release: Optional[str]
    ) -> None:
        assert bump_version(version, position, pre_release) == result

    # Test examples from the function docstring
    _test(version='1.2.2', result='1.2.3', position=2, pre_release=None)
    _test(version='1.2.3', result='1.3', position=1, pre_release=None)
    _test(version='1.3.4', result='2.0', position=0, pre_release=None)

# Generated at 2022-06-11 22:29:05.603736
# Unit test for function bump_version
def test_bump_version():

    import sys

    import flutils.packages

    from flutils.pyutils.testing import (
        call_test,
        helps_test,
        raises_test,
    )

    # Test for function bump_version
    if 1:
        helps_test(flutils.packages, 'bump_version')
        helps_test(flutils.packages.bump_version, 'version')
        helps_test(flutils.packages.bump_version, 'position')
        helps_test(flutils.packages.bump_version, 'prerelease')
        call_test(
            flutils.packages.bump_version('0.0.0'),
            '0.0.1',
            '0.0.1 - version:'
        )

# Generated at 2022-06-11 22:29:16.690039
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0903
    """Unit test for function bump_version."""

# Generated at 2022-06-11 22:29:27.529972
# Unit test for function bump_version
def test_bump_version():
    """ Tests function bump_version.

    """
    version = '1.2.3'

    assert bump_version(version) == '1.2.4'

    assert bump_version(version, position=1) == '1.3'

    assert bump_version(version, position=0) == '2.0'

    assert bump_version(version, pre_release='a') == '1.2.4a0'

    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

    assert bump_version('1.2.4a1') == '1.2.4'


# Generated at 2022-06-11 22:29:43.280368
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from pathlib import Path
    from ruamel.yaml import YAML
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from flutils.packages import bump_version

    class TestBumpVersion(TestCase):
        """Test the function bump_version."""

        def test_bump_version(self):
            """Test the function bump_version."""
            # Test with a single bump.
            with TemporaryDirectory() as _tmpdir:
                tmpdir: Path = Path(_tmpdir)
                yaml: YAML = YAML()
                yaml.explicit_start = True
                yaml.explicit_end = True
                yaml.indent(mapping=4)
                yaml.default_flow_style = False

                version_path

# Generated at 2022-06-11 22:29:55.231126
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.testing import UnitTester

    test = UnitTester(__file__)

    test.assert_equal(bump_version('1.2.2'), '1.2.3')
    test.assert_equal(bump_version('1.2.3', position=1), '1.3')
    test.assert_equal(bump_version('1.3.4', position=0), '2.0')
    test.assert_equal(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
    test.assert_equal(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-11 22:30:06.530506
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version function."""

    for version in (
        '1.2.4a0',
        '1.2.4a1',
        '1.2.4b0',
        '2.1.3',
        '1.2b0',
    ):
        bumped = bump_version(version)
        assert bumped

    # Test error conditions raised
    try:
        bump_version('foo.bar.baz')
    except ValueError:
        pass
    else:
        raise AssertionError("Should not have passed.")

    try:
        bump_version('1.2.3', position=-4)
    except ValueError:
        pass
    else:
        raise AssertionError("Should not have passed.")


# Generated at 2022-06-11 22:30:17.181567
# Unit test for function bump_version
def test_bump_version():
    """Test the function 'bump_version'.

    See: :py:mod:`~flutils.packages.bump_version`

    """
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:30:25.845290
# Unit test for function bump_version
def test_bump_version():
    """ Test the function ``bump_version``. """
    import pytest  # pylint: disable=import-error
    from flutils.packages import bump_version

    with pytest.raises(ValueError):
        bump_version('1.2.3', 0, 'a')

    with pytest.raises(ValueError):
        bump_version('1.2.3', 0, 'b')

    with pytest.raises(ValueError):
        bump_version('1.2.3', 0, 'c')

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_

# Generated at 2022-06-11 22:30:35.270811
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914,R0915
    from flutils.packages import bump_version

    def _assert_bump_result(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            result: str = None,
            to_raise: Any = None
    ) -> None:
        if to_raise is not None:
            try:
                bump_version(version, position, pre_release)
            except Exception as err:  # pylint: disable=W0703
                assert err == to_raise  # type: ignore
            else:
                raise AssertionError(
                    '%r should have raised.' % version
                )
            return
        assert bump_version(version, position, pre_release) == result

    _assert_bump

# Generated at 2022-06-11 22:30:44.305680
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:57.215197
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version()."""
    from random import randint
    from flutils.textutils import random_str

    def _build_random_version():
        """Generate a random version number."""
        major_version = randint(0, 10)
        minor_version = randint(0, 10)
        patch_version = randint(0, 10)
        return '{}.{}.{}'.format(
            major_version, minor_version, patch_version
        )

    def _test_bump_version(ver_str):
        """Run the function bump_version()."""

# Generated at 2022-06-11 22:31:06.621392
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    # pylint: disable=R0914

    module_name = globals()['__name__']
    this_module = sys.modules[module_name]
    this_module_name = this_module.__name__
    function_name = inspect.stack()[0][3]

    print('\nUnit test for "%s" in "%s"\n' % (function_name, this_module_name))


# Generated at 2022-06-11 22:31:19.141235
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for function bump_version
    """

# Generated at 2022-06-11 22:31:39.726672
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    ver = '2.3.4'
    pos = 2
    pre = None
    out = bump_version(ver, position=pos, pre_release=pre)
    exp = '2.3.5'
    assert out == exp, out

    ver = '2.3.0'
    pos = 2
    pre = None
    out = bump_version(ver, position=pos, pre_release=pre)
    exp = '2.3.1'
    assert out == exp, out

    ver = '2.3.4'
    pos = 0
    pre = None
    out = bump_version(ver, position=pos, pre_release=pre)
    exp = '3.0'
    assert out == exp, out


# Generated at 2022-06-11 22:31:51.295285
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the bump_version function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.2', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:32:02.840870
# Unit test for function bump_version
def test_bump_version():
    import json

    def test_func(
            i: int,
            input_version: str,
            position: int,
            pre_release: Optional[str],
            expected_result: str
    ) -> None:
        """Test the bump_version() function in the version_bump.py file."""
        actual_result = bump_version(
            input_version,
            position=position,
            pre_release=pre_release
        )
        assert actual_result == expected_result

    here = os.path.dirname(os.path.realpath(__file__))
    fn = os.path.join(
        here,
        'static',
        'version_bump_unit_tests.json'
    )

# Generated at 2022-06-11 22:32:15.709011
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:28.425086
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Tests for the position value
    assert bump_version('1.2.4') == '1.2.5'
    assert bump_version('1.2.4', position=1) == '1.3'
    assert bump_version('1.2.4', position=0) == '2.0'
    assert bump_version('1.2.4', position=2) == '1.2.5'
    assert bump_version('1.2.4', position=2) == '1.2.5'
    assert bump_version('1.2.4', position=3) == '1.2.5'
    assert bump_version('1.2.4', position=-1) == '1.2.5'

# Generated at 2022-06-11 22:32:38.460706
# Unit test for function bump_version
def test_bump_version():
    from warnings import warn
    from sys import version_info

    from flutils.testing import (
        suppress_warnings,
    )

    if version_info.major == 2:
        warn(
            "Skipping unit test of function bump_version due to it running "
            "on Python 2.",
            DeprecationWarning
        )
        return

    with suppress_warnings(category=DeprecationWarning):
        # Each of the following lines tests a section of the main function.
        # pylint: disable=E1103
        assert bump_version('1.2.2') == '1.2.3'
        assert bump_version('1.2.3', position=1) == '1.3'
        assert bump_version('1.3.4', position=0) == '2.0'
        assert bump_

# Generated at 2022-06-11 22:32:46.081830
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import (
        bump_version,
    )


# Generated at 2022-06-11 22:32:57.350084
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    for vtext in (
            None, '', '1.2', '1.2.3.4', 'a', 'a.b', '1.2.3b', '1.2.3a4b'
    ):
        try:
            bump_version(vtext)
        except Exception:
            pass
        else:
            raise AssertionError(
                "bump_version('%s') should raise an exception.  It did not."
                % vtext
            )
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'

# Generated at 2022-06-11 22:33:04.792705
# Unit test for function bump_version
def test_bump_version():
    """Unit test function for function bump_version."""

    from unittest import TestCase
    from unittest.mock import patch

    from flutils.packages import bump_version

    class Test(TestCase):
        """Unit test class for function bump_version."""

        def test_001(self):
            """Test function with a simple version number."""
            version = '1.2.2'
            exp_out = '1.2.3'
            out = bump_version(version)
            self.assertEqual(out, exp_out)

        def test_002(self):
            """Test function with a simple alpha version number."""
            version = '1.2.2a0'
            exp_out = '1.2.2a1'
            out = bump_version(version)
            self.assertE

# Generated at 2022-06-11 22:33:15.217110
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:37.626488
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    ver: str = '1.2.2'
    out: str = bump_version(ver)
    assert out == '1.2.3'
    out: str = bump_version(ver, position=1)
    assert out == '1.3'
    out: str = bump_version(ver, position=0)
    assert out == '2.0'
    ver: str = '1.2.2'
    out: str = bump_version(ver, pre_release='a')
    assert out == '1.2.4a0'
    out: str = bump_version(out, pre_release='b')
    assert out == '1.2.4b0'
    out: str = bump_version(out, pre_release='a')

# Generated at 2022-06-11 22:33:49.557308
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for function bump_version
    """
    ver_kwargs = {
        'version': '1.2.3',
        'position': 2,
        'prerelease': None
    }
    assert bump_version(**ver_kwargs) == '1.2.4'
    ver_kwargs['position'] = 1
    assert bump_version(**ver_kwargs) == '1.3'
    ver_kwargs['position'] = 0
    assert bump_version(**ver_kwargs) == '2.0'
    ver_kwargs['position'] = 2
    ver_kwargs['prerelease'] = 'a'
    assert bump_version(**ver_kwargs) == '1.2.4a0'
    ver_kwargs['prerelease'] = 'b'
    assert bump_

# Generated at 2022-06-11 22:33:57.662019
# Unit test for function bump_version
def test_bump_version():
    from flutils.common import unit_test_setup

    unit_test_setup(
        __file__,
        [],
        # Need the following modules for testing
        (
            'distutils.version',
        ),
        # Do not need the following modules for testing
        globls=dict(
            bump_version=bump_version,
        )
    )

    try:
        bump_version('1.0.0')
        print('bump_version(1.0.0) -> 1.0.1')
    except Exception as err:
        print('bump_version(1.0.0) ->')
        print('    %s' % err)


# Generated at 2022-06-11 22:34:10.741886
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.textutils import to_bool

    import docopt

    usage = """
    Usage:
        test_bump_version [options] <version>...
        
    Options:
        --version                                 Show version.
        -h --help                                 Show this screen.
        -v --verbose                              Verbose mode.
        -L --log-level=<level>
        -b --bump=<bump>
        -p --prerelease=<prerelease>
        -r --release-strategy=<strategy>
    """

    version = '0.3.6'

    arguments = docopt.docopt(
        usage,
        version=version
    )

    log_level = arguments['--log-level']

# Generated at 2022-06-11 22:34:18.247678
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    def make_version(version: str) -> str:
        """
        Simple wrapper around `bump_version` to generate a version string.

        Args:
            version: The version string to convert.

        :rtype:
            :obj:`str`

        """
        return bump_version(version, pre_release=None)

    ver = 'v0.0.1'
    assert bump_version(ver) == 'v0.0.2'
    assert bump_version(ver, position=1) == 'v0.1'
    assert bump_version(ver, position=0) == 'v1.0'
    assert bump_version(ver, pre_release='a') == 'v0.0.2a0'

# Generated at 2022-06-11 22:34:25.416665
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0212
    from flutils.packages import (
        _build_version_bump_position,
        _build_version_bump_type,
    )


# Generated at 2022-06-11 22:34:38.599403
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:43.743907
# Unit test for function bump_version
def test_bump_version():
    """Source:
        https://github.com/marrow/marrow.util/blob/master/marrow/util/version.py
    """
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version

# Generated at 2022-06-11 22:34:51.226730
# Unit test for function bump_version
def test_bump_version():
    """Test the flutils.packages.bump_version function."""
    from random import randint, seed
    from collections import namedtuple


# Generated at 2022-06-11 22:35:01.863074
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version module function."""
    version_dict = {
        (0, None): '2.0',
        (1, None): '1.3',
        (2, None): '1.2.3',
        (2, 'a'): '1.2.4a0',
        (2, 'alpha'): '1.2.4a0',
        (1, 'b'): '1.3b0',
        (1, 'beta'): '1.3b0',
        (2, 'blah'): ValueError,
        (2, ''): '1.2.3',
        (-3, None): ValueError,
        (3, None): ValueError,
    }