

# Generated at 2022-06-11 22:25:57.411262
# Unit test for function bump_version
def test_bump_version():
    """Unit test ``bump_version()``.

    Returns:
        True: if the unit test runs successfully.
        False: if ``bump_version()`` has changed.

    """
    from flutils.packages import (
        _BUMP_VERSION_MAJOR,
        _BUMP_VERSION_MINOR,
        _BUMP_VERSION_MINOR_ALPHA,
        _BUMP_VERSION_MINOR_BETA,
        _BUMP_VERSION_PATCH,
        _BUMP_VERSION_PATCH_ALPHA,
        _BUMP_VERSION_PATCH_BETA,
    )
    from flutils.textutils import text2list

# Generated at 2022-06-11 22:26:08.403117
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version

    :rtype: bool
    """
    from flutils.interop.unittest import Test
    from flutils.packages import bump_version
    from flutils.textutils import ensure_unicode
    try:
        from flutils._testing.unittest_helpers import (
            TestException,
            test_assert,
            test_assert_exception,
            test_assert_exception_msg,
            test_assert_raises,
        )
    except ImportError:
        from flutils._testing.unittest_helpers_pyi import (
            TestException,
            test_assert,
            test_assert_exception,
            test_assert_exception_msg,
            test_assert_raises,
        )


# Generated at 2022-06-11 22:26:18.755778
# Unit test for function bump_version

# Generated at 2022-06-11 22:26:28.227120
# Unit test for function bump_version
def test_bump_version():
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')
    assert ver == '1.2.4b0'

# Generated at 2022-06-11 22:26:35.810268
# Unit test for function bump_version
def test_bump_version():
    """
    Test the bump_version function.

    *New in version 0.3.0.*
    """

    # Test increase patch version
    assert bump_version('1.2.2') == '1.2.3'

    # Test increase minor version
    assert bump_version('1.2.3', position=1) == '1.3'

    # Test increase major version
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test increase prerelease version
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Test increase prerelease version again
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Test increase prerelease version again

# Generated at 2022-06-11 22:26:47.648429
# Unit test for function bump_version
def test_bump_version():
    from os import path
    from re import compile as re_compile
    from sys import version_info

    from flutils.common import (
        json
    )
    from flutils.debug import (
        call_trace,
        set_call_trace
    )
    from flutils.packages import (
        bump_version
    )

    # noinspection PyUnresolvedReferences
    if (version_info[0] == 2 and version_info[1] <= 6):
        # noinspection PyUnresolvedReferences
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-11 22:27:00.961462
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:10.764053
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.0')
    bump_version('1.2.0', position=1)
    bump_version('1.2.0', position=0)
    bump_version('1.2.0', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-11 22:27:20.127465
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    """Unit test for function bump_version
    """
    from flutils.packages import bump_version

    # Bump the version with the default position
    assert bump_version('1.2.2') == '1.2.3'

    # Bump the version with position 1
    assert bump_version('1.2.3', position=1) == '1.3'

    # Bump the version with position 0
    assert bump_version('1.3.4', position=0) == '2.0'

    # Bump the version with position 0 and pre-release 'a'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Bump the version with position 0 and pre-release 'a'
    assert bump_

# Generated at 2022-06-11 22:27:31.744827
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:02.439362
# Unit test for function bump_version
def test_bump_version():
    def _test_version_bump(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ):
        actual = bump_version(version, position, pre_release)
        assert actual == expected

    _test_version_bump('1.2.2', 2, None, '1.2.3')
    _test_version_bump('1.2.3', 1, None, '1.3')
    _test_version_bump('1.3.4', 0, None, '2.0')
    _test_version_bump('1.2.3', 2, 'a', '1.2.4a0')

# Generated at 2022-06-11 22:28:15.233813
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # pylint: disable=W0106,C0116,C0115
    from unittest import TestCase

    class _BumpVersionTestCase(TestCase):
        """Test case for function bump_version."""

        def test_bump_version_01(self):
            """Test case for function bump_version, no pre-release."""
            result = bump_version('1.2.2')
            self.assertEqual(result, '1.2.3')
            result = bump_version('1.2.3', position=1)
            self.assertEqual(result, '1.3')
            result = bump_version('1.3.4', position=0)
            self.assertEqual(result, '2.0')


# Generated at 2022-06-11 22:28:26.296058
# Unit test for function bump_version
def test_bump_version():
    """Test for function `bump_version`."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-11 22:28:34.319531
# Unit test for function bump_version
def test_bump_version():
    r"""Unit test for function bump_version."""
    from flutils.py23_compat._collections import OrderedDict
    import os
    import unittest

    # noinspection PyUnresolvedReferences,PyPackageRequirements
    from nose.tools import (
        assert_equals,
        assert_raises,
        raises
    )
    from nose.plugins.attrib import attr
    from flutils.packages import bump_version

    # pylint: disable=R0904,C0111,C0103
    class TestBumpVersion(unittest.TestCase):
        """Test class for function bump_version."""

        def setUp(self):
            _tests: Dict[str, Dict[str, Any]] = OrderedDict()

# Generated at 2022-06-11 22:28:44.984811
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    """

# Generated at 2022-06-11 22:28:57.640769
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-statements
    from flutils.packages import bump_version
    from flutils.textutils import maketext


# Generated at 2022-06-11 22:29:03.147898
# Unit test for function bump_version
def test_bump_version():
    import os
    import sys
    import pytest
    this_dir = os.path.dirname(__file__)
    pytest.main(['-x', os.path.join(this_dir, 'packages_test.py')])
    if hasattr(sys, 'exit'):
        sys.exit()
    else:
        exit()

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:29:14.780476
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:21.366436
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:24.289186
# Unit test for function bump_version
def test_bump_version():
    """  Unit test for function bump_version """
    raise NotImplementedError(
        "Test not implemented for function bump_version"
    )

# Generated at 2022-06-11 22:29:46.844577
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the :class:`bump_version` method."""

    def _check(
            version: str,
            position: int,
            pre_release: Union[str, None],
            out: str
    ) -> None:
        msg = '{} {} {}'.format(
            version,
            position,
            pre_release
        )
        _out = bump_version(version, position, pre_release)
        assert _out == out, msg
        assert isinstance(_out, str)

    _check('1.2.2', 2, None, '1.2.3')
    _check('1.2.3', 1, None, '1.3')
    _check('1.3.4', 0, None, '2.0')

# Generated at 2022-06-11 22:29:52.323052
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for function: bump_version"""
    from flutils.test.test_packages import TestVersionInfo

    for ver, ver_info in TestVersionInfo.test_data.items():
        out = bump_version(ver)
        assert out == ver_info.bump_version_out


# Generated at 2022-06-11 22:30:03.326348
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """ Unit test for function bump_version"""
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:30:10.912502
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=unused-variable
    """
        Assert that bump_version function works as expected.
    """
    from flutils.process import capture_output

    out = capture_output(bump_version, version='1.2.2')
    assert out == '1.2.3'

    out = capture_output(bump_version, version='1.2.3', position=1)
    assert out == '1.3'

    out = capture_output(bump_version, version='1.3.4', position=0)
    assert out == '2.0'

    out = capture_output(bump_version, version='1.2.3', prerelease='a')
    assert out == '1.2.4a0'


# Generated at 2022-06-11 22:30:19.744786
# Unit test for function bump_version
def test_bump_version():
    """Unit test function for function bump_version."""
    is_pass = True

    if bump_version('1.2.2') != '1.2.3':
        is_pass = False
    if bump_version('1.2.3', position=1) != '1.3':
        is_pass = False
    if bump_version('1.3.4', position=0) != '2.0':
        is_pass = False
    if bump_version('1.2.3', prerelease='a') != '1.2.4a0':
        is_pass = False
    if bump_version('1.2.4a0', pre_release='a') != '1.2.4a1':
        is_pass = False

# Generated at 2022-06-11 22:30:32.307454
# Unit test for function bump_version
def test_bump_version():
    """Test the packages.bump_version() function."""
    # basic func testing
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:30:41.903315
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version found in __main__.py."""
    from flutils.packages import __main__
    assert __main__.bump_version('1.2.2') == '1.2.3'
    assert __main__.bump_version('1.2.3', position=1) == '1.3'
    assert __main__.bump_version('1.3.4', position=0) == '2.0'
    assert __main__.bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert __main__.bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:30:54.113809
# Unit test for function bump_version
def test_bump_version():
    import pytest


# Generated at 2022-06-11 22:31:04.880743
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.2.2', position=0) == '2.0'
    assert bump_version('1.2.2', pre_release='a') == '1.2.3a0'
    assert bump_version('1.2.3a0', pre_release='a') == '1.2.3a1'
    assert bump_version('1.2.3a1', pre_release='b') == '1.2.3b0'
    assert bump_version('1.2.3a1') == '1.2.3'

# Generated at 2022-06-11 22:31:17.477558
# Unit test for function bump_version
def test_bump_version():
    import pytest


# Generated at 2022-06-11 22:31:55.175253
# Unit test for function bump_version
def test_bump_version():
    """Testing function: bump_version"""
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')
    assert ver == '1.2.4b0'
    ver = bump_version('1.2.4a1')
    assert ver == '1.2.4'
   

# Generated at 2022-06-11 22:32:04.519736
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from sys import version_info
    from random import randint

    # Python 2

# Generated at 2022-06-11 22:32:12.212195
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version

    *New in version 0.3*

    .. note::
        This test requires the ``pytest`` package to be installed.
    """
    # These just run without error, proving that the function does not exist
    import flutils
    try:
        flutils.packages.bump_version
    except AttributeError as exc:
        assert False, '{}: {}'.format(type(exc), exc)

    # These just run without error, proving that the function is accessible
    from flutils.packages import bump_version



# Generated at 2022-06-11 22:32:20.874707
# Unit test for function bump_version

# Generated at 2022-06-11 22:32:32.455348
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:44.304385
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import *
    from flutils.tests.testobjects import *
    from os.path import join as _join
    from os.path import dirname as _dirname

    test_root = _join(_dirname(__file__), 'funcs')

# Generated at 2022-06-11 22:32:55.566616
# Unit test for function bump_version

# Generated at 2022-06-11 22:33:03.848732
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    assert bump_version(version) == '0.0.1'
    version = '0.0.17'
    assert bump_version(version) == '0.0.18'
    version = '0.0.17'
    assert bump_version(version, 0) == '1.0.0'
    version = '0.0.1'
    assert bump_version(version, 0) == '1.0.0'
    version = '5.1.2'
    assert bump_version(version) == '5.1.3'
    version = '5.1.2'
    assert bump_version(version, 1) == '5.2'
    version = '0.0.1'

# Generated at 2022-06-11 22:33:14.472206
# Unit test for function bump_version
def test_bump_version():
    """Test for function: bump_version."""

    from flutils.packages import bump_version

    assert bump_version(None) == '1.0'

    assert bump_version('1.0') == '1.1'
    assert bump_version('1.1') == '1.2'
    assert bump_version('1.2') == '1.2.1'
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.1.1.1.1.1.1.1') == '1.2'


# Generated at 2022-06-11 22:33:27.399293
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    # Basic test
    test_data = {
        '1.2.3': '1.2.4',
        '1.2.3-a1': '1.2.4',
        '1.2.3-b3': '1.2.4',
        '1.2.3a1': '1.2.4',
        '1.2.3b3': '1.2.4',
    }
    for ver, exp in test_data.items():
        assert bump_version(ver) == exp

    # position=1

# Generated at 2022-06-11 22:35:28.106541
# Unit test for function bump_version
def test_bump_version():
    def test_1():
        """Test a non-prerelease version bumping."""
        ver_str = bump_version('2.1.0')
        assert ver_str == '2.1.1'

        ver_str = bump_version('2.1.1', position=1)
        assert ver_str == '2.2'

        ver_str = bump_version('2.2', position=0)
        assert ver_str == '3.0'

        ver_str = bump_version('2.1.1', position=0)
        assert ver_str == '3.0'

    def test_2():
        """Test a prerelease version bumping."""
        ver_str = bump_version('2.1.1', prerelease='a')