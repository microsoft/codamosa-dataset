

# Generated at 2022-06-11 22:25:56.049961
# Unit test for function bump_version
def test_bump_version():
    from tests.shared import _test_messages as msg

    args = (
        '0.1.2',
        '0.2',
        '0.3a1',
        '0.3.4b0',
        '0.4.0',
        '1.1.1a0',
        '1.1.1b0',
        '2.0.0',
    )
    kwargs = {
        'position': 2,
        'pre_release': None,
    }

# Generated at 2022-06-11 22:26:07.994833
# Unit test for function bump_version
def test_bump_version():
    """Function bump_version

    Unit test

    :rtype:
        :obj:`bool`

        * ``True`` if successful

    """
    from flutils.packages import bump_version

    ver = '1.0.0'
    result = bump_version(ver)
    assert result == '1.0.1'  # type: ignore

    ver = '1.0.0'
    result = bump_version(ver, prerelease='a')
    assert result == '1.0.1a0'  # type: ignore

    ver = '1.0.1a0'
    result = bump_version(ver, prerelease='b')
    assert result == '1.0.1b0'  # type: ignore

    ver = '1.0.1b0'

# Generated at 2022-06-11 22:26:18.123472
# Unit test for function bump_version
def test_bump_version():
    err = r'^The given value for \'position\', (\d+), must be an \'int\' ' \
          r'between \((-?\d+)\) and \((-?\d+)\)\.$'
    err2 = r'^The given value for \'pre_release\', (\w+), can only be one ' \
           r'of: \'a\', \'alpha\', \'b\', \'beta\', None\.$'
    err3 = r'^Only the \'minor\' or \'patch\' parts of the version ' \
           r'number can get a prerelease bump\.$'
    err4 = r'^Invalid version number (\'.+\')$'
    test_value = None
    assert test_value is None



# Generated at 2022-06-11 22:26:28.001631
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=W0612,C0415

    from flutils.packages import bump_version

    # Work with version numbers that do not have pre-release numbers
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=2) == '1.2.4'
    assert bump_version(version, position=1, pre_release='alpha') == '1.3a0'
    assert bump_version(version, position=2, pre_release='alpha') == '1.2.4a0'
    assert bump_version(version, position=2, pre_release='beta') == '1.2.4b0'

# Generated at 2022-06-11 22:26:36.395998
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from .unittest import TestCase
    from .unittest import TestCase


# Generated at 2022-06-11 22:26:47.763400
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    from os.path import dirname, realpath
    from sys import path
    from flutils.packages import bump_version
    from flutils.testing import are_equal, parse_test_args

    cmd_line_args = parse_test_args()

    test_root = dirname(realpath(__file__))
    path.insert(0, test_root)

    # noinspection PyUnresolvedReferences
    import test_bump_version  # pylint: disable=E0401,C0413

    fcn_name = cmd_line_args['function']
    fcn = test_bump_version.__dict__[fcn_name]()
    fcn_arg_names = list(fcn['args'].keys())
    kwargs = {}

# Generated at 2022-06-11 22:27:01.012105
# Unit test for function bump_version
def test_bump_version():
    '''Unit test for function bump_version'''
    import pytest
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:27:09.122107
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:19.115638
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0918,R0201
    """
    Unittest for function bump_version.

    """
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """
        Tests for function bump_version.

        """
        @staticmethod
        def _do_test_bumper(
                ver: str,
                pos: int,
                expected: Optional[str] = None,
                pre: Optional[str] = None
        ):
            """

            Args:
                ver:
                pos:
                expected:
                pre:

            Returns:

            """
            bump_ver = bump_version(ver, position=pos, pre_release=pre)
            if expected is None:
                expected = bump_ver
            assert bump_ver == expected


# Generated at 2022-06-11 22:27:30.958909
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914
    import sys
    import unittest

    class Test_bump_version(unittest.TestCase):
        """Bump a version number."""

        def test_01(self):
            res = bump_version('1.2.2')
            self.assertEqual(res, '1.2.3')

        def test_02(self):
            res = bump_version('1.2.3', position=1)
            self.assertEqual(res, '1.3')

        def test_03(self):
            res = bump_version('1.2.3', position=0)
            self.assertEqual(res, '2.0')


# Generated at 2022-06-11 22:27:52.602617
# Unit test for function bump_version
def test_bump_version():
    from .testing_helpers import verify_func_returns, verify_func_raises

# Generated at 2022-06-11 22:28:02.830206
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    """Test function set_logger_level."""
    from flutils.packages import bump_version

    version = '1.2.3'
    assert bump_version(version) == '1.2.4'

    version = '4.2.3'
    assert bump_version(version) == '4.2.4'

    version = '1.2.4'
    assert bump_version(version) == '1.2.5'

    version = '1.2.4'
    assert bump_version(version, position=1) == '1.3'

    version = '1.2.4'
    assert bump_version(version, position=0) == '2.0'

    version = '1.2.9'

# Generated at 2022-06-11 22:28:15.443907
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    """Test function :func:`flutils.packages.bump_version`."""
    from flutils import packages

    def _test(
            ver_in: str = '1.2.3',
            position: int = -1,
            pre_release: Optional[str] = None,
            ver_expected: str = '1.2.4'
    ):
        ver_out = packages.bump_version(
            ver_in, position, pre_release
        )
        assert ver_out == ver_expected, (
            'Expected %r, got %r'
            % (ver_expected, ver_out)
        )

    _test()

    # Test bumping from 0.0.0

# Generated at 2022-06-11 22:28:17.919578
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.3', pre_release='b'))


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-11 22:28:29.304037
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:42.027166
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from sys import version_info as py_version
    from importlib import reload as reload_module
    from os import path as os_path
    from tempfile import gettempdir

    from flutils.packages import bump_version

    TMP_DIR = os_path.join(gettempdir(), 'flutils-tests')
    is_py2 = py_version.major == 2
    is_py26 = py_version.major == 2 and py_version.minor == 6
    should_raise = True

    if is_py2 is True and is_py26 is False:
        try:
            import unittest2 as unittest  # type: ignore
        except ImportError:
            pass
        else:
            unittest = reload_module(unittest)
            should_

# Generated at 2022-06-11 22:28:47.387583
# Unit test for function bump_version
def test_bump_version():
    from . import unit_test_helpers

    check_version = unit_test_helpers.make_check_version()

    # noinspection PyUnusedLocal,PyUnreachableCode
    @check_version
    def test_bump_version_patch(ver: str):
        out = bump_version(ver)
        assert out is not None

    # noinspection PyUnusedLocal,PyUnreachableCode
    @check_version
    def test_bump_version_minor(ver: str):
        out = bump_version(ver, position=1)
        assert out is not None

    # noinspection PyUnusedLocal,PyUnreachableCode
    @check_version
    def test_bump_version_major(ver: str):
        out = bump_version(ver, position=0)

# Generated at 2022-06-11 22:28:58.992002
# Unit test for function bump_version
def test_bump_version():
    """Test the function ``bump_version``."""
    import sys

    major, minor = sys.version_info[:2]
    if major == 3 and minor < 7:
        raise RuntimeError(
            "Testing of `bump_version()` is only available on Python "
            "versions 3.7 and higher."
        )
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

# Generated at 2022-06-11 22:29:06.942148
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', pre_release='a') == '1.2.3a0'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'
    assert bump

# Generated at 2022-06-11 22:29:17.337128
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """
    # Testing major/minor/patch
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    # Testing alpha/beta
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:29:37.582396
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:45.811547
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the bump_version function."""

    from flutils.packages import bump_version


# Generated at 2022-06-11 22:29:56.733615
# Unit test for function bump_version
def test_bump_version():
    """Tests the 'bump_version' function."""
    # noinspection PyUnresolvedReferences
    from flutils.packages import bump_version

    # Setup

# Generated at 2022-06-11 22:30:06.975892
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    # pylint: disable=line-too-long
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:30:17.474475
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    class TestData(NamedTuple):
        """Test data for function bump_version."""
        version: str
        position: int
        pre_release: Optional[str]
        output: str


# Generated at 2022-06-11 22:30:26.005446
# Unit test for function bump_version
def test_bump_version():
    print(__name__, '.test_bump_version')
    print('\tbump_version')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1')

# Generated at 2022-06-11 22:30:35.566724
# Unit test for function bump_version

# Generated at 2022-06-11 22:30:44.483634
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test of function: `bump_version`.
    """

# Generated at 2022-06-11 22:30:57.360141
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:06.698615
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    print('Function bump_version')
    assert(bump_version('1.2.2') == '1.2.3')
    assert(bump_version('1.2.3', position=1) == '1.3')
    assert(bump_version('1.3.4', position=0) == '2.0')
    assert(bump_version('1.2.3', prerelease='a') == '1.2.4a0')
    assert(bump_version('1.2.4a0', pre_release='a') == '1.2.4a1')
    assert(bump_version('1.2.4a1', pre_release='b') == '1.2.4b0')

# Generated at 2022-06-11 22:31:23.722784
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:35.167794
# Unit test for function bump_version
def test_bump_version():
    from click.testing import CliRunner
    from flutils.packages import cli
    from pkg_resources import parse_version

    func = bump_version

# Generated at 2022-06-11 22:31:48.158543
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version.

    :return:
        :obj:`bool`

        * ``True`` if the test was successful.

    """
    from flutils.testing import capture_stdout

    # noinspection PyUnusedLocal
    with capture_stdout() as (out, err):
        try:
            bump_version(None)
        except TypeError:
            pass
        else:
            raise Exception('Bumped a non-string')

        try:
            bump_version('N/A')
        except ValueError:
            pass
        else:
            raise Exception("Bumped an invalid version number")

        try:
            bump_version('1.2.3', position=3)
        except ValueError:
            pass
        else:
            raise Exception("Bump a position that doesn't exist")


# Generated at 2022-06-11 22:31:55.052825
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Test the bump_version function."""

        def test_basic(self):
            """Test the basic functionality of bump_version."""
            self.assertEqual(bump_version('1.2'), '1.3')
            self.assertEqual(bump_version('1.2.3'), '1.2.4')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.2.3', position=0), '2.0')

# Generated at 2022-06-11 22:32:04.470262
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the function :func:`bump_version`.

    .. versionadded:: 0.3

    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:32:16.005253
# Unit test for function bump_version
def test_bump_version():
    from assertpy import assert_that

    assert_that(bump_version('1.2.2')).is_equal_to('1.2.3')
    assert_that(bump_version('1.2.3', position=1)).is_equal_to('1.3')
    assert_that(bump_version('1.3.4', position=0)).is_equal_to('2.0')
    assert_that(bump_version('1.2.3', prerelease='a')).is_equal_to('1.2.4a0')
    assert_that(bump_version('1.2.4a0', pre_release='a')).is_equal_to('1.2.4a1')

# Generated at 2022-06-11 22:32:28.752972
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version as ut

# Generated at 2022-06-11 22:32:38.804362
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # Make sure the output of bump_version() matches the expected output for
    # all examples listed in the docstring of bump_version()
    #
    # The examples are:
    #
    # Example:
    # >>> from flutils.packages import bump_version
    # >>> bump_version('1.2.2')
    # '1.2.3'
    # >>> bump_version('1.2.3', position=1)
    # '1.3'
    # >>> bump_version('1.3.4', position=0)
    # '2.0'
    # >>> bump_version('1.2.3', prerelease='a')
    # '1.2.4a0'
    # >>> bump_version('1.2.4a0', pre_

# Generated at 2022-06-11 22:32:46.351975
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=undefined-variable
    # pylint: disable=invalid-name
    """Unit test for module function ``bump_version``."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'


# Generated at 2022-06-11 22:32:57.530604
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # pylint: disable=C0103,R0914

    class _BumpVersionTestCase(NamedTuple):
        in_version: str
        out_version: str
        position: int
        pre_release: str
        name: str

    kwargs = {'position': 2}

# Generated at 2022-06-11 22:33:27.811321
# Unit test for function bump_version
def test_bump_version():  # noqa
    # pylint: disable=R0903,R0904
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-11 22:33:37.704598
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,R0914
    from collections import namedtuple
    VersionType = namedtuple('VersionType', 'version pre')


# Generated at 2022-06-11 22:33:49.701574
# Unit test for function bump_version
def test_bump_version():
    """Tests for bump_version() function.

    *New in version 0.3*

    """
    from .func_testing import TestCase, test_function
    from .func_testing import test_function_returns
    from .func_testing import test_function_raises_exception

    class TestCase1(TestCase):
        def test(self) -> None:
            keyword_args: Dict[str, Any] = {
                'version': '1.2.2',
            }
            test_function(
                function=bump_version,
                expected_result='1.2.3',
                keyword_args=keyword_args
            )


# Generated at 2022-06-11 22:33:57.755040
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:10.829630
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    def _test_bump_version(v: str, p: int, pr: Optional[str] = None):
        if pr is None:
            print("bump_version('{}', position={}) => '{}'".format(
                v, p, bump_version(v, position=p)
            ))
            return
        print("bump_version('{}', position={}, pre_release='{}') => '{}'".format(
            v, p, pr, bump_version(v, position=p, pre_release=pr)
        ))

    _test_bump_version('1.2.2', 2)
    _test_bump_version('1.2.2', 1)

# Generated at 2022-06-11 22:34:18.337058
# Unit test for function bump_version
def test_bump_version():
    import os
    import sys
    from pathlib import Path
    from flutils.packages import _get_metafunc_version

    def _build_expected_output(
            version: str,
            position: int = 2,
            pre_release: str = '',
    ) -> Tuple[str, str]:
        ver_info = _build_version_info(version)
        position = _build_version_bump_position(position)
        bump_type = _build_version_bump_type(position, pre_release)
        hold: Tuple[Union[int, str], ...] = []

# Generated at 2022-06-11 22:34:25.454601
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    Not called if module calling :mod:`unittest`.

    *New in version 0.3*

    """
    from os import path
    from sys import argv, exit
    try:
        from flutils.packages import _TESTS_DIR
    except ImportError:
        exit(1)
    try:
        from flutils.packages import UnitTestCase
    except ImportError:
        exit(1)

    class TestBumpVersion(UnitTestCase):
        """Test flutils.packages.bump_version

        *New in version 0.3*

        """
        args: List[str] = []
        package_name: str = path.split(path.split(argv[0])[0])[1]

# Generated at 2022-06-11 22:34:38.598934
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0915
    # pylint: disable=R0912
    # pylint: disable=R0914
    # pylint: disable=W0612
    from . import utils
    from .pytest_context import fixture_version_file, fixture_version_info

    ver_info = _build_version_info(fixture_version_info)
    for pos in range(0, 2):
        for pre_release in ('a', 'b', 'alpha', 'beta'):
            ver_info = _build_version_info(fixture_version_info)
            old_ver = fixture_version_info
            new_ver = bump_version(fixture_version_info, pos, pre_release)

            if pos == 0:
                assert old_ver[0] != new_ver

# Generated at 2022-06-11 22:34:44.831200
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for function bump_version."""
    # noinspection PyUnusedLocal
    import sys
    import pytest
    import flutils.packages

    # Build the tests and options
    funcs = [
        bump_version
    ]

# Generated at 2022-06-11 22:34:51.887368
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import pytest
    from textwrap import dedent

    def get_err_msg(exc: Exception) -> str:
        msg = str(exc)
        if '\n' in msg:
            msg = dedent(msg.strip())
        return msg

    def test_version_info() -> None:
        from flutils.packages import _build_version_info
