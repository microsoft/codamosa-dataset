

# Generated at 2022-06-11 22:25:59.718552
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    import pytest
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:26:09.747443
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0912,R0915,R0914,W0212
    """Unit test for function :func:`bump_version`"""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'


# Generated at 2022-06-11 22:26:20.651490
# Unit test for function bump_version
def test_bump_version():
    # noinspection SpellCheckingInspection,PyCompatibility
    from assertpy import assert_that

    # Check that positional argument is of type 'str'
    try:
        # noinspection PyTypeChecker
        assert_that(bump_version(1)).is_type_of(str)
    except TypeError:
        pass

    # Check that the argument 'position' is of type 'int'
    try:
        # noinspection PyTypeChecker
        assert_that(bump_version('1.2', position='1')).is_type_of(str)
    except TypeError:
        pass

    # Check that the argument 'pre_release' is of type 'str' or None

# Generated at 2022-06-11 22:26:28.968078
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function ``bump_version``
    """

# Generated at 2022-06-11 22:26:36.953569
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function flutils.packages.bump_version."""
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:26:48.026082
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:01.206823
# Unit test for function bump_version
def test_bump_version():
    """Test: bump_version
    """
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:27:13.092173
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``.
    """

    def _check_output(
            version: str,
            position: int,
            pre_release: Optional[str],
            exp_res: str,
            exp_err: bool
    ) -> None:
        should_pass = True
        try:
            output = bump_version(version, position, pre_release)
        except Exception as err:
            should_pass = False
            output = repr(err)
        if output == exp_res:
            assert should_pass is exp_err
        else:
            assert output == exp_res

    # region: basic
    # noinspection PyUnresolvedReferences
    _check_output('1.2.2', 2, None, '1.2.3', False)
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:27:21.278997
# Unit test for function bump_version
def test_bump_version():
    from flutils import testutils

    from . import __version__

    fname = testutils.get_callable_name()
    # No change
    assert bump_version(__version__) == __version__

    # Patch
    assert bump_version(__version__, position=2) == '0.3.1'

    # Minor
    assert bump_version(__version__, position=1) == '0.4'

    # Patch and alpha
    assert bump_version(__version__, position=2, pre_release='a') == '0.3.1a0'
    assert bump_version(
        bump_version(__version__, position=2, pre_release='a'),
        position=2,
        pre_release='a'
    ) == '0.3.1a1'

    # Minor and beta

# Generated at 2022-06-11 22:27:32.019622
# Unit test for function bump_version
def test_bump_version():
    from flutils.testhelpers import (
        call_and_check,
        not_raises,
    )


# Generated at 2022-06-11 22:28:20.216908
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:28:31.161130
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:43.951002
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version
    """
    # pylint: disable=C0103,C0116
    from flutils.packages import (
        bump_version
    )

    print('Verifying bump_version')

    # no pre-release
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    # bumping pre-release
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='A') == '1.2.4a0'
    assert bump

# Generated at 2022-06-11 22:28:56.846215
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import unittest

    class Test_bump_version(unittest.TestCase):
        def test_bump_version(self):
            """bump_version unit test"""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', 1), '1.3')
            self.assertEqual(bump_version('1.3.4', 0), '2.0')
            self.assertEqual(bump_version('1.2.3', 'a'), '1.2.4a0')
            self.assertEqual(bump_version('1.2.4a0', 'a'), '1.2.4a1')


# Generated at 2022-06-11 22:29:06.219269
# Unit test for function bump_version

# Generated at 2022-06-11 22:29:16.953187
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-branches
    import pytest
    from flutils.packages import bump_version

    ver_str_list = [
        "1.1.1",
        "1.0",
        "1",
        "0.1.1",
        "1.1.0",
        "0",
        "2.1.3",
        "1.2b0"
    ]

    # Verify basic version output
    for ver_str in ver_str_list:
        exp_str = '%s.%s.%s' % (ver_str, '0', '0')
        result = bump_version(ver_str, position=-3)
        assert result == exp_str
        exp_str = '%s.%s' % (ver_str, '0')


# Generated at 2022-06-11 22:29:27.529019
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:38.760206
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-branches
    def _test_bump_ver_one(
            ver_in: str,
            ver_out: str = '',
            pos: int = -2,
            pre: str = '',
    ) -> None:
        did_error = False
        try:
            ver_out_actual = bump_version(ver_in, pos, pre)
        except Exception:  # pylint: disable=W0703
            did_error = True
        if ver_out == '':
            assert did_error is True
        else:
            assert did_error is False
            assert ver_out == ver_out_actual

    _test_bump_ver_one('1.2.3')

# Generated at 2022-06-11 22:29:45.034027
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function "bump_version"
    """

    # Test case #1
    version = bump_version('1.2.2')
    assert version == '1.2.3'

    # Test case #2
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'

    # Test case #3
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'

    # Test case #4
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'

    # Test case #5
    version = bump_version('1.2.4a0', pre_release='a')

# Generated at 2022-06-11 22:29:56.311477
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:17.110448
# Unit test for function bump_version
def test_bump_version():
    # This should not be necessary, but using a new instance for each test
    # prevents unexpected bugs.
    from flutils.packages import bump_version
    from flutils.tests.util import none2str
    from flutils.textutils import repeat_char
    from flutils.versatile import get_class
    from hamcrest import assert_that
    from hamcrest import equal_to
    from hamcrest import has_length
    from hamcrest import is_not
    from hamcrest import is_not_none
    from hamcrest import is_not_empty
    from hamcrest import is_
    from hamcrest import only_contains
    from hamcrest import raises
    from hamcrest.core.base_matcher import BaseMatcher


# Generated at 2022-06-11 22:30:25.810163
# Unit test for function bump_version

# Generated at 2022-06-11 22:30:35.248067
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:44.276453
# Unit test for function bump_version
def test_bump_version():
    import inspect
    from flutils.packages import bump_version
    from . import assert_raises_type_error, assert_raises_value_error
    with open(inspect.getsource(bump_version)) as fsrc:
        lines = fsrc.readlines()
    test_functions = []
    test_objects = []
    for line in lines:
        if line.startswith('Examples:'):
            break
        if line.startswith('>>>'):
            line = line.replace('>>>', '').strip()
            if line.startswith('from'):
                continue
            if line.startswith('__'):
                continue
            if line == '':
                continue
            if line.startswith('raise'):
                continue

# Generated at 2022-06-11 22:30:47.372004
# Unit test for function bump_version
def test_bump_version():
    """Test :func:`bump_version` with the doctest provided in the docstring.
    """
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-11 22:30:59.541695
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """

    # Bump patch
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2b0', position=2) == '1.2.1'

    # Bump minor
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0') == '1.2.4'

    # Bump major
    assert bump_version('1.2.3', position=0) == '2'
    assert bump_version

# Generated at 2022-06-11 22:31:07.915093
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version
    current_bump_version: str = '0.0.3'
    assert bump_version(current_bump_version) == '0.0.4'
    assert bump_version(current_bump_version, position=2) == '0.0.4'
    assert bump_version(current_bump_version, position=1) == '0.1'
    assert bump_version(current_bump_version, position=0) == '1.0'
    current_bump_version: str = '1.2.3'
    assert bump_version(current_bump_version) == '1.2.4'

# Generated at 2022-06-11 22:31:20.023776
# Unit test for function bump_version
def test_bump_version():
    """
    Unit testing for the ``bump_version`` function.
    """
    # fmt: off

# Generated at 2022-06-11 22:31:32.760157
# Unit test for function bump_version
def test_bump_version(): # noqa: D103
    """
    Unit test for function flutils.packages.bump_version
    """
    import unittest
    import unittest.mock

    class Test__each_version_part(unittest.TestCase):

        def test_00(self):
            """
            Test function _each_version_part
            """
            from flutils.packages import _each_version_part

            result = list(_each_version_part(StrictVersion('1')))
            self.assertIsInstance(result, list)
            self.assertEqual(result, [
                _VersionPart(
                    pos=0,
                    txt='1',
                    num=1,
                    pre_txt='',
                    pre_num=-1,
                    name='major'
                )
            ])


# Generated at 2022-06-11 22:31:40.404257
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-locals
    from string import ascii_letters
    import sys

    for k in range(-25, 90):
        prereleases: List[str] = [
            'a', 'alpha', 'b', 'beta', ''
        ]
        for prerelease in prereleases:
            try:
                bump_version(
                    '1.2.2', position=k, pre_release=prerelease
                )
            except ValueError:
                pass

# Generated at 2022-06-11 22:32:20.317996
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:32.193659
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """
    import pytest

# Generated at 2022-06-11 22:32:44.050840
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    import pytest

# Generated at 2022-06-11 22:32:51.527186
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:01.556678
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=R0914
    # Too many local variables (30/15)

# Generated at 2022-06-11 22:33:13.149134
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:26.030305
# Unit test for function bump_version
def test_bump_version():
    """Test for the bump_version function of the flutils.packages"""
    # pylint: disable=R0904
    from flutils.packages import bump_version
    import unittest
    from unittest import TestCase
    from unittest.mock import patch

    class Test_bump_version(TestCase):
        """TestCase for the bump_version function"""
        # pylint: disable=R0904

        def test_docstring(self):
            """Testing to make sure that the function has
            a docstring and the docstring has content.
            """
            self.assertIsNotNone(
                bump_version.__doc__,
                "The bump_version function has no docstring"
            )

# Generated at 2022-06-11 22:33:30.182494
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:33:35.878705
# Unit test for function bump_version
def test_bump_version():
    msg = ('The version number, %r, was %r, and was not as expected, %r.')
    version = '0.2.2'
    expect = '0.2.3'
    actual = bump_version(version)
    assert actual == expect, msg % (version, actual, expect)

    version = '0.2.2'
    expect = '0.3'
    actual = bump_version(version, 1)
    assert actual == expect, msg % (version, actual, expect)

    version = '1.3.4'
    expect = '2.0'
    actual = bump_version(version, 0)
    assert actual == expect, msg % (version, actual, expect)

    version = '1.2.3'
    expect = '1.2.4a0'
    actual = bump_

# Generated at 2022-06-11 22:33:47.209059
# Unit test for function bump_version
def test_bump_version():
    #
    # Test bump_version
    #
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:17.792964
# Unit test for function bump_version
def test_bump_version():
    """Test for function 'bump_version'."""
    # pylint: disable=E0611,E0401
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:34:25.200911
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version

    # Version numbers
    vn = '0.11.3'

# Generated at 2022-06-11 22:34:38.422383
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Function called from unit tests, only."""

# Generated at 2022-06-11 22:34:44.723312
# Unit test for function bump_version
def test_bump_version():
    """Unit test of function ``bump_version``"""
    from flutils.packages import bump_version

    errors = []


# Generated at 2022-06-11 22:34:51.842609
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""

    import sys
    import unittest

    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        """Test the function ``bump_version``."""

        def test_all_versions(self) -> None:
            """Test all versions."""

            versions: List[str] = [
                '1.1.1',
                '2.2.2',
                '3.3.3',
                '1.1.1b1',
                '1.1.1a1',
                '2.2.2b2',
                '2.2.2a2',
                '3.3.3b3',
                '3.3.3a3',
            ]

# Generated at 2022-06-11 22:35:02.268824
# Unit test for function bump_version
def test_bump_version():
    """Tests for ``bump_version``."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:35:05.147525
# Unit test for function bump_version
def test_bump_version():
    from tests.helpers import UnitHelper
    from . import bump_version

    uu = UnitHelper()
    name = 'bump_version'
    uu.run_test_function(name, bump_version)

# Generated at 2022-06-11 22:35:15.584131
# Unit test for function bump_version
def test_bump_version():
    """Test flutils.packages.bump_version function."""
    # Test normal increase
    assert bump_version('1.2.2') == '1.2.3'
    # Test minor bump with alpha release
    assert bump_version('1.2.2') == '1.2.3'
    # Test minor bump with beta release
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test minor bump with minor release
    assert bump_version('1.3.4', position=0) == '2.0'
    # Test minor bump with minor release
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    # Test minor bump with minor release

# Generated at 2022-06-11 22:35:26.589265
# Unit test for function bump_version
def test_bump_version():  # noqa
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    import unittest

    class Test(unittest.TestCase):
        """Class for unit testing function bump_version."""

        def test_bump_version(self):
            """Test bump_version with different test cases."""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
           

# Generated at 2022-06-11 22:35:35.639994
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'