

# Generated at 2022-06-11 22:25:56.682238
# Unit test for function bump_version
def test_bump_version():
    """Test case for function ``bump_version``"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:26:04.333173
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # pylint: disable=C0103,R0915

# Generated at 2022-06-11 22:26:14.016893
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:22.591110
# Unit test for function bump_version

# Generated at 2022-06-11 22:26:34.031576
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:46.694600
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    # pylint: disable=E1101

    # import os
    import shutil
    import tempfile

    from flutils.packages import bump_version
    from flutils.testing import test_dir_path

    # The version string to be bumped
    _version = '1.2.3'

    def _cleanup_(dir_name: str) -> None:
        if os.path.isdir(dir_name):
            shutil.rmtree(dir_name)

    # Build a test directory
    dir_name = tempfile.mkdtemp()

# Generated at 2022-06-11 22:27:00.248099
# Unit test for function bump_version
def test_bump_version():
    from . import package_base  # pylint: disable=E

# Generated at 2022-06-11 22:27:08.766230
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0')

# Generated at 2022-06-11 22:27:18.877847
# Unit test for function bump_version
def test_bump_version():
    from .string import clean_string

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:30.800099
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # pylint: disable=R0914
    # pylint: disable=R0915
    major = '%s'
    minor = '%s.%s'
    patch = '%s.%s.%s'
    minor_alpha = '%sa%s'
    minor_beta = '%sb%s'
    patch_alpha = '%sa%s'
    patch_beta = '%sb%s'

# Generated at 2022-06-11 22:27:59.648982
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    # noinspection PyUnresolvedReferences
    from flutils.packages import bump_version

    def _run(
            version: str,
            expected: str,
            position: int,
            pre_release: Optional[str] = None,
    ) -> None:
        actual = bump_version(version, position, pre_release)
        assert actual == expected

    _ver: str
    _exp: str
    # _pos: int
    # _pre: Optional[str]

    _ver = '1.2.2'
    _exp = '1.2.3'
    _run(_ver, _exp, position=2)

    _ver = '1.2.3'
    _exp = '1.3'

# Generated at 2022-06-11 22:28:06.046261
# Unit test for function bump_version

# Generated at 2022-06-11 22:28:13.183904
# Unit test for function bump_version
def test_bump_version():
    """
    Test for function bump_version
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:28:20.405383
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'

    version = '1.2.3'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'
    assert bump_version(version, pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:28:31.310283
# Unit test for function bump_version
def test_bump_version():
    func = bump_version
    ver = '1.2.3'
    should = '1.2.4'
    got = func(ver)
    assert should == got, 'Expected version number to be (%r), got (%r).' % (
        should, got
    )
    ver = '0.0.0'
    should = '0.0.1'
    got = func(ver)
    assert should == got, 'Expected version number to be (%r), got (%r).' % (
        should, got
    )
    ver = '1.2.3alpha1'
    should = '1.2.3alpha2'
    got = func(ver)
    assert should == got, 'Expected version number to be (%r), got (%r).' % (
        should, got
    )
    ver

# Generated at 2022-06-11 22:28:44.075631
# Unit test for function bump_version
def test_bump_version():                                                       # pylint: disable=C0116,C0115
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:56.978139
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version() function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:06.282513
# Unit test for function bump_version
def test_bump_version():
    """Test the function 'bump_version'."""
    # pylint: disable=no-member,protected-access
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:29:16.989621
# Unit test for function bump_version
def test_bump_version():
    """Test the `bump_version` function."""
    from .pkgs import main

    argv = ['-s', 'bump', '1.2.2']

    cliargs = main(argv=argv)
    assert cliargs.func == bump_version
    assert cliargs.version == '1.2.2'
    assert cliargs.position == 2
    assert cliargs.pre_release is None

    argv = ['-s', 'bump', '1.2.2', '--position', '1']
    cliargs = main(argv=argv)
    assert cliargs.position == 1

    argv = ['-s', 'bump', '1.2.2', '--pre-release', 'a']
    cliargs = main(argv=argv)

# Generated at 2022-06-11 22:29:27.563093
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:30:24.479546
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.testing import capture_output

    out = (
        '1.2.3',
        '1.3',
        '2.0',
        '1.2.4a0',
        '1.2.4a1',
        '1.2.4b0',
        '1.2.4',
        '1.2.4',
        '2.2a0',
        '1.2.1'
    )

# Generated at 2022-06-11 22:30:34.489374
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function.
    """
    from flutils.packages import bump_version

    version: str = '1.2.2'

    # Test the version bumping.
    version = bump_version(version)
    print(version)
    assert version == '1.2.3'
    version = bump_version(version, position=1)
    print(version)
    assert version == '1.3'
    version = bump_version(version, position=0)
    print(version)
    assert version == '2.0'
    version = bump_version(version, prerelease='a')
    print(version)
    assert version == '2.0a0'
    version = bump_version(version, pre_release='a')
    print(version)

# Generated at 2022-06-11 22:30:43.740161
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version."""
    import pytest

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-11 22:30:48.846352
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises
    from flutils.packages import bump_version, Version

    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.1', 2, 'a') == '1.0.1a0'
    assert bump_version('1.0.2a0', 2, 'a') == '1.0.2a1'
    assert bump_version('1.0.2a1', 2, 'a') == '1.0.2a2'
    assert bump_version('1.0.2a0', 2, 'b') == '1.0.2b0'

# Generated at 2022-06-11 22:31:00.927218
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """
    # pylint: disable=W0622
    global bump_version
    from flutils.packages import bump_version
    # Test major
    assert bump_version('1.2.3') == '1.2.4'
    # Test minor
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.4a0', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.5a1', pre_release='b') == '1.2.5b0'

# Generated at 2022-06-11 22:31:08.367128
# Unit test for function bump_version
def test_bump_version():
    from .testingutils import assert_equality

    def _assert(version: str, position: int, release: Optional[str],
                expected_out: str):
        """Assert the given input and output of bump_version."""
        out = bump_version(version, position, release)
        assert_equality(out, expected_out)


# Generated at 2022-06-11 22:31:20.265190
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:33.886717
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:40.675948
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:51.666987
# Unit test for function bump_version

# Generated at 2022-06-11 22:32:13.798187
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:25.722442
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    # pylint: disable=E0401
    # pylint: disable=E0611
    import os
    import shutil
    import tempfile
    import unittest

    # pylint: disable=E0401
    # pylint: disable=E0611
    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        """Tests for function flutils.packages.bump_version."""

        def test_bump_version_major(self):
            """Test the 'major' version bump."""
            version = '1.2.3'
            expect = '2.0'
            actual = bump_version(version, position=0)

# Generated at 2022-06-11 22:32:34.948743
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    from pytest import approx

    assert ('2.0' == bump_version('1.2.3', position=0))
    assert ('2.0' == bump_version('1.2.3.4', position=0))
    assert ('1.3' == bump_version('1.2.3', position=1))
    assert ('1.3' == bump_version('1.2.3.4', position=1))
    assert ('1.2.3' == bump_version('1.2.2'))
    assert ('1.2.3' == bump_version('1.2.2.4'))
    assert ('1.2.4a0' == bump_version('1.2.3', pre_release='a'))

# Generated at 2022-06-11 22:32:47.087506
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function :func:`bump_version`
    """

# Generated at 2022-06-11 22:32:53.272817
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the function bump_version"""
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:33:03.002590
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for ``bump_version``"""
    # Major bump
    assert bump_version('1.2.3') == '1.2.4'
    # Minor bump
    assert bump_version('1.2.3', position=1) == '1.3'
    # Major bump
    assert bump_version('1.3.4', position=0) == '2.0'
    # Pre-release bump
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Pre-release bump
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Pre-release bump

# Generated at 2022-06-11 22:33:13.924984
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function flutils.packages.bump_version
    """
    # pylint: disable=W0612,C0116
    from flutils.packages import bump_version

    def get_error_msg(
            msg: str,
            version: str,
            position: int,
            pre_release: Optional[str]
    ) -> str:
        return (
            'When testing a call to: '
            "bump_version(%r, %r, %r)\n%s" % (
                version,
                position,
                pre_release,
                msg
            )
        )


# Generated at 2022-06-11 22:33:26.991747
# Unit test for function bump_version
def test_bump_version():
    import sys
    import re

    if sys.version_info.major < 3:
        # noinspection PyCompatibility
        ver = re.match(r'[0-9]+', sys.version).group()
        ver = int(ver)
        # noinspection PyCompatibility
        if ver < 7:
            # noinspection PyProtectedMember,PyUnresolvedReferences
            # pylint: disable=no-member
            from unittest2 import TestCase, main
            # pylint: enable=no-member
    else:
        from unittest import TestCase, main


# Generated at 2022-06-11 22:33:37.479947
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914,R0915
    """Unit test for function bump_version."""
    # Need to import here to prevent circular dependency
    # pylint: disable=C0415,C0416
    from flutils.misc import test_value
    import flutils.packages as target

# Generated at 2022-06-11 22:33:49.402089
# Unit test for function bump_version

# Generated at 2022-06-11 22:34:17.126202
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version

    :return: None
    """
    # pylint: disable=W0611, W0612
    from flutils.packages import bump_version  # noqa: F401

    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            result: str,
    ):
        ver = bump_version(version, position=position, pre_release=pre_release)
        assert ver == result, 'Failed: {}: {}: {}: {}: {}'.format(
            version, position, pre_release, result, ver
        )

    _test('1.2.2', 2, None, '1.2.3')
    _test('1.2.3', 1, None, '1.3')

# Generated at 2022-06-11 22:34:24.999350
# Unit test for function bump_version
def test_bump_version():
    """Function ``bump_version`` unit test."""

    # noinspection PyUnresolvedReferences
    import pytest  # type: ignore


# Generated at 2022-06-11 22:34:38.274581
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from . import unit_uuid_
    from . import unit_uuid_snowflake

    test_name = 'bump_version'
    header = 'from flutils.packages import bump_version\n'

    test_str = '1.2.2'
    expected_str = '1.2.3'
    code = (
        header +
        "ret = bump_version(%r)\n"
        "assert ret == %r\n" % (test_str, expected_str)
    )
    unit_uuid_snowflake._test(test_name, code)
    unit_uuid_._test(test_name, code)

    test_str = '1.2.3'
    expected_str = '1.3'

# Generated at 2022-06-11 22:34:49.266622
# Unit test for function bump_version
def test_bump_version():
    """Test ``_build_version_info``

    This is mostly for code coverage.

    """
    # pylint: disable=C0321,C0301,R0912
    # pylint: disable=R0801,R0914,R0915
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:34:52.009282
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    import sys
    import doctest

    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-11 22:35:02.379728
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,W0612
    from flutils.package import bump_version as bv

    def _build_bump_test(in_ver: str, out_ver: str, pos: int,
                         pre_release: Optional[str] = None) -> None:
        assert bv(in_ver, pos, pre_release) == out_ver

    _build_bump_test('1.2.2', '1.2.3', 2)
    _build_bump_test('1.2.3', '1.3', 1)
    _build_bump_test('1.3.4', '2.0', 0)
    _build_bump_test('1.2.3', '1.2.4a0', 2, 'a')
    _build_b

# Generated at 2022-06-11 22:35:13.679522
# Unit test for function bump_version
def test_bump_version():
    """Execute unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:35:26.040005
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914,W0613
    from flutils.testing import BaseTestCase
    from flutils.miscutils import get_fn_name_calling_me, get_first_lines

    # noinspection PyUnusedLocal
    class TestCase(BaseTestCase):
        """Test functions from the package flutils.packages"""

        # noinspection PyUnusedLocal

# Generated at 2022-06-11 22:35:35.362008
# Unit test for function bump_version
def test_bump_version():
    """
    Test the function 'bump_version()'
    """

    # .. note::
    #
    #    The function :func:`tests.test_version_bump.test_bump_version` is
    #    generated on-the-fly.  At the time of this docstrings creation, it
    #    does not exist.

    ret = bump_version('1.0.0')
    assert ret == '1.0.1'

    ret = bump_version('1.2.2')
    assert ret == '1.2.3'

    ret = bump_version('1.2.3', position=1)
    assert ret == '1.3'

    ret = bump_version('1.3.4', position=0)
    assert ret == '2.0'
