

# Generated at 2022-06-11 22:25:56.860810
# Unit test for function bump_version
def test_bump_version():
    def _test_bump_version_for(
            ver_txt: str,
            pos: int,
            pre_release: Optional[str],
            res_ver_txt: str,
    ) -> None:
        res = bump_version(
            version=ver_txt,
            position=pos,
            pre_release=pre_release
        )
        assert res == res_ver_txt

    _test_bump_version_for(
        '1.2.2',
        position=2,
        pre_release=None,
        res_ver_txt='1.2.3'
    )
    _test_bump_version_for(
        '1.2.3',
        position=1,
        pre_release=None,
        res_ver_txt='1.3'
    )


# Generated at 2022-06-11 22:26:08.262739
# Unit test for function bump_version
def test_bump_version():
    out = bump_version('1.2.2')
    assert out == '1.2.3'
    out = bump_version('1.2.3', position=1)
    assert out == '1.3'
    out = bump_version('1.3.4', position=0)
    assert out == '2.0'
    out = bump_version('1.2.3', prerelease='a')
    assert out == '1.2.4a0'
    out = bump_version('1.2.4a0', pre_release='a')
    assert out == '1.2.4a1'
    out = bump_version('1.2.4a1', pre_release='b')
    assert out == '1.2.4b0'

# Generated at 2022-06-11 22:26:18.654479
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('0.2.1') == '0.2.2'
    assert bump_version('0.2.1', position=1) == '0.3'
    assert bump_version('0.3', position=1) == '0.4'
    assert bump_version('0.2.1', position=0) == '1.0'
    assert bump_version('0.2.1', pre_release='a') == '0.2.1a0'
    assert bump_version('0.2.1a0', pre_release='a') == '0.2.1a1'
    assert bump_version('0.2.1a1', pre_release='a') == '0.2.1a2'

# Generated at 2022-06-11 22:26:28.202796
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the :func:`bump_version` function."""
    from unittest import TestCase
    from unittest import main

    class MyTester(TestCase):
        """Test :func:`bump_version`."""

        def test_bump_version(self):
            """Test :func:`bump_version`."""
            from flutils.packages import bump_version
            self.assertEqual(bump_version('1.2.3'), '1.2.4')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

# Generated at 2022-06-11 22:26:35.790329
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function"""
    from nose.tools import assert_equal


# Generated at 2022-06-11 22:26:47.550730
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import _VersionPart
    from flutils.packages import _VersionInfo
    from flutils.packages import _each_version_part
    import unittest

    class TestBumpVersion(unittest.TestCase):

        def test_each_version_part(self):
            ver_obj = StrictVersion('0.1.0a1')

# Generated at 2022-06-11 22:27:00.961640
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:05.729010
# Unit test for function bump_version

# Generated at 2022-06-11 22:27:16.989373
# Unit test for function bump_version

# Generated at 2022-06-11 22:27:29.515290
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the ``bump_version`` function."""
    for item in ('1.2.3', '1.2.3', (1, 2, 3), (1, 2, 3, 0), (1, 2, 3, 'a')):
        ver_str: str = bump_version(item)
        if ver_str != '1.2.4':
            raise ValueError('Expected: 1.2.4, Got: %r' % (ver_str,))

    ver_str = bump_version('1.2.3', position=1)
    if ver_str != '1.3':
        raise ValueError('Expected: 1.3, Got: %r' % (ver_str,))

    ver_str = bump_version('1.2.3', position=0)

# Generated at 2022-06-11 22:28:02.914982
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    *New in version 0.3*

    """

# Generated at 2022-06-11 22:28:15.527338
# Unit test for function bump_version
def test_bump_version():
    # Basic
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    # Pre-release
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:26.728293
# Unit test for function bump_version
def test_bump_version():
    import sys

    from flutils.packages import is_version_less
    from flutils.testing import capture_stdout

    release_bump = {
        '1.2.3': '1.2.4',
        '1.2.3a0': '1.2.4',
        '1.2.3b0': '1.2.4',
        '1.2.3dev 0': '1.2.4',
        '1.2.3.dev0': '1.2.4',
        '1.2.3.post0': '1.2.4',
    }

# Generated at 2022-06-11 22:28:34.546453
# Unit test for function bump_version
def test_bump_version():
    """Unit test for package function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:45.143493
# Unit test for function bump_version
def test_bump_version():

    # pylint: disable=E1120
    from flutils.test.test_common import get_test_func
    from flutils.packages import bump_version

    tfunc = get_test_func(bump_version)

    ver_list = [
        '1.2.2',
        '1.2.3',
        '1.3.4',
        '2.1.3',
        '1.2.4a0',
        '1.2.4a1',
        '1.2.4a1',
        '1.2.4b0',
        '1.2.4b0',
        '1.2.4b0',
        '1.2b0',
    ]


# Generated at 2022-06-11 22:28:57.756886
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:06.404137
# Unit test for function bump_version

# Generated at 2022-06-11 22:29:17.063193
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import pytest
    # fmt: off

# Generated at 2022-06-11 22:29:27.597762
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """
    version = '1.2.2'
    assert bump_version(version) == '1.2.3'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'
    version = '1.2.3'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'
    assert bump_version(version, pre_release='b')

# Generated at 2022-06-11 22:29:38.842010
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Unit test for function :func:`bump_version`."""
    from flutils.runhelpers import print_test_header
    from pprint import pprint
    from flutils.packages import test_pkg_info

    print_test_header(
        __name__, 'bump_version',
        docstr='Unit test for function :func:`bump_version`.'
    )

    print('Test 1:')
    print('  Description: Test normal function operation.')
    print('  Values:')
    pprint('    version: {}'.format(test_pkg_info['version']))
    pprint('    position: 2')
    pprint('    pre_release: alpha')
    pprint('  Results:')

# Generated at 2022-06-11 22:30:05.725309
# Unit test for function bump_version
def test_bump_version():
    """
    Tests the bump_version function.
    """

# Generated at 2022-06-11 22:30:16.854582
# Unit test for function bump_version
def test_bump_version():
    get_out = lambda ver, pos, pre=None: bump_version(ver, pos, pre)
    test_desc_fmt = 'bump_version({!r}, {!r}, {!r})'

# Generated at 2022-06-11 22:30:25.719364
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for :func:`bump_version`"""
    from flutils.packages import bump_version
    def _assert(v1, v2):
        msg = 'For version: {0!r}'.format(v1)

        vbump = bump_version(v1)
        assert vbump == v2, msg

        vbump = bump_version(v1, position=0)
        assert vbump == v2, msg

        vbump = bump_version(v1, position=1)
        assert vbump == v2, msg

        vbump = bump_version(v1, position=0, pre_release='a')
        assert vbump == v2, msg

        vbump = bump_version(v1, position=0, pre_release='b')
        assert vb

# Generated at 2022-06-11 22:30:35.184980
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    t_bump_version = bump_version

    def _tst(*args, **kwargs):
        return t_bump_version(*args, **kwargs)

    assert _tst('1.2.2') == '1.2.3'
    assert _tst('1.2.2', position=2) == '1.2.3'
    assert _tst('1.2.3', position=1) == '1.3'
    assert _tst('1.3.4', position=0) == '2.0'
    assert _tst('1.2.3', prerelease='a') == '1.2.4a0'

# Generated at 2022-06-11 22:30:42.957137
# Unit test for function bump_version
def test_bump_version():
    """Test function(s) in module: flutils.packages
    """
    def test_bump_version_1():
        """Test function(s) in module: flutils.packages
        """
        # Test 1
        res = bump_version('1.2.2')
        assert res == '1.2.3'
        # Test 2
        res = bump_version('1.2.3', position=1)
        assert res == '1.3'
        # Test 3
        res = bump_version('1.3.4', position=0)
        assert res == '2.0'
        # Test 4
        res = bump_version('1.2.3', prerelease='a')
        assert res == '1.2.4a0'
        # Test 5

# Generated at 2022-06-11 22:30:55.713439
# Unit test for function bump_version
def test_bump_version():
    """Flutils -- test 'bump_version' function."""
    # noinspection PyStatementEffect

# Generated at 2022-06-11 22:31:05.906446
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version."""
    print(bump_version('1.2.2'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-11 22:31:18.641616
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from .version import version as flutils_ver
    from .version import version_info as flutils_ver_info
    from .version import version_tuple as flutils_ver_tpl
    from .version import version_dict as flutils_ver_dct

    imports = (
        ('flutils', False),
        ('flutils.packages', True),
    )
    for import_ in imports:
        module = import_[0]
        if import_[1] is True:
            import_module = importlib.import_module(module)
        else:
            # noinspection PyUnresolvedReferences
            import_module = importlib.import_module(module)

        if hasattr(import_module, '__version__'):
            assert \
                import_module.__

# Generated at 2022-06-11 22:31:24.970006
# Unit test for function bump_version
def test_bump_version():
    r"""Tests for function bump_version."""
    from flutils.packages import _test_bump_version
    _test_bump_version()


if __name__ == '__main__':
    # Unit test for function bump_version
    test_bump_version()

# Generated at 2022-06-11 22:31:34.926627
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.
    """
    # pylint: disable=W0612,C0103
    import sys

    def get_version_info(s):
        vs = [int(v) for v in s.split('.')]
        return (len(vs) == 3, vs[0], vs[1], vs[2])

    def test_basic():
        assert bump_version('1.2.1', 0) == '2.0'
        assert bump_version('1.2.1', 1) == '1.3'
        assert bump_version('1.2.1', 2) == '1.2.2'
        assert bump_version('1.2.1', -1) == '1.2.2'

# Generated at 2022-06-11 22:31:52.649060
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0212
    from unittest.mock import patch as _patch  # nosec
    from .tutil import UnitTBase

    class TestBumpVersion(UnitTBase):
        def setUp(self):
            UnitTBase.setUp(self)
            self._set_test_function(test_bump_version())

        def test_000_basic(self):
            self._test_case(
                bump_version('1.2.2'),
                '1.2.3'
            )

        def test_001_minor_with_no_pre_release(self):
            self._test_case(
                bump_version('1.2.3', position=1),
                '1.3'
            )


# Generated at 2022-06-11 22:32:03.653428
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=I0011,C0103
    cvt = bump_version
    assert cvt('1.2.2') == '1.2.3'
    assert cvt('1.2.3', position=1) == '1.3'
    assert cvt('1.3.4', position=0) == '2.0'
    assert cvt('1.2.3', prerelease='a') == '1.2.4a0'
    assert cvt('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert cvt('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert cvt('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:15.752018
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Test for 'bump_version'
    assert bump_version('1.2.3') == '1.2.4'

    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:32:28.512252
# Unit test for function bump_version
def test_bump_version(): # pylint: disable=missing-function-docstring
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', position=1) == '1.3'

# Generated at 2022-06-11 22:32:35.840057
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the bump_version function."""
    try:
        bump_version('1.2.2')
        bump_version('1.2.3', position=1)
        bump_version('1.3.4', position=0)
        bump_version('1.2.3', prerelease='a')
        bump_version('1.2.4a0', pre_release='a')
        bump_version('1.2.4a1', pre_release='b')
        bump_version('1.2.4a1')
        bump_version('1.2.4b0')
        bump_version('2.1.3', position=1, pre_release='a')
        bump_version('1.2b0', position=2)
    except Exception:
        return False
    return True

# Generated at 2022-06-11 22:32:47.287898
# Unit test for function bump_version
def test_bump_version():
    """Testing Function bump_version."""

    from flutils.packages import bump_version

    # Given a version number "major.minor.patch" increase the:
    # patch: by default
    assert bump_version('1.2.2') == '1.2.3'
    # minor: if the 'position' argument is set to one
    assert bump_version('1.2.3', position=1) == '1.3'
    # major: if the 'position' argument is set to zero
    assert bump_version('1.3.4', position=0) == '2.0'
    # patch: by default, if an alpha version number exists
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    # next alpha version, if the 'pre_release'

# Generated at 2022-06-11 22:32:53.367997
# Unit test for function bump_version
def test_bump_version():  # noqa
    """Unit test for function: :func:`bump_version`."""
    from flutils.packages import bump_version

# Generated at 2022-06-11 22:33:03.070631
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=I0011,C0111
    import pytest

    with pytest.raises(ValueError):
        bump_version('v1.2.3')
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=-4)
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=3)
    with pytest.raises(ValueError):
        bump_version('1.2.3', pre_release='c')
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=-3, pre_release='a')
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=0, pre_release='a')

# Generated at 2022-06-11 22:33:10.080680
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    ver_info = _build_version_info('1.2.3')
    version = ver_info.version
    parts: Dict[str, Optional[Any]] = {
        'major': ver_info.major,
        'minor': ver_info.minor,
        'patch': ver_info.patch
    }
    assert version == '1.2.3'
    assert parts['major'].txt == '1'
    assert parts['minor'].txt == '2'
    assert parts['patch'].txt == '3'

    ver_info = _build_version_info('1.2.3a5')
    version = ver_info.version

# Generated at 2022-06-11 22:33:17.320375
# Unit test for function bump_version
def test_bump_version():
    """Test for function flutil.packages.bump_version()."""
    from flutils.packages import bump_version  # pylint: disable=E0611,E0401

# Generated at 2022-06-11 22:33:34.381390
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version.

    This function is designed to be used as a unit test.

    Example:
        >>> from flutils.packages import bump_version
        >>> test_bump_version()

    """
    from flutils.common import get_caller_info


# Generated at 2022-06-11 22:33:45.983430
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    """Unit test for function bump_version"""
    def _build_version_string(
            major: int,
            minor: int,
            patch: int,
            pre_type: str,
            pre_num: int
    ) -> str:
        ver = '%s.%s.%s' % (major, minor, patch)
        if pre_type:
            ver = '%s%s%s' % (ver, pre_type, pre_num)
        return ver


# Generated at 2022-06-11 22:33:47.992099
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""

    return bump_version('0.3.0-alpha.1')

# Generated at 2022-06-11 22:33:57.027421
# Unit test for function bump_version
def test_bump_version():
    # pragma: no cover
    ver_info = _build_version_info('1.1.1')

    assert ver_info.version == '1.1.1'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 1
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.1.1a0')

    assert ver_info.version == '1.1.1a0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 1
    assert ver_info.pre_pos == 2


# Generated at 2022-06-11 22:34:09.941880
# Unit test for function bump_version
def test_bump_version():
    """Execute unit test for function bump_version"""

    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:34:22.260488
# Unit test for function bump_version

# Generated at 2022-06-11 22:34:37.292688
# Unit test for function bump_version
def test_bump_version():
    from reframe.utility.sanity import check_equal

    check_equal('1.2.2', bump_version('1.2.2'))
    check_equal('1.2.3', bump_version('1.2.2', position=2))
    check_equal('1.3', bump_version('1.2.2', position=1))
    check_equal('2.0', bump_version('1.2.2', position=0))
    check_equal('1.2.4a0', bump_version('1.2.3', prerelease='a'))
    check_equal('1.2.4a1', bump_version('1.2.4a0', pre_release='a'))

# Generated at 2022-06-11 22:34:43.977556
# Unit test for function bump_version
def test_bump_version():

    # Tests 1 - 10, normal version bumps
    for test_num in range(1, 11):
        if test_num in (1, 7):
            expected = '1.2.3'
        elif test_num in (2, 8):
            expected = '1.3'
        elif test_num in (3, 9):
            expected = '2.0'
        else:
            expected = '1.2.4'

        if test_num in (1, 2, 3, 4):
            args = ()
        elif test_num in (5, 6, 7, 8):
            args = (1,)
        else:
            args = (0,)

        if test_num in (1, 5, 9):
            kwargs = {}

# Generated at 2022-06-11 22:34:51.391065
# Unit test for function bump_version
def test_bump_version():
    import unittest
    class TestBumpVersion(unittest.TestCase):
        def test_basic(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

        def test_prerelease(self):
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
            self.assertEqual(bump_version('1.2.4a0', pre_release='a'),
                             '1.2.4a1')
            self.assertE

# Generated at 2022-06-11 22:35:01.985104
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import pytest

# Generated at 2022-06-11 22:35:17.063989
# Unit test for function bump_version
def test_bump_version():
    import unittest
    from ..unittests.env import create_env

    env = create_env()
    env.execute('''
        from __future__ import print_function
        from flutils.packages import bump_version

        try:
            # an import like this is needed for the unit tests
            print('version=%s' % bump_version('1.2.3', position=1))
        except ValueError:
            pass
    ''')
    output = 'version=1.3'
    if env.last_out.strip() != output:  # pragma: no cover
        unittest.TestCase().fail('The output of "bump_version()" should be: '
                                 '"%s"' % output)



# Generated at 2022-06-11 22:35:26.864203
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""

    def _bump(
            ver: str,
            pos: int,
            pre: Optional[str] = None,
            exp: Optional[str] = None
    ) -> None:
        """Call :func:`~flutils.packages.bump_version` and test
        the result.

        """
        if exp is None:
            raise ValueError(
                "Must provide a value for the 'exp' parameter."
            )
        try:
            out = bump_version(ver, pos, pre)
        except Exception as exc:
            if isinstance(exp, Exception) is True:
                assert isinstance(exc, type(exp)) is True
                return
            raise
        assert out == exp


# Generated at 2022-06-11 22:35:35.771902
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'