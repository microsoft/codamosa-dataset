

# Generated at 2022-06-11 22:25:52.290329
# Unit test for function bump_version
def test_bump_version():
    """Test the unit of function bump_version."""
    from flutils.testing import assert_function

    def _test_func(version, position=2, pre_release=None):
        return bump_version(version, position, pre_release)

    assert_function(
        test_module=bump_version,
        func=_test_func,
        func_name='bump_version'
    )

# Generated at 2022-06-11 22:26:03.417084
# Unit test for function bump_version
def test_bump_version():

    # Test basic version numbering
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:26:11.260995
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Unit test for function bump_version."""
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:26:21.345238
# Unit test for function bump_version
def test_bump_version():
    from datetime import date
    from dateutil.parser import parse
    from textwrap import dedent
    from unittest.mock import patch

    from flutils.packages import bump_version

    # Test script, package version
    import flutils
    version = flutils.__version__
    version_bumped = bump_version(version)

    # Script: Test package version
    ver_parts = version.split('.')
    ver_parts_bumped = version_bumped.split('.')

    # Script: compare version numbers
    count = len(ver_parts)
    count_bumped = len(ver_parts_bumped)
    assert count_bumped == count

    # Script: compare version numbers
    for i in range(count):
        part = int(ver_parts[i])
        part_bumped = int

# Generated at 2022-06-11 22:26:29.184519
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version, the unit test."""
    # pylint: disable=C0111
    expected_results: List[str] = [
        '1.2.3',
        '1.3',
        '2.0',
        '1.2.4a0',
        '1.2.4a1',
        '1.2.4b0',
        '1.2.4',
        '1.2.4',
        '2.2a0',
        '1.2.1'
    ]

# Generated at 2022-06-11 22:26:37.049408
# Unit test for function bump_version
def test_bump_version():
    import random
    import unittest
    import sys

    class VersionUnitTests(unittest.TestCase):
        def test_bumps_from_wrong_types(self):
            version: Any = None
            position: Any = None
            prerelease: Any = None
            with self.assertRaises(TypeError):
                bump_version(  # pylint: disable=E1120
                    version=version, position=position, pre_release=prerelease
                )

            version = ''
            position = 'a'
            prerelease = 'b'
            with self.assertRaises(ValueError):
                bump_version(  # pylint: disable=E1120
                    version=version, position=position, pre_release=prerelease
                )


# Generated at 2022-06-11 22:26:48.096319
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Test function: bump_version."""
    import unittest

    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        """Test class: bump_version."""

        def test_1(self):
            """Test: bump_version."""
            self.assertEqual(bump_version('2.3.4'), '2.3.5')

        def test_2(self):
            self.assertEqual(bump_version('1.2.0'), '1.2.1')

        def test_3(self):
            self.assertEqual(bump_version('1.2.0', position=0), '2.0')


# Generated at 2022-06-11 22:27:01.255526
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.py import join_namespace
    from unittest import TestCase
    from io import StringIO

    from flutils.packages import bump_version

    join_namespace(globals(), locals())

    class Tester(TestCase):
        """Unit test for function bump_version."""

        def test_version_1(self):
            """Function bump_version, test version 1."""
            self.assertEqual(
                bump_version('1.2.2'),
                '1.2.3'
            )

        def test_version_2(self):
            """Function bump_version, test version 2."""
            self.assertEqual(
                bump_version('1.2.3', position=1),
                '1.3'
            )



# Generated at 2022-06-11 22:27:13.142549
# Unit test for function bump_version

# Generated at 2022-06-11 22:27:21.302954
# Unit test for function bump_version

# Generated at 2022-06-11 22:27:47.955983
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version'"""

    # Arrange

# Generated at 2022-06-11 22:27:58.695074
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:28:07.552456
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function flutils.packages.bump_version."""
    from flutils.packages import bump_version  # pylint: disable=E0611,E0401
    from flutils.testing import capture_stdout  # pylint: disable=E0611,E0401

    with capture_stdout() as stdout:
        version = bump_version('1.2.2')
    assert version == '1.2.3'
    assert stdout.getvalue() == ''

    with capture_stdout() as stdout:
        version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    assert stdout.getvalue() == ''


# Generated at 2022-06-11 22:28:17.481974
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    import os
    import sys
    from flutils.packages import bump_version
    from flutils.pkgs import PkgResourcesUtils

    import pytest


# Generated at 2022-06-11 22:28:28.842853
# Unit test for function bump_version
def test_bump_version():
    """Test for function ``bump_version``."""
    # noinspection PyUnresolvedReferences
    from flutils.packages import bump_version

    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-11 22:28:41.409246
# Unit test for function bump_version
def test_bump_version():
    tests = []

    # Test no pre-release
    name = 'Test no pre-release'
    version = '1.2.3'
    position = 2
    pre_release = None
    expected = '1.2.4'
    args = [version, position, pre_release]
    kwargs = {}
    tests.append((name, args, kwargs, expected))

    # Test no pre-release, position one
    name = 'Test no pre-release, position one'
    version = '1.2.3'
    position = 1
    pre_release = None
    expected = '1.3'
    args = [version, position, pre_release]
    kwargs = {}
    tests.append((name, args, kwargs, expected))

    # Test no pre-release, position zero
   

# Generated at 2022-06-11 22:28:48.284041
# Unit test for function bump_version
def test_bump_version():
    """Test for function ``bump_version``."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:28:59.358590
# Unit test for function bump_version
def test_bump_version():
    """Test :func:`bump_version`."""
    func = bump_version
    # noinspection PyTypeChecker
    assert func('1.2.2') == '1.2.3'
    assert func('1.2.2', position=1) == '1.3'
    assert func('1.2.2', position=0) == '2.0'
    assert func('1.2.3', pre_release='a') == '1.2.4a0'
    assert func('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert func('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert func('1.2.4a1') == '1.2.4'


# Generated at 2022-06-11 22:29:12.122978
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""


# Generated at 2022-06-11 22:29:23.574223
# Unit test for function bump_version
def test_bump_version():
    import os

    import flutils.system

    from flutils.packages import bump_version

    pkgdir = flutils.system.get_python_package_dir('flutils')
    verfile = os.path.join(pkgdir, '__version__.py')

    exec(compile(open(verfile, "rb").read(), verfile, 'exec'), globals())
    orig_version = __version__
    new_version = bump_version(orig_version)
    assert new_version != orig_version
    orig_version = new_version
    new_version = bump_version(orig_version, position=0)
    assert new_version != orig_version
    orig_version = new_version
    new_version = bump_version(orig_version, position=1, pre_release='a')
    assert new_version

# Generated at 2022-06-11 22:29:43.244702
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:55.232744
# Unit test for function bump_version
def test_bump_version():
    """Test the version number bumping logic.

    Raises:
        AssertionError: if any test fails

    """
    def test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected_result: str
    ) -> None:
        actual_result = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert expected_result == actual_result, (
            "Expected: %r. "
            "Got: %r." % (expected_result, actual_result)
        )

    test('1.2.2', position=2, pre_release=None, expected_result='1.2.3')

# Generated at 2022-06-11 22:30:06.526086
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    eq = lambda a, b: print('Pass' if a == b else 'Fail')
    eq(bump_version('1.2.2'), '1.2.3')
    eq(bump_version('1.2.3', position=1), '1.3')
    eq(bump_version('1.3.4', position=0), '2.0')
    eq(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
    eq(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')
    eq(bump_version('1.2.4a1', pre_release='b'), '1.2.4b0')

# Generated at 2022-06-11 22:30:17.181448
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import assert_function_outputs


# Generated at 2022-06-11 22:30:25.845746
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    from collections import namedtuple
    from flutils.packages import bump_version
    from pprint import pprint

    TestData = namedtuple('TestData', [
        'version',
        'position',
        'pre_release',
        'result',
        'msg'
    ])


# Generated at 2022-06-11 22:30:35.271130
# Unit test for function bump_version

# Generated at 2022-06-11 22:30:42.996675
# Unit test for function bump_version
def test_bump_version():
    def ut(v_in, v_out, p_pos=2, p_pre=None):
        out = bump_version(v_in, position=p_pos, pre_release=p_pre)
        if out != v_out:
            raise Exception("Unit test failed for: %r" % v_in)

    # noinspection PyUnusedLocal
    def tu(v_in, p_pos=2, p_pre=None):
        try:
            bump_version(v_in, position=p_pos, pre_release=p_pre)
        except Exception:
            pass
        else:
            raise Exception("Unit test failed for: %r" % v_in)

    ut('1.2.2', '1.2.3')

# Generated at 2022-06-11 22:30:55.773519
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    """
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:31:00.685450
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    """Tests the ``bump_version`` function."""
    from flutils.packages import bump_version

    def _test(version: str, expected: str,
              position: int = 2, pre_release: str = None):
        actual = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert expected == actual

    _test('1.2.2', '1.2.3')
    _test('1.2.3', '1.3', position=1)
    _test('1.3.4', '2.0', position=0)
    _test('1.2.3', '1.2.4a0', pre_release='a')

# Generated at 2022-06-11 22:31:08.259661
# Unit test for function bump_version
def test_bump_version():
    import pytest # type: ignore
    import os

    # Test 'bump_version'
    data_dir = os.path.join(os.path.dirname(__file__), 'bump_version')
    for ver_file in os.listdir(data_dir):
        ver_file_path = os.path.join(data_dir, ver_file)
        with open(ver_file_path, 'rt') as fh:
            data = fh.read().strip('\n')
        expected, raw_inputs = data.split('\n', 1)
        raw_inputs = raw_inputs.split('\n')
        inputs = {}
        for inp in raw_inputs:
            k, v = inp.split('=', 1)
            k = k.strip()

# Generated at 2022-06-11 22:31:32.096664
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=protected-access
    from flutils.py23 import NoneType  # pylint: disable=E0611,E0401
    from random import choice

    nt = NoneType
    prerelease_choices = ('a', 'alpha', 'b', 'beta')
    prerelease_values = prerelease_choices + (None, )

# Generated at 2022-06-11 22:31:40.172483
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:31:51.452915
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import os

    import pytest

    from flutils.packages import bump_version

    cur_dir = os.path.dirname(__file__)


# Generated at 2022-06-11 22:32:02.936776
# Unit test for function bump_version

# Generated at 2022-06-11 22:32:08.012064
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Trivial test.
    assert bump_version('1.2.2') == '1.2.3'

    # Test that the minor version is increased when position is 1.
    assert bump_version('1.2.3', position=1) == '1.3'

    # Test that the major version is increased when position is 0.
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test that alpha version is bumped.
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Test that the alpha version is increased.
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Test

# Generated at 2022-06-11 22:32:13.554673
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    Raises:
        ValueError: If a test fails.

    """
    from flutils.textutils import obj2str
    from re import match, search

    def test_basic(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected: str = ''
    ) -> None:
        if expected == '':
            return
        out = bump_version(version, position, pre_release)

# Generated at 2022-06-11 22:32:25.297226
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    test_num = 0
    result: str
    errors: List[str] = []

# Generated at 2022-06-11 22:32:34.655559
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

# Generated at 2022-06-11 22:32:43.893328
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=W0612
    from flutils.testing import capture_stdout_stderr, run_doctest

    results = run_doctest(
        'bump_version',
        module=__name__,
        doctest_kwargs=dict(raise_on_error=True, verbose=True)
    )
    with capture_stdout_stderr() as (stdout, stderr):
        for result in results:
            print(result)
    return bool(results)

# Generated at 2022-06-11 22:32:51.388432
# Unit test for function bump_version
def test_bump_version():
    r"""Test function bump_version.

    *New in version 0.3.1*
    """

    # Import standard packages
    import os

    # Import installed packages
    from flutils.packages import bump_version

    # Define variables

# Generated at 2022-06-11 22:33:25.138295
# Unit test for function bump_version
def test_bump_version():
    from flutils.misc import compare_dicts
    from flutils.packages import bump_version

    def _compare_dicts(
            expected: Dict[str, Any],
            result: Dict[str, Any],
            msg: Optional[str] = None,
    ) -> None:
        if compare_dicts(expected, result, 'ne') is True:
            msg = msg or ''
            raise AssertionError(
                "The given result dictionary does not match expected:\n"
                "Expected: %r\nResult: %r\n%s" % (expected, result, msg)
            )

    def _build_kwargs_bump_version(data: Dict[str, Any]) -> Dict[str, Any]:
        """Builds kwargs for bump_version.
        """

# Generated at 2022-06-11 22:33:34.285967
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

    from . import bump_version
    from npt.utils.env import get_pybin_env, get_pybin_bin

    # Get a Python interpreter to test against
    pybin = get_pybin_env()
    cmd = get_pybin_bin(pybin)
    assert cmd is not None

    # Import the source module into the interpreter
    ret = pybin.call('import os; import sys; cur = os.getcwd();'
                     'sys.path.insert(0, cur);'
                     'from flutils.packages import bump_version',
                     )
    assert ret.stderr == ''
    assert ret.returncode == 0

    # Test it!

# Generated at 2022-06-11 22:33:44.795786
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.2')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

test_bump_version()

# Generated at 2022-06-11 22:33:54.943163
# Unit test for function bump_version
def test_bump_version():  # noqa: D103,D301
    """Unit tests for function bump_version."""
    import sys
    import flutils.packages

    version = flutils.packages.__version__
    ver_info = _build_version_info(version)
    assert ver_info.major.num == 1, 'Major version number.'
    assert ver_info.minor.num == 3, 'Minor version number.'
    assert ver_info.patch.num == 2, 'Patch version number.'

    pre_release = None
    assert bump_version('1.2.2') == '1.2.3', 'Patch bump'
    assert bump_version('1.2.3', position=1) == '1.3', 'Minor bump'

# Generated at 2022-06-11 22:34:04.211111
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    """Unit test for function bump_version"""
    # pylint: disable=R0914
    # pylint: disable=W0612

# Generated at 2022-06-11 22:34:15.159791
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version.
    """
    import pytest
    with pytest.raises(ValueError) as pos_exc:
        bump_version('1.2.3', position=-4)
    assert str(pos_exc.value) == (
        "The given value for 'position', -4, must be an 'int' "
        "between (-3) and (2)."
    )

    with pytest.raises(ValueError) as exc:
        bump_version('1.2.3', position=-1, pre_release='alpha')
    assert str(exc.value) == (
        "Only the 'minor' or 'patch' parts of the version number "
        "can get a prerelease bump."
    )

    with pytest.raises(ValueError) as exc:
        bump_

# Generated at 2022-06-11 22:34:24.407538
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function flutils.packages.bump_version"""
    from flutils.packages import bump_version
    from flutils.testing import capture  # type: ignore
    from flutils.testing import PrintCapture  # type: ignore

    # noinspection PyUnusedLocal
    def _run_test(
            args: Tuple[str, ...],
            position: Optional[int] = 2,
            pre_release: Optional[str] = None,
            expected: Optional[str] = None,
            expected_error: Optional[str] = None
    ) -> Tuple[str, ...]:
        """Helper function to validate function bump_version"""

# Generated at 2022-06-11 22:34:37.903372
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version

    *New in version 0.3*
    """
    import unittest

    class _Test(unittest.TestCase):
        def test_1(self):
            version = '3.3.3'
            out = bump_version(version, position=0)
            self.assertEqual(out, '4.0')

        def test_2(self):
            version = '3.3.3'
            out = bump_version(version, position=1)
            self.assertEqual(out, '3.4')

        def test_3(self):
            version = '3.3.3'
            out = bump_version(version)
            self.assertEqual(out, '3.3.4')


# Generated at 2022-06-11 22:34:48.874068
# Unit test for function bump_version
def test_bump_version():
    def _check_output(out, ver, pos, pre):
        msg = 'bump_version(%r) returned %r, not %r'
        assert out == bump_version(ver, pos, pre), msg % (ver, out, ver)

    _check_output('1.2.3', '1.2.2', 2, '')
    _check_output('1.3', '1.2.3', 1, '')
    _check_output('2.0', '1.3.4', 0, '')
    _check_output('1.2.4a0', '1.2.3', 2, 'a')
    _check_output('1.2.4a1', '1.2.4a0', 2, 'a')

# Generated at 2022-06-11 22:35:00.666982
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version()."""
    # pylint: disable=R0801,C0116,R1705
    import re
