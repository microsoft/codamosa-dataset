

# Generated at 2022-06-11 22:25:52.820311
# Unit test for function bump_version
def test_bump_version():
    """Quick unit test for the functions provided in this module.

    Args:
        None

    Raises:
        AssertionError: if any of the unit tests fail.
        ValueError: if the version number given to :func:`bump_version`,
            is not a valid version number.

    Returns:
        None.

    """

# Generated at 2022-06-11 22:26:01.111808
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-11 22:26:06.385346
# Unit test for function bump_version
def test_bump_version():
    """Test the function 'bump_version'"""
    from flutils.versions import bump_version
    assert bump_version('0.3.3') == '0.3.4'
    assert bump_version('0.3.3', position=1) == '0.4'
    assert bump_version('0.3.3', position=0) == '1.0'
    assert bump_version('0.3.3', prerelease='a') == '0.3.4a0'
    assert bump_version('0.3.4a0', pre_release='a') == '0.3.4a1'
    assert bump_version('0.3.4a1', pre_release='a') == '0.3.4a2'

# Generated at 2022-06-11 22:26:17.303195
# Unit test for function bump_version

# Generated at 2022-06-11 22:26:27.442989
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version')

    print('  Testing invalid types')
    try:
        bump_version(1)
    except ValueError as exp:
        print('    Got: %s' % exp)
    else:
        print('    Expected a ValueError')

    for ver in (
            'invalid',
            'invalid.invalid'
    ):
        try:
            bump_version(ver)
        except ValueError as exp:
            print('    Got: %s' % exp)
        else:
            print('    Expected a ValueError')

    print('  Testing position out of range')
    for pos in (-4, 3):
        try:
            bump_version('1.2.3', position=pos)
        except ValueError as exp:
            print('    Got: %s' % exp)

# Generated at 2022-06-11 22:26:36.089800
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3', 'FAIL 1'
    assert bump_version('1.2.3', position=1) == '1.3', 'FAIL 2'
    assert bump_version('1.3.4', position=0) == '2.0', 'FAIL 3'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0', 'FAIL 4'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1', 'FAIL 5'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0', 'FAIL 6'

# Generated at 2022-06-11 22:26:47.731679
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""

# Generated at 2022-06-11 22:26:52.218084
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:04.254228
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:27:15.785143
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3.4') == '1.2.4'
    assert bump_version('1.x.3.4') == '1.x.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3b0'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'

# Generated at 2022-06-11 22:27:44.585070
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.testutils import is_valid_version
    from flutils.testutils import is_valid_version_bump
    from flutils.testutils import get_valid_versions
    from flutils.testutils import get_valid_versions_bump
    for ver, pos, pre in get_valid_versions_bump():
        out = bump_version(ver, pos, pre)
        msg = "The bump_version() function failed to create a valid version " \
              "number from: '%s', at position (%s), pre-release (%s)" % (
                  ver, pos, repr(pre)
              )
        assert is_valid_version_bump(out, ver, pos, pre), msg

# Generated at 2022-06-11 22:27:53.011673
# Unit test for function bump_version
def test_bump_version():
    """
    Usage: python3 ./path/to/flutils/packages.py 
    """
    from pprint import pprint
    from collections import OrderedDict

# Generated at 2022-06-11 22:28:03.122298
# Unit test for function bump_version
def test_bump_version():
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    assert bump_version(ver, 1) == '1.3'
    assert bump_version(ver, 0) == '2.0'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'
    assert bump_version(ver, pre_release='b') == '1.2.4b0'
    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'
    assert bump_version(ver, pre_release='b') == '1.2.4b0'
    ver = '1.2.4b0'

# Generated at 2022-06-11 22:28:15.655071
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_bump_version(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', pre_release='a'),
                             '1.2.4a0')
            self.assertEqual(bump_version('1.2.4a0', pre_release='a'),
                             '1.2.4a1')

# Generated at 2022-06-11 22:28:26.935128
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    version = '1.2.2'
    assert bump_version(version) == '1.2.3'

    version = '1.2.3'
    position = 1
    assert bump_version(version, position) == '1.3'

    version = '1.3.4'
    position = 0
    assert bump_version(version, position) == '2.0'

    version = '1.2.3'
    pre_release = 'a'
    assert bump_version(version, pre_release=pre_release) == '1.2.4a0'

    version = '1.2.4a0'
    pre_release = 'a'

# Generated at 2022-06-11 22:28:34.659907
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0115
    version = '0.0.0'
    if bump_version(version) != '0.0.1':
        return False
    version = '0.0.1'
    if bump_version(version) != '0.0.2':
        return False
    version = '0.1.0'
    if bump_version(version) != '0.1.1':
        return False
    version = '1.0.0'
    if bump_version(version) != '1.0.1':
        return False
    version = '1.0.1'
    if bump_version(version, position=0) != '2.0':
        return False
    if bump_version(version, position=1) != '1.1':
        return False
    version

# Generated at 2022-06-11 22:28:45.203147
# Unit test for function bump_version
def test_bump_version():
    fnc_name = 'bump_version'

# Generated at 2022-06-11 22:28:57.794920
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from tests.testingutils import print_fails
    from tests.testingutils import run_test_module_by_name

    # noinspection PyUnusedLocal
    def assert_v(ver: str, pos: int, pre: Optional[str], out: str):
        c_out = bump_version(ver, pos, pre)
        if c_out != out:
            print_fails(
                'bump_version(%r, %r, %r)' % (ver, pos, pre),
                c_out,
                out
            )

    assert_v('1.2.2', 2, None, '1.2.3')
    assert_v('1.2.3', 1, None, '1.3')

# Generated at 2022-06-11 22:29:06.403657
# Unit test for function bump_version
def test_bump_version():
    """Unit test for :func:`bump_version`."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:10.721709
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:27.308909
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0914
    """Unit test for function bump_version

    """
    from os import path
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.packages import bump_version

    base_path = path.join(path.dirname(path.abspath(__file__)), 'data')
    test_data_path = path.join(base_path, 'version', 'data.json')
    with open(test_data_path) as t_data:
        tests: List[Any] = cast(List[Any], t_data.read())

    class VersionTest(TestCase):
        """

        """

        maxDiff = 4096


# Generated at 2022-06-11 22:29:38.588896
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:29:46.987240
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version() function.
    """
    from test_packages import (
        assert_common as a,
        assert_info,
        assert_one,
        assert_two,
        TMP_DIR,
        TMP_FILE,
    )

# Generated at 2022-06-11 22:29:57.336681
# Unit test for function bump_version
def test_bump_version(): # pragma: no cover
    """
    Unit test for function bump_version
    """
    import sys
    import traceback
    import unittest

    class BumpVersionTestCase(unittest.TestCase):  #pylint: disable=R0904
        """
        Test case for function bump_version
        """
        def test_bump_version(
                self,
                version: str,
                expected_out: str,
                position: int = 2,
                pre_release: Optional[str] = None
        ) -> None:
            """
            Test function bump_version
            """
            out = bump_version(version, position, pre_release)

# Generated at 2022-06-11 22:30:07.425466
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for bump_version"""
    # pylint: disable=protected-access,too-many-locals,too-many-statements
    from pytest import raises  # type: ignore


# Generated at 2022-06-11 22:30:17.780292
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version() function"""

    # _build_version_info()

# Generated at 2022-06-11 22:30:26.066632
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('3.2.1', position=2, pre_release='b') == '3.2.2b0'
    assert bump_version('3.2.1b0') == '3.2.1'
    assert bump_version('3.2.1b1') == '3.2.1b2'
    assert bump_version('3.2.1b1', position=1) == '3.2.2'
    assert bump_version('3.2.1a5', position=1) == '3.2.2'
    assert bump_version('3.2.1a5', position=3) == '3.2.2'
    assert bump_version('3.2.1a5', position=2) == '3.2.2'


# Generated at 2022-06-11 22:30:35.620557
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    def _test(
            version: str, position: int, pre_release_txt: Optional[str],
            expected: str
    ):
        """
        Unit test for function bump_version
        """
        assert bump_version(
            version=version,
            position=position,
            pre_release=pre_release_txt
        ) == expected

    # noinspection SpellCheckingInspection
    _test('1.2.3', position=2, pre_release_txt=None, expected='1.2.4')
    _test('1.2.0', position=2, pre_release_txt=None, expected='1.2.1')

# Generated at 2022-06-11 22:30:44.509235
# Unit test for function bump_version
def test_bump_version():
    """Testing function bump_version()."""

# Generated at 2022-06-11 22:30:57.406761
# Unit test for function bump_version
def test_bump_version():
    def run_test(
            ver,
            position=2,
            pre_release=None,
            expected=None,
            expected_err=False
    ):
        try:
            actual = bump_version(ver, position, pre_release)
            assert actual == expected
        except Exception as err:
            if expected_err is False:
                raise
            if expected != str(err):
                raise
    run_test('1.2.2', expected='1.2.3')
    run_test('1.2.3', position=1, expected='1.3')
    run_test('1.3.4', position=0, expected='2.0')
    run_test('1.2.3', pre_release='a', expected='1.2.4a0')

# Generated at 2022-06-11 22:31:19.717544
# Unit test for function bump_version

# Generated at 2022-06-11 22:31:32.505869
# Unit test for function bump_version

# Generated at 2022-06-11 22:31:40.315895
# Unit test for function bump_version
def test_bump_version():
    version: str = '1.2.3'
    out: str = bump_version(version)
    assert out == '1.2.4'

    version: str = '1.2.3'
    out: str = bump_version(version, position=1)
    assert out == '1.3'

    version: str = '1.2.3'
    out: str = bump_version(version, position=0)
    assert out == '2.0'

    version: str = '1.2.3'
    out: str = bump_version(version, prerelease='a')
    assert out == '1.2.4a0'

    version: str = '1.2.4a0'
    out: str = bump_version(version, pre_release='a')

# Generated at 2022-06-11 22:31:51.505697
# Unit test for function bump_version
def test_bump_version():
    import pytest

# Generated at 2022-06-11 22:32:02.966340
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:08.052229
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-statements
    from collections import OrderedDict

    import sys

    import pytest

    if sys.version_info < (3, 6, 0):
        pytest.skip("Can only run on Python 3.6+.")

    version_dict = OrderedDict()
    version_dict['1.2.0'] = OrderedDict([
        ('major', '2.0.0'), ('minor', '1.3.0'), ('patch', '1.2.1')
    ])
    version_dict['1.3.0'] = OrderedDict([
        ('major', '2.0.0'), ('minor', '1.4.0'), ('patch', '1.3.1')
    ])
    version_dict['1.3.1'] = Ordered

# Generated at 2022-06-11 22:32:18.516383
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'.
    """

# Generated at 2022-06-11 22:32:30.763143
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:32:42.208083
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3.7*

    """

# Generated at 2022-06-11 22:32:49.993454
# Unit test for function bump_version
def test_bump_version():

    def _test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expected_result: Optional[str] = None
    ) -> None:
        result = bump_version(version, position, pre_release)
        if expected_result is not None:
            assert result == expected_result, result
        else:
            raise ValueError(
                "Must provide an expected result for test for: %r" % version
            )

    _test('1.2.2', 2, None, '1.2.3')
    _test('1.2.3', 1, None, '1.3')
    _test('1.3.4', 0, None, '2.0')

# Generated at 2022-06-11 22:33:03.343937
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-11 22:33:14.091812
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version

    :return:
    """

# Generated at 2022-06-11 22:33:27.291123
# Unit test for function bump_version
def test_bump_version():
    """ Test suite for function: bump_version. """
    from flutils.packages import bump_version

    def _assert_error(
            msg: str,
            ver_: str,
            pos: int,
            prerel: str
    ) -> None:
        try:
            bump_version(ver_, pos, prerel)
        except ValueError as err:
            assert msg == str(err)
        else:
            raise AssertionError(
                "A ValueError was not raised for the version: "
                "(%r, pos=%r, prerel=%r)." % (ver_, pos, prerel)
            )


# Generated at 2022-06-11 22:33:37.565295
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

# Generated at 2022-06-11 22:33:49.505458
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-11 22:33:57.630371
# Unit test for function bump_version
def test_bump_version():
    def _check_str(version: str, position: int = 2, pre_release: str = ''
                   ) -> None:
        bumped_version = bump_version(version, position, pre_release)
        old_version = StrictVersion(version)
        new_version = StrictVersion(bumped_version)
        if old_version >= new_version:
            raise AssertionError(
                "The bumped version number, %r, is not "
                "greater than the original version %r." % (
                    bumped_version, version
                )
            )

    # Test the major version
    _check_str('0.0.0')
    _check_str('1.0.0')
    _check_str('2.0.0')
    _check_str('2.0.0', position=0)


# Generated at 2022-06-11 22:34:10.743803
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:22.824480
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:34:37.336944
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    import os
    import sys
    import unittest

    # Mock out subprocess_run function
    sys.modules['flutils.packages'].subprocess_run = subprocess_run

    from flutils.packages import bump_version

    # noinspection PyUnresolvedReferences,PyPackageRequirements
    class TestBumpVersion(unittest.TestCase):
        def test_bump_version(self):
            self.assertEqual(
                bump_version('1.2.2'),
                '1.2.3'
            )
            self.assertEqual(
                bump_version('1.2.3', position=1),
                '1.3'
            )

# Generated at 2022-06-11 22:34:44.031631
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

    import pytest

    with pytest.raises(ValueError):
        bump_version('1.2.3', position=1, pre_release='a')

    with pytest.raises(ValueError):
        bump_version('1.2.2', position=-3)

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

# Generated at 2022-06-11 22:35:01.530866
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    from unittest import TestCase
    from . import assert_exit_1
    from . import assert_stdout

    class Test(TestCase):
        def test_version_bump(self):
            from sys import executable
            from os import sep

            from flutils.packages import (  # noqa: F401
                bump_version
            )

            self.assertEqual(bump_version('1.2.3'), '1.2.4')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

# Generated at 2022-06-11 22:35:05.959160
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-11 22:35:15.862661
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=unused-argument

    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals
    r"""Test the bump_version() function.

    The 'test_bump_version()' function is called by
    the :func:`test_all_test_modules()` function.

    """
    from flutils.packages import bump_version


# Generated at 2022-06-11 22:35:26.589796
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the function bump_version

    Raises:
        AssertionError: if the function fails in anyway.

    """
