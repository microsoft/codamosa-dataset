

# Generated at 2022-06-23 18:16:39.981543
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    print('\n' * 2)
    print('Test: bump_version()')
    print('\n * Test: "1.2.2"')
    print('REAL: %s' % bump_version('1.2.2'))
    print('\n * Test: "1.2.3", position=1')
    print('REAL: %s' % bump_version('1.2.3', position=1))
    print('\n * Test: "1.3.4", position=0')
    print('REAL: %s' % bump_version('1.3.4', position=0))
    print('\n * Test: "1.2.3", prerelease="a"')

# Generated at 2022-06-23 18:16:53.032273
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for :class:`_VersionPart`.

    """
    from collections.abc import Iterable
    from flutils.packages import _VersionPart
    from flutils.testing import GenericMock

    ver = _VersionPart.__new__(_VersionPart)
    ver.__init__(
        pos=0,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=0,
        name='major'
    )
    assert ver.pos == 0
    assert ver.txt == '1'
    assert ver.num == 1
    assert ver.pre_txt == 'a'
    assert ver.pre_num == 0
    assert ver.name == 'major'

# Generated at 2022-06-23 18:17:05.836341
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    num = 19
    version = '19.0.0'
    pos = 0
    ctor = _VersionPart
    args = (pos, '%s' % num, num, '', -1, 'major')
    assert ctor(*args) == ctor(
        pos=pos,
        txt='%s' % num,
        num=num,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    num = 1
    pos = 1
    args = (pos, '%s' % num, num, '', -1, 'minor')

# Generated at 2022-06-23 18:17:17.713625
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test versions without a prerelease
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-23 18:17:28.632010
# Unit test for function bump_version
def test_bump_version():
    """Run unit tests for function: ``bump_version``."""
    from flutils.packages import bump_version
    from flutils.testing import test_text_with_optional_eq
    from flutils.toolbox import is_str
    # Set the limit for this test
    max_versions = 10000
    # Run tests

# Generated at 2022-06-23 18:17:40.973627
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3a0')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert isinstance(part.txt, str)
        assert part.num >= 0
        assert isinstance(part.pre_txt, str)
        assert part.pre_num >= -1
        assert isinstance(part.name, str)
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert isinstance(part.txt, str)
        assert part.num >= 0
        assert isinstance(part.pre_txt, str)
        assert part.pre_num >= -1

# Generated at 2022-06-23 18:17:45.914827
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of class _VersionPart."""
    args = dict(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    obj = _VersionPart(**args)
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'
    assert obj
    assert len(obj) == 6
    assert str(obj)



# Generated at 2022-06-23 18:17:54.277656
# Unit test for function bump_version

# Generated at 2022-06-23 18:18:04.614833
# Unit test for function bump_version
def test_bump_version():
    """Unit test for :func:`flutils.packages.bump_version`."""

    def _verify(version, position, pre_release, expected):
        out = bump_version(version, position, pre_release)
        assert out == expected, '%r != %r' % (out, expected)

    _verify('1.2.2', position=2, pre_release=None, expected='1.2.3')
    _verify(
        '1.2.3', position=1, pre_release=None, expected='1.3')
    _verify(
        '1.3.4', position=0, pre_release=None, expected='2.0')

# Generated at 2022-06-23 18:18:15.877067
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:18:27.932208
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('1.2.1', _VersionPart(0, 1, 1, '', -1, 'major'),
                 _VersionPart(1, 2, 2, '', -1, 'minor'),
                 _VersionPart(2, 1, 1, '', -1, 'patch'), -1)
    _VersionInfo('1.2.0', _VersionPart(0, 1, 1, '', -1, 'major'),
                 _VersionPart(1, 2, 2, '', -1, 'minor'),
                 _VersionPart(2, '', 0, '', -1, 'patch'), -1)

# Generated at 2022-06-23 18:18:36.630638
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:18:47.645264
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from unittest import TestCase
    ver_info = _build_version_info('1.2.3')
    TestCase.assertEqual(ver_info.version, '1.2.3')
    TestCase.assertEqual(ver_info.major.pos, 0)
    TestCase.assertEqual(ver_info.major.num, 1)
    TestCase.assertEqual(ver_info.major.txt, '1')
    TestCase.assertEqual(ver_info.minor.pos, 1)
    TestCase.assertEqual(ver_info.minor.num, 2)
    TestCase.assertEqual(ver_info.minor.txt, '2')
    TestCase.assertEqual(ver_info.patch.pos, 2)

# Generated at 2022-06-23 18:18:51.657229
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3b0')
    assert ver_info.version is not None
    assert ver_info.major is not None
    assert ver_info.minor is not None
    assert ver_info.patch is not None
    assert ver_info.pre_pos != -1



# Generated at 2022-06-23 18:18:52.457681
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pass


# Generated at 2022-06-23 18:19:02.842792
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    ver_obj = StrictVersion('1.2a0')

    for pos, num in enumerate(ver_obj.version):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kwargs = {
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': '',
            'pre_num': -1,
            'name': _BUMP_VERSION_POSITION_NAMES[pos]
        }
        if pos == 1:
            kwargs['num'] = 2
            kwargs['txt'] = '2a0'
            kwargs['pre_txt'] = 'a'
            kwargs['pre_num'] = 0
       

# Generated at 2022-06-23 18:19:07.631108
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        -1
    )

# Generated at 2022-06-23 18:19:13.564049
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [0, '1', 1, '', -1, 'major']
    vp = _VersionPart(*args)
    assert vp.pos == 0
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'

    args = [1, '1', 1, '', -1, 'minor']
    vp = _VersionPart(*args)
    assert vp.pos == 1
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'minor'


# Generated at 2022-06-23 18:19:17.484189
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:19:27.571141
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test 6.1
    assert _build_version_info('6.1') == _VersionInfo(
        '6.1',
        _VersionPart(0, '6', 6, '', -1, 'major'),
        _VersionPart(1, '1', 1, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    )
    # Test 1.2.3

# Generated at 2022-06-23 18:19:32.640036
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == 'a'
    assert part.pre_num == 1
    assert part.name == 'major'


# Generated at 2022-06-23 18:19:42.092889
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=E1120
    # noinspection PyUnusedLocal
    pos: int = _BUMP_VERSION_MAJOR
    for pos in range(_BUMP_VERSION_MAJOR, _BUMP_VERSION_PATCHES[-1] + 1):
        part = _VersionPart(
            pos, '0', 0, '', -1, _BUMP_VERSION_POSITION_NAMES[pos])
        assert part.pos == pos
        assert part.txt == '0'
        assert part.num == 0
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name == _BUMP_VERSION_POSITION_NAMES[pos]



# Generated at 2022-06-23 18:19:51.954363
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:58.656699
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args: List[str] = [
        '1.2.4a0',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2a0', num=2, pre_txt='a', pre_num=0, name='minor'),
        _VersionPart(pos=2, txt='4', num=4, pre_txt='a', pre_num=0, name='patch'),
        1
    ]
    ver_info = _VersionInfo(*args)
    assert ver_info.version == '1.2.4a0'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.name == 'minor'
    assert ver_info

# Generated at 2022-06-23 18:20:06.307867
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('0.0.0')
    assert info.version == '0.0.0'
    assert info.major.pos == 0
    assert info.major.txt == '0'
    assert info.major.num == 0
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '0'
    assert info.minor.num == 0
    assert info.minor.pre_txt == ''
    assert info.minor.pre_num == -1
    assert info.minor.name == 'minor'
    assert info.patch.pos == 2
    assert info.patch.txt == ''
    assert info

# Generated at 2022-06-23 18:20:13.975335
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo
    import unittest

    class _VersionInfoTest(unittest.TestCase):
        def runTest(self):
            ver_info = _VersionInfo('1.2.3-alpha.4', 1, 2, 3, 'alpha', 4, 1)
            self.assertEqual(ver_info.version, '1.2.3-alpha.4')
            self.assertEqual(ver_info.major.pos, 0)
            self.assertEqual(ver_info.major.txt, '1')
            self.assertEqual(ver_info.major.num, 1)
            self.assertEqual(ver_info.major.pre_txt, '')
            self.assertEqual(ver_info.major.pre_num, -1)
            self.assertE

# Generated at 2022-06-23 18:20:27.311701
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    version = '1.2.3'
    ver_info = _build_version_info(version)

# Generated at 2022-06-23 18:20:38.021757
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.2.3')
    assert isinstance(info, _VersionInfo)
    assert info.version == '1.2.3'
    assert isinstance(info.major, _VersionPart)
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert isinstance(info.minor, _VersionPart)
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2
    assert info.minor.pre_txt == ''
    assert info.minor.pre_num

# Generated at 2022-06-23 18:20:47.882730
# Unit test for function bump_version
def test_bump_version():
    """ Run bump_version unit tests.
    Returns:
        True if all tests pass, False if any test fails.
    """
    import io
    import unittest
    import contextlib
    from flutils.packages import bump_version

    @contextlib.contextmanager
    def capture_stdout():
        """ Capture stdout """
        old = sys.stdout
        capturer = io.StringIO()
        sys.stdout = capturer
        try:
            yield capturer
        finally:
            sys.stdout = old

    class TestBumpVersion(unittest.TestCase):

        """ Run bump_version unittests.  """

        def test_bump_version(self) -> bool:
            """ Unit test of bump_version().

            Returns:
                True if successful, otherwise False.
            """
            self

# Generated at 2022-06-23 18:20:55.379357
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    _VersionPart(0, '0', 0, '', -1, 'major')
    _VersionPart(1, '1', 1, '', -1, 'minor')
    _VersionPart(2, '', 0, 'a0', 0, 'patch')
    _VersionPart(1, '1a0', 1, 'a', 0, 'minor')
    _VersionPart(2, '3b0', 3, 'b', 0, 'patch')
    _VersionPart(1, '1b0', 1, 'b', 0, 'minor')


# Generated at 2022-06-23 18:21:03.305886
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    parts = [
        ver_part
        for ver_part in _each_version_part(ver_obj)
    ]
    assert parts[0] == _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert parts[1] == _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )

# Generated at 2022-06-23 18:21:12.274069
# Unit test for function bump_version

# Generated at 2022-06-23 18:21:23.680799
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    try:
        from flutils.packages import bump_version
    except ImportError:  # pragma: no cover
        return
    print(
        "Testing function bump_version\n"
        "(from: flutils.packages.bump_version)\n"
        "-" * 70
    )

    print(">>> bump_version('1.2.2')")
    print(bump_version('1.2.2'))
    print()

    print(">>> bump_version('1.2.3', position=1)")
    print(bump_version('1.2.3', position=1))
    print()

    print(">>> bump_version('1.3.4', position=0)")
    print(bump_version('1.3.4', position=0))
    print

# Generated at 2022-06-23 18:21:36.563706
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2')
    obj = next(_each_version_part(ver_obj))
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'
    obj = next(_each_version_part(ver_obj))
    assert obj.pos == 1
    assert obj.txt == '2'
    assert obj.num == 2
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'minor'

    ver_obj = StrictVersion('1.2.0')
    obj = next(_each_version_part(ver_obj))

# Generated at 2022-06-23 18:21:47.127277
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,R0201,R0914,W0612
    import unittest

    def test(version: str, position: int, prerelease: Optional[str],
             expected: str) -> None:
        try:
            tst = bump_version(version, position, prerelease)
            assert tst == expected
        except Exception as err:
            if isinstance(expected, Exception):
                assert isinstance(err, type(expected))
                assert str(err) == str(expected)
            else:
                raise err

    # Testing correct exceptions

# Generated at 2022-06-23 18:21:57.563918
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=E1101
    result = _VersionInfo('1.2.3rc4',
                          _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
                          _VersionPart(pos=1, txt='2', num=2, pre_txt='rc', pre_num=4, name='minor'),
                          _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
                          2)
    print('result: %r' % result)
    assert result.version == '1.2.3rc4'
    assert result.major.pos == 0
    assert result.major.txt == '1'
    assert result.major.num == 1

# Generated at 2022-06-23 18:22:11.188981
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = '1.2.3'
    res = _build_version_info(ver)
    assert res.version == ver
    assert res.major.txt == '1'
    assert res.major.num == 1
    assert res.major.pre_txt == ''
    assert res.major.pre_num == -1
    assert res.major.name == 'major'
    assert res.minor.txt == '2'
    assert res.minor.num == 2
    assert res.minor.pre_txt == ''
    assert res.minor.pre_num == -1
    assert res.minor.name == 'minor'
    assert res.patch.txt == '3'
    assert res.patch.num == 3
    assert res.patch.pre_txt == ''
    assert res.patch.pre_num

# Generated at 2022-06-23 18:22:15.826035
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo.

    * Only used in unit tests *

    """
    assert repr(_VersionInfo(*[1, 2, 3])) == \
        "_VersionInfo(version='1', major=2, minor=3)"

# Generated at 2022-06-23 18:22:26.080062
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # noinspection PyUnresolvedReferences
    import flutils.testhelpers

    def _test_bump_version(
            version: str,
            expected: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        actual = bump_version(version, position, pre_release)
        if actual != expected:
            raise AssertionError(
                "The version returned was not as expected.\n"
                "Expected: %r\n"
                "Received: %r" % (expected, actual)
            )


# Generated at 2022-06-23 18:22:35.978511
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert isinstance(ver_info, _VersionInfo)
    assert isinstance(ver_info.major, _VersionPart)
    assert isinstance(ver_info.minor, _VersionPart)
    assert isinstance(ver_info.patch, _VersionPart)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _build_

# Generated at 2022-06-23 18:22:46.458566
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version')
    from flutils.packages import bump_version

    results = [
        '1.2.3',
        '1.3',
        '2.0',
        '1.2.4a0',
        '1.2.4a1',
        '1.2.4b0',
        '1.2.4',
        '1.2.4',
        '2.2a0',
        '1.2.1',
    ]

# Generated at 2022-06-23 18:22:53.220685
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion
    from flutils.packages import _VersionPart
    from flutils.testing import UnitTester

    ver_obj = StrictVersion('1.2a1')
    part = _VersionPart(0, '1', 1, '', -1, 'major')
    UnitTester.assertEqual(part.num, 1)
    UnitTester.assertEqual(part.txt, '1')
    UnitTester.assertEqual(part.pre_txt, '')
    UnitTester.assertEqual(part.pre_num, -1)
    UnitTester.assertEqual(part.pos, 0)
    UnitTester.assertEqual(part.name, 'major')

# Generated at 2022-06-23 18:23:02.699084
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    vi = _VersionInfo("1.1.0", _VersionPart(0, "1", 1, "", -1, "major"),
                      _VersionPart(1, "1", 1, "", -1, "minor"),
                      _VersionPart(2, "0", 0, "", -1, "patch"), -1)
    assert str(vi) == "1.1.0"
    assert vi.version == "1.1.0"
    assert vi.major.pos == 0
    assert vi.major.txt == "1"
    assert vi.major.num == 1
    assert vi.major.pre_txt == ""
    assert vi.major.pre_num == -1
    assert vi.major.name == "major"
    assert vi.minor.pos == 1

# Generated at 2022-06-23 18:23:13.394689
# Unit test for function bump_version

# Generated at 2022-06-23 18:23:24.052461
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the bump_version function.

    .. versionadded:: 0.3

    """

# Generated at 2022-06-23 18:23:35.529325
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase

    class __UnitTestVersionPart(TestCase):
        """Tests for constructor of class _VersionPart.
        """

        class _Attr(NamedTuple):
            attr_name: str
            attr_type: type

        def _attr_defs(self) -> List[_Attr]:
            return [
                self._Attr('pos', int),
                self._Attr('txt', str),
                self._Attr('num', int),
                self._Attr('pre_txt', str),
                self._Attr('pre_num', int),
            ]

        def test___init__(self):
            from types import SimpleNamespace


# Generated at 2022-06-23 18:23:46.127400
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=R0914
    """ Test _VersionPart.__init__() """
    version: str
    ver_obj: StrictVersion
    part: _VersionPart
    version = '1.2.3'
    ver_obj = StrictVersion(version)
    gen_parts = _each_version_part(ver_obj)
    part = next(gen_parts)
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = next(gen_parts)
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''


# Generated at 2022-06-23 18:23:57.624266
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:24:07.733854
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0612
    _VersionInfo(
        version='2.0.0',
        major=_VersionPart(
            pos=0,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )

# Generated at 2022-06-23 18:24:16.099490
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo
    version_info = _VersionInfo('1.2.3', version='1.2.3', major='1.2.3', minor='1.2.3', patch='1.2.3', pre_pos=-1)
    assert version_info.version == '1.2.3'
    assert version_info.major == '1.2.3'
    assert version_info.minor == '1.2.3'
    assert version_info.patch == '1.2.3'
    assert version_info.pre_pos == -1


# Generated at 2022-06-23 18:24:23.858562
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = "1.2.2a1"
    ver_obj = StrictVersion(version)
    list_of_tuples = [
        (
            0,
            '1',
            1,
            '',
            -1,
            'major'
        ),
        (
            1,
            '2a1',
            2,
            'a',
            1,
            'minor'
        ),
        (
            2,
            '',
            0,
            '',
            -1,
            'patch'
        ),
    ]
    counter = 0
    for part in _each_version_part(ver_obj):
        tuple_ = list_of_tuples[counter]
        counter += 1
        assert part.pos == tuple_[0]
        assert part.txt == tuple_

# Generated at 2022-06-23 18:24:31.025132
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    tst = _VersionPart(
        pos=0, txt='1', num=1,
        pre_txt='a', pre_num=0, name='major'
    )
    assert tst.pos == 0
    assert tst.txt == '1'
    assert tst.num == 1
    assert tst.pre_txt == 'a'
    assert tst.pre_num == 0
    assert tst.name == 'major'



# Generated at 2022-06-23 18:24:38.914809
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    parts = [
        _VersionPart(1, '2', 3, '', 0, ''),
        _VersionPart(2, '3', 4, 'a', 5, ''),
    ]
    assert parts == [
        _VersionPart(pos=1, txt='2', num=3, pre_txt='', pre_num=0, name=''),
        _VersionPart(pos=2, txt='3a5', num=4, pre_txt='a', pre_num=5, name=''),
    ]



# Generated at 2022-06-23 18:24:48.618801
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:24:56.153572
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pragma: nocover
    from .testing_utils import obj_to_dump
    print('Version Part Object:')
    part = _VersionPart(
        pos=1,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='minor',
    )
    print(obj_to_dump(part))



# Generated at 2022-06-23 18:25:08.263937
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=R0201
    from flutils.packages import _build_version_info

# Generated at 2022-06-23 18:25:19.086045
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    ver_obj = StrictVersion(0.3)
    part: _VersionPart
    parts: List[_VersionPart] = [
        part
        for part in _each_version_part(ver_obj)
        if part.pos in (0, 1, 2)
        ]
    assert parts[0] == _VersionPart(
        0, '0', 0, '', -1, 'major'
    )
    assert parts[1] == _VersionPart(
        1, '3', 3, '', -1, 'minor'
    )
    assert parts[2] == _VersionPart(
        2, '', 0, '', -1, 'patch'
    )


# Generated at 2022-06-23 18:25:29.813976
# Unit test for function bump_version
def test_bump_version():
    from .utils import UnitTest

    ut = UnitTest('test_bump_version', test_print=False)
    ut.assert_equal(bump_version('1.2.2'), '1.2.3')
    ut.assert_equal(bump_version('1.2.3', position=1), '1.3')
    ut.assert_equal(bump_version('1.3.4', position=0), '2.0')
    ut.assert_equal(bump_version('1.2.3', prerelease='a'), '1.2.4a0')
    ut.assert_equal(bump_version('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-23 18:25:32.000580
# Unit test for function bump_version
def test_bump_version():
    # TODO(dw): Write unit tests.
    pass

# Generated at 2022-06-23 18:25:42.040942
# Unit test for function bump_version
def test_bump_version():
    """ Test function bump_version """


# Generated at 2022-06-23 18:25:49.543276
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Build the object
    info = _build_version_info('1.2.3')

    # Make sure info object has the correct values
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.num == 1
    assert info.major.pre_num == -1
    assert info.major.pre_txt == ''
    assert info.minor.pos == 1
    assert info.minor.num == 2
    assert info.minor.pre_num == -1
    assert info.minor.pre_txt == ''
    assert info.patch.pos == 2
    assert info.patch.num == 3
    assert info.patch.pre_num == -1
    assert info.patch.pre_txt == ''
    assert info.pre_pos == -1

   

# Generated at 2022-06-23 18:26:01.358970
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    # pylint: disable=C0103
    # pylint: disable=R0914
    def t(v, n, p, o):
        assert bump_version(v, n, p) == o

    t('0.0.0', 0, None, '1.0')
    t('1.0.0', 0, None, '2.0')
    t('2.0.0', 0, None, '3.0')
    t('0.0.0', 1, None, '0.1')
    t('0.1.0', 1, None, '0.2')
    t('0.2.0', 1, None, '0.3')
    t('0.0.0', 2, None, '0.0.1')
   

# Generated at 2022-06-23 18:26:10.905628
# Unit test for function bump_version

# Generated at 2022-06-23 18:26:23.319469
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.packages import _VersionPart

    class MockStrictVersion(object):
        def __init__(self):
            pass

        @staticmethod
        def version():
            return (1, 2, 3)

        @staticmethod
        def prerelease():
            return ('a', 4)

    def mock_each_version_part(ver_obj):
        return list(_each_version_part(ver_obj))


# Generated at 2022-06-23 18:26:33.290785
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def _do_test(version, expected):
        vinfo = _VersionInfo(version,
                             major=_VersionPart(0, '1', 1, '', -1, 'major'),
                             minor=_VersionPart(1, '0', 0, '', -1, 'minor'),
                             patch=_VersionPart(2, '0', 0, '', -1, 'patch'),
                             pre_pos=-1)
        assert vinfo.version == expected

    _do_test('1.0.0', '1.0.0')
    _do_test('1.2.3', '1.2.3')
    _do_test('1.2.0', '1.2')
    _do_test('1.0', '1')
    _do_test('1', '1')
   