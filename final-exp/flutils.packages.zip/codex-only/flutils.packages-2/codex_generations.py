

# Generated at 2022-06-23 18:16:38.341008
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyMethodMayBeStatic
    def _test_assertions(ver_info: _VersionInfo) -> Optional[str]:
        if ver_info.version != '1.2.3':
            return "ver_info.version(%r) != '1.2.3'" % ver_info.version
        if ver_info.major.pos != 0:
            return "ver_info.major.pos(%r) != 0" % ver_info.major.pos
        if ver_info.major.txt != '1':
            return "ver_info.major.txt(%r) != '1'" % ver_info.major.txt
        if ver_info.minor.name != 'minor':
            return "ver_info.minor.name(%r) != 'minor'" % ver_info.minor

# Generated at 2022-06-23 18:16:45.510313
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0613,W0212,C0103
    from unittest import TestCase
    from .utils import check_types_and_endpoint

    is_major = (True, False)
    is_minor = (True, False)
    no_prerelease = ('', None)

    version_numbers = (
        (1, 0, 0),
        (1, 1, 0),
        (1, 1, 1),
        (2, 0, 0)
    )

    prerelease_nums = (
        (0, 1),
        (0, 2),
        (1, 0),
        (1, 1),
    )

    prerelease_text = ('a', 'alpha', 'b', 'beta')


# Generated at 2022-06-23 18:16:50.387807
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    def do_test(version, major, minor, patch, pre) -> None:
        obj = _VersionInfo(version, major, minor, patch, pre)
        assert obj.version == version
        assert obj.major is major
        assert obj.minor is minor
        assert obj.patch is patch
        assert obj.pre_pos == pre


test__VersionInfo()


# Generated at 2022-06-23 18:16:53.704536
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'



# Generated at 2022-06-23 18:17:00.343163
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    args = {
        "pos": 0,
        "num": 0,
        "txt": "a",
        "pre_num": 0,
        "pre_txt": "a"
    }
    _VersionPart(**args)


# Generated at 2022-06-23 18:17:06.536946
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major') == \
                                 _VersionPart(pos=0, txt='1', num=1,
                                              pre_txt='', pre_num=-1,
                                              name='major')


# Generated at 2022-06-23 18:17:17.737188
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E1133
    def tst(
            ver_in: str,
            pos: int,
            pre_rel: Optional[str],
            ver_out: str
    ) -> None:
        ver = bump_version(
            version=ver_in,
            position=pos,
            pre_release=pre_rel
        )
        msg = "Expected version to be '%s' for  %r, %r, %r"
        msg = msg % (ver_out, ver_in, pos, pre_rel)
        assert ver == ver_out, msg
    tst(ver_in='1.2.2', pos=2, pre_rel=None, ver_out='1.2.3')

# Generated at 2022-06-23 18:17:28.631837
# Unit test for function bump_version
def test_bump_version():
    from .test_helpers import random_ints
    from .test_helpers import random_string

    def _test_version(ver_info: _VersionInfo, version_type: int):
        position = version_type

        if version_type < _BUMP_VERSION_MINOR_ALPHA:
            base_version = '%s.%s.%s' % (
                ver_info.major.num,
                ver_info.minor.num,
                ver_info.patch.num,
            )

# Generated at 2022-06-23 18:17:40.973548
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    src_ = '0.12.0'
    out = _build_version_info(src_)
    assert out.version == src_
    assert out.major == _VersionPart(0, '0', 0, '', -1, 'major')
    assert out.minor == _VersionPart(1, '12', 12, '', -1, 'minor')
    assert out.patch == _VersionPart(2, '0', 0, '', -1, 'patch')
    assert out.pre_pos == -1

    src_ = '0.12.0a0'
    out = _build_version_info(src_)
    assert out.version == src_
    assert out.major == _VersionPart(0, '0', 0, '', -1, 'major')
    assert out.minor == _VersionPart

# Generated at 2022-06-23 18:17:41.692562
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart is not None



# Generated at 2022-06-23 18:17:51.944789
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=R0914
    """Unit test for constructor of class _VersionInfo.

    *New in version 0.1*

    """
    version: str = '1.2.3'
    ver_obj = _build_version_info(version)
    assert ver_obj.version == version
    assert ver_obj.major.pos == 0
    assert ver_obj.major.num == 1
    assert ver_obj.major.pre_txt == ''
    assert ver_obj.major.pre_num == -1
    assert ver_obj.major.name == 'major'
    assert ver_obj.minor.pos == 1
    assert ver_obj.minor.num == 2
    assert ver_obj.minor.pre_txt == ''
    assert ver_obj.minor.pre_num == -1


# Generated at 2022-06-23 18:18:03.568215
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    import copy
    import random
    import sys
    import unittest

    if sys.version_info[0] >= 3 and sys.version_info[1] >= 7:
        # https://stackoverflow.com/a/55058007/116091
        # https://github.com/python/cpython/commit/22e8c077b6a24e5179f85258e2c5e7e5cbe18b58
        random.seed(1, 2)
    else:
        random.seed(1)

    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)

    # noinspection PyShadowingNames
    def gen_version(major=0, minor=0, patch=0, alpha=False) -> str:
        pre

# Generated at 2022-06-23 18:18:14.865588
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # Test 1
    parts = _each_version_part(StrictVersion('1.2.3'))
    part = next(parts)
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    # Test 2
    part = next(parts)
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'

    # Test 3
    part = next(parts)
    assert part.pos == 2
    assert part.txt == ''
    assert part.num == 3

# Generated at 2022-06-23 18:18:26.992115
# Unit test for function bump_version
def test_bump_version():
    results = [
        ('1.2.3', '1.2.3'),
        ('1.2.3', '1.2.3'),
        ('1.2.3', '1.2.3'),
        ('1.2.3', '1.2.3'),
        ('1.2.4a0', '1.2.4a0'),
        ('1.2.4a1', '1.2.4a1'),
        ('1.2.4b0', '1.2.4b0'),
        ('1.2.4', '1.2.4'),
        ('1.2.4', '1.2.4'),
        ('2.2a0', '2.2a0'),
        ('1.2.1', '1.2.1')
    ]

# Generated at 2022-06-23 18:18:35.324625
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    txt = '123a456'
    pos = 1
    num = 123
    pre_txt = 'a'
    pre_num = 456
    name = 'minor'
    with pytest.raises(TypeError):
        _VersionPart()
    with pytest.raises(TypeError):
        _VersionPart(**{
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': pre_txt,
            'pre_num': pre_num,
            'name': name,
            'extra_arg': '123'
        })

# Generated at 2022-06-23 18:18:45.338305
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2a0') == '1.2.2a1'
    assert bump_version('1.2.2b0') == '1.2.2b1'

    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3b0'
    assert bump_version('1.2.3', position=1, pre_release='A') == '1.3a0'

# Generated at 2022-06-23 18:18:53.643592
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('0.0.0')
    assert info.version == '0.0.0'
    assert info.major.pos == 0
    assert info.major.num == 0
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.num == 0
    assert info.minor.pre_txt == ''
    assert info.minor.pre_num == -1
    assert info.minor.name == 'minor'
    assert info.patch.pos == 2
    assert info.patch.num == 0
    assert info.patch.pre_txt == ''
    assert info.patch.pre_num == -1
    assert info

# Generated at 2022-06-23 18:19:00.693701
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=C0103
    x = _VersionPart(pos=0, num=1, txt='1', pre_num=0, pre_txt='a', name='major')
    assert x.pos == 0
    assert x.num == 1
    assert x.txt == '1'
    assert x.pre_num == 0
    assert x.pre_txt == 'a'
    assert x.name == 'major'



# Generated at 2022-06-23 18:19:05.356219
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    p = _VersionPart(4, '4', 4, '', -1, 'major')
    assert p.pos == 4
    assert p.txt == '4'
    assert p.num == 4
    assert p.pre_txt == ''
    assert p.pre_num == -1
    assert p.name == 'major'


# Generated at 2022-06-23 18:19:13.661433
# Unit test for function bump_version

# Generated at 2022-06-23 18:19:23.687279
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:32.561561
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    import pytest

    # pylint: disable=W0212
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major == _VersionPart(0, '1', 1, '', -1, 'major')
    assert ver_info.minor == _VersionPart(1, '2', 2, '', -1, 'minor')
    assert ver_info.patch == _VersionPart(2, '3', 3, '', -1, 'patch')

    ver_info = _build_version_info('1.2b2')
    assert ver_info.version == '1.2b2'

# Generated at 2022-06-23 18:19:44.383375
# Unit test for function bump_version
def test_bump_version():
    # Simple usage
    assert bump_version('1.0.0') == '1.0.1'
    # Bump from (0) major to (1) minor
    assert bump_version('1.0.0', position=1) == '1.1'
    # Bump from (1) minor to (2) patch
    assert bump_version('1.0.0', position=2) == '1.0.1'
    # Bump from (2) patch to (0) major
    assert bump_version('1.0.0', position=0) == '2.0'
    # Bump from (2) patch to (1) minor
    assert bump_version('1.0.0', position=1) == '1.1'
    # Bump from (1) minor to (0) major
    assert bump_

# Generated at 2022-06-23 18:19:52.605553
# Unit test for function bump_version
def test_bump_version():
    """Test function _bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:20:00.771769
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_simple(self):
            self.assertEqual(bump_version('1.2.3'), '1.2.4')
            self.assertEqual(bump_version('1.2.0'), '1.2.1')
            self.assertEqual(bump_version('1.2.2', position=1), '1.3')

        def test_prerelease(self):
            self.assertEqual(bump_version('1.2.4', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-23 18:20:10.492018
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:20:17.941246
# Unit test for function bump_version
def test_bump_version():
    """If the function bump_version raise an Exception,
       or do not return the expected output, it will show up here.
    """
    import sys

    import pytest

    from flutils.packages import bump_version


# Generated at 2022-06-23 18:20:26.648420
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3a1')
    _build_version_info('1.2.3b1')
    _build_version_info('1.2.3')
    _build_version_info('1')
    _build_version_info('1.2a1')
    _build_version_info('1.2b1')
    _build_version_info('1.2')
    _build_version_info('1.2.3a1')



# Generated at 2022-06-23 18:20:36.135833
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2.1') == '1.2.2.2'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.3.4.0', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

# Generated at 2022-06-23 18:20:46.729852
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.34') == _VersionInfo(
        version='1.2.34',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='34', num=34, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1,
    )

# Generated at 2022-06-23 18:20:57.154165
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:09.676291
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version: str = '9.9.9'
    ver_info = _VersionInfo(
        version=version,
        major=_VersionPart(
            pos=0,
            txt='9',
            num=9,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='9',
            num=9,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='9',
            num=9,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )

# Generated at 2022-06-23 18:21:17.584398
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2a0'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 0
    assert ver_

# Generated at 2022-06-23 18:21:26.934039
# Unit test for function bump_version
def test_bump_version():
    """Test the function: ``bump_version``."""
    from flutils.testing_utils import unit_test_message

    message = 'The function: "bump_version" failed for the input: (%r, %r).'
    message += '  The returned value was: %r.'


# Generated at 2022-06-23 18:21:32.125778
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3'
    ver_obj = StrictVersion(version)
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)


# Generated at 2022-06-23 18:21:43.780917
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:21:53.366567
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase
    from unittest_expander import expand, foreach

    ver_obj = StrictVersion('1.2.3')
    versions: List[Tuple[int, ...]] = [
        (100, 200, 300),
        (100, 200, 0),
        (100, 0, 0),
        (0, 0, 0),
        (0, 0, 1),
    ]
    prereleases: List[Tuple[str, ...]] = [
        # (a, 0),
        (0, 2),
        (0, 1),
        (1, 0),
    ]
    prereleases_exist: List[bool] = [True, False]
    versions_exist: List[bool] = [True, False]


# Generated at 2022-06-23 18:22:05.621002
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:22:14.629124
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import sys
    # noinspection PyProtectedMember
    assert hasattr(sys.modules[__name__], '_VersionPart')
    assert hasattr(sys.modules[__name__]._VersionPart, '__name__')
    assert sys.modules[__name__]._VersionPart.__name__ == '_VersionPart'
    assert hasattr(sys.modules[__name__]._VersionPart, '__doc__')
    assert hasattr(sys.modules[__name__]._VersionPart, '__annotations__')
    assert isinstance(sys.modules[__name__]._VersionPart.__doc__, str)
    assert isinstance(sys.modules[__name__]._VersionPart.__annotations__, dict)

# Generated at 2022-06-23 18:22:25.792917
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('2.0')
    pos = 0
    num = 2
    pre_txt = ''
    pre_num = -1
    name = 'major'
    ver_part = _VersionPart(pos, '0', num, pre_txt, pre_num, name)
    assert all([
        ver_obj.version[0] == num,
        ver_obj.version[0] == ver_part.num
    ])
    assert ver_obj.prerelease == ()
    assert all([
        ver_part.pre_txt == '',
        ver_part.pre_num == -1
    ])
    ver_obj = StrictVersion('2.0.0')
    pos = 2
    num = 0
    pre_txt = ''
    pre_num = -1

# Generated at 2022-06-23 18:22:35.444657
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    vi = _VersionInfo('1.0.0', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '0', 0, '', -1, 'minor'), _VersionPart(2, '', 0, '', -1, 'patch'), -1)
    assert(vi.version == '1.0.0')
    assert(vi.major.pos == 0)
    assert(vi.major.txt == '1')
    assert(vi.major.num == 1)
    assert(vi.major.pre_txt == '')
    assert(vi.major.pre_num == -1)
    assert(vi.major.name == 'major')
    assert(vi.minor.pos == 1)
    assert(vi.minor.txt == '0')

# Generated at 2022-06-23 18:22:46.120658
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=E1129
    # pylint: disable=R0913
    with pytest.raises(TypeError):
        _VersionPart()
    # pylint: disable=C0103
    p = _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='a',
        pre_num=0,
        name='major'
    )
    assert p.pos == 0
    assert p.txt == '0'
    assert p.num == 0
    assert p.pre_txt == 'a'
    assert p.pre_num == 0
    assert p.name == 'major'
    # pylint: disable=R0913

# Generated at 2022-06-23 18:22:53.008343
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '0', 0, '', -1, 'major').pos == 0
    assert _VersionPart(0, '0', 0, '', -1, 'major').txt == '0'
    assert _VersionPart(0, '0', 0, '', -1, 'major').num == 0
    assert _VersionPart(0, '0', 0, '', -1, 'major').pre_txt == ''
    assert _VersionPart(0, '0', 0, '', -1, 'major').pre_num == -1
    assert _VersionPart(0, '0', 0, '', -1, 'major').name == 'major'
    assert _VersionPart(1, '1', 1, 'a', 0, 'minor').pos == 1

# Generated at 2022-06-23 18:23:00.549131
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    objs = []  # type: List[_VersionPart]
    objs.append(_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                             name='major'))
    objs.append(_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1,
                             name='minor'))
    objs.append(_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1,
                             name='patch'))
    objs.append(_VersionPart(pos=1, txt='2', num=2, pre_txt='a', pre_num=0,
                             name='minor'))

# Generated at 2022-06-23 18:23:09.456065
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    tests = (
        ('1.0', '1.0'),
        ('1.0.1', '1.0.1'),
        ('1.2.0beta0', '1.2.0beta0'),
        ('1.2.0a0', '1.2.0a0'),
        ('1.2.1a0', '1.2.1a0'),
        ('1.2.1b0', '1.2.1b0'),
        ('1.2.1', '1.2.1'),
        ('1.2.1', '1.2.1'),
    )


# Generated at 2022-06-23 18:23:22.040602
# Unit test for function bump_version
def test_bump_version(): # pylint: disable=R0915
    """Test the function: bump_version."""

    args = {
        'version': '0.0.0',
        'position': 2,
        'pre_release': None
    }
    expected = '0.0.1'
    actual = bump_version(**args)
    assert actual == expected

    args = {
        'version': '0.0.1',
        'position': 1,
        'pre_release': None
    }
    expected = '0.1'
    actual = bump_version(**args)
    assert actual == expected

    args = {
        'version': '0.1',
        'position': 0,
        'pre_release': None
    }
    expected = '1.0'
    actual = bump_version(**args)


# Generated at 2022-06-23 18:23:30.424300
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '3', 3, '', -1, 'patch'),
                 -1)
    _VersionInfo('1.2.3a0', _VersionPart(0, '1', 1, '', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '3', 3, 'a', 0, 'patch'),
                 2)


# Generated at 2022-06-23 18:23:40.367209
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    args = dict(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    ver_part = _VersionPart(**args)
    assert ver_part.pos == args['pos']
    assert ver_part.txt == args['txt']
    assert ver_part.num == args['num']
    assert ver_part.pre_txt == args['pre_txt']
    assert ver_part.pre_num == args['pre_num']
    assert ver_part.name == args['name']



# Generated at 2022-06-23 18:23:44.635232
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': _BUMP_VERSION_POSITION_NAMES[0]
    }

    obj = _VersionPart(**kwargs)
    assert vars(obj) == kwargs



# Generated at 2022-06-23 18:23:48.414973
# Unit test for function bump_version
def test_bump_version():
    """Test the function 'bump_version'"""
    from flutils.packages._versioning_test_data import VERSION_DATA
    for args, expected in VERSION_DATA:
        out = bump_version(*args)
        print(out)
        assert out == expected



# Generated at 2022-06-23 18:23:59.385009
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-statements,too-many-branches,unused-argument
    """Unit test for function bump_version."""
    from flutils.tests.base_tests import UnitTestBase
    from flutils.packages import bump_version

    UnitTestBase.BASE.logger.debug(
        "Executing test_bump_version ..."
    )
    try:
        bump_version('')
    except ValueError:
        pass
    else:
        assert False
    try:
        bump_version('abc')
    except ValueError:
        pass
    else:
        assert False
    for ver in ('1', '1.9', '1.9.5'):
        try:
            bump_version(ver)
        except ValueError:
            assert False
    parts: List

# Generated at 2022-06-23 18:24:10.941907
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # noqa: D103
    from hypothesis import given
    from hypothesis import strategies
    from hypothesis import Verbosity
    from hypothesis.strategies import composite
    from hypothesis.strategies import text
    from hypothesis.strategies import tuples
    import pytest

    version = text(alphabet='0123456789.', min_size=1)

    @composite
    def version_info(draw):
        return _build_version_info(draw(version))

    @given(version_info())
    def test_version_parts_exist(vi):
        parts = ['major', 'minor', 'patch']
        for part in parts:
            object_name = 'vi.{}'.format(part)
            assert eval(object_name) is not None


# Generated at 2022-06-23 18:24:14.561016
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyUnusedLocal
    part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:24:22.779630
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyUnresolvedReferences
    from flutils.testing import (
        call_unit_function_with_kwargs,
        assert_equals,
        assert_false,
        assert_true,
    )
    from flutils.packages import _VersionPart

    # noinspection PyUnresolvedReferences
    from distutils.version import StrictVersion
    ver = StrictVersion('1.2.3b4')
    kwargs = {
        'pos': 1,
        'txt': '2',
        'num': 2,
        'pre_txt': 'b',
        'pre_num': 4,
        'name': 'minor',
    }

# Generated at 2022-06-23 18:24:31.309425
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection SpellCheckingInspection
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.name == 'major'
    assert ver_info.major.num == 1
    assert ver_info.minor.name == 'minor'
    assert ver_info.minor.num == 2
    assert ver_info.patch.name == 'patch'
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

# Generated at 2022-06-23 18:24:44.426755
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.num == 3
    assert ver_info.patch.pre_num == -1
    assert ver_info.patch.name == 'patch'

    ver_info = _build_version_info('1.2.0')
    assert ver_info.version == '1.2.0'

# Generated at 2022-06-23 18:24:50.736198
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '0', 0, '', -1, 'major').pos == 0
    assert _VersionPart(0, '0', 0, '', -1, 'major').txt == '0'
    assert _VersionPart(0, '0', 0, '', -1, 'major').num == 0
    assert _VersionPart(0, '0', 0, '', -1, 'major').pre_txt == ''
    assert _VersionPart(0, '0', 0, '', -1, 'major').pre_num == -1
    assert _VersionPart(0, '0', 0, '', -1, 'major').name == 'major'
    assert _VersionPart(1, '2', 2, '', -1, 'minor').pos == 1

# Generated at 2022-06-23 18:25:01.607666
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:25:09.442832
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """
    Test :obj:`_VersionPart`.

    *New in version 0.3*
    """
    vp = _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )
    assert vp.pos == 1
    assert vp.txt == '2'
    assert vp.num == 2
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'minor'



# Generated at 2022-06-23 18:25:10.788966
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(0, '0', 0, '', -1, 'major')

# Generated at 2022-06-23 18:25:13.700880
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyTypeChecker
    _VersionPart(0, '', 0, '', -1, '')



# Generated at 2022-06-23 18:25:26.563155
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=1,
        name='major'
    ).pos == 0
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=1,
        name='major'
    ).txt == '1'
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=1,
        name='major'
    ).num == 1

# Generated at 2022-06-23 18:25:38.200137
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    with pytest.raises(TypeError) as err:
        _VersionPart()
    assert str(err.value) == '__new__() missing 6 required positional arguments: ' \
                             '\'pos\', \'txt\', \'num\', \'pre_txt\', \'pre_num\', and \'name\''
    with pytest.raises(TypeError) as err:
        _VersionPart(1)

    assert str(err.value) == '__new__() missing 5 required positional arguments: ' \
                             '\'txt\', \'num\', \'pre_txt\', \'pre_num\', and \'name\''
    with pytest.raises(TypeError) as err:
        _VersionPart(1, '1')

    assert str(err.value) == '__new__() missing 4 required positional arguments: '

# Generated at 2022-06-23 18:25:46.765423
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    # ver_obj = StrictVersion('99.0')
    ver_obj = StrictVersion('99.99')
    # ver_obj = StrictVersion('99.99.99')
    # ver_obj = StrictVersion('99.99.0')

    print(ver_obj)
    print(ver_obj.version)
    print(ver_obj.prerelease)

    version = '99.99'
    pre_pos = -1
    args: List[Any] = [version]
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            pre_pos = part.pos
        args.append(part)
    args.append(pre_pos)
    print(args)



# Generated at 2022-06-23 18:25:58.514536
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0613
    def _assert(version: str, position: int, pre_release: Optional[str]):
        ver_info = _build_version_info(version)
        position = _build_version_bump_position(position)
        bump_type = _build_version_bump_type(position, pre_release)
        # noinspection PyUnusedLocal
        hold: List[Union[int, str]] = []
        if bump_type == _BUMP_VERSION_MAJOR:
            hold = [ver_info.major.num + 1, 0]

# Generated at 2022-06-23 18:26:09.018108
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:26:21.416664
# Unit test for function bump_version

# Generated at 2022-06-23 18:26:32.196729
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3.4'
    ver_info = _VersionInfo(
        version,
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'