

# Generated at 2022-06-23 18:16:40.124908
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    import pytest

    def run_test(
            test_id: str,
            test_args: List[Any]
    ) -> None:
        nonlocal ver_info
        ver_info = _VersionInfo(*test_args)


# Generated at 2022-06-23 18:16:52.975062
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    Args:
        None

    Returns:
        None

    """
    # Initialize key variables
    version = '1.0.2'

    # Simple test
    test_version = bump_version(version)
    assert test_version == '1.0.3'

    # Minor test
    test_version = bump_version(version, position=1)
    assert test_version == '1.1'

    # Patch pre-release test
    test_version = bump_version(version, position=2, pre_release='a')
    assert test_version == '1.0.3a0'

    # Patch pre-release bump test
    test_version = bump_version(test_version, position=2, pre_release='a')

# Generated at 2022-06-23 18:17:05.802924
# Unit test for function bump_version
def test_bump_version():
    """Execute bump_version function unit tests.

    *New in version 0.3*

    Examples:
        >>> from flutils.packages import test_bump_version
        >>> test_bump_version()  # doctest: +NORMALIZE_WHITESPACE
        ============================= test session starts ============================
        platform darwin -- Python 3.7.6, pytest-5.4.2, py-1.8.1, pluggy-0.13.1 -- /Users/bchapman/flutils/bin/python
        cachedir: .pytest_cache
        rootdir: /Users/bchapman/flutils
        collected 2 items

        tests/test_packages.py ..                                             [100%]

        ============================== 2 passed in 0.04s ==============================

    """

# Generated at 2022-06-23 18:17:11.604340
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    exp_kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'a',
        'pre_num': 1,
        'name': 'major'
    }
    assert _VersionPart(**exp_kwargs) == _VersionPart(**exp_kwargs)
    exp_kwargs['pre_num'] = 2
    assert _VersionPart(**exp_kwargs) != _VersionPart(**exp_kwargs)



# Generated at 2022-06-23 18:17:21.579114
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    *New in version 0.3*

    """
    from flutils.packages import is_equal_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert is_equal_version('1.2.3', bump_version('1.2.3', pre_release='a'))
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='a') == '1.2.4a2'
   

# Generated at 2022-06-23 18:17:31.705146
# Unit test for function bump_version
def test_bump_version():
    ver = '1.2.3b0'
    assert bump_version(ver) == '1.2.3'
    assert bump_version(ver, position=1) == '1.2b1'
    ver = '1.9.9b0'
    assert bump_version(ver) == '1.9.9'
    assert bump_version(ver, position=2) == '1.10.0'
    assert bump_version(ver, position=1) == '1.10b0'
    assert bump_version(ver, position=1, pre_release='a') == '1.10a0'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:17:42.751482
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:49.045758
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    obj = _VersionPart(1, '1', 1, '', -1, 'minor')
    assert isinstance(obj, _VersionPart)
    assert obj.pos == 1
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'minor'



# Generated at 2022-06-23 18:18:02.100404
# Unit test for function bump_version
def test_bump_version():
    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ):
        out = bump_version(version, position, pre_release)
        print(out)
        assert out == expected

    _test('1.2.2', position=2, pre_release=None, expected='1.2.3')
    _test('1.2.3', position=1, pre_release=None, expected='1.3')
    _test('1.3.4', position=0, pre_release=None, expected='2.0')
    _test('1.2.3', position=2, pre_release='a', expected='1.2.4a0')

# Generated at 2022-06-23 18:18:06.102700
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:18:13.445260
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:18:21.559460
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:18:30.595277
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor for class ``_VersionPart``."""
    kwargs = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    obj = _VersionPart(**kwargs)
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'



# Generated at 2022-06-23 18:18:37.319164
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '1', 1, 'a', 0, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'major'


# Unit tests for method _each_version_part

# Generated at 2022-06-23 18:18:48.422995
# Unit test for constructor of class _VersionPart
def test__VersionPart():

    # Test 1: constructor with 0 as pos
    try:
        _VersionPart(pos=0, txt='', num=0, pre_txt='', pre_num=-1)
    except TypeError:
        raise AssertionError('_VersionPart(0, "", 0, "", -1) raised '
                             'TypeError unexpectedly!')

    # Test 2: constructor with 1 as pos
    try:
        _VersionPart(pos=1, txt='', num=0, pre_txt='', pre_num=-1)
    except TypeError:
        raise AssertionError('_VersionPart(1, "", 0, "", -1) raised '
                             'TypeError unexpectedly!')

    # Test 3: constructor with 2 as pos

# Generated at 2022-06-23 18:18:53.388617
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=R0201
    args = (0, '1', 1, '', -1, 'major')
    assert _VersionPart(*args).pos == 0
    assert _VersionPart(*args).txt == '1'
    assert _VersionPart(*args).num == 1
    assert _VersionPart(*args).pre_txt == ''
    assert _VersionPart(*args).pre_num == -1
    assert _VersionPart(*args).name == 'major'



# Generated at 2022-06-23 18:19:04.547308
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:15.511402
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    from flutils.packages import _VersionPart  # pylint: disable=E0401

    # noinspection PyProtectedMember
    ver_obj = StrictVersion('1.2.3')
    # noinspection PyProtectedMember
    for pos, num in enumerate(ver_obj.version):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kwargs = {
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': '',
            'pre_num': -1,
            'name': _BUMP_VERSION_POSITION_NAMES[pos]
        }
        obj = _VersionPart(**kwargs)
       

# Generated at 2022-06-23 18:19:26.126728
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version.

    *New in version 0.3*

    """
    # Testing _build_version_info()
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor

# Generated at 2022-06-23 18:19:34.235558
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0')
    assert ver_info.version == '1.0.0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 0
    assert ver_info.patch.num == 0
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.0')
    assert ver_info.version == '1.0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 0
    assert ver_info.patch.num == 0
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.0.0a0')

# Generated at 2022-06-23 18:19:38.048950
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') == \
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')


# Generated at 2022-06-23 18:19:46.643623
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version

    """
    # noinspection PyUnusedLocal
    def assert_version(
            ver: str,
            position: int,
            pre_release: Optional[str],
            expected: str,
            msg: str
    ) -> None:
        """Test function bump_version

        """
        actual = bump_version(ver, position, pre_release)
        assert actual == expected, msg

    assert_version(
        '1.2.2',
        2,
        None,
        '1.2.3',
        'Should bump the patch number.'
    )
    assert_version(
        '1.2.3',
        1,
        None,
        '1.3',
        'Should bump the minor number and leave the patch number as 0.'
    )
    assert_version

# Generated at 2022-06-23 18:19:55.199823
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')

    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name == 'minor'

    assert ver_info.patch.pos == 2

# Generated at 2022-06-23 18:20:06.393061
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert _build

# Generated at 2022-06-23 18:20:14.050821
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:20:17.016053
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(0, '1', 1, '', -1, 'major')


# Generated at 2022-06-23 18:20:30.491820
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2

# Generated at 2022-06-23 18:20:32.739889
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnusedLocal
    ver_info = _build_version_info('1.2.3')



# Generated at 2022-06-23 18:20:45.157182
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert_equals(_VersionInfo('1.2', '1', '2', '', -1),
                  _build_version_info('1.2'))
    assert_equals(_VersionInfo('1.2.3', '1', '2', '3', -1),
                  _build_version_info('1.2.3'))
    assert_equals(_VersionInfo('1.2.0', '1', '2', '', -1),
                  _build_version_info('1.2.0'))
    assert_equals(_VersionInfo('1.2.3a0', '1', '2', '3', 1),
                  _build_version_info('1.2.3a0'))

# Generated at 2022-06-23 18:20:55.071936
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major') == _VersionPart(pos=0, txt='1',
                                                      num=1, pre_txt='',
                                                      pre_num=-1, name='major')
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major') != _VersionPart(pos=0, txt='2',
                                                      num=2, pre_txt='',
                                                      pre_num=-1, name='major')

# Generated at 2022-06-23 18:21:01.967827
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test_data = [
        ('1.2.3', True),
        ('1.2', True),
        ('1', True),
        ('1.2.0', True),
        ('1.2.0a0', True),
        ('1.2.0b0', True),
        ('1.2.0a0.2', False),
        ('1.2.a0', False),
        ('1.b.3', False),
        ('1a2.3.4', False),
        ('1.2.3b', False),
        ('1.23.4', True),
    ]

    for t in test_data:
        if t[1] is False:
            with pytest.raises(ValueError):
                _build_version_info(t[0])
        else:
            _build

# Generated at 2022-06-23 18:21:11.463208
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') \
        == _VersionInfo('1.2.3', _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'), _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'), _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'), -1)


# Generated at 2022-06-23 18:21:22.862489
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit testing for the :meth:`flutils.packages._VersionInfo` class.

    *New in version 0.3*

    """

# Generated at 2022-06-23 18:21:26.095997
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert str(_VersionPart(_BUMP_VERSION_MAJOR, '3', 3, '', -1, '')) ==\
        "VersionPart(pos=0, txt='3', num=3, pre_txt='', pre_num=-1, name='')"



# Generated at 2022-06-23 18:21:39.173718
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    Unit test for constructor of class _VersionInfo
    """
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import PropertyMock

    version = '1.2.3a0'
    pre_num = 0
    pre_txt = 'a'
    pre_pos = 2
    major_num = 1
    major_txt = '1'
    minor_num = 2
    minor_txt = '2'
    patch_num = 3
    patch_txt = '3'

    ver_obj = Mock()
    type(ver_obj).version = PropertyMock(return_value=(major_num, minor_num, patch_num))

# Generated at 2022-06-23 18:21:48.991757
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.0')
    for idx, part in enumerate(_each_version_part(ver_obj)):
        assert isinstance(part.pos, int)
        assert isinstance(part.txt, str)
        assert isinstance(part.num, int)
        assert isinstance(part.pre_txt, str)
        assert isinstance(part.pre_num, int)
        assert isinstance(part.name, str)
        if idx == 0:
            assert part.pos == 0
            assert part.txt == '1'
            assert part.num == 1
            assert part.pre_txt == ''
            assert part.pre_num == -1
            assert part.name == 'major'
        elif idx == 1:
            assert part.pos == 1
            assert part

# Generated at 2022-06-23 18:21:50.435351
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    pass  # TODO: implement test



# Generated at 2022-06-23 18:21:56.354610
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.0.0a10')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert part.txt in ('1', '0', '0a10')
        assert part.num in (1, 0, 0)
        if part.pos == 2:
            assert part.pre_txt in ('a', '')
        assert part.pre_num in (10, -1)
        assert part.name in ('major', 'minor', 'patch')



# Generated at 2022-06-23 18:22:09.894715
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version method.

    *New in version 0.3*

    """

# Generated at 2022-06-23 18:22:19.384062
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for the ``bump_version()`` function.

    """
    import os
    import sys

    import pytest

    from flutils.packages import (
        bump_version,
        _VersionInfo,
        _VersionPart
    )

    _prerelease_types: Tuple[int, ...] = (
        _BUMP_VERSION_MINOR_ALPHA,
        _BUMP_VERSION_MINOR_BETA,
        _BUMP_VERSION_PATCH_ALPHA,
        _BUMP_VERSION_PATCH_BETA,
    )

    def test_bump_version_values(expected, version, pos, pre_release):
        """Test the ``bump_version()`` function.

        """
        bumped = bump_version(version, pos, pre_release)
        assert bumped == expected

# Generated at 2022-06-23 18:22:29.592826
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=W0613, R0201
    assert _VersionPart(0, '0', 0, '', 6, 'major').pos == 0
    assert _VersionPart(0, '0', 0, '', 6, 'major').txt == '0'
    assert _VersionPart(0, '0', 0, '', 6, 'major').num == 0
    assert _VersionPart(0, '0', 0, '', 6, 'major').pre_txt == ''
    assert _VersionPart(0, '0', 0, '', 6, 'major').pre_num == 6
    assert _VersionPart(0, '0', 0, '', 6, 'major').name == 'major'
    assert _VersionPart(1, '1.1', 1, '.1', 1, 'minor').pos == 1
    assert _Version

# Generated at 2022-06-23 18:22:31.127016
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '2', 3, 'pre_txt', 4, 'name')


# Generated at 2022-06-23 18:22:38.082375
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert vp.pos == 0
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'


# Generated at 2022-06-23 18:22:47.046580
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('0.0.0') == _VersionInfo('0.0.0',
                                                        _VersionPart(0, '0', 0, '', -1, 'major'),
                                                        _VersionPart(1, '0', 0, '', -1, 'minor'),
                                                        _VersionPart(2, '0', 0, '', -1, 'patch'),
                                                        -1)

# Generated at 2022-06-23 18:22:53.871777
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.0b2')
    assert ver_info.version == '1.2.0b2'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2b2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'b'
    assert ver_info.minor.pre_num == 2
    assert ver_

# Generated at 2022-06-23 18:23:01.223872
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase

    class _TestCases(TestCase):
        def test__VersionPart(self):
            self.assertRaises(
                TypeError,
                _VersionPart,
                pos='1',
                txt='1',
                num='1',
                pre_txt='',
                pre_num='1',
                name='1'
            )
            self.assertRaises(
                TypeError,
                _VersionPart,
                pos=1,
                txt='1',
                num='1',
                pre_txt='',
                pre_num='1',
                name='1'
            )

# Generated at 2022-06-23 18:23:13.120063
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0a0')
    assert ver_info.version == '1.0.0a0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 0
    assert ver_info.patch.num == 0
    assert ver_info.pre_pos == 2

    ver_info = _build_version_info('3.14159.26535')
    assert ver_info.version == '3.14159.26535'
    assert ver_info.major.num == 3
    assert ver_info.minor.num == 14159
    assert ver_info.patch.num == 26535
    assert ver_info.pre_pos == -1
    assert ver_info.patch.txt == '26535'


# Generated at 2022-06-23 18:23:24.689602
# Unit test for function bump_version
def test_bump_version():
    '''
    Tests the function bump_version

    Returns:
        None
    '''

    print('Testing bump_version')

# Generated at 2022-06-23 18:23:36.412411
# Unit test for function bump_version
def test_bump_version():
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    ver = '1.0'
    assert bump_version(ver) == '1.0.1'
    ver = '1'
    assert bump_version(ver) == '1.1'
    ver = '1.0beta0'
    assert bump_version(ver) == '1.0beta1'
    ver = '1.2.3'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'
    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'
    ver = '1.2.4a1'

# Generated at 2022-06-23 18:23:43.711564
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    args: List[Any] = []
    for part in _each_version_part(ver_obj):
        args.append(part)
    out: _VersionPart = _VersionPart(*args)
    assert out == _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )


# Generated at 2022-06-23 18:23:55.459152
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=C0111
    # pylint: disable=R0201
    assert _build_version_info('1.2.3').version == '1.2.3'
    assert _build_version_info('1.2.3').major.num == 1
    assert _build_version_info('1.2.3').major.pre_txt == ''
    assert _build_version_info('1.2.3').minor.num == 2
    assert _build_version_info('1.2.3').minor.pre_txt == ''
    assert _build_version_info('1.2.3').patch.num == 3
    assert _build_version_info('1.2.3').patch.pre_txt == ''
    assert _build_version_info('1.2.3').pre

# Generated at 2022-06-23 18:23:58.152323
# Unit test for function bump_version
def test_bump_version():
    """Run a unit test for the bump_version function."""
    from flutils.testing import test_bump_version as tbv
    tbv()

# Generated at 2022-06-23 18:24:09.486853
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = "1.2.3"
    major_num = 1
    minor_num = 2
    patch_num = 3
    pre_pos = -1
    version_info = _build_version_info(version)

    # Test: Major
    major_part = version_info.major
    assert major_part.pos == 0
    assert major_part.txt == "1"
    assert major_part.num == major_num
    assert major_part.pre_txt == ""
    assert major_part.pre_num == -1
    assert major_part.name == "major"

    # Test: Minor
    minor_part = version_info.minor
    assert minor_part.pos == 1
    assert minor_part.txt == "2"
    assert minor_part.num == minor_num
    assert minor_

# Generated at 2022-06-23 18:24:19.180592
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version

    .. seealso::
        * :func:`bump_version`
        * :func:`test_bump_version.module_doctest_src`

    *New in version 0.3*

    """
    # Import builtins for the python version
    import builtins
    # Import doctest for the python version
    import doctest

    # Get the source for the module
    mod_src = test_bump_version.module_doctest_src()
    # Run the doctests

# Generated at 2022-06-23 18:24:28.041542
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:24:34.974231
# Unit test for function bump_version
def test_bump_version():
    from flutils import packages
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
   

# Generated at 2022-06-23 18:24:46.237563
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-23 18:24:50.123580
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    part = _VersionPart(0, '1', 1, '', -1, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:24:55.361909
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from random import randint
    from pprint import pprint
    from collections import namedtuple

    ALPHA = 'a'
    BETA = 'b'
    ALPHA_NUM = randint(0, 10)
    BETA_NUM = randint(0, 10)
    VersionPart = namedtuple(
        'VersionPart',
        field_names=(
            'pos',
            'txt',
            'num',
            'pre_txt',
            'pre_num',
            'name',
        )
    )

# Generated at 2022-06-23 18:25:06.558273
# Unit test for function bump_version
def test_bump_version():
    import doctest
    num_failed, num_attempted = doctest.testmod(
        name='bump_version',
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE
    )
    print('\nRan', num_attempted, 'tests:', num_failed, 'failed.')
    print(' DocTest results for function bump_version:', end='')
    if num_failed == 0:
        print(' PASSED.')
    else:
        print(' FAILED.')


# Call test_bump_version if called from the command line
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:25:18.652508
# Unit test for function bump_version
def test_bump_version():
    """Test the function, ``bump_version``."""
    from flutils.packages import bump_version

    def _test_bump_version(
            version,
            position,
            expected_version,
            pre_release=None
    ):
        got = bump_version(version, position, pre_release)
        assert got == expected_version

    _test_bump_version(
        '1.2.2',
        2,
        '1.2.3'
    )
    _test_bump_version(
        '1.2.3',
        1,
        '1.3'
    )
    _test_bump_version(
        '1.3.4',
        0,
        '2.0'
    )

# Generated at 2022-06-23 18:25:29.566438
# Unit test for function bump_version
def test_bump_version():

    from unittest import TestCase
    from unittest.mock import patch

    class DummyVerObj:
        version: Tuple[int, int, int] = (0, 0, 0)
        prerelease: Optional[Tuple[str, int]] = None

        def __init__(self, version, prerelease):
            self.version = version
            self.prerelease = prerelease

    class Test(TestCase):
        def test_bump_version(self):

            def patch_strict_version(version):
                # pylint: disable=W0613
                return DummyVerObj(
                    version=version.version,
                    prerelease=version.prerelease
                )

            patch_strict_version = staticmethod(patch_strict_version)

# Generated at 2022-06-23 18:25:40.943399
# Unit test for function bump_version
def test_bump_version():
    # For test coverage
    bump_version('')
    bump_version('1.2.3')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)
    bump_version('1.2.3', position=-2)
    bump

# Generated at 2022-06-23 18:25:43.749143
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    import doctest
    doctest.testmod()


# Make sure the unit test is run
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:25:55.678820
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = {}
    args['pos'] = -1
    args['txt'] = '-1'
    args['num'] = -1
    args['pre_txt'] = ''
    args['pre_num'] = -1
    args['name'] = ''
    version_part = _VersionPart(**args)
    assert version_part.pos == -1 and version_part.txt == '-1' and version_part.num == -1 and version_part.pre_txt == '' and version_part.pre_num == -1 and version_part.name == ''
    args['pos'] = 0
    args['txt'] = '0'
    args['num'] = 0
    args['pre_txt'] = ''
    args['pre_num'] = -1
    args['name'] = ''
    version_part = _VersionPart

# Generated at 2022-06-23 18:26:01.559197
# Unit test for function bump_version
def test_bump_version():
    """Unit test that tests :py:func:`flutils.packages.bump_version`."""
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Unit test for :py:func:`flutils.packages.bump_version`."""

        def test_bump_version(self) -> None:
            """Unit test for :py:func:`flutils.packages.bump_version`."""
            from flutils.packages import bump_version

            self.assertEqual('1.2.3', bump_version('1.2.2'))
            self.assertEqual('1.3', bump_version('1.2.2',
                                                 position=1))

# Generated at 2022-06-23 18:26:09.454544
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.0.0'
    major_num = 1
    minor_num = 0
    patch_num = 0
    ver_info = _build_version_info(version)

    assert ver_info.version == version
    assert ver_info.major.txt == str(major_num)
    assert ver_info.major.num == major_num
    assert ver_info.minor.txt == str(minor_num)
    assert ver_info.minor.num == minor_num
    assert ver_info.patch.txt == str(patch_num)
    assert ver_info.patch.num == patch_num



# Generated at 2022-06-23 18:26:21.463600
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        '1.2.3',
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        -1
    ) == _build_version_info('1.2.3')

# Generated at 2022-06-23 18:26:32.193370
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from flutils.packages import bump_version
    from collections import namedtuple
    from flutils.misc import InvalidData

    Test = namedtuple('Test', ['start', 'expected', 'position', 'prerelease'])
