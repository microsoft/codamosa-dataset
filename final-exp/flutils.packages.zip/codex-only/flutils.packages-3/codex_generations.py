

# Generated at 2022-06-23 18:16:43.634099
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _build_version_info('1.2.3')
    assert ver.version == '1.2.3'
    ver = _build_version_info('1.2b0')
    assert ver.version == '1.2b0'
    ver = _build_version_info('1.2a0')
    assert ver.version == '1.2a0'
    ver = _build_version_info('1.3')
    assert ver.version == '1.3'
    ver = _build_version_info('6.0.0')
    assert ver.version == '6.0.0'
    ver = _build_version_info('6.0.0a3')
    assert ver.version == '6.0.0a3'

# Generated at 2022-06-23 18:16:50.546320
# Unit test for function bump_version
def test_bump_version():
    """
    Tests for function bump_version. See that function for documentation.

    """
    import doctest
    options = (doctest.ELLIPSIS |
               doctest.NORMALIZE_WHITESPACE |
               doctest.REPORT_NDIFF)
    results = doctest.testmod(optionflags=options)
    assert results[0] == 0

# Generated at 2022-06-23 18:16:57.498883
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase

    class Test__VersionPart(TestCase):
        """Test for the constructor of ``_VersionPart``."""

        def test__all_kwargs(self):
            """Test for all kwargs."""
            kwargs = {
                'pos': 0,
                'txt': '1',
                'num': 1,
                'pre_txt': 'a',
                'pre_num': 0,
                'name': 'major'
            }
            obj = _VersionPart(**kwargs)
            # Make sure all kwargs were set correctly
            for key in kwargs:
                self.assertEqual(getattr(obj, key), kwargs[key])

    # noinspection PyTypeChecker
    return Test__VersionPart

# Generated at 2022-06-23 18:17:08.294546
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=no-value-for-parameter
    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.name == 'patch'
    assert ver_info.pre_pos == 1
    ver_info = _build_version_info('2.1.4b0')
    assert ver_info.version == '2.1.4b0'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.name == 'patch'
    assert ver_

# Generated at 2022-06-23 18:17:17.577450
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.2'
    assert _VersionInfo(
        version=version,
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='2', num=2, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1
    ) == _build_version_info(version)



# Generated at 2022-06-23 18:17:28.430409
# Unit test for function bump_version
def test_bump_version():
    """Pytest unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:40.785754
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = {
        'version': '1.0.0',
        'major': _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major',
        ),
        'minor': _VersionPart(
            pos=1,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='minor',
        ),
        'patch': _VersionPart(
            pos=2,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch',
        ),
        'pre_pos': -1
    }
    out = _VersionInfo(**args)

   

# Generated at 2022-06-23 18:17:46.376924
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test_data = (
        ('1.2.3', 1, 2, 3),
        ('1.2.3a0', 1, 2, 3),
        ('1.2.3b1', 1, 2, 3),
    )
    for version, major, minor, patch in test_data:
        _build_version_info(version)
        ver_info = _build_version_info(version)

        assert ver_info.major.pos == 0
        assert ver_info.major.num == major

        assert ver_info.minor.pos == 1
        assert ver_info.minor.num == minor

        assert ver_info.patch.pos == 2
        assert ver_info.patch.num == patch



# Generated at 2022-06-23 18:17:54.522946
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo(
        '1.0.0',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1)
    _VersionInfo(
        '1.0.1',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '1', 1, '', -1, 'patch'),
        -1)

# Generated at 2022-06-23 18:17:57.675470
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [0, '2', 2, '', -1, 'major']
    assert _VersionPart(*args) == _VersionPart(*args)



# Generated at 2022-06-23 18:18:06.158150
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3.4')
    _build_version_info('1.2.3.4a0')
    _build_version_info('1.2.3.4a0b0')
    _build_version_info('1.2.3.4a0b0c0')
    _build_version_info('1.2.3.4a0b0c0d0')
    _build_version_info('1.2.3.4.5')
    _build_version_info('1.2.3.4.5.6a0')
    _build_version_info('1.2.3.4.5.6a0b0')

# Generated at 2022-06-23 18:18:10.625482
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from collections import namedtuple
    from pprint import pprint

    VersionPart = namedtuple(
        'VersionPart',
        'pos txt num pre_txt pre_num name'
    )
    ver_obj = StrictVersion('1.9')
    for part in _each_version_part(ver_obj):
        # noinspection PyUnresolvedReferences
        pprint(VersionPart._make(part))


# Generated at 2022-06-23 18:18:21.037298
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the bump_version() function."""

# Generated at 2022-06-23 18:18:26.293647
# Unit test for function bump_version

# Generated at 2022-06-23 18:18:34.869792
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version'."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:18:45.663497
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.2')
    assert version == '1.2.3'

    version = bump_version('1.2.3', position=1)
    assert version == '1.3'

    version = bump_version('1.3.4', position=0)
    assert version == '2.0'

    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'

    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'

    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'


# Generated at 2022-06-23 18:18:54.370031
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major',
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor',
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch',
        ),
        pre_pos=-1
    )
    assert info.version == '1.2.3'
    assert info

# Generated at 2022-06-23 18:19:05.182691
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo.

    *New in version 0.3.0b0*

    """
    # pylint: disable=W0105
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:19:10.163961
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        _VersionPart()
    except TypeError:
        pass
    else:
        raise RuntimeError('Programmers error.')

    args = (1, '2', 3, '4', 5, '6')
    t = _VersionPart(*args)
    for i, a in enumerate(args):
        assert t.__getattribute__(t._fields[i]) == a


# Generated at 2022-06-23 18:19:22.114481
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion

    ver_obj = StrictVersion('1.2.3')
    result = _each_version_part(ver_obj).__next__()
    assert result.pos == 0
    assert result.txt == '1'
    assert result.num == 1
    assert result.pre_txt == ''
    assert result.pre_num == -1
    assert result.name == 'major'

    ver_obj = StrictVersion('1.2.3a1')
    result = _each_version_part(ver_obj).__next__()
    assert result.pos == 0
    assert result.txt == '1'
    assert result.num == 1
    assert result.pre_txt == ''
    assert result.pre_num == -1
    assert result.name == 'major'

    result

# Generated at 2022-06-23 18:19:30.951308
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3.4')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    ver_obj = StrictVersion('1.2.3')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    ver_obj = StrictVersion('1.2')

# Generated at 2022-06-23 18:19:41.593446
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    bump_version('1.2.2')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-23 18:19:51.899623
# Unit test for function bump_version
def test_bump_version():
    """Test(s) for the :py:func:`bump_version` function."""
    from flutils.packages import bump_version

    def test_bump_version_pos():
        """Test(s) for :py:func:`bump_version` using position."""
        print('Testing bump_version using position...')
        ver = '1.2.2'
        out = bump_version(ver)
        print('  %s -> %s' % (ver, out))
        ver = '1.2.3'
        out = bump_version(ver, position=1)
        print('  %s -> %s' % (ver, out))
        ver = '1.3.4'
        out = bump_version(ver, position=0)

# Generated at 2022-06-23 18:19:58.632371
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the :py:func:`flutils.packages.bump_version` function.
    """

    import sys
    import unittest
    import warnings

    from .common import (
        TestCase,
        skipIfLong,
        skipIfPy3,
        skipIfPyPy,
        skipIfPy36,
        skipIfPyPy3,
        skipIfPy37,
        skipIfTravis,
        skipIfNoPillow,
        skipIfNoScipy,
        skipIfNoXlsxWriter,
        skipIfWin32,
    )

    IS_PY3: bool = (sys.version_info[0] == 3)
    PY3_VERSION: int = 3
    PY2_VERSION: int = 2

# Generated at 2022-06-23 18:20:09.558113
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'"""
    import unittest
    import sys

    def _build_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        ver_info = _build_version_info(version)
        _bump_position = _build_version_bump_position(position)
        _bump_type = _build_version_bump_type(_bump_position, pre_release)
        if expected:
            out = bump_version(version, position, pre_release)

# Generated at 2022-06-23 18:20:17.224648
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert {
        'version': '1.2.3.dev1',
        'major': _VersionPart(
            pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
        ),
        'minor': _VersionPart(
            pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
        ),
        'patch': _VersionPart(
            pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
        ),
        'pre_pos': -1
    } == _build_version_info('1.2.3.dev1')

# Generated at 2022-06-23 18:20:30.701216
# Unit test for function bump_version
def test_bump_version():
    """Test the function ``bump_version``.

    *New in version 0.3*

    Raises:
        AssertionError: if any of the tests fail.

    See Also:
        :func:`bump_version`

    """
    tests: Dict[str, Tuple[str, int, Optional[str], str]] = {}
    tests['0.1.1'] = ('0.1.1', 2, None, '0.1.2')
    tests['1.1.1'] = ('1.1.1', 1, None, '1.2')
    tests['2.0.0'] = ('2.0.0', 0, None, '3.0')


# Generated at 2022-06-23 18:20:39.323317
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import (
        bump_version,
        _build_version_info,
        _build_version_bump_position,
        _build_version_bump_type,
        _VersionInfo,
    )

    # Test with a basic version
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.2') == '0.0.3'
    assert bump_version('0.1.3') == '0.1.4'
    assert bump_version('0.2.0') == '0.2.1'
    assert bump_version('1.2.1') == '1.2.2'

    # Test with a version with a pre-release

# Generated at 2022-06-23 18:20:51.853956
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    # ARRANGE
    version = '1.2.3'
    part = _VersionPart(
        pos = 1,
        txt = '2',
        num = 2,
        pre_txt = '',
        pre_num = -1,
        name = 'minor'
    )
    part2 = _VersionPart(
        pos = 2,
        txt = '3',
        num = 3,
        pre_txt = '',
        pre_num = -1,
        name = 'patch'
    )
    expected = _VersionInfo(
        version = '1.2.3',
        major = part,
        minor = part,
        patch = part2,
        pre_pos = -1
    )

    # ACT
    actual = _build_version_info(version)

    # ASSERT

# Generated at 2022-06-23 18:21:00.781267
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnresolvedReferences
    """
    Test function to be run by a unit test or test suite.
    """
    assert str(_build_version_info('1.2.3')) == \
        "VersionInfo(version='1.2.3', major=VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'), minor=VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'), patch=VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'), pre_pos=-1)"

# Generated at 2022-06-23 18:21:07.521889
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info("1.2.3a0")
    assert ver_info.version == "1.2.3a0"
    assert ver_info.major.txt == "1"
    assert ver_info.minor.txt == "2"
    assert ver_info.patch.txt == "3a0"
    assert ver_info.pre_pos == 1
    
    ver_info = _build_version_info("1.2a0")
    assert ver_info.version == "1.2a0"
    assert ver_info.major.txt == "1"
    assert ver_info.minor.txt == "2a0"
    assert ver_info.patch.txt == ""
    assert ver_info.pre_pos == 1
    
    ver_info = _build_version

# Generated at 2022-06-23 18:21:12.749432
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """ Test instance of _VersionPart """
    version_part = _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=0, name='major'
    )
    assert version_part.pos == 0
    assert version_part.txt == '1'
    assert version_part.num == 1
    assert version_part.pre_txt == ''
    assert version_part.pre_num == 0
    assert version_part.name == 'major'

# Generated at 2022-06-23 18:21:18.203372
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    expected = '_VersionPart(pos=0, txt=\'1\', num=1, pre_txt=\'\', pre_num=-1, name=\'major\')' # noqa
    actual = str(_VersionPart(0, '1', 1, '', -1, 'major'))
    assert actual == expected


# Generated at 2022-06-23 18:21:27.313613
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from flutils.testing import UnitTester
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        tester = UnitTester(
            _VersionPart,
            func_name='__init__',
            args=(part.pos, part.txt, part.num, part.pre_txt, part.pre_num, part.name),
            kwargs={},
            expected_repr=repr(dict(
                pos=part.pos,
                txt=part.txt,
                num=part.num,
                pre_txt=part.pre_txt,
                pre_num=part.pre_num,
                name=part.name
            ))
        )
        msg = tester.run

# Generated at 2022-06-23 18:21:39.989466
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    import tests.helpers

    argspec = inspect.getfullargspec(bump_version)
    assert argspec.args == ['version', 'position', 'pre_release']
    assert argspec.varargs is None
    assert argspec.varkw is None
    assert argspec.defaults == (2, None)
    assert argspec.kwonlyargs == []
    assert argspec.kwonlydefaults is None
    assert argspec.annotations == {
        'return': str,
        'version': str,
        'position': int,
        'pre_release': Optional[str]
    }

# Generated at 2022-06-23 18:21:49.397981
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit tests for the constructor of class _VersionInfo."""
    assert _VersionInfo(
        '1.2.0',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    ) == _build_version_info('1.2.0')

# Generated at 2022-06-23 18:21:54.337095
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver = '1.2.3'
    ver_obj = StrictVersion(ver)
    for part in _each_version_part(ver_obj):
        assert(
            part.pos in (0, 1, 2) and
            part.txt in ('1', '2', '3') and
            part.num in (1, 2, 3) and
            part.pre_txt in ('', 'a', 'b') and
            part.pre_num in (-1, 0, 1) and
            part.name in ('major', 'minor', 'patch')
        )

    ver = '1.2.0'
    ver_obj = StrictVersion(ver)

# Generated at 2022-06-23 18:21:59.895834
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0108
    info = _build_version_info('1.2.3')
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.minor.pre_num == -1
    assert info.patch.num == 3
    assert info.pre_pos == -1



# Generated at 2022-06-23 18:22:06.898008
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = (1, '2', 3, 'a', 4, 'alpha')
    part = _VersionPart(*args)
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 3
    assert part.pre_txt == 'a'
    assert part.pre_num == 4
    assert part.name == 'alpha'

# Generated at 2022-06-23 18:22:13.666489
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart('test', 'test', 1, 'test', 2, 'test')
    assert vp == ('test', 'test', 1, 'test', 2, 'test')
    # test use of NamedTuple
    assert vp.pos == 'test'
    assert vp.txt == 'test'
    assert vp.num == 1
    assert vp.pre_txt == 'test'
    assert vp.pre_num == 2
    assert vp.name == 'test'


# Generated at 2022-06-23 18:22:25.079062
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    normal_version = '1.2.3'
    assert(_build_version_info(normal_version) == _VersionInfo(
        '1.2.3',
        _VersionPart(
            0, '1', 1, '', -1, 'major'
        ),
        _VersionPart(
            1, '2', 2, '', -1, 'minor'
        ),
        _VersionPart(
            2, '3', 3, '', -1, 'patch'
        ),
        -1
    ))

    version = '1.2.0'

# Generated at 2022-06-23 18:22:35.239243
# Unit test for function bump_version
def test_bump_version():
    """Unit test for ``bump_version()``."""

    from test.utils import check_samples, run_test


# Generated at 2022-06-23 18:22:36.566459
# Unit test for function bump_version
def test_bump_version():
    """No unit tests yet."""
    return

# Generated at 2022-06-23 18:22:46.749960
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version

    with pytest.raises(ValueError):
        bump_version('1.2.3', position=-4)
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=3)
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=0, pre_release='c')
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=1, pre_release='c')
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=2, pre_release='c')

# Generated at 2022-06-23 18:22:53.456908
# Unit test for function bump_version

# Generated at 2022-06-23 18:23:02.818120
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump

# Generated at 2022-06-23 18:23:13.435945
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version 
    from flutils.testing import (
        assert_str,
        assert_str_kwargs,
        assert_str_raises,
        create_temp_file_path,
        write_file
    )

    def _assert_bump_version(
            ver_str: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        assert_str_kwargs(
            bump_version,
            actual_args=[ver_str],
            actual_kwargs={'position': position, 'pre_release': pre_release},
            expected=expected
        )


# Generated at 2022-06-23 18:23:24.093228
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('0.1')
    assert isinstance(ver_info, _VersionInfo)
    assert ver_info.version == '0.1'
    assert ver_info.major.num == 0
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 0
    assert ver_info.pre_pos == -1
    ver_info = _build_version_info('1.1.1')
    assert isinstance(ver_info, _VersionInfo)
    assert ver_info.version == '1.1.1'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 1
    assert ver_info.patch.num == 1
    assert ver_info.pre_pos == -1

# Generated at 2022-06-23 18:23:35.587467
# Unit test for function bump_version

# Generated at 2022-06-23 18:23:46.169249
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version
    from distutils.version import StrictVersion

    def check(ver_in, ver_out, position, pre_release=None):
        ver = bump_version(ver_in, position=position,
                           pre_release=pre_release)
        StrictVersion(ver)
        assert ver == ver_out

        ver = bump_version(ver, position=position, pre_release=pre_release)
        StrictVersion(ver)
        assert ver == ver_out

    def test():
        check('1.2.3', '1.2.4', position=2)
        check('1.2.3', '1.3', position=1)
        check('1.2.3', '2.0', position=0)


# Generated at 2022-06-23 18:23:57.674538
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-23 18:24:06.927842
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _VersionInfo(
        version='1.2.3a0',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='a',
            pre_num=0,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3a0',
            num=3,
            pre_txt='a',
            pre_num=0,
            name='patch'
        ),
        pre_pos=1
    )
    assert ver.major.num == 1
   

# Generated at 2022-06-23 18:24:17.623930
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:24:27.795476
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """pytest unit test for the class _VersionInfo."""

    major = 1
    minor = 2
    patch = 3
    pre_release1 = 'a0'
    pre_release2 = 'a1'

    test_version1 = '%s.%s.%s%s' % (major, minor, patch, pre_release1)
    test_version2 = '%s.%s.%s%s' % (major, minor, patch, pre_release2)
    test_version3 = '%s.%s.%s' % (major, minor, patch)


# Generated at 2022-06-23 18:24:33.890890
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # fmt: off
    assert _VersionInfo(
        '1.2.0.1a1',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2.0', num=2, pre_txt='a', pre_num=1, name='minor'),
        _VersionPart(pos=2, txt='0', num=0, pre_txt='', pre_num=-1, name='patch'),
        1
    ) == _build_version_info('1.2.0.1a1')
    # fmt: on



# Generated at 2022-06-23 18:24:45.327794
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    vi = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    assert vi.version == '1.2.3'
    assert vi.major.pos == 0
    assert vi.major.txt == '1'
    assert vi.major.num == 1
    assert vi.major.pre_txt == ''
    assert vi.major.pre_num == -1
    assert vi.major.name == 'major'
    assert vi.minor.pos == 1
    assert vi.minor.txt == '2'

# Generated at 2022-06-23 18:24:46.760985
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    import tests
    assert tests.do('flutils.packages._VersionInfo')


# Generated at 2022-06-23 18:24:50.967554
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test constructor of class _VersionInfo"""

    # Version 2.1.0 is the current version
    out = _build_version_info('2.1.0')
    assert out.version == '2.1.0'
    assert out.major.txt == '2'
    assert out.major.num == 2
    assert out.minor.txt == '1'
    assert out.minor.num == 1
    assert out.patch.txt == ''
    assert out.patch.num == 0
    assert out.pre_pos == -1


# Generated at 2022-06-23 18:25:01.892523
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = '1.2.3a0'
    exp = ['1', '2', '3', 'a', '0']
    ver_info = _build_version_info(ver)
    assert ver_info.version == ver
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info

# Generated at 2022-06-23 18:25:10.773228
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3', 3, '', -1, 'patch'), -1)

    ver_info = _VersionInfo('1.2.3a0', _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3a0', 3, 'a', 0, 'patch'), 1)



# Generated at 2022-06-23 18:25:20.496118
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1
    )

# Generated at 2022-06-23 18:25:29.330835
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = dict(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    VersionPart = _VersionPart(**kwargs)
    assert VersionPart.pos == kwargs.get('pos')
    assert VersionPart.txt == kwargs.get('txt')
    assert VersionPart.num == kwargs.get('num')
    assert VersionPart.pre_txt == kwargs.get('pre_txt')
    assert VersionPart.pre_num == kwargs.get('pre_num')
    assert VersionPart.name == kwargs.get('name')



# Generated at 2022-06-23 18:25:40.809224
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        print(part)
    print('')

    ver_obj = StrictVersion('0.0.0')
    for part in _each_version_part(ver_obj):
        print(part)
    print('')

    ver_obj = StrictVersion('1.2a0')
    for part in _each_version_part(ver_obj):
        print(part)
    print('')

    ver_obj = StrictVersion('3.4.5a1')
    for part in _each_version_part(ver_obj):
        print(part)
    print('')

    ver_obj = StrictVersion('2.5.6b7')

# Generated at 2022-06-23 18:25:48.876790
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3a4')
    assert ver_info.version == '1.2.3a4'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 4

# Generated at 2022-06-23 18:25:56.182705
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=W0612
    # pylint: disable=W0212
    part = _VersionPart(0, '1.2.3', 1, '', -1, 'major')
    assert part.pos == 0
    assert part.txt == '1.2.3'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:26:02.061784
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from .bump_version import BUMP_VERSION_TESTS
    from .bump_version import BUMP_VERSION_TESTS_SORTED
    tests = BUMP_VERSION_TESTS
    for test_num in range(len(tests)):
        test = tests[test_num]
        bumped_version = bump_version(test['input'])
        test_num_bumped_version = test_num + len(BUMP_VERSION_TESTS_SORTED)
        assert bumped_version == tests[test_num_bumped_version]['input']
        test_num_bumped_version += len(BUMP_VERSION_TESTS_SORTED)

# Generated at 2022-06-23 18:26:12.171960
# Unit test for function bump_version

# Generated at 2022-06-23 18:26:17.943577
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    result = repr(_VersionInfo('1.2.3', None, None, None, -1))
    expected = ("_VersionInfo(version='1.2.3', major=None, minor=None, "
                "patch=None, pre_pos=-1)")
    assert result == expected

# Generated at 2022-06-23 18:26:29.185561
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from pprint import pprint
    from time import time
    from timeit import default_timer
    from unittest import TestCase
    from flutils.packages import bump_version as bv


# Generated at 2022-06-23 18:26:36.814349
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914
    # noinspection PyUnusedLocal
    def _test_bump_version(
            version: str,
            pos: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        out = bump_version(version, pos, pre_release)
        assert out == expected, (
            "Expected %s but got %s, when bumping: %s, position: %s, "
            "pre_release: %s" % (
                expected, out, version, pos, pre_release
            )
        )

    _test_bump_version('1.2.2', 2, None, '1.2.3')
    _test_bump_version('1.2.3', 1, None, '1.3')
   