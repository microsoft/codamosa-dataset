

# Generated at 2022-06-23 18:16:39.894907
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    import random


# Generated at 2022-06-23 18:16:46.307437
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        from types import SimpleNamespace
    except ImportError:
        if_python2_raise_import_error()
    _args = dict(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    class_ = _VersionPart(**_args)
    part = SimpleNamespace(**_args)
    assert part.pos == class_.pos
    assert part.txt == class_.txt
    assert part.num == class_.num
    assert part.pre_txt == class_.pre_txt
    assert part.pre_num == class_.pre_num
    assert part.name == class_.name
    assert part == class_
    part = SimpleNamespace(**_args)
    assert part == class_

# Generated at 2022-06-23 18:16:48.321307
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    t = _VersionPart(0,1,2,3,4,5)
    assert t.pos == 0
    assert t.txt == 1
    assert t.num == 2
    assert t.pre_txt == 3
    assert t.pre_num == 4
    assert t.name == 5



# Generated at 2022-06-23 18:16:51.305565
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pprint
    ver_obj = StrictVersion('1.0.0')
    for part in _each_version_part(ver_obj):
        pprint(vars(part))


# Generated at 2022-06-23 18:16:54.496140
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('0.0.0', _VersionPart(0, '0', 0, '', -1, 'major'), _VersionPart(1, '0', 0, '', -1, 'minor'), _VersionPart(2, '', 0, '', -1, 'patch'), -1) == _build_version_info('0.0.0')

# Generated at 2022-06-23 18:17:00.577953
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args: Dict[str, Any] = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'b',
        'pre_num': 5,
        'name': _BUMP_VERSION_POSITION_NAMES[0]
    }
    ver_part = _VersionPart(**args)
    args = dict(args)
    del args['name']
    args['pre_txt'] = 'alpha'
    ver_part_alpha = _VersionPart(**args)
    # noinspection PyProtectedMember
    assert ver_part._asdict() == args
    # noinspection PyProtectedMember
    assert (ver_part_alpha._asdict() == args) is False


# Generated at 2022-06-23 18:17:10.542988
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    pos = _build_version_bump_position(-3)
    bump_type = _build_version_bump_type(pos, 'alpha')
    # noinspection PyUnusedLocal
    hold: List[Union[int, str]] = []
    if bump_type == _BUMP_VERSION_MAJOR:
        hold = [1, 0]
    elif bump_type in _BUMP_VERSION_MINORS:
        if bump_type == _BUMP_VERSION_MINOR:
            hold = [1, 0]
        else:
            if bump_type == _BUMP_VERSION_MINOR_ALPHA:
                part = '{}a0'.format(0 + 1)
            else:
                part = '{}b0'.format(0 + 1)
            hold = [1, part]
   

# Generated at 2022-06-23 18:17:16.391852
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for ver in [
            '1.2.3.4', '1.2.3.4.5',
            '1.2', '1.2.0.0',
            '1', '1.0', '1.0.0',
    ]:
        for part in _each_version_part(StrictVersion(ver)):
            assert isinstance(part, _VersionPart)



# Generated at 2022-06-23 18:17:24.949454
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    ver_part = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert ver_part.pos == 0
    assert ver_part.txt == '1'
    assert ver_part.num == 1
    assert ver_part.pre_txt == ''
    assert ver_part.pre_num == -1
    assert ver_part.name == 'major'
    ver_part = _VersionPart(pos=1, txt='0', num=0, pre_txt='a', pre_num=1, name='minor')
    assert ver_part.pos == 1
    assert ver_part.txt == '0'
    assert ver_part.num == 0
    assert ver_part.pre_txt

# Generated at 2022-06-23 18:17:28.128689
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0612
    part = _VersionPart(0, '0', 0, '', -1, 'major')
    # pylint: enable=W0612



# Generated at 2022-06-23 18:17:40.592219
# Unit test for function bump_version
def test_bump_version():

    # pylint: disable=C0103
    # The line above is to prevent errors from the function name itself

    from pytest import raises

    # pylint: disable=W0612
    # The line above is to prevent errors from unused variables
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-23 18:17:48.405901
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.tests.base import raises_error_msg

    assert bump_version('1.2.4b0') == '1.2.4'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.4a1', pre_release='a') == '1.2.4a2'
    assert bump_version('1.2.4b0', pre_release='b') == '1.2.4b1'
    assert bump_version('1.2.3', position=1) == '1.3'

# Generated at 2022-06-23 18:17:57.034547
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0613
    # pylint: disable=R0201,W0621
    a = _VersionInfo([0, 1, 2], 0, 1, 2, -1)
    b = type(a)
    _build_version_info('1.2.3')
    _build_version_info('1.2.3a1')
    _build_version_info('1.2.3b1')

# Generated at 2022-06-23 18:18:05.805754
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pragma: no cover
    from flutils_tests.helpers import TestHelpers
    from flutils.packages import _VersionPart
    th = TestHelpers('flutils.packages._VersionPart')
    version_part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=0,
        name='major'
    )
    th.assertEquals(version_part.pos, 0)
    th.assertEquals(version_part.txt, '1')
    th.assertEquals(version_part.num, 1)
    th.assertEquals(version_part.pre_txt, '')
    th.assertEquals(version_part.pre_num, 0)

# Generated at 2022-06-23 18:18:13.224283
# Unit test for function bump_version
def test_bump_version():
    """
    Tests for bump_version
    """
    from flutils.testing import (
        assert_equality,
        assert_equality_multi,
        assert_error,
    )


# Generated at 2022-06-23 18:18:20.330057
# Unit test for function bump_version
def test_bump_version():
    """
    Unit tests for function bump_version.
    """
    import pytest
    from flutils.packages import bump_version
    from flutils.dotdict import dotdictify

    # Setup

# Generated at 2022-06-23 18:18:30.667826
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    pos = -1
    try:
        _VersionInfo(version)
    except (IndexError, AttributeError) as exc:
        raise
    else:
        raise Exception('Did not catch expected exception')

    args = [version]
    for part in _each_version_part(StrictVersion(version)):
        if part.pre_txt:
            pos = part.pos
        args.append(part)
    args.append(pos)
    try:
        _VersionInfo(*args)
    except IndexError as exc:
        raise
    except AttributeError as exc:
        raise
    except Exception as exc:
        raise
    else:
        pass



# Generated at 2022-06-23 18:18:42.889968
# Unit test for function bump_version
def test_bump_version():

    # Test logic
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0')

# Generated at 2022-06-23 18:18:52.734716
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2a0.3')
    _build_version_info('10.20b0.3')
    _build_version_info('10.20b0.3')
    _build_version_info('1.2.3')
    _build_version_info('1.2.3.4')
    _build_version_info('1.2.3a1')
    _build_version_info('1.2.3a1.4')
    _build_version_info('1.2.3b2')
    _build_version_info('1.2.3b2.4')
    _build_version_info('1.0.3')

# Generated at 2022-06-23 18:18:56.426258
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version_info = _build_version_info('0.3.3')
    assert version_info.version == '0.3.3'



# Generated at 2022-06-23 18:19:01.161736
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(0, '', 0, '', 0, 'test')
    assert vp.pos == 0
    assert vp.txt == ''
    assert vp.num == 0
    assert vp.pre_txt == ''
    assert vp.pre_num == 0
    assert vp.name == 'test'


# Generated at 2022-06-23 18:19:03.732150
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )

# Generated at 2022-06-23 18:19:12.969925
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.2')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-23 18:19:23.533742
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test with valid data
    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.num == 3
    assert ver

# Generated at 2022-06-23 18:19:27.990482
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(0, '1', 1, 'a', 0, 'major')
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == 'a'
    assert obj.pre_num == 0
    assert obj.name == 'major'

# Generated at 2022-06-23 18:19:39.537897
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.3')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-23 18:19:47.645031
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests the _VersionInfo constructor."""
    # pylint: disable=C0103,W0612
    test_info = _build_version_info('1.2.3a0')
    assert test_info.version == '1.2.3a0'
    assert test_info.major.num == 1
    assert test_info.major.txt == '1'
    assert test_info.major.pos == 0
    assert test_info.major.pre_txt == ''
    assert test_info.major.pre_num == -1
    assert test_info.major.name == 'major'
    assert test_info.minor.num == 2
    assert test_info.minor.txt == '2a0'
    assert test_info.minor.pos == 1
    assert test_info.minor

# Generated at 2022-06-23 18:19:54.210395
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info == _VersionInfo('1.2.3', 0, 1, 2, -1)

    ver_info = _build_version_info('1.2.0')
    assert ver_info == _VersionInfo('1.2', 0, 1, 2, -1)

    ver_info = _build_version_info('1.2.3b4')
    assert ver_info == _VersionInfo('1.2.3b4', 0, 1, 2, 4)

    ver_info = _build_version_info('1.2.0b4')
    assert ver_info == _VersionInfo('1.2.3b4', 0, 1, 2, 4)


# Generated at 2022-06-23 18:20:05.605462
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    data = [
        ('1.2.3', 0, '1.2.3', '1', '2', '3', '1', '2', '3', -1),
        ('1.2.3a0', 0, '1.2.3a0', '1', '2', '3', '1', '2', '3', -1),
        ('1.2a1', 0, '1.2a1', '1', '2', '0', '1', '2', 'a1', 1),
        ('1.3b3', 0, '1.3b3', '1', '3', '0', '1', '3', 'b3', 1),
    ]
    for ver, args in zip(data, _VersionInfo(*data)._asdict().values()):
        assert ver == args



# Generated at 2022-06-23 18:20:14.394222
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert(ver_info.major.txt == '1')
    assert(ver_info.minor.txt == '2')
    assert(ver_info.patch.txt == '3')
    assert(ver_info.pre_pos == -1)

    ver_info = _build_version_info('1.2')
    assert(ver_info.major.txt == '1')
    assert(ver_info.minor.txt == '2')
    assert(ver_info.patch.txt == '')
    assert(ver_info.pre_pos == -1)

    ver_info = _build_version_info('1')
    assert(ver_info.major.txt == '1')

# Generated at 2022-06-23 18:20:27.788946
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:20:29.845396
# Unit test for function bump_version
def test_bump_version():
    pass


# Generated at 2022-06-23 18:20:38.979365
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import bump_version
    from io import StringIO
    from json import dump, load
    from unittest import TestCase


# Generated at 2022-06-23 18:20:51.773493
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for part in _each_version_part(StrictVersion('1.3')):
        assert part == _VersionPart(
            pos=1,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='minor'
        )
        break
    for part in _each_version_part(StrictVersion('1.2.0')):
        assert part == _VersionPart(
            pos=2,
            txt='',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch'
        )
        break

# Generated at 2022-06-23 18:20:58.514829
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # noqa: D103
    """Unit test for constructor of class _VersionPart"""
    part = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:21:03.616915
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert isinstance(_VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart)



# Generated at 2022-06-23 18:21:13.651090
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    expected = _VersionInfo('1.2.3',
                            _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3', 3, '', -1, 'patch'),
                            -1)
    actual = _build_version_info('1.2.3')
    assert expected == actual

    expected = _VersionInfo('1.2.3a4',
                            _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, 'a4', 4, 'minor'),
                            _VersionPart(2, '3', 3, 'a4', 4, 'patch'),
                            1)

# Generated at 2022-06-23 18:21:24.132373
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    from flutils.packages import bump_version
    from flutils.testingutils import FlUtilsUnitTestCase

    class _TestBumpVersion(FlUtilsUnitTestCase):
        def test_bump_version_00(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')

        def test_bump_version_01(self):
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')

        def test_bump_version_02(self):
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')


# Generated at 2022-06-23 18:21:30.484021
# Unit test for function bump_version
def test_bump_version():
    """Runs the test for this module."""
    import sys
    import unittest

    sys.modules['__main__'].__file__ = 'tests/test_packages.py'

    class TestBumpVersion(unittest.TestCase):
        """The test class for this module."""

        def test_bump_version(self):
            """The test_bump_version() test method."""
            arg_obj = {
                'version': '1.2.2',
                'position': 2,
                'pre_release': None,
            }
            self.assertEqual(
                bump_version(**arg_obj), '1.2.3'
            )


# Generated at 2022-06-23 18:21:32.462792
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pass


# Generated at 2022-06-23 18:21:39.173984
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version_part = _VersionPart(
        pos=0, txt='2', num=2, pre_txt='', pre_num=-1, name='major'
    )
    assert version_part.pos == 0
    assert version_part.txt == '2'
    assert version_part.num == 2
    assert version_part.pre_txt == ''
    assert version_part.pre_num == -1
    assert version_part.name == 'major'



# Generated at 2022-06-23 18:21:48.996344
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2a0'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 0
    assert ver_

# Generated at 2022-06-23 18:21:57.148283
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert str(_build_version_info('1.2.3')) == (
        "_VersionInfo(version='1.2.3', major=_VersionPart(pos=0, txt='1', num="
        "1, pre_txt='', pre_num=-1, name='major'), minor=_VersionPart(pos=1, "
        "txt='2', num=2, pre_txt='', pre_num=-1, name='minor'), "
        "patch=_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, "
        "name='patch'), pre_pos=-1)"
    )

# Generated at 2022-06-23 18:22:10.868833
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('0.0.0')
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.name == 'minor'

    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == ''
    assert ver_info.patch.num == 0
    assert ver_info.patch.name == 'patch'

    assert ver_info.pre_pos == -1

    ver_info = _build_

# Generated at 2022-06-23 18:22:14.061510
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    __ver_info = _build_version_info('1.2.3')
    assert isinstance(__ver_info, _VersionInfo)


# Generated at 2022-06-23 18:22:25.408598
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    try:
        bump_version('1.2.2')
    except ValueError:
        assert False, "bump_version('1.2.2') raised ValueError unexpectedly!"

    try:
        bump_version('1.2.3', position=1)
    except ValueError:
        assert False, "bump_version('1.2.3', position=1) raised ValueError unexpectedly!"

    try:
        bump_version('1.3.4', position=0)
    except ValueError:
        assert False, "bump_version('1.3.4', position=0) raised ValueError unexpectedly!"


# Generated at 2022-06-23 18:22:35.411829
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:22:46.077996
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0622
    import unittest
    from .testutils import FunctionTestCase


# Generated at 2022-06-23 18:22:52.982920
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0')
    assert len(ver_info) == 6
    assert isinstance(ver_info.version, str)
    assert isinstance(ver_info.major, _VersionPart)
    assert isinstance(ver_info.minor, _VersionPart)
    assert isinstance(ver_info.patch, _VersionPart)
    assert isinstance(ver_info.pre_pos, int)

    ver_info = _build_version_info('0.2.4a2')
    assert len(ver_info) == 6
    assert isinstance(ver_info.version, str)
    assert isinstance(ver_info.major, _VersionPart)
    assert isinstance(ver_info.minor, _VersionPart)

# Generated at 2022-06-23 18:23:02.613894
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3a0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart), \
            "A _VersionPart was not returned from _each_version_part()."
        assert part.pos in (0, 1, 2), \
            "position of part %r returned from _each_version_part() " \
            "is not one of (0, 1, 2)." % part.pos
        assert isinstance(part.txt, str), \
            "The 'txt' part of part %r returned from _each_version_part() " \
            "is not a 'str'." % part.pos

# Generated at 2022-06-23 18:23:13.394588
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    :rtype:
        :obj:`None`

    """
    import sys

    import pytest

    #: (:obj:`tuple`): Tuple of test versions.
    versions = (
        '0.0.1',
        '0.0.2',
        '1.2.0',
        '1.2.3',
        '1.3.0',
        '1.3.4',
        '1.3.4a0',
        '1.3.4a1',
        '1.3.4b0',
        '1.3.4b2',
        '2.0.0',
    )

    #: (:obj:`tuple`): Tuple of test versions.
    versions_pre = versions[:-1]

# Generated at 2022-06-23 18:23:20.031930
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info
    info = _build_version_info('1.2.2')
    assert info.version == '1.2.2'
    assert info.major.num == 1
    assert info.minor.num == 2
    assert info.patch.num == 2
    assert info.pre_pos == -1


# Generated at 2022-06-23 18:23:28.282742
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:23:40.945159
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3',\
        "Failed to increment a patch-level version number correctly."
    assert bump_version('1.2.3', position=1) == '1.3',\
        "Failed to increment a minor-level version number correctly."
    assert bump_version('1.3.4', position=0) == '2.0',\
        "Failed to increment a major-level version number correctly."
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0',\
        "Failed to increment a pre-release version number correctly."

# Generated at 2022-06-23 18:23:51.477872
# Unit test for function bump_version
def test_bump_version():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == '3'

    ver_info = _build_version_info('1.2')
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == '2'
    assert ver_info.patch.txt == ''

    ver_info = _build_version_info('1')
    assert ver_info.major.txt == '1'
    assert ver_info.minor.txt == ''
    assert ver_info.patch.txt == ''

    ver_info = _build_version_info('1.2.0')

# Generated at 2022-06-23 18:24:02.307318
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103,R0914,R0912,R0915

    def _check(
            version: str,
            position: int = 2,
            pre_release: Union[str, None] = None,
            expected: str = None,
    ) -> None:
        if position < 0:
            raise ValueError(
                "The given value for 'position', %r, must be an 'int' "
                "greater than or equal to zero." % position
            )
        if expected is None:
            raise ValueError(
                "The 'expected' value must be given."
            )

# Generated at 2022-06-23 18:24:13.491560
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:24:22.805000
# Unit test for function bump_version
def test_bump_version():
    """ Test the version number bumping function.
    """
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-23 18:24:30.188440
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    expected = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    actual = _build_version_info('1.2.3')
    assert expected == actual


# Generated at 2022-06-23 18:24:41.543163
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:24:50.038013
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=C0103
    from unittest import TestCase

    class Test__VersionPart(TestCase):
        """Unit test class for '_VersionPart'"""
        def test__expected_attrs(self):
            # pylint: disable=C0103,C0111
            kwargs = {
                'pos': 3,
                'txt': '12',
                'num': 12,
                'pre_txt': 'a',
                'pre_num': 0,
                'name': 'patch'
            }
            # noinspection PyUnresolvedReferences
            from flutils.packages import _VersionPart
            ver_part = _VersionPart(**kwargs)
            for attr, val in kwargs.items():
                act_val = getattr(ver_part, attr)
               

# Generated at 2022-06-23 18:25:01.868951
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:25:11.252546
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the :func:`~flutils.packages.bump_version` function.
    """
    import unittest
    # noinspection PyUnresolvedReferences
    from flutils.packages import bump_version as func
    from flutils.packages import __version__

    class BumpVersionFuncTestCase(unittest.TestCase):
        """Unit test for the :func:`~flutils.packages.bump_version`
        function.
        """

        def test_func(self):
            """Test the :func:`~flutils.packages.bump_version` function.
            """
            # Test with valid values
            val = '1.0.1'
            pos = 2
            pre = 'a'
            exp = '1.0.2a0'

# Generated at 2022-06-23 18:25:23.069623
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion
    import pytest
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.2.3a0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.2.3b0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
    ver_obj = StrictVersion('1.2.3b1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
   

# Generated at 2022-06-23 18:25:29.294267
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class `_VersionInfo`."""
    version = '1.2.3a0'

# Generated at 2022-06-23 18:25:39.137636
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the constructor of the _VersionPart."""
    args = {
        'pos': 0,
        'txt': '2',
        'num': 2,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    obj = _VersionPart(**args)
    assert obj.pos == args['pos']
    assert obj.txt == args['txt']
    assert obj.num == args['num']
    assert obj.pre_txt == args['pre_txt']
    assert obj.pre_num == args['pre_num']
    assert obj.name == args['name']


# Generated at 2022-06-23 18:25:46.024336
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0')
    assert ver_info.version == '1.0.0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:25:57.709204
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:26:03.660657
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    p = _VersionPart(pos=0, txt='2', num=2, pre_txt='a', pre_num=1, name='major')
    assert p.pos == 0
    assert p.txt == '2'
    assert p.num == 2
    assert p.pre_txt == 'a'
    assert p.pre_num == 1
    assert p.name == 'major'



# Generated at 2022-06-23 18:26:13.526389
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version


# Generated at 2022-06-23 18:26:25.371399
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test for constructor of class _VersionInfo"""
    from flutils.packages import _VersionInfo
    from flutils.objutils import class_pretty_name
    version = '6.7.8b2'
    ver_info = _VersionInfo(
        version=version,
        major=(6, '6', 6, '', -1, 'major'),
        minor=(7, '7', 7, 'b', 2, 'minor'),
        patch=(8, '8', 8, '', -1, 'patch'),
        pre_pos=1,
    )
    obj_class = '%s.%s' % (
        __name__,
        '_VersionInfo'
    )
    obj_name = class_pretty_name(obj_class)

# Generated at 2022-06-23 18:26:34.554540
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the bump_version function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'