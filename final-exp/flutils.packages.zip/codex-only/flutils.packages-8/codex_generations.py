

# Generated at 2022-06-23 18:16:33.397766
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor').pos == 1


# Generated at 2022-06-23 18:16:44.362004
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-23 18:16:54.037479
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:01.772180
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the _VersionInfo class constructor."""
    _build_version_info('1.2.3')
    _build_version_info('1.2.3a0')
    _build_version_info('1.2.3b0')
    _build_version_info('1.2.3a1')
    _build_version_info('1.2.3b1')



# Generated at 2022-06-23 18:17:05.834851
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '1', 1, '', -1, 'minor') == _VersionPart(
        pos=1,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='minor'
    )



# Generated at 2022-06-23 18:17:17.711277
# Unit test for function bump_version
def test_bump_version():
    """
    Test the function ``bump_version``.
    """
    # pylint: disable=C0103
    #
    # Main tests
    #
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
   

# Generated at 2022-06-23 18:17:25.653849
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:38.278876
# Unit test for function bump_version
def test_bump_version():  # noqa
    """Function for testing the bump_version() function."""
    from flutils.packages import bump_version
    print(bump_version('1.2.2'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.3.4', position=-3))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))

# Generated at 2022-06-23 18:17:47.053890
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from flutils.packages import _each_version_part

    version = '2.1.4'
    for version_part in _each_version_part(StrictVersion(version)):
        assert isinstance(version_part, _VersionPart)
        assert isinstance(version_part.pos, int)
        assert isinstance(version_part.txt, str)
        assert isinstance(version_part.num, int)
        assert isinstance(version_part.pre_txt, str)
        assert isinstance(version_part.pre_num, int)
        assert isinstance(version_part.name, str)
        if version_part.pos == 0:
            assert version_part.num == 2
            assert version_part.txt == '2'
            assert version_part.name

# Generated at 2022-06-23 18:18:00.105585
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    # Setup
    # Tested with v0.0.2, v0.0.3, v0.1.0, v0.1.1, v0.1.2, v0.1.3, v0.1.4,
    # v0.1.5, v0.2.0, v0.2.1, v0.2.2, v0.2.3, v0.2.4, v0.2.5, v0.2.6, v0.2.7,
    # v0.2.8, v0.2.9, v0.2.10, v0.2.11, v0.2.12, v0.2.13, v0.2.14, v0.2.15,
    # v

# Generated at 2022-06-23 18:18:12.685070
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    cases = [
        '0.0',
        '0.1',
        '0.1.1',
        '0.1.1a0',
        '0.1.1a1',
        '0.1.1b0',
        '0.1.1b1',
        '1.0',
        '1.0.0',
        '1.0.1',
        '1.0.1a0',
        '1.0.1a1',
        '1.0.1b0',
        '1.0.1b1',
    ]
    for item in cases:
        ver_info = _build_version_info(item)
        assert ver_info.version == item
        assert ver_info.major.pos == 0

# Generated at 2022-06-23 18:18:20.028583
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart

    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                        name='major') == _VersionPart(0, '1', 1, '', -1, 'major')
    assert _VersionPart(pos=1, txt='3', num=3, pre_txt='', pre_num=-1,
                        name='minor') == _VersionPart(1, '3', 3, '', -1, 'minor')
    assert _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1,
                        name='patch') == _VersionPart(2, '', 0, '', -1, 'patch')

# Generated at 2022-06-23 18:18:31.084059
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=I0011,C0103
    from distutils.version import StrictVersion as _StrictVersion

    # Tests for project release version
    v1 = "'1.2.3'"
    v2 = "'1.2.3a4'"
    v3 = "'1.2.3b1'"
    v4 = "'1.2.3a4.b5'"

    # Tests for pre-release version
    v5 = "'1.2a3.4'"
    v6 = "'1.2a3.4b1'"
    v7 = "'1.2.3b1.4a5'"
    v8 = "'1.2.3b1.4a5.6.7b2'"


# Generated at 2022-06-23 18:18:43.157493
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major')._asdict() == \
        {'pos': 0, 'txt': '1', 'num': 1, 'pre_txt': '', 'pre_num': -1,
         'name': 'major'}
    assert _VersionPart(1, '2', 2, '', -1, 'minor')._asdict() == \
        {'pos': 1, 'txt': '2', 'num': 2, 'pre_txt': '', 'pre_num': -1,
         'name': 'minor'}

# Generated at 2022-06-23 18:18:52.894903
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3b0'
    info = _build_version_info(version)
    assert info.version == version
    assert info.major.pos == 0
    assert info.major.num == 1
    assert info.major.txt == '1'
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.minor.pos == 1
    assert info.minor.num == 2
    assert info.minor.txt == '2b0'
    assert info.minor.pre_txt == 'b'
    assert info.minor.pre_num == 0
    assert info.patch.pos == 2
    assert info.patch.num == 3
    assert info.patch.txt == ''
    assert info.patch.pre_txt == ''
   

# Generated at 2022-06-23 18:19:04.505312
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test ``_VersionInfo``.

    *New in version 0.3*

    """
    # pylint: disable=missing-function-docstring
    info = _build_version_info('2.3.4')
    assert info.version == '2.3.4'
    assert info.major.name == 'major'
    assert info.major.num == 2
    assert info.major.txt == '2'
    assert info.minor.name == 'minor'
    assert info.minor.num == 3
    assert info.minor.txt == '3'
    assert info.patch.name == 'patch'
    assert info.patch.num == 4
    assert info.patch.txt == '4'

    info = _build_version_info('2.3.4a1')
    assert info.version

# Generated at 2022-06-23 18:19:10.169247
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # noinspection PyUnresolvedReferences
    from flutils.packages._tests import test_bump_version
    test_bump_version.test_bump_version()

# Make sure functions go through the 'ansicolor' processor.
from flutils.tty import ansicolor  # pylint: disable=wrong-import-position
ansicolor.init()  # pylint: disable=undefined-variable

# Generated at 2022-06-23 18:19:16.065301
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from .test_common import assert_sorted_equal

    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected_output: str
    ) -> None:
        output = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert output == expected_output, (
            "Output not as expected.\n"
            "Version: {!r}\n"
            "Position: {!r}\n"
            "Pre-release: {!r}\n"
            "Output: {!r}\n"
            "Expected: {!r}".format(
                version, position, pre_release, output, expected_output
            )
        )



# Generated at 2022-06-23 18:19:22.114452
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = ['pos', 'txt', 'num', 'pre_txt', 'pre_num', 'name']
    assert list(_VersionPart(**{k: '' for k in args})._fields) == args
    assert _VersionPart(
        *[i for i in range(len(_VersionPart._fields))]
    )
    assert _VersionPart(
        *[i for i in range(len(_VersionPart._fields) - 1)]
    )



# Generated at 2022-06-23 18:19:31.331624
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('0.0.1', _VersionPart(0, '0', 0, '', -1, 'major'),
                        _VersionPart(1, '0', 0, '', -1, 'minor'),
                        _VersionPart(2, '1', 1, '', -1, 'patch'), -1)
    assert info.version == '0.0.1'
    assert info.major == _VersionPart(0, '0', 0, '', -1, 'major')
    assert info.minor == _VersionPart(1, '0', 0, '', -1, 'minor')
    assert info.patch == _VersionPart(2, '1', 1, '', -1, 'patch')
    assert info.pre_pos == -1


# Generated at 2022-06-23 18:19:41.715886
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from hypothesis import given
    from hypothesis.strategies import from_regex, integers

    @given(from_regex('((\d\.){0,4}(\d))', fullmatch=True),
           integers(min_value=-3, max_value=2))
    # pylint: disable=unused-argument
    def test_it(ver_str, position):
        _build_version_info(ver_str)
        bump_version(ver_str, position=position)
        bump_version(ver_str, position=position, pre_release='a')
        bump_version(ver_str, position=position, pre_release='alpha')
        bump_version(ver_str, position=position, pre_release='b')
        bump_version(ver_str, position=position, pre_release='beta')



# Generated at 2022-06-23 18:19:49.628558
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    import pytest
    arg = '1.2.3'
    ver_info = _build_version_info(arg)
    assert ver_info.version == arg
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    arg = '1.2.3-beta.1'
    ver_info = _build_version_info(arg)
    assert ver_info.version == arg
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == 1

    arg = '1.2.3a7'
    ver_info = _

# Generated at 2022-06-23 18:19:57.191833
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    pos = 2
    prerelease = 'alpha'
    pre_pos = -1
    args = [version, ('1', '1', 1, '', -1, 'major'), ('2', '2', 2, '', -1, 'minor'), ('3', '3', 3, '', -1, 'patch'), pre_pos]
    assert _build_version_info(version) == _VersionInfo(*args)
    # Test all positions
    for i in range(-3, 3):
        position = _build_version_bump_position(i)
        assert position == i + 3

# Generated at 2022-06-23 18:20:06.991406
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import pytest
    t = _VersionPart(0, '1', 1, '', -1, 'major')
    assert t.pos == 0
    assert t.txt == '1'
    assert t.num == 1
    assert t.pre_txt == ''
    assert t.pre_num == -1
    assert t.name == 'major'

    with pytest.raises(ValueError):
        _VersionPart(0, '1', '2', '', -1, 'major')

    with pytest.raises(ValueError):
        _VersionPart(0, '1', 1, '', -1, 1)



# Generated at 2022-06-23 18:20:15.462449
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212,E0602
    assert _VersionPart._fields == ('pos', 'txt', 'num', 'pre_txt', 'pre_num', 'name')
    ver_obj = StrictVersion('1.0.0')
    part = _each_version_part(ver_obj).__next__()
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = _each_version_part(ver_obj).__next__()
    assert part.pos == 1
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre

# Generated at 2022-06-23 18:20:23.883433
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = (0, '2', 3, 'a', 4, 'major')
    vp = _VersionPart(*args)
    assert vp.pos == args[0]
    assert vp.txt == args[1]
    assert vp.num == args[2]
    assert vp.pre_txt == args[3]
    assert vp.pre_num == args[4]
    assert vp.name == args[5]


# Generated at 2022-06-23 18:20:35.533536
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test 1, Major and Minor with no pre-release
    pre = None
    pos = 1
    bump_type = _build_version_bump_type(pos, pre)
    version = '5.5.5'
    ver_info = _build_version_info(version)
    assert bump_type == _BUMP_VERSION_MINOR
    assert ver_info.version == version
    assert ver_info.major.num == 5
    assert ver_info.minor.num == 5
    assert ver_info.patch.num == 5
    assert ver_info.pre_pos == -1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre

# Generated at 2022-06-23 18:20:47.423525
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import os
    import sys
    import unittest
    import unittest.mock as mock  # type: ignore

    class VersionBumpTestCase(unittest.TestCase):
        """Class for testing version bumping."""

        def test_version_bump_patch(self):
            """Test bumping the patch number."""
            val = bump_version('1.0.0')
            self.assertEqual(val, '1.0.1')

# Generated at 2022-06-23 18:20:57.724193
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    # noinspection PyUnusedLocal
    f_name = '%s.%s' % (__name__, test_bump_version.__name__)

    def assert_bumps(version: str, bumped: str, *args, **kwargs):
        """Assert that the given ``version`` bumps to the given ``bumped``
        value.

        """
        def caller(v, b, *a, **kw):
            return bump_version(v, *a, **kw)

        # noinspection PyTypeChecker
        assert caller(version, bumped, *args, **kwargs) == bumped

    assert_bumps('1.2.4b0', '1.2.4')

# Generated at 2022-06-23 18:21:04.244190
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:21:14.268849
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.3a0')
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.patch.pre_txt == 'a'
    assert ver_info.patch.pre_num == 0
    assert ver_info.pre_

# Generated at 2022-06-23 18:21:24.602166
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from tests.testutils import assert_instance

    expected = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major',
    )
    assert_instance(expected, _BUMP_VERSION_MAJOR, _VersionPart)

    expected = _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor',
    )
    assert_instance(expected, _BUMP_VERSION_MINOR, _VersionPart)


# Generated at 2022-06-23 18:21:37.893332
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version function."""
    import sys

    # pylint: disable=W0612
    # noinspection PyUnresolvedReferences
    import flstructs
    # pylint: enable=W0612

    # pylint: disable=W0611,C0415
    # noinspection PyUnresolvedReferences,PyUnboundLocalVariable
    from flutils.tests._testing import flutils_testing_object
    # pylint: enable=W0611,C0415

    from flutils.packages import bump_version


# Generated at 2022-06-23 18:21:48.164478
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.general import ObjectWithType

    class TestClass(ObjectWithType):
        def __init__(self):
            self._version = '0.0.0'
            ObjectWithType.__init__(self)

        def __repr__(self):
            return 'TestClass(version=%r)' % self._version

        def _get_version(self) -> str:
            return self._version

        def _set_version(self, value: str):
            self._version = value

        version = property(_get_version, _set_version)
    test_object = TestClass()
    assert test_object._version == '0.0.0'
    assert test_object.version == '0.0.0'
    # Make sure a TypeError is thrown if trying to set the version to an
    # invalid value

# Generated at 2022-06-23 18:21:57.594154
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1
    ver_info = _build_version_info('1.2.3a1')
    assert ver_info.version == '1.2.3a1'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == 2
    ver_info = _build_version_info('1.2.3b1')
    assert ver_info

# Generated at 2022-06-23 18:22:07.673886
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '2', 2, '', -1, 'minor')
    patch = _VersionPart(2, '3', 3, '', -1, 'patch')
    pre_pos = -1
    expected = _VersionInfo(version, major, minor, patch, pre_pos)
    return _build_version_info(version) == expected


# Generated at 2022-06-23 18:22:17.273894
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from typing import Generator
    from types import GeneratorType
    from distutils.version import StrictVersion
    # pylint: disable=E1101
    assert isinstance(
        _each_version_part(StrictVersion('1.2.3')),
        GeneratorType)
    assert isinstance(
        _each_version_part(StrictVersion('1.2.3')),
        Generator[_VersionPart, None, None]
    )

# Generated at 2022-06-23 18:22:26.445356
# Unit test for function bump_version
def test_bump_version():
    """Test function: bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:22:35.767891
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    data = '1.2.3'
    expected = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major',
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor',
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch',
        ),
        pre_pos=-1,
    )
    actual = _build

# Generated at 2022-06-23 18:22:46.311676
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():     # pylint: disable=W0612,R0914
    """Test constructor of class _VersionInfo."""
    version: str
    info: _VersionInfo
    version = '2.3.1'
    info = _build_version_info(version)
    assert info.version == version
    assert info.major.num == 2
    assert info.major.pos == 0
    assert info.minor.num == 3
    assert info.minor.pos == 1
    assert info.patch.num == 1
    assert info.patch.pos == 2
    assert info.pre_pos == -1
    version = '2.3.1b2'
    info = _build_version_info(version)
    assert info.version == version
    assert info.major.num == 2
    assert info.major.pos == 0
   

# Generated at 2022-06-23 18:22:53.130325
# Unit test for constructor of class _VersionInfo
def test__VersionInfo(): # pylint: disable=R0915
    """Test the constructor of class ``_VersionInfo``.
    """
    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    major = ver_info.major
    assert major.pos == 0
    assert major.num == 1
    assert major.txt == '1'
    assert major.pre_num == -1
    assert major.pre_txt == ''
    assert major.name == 'major'
    minor = ver_info.minor
    assert minor.pos == 1
    assert minor.num == 2
    assert minor.txt == '2'
    assert minor.pre_num == -1
    assert minor.pre_txt == ''
    assert minor.name == 'minor'
    patch

# Generated at 2022-06-23 18:22:59.137461
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(pos = 1, txt = '2', num = 2, pre_txt = 'a', pre_num = 2, name = 'minor')
    assert vp[0] == 1
    assert vp[1] == '2'
    assert vp[2] == 2
    assert vp[3] == 'a'
    assert vp[4] == 2
    assert vp[5] == 'minor'



# Generated at 2022-06-23 18:23:05.824731
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from .test_packages import _MockVersion

# Generated at 2022-06-23 18:23:13.119895
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    _VersionPart(0, '', 0, '', -1, 'major')
    _VersionPart(1, '5', 5, '', -1, 'minor')
    _VersionPart(2, 'b0', 0, 'b', 0, 'patch')
    _VersionPart(1, '5a0', 5, 'a', 0, 'minor')
    _VersionPart(1, '5b1', 5, 'b', 1, 'minor')
    _VersionPart(2, '7', 7, '', -1, 'patch')



# Generated at 2022-06-23 18:23:19.585619
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from datetime import datetime
    from flutils.packages import _VersionInfo, _build_version_info
    from flutils.testing import UnitTester
    tst = UnitTester(
        _build_version_info,
        _VersionInfo('1.2.3', '1', '2', '3', -1),
        ['1.2.3']
    )
    tst.run_tests()



# Generated at 2022-06-23 18:23:29.475853
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3.4'
    ver_obj = StrictVersion(version)
    parts = list(_each_version_part(ver_obj))
    assert parts[0].pos == 0
    assert parts[0].txt == '1'
    assert parts[0].num == 1
    assert parts[0].name == 'major'
    assert parts[0].pre_txt == ''
    assert parts[0].pre_num == -1

    assert parts[1].pos == 1
    assert parts[1].txt == '2'
    assert parts[1].num == 2
    assert parts[1].name == 'minor'
    assert parts[1].pre_txt == ''
    assert parts[1].pre_num == -1

    assert parts[2].pos == 2

# Generated at 2022-06-23 18:23:41.790112
# Unit test for function bump_version
def test_bump_version():
    """Test ``bump_version`` with a unit test.

    New in version 0.3.5

    Returns:
        int: The total number of unit test function failures.

    """
    import unittest
    import unittest.mock

    from flutils.packages import bump_version

    class TestBumpVersion(unittest.TestCase):
        """Unit test for function ``bump_version``."""

        def test_version(self):
            """Test version verification."""
            unittest.TestCase.assertRaises(  # type: ignore
                self,
                ValueError,
                bump_version,
                'hello world',
            )

        def test_position_too_small(self):
            """Test position is too small."""

# Generated at 2022-06-23 18:23:53.005913
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0111,C0301,C0330
    # pylint: disable=R0201,R0904,W0612
    def do_test_bump_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        out = bump_version(version, position, pre_release)
        if out != expected:
            raise RuntimeError(
                '%r != %r for (v:%r, pos:%r, pr:%r)' % (
                    out, expected, version, position, pre_release
                )
            )

    do_test_bump_version('1.2.2', position=0, pre_release=None, expected='2.0')
    do_test_b

# Generated at 2022-06-23 18:23:55.763955
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # noqa
    _VersionInfo('1.2.3', '1', '2.3', '3', -1)



# Generated at 2022-06-23 18:24:06.747463
# Unit test for function bump_version
def test_bump_version():
    from itertools import product
    from random import randint
    from sys import exit

    # Setup some test version numbers

# Generated at 2022-06-23 18:24:17.496451
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.version == '1.2.3'
    assert ver_obj.major.num == 1
    assert ver_obj.major.pos == 0
    assert ver_obj.minor.num == 2
    assert ver_obj.minor.pos == 1
    assert ver_obj.patch.num == 3
    assert ver_obj.patch.pos == 2
    assert ver_obj.pre_pos == -1
    ver_obj = _build_version_info('1.2a0')
    assert ver_obj.version == '1.2a0'
    assert ver_obj.major.num == 1
    assert ver_obj.major.pos == 0
    assert ver_obj.minor.num == 2
    assert ver_obj

# Generated at 2022-06-23 18:24:27.674489
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    .. Note::
        The ``bump_version`` function is tested on Python 3.x only.

    """
    # noinspection PyUnresolvedReferences
    import unittest  # pylint: disable=E0611,E0401
    import sys

    if sys.version_info >= (3, 6):
        # noinspection SpellCheckingInspection
        ver = '1.2.3'
        # noinspection SpellCheckingInspection
        klass = bump_version(ver)
        # noinspection SpellCheckingInspection
        assert klass == '1.2.4'

        # noinspection SpellCheckingInspection
        klass = bump_version(ver, position=1)
        # noinspection SpellCheckingInspection

# Generated at 2022-06-23 18:24:34.673402
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=maybe-no-member
    ver_info: _VersionInfo = _build_version_info('1.2.3a4')
    assert ver_info.version == '1.2.3a4'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2a4'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'a'
   

# Generated at 2022-06-23 18:24:45.989577
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('0.0.0', position=1) == '0.1'
    assert bump_version('0.0.0', position=0) == '1.0'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('2.0.0') == '2.0.1'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('0.0.0', position=-1) == '0.0.1'
    assert bump_version('0.0.0', position=-2) == '0.1'


# Generated at 2022-06-23 18:24:54.271364
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    import pytest
    from random import choice

    @pytest.fixture(scope='function')
    def version() -> str:
        """
        Generate a valid version number.
        """
        args: List[Union[int, str]] = []
        for pos in range(3):
            num = choice(range(10))
            if pos == 2 and num == 0:
                num = ''
            args.append(num)
        return '.'.join(map(str, args))

    @pytest.fixture(scope='function')
    def ver_info(version: str) -> _VersionInfo:
        """
        Generate a VersionInfo instance from a version number.
        """
        return _build_version_info(version)


# Generated at 2022-06-23 18:25:03.532057
# Unit test for function bump_version
def test_bump_version():
    """Tests for the ``bump_version`` function."""
    from flutils.packages import bump_version

    # Callable Tests
    try:
        bump_version('1.2.3')
    except TypeError:
        raise AssertionError("The 'bump_version' function did not accept the "
                             "required 'version' positional argument.")

    # Position Tests
    try:
        bump_version('1.2.3', -4)
    except ValueError:
        pass
    except BaseException as e:
        raise AssertionError(
            "The 'bump_version' raised an unexpected error while setting "
            "'position' to an 'int' less than -3.\n%r" % e
        )

# Generated at 2022-06-23 18:25:06.744276
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)


# Generated at 2022-06-23 18:25:18.689626
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3dev') == _VersionInfo(
        '1.2.3dev',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, 'dev', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        2
    )

# Generated at 2022-06-23 18:25:29.602375
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def _build_ver_info(
            ver: str,
            major: _VersionPart,
            minor: _VersionPart,
            patch: _VersionPart,
            pre_pos: int
    ) -> None:
        info = _build_version_info(ver)
        # noinspection DuplicatedCode
        assert info.version == ver
        assert info.major == major
        assert info.minor == minor
        assert info.patch == patch
        assert info.pre_pos == pre_pos


# Generated at 2022-06-23 18:25:40.983607
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    from flutils.packages import _build_version_info, _VersionInfo

# Generated at 2022-06-23 18:25:48.988429
# Unit test for function bump_version
def test_bump_version():
    """Test function: flutils.packages.bump_version()"""
    errors = 0

# Generated at 2022-06-23 18:26:00.632786
# Unit test for function bump_version
def test_bump_version():
    """Test for :func:`flutils.packages.bump_version`."""
    # Test for errors.
    for args in (
            ('1.2.3', 0, 'bad'),
            ('1.2.3', 2, 'a'),
            ('1.2.3', 2, 'alpha'),
            ('1.2.3', 2, 'b'),
            ('1.2.3', 2, 'beta'),
            ('1.2.3', 2, None),
            ('1.2.3', 0),
    ):
        with pytest.raises(ValueError):
            bump_version(*args)
    # Test for success.
    assert bump_version('1.2.2') == '1.2.3'

# Generated at 2022-06-23 18:26:10.497868
# Unit test for function bump_version
def test_bump_version():
    """Test flutils.packages.bump_version()"""
    from flutils.packages import bump_version

    func = bump_version

# Generated at 2022-06-23 18:26:22.710914
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:26:30.108258
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        part = _VersionPart(1, '1', 1, 'a', 0, 'major')
        if tuple(part) != (1, '1', 1, 'a', 0, 'major'):
            raise AssertionError(
                "The constructor for '_VersionPart' did not build the output "
                "as expected."
            )
    except Exception:
        raise AssertionError(
            "The constructor for '_VersionPart' did not build the output "
            "as expected."
        )


# Generated at 2022-06-23 18:26:37.348718
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3a0')
    _build_version_info('1.2.3a10')
    _build_version_info('1.2.3b0')
    _build_version_info('1.2.3b10')
    with pytest.raises(ValueError):
        _build_version_info('1.2.3abc')
    with pytest.raises(ValueError):
        _build_version_info('1.2.3a')
    with pytest.raises(ValueError):
        _build_version_info('1.2')
    with pytest.raises(ValueError):
        _build_version_info('a.2.3')