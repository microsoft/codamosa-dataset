

# Generated at 2022-06-23 18:16:39.077496
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        0, '2', 2, '', -1, 'major'
    ) == _VersionPart(
        pos=0,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='major'
    )



# Generated at 2022-06-23 18:16:46.984003
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    pre_pos = -1
    args: List[Any] = [version]
    for part in _each_version_part(StrictVersion(version)):
        if part.pre_txt:
            pre_pos = part.pos
        args.append(part)
    args.append(pre_pos)
    _VersionInfo(*args)

# Generated at 2022-06-23 18:16:55.463933
# Unit test for function bump_version
def test_bump_version():
    """
    Test function: bump_version

    **Returns**:
        :obj:`None`

    """
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    assert bump_version(ver, position=1) == '1.3'
    assert bump_version(ver, position=0) == '2.0'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'
    assert bump_version(ver, pre_release='b') == '1.2.4b0'
    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'

# Generated at 2022-06-23 18:17:06.821122
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of class _VersionPart.

    *New in version 0.5*

    """
    obj = _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert obj.pos == 0
    assert obj.txt == '0'
    assert obj.num == 0
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'

    obj = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert obj.pos == 0

# Generated at 2022-06-23 18:17:17.759171
# Unit test for function bump_version

# Generated at 2022-06-23 18:17:25.680907
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info(version='0.1.2')
    assert ver_info.version == '0.1.2'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '0'
    assert ver_info.major.num == 0
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '1'
    assert ver_info.minor.num == 1
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:17:30.072972
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('1.2', _VersionPart(0, '1', 1, '', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '', 0, '', -1, 'patch'), -1)



# Generated at 2022-06-23 18:17:36.993244
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'


# Generated at 2022-06-23 18:17:46.280592
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1') == _VersionInfo('1',
                                                    _VersionPart(0, '1', 1, '', -1, 'major'),
                                                    _VersionPart(1, '', 0, '', -1, 'minor'),
                                                    _VersionPart(2, '', 0, '', -1, 'patch'),
                                                    -1), \
        "test__VersionInfo: failed (_build_version_info('1'))"


# Generated at 2022-06-23 18:17:52.022399
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests for the constructor of class :obj:`VersionInfo`."""
    inp = '1.2.3'
    ver_info = _build_version_info(inp)
    assert ver_info.version == inp
    assert (
        ver_info.major.pos,
        ver_info.major.txt,
        ver_info.major.num,
        ver_info.major.pre_txt,
        ver_info.major.pre_num,
        ver_info.major.name
    ) == (0, '1', 1, '', -1, 'major')

# Generated at 2022-06-23 18:17:59.038578
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    func = 'bump_version'

# Generated at 2022-06-23 18:18:12.568979
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info
    # Act
    result = _build_version_info('1.2.3')
    # Assert
    assert str(result) == '_VersionInfo(version=\'1.2.3\', major=_VersionPart(pos=0, txt=\'1\', num=1, pre_txt=\'\', pre_num=-1, name=\'major\'), minor=_VersionPart(pos=1, txt=\'2\', num=2, pre_txt=\'\', pre_num=-1, name=\'minor\'), patch=_VersionPart(pos=2, txt=\'3\', num=3, pre_txt=\'\', pre_num=-1, name=\'patch\'), pre_pos=-1)'

    # Act
    result = _build

# Generated at 2022-06-23 18:18:21.541246
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    def _test_one(version: str, major: int, minor: int, patch: int, pre_pos: int) -> None:
        ver_info = _VersionInfo(
            version, major, minor, patch,
            pre_pos
        )
        assert ver_info.version == version
        assert ver_info.major.num == major
        assert ver_info.minor.num == minor
        assert ver_info.patch.num == patch
        assert ver_info.pre_pos == pre_pos

    _test_one('1.0.0', 1, 0, 0, -1)
    _test_one('1.0.0a0', 1, 0, 0, 1)
    _test_one('2.1.2b1', 2, 1, 2, 2)

# Generated at 2022-06-23 18:18:26.658260
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart('major', '0', 0, '', -1, '0') is not None
    assert _VersionPart('minor', '1', 1, '', -1, '1') is not None
    assert _VersionPart('patch', '2', 2, '', -1, '2') is not None
    assert _VersionPart('minor', '1a0', 1, 'a', 0, '1a0') is not None
    assert _VersionPart('patch', '0a0', 0, 'a', 0, '0a0') is not None
    assert _VersionPart('minor', '1a1', 1, 'a', 1, '1a1') is not None
    assert _VersionPart('patch', '0b1', 0, 'b', 1, '0b1') is not None
    assert _VersionPart

# Generated at 2022-06-23 18:18:34.618201
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnusedLocal
    args = []
    # noinspection PyUnusedLocal
    args.append('1.2.3')
    args.append(_VersionPart(pos=0, txt='1', num=1,
                             pre_txt='', pre_num=-1, name='major'))
    args.append(_VersionPart(pos=1, txt='2', num=2,
                             pre_txt='', pre_num=-1, name='minor'))
    args.append(_VersionPart(pos=2, txt='3', num=3,
                             pre_txt='', pre_num=-1, name='patch'))
    args.append(-1)
    return _VersionInfo(*args)

# Generated at 2022-06-23 18:18:44.971467
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # ANY CHANGE TO THIS TEST SHOULD BE MADE TO THE ASSOCIATED PYTEST TEST
    # (test_packages.py::test_bump_version)
    import flutils
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-23 18:18:53.615478
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the version info constructor."""
    actual = _build_version_info('1.2.3a0')
    actual = actual._asdict()

# Generated at 2022-06-23 18:19:02.925868
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for pos_part in enumerate(_each_version_part(ver_obj)):
        pos_num, part = pos_part
        assert isinstance(part, _VersionPart)
        assert part.pos == pos_num
        assert part.name == _BUMP_VERSION_POSITION_NAMES[pos_num]
        assert part.pre_num == -1
        assert part.pre_txt == ''

    ver_obj = StrictVersion('1.2.3b0')
    for pos_part in enumerate(_each_version_part(ver_obj)):
        pos_num, part = pos_part
        assert isinstance(part, _VersionPart)
        assert part.pos == pos_num
        assert part.name == _BUMP_VERSION_POS

# Generated at 2022-06-23 18:19:12.742584
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:19:23.305785
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:19:28.777574
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.0') == _VersionInfo('1.0',
                                                      _VersionPart(0, '1', 1, '', -1, 'major'),
                                                      _VersionPart(1, '0', 0, '', -1, 'minor'),
                                                      _VersionPart(2, '', 0, '', -1, 'patch'),
                                                      -1)


# Generated at 2022-06-23 18:19:41.591503
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    def _test_version_bump(version, position, pre_release, expected):
        # type: (str, int, str, str) -> None
        assert bump_version(version, position, pre_release) == expected

    _test_version_bump('1.2.2', 2, 'a', '1.2.4a0')
    _test_version_bump('1.2.2', 2, 'alpha', '1.2.4a0')
    _test_version_bump('1.2.3', 2, 'a', '1.2.4a0')
    _test_version_bump('1.2.3', 2, 'alpha', '1.2.4a0')

    # Alpha

# Generated at 2022-06-23 18:19:51.869309
# Unit test for function bump_version
def test_bump_version():
    """Tests for function bump_version"""
    pass


if __name__ == '__main__':
    import os
    import sys
    import unittest


    # Allow imports of the parent directory
    if os.path.isdir('../'):
        sys.path.insert(0, os.path.abspath('../'))


    class TestCases(unittest.TestCase):
        # pylint: disable=R0904,C0115
        """Unit test for function bump_version"""

        def test_str(self):
            """Test for function bump_version with a str as the version"""
            self.assertEqual(
                bump_version('1.2.2'),
                '1.2.3'
            )

# Generated at 2022-06-23 18:20:00.278462
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = '1.2.4a0'.split('.')
    out = _VersionInfo(*args)
    assert out.version == '1.2.4a0'
    assert out.major.pos == 0
    assert out.major.txt == '1'
    assert out.major.num == 1
    assert out.major.pre_txt == ''
    assert out.major.pre_num == -1
    assert out.major.name == 'major'
    assert out.minor.pos == 1
    assert out.minor.txt == '2'
    assert out.minor.num == 2
    assert out.minor.pre_txt == 'a'
    assert out.minor.pre_num == 0
    assert out.minor.name == 'minor'
    assert out.patch.pos == 2


# Generated at 2022-06-23 18:20:10.113173
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=W0613
    """Test method ``_VersionPart``.

    """
    ver_obj = StrictVersion('1.3.0')
    for exp_pos, part in enumerate(_each_version_part(ver_obj)):
        assert exp_pos == part.pos
        if exp_pos == 2:
            assert part.txt == ''
        else:
            assert int(part.txt) == part.num

    ver_obj = StrictVersion('1.3.1a1')
    for exp_pos, part in enumerate(_each_version_part(ver_obj)):
        assert exp_pos == part.pos
        if exp_pos == 2:
            assert part.txt == '1a1'
        else:
            assert int(part.txt) == part.num

# Generated at 2022-06-23 18:20:15.677386
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert repr(
        _VersionPart(1, '', 2, '', -1, 'this is a name')
    ) == "_VersionPart(pos=1, txt='', num=2, pre_txt='', pre_num=-1, " \
          "name='this is a name')"

# Generated at 2022-06-23 18:20:21.303730
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def _test(version: str, expected: _VersionInfo) -> None:
        info = _build_version_info(version)
        # noinspection PyUnresolvedReferences
        assert info == expected
        # expected_repr = "VersionInfo(version={!r}, major={!r}, minor={!r}, " \
        #         "patch={!r}, pre_pos={!r})".format(
        #     expected.version,
        #     expected.major,
        #     expected.minor,
        #     expected.patch,
        #     expected.pre_pos
        # )
        # assert repr(info) == expected_repr


# Generated at 2022-06-23 18:20:33.478395
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    name: str
    obj: _VersionPart
    args: Tuple[Any, ...]
    test_values: List[Tuple[Tuple[Any, ...], Dict[str, Any]]]