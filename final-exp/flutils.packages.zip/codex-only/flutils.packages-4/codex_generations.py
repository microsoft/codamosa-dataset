

# Generated at 2022-06-23 18:16:37.873366
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test with basic version
    assert _build_version_info('1.2') == _VersionInfo(
        version='1.2',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1,
    )

    # Test with prerelease position 1

# Generated at 2022-06-23 18:16:45.320673
# Unit test for function bump_version
def test_bump_version():
    """ Unit-test for function: bump_version """

    def check_bump(version, **kwargs):
        """ Check the bump_version() function """
        expected_version = kwargs.pop('expected_version', None)
        if expected_version is None:
            expected_version = version
        out = bump_version(version, **kwargs)
        assert out == expected_version, (
            f'bump_version({version!r}, {kwargs!r}) == {out!r}, not '
            f'{expected_version!r}'
        )

    # Unit test 1
    check_bump('1.2.2')
    check_bump('1.2.3', position=1)
    check_bump('1.3.4', position=0)

# Generated at 2022-06-23 18:16:49.994341
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for pos in range(3):
        for num in range(10):
            ver_obj = StrictVersion('%s.%s.%s' % (pos, num, num))
            part = next(_each_version_part(ver_obj))
            args = [part.pos, part.txt, part.num, part.pre_txt, part.pre_num]
            assert args == [pos, '%s' % num, num, '', -1], args
        ver_obj = StrictVersion('%s.%s.%s.dev0' % (pos, num, num))
        part = next(_each_version_part(ver_obj))
        args = [
            part.pos, part.txt, part.num, part.pre_txt, part.pre_num, part.name
        ]
        assert args

# Generated at 2022-06-23 18:16:57.201500
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test adding new data to an existing BEGIN SQL block.

    """
    def _test_ver(
            version: str
    ) -> None:
        info = _build_version_info(version)
        assert info.version == version
        parts = list(_each_version_part(StrictVersion(version)))
        assert len(parts) == 3
        assert isinstance(info, _VersionInfo)
        assert info.major == parts[0]
        assert isinstance(info.major, _VersionPart)
        assert info.minor == parts[1]
        assert isinstance(info.minor, _VersionPart)
        assert info.patch == parts[2]
        assert isinstance(info.patch, _VersionPart)

    _test_ver('1.2.3')

# Generated at 2022-06-23 18:17:08.034750
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from flutils.packages import _StrictVersion
    from flutils.packages import _build_version_info

    for ver_info in _build_version_info('1.2.3'):
        if ver_info == '1':
            ver_obj = _StrictVersion('1.%s.%s' % (ver_info[3], ver_info[5]))
        else:
            ver_obj = _StrictVersion(ver_info)
        version = _build_version_info(ver_obj)

        for part in _each_version_part(ver_obj):
            assert part.pos == version[part.pos].pos
            assert part.txt == version[part.pos].txt
            assert part.num == version[part.pos].num
            assert part.pre

# Generated at 2022-06-23 18:17:19.147421
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:23.673877
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major')
    assert part.pos == 0
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:17:35.502867
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # type: (...) -> None
    # pylint: disable=W0612
    """Unit test for: _VersionPart"""
    # pylint: enable=W0612
    ver_obj = StrictVersion('1.2.3')
    versions: List[Tuple[int, int, int]] = [
        (1, 0, 0),
        (1, 2, 0),
        (1, 2, 3),
    ]
    prereleases: List[Union[Tuple[str, int], None]] = [
        None,
        ('a', 0),
        ('b', 0),
        ('a', 1),
        ('b', 1),
    ]

# Generated at 2022-06-23 18:17:40.686338
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the named tuple ``_VersionPart``.

    :rtype:
        :obj:`bool`

    """
    try:
        _VersionPart(0, '1', 1, '', -1, 'major')
    except Exception as e:
        print(e)
        return False
    return True



# Generated at 2022-06-23 18:17:46.746610
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    """Unit test for function bump_version"""

# Generated at 2022-06-23 18:17:54.690483
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # Testing the bump_version function
# pylint: disable=W0612,W0613
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:18:02.264675
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0613
    _VersionInfo('1.2.3', '1', '2', '3', -1)
    _VersionInfo('1.2.3a1', '1', '2a1', '3', 1)
    _VersionInfo('1.2.3b2', '1', '2b2', '3', 1)
    _VersionInfo('1.2.3a0b0', '1', '2a0b0', '3', 1)

# Generated at 2022-06-23 18:18:13.565690
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0-alpha.0')
    assert ver_info.version == '1.0.0-alpha.0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 0

# Generated at 2022-06-23 18:18:20.539542
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # fmt: off
    # pylint: disable=expression-not-assigned
    # pylint: disable=pointless-statement
    v = _build_version_info(version='1.2.3')
    v
    v = _build_version_info(version='1.2a1')
    v
    v = _build_version_info(version='1.2.0a1')
    v
    v = _build_version_info(version='1.2')
    v
    v = _build_version_info(version='1.2.0')
    v
    v = _build_version_info(version='1')
    v
    # fmt: on
    # pylint: enable=expression-not-assigned
    # pylint: enable=pointless-statement

test__

# Generated at 2022-06-23 18:18:31.454055
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    test_data = [
        '1.2.3',
        '1.2.3a0',
        '1.2.3a0',
        '1.2.3b0',
        '1.2.3a2',
        '1.2.3b3',
        '1.2a0.1',
        '1.2b0.1',
        '1.2a2.1',
        '1.2b3.1',
        '1a0.2.3',
        '1b0.2.3',
        '1a2.2.3',
        '1b3.2.3',
    ]
    for test_val in test_data:
        ver_obj = StrictVersion(test_val)

# Generated at 2022-06-23 18:18:41.144483
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': '9',
        'num': 9,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    obj = _VersionPart(**kwargs)
    assert obj.pos == 0
    assert obj.txt == '9'
    assert obj.num == 9
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'



# Generated at 2022-06-23 18:18:50.304704
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '', 0, '', 0, 'minor').pos == 1
    assert _VersionPart(1, '', 0, '', 0, 'minor').txt == ''
    assert _VersionPart(1, '', 0, '', 0, 'minor').num == 0
    assert _VersionPart(1, '', 0, '', 0, 'minor').pre_txt == ''
    assert _VersionPart(1, '', 0, '', 0, 'minor').pre_num == 0
    assert _VersionPart(1, '', 0, '', 0, 'minor').name == 'minor'


# Generated at 2022-06-23 18:18:56.362963
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3b1')
    _build_version_info('1.2.3a7')
    try:
        _build_version_info('1.0.b1')
    except ValueError:
        pass
    try:
        _build_version_info('1.0.a1')
    except ValueError:
        pass
    _build_version_info('1.2.3b1')
    _build_version_info('1.2.3a7')
    try:
        _build_version_info('1.0.a1')
    except ValueError:
        pass
    _build_version_info('1.2.3a1')

# Generated at 2022-06-23 18:19:06.774740
# Unit test for function bump_version
def test_bump_version():
    """
    Unit Tests for function bump_version().

    :returns:
        None

    """
    from nose.tools import (
        assert_equal,
        assert_raises,
    )

    assert_equal(
        bump_version('1.2.2'),
        '1.2.3',
        "bump_version should increase the 'patch' version number."
    )

    assert_equal(
        bump_version('1.2.3', position=1),
        '1.3',
        "bump_version should increase the 'minor' version number."
    )

    assert_equal(
        bump_version('1.3.4', position=0),
        '2.0',
        "bump_version should increase the 'major' version number."
    )


# Generated at 2022-06-23 18:19:18.261460
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=missing-function-docstring
    import pytest
    from flutils import packages

    def run_test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        with pytest.raises(ValueError):
            return packages.bump_version(version, position, pre_release)
        return None

    out = packages.bump_version('1.2.3')
    assert out == '1.2.4'
    out = packages.bump_version('1.2.3', position=1)
    assert out == '1.3'
    out = packages.bump_version('1.3.4', position=0)
    assert out == '2.0'
    out = packages.bump_

# Generated at 2022-06-23 18:19:28.888824
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.1.1')
    assert len(ver_info) == 6
    assert ver_info.version == '1.1.1'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.num == 1
    assert ver_info.patch.pre_txt == ''
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.0.0-alpha.1')
    assert len(ver_info) == 6
    assert ver_info.version == '1.0.0-alpha.1'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.num == 0
    assert ver_info.patch.pre_txt == 'alpha'

# Generated at 2022-06-23 18:19:41.591882
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('0.0.0')
    assert (ver_info.version == '0.0.0')

    ver_info = _build_version_info('0.0.1')
    assert (ver_info.version == '0.0.1')

    ver_info = _build_version_info('0.1.0')
    assert (ver_info.version == '0.1.0')

    ver_info = _build_version_info('2.0.0')
    assert (ver_info.version == '2.0.0')

    ver_info = _build_version_info('1.2.3a4')
    assert (ver_info.version == '1.2.3a4')


# Generated at 2022-06-23 18:19:49.539554
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name

# Generated at 2022-06-23 18:19:58.701154
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0911
    """Test function bump_version."""
    # pylint: disable=C0116,C0115,C0114,C0103
    from flutils.miscutils import get_test_msg
    from flutils.packages import bump_version

    fn = bump_version


# Generated at 2022-06-23 18:20:09.640195
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _each_version_part

    from flutils.packages import _VersionPart

    version = '1.2.3a4'
    for version_part in _each_version_part(StrictVersion(version)):
        assert isinstance(version_part, _VersionPart)
        assert version_part.pos in (0, 1, 2)
        assert isinstance(version_part.txt, str)
        assert isinstance(version_part.num, int)
        assert isinstance(version_part.pre_txt, str)
        assert isinstance(version_part.pre_num, int)
        assert isinstance(version_part.name, str)


# Generated at 2022-06-23 18:20:19.434199
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = (0, '0', 0, '', -1, 'major')
    assert args == _VersionPart(*args)._asdict()

    args = (0, '1', 1, '', -1, 'major')
    assert args == _VersionPart(*args)._asdict()

    args = (0, '1a0', 1, 'a', 0, 'major')
    assert args == _VersionPart(*args)._asdict()

    args = (1, '1', 1, '', -1, 'minor')
    assert args == _VersionPart(*args)._asdict()

    args = (1, '1a0', 1, 'a', 0, 'minor')
    assert args == _VersionPart(*args)._asdict()


# Generated at 2022-06-23 18:20:32.403799
# Unit test for function bump_version
def test_bump_version():
    """Test the method flutils.packages.bump_version()."""
    # pylint: disable=I0011,protected-access,too-many-branches,too-many-statements
    import pytest

    # A list of values, and the expected results, of the method

# Generated at 2022-06-23 18:20:45.040810
# Unit test for function bump_version
def test_bump_version():
    """Unit test function for ``bump_version``."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-23 18:20:56.812799
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    ).pos == 0
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    ).txt == '1'
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    ).num == 1

# Generated at 2022-06-23 18:21:09.549504
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # Test basic
    vp = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert vp.pos == 0
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'
    # Test no pre-release
    vp = next(_each_version_part(StrictVersion('1.2.3')))
    assert vp.pos == 1
    assert vp.txt == '2'
    assert vp.num == 2
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    # Test pre-release
    vp

# Generated at 2022-06-23 18:21:17.187136
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.

    Also serves as a documentation example.
    """
    from flutils.packages import bump_version
    from flutils.testing import Runner
    from flutils.textutils import to_str

    rnr = Runner()

    # Test that the function works with a simple version bump
    ver_in = '1.2.2'
    ver_out = '1.2.3'
    ver_got = bump_version(ver_in)
    rnr.assert_equal(ver_got, ver_out,
                     "The given version, %r, is not correctly bumped. "
                     "Expected: %r.  Got: %r" % (
                         ver_in,
                         ver_out,
                         ver_got
                     ))

    # Test that the function works with a bump of the minor part

# Generated at 2022-06-23 18:21:23.148407
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.scripts.tests.helpers import (
        assert_raises_msg, assert_equal
    )
    bv = bump_version
    ae = assert_equal
    aem = assert_raises_msg

    ae(bv('1.2.3'), '1.2.4')
    ae(bv('1.2.3', position=1), '1.3')
    ae(bv('1.3.4', position=0), '2.0')
    ae(bv('1.2.3', pre_release='a'), '1.2.4a0')
    ae(bv('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-23 18:21:30.039072
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert 0 == _build_version_info('0.0').major.txt
    assert 0 == _build_version_info('0').major.txt
    assert 0 == _build_version_info('0.0.0').major.txt
    assert 2 == len(_build_version_info('2.0.0').minor)
    assert 'a0' == _build_version_info('2.0.0a0').patch.pre_txt
    assert 1 == _build_version_info('2.0.0a0').patch.pre_num
    assert 1 == _build_version_info('2.0.0a1').patch.pre_num
    assert 'b' == _build_version_info('2.0.0b1').patch.pre_txt

# Generated at 2022-06-23 18:21:42.976152
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion
    from flutils.tests.helpers import print_check

    ver_obj = StrictVersion('1.2.3')
    parts = list(_each_version_part(ver_obj))
    assert len(parts) == 3, 'This version has 3 parts.'
    part_major, part_minor, part_patch = parts
    assert part_major.pos == 0, 'The major version number has an index of 0.'
    assert part_major.txt == '1', 'The major "text" version is "1".'
    assert part_major.num == 1, 'The major "number" version is 1.'
    assert part_major.pre_txt == '', 'The major "text" pre-release is blank.'

# Generated at 2022-06-23 18:21:46.357475
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [10, '20.30.40', 50, 'alpha', 60, 'beta']
    instance = _VersionPart(*args)
    for attr, val in zip(instance._fields, args):
        assert getattr(instance, attr) == val


# Generated at 2022-06-23 18:21:56.106744
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # noqa
    return
    # Run against all supported python versions
    for version in ('2.6', '2.7', '3.4', '3.5', '3.6', '3.7'):
        try:
            assert _VersionInfo('1.0',
                                _VersionPart(0, '1', 1, '', -1, 'major'),
                                _VersionPart(1, '0', 0, '', -1, 'minor'),
                                _VersionPart(2, '', 0, '', -1, 'patch'),
                                -1)
        except AssertionError:
            print('Failed for: %s' % version)
            raise


# Generated at 2022-06-23 18:22:00.089916
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major',
    )



# Generated at 2022-06-23 18:22:12.557940
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:22:24.374521
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:22:33.571342
# Unit test for function bump_version

# Generated at 2022-06-23 18:22:41.429282
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': '3',
        'num': 3,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major',
    }
    assert repr(_VersionPart(**kwargs)) == "<_VersionPart('3', '0', 'major')>"
    assert _VersionPart(**kwargs) == _VersionPart(**kwargs)
    assert _VersionPart(**kwargs) != kwargs



# Generated at 2022-06-23 18:22:48.399055
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=line-too-long
    _build_version_info('1.2.3')  # noqa
    _build_version_info('1.2.3a2')
    _build_version_info('1.2.3b3')
    _build_version_info('1.2a2.3')
    _build_version_info('1.2b3.4')
    _build_version_info('1.2.3.4')
    _build_version_info('1.2.3.4a5')
    _build_version_info('1.2.3.4b6')
    _build_version_info('1.2.0')
    _build_version_info('1.2')
    _build_version_info('1')

# Generated at 2022-06-23 18:23:00.223570
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') == \
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _VersionPart(1, '2', 2, '', -1, 'minor') == \
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    assert _VersionPart(2, '3', 3, '', -1, 'patch') == \
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch')

# Generated at 2022-06-23 18:23:05.744874
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    ) == _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert _VersionPart(
        pos=0, txt='2', num=2, pre_txt='', pre_num=-1, name='major'
    ) != _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )


# Generated at 2022-06-23 18:23:09.562553
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    if __name__ == '__main__':
        for part in _each_version_part(StrictVersion('2.3.4a1')):
            print(part)
            assert len(part) == 3



# Generated at 2022-06-23 18:23:22.122367
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase
    from unittest.mock import patch, MagicMock

    class Test(TestCase):
        def setUp(self):
            self.build_called = False
            self.kwargs: Dict[str, Any] = {
                'pos': -1,
                'txt': '',
                'num': -1,
                'pre_txt': '',
                'pre_num': -1,
                'name': 'test'
            }

        def build(self, version: str) -> _VersionPart:
            self.build_called = True
            with patch('flutils.packages._each_version_part') as mock:
                ver_obj = MagicMock()
                ver_obj.version = (1, 2, 3)
                ver_obj.prerelease = None
                mock

# Generated at 2022-06-23 18:23:26.430245
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pp = _VersionPart(3, '3', 3, '', -1, 'patch')
    assert pp.pos == 3
    assert pp.txt == '3'
    assert pp.num == 3
    assert pp.pre_txt == ''
    assert pp.pre_num == -1
    assert pp.name == 'patch'


# Generated at 2022-06-23 18:23:37.841325
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version

    # Test major version bump, with no pre-release
    version = '0.2.2'
    pos = 0
    res = bump_version(version, pos)
    assert res == '1.0'

    # Test minor version bump, with no pre-release
    version = '0.2.2'
    pos = 1
    res = bump_version(version, pos)
    assert res == '0.3'

    # Test patch version bump, with no pre-release
    version = '0.2.2'
    pos = 2
    res = bump_version(version, pos)
    assert res == '0.2.3'

    # Test negative position
    version = '0.2.2'

# Generated at 2022-06-23 18:23:46.253857
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """
    import flutils.packages as pkgutils

    version = '1.2.0'
    assert pkgutils.bump_version(version) == '1.2.1'

    version = '1.2.0'
    assert pkgutils.bump_version(version, 0) == '2.0'

    version = '1.2.0'
    assert pkgutils.bump_version(version, position=1) == '1.3.0'


if __name__ == '__main__':
    import flutils.packages as pkgutils

    pkgutils.test_bump_version()

# Generated at 2022-06-23 18:23:57.669872
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # Test bump_version with no data
    expected = '1.0.0'
    actual = bump_version('')
    assert expected == actual

    expected = '1.0.0'
    actual = bump_version('0.0.0')
    assert expected == actual

    # Test bump_version position 2
    expected = '1.2.0'
    actual = bump_version('1.1.9')
    assert expected == actual, str(actual)

    expected = '1.2.1'
    actual = bump_version('1.2.0')
    assert expected == actual, actual

    expected = '1.2.1'
    actual = bump_version('1.2.1')
    assert expected == actual, actual

    # Test bump_version position 1


# Generated at 2022-06-23 18:24:08.940210
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('0.1.2')
    parts = _each_version_part(ver_obj)
    assert parts.gi_frame.f_lasti == -1
    assert parts.gi_frame.f_back is None
    assert parts.gi_frame.f_code.co_name == '_each_version_part'
    assert parts.gi_frame.f_code.co_argcount == 1
    assert parts.gi_frame.f_code.co_varnames == ()
    assert parts.gi_frame.f_code.co_filename is __file__
    assert parts.gi_frame.f_code.co_firstlineno == 179
    assert parts.gi_frame.f_code.co_flags == 67

# Generated at 2022-06-23 18:24:18.776090
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    text = '1.2.3a0'
    res = _build_version_info(text)
    assert res.version == '1.2.3a0'
    assert res.major.pos == 0
    assert res.major.txt == '1'
    assert res.major.num == 1
    assert res.major.pre_txt == ''
    assert res.major.pre_num == -1
    assert res.minor.pos == 1
    assert res.minor.txt == '2.3a0'
    assert res.minor.num == 2
    assert res.minor.pre_txt == 'a'
    assert res.minor.pre_num == 0
    assert res.patch.pos == 2
    assert res.patch.txt == ''
    assert res.patch.num == 0
    assert res

# Generated at 2022-06-23 18:24:28.016767
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    """Basic unit tests for function bump_version."""
    from pprint import pprint as pp
    from flutils.test_helpers import print_test_header

    print_test_header('test_bump_version')

# Generated at 2022-06-23 18:24:32.857511
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    tst = _VersionPart(
        pos=0, txt='0', num=0, pre_txt='', pre_num=0, name='a'
    )
    assert tst.pos == 0
    assert tst.txt == '0'
    assert tst.num == 0
    assert tst.pre_txt == ''
    assert tst.pre_num == 0
    assert tst.name == 'a'



# Generated at 2022-06-23 18:24:44.320616
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """

# Generated at 2022-06-23 18:24:52.766079
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""

# Generated at 2022-06-23 18:25:01.986083
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:25:03.834989
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major').pos == 0



# Generated at 2022-06-23 18:25:15.245633
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:25:27.428556
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.2')
    assert version == '1.2.3'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'

# Generated at 2022-06-23 18:25:39.485202
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from testutils import eq_

    eq_(_VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(0, '1', 1, '', -1, 'major'))

    eq_(_VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(0, 'a', 181, '', -1, 'major'))
    eq_(_VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(-1, '1', 1, '', -1, 'minor'))
    eq_(_VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(-2, '1', 1, '', -1, 'patch'))

# Generated at 2022-06-23 18:25:46.540117
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion
    from flutils.packages import _each_version_part
    from flutils.packages import _VersionPart
    from flutils.testing import compare_exception_message
    from unittest import TestCase

    class test__VersionPart__(TestCase):
        def test__VersionPart__ok(self):
            for version in ('1', '1.2', '1.2.3'):
                ver_obj = StrictVersion(version)
                for part in _each_version_part(ver_obj):
                    self.assertIsInstance(part, _VersionPart)

        def test__VersionPart__failure(self):
            msg = ('The given value, "a", must be a '
                   '"distutils.version.StrictVersion" instance.')

# Generated at 2022-06-23 18:25:47.457690
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pass


# Generated at 2022-06-23 18:25:59.265962
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from copy import copy
    from flutils.packages import _VersionPart

    def cpn(kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Copy and build new

        Copy the given dict and add a new key of 'name'

        Args:
            kwargs (Dict[str, Any]): The dict to copy

        Returns:
            Dict[str, Any]: The copied dict with the 'name' key added.

        """
        kw = copy(kwargs)
        kw['name'] = _BUMP_VERSION_POSITION_NAMES[kw['pos']]
        return kw


# Generated at 2022-06-23 18:26:09.715097
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    ver_obj = StrictVersion('1')
    version = ver_obj.version

    pos_check = 0
    num_check = version[0]
    txt_check = str(num_check)
    pre_txt_check = ''
    pre_num_check = -1
    name_check = 'major'
    check_kwargs = {
        'pos': pos_check,
        'txt': txt_check,
        'num': num_check,
        'pre_txt': pre_txt_check,
        'pre_num': pre_num_check,
        'name': name_check,
    }
    ver_part_obj = _VersionPart(**check_kwargs)

    for key, val in check_kwargs.items():
        assert get

# Generated at 2022-06-23 18:26:21.562711
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest.mock import patch
    patched_each_version_part = patch(
        '%s._each_version_part' % __name__
    )
    with patched_each_version_part as each_version_part:
        each_version_part.return_value = [
            _VersionPart(2, 3, 3, 'a', 1, 'patch'),
            _VersionPart(1, 2, 2, '', -1, 'minor')
        ]
        obj = StrictVersion('1.2.3a1')
        parts = tuple(_each_version_part(obj))
        assert parts[0] == _VersionPart(2, 3, 3, 'a', 1, 'patch')
        assert parts[1] == _VersionPart(1, 2, 2, '', -1, 'minor')


# Generated at 2022-06-23 18:26:32.277820
# Unit test for function bump_version
def test_bump_version():
    '''
    Unit test for function bump_version
    '''
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1')