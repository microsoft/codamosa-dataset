

# Generated at 2022-06-23 18:16:42.539077
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3a4')
    _build_version_info('1.2.3b5')
    _build_version_info('1.2.3.4.5')
    _build_version_info('1.2.3.4.5a6')
    _build_version_info('1.2.3.4.5b7')
    _build_version_info('1.2.3.4.5.6')
    _build_version_info('1.2.3.4.5.6a0')
    _build_version_info('1.2.3.4.5.6b0')
    _build_version_info('1.2.3.4.5.6.7')

# Generated at 2022-06-23 18:16:53.137605
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    from flutils.packages import get_version
    from flutils.packages import set_version
    from tempfile import NamedTemporaryFile
    from unittest import TestCase
    from textwrap import dedent
    from distutils.version import StrictVersion

    class BumpVersionTestCase(TestCase):
        """TestCase for function bump_version."""

        def test_major(self):
            set_version('1.2.3')
            self.assertEqual(bump_version('1.2.3'), '1.2.4')
            self.assertEqual(bump_version('1.2.3', position=0), '2.0')
            self.assertEqual

# Generated at 2022-06-23 18:16:59.689101
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnresolvedReferences
    """Test the constructor of the _VersionInfo class."""

    def _test(
            version: str,
            major: str,
            minor: str,
            patch: str,
            pre_pos: int
    ) -> None:
        """Test the constructor of the _VersionInfo class."""
        kw_args = {
            'version': version,
            'major': major,
            'minor': minor,
            'patch': patch,
            'pre_pos': pre_pos
        }
        instance = _VersionInfo(**kw_args)
        assert instance.version == version
        assert instance.major == major
        assert instance.minor == minor
        assert instance.patch == patch
        assert instance.pre_pos == pre_pos


# Generated at 2022-06-23 18:17:11.211768
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-23 18:17:21.243881
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    import unittest
    import sys
    import os


# Generated at 2022-06-23 18:17:26.389753
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'


# Generated at 2022-06-23 18:17:39.460668
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for called function bump_version"""
    # pylint: disable=W0106,W0142
    import io
    import sys
    import unittest

    class OutputCapture(list):
        """Capture output written to a stream."""

        def __enter__(self) -> Any:
            """Capture output written to a stream."""
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self

        def __exit__(
                self,
                *args: Any
        ) -> Any:
            """Capture output written to a stream."""
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout


# Generated at 2022-06-23 18:17:45.598368
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0221
    """Test bump_version()."""
    import pytest

    @pytest.mark.parametrize(
        'ver_str',
        (
            'ping',
            '0.0.0',
            '0.0.1',
            '1.2',
            '1.2.0',
            '1.2.3',
            '1.2.3a0',
            '1.2.3b0',
            '1.2.4',
            '1.2.4a0',
            '1.2.4b0',
            '2.1.3a0',
        )
    )
    def test_version_bump(ver_str: str) -> None:
        """Test the version number bumping."""
        out

# Generated at 2022-06-23 18:17:54.215843
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:17:58.794432
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:18:07.125357
# Unit test for function bump_version
def test_bump_version():
    from pytest import mark
    from .abc import (
        func_test_kwargs,
        func_test_no_args,
    )
    from flutils.packages import bump_version

    @mark.parametrize(
        'kwargs',
        func_test_kwargs(bump_version),
    )
    def test__bump_version__1(kwargs: Any):
        """Test that function bump_version() with kwargs returns proper
        value.
        """
        out = bump_version(**kwargs)
        kwargs['version'] = kwargs['version'].strip()
        if 'position' in kwargs:
            kwargs['position'] = _build_version_bump_position(kwargs['position'])

# Generated at 2022-06-23 18:18:18.415599
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:18:29.908052
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version_a = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major',
    }
    version_b = {
        'pos': 1,
        'txt': '2',
        'num': 2,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'minor',
    }
    version_c = {
        'pos': 2,
        'txt': '',
        'num': 0,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'patch',
    }

# Generated at 2022-06-23 18:18:42.723828
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('0.0.1')
    assert info.version == '0.0.1'
    assert info.major.txt == '0'
    assert info.major.num == 0
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.major.pos == 0
    assert info.minor.txt == '0'
    assert info.minor.num == 0
    assert info.minor.pre_txt == ''
    assert info.minor.pre_num == -1
    assert info.minor.name == 'minor'
    assert info.minor.pos == 1
    assert info.patch.txt == '1'
    assert info.patch.num == 1
   

# Generated at 2022-06-23 18:18:52.494414
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences,PyUnresolvedReferences
    from flutils.packages import bump_version
    from testhelpers import p
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:19:02.843366
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function: py:func:`flutils.packages.bump_version`
    """
    import pytest

    def _test_bump_version(
            version: str,
            position: int = 2,
            pre_release: str = '',
            expected: Optional[str] = None,
            expected_exception: Optional[Any] = None
    ):
        if expected_exception is None:
            output = bump_version(version, position, pre_release)
            assert output == expected
        else:
            with pytest.raises(expected_exception):
                bump_version(version, position, pre_release)

    # Test position and pre_release

    # Test patch
    _test_bump_version('1.2.3', expected='1.2.4')
    _

# Generated at 2022-06-23 18:19:13.622483
# Unit test for function bump_version
def test_bump_version():
    "Unit test for 'flutils.packages.bump_version'."
    ver = '1.1.0'

    assert bump_version(ver) == '1.1.1'
    assert bump_version(ver, position=1) == '1.2'
    assert bump_version(ver, position=0) == '2.0'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', position=1) == '1.2'
    assert bump_version('1.1.1', position=0) == '2.0'
    assert bump_version('2.0.0', position=1) == '2.1'
    assert bump_version(ver, pre_release='a') == '1.1.0a0'
   

# Generated at 2022-06-23 18:19:24.316359
# Unit test for function bump_version
def test_bump_version():
    """
    Function used to test the ``bump_version`` function.
    """
    # pragma: no cover
    import os
    import json
    import sys

    # Import the testing module
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    # noinspection PyUnresolvedReferences
    from flutils.packages import (
        bump_version
    )

    test_dir = os.path.split(os.path.abspath(__file__))[0]
    with open(os.path.join(test_dir, 'test_version_bump.json'), 'r') as f:
        test_data = json.loads(f.read())


# Generated at 2022-06-23 18:19:32.285734
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    class_name = 'flutils.packages._VersionInfo'
    ver_obj = _build_version_info('1.2.3')
    try:
        assert isinstance(ver_obj, _VersionInfo)
    except AssertionError:
        msg = '%s  is not instance of %s' % (ver_obj, class_name)
        raise AssertionError(msg)
    try:
        assert ver_obj.version == '1.2.3'
    except AssertionError:
        msg = '%s  version is not 1.2.3' % ver_obj
        raise AssertionError(msg)

# Generated at 2022-06-23 18:19:34.910349
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils import packages
    from flutils.testing import construct_object_test, get_test_args
    args = get_test_args(packages._VersionPart, ('pos', 'txt', 'num'))
    construct_object_test(packages._VersionPart, args)


# Generated at 2022-06-23 18:19:44.304975
# Unit test for function bump_version
def test_bump_version():
    from flutils.pytest import raises_exception
    from flutils.packages import bump_version

# Generated at 2022-06-23 18:19:48.004181
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(0, '2', 2, '', -1, 'major')
    assert vp.pos == 0
    assert vp.txt == '2'
    assert vp.num == 2
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'


# Generated at 2022-06-23 18:19:57.901597
# Unit test for function bump_version
def test_bump_version():
    'Unit test for function bump_version'
    print('Test increase version string.\n')

# Generated at 2022-06-23 18:20:09.261626
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info("1.2.3")
    _build_version_info("1.2.3-b0")
    _build_version_info("1.2.3-a1")
    _build_version_info("1.2.3-b1")
    _build_version_info("1.2.3a1")
    _build_version_info("1.2.3b1")
    _build_version_info("1.2.30")
    _build_version_info("1.20.30")
    _build_version_info("1.2.0-b0")
    _build_version_info("1.2.0-a1")
    _build_version_info("1.2.0-b1")

# Generated at 2022-06-23 18:20:17.012963
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:20:29.895938
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the private constructor of class _VersionPart.

    This is used in unit testing ``bump_version``.

    """
    pos = 0
    txt = '1'
    num = 1
    pre_txt = ''
    pre_num = -1
    name = 'major'
    version_part = _VersionPart(pos, txt, num, pre_txt, pre_num, name)
    assert isinstance(version_part, tuple)
    assert version_part.pos == pos
    assert version_part.txt == txt
    assert version_part.num == num
    assert version_part.pre_txt == pre_txt
    assert version_part.pre_num == pre_num
    assert version_part.name == name



# Generated at 2022-06-23 18:20:39.009172
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test a version without pre-release
    args = (
        '1.2',  # version
        _VersionPart(0, '1', 1, '', -1, 'major'),  # major
        _VersionPart(1, '2', 2, '', -1, 'minor'),  # minor
        _VersionPart(2, '', 0, '', -1, 'patch'),  # patch
        -1  # pre_pos
    )
    version_info = _VersionInfo(*args)
    assert version_info.version == arg[0]
    assert version_info.major == arg[1]
    assert version_info.minor == arg[2]
    assert version_info.patch == arg[3]
    assert version_info.pre_pos == arg[4]

    # Test a version with pre-release


# Generated at 2022-06-23 18:20:51.768145
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=missing-function-docstring
    # pylint: disable=line-too-long
    assert bump_version(
        '2.0.0a2',
        position=1,
        pre_release='a'
    ) == '2.1a0'
    assert bump_version(
        '2.0.0b2',
        position=1,
        pre_release='b'
    ) == '2.1b0'
    assert bump_version(
        '0.0.0',
        position=1,
        pre_release='a'
    ) == '0.1a0'  # New pre_release

# Generated at 2022-06-23 18:20:56.288308
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert repr(_VersionPart(1, '1', 1, 'a', 0, 'minor')) == \
        "_VersionPart(pos=1, txt='1', num=1, pre_txt='a', pre_num=0, name='minor')"



# Generated at 2022-06-23 18:21:07.589163
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test class `flutils.packages._VersionInfo`.
    """
    from flutils.packages import _VersionInfo
    from pprint import pformat
    VersionInfo = _VersionInfo

    msg = pformat(VersionInfo.__annotations__)
    assert msg == (
        "{'major': '_VersionPart',\n"
        " 'minor': '_VersionPart',\n"
        " 'patch': '_VersionPart',\n"
        " 'pre_pos': 'int',\n"
        " 'version': 'str'}"
    )
    assert class_has_annotations(VersionInfo) is True
    return


# Unit test function

# Generated at 2022-06-23 18:21:15.195312
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert ('1.1.1' == _build_version_info('1.1.1').version)
    ver_info = _build_version_info('1.1.1a0')
    assert ('1.1.1a0' == ver_info.version)
    assert (1 == ver_info.pre_pos)
    assert ('a' == ver_info.minor.pre_txt)
    assert (0 == ver_info.minor.pre_num)
    ver_info = _build_version_info('1.10.1b0')
    assert ('1.10.1b0' == ver_info.version)
    assert (2 == ver_info.pre_pos)
    assert ('b' == ver_info.patch.pre_txt)

# Generated at 2022-06-23 18:21:25.429112
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1,
    )

# Generated at 2022-06-23 18:21:38.887106
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'

    ver = '1.2.3'
    assert bump_version(ver, position=1) == '1.3'

    ver = '1.3.4'
    assert bump_version(ver, position=0) == '2.0'

    ver = '1.2.3'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'

    ver = '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a1'

    ver = '1.2.4a1'

# Generated at 2022-06-23 18:21:48.866933
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3a1'

# Generated at 2022-06-23 18:21:56.239364
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs: Dict[str, Any] = {
        'pos': 0,
        'txt': 'a',
        'num': 1,
        'pre_txt': 'b',
        'pre_num': 2,
        'name': 'c'
    }
    # noinspection PyTypeChecker
    p = _VersionPart(**kwargs)
    for k, v in kwargs.items():
        assert getattr(p, k) == v
    assert p.pos == 0
    assert p.txt == 'a'
    assert p.num == 1
    assert p.pre_txt == 'b'
    assert p.pre_num == 2
    assert p.name == 'c'



# Generated at 2022-06-23 18:22:09.735578
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from textwrap import dedent
    from unittest import TestCase

    import flutils.packages

    class Test__VersionPart(TestCase):
        def test_case_001(self):
            ver_obj = StrictVersion('1.2.3')
            for part in flutils.packages._each_version_part(ver_obj):
                if part.pos == 0:
                    self.assertEqual(part, flutils.packages._VersionPart(
                        pos=0,
                        txt='1',
                        num=1,
                        pre_txt='',
                        pre_num=-1,
                        name='major'
                    ))

# Generated at 2022-06-23 18:22:19.254084
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.2')
    expected = dict(
        version='1.2',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert expected == info._as

# Generated at 2022-06-23 18:22:21.355806
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test__VersionInfo.__test__ = False
    ver_info = _build_version_info('1.3.4')



# Generated at 2022-06-23 18:22:31.266285
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo"""
    tdata = []
    tdata.append(('1.2.3', '1.2.3', 1, 2, 3, -1))
    tdata.append(('1.2.4b0', '1.2.4b0', 1, 2, 4, 1))
    tdata.append(('1.3b1', '1.3b1', 1, 3, 0, 1))
    tdata.append(('2.2a1', '2.2a1', 2, 2, 0, 1))
    tdata.append(('0.1.1a1', '0.1.1a1', 0, 1, 1, 2))

# Generated at 2022-06-23 18:22:32.220871
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(*range(7)) is not None

# Generated at 2022-06-23 18:22:43.571515
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    from flutils.packages import bump_version

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:22:52.778221
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    """Test for :func:`bump_version`.

    """

    def test_value(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        """Test a single version value.

        """
        bump = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert bump == expected, (
            "Got:\n%r\n\nExpected:\n%r" % (bump, expected)
        )

    test_value(version='1.2.2', position=2, pre_release=None, expected='1.2.3')

# Generated at 2022-06-23 18:22:58.792480
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version. """

    from random import choice, randint
    from itertools import product
    from flutils.packages import bump_version
    from pkg_resources import parse_version
    from flutils.datautils import flatten

    from .testingutils import dict_compare, get_random_string

    values = [
        ['1.0.0'],
        ['1.0.0', 1],
        ['1.0.0', -1],
        ['1.0.0', 2],
        ['1.0.0', -2],
        ['1.0.0', 3],
        ['1.0.0', -3],
        ['1.0.0', randint(4, 1000)],
        ['1.0.0', randint(-1000, -1)],
    ]


# Generated at 2022-06-23 18:23:05.603967
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:23:08.699221
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:23:21.580065
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    r = _build_version_info('1.2.3')
    assert r.version == '1.2.3'
    assert r.pre_pos == 2
    r = _build_version_info('1.2.3a0')
    assert r.version == '1.2.3a0'
    assert r.pre_pos == 1
    r = _build_version_info('1.2.4b1')
    assert r.version == '1.2.4b1'
    assert r.pre_pos == 2
    r = _build_version_info('1.2.4')
    assert r.version == '1.2.4'
    assert r.pre_pos == -1
    r = _build_version_info('1.2.0')

# Generated at 2022-06-23 18:23:26.859871
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    exp = ('1.2.3',
           _VersionPart(0, '1', 1, '', -1, 'major'),
           _VersionPart(1, '2', 2, '', -1, 'minor'),
           _VersionPart(2, '3', 3, '', -1, 'patch'), 2)
    assert _build_version_info('1.2.3-a1') == _VersionInfo(*exp)



# Generated at 2022-06-23 18:23:38.295226
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0613
    """Unit tests for function bump_version"""
    # pylint: disable=R0912,R0914,W0612,W0613
    ver_list = []
    ver_list.append((None, 'a', 'b', 'c', 'd'))  # bad version
    ver_list.append(('1.2.3', None, 'b', 'c', 'd'))  # bad position
    ver_list.append(('1.2.3', 1, 'f', 'c', 'd'))  # bad pre-release
    ver_list.append(('1.2.3', 0, 'a', 'c', 'd'))  # bad major pre-release

# Generated at 2022-06-23 18:23:48.458894
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from distutils.version import StrictVersion

    obj = StrictVersion('1.2.3')
    for part in _each_version_part(obj):
        assert isinstance(part, _VersionPart)

    obj = StrictVersion('1.2.3a1')
    for part in _each_version_part(obj):
        assert isinstance(part, _VersionPart)

    obj = StrictVersion('1.2.3b2')
    for part in _each_version_part(obj):
        assert isinstance(part, _VersionPart)

    obj = StrictVersion('1.2a3')
    for part in _each_version_part(obj):
        assert isinstance(part, _VersionPart)

    obj = StrictVersion('1.2b4')

# Generated at 2022-06-23 18:23:59.384704
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart."""
    ver_obj = StrictVersion('2.1.1')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
        assert isinstance(part.pos, int)
        assert isinstance(part.txt, str)
        assert isinstance(part.num, int)
        assert isinstance(part.pre_txt, str)
        assert isinstance(part.pre_num, int)
        assert isinstance(part.name, str)
    ver_obj = StrictVersion('2.1.0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
        assert isinstance(part.pos, int)

# Generated at 2022-06-23 18:24:10.941856
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase
    from unittest.mock import patch

    import flutils.packages


# Generated at 2022-06-23 18:24:16.230589
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0612
    from pprint import pprint

    for ver_str in ('1', '1.2', '1.2.3', '1.2.3a4', '1.2.4b4'):
        ver_obj = StrictVersion(ver_str)
        for part in _each_version_part(ver_obj):
            pprint(part)



# Generated at 2022-06-23 18:24:23.951762
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:24:35.105104
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        -1
    )

# Generated at 2022-06-23 18:24:38.578290
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver = StrictVersion('1.2.3')
    a = _each_version_part(ver)
    assert isinstance(next(a), _VersionPart)



# Generated at 2022-06-23 18:24:41.182432
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnusedLocal
    out = _build_version_info('1.2.3')


# Generated at 2022-06-23 18:24:46.391135
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(pos=0, txt='9', num=9, pre_txt='', pre_num=-1, name='major')
    assert obj.pos == 0
    assert obj.txt == '9'
    assert obj.num == 9
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'



# Generated at 2022-06-23 18:24:52.942880
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.string import random_alpha
    from flutils.string import random_alpha_numeric
    from flutils.string import random_digit
    from flutils.string import random_numeric

    t_num = random_digit()
    t_txt = random_alpha()
    t_name = random_alpha_numeric()

    t_part = _VersionPart(1, t_txt, t_num, '', -1, t_name)


# Generated at 2022-06-23 18:25:02.105342
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for ver in ['1.2.3', '4.5', '6']:
        for pos, part in enumerate(_each_version_part(StrictVersion(ver))):
            assert isinstance(part.pos, int)
            assert isinstance(part.txt, str)
            assert isinstance(part.num, int)
            assert isinstance(part.pre_txt, str)
            assert isinstance(part.pre_num, int)
            assert isinstance(part.name, str)
            if part.pre_txt:
                if pos == 0:
                    assert part.pre_num == -1
                elif pos == 1:
                    assert part.pre_num >= 0
            elif pos != 2 or ver != '6':
                assert part.pre_num == -1



# Generated at 2022-06-23 18:25:11.412146
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = {
        'pos': 1,
        'txt': '2',
        'num': 2,
        'pre_txt': 'b',
        'pre_num': 3,
        'name': 'minor'
    }
    verpart = _VersionPart(**args)
    assert isinstance(verpart, _VersionPart) is True
    assert verpart.pos == args['pos']
    assert verpart.txt == args['txt']
    assert verpart.num == args['num']
    assert verpart.pre_txt == args['pre_txt']
    assert verpart.pre_num == args['pre_num']
    assert verpart.name == args['name']


# Generated at 2022-06-23 18:25:20.259142
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ('1.2.3', _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                                  pre_num=-1, name='major'),
            _VersionPart(pos=1, txt='2', num=2, pre_txt='',
                         pre_num=-1, name='minor'),
            _VersionPart(pos=2, txt='3', num=3, pre_txt='',
                         pre_num=-1, name='patch'),
            -1)
    try:
        _VersionInfo(*args)
    except Exception:
        raise


# Generated at 2022-06-23 18:25:27.069150
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    txt = '3.0'
    num = 3
    pos = 0
    name = 'major'

    _VersionPart(
        pos, txt, num, '', -1, name
    )

    _VersionPart(
        pos, txt, num, 'a', 0, name
    )

    _VersionPart(
        pos, txt, num, 'b', 0, name
    )


# Generated at 2022-06-23 18:25:38.581345
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    for ver in [
            '1.2.3',
            '1.21.3',
            '1.21.0',
            '1.21.0a1',
            '1.21.1a1',
            '1.21.1a2',
            '1.21.0b1',
            '1.21.1b1',
            '1.21.1b2',
            '1.21.0',
            '1.21.0a1',
            '1.21.1a1',
            '1.21.1a2',
            '1.21.0b1',
            '1.21.1b1',
            '1.21.1b2',
    ]:
        _build_version_info(ver)


# Generated at 2022-06-23 18:25:47.364032
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pragma: no cover
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        print(part)

    ver_obj = StrictVersion('1.2.3a1')
    for part in _each_version_part(ver_obj):
        print(part)

    ver_obj = StrictVersion('1.2.3b1')
    for part in _each_version_part(ver_obj):
        print(part)

    ver_obj = StrictVersion('1.2.0a1')
    for part in _each_version_part(ver_obj):
        print(part)

    ver_obj = StrictVersion('1.2.0b1')

# Generated at 2022-06-23 18:25:53.678036
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test_version = '1.2.3rc2'
    version_info = _build_version_info(test_version)
    print(version_info)


if __name__ == '__main__':
    #test__VersionInfo()
    #test_get_package_name()
    print(bump_version('1.2.0rc2'))

# Generated at 2022-06-23 18:26:03.200764
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyProtectedMember
    from flutils.packages import _VersionPart

    ver_part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert isinstance(ver_part, _VersionPart)
    assert ver_part.pos == 0
    assert ver_part.txt == '1'
    assert ver_part.num == 1
    assert ver_part.pre_txt == ''
    assert ver_part.pre_num == -1
    assert ver_part.name == 'major'



# Generated at 2022-06-23 18:26:12.062077
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=missing-docstring,redefined-outer-name
    from collections import namedtuple

    def assert_bump(
            version: str,
            position: int,
            prerelease: Optional[str],
            expected: str
    ) -> None:
        bumped = bump_version(version, position, prerelease)
        assert bumped == expected, '%s != %s' % (bumped, expected)

    TestCase = namedtuple('TestCase', ['version', 'position', 'prerelease', 'expected'])


# Generated at 2022-06-23 18:26:24.501990
# Unit test for function bump_version
def test_bump_version():
    """Unit Tests for function bump_version"""
    # pylint: disable=R0201,C0415
    import unittest
    from flutils.packages import bump_version

    class TestClass(unittest.TestCase):
        """Unit Test Class"""

        def test_bump_version(self):
            """Unit Tests for function bump_version"""
            # pylint: disable=R0201
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

# Generated at 2022-06-23 18:26:34.005296
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0106
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        patch=_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        pre_pos=-1
    )