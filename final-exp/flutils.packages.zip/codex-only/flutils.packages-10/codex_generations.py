

# Generated at 2022-06-23 18:16:37.485126
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    ver_info = _build_version_info('1.0.0')
    assert ver_info.version == '1.0.0'
    ver_info = _build_version_info('2.1.3')
    assert ver_info.version == '2.1.3'
    ver_info = _build_version_info('1.2b0')
    assert ver_info.version == '1.2b0'
    ver_info = _build_version_info('1.3.4a0')
    assert ver_info.version == '1.3.4a0'
    ver_info = _build_version_info('1.2.4a1')

# Generated at 2022-06-23 18:16:45.024940
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    version = bump_version('1.2.2')
    assert version == '1.2.3', version
    version = bump_version('1.2.3', position=1)
    assert version == '1.3', version
    version = bump_version('1.3.4', position=0)
    assert version == '2.0', version
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0', version
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1', version
    version = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-23 18:16:54.399330
# Unit test for function bump_version
def test_bump_version():
    """Test the function: bump_version."""
    versions = [
        '1.0',
        '1.0.0',
        '1.1.0',
        '1.1.1',
        '1.2a0',
        '1.2a1',
        '1.2b1',
        '1.2.2',
        '1.2.2a0',
        '1.2.2a1',
        '1.2.2b1',
    ]

# Generated at 2022-06-23 18:17:00.699974
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1', 1, 0, 0, -1) == _build_version_info('1')
    assert _VersionInfo('1.2', 1, 2, 0, -1) == _build_version_info('1.2')
    assert _VersionInfo(
        '1.2.3',
        1,
        2,
        3,
        -1
    ) == _build_version_info('1.2.3')
    assert _VersionInfo(
        '1.2.0',
        1,
        2,
        0,
        -1
    ) == _build_version_info('1.2.0')
    assert _VersionInfo(
        '1.2.3a0',
        1,
        2,
        3,
        1
    ) == _build_version_

# Generated at 2022-06-23 18:17:12.126737
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v = _build_version_info('0.0.4')
    assert v.version == '0.0.4'
    assert v.major.pos == 0
    assert v.minor.pos == 1
    assert v.patch.pos == 2
    assert v.major.txt == '0'
    assert v.minor.txt == '0'
    assert v.patch.txt == '4'
    assert v.major.num == 0
    assert v.minor.num == 0
    assert v.patch.num == 4
    assert v.major.pre_txt == ''
    assert v.minor.pre_txt == ''
    assert v.patch.pre_txt == ''
    assert v.major.pre_num == -1
    assert v.minor.pre_num == -1
    assert v.patch

# Generated at 2022-06-23 18:17:21.830256
# Unit test for function bump_version
def test_bump_version():
    """Test the version number bumping function."""
    # pylint: disable=C0301

# Generated at 2022-06-23 18:17:28.017848
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.0.0') == _VersionInfo(
        '1.0.0',
        _VersionPart(
            0, '1', 1, '', -1, 'major'
        ),
        _VersionPart(
            1, '0', 0, '', -1, 'minor'
        ),
        _VersionPart(
            2, '', 0, '', -1, 'patch'
        ),
        -1
    )

# Generated at 2022-06-23 18:17:35.011315
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                                 _VersionPart(2, '3', 3, '', -1, 'patch'),
                                 0) == _build_version_info('1.2.3')



# Generated at 2022-06-23 18:17:45.118660
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

# Generated at 2022-06-23 18:17:53.871390
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit tests for the constructor of class _VersionInfo."""
    obj = _build_version_info('2.3.4a1')
    assert obj.version == '2.3.4a1'
    assert obj.major.version == 2
    assert obj.major.pre_txt == ''
    assert obj.major.pre_num == -1
    assert obj.minor.version == 3
    assert obj.minor.pre_txt == 'a'
    assert obj.minor.pre_num == 1
    assert obj.patch.version == 4
    assert obj.patch.pre_txt == 'a'
    assert obj.patch.pre_num == 1
    assert obj.pre_pos == 1
    obj = _build_version_info('2.3.4')

# Generated at 2022-06-23 18:18:00.225405
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function `bump_version`."""
    from unittest import TestCase
    from os import path

    from .pkgutils import _tests_dir

    class TestBumpVersion(TestCase):
        """Test for function `bump_version`."""

        def test_bump_version_invalid_ver(self):
            """Test `bump_version` with an invalid version number."""
            ver = '1.1.1a'
            self.assertRaisesRegex(
                ValueError,
                "not a valid version number",
                bump_version,
                ver
            )

        def test_bump_version_invalid_pos(self):
            """Test `bump_version` with an invalid position."""
            ver = '1.1.1'
            pos = 10
            self

# Generated at 2022-06-23 18:18:07.824769
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:18:14.997187
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:18:23.108197
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.2.3')
    info = _build_version_info('1.2')
    info = _build_version_info('1.2.3-dev')
    info = _build_version_info('1.2.3a0')
    info = _build_version_info('1.2.3b0')
    info = _build_version_info('1.2a0')
    info = _build_version_info('1.2b0')


# Generated at 2022-06-23 18:18:32.664386
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver = '1.2.3'
    parts = []
    for part in _each_version_part(StrictVersion(ver)):
        parts.append(part)
    assert len(parts) == 3

    assert parts[0].pos == 0
    assert parts[0].txt == '1'
    assert parts[0].num == 1
    assert parts[0].pre_txt == ''
    assert parts[0].pre_num == -1
    assert parts[0].name == 'major'

    assert parts[1].pos == 1
    assert parts[1].txt == '2'
    assert parts[1].num == 2
    assert parts[1].pre_txt == ''
    assert parts[1].pre_num == -1
    assert parts[1].name == 'minor'


# Generated at 2022-06-23 18:18:39.976369
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    args = (
        _BUMP_VERSION_MAJOR, '1', 1, '', -1, 'major'
    )
    args_kwargs = {
        'pos': _BUMP_VERSION_MAJOR,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    _VersionPart(*args)
    _VersionPart(**args_kwargs)
    assert True



# Generated at 2022-06-23 18:18:50.850509
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914, C0103

    test_ver_info_1 = _build_version_info('1.2.3')
    assert test_ver_info_1.version == '1.2.3'
    assert test_ver_info_1.major.pos == 0
    assert test_ver_info_1.major.txt == '1'
    assert test_ver_info_1.major.num == 1
    assert test_ver_info_1.major.name == 'major'
    assert test_ver_info_1.major.pre_txt == ''
    assert test_ver_info_1.major.pre_num == -1

    assert test_ver_info_1.minor.pos == 1
    assert test_ver_info_1.minor.txt == '2'

# Generated at 2022-06-23 18:18:53.724920
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('0.0.0')
    try:
        _ = _build_version_info('t.e.s.t')
    except ValueError:
        pass
    else:
        raise ValueError('_build_version_info() should have failed')


# Generated at 2022-06-23 18:19:04.883094
# Unit test for function bump_version
def test_bump_version():
    # Test the default
    ver = '1.2.2'
    res = bump_version(ver)
    assert res == '1.2.3'
    # 'minor' part
    ver = '1.2.3'
    res = bump_version(ver, position=1)
    assert res == '1.3'
    # 'major' part
    ver = '1.3.4'
    res = bump_version(ver, position=0)
    assert res == '2.0'
    # alpha part
    ver = '1.2.3'
    res = bump_version(ver, pre_release='a')
    assert res == '1.2.4a0'
    ver = '1.2.4a0'
    res = bump_version(ver, pre_release='a')


# Generated at 2022-06-23 18:19:16.115675
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info("1.0.0")
    assert isinstance(ver_info.version, str)
    assert ver_info.version == "1.0.0"
    assert isinstance(ver_info.major, _VersionPart)
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == "1"
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ""
    assert ver_info.major.pre_num == -1
    assert isinstance(ver_info.minor, _VersionPart)
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == "0"
    assert ver_info.minor.num == 0

# Generated at 2022-06-23 18:19:26.542952
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.helpers import get_code_lines

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:19:33.472484
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import flutils.packages
    # pylint: disable=E0602
    # pylint: disable=W0201
    flutils.packages.__dict__['_BUMP_VERSION_MAJOR'] = 0
    flutils.packages.__dict__['_BUMP_VERSION_MINOR'] = 1
    flutils.packages.__dict__['_BUMP_VERSION_PATCH'] = 2
    flutils.packages.__dict__['_BUMP_VERSION_MINORS'] = (1,)
    flutils.packages.__dict__['_BUMP_VERSION_PATCHES'] = (2,)
    flutils.packages.__dict__['_BUMP_VERSION_POSITION_NAMES'] = {
        0: 'major',
        1: 'minor',
        2: 'patch',
    }
    args

# Generated at 2022-06-23 18:19:45.906294
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    exps = [
        '0.0.2',
        _VersionPart(
            pos=0,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='0',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        -1
    ]
    args = [
        ('0.0.2',),
    ]

# Generated at 2022-06-23 18:19:54.504513
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('0.0.0',
                 _VersionPart(pos=0, txt='0', num=0, pre_txt='',
                              pre_num=-1, name='major'),
                 _VersionPart(pos=1, txt='0', num=0, pre_txt='',
                              pre_num=-1, name='minor'),
                 _VersionPart(pos=2, txt='0', num=0, pre_txt='',
                              pre_num=-1, name='patch'),
                 -1)
    # Beta version

# Generated at 2022-06-23 18:19:55.856322
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 18:20:07.543445
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:20:11.732151
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = [0, '0', 0, '', -1, 'major']
    ver_part = _VersionPart(*args)
    assert ver_part.pos == 0
    assert ver_part.txt == '0'
    assert ver_part.num == 0
    assert ver_part.pre_txt == ''
    assert ver_part.pre_num == -1
    assert ver_part.name == 'major'



# Generated at 2022-06-23 18:20:18.760129
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    val = bump_version('1.2.1')
    assert val == '1.2.2'

    val = bump_version('1.2.2', position=1)
    assert val == '1.3'

    val = bump_version('1.3.4', position=0)
    assert val == '2.0'

    val = bump_version('1.2.3', prerelease='a')
    assert val == '1.2.4a0'

    val = bump_version('1.2.4a0', pre_release='a')
    assert val == '1.2.4a1'

    val = bump_version('1.2.4a1', pre_release='b')
    assert val == '1.2.4b0'



# Generated at 2022-06-23 18:20:32.123845
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3'
    ver_obj = StrictVersion(version)
    part = _each_version_part(ver_obj).__next__()
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = _each_version_part(ver_obj).__next__()
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'
    part = _each_version_part(ver_obj).__next__()

# Generated at 2022-06-23 18:20:44.876739
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('1.2.3',
                        _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'),
                        2)
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2

# Generated at 2022-06-23 18:20:56.657815
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v1 = _build_version_info('1.2.3')
    v2 = _build_version_info('1.2.3a0')
    v3 = _build_version_info('1.2.3a1')
    v4 = _build_version_info('1.2.3b0')
    v5 = _build_version_info('1.2.3b1')
    v6 = _build_version_info('1.2.3a')
    v7 = _build_version_info('1.2.3b')
    # pylint: disable=C0326
    v8 = _build_version_info('1.2a0')
    v9 = _build_version_info('1.2b0')

# Generated at 2022-06-23 18:21:09.379036
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        version='8.9.10',
        major=_VersionPart(pos=0, txt='8', num=8, pre_txt='', pre_num=-1,
                           name='major'),
        minor=_VersionPart(pos=1, txt='9', num=9, pre_txt='', pre_num=-1,
                           name='minor'),
        patch=_VersionPart(pos=2, txt='10', num=10, pre_txt='', pre_num=-1,
                           name='patch'),
        pre_pos=-1,
    ) == _build_version_info('8.9.10')

# Generated at 2022-06-23 18:21:17.015835
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.3.4'
    obj = _VersionInfo(
        version,
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major',
        ),
        _VersionPart(
            pos=1,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='minor',
        ),
        _VersionPart(
            pos=2,
            txt='4',
            num=4,
            pre_txt='',
            pre_num=-1,
            name='patch',
        ), -1
    )
    assert obj.version == version
    assert obj.major.pos == 0
    assert obj.major

# Generated at 2022-06-23 18:21:26.599417
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=missing-docstring
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:21:39.433025
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:21:49.172620
# Unit test for function bump_version
def test_bump_version():

    """Unit test for function bump_version."""

    # pylint: disable=I0011,E1129,C0116
    import pytest
    from flutils.packages import bump_version

    # Test: bump_version

# Generated at 2022-06-23 18:21:57.313132
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Test that the constructor returns the correct information
    version = '2.1.0a1'
    ver_info = _build_version_info(version)
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '2'
    assert ver_info.major.num == 2
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '1a1'
    assert ver_info.minor.num == 1
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 1
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == ''
    assert ver_info.patch.num == 0
    assert ver_info.patch.pre_txt

# Generated at 2022-06-23 18:22:10.161828
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    o = _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert o.pos == 0
    assert o.txt == '0'
    assert o.num == 0
    assert o.pre_txt == ''
    assert o.pre_num == -1
    assert o.name == 'major'
    assert repr(o) == (
        "VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major')"
    )
    assert str(o) == '(0, 0, 0, '', -1, major)'


# Generated at 2022-06-23 18:22:22.171185
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of :class:`_VersionInfo`"""
    ver = '1.2.3'
    ver_info = _build_version_info(ver)
    assert ver in str(ver_info)
    assert ver_info.version == ver
    major, minor, patch = ver_info.major, ver_info.minor, ver_info.patch
    assert major.name == 'major'
    assert major.pos == 0
    assert major.num == 1
    assert minor.name == 'minor'
    assert minor.pos == 1
    assert minor.num == 2
    assert patch.name == 'patch'
    assert patch.pos == 2
    assert patch.num == 3

    ver = '1.2.3a4'
    ver_info = _build_version_info(ver)
    assert ver

# Generated at 2022-06-23 18:22:35.087770
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=C0103
    version = '1.2.3a1'
    info = _VersionInfo(
        version,
        _VersionPart(
            pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
        ),
        _VersionPart(
            pos=1, txt='2a1', num=2, pre_txt='a', pre_num=1, name='minor'
        ),
        _VersionPart(
            pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
        ),
        1
    )
    assert info.version == version
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major

# Generated at 2022-06-23 18:22:45.823108
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    # pylint: disable=W0613,W0106

# Generated at 2022-06-23 18:22:49.380170
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _version_part = _VersionPart(0, '1', 1, '', -1, 'major')
    assert _version_part.pos == 0
    assert _version_part.txt == '1'
    assert _version_part.num == 1
    assert _version_part.pre_txt == ''
    assert _version_part.pre_num == -1
    assert _version_part.name == 'major'



# Generated at 2022-06-23 18:22:58.468143
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyTypeChecker
    res = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    # We have to use isinstance() instead of assertIsInstance()
    assert isinstance(res, _VersionPart)
    assert res.pos == 0
    assert res.txt == '1'
    assert res.num == 1
    assert res.pre_txt == ''
    assert res.pre_num == -1
    assert res.name == 'major'



# Generated at 2022-06-23 18:23:05.310467
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0
        assert part.num == 1
        assert part.txt == '1'
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name == 'major'

    ver_obj = StrictVersion('1.2.3a4')
    for part in _each_version_part(ver_obj):
        assert part.pos == 0
        assert part.num == 1
        assert part.txt == '1'
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name == 'major'
        break

    ver_obj = StrictVersion('1.2')

# Generated at 2022-06-23 18:23:17.966373
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    tst = _build_version_info('1.2.3')
    assert tst.version == '1.2.3'
    assert tst.major.pos == 0
    assert tst.major.txt == '1'
    assert tst.major.num == 1
    assert tst.major.pre_txt == ''
    assert tst.major.pre_num == -1
    assert tst.major.name == 'major'
    assert tst.minor.pos == 1
    assert tst.minor.txt == '2'
    assert tst.minor.num == 2
    assert tst.minor.pre_txt == ''
    assert tst.minor.pre_num == -1
    assert tst.minor.name == 'minor'

# Generated at 2022-06-23 18:23:27.873964
# Unit test for function bump_version
def test_bump_version():
    """Unit test for module 'bump_version'
    """
    from flutils.packages import bump_version

    def _assert(
            s_version: str,
            position: Union[int, None],
            pre_release: Union[str, None],
            s_expected: str
    ) -> None:
        assert bump_version(s_version, position, pre_release) == s_expected

    _assert('1.2.2', None, None, '1.2.3')
    _assert('1.2.3', 1, None, '1.3')
    _assert('1.3.4', 0, None, '2.0')
    _assert('1.2.3', None, 'a', '1.2.4a0')

# Generated at 2022-06-23 18:23:30.996992
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert cast(_VersionPart, ())



# Generated at 2022-06-23 18:23:43.455460
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    ) == _build_version_info('1.2.3')

# Generated at 2022-06-23 18:23:55.190325
# Unit test for function bump_version
def test_bump_version():
    '''
    Unit test for the function bump_version

    '''
    # pragma: no cover
    try:
        # noinspection PyUnusedLocal
        bump_version('1.2.3', position='a')
    except ValueError:
        pass
    else:
        print('1')

    try:
        # noinspection PyUnusedLocal
        bump_version('1.2.3', position=3)
    except ValueError:
        pass
    else:
        print('1')

    try:
        # noinspection PyUnusedLocal
        bump_version('1.2.3', position=2, pre_release='a')
    except ValueError:
        pass
    else:
        print('1')


# Generated at 2022-06-23 18:24:06.476101
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import unittest

    class Test__VersionPart(unittest.TestCase):
        """Unit test for constructor of class _VersionPart"""

        def test__should_create_no_pre_release_part(self):
            """Should create an _VersionPart instance with no pre-release."""
            input_data = {
                'pos': 0,
                'txt': '12',
                'num': 12,
                'pre_txt': '',
                'pre_num': -1,
                'name': 'major'
            }
            part = _VersionPart(**input_data)
            for k, v in input_data.items():
                self.assertEqual(v, getattr(part, k))


# Generated at 2022-06-23 18:24:17.238298
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function `bump_version`.

    This unit test uses the pytest framework (https://docs.pytest.org/).

    *New in version 0.3*

    """
    import pytest

    # All versions are tested with no prerelease bump

# Generated at 2022-06-23 18:24:28.373398
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function ``bump_version``."""
    # noinspection PyUnusedLocal
    def _test(
            version: str,
            position: int = 2,
            pre_release: str = '',
            should_raise: bool = False
    ) -> None:
        try:
            if pre_release.strip() != '':
                pre_release = pre_release.strip().lower()
            else:
                pre_release = None
            out = bump_version(version, position, pre_release)
            assert out
        except Exception:
            if should_raise is False:
                raise
    _test('1.2.2', 2)
    _test('1.2.3', position=1)
    _test('1.3.4', position=0)

# Generated at 2022-06-23 18:24:39.505752
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=C0103
    VersionInfo = _VersionInfo

    assert VersionInfo(version='1.2.3', major=None, minor=None, patch=None,
                       pre_pos=-1) == VersionInfo('1.2.3',
                                                  _VersionPart(0, '1', 1, '',
                                                               -1, 'major'),
                                                  _VersionPart(1, '2', 2, '',
                                                               -1, 'minor'),
                                                  _VersionPart(2, '3', 3, '',
                                                               -1, 'patch'),
                                                  -1)


# Generated at 2022-06-23 18:24:48.576693
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0212
    part = _VersionPart(0, '1', 1, 'a', 0, 'major')
    assert part._asdict() == {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': 'a',
        'pre_num': 0,
        'name': 'major',
    }
    part = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert part._asdict() == {
        'pos': 1,
        'txt': '2',
        'num': 2,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'minor',
    }

# Generated at 2022-06-23 18:24:55.394776
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('2.1.3')
    for part in _each_version_part(ver_obj):
        pass
    assert part.pos == 2 and part.txt == '3' and part.num == 3 and part.pre_txt == '' and part.pre_num == -1 and part.name == 'patch'


# Generated at 2022-06-23 18:25:03.836420
# Unit test for function bump_version
def test_bump_version():
    """ Unit tests for bump_version()
    """
    version = '1.2.3'
    position = 2
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out == '1.2.4'

    version = '1.2.3'
    position = 1
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out == '1.3'

    version = '1.3.4'
    position = 0
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out == '2.0'

    version = '1.2.3'
    position = 2
    pre_release = 'a'

# Generated at 2022-06-23 18:25:12.534744
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert isinstance(part.pos, int)
        if part.pos == 0:
            assert part.txt == '1'
            assert part.num == 1
            assert part.pre_txt == ''
            assert part.pre_num == -1
        if part.pos == 1:
            assert part.txt == '2'
            assert part.num == 2
            assert part.pre_txt == ''
            assert part.pre_num == -1
        if part.pos == 2:
            assert part.txt == '3'
            assert part.num == 3
            assert part.pre_txt == ''
            assert part.pre_num == -1


# Generated at 2022-06-23 18:25:24.874052
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3')
    assert _build_version_info('1.2.3').major.num == 1
    assert _build_version_info('1.2.3').minor.num == 2
    assert _build_version_info('1.2.3').patch.num == 3
    assert _build_version_info('1.2.3').pre_pos == -1
    assert _build_version_info('1.2.4a0').minor.pre_num == 0
    assert _build_version_info('1.2.4a0').pre_pos == 1
    assert _build_version_info('1.2.4b0').minor.pre_num == 0
    assert _build_version_info('1.2.4b0').pre_pos == 1

# Generated at 2022-06-23 18:25:32.298842
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver = StrictVersion('0.0.1a0')
    parts = _each_version_part(ver)
    part = next(parts)
    assert part.pos == 0
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.name == 'major'
    part = next(parts)
    assert part.pos == 1
    assert part.txt == '0a0'
    assert part.num == 0
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'minor'
    part = next(parts)
    assert part.pos == 2
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part

# Generated at 2022-06-23 18:25:42.192803
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit testing for ``_VersionPart``.

    *New in version 0.3*

    The ``_test__VersionPart`` function unit tests the
    :obj:`_VersionPart` class.

    """
    from flutils.packages import _VersionPart
    kwargs = {
        'pos': 0,
        'txt': '4',
        'num': 4,
        'pre_txt': '-dev',
        'pre_num': 4,
        'name': 'major',
    }
    ver_part_obj: _VersionPart = _VersionPart(**kwargs)
    assert ver_part_obj.pos == 0
    assert ver_part_obj.txt == '4-dev4'
    assert ver_part_obj.num == 4
    assert ver_part_obj.pre_txt == '-dev'

# Generated at 2022-06-23 18:25:53.530319
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.pos == 2
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.name == 'patch'
    assert ver_info.pre_pos == -1
    # Pre-release version
    ver_info = _

# Generated at 2022-06-23 18:25:56.502956
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from pprint import pprint
    from flutils.packages import _build_version_info
    info = _build_version_info('1.2.3')
    pprint(info)

# Generated at 2022-06-23 18:26:03.254528
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = {
        'pos': 0,
        'txt': '0',
        'num': 0,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major',
    }
    ver_part = _VersionPart(**args)
    # Test that version part is an instance of _VersionPart
    assert isinstance(ver_part, _VersionPart)


# Unit test of function _each_version_part

# Generated at 2022-06-23 18:26:12.088734
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {'pos': 0, 'txt': '1', 'num': 1, 'pre_txt': '', 'pre_num': -1, 'name': 'major'}
    _VersionPart(**kwargs)

    def _build_part_type(pos: int, pre_txt: str, pre_num: int) -> type:
        class _Part(NamedTuple):
            pos: int
            pre_txt: str
            pre_num: int

        part: _Part = _Part(pos, pre_txt, pre_num)
        return part

    parts: List[_VersionPart] = []
    part = _build_part_type(0, '', -1)

# Generated at 2022-06-23 18:26:20.331574
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.2')
    assert info.major.num == 1
    assert info.minor.num == 2
    assert info.patch.num == 0
    assert info.patch.txt == ''

    info = _build_version_info('1.2.3')
    assert info.major.num == 1
    assert info.minor.num == 2
    assert info.patch.num == 3
    assert info.patch.txt == '3'

    info = _build_version_info('1.2a4')
    assert info.major.num == 1
    assert info.minor.num == 2
    assert info.patch.txt == ''
    assert info.minor.pre_txt == 'a'
    assert info.minor.pre_num == 4

    info = _build_version

# Generated at 2022-06-23 18:26:31.188247
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'