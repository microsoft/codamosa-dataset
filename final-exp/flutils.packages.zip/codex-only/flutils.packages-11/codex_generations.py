

# Generated at 2022-06-23 18:16:38.818271
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=W0613

    ver_obj = StrictVersion('1.2.3')
    for each_part in _each_version_part(ver_obj):
        assert each_part.pos == 0 or each_part.pos == 1 or each_part.pos == 2
        assert each_part.txt == '%s' % each_part.num
        assert each_part.pre_txt == ''
        assert each_part.pre_num == -1

    ver_obj = StrictVersion('1.2.0')
    for each_part in _each_version_part(ver_obj):
        assert each_part.pos == 0 or each_part.pos == 1 or each_part.pos == 2
        assert each_part.txt == '%s' % each_part.num
        assert each_part

# Generated at 2022-06-23 18:16:45.776565
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``.
    """
    import sys
    import unittest
    import unittest.mock as mock

    class TestFlutilsPackagesBumpVersion(unittest.TestCase):
        """Test class for function ``bump_version``.
        """
        @staticmethod
        @mock.patch('flutils.packages._build_version_info')
        @mock.patch('flutils.packages._build_version_bump_type')
        def test_bump_version_patch(
                mock_build_version_bump_type,
                mock_build_version_info
        ):
            """Test 'patch' bump.
            """

# Generated at 2022-06-23 18:16:47.988274
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(0, '0', 0, '', -1, 'major')
    assert part.pos == 0
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'


# Generated at 2022-06-23 18:16:56.040767
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

    ver_info = _build_version_info('1.2.3b4')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.minor.pre_txt == 'b'
    assert ver_info.minor.pre_num == 4

    ver_info = _

# Generated at 2022-06-23 18:17:03.798421
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for :func:`flutils.packages.bump_version`."""
    from flutils.packages import _BUMP_VERSION_MAJOR
    from flutils.packages import _BUMP_VERSION_MINOR
    from flutils.packages import _BUMP_VERSION_PATCH

    from flutils.packages import bump_version

    ###########################################################################
    # _build_version_bump_position

    with pytest.raises(ValueError):
        bump_version('1.2.3', position=-4)

    with pytest.raises(ValueError):
        bump_version('1.2.3', position=3)

    ###########################################################################
    # _build_version_bump_type


# Generated at 2022-06-23 18:17:07.642623
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart.

    :rtype: None

    """
    ver = StrictVersion('1.2.3')
    for part in _each_version_part(ver):
        _VersionPart(**part._asdict())



# Generated at 2022-06-23 18:17:17.781479
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    the_func = _VersionPart
    # Test exception
    the_kwargs = dict(
        pos='bad',
        txt='bad',
        num='bad',
        pre_txt='bad',
        pre_num='bad',
        name='bad'
    )
    try:
        the_func(**the_kwargs)
    except TypeError as err:
        err_msg = str(err)

# Generated at 2022-06-23 18:17:23.022835
# Unit test for function bump_version

# Generated at 2022-06-23 18:17:24.612481
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2')



# Generated at 2022-06-23 18:17:36.882356
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.3.0') == _VersionInfo(
        '1.3.0',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '3', 3, '', -1, 'minor'),
        _VersionPart(2, '0', 0, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-23 18:17:42.731916
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test

    Raises:
        AssertionError: if a unit test fails

    Returns:
        None

    """
    # Version number string to test.

# Generated at 2022-06-23 18:17:51.295763
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        '1.2.3',
        _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        _VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        _VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        -1
    ) == _build_version_info('1.2.3')


# Generated at 2022-06-23 18:18:03.266404
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    # noinspection PyUnresolvedReferences
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1


# Generated at 2022-06-23 18:18:12.048559
# Unit test for function bump_version
def test_bump_version():
    # Happy path
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0')

# Generated at 2022-06-23 18:18:15.520221
# Unit test for function bump_version
def test_bump_version():
    """Run test for function bump_version."""
    from os import sys
    from flutils.packages import bump_version
    out = bump_version(sys.version)
    print('out:', out)


# Make the module executable.

if __name__ == "__main__":
    raise SystemExit(test_bump_version())

# Generated at 2022-06-23 18:18:24.079101
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart"""
    # pylint: disable=C0103
    assert _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='a',
        pre_num=1,
        name='minor'
    )


# Generated at 2022-06-23 18:18:33.335940
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert isinstance(part.txt, str)
        assert part.num > -1
        assert part.pre_txt in ('', 'a', 'b')
        assert part.pre_num in (-1, 0)
        assert part.name in ('major', 'minor', 'patch')

    ver_obj = StrictVersion('1.2.3a0')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert isinstance(part.txt, str)
        assert part.num > -1

# Generated at 2022-06-23 18:18:43.976837
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    fn = bump_version
    # noinspection PyTypeChecker
    res: _VersionInfo = _build_version_info('1.2.3')
    assert res == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
        ),
        minor=_VersionPart(
            pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
        ),
        patch=_VersionPart(
            pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
        ),
        pre_pos=-1
    )
    res = _build_version_

# Generated at 2022-06-23 18:18:53.585702
# Unit test for function bump_version
def test_bump_version():   # noqa: D103
    _version: str = '1.2.3'
    _version_bumped: str = bump_version(_version)
    assert _version_bumped == '1.2.4'
    _version_bumped = bump_version(_version, position=1)
    assert _version_bumped == '1.3'
    _version_bumped = bump_version(_version, position=0)
    assert _version_bumped == '2.0'
    _version_bumped = bump_version(_version, pre_release='a')
    assert _version_bumped == '1.2.4a0'
    _version_bumped = bump_version(_version_bumped, pre_release='a')
    assert _version_bumped == '1.2.4a1'
    _version

# Generated at 2022-06-23 18:19:04.771683
# Unit test for function bump_version
def test_bump_version():
    """Simple unit test for function: bump_version()

    *New in version 0.3*

    """
    # pylint: disable=R0914,W0212
    from flutils._compat import IS_PY2

    if IS_PY2 is False:
        # Test basic versions
        assert bump_version('1.0.0') == '1.0.1'
        assert bump_version('1.1.1') == '1.1.2'
        assert bump_version('1.2.1') == '1.2.2'
        assert bump_version('1.2.1', position=1) == '1.3'
        assert bump_version('1.2.1', position=0) == '2.0'
        # Test alpha pre-release versions

# Generated at 2022-06-23 18:19:06.547763
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # noinspection PyUnusedLocal
    from flutils.packages import _VersionPart



# Generated at 2022-06-23 18:19:16.251446
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0612,W0613
    ver_info = _build_version_info('1.2.3.4')
    ver_info = _build_version_info('1.2.3-a0')
    ver_info = _build_version_info('1.2b0-a0')
    ver_info = _build_version_info('1.2a1')
    ver_info = _build_version_info('1.2-a1')
    ver_info = _build_version_info('1.2a1.4')
    ver_info = _build_version_info('1.2.3-a1.4')

# Generated at 2022-06-23 18:19:26.677201
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0612
    """Tests for the package version bumping function."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:19:31.283495
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args = {
        'pos': 2,
        'txt': '2',
        'num': 2,
        'pre_txt': 'a',
        'pre_num': 1,
        'name': 'patch'
    }
    vp = _VersionPart(**args)
    assert isinstance(vp, _VersionPart)
    for k, v in args.items():
        assert getattr(vp, k) == v



# Generated at 2022-06-23 18:19:41.636279
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '2', 2, '', -1, 'major')
    assert _VersionPart(1, '3', 3, '', -1, 'minor')
    assert _VersionPart(2, '4', 4, '', -1, 'patch')
    assert _VersionPart(1, '1b0', 1, 'b', 0, 'minor')
    assert _VersionPart(1, '1b1', 1, 'b', 1, 'minor')
    assert _VersionPart(1, '1a0', 1, 'a', 0, 'minor')
    assert _VersionPart(1, '1a1', 1, 'a', 1, 'minor')



# Generated at 2022-06-23 18:19:51.927050
# Unit test for function bump_version
def test_bump_version():
    """Unit test for 'bump_version'."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:56.342885
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """
    _VersionPart:
    """
    import pytest

    args: Dict[str, Any] = {
        'pos': 0,
        'txt': '0',
        'num': 0,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    assert _VersionPart(**args) == _VersionPart(**args)



# Generated at 2022-06-23 18:20:08.152869
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                     name='major'),
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1,
                     name='minor'),
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1,
                     name='patch'),
        -1
    )

# Generated at 2022-06-23 18:20:19.384279
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import io
    import unittest
    from unittest.mock import patch

    class TestVersionPart(unittest.TestCase):
        def test_equal(self):
            arg_pos = 10
            arg_txt = 'some text'
            arg_num = 100
            arg_pre_txt = 'pre text'
            arg_pre_num = 200
            arg_name = 'some name'
            position = _VersionPart(
                pos=arg_pos,
                txt=arg_txt,
                num=arg_num,
                pre_txt=arg_pre_txt,
                pre_num=arg_pre_num,
                name=arg_name
            )
            self.assertEqual(position.pos, arg_pos)
            self.assertEqual(position.txt, arg_txt)
           

# Generated at 2022-06-23 18:20:32.355476
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    parts = list(_each_version_part(StrictVersion('1.2.3')))
    assert parts[0] == _VersionPart(0, '1', 1, '', -1, 'major')
    assert parts[1] == _VersionPart(1, '2', 2, '', -1, 'minor')
    assert parts[2] == _VersionPart(2, '3', 3, '', -1, 'patch')

    parts = list(_each_version_part(StrictVersion('1.2.0')))
    assert parts[0] == _VersionPart(0, '1', 1, '', -1, 'major')
    assert parts[1] == _VersionPart(1, '2', 2, '', -1, 'minor')

# Generated at 2022-06-23 18:20:45.041048
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=missing-function-docstring
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-arguments
    # pylint: disable=invalid-name

    def _run_test(in_version, out_version, position=2):
        assert bump_version(in_version, position) == out_version

    _run_test('1.2.2', '1.2.3')
    _run_test('1.2.3', '1.3', position=1)

# Generated at 2022-06-23 18:20:54.637752
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class :class:`_VersionPart`."""
    from unittest import TestCase
    from unittest.mock import patch

    with patch.object(_VersionPart, '__new__', return_value=None) as patched:
        version_part = _VersionPart(
            pos=0,
            txt='foo',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='bar'
        )
        assert version_part is None
        patched.assert_called_once_with(
            _VersionPart,
            pos=0,
            txt='foo',
            num=0,
            pre_txt='',
            pre_num=-1,
            name='bar'
        )



# Generated at 2022-06-23 18:20:56.508137
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.0')



# Generated at 2022-06-23 18:21:09.248096
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:13.405741
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args = ['1.2.3', '1', '2', '0', 2]
    ver_info = _VersionInfo(*args)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.txt == '1'
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1

# Generated at 2022-06-23 18:21:23.917699
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info
    import unittest.mock

    class _MockVersionPart:

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'

    a = _MockVersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert ver_info.major == a


# Generated at 2022-06-23 18:21:36.972293
# Unit test for function bump_version
def test_bump_version():
    """Test the function, bump_version."""

# Generated at 2022-06-23 18:21:47.412718
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = _build_version_info('0.0.0')
    assert version.version == '0.0.0'
    assert version.major.txt == '0'
    assert version.minor.txt == '0'
    assert version.patch.txt == ''
    assert version.pre_pos == -1

    version = _build_version_info('0.0.1')
    assert version.version == '0.0.1'
    assert version.major.txt == '0'
    assert version.minor.txt == '0'
    assert version.patch.txt == '1'
    assert version.pre_pos == -1

    version = _build_version_info('0.1')
    assert version.version == '0.1'
    assert version.major.txt == '0'

# Generated at 2022-06-23 18:21:51.422351
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from types import SimpleNamespace
    args = [0, '1', 1, '', -1, 'major']
    obj = _VersionPart(*args)
    for pos, key in enumerate(args):
        assert obj[pos] == key
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'
    obj2 = SimpleNamespace(
        pos=3,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='patch'
    )
    obj = _VersionPart(obj2)
    assert obj.pos == 3
    assert obj.txt == '0'

# Generated at 2022-06-23 18:21:58.972565
# Unit test for function bump_version
def test_bump_version():
    # New in version 0.3
    ver = bump_version('1.2.2')
    assert ver == '1.2.3'
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    ver = bump_version('1.3.4', position=0)
    assert ver == '2.0'
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    ver = bump_version('1.2.4a0', pre_release='a')
    assert ver == '1.2.4a1'
    ver = bump_version('1.2.4a1', pre_release='b')
    assert ver == '1.2.4b0'
    ver

# Generated at 2022-06-23 18:22:11.739299
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function "bump_version"."""
    version: str
    output: str
    version = '1.2.2'
    output = bump_version(version)
    assert output == '1.2.3'
    version = '1.2.3'
    output = bump_version(version, position=1)
    assert output == '1.3'
    version = '1.3.4'
    output = bump_version(version, position=0)
    assert output == '2.0'
    version = '1.2.3'
    output = bump_version(version, prerelease='a')
    assert output == '1.2.4a0'
    version = '1.2.4a0'
    output = bump_version(version, pre_release='a')

# Generated at 2022-06-23 18:22:21.528683
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ctor_args: Dict[str, Any] = dict(pos=0, txt='0', num=0,
                                     pre_txt='', pre_num=-1, name='major')
    obj = _VersionPart(**ctor_args)
    assert obj.pos == ctor_args['pos']
    assert obj.txt == ctor_args['txt']
    assert obj.num == ctor_args['num']
    assert obj.pre_txt == ctor_args['pre_txt']
    assert obj.pre_num == ctor_args['pre_num']
    assert obj.name == ctor_args['name']


# Generated at 2022-06-23 18:22:30.514797
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_info = _build_version_info('1.2.3')
    part = ver_info.patch
    assert part.pos == 2
    assert part.txt == '3'
    assert part.num == 3
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'patch'
    ver_info = _build_version_info('1.2.3b2')
    part = ver_info.patch
    assert part.pos == 2
    assert part.txt == '3b2'
    assert part.num == 3
    assert part.pre_txt == 'b'
    assert part.pre_num == 2
    assert part.name == 'patch'

# Generated at 2022-06-23 18:22:36.717881
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Tests the ``_VersionPart`` class constructor."""
    part = _VersionPart(0, '1', 1, '', -1, 'major')
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:22:46.817674
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('0.0.0')
    out = list(_each_version_part(ver_obj))
    assert len(out) == 3
    assert out[0].pos == 0
    assert out[1].pos == 1
    assert out[2].pos == 2
    assert out[0].num == 0
    assert out[1].num == 0
    assert out[2].num == 0
    assert out[0].txt == '0'
    assert out[1].txt == ''
    assert out[2].txt == ''
    assert out[0].name == 'major'
    assert out[1].name == 'minor'
    assert out[2].name == 'patch'
    ver_obj = StrictVersion('1.2.3')

# Generated at 2022-06-23 18:22:49.479815
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    expected = _VersionPart(1, '1', 1, '', -1, 'minor')
    actual = _VersionPart(1, '1', 1, '', -1, 'minor')
    assert actual == expected


# Generated at 2022-06-23 18:23:00.907549
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:23:09.683081
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2') == _VersionInfo(
        '1.2',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'),
        -1,
    )

# Generated at 2022-06-23 18:23:22.204013
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    form = (
        '{\n'
        '    "pos": %(pos)s,\n'
        '    "txt": %(txt)r,\n'
        '    "num": %(num)s,\n'
        '    "pre_txt": %(pre_txt)r,\n'
        '    "pre_num": %(pre_num)s,\n'
        '    "name": %(name)r\n'
        '}'
    )
    out_list: List[str] = []
    for part in _each_version_part(StrictVersion('1.2a0')):
        out_list.append(form % part._asdict())

# Generated at 2022-06-23 18:23:27.061263
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    ver_obj = StrictVersion(version)
    pre_pos = -1
    args: List[Any] = [version]
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            pre_pos = part.pos
        args.append(part)
    args.append(pre_pos)
    return _VersionInfo(*args)

# Generated at 2022-06-23 18:23:38.500301
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from hypothesis import (
        assume,
        given,
        settings,
        strategies as st
    )

    from flutils.packages import _VersionInfo  # pylint: disable=E0611,W0611

    # Test the constructor

# Generated at 2022-06-23 18:23:43.667495
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(0, '0', 0, '', -1, 'major')
    assert vp.pos == 0
    assert vp.txt == '0'
    assert vp.num == 0
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'major'



# Generated at 2022-06-23 18:23:45.265781
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '', -1, '', -1, '')



# Generated at 2022-06-23 18:23:56.896479
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function."""
    from sys import version_info as py_version
    from os import path
    from time import time
    from random import randint
    from platform import system
    from importlib import reload
    from textwrap import dedent
    from tempfile import TemporaryDirectory
    from flutils.packages import bump_version

    reload_needed = False
    if py_version >= (3, 8):
        reload_needed = True

    def get_version_stores():
        """Gets the temporary version stores."""
        files = [path.join('test_data', 'version_data', x)
                 for x in ('version.txt', 'version.py', 'version.cfg')]
        paths = []

# Generated at 2022-06-23 18:24:08.020265
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.4a0')
    assert ver_info.version == '1.2.4a0'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 4
    assert ver_info.patch.pre_txt == 'a'
    assert ver_info.patch.pre_num == 0
    assert ver_info.pre_pos == 2
    assert ver_info.patch.name == 'patch'
    assert str(ver_info.minor) == 'VersionPart(pos=1, txt=\'2\', num=2, pre_txt=\'\', pre_num=-1, name=\'minor\')'


# Generated at 2022-06-23 18:24:19.737351
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from sys import version_info
    if (version_info < (3, 5)):
        import unittest2 as unittest
    else:
        import unittest

    class Test_VersionInfo(unittest.TestCase):
        """

        """

        # noinspection PyPep8Naming
        def setUp(self):
            self.version_info: _VersionInfo = None

        # noinspection PyPep8Naming
        def tearDown(self):
            self.version_info = None

        def test_with_no_prerelease(self):
            """

            """
            ver_info = _build_version_info('1.2.3')
            self.assertIsInstance(ver_info, _VersionInfo)

        def test_with_prerelease(self):
            """

            """


# Generated at 2022-06-23 18:24:28.131993
# Unit test for function bump_version
def test_bump_version():
    """Tests the function bump_version."""
    ver = '1.2.2'
    exp = '1.2.3'
    assert bump_version(ver) == exp

    ver = '1.2.3'
    exp = '1.3'
    assert bump_version(ver, position=1) == exp

    ver = '1.3.4'
    exp = '2.0'
    assert bump_version(ver, position=0) == exp

    ver = '1.2.3'
    exp = '1.2.4a0'
    assert bump_version(ver, prerelease='a') == exp

    ver = '1.2.4a0'
    exp = '1.2.4a1'
    assert bump_version(ver, pre_release='a') == exp

   

# Generated at 2022-06-23 18:24:31.436601
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1')
    _build_version_info('1.2')
    _build_version_info('1.2.3')
    _build_version_info('1.2.3.4')

# Generated at 2022-06-23 18:24:38.500838
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch')
    _VersionPart(pos=1, txt='1', num=1, pre_txt='a', pre_num=0, name='minor')
    _VersionPart(pos=2, txt='1', num=1, pre_txt='a', pre_num=0, name='patch')

# Generated at 2022-06-23 18:24:48.364796
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp01 = _VersionPart(pos=0, num=1, txt='1', pre_txt='', pre_num=-1, name='major')
    vp02 = _VersionPart(pos=1, num=2, txt='2', pre_txt='', pre_num=-1, name='minor')
    vp03 = _VersionPart(pos=2, num=3, txt='3', pre_txt='', pre_num=-1, name='patch')
    vp04 = _VersionPart(pos=1, num=1, txt='1', pre_txt='a', pre_num=0, name='minor')
    vp05 = _VersionPart(pos=1, num=1, txt='1a0', pre_txt='a', pre_num=0, name='minor')

# Generated at 2022-06-23 18:25:00.170426
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:25:07.341605
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    tester = _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert tester.pos == 0
    assert tester.txt == '1'
    assert tester.num == 1
    assert tester.pre_txt == ''
    assert tester.pre_num == -1
    assert tester.name == 'major'



# Generated at 2022-06-23 18:25:18.991525
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _build_version_info('1.5.1')
    assert ver.version == '1.5.1'
    assert ver.major.pos == 0
    assert ver.major.txt == '1'
    assert ver.major.num == 1
    assert ver.major.pre_num == -1
    assert ver.major.pre_txt == ''
    assert ver.major.name == 'major'
    assert ver.minor.pos == 1
    assert ver.minor.txt == '5'
    assert ver.minor.num == 5
    assert ver.minor.pre_num == -1
    assert ver.minor.pre_txt == ''
    assert ver.minor.name == 'minor'
    assert ver.patch.pos == 2
    assert ver.patch.txt == '1'
   

# Generated at 2022-06-23 18:25:20.468531
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import doctest

    doctest.testmod(verbose=1)

# Generated at 2022-06-23 18:25:22.349638
# Unit test for constructor of class _VersionPart
def test__VersionPart(): # pylint: disable=W0613
    return True



# Generated at 2022-06-23 18:25:31.290582
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnresolvedReferences
    """Unit testing for class _VersionInfo."""
    ver = _build_version_info('1.0.0')
    assert ver.version == '1.0.0'
    assert ver.major.pos == 0
    assert ver.major.txt == '1'
    assert ver.major.num == 1
    assert ver.major.pre_txt == ''
    assert ver.major.pre_num == -1
    assert ver.major.name == 'major'
    assert ver.minor.pos == 1
    assert ver.minor.txt == '0'
    assert ver.minor.num == 0
    assert ver.minor.pre_txt == ''
    assert ver.minor.pre_num == -1
    assert ver.minor.name == 'minor'


# Generated at 2022-06-23 18:25:41.615488
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('2.1')
    assert ver_info.version == '2.1'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '2'
    assert ver_info.major.num == 2
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '1'
    assert ver_info.minor.num == 1
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name == 'minor'

# Generated at 2022-06-23 18:25:49.341931
# Unit test for function bump_version
def test_bump_version():
    from flutils.common import capture_output

    def _check(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            out: str = '',
            exc_type: Optional[str] = None,
            exc_msg: str = ''
    ) -> None:
        if exc_type is not None:
            with capture_output() as (stdout, stderr):
                with pytest.raises(exc_type) as exc_info:
                    bump_version(version, position, pre_release)
                exc_info_msg = exc_info.value.args[0]
        else:
            with capture_output() as (stdout, stderr):
                val = bump_version(version, position, pre_release)

# Generated at 2022-06-23 18:26:01.150626
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from sys import version_info
    if version_info < (3, 7):
        from unittest import TestCase, TextTestRunner
        from unittest import SkipTest
        from unittest.mock import Mock
    else:
        from unittest import TestCase, TextTestRunner, SkipTest
        from unittest.mock import Mock

    import flutils.packages as fup

    class Test__VersionInfo(TestCase):
        """Unit tests for the class constructor _VersionInfo()."""

        def test__VersionInfo__init__(self):
            """Test _VersionInfo.__init__."""

# Generated at 2022-06-23 18:26:10.757544
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():

    expected1 = _VersionInfo('0.0.1', _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major'), _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'), _VersionPart(pos=2, txt='1', num=1, pre_txt='', pre_num=-1, name='patch'), -1)
    assert _build_version_info('0.0.1') == expected1


# Generated at 2022-06-23 18:26:23.103209
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from copy import copy

    from pytest import raises  # type: ignore

    args = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major',
    }
    kwargs = copy(args)
    kwargs['name'] = 'foo'
    with raises(TypeError) as err:
        _VersionPart(**kwargs)
    assert str(err.value) == "Unknown keyword arguments: 'name'."

    args['pos'] = 'foo'
    kwargs = copy(args)
    with raises(TypeError) as err:
        _VersionPart(**kwargs)

# Generated at 2022-06-23 18:26:32.730958
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=E0511,E0401
    from flutils.packages import bump_version
    from flutils.testing import assert_equal

    def test_basic(version, position, pre_release, expected):
        # noinspection PyUnresolvedReferences
        tdata = locals()
        rtn = bump_version(**tdata)
        assert_equal(expected, rtn, **tdata)
