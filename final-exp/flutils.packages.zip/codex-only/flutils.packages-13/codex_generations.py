

# Generated at 2022-06-23 18:16:34.686011
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='major'
    ) == _VersionPart(
        *(0, '3', 3, '', -1, 'major')
    )



# Generated at 2022-06-23 18:16:41.158230
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from unittest import mock
    ver_obj = mock.Mock()
    ver_obj.version = (1, 2, 3)
    ver_obj.prerelease = ('a', 1)
    part = next(_each_version_part(ver_obj))
    assert part == _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    part = next(_each_version_part(ver_obj))
    assert part == _VersionPart(
        pos=1, txt='2a1', num=2, pre_txt='a', pre_num=1, name='minor'
    )
    part = next(_each_version_part(ver_obj))

# Generated at 2022-06-23 18:16:48.188099
# Unit test for function bump_version
def test_bump_version():
    """Test for bump_version

    *New in version 0.3*
    """
    # noinspection PyUnresolvedReferences
    from flutils.testing import run_doctest

    run_doctest(bump_version)


# =============================================================================
#
# =============================================================================

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:16:56.166586
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """ """

# Generated at 2022-06-23 18:17:02.548112
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=C0103
    prt = _VersionPart(1, '1', 1, '', -1, 'minor')
    assert prt.pos == 1
    assert prt.txt == '1'
    assert prt.num == 1
    assert prt.pre_txt == ''
    assert prt.pre_num == -1
    assert prt.name == 'minor'



# Generated at 2022-06-23 18:17:07.159324
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3a0')
    _build_version_info('1.2.3b0')


# Generated at 2022-06-23 18:17:16.915822
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {
        'pos': 0,
        'txt': '0',
        'num': 0,
        'pre_txt': 'x',
        'pre_num': 5,
        'name': 'major'
    }
    part = _VersionPart(**kwargs)
    assert part.pos == kwargs['pos']
    assert part.txt == kwargs['txt']
    assert part.num == kwargs['num']
    assert part.pre_txt == kwargs['pre_txt']
    assert part.pre_num == kwargs['pre_num']
    assert part.name == kwargs['name']
    return



# Generated at 2022-06-23 18:17:25.307461
# Unit test for function bump_version
def test_bump_version():
    """Test the function :func:`bump_version`."""
    from flutils.packages import bump_version as bv
    assert bv('1.2.2') == '1.2.3'
    assert bv('1.2.3', position=1) == '1.3'
    assert bv('1.3.4', position=0) == '2.0'
    assert bv('1.2.3', prerelease='a') == '1.2.4a0'
    assert bv('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bv('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-23 18:17:30.191190
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=R0914,R0915
    ver_info = _build_version_info('1.2')
    assert ver_info.version == '1.2'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:17:42.001637
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _build_version_info('1.0')
    parts = list(info)
    assert info.version == '1.0'  # Version number
    assert parts[1].pos == 0      # Major position
    assert parts[1].num == 1      # Major number
    assert parts[1].txt == '1'    # Major text
    assert parts[1].name == 'major'   # Major name
    assert parts[2].pos == 1      # Minor position
    assert parts[2].num == 0      # Minor number
    assert parts[2].txt == '0'    # Minor text
    assert parts[2].name == 'minor'   # Minor name
    assert parts[3].pos == 2      # Patch position
    assert parts[3].num == 0      # Patch number
    assert parts[3].txt == ''     #

# Generated at 2022-06-23 18:17:45.743330
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=C0111
    args = (1, '1', 1, 'a', 0, 'major')
    part = _VersionPart(*args)
    assert part.pos == args[0]
    assert part.txt == args[1]
    assert part.num == args[2]
    assert part.pre_txt == args[3]
    assert part.pre_num == args[4]
    assert part.name == args[5]


# Generated at 2022-06-23 18:17:54.231162
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0, txt='1', num=1,
            pre_txt='', pre_num=-1, name='major'
        ),
        minor=_VersionPart(
            pos=1, txt='2', num=2,
            pre_txt='', pre_num=-1, name='minor'
        ),
        patch=_VersionPart(
            pos=2, txt='3', num=3,
            pre_txt='', pre_num=-1, name='patch'
        ),
        pre_pos=-1
    )

# Generated at 2022-06-23 18:18:04.586557
# Unit test for function bump_version

# Generated at 2022-06-23 18:18:15.834400
# Unit test for function bump_version
def test_bump_version():
    """Test all of the combinations for the ``bump_version`` function.

    Examples:
        >>> from flutils.packages import bump_version
        >>> test_bump_version()

    """

# Generated at 2022-06-23 18:18:19.531665
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from flutils.packages import _BUMP_VERSION_MINOR_BETA
    _VersionPart(_BUMP_VERSION_MINOR_BETA, '2', 3, 'b', 0, 'minor')

# Generated at 2022-06-23 18:18:30.917624
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo"""
    ver_info = _build_version_info('1.2.3a0')

    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.num == 1
    assert ver_info.major.txt == '1'
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.num == 2
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 0
    assert ver_info.minor.name == 'minor'

# Generated at 2022-06-23 18:18:43.059162
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:18:51.348899
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version_number = "1.2.3"
    arg = _build_version_info(version_number)
    assert arg.version == "1.2.3"
    assert arg.major.pos == 0
    assert arg.major.num == 1
    assert arg.major.txt == "1"
    assert arg.minor.pos == 1
    assert arg.minor.num == 2
    assert arg.minor.txt == "2"
    assert arg.patch.pos == 2
    assert arg.patch.num == 3
    assert arg.patch.txt == "3"
    assert arg.pre_pos == -1


# Generated at 2022-06-23 18:18:57.135252
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:07.290425
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=R0912,R0915
    """Unit test for class _VersionPart."""
    cls = _VersionPart
    obj = cls(1, '1', 1, 'a', 0, 'minor')
    assert obj.pos == 1
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == 'a'
    assert obj.pre_num == 0
    assert obj.name == 'minor'

    obj = cls(0, '1', 1, '', -1, 'major')
    assert obj.pos == 0
    assert obj.txt == '1'
    assert obj.num == 1
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'


# Unit

# Generated at 2022-06-23 18:19:18.737150
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    # pylint: disable=R0201
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1')

# Generated at 2022-06-23 18:19:29.911471
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '0.3.3.3'
    expected = (
        '0.3.3.3',
        _VersionPart(
            0, '0', 0, '', -1, 'major'
        ),
        _VersionPart(
            1, '3', 3, '', -1, 'minor'
        ),
        _VersionPart(
            2, '3', 3, '', -1, 'patch'
        ),
        -1
    )
    assert _build_version_info(version) == expected
    version = '0.3.3.3.3'

# Generated at 2022-06-23 18:19:41.641404
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    vi1 = _build_version_info('1.2.3')
    assert vi1.major.pos == 0
    assert vi1.major.txt == '1'
    assert vi1.major.num == 1

    vi2 = _build_version_info('1.2')
    assert vi2.major.pos == 0
    assert vi2.major.txt == '1'
    assert vi2.major.num == 1

    vi3 = _build_version_info('1.2a0')
    assert vi3.major.pos == 0
    assert vi3.major.txt == '1'
    assert vi3.major.num == 1
    assert vi3.minor.txt == '2a0'
    assert vi3.minor.pre_txt == 'a'
    assert vi3.pre_pos == 1

# Generated at 2022-06-23 18:19:51.927936
# Unit test for function bump_version
def test_bump_version():
    """
    >>> test_bump_version()

    """

# Generated at 2022-06-23 18:19:56.123778
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.tests import random

    args = {
        'version': __version__,
        'position': random.randint_positive(),
        'pre_release': random.choice(['a', 'alpha', 'b', 'beta', None])
    }
    bump_version(**args)


# Unit tests for function _each_version_part

# Generated at 2022-06-23 18:19:59.992690
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')



# Generated at 2022-06-23 18:20:09.918416
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('1.2.3', _VersionPart(
        0, '1', 1, '', -1, 'major'), _VersionPart(
        1, '2', 2, '', -1, 'minor'), _VersionPart(
        2, '3', 3, '', -1, 'patch'), -1)
    assert info.version == '1.2.3'
    assert info.major.pos == 0
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.major.pre_txt == ''
    assert info.major.pre_num == -1
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '2'
    assert info.minor.num == 2


# Generated at 2022-06-23 18:20:17.488251
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    t1 = _VersionPart(0, '1', 1, '', -1, 'major')
    assert t1.pos == 0
    assert t1.txt == '1'
    assert t1.num == 1
    assert t1.pre_txt == ''
    assert t1.pre_num == -1
    assert t1.name == 'major'

    t2 = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert t2.pos == 1
    assert t2.txt == '2'
    assert t2.num == 2
    assert t2.pre_txt == ''
    assert t2.pre_num == -1
    assert t2.name == 'minor'

    t3 = _VersionPart(2, '3', 3, '', -1, 'patch')

# Generated at 2022-06-23 18:20:20.750014
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0613,W0612
    _build_version_info('1.2.3')



# Generated at 2022-06-23 18:20:31.133841
# Unit test for function bump_version
def test_bump_version():
    def _test_version(
            version: str,
            value: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        func_version = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )
        assert func_version == value, (
            'bump_version() failed, got: %r, expected: %r' % (
                func_version, value
            )
        )

    _test_version('1.2.2', '1.2.3')
    _test_version('1.2.3', '1.3', position=1)
    _test_version('1.3.4', '2.0', position=0)

# Generated at 2022-06-23 18:20:39.565354
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pprint

    test_data = (
        ('1', 0, '1'),
        ('1.2', 1, '2'),
        ('1.2.3', 2, '3'),
        ('1.2.3a0', 2, '3a0'),
        ('1.2.3a1', 2, '3a1'),
        ('1.2.3b0', 2, '3b0'),
        ('1.2.3b1', 2, '3b1'),
    )

# Generated at 2022-06-23 18:20:52.025161
# Unit test for function bump_version

# Generated at 2022-06-23 18:20:58.000977
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """
    Function to test the instance creation of class _VersionPart
    """
    v = _VersionPart(2, '2', 2, '', -1, 'patch')
    assert v.pos == 2
    assert v.txt == '2'
    assert v.num == 2
    assert v.pre_txt == ''
    assert v.pre_num == -1
    assert v.name == 'patch'



# Generated at 2022-06-23 18:21:09.763318
# Unit test for function bump_version
def test_bump_version():
    """Test the ``pysvn.Svn.log`` method."""
    from flutils.packages import bump_version

    # Testing the basics

# Generated at 2022-06-23 18:21:12.877291
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    out = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert out.pos == 0
    assert out.txt == '1'
    assert out.num == 1
    assert out.pre_txt == ''
    assert out.pre_num == -1
    assert out.name == 'major'


# Generated at 2022-06-23 18:21:23.831926
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo('1.2.3',
                                                        _VersionPart(0, '1', 1, '', -1, 'major'),
                                                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                                                        _VersionPart(2, '3', 3, '', -1, 'patch'),
                                                        -1)

# Generated at 2022-06-23 18:21:36.818111
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Check major version
    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.major == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    ver_obj = _build_version_info('0.2.3')
    assert ver_obj.major == _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major')
    # Check minor version
    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.minor == _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')

# Generated at 2022-06-23 18:21:47.332519
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    # pylint: disable=R0912,R0915
    from os.path import dirname
    from os.path import realpath
    from pytest import raises

    from flutils.packages import bump_version  # noqa: E402

    dir_path = dirname(realpath(__file__))
    from flutils.pathutils import add_path_to_sys_path
    add_path_to_sys_path(dir_path)

    res = bump_version('1.2.2')
    assert res == '1.2.3'

    res = bump_version('1.2.3', position=1)
    assert res == '1.3'


# Generated at 2022-06-23 18:21:55.533251
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """
    Test the constructor for the class ``_VersionPart``.

    """
    from testutils import assert_tuple_equal
    from flutils.packages import _VersionPart, _each_version_part

    # Test record definition
    result = _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert result.pos == 0
    assert result.txt == '0'
    assert result.num == 0
    assert result.pre_txt == ''
    assert result.pre_num == -1
    assert result.name == 'major'

    # Test of `_each_version_part()`
    # pylint: disable=protected-access

# Generated at 2022-06-23 18:22:08.717946
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('0.9a7') == '1.0.0'
    assert bump_version('0.9b5') == '1.0.0'
    assert bump_version('0.9') == '1.0.0'
    assert bump_version('0.9.0') == '1.0.0'
    assert bump_version('1.0a7') == '1.0.0a8'
    assert bump_version('1.0b5') == '1.0.0b6'
    assert bump_version('1.0') == '1.0.0'
    assert bump_version('1.0.0') == '1.0.0'

# Generated at 2022-06-23 18:22:17.987941
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version_string = '1.2.3'
    info = _VersionInfo(
        version=version_string,
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )

# Generated at 2022-06-23 18:22:25.955980
# Unit test for constructor of class _VersionInfo
def test__VersionInfo(): # pylint: disable=W0613,W0102
    _build_version_info('1')
    _build_version_info('1.2')
    _build_version_info('1.2.3')
    _build_version_info('1.2.3.4')
    _build_version_info('1.2.3.4a0')
    _build_version_info('1.2.3.4b0')
    _build_version_info('1.2a0.3')
    _build_version_info('1.2b0.3')


# Unit tests for constructor of class _VersionPart

# Generated at 2022-06-23 18:22:34.266864
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import unittest
    class Test_VersionPart(unittest.TestCase):
        def test__notequal(self):
            obj = _VersionPart(0, '0', 0, '', -1, '')
            obj2 = _VersionPart(1, '1', 1, '', -1, '')
            self.assertNotEqual(obj, obj2)

        def test__equal(self):
            obj = _VersionPart(0, '0', 0, '', -1, '')
            obj2 = _VersionPart(0, '0', 0, '', -1, '')
            self.assertEqual(obj, obj2)

    unittest.main()



# Generated at 2022-06-23 18:22:45.300116
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from flutils.packages import _each_version_part

    ver_obj = StrictVersion('1.2.3')
    parts = list(
        _each_version_part(ver_obj)
    )
    part = parts[0]
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    assert repr(part) == '_VersionPart(pos=0, txt=1, num=1, pre_txt=, pre_num=-1, name=major)'
    assert str(part) == '<_VersionPart "major" 1.0>'

    ver_obj = StrictVersion('1.2.3')
   

# Generated at 2022-06-23 18:22:50.662378
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=W0613
    # Args:
    #     pos (int): The version number part position.
    #     txt (str): The text version of the number part.
    #     num (int): The number version of the number part.
    #     pre_txt (str): The text version of the pre-release part.
    #     pre_num (int): The number version of the pre-release part.
    #     name (str): The name of the version part.

    from pprint import pprint

    ver = StrictVersion('0.0.0a0')
    for part in _each_version_part(ver):
        pprint(part)


# Generated at 2022-06-23 18:22:58.031885
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('0.0.0') == \
        _VersionInfo('0.0.0', _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major'),
                     _VersionPart(pos=1, txt='0', num=0, pre_txt='', pre_num=-1, name='minor'),
                     _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch'), -1)

# Generated at 2022-06-23 18:23:04.398570
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit tests for the constructor of class :class:`_VersionPart`."""
    # noinspection PyTypeChecker
    # pylint: disable=E1123
    _VersionPart(
        0, '1', 1, '', -1, 'major'
    )
    _VersionPart(
        1, '2', 2, '', -1, 'minor'
    )
    _VersionPart(
        2, '', 0, '', -1, 'patch'
    )
    _VersionPart(
        1, '2a0', 2, 'a', 0, 'minor'
    )
    _VersionPart(
        1, '2a0', 2, 'a', 0, 'minor'
    )


# Generated at 2022-06-23 18:23:13.999998
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    output = []
    for part in _each_version_part(ver_obj):
        output.append(part)
    assert len(output) == 3
    assert output[0] == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert output[1] == _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    assert output[2] == _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch')

    ver_obj = StrictVersion('1.2a0')
    output = []

# Generated at 2022-06-23 18:23:24.593005
# Unit test for function bump_version
def test_bump_version():
    """Test bump version."""

    from random import choice
    from string import ascii_letters, digits

    import pytest

    from flutils.packages import bump_version

    positions = [-3, -2, -1, 0, 1, 2]
    for i in range(50):
        major = ''.join(
            choice(ascii_letters + digits) for _ in range(3)
        )
        minor = ''.join(
            choice(ascii_letters + digits) for _ in range(3)
        )
        patch = ''.join(
            choice(ascii_letters + digits) for _ in range(3)
        )
        v = '%s.%s.%s' % (major, minor, patch)


# Generated at 2022-06-23 18:23:27.126958
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(
        pos=1,
        txt='1',
        num=1,
        pre_txt='a',
        pre_num=2,
        name='minor'
    )


# Generated at 2022-06-23 18:23:38.860537
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from collections import namedtuple
    test_case = namedtuple('TestCase', 'version position pre_release expected')

# Generated at 2022-06-23 18:23:44.316196
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    t = _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor')
    assert t.pos == 1
    assert t.txt == '1'
    assert t.num == 1
    assert t.pre_txt == ''
    assert t.pre_num == -1
    assert t.name == 'minor'



# Generated at 2022-06-23 18:23:56.060873
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:24:06.840640
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=R0915
    def _test_case(
            version: str,
            major_pos: int,
            major_txt: str,
            major_num: int,
            major_pre_txt: str,
            major_pre_num: int,
            minor_pos: int,
            minor_txt: str,
            minor_num: int,
            minor_pre_txt: str,
            minor_pre_num: int,
            patch_pos: int,
            patch_txt: str,
            patch_num: int,
            patch_pre_txt: str,
            patch_pre_num: int,
            pre_pos: int
    ) -> None:
        version_info = _build_version_info(version)
        assert version_info.version == version
        assert version

# Generated at 2022-06-23 18:24:09.748646
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test the class _VersionPart.

    """
    _VersionPart(0, '1', 1, '', -1, 'major')



# Generated at 2022-06-23 18:24:14.911898
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version_info = _VersionInfo('1.2.3', part1, part2, part3, -1)
    assert version_info.version == '1.2.3'
    assert version_info.major == part1
    assert version_info.minor == part2
    assert version_info.patch == part3
    assert version_info.pre_pos is -1



# Generated at 2022-06-23 18:24:24.789354
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0611
    # noinspection PyUnusedLocal
    _VersionInfo('1.2.3', _VersionPart(pos=0, txt='1', num=1, pre_txt='',
                                       pre_num=-1, name='major'),
                 _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1,
                              name='minor'),
                 _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1,
                              name='patch'),
                 -1)

# Generated at 2022-06-23 18:24:35.717263
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:24:44.974163
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=invalid-name
    """Unit test for constructor of class _VersionPart.

    This function is intended to unit test the constructor of class
    _VersionPart.

    """
    from .unittools import UnitCase, UnitTestCase
    class _TestCase(_UnitCase):  # pylint: disable=too-few-public-methods
        @staticmethod
        def _call_fut(
                txt: str,
                num: int,
                pre_txt: str,
                pre_num: int,
                pos: int,
                name: str,
        ):
            from .packages import _VersionPart       # pylint: disable=E0401,E0611
            return _VersionPart(txt, num, pre_txt, pre_num, pos, name)

# Generated at 2022-06-23 18:24:51.240062
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest import TestCase
    from unittest.mock import patch

    class Test(TestCase):

        @patch('flutils.packages._each_version_part')
        def test__VersionPart__each_version_part(
                self,
                mock__each_version_part
        ):
            # pylint: disable=E1101,W0212
            import flutils.packages as mod
            pos_min = -3
            pos_max = 2
            results: List[int] = []

            # Test the test
            for pos in range(pos_min, pos_max + 1):
                results.append(_build_version_bump_position(pos))


# Generated at 2022-06-23 18:25:00.951983
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from os.path import dirname, abspath
    from flutils.fileutils import load_file_contents

    version_file = '%s/__version__.py' % dirname(abspath(__file__))
    version = load_file_contents(version_file)
    ver_obj = StrictVersion(version)
    for part in _each_version_part(ver_obj):
        assert part.pos >= 0
        assert isinstance(part.txt, str)
        assert part.num >= 0
        assert isinstance(part.pre_txt, str)
        assert part.pre_num >= -1
        assert isinstance(part.name, str)



# Generated at 2022-06-23 18:25:03.532175
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(1, '2', 2, 'a', 1, 'minor')


# Generated at 2022-06-23 18:25:12.245437
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=R0914
    """Test the constructor of class _VersionPart."""
    ver_obj = StrictVersion('0.0')
    gen = _each_version_part(ver_obj)
    part = next(gen)
    assert part.pos == 0
    assert part.name == 'major'
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == -1
    part = next(gen)
    assert part.pos == 1
    assert part.name == 'minor'
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == -1
    part = next(gen)
    assert part.pos == 2

# Generated at 2022-06-23 18:25:24.612732
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version
    """
    from flutils.packages import bump_version

    def test(
            ver: str,
            expect: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        actual = bump_version(ver, position, pre_release)
        assert actual == expect, (
            "Expected '{}', but got '{}'".format(expect, actual)
        )

    test('1.2.2', '1.2.3')
    test('1.2.3', '1.3', position=1)
    test('1.3.4', '2.0', position=0)
    test('1.2.3', '1.2.4a0', pre_release='a')
    test

# Generated at 2022-06-23 18:25:30.211062
# Unit test for function bump_version
def test_bump_version():
    import sys
    import unittest

    class TestBumpVersion(unittest.TestCase):

        maxDiff = None

        def setUp(self):
            self.version = '1.2.3'

        def test_bump_version(self):
            result = bump_version(self.version)
            self.assertEqual(result, '1.2.4')
            result = bump_version(self.version, position=1)
            self.assertEqual(result, '1.3')
            result = bump_version(self.version, position=0)
            self.assertEqual(result, '2.0')
            result = bump_version(self.version, prerelease='a')
            self.assertEqual(result, '1.2.4a0')

# Generated at 2022-06-23 18:25:41.261561
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1a'
    version_info = _build_version_info(version)

# Generated at 2022-06-23 18:25:49.140462
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from json import dumps
    from re import findall
    from sys import version_info
    from types import ModuleType
    from unittest import TestCase
    from unittest.mock import MagicMock

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    try:
        from unittest.mock import mock_open
    except ImportError:
        from mock import mock_open  # type: ignore

    flutils_module = ModuleType('flutils')
    flutils_module.__file__ = '/path/to/flutils/__init__.py'
    flutils_module.__path__ = ['/path/to/flutils']

# Generated at 2022-06-23 18:26:00.929511
# Unit test for function bump_version
def test_bump_version():
    """Test the :py:func:`~flutils.packages.bump_version` function."""

# Generated at 2022-06-23 18:26:10.610321
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=too-many-statements
    def _assert_equal(obj: _VersionPart, expected: str) -> None:
        pos = obj.pos  # type: ignore
        txt = obj.txt  # type: ignore
        num = obj.num  # type: ignore
        pre_txt = obj.pre_txt  # type: ignore
        pre_num = obj.pre_num  # type: ignore
        name = obj.name  # type: ignore
        assert pos == expected[0]  # type: ignore
        assert txt == expected[1]  # type: ignore
        assert num == expected[2]  # type: ignore
        assert pre_txt == expected[3]  # type: ignore
        assert pre_num == expected[4]  # type: ignore
        assert name == expected[5]

# Generated at 2022-06-23 18:26:22.873235
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.2')
    assert version == '1.2.3'

    version = bump_version('1.2.3', position=1)
    assert version == '1.3'

    version = bump_version('1.3.4', position=0)
    assert version == '2.0'

    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'

    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'

    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'


# Generated at 2022-06-23 18:26:32.977981
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # TYPE: (Any) -> None
    ver_obj = _build_version_info('1.2.3')
    assert ver_obj.major.pos == 0
    assert ver_obj.minor.pos == 1
    assert ver_obj.patch.pos == 2
    assert ver_obj.version == '1.2.3'
    assert ver_obj.major.txt == '1'
    assert ver_obj.minor.txt == '2'
    assert ver_obj.patch.txt == '3'
    assert ver_obj.major.num == 1
    assert ver_obj.minor.num == 2
    assert ver_obj.patch.num == 3
    assert ver_obj.major.pre_txt == ''
    assert ver_obj.minor.pre_txt == ''