

# Generated at 2022-06-23 18:16:38.872061
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    data = '1.2.3'
    _build_version_info(data)
    data = '1.2'
    _build_version_info(data)
    data = '1'
    _build_version_info(data)
    data = '1.2,a0'
    _build_version_info(data)
    data = '1.2.3,b0'
    _build_version_info(data)
    data = '1.2.3,b1'
    _build_version_info(data)
    data = '1.2.3.1'
    _build_version_info(data)
    data = '1.2.3,a01'
    _build_version_info(data)



# Generated at 2022-06-23 18:16:45.627513
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=missing-function-docstring
    from unittest import TestCase

    class _TestCase(_TestCase):
        # pylint: disable=missing-class-docstring
        version = '1.0.0'

        def test_build_part(self):
            # pylint: disable=missing-function-docstring
            expect = _VersionPart(0, '1', 1, '', -1, 'major')
            actual = _VersionPart(*_each_version_part(StrictVersion(self.version)).__next__())
            self.assertEqual(expect, actual)

    _TestCase.__name__ = '%s.%s' % (__name__, _TestCase.__name__)
    return _TestCase



# Generated at 2022-06-23 18:16:50.218835
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part_1 = _VersionPart(pos=2, txt='', num=0, pre_txt='', pre_num=-1, name='patch')
    assert part_1.pos == 2
    assert part_1.txt == ''
    assert part_1.num == 0
    assert part_1.pre_txt == ''
    assert part_1.pre_num == -1
    assert part_1.name == 'patch'

    part_2 = _VersionPart(pos=2, txt='1a0', num=1, pre_txt='a', pre_num=0, name='patch')
    assert part_2.pos == 2
    assert part_2.txt == '1a0'
    assert part_2.num == 1
    assert part_2.pre_txt == 'a'

# Generated at 2022-06-23 18:16:57.429628
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    # print('Testing function bump_version...')

    # Testing the function
    from flutils.tests.infotest import run_test

    # New and empty test
    test_case = {
        'test_id': 'a3f3a0af-c2d2-40d9-9c43-31b74a68b739',
        'description': (
            'Function bump_version, new and empty test.'
        ),
        'function': 'bump_version',
        'args': ('1.2.3', 2),
        'expected': '1.2.4',
    }
    run_test(test_case)

    # Bumping the minor version

# Generated at 2022-06-23 18:17:08.250334
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2')
    assert ver_info.major.num == 1
    assert ver_info.major.pos == 0
    assert ver_info.major.pre_num == -1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.txt == '1'
    assert ver_info.major.name == 'major'

    assert ver_info.minor.num == 2
    assert ver_info.minor.pos == 1
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.name == 'minor'

    assert ver_info.patch.num == 0
   

# Generated at 2022-06-23 18:17:19.368782
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:26.629968
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    ver_info = _build_version_info('1.2.2')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 2

    ver_info = _build_version_info('1.3.0')
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 3
    assert ver_info.patch.num == 0

    ver_info = _build_version_info('0.0.1')
    assert ver_info.major.num == 0
    assert ver_info.minor.num == 0
    assert ver_info.patch.num == 1

    ver_info = _build_version_info('1.2.3a1')

# Generated at 2022-06-23 18:17:39.274020
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:17:41.053937
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.0.0')
    _build_version_info('1.1.3b1')
    _build_version_info('1.2.3a1')

# Generated at 2022-06-23 18:17:47.043518
# Unit test for function bump_version
def test_bump_version():
    """Test that versions are bumped to the expected versions."""

# Generated at 2022-06-23 18:18:00.064461
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    test_name = 'test__VersionInfo'
    # noinspection PyUnusedLocal
    test_count = 0
    # noinspection PyUnusedLocal
    failed_count = 0

    print('\nTesting %s' % test_name)
    print('=' * len(test_name))

# Generated at 2022-06-23 18:18:12.685367
# Unit test for function bump_version

# Generated at 2022-06-23 18:18:24.855690
# Unit test for function bump_version
def test_bump_version():
    """Test function: bump_version()
    """

# Generated at 2022-06-23 18:18:33.163420
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('0.0.0', _VersionPart(0, '0', 0, '', -1, 'major'),
                        _VersionPart(1, '0', 0, '', -1, 'minor'),
                        _VersionPart(2, '0', 0, '', -1, 'patch'), -1)
    assert info.major.name == 'major'
    assert info.minor.name == 'minor'
    assert info.patch.name == 'patch'
    assert info.version == '0.0.0'
    assert info.major.txt == '0'
    assert info.minor.txt == '0'
    assert info.patch.txt == '0'
    assert info.pre_pos == -1



# Generated at 2022-06-23 18:18:42.689463
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {
        'pos': 0,
        'txt': '10',
        'num': 10,
        'pre_txt': 'b',
        'pre_num': 1,
        'name': 'major'
    }
    version_part = _VersionPart(**kwargs)
    assert isinstance(version_part, _VersionPart)
    assert version_part.pos == 0
    assert version_part.txt == '10'
    assert version_part.num == 10
    assert version_part.pre_txt == 'b'
    assert version_part.pre_num == 1
    assert version_part.name == 'major'



# Generated at 2022-06-23 18:18:52.998137
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test constructor of class _VersionInfo."""
    # Test both major and minor version positions.
    positions = [0, 1]
    # Test every possible pre-release type
    pr = ['a', 'alpha', 'b', 'beta', None]
    # Test both with and without pre-releases
    is_pre_release = [True, False]
    # Test all possible combinations
    return
    pr_is_pre = [
        (p, i)
        for p in pr
        for i in is_pre_release
    ]
    full_test_list = [
        (p, q, r)
        for p in positions
        for q in pr_is_pre
        for r in pr_is_pre
    ]

# Generated at 2022-06-23 18:19:02.870458
# Unit test for function bump_version
def test_bump_version():
    func_name = 'bump_version'
    func_ref = globals()[func_name]
    if isinstance(func_ref, classmethod):
        func_ref = func_ref.__func__
    assert callable(func_ref) is True


# Generated at 2022-06-23 18:19:06.276530
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test function/class '_VersionInfo' in module 'packages'."""
    import flutils.packages as pkg

    assert isinstance(pkg._build_version_info('1.2.3'), pkg._VersionInfo)



# Generated at 2022-06-23 18:19:17.741533
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_bump_position(-3) == 0
    assert _build_version_bump_position(-2) == 1
    assert _build_version_bump_position(-1) == 2
    assert _build_version_bump_position(0) == 0
    assert _build_version_bump_position(1) == 1
    assert _build_version_bump_position(2) == 2

    assert _build_version_bump_type(0, '') == 0
    assert _build_version_bump_type(0, 'a') == 0
    assert _build_version_bump_type(0, 'alpha') == 0
    assert _build_version_bump_type(0, 'b') == 0

# Generated at 2022-06-23 18:19:27.779279
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 18:19:35.160514
# Unit test for function bump_version
def test_bump_version():
    """Unit test for this module."""
    import sys
    import os

    import pytest

    # noinspection PyUnresolvedReferences
    from flutils.packages import (
        bump_version,
    )

    # noinspection PyUnresolvedReferences,PyUnresolvedReferences
    from flutils.test import (
        get_test_data_path,
    )

    __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__))
    )
    test_path = get_test_data_path(__location__)

    # noinspection PyUnresolvedReferences
    from flutils.test.packages import (
        test_bump_version_data,
    )


# Generated at 2022-06-23 18:19:44.459850
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit tests for the constructor of class _VersionInfo."""
    def _build_test_case(
            version: str,
            major: _VersionPart,
            minor: _VersionPart,
            patch: _VersionPart,
            pre_pos: int
    ) -> None:
        """Build a test case for _VersionInfo."""
        ver_info = _build_version_info(version)
        assert version == version
        assert major == ver_info.major
        assert minor == ver_info.minor
        assert patch == ver_info.patch
        assert pre_pos == ver_info.pre_pos


# Generated at 2022-06-23 18:19:55.973813
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    from flutils import pretty_items_print
    from flutils.textutils import split_strip
    from flutils.packages import bump_version

    errors: List[Tuple[int, Exception]] = []
    rows: List[Dict[str, Union[int, str, Exception]]] = []

# Generated at 2022-06-23 18:20:07.685824
# Unit test for function bump_version

# Generated at 2022-06-23 18:20:15.917132
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from nose.tools import ok_, assert_equal, assert_true
    from flutils.packages import _VersionPart

    assert_equal(_VersionPart(pos=0, txt='0', num=0,
                              pre_txt='', pre_num=-1, name='major').pos, 0)
    assert_equal(_VersionPart(pos=0, txt='0', num=0,
                              pre_txt='', pre_num=-1, name='major').txt, '0')
    assert_equal(_VersionPart(pos=0, txt='0', num=0,
                              pre_txt='', pre_num=-1, name='major').pre_num, -1)

# Generated at 2022-06-23 18:20:25.754998
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from .test_helpers import assert_strings_equal

    for version in (
            '1',
            '1.0',
            '1.0.0',
            '1.0.0a0',
            '1.0.0b0',
            '1.0.0rc0',
            '1.0.0.0',
    ):
        ver_obj = StrictVersion(version)
        for part in _each_version_part(ver_obj):
            assert_strings_equal(version, part.txt)
            assert_strings_equal(version, part.pre_txt)


# Generated at 2022-06-23 18:20:36.843176
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=missing-docstring
    import re
    import sys

    print(sys.version)
    print(re.search(r'[\d]+\.[\d]+\.[\d]+', sys.version).group(0))
    print(bump_version('1.2.3'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))

# Generated at 2022-06-23 18:20:47.110734
# Unit test for function bump_version

# Generated at 2022-06-23 18:20:57.465231
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:02.069075
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(pos=1, txt='1', num=1, pre_txt='', pre_num=-1, name='minor')



# Generated at 2022-06-23 18:21:11.512756
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyUnusedLocal,PyShadowingBuiltins
    def _build_version_info_helper(
            version: str,
            major_num: int,
            minor_num: int,
            patch_num: int,
            pre_pos: int
    ):
        ver_info = _build_version_info(version)
        assert isinstance(ver_info, _VersionInfo)
        assert ver_info.version == version
        assert isinstance(ver_info.major, _VersionPart)
        assert ver_info.major.num == major_num
        assert isinstance(ver_info.minor, _VersionPart)
        assert ver_info.minor.num == minor_num
        assert isinstance(ver_info.patch, _VersionPart)
        assert ver_info.patch.num == patch_num

# Generated at 2022-06-23 18:21:22.893171
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    from flutils.packages import bump_version as func
    from flutils.packages import bump_version as func2
    from flutils.packages import bump_version as func3
    from flutils.packages import bump_version as func4
    from flutils.packages import bump_version as func5
    from flutils.packages import bump_version as func6
    from flutils.packages import bump_version as func7
    from flutils.packages import bump_version as func8
    from flutils.packages import bump_version as func9
    from flutils.packages import bump_version as func10
    from flutils.packages import bump_version as func11
    from flutils.packages import bump_version as func12
    from flutils.packages import bump_version as func13

# Generated at 2022-06-23 18:21:35.305951
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    class TestVersionInfo(NamedTuple):
        ver_str: str
        major_pos: int
        major_txt: str
        major_num: int
        major_pre_txt: str
        major_pre_num: int
        major_name: str
        minor_pos: int
        minor_txt: str
        minor_num: int
        minor_pre_txt: str
        minor_pre_num: int
        minor_name: str
        patch_pos: int
        patch_txt: str
        patch_num: int
        patch_pre_txt: str
        patch_pre_num: int
        patch_name: str
        pre_pos: int


# Generated at 2022-06-23 18:21:41.176020
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test _VersionInfo constructor.

    """
    # pylint: disable=W0403,E1120,W0612,R0914
    from unittest.mock import Mock, patch
    from flutils.packages import _VersionPart, _VersionInfo

    version = '1.2.3b4'
    pre_pos = 2
    pre_txt = 'b'
    pre_num = 4
    pos = 0
    txt = '1'
    num = 1
    name = 'major'
    major = _VersionPart(pos, txt, num, pre_txt, pre_num, name)
    pos = 1
    txt = '2'
    num = 2
    name = 'minor'

# Generated at 2022-06-23 18:21:53.301517
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=C0111,W0613
    # pylint: disable=W0612,W0621,W0622
    from flutils.packages import bump_version
    from unittest import TestCase
    from textwrap import dedent

    isa = isinstance
    str_ = str

    def _run_test(fun, case):
        if isa(case, str_):
            case = dedent(case).strip()
        if isa(case, (tuple, list)):
            return fun(*case)
        else:
            return fun(case)

    class Test_bump_version(TestCase):
        def test_with_no_pre_release(self):
            bump = bump_version

# Generated at 2022-06-23 18:22:02.886246
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0b0')
    assert ver_info.pre_pos == 2
    assert ver_info.patch.pre_txt == 'b'
    ver_info = _build_version_info('3.3.3')
    assert ver_info.pre_pos == -1
    assert ver_info.major.txt == '3'
    assert ver_info.major.num == 3
    assert ver_info.minor.txt == '3'
    assert ver_info.minor.num == 3
    assert ver_info.patch.txt == '3'
    assert ver_info.patch.num == 3


# Generated at 2022-06-23 18:22:05.148327
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    return _build_version_info('1.3.3')



# Generated at 2022-06-23 18:22:15.693191
# Unit test for function bump_version
def test_bump_version():
    """Unit testing for ``bump_version``."""

# Generated at 2022-06-23 18:22:26.009689
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pprint
    from string import digits
    for version in (
        '1.0.0',
        '1.0.0a1',
        '1.2.3',
        '1.2.3a1',
        '1.2.3b1',
        '1.2.3a5',
        '1.2.3b5',
        '1.2.3a5b5',
        '1.2',
        '10.2',
        '1.10',
        '10.10'
    ):
        ver_obj = StrictVersion(version)
        print('VERSION: %s\n' % version)
        for part in _each_version_part(ver_obj):
            pprint(part)

# Generated at 2022-06-23 18:22:34.633727
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = dict(
        pos=2,
        txt='3',
        num=3,
        pre_txt='p',
        pre_num=9,
        name='minor'
    )

    ver_part = _VersionPart(**kwargs)

    assert kwargs['pos'] == ver_part.pos
    assert kwargs['txt'] == ver_part.txt
    assert kwargs['num'] == ver_part.num
    assert kwargs['pre_txt'] == ver_part.pre_txt
    assert kwargs['pre_num'] == ver_part.pre_num
    assert kwargs['name'] == ver_part.name



# Generated at 2022-06-23 18:22:45.531443
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    class UnitTest(_VersionInfo):
        def __init__(
                self,
                version: str,
                major: _VersionPart,
                minor: _VersionPart,
                patch: _VersionPart,
                pre_pos: int
        ) -> None:
            super().__init__(
                version=version,
                major=major,
                minor=minor,
                patch=patch,
                pre_pos=pre_pos
            )
    class TestArgs(_VersionPart):
        def __init__(
                self,
        ) -> None:
            super().__init__(
                pos=-1,
                txt='',
                num=-1,
                pre_txt='',
                pre_num=-1,
                name='',
            )
    # noinspection PyUnusedLocal

# Generated at 2022-06-23 18:22:51.463605
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args: List[Any] = [
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    ]
    ver_info = _VersionInfo(*args)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.minor.pos == 1
    assert ver_info.patch.pos == 2
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.major

# Generated at 2022-06-23 18:23:01.753331
# Unit test for function bump_version

# Generated at 2022-06-23 18:23:13.299118
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    obj = _build_version_info('1.2.3')
    assert obj.version == '1.2.3'
    assert obj.major.pos == 0
    assert obj.major.txt == '1'
    assert obj.major.num == 1
    assert obj.major.pre_txt == ''
    assert obj.major.pre_num == -1
    assert obj.major.name == 'major'

    assert obj.minor.pos == 1
    assert obj.minor.txt == '2'
    assert obj.minor.num == 2
    assert obj.minor.pre_txt == ''
    assert obj.minor.pre_num == -1
    assert obj.minor.name == 'minor'

    assert obj.patch.pos == 2
    assert obj.patch.txt == '3'
   

# Generated at 2022-06-23 18:23:24.866639
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.testing import SuppressWarningsMixin

    class UnitTest(SuppressWarningsMixin):

        def test_bump_version(self):
            """Test function bump_version."""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-23 18:23:36.771333
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    vp1 = _VersionPart(0, '1', 1, '', -1, 'major')
    assert vp1.pos == 0
    assert vp1.txt == '1'
    assert vp1.num == 1
    assert vp1.pre_txt == ''
    assert vp1.pre_num == -1
    assert vp1.name == 'major'
    vp2 = _VersionPart(1, '2', 2, '', -1, 'minor')
    assert vp2.pos == 1
    assert vp2.txt == '2'
    assert vp2.num == 2
    assert vp2.pre_txt == ''
    assert vp2.pre_num == -1

# Generated at 2022-06-23 18:23:41.073172
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.0.0')
    _build_version_info('1.2')
    _build_version_info('1.2.3a0')



# Generated at 2022-06-23 18:23:51.634907
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    import unittest
    import unittest.mock

    from flutils.packages import bump_version

    class Test(unittest.TestCase):
        """Test class."""


# Generated at 2022-06-23 18:24:02.482342
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from distutils.version import StrictVersion

# Generated at 2022-06-23 18:24:13.682365
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    result = _VersionPart(pos=0, txt='0', num=0, pre_txt='', pre_num=-1, name='major')
    assert result.pos == 0, result.pos
    assert result.txt == '0', result.txt
    assert result.num == 0, result.num
    assert result.pre_txt == '', result.pre_txt
    assert result.pre_num == -1, result.pre_num
    assert result.name == 'major', result.name

    result = _VersionPart(pos=1, txt='2', num=2, pre_txt='alpha', pre_num=99, name='minor')
    assert result.pos == 1, result.pos
    assert result.txt == '2alpha99', result.txt
    assert result.num == 2, result.num
    assert result

# Generated at 2022-06-23 18:24:23.126453
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:24:32.516436
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3').version == '1.2.3'
    assert _build_version_info('1.2.3a0').version == '1.2.3a0'
    assert _build_version_info('1.2.3').major.name == 'major'
    assert _build_version_info('1.2.3').minor.name == 'minor'
    assert _build_version_info('1.2.3').patch.name == 'patch'
    assert _build_version_info('1.2.3a0').pre_pos == 2



# Generated at 2022-06-23 18:24:39.143927
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    x = _VersionInfo("1.2.3", _VersionPart(0, "1", 1, "", -1, "major"),
            _VersionPart(1, "2", 2, "", -1, "minor"), _VersionPart(2, "3", 3, "",
            -1, "patch"), -1)
    y = _build_version_info("1.2.3")
    assert x == y


# Generated at 2022-06-23 18:24:48.717800
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0615
    """Unit test for function bump_version"""
    def _test_bump_version(
            given: str,
            expected: str,
            position: int,
            pre_release: Optional[str]
    ) -> None:
        result = bump_version(
            given,
            position=position,
            pre_release=pre_release
        )

# Generated at 2022-06-23 18:25:00.604217
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-23 18:25:10.363960
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    import pytest

# Generated at 2022-06-23 18:25:15.407579
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R1710
    """Test bump_version"""

    import unittest

    if __name__ == '__main__':
        unittest.main(argv=[''], verbosity=2, exit=False)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-23 18:25:27.560710
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version"""

    # pylint: disable=C0301
    # pylint: disable=C0326

    # noinspection PyUnresolvedReferences
    """
    :type _TEST_PARAMS_BUMP_VERSION: list
    """

# Generated at 2022-06-23 18:25:39.012392
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests the constructor of class :class:`flutils.packages._VersionInfo`.

    Raises:
        AssertionError: if any of the assertions fail.

    """
    from flutils.packages import _VersionInfo

    vi=_VersionInfo('1.2.3',_VersionPart(0, '1', 1, '', -1, 'major'),
                         _VersionPart(1, '2', 2, '', -1, 'minor'),
                         _VersionPart(2, '3', 3, '', -1, 'patch'),
                         -1)
    assert vi.version == '1.2.3'
    assert vi.major == _VersionPart(0, '1', 1, '', -1, 'major')

# Generated at 2022-06-23 18:25:47.679742
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    _VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='b',
        pre_num=0,
        name='minor'
    )
    _VersionPart(
        pos=2,
        txt='',
        num=0,
        pre_txt='a',
        pre_num=1,
        name='patch'
    )
    _VersionPart(
        pos=2,
        txt='',
        num=0,
        pre_txt='beta',
        pre_num=0,
        name='patch'
    )




# Generated at 2022-06-23 18:25:59.804917
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0115,C0116
    from flutils.assertfuncs import assert_equal

    # TODO: unit test this.

    def _test_bump_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            exp_out: str
    ):
        out = bump_version(version, position, pre_release)
        assert_equal(out, exp_out)
        return True


# Generated at 2022-06-23 18:26:09.883770
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('0.0.0') == _VersionInfo(
        '0.0.0',
        _VersionPart(0, '0', 0, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    )
    assert _build_version_info('1.0.0') == _VersionInfo(
        '1.0.0',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '', 0, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-23 18:26:21.728244
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    def _wrap(
            data: Tuple[str, int, int, int],
            pre_pos: int
    ) -> None:
        output = _build_version_info(data[0])
        assert output.version == data[0]
        assert output.major.num == data[1]
        assert output.minor.num == data[2]
        assert output.patch.num == data[3]
        assert output.pre_pos == pre_pos

    _wrap(('1.2.3', 1, 2, 3), -1)
    _wrap(('1.0.0a0', 1, 0, 0), 1)
    _wrap(('1.0.0a2', 1, 0, 0), 1)
    _wrap(('1.0.0b0', 1, 0, 0), 1)


# Generated at 2022-06-23 18:26:32.321387
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    major = _VersionPart(0, '1', 1, '', -1, 'major')
    minor = _VersionPart(1, '2', 2, '', -1, 'minor')
    patch = _VersionPart(2, '3', 3, '', -1, 'patch')
    pre_pos = -1
    out = _VersionInfo(version, major, minor, patch, pre_pos)
    assert out.version == '1.2.3', out.version
    assert out.major == major, out.major
    assert out.minor == minor, out.minor
    assert out.patch == patch, out.patch
    assert out.pre_pos == pre_pos, out.pre_pos

    version = '1.2.a0'
    major = _Version