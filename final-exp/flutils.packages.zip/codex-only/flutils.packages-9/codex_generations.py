

# Generated at 2022-06-23 18:16:39.944950
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from nose.tools import assert_equal
    from nose.tools import assert_true

    assert_equal(_build_version_info('1.2.3').version, '1.2.3')
    assert_equal(_build_version_info('1.2.3').major.pos, 0)
    assert_equal(_build_version_info('1.2.3').major.txt, '1')
    assert_equal(_build_version_info('1.2.3').major.num, 1)
    assert_equal(_build_version_info('1.2.3').major.pre_txt, '')
    assert_equal(_build_version_info('1.2.3').major.pre_num, -1)
    assert_equal(_build_version_info('1.2.3').minor.pos, 1)
   

# Generated at 2022-06-23 18:16:52.723543
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
        pos=0,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='major'
    )._asdict() == {
        'pos': 0,
        'txt': '2',
        'num': 2,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major',
    }

# Generated at 2022-06-23 18:17:05.298248
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # Args:
    #     pos (int): The position (starting at zero) of the
    #         version number component that the object
    #         represents.
    #     txt (str): The component's text representation.
    #     num (int): The component's number representation.
    #     pre_txt (str): The component's pre-release text
    #         component.
    #     pre_num (int): The component's  pre-release number
    #         component.
    #     name (str): The component's position name.
    ver_obj = StrictVersion('1.2.3')

# Generated at 2022-06-23 18:17:14.507967
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=C0103
    kwargs = {
        'pos': 1,
        'txt': '2',
        'num': 2,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'minor'
    }
    inst = _VersionPart(**kwargs)
    assert inst.pos == 1
    assert inst.txt == '2'
    assert inst.num == 2
    assert inst.pre_txt == ''
    assert inst.pre_num == -1
    assert inst.name == 'minor'


# Generated at 2022-06-23 18:17:23.609072
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version


# Generated at 2022-06-23 18:17:35.448945
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args: List[Any] = ['1.2.3']
    args.append(_VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    ))
    args.append(_VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor'
    ))
    args.append(_VersionPart(
        pos=2,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='patch'
    ))
    args.append(-1)
    _VersionInfo(*args)



# Generated at 2022-06-23 18:17:45.415319
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=R0204, R0914
    # noinspection PyUnresolvedReferences
    from flutils.packages import _VersionPart
    # noinspection PyUnresolvedReferences
    from flutils.packages import _each_version_part

    # _VersionPart.__init__()
    kwargs = {
        'pos': 0,
        'txt': '1',
        'num': 1,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    ver_part = _VersionPart(**kwargs)
    assert isinstance(ver_part, _VersionPart)

    # _each_version_part()

# Generated at 2022-06-23 18:17:54.070704
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.0.0')
    assert ver_info.version == '1.0.0'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '0'
    assert ver_info.minor.num == 0
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1

# Generated at 2022-06-23 18:18:04.498191
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    versions = [
        '0.0.1',
        '0.1',
        '1.2.3',
        '1.2.3a0',
        '1.2.3a1',
        '1.2.3a2',
        '1.2.3b0',
        '1.2.3b1',
        '1.2.3b2',
        '1.2.3rc0',
        '1.2.3rc1',
        '1.2.3rc2',
    ]
    for ver_str in versions:
        info = _build_version_info(ver_str)
        ver_obj = StrictVersion(ver_str)
        parts = list(_each_version_part(ver_obj))

# Generated at 2022-06-23 18:18:12.168043
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    r = _build_version_info('1.2.3')
    assert r.version == '1.2.3'
    assert r.major.pos == 0
    assert r.major.txt == '1'
    assert r.major.num == 1
    assert r.major.pre_txt == ''
    assert r.major.pre_num == -1
    assert r.major.name == 'major'
    assert r.minor.pos == 1
    assert r.minor.txt == '2'
    assert r.minor.num == 2
    assert r.minor.pre_txt == ''
    assert r.minor.pre_num == -1
    assert r.minor.name == 'minor'
    assert r.patch.pos == 2
    assert r.patch.txt == '3'
   

# Generated at 2022-06-23 18:18:21.540343
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for bump_version.

    Returns:
        bool: True if the unit test succeeds.

    """
    from flutils.testing import BasicUnitTest
    from flutils.packages import bump_version

    ut = BasicUnitTest()

    ut.assert_equals(bump_version('1.2.2'), '1.2.3')
    ut.assert_equals(bump_version('1.2.3', position=1), '1.3')
    ut.assert_equals(bump_version('1.3.4', position=0), '2.0')
    ut.assert_equals(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-23 18:18:31.765755
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _build_version_info # pylint: disable=E0611,E0401

    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''

# Generated at 2022-06-23 18:18:35.624704
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        print(part)


# Generated at 2022-06-23 18:18:40.603477
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(pos=0, txt='3', num=3, pre_txt='', pre_num=-1, name='major')
    assert obj.pos == 0
    assert obj.txt == '3'
    assert obj.num == 3
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'


# Generated at 2022-06-23 18:18:51.418748
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # noinspection PyUnresolvedReferences
    from flutils.tests.base import TestCase, mock

    class _TestCase(TestCase):
        def test_bump_version(self):
            # noinspection PyUnresolvedReferences
            from flutils.dates import now
            from flutils.packages import bump_version
            from flutils.strings import to_str
            # Testing negative position
            args = ('1.2.0', -2, None)
            self.assertEqual(
                bump_version(*args),
                '2.0',
                msg=("Testing mode: %s, Position: '-2', "
                     "Pre-release: 'None'." % list(args))
            )

# Generated at 2022-06-23 18:18:54.800501
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    obj = _build_version_info(version)
    assert isinstance(obj.version, str)
    assert isinstance(obj.major, _VersionPart)
    assert isinstance(obj.minor, _VersionPart)
    assert isinstance(obj.patch, _VersionPart)
    assert isinstance(obj.pre_pos, int)



# Generated at 2022-06-23 18:19:03.800453
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3a0')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
        assert isinstance(part.pos, int)
        assert isinstance(part.txt, str)
        assert isinstance(part.num, int)
        assert isinstance(part.pre_txt, str)
        assert isinstance(part.pre_num, int)
        assert isinstance(part.name, str)

    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert isinstance(part, _VersionPart)
        assert isinstance(part.pos, int)
        assert isinstance(part.txt, str)

# Generated at 2022-06-23 18:19:14.698620
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:19:24.280387
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit test for constructor of class _VersionPart"""

    VER_ARGS = ['1.0.0', '1.0.1', '1.0.2', '1.1.1a', '1.1a', '1a']
    POS1 = 1
    POS2 = 2
    POS3 = 3

    VER_OBJ = StrictVersion(VER_ARGS[POS1])

    for ver in VER_ARGS:
        for part in _each_version_part(ver):
            assert(isinstance(part, _VersionPart))
    for part in _each_version_part(VER_OBJ):
        assert(isinstance(part, _VersionPart))


# Generated at 2022-06-23 18:19:32.886848
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:39.439447
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') == _VersionPart(0, '1', 1, '', -1, 'major')
    assert _VersionPart(0, '1', 1, '', -1, 'major') != _VersionPart(1, '1', 1, '', -1, 'minor')
    _VersionPart(0, '1', 1, '', -1, 'major')


# Generated at 2022-06-23 18:19:47.579179
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo(
        version='1.2.3a0',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='a',
            pre_num=0,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=1,
    )

# Generated at 2022-06-23 18:19:57.859529
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo('1.2.3', '1', '2', '3', -1)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1

    ver_info = _VersionInfo('1.2.3a1', '1', '2', '3', -1)
    assert ver_info.version == '1.2.3a1'
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.patch.num == 3
    assert ver_info.pre_pos == -1
    assert ver_info.patch

# Generated at 2022-06-23 18:20:09.220222
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pylint: disable=W0612
    assert _VersionInfo(
        '1.2.3',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        -1
    ) == _build_version_info('1.2.3')

# Generated at 2022-06-23 18:20:15.403026
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=C0103
    try:
        _VersionPart(1, 2, 3, 4, 5, 6)
    except Exception:  # pylint:disable=W0703
        assert False, "Should not raise exception"
    assert True



# Generated at 2022-06-23 18:20:28.114841
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:20:34.882714
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
    ) == _VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
    )


# Generated at 2022-06-23 18:20:41.178693
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '0.2.1'
    major_txt = '0'
    minor_txt = '2'
    patch_txt = '1'
    pre_pos = -1
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.txt == major_txt
    assert ver_info.minor.txt == minor_txt
    assert ver_info.patch.txt == patch_txt
    assert ver_info.pre_pos == pre_pos

    version = '0.2.1a0'
    major_txt = '0'
    minor_txt = '2'
    patch_txt = '1a0'
    pre_pos = 0
    ver_info = _build_version_info(version)
    assert ver_info.version

# Generated at 2022-06-23 18:20:49.434572
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Test constructor of ``_VersionPart``."""
    # noinspection PyUnresolvedReferences
    part = _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'



# Generated at 2022-06-23 18:20:53.251381
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    expected = _VersionPart(
        pos=1,
        txt=4,
        num=4,
        pre_txt=0,
        pre_num=0,
        name='minor'
    )
    _ = _VersionPart(**expected._asdict())


# Generated at 2022-06-23 18:20:59.418934
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    try:
        part = _VersionPart(
            pos=1, txt='3', num=3, pre_txt='alpha', pre_num=2, name='minor')
    except Exception:  # pragma: no cover
        assert True is False
    assert part.pos == 1
    assert part.txt == '3'
    assert part.num == 3
    assert part.pre_txt == 'alpha'
    assert part.pre_num == 2
    assert part.name == 'minor'


# Generated at 2022-06-23 18:21:04.735466
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major') == _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')


# Generated at 2022-06-23 18:21:14.567313
# Unit test for function bump_version
def test_bump_version():
    func_name = 'bump_version'
    pos_msg = "The given value for 'position', %r, must be an 'int' between (%r) and (%r)."
    pre_msg = "The given value for 'pre_release', %r, can only be one of: " \
        "'a', 'alpha', 'b', 'beta', None."
    ver_msg = "Only the 'minor' or 'patch' parts of the version number can get a prerelease bump."
    # 'position', 'pre_release', 'expected_result'

# Generated at 2022-06-23 18:21:24.893752
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:37.889282
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    item = _VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert type(item.pos) is int
    assert item.pos == 0
    assert type(item.txt) is str
    assert item.txt == '0'
    assert type(item.num) is int
    assert item.num == 0
    assert type(item.pre_txt) is str
    assert item.pre_txt == ''
    assert type(item.pre_num) is int
    assert item.pre_num == -1
    assert type(item.name) is str
    assert item.name == 'major'
    return True



# Generated at 2022-06-23 18:21:42.778356
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    from os import path
    from sys import modules as m
    from unittest.mock import patch

    m['_PATH'] = path.abspath(path.join(path.dirname(__file__), '..'))
    m['_EXPECTED'] = path.abspath(path.join(m['_PATH'], 'expected'))

    def _test_func(
            version: str,
            expected: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        with patch('builtins.print') as mock_print:
            # noinspection PyUnresolvedReferences
            out = bump_version(version, position=position, pre_release=pre_release)
        mock_print.assert_

# Generated at 2022-06-23 18:21:53.369010
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test constructor of class _VersionInfo."""
    version = '1.2.3.dev0'
    ver_info = _build_version_info(version)
    assert str(ver_info) == (
        "VersionInfo(version='1.2.3.dev0', major=VersionPart(pos=0, txt='1', "
        "num=1, pre_txt='', pre_num=-1, name='major'), minor=VersionPart(pos"
        "=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'), patch="
        "VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name="
        "'patch'), pre_pos=-1)"
    )
    assert ver_info.version

# Generated at 2022-06-23 18:22:05.620694
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo
    ver_info = _VersionInfo('1.2.3',
                            _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3', 3, '', -1, 'patch'),
                            -1)

# Generated at 2022-06-23 18:22:12.001099
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0613
    from types import SimpleNamespace
    import unittest

    version_part = SimpleNamespace(
        pos=0,
        txt='1.4.0',
        num=0,
        pre_txt='a',
        pre_num='0',
        name='major'
    )
    args = [version_part.pos, version_part.txt, version_part.num,
            version_part.pre_txt, version_part.pre_num, version_part.name]
    result = _VersionPart(*args)
    assert isinstance(result, _VersionPart)



# Generated at 2022-06-23 18:22:17.950918
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pytest import raises
    from types import SimpleNamespace as obj
    tup = obj(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major')
    assert _VersionPart(**tup._asdict()) == tup



# Generated at 2022-06-23 18:22:19.287797
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pass


# Generated at 2022-06-23 18:22:27.780932
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3a0')
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            assert part.txt == part.txt.lower()
            assert part.pre_txt == part.pre_txt.lower()
        if part.name == 'major' and part.num != 1:
            assert False
        if part.name == 'minor' and part.num != 2:
            assert False
        if part.name == 'patch' and part.num != 3:
            assert False
test__each_version_part = test__VersionPart



# Generated at 2022-06-23 18:22:36.613254
# Unit test for function bump_version
def test_bump_version():
    """ Unit test for function bump_version """
    # noinspection PyShadowingNames
    version = bump_version("1.2.2")
    assert version == "1.2.3"

    version = bump_version("1.2.3", position=1)
    assert version == "1.3"

    version = bump_version("1.3.4", position=0)
    assert version == "2.0"

    version = bump_version("1.2.3", prerelease='a')
    assert version == "1.2.4a0"

    version = bump_version("1.2.4a0", pre_release='a')
    assert version == "1.2.4a1"

    version = bump_version("1.2.4a1", pre_release='b')

# Generated at 2022-06-23 18:22:46.441373
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    import pytest
    ver_obj = StrictVersion('1.2.3')
    gen = _each_version_part(ver_obj)
    part = next(gen)
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = next(gen)
    assert part.pos == 1
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'
    part = next(gen)
    assert part.pos == 2
    assert part.txt == '3'

# Generated at 2022-06-23 18:22:49.699405
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    info = _VersionInfo('1', '1', '1', '1', 1)
    assert info.version == '1'
    assert info.major == '1'
    assert info.minor == '1'
    assert info.patch == '1'
    assert info.pre_pos == 1


# Generated at 2022-06-23 18:23:00.993689
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '10.8.0a0'
    info = _build_version_info(version)
    assert info.version == version
    assert info.major.txt == '10'
    assert info.major.num == 10
    assert info.minor.txt == '8a0'
    assert info.minor.num == 8
    assert info.minor.pre_txt == 'a'
    assert info.minor.pre_num == 0
    assert info.patch.num == 0
    assert info.pre_pos == 1

    version = '1.2.3'
    info = _build_version_info(version)
    assert info.version == version
    assert info.major.txt == '1'
    assert info.major.num == 1
    assert info.minor.txt == '2'

# Generated at 2022-06-23 18:23:09.785485
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:23:22.275478
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0612
    version: str = '1.2.2'
    assert bump_version(version) == '1.2.3'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'
    version = '1.2.3'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'

# Generated at 2022-06-23 18:23:30.673302
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _build_version_info('1.2.3')
    _build_version_info('1.2.3b0')
    _build_version_info('1.2b0.3')
    _build_version_info('1.2a0.3')
    _build_version_info('1.2a0')
    _build_version_info('1.2.3b0')
    _build_version_info('1.2.3a0')
    _build_version_info('2.0a0')
    _build_version_info('1.0.0')
    _build_version_info('0.0.0')


# Generated at 2022-06-23 18:23:38.159698
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """ Unit test for constructor of class _VersionPart.

    Args:
        No args required.

    Returns:
        No returns.

    Raises:
        No exceptions explicitly raised.
    """
    _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )



# Generated at 2022-06-23 18:23:48.370549
# Unit test for function bump_version
def test_bump_version():
    """Tests function bump_version."""
    from io import StringIO
    from unittest import TestCase

    class Test(TestCase):
        def test_no_pre_release(self):
            """Test function without pre_release."""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')

        def test_no_pre_release_minor(self):
            """Test function without pre_release."""

# Generated at 2022-06-23 18:23:59.341482
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from sys import modules
    from os import linesep
    from flutils.packages import bump_version

    mod_name = modules[__name__].__name__

    def test_expect(
            ver_in: str,
            position: int = 2,
            pre_release: Union[str, None] = None,
            ver_expect: str = '',
            expect_error: bool = False
    ) -> None:
        """Test to ensure that the function works as expected."""
        if expect_error is False:
            a_out = bump_version(ver_in, position, pre_release)
            assert a_out == ver_expect

# Generated at 2022-06-23 18:24:06.733955
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    >>> test__VersionInfo()
    _VersionInfo(version='1.2.3', major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'), minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'), patch=_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'), pre_pos=-1)
    """
    info = _build_version_info('1.2.3')
    # noinspection PyUnresolvedReferences
    print(info)
    return info



# Generated at 2022-06-23 18:24:17.452870
# Unit test for function bump_version

# Generated at 2022-06-23 18:24:28.597607
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pprint
    from itertools import count, zip_longest
    from collections import namedtuple

    VersionPart = namedtuple('VersionPart', 'pos, txt, num, pre_txt, pre_num, name')
    test = VersionPart(pos=0, txt="1", num=1, pre_txt='', pre_num=-1, name='major')
    assert test == _VersionPart(0, '1', 1, '', -1, 'major')
    test = VersionPart(pos=1, txt="2", num=2, pre_txt='', pre_num=-1, name='minor')
    assert test == _VersionPart(1, '2', 2, '', -1, 'minor')

# Generated at 2022-06-23 18:24:29.653181
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    pass



# Generated at 2022-06-23 18:24:35.004247
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # noinspection PyTypeChecker
    _build_version_info('1.2.3')
    _build_version_info('1.2')
    _build_version_info('1.2.3a4')
    _build_version_info('1.2.4b5')
    _build_version_info('1.3')
    _build_version_info('2.0')



# Generated at 2022-06-23 18:24:48.862158
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    v = '1.2.2'
    assert bump_version(v) == '1.2.3'
    v = '1.2.3'
    assert bump_version(v, position=1) == '1.3'
    v = '1.3.4'
    assert bump_version(v, position=0) == '2.0'
    v = '1.2.3'
    assert bump_version(v, pre_release='a') == '1.2.4a0'
    v = '1.2.4a0'
    assert bump_version(v, pre_release='a') == '1.2.4a1'
    v = '1.2.4a1'

# Generated at 2022-06-23 18:25:00.793457
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    my_ver = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    )
    assert my_ver.patch.pre_txt == ''
   

# Generated at 2022-06-23 18:25:10.470827
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        assert part.txt in ('1', '2', '3')
        assert part.num in (1, 2, 3)
        assert part.pre_txt == ''
        assert part.pre_num == -1
        assert part.name in ('major', 'minor', 'patch')

    ver_obj = StrictVersion('1.2.3a1')
    for part in _each_version_part(ver_obj):
        assert part.pos in (0, 1, 2)
        if part.pos == 0:
            assert part.txt == '1'

# Generated at 2022-06-23 18:25:20.325493
# Unit test for function bump_version
def test_bump_version():
    # Test prerelease values
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0') == '1.2.4'
    assert bump_version('1.2.4a1', position=1) == '1.3'
    assert bump_version('2.1.3', position=1, pre_release='a') == '2.2a0'

# Generated at 2022-06-23 18:25:30.522904
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    import sys


# Generated at 2022-06-23 18:25:41.438596
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    obj = _build_version_info('0.1.3')
    assert obj.version == '0.1.3'
    assert obj.major.pos == 0
    assert obj.major.txt == '0'
    assert obj.major.num == 0
    assert obj.major.pre_txt == ''
    assert obj.major.pre_num == -1
    assert obj.major.name == 'major'
    assert obj.minor.pos == 1
    assert obj.minor.txt == '1'
    assert obj.minor.num == 1
    assert obj.minor.pre_txt == ''
    assert obj.minor.pre_num == -1
    assert obj.minor.name == 'minor'
    assert obj.patch.pos == 2
    assert obj.patch.txt == '3'
   

# Generated at 2022-06-23 18:25:49.236747
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3a4'
    ver_info = _build_version_info(version)
    assert ver_info.version == version
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == 'a'
    assert ver_info.minor.pre_num == 4
    assert ver_info.min

# Generated at 2022-06-23 18:26:01.044938
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:26:10.722619
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # noqa
    ver_info = _build_version_info('1.2.4')
    assert ver_info.version == '1.2.4'
    assert ver_info.pre_pos == -1
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre

# Generated at 2022-06-23 18:26:23.102213
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    version = '0.1.0'
    position = 2
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out == '0.1.1'

    version = '0.1.0'
    position = 1
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out == '0.2'

    version = '0.1.0'
    position = 0
    pre_release = None
    out = bump_version(version, position, pre_release)
    assert out == '1.0'

    version = '0.1.0'
    position = 2
    pre_release = 'a'

# Generated at 2022-06-23 18:26:33.552247
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    parts = []
    ver = '1.2.3'
    parts.append(_VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    ))
    parts.append(_VersionPart(
        pos=1,
        txt='2',
        num=2,
        pre_txt='',
        pre_num=-1,
        name='minor'
    ))
    parts.append(_VersionPart(
        pos=2,
        txt='3',
        num=3,
        pre_txt='',
        pre_num=-1,
        name='patch'
    ))
    ver = '1.2.3a2'