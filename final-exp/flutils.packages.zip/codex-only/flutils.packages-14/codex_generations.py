

# Generated at 2022-06-23 18:16:39.157642
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from pprint import pprint
    from flutils.packages import _VersionInfo, _build_version_info
    from flutils.types import FlLogger
    from flutils.logs import init_logging
    from flutils.inspection import get_function_arg_names

    try:
        init_logging(logger='test._VersionInfo.logger')
    except ValueError:
        pass

    version: str = '3.9.3'
    inst = _build_version_info(version)
    pprint(inst)

    kwargs: Dict[str, Any] = {
        'version': inst[0],
        'major': inst[1],
        'minor': inst[2],
        'patch': inst[3],
        'pre_pos': inst[4]
    }

# Generated at 2022-06-23 18:16:52.021997
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # pylint: disable=R0914
    """ Test the constructor for :class:`~.VersionPart`
    """


# Generated at 2022-06-23 18:17:02.006744
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(1, '1', 2, 'a', 0, 'minor')
    assert isinstance(part, _VersionPart)
    assert part.pos == 1
    assert part.txt == '1'
    assert part.num == 2
    assert part.pre_txt == 'a'
    assert part.pre_num == 0
    assert part.name == 'minor'
    assert part.__repr__() == '_VersionPart(pos=1, txt=\'1\', num=2, pre_txt=\'a\', pre_num=0, name=\'minor\')'



# Generated at 2022-06-23 18:17:13.558687
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    # noinspection PyTypeChecker
    ver_info = _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0, txt='1', num=1, pre_txt='', pre_num=0, name='major'
        ),
        minor=_VersionPart(
            pos=1, txt='2', num=2, pre_txt='', pre_num=0, name='minor'
        ),
        patch=_VersionPart(
            pos=2, txt='3', num=3, pre_txt='', pre_num=0, name='patch'
        ),
        pre_pos=-1,
    )

    assert ver_info.version == '1.2.3'

# Generated at 2022-06-23 18:17:22.879816
# Unit test for constructor of class _VersionPart
def test__VersionPart():

    # Create an instance without prerelease
    ver_obj = StrictVersion('1.2.3')
    part = next(_each_version_part(ver_obj))
    assert part.pos == 0
    assert part.num == 1
    assert part.txt == '1'
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'

    part = next(_each_version_part(ver_obj))
    assert part.pos == 1
    assert part.num == 2
    assert part.txt == '2'
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'

    part = next(_each_version_part(ver_obj))
    assert part.pos == 2
    assert part

# Generated at 2022-06-23 18:17:34.901867
# Unit test for constructor of class _VersionPart

# Generated at 2022-06-23 18:17:45.079094
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # Simple bump of the patch version number
    assert bump_version('1.2.2') == '1.2.3'
    # Simple bump of the minor version number
    assert bump_version('1.2.3', position=1) == '1.3'
    # Simple bump of the major version number
    assert bump_version('1.3.4', position=0) == '2.0'
    # Add an alpha version
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Bump the alpha version
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Change to a beta version

# Generated at 2022-06-23 18:17:53.809759
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:18:04.407499
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == '1.2.3'
    assert ver_info.major.num == 1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.num == 2
    assert ver_info.minor.name == 'minor'
    assert ver_info.patch.num == 3
    assert ver_info.patch.name == 'patch'
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2a0')
    assert ver_info.version == '1.2a0'
    assert ver_info.major.num == 1
    assert ver_info.major.name == 'major'

# Generated at 2022-06-23 18:18:11.649053
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    t = _VersionInfo('1.2.1', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'),
                     _VersionPart(2, '1', 1, '', -1, 'patch'), -1)
    assert t.version == '1.2.1'
    assert t.major == _VersionPart(0, '1', 1, '', -1, 'major')
    assert t.minor == _VersionPart(1, '2', 2, '', -1, 'minor')
    assert t.patch == _VersionPart(2, '1', 1, '', -1, 'patch')
    assert t.pre_pos == -1

# Generated at 2022-06-23 18:18:21.308724
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from pprint import pformat
    from unittest import TestCase
    from flutils.packages._version import _VersionPart, _each_version_part

    class TestVersionPart(TestCase):
        """Unit test for constructor of class _VersionPart."""

        def test__VersionPart__methods__(self):
            version: str = '1.2.3a0'
            for part in _each_version_part(StrictVersion(version)):
                self.assertTrue(isinstance(part, _VersionPart))
                self.assertTrue(hasattr(part, 'pos'))
                self.assertTrue(hasattr(part, 'txt'))
                self.assertTrue(hasattr(part, 'num'))
                self.assertTrue(hasattr(part, 'pre_txt'))

# Generated at 2022-06-23 18:18:31.570337
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    c = _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                     _VersionPart(1, '2', 2, '', -1, 'minor'),
                     _VersionPart(2, '3', 3, '', -1, 'patch'),
                     -1)
    assert c.version == '1.2.3'
    assert c.major.pos == 0
    assert c.major.txt == '1'
    assert c.major.num == 1
    assert c.major.pre_txt == ''
    assert c.major.pre_num == -1
    assert c.major.name == 'major'
    assert c.minor.pos == 1
    assert c.minor.txt == '2'
    assert c.minor.num == 2


# Generated at 2022-06-23 18:18:43.514281
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.testing import guard_against_exception


# Generated at 2022-06-23 18:18:53.160505
# Unit test for function bump_version
def test_bump_version():
    """ flutils.packages.bump_version() unit test

    """
    import sys
    import re
    import pytest
    from hypothesis import assume, given, settings
    from hypothesis.strategies import (
        text,
        integers,
        one_of,
        sampled_from,
        just
    )

    from .version import make_version, _BUILD_VERSION_REGEX


# Generated at 2022-06-23 18:19:02.871080
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3')
    assert ver_info.version == "1.2.3"
    assert ver_info.major.num == 1
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.patch.num == 3
    assert ver_info.patch.pre_txt == ''
    assert ver_info.patch.pre_num == -1
    assert ver_info.pre_pos == -1

    ver_info = _build_version_info('1.2.3a4')
    assert ver_info.version == "1.2.3a4"

# Generated at 2022-06-23 18:19:10.553609
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion
    from nose.tools import eq_, ok_
    ver_obj = StrictVersion('1.2.3')
    for pos, part in enumerate(_each_version_part(ver_obj)):
        if pos == 0:
            expect = _VersionPart(
                pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
            )
        if pos == 1:
            expect = _VersionPart(
                pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
            )

# Generated at 2022-06-23 18:19:16.550803
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    for ver in ('0.0.0', '1.2.3', '1.2.0a0', '1.2.9b1'):
        for ver_part in _each_version_part(StrictVersion(ver)):
            assert ver_part.pos in (0, 1, 2)
            assert type(ver_part.txt) is str
            assert type(ver_part.num) is int
            assert type(ver_part.pre_txt) is str
            assert type(ver_part.pre_num) is int
            assert type(ver_part.name) is str
            if ver_part.pos == 0:
                assert ver_part.name == 'major'
            if ver_part.pos == 1:
                assert ver_part.name == 'minor'

# Generated at 2022-06-23 18:19:24.364974
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') is not None
    assert _VersionPart(1, '2', 2, '', -1, 'minor') is not None
    assert _VersionPart(2, '', 0, '', -1, 'patch') is not None
    assert _VersionPart(1, '3a0', 3, 'a', 0, 'minor') is not None
    assert _VersionPart(1, '3b0', 3, 'b', 0, 'minor') is not None


# Generated at 2022-06-23 18:19:32.336699
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    import unittest
    from flutils.packages import bump_version

    class BumpVersionTestCase(unittest.TestCase):
        def test_01_basic(self):
            test = '1.2.3'
            self.assertEqual(bump_version(test), '1.2.4')
            test = '1.2.3'
            self.assertEqual(bump_version(test, position=1), '1.3')
            test = '1.3.4'
            self.assertEqual(bump_version(test, position=0), '2.0')
            test = '1.2.3'
            self.assertEqual(bump_version(test, pre_release='a'), '1.2.4a0')

# Generated at 2022-06-23 18:19:44.207382
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version

    def test_bump_version_base(base_ver, exp_ver, kwargs):
        obs_ver = bump_version(base_ver, **kwargs)
        assert obs_ver == exp_ver


# Generated at 2022-06-23 18:19:53.856260
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    """Unit tests for the _VersionPart class"""
    version = StrictVersion('0.3.3')
    vlist = []
    for part in _each_version_part(version):
        vlist.append(part)
    assert vlist[0] == _VersionPart(0, '0', 0, '', -1, 'major')
    assert vlist[1] == _VersionPart(1, '3', 3, '', -1, 'minor')
    assert vlist[2] == _VersionPart(2, '3', 3, '', -1, 'patch')



# Generated at 2022-06-23 18:20:05.480727
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=missing-docstring
    assert _VersionPart(0, '1', 1, '', -1, 'major').pos == 0
    assert _VersionPart(0, '1', 1, '', -1, 'major').txt == '1'
    assert _VersionPart(0, '1', 1, '', -1, 'major').num == 1
    assert _VersionPart(0, '1', 1, '', -1, 'major').pre_txt == ''
    assert _VersionPart(0, '1', 1, '', -1, 'major').pre_num == -1
    assert _VersionPart(0, '1', 1, '', -1, 'major').name == 'major'
    assert _VersionPart(
        0, '1.2', -1, '', -1, 'major').txt

# Generated at 2022-06-23 18:20:14.266623
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:20:27.742074
# Unit test for function bump_version
def test_bump_version():
    """Test for ``bump_version`` function.

    Testing for Pythons: 3.6, 3.7, 3.8, 3.9

    """
    for i in ('alpha', 'beta', 'a', 'b'):
        for j in ('0', '1'):
            ver = '1.2.%s%s' % (i, j)
            r = bump_version(ver)
            assert r == '1.2'

    # Raises ValueError
    try:
        r = bump_version('1.2.3', position=-4)
        assert False, 'Should not reach this statement'
    except ValueError:
        assert True, 'Correctly raised ValueError'

    # Raises ValueError

# Generated at 2022-06-23 18:20:38.055947
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import (
        _BUMP_VERSION_PATCH_ALPHA,
        _BUMP_VERSION_PATCH_BETA
    )
    from flutils.packages import _each_version_part
    from flutils.packages import _build_version_bump_type

    # _each_version_part

# Generated at 2022-06-23 18:20:45.611261
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    kwargs = {
        'pos': 0,
        'txt': '0',
        'num': 0,
        'pre_txt': '',
        'pre_num': -1,
        'name': 'major'
    }
    obj = _VersionPart(**kwargs)
    assert isinstance(obj, _VersionPart)


# Generated at 2022-06-23 18:20:55.377916
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from pprint import pprint
    ver_info = _build_version_info('1.0')
    assert(ver_info.version == '1.0')
    assert(ver_info.major.pos == 0)
    assert(ver_info.major.num == 1)
    assert(ver_info.major.name == 'major')
    assert(ver_info.minor.pos == 1)
    assert(ver_info.minor.num == 0)
    assert(ver_info.minor.name == 'minor')
    assert(ver_info.patch.pos == 2)
    assert(ver_info.patch.num == -1)
    assert(ver_info.patch.name == 'patch')
    assert(ver_info.pre_pos == -1)
    ver_info = _build_version_

# Generated at 2022-06-23 18:21:02.074537
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612,W0613
    import sys

    # 'major' part
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=-1) == '1.2.4'

    # 'minor' part
    assert bump_version('1.2.4', position=1) == '1.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=-2) == '1.3'

    # 'major' part

# Generated at 2022-06-23 18:21:07.676750
# Unit test for function bump_version
def test_bump_version():
    """Unit test for bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:11.362094
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                        _VersionPart(1, '2', 2, '', -1, 'minor'),
                        _VersionPart(2, '3', 3, '', -1, 'patch'), -1)



# Generated at 2022-06-23 18:21:22.714798
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():  # pragma: no cover; test__VersionInfo
    def _test(
            version: str,
            expected: _VersionInfo
    ) -> None:
        assert _build_version_info(version) == expected


# Generated at 2022-06-23 18:21:29.796743
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    # noinspection PyUnusedLocal
    hold = []
    hold.append(bump_version('1.2.2'))
    hold.append(bump_version('1.2.3', position=1))
    hold.append(bump_version('1.3.4', position=0))
    hold.append(bump_version('1.2.3', prerelease='a'))
    hold.append(bump_version('1.2.4a0', pre_release='a'))
    hold.append(bump_version('1.2.4a1', pre_release='b'))
    hold.append(bump_version('1.2.4a1'))

# Generated at 2022-06-23 18:21:42.578014
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:52.772390
# Unit test for function bump_version
def test_bump_version():  # pragma: no cover
    import sys
    import unittest
    from .utils import build_test_function

    from flutils.packages._version import __name__ as package_name

    SUITE = unittest.TestSuite()
    LOADER = unittest.TestLoader()
    MODULE = sys.modules[__name__]

    TEST_NAMES = (
        'bump_version',
    )
    for name in TEST_NAMES:
        SUITE.addTests(LOADER.loadTestsFromModule(
            build_test_function(
                MODULE,
                name,
                package_name
            )
        ))

    unittest.TextTestRunner(verbosity=2).run(SUITE)

# Generated at 2022-06-23 18:21:59.803170
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from unittest.mock import patch
    from flutils.packages import patch_fakes

    version = '1.2.3'
    patch_fakes()
    with patch('flutils.packages._each_version_part') as m_each_version_part:
        m_each_version_part.return_value = _each_version_part(
            StrictVersion(version)
        )
        ver_info = _build_version_info(version)

    assert ver_info.major == _VersionPart(
        0, '1', 1, '', -1, 'major'
    )
    assert ver_info.minor == _VersionPart(
        1, '2', 2, '', -1, 'minor'
    )

# Generated at 2022-06-23 18:22:12.375554
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    args: List[_VersionPart] = []
    for ver_obj in (
            StrictVersion('1.2.3'),
            StrictVersion('1.2.3b0'),
            StrictVersion('1.2.3a0'),
            StrictVersion('1.2a0'),
            StrictVersion('1a0')
    ):
        for part in _each_version_part(ver_obj):
            args.append(part)

# Generated at 2022-06-23 18:22:23.125613
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
            version='1.2.3',
            major=_VersionPart(
                pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
            ),
            minor=_VersionPart(
                pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'
            ),
            patch=_VersionPart(
                pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'
            ),
            pre_pos=-1
        )


# Generated at 2022-06-23 18:22:35.129664
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Test function 'bump_version'."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:22:45.865911
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    new_version = bump_version(version)
    assert new_version == '1.2.4'
    new_version = bump_version(version, position=1)
    assert new_version == '1.3'
    new_version = bump_version(version, position=0)
    assert new_version == '2.0'
    new_version = bump_version(version, prerelease='a')
    assert new_version == '1.2.4a0'
    new_version = bump_version('1.2.4a0', pre_release='a')
    assert new_version == '1.2.4a1'
    new_version = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-23 18:22:51.676749
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _build_version_info('1.2.3.4')
    assert ver_info.version == '1.2.3.4'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '2'
    assert ver_info.minor.num == 2
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.min

# Generated at 2022-06-23 18:22:57.453962
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart._make([1, '2', 3, '4', 5, 'pos'])
    assert obj.pos == 1
    assert obj.txt == '2'
    assert obj.num == 3
    assert obj.pre_txt == '4'
    assert obj.pre_num == 5
    assert obj.name == 'pos'
    print('passed')



# Generated at 2022-06-23 18:23:08.321861
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:23:21.230654
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _build_version_info('2.3.4')
    assert ver.version == '2.3.4'
    assert ver.major.num == 2
    assert ver.major.pos == 0
    assert ver.minor.num == 3
    assert ver.minor.pos == 1
    assert ver.patch.num == 4
    assert ver.patch.pos == 2
    assert ver.pre_pos == -1

    ver = _build_version_info('2.3.4a0')
    assert ver.pre_pos == 2
    assert ver.patch.pre_txt == 'a'
    assert ver.patch.pre_num == 0

    ver = _build_version_info('2.3.4b0')
    assert ver.pre_pos == 2

# Generated at 2022-06-23 18:23:27.531538
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # noqa: D103
    version_part = _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )
    assert version_part.pos == 0
    assert version_part.txt == '1'
    assert version_part.num == 1
    assert version_part.pre_txt == ''
    assert version_part.pre_num == -1
    assert version_part.name == 'major'


# Generated at 2022-06-23 18:23:39.253281
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    assert _build_version_info('0.0.0') == _VersionInfo(
        '0.0.0',
        _VersionPart(0, '0', 0, '', -1, 'major'),
        _VersionPart(1, '0', 0, '', -1, 'minor'),
        _VersionPart(2, '0', 0, '', -1, 'patch'),
        -1
    )

# Generated at 2022-06-23 18:23:42.874352
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # fmt: off
    version: str = '1.2.3a0.0'
    # fmt: on
    for part in _each_version_part(StrictVersion(version)):
        pass


# Generated at 2022-06-23 18:23:49.226344
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    v_part = _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor')
    assert v_part.pos == 1
    assert v_part.txt == '2'
    assert v_part.num == 2
    assert v_part.pre_txt == ''
    assert v_part.pre_num == -1
    assert v_part.name == 'minor'


# Generated at 2022-06-23 18:23:59.512692
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart

    # Args:
    #     pos: int
    #     txt: str
    #     num: int
    #     pre_txt: str
    #     pre_num: int
    #     name: str
    args: Dict[str, Any] = {
        'pos': 0,
        'txt': '22',
        'num': 22,
        'pre_txt': 'a',
        'pre_num': 4,
        'name': 'major'
    }
    version_part = _VersionPart(**args)
    assert version_part.pos == 0
    assert version_part.txt == '22'
    assert version_part.num == 22
    assert version_part.pre_txt == 'a'
    assert version_part.pre_num == 4

# Generated at 2022-06-23 18:24:11.090472
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    v = _VersionInfo('1.2.4a1',
                     _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
                     _VersionPart(pos=1, txt='2a1', num=2, pre_txt='a', pre_num=1, name='minor'),
                     _VersionPart(pos=2, txt='4', num=4, pre_txt='', pre_num=-1, name='patch'),
                     1,
                     )
    assert v.version == '1.2.4a1'
    assert v.major.pos == 0
    assert v.major.txt == '1'
    assert v.major.num == 1
    assert v.major.pre_txt == ''

# Generated at 2022-06-23 18:24:20.331861
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # As of 04/30/2016 I'm removing all of the doctest examples from
    # the main docstring and moving them down into here.  I'm doing
    # this because I'm seeing sporadic test failures on them, and
    # it's not clear what is causing those issues, yet (4/30/2016).

# Generated at 2022-06-23 18:24:24.893790
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Unit test for constructor of class _VersionInfo."""
    _build_version_info('1.0')
    _build_version_info('2.0.3')
    _build_version_info('4.6.8a2')



# Generated at 2022-06-23 18:24:35.818199
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase

    # pylint: disable=R0904,C0111
    class Test_bump_version(TestCase):

        def test_bump_version_00(self):
            self.assertEqual(bump_version('1.2.2'), '1.2.3')

        def test_bump_version_01(self):
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')

        def test_bump_version_02(self):
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')


# Generated at 2022-06-23 18:24:45.086842
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.3')
    for pos, num in enumerate(ver_obj.version):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kwargs: Dict[str, Any] = {
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': '',
            'pre_num': -1,
            'name': _BUMP_VERSION_POSITION_NAMES[pos]
        }
        part = _VersionPart(**kwargs)
        for key, value in kwargs.items():
            assert getattr(part, key) == value
    prerelease = ver_obj.prerelease

# Generated at 2022-06-23 18:24:50.465207
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    '''
    Expected result (correct)
    '''
    # Args:
    #     pos: int,
    #     txt: str,
    #     num: int,
    #     pre_txt: str,
    #     pre_num: int,
    #     name: str
    expected_result = _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    )
    assert _VersionPart(
        pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'
    ) == expected_result



# Generated at 2022-06-23 18:25:01.861498
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    # pylint: disable=W0613
    def _run(
            pos: int,
            txt: str,
            num: int,
            pre_txt: str,
            pre_num: int,
            name: str
    ) -> None:
        vp = _VersionPart(pos, txt, num, pre_txt, pre_num, name)
        vp

    _run(0, '1', 1, '', -1, 'major')
    _run(1, '2', 2, '', -1, 'minor')
    _run(1, '2b0', 2, 'b', 0, 'minor')
    _run(2, '3', 3, '', -1, 'patch')
    _run(2, '3a0', 3, 'a', 0, 'patch')

# Generated at 2022-06-23 18:25:11.252177
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version

    CommandLine:
        python -m flutils.packages.test_bump_version test_bump_version

    Example:
        >>> from flutils.packages.test_bump_version import *  # NOQA
        >>> test_bump_version()
    """
    import sys
    import pytest
    import six

    if six.PY3:
        pytest.skip('Test only supports Python 2')
        sys.exit(0)

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

# Generated at 2022-06-23 18:25:23.065496
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from . import get_data_file_path
    ver_file = get_data_file_path('version_data.txt')
    with open(ver_file) as fp:
        lines = [line.rstrip('\r\n') for line in fp.readlines()]
    lines.sort(key=lambda k: (k.startswith('DEV') and k[3:], k))
    for line in lines:
        print(line)
        if line.endswith('...'):
            line = line[:-3]
        assert StrictVersion(line).version is not None
        ver_parts = [part for part in _each_version_part(StrictVersion(line))]
        assert len(ver_parts) == 3
        for part in ver_parts:
            assert part.num is not None


# Generated at 2022-06-23 18:25:31.583483
# Unit test for function bump_version
def test_bump_version():
    for version in ('1.2', '1.2.0', '1.2.0.0', '1.2.0.0.0', '1.2.0.0.0.0'):
        assert bump_version(version) == '1.2.1'
    for version in (
            '1.2.0', '1.2.0.0', '1.2.0.0.0', '1.2.0.0.0.0',
            '1.2.0a0', '1.2.0a0.0', '1.2.0a1', '1.2.0a1.0'
    ):
        assert bump_version(version, 0) == '2.0'

# Generated at 2022-06-23 18:25:41.815221
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version: StrictVersion = StrictVersion('1.0')
    each_part: Generator[_VersionPart, None, None] = _each_version_part(version)
    part: _VersionPart = next(each_part)
    assert part.pos == 0
    assert part.txt == '1'
    assert part.num == 1
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'major'
    part = next(each_part)
    assert part.pos == 1
    assert part.txt == '0'
    assert part.num == 0
    assert part.pre_txt == ''
    assert part.pre_num == -1
    assert part.name == 'minor'
    part = next(each_part)
    assert part.pos == 2
   

# Generated at 2022-06-23 18:25:52.604295
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.2'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-23 18:26:03.809452
# Unit test for function bump_version
def test_bump_version():
    """Test ensures that the function ``bump_version`` functions as
    expected.

    """

# Generated at 2022-06-23 18:26:13.694322
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    tst_nm = 'test__VersionPart'


# Generated at 2022-06-23 18:26:25.515494
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.0')
    parts = [build_part for build_part in _each_version_part(ver_obj)]
    assert parts[0][0] == 0
    assert parts[0][1] == '1'
    assert parts[0][2] == 1
    assert parts[0][3] == ''
    assert parts[0][4] == -1
    assert parts[0][5] == 'major'

    assert parts[1][0] == 1
    assert parts[1][1] == '2'
    assert parts[1][2] == 2
    assert parts[1][3] == ''
    assert parts[1][4] == -1
    assert parts[1][5] == 'minor'

    assert parts[2][0] == 2

# Generated at 2022-06-23 18:26:34.237074
# Unit test for function bump_version
def test_bump_version():
    """Unit test for 'bump_version' function.

    :rtype:
        :obj:`bool`

        * A boolean value indicating if the tests
          have passed or failed.

    """
    # pylint: disable=W0401,W0621
    from flutils.packages import bump_version
    import unittest
