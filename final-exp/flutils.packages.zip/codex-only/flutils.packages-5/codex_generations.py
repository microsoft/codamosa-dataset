

# Generated at 2022-06-23 18:16:36.544168
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """
    Unit test for constructor of class _VersionInfo

    """
    current_version = str(bump_version(__version__))
    version = _build_version_info(''.join(current_version))
    assert version.version == __version__
    assert version.major.num == 0
    assert version.major.txt == '0'
    assert version.major.name == 'major'
    assert version.minor.num == 1
    assert version.minor.txt == '1'
    assert version.minor.name == 'minor'
    assert version.patch.num == 0
    assert version.patch.txt == ''
    assert version.patch.name == 'patch'
    assert version.pre_pos == -1



# Generated at 2022-06-23 18:16:42.881780
# Unit test for function bump_version
def test_bump_version():
    """Test to make sure bump_version() works as expected.

    """
    from flutils.packages import bump_version as bv


# Generated at 2022-06-23 18:16:53.254595
# Unit test for function bump_version

# Generated at 2022-06-23 18:17:06.523864
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    from flutils.packages import _VersionInfo
    with pytest.raises(ValueError) as error:
        _VersionInfo('1.2.3.4')
    assert str(error) == 'Version number out of range'

    with pytest.raises(ValueError) as error:
        _VersionInfo('a.b.c')
    assert str(error) == "invalid literal for int() with base 10: 'a'"

    with pytest.raises(ValueError) as error:
        _VersionInfo('1.2.3.a')
    assert str(error) == "invalid literal for int() with base 10: 'a'"

    with pytest.raises(ValueError) as error:
        _VersionInfo('1.2.3.a.b')

# Generated at 2022-06-23 18:17:17.739007
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Tests for the ``_build_version_info`` function.  Execute via:
        $ flutils test -v0
    """
    # pylint: disable=R0914
    from pprint import pformat
    from string import ascii_letters

    from flutils.calc import random_int

    def _build_random_pre_tuple(
            rnd_int: int,
            pre_txt: str,
            pre_num: int
    ) -> Tuple[str, int]:
        if rnd_int % 3 == 0:
            return pre_txt, pre_num
        if rnd_int % 4 == 0:
            return pre_txt, pre_num + 1
        return '', -1


# Generated at 2022-06-23 18:17:28.631876
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'),
                            _VersionPart(1, '2', 2, '', -1, 'minor'),
                            _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'
    assert ver_info.minor.pos == 1

# Generated at 2022-06-23 18:17:40.973317
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version: str = '1.2.0'
    pre_release: str = 'a'

# Generated at 2022-06-23 18:17:51.915452
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version = '1.2.3'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3'
    assert ver_info.major.pos == 0
    assert ver_info.minor.pos == 1
    assert ver_info.patch.pos == 2
    assert ver_info.pre_pos == -1

    version = '1.2.3a0'
    ver_info = _build_version_info(version)
    assert ver_info.version == '1.2.3a0'
    assert ver_info.major.pos == 0
    assert ver_info.minor.pos == 1
    assert ver_info.patch.pos == 2
    assert ver_info.pre_pos == 1

    version = '1.2.3b1'

# Generated at 2022-06-23 18:18:03.534085
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version()."""
    from flutils.testing import (
        assert_str_eq,
        assert_str_ne,
        get_called_function_name,
    )


# Generated at 2022-06-23 18:18:14.809851
# Unit test for function bump_version

# Generated at 2022-06-23 18:18:21.945702
# Unit test for constructor of class _VersionPart
def test__VersionPart():  # noqa: D103
    from distutils.version import StrictVersion
    for ver in ('1.0', '1.2.3', '1.2.3rc1', '1.2.3b4'):
        ver_obj = StrictVersion(ver)
        for part in _each_version_part(ver_obj):  # noqa: WPS337
            assert isinstance(part, _VersionPart)



# Generated at 2022-06-23 18:18:32.357666
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=E0602
    info = _build_version_info('0.1')
    assert info.version == '0.1'
    assert info.major.pos == 0
    assert info.major.txt == '0'
    assert info.major.name == 'major'
    assert info.minor.pos == 1
    assert info.minor.txt == '1'
    assert info.minor.name == 'minor'
    assert info.pre_pos == -1

    info = _build_version_info('0.1.2')
    assert info.version == '0.1.2'
    assert info.major.pos == 0
    assert info.major.txt == '0'
    assert info.major.name == 'major'
    assert info.minor.pos == 1
   

# Generated at 2022-06-23 18:18:43.749132
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from distutils.version import StrictVersion  # pylint: disable=E0611,E0401
    ver = StrictVersion('1.2b3')
    hold = []
    for part in _each_version_part(ver):
        hold.append(part)
    assert hold[0].pos == 0
    assert hold[0].txt == '1'
    assert hold[0].num == 1
    assert hold[0].pre_txt == ''
    assert hold[0].pre_num == -1
    assert hold[0].name == 'major'
    assert hold[1].pos == 1
    assert hold[1].txt == '2b3'
    assert hold[1].num == 2
    assert hold[1].pre_txt == 'b'
    assert hold[1].pre_num == 3
    assert hold

# Generated at 2022-06-23 18:18:53.499331
# Unit test for constructor of class _VersionInfo

# Generated at 2022-06-23 18:18:59.116639
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(pos=0, txt='1', num=1,
                        pre_txt='', pre_num=-1, name='major') == \
        _VersionPart(pos=0, txt='1', num=1,
                     pre_txt='', pre_num=-1, name='major')



# Generated at 2022-06-23 18:19:08.946181
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo(
        '1.2.3',
        _VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1, name='major'),
        _VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1, name='minor'),
        _VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1, name='patch'),
        -1
    )


# Generated at 2022-06-23 18:19:20.514509
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from io import StringIO

    args = [2, '2', 2, 'a', 0, 'patch']
    ver_part = _VersionPart(*args)
    assert ver_part.pre_txt == 'a'
    assert ver_part.pre_num == 0
    assert ver_part.pos == 2
    assert ver_part.txt == '2a0'
    assert ver_part.num == 2
    assert ver_part.name == 'patch'
    ver_part_str = '%s' % ver_part
    assert ver_part_str == 'VersionPart(pos=2, txt=\'2a0\', num=2, ' \
                           'pre_txt=\'a\', pre_num=0, name=\'patch\')'
    ver_part_repr = repr(ver_part)


# Generated at 2022-06-23 18:19:30.199091
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the ``bump_version()`` function."""
    # pylint: disable=bad-whitespace
    # pylint: disable=line-too-long

# Generated at 2022-06-23 18:19:42.589136
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:19:55.805002
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    This is a unit test for the bump_version() function.

    """
    from flutils.packages import bump_version


# Generated at 2022-06-23 18:20:01.043673
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert isinstance(_build_version_info('0.1'), _VersionInfo)
    assert isinstance(_build_version_info('1.2.3'), _VersionInfo)
    assert isinstance(_build_version_info('1.2.3b1'), _VersionInfo)



# Generated at 2022-06-23 18:20:10.720689
# Unit test for function bump_version
def test_bump_version():
    """
    Increase the version number from a version number string.
    *New in version 0.3*
    """
    # create a new version number
    assert bump_version('1.2.2') == '1.2.3'
    # create a new version number
    assert bump_version('1.2.3', position=1) == '1.3'
    # create a new version number
    assert bump_version('1.3.4', position=0) == '2.0'
    # create a new version number
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # create a new version number
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # create a new

# Generated at 2022-06-23 18:20:12.304268
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(0, '1', 1, '', 0, 'major')



# Generated at 2022-06-23 18:20:19.087376
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version = '1.2.3'
    assert len(version) == 7
    for p in _each_version_part(StrictVersion(version)):
        print(p)
    print()
    version = '1.2.0'
    assert len(version) == 7
    for p in _each_version_part(StrictVersion(version)):
        print(p)
    print()
    version = '1.2.4a1'
    assert len(version) == 8
    for p in _each_version_part(StrictVersion(version)):
        print(p)
    print()
    version = '1.2.4b1'
    assert len(version) == 8
    for p in _each_version_part(StrictVersion(version)):
        print(p)
# Unit test

# Generated at 2022-06-23 18:20:32.226111
# Unit test for function bump_version
def test_bump_version():
    """Run module unit test."""
    print('Running...')

    def test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None,
            expect: str = ''
    ):
        actual = bump_version(version, position, pre_release)
        actual_bool = False
        if actual == expect:
            actual_bool = True
        msg_lst: List[str] = [
            'Test Failed',
            "version: %r" % version,
            "position: %r" % position,
            "pre_release: %r" % pre_release,
            'actual: %r' % actual,
            'expect: %r' % expect
        ]
        if actual_bool is True:
            msg_lst.append('OK')

# Generated at 2022-06-23 18:20:44.998034
# Unit test for function bump_version

# Generated at 2022-06-23 18:20:56.774018
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-23 18:21:09.506883
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    vp = _VersionPart(0, '2', 2, 'alpha', 0, '')
    assert isinstance(vp, _VersionPart)
    assert vp.pos == 0
    assert vp.txt == '2'
    assert vp.num == 2
    assert vp.pre_txt == 'alpha'
    assert vp.pre_num == 0
    assert vp.name == 'major'
    vp = _VersionPart(1, '1', 1, '', -1, '')
    assert isinstance(vp, _VersionPart)
    assert vp.pos == 1
    assert vp.txt == '1'
    assert vp.num == 1
    assert vp.pre_txt == ''
    assert vp.pre_num == -1
    assert vp.name == 'minor'
   

# Generated at 2022-06-23 18:21:17.156330
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """ Unit test for constructor of class _VersionInfo
    """
    _VersionInfo('1.2.3', '1', '2', '3')
    _VersionInfo('1.2.3b0', '1', '2', '3b0')
    _VersionInfo('1.2.3a0', '1', '2', '3a0')
    _VersionInfo('1.2.3a1', '1', '2', '3a1')
    _VersionInfo('1.2.3.0b0', '1.2.3', '1.2.3', '0b0')
    _VersionInfo('1.2.3.0b0b0', '1.2.3.0b0', '1.2.3.0b0', 'b0')

# Generated at 2022-06-23 18:21:25.186956
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    obj = _VersionPart(0, '2', 2, '', -1, 'major')
    assert obj.pos == 0
    assert obj.txt == '2'
    assert obj.num == 2
    assert obj.pre_txt == ''
    assert obj.pre_num == -1
    assert obj.name == 'major'
    assert obj.__str__() == '2'
    assert obj.__repr__() == 'VersionPart(pos=0, txt=\'2\', num=2, ' \
        'pre_txt=\'\', pre_num=-1, name=\'major\')'


# Generated at 2022-06-23 18:21:38.584117
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    version: Tuple[int, int, int] = (1, 0, 0)
    prerelease: Union[Tuple[str, int], None] = ('b', 1)
    ver_obj = StrictVersion('1.0.0b1')
    for pos, num in enumerate(version):
        txt = '%s' % num
        if pos == 2 and num == 0:
            txt = ''
        kwargs: Dict[str, Any] = {
            'pos': pos,
            'txt': txt,
            'num': num,
            'pre_txt': '',
            'pre_num': -1,
            'name': _BUMP_VERSION_POSITION_NAMES[pos]
        }

# Generated at 2022-06-23 18:21:48.673769
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for bump_version()."""
    def build_tup(
            major: int,
            minor: int,
            patch: int,
            pre_release: Optional[Union[Tuple[str, int], bool]] = None
    ) -> Tuple[List[int], str, int]:
        if pre_release is None:
            pre_release = False
        if pre_release is False:
            pre_release_out = 'None'
        else:
            pre_release_out = '%s%s' % pre_release
        if pre_release is False:
            if patch != 0:
                version = '%s.%s.%s' % (major, minor, patch)
            else:
                version = '%s.%s' % (major, minor)

# Generated at 2022-06-23 18:21:57.596468
# Unit test for function bump_version
def test_bump_version():
    import unittest


# Generated at 2022-06-23 18:22:11.235692
# Unit test for function bump_version
def test_bump_version():
    # Define the unit test class
    class _TestSuite(object):
        def __init__(self):
            self.total_run = 0

# Generated at 2022-06-23 18:22:23.353637
# Unit test for function bump_version

# Generated at 2022-06-23 18:22:35.129313
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _VersionInfo(
        version='1.2.3',
        major=_VersionPart(
            pos=0,
            txt='1',
            num=1,
            pre_txt='',
            pre_num=-1,
            name='major'
        ),
        minor=_VersionPart(
            pos=1,
            txt='2',
            num=2,
            pre_txt='',
            pre_num=-1,
            name='minor'
        ),
        patch=_VersionPart(
            pos=2,
            txt='3',
            num=3,
            pre_txt='',
            pre_num=-1,
            name='patch'
        ),
        pre_pos=-1
    ) is not None


# Generated at 2022-06-23 18:22:42.334462
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from nose.tools import assert_equal
    from flutils.textutils import to_unicode
    from flutils.packages import _VersionPart
    args = [3, '3', 3, '', -1, 'patch']
    result = _VersionPart(*args)
    expected = _VersionPart(*args)
    assert_equal(
        repr(result),
        repr(expected),
        "Test `_VersionPart`, failed with message: %r" % (to_unicode(result))
    )


# Generated at 2022-06-23 18:22:52.730188
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # pylint: disable=W0612,W0613
    def test_func(ver_input, exp, *args):
        ver_info = _build_version_info(ver_input)
        if ver_input != ver_info.version:
            raise AssertionError(
                "The version input (%r) does not match the version "
                "string (%r)." % (ver_input, ver_info.version)
            )
        for arg in args:
            pos, txt, num, pre_txt, pre_num, name = arg
            fmt = "%s: %r != %r"

# Generated at 2022-06-23 18:23:00.357490
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    assert _build_version_info('1.2.3') == _VersionInfo('1.2.3', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '3', 3, '', -1, 'patch'), -1)
    # assert _build_version_info('1.2a1') == _VersionInfo('1.2a1', _VersionPart(0, '1', 1, '', -1, 'major'), _VersionPart(1, '2', 2, '', -1, 'minor'), _VersionPart(2, '', 0, 'a', 1, 'patch'), 1)

# Generated at 2022-06-23 18:23:12.351438
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    from flutils.packages import _VersionPart
    from distutils.version import StrictVersion

    vobj = StrictVersion('1.2.3')
    vparts = tuple(_each_version_part(vobj))

# Generated at 2022-06-23 18:23:23.502876
# Unit test for function bump_version
def test_bump_version():
    """Simple unit tests for bump_version"""
    import os
    import sys
    import tempfile

    # Create and clean temp files
    file_prefix = '.test_bump_version'
    tmp_dir = tempfile.gettempdir()
    file_list = [
        os.path.join(tmp_dir, file_prefix+'_version_txt'),
        os.path.join(tmp_dir, file_prefix+'_version.py'),
    ]
    for file_path in file_list:
        try:
            os.remove(file_path)
        except:
            pass

    # Test mock version file
    version_data = 'version_info = ("0.0.0",)'

# Generated at 2022-06-23 18:23:33.928865
# Unit test for function bump_version
def test_bump_version():
    import pytest


# Generated at 2022-06-23 18:23:45.524900
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # All version numbers should be equal to version number
    version = '1.2.3a0'
    res = _build_version_info(version)
    assert res.version == version
    # Verify that major, minor and patch are correct
    assert res.major.num == 1
    assert res.minor.num == 2
    assert res.patch.num == 3
    # Verify that pre_pos is correct
    assert res.pre_pos == 2

    # Strip out pre-release
    version = '1.2'
    res = _build_version_info(version)
    assert res.version == version
    # Verify that major and minor are correct
    assert res.major.num == 1
    assert res.minor.num == 2
    # Verify that pre_pos is correct
    assert res.pre_pos == -1



# Generated at 2022-06-23 18:23:57.120253
# Unit test for function bump_version

# Generated at 2022-06-23 18:24:08.130655
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    version_str = '1.2.3a2'
    version_info = _build_version_info(version_str)
    assert version_info.version == '1.2.3a2'
    assert version_info.major.num == 1
    assert version_info.major.txt == '1'
    assert version_info.major.pre_txt == ''
    assert version_info.major.pre_num == -1
    assert version_info.major.name == 'major'
    assert version_info.minor.num == 2
    assert version_info.minor.txt == '2a2'
    assert version_info.minor.pre_txt == 'a'
    assert version_info.minor.pre_num == 2
    assert version_info.minor.name == 'minor'

# Generated at 2022-06-23 18:24:16.607032
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    part = _VersionPart(
        pos=0,
        txt='2',
        num=2,
        pre_txt='a',
        pre_num=1,
        name='major'
    )
    assert part.pos == 0
    assert part.txt == '2'
    assert part.num == 2
    assert part.pre_txt == 'a'
    assert part.pre_num == 1
    assert part.name == 'major'



# Generated at 2022-06-23 18:24:22.043056
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    assert _VersionPart(0, '1', 1, '', -1, 'major') == _VersionPart(
        pos=0,
        txt='1',
        num=1,
        pre_txt='',
        pre_num=-1,
        name='major'
    )



# Generated at 2022-06-23 18:24:33.465014
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0612
    _good = (
        ('1.2.3', (1, 2, 3)),
        ('1.2.3', (1, 2, -1)),
        ('1.2.3', (1, -1, 3)),
        ('1.2.3', (-1, 2, 3)),
        ('1.2.3', (-1, -1, 3)),
        ('1.2.3', (1, -1, -1)),
        ('1.2.3', (-1, 2, -1)),
        ('1.2.3', (-1, -1, -1)),
    )
    for item in _good:
        new = bump_version(*item)
        old = item[0]

# Generated at 2022-06-23 18:24:44.952092
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test bump_version function.

    :rtype:
        None

    """
    assert _build_version_info('1.2.3') == _VersionInfo(
        version='1.2.3',
        major=_VersionPart(pos=0, txt='1', num=1, pre_txt='', pre_num=-1,
                           name='major'),
        minor=_VersionPart(pos=1, txt='2', num=2, pre_txt='', pre_num=-1,
                           name='minor'),
        patch=_VersionPart(pos=2, txt='3', num=3, pre_txt='', pre_num=-1,
                           name='patch'),
        pre_pos=-1
    )
    assert _build_version_info('1.2a0') == _VersionInfo

# Generated at 2022-06-23 18:24:51.238638
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    args: List[Any] = [
        '1.2.3a4',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, 'a', 4, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        1,
    ]
    ver_info = _VersionInfo(*args)
    assert ver_info.version == '1.2.3a4'
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '1'
    assert ver_info.major.num == 1
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1

# Generated at 2022-06-23 18:25:02.284951
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # fmt: off
    obj1 = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    # fmt: on
    assert obj1.version == '1.2.3'
    assert obj1.major.num == 1
    assert obj1.major.pos == 0
    assert obj1.minor.num == 2
    assert obj1.minor.pos == 1
    assert obj1.patch.num == 3
    assert obj1.patch.pos == 2
    assert obj1.pre_pos == -1

    # fmt

# Generated at 2022-06-23 18:25:11.542726
# Unit test for function bump_version
def test_bump_version():
    """Test function: bump_version (from flutils.packages)"""

# Generated at 2022-06-23 18:25:19.116664
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver_info = _VersionInfo(
        '1.2.3',
        _VersionPart(0, '1', 1, '', -1, 'major'),
        _VersionPart(1, '2', 2, '', -1, 'minor'),
        _VersionPart(2, '3', 3, '', -1, 'patch'),
        -1
    )
    assert ver_info.major.txt == '1'
    assert ver_info.patch.pre_txt == ''
    assert ver_info.major.num == 1
    assert ver_info.minor.pre_num == -1


# Generated at 2022-06-23 18:25:29.845191
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function.

    *New in version 0.3*

    Examples:
        >>> from flutils.packages import test_bump_version, bump_version
        >>> test_bump_version()

    """

# Generated at 2022-06-23 18:25:41.066182
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    _VersionInfo('1.2.3',
                 _VersionPart(0, '1', 1, '', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '3', 3, '', -1, 'patch'),
                 -1)
    _VersionInfo('1.2.3a1',
                 _VersionPart(0, '1', 1, '', -1, 'major'),
                 _VersionPart(1, '2', 2, '', -1, 'minor'),
                 _VersionPart(2, '3', 3, 'a', 0, 'patch'),
                 2)

# Generated at 2022-06-23 18:25:49.041479
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    # Create value from regular version
    ver_info = _build_version_info('2.3.4')
    assert ver_info.major.pos == 0
    assert ver_info.major.txt == '2'
    assert ver_info.major.num == 2
    assert ver_info.major.pre_txt == ''
    assert ver_info.major.pre_num == -1
    assert ver_info.major.name == 'major'

    assert ver_info.minor.pos == 1
    assert ver_info.minor.txt == '3'
    assert ver_info.minor.num == 3
    assert ver_info.minor.pre_txt == ''
    assert ver_info.minor.pre_num == -1
    assert ver_info.minor.name == 'minor'

    assert ver

# Generated at 2022-06-23 18:25:51.879099
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    ver = _VersionInfo('1.2.3', '', '', '', -1)


# Generated at 2022-06-23 18:25:56.165429
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    ver_obj = StrictVersion('1.2.0')
    for part in _each_version_part(ver_obj):
        if part:
            assert isinstance(part, _VersionPart)



# Generated at 2022-06-23 18:26:02.045425
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    bump = bump_version  # pylint: disable=C0103
    v = '1.2.3'
    # Version number.  No change.
    assert bump(v) == '1.2.3'
    # Version number.  Minor.
    assert bump(v, position=1) == '1.3'
    # Version number.  Major.
    assert bump(v, position=0) == '2.0'
    # Version number.  Major.  With pre-release major.
    with pytest.raises(ValueError):
        bump(v, position=0, pre_release='a')
    # Version number.  Minor.  With pre-release minor alpha.

# Generated at 2022-06-23 18:26:11.368157
# Unit test for constructor of class _VersionInfo
def test__VersionInfo():
    """Test the constructor of class _VersionInfo."""
    # pylint: disable=W0612
    # noinspection PyUnusedLocal
    ver_info = _build_version_info('1.2.3')
    ver_info = _build_version_info('1.3')
    ver_info = _build_version_info('2.0')
    ver_info = _build_version_info('1.2.4a0')
    ver_info = _build_version_info('1.2.4a1')
    ver_info = _build_version_info('1.2.4b0')
    ver_info = _build_version_info('1.2.4')
    ver_info = _build_version_info('2.2a0')
    ver_info = _build_version_

# Generated at 2022-06-23 18:26:23.896266
# Unit test for constructor of class _VersionPart
def test__VersionPart():
    with pytest.raises(TypeError):
        _VersionPart()
    with pytest.raises(TypeError):
        _VersionPart(1)
    with pytest.raises(TypeError):
        _VersionPart(1, 2)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3, 4)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3, 4, 5)
    with pytest.raises(TypeError):
        _VersionPart(1, 2, 3, 4, 5, 6, 7)

# Generated at 2022-06-23 18:26:33.301012
# Unit test for constructor of class _VersionInfo