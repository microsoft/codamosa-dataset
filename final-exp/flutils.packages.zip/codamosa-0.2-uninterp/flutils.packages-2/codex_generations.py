

# Generated at 2022-06-17 19:18:20.750051
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:18:30.734712
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:18:41.353569
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # pylint: disable=W0612,W0613
    from flutils.packages import bump_version
    from flutils.testing import UnitTester

    tester = UnitTester()
    tester.test_function(bump_version)
    tester.test_function(bump_version, '1.2.2')
    tester.test_function(bump_version, '1.2.3', position=1)
    tester.test_function(bump_version, '1.3.4', position=0)
    tester.test_function(bump_version, '1.2.3', prerelease='a')
    tester.test_function(bump_version, '1.2.4a0', pre_release='a')
   

# Generated at 2022-06-17 19:18:52.255449
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:19:02.503534
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:19:10.903955
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:19:20.973587
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:19:31.521843
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:19:41.753484
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:19:50.607364
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:20:22.843680
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:20:32.087993
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:20:43.696413
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:20:56.232695
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:21:05.649928
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:21:16.202551
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=C0103
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:21:26.753814
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:21:36.972259
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:21:45.162363
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-17 19:21:56.915368
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=R0914
    # pylint: disable=R0915
    # pylint: disable=W0612
    # pylint: disable=W0613
    # pylint: disable=W0621
    # pylint: disable=W0622
    # pylint: disable=W0631
    # pylint: disable=W0632
    # pylint: disable=W0633
    # pylint: disable=W0634
    # pylint: disable=W0635
    # pylint: disable=W0636
    # pylint: disable=W0637
    # pylint: disable=W0638
    # pylint: disable=W0639
    # pylint: disable

# Generated at 2022-06-17 19:22:37.551685
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    import sys
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Test class for function bump_version"""

        def test_bump_version(self):
            """Test function for bump_version"""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-17 19:22:48.725561
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:22:58.133092
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:23:08.708769
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # pylint: disable=C0103
    import pytest

    # Test the function bump_version
    def _test_bump_version(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        """Test the function bump_version."""
        actual = bump_version(version, position, pre_release)
        assert actual == expected

    # Test the function bump_version
    def _test_bump_version_exception(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        """Test the function bump_version."""

# Generated at 2022-06-17 19:23:16.275217
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:23:26.300445
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-17 19:23:36.576040
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-17 19:23:43.186219
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # pylint: disable=C0103
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:23:51.784595
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version

    # Test basic version bumps
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test pre-release bumps
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_

# Generated at 2022-06-17 19:24:01.723752
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version.

    *New in version 0.3*

    """
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:24:22.537711
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # pylint: disable=R0914
    # pylint: disable=R0915
    # pylint: disable=R0912
    # pylint: disable=R0913
    # pylint: disable=R1702
    # pylint: disable=R1710
    # pylint: disable=R1711
    # pylint: disable=R1712
    # pylint: disable=R1713
    # pylint: disable=R1714
    # pylint: disable=R1715
    # pylint: disable=R1716
    # pylint: disable=R1717
    # pylint: disable=R1718
    # pylint: disable=R1719
    # pylint: disable=R

# Generated at 2022-06-17 19:24:29.995420
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    # pylint: disable=C0103
    # pylint: disable=W0612
    # pylint: disable=W0613
    # pylint: disable=W0106
    # pylint: disable=W0107
    # pylint: disable=W0108
    # pylint: disable=W0109
    # pylint: disable=W0110
    # pylint: disable=W0111
    # pylint: disable=W0112
    # pylint: disable=W0113
    # pylint: disable=W0114
    # pylint: disable=W0115
    # pylint: disable=W0116
    # pylint: disable=W0117
    # pylint: disable=

# Generated at 2022-06-17 19:24:38.893705
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:24:47.134539
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=C0103
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:24:57.449033
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # pylint: disable=C0103
    from flutils.packages import bump_version

    def _test_bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        return bump_version(version, position, pre_release)

    def _test_bump_version_error(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        try:
            bump_version(version, position, pre_release)
        except ValueError:
            pass

# Generated at 2022-06-17 19:25:06.737173
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=C0103
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:25:16.541568
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import pytest

    # Test invalid version numbers
    with pytest.raises(ValueError):
        bump_version('1.2.3.4')
    with pytest.raises(ValueError):
        bump_version('1.2.3a')
    with pytest.raises(ValueError):
        bump_version('1.2.3a0.1')
    with pytest.raises(ValueError):
        bump_version('1.2.3a0.1')
    with pytest.raises(ValueError):
        bump_version('1.2.3a0.1')
    with pytest.raises(ValueError):
        bump_version('1.2.3a0.1')
    with pytest.raises(ValueError):
        bump

# Generated at 2022-06-17 19:25:26.442034
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version

    def _test(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> str:
        return bump_version(version, position, pre_release)

    assert _test('1.2.2') == '1.2.3'
    assert _test('1.2.3', position=1) == '1.3'
    assert _test('1.3.4', position=0) == '2.0'
    assert _test('1.2.3', prerelease='a') == '1.2.4a0'
    assert _test('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert _

# Generated at 2022-06-17 19:25:35.224807
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-17 19:25:46.291706
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    # pylint: disable=C0103
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Unit test for function bump_version."""

        def test_bump_version(self):
            """Unit test for function bump_version."""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.3.4', position=0), '2.0')
            self.assertEqual(bump_version('1.2.3', prerelease='a'), '1.2.4a0')

# Generated at 2022-06-17 19:26:02.858786
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    from flutils.packages import bump_version

    def _test_bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        """Test function bump_version."""
        try:
            bump_version(version, position, pre_release)
        except ValueError as err:
            raise AssertionError(
                "The version number, %r, with position, %r, and pre-release, "
                "%r, raised a ValueError: %s" % (
                    version,
                    position,
                    pre_release,
                    err
                )
            )

    _test_bump_version('1.2.2')

# Generated at 2022-06-17 19:26:13.139016
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:26:23.507799
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    import pytest
    from flutils.packages import bump_version

    def _test_bump_version(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        """Test the function bump_version."""
        out = bump_version(version, position, pre_release)
        ver_obj = StrictVersion(out)
        assert ver_obj.version[position] > StrictVersion(version).version[position]

    def _test_bump_version_error(
            version: str,
            position: int = 2,
            pre_release: Optional[str] = None
    ) -> None:
        """Test the function bump_version."""

# Generated at 2022-06-17 19:26:31.723893
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:26:42.378663
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:26:52.438090
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:27:02.263369
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:27:11.720835
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    from flutils.packages import bump_version

    # Test the function bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:27:21.075809
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # pylint: disable=C0103
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-17 19:27:29.999537
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-17 19:28:01.081557
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'