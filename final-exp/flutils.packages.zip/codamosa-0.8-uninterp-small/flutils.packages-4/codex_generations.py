

# Generated at 2022-06-25 17:31:46.131576
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:31:54.589011
# Unit test for function bump_version
def test_bump_version():
    # TODO: Fix.
    return

# Generated at 2022-06-25 17:31:57.636343
# Unit test for function bump_version
def test_bump_version():
    pytest.dbgfunc()
    bump_version('1.2.0a0')
    bump_version('1.2.0a1')
    bump_version('1.2.0b2')
    bump_version('1.2.0')

# Generated at 2022-06-25 17:32:07.139061
# Unit test for function bump_version
def test_bump_version():

    # Example 1
    assert bump_version('1.2.2') == '1.2.3'

    # Example 2
    assert bump_version('1.2.3', position=1) == '1.3'

    # Example 3
    assert bump_version('1.3.4', position=0) == '2.0'

    # Example 4
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Example 5
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Example 6
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

    # Example 7

# Generated at 2022-06-25 17:32:19.501236
# Unit test for function bump_version
def test_bump_version():
    cases = [
        # Tuple: (position, pre_release)
        ((2, None), '1.2.3'),
        ((1, None), '1.3'),
        ((0, None), '2.0'),
        ((2, 'a'), '1.2.4a0'),
        ((2, 'a'), '1.2.4a1'),
        ((2, 'b'), '1.2.4b0'),
        ((2, None), '1.2.4'),
        ((2, None), '1.2.4'),
        ((1, 'a'), '2.2a0'),
        ((2, None), '1.2.1'),
    ]

# Generated at 2022-06-25 17:32:22.166678
# Unit test for function bump_version
def test_bump_version():
    """Unit Test for `bump_version`.

    Notes:
        No unit tests are implemented for this function as this function was
        written using the testing driven development methodology.

    """
    pass

# Generated at 2022-06-25 17:32:34.556515
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:42.635874
# Unit test for function bump_version
def test_bump_version():
    """This function is called from the setup.py file when installing this
    module.
    """
    print("Testing bump_version...")
    if bump_version("1.2.3") != "1.2.3":
        raise Exception("bump_version('1.2.3') != '1.2.3'")

    if bump_version("1.0.0", position=1) != "1.1":
        raise Exception("bump_version('1.0.0', position=1) != '1.1'")

    if bump_version("1.2.3", position=0) != "2.0":
        raise Exception("bump_version('1.2.3', position=0) != '2.0'")


# Generated at 2022-06-25 17:32:51.026786
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:03.551120
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0301
    # pylint: disable=C0103
    print('version:', StrictVersion(__version__).version)
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
   

# Generated at 2022-06-25 17:33:29.915309
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 17:33:31.365301
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:33:38.098324
# Unit test for function bump_version
def test_bump_version():
    """Test function `bump_version`."""

# Generated at 2022-06-25 17:33:48.153571
# Unit test for function bump_version
def test_bump_version():
    def test_case_0():
        str_0 = '1.2.0a1'
        str_1 = bump_version(str_0)

    def _test_case(
            input_value: str,
            expected_value: str,
            position: int = 2,
            pre_release: Optional[str] = None,
    ):
        actual_value = bump_version(
            input_value,
            position=position,
            pre_release=pre_release,
        )
        assert expected_value == actual_value

    def test_case_1():
        _test_case('1.2.0a1', '1.2.0a2')

    def test_case_2():
        _test_case('1.2.0b1', '1.2.0b2')


# Generated at 2022-06-25 17:34:00.068554
# Unit test for function bump_version
def test_bump_version():

    # Test case 0
    str_0 = '1.2.0a1'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.0a2'

    # Test case 1
    str_0 = '1.2.0a0'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.0a1'

    # Test case 2
    str_0 = '1.0.0a1'
    str_1 = bump_version(str_0)
    assert str_1 == '1.0.0a2'

    # Test case 3
    str_0 = '1.2.0b1'
    str_1 = bump_version(str_0)

# Generated at 2022-06-25 17:34:08.342964
# Unit test for function bump_version
def test_bump_version():
    ver_0 = '1.2.3'
    ver_0_1 = '1.2.4'
    ver_1 = '1.3.0'
    ver_2 = '2.0.0'
    ver_3 = '1.2.4a0'
    ver_4 = '1.2.4a1'
    ver_5 = '1.2.4b0'
    ver_6 = '1.2.5'

    ver_bump_0 = bump_version(ver_0)
    ver_bump_1 = bump_version(ver_0, position=1)
    ver_bump_2 = bump_version(ver_0, position=0)
    ver_bump_3 = bump_version(ver_0, pre_release='a')
    ver_bump

# Generated at 2022-06-25 17:34:11.317553
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:34:20.436552
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:30.802394
# Unit test for function bump_version
def test_bump_version():
    import json5
    import os
    from flutils.packages import get_root_pkg_name
    root_pkg_name = get_root_pkg_name(__file__)

    file_path = os.path.join(
        os.path.dirname(__file__),
        'testdata',
        'test_bump_version.json5'
    )
    with open(file_path, encoding='utf-8') as f:
        data = json5.load(f)

    for case in data:
        version = case['version']
        expected = case['expected']
        position = case['position']

        actual_version = bump_version(
            version=version,
            position=position
        )

        assert actual_version == expected

# Generated at 2022-06-25 17:34:43.188696
# Unit test for function bump_version
def test_bump_version():
    ver, desired = [], []
    ver.append(('1.2.0a1', '1.2.0a1'))
    desired.append(('1.2.0a2'))
    ver.append(('1.2.0a2', '1.2.0a2'))
    desired.append(('1.2.0a3'))
    ver.append(('0.0.0b0', '0.0.0b0'))
    desired.append(('0.0.0b1'))
    ver.append(('0.0.0b1', '0.0.0b1'))
    desired.append(('0.0.0b2'))
    ver.append(('0.0.1a1', '0.0.1a1'))
   

# Generated at 2022-06-25 17:35:15.834125
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:28.444257
# Unit test for function bump_version
def test_bump_version():
    str_0 = '0.0.1'
    str_1 = bump_version(str_0)
    assert str_1 == '0.0.2'
    str_0 = '0.0.0'
    str_1 = bump_version(str_0)
    assert str_1 == '0.0.0'
    str_0 = '0.1.1'
    str_1 = bump_version(str_0)
    assert str_1 == '0.1.2'
    str_0 = '0.1.2'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '1.0'
    str_0 = '0.1.2'
    str_1 = bump_version(str_0, position=1)

# Generated at 2022-06-25 17:35:38.952424
# Unit test for function bump_version
def test_bump_version():
    res = bump_version('1.2.2')  # 1.2.3
    assert res == '1.2.3'

    res = bump_version('1.2.3', position=1)  # 1.3
    assert res == '1.3'

    res = bump_version('1.3.4', position=0)  # 2.0
    assert res == '2.0'

    res = bump_version('1.2.3', prerelease='a')  # 1.2.4a0
    assert res == '1.2.4a0'

    res = bump_version('1.2.4a0', pre_release='a')  # 1.2.4a1
    assert res == '1.2.4a1'


# Generated at 2022-06-25 17:35:50.620570
# Unit test for function bump_version
def test_bump_version():
    # Test: bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:01.790035
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:14.742380
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.0'
    str_1 = bump_version(str_0)

    assert str_1 == '1.2.1'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_1 = bump_version(str_0, position=1, pre_release='a')
    assert str_1 == '1.3a0'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_0 = '1.2.0a0'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.0a1'
    str_0 = '1.2.1a1'


# Generated at 2022-06-25 17:36:21.142676
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:31.968908
# Unit test for function bump_version
def test_bump_version():
    # Setup
    str_0 = '1.2.0a1'
    str_1 = '1.2.0a2'
    str_2 = '1.2.1a0'
    str_3 = '1.2.1'
    str_4 = '1.2a0'
    str_5 = '1.2a1'
    str_6 = '1.3.0'
    str_7 = '2.0.0'

    # Execute
    out_0 = bump_version(str_0, position=2)
    out_1 = bump_version(str_0, position=2, pre_release='a')
    out_2 = bump_version(str_0, position=1)

# Generated at 2022-06-25 17:36:40.578739
# Unit test for function bump_version
def test_bump_version():
    str_3 = '1.2.0'
    str_4 = bump_version(str_3)
    str_5 = bump_version(str_4)
    str_6 = bump_version(str_4, pre_release='a')
    str_7 = bump_version(str_6)
    str_8 = bump_version(str_6, position=0)
    str_9 = bump_version(str_6, position=1, pre_release='b')
    str_10 = bump_version(str_9)
    str_11 = bump_version(str_10)
    str_12 = bump_version(str_11)
    str_13 = bump_version(str_12, position=-1)
    str_14 = bump_version(str_13)
    str_15 = bump_version

# Generated at 2022-06-25 17:36:51.948390
# Unit test for function bump_version
def test_bump_version():
    ver_0 = bump_version('1.2.0a1')
    ver_1 = bump_version(ver_0)
    ver_2 = bump_version(ver_1, pre_release='')
    ver_3 = bump_version(ver_2, pre_release='a')
    ver_4 = bump_version(ver_3, pre_release='a')
    ver_5 = bump_version(ver_4)
    ver_6 = bump_version(ver_5, 1, 'b')
    ver_7 = bump_version(ver_6, 1, 'b')
    ver_8 = bump_version(ver_7)
    ver_9 = bump_version(ver_8)
    ver_10 = bump_version(ver_9)


# Generated at 2022-06-25 17:37:43.507473
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:52.895461
# Unit test for function bump_version
def test_bump_version():
    # Test 0
    str_0 = '1.2.0a1'
    str_1 = '1.2.0a2'
    assert bump_version(str_0) == str_1

    # Test 1
    str_0 = '1.2.3'
    str_1 = '1.2.4a0'
    assert bump_version(str_0, pre_release='a') == str_1

    # Test 2
    str_0 = '1.2.4a0'
    str_1 = '1.2.4a1'
    assert bump_version(str_0, pre_release='a') == str_1

    # Test 3
    str_0 = '1.2.4a1'
    str_1 = '1.2.4b0'
    assert bump_

# Generated at 2022-06-25 17:38:04.107911
# Unit test for function bump_version
def test_bump_version():
    """Tests: bump_version."""
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=-1)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_

# Generated at 2022-06-25 17:38:15.108958
# Unit test for function bump_version
def test_bump_version():
    # Setup
    str_0 = '1.2.0'
    str_1 = '1.2.4a0'
    str_2 = '1.2.0a1'
    str_3 = '1.2.0a2.3'
    str_4 = '1.2.0b1'
    str_5 = '1.2.0a3.4'
    str_6 = '1.2.4'
    str_7 = '1.2.4b0'
    str_8 = '1.2.4b1'
    str_9 = '1.2a0'
    str_10 = '1.2a1'
    str_11 = '1.2a2.3'
    str_12 = '1.2b1'

# Generated at 2022-06-25 17:38:27.041054
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:35.139665
# Unit test for function bump_version
def test_bump_version():
    # from flutils.packages import bump_version

    # 1.0.0
    ver = '1.0.0'
    assert bump_version(ver) == '1.0.1'
    assert bump_version(ver, position=0) == '2.0.0'
    assert bump_version(ver, position=1) == '1.1'
    assert bump_version(ver, position=2) == '1.0.1'
    assert bump_version(ver, position=-1) == '1.0.1'
    assert bump_version(ver, position=-2) == '1.1'
    assert bump_version(ver, position=-3) == '2.0.0'
    assert bump_version(ver, position=0, pre_release='a') == '2.0.0a0'


# Generated at 2022-06-25 17:38:45.023626
# Unit test for function bump_version
def test_bump_version():
    out = bump_version('1.2.0a1')
    assert out == '1.2.0a2'

    out = bump_version('1.2.0a1', position=1)
    assert out == '1.3.0a0'

    out = bump_version('1.3.0a0')
    assert out == '1.3.0'

    out = bump_version('1.4.0')
    assert out == '1.5'

    out = bump_version('1.5')
    assert out == '2'

    out = bump_version('2.0.0a0')
    assert out == '2.0.0a1'

    out = bump_version('2.0.0b1')
    assert out == '2.0.0b2'


# Generated at 2022-06-25 17:38:46.248820
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    return True



# Generated at 2022-06-25 17:38:56.333013
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.0a1'
    str_1 = bump_version(str_0)
    # AssertionError: '1.2.0a1' != '1.2.0a2'
    assert str_1 == '1.2.0a2'
    str_0 = '1.2.0a1'
    str_1 = bump_version(str_0, position=2)
    # AssertionError: '1.2.0a1' != '1.2.1a0'
    assert str_1 == '1.2.1a0'
    str_0 = '1.2.0a1'
    str_1 = bump_version(str_0, position=1)
    # AssertionError: '1.2.0a1' != '

# Generated at 2022-06-25 17:39:07.075517
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``.

    This was done in Python 3.6.  However, it should work in earlier versions
    of Python as well.
    """
    new_version = bump_version('1.0.0')
    assert new_version == '1.0.1', (
        "Checking '1.0.0' bumps to '1.0.1' "
        "with default options."
    )
    new_version = bump_version('1.0.0', position=1)
    assert new_version == '1.1', (
        "Checking '1.0.0' bumps to '1.1' "
        "with 'position=1'."
    )
    new_version = bump_version('1.0.0', position=0)

# Generated at 2022-06-25 17:39:39.531356
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.0a1'
    str_1 = bump_version(str_0)

    assert str_1 == '1.2.0a2'


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:50.100977
# Unit test for function bump_version
def test_bump_version():
    result = bump_version('1.2.3')
    assert result == '1.2.4'
    result = bump_version('1.2.3', position=1)
    assert result == '1.3'
    result = bump_version('1.3.4', position=0)
    assert result == '2.0'
    result = bump_version('1.2.3', prerelease='a')
    assert result == '1.2.4a0'
    result = bump_version('1.2.4a0', pre_release='a')
    assert result == '1.2.4a1'
    result = bump_version('1.2.4a1', pre_release='b')
    assert result == '1.2.4b0'

# Generated at 2022-06-25 17:39:59.466910
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:00.492444
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:40:13.481539
# Unit test for function bump_version
def test_bump_version():
    print('test_bump_version:')
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    print('%s %s' % (str_0, str_1))
    str_0 = str_1
    str_1 = bump_version(str_0)
    print('%s %s' % (str_0, str_1))
    str_0 = str_1
    str_1 = bump_version(str_0)
    print('%s %s' % (str_0, str_1))
    str_0 = str_1
    str_1 = bump_version(str_0)
    print('%s %s' % (str_0, str_1))

    str_0 = '1.2.3'
    str

# Generated at 2022-06-25 17:40:22.408534
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0'
    str_0 = '1.2.4a0'
    str_1 = bump_version

# Generated at 2022-06-25 17:40:27.902097
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from pprint import pprint

    # TODO: Add better tests for pypi preview mode

# Generated at 2022-06-25 17:40:40.067184
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0914
    # pylint: disable=R0915
    str_0 = '1.2.0a1'
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_0, position=0)
    str_3 = bump_version(str_0, position=1)
    str_4 = bump_version(str_0, position=2)
    str_5 = bump_version(str_0, position=3)
    str_6 = bump_version(str_0, position=4)
    str_7 = bump_version(str_0, position=-3)
    str_8 = bump_version(str_0, position=-2)
    str_9 = bump_version(str_0, position=-1)
    str

# Generated at 2022-06-25 17:40:49.833027
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test function.

    :return:
        None.

    """
    def check(ver_str, expected):
        """
        Compare a string to the expected value.

        :return:
            None

        """
        ver_1 = bump_version(ver_str)
        if ver_1 != expected:
            print_('Wrong version returned:\n  %s\n  %s' % (ver_1, expected))
            exit(1)

    check('0.4.4', '0.4.5')
    check('0.4.4a3', '0.4.4a4')
    check('0.4.4a3', '0.4.4b0')
    check('0.4.4b1', '0.4.4b2')

# Generated at 2022-06-25 17:40:58.724641
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'