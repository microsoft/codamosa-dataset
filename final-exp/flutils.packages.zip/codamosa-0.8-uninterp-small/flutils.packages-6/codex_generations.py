

# Generated at 2022-06-25 17:31:44.059457
# Unit test for function bump_version
def test_bump_version():
    # Check that bumping the major part works
    result = bump_version('0.2.1')
    assert result == '1.0', \
        'bumps the major part; expected: 1.0, result: %s' % result
    result = bump_version('1.2.1')
    assert result == '2.0', \
        'bumps the major part; expected: 1.0, result: %s' % result

    # Check that bumping the minor part works
    result = bump_version('0.2.1', 1)
    assert result == '0.3', \
        'bumps the minor part; expected: 0.3, result: %s' % result
    result = bump_version('0.2.10', 1)

# Generated at 2022-06-25 17:31:50.261643
# Unit test for function bump_version

# Generated at 2022-06-25 17:31:59.711899
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    """Unit test for function ``bump_version``.

    *New in version 0.3*

    """

    def _run_test(
            test_number: int,
            version: str,
            expected: str,
            position: Optional[int] = None,
            prerelease: Optional[str] = None
    ) -> None:
        """Run the test.

        *New in version 0.3*

        Args:
            test_number (int): The test number.
            version (str): The version to be bumped.
            expected (str): The expected version, after the bump.
            position (Optional[int], optional): The position of the bump.
            prerelease (Optional[int], optional): The pre-release position.

        """

# Generated at 2022-06-25 17:32:08.437228
# Unit test for function bump_version
def test_bump_version():
    from flutils.misc import is_version_higher

    version = '1.2.3'
    major = bump_version(version)
    assert major == '2.0'

    minor = bump_version(version, position=1)
    assert minor == '1.3'

    patch = bump_version(version)
    assert patch == '1.2.4'

    is_higher_0 = is_version_higher(major, version)
    assert is_higher_0 is True

    is_higher_1 = is_version_higher(minor, version)
    assert is_higher_1 is True

    is_higher_2 = is_version_higher(patch, version)
    assert is_higher_2 is True

    is_higher_3 = is_version_higher(version, major)
    assert is_higher_

# Generated at 2022-06-25 17:32:20.695102
# Unit test for function bump_version
def test_bump_version():
    # Major
    assert bump_version('1.0') == '2.0'
    assert bump_version('1.2') == '2.0'
    assert bump_version('1.2.3') == '2.0'
    # Minor
    assert bump_version('1.1') == '1.2'
    assert bump_version('1.0.4') == '1.1'
    assert bump_version('1.1.4') == '1.2'
    assert bump_version('1.2.4') == '1.3'
    # Patch
    assert bump_version('1.0.3') == '1.0.4'
    assert bump_version('1.0.4') == '1.0.5'

# Generated at 2022-06-25 17:32:33.097600
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyTypeChecker
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:35.502561
# Unit test for function bump_version
def test_bump_version():
    ver_obj = StrictVersion('4.4.4')
    for part in _each_version_part(ver_obj):
        pass
    if True:
        pass
    if True:
        pass

# Generated at 2022-06-25 17:32:37.592104
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.3', position=2)
    assert version == '1.2.4'



# Generated at 2022-06-25 17:32:48.045223
# Unit test for function bump_version
def test_bump_version():
    # Nose
    from nose.tools import assert_equal, assert_raises

    # pylint: disable=W0612,C0103
    def _bump(v, p, **kwargs):
        return bump_version(v, p, **kwargs)

    assert_equal(_bump('1.2.2'), '1.2.3')
    assert_equal(_bump('1.2.3', position=1), '1.3')
    assert_equal(_bump('1.3.4', position=0), '2.0')
    assert_equal(_bump('1.2.3', pre_release='a'), '1.2.4a0')
    assert_equal(_bump('1.2.4a0', pre_release='a'), '1.2.4a1')

# Generated at 2022-06-25 17:33:01.725261
# Unit test for function bump_version
def test_bump_version():
    from pytest import raises

    # Test the basic functionality.
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test the different types of pre-release bumps.
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:33:43.108677
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:51.385405
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:02.634415
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):

        def test_bump_version_00(self):
            """Test case for function ``bump_version``,
            testing the 'patch' position bump."""
            version = '0.0.1'
            result = bump_version(version)
            expected = '0.0.2'
            self.assertEqual(result, expected)

        def test_bump_version_01(self):
            """Test case for function ``bump_version``,
            testing the 'minor' position bump."""
            version = '0.7.2'
            result = bump_version(version, position=1)
            expected = '0.8'
            self.assertEqual(result, expected)


# Generated at 2022-06-25 17:34:11.875945
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:17.399544
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    import unittest
    import unittest.mock
    # pylint: disable=R0904,C0115

    class TestBumpVersion(unittest.TestCase):
        """The test case for the ``bump_version`` module."""

        @unittest.mock.patch('flutils.packages.bump_version')
        def test_bump_version_fix_0(
                self,
                mock_bump_version: unittest.mock.MagicMock
        ) -> None:
            """Test the ``bump_version`` function."""
            on_input = '1.2.3'
            on_position = 0
            on_pre_release = None
            expected = '1.2.3'
            mock_bump_

# Generated at 2022-06-25 17:34:29.397765
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.1'
    result = bump_version(version)
    assert result == '1.2.2'

    version = '1.2.2'
    position = -1
    pre_release = None
    result = bump_version(version, position=position, pre_release=pre_release)
    assert result == '1.2.3'

    version = '1.2.2'
    position = -1
    pre_release = 'a'
    result = bump_version(version, position=position, pre_release=pre_release)
    assert result == '1.2.2a0'

    version = '1.2.2a0'
    position = -1
    pre_release = 'a'

# Generated at 2022-06-25 17:34:36.738330
# Unit test for function bump_version
def test_bump_version():
    from sys import version_info
    from flutils.txtutils import safe_str

    if version_info.major == 2:
        from flutils.packages import __pkg_metadata__

    if version_info.major == 3:
        from flutils import __pkg_metadata__


# Generated at 2022-06-25 17:34:44.275238
# Unit test for function bump_version
def test_bump_version():
    ver = '0.0.0b2'
    ver = bump_version(ver)
    assert ver == '0.0.0b3'
    ver = bump_version(ver, position=0)
    assert ver == '1.0'
    ver = bump_version(ver, pre_release='b')
    assert ver == '1.0b0'
    ver = bump_version(ver, position=1, pre_release='a')
    assert ver == '1.0a0'
    ver = bump_version(ver)
    assert ver == '1.0a1'
    ver = bump_version(ver, pre_release='b')
    assert ver == '1.0b0'
    ver = bump_version(ver, position=1, pre_release='a')

# Generated at 2022-06-25 17:34:57.477657
# Unit test for function bump_version
def test_bump_version():
    v = bump_version('1.2.1', 3)
    assert v == '1.2.2'

    for vv in ('1.2.1', '1.2.1.0', '1.2.1.0.0', '1.2.1.0.0.0'):
        v = bump_version(vv)
        assert v == '1.2.2'

    for vv in ('1.2.0', '1.2.0.0', '1.2.0.0.0', '1.2.0.0.0.0'):
        v = bump_version(vv)
        assert v == '1.2.1'


# Generated at 2022-06-25 17:35:06.180891
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:28.795985
# Unit test for function bump_version
def test_bump_version():
    ver_str = '1.2.4'
    ver_str_bumped = bump_version(ver_str)
    assert ver_str_bumped == '1.2.5'
    ver_str = '2.1.3a1'
    bump_str = bump_version(ver_str, pre_release='a')
    assert bump_str == '2.1.3a2'
    bump_str = bump_version(ver_str, pre_release='b')
    assert bump_str == '2.1.3b0'
    bump_str = bump_version(ver_str)
    assert bump_str == '2.1.3'
    ver_str = '2.1.3a1'

# Generated at 2022-06-25 17:35:39.136991
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_0 = '1.22.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.22.4'
    str_0 = '1.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.3'
    str_0 = '1.2.3a0'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4a0'
    str_0 = '1.2.4a0'
    str_1 = bump_version(str_0, pre_release='alpha')


# Generated at 2022-06-25 17:35:42.183233
# Unit test for function bump_version
def test_bump_version():
    # Test case: 0
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:35:52.665898
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version(
        '1.3.4',
        position=0
    ) == '2.0'
    assert bump_version(
        '1.2.3',
        pre_release='a'
    ) == '1.2.4a0'
    assert bump_version(
        '1.2.4a0',
        pre_release='a'
    ) == '1.2.4a1'
    assert bump_version(
        '1.2.4a1',
        pre_release='b'
    ) == '1.2.4b0'

# Generated at 2022-06-25 17:36:03.780227
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:15.679685
# Unit test for function bump_version
def test_bump_version():
    #TODO: Make this a real unit test
    print(test_case_0())


# Set this to True when debugging this module.  It will cause the
# module to run when executed instead of being imported.
if __name__ == '__main__':
    import sys

    # Import all the functions in flutils.packages to make them
    # available in the console output.
    for func_name in dir(sys.modules[__name__]):
        func = getattr(sys.modules[__name__], func_name)
        if func_name.startswith('_') is False:
            globals()[func_name] = func

    import os
    import time
    import traceback
    import unittest

    # Set this to False to not run unit tests.  This will cause the
    # module to run when

# Generated at 2022-06-25 17:36:19.304086
# Unit test for function bump_version
def test_bump_version():
    return
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:36:21.529034
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 17:36:32.208970
# Unit test for function bump_version
def test_bump_version():
    # Test case #0
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    str_2 = '1.2.4'
    check: bool = (str_1 == str_2)
    assert check is True, 'bump_version() failed on test #0'

    # Test case #1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    str_2 = '1.3'
    check: bool = (str_1 == str_2)
    assert check is True, 'bump_version() failed on test #1'

    # Test case #2
    str_0 = '1.2.3'

# Generated at 2022-06-25 17:36:40.706019
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class BumpVersionTests(unittest.TestCase):
        def test_bump_version_00(self):
            str_0 = '1.2.3'
            str_1 = bump_version(str_0)
            self.assertEqual(str_1, '1.2.4')

        def test_bump_version_01(self):
            str_0 = '1.2.3'
            str_1 = bump_version(str_0, position=1)
            self.assertEqual(str_1, '1.3')

        def test_bump_version_02(self):
            str_0 = '1.2.3'
            str_1 = bump_version(str_0, position=0)

# Generated at 2022-06-25 17:37:06.144811
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


# Insert at top so's to be used when module is 'main'
################################################################################



# Generated at 2022-06-25 17:37:12.524533
# Unit test for function bump_version
def test_bump_version():
    import flutils.packages
    str_0 = '1.2.3'
    str_1 = flutils.packages.bump_version(str_0)
    assert str_1 == '1.2.4'

    str_0 = '1.2.1'
    str_1 = flutils.packages.bump_version(str_0)
    assert str_1 == '1.2.2'



# Generated at 2022-06-25 17:37:23.201339
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = '1.2.4'
    str_2 = bump_version(str_0)
    assert str_1 == str_2, 'Failed to bump version string {0}'.format(str_0)

    str_0 = '1.2.3'
    str_1 = '1.3'
    str_2 = bump_version(str_0, position=1)
    assert str_1 == str_2, 'Failed to bump version string {0}'.format(str_0)

    str_0 = '1.3.4'
    str_1 = '2.0'
    str_2 = bump_version(str_0, position=0)

# Generated at 2022-06-25 17:37:31.310278
# Unit test for function bump_version
def test_bump_version():
    print('\n')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()

    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()

    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()



# Generated at 2022-06-25 17:37:38.193134
# Unit test for function bump_version
def test_bump_version():
    ver_num = '13.4.0a4'
    for i in range(-3, 3):
        for pre_release in ['a', 'alpha', 'b', 'beta', None]:
            str_0 = bump_version(ver_num, position=i, pre_release=pre_release)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:37:39.139181
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:37:49.443119
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:56.188473
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    # Test case 1
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'

    # Test case 2
    str_0 = '1.3.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.3.4'

    # Test case 3
    str_0 = '1.1.0'
    str_1 = bump_version(str_0)
    assert str_1 == '1.1.1'

    # Test case 4

# Generated at 2022-06-25 17:38:03.496279
# Unit test for function bump_version
def test_bump_version():
    for ver_str in (
            '3.4.5',
            '3.4.5a1',
            '3.4.5b1',
            '3.4a1',
            '3.4b1',
            '3.4.5a1',
            '3.4.5b1',
            '3a1',
            '3b1'
    ):
        ver_info = _build_version_info(ver_str)
        assert str(ver_info.version) == ver_str

# Generated at 2022-06-25 17:38:14.371047
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:48.757664
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    test_case_0()


# vim: fileencoding=utf-8 filetype=python ts=4 sw=4 et

# Generated at 2022-06-25 17:38:52.754585
# Unit test for function bump_version
def test_bump_version():
    print('BEGIN TESTING')
    test_case_0()
    # test_case_1()
    # test_case_2()
    print('TESTING ENDED')


if __name__ == '__main__':
    test_bump_version()
# EOF

# Generated at 2022-06-25 17:39:00.755616
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, prerelease='a')

# Generated at 2022-06-25 17:39:13.364880
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.4') == '1.2.5'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:39:19.515540
# Unit test for function bump_version
def test_bump_version():
    ver = '2.0.0'
    bumped = bump_version(ver, pre_release='a')
    bumped = bump_version(bumped, pre_release='a')

    print(ver, "=>", bumped)
    assert bumped == '2.0.0a2'

    ver = '1.1.0'
    bumped = bump_version(ver, position=1, pre_release='b')

    print(ver, "=>", bumped)
    assert bumped == '1.2b0'

    ver = '1.1.0'
    bumped = bump_version(ver, position=0)

    print(ver, "=>", bumped)
    assert bumped == '2.0'

test_case_0()

test_bump_version()

# Generated at 2022-06-25 17:39:29.805650
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version


# Generated at 2022-06-25 17:39:40.016833
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function "bump_version"."""

    def _test_case(
            version: str,
            expected: str,
            position: int = -1,
            pre_release: Optional[str] = None
    ):
        result = bump_version(version, position, pre_release)
        if result != expected:
            msg = (
                "Expected '%s', given '%s', for the args:\n"
                "    version=%r\n"
                "    position=%r\n"
                "    pre_release=%r" % (
                    expected,
                    result,
                    version,
                    position,
                    pre_release
                )
            )
            raise AssertionError(msg)

    _test_case('1.2.3', '1.2.4')


# Generated at 2022-06-25 17:39:43.247583
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    # raise NotImplementedError("Please add test methods in test_bump_version")


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:46.814762
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version'."""
    # Test Case: 0
    test_case_0()


if __name__ == '__main__':
    # Run tests
    test_bump_version()
    print('Done.')

# Generated at 2022-06-25 17:39:55.167577
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'



# Generated at 2022-06-25 17:40:12.411335
# Unit test for function bump_version
def test_bump_version():
    import pytest
    from flutils.packages import bump_version

# Generated at 2022-06-25 17:40:21.024544
# Unit test for function bump_version
def test_bump_version():
    import flutils.packages
    v = ('0.5.5')
    assert(flutils.packages.bump_version(v) == '0.5.6')
    v = ('0.5.5a1')
    assert(flutils.packages.bump_version(v) == '0.5.6')
    v = ('0.5.5')
    assert(flutils.packages.bump_version(v, position=1) == '0.6')
    v = ('0.5.4')
    assert(flutils.packages.bump_version(v, position=1, pre_release='a') == '0.6a0')
    v = ('0.5.4')

# Generated at 2022-06-25 17:40:23.463904
# Unit test for function bump_version
def test_bump_version():

    try:
        test_case_0()
    except:
        raise


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:40:30.401583
# Unit test for function bump_version
def test_bump_version():
    """
    Test bump_version()
    """
    # --- 0 ---
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    # --- 1 ---
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    # --- 2 ---
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    # --- 3 ---
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, prerelease='a')
    assert str

# Generated at 2022-06-25 17:40:35.544306
# Unit test for function bump_version
def test_bump_version():
    # Setup
    str_0 = '1.2.3'

    # Exercise (Goal: '1.2.4')
    str_1 = bump_version(str_0)

    # Verify and assert
    assert str_1 == '1.2.4'



# Generated at 2022-06-25 17:40:44.424868
# Unit test for function bump_version
def test_bump_version():
    import flutils.packages
    test_case_0()
    str_0 = '1.2.3'
    str_1 = flutils.packages.bump_version(str_0)
    assert str_1 == '1.2.4'
    str_1 = flutils.packages.bump_version(str_0, 1)
    assert str_1 == '1.3'
    str_1 = flutils.packages.bump_version(str_0, 0)
    assert str_1 == '2.0'
    str_1 = flutils.packages.bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0'
    str_1 = flutils.packages.bump_version(str_0, pre_release='b')
   

# Generated at 2022-06-25 17:40:47.381555
# Unit test for function bump_version
def test_bump_version():
    # Test: bump_version('1.2.3')
    test_case_0()


# Main program section

# Generated at 2022-06-25 17:40:57.563163
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:41:10.739452
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""