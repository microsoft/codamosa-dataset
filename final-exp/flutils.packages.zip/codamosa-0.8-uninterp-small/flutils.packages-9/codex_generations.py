

# Generated at 2022-06-25 17:31:46.724453
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    tests = {
        0: '2.0',
        1: '1.3',
        2: '1.2.4',
        -1: '1.2.4',
        -2: '1.3',
        -3: '2.0',
        None: '1.2.3',
    }
    for position, out in tests.items():
        assert bump_version(version, position=position) == out


# Generated at 2022-06-25 17:31:55.708963
# Unit test for function bump_version
def test_bump_version():

    x = bump_version('1.2.2')
    assert x == '1.2.3'

    x = bump_version('1.2.3', position=1)
    assert x == '1.3'

    x = bump_version('1.3.4', position=0)
    assert x == '2.0'

    x = bump_version('1.2.3', prerelease='a')
    assert x == '1.2.4a0'

    x = bump_version('1.2.4a0', pre_release='a')
    assert x == '1.2.4a1'

    x = bump_version('1.2.4a1', pre_release='b')
    assert x == '1.2.4b0'


# Generated at 2022-06-25 17:32:01.200393
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:09.239379
# Unit test for function bump_version
def test_bump_version():
    import unittest
    from .test_classes import FlutilsTestCase

    class TestBumpVersion(FlutilsTestCase):

        def test_00(self):
            self.assertRaises(ValueError, bump_version, '0')

        def test_01(self):
            self.assertRaises(ValueError, bump_version, '0', position=0)

        def test_02(self):
            self.assertRaises(ValueError, bump_version, '0', position=-1)

        def test_03(self):
            self.assertRaises(ValueError, bump_version, '0', position=3)

        def test_04(self):
            self.assertRaises(ValueError, bump_version, '0', position=-3)


# Generated at 2022-06-25 17:32:20.849097
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    ver = '0.0.0'
    bump_ver = bump_version(ver)
    assert bump_ver == '0.0.1'

    ver = '0.0.0a0'
    bump_ver = bump_version(ver)
    assert bump_ver == '0.0.1'

    ver = '0.0.0b0'
    bump_ver = bump_version(ver)
    assert bump_ver == '0.0.1'

    ver = '0.1.2'
    bump_ver = bump_version(ver)
    assert bump_ver == '0.1.3'

    ver = '0.1.2a1'
    bump_ver = bump_version(ver)

# Generated at 2022-06-25 17:32:33.095440
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:42.225398
# Unit test for function bump_version
def test_bump_version():
    """

    :return:
    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:50.810327
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:03.296607
# Unit test for function bump_version
def test_bump_version():

    assert (
        bump_version('1.2.3') == '1.2.4'
    )

    assert (
        bump_version('1.2.3', position=1) == '1.3'
    )

    assert (
        bump_version('1.3.4', position=0) == '2.0'
    )

    assert (
        bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    )

    assert (
        bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    )

    assert (
        bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    )


# Generated at 2022-06-25 17:33:10.666494
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:46.085030
# Unit test for function bump_version
def test_bump_version():
    version: str
    new_version: str

    version = '1.2.3'
    new_version = bump_version(version)
    assert str(version) != str(new_version)

    version = '1.2.3'
    new_version = bump_version(version, 1)
    assert new_version == '1.3'

    version = '1.2.3'
    new_version = bump_version(version, 0)
    assert new_version == '2.0'

    version = '1.2.3'
    new_version = bump_version(version, pre_release='a')
    assert new_version == '1.2.4a0'

    version = '1.2.4a0'
    new_version = bump_version(version, pre_release='a')


# Generated at 2022-06-25 17:33:49.034182
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.
    """

    # noinspection PyUnusedLocal
    result: str = bump_version('1.2.3')


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:34:01.369881
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:10.705310
# Unit test for function bump_version
def test_bump_version():

    # Test going up a minor release with a patch release
    assert bump_version('1.2.2') == '1.2.3'

    # Test going up a major release
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test going up a patch release with a prerelease
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Test going up a patch release with an alpha
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Test going up a patch release with a beta
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

    # Test going up a

# Generated at 2022-06-25 17:34:12.747289
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'



# Generated at 2022-06-25 17:34:21.164974
# Unit test for function bump_version
def test_bump_version():
    """
    Unit testing for the ``bump_version`` function.
    The test cases are the examples shown in the function documentation.
    """

# Generated at 2022-06-25 17:34:32.268209
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Test 0
    expected_result = '1.2.3'
    got_result = bump_version('1.2.2')
    assert(expected_result == got_result)
    # Test 1
    expected_result = '1.3'
    got_result = bump_version('1.2.3', position=1)
    assert(expected_result == got_result)
    # Test 2
    expected_result = '2.0'
    got_result = bump_version('1.3.4', position=0)
    assert(expected_result == got_result)
    # Test 3
    expected_result = '1.2.4a0'
    got_result = bump_version('1.2.3', prerelease='a')

# Generated at 2022-06-25 17:34:43.844692
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.4') == '1.2.5'
    assert bump_version('1.2.4', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:57.134083
# Unit test for function bump_version
def test_bump_version():
    """Bump version number.

    Unit test for function: `bump_version`
    """
    # Define tests for a string which cannot be converted to a version number.
    tests_bad_version_number_string = (
        '',
        'a',
        'a.a',
        'a.a.a',
        '1.2.3.4',
        '1.2.3a.4',
        '1.2.3a0.4',
        '1.2.3a0.a',
        '1.2.3a0.a0',
    )
    for version_string in tests_bad_version_number_string:
        try:
            bump_version(version_string)
        except ValueError:
            pass

# Generated at 2022-06-25 17:35:06.102370
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    # Test with a simple version number
    assert bump_version('1.2.2') == '1.2.3'

    # Test with the 'minor' part
    assert bump_version('1.2.3', position=1) == '1.3'

    # Test with the 'major' part
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test with an alpha pre_release
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

    # Test bumping an alpha pre_release
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Test bumping a beta pre_release

# Generated at 2022-06-25 17:35:30.605075
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:40.217787
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', position=1) == '1.3.0'
    assert bump_version('1.3.4', position=0) == '2'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4.0'

# Generated at 2022-06-25 17:35:51.330474
# Unit test for function bump_version
def test_bump_version():
    # Test for no pre-release number
    assert bump_version('1.2.3') == '1.2.4'
    # Test bumping the minor number
    assert bump_version('1.2.2', position=1) == '1.3'
    # Test bumping the major number
    assert bump_version('1.2.2', position=0) == '2.0'
    # Test adding alpha pre-release
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    # Test bumping the alpha number
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Test switching from alpha to beta pre-release

# Generated at 2022-06-25 17:36:01.749402
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0201
    bump_version('1.2.3')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-25 17:36:14.700760
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:27.336933
# Unit test for function bump_version
def test_bump_version():
    """Test to ensure that function bump_version is working properly."""
    expected = '1.2.3'
    actual = bump_version('1.2.2')
    assert expected == actual, 'Expected: %s.  Got: %s' % (expected, actual)
    expected = '1.3'
    actual = bump_version('1.2.3', position=1)
    assert expected == actual, 'Expected: %s.  Got: %s' % (expected, actual)
    expected = '2.0'
    actual = bump_version('1.3.4', position=0)
    assert expected == actual, 'Expected: %s.  Got: %s' % (expected, actual)
    expected = '1.2.4a0'

# Generated at 2022-06-25 17:36:38.780427
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:51.780080
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """

# Generated at 2022-06-25 17:37:02.134718
# Unit test for function bump_version
def test_bump_version():
    # Valid major
    assert bump_version('1.2.3') == '1.2.4'
    # Valid minor
    assert bump_version('1.2.3', position=1) == '1.3'
    # Valid patch
    assert bump_version('1.3.4', position=0) == '2.0'
    # Valid alpha
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Valid alpha
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Valid beta
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    # Valid release

# Generated at 2022-06-25 17:37:13.106604
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:34.032296
# Unit test for function bump_version
def test_bump_version():
    ver_0 = '1.2.2'
    ver_1 = bump_version('1.2.2')
    assert ver_1 == '1.2.3'
    ver_2 = bump_version('1.2.2', position=1)
    assert ver_2 == '1.3'
    ver_3 = bump_version('1.2.2', position=2)
    assert ver_3 == '1.2.3'
    ver_4 = bump_version('1.2.2', position=0)
    assert ver_4 == '2.0'
    ver_5 = bump_version('1.2.2', position=0, pre_release='alpha')
    assert ver_5 == '2.0'
    ver_6 = bump_version('1.2.2', position=-1)


# Generated at 2022-06-25 17:37:44.307372
# Unit test for function bump_version
def test_bump_version():
    import unittest


    class TestBumpVersion(unittest.TestCase):

        def test_case_0(self):
            ver_obj = StrictVersion('1.2.3')
            for part in _each_version_part(ver_obj):
                out = part

        def test_case_1(self):
            ver_obj = StrictVersion('1.2.3a1')
            for part in _each_version_part(ver_obj):
                out = part

        def test_case_2(self):
            ver_obj = StrictVersion('1.2.3b1')
            for part in _each_version_part(ver_obj):
                out = part

        def test_case_3(self):
            ver_obj = StrictVersion('1.0.0')

# Generated at 2022-06-25 17:37:53.405189
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function 'bump_version'"""
    from flutils.testhelpers import (
        BasicTestCase,
        test_case_msg,
        test_version_info
    )
    from flutils.packages import bump_version
    test_cases = (
        BasicTestCase(
            True,
            bump_version,
            '2.0.0',
            0,
            pre_release='b'
        ),
    )
    test_case_msg(test_cases)
    for case in test_cases:
        print('version: ', case.args[0])
        print('position: ', case.args[1])
        print('pre_release: ', case.kwargs.get('pre_release', None))
        test_case_msg(case)
        ver_info = _build_version_

# Generated at 2022-06-25 17:38:04.150745
# Unit test for function bump_version
def test_bump_version():
    versions = (
        '1.2.2',
        '1.2.3',
        '1.3.4',
        '2.0',
        '1.2.3',
        '1.2.4a0',
        '1.2.4a1',
        '1.2.4b0',
        '1.2.4',
        '1.2.4',
        '2.2a0',
        '1.2.1',
    )
    for ver, ver_bumped in zip(versions[::2], versions[1::2]):
        assert bump_version(ver) == ver_bumped


if __name__ == '__main__':
    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:38:11.117697
# Unit test for function bump_version
def test_bump_version():
    try:
        bump_version('abc')
    except ValueError:
        pass

    assert bump_version('1.2.3') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:38:19.986687
# Unit test for function bump_version
def test_bump_version():
    test_cases = []

    # 0
    test_cases.append(
        (
            '1.2.2',
            {
                'default': '1.2.3',
            },
        )
    )

    # 1

# Generated at 2022-06-25 17:38:24.285644
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:34.493071
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version.

    *New in version 0.3*
    """
    # Setup

# Generated at 2022-06-25 17:38:44.648067
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase, TestSuite, TextTestRunner
    from unittest.mock import patch

    class TestCase_0_bump_version(TestCase):
        def test_case_0(self):
            tst_obj = bump_version('1.0.0')
            self.assertEqual(tst_obj, '1.0.1')

        def test_case_1(self):
            tst_obj = bump_version('1.2.3')
            self.assertEqual(tst_obj, '1.2.4')

        def test_case_2(self):
            tst_obj = bump_version('1.2.3', position=1)
            self.assertEqual(tst_obj, '1.3')


# Generated at 2022-06-25 17:38:55.371855
# Unit test for function bump_version
def test_bump_version():
    # Major part of version are bumped.
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', position=-3) == '2.0'

    # Minor part of version are bumped.
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=-2) == '1.3'

    # Patch part of version are bumped.
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=2) == '1.2.4'
    assert bump_version('1.2.3', position=-1) == '1.2.4'

    # Alpha versions are bumped

# Generated at 2022-06-25 17:39:26.738722
# Unit test for function bump_version
def test_bump_version():
    if bump_version('1.2.2') == '1.2.3':
        print('test_bump_version_0: PASS')
    else:
        print('test_bump_version_0: FAIL')

    if bump_version('1.2.3', position=1) == '1.3':
        print('test_bump_version_1: PASS')
    else:
        print('test_bump_version_1: FAIL')

    if bump_version('1.3.4', position=0) == '2.0':
        print('test_bump_version_2: PASS')
    else:
        print('test_bump_version_2: FAIL')


# Generated at 2022-06-25 17:39:34.791719
# Unit test for function bump_version

# Generated at 2022-06-25 17:39:46.389632
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:39:56.336322
# Unit test for function bump_version
def test_bump_version():
    # Correct operation on expected inputs
    bump_version('1.2.3', position=0)
    bump_version('1.2.3', position=1)
    bump_version('1.2.3', position=2)
    bump_version('1.2.3', position=2, pre_release='a')
    bump_version('1.2.3', position=2, pre_release='b')
    bump_version('1.2.3', position=-1)
    bump_version('1.2.3', position=-2)
    bump_version('1.2.3', position=-3)
    bump_version('1.2.3a0', position=2)
    bump_version('1.2.3a0', position=2, pre_release='a')

# Generated at 2022-06-25 17:40:00.367297
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:13.278383
# Unit test for function bump_version
def test_bump_version():
    from random import randint

    def test():
        expected = []
        actual = []
        for pos in range(3):
            for build in (None, 'a', 'alpha', 'b', 'beta'):
                expected.append(
                    bump_version('1.2.3', position=pos, pre_release=build)
                )
        positions = [randint(-3, 2) for _ in range(3)]
        pre_releases = ['a', 'alpha', 'b', 'beta']
        actual = [
            bump_version(
                '1.2.3',
                position=positions[idx],
                pre_release=pre_releases[idx]
            ) for idx in range(3)
        ]
        return expected, actual

    test_0 = test()
    test_1 = test

# Generated at 2022-06-25 17:40:16.100735
# Unit test for function bump_version
def test_bump_version():
    """Does the function bump_version work as expected?
    """
    assert bump_version('1.2.2') == '1.2.3'



# Generated at 2022-06-25 17:40:18.200191
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """
    >>> from flutils.packages import bump_version
    """

# Test for module import

# Generated at 2022-06-25 17:40:27.200874
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function flutils.packages.bump_version
    """
    import flutils.packages

    # If a version string is given, it should be a string.
    ver_str = '1.2.3.4'
    bump_ver_str = flutils.packages.bump_version(ver_str)
    assert type(bump_ver_str) == str

    # If a version string is given, it should have the same number of
    # parts as the given string, and each part should increase.
    for i in range(0, 10):
        ver_str = '1.2.3.4'
        ver_parts = ver_str.split('.')
        bump_ver_str = flutils.packages.bump_version(ver_str)
        bump_ver_parts = bump_ver

# Generated at 2022-06-25 17:40:39.494935
# Unit test for function bump_version
def test_bump_version():
    """Test the function ``bump_version`` using the ``unittest`` module."""
    import unittest

    class TestBumpVersion(unittest.TestCase):
        """Test the function ``bump_version`` in the module ``packages``."""

        def test_bump_version_0(self):
            return
            """Test the function ``bump_version`` with the input:
                `version` = (1)
                `position` = (2)
                `pre_release` = ('a')
            """
            # Test for function bump_version
            result = bump_version('1', 2, 'a')
            self.assertEqual(result, '1.0a0')

        def test_bump_version_1(self):
            return

# Generated at 2022-06-25 17:40:57.689092
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:41:10.783507
# Unit test for function bump_version
def test_bump_version():

    def test_0():
        """Test 0."""
        # Test with no parameters
        str_0 = "1.2.3"
        str_1 = bump_version(str_0)
        assert str_1 == "1.2.4"

    test_0()

    def test_1():
        """Test 1."""
        # Test with position= 1, patch increase
        str_0 = "1.2.3"
        str_1 = bump_version(str_0, position=1)
        assert str_1 == "1.3"

    test_1()

    def test_2():
        """Test 2."""
        # Test with position= 0, major increase
        str_0 = "1.2.3"
        str_1 = bump_version(str_0, position=0)
       