

# Generated at 2022-06-25 17:31:44.087149
# Unit test for function bump_version
def test_bump_version():
    # TODO: Add test cases to ensure that all error scenarios are caught by
    # the code.

    def build_test_case(
            version: str,
            position: str,
            pre_release: str,
            bumped: str,
    ) -> dict:
        return dict(
            version=version,
            position=position,
            pre_release=pre_release,
            bumped=bumped,
        )


# Generated at 2022-06-25 17:31:52.644259
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:02.517477
# Unit test for function bump_version
def test_bump_version():
    """Tests for function bump_version."""
    import sys
    import unittest

    # noinspection PyPep8Naming
    class TestCase_0(unittest.TestCase):
        """Test bump_version."""
        def runTest(self):
            """Tests for function bump_version."""
            import os
            import platform

            # pylint: disable=R0201
            # pylint: disable=R0913
            def test_case_0(self: Any, version: str, position: int):
                """Test case for function bump_version."""
                from flutils.packages import bump_version

                out = bump_version(
                    version=version,
                    position=position,
                )
                ver_info = _build_version_info(version)

# Generated at 2022-06-25 17:32:09.993757
# Unit test for function bump_version
def test_bump_version():
    import pytest

# Generated at 2022-06-25 17:32:21.449432
# Unit test for function bump_version
def test_bump_version():

    # Test case: 0
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_1)
    str_3 = bump_version(str_2, position=1)
    str_4 = bump_version(str_3, position=0)
    str_5 = bump_version(str_4, pre_release='a')
    str_6 = bump_version(str_5, pre_release='a')
    str_7 = bump_version(str_6, pre_release='b')
    str_8 = bump_version(str_5)
    str_9 = bump_version(str_7)
    str_10 = bump_version(str_9, position=2)

# Generated at 2022-06-25 17:32:33.982087
# Unit test for function bump_version
def test_bump_version():
    # Make sure that nothing actually changed
    version_1 = bump_version('1.2.3')
    if version_1 != '1.2.3':
        raise RuntimeError(
            "Expected '1.2.3' from bump_version('1.2.3') but got %r."
            % version_1
        )
    # Minors
    version_2 = bump_version('1.2.3', position=1)
    if version_2 != '1.3':
        raise RuntimeError(
            "Expected '1.3' from bump_version('1.2.3', position=1) "
            "but got %r." % version_2
        )
    version_3 = bump_version('1.3.4', position=0)

# Generated at 2022-06-25 17:32:44.729024
# Unit test for function bump_version
def test_bump_version():
    from flutils.common import (
        cmp_expected_actual_exact
    )

# Generated at 2022-06-25 17:32:56.862916
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'

    version = '1.2.x'
    try:
        assert bump_version(version)
    except ValueError:
        assert True is True
    else:
        assert True is False

    version = '1.2.1'
    assert bump_version(version) == '1.2.2'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, prerelease='b') == '1.2.1b0'
    assert bump_version(
        version,
        prerelease='b'
    ) == '1.2.1b0'
    assert bump_

# Generated at 2022-06-25 17:33:05.885255
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3.0'
    assert bump_version('1.3.4', position=0) == '2.0.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a0', prerelease='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:16.383772
# Unit test for function bump_version
def test_bump_version():
    import sys

    # Successes

# Generated at 2022-06-25 17:34:02.677347
# Unit test for function bump_version
def test_bump_version():
    """Test that bump_version bumps the version string as expected."""
    # Initialize baseline for function
    version = '0.0.4'
    result = bump_version(version)
    assert result == '0.0.5'

    # Increase major version
    version = '3.0.4'
    result = bump_version(version)
    assert result == '4.0.0'

    # Increase minor version
    version = '2.2.4'
    result = bump_version(version, position=1)
    assert result == '2.3'

    # Increase patch version
    version = '3.2.5'
    result = bump_version(version, position=2)
    assert result == '3.2.6'

    # Bad prerelease

# Generated at 2022-06-25 17:34:11.921485
# Unit test for function bump_version
def test_bump_version():
    # Test basic functionality
    ver_0 = bump_version('1.2.3')
    assert ver_0 == '1.2.4'
    ver_1 = bump_version('1.2.3', 1)
    assert ver_1 == '1.3'
    ver_2 = bump_version('1.3.4', 0)
    assert ver_2 == '2.0'
    # Test basic pre-release functionality
    ver_3 = bump_version('1.2.3', prerelease='a')
    assert ver_3 == '1.2.4a0'
    ver_4 = bump_version('1.2.4a0', prerelease='a')
    assert ver_4 == '1.2.4a1'

# Generated at 2022-06-25 17:34:15.522904
# Unit test for function bump_version
def test_bump_version():
    str_0 = 'C[%Dpbe"pdOu"v#'
    str_1 = bump_version(str_0, str_0)
    version_info_0 = _VersionInfo()
    delta_0 = version_info_0.version
    for tuple_0 in range(100):
        # Put the rest of the code here
        pass

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:34:27.501269
# Unit test for function bump_version
def test_bump_version():
    this_dir = os.path.dirname(__file__)
    set_dir = os.path.join(this_dir, 'set_a')
    exp_dir = os.path.join(this_dir, 'set_b')
    error_string = ''
    if os.path.isdir(set_dir):
        test_desc = "Test the 'bump_version()' function"
        print_info(test_desc)
        failed = False
        count = 0
        for item in os.listdir(set_dir):
            count += 1
            in_file = os.path.join(set_dir, item)
            if os.path.isfile(in_file):
                out_file = os.path.join(exp_dir, item)

# Generated at 2022-06-25 17:34:35.624343
# Unit test for function bump_version
def test_bump_version():
    pass

# Compiled regex for matching a version number in a string
# _re_version = re.compile(r'^\d+(\.\d+){0,2}(?:(a|b|rc)\d+)?$')
#
#
# def _each_version_part(
#         parts: Tuple[str, str]
# ) -> Generator[Tuple[int, str], None, None]:
#     """An iterator which yields each part of the version number.
#
#     Raises:
#         TypeError: if the given ``parts`` is not a 'tuple' of length 2.
#         ValueError: if the given ``parts`` is missing a value for the first
#             part or if the first part does not contain a valid version number.
#
#     """
#     if (isinstance(parts, tuple

# Generated at 2022-06-25 17:34:38.453839
# Unit test for function bump_version
def test_bump_version():
    # Test if attribute 'bump_version' of 'PackageUtils' class is callable
    assert callable(bump_version)



# Generated at 2022-06-25 17:34:50.117237
# Unit test for function bump_version
def test_bump_version():
    # Test with just major, minor and patch
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    # Test with only alpha
    assert bump_version('1.2.3', prerelease='a') == '1.2.3a0'
    assert bump_version('1.2.3a0', pre_release='a') == '1.2.3a1'
    # Test with only beta
    assert bump_version('1.2.3', prerelease='b') == '1.2.3b0'
    assert bump_version('1.2.3b0', pre_release='b')

# Generated at 2022-06-25 17:34:55.964503
# Unit test for function bump_version
def test_bump_version():
    try:
        test_case_0()
    except:  # noqa: E722
        print("**test_bump_version Error**")
        import traceback
        traceback.print_exc()

# Run the test_bump_version function
test_bump_version()

# Generated at 2022-06-25 17:35:05.994064
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for bump_version"""

# Generated at 2022-06-25 17:35:07.610075
# Unit test for function bump_version
def test_bump_version():
    # todo: test bump_version
    pass

# Generated at 2022-06-25 17:35:31.872512
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    version = "2.1.3"
    expected_1 = "2.2.0"
    expected_2 = "2.2a0"
    expected_3 = "2.1.4"

    # Act
    actual_1 = bump_version(version, position=1)
    actual_2 = bump_version(version, position=1, pre_release="a")
    actual_3 = bump_version(version, position=2)

    # Assert
    assert version != actual_1, "Should be different"
    assert version != actual_2, "Should be different"
    assert version != actual_3, "Should be different"
    assert expected_1 == actual_1, "Should be the same"
    assert expected_2 == actual_2, "Should be the same"
    assert expected_3

# Generated at 2022-06-25 17:35:40.903538
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:51.878832
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:03.004823
# Unit test for function bump_version
def test_bump_version():
    version_0 = '1.2.3'
    version_1 = bump_version(version_0)
    version_2 = bump_version(version_0, 0)
    version_3 = bump_version(version_0, 0, 'a')
    version_4 = bump_version(version_0, 0, 'b')
    version_5 = bump_version(version_0, 1)
    version_6 = bump_version(version_0, 1, 'a')
    version_7 = bump_version(version_0, 1, 'b')
    version_8 = bump_version(version_0, 2)
    version_9 = bump_version(version_0, 2, 'a')
    version_10 = bump_version(version_0, 2, 'b')

# Generated at 2022-06-25 17:36:14.895290
# Unit test for function bump_version
def test_bump_version():

    assert True is True
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:20.415460
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    expected_result = '1.5.0'
    version = '1.4.1'
    position = 1

    # Act
    actual_result = bump_version(version, position)

    # Assert
    assert(expected_result == actual_result)



# Generated at 2022-06-25 17:36:31.656099
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'

    assert bump_version('1.3.4', position=0) == '2.0'

    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'

    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:42.330044
# Unit test for function bump_version
def test_bump_version():
    print('bump_version')
    version_info_0 = _VersionInfo()
    version_info_1 = _VersionInfo()
    version_info_2 = _VersionInfo()
    version_info_3 = _VersionInfo()
    version_info_4 = _VersionInfo()
    version_info_5 = _VersionInfo()
    version_info_6 = _VersionInfo()
    version_info_7 = _VersionInfo()
    version_info_8 = _VersionInfo()
    version_info_9 = _VersionInfo()
    version_info_10 = _VersionInfo()
    version_info_11 = _VersionInfo()
    version_info_12 = _VersionInfo()
    version_info_13 = _VersionInfo()
    version_info_14 = _VersionInfo()
    version_info_15 = _VersionInfo

# Generated at 2022-06-25 17:36:54.030419
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:58.309025
# Unit test for function bump_version
def test_bump_version():
    str_0 = 'C[%Dpbe"pdOu"v#'
    str_1 = bump_version(str_0, str_0)
    version_info_0 = _VersionInfo()



# Generated at 2022-06-25 17:37:24.264110
# Unit test for function bump_version
def test_bump_version():
    """
    Test the bump_version function.

    Args:
        None.

    Returns:
        None.

    """
    ########################################################################
    # Test all possible bumps of 1.0.0
    ########################################################################
    assert '2.0' == bump_version('1.0.0', 0)
    assert '1.1' == bump_version('1.0.0', 1)
    assert '1.0.1' == bump_version('1.0.0', 2)

    ########################################################################
    # Test pre-releases
    ########################################################################
    assert '1.0.1a0' == bump_version('1.0.0', 2, 'a')

# Generated at 2022-06-25 17:37:33.199499
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, 1) == '1.3'
    assert bump_version(version, 0) == '2.0'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0') == '1.2.4'
    assert bump_

# Generated at 2022-06-25 17:37:43.791569
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.3.4', position=1) == '1.4'
    assert bump_version('2.1.3', position=1) == '2.2'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'

# Generated at 2022-06-25 17:37:53.091868
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.2'
    assert bump_version(version) == '1.2.3'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'
    version = '1.2.3'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'
    assert bump_version(version, pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:38:04.253934
# Unit test for function bump_version
def test_bump_version():
    # Test positional arguments
    str_1 = bump_version('0.0.0')
    assert str_1 == '0.0.1', str_1

    str_2 = bump_version('0.0.0', 0)
    assert str_2 == '1.0', str_2

    str_3 = bump_version('0.0.0', 1)
    assert str_3 == '0.1', str_3

    str_4 = bump_version('0.0.0', 2)
    assert str_4 == '0.0.1', str_4

    str_5 = bump_version('1.2.3')
    assert str_5 == '1.2.4', str_5

    str_6 = bump_version('1.2.3', 2)

# Generated at 2022-06-25 17:38:15.108453
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    ver_1 = '2.1.3'
    ver_2 = '2.2.0'
    ver_3 = '2.2b0'
    ver_4 = '2.2b0'

    # Act
    b_ver_1 = bump_version(ver_1, position=1)
    b_ver_2 = bump_version(ver_2, position=1)
    b_ver_3 = bump_version(ver_3, position=1)
    b_ver_4 = bump_version(ver_4, position=1)

    # Assert
    assert b_ver_1 == ver_2
    assert b_ver_2 == ver_2
    assert b_ver_3 == ver_2
    assert b_ver_4 == ver_2



# Generated at 2022-06-25 17:38:27.077833
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:38:35.200154
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:45.053007
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:55.652071
# Unit test for function bump_version

# Generated at 2022-06-25 17:39:14.174043
# Unit test for function bump_version
def test_bump_version():
    version = '3.0'
    position = 1
    pre_release = 'a'
    assert bump_version(version) == '3.0.1'
    assert bump_version(version, position=position) == '3.1'
    assert bump_version(version, pre_release=pre_release) == \
        '3.0.1a0'
    assert bump_version(version, position=position,
                        pre_release=pre_release) == '3.1a0'
    assert bump_version('1.2.3a0', pre_release='a') == '1.2.3a1'
    assert bump_version('1.2.3a0', pre_release='b') == '1.2.3b0'

# Generated at 2022-06-25 17:39:26.257361
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.0.1') == '1.0.2'
    assert bump_version('1.0.0', 0) == '2.0.0'
    assert bump_version('1.0.0', 1) == '1.1.0'
    assert bump_version('1.0.0', 2) == '1.0.1'
    assert bump_version('1.0.0', -1) == '1.0.1'
    assert bump_version('1.0.0', -2) == '1.1.0'
    assert bump_version('1.0.0', -3) == '2.0.0'

# Generated at 2022-06-25 17:39:33.800032
# Unit test for function bump_version

# Generated at 2022-06-25 17:39:46.059451
# Unit test for function bump_version
def test_bump_version():
    version_0 = '1.2.3'
    result_0 = bump_version(version_0)
    assert result_0 == '1.2.4'

    version_0 = '1.2.3'
    position_0 = 1
    result_0 = bump_version(version_0, position_0)
    assert result_0 == '1.3'

    version_0 = '1.2.3'
    position_0 = 0
    result_0 = bump_version(version_0, position_0)
    assert result_0 == '2.0'

    version_0 = '1.2.3'
    pre_release_0 = 'a'
    result_0 = bump_version(version_0, pre_release=pre_release_0)

# Generated at 2022-06-25 17:39:50.258271
# Unit test for function bump_version
def test_bump_version():
    import io
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # Replace stdout with mock object
    with captured_output() as (out, err):
        test_case_0()
    actual_stdout = out.getvalue().strip()
    actual_stderr = err.getvalue().strip()
    assert actual_stdout == ''

# Generated at 2022-06-25 17:39:59.625658
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:12.372616
# Unit test for function bump_version
def test_bump_version():

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=-2) == '1.3'
    assert bump_version('1.2.3', position=-3) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.3a0'
    assert bump_version('1.2.3a0') == '1.2.3'

# Generated at 2022-06-25 17:40:21.517644
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version"""

    # Test: 1
    # Raises TypeError when too few arguments are passed to the function
    assert bump_version()
    # Test: 2
    # Raises TypeError when too many arguments are passed to the function
    assert bump_version('1.2.3', '1.2.3')
    # Test: 3
    # Raises TypeError when a wrong argument is passed
    assert bump_version('1.2.3', '1.2.3', string = '1.2.3')
    # Test: 4
    assert bump_version('1.2.3') == '1.2.4'
    # Test: 5
    assert bump_version('1.2.3', position = 1) == '1.3'
    # Test: 6

# Generated at 2022-06-25 17:40:23.507228
# Unit test for function bump_version
def test_bump_version():
    # ...
    test_case_0()
    # ...

if (__name__ == '__main__'):
    test_bump_version()

# Generated at 2022-06-25 17:40:30.421354
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:50.245834
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version


# Generated at 2022-06-25 17:40:59.038099
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:41:11.068382
# Unit test for function bump_version