

# Generated at 2022-06-25 17:31:39.039861
# Unit test for function bump_version
def test_bump_version():
    version_0: str = '1.2.2'
    expected_0: str = '1.2.3'
    assert bump_version(version_0) == expected_0



# Generated at 2022-06-25 17:31:45.251117
# Unit test for function bump_version
def test_bump_version():
    str_err_msg_0 = "The given value for 'bump_pos', (), must be an 'int'"

    try:
        bump_version('')
    except ValueError as err:
        str_err_msg_1 = str(err)

    try:
        bump_version('')
    except ValueError as err:
        str_err_msg_1 = str(err)

    try:
        bump_version('')
    except ValueError as err:
        str_err_msg_1 = str(err)


# Generated at 2022-06-25 17:31:53.720347
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:03.552068
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0') == '1.2.4'
    assert bump_version('2.1.3', position=1, prerelease='a') == '2.2a0'

# Generated at 2022-06-25 17:32:14.688757
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:24.652888
# Unit test for function bump_version
def test_bump_version():
    """Test ``bump_version`` function.

    :rtype:
        :obj:`bool`

        * ``True`` if all tests passed.
        * ``False`` if one or more tests failed.

    """

# Generated at 2022-06-25 17:32:36.546051
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:43.982322
# Unit test for function bump_version
def test_bump_version():
    """Test function: `bump_version`"""
    if True:
        # Test
        assert bump_version('1.2.2') == '1.2.3'
        # Test
        assert bump_version('1.2.3', position=1) == '1.3'
        # Test
        assert bump_version('1.3.4', position=0) == '2.0'
        # Test
        assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
        # Test
        assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
        # Test
        assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'


# Generated at 2022-06-25 17:32:51.833492
# Unit test for function bump_version
def test_bump_version():
    test_input_0 = '1.2.3'
    test_output_0 = '1.2.4'
    test_input_1 = '0.2.3'
    test_output_1 = '0.2.4'
    test_input_2 = '0.2.0'
    test_output_2 = '0.2.1'
    test_input_3 = '1.1.1'
    test_output_3 = '1.2.0'
    test_input_4 = '1.1.1'
    test_output_4 = '2.0.0'
    test_input_5 = '1.1.1'
    test_output_5 = '1.1.4a0'
    test_input_6 = '1.1.4a0'


# Generated at 2022-06-25 17:33:04.219506
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('0.0.2') == '0.0.3'
    assert bump_version('0.0.0', position=1) == '0.1'
    assert bump_version('0.1', position=1) == '0.2'
    assert bump_version('0.2', position=1) == '0.3'
    assert bump_version('0.0.0', position=0) == '1.0'
    assert bump_version('1.0', position=0) == '2.0'
    assert bump_version('2.0', position=0) == '3.0'

# Generated at 2022-06-25 17:33:34.578352
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:44.712926
# Unit test for function bump_version
def test_bump_version():
    # Test
    assert bump_version('1.2.2') == '1.2.3'
    # Test
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test
    assert bump_version('1.3.4', position=0) == '2.0'
    # Test
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Test
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Test
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    # Test
    assert bump_version('1.2.4a1')

# Generated at 2022-06-25 17:33:52.323317
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    assert bump_version('1.2.2') == '1.2.3'
    # Test case 1
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test case 2
    assert bump_version('1.3.4', position=0) == '2.0'
    # Test case 3
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Test case 4
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Test case 5
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    # Test case 6


# Generated at 2022-06-25 17:34:02.722189
# Unit test for function bump_version
def test_bump_version():
    print('\napp.packages.test_bump_version()')

    def run_test(ver_in, ver_out, position, bump_type):
        print(
            '  input: {}\n'
            ' output: {} ({}, {})'.format(
                ver_in,
                ver_out,
                position,
                bump_type
            )
        )
        ver = bump_version(ver_in, position=position, pre_release=bump_type)
        assert ver == ver_out

    def run_test_error(ver_in, position, pre_release):
        print(
            '  input: {} ({}, {})'.format(
                ver_in,
                position,
                pre_release
            )
        )

# Generated at 2022-06-25 17:34:11.944851
# Unit test for function bump_version
def test_bump_version():
    version_0 = '1.2.2'
    version_1 = bump_version(version_0)
    assert version_1 == '1.2.3'

    version_0 = '1.2.3'
    position = 1
    version_1 = bump_version(version_0, position)
    assert version_1 == '1.3'

    version_0 = '1.3.4'
    position = 0
    version_1 = bump_version(version_0, position)
    assert version_1 == '2.0'

    version_0 = '1.2.3'
    pre_release = 'a'
    version_1 = bump_version(version_0, pre_release=pre_release)
    assert version_1 == '1.2.4a0'


# Generated at 2022-06-25 17:34:21.412186
# Unit test for function bump_version
def test_bump_version():
    cur_version = '0.1.1a1'
    assert bump_version(cur_version) == '0.1.1'
    assert bump_version(cur_version, 2, 'a') == '0.1.1a2'
    assert bump_version(cur_version, 2, 'b') == '0.1.1b1'


if __name__ == '__main__':
    import sys
    from flutils.packages import bump_version
    from pyutils.version import get_version_long

    pkg_name = 'flutils'
    cur_version = get_version_long(pkg_name)
    pos = 2
    if len(sys.argv) > 1:
        pos = int(sys.argv[1])

# Generated at 2022-06-25 17:34:32.505501
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:40.518437
# Unit test for function bump_version
def test_bump_version():
    ver_0 = '1.2.3'
    pos_0 = 2
    pre_0 = None
    out_0 = bump_version(ver_0, pos_0, pre_0)

    print('ver_0: %s' % ver_0)
    print('pos_0: %s' % pos_0)
    print('pre_0: %s' % pre_0)
    print('out_0: %s' % out_0)



# Generated at 2022-06-25 17:34:49.801080
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.2'
    desired = '1.2.3'
    out = bump_version(version)
    assert out == desired, out

    desired = '1.2.2a0'
    out = bump_version(version, pre_release='a')
    assert out == desired, out

    version = '1.2.2a0'
    desired = '1.2.2a1'
    out = bump_version(version, pre_release='a')
    assert out == desired, out

    version = '1.2.2a1'
    desired = '1.2.2b0'
    out = bump_version(version, pre_release='b')
    assert out == desired, out

    version = '1.2.2a1'

# Generated at 2022-06-25 17:34:58.550770
# Unit test for function bump_version
def test_bump_version():
    # 1
    res = bump_version('1.2.2')
    assert res == '1.2.3'

    # 2
    res = bump_version('1.2.3', position=1)
    assert res == '1.3'

    # 3
    res = bump_version('1.3.4', position=0)
    assert res == '2.0'

    # 4
    res = bump_version('1.2.3', prerelease='a')
    assert res == '1.2.4a0'

    # 5
    res = bump_version('1.2.4a0', pre_release='a')
    assert res == '1.2.4a1'

    # 6
    res = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-25 17:35:21.533315
# Unit test for function bump_version
def test_bump_version():
    ver = bump_version('1.2.3', position=0, pre_release='a')
    assert ver == '2.0a0'
    ver = bump_version('1.2.3', position=0, pre_release='b')
    assert ver == '2.0b0'
    ver = bump_version('1.2.3', position=1, pre_release='a')
    assert ver == '1.3a0'
    ver = bump_version('1.2.3', position=1, pre_release='b')
    assert ver == '1.3b0'
    ver = bump_version('1.2.3', position=2, pre_release='a')
    assert ver == '1.2.4a0'

# Generated at 2022-06-25 17:35:32.845531
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):

        def test_basic(self):
            res = bump_version('1.2.2')
            self.assertEqual(res, '1.2.3')

        def test_minor(self):
            res = bump_version('1.2.3', position=1)
            self.assertEqual(res, '1.3')

        def test_major(self):
            res = bump_version('1.3.4', position=0)
            self.assertEqual(res, '2.0')

        def test_alpha(self):
            res = bump_version('1.2.3', prerelease='a')
            self.assertEqual(res, '1.2.4a0')


# Generated at 2022-06-25 17:35:41.442521
# Unit test for function bump_version
def test_bump_version():
    """Test function to test the bump_version function"""

    def test_case_0():
        print('Test case 0: No args')
        try:
            bump_version('')
        except ValueError:
            pass
        else:
            raise RuntimeError('Test case 0 failed: No args')

    def test_case_1():
        print('Test case 1: 1 arg')
        try:
            bump_version('1.2.3')
        except ValueError:
            raise RuntimeError('Test case 1 failed: 1 arg')

    def test_case_2():
        print('Test case 2: 2 args')
        try:
            bump_version('1.2.3', position=2)
        except ValueError:
            raise RuntimeError('Test case 2 failed: 2 args')

    def test_case_3():
        print

# Generated at 2022-06-25 17:35:52.298625
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """
    Test the bump_version function.
    """
    import pytest

    version_info_a = _build_version_info('1.2.3')
    assert version_info_a.major.name == 'major'
    assert version_info_a.major.num == 1
    assert version_info_a.major.pre_num == -1
    assert version_info_a.major.pre_txt == ''
    assert version_info_a.major.txt == '1'

    assert version_info_a.minor.name == 'minor'
    assert version_info_a.minor.num == 2
    assert version_info_a.minor.pre_num == -1
    assert version_info_a.minor.pre_txt == ''
    assert version

# Generated at 2022-06-25 17:36:03.422356
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('0.0.1') == '0.0.2'
    assert bump_version('1.1.0') == '1.1.1'
    assert bump_version('0.0.0', position=0) == '1.0'
    assert bump_version('1.1.1', position=1) == '1.2'
    assert bump_version('0.0.1', position=2) == '0.0.2'
    assert bump_version('1.1.0', position=2) == '1.1.1'

# Generated at 2022-06-25 17:36:15.389184
# Unit test for function bump_version
def test_bump_version():
    def do_test(version, position, pre_release):
        bumped = bump_version(version, position, pre_release)
        print('version: %r' % version)
        print('position: %r' % position)
        print('pre_release: %r' % pre_release)
        print('bumped: %r\n' % bumped)
    do_test('1.2.2', 2, 'a')
    do_test('1.2.3', 1, 'alpha')
    do_test('1.3.4', 0, 'b')
    do_test('1.2.3', position=2, pre_release='a')
    do_test('1.2.4a0', position=2, pre_release='a')

# Generated at 2022-06-25 17:36:27.377747
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    assert bump_version('1.3.4') == '1.3.5'
    assert bump_version('1.3.4', position=1) == '1.4'
    assert bump_version('1.3.4', position=0) == '2'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:35.689868
# Unit test for function bump_version
def test_bump_version():
    value = bump_version(
        version='1.2.3',
        position=2,
        pre_release='a'
    )
    assert value == '1.2.4a0'

    value = bump_version(
        version='1.2.4a0',
        position=2,
        pre_release='a'
    )
    assert value == '1.2.4a1'

    value = bump_version(
        version='1.2.4a1',
        position=2,
        pre_release='b'
    )
    assert value == '1.2.4b0'

    value = bump_version(
        version='1.2.4a1',
        position=2,
        pre_release=None
    )
    assert value == '1.2.4'



# Generated at 2022-06-25 17:36:43.939936
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint
    version = '1.2.2'
    assert bump_version(version) == '1.2.3', 'bump_version(version)'
    version = '1.2.3'
    assert (
        bump_version(version, position=1) == '1.3'
    ), 'bump_version(version, position=1)'
    version = '1.3.4'
    assert (
        bump_version(version, position=0) == '2.0'
    ), 'bump_version(version, position=0)'
    version = '1.2.3'
    assert (
        bump_version(version, pre_release='a') == '1.2.4a0'
    ), 'bump_version(version, pre_release="a")'
    version

# Generated at 2022-06-25 17:36:55.950498
# Unit test for function bump_version
def test_bump_version():
    from os.path import join, dirname
    from unittest import TestCase, main
    from flutils.packages import bump_version

    class BumpVersionTestCase(TestCase):
        """Unit tests for function 'bump_version()'."""
        def test_bump_version_default(self):
            self.assertEqual(bump_version('0.01.002'), '0.01.3')

        def test_bump_version_pre_release(self):
            self.assertEqual(bump_version('0.01.002', pre_release='beta'),
                             '0.01.2b0')
            self.assertEqual(bump_version('0.01.002', pre_release='a'),
                             '0.01.2a0')


# Generated at 2022-06-25 17:37:07.445522
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:17.584121
# Unit test for function bump_version
def test_bump_version():
    # Unit test for function bump_version
    def _test_case_0():
        _test_item_0 = bump_version('1.2.2')
        assert _test_item_0 == '1.2.3'
    _test_case_0()

    def _test_case_1():
        _test_item_0 = bump_version('1.2.3', position=1)
        assert _test_item_0 == '1.3'
    _test_case_1()

    def _test_case_2():
        _test_item_0 = bump_version('1.3.4', position=0)
        assert _test_item_0 == '2.0'
    _test_case_2()

    def _test_case_3():
        _test_item_0 = bump_

# Generated at 2022-06-25 17:37:27.782591
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:38.918549
# Unit test for function bump_version
def test_bump_version():
    #assert bump_version('1.2.2') == '1.2.3'
    #assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.3.4', position=-1) == '1.3.4'
    assert bump_version('1.3.4', position=-3) == '1.3.4'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

# Generated at 2022-06-25 17:37:49.222330
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    # type: (...) -> None

    # Major
    assert bump_version('1.2.4b1') == '2.0'
    # Minor
    assert bump_version('1.2.5') == '1.3'
    # Patch
    assert bump_version('1.2.3.4') == '1.2.3.5'
    # Alpha
    assert bump_version('1.2.3b1') == '1.2.4a0'
    assert bump_version('1.2.3a0') == '1.2.3a1'
    # Beta
    assert bump_version('1.2.3') == '1.2.4b0'

# Generated at 2022-06-25 17:37:56.082064
# Unit test for function bump_version
def test_bump_version():

    # Example 1
    # The default bump of the patch part.
    version = '1.2.3'
    bump_type = bump_version(version)
    assert bump_type == '1.2.4'

    # Example 2
    # Increase the minor part.
    version = '1.2.3'
    bump_type = bump_version(version, position=1)
    assert bump_type == '1.3'

    # Example 3
    # Increase the major part.
    version = '1.2.3'
    bump_type = bump_version(version, position=0)
    assert bump_type == '2'

    # Example 4
    # Increase the patch part with a minor pre-release number.
    version = '1.2.3'

# Generated at 2022-06-25 17:38:07.145484
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:17.104541
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:28.724810
# Unit test for function bump_version
def test_bump_version():
    test_cases: List[Tuple[str, int, str]] = [
        ('1.2.3', 2, '1.2.4'),
        ('1.2.4', 2, '1.2.5'),
        ('1.2.4', 1, '1.3'),
        ('1.4.4', 1, '1.5'),
        ('1.4.4', 0, '2.0'),
        ('1.2.3', 2, '1.2.4'),
        ('1.2.3', 2, '1.2.4'),
        ('1.2.3', 2, '1.2.4'),
        ('1.2.3', 2, '1.2.4'),
        ('1.2.3', 2, '1.2.4'),
    ]

# Generated at 2022-06-25 17:38:40.647709
# Unit test for function bump_version
def test_bump_version():
    n = 0
    for ver in (
            '1', '1.2', '1.2.3', '1.2.3a0', '1.2.3a1', '1.2.3b0', '1.2.3b1',
    ):
        v1 = bump_version(ver)
        v3 = bump_version(ver, position=3)
        v2 = bump_version(v1, position=1)
        v1 = bump_version(v2, position=0)
        v2 = bump_version(v1, position=1)
        v1 = bump_version(v2, position=0)
        v2 = bump_version(v1, position=1)
        v1 = bump_version(v2, position=0)

# Generated at 2022-06-25 17:39:00.096611
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    min_version = '1.2.2'
    assert bump_version(min_version) == '1.2.3'
    assert bump_version(min_version, position=1) == '1.3'
    assert bump_version(min_version, position=0) == '2.0'
    assert bump_version(min_version, prerelease='a') == '1.2.4a0'
    assert bump_version(min_version, prerelease='a') == '1.2.4a0'
    assert bump_version(min_version, prerelease='a') == '1.2.4a0'
    assert bump_version(min_version, prerelease='A') == '1.2.4a0'

# Generated at 2022-06-25 17:39:12.356431
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyTypeChecker
    bump_version(None)  # noqa: F841

    # Test input: ('1.2.3', 0)
    res_0 = bump_version('1.2.3', 0)
    assert '2.0' == res_0

    # Test input: ('1.0.0', 1)
    res_1 = bump_version('1.0.0', 1)
    assert '1.1' == res_1

    # Test input: ('2.0.0', 2)
    res_2 = bump_version('2.0.0', 2)
    assert '2.0.1' == res_2

    # Test input: ('1.2.3', 0)
    res_3 = bump_version('1.2.3')

# Generated at 2022-06-25 17:39:19.434102
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function from ``flutils.packages``.

    To run this test, you can install ``flutils[test]``.

    Example:
        >>> from flutils.packages import test_bump_version
        >>> test_bump_version()

    """
    ver = '1.2.3'
    assert bump_version(ver) == '1.2.4'
    assert bump_version(ver, position=1) == '1.3'
    assert bump_version(ver, position=0) == '2.0'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'
    assert bump_version(ver, pre_release='a') == '1.2.4a0'

# Generated at 2022-06-25 17:39:29.712112
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=W0212
    assert _build_version_bump_position(1) == 1
    assert _build_version_bump_position(0) == 0
    assert _build_version_bump_position(2) == 2
    assert _build_version_bump_position(-1) == 3
    assert _build_version_bump_position(-2) == 4
    assert _build_version_bump_position(-3) == 5
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

# Generated at 2022-06-25 17:39:36.826678
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:39:48.724608
# Unit test for function bump_version
def test_bump_version():
    try:
        _build_version_bump_position(-4)
        assert False
    except ValueError:
        assert True

    try:
        _build_version_bump_position(3)
        assert False
    except ValueError:
        assert True

    try:
        _build_version_bump_type(0, 'a')
        assert False
    except ValueError:
        assert True

    try:
        _build_version_bump_type(0, 'alpha')
        assert False
    except ValueError:
        assert True

    try:
        _build_version_bump_type(0, 'b')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 17:39:58.207838
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:09.391259
# Unit test for function bump_version
def test_bump_version():
    # Test case 1
    assert bump_version('0.0.0') == '0.0.1'
    # Test case 2
    assert bump_version('1.2.3') == '1.2.4'
    # Test case 3
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test case 4
    assert bump_version('1.2.3', position=0) == '2.0'
    # Test case 5
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Test case 6
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'

    # Test case 7

# Generated at 2022-06-25 17:40:20.062831
# Unit test for function bump_version
def test_bump_version():
    # Test adding an item to the end of an empty list
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2') == '1.2.1'
    assert bump_version('1.2', 1) == '1.3'
    assert bump_version('1.2', 1, 'a') == '1.3a0'
    assert bump_version('1.2.4a0', 'a') == '1.2.4a1'
    assert bump_version('1.2.4a1', 'a') == '1.2.4a2'
    assert bump_version('1.2.4b0', 'b') == '1.2.4b1'

# Generated at 2022-06-25 17:40:28.628418
# Unit test for function bump_version
def test_bump_version():
    # Increase the patch value
    assert bump_version('1.2.2') == '1.2.3'

    # Increase the minor value
    assert bump_version('1.2.3', position=1) == '1.3'

    # Increase the major value
    assert bump_version('1.3.4', position=0) == '2.0'

    # Add an alpha
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    # Increase the alpha version
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Add a beta
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

    #

# Generated at 2022-06-25 17:40:48.779053
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:54.621406
# Unit test for function bump_version
def test_bump_version():
    ver = '1.5.5'
    pos = 2
    pre_release = 'a'

    out = bump_version(ver, pos, pre_release)
    assert out == '1.5.6a0'
    out2 = bump_version(out, pos, pre_release)
    assert out2 == '1.5.6a1'
    out3 = bump_version(out2, pos, 'b')
    assert out3 == '1.5.6b0'
    out4 = bump_version(out2)
    assert out4 == '1.5.6'
    out5 = bump_version(out3)
    assert out5 == '1.5.6'
    out6 = bump_version(ver, pos=1, pre_release='a')

# Generated at 2022-06-25 17:41:07.137134
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', 1) == '1.3'
    assert bump_version('1.2.2', 0) == '2.0'
    assert bump_version('1.2.2', 1, 'a') == '1.3a0'
    assert bump_version('1.3a0') == '1.3'
    assert bump_version('1.3a0', 1, 'b') == '1.3b0'
    assert bump_version('1.3b0') == '1.3.1'