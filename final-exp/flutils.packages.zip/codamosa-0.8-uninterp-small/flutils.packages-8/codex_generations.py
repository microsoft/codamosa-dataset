

# Generated at 2022-06-25 17:31:44.558845
# Unit test for function bump_version
def test_bump_version():
    """Lint code stored in code_to_lint.py."""
    assert True is True
    return True



if __name__ == '__main__':
    import os
    import sys
    import unittest
    sys.path.insert(0, os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..')))
    from flutils.packages import bump_version  # noqa: E402
    del os
    del sys


    class Test_bump_version(unittest.TestCase):
        """Lint code stored in code_to_lint.py."""

        def test_0(self):
            """Test case for bump_version."""

# Generated at 2022-06-25 17:31:53.067344
# Unit test for function bump_version
def test_bump_version():
    # Test the case where a different part is given for 'position', than
    # for what is the actual version number
    version_info_0 = _build_version_info('1.2.2')
    assert version_info_0.major.txt == '1'
    assert version_info_0.minor.txt == '2'
    assert version_info_0.patch.txt == '2'
    assert version_info_0.major.name == 'major'

    version_info_1 = _build_version_info('1.2')
    assert version_info_1.major.txt == '1'
    assert version_info_1.minor.txt == '2'
    assert version_info_1.patch.txt == ''
    assert version_info_1.patch.num == 0

    # Test a version number

# Generated at 2022-06-25 17:32:02.919905
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:13.649223
# Unit test for function bump_version
def test_bump_version():
    """Tests the ``bump_version`` function.

    The following is the result of running this test in the console:

    .. code-block:: none

        ----------------------------------------------------------------------
        Ran 1 test in 0.000s

        OK


    """
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-25 17:32:23.818640
# Unit test for function bump_version
def test_bump_version():
    import pytest

    v = '1.2.3'
    assert bump_version(v) == '1.2.4'
    assert bump_version(v, 0) == '2.0'
    assert bump_version(v, 1) == '1.3'
    assert bump_version(v, 2) == '1.2.4'
    assert bump_version(v, -1) == '1.2.4'
    assert bump_version(v, -2) == '1.3'
    assert bump_version(v, -3) == '2.0'

    v = '1.2.3a0'
    assert bump_version(v, 0) == '2.0'
    assert bump_version(v, 1) == '1.3a0'

# Generated at 2022-06-25 17:32:35.787186
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:43.513909
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:51.576716
# Unit test for function bump_version
def test_bump_version():
    # A call to bump_version
    # A call to bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
   

# Generated at 2022-06-25 17:33:03.987722
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:11.085243
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:47.945076
# Unit test for function bump_version
def test_bump_version():
    # 0: Testing: '1.2.2' => '1.2.3'
    try:
        assert (
            bump_version('1.2.2') == '1.2.3'
        )
    except AssertionError:
        err_msg = (
            'Should be: \'1.2.3\' but is instead: %r' %
            bump_version('1.2.2')
        )
        raise AssertionError(err_msg)
    # 1: Testing: '1.2.3' => '1.3'

# Generated at 2022-06-25 17:33:59.728474
# Unit test for function bump_version
def test_bump_version():
    version_0: str = bump_version('1.2.2')
    version_1 = bump_version(version_0)
    version_2 = bump_version(version_1)
    version_3 = bump_version(version_2, position=1)
    version_4 = bump_version(version_3)
    version_5 = bump_version(version_4)
    version_6 = bump_version(version_5, position=0)
    version_7 = bump_version(version_6)
    version_8 = bump_version(version_7)
    version_9 = bump_version(version_8, position=1, pre_release='a')
    version_10 = bump_version(version_9, pre_release='a')

# Generated at 2022-06-25 17:34:07.933567
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:18.633717
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase

    from . import test_utils

    # noinspection PyUnresolvedReferences
    class Test_bump_version(TestCase):
        """Unit tests for function "bump_version"."""

        def test_case_0(self):
            """Test case 0.

            This test case is adapted from:
                https://github.com/mverleg/versions/blob/master/tests/test_versions.py

            """
            # Arrange
            expected = '0.0.1'
            version = '0.0.0'
            # Act
            result = bump_version(version)
            # Assert
            self.assertEqual(expected, result)

        def test_case_1(self):
            # Arrange
            expected = '0.0.2'
            version

# Generated at 2022-06-25 17:34:30.625584
# Unit test for function bump_version
def test_bump_version():
    version_0 = '1.2.3'

    bump_version(version_0)  # '1.2.3'
    bump_version(version_0, position=1)  # '1.3'
    bump_version(version_0, position=0)  # '2.0'
    bump_version(version_0, prerelease='a')  # '1.2.4a0'
    bump_version(version_0, pre_release='a')  # '1.2.4a1'
    bump_version(version_0, pre_release='b')  # '1.2.4b0'
    bump_version(version_0)  # '1.2.4'
    bump_version(version_0, pre_release='b')  # '1.2.4'
   

# Generated at 2022-06-25 17:34:42.918066
# Unit test for function bump_version
def test_bump_version():
    def run_test(test_input: str, test_output: str,
                 test_position: int = 2, test_pre_release: str = None):
        """Runs a bump version unit test.

        Args:
            test_input (str): The version to be bumped.
            test_output (str): The result of the bump.
            test_position (int, optional): The position to bump. Default to: 2
            test_pre_release (str, optional): If provided, the bump is a
                pre-release bump.

        Raises:
            AssertionError: If the bump fails.

        """
        actual = bump_version(
            test_input,
            position=test_position,
            pre_release=test_pre_release
        )

# Generated at 2022-06-25 17:34:56.346780
# Unit test for function bump_version
def test_bump_version():
    """
    Testing function bump_version
    """
    version = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', pre_release='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-25 17:35:06.021930
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:15.368849
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:27.974173
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:35.962824
# Unit test for function bump_version
def test_bump_version():
    print('\n' * 3)

    test_case_0()

    print('\n\n' + 60 * '*')



# Generated at 2022-06-25 17:35:47.262900
# Unit test for function bump_version
def test_bump_version():
    # Setup
    str_0 = '1.2.2'
    str_1 = '1.2.3'
    str_2 = '1.3'
    str_3 = '2.0'
    str_4 = '1.2.4a0'
    str_5 = '1.2.4a1'
    str_6 = '1.2.4b0'
    str_7 = '1.2.4'
    str_8 = '1.2.4'
    str_9 = '2.2a0'
    str_10 = '1.2.1'

    # Testing bump_version()
    str_11 = bump_version(str_0)
    assert str_11 == str_1
    str_12 = bump_version(str_0, position=1)


# Generated at 2022-06-25 17:35:50.200864
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    assert str_1 == str_2



# Generated at 2022-06-25 17:36:01.288934
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'

    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    str_2 = '1.2.2'
    str_3 = bump_version(str_2)
    assert str_3 == '1.2.3'
    str_4 = bump_version(str_3, position=2)
    assert str_4 == '1.2.4'

# Generated at 2022-06-25 17:36:05.536352
# Unit test for function bump_version
def test_bump_version():
    for index, method in enumerate([test_case_0]):
        try:
            print('')
            method()
            print('\tpassed: {}'.format(method.__name__))
        except AssertionError as err:
            print(
                '\tFAILED: {}: {}'.format(
                    method.__name__,
                    err,
                )
            )

# Generated at 2022-06-25 17:36:17.017904
# Unit test for function bump_version
def test_bump_version():
    tuple_0 = bump_version('1.2.3')
    tuple_1 = '1.2.4'
    assert tuple_0 == tuple_1

    tuple_2 = bump_version('1.2.2', 2)
    tuple_3 = '1.2.3'
    assert tuple_2 == tuple_3

    tuple_4 = bump_version('1.3.4')
    tuple_5 = '1.3.5'
    assert tuple_4 == tuple_5

    tuple_6 = bump_version('1.3.4', pre_release='b')
    tuple_7 = '1.3.4b0'
    assert tuple_6 == tuple_7

    tuple_8 = bump_version('1.3.4a1', pre_release='b')

# Generated at 2022-06-25 17:36:28.856833
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    str_0 = '1.2.2'
    # noinspection PyUnusedLocal
    str_1 = '2.0'
    # noinspection PyUnusedLocal
    str_2 = str_1 + str_0
    # noinspection PyUnusedLocal
    str_3 = 'M7)M2P{e'
    # noinspection PyUnusedLocal
    str_4 = '>rG)fNY$\\8,\\$Qz`'
    # noinspection PyUnusedLocal
    str_5 = 'cQ'
    # noinspection PyUnusedLocal
    str_6 = '1.2.3'
    # noinspection PyUnusedLocal
    i_0 = int(str_6)
    # noinspection PyUnused

# Generated at 2022-06-25 17:36:36.559788
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:42.438263
# Unit test for function bump_version
def test_bump_version():
    try:
        import flutils.packages as fpkg
    except ImportError:
        fpkg = reload(fpkg)
    # Verify the function has the same name as the test
    assert bump_version.__name__ == fpkg.__dict__[test_case_0.__name__]
    # Verify the function hasn't changed
    h_0 = bump_version.__hash__()
    h_1 = fpkg.__dict__[test_case_0.__name__].__hash__()
    assert h_0 == h_1
    # Verify the function works to expectations
    test_case_0()

# Generated at 2022-06-25 17:36:54.146759
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.2.2', position=0) == '2.0'
    assert bump_version('1.2.2', pre_release='a') == '1.2.2a0'
    assert bump_version('1.2.2a0', pre_release='a') == '1.2.2a1'
    assert bump_version('1.2.2a1', pre_release='b') == '1.2.2b0'
    assert bump_version('1.2.2a1') == '1.2.2'

# Generated at 2022-06-25 17:37:16.703201
# Unit test for function bump_version
def test_bump_version():
    # Tests based on example arguments given in the PEP-440 documentation
    # https://www.python.org/dev/peps/pep-0440/
    bump_version('1.2.post4', position=0)
    bump_version('1.2.post4', position=1)
    bump_version('1.2.post4', position=2)

    bump_version('1.2.post4', pre_release='a')
    bump_version('1.2.post4', pre_release='b')

    bump_version('1.2.post4', position=2, pre_release='a')
    bump_version('1.2.post4', position=2, pre_release='b')

    bump_version('1.2', position=1, pre_release='a')

# Generated at 2022-06-25 17:37:21.060904
# Unit test for function bump_version
def test_bump_version():
    # Call function with arguments (tests args parsing and validation)
    output = bump_version('1.2.2')
    assert output == '1.2.3', \
        'Expected {}, but got {}'.format('1.2.3', output)



# Generated at 2022-06-25 17:37:29.976310
# Unit test for function bump_version
def test_bump_version():
    """
    The "unit" test for the function bump_version in the packages module.
    """
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-25 17:37:34.544958
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=W0612
    test_case_0()

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:37:44.727810
# Unit test for function bump_version
def test_bump_version():
    """
    Run unit test against the package.
    """

    # noinspection PyUnresolvedReferences
    import utils
    import test_utils


# Generated at 2022-06-25 17:37:53.679229
# Unit test for function bump_version
def test_bump_version():
    str_0 = bump_version('1.2.2')
    str_1 = bump_version('1.2.3', position=1)
    str_2 = bump_version('1.3.4', position=0)
    str_3 = bump_version('1.2.3', prerelease="a")
    str_4 = bump_version('1.2.4a0', pre_release="a")
    str_5 = bump_version('1.2.4a1', pre_release="b")
    str_6 = bump_version('1.2.4a1')
    str_7 = bump_version('1.2.4b0')
    str_8 = bump_version('2.1.3', position=1, pre_release="a")

# Generated at 2022-06-25 17:37:57.975754
# Unit test for function bump_version
def test_bump_version():
    # Test case 0:
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    assert str_1 == str_2

# Generated at 2022-06-25 17:38:01.334455
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    print('Test bump_version Done')
    return


# Test
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:38:03.423435
# Unit test for function bump_version
def test_bump_version():
    """Test module for function bump_version."""
    # noinspection PyUnusedLocal
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'


# Generated at 2022-06-25 17:38:05.549914
# Unit test for function bump_version
def test_bump_version():
    """ Test function bump_version."""
    test_case_0()



# Generated at 2022-06-25 17:38:31.685556
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import UnitTester
    tester = UnitTester()
    tester.test_case(test_case_0)

# Generated at 2022-06-25 17:38:35.284729
# Unit test for function bump_version
def test_bump_version():
    # See: https://github.com/gadfly361/PythonUtils/issues/1
    print("Test: bump_version")
    #__: test_case_0()
    __: Any = None
    assert True
    print("Done: bump_version")


if __name__ == '__main__':
    # Run unit tests
    test_bump_version()

# Generated at 2022-06-25 17:38:40.458460
# Unit test for function bump_version
def test_bump_version():
    print('Testing test_bump_version ...', end='')
    try:
        test_case_0()
    except Exception as e:
        print(
            'Exception: %s\n'
            'Stacktrace:\n%s' % (e, traceback.format_exc())
        )
    print('Done')

# Generated at 2022-06-25 17:38:52.154746
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    str_0 = '2.0.0'
    str_1 = bump_version(str_0)
    str_2 = '2.0.1'
    str_3 = '1.2.3'
    str_4 = bump_version(str_3, position=0)
    str_5 = '2.0'
    str_6 = bump_version(str_3, pre_release='a')
    str_7 = '1.2.4a0'
    str_8 = bump_version(str_3, pre_release='b')
    str_9 = '1.2.4b0'
    str_10 = bump_version(str_7)
    str_11 = '1.2.4'

# Generated at 2022-06-25 17:39:00.406453
# Unit test for function bump_version
def test_bump_version():
    ver_0 = '1.0.0'
    ver_1 = bump_version(ver_0)
    ver_2 = '1.0.1'
    ver_2_a0 = '1.1a0'
    ver_2_a1 = '1.1a1'
    ver_2_b0 = '1.1b0'
    ver_2_b1 = '1.1b1'
    ver_3 = '1.1'
    ver_3_a0 = '1.2a0'
    ver_3_a1 = '1.2a1'
    ver_3_b0 = '1.2b0'
    ver_3_b1 = '1.2b1'
    ver_4 = '1.2'
    assert ver_1 == ver_2

# Generated at 2022-06-25 17:39:12.621152
# Unit test for function bump_version
def test_bump_version():
    # Test with string
    assert bump_version('1.2.2') == '1.2.3'

    # Test with long

# Generated at 2022-06-25 17:39:15.310253
# Unit test for function bump_version
def test_bump_version():
    cmds = [
        'bump_version',
        'test_case_0',
    ]
    globs = globals()
    return True



# Generated at 2022-06-25 17:39:27.396570
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    assert str_1 == str_2

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    str_2 = '1.3'
    assert str_1 == str_2

    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    str_2 = '2.0'
    assert str_1 == str_2

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')

# Generated at 2022-06-25 17:39:29.917048
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    print("Called directly.")
    test_bump_version()
else:
    print("Imported as module.")

# Generated at 2022-06-25 17:39:30.818365
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Standalone test code

# Generated at 2022-06-25 17:40:01.668198
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    str_3 = '>rG)fNY$\\8,\\$Qz`'

# Generated at 2022-06-25 17:40:05.508252
# Unit test for function bump_version
def test_bump_version():
    """In this specific case, test_bump_version

    Args:
        None.

    Returns:
        None.

    Raises:
        None.

    """
    msg = 'test_bump_version failed'
    test_case_0()

# Generated at 2022-06-25 17:40:18.480658
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    # Test case 0
    # str_0 = '1.2.2'
    # str_1 = bump_version(str_0)
    # str_2 = '1.2.3'
    # Test case 1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 1)
    str_2 = '1.3'
    # Test case 2
    str_0 = '1.2.1'
    str_1 = bump_version(str_0, 0)
    str_2 = '2.0'
    # Test case 3

# Generated at 2022-06-25 17:40:25.901505
# Unit test for function bump_version
def test_bump_version():
    print('Testing function bump_version()')
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    str_3 = '>rG)fNY$\\8,\\$Qz'
    assert str_1 == str_2, str_3
    print('Function bump_verison() ran to completion.')

# If this script is run from the command line, run test_bump_version
if __name__ == '__main__':
    try:
        test_bump_version()
    except Exception as exc:
        print(exc)

# Generated at 2022-06-25 17:40:28.980301
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    assert str_1 == str_2



# Generated at 2022-06-25 17:40:35.489585
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()


__author__ = 'Jathan McCollum'
__maintainer__ = 'Jathan McCollum'
__email__ = 'jathan@gmail.com'
__copyright__ = 'Copyright 2016, Jathan McCollum'
__license__ = 'MIT'

# Generated at 2022-06-25 17:40:42.684641
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


# pylint: disable=W0105


# pylint: disable=W0105
''' Disabled transformations for the remainder of this source file.

    .. py:decorator:: disable

        Disables the given checkers in the decorated function or method.

    .. versionadded:: 0.3

    .. seealso::

        :py:func:`~flutils.validation.disable_transforms`
            For disabling transformations for the remainder of a source file.
'''


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:40:51.192351
# Unit test for function bump_version
def test_bump_version():
    # str_0
    str_0 = '1.2.2'

    # str_1
    str_1 = bump_version(str_0)

    # str_2
    str_2 = '1.2.3'

    # str_3
    str_3 = '>rG)fNY$\\8,\\$Qz`'

    # str_4
    test_case_0()

    # str_a
    str_a = '0.0.0b'

    # str_b
    str_b = '1.2.3'

    # int_0
    int_0 = 1

    # int_1
    int_1 = 1

    # int_2
    int_2 = 3

    # int_3
    int_3 = 18

    # int_4
   

# Generated at 2022-06-25 17:40:57.563020
# Unit test for function bump_version
def test_bump_version():
    print('Testing bump_version(...)')
    test_case_0()
    print('\tTest Case 0: Passed')


# Main entry point for this script
if __name__ == '__main__':
    test_bump_version()
    raise SystemExit(0)

# Generated at 2022-06-25 17:41:10.694693
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    assert str_1 == str_2
    str_0 = '1.2.3'
    pos_0 = 1
    str_1 = bump_version(str_0, position=pos_0)
    str_2 = '1.3'
    assert str_1 == str_2
    str_0 = '1.3.4'
    pos_0 = 0
    str_1 = bump_version(str_0, position=pos_0)
    str_2 = '2.0'
    assert str_1 == str_2
    str_0 = '1.2.3'