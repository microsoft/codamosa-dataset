

# Generated at 2022-06-25 17:31:47.802928
# Unit test for function bump_version
def test_bump_version():
    from flutils.objects import Object

    def bump_it(
            ver_obj: Object,
            position: int,
            prerelease: Optional[str],
            expected: str
    ) -> None:
        actual = bump_version(ver_obj.version, position, prerelease)
        assert actual == expected


# Generated at 2022-06-25 17:31:57.594954
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:31:59.142788
# Unit test for function bump_version
def test_bump_version():
    from .. import packages
    packages.test_bump_version()



# Generated at 2022-06-25 17:32:00.083277
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:32:00.946644
# Unit test for function bump_version
def test_bump_version():
    return True

# Generated at 2022-06-25 17:32:09.057169
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:20.799310
# Unit test for function bump_version
def test_bump_version():
    # Test the major version bump
    assert bump_version('0.0.0') == '1.0', \
        "The major version bump did not work."
    assert bump_version('0.1.0') == '1.0', \
        "The major version bump did not work."
    assert bump_version('0.1.1') == '1.0', \
        "The major version bump did not work."
    assert bump_version('1.1.1') == '2.0', \
        "The major version bump did not work."
    assert bump_version('1.1.0') == '2.0', \
        "The major version bump did not work."
    assert bump_version('1.0.0') == '2.0', \
        "The major version bump did not work."
    assert bump_version

# Generated at 2022-06-25 17:32:33.098592
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    assert bump_version(version, prerelease='alpha') == '1.2.4a0'
    assert bump_version(version, prerelease='b') == '1.2.4b0'
    assert bump_version(version, prerelease='beta') == '1.2.4b0'
    assert bump_version(version) == '1.2.4'

# Generated at 2022-06-25 17:32:43.350327
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase


# Generated at 2022-06-25 17:32:51.466997
# Unit test for function bump_version
def test_bump_version():
    from sys import version_info
    from flutils.packages import bump_version, bump_version_range
    from flutils.stringutils import normalize_version
    from nose.tools import eq_

    # noinspection PyUnresolvedReferences
    py_version = version_info[:3]
    py_version_str = '%s.%s.%s' % py_version
    py_version_norm = normalize_version(py_version_str)


# Generated at 2022-06-25 17:33:19.036431
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.2.1') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:33:29.930987
# Unit test for function bump_version
def test_bump_version():
    # Tests based on examples in documentation

    version = '1.2.2'
    position = 2
    pre_release = None
    result = bump_version(version, position, pre_release)
    assert result == '1.2.3'

    version = '1.2.3'
    position = 1
    pre_release = None
    result = bump_version(version, position, pre_release)
    assert result == '1.3'

    version = '1.3.4'
    position = 0
    pre_release = None
    result = bump_version(version, position, pre_release)
    assert result == '2.0'

    version = '1.2.3'
    position = 2
    pre_release = 'a'
    result = bump_version(version, position, pre_release)


# Generated at 2022-06-25 17:33:36.382229
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)
    assert str_2 in {'1.3.4a0', '1.3.5a0'}
    assert str_3 == '0.0.1a0'
    return True


if __name__ == '__main__':
    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:33:47.115408
# Unit test for function bump_version
def test_bump_version():
    # Verify that: bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    str_0 = '1.2.3'
    str_1 = 'a'
    str_2 = bump_version(str_0, 2, str_1)
    str_3 = '1.2.4a0'
    assert str_2 == str_3
    # Verify that: bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    str_0 = '1.2.4a0'
    str_1 = 'a'
    str_2 = bump_version(str_0, 2, str_1)
    str_3 = '1.2.4a1'
    assert str_2 == str

# Generated at 2022-06-25 17:33:49.105372
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:34:01.462281
# Unit test for function bump_version
def test_bump_version():
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    assert str_2 == '1.3.5a0'
    str_3 = bump_version(str_2)
    assert str_3 == '1.3.5a1'
    int_1 = 2
    str_4 = '1.3.0'
    str_5 = bump_version(str_4, int_1, str_1)
    assert str_5 == '1.3.a0'
    int_2 = 2
    str_6 = '1.3.0a1'
    str_7 = bump_version(str_6, int_2, str_1)
   

# Generated at 2022-06-25 17:34:04.470084
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version().
    """
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)

# Generated at 2022-06-25 17:34:13.075394
# Unit test for function bump_version
def test_bump_version():
    # Test 0
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)
    str_4 = '1.3.5'
    str_5 = '1.3.5a0'
    assert str_2 == str_5
    assert bump_version(str_3) == '1.0.0'
    # Test 1
    str_0 = '3.6.3'
    str_1 = 'alpha'
    str_2 = bump_version(str_0, int_0, str_1)
    print('str_2: %s' % str_2)
    # Test 2
    str

# Generated at 2022-06-25 17:34:21.343629
# Unit test for function bump_version
def test_bump_version():
    # Setup for test case 0
    str_0 = '1.3.4'
    str_1 = bump_version(str_0)
    str_2 = '1.3.5'
    assert str_1 == str_2
    # Setup for test case 1
    str_0 = '1.3.4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    str_2 = '1.4'
    assert str_1 == str_2
    # Setup for test case 2
    str_0 = '1.3.1'
    int_0 = 0
    str_1 = bump_version(str_0, int_0)
    str_2 = '2.0'
    assert str_1 == str_2
    # Setup for test case 3

# Generated at 2022-06-25 17:34:32.428594
# Unit test for function bump_version
def test_bump_version():

    # Test Case 0
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)

    assert str_2 == '1.3.5a0'

    # Test Case 1
    int_0 = 0
    str_0 = '1.2.5'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)

    assert str_2 == '2.0'

    # Test Case 2
    int_0 = 2
    str_0 = '1.2.5'
    str_1 = 'b'
    str_2 = bump_version(str_0, int_0, str_1)



# Generated at 2022-06-25 17:34:47.603604
# Unit test for function bump_version
def test_bump_version():
    """Test the module ``bump_version``."""

# Generated at 2022-06-25 17:34:49.256069
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:34:59.877828
# Unit test for function bump_version
def test_bump_version():
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)
    print(repr(str_2))
    print(repr(str_2))
    print(repr(str_3))
    assert str_2 == '1.3.4a0'
    assert str_3 == '0.1'
    str_0 = '1.3.4'
    str_1 = 'alpha'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)
    print(repr(str_2))

# Generated at 2022-06-25 17:35:05.351795
# Unit test for function bump_version
def test_bump_version():
    """ Test function bump_version. """
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)
    assert str_2 == '1.3.4a0'
    assert str_3 == '1.0'


if __name__ == '__main__':
    import sys
    sys.exit(test_bump_version())

# Generated at 2022-06-25 17:35:07.610106
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 17:35:15.981891
# Unit test for function bump_version
def test_bump_version():
    assert '2.0' == bump_version('1.2.3', 0)

    assert '1.0.1' == bump_version('1.0.0', 2)
    assert '1.1.0' == bump_version('1.0.0', 1)
    assert '2.0.0' == bump_version('1.0.0')

    assert '0.0.0' == bump_version('0.0.0')
    assert '1.0.0' == bump_version('0.0.0', 0)
    assert '0.1.0' == bump_version('0.0.0', 1)
    assert '0.0.1' == bump_version('0.0.0', 2)


# Generated at 2022-06-25 17:35:28.693983
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:39.105514
# Unit test for function bump_version
def test_bump_version():
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = '1.3.4a1'
    str_3 = '1.3.4a0'
    str_4 = '1.3.4'
    str_5 = '1.3.4a0'
    str_6 = '1.3.5'
    str_7 = '1.3.5a0'
    assert bump_version(str_0, int_0, str_1) == str_2
    assert bump_version(str_0, int_0, str_1) == str_2
    assert bump_version(str_0, int_0) == str_4
    assert bump_version(str_0, int_0) == str_4


# Generated at 2022-06-25 17:35:43.828530
# Unit test for function bump_version
def test_bump_version():
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)


# Generated at 2022-06-25 17:35:53.936145
# Unit test for function bump_version
def test_bump_version():
    # Test the case that the position is a negative number
    # noinspection PyShadowingNames
    def case_0():
        int_0 = -2
        str_0 = '1.2.3'
        str_1 = '%s-%s' % (str_0, str(int_0))
        str_2 = bump_version(str_0, int_0)
        assert str_2 == str_1
    case_0()

    # Test the case that the position is an invalid number
    # noinspection PyShadowingNames
    def case_1():
        int_0 = 3
        str_0 = '1.2.3'
        str_1 = '%s-%s' % (str_0, str(int_0))

# Generated at 2022-06-25 17:36:10.444350
# Unit test for function bump_version
def test_bump_version():
    from random import randint
    from flutils.packages import (
        bump_version,
        is_strict_version
    )
    from flutils.testing import (
        BaseTestCase,
        do_run_test_functions
    )

    class _TestCase(BaseTestCase):
        def _do_test_bump_version(
                self,
                *,
                version: str,
                position: int,
                pre_release: Union[str, None],
                expected: str
        ) -> None:
            ver_out = bump_version(
                version=version,
                position=position,
                pre_release=pre_release
            )

# Generated at 2022-06-25 17:36:17.201768
# Unit test for function bump_version
def test_bump_version():
    import os
    import sys
    ##############################################
    # 1. Test all the functions
    ##############################################
    test_case_0()
    ##############################################
    # 2. Return the results
    ##############################################
    return True

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:36:29.439330
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``."""

    # Create a dict with the expected results
    dict_0 = dict()
    dict_0['1.2.2'] = '1.2.3'
    dict_0['1.2.3'] = '1.3'
    dict_0['1.3.4'] = '2.0'
    dict_0['1.2.3', 'a'] = '1.2.4a0'
    dict_0['1.2.4a0'] = '1.2.4a1'
    dict_0['1.2.4a1', 'b'] = '1.2.4b0'
    dict_0['1.2.4a1'] = '1.2.4'

# Generated at 2022-06-25 17:36:40.326797
# Unit test for function bump_version
def test_bump_version():
    for input_0 in (
            '1.2.3', '1.2.3a1', '1.2.3b1', '1.2.3a0', '1.2.3b0',
            '1.2.3a2', '1.2.3b2', '1.2.3a3', '1.2.3b3'
    ):
        for input_1 in range(-3, 3):
            if input_0.endswith(('a1', 'b1')):
                for input_2 in ('a', 'alpha', 'b', 'beta'):
                    if input_1 == -1:
                        if input_0.endswith(('a1', 'b1')):
                            continue
                        if input_2 == 'a':
                            str_0 = bump_

# Generated at 2022-06-25 17:36:51.907735
# Unit test for function bump_version
def test_bump_version():
    int_0 = -1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 2, 'b')
    str_2 = bump_version(str_0, 2)
    str_3 = bump_version(str_0, 1, 'a')
    str_4 = bump_version(str_0, 1, 'b')
    str_5 = bump_version(str_0, 1)
    str_6 = bump_version(str_0, 0)
    str_7 = bump_version(str_0, int_0, 'b')
    str_8 = bump_version(str_0, int_0, 'a')
    str_9 = bump_version(str_0, int_0)
    str_10 = bump_version(str_0)

# Generated at 2022-06-25 17:36:53.966224
# Unit test for function bump_version
def test_bump_version():
    return True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:37:03.464848
# Unit test for function bump_version
def test_bump_version():
    # Test 0
    result = bump_version('0.2.2')
    assert result == '0.2.3'
    # Test 1
    result = bump_version('0.3.4', position=1)
    assert result == '0.4'
    # Test 2
    result = bump_version('3.4.4', position=0)
    assert result == '4.0'
    # Test 3
    result = bump_version('0.2.2', prerelease='a')
    assert result == '0.2.3a0'
    # Test 4
    result = bump_version('0.2.3a0', pre_release='a')
    assert result == '0.2.3a1'
    # Test 5

# Generated at 2022-06-25 17:37:14.273935
# Unit test for function bump_version
def test_bump_version():
    '''
    Unit test for function ``flutils.packages.bump_version``.
    '''
    import os
    import sys
    import traceback
    from flutils.packages import bump_version
    try:
        from IPython import get_ipython
    except ImportError:
        get_ipython = None

    print('-=' * 20)
    print('Unit test for function flutils.packages.bump_version')

    # Print out the header stuff
    cur_name = os.path.basename(sys.argv[0])
    cur_name = cur_name.replace('.py', '')
    cur_name = cur_name.replace('.ipy', '')
    if get_ipython is not None:
        # pylint: disable=E1101,E1102
        ipy_

# Generated at 2022-06-25 17:37:17.278856
# Unit test for function bump_version
def test_bump_version():
    str_1 = '1.2.3'
    str_2 = bump_version(str_1)
    assert (str_2 == '1.2.4')
    return True



# Generated at 2022-06-25 17:37:27.538559
# Unit test for function bump_version
def test_bump_version():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    str_0 = '1.2.3'
    str_1 = '2.3.4'
    str_2 = '0.1.0'
    str_3 = '1.2.4'
    str_4 = '1.3'
    str_5 = '1.2.4a0'
    str_6 = '1.2.4a1'
    str_7 = '1.2.4b0'
    str_8 = '1.2.4'
    str_9 = '1.2.0'
    str_10 = '2.0'
    str_11 = '1.0.0'
    str_12 = '2.2a0'

# Generated at 2022-06-25 17:37:35.916084
# Unit test for function bump_version
def test_bump_version():
    print('Testing function: test_bump_version')
    test_case_0()
    try:
        test_case_0()
    except Exception as error:
        traceback.print_exc()
        print(error)
        assert False

# Generated at 2022-06-25 17:37:46.155500
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = '1.2.4'
    assert bump_version(str_0) == str_1
    str_0 = '1.2.3'
    str_1 = '1.3'
    assert bump_version(str_0, position=1) == str_1
    str_0 = '1.3.4'
    str_1 = '2.0'
    assert bump_version(str_0, position=0) == str_1
    str_0 = '1.2.3'
    str_1 = '1.2.4a0'
    assert bump_version(str_0, pre_release='a') == str_1
    str_0 = '1.2.4a0'

# Generated at 2022-06-25 17:37:54.447808
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function.

    .. todo::
        - Add more tests

    """
    import pytest
    from flutils.packages import bump_version

    ver_info = _build_version_info('0.0.1')

    def _bump_version(
            version: str,
            expected: str,
            position: int = 0,
            pre_release: Optional[str] = None
    ):
        actual = bump_version(
            version=version,
            position=position,
            pre_release=pre_release
        )

# Generated at 2022-06-25 17:38:06.144715
# Unit test for function bump_version
def test_bump_version():
    int_0 = -1
    str_0 = '0.3'
    str_1 = bump_version(str_0, int_0)
    str_2 = '2.0.3'
    assert str_1 == str_2
    str_1 = bump_version('1.0.0')
    assert str_1 == '1.0.1'
    str_1 = bump_version('2.0.0', pre_release='a')
    assert str_1 == '2.0.1a0'
    str_1 = bump_version('1.2.3a0', pre_release='a')
    assert str_1 == '1.2.3a1'
    str_1 = bump_version('1.2.3a1', pre_release='b')

# Generated at 2022-06-25 17:38:10.146792
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    int_0 = 2
    str_0 = '1.2.2'
    str_1 = bump_version(str_0, int_0)
    str_2 = '1.2.3'
    assert str_1 == str_2



# Generated at 2022-06-25 17:38:16.369323
# Unit test for function bump_version
def test_bump_version():
    """
    Function to unit test ``bump_version``
    """

    def _check(
            input_version: str,
            input_position: int,
            input_pre_release: Optional[str],
            output_version: str,
    ) -> None:
        str_2 = bump_version(input_version, input_position, input_pre_release)
        str_3 = bump_version(input_version)
        assert str_2 == output_version

    _check('1.2.2', 2, None, '1.2.3')
    _check('1.2.3', 1, None, '1.3')
    _check('1.3.4', 0, None, '2.0')

# Generated at 2022-06-25 17:38:20.455705
# Unit test for function bump_version
def test_bump_version():
    return


if __name__ == "__main__":
    print(__doc__)

# Generated at 2022-06-25 17:38:22.336837
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:38:33.847414
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    str_3 = '1.3'
    str_4 = bump_version(str_0, 1)
    str_5 = '2.0'
    str_6 = bump_version(str_0, 0)
    str_7 = '1.2.4a0'
    str_8 = bump_version(str_0, 2, 'a')
    str_9 = '1.2.4a1'
    str_10 = bump_version(str_7)
    str_11 = '1.2.4b0'
    str_12 = bump_version(str_7, 2, 'b')

# Generated at 2022-06-25 17:38:38.704759
# Unit test for function bump_version
def test_bump_version():
    # Get the version numbers from the version file
    from flutils import __version__
    # Raise an error if the following version number does not increase from
    # the value found in the version number file
    assert bump_version(__version__) == '0.4.4'

# Generated at 2022-06-25 17:38:50.380752
# Unit test for function bump_version
def test_bump_version():
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_2, int_0, str_1)
    str_4 = bump_version(str_3, int_0, str_1)
    str_5 = bump_version(str_4)
    str_6 = bump_version(str_5, 1, 'b')


# Generated at 2022-06-25 17:38:53.947673
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    try:
        test_case_0()
    except Exception:  # pylint: disable=W0702
        str_0 = 'Unit test failed with uncaught exception.'
        raise AssertionError(str_0)


# Generated at 2022-06-25 17:39:01.556345
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``"""
    str_0 = '1.2.3'
    list_0, list_1, list_2 = list('123'), list('123'), list('123')
    str_1 = '.'.join(list_0)
    list_0[-1] = '4'
    str_2 = '.'.join(list_0)
    list_1[-2] = '3'
    str_3 = '.'.join(list_1)
    list_2[0] = '2'
    str_4 = '.'.join(list_2)
    list_2[1], list_2[2] = '0', '0'
    str_5 = '.'.join(list_2)
    list_1[1] = '3a0'


# Generated at 2022-06-25 17:39:04.097251
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


# Execute the tests against the package
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:15.533768
# Unit test for function bump_version
def test_bump_version():
    int_0 = -1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '2.0'
    int_1 = -2
    str_2 = bump_version(str_0, int_1)
    assert str_2 == '1.3'
    int_2 = 0
    str_3 = bump_version(str_0, int_2)
    assert str_3 == '2.0'
    str_4 = '1.2.3a0'
    str_5 = bump_version(str_4, int_2, str_1)
    assert str_5 == '2.0a0'
    str_6 = bump_version(str_0, int_2)
    assert str_

# Generated at 2022-06-25 17:39:18.502768
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # TODO: Write this unit test



# Generated at 2022-06-25 17:39:26.103286
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestCase(unittest.TestCase):
        def test_0(self):
            bump_version('1.2.3')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.failures or result.errors:
        raise RuntimeError("Test failures")


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:34.331436
# Unit test for function bump_version

# Generated at 2022-06-25 17:39:46.181185
# Unit test for function bump_version
def test_bump_version():
    # Bump the patch part by default
    assert bump_version('1.2.3') == '1.2.4'

    # Bump the patch part
    assert bump_version('1.2.3', position=2) == '1.2.4'

    # Bump the alpha part
    assert bump_version('1.2.3', position=2, pre_release='a') == '1.2.4a0'

    # Bump the beta part
    assert bump_version('1.2.3', position=2, pre_release='b') == '1.2.4b0'

    # Bump the minor part
    assert bump_version('1.2.3', position=1) == '1.3'

    # Bump the minor part, alpha part

# Generated at 2022-06-25 17:39:56.097866
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.testing import capture_output
    from flutils.textutils import make_unicode
    from flutils.textutils import to_strs
    def _test_bump_version_run(in_0, in_1, in_2, exp_0):
        out_0 = bump_version(in_0, in_1, in_2)
        if out_0 != exp_0:
            raise AssertionError(
                'Returned data not correct,\n'
                'Expected: {}\n'
                'Returned: {}'.format(exp_0, out_0)
            )
    # Test normal flow

# Generated at 2022-06-25 17:40:16.509264
# Unit test for function bump_version
def test_bump_version():
    # Test: case_0
    # Verifies: return type, alpha bump
    int_0 = 2
    str_0 = '1.3.4'
    str_1 = 'a'
    str_2 = bump_version(str_0, int_0, str_1)
    str_3 = bump_version(str_1)
    assert isinstance(str_2, str)
    assert str_2 == '1.3.4a0'
    assert str_3 == '2'
    # Test: case_1
    # Verifies: pre-release bump
    int_1 = 2
    str_4 = '1.3.4'
    str_5 = 'a'
    str_6 = bump_version(str_4, int_1, str_5)
    str_7 = bump_version

# Generated at 2022-06-25 17:40:24.186482
# Unit test for function bump_version
def test_bump_version():
    print('Testing function: bump_version()')

    # Simple tests
    assert '1.2.3' == bump_version('1.2.2')
    assert '1.3' == bump_version('1.2.2', position=1)
    assert '2.0' == bump_version('1.3.4', position=0)
    assert '1.2.4a0' == bump_version('1.2.3', prerelease='a')
    assert '1.2.4a1' == bump_version('1.2.4a0', pre_release='a')
    assert '1.2.4b0' == bump_version('1.2.4a1', pre_release='b')
    assert '1.2.4' == bump_version('1.2.4a1')

# Generated at 2022-06-25 17:40:30.727111
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:41.922336
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:50.918296
# Unit test for function bump_version
def test_bump_version():
    # Testing no pre-release value
    str_0 = '1.2.3'
    str_1 = '1.2.4'
    assert bump_version(str_0) == str_1
    # Testing with a supplied pre-release value
    str_0 = '1.2.3'
    str_1 = '1.2.4a0'
    assert bump_version(str_0, pre_release='a') == str_1
    # Testing with a supplied pre-release value that already exists
    str_0 = '1.2.4a0'
    str_1 = '1.2.4a1'
    assert bump_version(str_0, pre_release='a') == str_1
    # Testing pre-release value bumping
    str_0 = '1.2.4a1'

# Generated at 2022-06-25 17:40:55.880699
# Unit test for function bump_version
def test_bump_version():
    # '1.2.3'
    assert bump_version('1.2.2') == '1.2.3'
    # '1.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    # '2.0'
    assert bump_version('1.3.4', position=0) == '2.0'
    # '1.2.4a0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # '1.2.4a1'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # '1.2.4b0'

# Generated at 2022-06-25 17:40:57.048440
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version.
    """
    test_case_0()

# Generated at 2022-06-25 17:40:59.861519
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function: bump_version"""
    # For coverage.
    test_case_0()



# Generated at 2022-06-25 17:41:11.608933
# Unit test for function bump_version
def test_bump_version():
    '''
    Test cases for the function `bump_version`
    '''
    # str_0 = '1.3.4'
    # str_1 = 'a'
    # str_2 = bump_version(str_0, 2, str_1)
    # print(str_2)  ## 1.3.4a0

    str_3 = bump_version('1.3.4', position=2, pre_release='b')
    assert str_3 == '1.3.4b0'

    str_4 = bump_version('1.3.4', position=1, pre_release='b')
    assert str_4 == '1.4b0'

    str_5 = bump_version('1.3.4', position=0, pre_release='b')