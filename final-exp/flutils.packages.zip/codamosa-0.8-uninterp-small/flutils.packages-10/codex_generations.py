

# Generated at 2022-06-25 17:31:46.844459
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.2', position=2) == '1.2.3'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:31:57.553432
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:07.067487
# Unit test for function bump_version
def test_bump_version():

    # Test case 0
    # Given:
    version = {'args': ['1.2.3'], 'kwargs': {}}
    # When:
    result = bump_version(**version['args'], **version['kwargs'])
    # Then:
    assert result == '1.2.4'

    # Test case 1
    # Given:
    version = {'args': ['1.2.3'], 'kwargs': {'position': 1}}
    # When:
    result = bump_version(**version['args'], **version['kwargs'])
    # Then:
    assert result == '1.3'

    # Test case 2
    # Given:
    version = {'args': ['1.3.4'], 'kwargs': {'position': 0}}
    # When:

# Generated at 2022-06-25 17:32:19.409382
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2') == '1.2.1'
    assert bump_version('1.2', position=0) == '2.0'
    assert bump_version('1.2', position=1) == '1.3'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='a') == '1.2.4a2'

# Generated at 2022-06-25 17:32:27.945986
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase

    class Test00_bump_version(TestCase):
        def test_00_bump_version_000(self):
            self.assertEqual(bump_version('1.2.3'), '1.2.4')

        def test_00_bump_version_001(self):
            self.assertEqual(bump_version('3.20.3'), '3.20.4')

        def test_00_bump_version_002(self):
            self.assertEqual(bump_version('1.2.3', position=1), '1.3')
            self.assertEqual(bump_version('1.2.3', position=1), '1.3.0')

# Generated at 2022-06-25 17:32:39.102855
# Unit test for function bump_version
def test_bump_version():
    # Function 'bump_version'
    major = '1.2.3'
    minor = '0.2.3'
    patch = '0.0.3'
    minor_alpha = '0.2.3a0'
    patch_alpha = '0.2.3a1'

    # Bump major
    major_bump = bump_version(major)
    assert major_bump == '2.0'
    # Bump minor
    minor_bump = bump_version(minor, position=1)
    assert minor_bump == '0.3'
    # Bump patch
    patch_bump = bump_version(patch, position=2)
    assert patch_bump == '0.0.4'
    # Bump minor alpha

# Generated at 2022-06-25 17:32:48.814952
# Unit test for function bump_version
def test_bump_version():
    # Bumping the default position
    version_1_2_2 = '1.2.2'
    assert bump_version(version_1_2_2) == '1.2.3'

    # Bumping the 'minor' position
    version_1_2_3 = '1.2.3'
    assert bump_version(version_1_2_3, position=1) == '1.3'

    # Bumping the 'major' position
    version_1_3_4 = '1.3.4'
    assert bump_version(version_1_3_4, position=0) == '2.0'

    # Bumping the default position, with an alpha version number
    version_1_2_3 = '1.2.3'

# Generated at 2022-06-25 17:32:51.863313
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.4a0'))
    print(bump_version('1.2.4a1'))

# Generated at 2022-06-25 17:33:04.220128
# Unit test for function bump_version
def test_bump_version():
    def _build_version_info(
            version: str,
    ) -> _VersionInfo:
        ver_obj = StrictVersion(version)
        pre_pos = -1
        args: List[Any] = [version]
        for part in _each_version_part(ver_obj):
            if part.pre_txt:
                pre_pos = part.pos
            args.append(part)
        args.append(pre_pos)
        return _VersionInfo(*args)

    def _build_version_bump_position(
            position: int,
    ) -> int:
        pos_min = -3
        pos_max = 2


# Generated at 2022-06-25 17:33:08.080978
# Unit test for function bump_version
def test_bump_version():
    for bump in (0, 1, 2):
        for pos in (0, -1, -2):
            for pre in ('a', 'alpha', 'b', 'beta', None):
                bump_version('1.2.3', pos, pre)


if __name__ == '__main__':
    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:33:47.987330
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

    str_0 = bump_version('1.2.3')
    assert str_0 == '1.2.4'
    str_0 = bump_version('1.2.3', position=1)
    assert str_0 == '1.3'
    str_0 = bump_version('1.2.3', position=2)
    assert str_0 == '1.2.4'
    str_0 = bump_version('1.2.3', position=0)
    assert str_0 == '2.0'

    str_0 = bump_version('1.2.4a1')
    assert str_0 == '1.2.4'
    str_0 = bump_version('1.2.4b0')

# Generated at 2022-06-25 17:33:59.776826
# Unit test for function bump_version
def test_bump_version():
    # Create an object to hold the test suite
    class Suite:
        def test_case_0(self):
            str_0 = '1.2.3'
            str_1 = bump_version(str_0)
            assert str_0 != str_1
            assert str_1 == '1.2.4'

        def test_case_1(self):
            str_0 = '2.1.3'
            str_1 = bump_version(str_0, position=1)
            assert str_0 != str_1
            assert str_1 == '2.2'

        def test_case_2(self):
            str_0 = '2.1.3'
            str_1 = bump_version(str_0, position=1, pre_release='a')
            assert str_0 != str_1

# Generated at 2022-06-25 17:34:07.984387
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:18.673913
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:30.670385
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:42.999256
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:56.346473
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:02.025645
# Unit test for function bump_version
def test_bump_version():
    # Test function for function bump_version
    print('Testing function bump_version...')
    # Test for case 0
    test_case_0()
    print('Done testing function bump_version.')


if __name__ == '__main__':
    # test_bump_version()
    test_case_0()

# Generated at 2022-06-25 17:35:07.225769
# Unit test for function bump_version
def test_bump_version():
    try:
        test_case_0()
    except Exception as e:
        import traceback
        # pylint: disable=W0212
        traceback.print_exc()
        raise e

# Generated at 2022-06-25 17:35:15.742290
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_2 = bump_version(str_0, position=1)
    assert str_2 == '1.3'
    str_3 = bump_version(str_0, position=0)
    assert str_3 == '2.0'
    str_4 = bump_version(str_0, prerelease='a')
    assert str_4 == '1.2.4a0'
    str_5 = bump_version(str_0, pre_release='a')
    assert str_5 == '1.2.4a1'
    str_6 = bump_version(str_0, pre_release='b')

# Generated at 2022-06-25 17:35:42.828388
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:53.233103
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Test Case #0
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assertion_0 = str_1
    assertion_1 = '1.2.4'
    assert assertion_0 == assertion_1

    # Test Case #1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assertion_0 = str_1
    assertion_1 = '1.3'
    assert assertion_0 == assertion_1

    # Test Case #2
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=0)
    assertion_0 = str_1

# Generated at 2022-06-25 17:36:04.316017
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # Test for function bump_version
    # Test for function bump_version
    # Test for function bump_version
    # Test for function bump_version
    # Test for function bump_version
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    # Test for function bump_version
    str_0 = '1.2.0'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.1'

    # Test for function bump_version
    str_0 = '1.0.0'
    str_1 = bump_version(str_0)
    assert str_1 == '1.0.1'

    #

# Generated at 2022-06-25 17:36:16.086977
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_1 = bump_version(str_0, prerelease='a')
    assert str_1 == '1.2.4a0'
    str_1 = bump_version(str_1, pre_release='a')
    assert str_1 == '1.2.4a1'
    str_1 = bump_version(str_1, pre_release='b')

# Generated at 2022-06-25 17:36:27.598303
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0'

    str_0 = '1.2.4a0'
    str_1 = bump_version

# Generated at 2022-06-25 17:36:35.815169
# Unit test for function bump_version
def test_bump_version():
    # test case 0
    test_case_0()

    # test case 1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    str_2 = '1.3'
    assert str_1 == str_2

    # test case 2
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    str_2 = '2.0'
    assert str_1 == str_2

    # test case 3
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    str_2 = '1.2.4a0'
    assert str_1 == str_2

    # test case 4

# Generated at 2022-06-25 17:36:47.200215
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:58.566556
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, prerelease='a')
    assert str_1 == '1.2.4a0'

    str_0 = '1.2.4a0'

# Generated at 2022-06-25 17:37:00.712138
# Unit test for function bump_version
def test_bump_version():

    test_case_0()


# Executes the unit tests when this file is run directly.
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:37:07.060475
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    str_2 = '1.2.3'
    str_3 = bump_version(str_0, 0)
    str_4 = '1.2.3'
    str_5 = bump_version(str_0, 1)
    str_6 = bump_version(str_0, 2)
    str_7 = bump_version(str_0, -1)
    str_8 = bump_version(str_0, -2)
    str_9 = bump_version(str_0, -3)
    str_10 = bump_version(str_0, 3)
    str_11 = bump_version(str_0, 4)
    str_12 = bump_version(str_0, 5)

# Generated at 2022-06-25 17:37:30.935546
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:43.047248
# Unit test for function bump_version
def test_bump_version():

    from pprint import pprint
    from flutils.packages import bump_version

    def test_case(v, pos):
        print('\n' + ('-' * 79))
        print("Bumping version (%r) at position (%r):" % (v, pos))
        result = bump_version(v, pos)
        print("Result: %r" % result)
        return result

    print("\nTesting the 'bump_version' function.")
    test_case('1.2.3', 0)
    test_case('1.2.3', 1)
    test_case('1.2.3', 2)
    test_case('1.2.3', position=0)
    test_case('1.2.3', position=1)
    test_case('1.2.3', position=2)



# Generated at 2022-06-25 17:37:52.562951
# Unit test for function bump_version
def test_bump_version():
    # First test-case.
    # A simple version number.  Major = 1, Minor = 3, Patch = 11
    str_0 = '1.3.11'
    str_1 = bump_version(str_0)
    # The patch number is incremented.
    assert str_1 == '1.3.12'

    # Second test-case.
    # Increase the major number.
    str_0 = '1.3.11'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    # Third test-case.
    # Increase the minor number.
    str_0 = '1.3.11'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.4'

    #

# Generated at 2022-06-25 17:38:03.903456
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = '1.2.3'
    str_2 = '1.2.3a0'
    str_3 = '1.2.3b0'
    str_4 = '1.2.3a1'
    str_5 = '1.2.3b1'
    str_6 = '1.2.4'
    str_7 = '1.2.4a0'
    str_8 = '1.2.4b0'
    str_9 = '1.2a0'
    str_10 = '1.2b0'
    str_11 = '1.3'
    str_12 = '1.3a0'
    str_13 = '1.3b0'

# Generated at 2022-06-25 17:38:14.841704
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', prerelease='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', prerelease='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:22.690627
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:34.361187
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:44.541847
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4', str_1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3', str_1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0', str_1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0', str_1

# Generated at 2022-06-25 17:38:55.328344
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    if str_1 != '1.2.4':
        raise AssertionError('String - "%s" Expected - "%s" Received - "%s"'
                             % (str_0, '1.2.4', str_1))

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    if str_1 != '1.3':
        raise AssertionError('String - "%s" Expected - "%s" Received - "%s"'
                             % (str_0, '1.3', str_1))

    str_0 = '1.3.4'
    str_1

# Generated at 2022-06-25 17:38:58.934058
# Unit test for function bump_version
def test_bump_version():
    # Logged:
    #   2020-01-24T10:29:51-05:00 lgsvl-dev flutils.packages.bump_version: test_case_0
    test_case_0()


if __name__ == '__main__':
    # Run test_bump_version()
    # test_bump_version()
    pass

# Generated at 2022-06-25 17:39:35.759039
# Unit test for function bump_version
def test_bump_version():
    test_case_0()



# Generated at 2022-06-25 17:39:47.564837
# Unit test for function bump_version
def test_bump_version():
    """
    Assert that the function returns the value expected.
    """
    # Use the shortcut function.
    assert bump_version('1.2.3') == '1.2.4'

    # Bump the minor number
    assert bump_version('1.2.3', 1) == '1.3'

    # Bump the major number
    assert bump_version('1.2.3', 0) == '2.0'

    # Bump the minor number to an alpha release
    assert bump_version('1.2.3', 1, 'a') == '1.3a0'

    # Bump the minor number to an alpha release
    assert bump_version('1.2.3', 1, 'alpha') == '1.3a0'

    # Bump the minor number to a beta release

# Generated at 2022-06-25 17:39:57.237721
# Unit test for function bump_version
def test_bump_version():

    # Test for valid version number
    version = '1.2.3'
    actual = bump_version(version)
    assert actual == '1.2.4'

    # Test for pre-release versions
    version = '1.2.3a0'
    actual = bump_version(version, 1, 'a')
    assert actual == '1.3a0'
    version = '1.2.3a0'
    actual = bump_version(version, 1, 'b')
    assert actual == '1.3b0'
    version = '1.2.3b0'
    actual = bump_version(version, 1, 'b')
    assert actual == '1.3b0'
    version = '1.2.3b0'
    actual = bump_version(version, 1, 'a')
   

# Generated at 2022-06-25 17:39:57.814494
# Unit test for function bump_version
def test_bump_version():
    # TODO: Fix function
    pass

# Generated at 2022-06-25 17:40:08.144027
# Unit test for function bump_version
def test_bump_version():

    # Test: no prerelease
    #
    # Test: position of 0
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 0)
    assert str_1 == '2.0', 'incorrect version string'
    # Test: position of 1
    str_1 = bump_version(str_0, 1)
    assert str_1 == '1.3', 'incorrect version string'
    # Test: position of 2
    str_1 = bump_version(str_0, 2)
    assert str_1 == '1.2.4', 'incorrect version string'
    # Test: position of -1
    str_1 = bump_version(str_0, -1)
    assert str_1 == '1.2.4', 'incorrect version string'
   

# Generated at 2022-06-25 17:40:13.793000
# Unit test for function bump_version
def test_bump_version():
    # Unit test for function bump_version
    from flutils.packages import bump_version

    version_str = '1.2.0'
    result = bump_version(version_str)
    assert result == '1.2.1'

    result = bump_version(version_str, 0)
    assert result == '2.0'

    result = bump_version(version_str, 1)
    assert result == '1.3'

    result = bump_version(version_str, -2)
    assert result == '1.2.1'

    result = bump_version(version_str, -1)
    assert result == '1.2.1'

    result = bump_version(version_str, -3)
    assert result == '2.0'


# Generated at 2022-06-25 17:40:20.863154
# Unit test for function bump_version
def test_bump_version():
    from flutils.testutils import run_tests
    from flutils.testutils import TEST_CASES
    from flutils.testutils import TestCase

    tests: List[Tuple[TestCase, Optional[Tuple[Any, ...]]]] = [
        (
            TestCase(
                cmd=test_case_0,
                exp=True,
                cmp=None,
                cmp_method='exact',
            ),
            None
        ),
    ]
    fail_fast = False
    run_tests(
        tests,
        TEST_CASES,
        fail_fast=fail_fast
    )

# Generated at 2022-06-25 17:40:28.983149
# Unit test for function bump_version
def test_bump_version():

    test_case_0()
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_1)
    str_3 = bump_version(str_2)
    assert str_1 == '1.2.4'
    assert str_2 == '1.2.5'
    assert str_3 == '1.2.6'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3b0'

# Generated at 2022-06-25 17:40:40.953309
# Unit test for function bump_version
def test_bump_version():
    import pytest
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_2 = bump_version(str_1, pre_release='alpha')
    assert str_2 == '1.2.5a0'
    str_3 = bump_version(str_2, pre_release='beta')
    assert str_3 == '1.2.5b0'
    str_4 = bump_version(str_2)
    assert str_4 == '1.2.5'
    str_5 = bump_version(str_4, pre_release='alpha')
    assert str_5 == '1.2.5a1'

# Generated at 2022-06-25 17:40:43.655691
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    # assert True


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:41:11.949507
# Unit test for function bump_version
def test_bump_version():
    # Test with the major version
    assert bump_version('1.2.3', 0) == '2.0'
    assert bump_version('1.2.3', 0, 'a') == '1.2.3a0'
    # Test with the minor version
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.2', 1) == '1.3'
    assert bump_version('1', 1) == '1.1'
    assert bump_version('1.2.3', 1, 'a') == '2.0a0'
    assert bump_version('1.2', 1, 'a') == '1.3a0'
    assert bump_version('1', 1, 'a') == '1.1a0'
    # Test with the