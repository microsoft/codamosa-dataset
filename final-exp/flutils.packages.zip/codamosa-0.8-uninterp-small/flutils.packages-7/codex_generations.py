

# Generated at 2022-06-25 17:31:48.069684
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:31:56.518134
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:06.202950
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:18.896827
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:27.587589
# Unit test for function bump_version
def test_bump_version():
    print('Testing: bump_version')
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:38.877912
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:40.883510
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.0') == '1.2.1'



# Generated at 2022-06-25 17:32:49.997371
# Unit test for function bump_version
def test_bump_version():
    # Test 1
    in_version: str = '1.2.2'
    out_version: str = '1.2.3'
    assert bump_version(in_version) == out_version
    # Test 2
    in_version: str = '1.2.3'
    out_version: str = '1.3'
    assert bump_version(in_version, position=1) == out_version
    # Test 3
    in_version: str = '1.3.4'
    out_version: str = '2.0'
    assert bump_version(in_version, position=0) == out_version
    # Test 4
    in_version: str = '1.2.3'
    out_version: str = '1.2.4a0'

# Generated at 2022-06-25 17:33:02.385832
# Unit test for function bump_version
def test_bump_version():
    # Bump patch
    ver = bump_version('1.2.3')
    assert ver == '1.2.4'
    # Bump minor
    ver = bump_version('1.2.3', position=1)
    assert ver == '1.3'
    # Bump major
    ver = bump_version('1.2.3', position=0)
    assert ver == '2.0'
    # Bump minor with alpha
    ver = bump_version('1.2.3', pre_release='a')
    assert ver == '1.2.4a0'
    # Bump minor with beta
    ver = bump_version('1.2.3', pre_release='b')
    assert ver == '1.2.4b0'
    # Bump prerelease alpha

# Generated at 2022-06-25 17:33:10.149723
# Unit test for function bump_version
def test_bump_version():
    a = bump_version('1.2.2')
    assert a == '1.2.3'
    b = bump_version('1.2.3', position=1)
    assert b == '1.3'
    c = bump_version('1.3.4', position=0)
    assert c == '2.0'
    d = bump_version('1.2.3', pre_release='a')
    assert d == '1.2.4a0'
    e = bump_version('1.2.4a0', pre_release='a')
    assert e == '1.2.4a1'
    f = bump_version('1.2.4a1', pre_release='b')
    assert f == '1.2.4b0'

# Generated at 2022-06-25 17:33:50.181536
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:02.459182
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    Testing:
        (str) -> str
    """
    def _run_test(
            version: str,
            position: int,
            pre_release: Optional[str]
    ) -> None:
        pre_release = pre_release or ''
        for _ in range(2):
            try:
                out = bump_version(
                    version=version,
                    position=position,
                    pre_release=pre_release
                )
            except ValueError:
                print(
                    "Failed bumping version %r, with %r, using %r." % (
                        version,
                        position,
                        pre_release
                    )
                )
                raise

# Generated at 2022-06-25 17:34:07.428212
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:34:18.165495
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:30.036134
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:41.950973
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=missing-function-docstring
    version = bump_version('1.2.2')
    assert version == '1.2.3'

    version = bump_version('1.2.3', position=1)
    assert version == '1.3'

    version = bump_version('1.3.4', position=0)
    assert version == '2.0'

    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'

    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'

    version = bump_version('1.2.4a1', pre_release='b')

# Generated at 2022-06-25 17:34:55.456403
# Unit test for function bump_version
def test_bump_version():

    def check_version_bump(
            old_version: str,
            new_version: str,
            position: int = 2,
            pre_release: Union[str, None] = None
    ):
        assert bump_version(
            old_version, position, pre_release
        ) == new_version

    check_version_bump('1.2.2', '1.2.3')
    check_version_bump('1.2.3', '1.3', position=1)
    check_version_bump('1.3.4', '2.0', position=0)
    check_version_bump('1.2.3', '1.2.4a0', pre_release='a')

# Generated at 2022-06-25 17:35:05.963144
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Unit test for function bump_version."""
    from os import getcwd
    import unittest
    from .test_helpers import TestStderrCapture

    from .test_helpers import TestStdoutCapture

    class TestBumpVersion(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.out_path = '%s/out' % getcwd()

        def test_bump_version_0(self):
            # type: () -> None
            """Test - Normal usage."""
            self.assertEqual(bump_version('1.2.2'), '1.2.3')

        def test_bump_version_1(self):
            # type: () -> None
            """Test - Normal usage."""

# Generated at 2022-06-25 17:35:10.330644
# Unit test for function bump_version
def test_bump_version():
    # Test that a valid version can be used
    version_0 = bump_version('1.2.1')
    assert version_0 == '1.2.2'
    # Test that the 'major' part can be used to increase the version number
    version_1 = bump_version('1.2.2', position=0)
    assert version_1 == '2.0'
    # Test that the 'minor' part can be used to increase the version number
    version_2 = bump_version('1.2.2', position=1)
    assert version_2 == '1.3'
    # Test that the 'patch' part can be used to increase the version number
    version_3 = bump_version('1.2.2', position=2)
    assert version_3 == '1.2.3'
    # Test that the

# Generated at 2022-06-25 17:35:17.443440
# Unit test for function bump_version
def test_bump_version():
    """Basic unit test of bump_version"""

    ver0 = bump_version("0.1.0")
    ver1 = bump_version("0.1.0", 1)
    ver2 = bump_version("0.1.0", 0)
    ver3 = bump_version("0.1.0", 1, "a")

    if ver0 != "0.1.1":
        sys.stderr.write("Test failure: " + "Expected: " + "0.1.1" +
                         " Got: " + ver0 + "\n")
        return 1

    if ver1 != "0.2":
        sys.stderr.write("Test failure: " + "Expected: " + "0.2" +
                         " Got: " + ver1 + "\n")
        return 1


# Generated at 2022-06-25 17:35:38.631813
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    from copy import deepcopy


# Generated at 2022-06-25 17:35:50.369647
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:01.472222
# Unit test for function bump_version
def test_bump_version():
    # Test for correct version bump
    assert bump_version('1.2.2') == '1.2.3'

    # Test for correct minor part bump
    assert bump_version('1.2.3', position=1) == '1.3'

    # Test for correct major part bump
    assert bump_version('1.3.4', position=0) == '2.0'

    # Test for correct pre-release bump
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

    # Test for correct pre-release bump
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    # Test for correct pre-release bump

# Generated at 2022-06-25 17:36:14.325214
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version()"""
    from flutils.packages import bump_version
    from flutils.textutils import compare_strings


# Generated at 2022-06-25 17:36:27.333060
# Unit test for function bump_version
def test_bump_version():  # type: ignore
    ver_str = '0.2.3'
    ver_obj = bump_version(ver_str)
    assert ver_obj == '0.2.4'
    ver_str = '0.2.3'
    ver_obj = bump_version(ver_str, position=1)
    assert ver_obj == '0.3'
    ver_str = '0.2.3'
    ver_obj = bump_version(ver_str, position=0)
    assert ver_obj == '1.0'
    ver_str = '0.2.3'
    ver_obj = bump_version(ver_str, position=-1)
    assert ver_obj == '0.2.4'
    ver_str = '0.2.3'

# Generated at 2022-06-25 17:36:31.059826
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    """
    result = bump_version('1.2.2')
    print()
    print(result)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:36:42.299107
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:53.819112
# Unit test for function bump_version
def test_bump_version():
    def _test(version, position, pre_release, expect):
        actual = bump_version(version, position, pre_release)
        assert actual == expect

    # Patch
    _test('1.2.3', 2, None, '1.2.4')
    _test('1.2.3', -1, None, '1.2.4')
    _test('1.2.0', 2, None, '1.2.1')
    _test('1.2.3', 2, 'a', '1.2.4a0')
    _test('1.2.3', 2, 'b', '1.2.4b0')
    _test('1.2.4a0', 2, 'a', '1.2.4a1')

# Generated at 2022-06-25 17:37:03.401011
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:37:14.016941
# Unit test for function bump_version
def test_bump_version():
    """Tests for function bump_version."""
    # TypeError: bump_version() missing 1 required positional argument: 'version'
    # TypeError: bump_version() takes 2 positional arguments but 4 were given
    # TypeError: bump_version() takes from 1 to 3 positional arguments but 4 were given
    # TypeError: bump_version() takes from 2 to 3 positional arguments but 4 were given
    # TypeError: bump_version() takes from 1 to 2 positional arguments but 4 were given
    # bump_version() argument after ** must be an iterable, not int
    # bump_version() argument after ** must be a dictionary, not int
    # bump_version() argument after ** must be an iterable, not float
    # bump_version() argument after ** must be a dictionary, not float
    # TypeError: bump_version() missing 1 required positional argument: 'version

# Generated at 2022-06-25 17:37:21.009619
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'



# Generated at 2022-06-25 17:37:29.940475
# Unit test for function bump_version
def test_bump_version():
    version_number = bump_version
    ###################################
    # Testing that errors are raised
    ###################################
    # The 'version' is invalid
    try:
        version_number('a')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')
    try:
        version_number('a.b')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')
    try:
        version_number('a.b')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # 'position' is out of range
    try:
        version_number('1.2.3', -4)
    except ValueError:
        pass
    else:
        raise Ass

# Generated at 2022-06-25 17:37:42.003357
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    version = '0.3.4'
    for position in (-3, -2, -1, 0, 1, 2):
        for pre_release in (None, '', 'a', 'alpha', 'b', 'beta'):
            next_version = bump_version(version, position, pre_release)
            ver_info = _build_version_info(version)

            # Be sure we are not increasing the version to a pre-release
            #   before we should be.
            if (ver_info.pre_pos >= 0 and
                    position > ver_info.pre_pos):
                assert 'a' not in next_version
                assert 'b' not in next_version

            # We are increasing the version number.
            #   Be sure it is increasing.
            #   Be sure it

# Generated at 2022-06-25 17:37:51.687431
# Unit test for function bump_version
def test_bump_version():
    """Test the bump_version function."""
    from textwrap import dedent

    def _test_error(version: str, position: int, pre_release: Optional[str],
                    errmsg: str) -> None:
        try:
            bump_version(version, position, pre_release)
        except ValueError as err:
            print('version:', version)
            print('position:', position)
            print('pre_release:', pre_release)
            print('err:', err)
            assert errmsg == str(err)
            print('---\n')

# Generated at 2022-06-25 17:38:03.762601
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:14.752545
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:22.633816
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    version = '1.2.3'
    assert bump_version(version, position=1) == '1.3'
    version = '1.3.4'
    assert bump_version(version, position=0) == '2.0'
    version = '1.2.3'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    version = '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    version = '1.2.4a1'
    assert bump_version(version, pre_release='b') == '1.2.4b0'


# Generated at 2022-06-25 17:38:30.268653
# Unit test for function bump_version
def test_bump_version():
    """
    Test function bump_version
    """
    version_0 = bump_version('1.2.3')
    assert version_0 == '1.2.4'
    version_1 = bump_version('1.2.3', position=1)
    assert version_1 == '1.3'
    version_2 = bump_version('1.3.4', position=0)
    assert version_2 == '2.0'
    version_3 = bump_version('1.2.3', prerelease='a')
    assert version_3 == '1.2.4a0'
    version_4 = bump_version('1.2.4a0', pre_release='a')
    assert version_4 == '1.2.4a1'

# Generated at 2022-06-25 17:38:41.803520
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:52.671358
# Unit test for function bump_version
def test_bump_version():
    """Test function :func:`.bump_version`."""
    from flutils.packages import bump_version
    from flutils.testutils import (
        AssertStrMixin,
        AssertExceptionMixin
    )

    class AssertBumpVersion(AssertStrMixin, AssertExceptionMixin):
        """Utility class for function ``bump_version``."""

        # noinspection PyMissingConstructor
        def __init__(
                self,
                version: str,
                position: int = 2,
                pre_release: Optional[str] = None
        ) -> None:
            self.version = str(version)
            self.position = int(position)
            if pre_release is None:
                self.pre_release = None

# Generated at 2022-06-25 17:38:59.143069
# Unit test for function bump_version
def test_bump_version():
    version_str_0 = '1.2.2'
    version_str_1 = bump_version(version_str_0)
    assert version_str_1 == '1.2.3'



# Generated at 2022-06-25 17:39:01.931491
# Unit test for function bump_version
def test_bump_version():
    version_bump_0 = bump_version("0.2.2")
    assert version_bump_0 == "0.2.3"


# Generated at 2022-06-25 17:39:14.173964
# Unit test for function bump_version
def test_bump_version():
    test_dict: Dict[Tuple[str, int, Optional[str]], str] = {}
    test_dict[('1.2.2', 2, None)] = '1.2.3'
    test_dict[('1.2.3', 1, None)] = '1.3'
    test_dict[('1.3.4', 0, None)] = '2.0'
    test_dict[('1.2.3', 2, 'a')] = '1.2.4a0'
    test_dict[('1.2.4a0', 2, 'a')] = '1.2.4a1'
    test_dict[('1.2.4a1', 2, 'b')] = '1.2.4b0'

# Generated at 2022-06-25 17:39:26.206705
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:39:33.762544
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('2.1.3', position=1, pre_release='a') == '2.2a0'

# Generated at 2022-06-25 17:39:39.771916
# Unit test for function bump_version
def test_bump_version():
    import doctest
    results = doctest.testmod()
    if results.failed > 0:
        print('Failed:', results.failed)
        print('Attempted:', results.attempted)
    assert results.failed == 0


if __name__ == "__main__":
    test_bump_version()

# Generated at 2022-06-25 17:39:50.321337
# Unit test for function bump_version
def test_bump_version():
    # Test: '1.2.3'
    version = '1.2.3'
    expected = '1.2.4'
    out = bump_version(version)
    assert out == expected

    # Test: '1.2.3', position=1
    version = '1.2.3'
    expected = '1.3'
    out = bump_version(version, position=1)
    assert out == expected

    # Test: '1.3.4', position=0
    version = '1.3.4'
    expected = '2.0'
    out = bump_version(version, position=0)
    assert out == expected

    # Test: '1.2.3', pre_release='a'
    version = '1.2.3'

# Generated at 2022-06-25 17:39:59.648811
# Unit test for function bump_version
def test_bump_version():
    # Test case: normal: no pre-release
    version = '1.2.3'
    position = 2
    pre_release = None
    assert bump_version(version, position, pre_release) == '1.2.4'

    # Test case: normal: no pre-release
    version = '1.2.2'
    assert bump_version(version, position, pre_release) == '1.2.3'

    # Test case: normal: no pre-release
    version = '1.2.3'
    position = 1
    assert bump_version(version, position, pre_release) == '1.3'

    # Test case: normal: no pre-release
    version = '1.2.2'
    assert bump_version(version, position, pre_release) == '1.3'

    #

# Generated at 2022-06-25 17:40:11.996883
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""

    # Arrange
    version = '0.1.0'
    version_list = ['0.1.0', '0.1.1', '0.2.0', '0.2.1', '1.0.0', '1.1.0',
                    '1.1.1', '1.2.0', '1.2.1', '2.0.0', '2.1.0', '2.1.1',
                    '2.2.0', '2.2.1', '3.0.0']
    position = 0

    # Act
    for version in version_list:
        version = bump_version(version, position)

    # Assert
    assert version == '3.0.0'

# Generated at 2022-06-25 17:40:21.305598
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:37.477037
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:48.815847
# Unit test for function bump_version
def test_bump_version():
    # Test for bump_version().
    # Test for a 'patch' position bump
    assert bump_version('1.2.3') == '1.2.4'
    # Test for a 'minor' position bump
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test for a 'major' position bump
    assert bump_version('1.2.3', position=0) == '2.0'
    # Test for a 'minor' position bump with an alpha release
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    # Test for a 'minor' position bump with a beta release
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:40:57.814806
# Unit test for function bump_version
def test_bump_version():
    """
    Test for function bump_version
    """
    # noinspection PyUnresolvedReferences,PyProtectedMember
    from flutils.packages import bump_version
    from flutils.testing import CaptureStd
    import sys

    def _test_1():
        ver_bumped = bump_version(
            '1.2.2',
            position=2,
            pre_release='b'
        )
        assert ver_bumped == '1.2.3b0'

    def _test_2():
        ver_bumped = bump_version(
            '1.2.2',
            position=2,
            pre_release='beta'
        )

        assert ver_bumped == '1.2.3b0'


# Generated at 2022-06-25 17:41:10.783047
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Test: Bumping the major version number
    version = bump_version('1.2.3', 0)
    assert version == '2'

    # Test: Bumping the minor version number
    version = bump_version('1.2.4', 1)
    assert version == '1.3'

    # Test: Bumping the patch version number
    version = bump_version('1.2.3')
    assert version == '1.2.4'

    # Test: Negative numbers
    version = bump_version('1.2.3', -1)
    assert version == '1.3'
    version = bump_version('1.2.3', -2)
    assert version == '2.0'
    version = bump_version('1.2.3', -3)
   