

# Generated at 2022-06-25 17:31:43.016834
# Unit test for function bump_version
def test_bump_version():
    for num in range(3):
        assert bump_version('1.0.0') == '1.0.1'
        assert bump_version('1.0.1') == '1.0.2'
        assert bump_version('1.0.2') == '1.0.3'

    assert bump_version('1.2.2', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-25 17:31:44.224469
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    raise NotImplementedError

# Generated at 2022-06-25 17:31:52.762900
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:02.607231
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:13.061713
# Unit test for function bump_version
def test_bump_version():
    # From version number string
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:23.319423
# Unit test for function bump_version
def test_bump_version():
    """Tests ``bump_version`` function."""
    # The number of tests to run.
    num_tests = 12
    # This is the number of tests that have been run.
    current_test = 1

    def run_test(
            version_number: str,
            position: int,
            pre_release: Optional[str],
            expected: str
    ) -> None:
        global current_test
        test_name = 'test_%s' % current_test
        print('Running %s ...' % test_name)

        # Run the test
        actual = bump_version(
            version=version_number,
            position=position,
            pre_release=pre_release
        )

        # Test to make sure what we got is what we expected.
        assert actual == expected

        # Display success message.
       

# Generated at 2022-06-25 17:32:35.277882
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    # Verify we can only increment the lower positions
    test_num = 2
    for pos in range(-3, 3):
        pos = _build_version_bump_position(pos)
        if pos > test_num:
            continue
        ver_info = _build_version_info('2.1.1')
        bump_type = _build_version_bump_type(pos, None)
        out = bump_version(ver_info.version, pos)
        part = ver_info[bump_type.name]
        if bump_type.pre_txt:
            part = part.num
        txt = '%s.%s' % (ver_info.major.num, part)
        assert txt == out
    # Verify we can increment alpha's and beta's

# Generated at 2022-06-25 17:32:43.151217
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=too-many-arguments,too-many-branches,too-many-locals,too-many-statements
    """Test bump_version.

    .. NOTE:: This function will only run if the current module has been
        imported.

    """
    # pylint: disable=E0602

    #  _BUMP_VERSION_MAJOR: int = 0
    #  _BUMP_VERSION_MINOR: int = 1
    #  _BUMP_VERSION_PATCH: int = 2
    #  _BUMP_VERSION_MINOR_ALPHA: int = 3
    #  _BUMP_VERSION_MINOR_BETA: int = 4
    #  _BUMP_VERSION_PATCH_ALPHA: int = 5
    #  _BUMP_VERSION_PATCH_

# Generated at 2022-06-25 17:32:51.354199
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:03.842933
# Unit test for function bump_version
def test_bump_version():
    "Unit test for function bump_version."
    # Minor, no pre-release
    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2.1', position=1) == '1.3'
    assert bump_version('1.2.1', position=0) == '2.0'
    # Minor, alpha
    assert bump_version('1.2.1', pre_release='a') == '1.2.2a0'
    assert bump_version('1.2.2a0', pre_release='a') == '1.2.2a1'
    # Minor, beta
    assert bump_version('1.2.2a0', pre_release='b') == '1.2.2b0'

# Generated at 2022-06-25 17:33:50.012766
# Unit test for function bump_version
def test_bump_version():
    """Test the function bump_version."""
    import pytest


# Generated at 2022-06-25 17:34:02.369649
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    import sys

    str_0 = '2'
    str_1 = bump_version(str_0, str_0)
    print('test_bump_version 1', str_1, str_1 == '2')

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, str_0)
    print('test_bump_version 2', str_1, str_1 == '1.2.4')

    str_0 = '1.2.4'
    str_1 = bump_version(str_0)
    print('test_bump_version 3', str_1, str_1 == '1.2.5')

    str_0 = '1.2.5'

# Generated at 2022-06-25 17:34:11.664017
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:17.286464
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""

    # Test with bad data
    with pytest.raises(ValueError):
        bump_version('1.2.3', '1.2.3', 0)

    with pytest.raises(ValueError):
        bump_version(1)

    with pytest.raises(ValueError):
        bump_version('1')

    with pytest.raises(ValueError):
        bump_version('1.2')

    with pytest.raises(ValueError):
        bump_version('1.2.3.4')

    with pytest.raises(ValueError):
        bump_version('1.2.3a1')

    with pytest.raises(ValueError):
        bump_version('1.2.3a0')


# Generated at 2022-06-25 17:34:29.318806
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:36.682826
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:47.184442
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=-2) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:53.580382
# Unit test for function bump_version
def test_bump_version():
    test_prerelease = 'a'
    # tests with no pre-release
    assert '1.2.3' == bump_version('1.2.2')
    assert '1.3' == bump_version('1.2.3', position=1)
    assert '2.0' == bump_version('1.3.4', position=0)
    assert '1.2.4' == bump_version('1.2.4a0')
    assert '1.2.4' == bump_version('1.2.4b0')
    assert '1.2.4' == bump_version('1.2b0', position=2)

    # tests with pre-release
    assert '1.2.4a0' == bump_version('1.2.3', prerelease=test_prerelease)

# Generated at 2022-06-25 17:34:54.134836
# Unit test for function bump_version
def test_bump_version():
    pass



# Generated at 2022-06-25 17:35:01.839670
# Unit test for function bump_version
def test_bump_version():
    version = '0.0.0'
    result = bump_version(version, position=0)
    assert result == '1.0'

    version = '1.0.0'
    result = bump_version(version, position=0)
    assert result == '2.0'

    version = '1.1.0'
    result = bump_version(version, position=0)
    assert result == '2.0'

    version = '0.0.0'
    result = bump_version(version, position=1)
    assert result == '0.1'

    version = '0.1.0'
    result = bump_version(version, position=1)
    assert result == '0.2'

    version = '0.0.0'
    result = bump_version(version, position=2)

# Generated at 2022-06-25 17:35:50.328182
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class BumpVersionTestCase(unittest.TestCase):
        def test_basic(self):
            """Basic test of bumping versions."""
            is_ok = bump_version('1.0.0') == '1.0.1'
            self.assertTrue(is_ok, '1.0.0 -> 1.0.1')
            is_ok = bump_version('1.1.1') == '1.1.2'
            self.assertTrue(is_ok, '1.1.1 -> 1.1.2')

        def test_minor(self):
            """Test bumping a version to a minor version (1.1)"""
            is_ok = bump_version('1.1.0', 1) == '1.2'

# Generated at 2022-06-25 17:36:01.427134
# Unit test for function bump_version
def test_bump_version():
    ####
    # Test 0: Edge case.
    ####
    str_0 = 'AI'
    str_1 = bump_version(str_0, str_0)
    str_2 = bump_version(str_1, str_0)
    str_3 = bump_version(str_2, str_0)
    str_4 = bump_version(str_3, str_0)
    str_5 = bump_version(str_4, str_0)
    str_6 = bump_version(str_5, str_0)
    str_7 = bump_version(str_6, str_0)
    str_8 = bump_version(str_7, str_0)
    str_9 = bump_version(str_8, str_0)

# Generated at 2022-06-25 17:36:04.010971
# Unit test for function bump_version
def test_bump_version():
    print('>>>')
    # test_case_0()
    print('<<<')
    exit(0)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:36:04.942995
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:36:16.565555
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:28.220011
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', 'a') == '1.2.4a1'
    assert bump_version('1.2.4a1', 'b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_

# Generated at 2022-06-25 17:36:36.295866
# Unit test for function bump_version
def test_bump_version():
    # type: () -> None
    """Unit test for function bump_version"""
    ver_num = '1.2.0'
    assert bump_version(ver_num) == '1.2.1'
    assert bump_version(ver_num, position=1) == '1.3'
    assert bump_version(ver_num, position=0) == '2.0'
    assert bump_version(ver_num, pre_release='a') == '1.2.1a0'
    assert bump_version(ver_num, pre_release='b') == '1.2.1b0'
    ver_num = '1.2.1a0'
    assert bump_version(ver_num, pre_release='a') == '1.2.1a1'

# Generated at 2022-06-25 17:36:44.273309
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:56.365788
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:04.416259
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:43.744922
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:53.060940
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.3', position=0)
    bump_version('1.2.3', position=1)
    bump_version('1.2.3', position=2)
    bump_version('1.2.3', position=-1)
    bump_version('1.2.3', position=-2)
    bump_version('1.2.3', position=-3)
    bump_version('1.2.3', position=3)
    bump_version('1.2.3', position=4)
    bump_version('1.2.3', position=5)

    bump_version('1.2.3', pre_release='a')
    bump_version('1.2.3', pre_release='alpha')
    bump_version('1.2.3', pre_release='b')
   

# Generated at 2022-06-25 17:38:04.240171
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    test_case_0()
    # Test case 1
    expected = '1.3'
    result = bump_version('1.2.2', position=1)
    assert result == expected

    # Test case 2
    expected = '2.0'
    result = bump_version('1.3.4', position=0)
    assert result == expected

    # Test case 3
    expected = '1.2.4a0'
    result = bump_version('1.2.3', prerelease='a')
    assert result == expected

    # Test case 4
    expected = '1.2.4a1'
    result = bump_version('1.2.4a0', pre_release='a')
    assert result == expected

    # Test case 5

# Generated at 2022-06-25 17:38:06.339544
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod()
    return True


# Run successful unit tests
if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:38:16.385297
# Unit test for function bump_version
def test_bump_version():
    """
    Test for version 1.2.3
    """
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 0)
    assert str_1 == '2.0'
    str_1 = bump_version(str_0, 1)
    assert str_1 == '1.3'
    str_1 = bump_version(str_0, 2)
    assert str_1 == '1.2.4'
    str_1 = bump_version(str_0, -1)
    assert str_1 == '1.2.4'
    str_1 = bump_version(str_0, -2)
    assert str_1 == '1.3'
    str_1 = bump_version(str_0, -3)

# Generated at 2022-06-25 17:38:28.460443
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:29.386149
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    return

# Generated at 2022-06-25 17:38:40.902692
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version, _force_version_bump
    from distutils.version import StrictVersion

    str_0 = '1.2.1'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.2'

    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'

    str_0 = '1.2.2'
    str_2 = bump_version(str_0, position=1)
    assert str_2 == '1.3'

    str_0 = '1.2.2'
    str_3 = bump_version(str_0, position=0)
    assert str_3 == '2.0'

   

# Generated at 2022-06-25 17:38:52.501631
# Unit test for function bump_version
def test_bump_version():
    """Unit test for ``bump_version``."""
    str_0 = '1.2.1'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.2'
    str_2 = bump_version(str_1, position=1)
    assert str_2 == '1.3'
    str_3 = bump_version(str_2, position=0)
    assert str_3 == '2.0'
    str_4 = bump_version(str_2, pre_release='a')
    assert str_4 == '1.3a0'
    str_5 = bump_version(str_4, pre_release='a')
    assert str_5 == '1.3a1'

# Generated at 2022-06-25 17:39:00.490228
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:08.651343
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:19.590091
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:21.109877
# Unit test for function bump_version
def test_bump_version():
    bump_version('1.2.1', 2, None)



# Generated at 2022-06-25 17:40:22.814904
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:40:30.062783
# Unit test for function bump_version
def test_bump_version():
    ver_0 = '1.2.0'
    ver_1 = bump_version(ver_0)
    if ver_1 != '1.2.1':
        raise ValueError(ver_1)
    ver_0 = '1.2.3'
    ver_1 = bump_version(ver_0)
    if ver_1 != '1.2.4':
        raise ValueError(ver_1)
    ver_0 = '1.3.4'
    ver_1 = bump_version(ver_0, 1)
    if ver_1 != '1.4':
        raise ValueError(ver_1)
    ver_0 = '4.2.0'
    ver_1 = bump_version(ver_0, 0)

# Generated at 2022-06-25 17:40:41.709453
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('2.1.3', position=1, pre_release='a') == '2.2a0'

# Generated at 2022-06-25 17:40:47.878232
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.1') == '1.2.2'
    assert bump_version('1.2', position=0) == '2.0'
    assert bump_version('1.2', position=0, pre_release='a') == '2.0a0'
    assert bump_version('1.2', position=1) == '1.3'
    assert bump_version('1.2', position=1, pre_release='b') == '1.3b0'
    assert bump_version('1.2', position=2) == '1.2.1'
    assert bump_version(
        '1.2',
        position=2,
        pre_release='b'
    ) == '1.2.1b0'


# Unit

# Generated at 2022-06-25 17:40:54.087384
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:57.942468
# Unit test for function bump_version
def test_bump_version():
    """Tests the ``bump_version`` function."""
    print(test_case_0())


if __name__ == '__main__':
    # Unit test this module
    test_bump_version()


# EOF

# Generated at 2022-06-25 17:41:10.783156
# Unit test for function bump_version
def test_bump_version():
    vers = '1.2.3'
    expected = '1.2.4'
    result = bump_version(vers)
    print(result)
    assert result == expected
    vers = '1.2.3'
    expected = '1.3'
    result = bump_version(vers, position=1)
    print(result)
    assert result == expected
    vers = '1.2.3'
    expected = '2.0'
    result = bump_version(vers, position=0)
    print(result)
    assert result == expected
    vers = '1.2.3'
    expected = '1.2.4a0'
    result = bump_version(vers, pre_release='a')
    print(result)
    assert result == expected