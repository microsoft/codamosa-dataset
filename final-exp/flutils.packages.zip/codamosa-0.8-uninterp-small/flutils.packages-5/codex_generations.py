

# Generated at 2022-06-25 17:31:45.893723
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:31:54.207799
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:04.016872
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:15.512339
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:25.276431
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function :func:`bump_version`."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
   

# Generated at 2022-06-25 17:32:37.080279
# Unit test for function bump_version
def test_bump_version():
    # simple patch
    assert bump_version('1.2.3') == '1.2.4'
    # simple minor
    assert bump_version('1.2.3', 1) == '1.3'
    # simple major
    assert bump_version('1.2.3', 0) == '2.0'
    # alpha patch
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    # alpha patch again
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # beta patch
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    # clear patch alpha

# Generated at 2022-06-25 17:32:43.664187
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version.
    """
    # Test case 0
    global test_case_0
    print(test_case_0.__doc__)
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:32:51.667024
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:04.059404
# Unit test for function bump_version
def test_bump_version():
    test_data = (
        ('0.0.0', '0.0.1'),
        ('1.2.3', '1.2.4'),
        ('1.2.3', '1.3.4', 1),
        ('1.2.3', '2.3.4', 0),
    )
    for args, exp in test_data:
        if len(args) == 2:
            args, exp = args + (None,)
        assert bump_version(*args) == exp

    for pos in range(-3, 3):
        for pre in ('a', 'alpha', 'b', 'beta', None):
            if pre is not None:
                pre = cast(str, pre)
            bump_version('1.2.3', pos, pre)

    with pytest.raises(ValueError):
        bump

# Generated at 2022-06-25 17:33:11.189206
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:36.272749
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    """Unit test for the bump_version function."""
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:33:39.100488
# Unit test for function bump_version
def test_bump_version():
    print('Testing module: %s' % __file__)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:33:48.848037
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:49.826535
# Unit test for function bump_version
def test_bump_version():
    ver_info = _build_version_info('1.2.3')

# test_case_0()

# Generated at 2022-06-25 17:34:02.369790
# Unit test for function bump_version
def test_bump_version():
    from .test_packages import assert_function_output

    assert_function_output(bump_version, in_kwargs={'version': '1.2.2'}, out=None)
    assert_function_output(bump_version, in_kwargs={'version': '1.2.3'}, out=None)
    assert_function_output(
        bump_version,
        in_kwargs={'version': '1.2.3', 'position': 1},
        out=None
    )
    assert_function_output(
        bump_version,
        in_kwargs={'version': '1.3.4', 'position': 0},
        out=None
    )

# Generated at 2022-06-25 17:34:11.664545
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestBumpVersion(unittest.TestCase):

        def test_00(self):
            version = '1.2.3'
            expected = '1.2.4'
            actual = bump_version(version)
            self.assertEqual(expected, actual)

        def test_01(self):
            version = '1.2.3'
            expected = '1.3'
            actual = bump_version(version, position=1)
            self.assertEqual(expected, actual)

        def test_02(self):
            version = '1.3.4'
            expected = '2.0'
            actual = bump_version(version, position=0)
            self.assertEqual(expected, actual)


# Generated at 2022-06-25 17:34:20.628797
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:31.699354
# Unit test for function bump_version
def test_bump_version():
    from pprint import pprint
    from textwrap import dedent

    # _VersionPart
    # pylint: disable=C0103
    VersionPart = _VersionPart

    # _VersionPart
    # pylint: disable=C0103
    VersionInfo = _VersionInfo

    # Setup the version parts
    major_0: VersionPart = VersionPart(
        pos=0,
        txt='0',
        num=0,
        pre_txt='',
        pre_num=-1,
        name=_BUMP_VERSION_POSITION_NAMES[0]
    )

# Generated at 2022-06-25 17:34:43.645323
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:56.931096
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:21.739686
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, prerelease='a') == '1.2.4a0'
    assert bump_version(version, pre_release='a') == '1.2.4a1'
    assert bump_version(version, pre_release='b') == '1.2.4b0'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version) == '1.2.4'
    assert bump_version(version + 'a0') == '1.2.4a1'

# Generated at 2022-06-25 17:35:33.018945
# Unit test for function bump_version
def test_bump_version():
    from flutils.commonutils import flat_list
    from flutils.commonutils import get_random_string
    from flutils.commonutils import get_random_digit_str

    # noinspection PyBroadException
    try:
        bump_version('1.2.3', position=3)
        assert False, 'Expecting a ValueError for position=3.'
    except ValueError:
        pass
    except Exception:  # pylint: disable=broad-except
        assert False, "Expecting a ValueError for position=3."

    # noinspection PyBroadException
    try:
        bump_version('1.2.3', position=-4)
        assert False, 'Expecting a ValueError for position=-4.'
    except ValueError:
        pass

# Generated at 2022-06-25 17:35:41.539984
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:52.384802
# Unit test for function bump_version
def test_bump_version():
    """Tests for the bump_version function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:03.500287
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:15.461452
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:27.376984
# Unit test for function bump_version
def test_bump_version():

    def test_bump_version_error(version, position, pre_release):
        with pytest.raises(ValueError) as excinfo:
            bump_version(version, position, pre_release)
        assert str(excinfo.value) == 'The given value for \'version\', \'' \
                                     '1.2.3.4\', is not a valid version ' \
                                     'number.'
        with pytest.raises(ValueError) as excinfo:
            bump_version(version, position, pre_release)
        assert str(excinfo.value) == 'The given value for \'version\', \'' \
                                     '1.2.3a0.0\', is not a valid version ' \
                                     'number.'
        with pytest.raises(ValueError) as excinfo:
            bump_

# Generated at 2022-06-25 17:36:35.690090
# Unit test for function bump_version
def test_bump_version():
    import pytest

    with pytest.raises(ValueError):
        bump_version('1.2.3', position=0, pre_release='a')
    with pytest.raises(ValueError):
        bump_version('1.2.3', position=0, pre_release='b')
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-25 17:36:47.201003
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.2', 3) == '1.2.2'
    assert bump_version('1.2.2alpha') == '1.2.3'
    assert bump_version('1.2.2alpha', 1) == '1.3'
    assert bump_version('1.2.2alpha', 0) == '2.0'
    assert bump_version('1.2.2beta') == '1.2.3'

# Generated at 2022-06-25 17:36:58.567101
# Unit test for function bump_version
def test_bump_version():
    """Test case for ``bump_version``."""

    # Test case 0
    try:
        test_case_0()
    except AttributeError as err:
        assert str(err) == (
            "'_VersionInfo' object has no attribute "
            "'major'"
        )

    # Test case 1
    ver_info = bump_version('1.2.2')
    assert ver_info == '1.2.3'

    # Test case 2
    ver_info = bump_version('1.2.3', position=1)
    assert ver_info == '1.3'

    # Test case 3
    ver_info = bump_version('1.3.4', position=0)
    assert ver_info == '2.0'

    # Test case 4

# Generated at 2022-06-25 17:37:30.141468
# Unit test for function bump_version
def test_bump_version():
    """
    tests for function
    :func:`flutils.packages.bump_version`
    """
    global version_info_0  # pylint: disable=W0603
    version_info_0 = _build_version_info('1.2.3')
    assert version_info_0.version == '1.2.3'
    assert version_info_0.major.pos == 0
    assert version_info_0.major.txt == '1'
    assert version_info_0.major.num == 1
    assert version_info_0.major.pre_txt == ''
    assert version_info_0.major.pre_num == -1
    assert version_info_0.minor.pos == 1
    assert version_info_0.minor.txt == '2'
    assert version_info

# Generated at 2022-06-25 17:37:35.649912
# Unit test for function bump_version
def test_bump_version():
    result = bump_version('1.2.2')
    assert(result == '1.2.3')


if __name__ == '__main__':
    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:37:45.872922
# Unit test for function bump_version
def test_bump_version():
    version_info_0 = _VersionInfo('1.2.3',
                                  _VersionPart(0, '1', 1, '', -1, 'major'),
                                  _VersionPart(1, '2', 2, '', -1, 'minor'),
                                  _VersionPart(2, '3', 3, '', -1, 'patch'),
                                  -1)

    assert bump_version('') == '0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'

# Generated at 2022-06-25 17:37:54.275628
# Unit test for function bump_version
def test_bump_version():

    # Test 1 - No prerelease
    version = '1.2.3'
    if bump_version(version) != '1.2.4':
        print(
            'Test 1 - Error: %s should be %s' % (
                bump_version(version),
                '1.2.4',
            )
        )

    # Test 2 - Bump minor, no prerelease
    version = '1.2.3'
    if bump_version(version, position=1) != '1.3':
        print(
            'Test 2 - Error: %s should be %s' % (
                bump_version(version, position=1),
                '1.3',
            )
        )

    # Test 3 - Bump major, no prerelease
    version = '1.2.3'

# Generated at 2022-06-25 17:38:06.007712
# Unit test for function bump_version
def test_bump_version():
    test_1 = '1.0.0'
    result = bump_version(test_1)
    assert result == '1.0.1'
    test_2 = '2.0.1'
    result = bump_version(test_2)
    assert result == '2.0.2'
    test_3 = '1.1.0'
    result = bump_version(test_3)
    assert result == '1.1.1'
    test_4 = '1.1.0'
    result = bump_version(test_4, position=1)
    assert result == '1.2'
    test_5 = '1.2.0'
    result = bump_version(test_5, position=0)
    assert result == '2.0'

# Generated at 2022-06-25 17:38:16.098541
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:28.163904
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:35.974814
# Unit test for function bump_version
def test_bump_version():

    def _build(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str,
    ) -> None:
        try:
            out = bump_version(version, position, pre_release)
            assert out == expected
        except Exception as e:
            msg = "Failed: bump_version(%r, %r, %r)" % (
                version,
                position,
                pre_release
            )
            if hasattr(e, 'message'):
                msg += '\n%s\n' % e.message
            raise AssertionError(msg)

# Generated at 2022-06-25 17:38:40.526231
# Unit test for function bump_version
def test_bump_version():
    # The given value for 'position', -3, must be an 'int'
    # between (-3) and (2)
    try:
        bump_version('1.0.0', position=-3)
    except ValueError as err:
        assert 'The given value for \'position\', -3, must be an \'int\' ' \
               'between (-3) and (2).' in '%s' % err
    else:
        assert False

    # The given value for 'position', -3, must be an 'int'
    # between (-3) and (2)

# Generated at 2022-06-25 17:38:52.241273
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the :func:`flutils.packages.bump_version` function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:39:07.254754
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:09.826903
# Unit test for function bump_version
def test_bump_version():
    # Test function bump_version
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 17:39:18.250118
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', position=1, pre_release='b') == '1.3b0'
    assert bump_version('1.2.3', position=1, pre_release='a') == '1.3a0'
    assert bump_version('1.2.3', position=-1) == '1.2.3'
    assert bump_version('1.2.3', position=-2) == '1.3'

# Generated at 2022-06-25 17:39:28.879220
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:39:30.406164
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:39:37.255372
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    def test_case_0():
        str_0 = '1.2.2'
        str_1 = bump_version(str_0)

    def test_case_1():
        str_0 = '1.2.3'
        str_1 = '1.3'
        str_2 = bump_version(str_0, position=1)
        assert str_1 == str_2

    def test_case_2():
        str_0 = '1.2.3'
        str_1 = '2.0'
        str_2 = bump_version(str_0, position=0)
        assert str_1 == str_2

    def test_case_3():
        str_0 = '1.2.3'

# Generated at 2022-06-25 17:39:38.607740
# Unit test for function bump_version
def test_bump_version():
    test_case_0()



# Generated at 2022-06-25 17:39:41.996571
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    print('%s passes' % bump_version.__name__)


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:52.477068
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:01.078002
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:20.353904
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:28.809502
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=R0915
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:40.785300
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:50.345264
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:59.135299
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:41:11.147473
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    from flutils.tests import TEST_PYVERSION
    from types import ModuleType
    from inspect import getmembers, ismodule
    from sys import modules
    import doctest
    TEST_PYVERSION = str(TEST_PYVERSION)