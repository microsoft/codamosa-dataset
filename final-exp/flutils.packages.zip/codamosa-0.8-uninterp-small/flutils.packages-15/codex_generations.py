

# Generated at 2022-06-25 17:31:44.869201
# Unit test for function bump_version
def test_bump_version():
    # Unit test for function bump_version
    import unittest
    from unittest import TestCase

    class BumpVersionTests(TestCase):
        """Unit tests for the bump_version function.
        """
        def test_bump_version_valid_patch(self):
            """ GIVEN a version number string WHEN bumping the patch number
                THEN the string is returned with the patch number increased
                by one.
            """
            self.assertEqual(
                bump_version('1.2.4'),
                '1.2.5'
            )

        def test_bump_version_valid_minor(self):
            """ GIVEN a version number string WHEN bumping the minor number
                THEN the string is returned with the minor number increased
                by one.
            """

# Generated at 2022-06-25 17:31:53.364859
# Unit test for function bump_version
def test_bump_version():
    print('\n*')
    print('* Tests for the "bump_version" function')
    print('*')

    def _rer(
            num_list: Tuple[int, ...],
            prerelease: Optional[str] = None
    ) -> str:
        txt = '.'.join(map(str, num_list))
        if prerelease is not None:
            return bump_version(txt, pre_release=prerelease)
        return bump_version(txt)

    def _test(num_list: Tuple[int, ...], prerelease: str = None) -> str:
        return _rer(num_list, prerelease=prerelease)


# Generated at 2022-06-25 17:32:03.227003
# Unit test for function bump_version
def test_bump_version():
    # unit tests
    version = '1.2.3'
    exp_lst = ['1.2.3', '1.3', '2.0', '1.2.3a0', '1.2.3a1', '1.2.3b0', '1.2.4',
               '1.2.4', '1.2.4', '1.3a0', '1.2.4b0', '1.2.4', '1.2.4', '1.2.4']


# Generated at 2022-06-25 17:32:14.224050
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=R0915
    # pylint: disable=C0103
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    test_data_dir = os.path.join(scripts_dir, 'test_data')
    test_input_file = os.path.join(test_data_dir, 'bump_input.json')

    with open(test_input_file, 'r') as fh:
        input_data = json.load(fh)

    # Structure for the test results
    test_results = []  # type: List[Dict[str, Any]]

    for test in input_data:
        version = test['Version']
        position = test['Position']
        prerelease = test['PreRelease']

# Generated at 2022-06-25 17:32:24.281562
# Unit test for function bump_version
def test_bump_version():
    ver_input = '0.0.1'
    ver_output = bump_version(ver_input)
    assert '0.0.2' == ver_output

    ver_input = '0.0.0'
    ver_output = bump_version(ver_input)
    assert '0.0' == ver_output

    ver_input = '0.0'
    ver_output = bump_version(ver_input)
    assert '0.0' == ver_output

    ver_input = '0.0'
    ver_output = bump_version(ver_input, position=1)
    assert '0.1' == ver_output

    ver_input = '0.0'
    ver_output = bump_version(ver_input, position=2)
    assert '0.0.1' == ver_

# Generated at 2022-06-25 17:32:36.295159
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:43.817415
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version."""
    # pylint: disable=E1120
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    # new test
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:32:51.732797
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

# Generated at 2022-06-25 17:33:04.122425
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:11.248961
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:35.077780
# Unit test for function bump_version
def test_bump_version():
    # Test if bump_version bumps the version numbers
    test_case_0()

    # Test if bump_version bumps the version numbers
    str_0 = '1.2.4'
    str_1 = bump_version(str_0, position=1)
    str_2 = '1.3'
    assert str_1 == str_2

    # Test if bump_version bumps the version numbers
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    str_2 = '2.0'
    assert str_1 == str_2

    # Test if bump_version bumps the version numbers
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')

# Generated at 2022-06-25 17:33:36.393780
# Unit test for function bump_version
def test_bump_version():
    test_cases = (
        test_case_0,
    )

    for t in test_cases:
        yield t

# Generated at 2022-06-25 17:33:38.886766
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:33:48.730586
# Unit test for function bump_version
def test_bump_version():
    import sys
    import random
    import string
    import unittest

    class TestBumpVersion(unittest.TestCase):
        def test_case_0(self):
            str_0 = '1.2.4'
            str_1 = bump_version(str_0)
            str_2 = '1.2.5'

            self.assertEqual(str_1, str_2)

        def test_case_1(self):
            str_0 = '1.2.4'
            str_1 = bump_version(str_0, position=1)
            str_2 = '1.3'

            self.assertEqual(str_1, str_2)

        def test_case_2(self):
            str_0 = '1.2.4'
            str_1 = bump

# Generated at 2022-06-25 17:34:00.938674
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version."""
    from tests._utilities import _messages_version2
    from tests._utilities import print_error_message
    from tests._utilities import print_success_message
    from tests._utilities import get_test_value

    # noinspection PyUnresolvedReferences
    from tests._constants import _TEST_BUMP_VERSION_ITEMS

    test_case_0()

    print('Testing bump_version')

    successes = 0
    failures = 0

    # noinspection PyUnusedLocal

# Generated at 2022-06-25 17:34:09.451496
# Unit test for function bump_version
def test_bump_version():  # noqa: D102
    str_0 = '1.2.4'
    str_1 = bump_version(str_0)
    str_2 = '1.2.5'
    assert str_1 == str_2

    str_0 = '1.2.4'
    str_1 = bump_version(str_0, position=1)
    str_2 = '1.3'
    assert str_1 == str_2

    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    str_2 = '2.0'
    assert str_1 == str_2

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')

# Generated at 2022-06-25 17:34:19.720886
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:31.076959
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.0.0') == '0.0.1'
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:34:32.015457
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:34:43.671240
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyShadowingNames
    def _test(version, expected):
        # noinspection PyUnusedLocal
        actual = bump_version(version)
        assert expected == actual

    _test('1.2.2', '1.2.3')
    _test('1.2.3', '1.2.4')
    _test('1.2.3', '1.2.4', position=2)
    _test('1.2.3', '1.3.0', position=1)
    _test('1.2.3', '2.0.0', position=0)
    _test('1.2.3', '1.2.4a0', pre_release='a')

# Generated at 2022-06-25 17:34:58.433408
# Unit test for function bump_version
def test_bump_version():

    version = "2.2.2a6"
    position = 2
    pre_release = "a"
    assert bump_version(version, position, pre_release) == "2.2.3a0"
    print("bump_version() works for :", bump_version(version, position, pre_release))


test_bump_version()

# Generated at 2022-06-25 17:35:06.653267
# Unit test for function bump_version
def test_bump_version():
    def check(s, pos, restype):
        got = bump_version(s, pos)
        if got != restype:
            raise ValueError(
                "Failed test.  Got: %s, expected: %s" % (got, restype))
    check('1.0.0', 0, '2.0')
    check('1.0.0', 1, '1.1')
    check('1.0.0', 2, '1.0.1')
    check('1.1.0', 2, '1.1.1')
    check('1.0.1', 0, '2.0')
    check('1.0.1', 1, '1.1.0')
    check('1.0.1', 2, '1.0.2')

# Generated at 2022-06-25 17:35:15.398482
# Unit test for function bump_version
def test_bump_version():
    """Test for function bump_version."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:19.028801
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert (str_1 == '1.2.4')



# Generated at 2022-06-25 17:35:30.812398
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version()."""
    # TODO: Fix this
    # Unit test for working in the Python REPL
    # print(bump_version('1.2.4'))
    # print(bump_version('1.2.4', position=1))
    # print(bump_version('1.3.4', position=0))
    # print(bump_version('1.2.3', prerelease='a'))
    # print(bump_version('1.2.4a0', pre_release='a'))
    # print(bump_version('1.2.4a1', pre_release='b'))
    # print(bump_version('1.2.4a1'))
    # print(bump_version('1.2.4b0'))
    #

# Generated at 2022-06-25 17:35:31.882301
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:35:38.788319
# Unit test for function bump_version
def test_bump_version():
    from random import randint
    from random import choice

    _type = None
    # noinspection PyUnusedLocal
    _msg = None

    try:
        bump_version('2.5')
    except ValueError:
        _type, _msg = sys.exc_info()[:2]
    assert _type is not None, 'No exception raised.'
    assert _msg is not None, 'No message on exception.'
    assert _msg.args[0] == \
        "The given value for 'position', 2, must be an 'int' between (0) and " \
        "(2)."

    try:
        bump_version('2.5', 1, 'z')
    except ValueError:
        _type, _msg = sys.exc_info()[:2]

# Generated at 2022-06-25 17:35:50.537027
# Unit test for function bump_version
def test_bump_version():
    a = '1.2.3'
    b = bump_version(a)
    assert b == '1.2.4'

    a = '1.2.3'
    b = bump_version(a, position=0)
    assert b == '2.0'

    a = '1.2.3'
    b = bump_version(a, position=1)
    assert b == '1.3'

    a = '1.2.3'
    b = bump_version(a, position=-1)
    assert b == '1.2.4'

    a = '1.2.3'
    b = bump_version(a, position=-2)
    assert b == '1.3'

    a = '1.2.3'
    b = bump_version(a, position=-3)

# Generated at 2022-06-25 17:36:01.652628
# Unit test for function bump_version
def test_bump_version():
    # Case 0
    version = '1.2.4'
    result = bump_version(version)
    expected = '1.2.5'
    assert result == expected, (
        'Expected (%s), but got (%s)' % (expected, result)
    )
    # Case 1
    version = '1.2.4'
    result = bump_version(version, position=1)
    expected = '1.3'
    assert result == expected, (
        'Expected (%s), but got (%s)' % (expected, result)
    )
    # Case 2
    version = '1.3.4'
    result = bump_version(version, position=0)
    expected = '2.0'

# Generated at 2022-06-25 17:36:09.392885
# Unit test for function bump_version
def test_bump_version():
    # Test case string 0
    # Original string
    str_0 = '1.2.4'
    # New string
    str_1 = bump_version(str_0)
    # Old position 0
    pos_0_0 = 1
    # New position 0
    pos_0_1 = 2
    # Old position 1
    pos_1_0 = 2
    # New position 1
    pos_1_1 = 0
    # Verify that the version number has been bumped
    assert str_1 != str_0
    # Verify that the original version number and new version number
    #   are valid version numbers
    assert StrictVersion(str_0)
    assert StrictVersion(str_1)
    # Verify that the patch position has been increased by 1
    assert StrictVersion(str_0).version[pos_0_0]

# Generated at 2022-06-25 17:36:33.050559
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version.

    Execute the tests from this module from the command line:
        python -m flutils.packages.test_bump_version

    """
    import unittest

    # noinspection PyShadowingNames
    class BumpVersionTests(unittest.TestCase):  # pylint: disable=R0904
        """Tests for the function :py:func:`~flutils.packages.bump_version`."""

        def test_case_0(self):
            """Test the '1.2.4' case."""
            str_0 = '1.2.4'
            str_1 = bump_version(str_0)
            self.assertEqual(str_1, '1.2.5')


# Generated at 2022-06-25 17:36:41.025504
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:52.384595
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, prerelease='a')
    assert str_1 == '1.2.4a0'

    str_0 = '1.2.4a0'

# Generated at 2022-06-25 17:36:56.220088
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    # assert bump_version(a, b) == c
    return


if __name__ == '__main__':

    test_bump_version()

# Generated at 2022-06-25 17:36:59.105849
# Unit test for function bump_version
def test_bump_version():
    print('\nFunction: bump_version()')
    test_case_0()


if __name__ == '__main__':
    print('\nModule: __main__')
    test_bump_version()

# Generated at 2022-06-25 17:37:06.090920
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import _build_version_bump_type
    from flutils.packages import _build_version_info
    from flutils.packages import _build_version_bump_position

    # noinspection PyUnusedLocal
    info: _VersionInfo

    # MAJOR
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '2.0'

    # MINOR
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    # PATCH
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=2)
    assert str_1

# Generated at 2022-06-25 17:37:16.969848
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.1.1') == '1.1.2'
    assert bump_version('1.1.1', pre_release='alpha') == '1.1.2a0'
    assert bump_version('1.1.1a0', pre_release='alpha') == '1.1.1a1'
    assert bump_version('1.1.1b0', pre_release='beta') == '1.1.1b1'
    assert bump_version('1.1.1a0', pre_release='beta') == '1.1.2b0'
    assert bump_version('1.1.1a0') == '1.1.2'
    assert bump_version('1.1.1b0') == '1.1.2'

# Generated at 2022-06-25 17:37:27.238557
# Unit test for function bump_version
def test_bump_version():
    """Tests for `bump_version`."""
    v = '1.2.4'
    bump_version(v)
    bump_version(v, position=-1)
    bump_version(v, position=-2)
    bump_version(v, position=-3)
    bump_version(v, position=0)
    bump_version(v, position=1)
    bump_version(v, position=2)
    bump_version(v, position=3)
    bump_version(v, pre_release='a')
    bump_version(v, position=1, pre_release='a')
    bump_version(v, position=2, pre_release='a')
    bump_version(v, pre_release='b')
    bump_version(v, position=1, pre_release='b')


# Generated at 2022-06-25 17:37:38.150067
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:39.689170
# Unit test for function bump_version
def test_bump_version():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 17:38:01.292956
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.4'
    str_1 = '1.2.5'
    assert bump_version(str_0) == str_1

    str_0 = '1.2.4'
    str_1 = '1.3.1'
    assert bump_version(str_0, position=1) == str_1

    str_0 = '1.2.4'
    str_1 = '2.1.1'
    assert bump_version(str_0, position=0) == str_1

    str_0 = '1.2.4'
    str_1 = '1.2.4a0'
    assert bump_version(str_0, prerelease='a') == str_1

    str_0 = '1.2.4a0'

# Generated at 2022-06-25 17:38:11.840382
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', 1) == '1.3'
    assert bump_version('1.3.4', 0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0') == '1.2.4'


# Generated at 2022-06-25 17:38:20.534837
# Unit test for function bump_version
def test_bump_version():
    func_name = 'bump_version'


# Generated at 2022-06-25 17:38:29.348438
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:36.683973
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.4'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.5'

    str_2 = '1.2'
    str_3 = bump_version(str_2)
    assert str_3 == '1.3'

    str_4 = '1'
    str_5 = bump_version(str_4)
    assert str_5 == '2'

    str_0 = '1.2.4'
    str_6 = bump_version(str_0, pre_release='a')
    assert str_6 == '1.2.4a0'

    str_7 = bump_version(str_6, pre_release='a')
    assert str_7 == '1.2.4a1'

    str_

# Generated at 2022-06-25 17:38:45.521505
# Unit test for function bump_version

# Generated at 2022-06-25 17:38:55.976801
# Unit test for function bump_version
def test_bump_version():
    str_0 = "4.4.4"
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_0, 0)
    str_3 = bump_version(str_0, 1)
    str_4 = bump_version(str_0, 2)
    str_5 = bump_version(str_0, -1)
    str_6 = bump_version(str_0, -2)
    str_7 = bump_version(str_0, -3)
    str_8 = bump_version(str_0, 2, 'alpha')
    str_9 = bump_version(str_0, 2, 'beta')
    str_10 = bump_version(str_0, 1, 'alpha')

# Generated at 2022-06-25 17:39:02.905465
# Unit test for function bump_version
def test_bump_version():
    """Unit test for the function ``bump_version``."""
    import sys
    import os
    import unittest

    try:
        # If running from the project directory, prefer the local version
        sys.path.insert(0, os.path.abspath(os.path.join(
            os.path.dirname(__file__),
            os.pardir,
            os.pardir
        )))
    except NameError:
        pass

    from flutils import packages
    from flutils.packages import (
        bump_version
    )
    from flutils.packages import _each_version_part
    from flutils.packages import _build_version_info
    from flutils.packages import _build_version_bump_type
    from distutils.version import StrictVersion
    from typing import List

# Generated at 2022-06-25 17:39:14.822887
# Unit test for function bump_version
def test_bump_version():
    import unittest
    from unittest import mock

    class DummyNamespace(NamedTuple):
        version: str
        position: int
        pre_release: str


# Generated at 2022-06-25 17:39:27.124520
# Unit test for function bump_version
def test_bump_version():
    version_tuple_0 = ('1.2.4', {
        None: '1.2.5',
        'a': '1.2.4a0',
        'b': '1.2.4b0',
        0: '2.0',
        1: '1.3',
        2: '1.2.5'
    })
    version_tuple_1 = ('1.2.4a0', {
        None: '1.2.4',
        'a': '1.2.4a1',
        'b': '1.2.4b0',
        0: '2.0',
        1: '1.2a1',
        2: '1.2.5'
    })

# Generated at 2022-06-25 17:39:41.690662
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test function bump_version.
    """
    # TODO: Write unit test
    # test_case_0()
    pass


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:42.772135
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:39:53.109883
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:01.514262
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:14.730440
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function: `bump_version`."""

    get_0 = bump_version('1.2.2')
    assert get_0 == '1.2.3'

    get_1 = bump_version('1.2.3', position=1)
    assert get_1 == '1.3'

    get_2 = bump_version('1.3.4', position=0)
    assert get_2 == '2.0'

    get_3 = bump_version('1.2.3', pre_release='a')
    assert get_3 == '1.2.4a0'

    get_4 = bump_version('1.2.4a0', pre_release='a')
    assert get_4 == '1.2.4a1'


# Generated at 2022-06-25 17:40:15.855539
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:40:23.750335
# Unit test for function bump_version

# Generated at 2022-06-25 17:40:35.998270
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.4'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.5'
    str_0 = '1.2.4'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_0 = '1.2.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_0 = '1.2.4'
    str_1 = bump_version(str_0, prerelease='a')
    assert str_1 == '1.2.4a0'
    str_0 = '1.2.4a0'

# Generated at 2022-06-25 17:40:48.377097
# Unit test for function bump_version
def test_bump_version():
    """
    Test bump_version function.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    from flutils.testing import run_tests


# Generated at 2022-06-25 17:40:54.373132
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``.

    This function is intended to be run from the command line as part of
    the ``flutils_testing_utility``, it is not imported into the package.

    """