

# Generated at 2022-06-25 17:31:46.358671
# Unit test for function bump_version
def test_bump_version():
    print('Running %s...' % __file__)
    # noinspection PyBroadException

# Generated at 2022-06-25 17:31:55.486736
# Unit test for function bump_version
def test_bump_version():
    # Test case-0
    ver_info_0 = _build_version_info('1.1')
    try:
        _build_version_bump_position(-4)
        raise Exception()
    except ValueError:
        pass
    try:
        _build_version_bump_position(2)
        raise Exception()
    except ValueError:
        pass
    try:
        _build_version_bump_position(it)
        raise Exception()
    except TypeError:
        pass
    try:
        _build_version_bump_position(it())
        raise Exception()
    except TypeError:
        pass
    try:
        _build_version_bump_type(0, 'a')
        raise Exception()
    except ValueError:
        pass

# Generated at 2022-06-25 17:32:05.213988
# Unit test for function bump_version
def test_bump_version():
    """Test :func:`bump_version` function."""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump

# Generated at 2022-06-25 17:32:17.579475
# Unit test for function bump_version
def test_bump_version():
    # These tests are very basic.  They are here to help prevent
    # accidental breakage.
    #
    # Note:  The tests below are not exhaustive.

    # Test bad arguments
    from pytest import raises

    args_0 = ('0.3', None)
    args_1 = ('0.3', )
    args_2 = ('0.3', 'z')
    args_3 = ('0.3', '1')
    args_4 = ('0.3.0', 'a')
    args_5 = ('0.3.0', '1')
    args_6 = ('1.2.3', '2')
    args_7 = ('1.2.3', 'a')
    args_8 = ('1.2.3', 'alpha')

# Generated at 2022-06-25 17:32:26.614588
# Unit test for function bump_version

# Generated at 2022-06-25 17:32:38.289742
# Unit test for function bump_version
def test_bump_version():
    version = '0.4.0'
    for position in range(-3, 4):
        for pre_release in ('a', 'alpha', 'b', 'beta', None):
            for i in range(0, 3):
                try:
                    new_ver = bump_version(
                        version, position, pre_release
                    )
                    new_ver_obj = StrictVersion(new_ver)
                    assert new_ver_obj == new_ver
                    # print('%r %r %r %r' % (version, position, pre_release, i))
                except Exception:
                    # print('%r %r %r %r' % (version, position, pre_release, i))
                    raise


if __name__ == '__main__':
    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:32:48.213170
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:01.772693
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    # noinspection PyUnresolvedReferences
    assert bump_version(version) == '1.2.4'
    assert bump_version(version, pre_release='a') == '1.2.4a0'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=1, pre_release='a') == '1.3a0'
    assert bump_version(version, position=0, pre_release='a') == '2.0'
    version = '1.2.4b0'
    # noinspection PyUnresolvedReferences
    assert bump_version(version) == '1.2.4'

# Generated at 2022-06-25 17:33:07.826325
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:17.316419
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.3'
    new_version = bump_version(version)
    assert new_version == '1.2.4'

    new_version = bump_version(version, position=1)
    assert new_version == '1.3'

    new_version = bump_version(version, position=0)
    assert new_version == '2.0'

    new_version = bump_version(version, pre_release='a')
    assert new_version == '1.2.4a0'

    new_version = bump_version(new_version, pre_release='a')
    assert new_version == '1.2.4a1'

    new_version = bump_version(new_version, pre_release='b')
    assert new_version == '1.2.4b0'



# Generated at 2022-06-25 17:33:49.141377
# Unit test for function bump_version
def test_bump_version():
    version_0 = bump_version('1.2.2')
    version_1 = bump_version('1.2.3', position=1)
    version_2 = bump_version('1.3.4', position=0)
    version_3 = bump_version('1.2.3', prerelease='a')
    version_4 = bump_version('1.2.4a0', pre_release='a')
    version_5 = bump_version('1.2.4a1', pre_release='b')
    version_6 = bump_version('1.2.4a1')
    version_7 = bump_version('1.2.4b0')
    version_8 = bump_version('2.1.3', position=1, pre_release='a')

# Generated at 2022-06-25 17:34:01.554128
# Unit test for function bump_version
def test_bump_version():
    import unittest

    class TestCase1(unittest.TestCase):
        """Test the bumping of a version number string.
        """
        def __init__(self, *args):
            super().__init__(*args)
            self.version = None

        def runTest(self):
            error_msg = (
                "bump_version({!r}, {!r}, {!r}) returned: {!r}; "
                "expected: {!r}."
            )

# Generated at 2022-06-25 17:34:10.978303
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:16.886867
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:28.853759
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnusedLocal
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from flutils.packages import bump_version as func
    from flutils.packages import bump_version as func_inner
    from flutils.packages import bump_version as func_inner_inner
    from flutils.packages import bump_version as func_inner_inner_inner

    from flutils._types import AnyStr
    from flutils._types import AnyStrs
    from flutils._types import AnyInt

    # This is to test:
    #   1. That the function is callable.
    #   2. Excepted Types
    #   3. Expected return value

    # AnyStr
    assert isinstance(func('1.2.3'), AnyStr)



# Generated at 2022-06-25 17:34:36.396852
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:46.990420
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'  # type: ignore
    assert bump_version('1.2.3', position=1) == '1.3'  # type: ignore
    assert bump_version('1.3.4', position=0) == '2.0'  # type: ignore
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'  # type: ignore
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'  # type: ignore
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'  # type: ignore

# Generated at 2022-06-25 17:34:58.808685
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""
    output = bump_version('1.2.2')
    assert output == '1.2.3'
    output = bump_version('1.2.3', position=1)
    assert output == '1.3'
    output = bump_version('1.3.4', position=0)
    assert output == '2.0'
    output = bump_version('1.2.3', prerelease='a')
    assert output == '1.2.4a0'
    output = bump_version('1.2.4a0', pre_release='a')
    assert output == '1.2.4a1'
    output = bump_version('1.2.4a1', pre_release='b')
    assert output == '1.2.4b0'


# Generated at 2022-06-25 17:35:06.854288
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version"""
    # noinspection PyUnresolvedReferences
    import flutils.packages


# Generated at 2022-06-25 17:35:14.062098
# Unit test for function bump_version
def test_bump_version():
    version_0 = '1.2.2'
    result = bump_version(version_0)
    assert result == '1.2.3'
    #
    version_1 = '1.2.3'
    result = bump_version(version_1, position=1)
    assert result == '1.3'
    #
    version_2 = '1.3.4'
    result = bump_version(version_2, position=0)
    assert result == '2.0'
    #
    version_3 = '1.2.3'
    result = bump_version(version_3, prerelease='a')
    assert result == '1.2.4a0'
    #
    version_4 = '1.2.4a0'

# Generated at 2022-06-25 17:35:36.421997
# Unit test for function bump_version
def test_bump_version():
    """Unit tests for function bump_version."""

    # test 0
    str_0 = '1.3.4'
    str_1 = '1.3.5'
    val_0 = bump_version(str_0)
    assert val_0 == str_1

    # test 1
    str_0 = '0.4.4'
    str_1 = '0.4.5'
    val_0 = bump_version(str_0)
    assert val_0 == str_1

    # test 2
    str_0 = '1.3.4'
    str_1 = '1.3.5'
    position = 2
    val_0 = bump_version(str_0, position)
    assert val_0 == str_1

    # test 3

# Generated at 2022-06-25 17:35:42.627037
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    # Try a normal 'patch' bump.
    try:
        test_case_0()
    except Exception:
        raise Exception(
            "Test case 0 failed.\nCould not bump a version number, with a "
            "pre-release, as a regular version number."
        )


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:35:53.073588
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'

    assert bump_version('1.2.3', position=1) == '1.3'

    assert bump_version('1.3.4', position=0) == '2.0'

    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'

    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

    assert bump_version('1.2.4a1') == '1.2.4'


# Generated at 2022-06-25 17:35:55.789806
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:36:05.599569
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.3.4'
    str_1 = bump_version(str_0)
    assert str_1 == '1.3.5'
    
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.3.4a0'
    str_1 = bump_version(str_1, pre_release='a')
    assert str_1 == '1.3.4a1'
    str_1 = bump_version(str_1, pre_release='b')
    assert str_

# Generated at 2022-06-25 17:36:17.086450
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('0.3.2', position=2, pre_release='alpha') == '0.3.3a0'
    assert bump_version('0.3.4', position=2, pre_release='alpha') == '0.3.5a0'
    assert bump_version('0.3.3a1', position=2, pre_release='alpha') == '0.3.3a2'
    assert bump_version('1.0.0', position=0, pre_release='alpha') == '2.0.0'
    assert bump_version('1.1.0', position=0, pre_release='alpha') == '2.0.0'
    assert bump_version('1.0.1', position=0, pre_release='alpha') == '2.0.0'
    assert bump_version

# Generated at 2022-06-25 17:36:28.909881
# Unit test for function bump_version
def test_bump_version():
    assert(bump_version('1.2.2') == '1.2.3')
    assert(bump_version('1.2.3', position=1) == '1.3')
    assert(bump_version('1.3.4', position=0) == '2.0')
    assert(bump_version('1.2.3', prerelease='a') == '1.2.4a0')
    assert(bump_version('1.2.4a0', pre_release='a') == '1.2.4a1')
    assert(bump_version('1.2.4a1', pre_release='b') == '1.2.4b0')
    assert(bump_version('1.2.4a1') == '1.2.4')

# Generated at 2022-06-25 17:36:40.014625
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:51.865597
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:02.171532
# Unit test for function bump_version
def test_bump_version():
    # initial version
    init_version = '0.0.0'
    # go to next version number at position 2
    assert (bump_version(init_version) == '0.0.1')
    # go to next version number at position 1
    assert (bump_version(init_version, position=1) == '0.1')
    # go to next version number at position 0
    assert (bump_version(init_version, position=0) == '1.0')
    # go to next version number at position 2 and add prerelease identifier
    assert (bump_version(init_version, pre_release='a')
            == '0.0.1a0')
    # go to next version number at position 2 and increase prerelease
    # identifier

# Generated at 2022-06-25 17:37:18.975107
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:28.706417
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:40.571189
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:37:50.598116
# Unit test for function bump_version
def test_bump_version():
    # Case 1: Without pre-release
    str_0 = '1.3.4'
    rtn = bump_version(str_0)
    assert rtn == '1.3.5'
    # Case 2: Bump minor
    rtn = bump_version(str_0, position=1)
    assert rtn == '1.4'
    # Case 3: Bump major
    rtn = bump_version(str_0, position=0)
    assert rtn == '2.0'
    # Case 4: Bump pre-release alpha
    str_0 = '1.2.3'
    rtn = bump_version(str_0, pre_release='a')
    assert rtn == '1.2.4a0'
    # Case 4-2: Bump pre-release alpha
    str_

# Generated at 2022-06-25 17:38:03.407455
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version"""

    str_0 = '1.3.4'
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_1, position=1)
    str_3 = bump_version(str_2, position=0)
    str_4 = bump_version(str_3, pre_release='a')
    str_5 = bump_version(str_4, pre_release='a')
    str_6 = bump_version(str_5, pre_release='b')
    str_7 = bump_version(str_6, position=2)
    str_8 = bump_version(str_7)
    str_9 = bump_version(str_8)
    str_10 = bump_version(str_9)
    str_11 = bump_

# Generated at 2022-06-25 17:38:14.269491
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:26.160724
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.3.4'
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_0, 1)
    str_3 = bump_version(str_0, 0)
    str_4 = bump_version(str_0, pre_release='a')
    str_5 = bump_version(str_4, pre_release='a')
    str_6 = bump_version(str_4, pre_release='b')
    str_7 = bump_version(str_4)
    str_8 = bump_version(str_6)
    str_9 = bump_version('1.2.3', position=2, pre_release='a')
    str_10 = bump_version('1.2b0', position=2)
    return True

# Generated at 2022-06-25 17:38:34.740900
# Unit test for function bump_version
def test_bump_version():
    from flutils.check import group_truth_values

    def test_func(version: str, position: int,
                  pre_release: Union[str, None], expect: str,
                  exp_err_type: Any) -> Tuple[bool, Optional[str]]:
        try:
            out = bump_version(version, position=position,
                               pre_release=pre_release)
        except BaseException as err:
            if isinstance(err, exp_err_type):
                if exp_err_type == ValueError:
                    return True, None
                return True, str(err)
            return False, str(err)
        if out == expect:
            return True, None
        return False, "Expected: %r. Given: %r." % (expect, out)


# Generated at 2022-06-25 17:38:44.776925
# Unit test for function bump_version
def test_bump_version():
    # Testing built-in type: str
    str_0 = '0.2.2'
    assert bump_version(str_0) == '0.2.3'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0'
    str_0 = '1.2.4a0'
    str_1 = bump_

# Generated at 2022-06-25 17:38:55.452278
# Unit test for function bump_version
def test_bump_version():
    # Normal
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version('1.2.4b0')