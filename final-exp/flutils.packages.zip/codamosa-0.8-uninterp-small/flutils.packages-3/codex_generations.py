

# Generated at 2022-06-25 17:31:47.290365
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.5'
    assert bump_version(version) == '1.2.6'
    assert bump_version(version, position=1) == '1.3'
    assert bump_version(version, position=0) == '2.0'
    assert bump_version(version, position=1, pre_release='a') == '1.3a0'
    assert bump_version(version, position=2, pre_release='a') == '1.2.6a0'
    assert bump_version(version, position=2, pre_release='b') == '1.2.6b0'

    version = '1.2.5b0'
    assert bump_version(version) == '1.2.6'
    assert bump_version(version, position=1) == '1.3'

# Generated at 2022-06-25 17:31:57.595867
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Test the 'bump_version' function."""
    # pylint: disable=R0914,R0912
    from flutils.packages import bump_version

    # Test of valid version numbers
    bump_version('0.0.1')
    bump_version('0.0.1a1')
    bump_version('0.0.1a1', position=1)
    bump_version('1.2a1')
    bump_version('1.2a1', position=1)
    bump_version('1.2a1', position=0)
    bump_version('1.2b1')
    bump_version('1.2b1', position=1)
    bump_version('1.2b1', position=0)

# Generated at 2022-06-25 17:32:07.102976
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function ``bump_version``"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-25 17:32:19.454887
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='a') == '1.2.4a2'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:27.959177
# Unit test for function bump_version
def test_bump_version():
    """Test bump_version()."""
    from flutils.pytest_helpers import runtests

    def test(test_input: Tuple[str, int, str], expected: str):
        """Test bumping the version number."""
        version, position, prerelease = test_input
        out = bump_version(version, position, prerelease)
        assert out == expected

    #
    # Examples:
    #
    # >>> from flutils.packages import bump_version
    # >>> bump_version('1.2.2')
    # '1.2.3'
    # >>> bump_version('1.2.3', position=1)
    # '1.3'
    # >>> bump_version('1.3.4', position=0)
    # '2.0'
    # >>> bump_version('1.

# Generated at 2022-06-25 17:32:35.346444
# Unit test for function bump_version
def test_bump_version():
    version = bump_version('1.2.2')
    version = bump_version('1.2.3', position=1)
    version = bump_version('1.3.4', position=0)
    version = bump_version('1.2.3', prerelease='a')
    version = bump_version('1.2.4a0', pre_release='a')
    version = bump_version('1.2.4a1', pre_release='b')
    version = bump_version('1.2.4a1')
    version = bump_version('1.2.4b0')
    version = bump_version('2.1.3', position=1, pre_release='a')
    version = bump_version('1.2b0', position=2)

# Generated at 2022-06-25 17:32:43.208285
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    version = '1.2.2'
    out = bump_version(version)
    if out != '1.2.3':
        raise AssertionError(
            "The resulting version should have been '1.2.3', but was: %r." % out
        )
    out = bump_version(version, position=1)
    if out != '1.3':
        raise AssertionError(
            "The resulting version should have been '1.3', but was: %r." % out
        )
    out = bump_version(version, position=0)
    if out != '2.0':
        raise AssertionError(
            "The resulting version should have been '2.0', but was: %r." % out
        )
    out = bump_version

# Generated at 2022-06-25 17:32:51.383303
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:03.874265
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    # noinspection PyUnusedLocal
    version: str = ''
    position: int = 0
    pre_release: str = ''

    version = '1.2.2'
    assert bump_version(version) == '1.2.3'

    version = '1.2.3'
    position = 1
    assert bump_version(version, position) == '1.3'

    version = '1.2.3'
    pre_release = 'a'
    assert bump_version(version, pre_release=pre_release) == '1.2.4a0'

    version = '1.2.4a0'
    pre_release = 'a'

# Generated at 2022-06-25 17:33:16.075230
# Unit test for function bump_version
def test_bump_version():
    import sys

    import flutils

    default_ver = '%s.%s.%s' % (
        flutils.__major_version__,
        flutils.__minor_version__,
        flutils.__patch_version__,
    )
    sys.stdout.write("Testing bump_version\n")
    sys.stdout.write("!!DEFAULT VERSION IS: %s!!\n" % default_ver)
    sys.stdout.write("\n")
    sys.stdout.write("# - #\n")
    for i in range(3):
        sys.stdout.write("# %s - #\n" % i)

# Generated at 2022-06-25 17:33:33.293117
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    bump_version('1.2.0b0')

    bump_version(version='1.2.3', position=2)

    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.2.0', 1) == '1.3'
    assert bump_version('1.2.0', 0) == '2.0'
    assert bump_version('1.2.0', pre_release='a') == '1.2.1a0'
    assert bump_version('1.2.0a0', pre_release='a') == '1.2.1a1'
    assert bump_version('1.2.0a1', pre_release='b') == '1.2.1b0'

# Generated at 2022-06-25 17:33:40.881738
# Unit test for function bump_version
def test_bump_version():
    # (1) Test: bump_version('0.9.9', position=0)
    assert bump_version('0.9.9', position=0) == '1.0'
    # (2) Test: bump_version('1.2.4a1', pre_release='a')
    assert bump_version('1.2.4a1', pre_release='a') == '1.2.4a2'
    # (3) Test: bump_version('1.2.3', prerelease='a')
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

# Generated at 2022-06-25 17:33:50.149140
# Unit test for function bump_version
def test_bump_version():

    # Tests for the function _build_version_bump_position
    with pytest.raises(ValueError):
        _build_version_bump_position(-4)
    with pytest.raises(ValueError):
        _build_version_bump_position(3)
    assert _build_version_bump_position(-3) == 0
    assert _build_version_bump_position(-2) == 1
    assert _build_version_bump_position(-1) == 2
    assert _build_version_bump_position(0) == 0
    assert _build_version_bump_position(1) == 1
    assert _build_version_bump_position(2) == 2

    # Tests for the function _build_version_bump_type

# Generated at 2022-06-25 17:34:02.459065
# Unit test for function bump_version
def test_bump_version():
    # Test 0
    v = bump_version('1.2.2')
    assert v == '1.2.3'
    v = bump_version('1.2.3', position=1)
    assert v == '1.3'
    v = bump_version('1.3.4', position=0)
    assert v == '2.0'
    v = bump_version('1.2.3', prerelease='a')
    assert v == '1.2.4a0'
    v = bump_version('1.2.4a0', pre_release='a')
    assert v == '1.2.4a1'
    v = bump_version('1.2.4a1', pre_release='b')
    assert v == '1.2.4b0'

# Generated at 2022-06-25 17:34:11.736398
# Unit test for function bump_version
def test_bump_version():
    """Test function bump_version.

    """
    assert bump_version('1.2.2') == '1.2.3'

    assert bump_version('1.2.3', position=1) == '1.3'

    assert bump_version('1.3.4', position=0) == '2.0'

    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

    assert bump_version('1.2.4a1') == '1.2.4'


# Generated at 2022-06-25 17:34:20.688951
# Unit test for function bump_version
def test_bump_version():
    def chk(inp, exp):
        a = bump_version(inp)
        assert a == exp

    chk('1.2.2', '1.2.3')
    chk('1.2.3', '1.2.4')
    chk('1.2.3', '1.2.4')
    chk('1.2.3', '1.2.4')
    chk('1.2.3', '1.2.4')

    chk('1.2.3', '1.2.4')
    chk('1.2.3a0', '1.2.3a1')
    chk('1.2.3a0', '1.2.3a1')

# Generated at 2022-06-25 17:34:31.751844
# Unit test for function bump_version
def test_bump_version():
    from nose.tools import assert_equals
    from nose.tools import assert_raises

    # Test case for exception 1
    raise_error = False
    try:
        bump_version('1.2.a.4')
    except ValueError:
        raise_error = True
    assert_equals(raise_error, True)

    # Test case for exception 2
    raise_error = False
    try:
        bump_version('1.2.1', position=3)
    except ValueError:
        raise_error = True
    assert_equals(raise_error, True)

    # Test case for exception 3
    raise_error = False
    try:
        bump_version('1.2.1', pre_release='z')
    except ValueError:
        raise_error = True

# Generated at 2022-06-25 17:34:43.636560
# Unit test for function bump_version
def test_bump_version():
    # Arrange
    version_0 = '1.2.3'
    version_1 = '1.2'
    version_2 = '1'
    version_3 = '0'
    version_4 = '1.2.3a0'
    version_5 = '1.2.3a1'
    version_6 = '1.2.3a2'
    version_7 = '1.2.3b0'
    version_8 = '1.2.3b1'
    version_9 = '1.2.3b2'
    version_10 = '1.2.3a1b0'
    version_11 = '1.4.4a2b1'
    version_12 = '1.4.4b0'

# Generated at 2022-06-25 17:34:56.931006
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:06.049945
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:58.498917
# Unit test for function bump_version
def test_bump_version():
    # Major part
    assert bump_version('1.2.3') == '1.2.3'
    assert bump_version('1.2.3', position=0) == '2.0'
    assert bump_version('1.2.3', position=-1) == '2.0'

    # Minor part
    assert bump_version('1.2.4', position=1) == '1.3'
    assert bump_version('1.2.4', position=-2) == '1.3'

    # Patch part
    assert bump_version('1.3.4', position=2) == '1.3.5'
    assert bump_version('1.3.4', position=-3) == '1.3.5'

    # Alpha part

# Generated at 2022-06-25 17:36:00.900176
# Unit test for function bump_version
def test_bump_version():
    # Test 0:
    # Test 1:
    # Test 2:
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:36:08.736565
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:17.786408
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.2'
    # Test basic version update
    assert bump_version(version) == '1.2.3'
    # Test minor version update
    version += 'a1'
    assert bump_version(version) == '1.2.3a2'
    # Test parameter position
    assert bump_version(version, position=1) == '1.3'
    # Test parameter pre_release
    assert bump_version(version, pre_release='b') == '1.2.3b0'
    # Test parameter position and pre_release
    assert bump_version(version, position=1, pre_release='a') == '1.3a0'
    # Test invalid parameter: pre_release

# Generated at 2022-06-25 17:36:29.886107
# Unit test for function bump_version
def test_bump_version():
    # Major to Major
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.0') == '1.2.1'
    assert bump_version('1.0.0') == '1.0.1'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.3', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=0) == '2.0'

# Generated at 2022-06-25 17:36:40.326808
# Unit test for function bump_version
def test_bump_version():
    print('> test_bump_version()')
    print(bump_version('1.2.2'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))
   

# Generated at 2022-06-25 17:36:51.908320
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:59.390685
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    def check_bump_version(version: str, pos: int, pre: Optional[str],
                           exp: str):
        """Check the bump_version function."""
        bump_version(version, pos, pre)

    # pylint: disable=E8103
    #         E8103: 8 arguments (expected 5)
    check_bump_version('1.2.3', pos=0, pre=None, exp='2.0')



# Generated at 2022-06-25 17:37:09.889415
# Unit test for function bump_version
def test_bump_version():
    """Test function ``bump_version``.
    """
    def _test_case(version_in, position, pre_release, version_out):
        res = bump_version(version_in, position, pre_release)
        if res != version_out:
            msg = '%r != %r' % (res, version_out)
            raise AssertionError(msg)

    # Test all version bumping scenarios
    _test_case('1.2.1', -1, None, '1.2.2')
    _test_case('1.2.2', -1, None, '1.2.3')
    _test_case('1.2.1', -2, None, '1.3')
    _test_case('1.2.1', -3, None, '2.0')
   

# Generated at 2022-06-25 17:37:20.232690
# Unit test for function bump_version
def test_bump_version():
    import unittest


# Generated at 2022-06-25 17:37:40.792480
# Unit test for function bump_version
def test_bump_version():
    # Test 1
    assert bump_version('1.2.2') == '1.2.3'
    # Test 2
    assert bump_version('1.2.3', position=1) == '1.3'
    # Test 3
    assert bump_version('1.3.4', position=0) == '2.0'
    # Test 4
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    # Test 5
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    # Test 6
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    # Test 7

# Generated at 2022-06-25 17:37:50.810528
# Unit test for function bump_version
def test_bump_version():
    # Test case 1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    str_2 = '1.2.4'
    assert str_1 == str_2

    # Test case 2
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 1)
    str_2 = '1.3'
    assert str_1 == str_2

    # Test case 3
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, 0)
    str_2 = '2.0'
    assert str_1 == str_2

    # Test case 4
    str_0 = '1.2.3'

# Generated at 2022-06-25 17:38:03.718383
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    func = bump_version

    version = '1'
    result = func(version, 0)
    version = '1.2'
    result = func(version, 0)
    version = '1.2'
    result = func(version, 1)
    version = '1.2'
    result = func(version, 2)

    version = '1'
    result = func(version, 0, pre_release='a')
    version = '1.2'
    result = func(version, 0, pre_release='a')
    version = '1.2'
    result = func(version, 1, pre_release='a')
    version = '1.2'
    result = func(version, 2, pre_release='a')

    # version = '1.2'

# Generated at 2022-06-25 17:38:05.503067
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


# Generated at 2022-06-25 17:38:15.587618
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:27.595395
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.3'))
    print(bump_version('1.2.3', position=1))
    print(bump_version('1.3.4', position=0))
    print(bump_version('1.2.3', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-25 17:38:29.261193
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:38:36.630120
# Unit test for function bump_version
def test_bump_version():
    """Unit test for function bump_version."""

    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 2)
    assert str_1 == '1.2.4'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 1)
    assert str_1 == '1.3'

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 0)
    assert str_1 == '2.0'

    str_0 = '1.2.3'
    str_1 = bump_version

# Generated at 2022-06-25 17:38:45.469908
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:55.977605
# Unit test for function bump_version
def test_bump_version():
    v = '1.2.3'
    v = bump_version(v)
    assert v == '1.2.4'
    v = bump_version(v, 0)
    assert v == '2.0'
    v = bump_version(v)
    assert v == '2.0'
    v = bump_version(v, 1)
    assert v == '2.1'
    v = bump_version(v, 2)
    assert v == '2.1.0'
    v = bump_version(v)
    assert v == '2.1.1'
    v = bump_version(v, 3)
    assert v == '2.2.0'
    v = bump_version(v, 4, 'a')
    assert v == '2.2.0a0'

# Generated at 2022-06-25 17:39:14.710468
# Unit test for function bump_version
def test_bump_version():
    try:
        test_case_0()
    except Exception as e:
        print("Exception: %s" % str(e))

# Generated at 2022-06-25 17:39:26.978773
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """
    err = None

# Generated at 2022-06-25 17:39:34.942565
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:39:46.545011
# Unit test for function bump_version
def test_bump_version():
    assert '1.0.1' == bump_version('1.0.0')
    assert '1.1' == bump_version('1.0', position=1)
    assert '2.0' == bump_version('1.0', position=0)
    assert '1.0.4a0' == bump_version('1.0.3', pre_release='a')
    assert '1.0.4a1' == bump_version('1.0.4a0', pre_release='a')
    assert '1.0.4b0' == bump_version('1.0.4a1', pre_release='b')
    assert '1.0.4' == bump_version('1.0.4a1')
    assert '1.0.4' == bump_version('1.0.4b0')

# Generated at 2022-06-25 17:39:51.695637
# Unit test for function bump_version
def test_bump_version():
    # Here is a simple test for the bump_version function,
    # but I want to add a more complete coverage.
    ver = '1.0.0'
    for i in range(3):
        ver = bump_version(ver)
    assert ver == '1.0.3'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:40:00.545801
# Unit test for function bump_version
def test_bump_version():
    ver_str = '0.0.1'
    assert bump_version(ver_str) == '0.0.2'
    assert bump_version(ver_str, position=1) == '0.1'
    assert bump_version(ver_str, position=0) == '1.0'
    assert bump_version(ver_str, pre_release='a') == '0.0.1a0'
    assert bump_version(ver_str, pre_release='alpha') == '0.0.1a0'
    ver_str = '0.0.1a0'
    assert bump_version(ver_str, pre_release='a') == '0.0.1a1'

# Generated at 2022-06-25 17:40:13.476820
# Unit test for function bump_version
def test_bump_version():
    def get_sut():
        from flutils.packages import bump_version
        return bump_version

    def set_up_vars_0():
        from flutils.packages import bump_version
        ver_0 = '1.2.2'
        ver_1 = bump_version(ver_0)
        ver_1_expected = '1.2.3'
        ver_2 = bump_version(ver_0, 1)
        ver_2_expected = '1.3'
        ver_3 = bump_version(ver_0, 0)
        ver_3_expected = '2.0'
        ver_4 = bump_version(ver_0, 2, 'a')
        ver_4_expected = '1.2.3a0'

# Generated at 2022-06-25 17:40:22.198200
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:29.523986
# Unit test for function bump_version
def test_bump_version():
    # Unit test for function bump_version
    from flutils.packages import bump_version

    bump_version('1.2.2')
    bump_version('1.2.3', position=1)
    bump_version('1.3.4', position=0)
    bump_version('1.2.3', prerelease='a')
    bump_version('1.2.4a0', pre_release='a')
    bump_version('1.2.4a1', pre_release='b')
    bump_version('1.2.4a1')
    bump_version('1.2.4b0')
    bump_version('2.1.3', position=1, pre_release='a')
    bump_version('1.2b0', position=2)

# Generated at 2022-06-25 17:40:41.313583
# Unit test for function bump_version
def test_bump_version():
    """Test function 'bump_version' in module 'flutils.packages'.

    This is a private function.  Tests are not made available.
    """
    # flake8: noqa
    import pytest  # pylint: disable=E0401

    # NOTE: This test case will likely fail as changes are made
    # to the bump_version function.

# Generated at 2022-06-25 17:41:14.537231
# Unit test for function bump_version
def test_bump_version():
    # Example 0
    str_0 = '1.2.2'
    str_1 = bump_version(str_0, str_0)
    assert str_1 == '1.2.3', 'Expected: %r. Found: %r' % ('1.2.3', str_1)

    # Example 1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, str_0)
    assert str_1 == '1.3', 'Expected: %r. Found: %r' % ('1.3', str_1)

    # Example 2
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, str_0)