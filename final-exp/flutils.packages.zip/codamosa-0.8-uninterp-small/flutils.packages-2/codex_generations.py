

# Generated at 2022-06-25 17:31:43.635086
# Unit test for function bump_version

# Generated at 2022-06-25 17:31:51.719444
# Unit test for function bump_version
def test_bump_version():

    def _check_bump_version(version_in, version_out, position, pre_release):
        version_bumped = bump_version(version_in, position, pre_release)

        assert version_bumped == version_out

    # Run test case
    _check_bump_version('1.2.2', '1.2.3', 2, None)
    _check_bump_version('1.2.3', '1.3', 1, None)
    _check_bump_version('1.3.4', '2.0', 0, None)
    _check_bump_version('1.2.3', '1.2.4a0', 2, 'a')

# Generated at 2022-06-25 17:32:01.583374
# Unit test for function bump_version
def test_bump_version():
    import unittest
    import sys
    import os

    if sys.version_info < (3, 4):
        # support for type hinting, part of Python 3.5+
        sys.exit("The current version of Python does not support type hints.")

    if sys.version_info < (3, 6):
        # TestCase class no longer inherits from object (new-style class)
        # in Python 3.6+
        sys.exit("The current version of Python does not support f-strings.")

    class Test_bump_version(unittest.TestCase):

        def test_0(self):

            version_info_0 = _VersionInfo()

        def test_1(self):
            def _format_input(*args):
                input_lines = [f'    bump_version({", ".join(args)})']


# Generated at 2022-06-25 17:32:09.470241
# Unit test for function bump_version
def test_bump_version():
    # noinspection SpellCheckingInspection
    valid_version_number_strings = [
        '1.0.0',
        '1.0',
        '0.5.5',
        '0.5',
        '1.5.5a0',
        '1.5.5b0',
    ]

    invalid_version_number_strings = [
        '1.0.0a',
        '1.0.0a5',
        '1.0.0b',
        '1.0.0b5',
        '1.0.0.',
        '1.0.0.5',
        '1.0.0..',
        '1.0..0',
        '1.0....',
    ]


# Generated at 2022-06-25 17:32:21.038172
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:32:33.937128
# Unit test for function bump_version
def test_bump_version():
    # pylint: disable=C0103
    def _f(v, p=2, pr=None):
        return bump_version(v, position=p, pre_release=pr)
    # pylint: enable=C0103
    from flutils.packages import get_next_version_number
    assert _f('1.2.2') == get_next_version_number('1.2.1')
    assert _f('1.2.3', position=1) == get_next_version_number('1.2.3', part=1)
    assert _f('1.3.4', position=0) == get_next_version_number('1.3.4', part=0)

# Generated at 2022-06-25 17:32:42.415590
# Unit test for function bump_version
def test_bump_version():
    # Test '0.1.0'
    ver = '0.1.0'
    assert bump_version(ver) == '0.1.1'
    assert bump_version(ver, position=1) == '0.2'
    assert bump_version(ver, position=0) == '1.0'
    assert bump_version(ver, pre_release='a') == '0.1.1a0'
    assert bump_version(ver, pre_release='b') == '0.1.1b0'
    assert bump_version('0.1.1a0') == '0.1.1a1'
    assert bump_version('0.1.1b0') == '0.1.1b1'

# Generated at 2022-06-25 17:32:50.915171
# Unit test for function bump_version
def test_bump_version():

    # Create a list of test cases
    tcs = []

    # Test Case 0 - 1
    test_case_0 = {
        'in': '0.0.0',
        'out': '0.0.1'
    }
    tcs.append(test_case_0)

    # Test Case 1 - 4
    test_case_1 = {
        'in': '0.0.1',
        'out': '0.0.2'
    }
    tcs.append(test_case_1)

    # Test Case 2 - 3
    test_case_2 = {
        'in': '0.0.2',
        'out': '0.0.3'
    }
    tcs.append(test_case_2)

    # Test Case 3 - 2
    test_case_

# Generated at 2022-06-25 17:33:03.424524
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:10.722034
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:36.423032
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = '1.2.1'
    str_2 = '1.2.3'
    str_3 = bump_version(str_2)
    int_0 = 0
    func_0 = bump_version
    str_4 = func_0(str_2)
    str_5 = '1.2.3'
    str_6 = str_4
    func_1 = bump_version
    str_7 = func_1(str_2, int_0)
    str_8 = '2.0'
    str_9 = str_7
    func_2 = bump_version
    str_10 = func_2(str_2, (int_0), '')
    str_11 = '2.0'
    str_12 = str

# Generated at 2022-06-25 17:33:47.159278
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)

# Generated at 2022-06-25 17:33:50.399947
# Unit test for function bump_version
def test_bump_version():
    """Check bump_version function."""
    str_0 = '1.2.2'
    str_1 = '1.2.1'
    str_2 = '1.2.3'
    str_3 = bump_version(str_2)
    int_0 = 0



# Generated at 2022-06-25 17:33:56.686419
# Unit test for function bump_version
def test_bump_version():
    """Tests for bump_version()."""
    ver_obj = StrictVersion('2.1.3')              # noqa
    pre_release: Optional[Tuple[str, int]] = None    # noqa
    pre_release = cast(Union[Tuple[str, int], None], pre_release)
    test_case_0()
    str_0 = bump_version('1.2.2')
    str_1 = bump_version('1.2.1', 1)
    str_2 = bump_version('1.3', 2)
    str_3 = bump_version('1.3', 2)
    str_4 = bump_version('1.2.4', pre_release='a')
    str_5 = bump_version('1.2.4a0', pre_release='b')
    str_

# Generated at 2022-06-25 17:34:06.903219
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:17.775055
# Unit test for function bump_version
def test_bump_version():
    import sys
    from difflib import unified_diff
    from io import StringIO
    from types import ModuleType
    from unittest import TestCase

    from flutils.packages import bump_version


# Generated at 2022-06-25 17:34:29.714108
# Unit test for function bump_version
def test_bump_version():
    str_0 = bump_version('1.2.2')
    str_1 = bump_version('1.2.2', position=1)
    str_2 = bump_version('1.2.2', position=-2)
    str_3 = bump_version('1.2.2', position=0)
    str_4 = bump_version('1.2.2', position=-1)
    str_5 = bump_version('1.2.2', pre_release='alpha')
    str_6 = bump_version('1.2.2', pre_release='a')
    str_7 = bump_version('1.2.2', pre_release='beta')
    str_8 = bump_version('1.2.2', pre_release='b')

# Generated at 2022-06-25 17:34:36.928318
# Unit test for function bump_version
def test_bump_version():  # noqa: D103
    """Unit test for function bump_version."""
    str_0 = '1.2.2'
    str_1 = '1.2.1'
    str_2 = '1.2.3'
    str_3 = bump_version(str_2)

    int_0 = 0

    str_4 = bump_version('1.3.4', position=0)
    str_5 = bump_version(
        '1.2.3',
        position=1,
        prerelease='a'
    )
    str_6 = bump_version('2.1.3', position=1, pre_release='a')

    str_7 = bump_version('1.2.4a0', pre_release='a')

# Generated at 2022-06-25 17:34:47.280230
# Unit test for function bump_version
def test_bump_version():
    # Testing version string with pre-release version
    test_version = '1.2.3a4'
    # Bumping major version
    assert bump_version(test_version, 0) == '2.0', \
        "Bumping major version incorrectly"

    # Bumping minor version
    assert bump_version(test_version, 1) == '1.3', \
        "Bumping minor version incorrectly"

    # Bumping patch version
    assert bump_version(test_version, 2) == '1.2.4', \
        "Bumping patch version incorrectly"

    # Bumping pre-release version
    assert bump_version(test_version, 2, 'a') == '1.2.3a5', \
        "Bumping prerelease version incorrectly"


# Generated at 2022-06-25 17:34:53.646597
# Unit test for function bump_version
def test_bump_version():
    """Blackbox test for bump_version."""
    str_0 = '1.2.2'
    str_1 = '1.2.1'
    str_2 = '1.2.3'
    str_3 = bump_version(str_2)

    int_0 = 0
    int_1 = 1

    assert str_0 == str_0
    assert str_1 == str_1
    assert str_2 == str_2
    assert str_3 == str_3
    assert int_0 == int_0
    assert int_1 == int_1

    assert not str_0 != str_0
    assert not str_1 != str_1
    assert not str_2 != str_2
    assert not str_3 != str_3
    assert not int_0 != int_0
    assert not int_

# Generated at 2022-06-25 17:35:15.110925
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'
    str_0 = '1.2.2'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'
    str_0 = '1.2.2'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'
    str_0 = '1.2.2'
    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0'
    str_0 = '1.2.4a0'
    str_1 = bump_version

# Generated at 2022-06-25 17:35:27.752519
# Unit test for function bump_version

# Generated at 2022-06-25 17:35:38.477057
# Unit test for function bump_version
def test_bump_version():
    # Test for bump_version(version, position=2)
    str_0 = '1.2.2'
    str_1 = '1.2.3'
    str_2 = bump_version(str_0)
    assert str_1 == str_2
    # Test for bump_version(version, position=1, pre_release='alpha')
    str_0 = '1.2.3'
    str_1 = '1.3a0'
    str_2 = bump_version(str_0, position=1, pre_release='alpha')
    assert str_1 == str_2
    # Test for bump_version(version, position=1, pre_release='beta')
    str_0 = '1.2.3'
    str_1 = '1.3b0'
    str_2 = bump

# Generated at 2022-06-25 17:35:50.243092
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:01.335471
# Unit test for function bump_version
def test_bump_version():  # pylint: disable=missing-docstring
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:09.126932
# Unit test for function bump_version
def test_bump_version():
    # Check if the function returns its only argument when called with no
    # arguments
    assert bump_version() == ''
    # Check if the function returns None when called with no arguments
    assert bump_version(None) is None
    # Check if any non-string argument raises a TypeError when given
    for arg in (with_metaclass, str, int, float, list, tuple, set, dict,
                object):
        try:
            bump_version(arg())
        except TypeError:
            pass
        else:
            assert False
    # Check if any non-string argument doesn't raise a TypeError when given
    for arg in (with_metaclass, str, int, float, list, tuple, set, dict):
        try:
            bump_version(arg())
        except TypeError:
            assert False

# Generated at 2022-06-25 17:36:11.374410
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:36:18.748898
# Unit test for function bump_version
def test_bump_version():
    # Test 0
    str_0 = '1.1.1'
    str_1 = bump_version(str_0)
    str_2 = '1.1.2'
    assert str_1 == str_2

    # Test 1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    str_2 = '1.3'
    assert str_1 == str_2

    # Test 2
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    str_2 = '1.2.4a0'
    assert str_1 == str_2

    # Test 3
    str_0 = '1.2.4a0'
    str_1

# Generated at 2022-06-25 17:36:26.550428
# Unit test for function bump_version
def test_bump_version():

    # Testing the version string: 1.2.3

    # Testing the position: 0
    str_0 = bump_version('1.2.3', position=0)
    assert str_0 == '2.0'

    # Testing the position: 1
    str_1 = bump_version('1.2.3', position=1)
    assert str_1 == '1.3'

    # Testing the position: 2
    str_2 = bump_version('1.2.3', position=2)
    assert str_2 == '1.2.4'

    # Testing the pre-release: a

    # Testing the pre-release: a
    str_3 = bump_version('1.2.3a0', pre_release='a')
    assert str_3 == '1.2.3a1'

    # Testing the

# Generated at 2022-06-25 17:36:38.535984
# Unit test for function bump_version
def test_bump_version():
    # Helper function to drive all test cases below.

    def _test_case(ver, pos, prerel, expect):
        result = bump_version(ver, pos, prerel)
        assert result == expect

    # Test 1
    test_ver = '1.2.2'
    test_pos = 2
    test_prerel = None
    test_expect = '1.2.3'
    _test_case(test_ver, test_pos, test_prerel, test_expect)

    # Test 2
    test_ver = '1.2.3'
    test_pos = -1
    test_prerel = None
    test_expect = '2.0'
    _test_case(test_ver, test_pos, test_prerel, test_expect)

    # Test 3


# Generated at 2022-06-25 17:37:02.778285
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = '2.0'
    int_1 = 2
    str_2 = '2.3'
    int_2 = 0
    str_3 = '1.3.0'
    int_3 = 1
    str_4 = '2.0'
    int_4 = 2
    str_5 = '1.2.4'
    int_5 = 2
    str_6 = '1.2.4a0'
    int_6 = 2
    str_7 = '1.2.4a1'
    str_8 = '1.2.4b0'
    int_7 = 2
    str_9 = '1.2.4'
    int_8 = 2
    str_10

# Generated at 2022-06-25 17:37:07.836535
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    assert str_1 == '1.3a4'
    assert int_1 == 2



# Generated at 2022-06-25 17:37:13.150755
# Unit test for function bump_version
def test_bump_version():
    test_0 = False
    test_1 = True
    if test_0 is True:
        test_case_0()
    if test_1 is True:
        pass


if __name__ == '__main__':
    print(__doc__)
    print(__file__)
    print(__copyright__)
    print(__license__)

    test_bump_version()

# Generated at 2022-06-25 17:37:23.994180
# Unit test for function bump_version
def test_bump_version():
    # Test for function bump_version
    # Test case 0
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    assert str_1 == '1.3a0'
    # Test case 1
    str_2 = '1.2.3a4'
    int_2 = 2
    str_3 = bump_version(str_2, int_2)
    int_3 = 2
    assert str_3 == '1.2.4a0'
    # Test case 2
    str_4 = '1.2.3'
    int_4 = 0
    str_5 = bump_version(str_4, int_4)
    int_5 = 2
    assert str

# Generated at 2022-06-25 17:37:30.018842
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    int_2 = 3
    str_2 = bump_version(str_1, int_1)
    int_3 = 0
    str_3 = bump_version(str_2, int_3)
    str_4 = bump_version(str_0, int_2)
    int_4 = 3
    str_5 = bump_version(str_0, int_4)
    int_5 = 0
    int_6 = 2
    str_6 = bump_version(str_1, int_5)
    str_7 = bump_version(str_1, int_6)

# Generated at 2022-06-25 17:37:42.207014
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:51.848986
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 3
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    assert str_1 == '2.0'
    int_0 = -1
    str_1 = bump_version(str_0, int_0)
    int_1 = -1
    assert str_1 == '1.2.4'
    int_0 = 2
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    assert str_1 == '1.2.4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    assert str_1 == '1.3a0'


# Generated at 2022-06-25 17:38:03.762264
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', position=-1) == '1.2.4'
    assert bump_version('1.2.3', position=-2) == '1.3'
    assert bump_version('1.2.3', position=-3) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'

# Generated at 2022-06-25 17:38:10.057451
# Unit test for function bump_version
def test_bump_version():
    ver_obj = StrictVersion('2.1.3')
    pre_pos = -1
    args: List[Any] = ['2.1.3']
    for part in _each_version_part(ver_obj):
        if part.pre_txt:
            pre_pos = part.pos
        args.append(part)
    args.append(pre_pos)
    ver_info = _VersionInfo(*args)



# Generated at 2022-06-25 17:38:19.371183
# Unit test for function bump_version
def test_bump_version():
    version: str = bump_version('1.2.3')
    assert version == '1.2.4'
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    version = bump_version('1.3.4', position=0)
    assert version == '2.0'
    version = bump_version('1.2.3', prerelease='a')
    assert version == '1.2.4a0'
    version = bump_version('1.2.4a0', pre_release='a')
    assert version == '1.2.4a1'
    version = bump_version('1.2.4a1', pre_release='b')
    assert version == '1.2.4b0'

# Generated at 2022-06-25 17:38:52.500322
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:39:00.629526
# Unit test for function bump_version
def test_bump_version():
    """Test function for function bump_version."""
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    int_2 = 3
    str_2 = '1.2.3b0'
    str_3 = bump_version(str_0)
    int_3 = 1
    int_4 = 2
    str_4 = bump_version(
            '1.2.3b0',
            int_1,
            'a'
    )
    int_5 = 0
    str_5 = bump_version('1.2.3', int_5)
    str_6 = bump_version('1.2.3b0', int_1)
    str_7 = bump

# Generated at 2022-06-25 17:39:12.948711
# Unit test for function bump_version
def test_bump_version():
    # Test 0:
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    # Test 1:
    str_0 = '1.2.3a4'
    int_0 = 0
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    # Test 2:
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    # Test 3:
    str_0 = '1.2.3a4'
    int_0 = 1

# Generated at 2022-06-25 17:39:24.523334
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '1.3a0'
    int_0 = 0
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '2.0.0a0'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '1.3a0'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '1.3a0'
    int_0 = 2
    str_1 = bump_version(str_0, int_0)
   

# Generated at 2022-06-25 17:39:28.449176
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2

# vim: set fileencoding=utf-8 ts=4 sw=4 tw=0 et :

# Generated at 2022-06-25 17:39:35.931219
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    str_1 = bump_version(str_0)
    str_2 = '1.2.4'
    assert str_1 == str_2
    str_3 = '1.2.4a0'
    str_4 = bump_version(str_2, pre_release='a')
    assert str_3 == str_4
    str_5 = '1.2.4a1'
    str_6 = bump_version(str_4, pre_release='a')
    assert str_5 == str_6
    str_7 = '1.2.4b0'
    str_8 = bump_version(str_6, pre_release='b')
    str_9 = '2.0'

# Generated at 2022-06-25 17:39:47.763569
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    # Test case 0
    str_0 = '1.2.3a'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.4'

    # Test case 1
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '1.3a0'

    # Test case 2
    str_0 = '1.2.3a4'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    str_2 = bump_version(str_1, int_1)

# Generated at 2022-06-25 17:39:57.364441
# Unit test for function bump_version
def test_bump_version():
    # ...
    int_0 = 2
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, int_0)
    str_2 = '1.2.4'
    assert str_1 == str_2
    # ...
    int_1 = 0
    str_3 = bump_version(str_0, int_1)
    str_4 = '2.0'
    assert str_3 == str_4
    # ...
    int_2 = 1
    str_5 = bump_version(str_0, int_2)
    str_6 = '1.3'
    assert str_5 == str_6
    # ...
    str_7 = bump_version('0.0.1', 2)
    str_8 = '0.0.2'

# Generated at 2022-06-25 17:40:06.348154
# Unit test for function bump_version
def test_bump_version():
    """
    Unit test for function bump_version
    """

    # Set up test objects
    str_0 = "1.2.3a4"
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    int_1 = 2
    str_2 = bump_version(str_0, int_1)
    int_2 = 3
    str_3 = bump_version(str_0, int_2)
    int_3 = -1
    str_4 = bump_version(str_0, int_3)
    int_4 = -2
    str_5 = bump_version(str_0, int_4)
    int_5 = -3
    str_6 = bump_version(str_0, int_5)
    int_6 = -4
   

# Generated at 2022-06-25 17:40:18.686821
# Unit test for function bump_version
def test_bump_version():

    import sys
    import os
    import flutils.packages as packages
    # Initialize a test directory in the global temp
    test_dir_path = os.path.join(os.path.sep, 'tmp', 'test_packages')
    if os.path.isdir(test_dir_path) is False:
        os.makedirs(test_dir_path)
    if (os.path.isdir(test_dir_path) is True and
            os.listdir(test_dir_path) == []):
        # noinspection PyUnresolvedReferences
        import flutils_tests.packages_tests  # pylint: disable=W0611
        # noinspection PyUnresolvedReferences
        import flutils_tests.packages_tests.pkg0  # pylint: disable=W0611
        import fl

# Generated at 2022-06-25 17:40:43.361670
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:40:51.590125
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3a4'
    int_0 = 0
    try:
        str_1 = bump_version(str_0, int_0)
        assert False
    except ValueError as err:
        assert isinstance(err, ValueError)

    int_1 = 1
    str_1 = bump_version(str_0, int_1)
    assert str_1 == '1.2a0'

    int_1 = 2
    str_1 = bump_version(str_0, int_1)
    assert str_1 == '1.2.3a5'

    int_1 = 3
    str_1 = bump_version(str_0, int_1)
    assert str_1 == '1.2.4a0'

    int_1 = 4
    str_1

# Generated at 2022-06-25 17:41:00.618511
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.3'
    int_0 = 2
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '1.2.4'
    str_0 = '1.2.3'
    int_0 = 1
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '1.3'
    str_0 = '1.2.3'
    int_0 = 0
    str_1 = bump_version(str_0, int_0)
    assert str_1 == '2.0'
    str_0 = '1.2.3'
    int_0 = 2
    str_1 = 'a'

# Generated at 2022-06-25 17:41:12.323762
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    bump_version('0.0.1')
    bump_version('0.1.1')
    bump_version('0.2.0')
    bump_version('1.0.0')
    bump_version('1.0.1')
    bump_version('1.1.1')
    bump_version('1.1.1', position=0)
    bump_version('1.1.1', position=0, pre_release='a')
    bump_version('1.1.1', position=1)
    bump_version('1.1.1', position=1, pre_release='a')
    bump_version('1.1.1', position=1, pre_release='b')
    bump_version('1.1.1', position=2)
    bump