

# Generated at 2022-06-25 17:31:36.364545
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version

    version = '1.2.2'
    assert bump_version(version) == '1.2.3'



# Generated at 2022-06-25 17:31:45.369214
# Unit test for function bump_version
def test_bump_version():
    """
    Test bump_version
    """
    # pylint: disable=C0103
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:31:53.783413
# Unit test for function bump_version
def test_bump_version():
    ver = bump_version('0.0.0')
    assert ver == '0.0.1'
    ver = bump_version('0.0.1')
    assert ver == '0.0.2'
    ver = bump_version('0.0.2')
    assert ver == '0.0.3'
    ver = bump_version('0.0.3')
    assert ver == '0.0.4'
    ver = bump_version('0.0.4')
    assert ver == '0.0.5'
    ver = bump_version('0.0.5')
    assert ver == '0.0.6'
    ver = bump_version('0.0.6')
    assert ver == '0.0.7'

    ver = bump_version('0.0.7')
    assert ver

# Generated at 2022-06-25 17:32:03.637872
# Unit test for function bump_version
def test_bump_version():
    version_to_bump: Dict[str, str] = {
        '1.2.2': '1.2.3',
        '1.2.3': '1.3',
        '1.3.4': '2',
        '1.2.3': '1.2.4a0',
        '1.2.4a0': '1.2.4a1',
        '1.2.4a1': '1.2.4b0',
        '1.2b0': '1.2.1',
        '2.1.3': '2.2a0',
        '1.2.4a1': '1.2.4',
        '1.2.4b0': '1.2.4',
    }

# Generated at 2022-06-25 17:32:14.846678
# Unit test for function bump_version
def test_bump_version():
    """Test the ``bump_version`` function"""
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', pre_release='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-25 17:32:24.981451
# Unit test for function bump_version
def test_bump_version():
    # 1.2.3 -> 1.2.4
    # noinspection PyUnboundLocalVariable
    assert (bump_version('1.2.3') == '1.2.4')

    # 1.2.3 -> 1.3
    # noinspection PyUnboundLocalVariable
    assert (bump_version('1.2.3', position=1) == '1.3')

    # 1.2.3 -> 2.0
    # noinspection PyUnboundLocalVariable
    assert (bump_version('1.2.3', position=0) == '2.0')

    # 1.2.3 -> 1.2.4a0
    # noinspection PyUnboundLocalVariable

# Generated at 2022-06-25 17:32:33.096766
# Unit test for function bump_version
def test_bump_version():
    _test_bump_version_1()
    _test_bump_version_2()
    _test_bump_version_3()
    _test_bump_version_4()
    _test_bump_version_5()
    _test_bump_version_6()
    _test_bump_version_7()
    _test_bump_version_8()
    _test_bump_version_9()
    _test_bump_version_10()
    _test_bump_version_11()



# Generated at 2022-06-25 17:32:38.589238
# Unit test for function bump_version
def test_bump_version():
    version_number_0 = '1.0.0'
    position_0 = 0
    pre_release_0 = None
    version_number_1 = bump_version(
        version_number_0,
        position=position_0,
        pre_release=pre_release_0
    )

    return


if __name__ == '__main__':

    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:32:48.442410
# Unit test for function bump_version
def test_bump_version():
    version_str = '1.2.3'
    assert bump_version(version_str) == '1.2.4'
    version_str = '1.2.3'
    assert bump_version(version_str, position=1) == '1.3'
    version_str = '1.3.4'
    assert bump_version(version_str, position=0) == '2.0'
    version_str = '1.2.3'
    assert bump_version(version_str, pre_release='a') == '1.2.4a0'
    version_str = '1.2.4a0'
    assert bump_version(version_str, pre_release='a') == '1.2.4a1'
    version_str = '1.2.4a1'

# Generated at 2022-06-25 17:33:01.772942
# Unit test for function bump_version
def test_bump_version():
    print('\n*** Testing "bump_version" ***')
    # Test case #: 0
    # Test case description: No given position means that the patch
    #   number is increased by 1.
    #   Given:
    #       version = '1.2.3'
    #   Expected:
    #       '1.2.4'
    print('\nTest case #: 0\n')
    ver = '1.2.3'
    print('Given: version = %r' % ver)
    print('Expected: %r' % '1.2.4')
    print('Actual: %r' % bump_version(ver))
    # Test case #: 1
    # Test case description: Test case no position.
    #   Given:
    #       version = '2.3.0'
   

# Generated at 2022-06-25 17:33:29.897756
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyUnresolvedReferences
    """Tests the 'bump_version' function"""

    ver = bump_version('1.2.2')
    assert ver == '1.2.3'

    ver = bump_version('1.2.2', position=1)
    assert ver == '1.3'

    ver = bump_version('1.2.2', position=0)
    assert ver == '2.0'

    ver = bump_version('1.2.2', prerelease='a')
    assert ver == '1.2.3a0'

    ver = bump_version('1.2.3a0', prerelease='a')
    assert ver == '1.2.3a1'

    ver = bump_version('1.2.3a1', prerelease='b')
    assert ver

# Generated at 2022-06-25 17:33:37.561346
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:33:47.772215
# Unit test for function bump_version

# Generated at 2022-06-25 17:33:59.676508
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:09.256078
# Unit test for function bump_version
def test_bump_version():
    """Function: bump_version."""
    # pylint: disable=too-many-branches, too-many-statements, too-many-locals
    # pylint: disable=too-many-nested-blocks
    raise_error = 'bump_version'
    failed_cases: List[Tuple[Any, str]] = []

    def _test(
            version: str,
            position: int,
            pre_release: Optional[str],
            expected: str,
            func_name: str):
        try:
            actual = bump_version(version, position, pre_release)
            assert actual == expected
        except AssertionError:
            failed_cases.append((
                (version, position, pre_release),
                expected
            ))

# Generated at 2022-06-25 17:34:19.587913
# Unit test for function bump_version
def test_bump_version():
    from flutils.testing import assert_raises, assert_equal

    assert_equal(bump_version('1.0.0'), '1.0.1')
    assert_equal(bump_version('0'), '1.0')
    assert_equal(bump_version('0.1.0'), '0.1.1')
    assert_equal(bump_version('0.0.1'), '0.0.2')
    assert_equal(bump_version('1.3.3.7'), '1.3.3.8')
    assert_equal(bump_version('1.1'), '1.2')

# Generated at 2022-06-25 17:34:30.933100
# Unit test for function bump_version
def test_bump_version():
    # noinspection PyShadowingNames
    def check_item(
            version: str,
            position: int,
            prerelease: Optional[str],
            out: str
    ):
        val = bump_version(
            version=version,
            position=position,
            pre_release=prerelease
        )
        assert val == out

    check_item('1.2.2', position=2, prerelease=None, out='1.2.3')
    check_item('1.2.3', position=1, prerelease=None, out='1.3')
    check_item('1.3.4', position=0, prerelease=None, out='2.0')
    check_item('1.2.3', position=2, prerelease='a', out='1.2.4a0')
    check

# Generated at 2022-06-25 17:34:37.645638
# Unit test for function bump_version

# Generated at 2022-06-25 17:34:47.760842
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:34:59.101102
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:35:17.907112
# Unit test for function bump_version
def test_bump_version():
    """Verify the results of function bump_version."""
    assert bump_version('1.2.3') == '1.2.4'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'
    assert bump_version

# Generated at 2022-06-25 17:35:29.791577
# Unit test for function bump_version
def test_bump_version():
    version = '1.2.4'
    out = bump_version(version)
    assert out == '1.2.5'

    version = '1.2.4'
    out = bump_version(version, position=1)
    assert out == '1.3'

    version = '1.3.4'
    out = bump_version(version, position=0)
    assert out == '2.0'

    version = '1.2.3'
    out = bump_version(version, pre_release='a')
    assert out == '1.2.4a0'

    version = '1.2.4a0'
    out = bump_version(version, pre_release='a')
    assert out == '1.2.4a1'

    version = '1.2.4a1'

# Generated at 2022-06-25 17:35:39.774636
# Unit test for function bump_version
def test_bump_version():
    #
    # Example #1
    #
    #   > bump_version('1.2.2')
    #   '1.2.3'
    #
    version = bump_version('1.2.2')
    assert version == '1.2.3'
    #
    # Example #2
    #
    #   > bump_version('1.2.3', position=1)
    #   '1.3'
    #
    version = bump_version('1.2.3', position=1)
    assert version == '1.3'
    #
    # Example #3
    #
    #   > bump_version('1.3.4', position=0)
    #   '2.0'
    #
    version = bump_version('1.3.4', position=0)


# Generated at 2022-06-25 17:35:51.084217
# Unit test for function bump_version
def test_bump_version():
    import pytest
    version = '1.2.3'

    expected = '2.0'
    actual = bump_version(version, position=0)
    assert actual == expected

    expected = '1.2.4'
    actual = bump_version(version)
    assert actual == expected

    expected = '1.3'
    actual = bump_version(version, position=1)
    assert actual == expected

    expected = '1.2.4a0'
    actual = bump_version(version, pre_release='a')
    assert actual == expected

    expected = '1.2.4a1'
    actual = bump_version(actual, pre_release='a')
    assert actual == expected

    expected = '1.2.4b0'
    actual = bump_version(actual, pre_release='b')

# Generated at 2022-06-25 17:36:02.234298
# Unit test for function bump_version
def test_bump_version():
    # Bump a patch version
    out = bump_version('1.2.3')
    assert out == '1.2.4'
    # Bump a minor version w/o prerelease
    out = bump_version('1.2.3', position=1)
    assert out == '1.3'
    # Bump a major version
    out = bump_version('1.2.3', position=0)
    assert out == '2.0'
    # Bump an inner minor with prerelease and continue higher minor
    out = bump_version('1.2.3', position=1, pre_release='a')
    assert out == '1.3a0'
    out = bump_version('1.2.3', position=2, pre_release='a')
    assert out == '1.2.4a0'

# Generated at 2022-06-25 17:36:14.783584
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:36:21.167945
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import bump_version as _bump_version

    def _check(kwargs: Dict[str, str], expected: str):
        output = _bump_version(**kwargs)
        assert output == expected


# Generated at 2022-06-25 17:36:31.968487
# Unit test for function bump_version

# Generated at 2022-06-25 17:36:36.361986
# Unit test for function bump_version
def test_bump_version():
    print('Testing function "bump_version"')
    print('...')

    print('...')
    print('Testing function "bump_version": done.')


if __name__ == '__main__':
    test_case_0()
    test_bump_version()

# Generated at 2022-06-25 17:36:44.295951
# Unit test for function bump_version

# Generated at 2022-06-25 17:37:16.159483
# Unit test for function bump_version
def test_bump_version():
    assert ('1.2.2' == bump_version('1.2.2'))
    assert ('1.2.10' == bump_version('1.2.9'))
    assert ('1.2.10' == bump_version('1.2.10'))
    assert ('1.2.11' == bump_version('1.2.10a0'))
    assert ('1.2.0' == bump_version('1.2.0a0'))


if __name__ == "__main__":
    test_bump_version()

# Generated at 2022-06-25 17:37:26.455145
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    str_2 = bump_version(str_1)
    str_3 = bump_version(str_2)
    str_4 = bump_version(str_3)
    str_5 = bump_version(str_4)
    str_6 = bump_version(str_5)
    str_7 = bump_version(str_6)
    str_8 = bump_version(str_7)
    str_9 = bump_version(str_8)
    str_10 = bump_version(str_9)
    str_11 = bump_version(str_10, position=1)
    str_12 = bump_version(str_11, position=1)

# Generated at 2022-06-25 17:37:37.289488
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)

    assert str_1 == '1.2.3'

    # Test case 1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)

    assert str_1 == '1.3'

    # Test case 2
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)

    assert str_1 == '2.0'

    # Test case 3
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, prerelease='a')

    assert str_1 == '1.2.4a0'



# Generated at 2022-06-25 17:37:47.623701
# Unit test for function bump_version
def test_bump_version():
    import sys
    import re

    ver_re = re.compile(r'\d+(\.\d+)+|[a-z]+(\d+)?')

    def is_version_number(x):
        return re.match(ver_re, x)

    def test_case_0():
        str_0 = '1.2.2'
        str_1 = bump_version(str_0)
        assert is_version_number(str_1)
        str_2 = bump_version(str_1)
        assert is_version_number(str_2)

    def test_case_1():
        str_0 = '1.2.2'
        str_1 = bump_version(str_0, position=1)
        assert is_version_number(str_1)

# Generated at 2022-06-25 17:37:55.233071
# Unit test for function bump_version
def test_bump_version():
    assert '1.2.3' == bump_version('1.2.2')
    assert '1.3' == bump_version('1.2.3', position=1)
    assert '2.0' == bump_version('1.3.4', position=0)
    assert '1.2.4a0' == bump_version('1.2.3', pre_release='a')
    assert '1.2.4a1' == bump_version('1.2.4a0', pre_release='a')
    assert '1.2.4b0' == bump_version('1.2.4a1', pre_release='b')
    assert '1.2.4' == bump_version('1.2.4a1')

# Generated at 2022-06-25 17:38:02.528660
# Unit test for function bump_version
def test_bump_version():
    # Simple version to version + 1 in patch
    assert bump_version('1.2.2') == '1.2.3'
    # Major version change
    assert bump_version('1.2.3', position=0) == '2.0'
    # Add an alpha to the minor version
    assert bump_version('2.1.3', position=1, pre_release='a') == '2.2a0'
    # Bump the minor alpha version by 1
    assert bump_version('2.2a0', pre_release='a') == '2.2a1'
    # Bump the minor alpha version to a beta
    assert bump_version('2.2a1', pre_release='b') == '2.2b0'
    # Bump the minor alpha version to a beta version

# Generated at 2022-06-25 17:38:13.153651
# Unit test for function bump_version
def test_bump_version():
    # Test case 0
    test_case_0()
    # Test case 1
    # noinspection PyUnusedLocal
    def test_case_1():
        str_0 = '1.2.2'
        str_1 = bump_version(str_0)
    test_case_1()
    # Test case 2
    # noinspection PyUnusedLocal
    def test_case_2():
        str_0 = '1.2.2'
        str_1 = bump_version(str_0, position=1)
    test_case_2()
    # Test case 3
    # noinspection PyUnusedLocal
    def test_case_3():
        str_0 = '1.2.2'
        str_1 = bump_version(str_0, position=0)
    test_case_

# Generated at 2022-06-25 17:38:14.269074
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

# Generated at 2022-06-25 17:38:22.327093
# Unit test for function bump_version
def test_bump_version():
    test_case_0()
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 1)
    assert str_1 == '1.3'
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, 0)
    assert str_1 == '2.0'
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, pre_release='a')
    assert str_1 == '1.2.4a0'
    str_0 = '1.2.4a0'
    str_1

# Generated at 2022-06-25 17:38:25.153481
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'



# Generated at 2022-06-25 17:38:51.803375
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'
    assert bump_version('1.2.4a1') == '1.2.4'

# Generated at 2022-06-25 17:38:53.860878
# Unit test for function bump_version
def test_bump_version():
    print('Testing function bump_version')
    test_case_0()

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:38:55.493806
# Unit test for function bump_version
def test_bump_version():
    test_case_0()

if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:38:57.215053
# Unit test for function bump_version
def test_bump_version():
    test_case_0()


if __name__ == '__main__':
    # print "testing"
    test_bump_version()

# Generated at 2022-06-25 17:39:03.631259
# Unit test for function bump_version
def test_bump_version():
    from unittest import TestCase, main

    class BumpVersionTests(TestCase):
        @classmethod
        def setUpClass(cls) -> None:
            cls.str_0 = '1.2.2'
            cls.str_1 = bump_version(cls.str_0)
            cls.str_2 = bump_version(cls.str_0, 1)
            cls.str_3 = bump_version(cls.str_0, 0)
            cls.str_4 = bump_version(cls.str_0, pre_release='a')
            cls.str_5 = bump_version(cls.str_0, pre_release='b')

# Generated at 2022-06-25 17:39:05.744361
# Unit test for function bump_version
def test_bump_version():
    print(test_case_0())


if __name__ == '__main__':
    test_bump_version()

# Generated at 2022-06-25 17:39:16.405074
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)

    assert str_1 == '1.2.3'

    str_2 = bump_version(str_0, position=1)

    assert str_2 == '1.3'

    str_3 = bump_version(str_0, position=0)

    assert str_3 == '2.0'

    str_4 = bump_version(str_0, pre_release='a')

    assert str_4 == '1.2.4a0'

    str_5 = bump_version(str_4)

    assert str_5 == '1.2.4'

    str_6 = bump_version(str_4, pre_release='a')


# Generated at 2022-06-25 17:39:18.502609
# Unit test for function bump_version
def test_bump_version():
    # TODO
    pass



# Generated at 2022-06-25 17:39:29.045978
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    print(str_1)
    str_1 = bump_version(str_0, position=1)
    print(str_1)
    str_1 = bump_version(str_0, position=0)
    print(str_1)
    str_1 = bump_version(str_0, prerelease='a')
    print(str_1)
    str_1 = bump_version(str_0, pre_release='a')
    print(str_1)
    str_1 = bump_version(str_0, pre_release='b')
    print(str_1)
    str_1 = bump_version(str_0)
    print(str_1)
    str_1 = bump_

# Generated at 2022-06-25 17:39:36.343545
# Unit test for function bump_version
def test_bump_version():
    """Test 'bump_version'."""
    version = '1.2.2'
    result = bump_version(version)
    assert result == '1.2.3'

    version = '1.2.2'
    result = bump_version(version, position=1)
    assert result == '1.3'

    version = '1.2.2'
    result = bump_version(version, position=0)
    assert result == '2.0'

    version = '1.2.2'
    result = bump_version(version, position=-1)
    assert result == '1.2.3'

    version = '1.2.2'
    result = bump_version(version, position=-2)
    assert result == '1.3'

    version = '1.2.2'
    result

# Generated at 2022-06-25 17:40:20.516113
# Unit test for function bump_version
def test_bump_version():
    print(bump_version('1.2.2'))
    print(bump_version('1.2.2', position=1))
    print(bump_version('1.2.2', position=0))
    print(bump_version('1.2.2', prerelease='a'))
    print(bump_version('1.2.4a0', pre_release='a'))
    print(bump_version('1.2.4a1', pre_release='b'))
    print(bump_version('1.2.4a1'))
    print(bump_version('1.2.4b0'))
    print(bump_version('2.1.3', position=1, pre_release='a'))

# Generated at 2022-06-25 17:40:28.927110
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)

    if str_1 != '1.2.3':
        raise AssertionError(
            "The result, %r, does not match the expected result, %r." % (
                str_1,
                '1.2.3'
            )
        )

    str_0 = '1.2.3'
    str_1 = bump_version(str_0, 1)

    if str_1 != '1.3':
        raise AssertionError(
            "The result, %r, does not match the expected result, %r." % (
                str_1,
                '1.3'
            )
        )

    str_0 = '1.3.4'
    str_1 = bump

# Generated at 2022-06-25 17:40:40.863501
# Unit test for function bump_version
def test_bump_version():
    str_0 = '1.2.2'
    str_1 = '1.2.3'
    assert bump_version(str_0) == str_1
    str_0 = '1.2.3'
    str_1 = '1.3'
    assert bump_version(str_0, position=1) == str_1
    str_0 = '1.3.4'
    str_1 = '2.0'
    assert bump_version(str_0, position=0) == str_1
    str_0 = '1.2.3'
    str_1 = '1.2.4a0'
    assert bump_version(str_0, prerelease='a') == str_1
    str_0 = '1.2.4a0'

# Generated at 2022-06-25 17:40:50.374499
# Unit test for function bump_version
def test_bump_version():
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.2.3', position=2) == '1.2.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'
    assert bump_version('1.2.4a0', pre_release='a') == '1.2.4a1'
    assert bump_version('1.2.4a1', pre_release='b') == '1.2.4b0'

# Generated at 2022-06-25 17:40:59.135362
# Unit test for function bump_version
def test_bump_version():
    from flutils.packages import __version__
    assert bump_version(__version__) == '0.5.2'
    assert bump_version(__version__, position=1) == '0.6.0'
    assert bump_version(__version__, position=1, pre_release='a') == '0.6a0'
    assert bump_version('1.2.2') == '1.2.3'
    assert bump_version('1.2.3', position=1) == '1.3'
    assert bump_version('1.3.4', position=0) == '2.0'
    assert bump_version('1.2.3', prerelease='a') == '1.2.4a0'

# Generated at 2022-06-25 17:41:07.185140
# Unit test for function bump_version
def test_bump_version():
    # Test case #0
    str_0 = '1.2.2'
    str_1 = bump_version(str_0)
    assert str_1 == '1.2.3'

    # Test case #1
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, position=1)
    assert str_1 == '1.3'

    # Test case #2
    str_0 = '1.3.4'
    str_1 = bump_version(str_0, position=0)
    assert str_1 == '2.0'

    # Test case #3
    str_0 = '1.2.3'
    str_1 = bump_version(str_0, prerelease='a')