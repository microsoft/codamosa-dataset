

# Generated at 2022-06-25 10:43:18.962755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # NOTE: first is a term dict, second a term string the tests will verify
    data = [
        {'paths': '../test/test2', 'files': 'file1, file2'},
        '../test/test2:file1,file2'
    ]

    for term in data:
        # NOTE: copied from unit test, may not be real world
        terms = [term]
        variables = {'subdir': 'test'}
        kwargs = {'all_vars': variables, 'var': 'subdir'}
        with open('../test/test2/file1') as f:
            res = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:43:28.612911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj_0 = LookupModule()
    arg_0 = [{'skip': False, '_terms': None, 'paths': ['/tmp/production', '/tmp/staging'], 'files': ['foo', '{{ inventory_hostname }}', 'bar']}]
    arg_1 = [{'skip': False, '_terms': None, 'paths': ['/tmp/production', '/tmp/staging'], 'files': ['foo', '{{ inventory_hostname }}', 'bar']}]
    ret_0 = lookup_obj_0.run(arg_0, arg_1)
    assert(ret_0 == ['/tmp/production/foo'])
    arg_0 = []

# Generated at 2022-06-25 10:43:38.713680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: use variables
    variables = None
    lookup_module_0._templar = None
    lookup_module_0._finder = None
    lookup_module_0._loader = None
    lookup_module_0._variable_manager = None
    lookup_module_0._display = None
    terms = []
    kwargs = {}
    subdir = 'files'
    fn = 'foo.txt'
    fn = lookup_module_0._templar.template(fn)
    path = None
    for path in lookup_module_0.find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        pass
    assert path is None

    return

# Generated at 2022-06-25 10:43:48.610206
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={})
    lookup_module_0._subdir = 'files'
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct={})
    lookup_module_1._subdir = 'files'


# Generated at 2022-06-25 10:43:53.438273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Expect to return an empty list if no files found
    lookup_module = LookupModule()
    terms = ["test_data/test_file1", "test_data/test_file2"]
    variables = {}
    result = lookup_module.run(terms, variables)
    assert not result

    # Expect to return path of first_found file
    lookup_module = LookupModule()
    terms = ["test_data/test_file1", "test_data/test_file3"]
    variables = {}
    result = lookup_module.run(terms, variables)
    assert result == ["test_data/test_file1"]

# Generated at 2022-06-25 10:43:55.580184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo']
    variables = {}
    kwargs = {}
    fm = LookupModule()
    fm.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:44:03.694662
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup class instance for lookup module
    lookup_module_0 = LookupModule()

    # Setup for test case_0
    terms = [{'files': ['file_0'], 'paths': ['path_1']}, 'term_1']
    variables = {'var_0': 'value_0'}

    # Perform lookup_module_0.run for test case_0
    test_case_0_result = lookup_module_0.run(terms, variables)

    # Test case assertions
    assert(test_case_0_result == [])

# Generated at 2022-06-25 10:44:14.907683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'tests/unit/plugins/lookup/first_found'
    str_1 = 'some.yml'
    terms_0 = [str_1]
    terms_1 = [str_1]
    terms_2 = [str_1]
    terms_3 = [str_1]
    terms_4 = [str_1]
    terms_5 = [str_1]
    terms_6 = [str_1]
    terms_7 = [str_1]
    terms_8 = [str_1]
    terms_9 = [str_1]
    terms_10 = [str_1]
    terms_11 = [str_1]
    terms_12 = [str_1]
    terms_13 = [str_1]
   

# Generated at 2022-06-25 10:44:22.266293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # For testing only, use given fixtures
    lookup_module_0.find_file_in_search_path = 'bar_foo.txt'

    # NOTE: find_file_in_search_path result will not be part of result
    assert lookup_module_0.run(terms='bar_foo.txt', variables= {'foo': 'bar'}) == ['/path/bar_foo.txt']
    assert lookup_module_0.run(terms=['foo.txt', 'bar_foo.txt'], variables= {'foo': 'bar'}) == ['/path/bar_foo.txt']
    assert lookup_module_0.run(terms=['foo.txt', 'bar_foo.txt'], variables= {'foo': 'bar'}, skip=True) == [] # files exist

# Generated at 2022-06-25 10:44:26.720072
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        # make temp file
        runner = AnsibleRunner('./tests/fixtures/lookup.yml')
        runner.run()

        # check the file was created
        assert os.path.exists(runner._results['test_0']['results'][0])

    except Exception as e:
        raise
    else:
        pass
    finally:
        # remove temp file
        os.remove(runner._results['test_0']['results'][0])

# Generated at 2022-06-25 10:44:44.434404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    lookup_module_1 = LookupModule()
    # Testing if the method can handle an error case
    # Input arguments:
    #   terms: List of file names
    #   variables: Environment variables
    #   kwargs: Keyword arguments
    # Expected output:
    #   An error should be raised
    terms = ['foo.txt', 'bar.txt']
    variables = {}
    kwargs = {}
    try:
        lookup_module_1.run(terms, variables, **kwargs)
    except AnsibleLookupError:
        pass
    else:
        raise Exception("Expected error not raised")


# Generated at 2022-06-25 10:44:46.396631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([], {})

    lookup_module._process_terms([], {}, {})

# Generated at 2022-06-25 10:44:55.251264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/path/to/foo.txt']
    skip_0 = lookup_module_0.run(terms_0, None)
    assert skip_0 == []
    terms_1 = ['/path/to/foo.txt']
    skip_1 = lookup_module_0.run(terms_1, None)
    assert skip_1 == []
    terms_2 = ['/path/to/foo.txt']
    skip_2 = lookup_module_0.run(terms_2, None)
    assert skip_2 == []
    terms_3 = ['/path/to/foo.txt']
    skip_3 = lookup_module_0.run(terms_3, None)
    assert skip_3 == []

# Generated at 2022-06-25 10:44:56.438827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=[], variables={}, kwargs={})


# Generated at 2022-06-25 10:44:59.305798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    total_search, skip = lookup_module_0._process_terms(['/root/.bashrc'], None, {})
    first_found_result = lookup_module_0.run(total_search, skip)
    assert first_found_result == ['/root/.bashrc']

# Generated at 2022-06-25 10:45:07.802454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(terms=[{"files": "file1.txt", "paths": "path1"}, {"files": "file2.txt", "paths": "path2"}])
    assert isinstance(ret, list) is True
    assert ret == []

    ret = lookup_module.run(terms=['file1.txt', 'path2'])
    assert isinstance(ret, list) is True
    assert ret == []


# Generated at 2022-06-25 10:45:09.963622
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:45:12.220277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run('test', 'test', 'test', 'test')
    assert result is not None


# Generated at 2022-06-25 10:45:15.930189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    params_0 = {}
    assert lookup_module_run_0.run(terms_0, variables_0, **params_0) == []


# Generated at 2022-06-25 10:45:25.940517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Negative test
    # Test for file that does not exist
    lookup_module_0 = LookupModule()
    file_str = "file.txt"
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(file_str, None)

    # Negative test
    # Test for unsupported type
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleLookupError):
        lookup_module_1.run(None, None)

    # Positive test
    # Test for existing file
    lookup_module_2 = LookupModule()
    file_str = "file.txt"
    open(file_str, "w+").close()
    assert lookup_module_2.run(file_str, None) == ["file.txt"]

# Generated at 2022-06-25 10:45:37.560957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([{'skip': False, 'paths': None}], {}) == None

# Generated at 2022-06-25 10:45:43.745948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        ' /tmp/junk',
        [' /tmp/junk'],
        {
            'files': [' /tmp/junk'],
            'paths': ['/tmp/junk']
        }
    ]
    variables_0 = [
        'trolololo',
        'trolololo'
    ]
    kwargs_0 = {
        'params': [
            "/tmp/junk",
            "/tmp/junk"
        ]
    }

    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:45:48.775004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0._subdir = 'files'

    # NOTE: I know this is not what the test meant to test
    #       but it is used to generate coverage for lookup's
    #       _get_file_in_search_path
    #       Just leave it until that is tested separately.
    lookup_module_0.run(['vizsla'], {'foo': 'hello'}, _tmpl_dir='files')

# Generated at 2022-06-25 10:45:55.132456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'foo'
    variables = {}

    lookup_module_obj = LookupModule()
    lookup_module_obj.set_options(var_options=variables, direct={'files': ['path/tasks.yaml']})
    lookup_module_obj.run(terms, variables)

    # verify value for method run
    expected = 'foo'
    actual = lookup_module_obj.run(terms, variables)
    assert expected == terms



# Generated at 2022-06-25 10:45:59.461103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with kwargs
    lookup_module_1 = LookupModule()
    terms_1 = [
        'file1',
        'file2',
    ]
    variables_1 = {
        'path1': 'path1_var',
        'path2': 'path2_var',
        'path3': 'path3_var',
    }
    files_1 = 'file_var1'
    paths_1 = 'path_var1'
    skip_1 = True
    result = lookup_module_1.run(terms=terms_1, variables=variables_1, files=files_1, paths=paths_1, skip=skip_1)

# Generated at 2022-06-25 10:46:05.054368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_1 = [
            'seth.txt',
            'skvidal.txt',
            'skvidal_elite_hacker.txt',
            'skvidal_elite_hacker_extraordinaire.txt',
            'skvidal_elite_hacker_extraordinaire_lovestar.txt'
        ]

    variables_1 = {}

    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(input_1, variables_1)

    except AnsibleUndefinedVariable:
        pass
    except AnsibleLookupError:
        pass


# Generated at 2022-06-25 10:46:09.077186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_run = LookupModule()



# Generated at 2022-06-25 10:46:15.590168
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # term / dict case
    lookup_module_1.run(
        terms=[
            {
                'files': 'd',
                'paths': '/a/b,/c',
                'skip': True,
            },
        ],
        variables={
        },
    )

    # string case
    lookup_module_1.run(
        terms=[
            'd',
        ],
        variables={
        },
    )

    # list case
    lookup_module_1.run(
        terms=[
            [
                'd',
            ],
        ],
        variables={
        },
    )


# Generated at 2022-06-25 10:46:19.866767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupModule()
    val = lookup_module_obj_0.run(terms=[], variables={})
    assert val == []


# Generated at 2022-06-25 10:46:22.087034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # check missing param
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:46:35.779190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Looking for a file with a filename 'foo_foo.conf'
    # returns a file with name 'foo_foo.conf' if exists, otherwise
    # returns a file 'default_foo.conf' if exists, otherwise
    # returns an error, 'No file was found when using first_found'
    terms = [
        "foo_foo.conf",
        "default_foo.conf"
    ]
    variables = {
        "ansible_virtualization_type": "foo"
    }
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms,variables) == ['foo_foo.conf']

# Generated at 2022-06-25 10:46:42.224107
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:46:44.607857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{"files": ['foo', 'bar'], "paths": ['/tmp/production', '/tmp/staging']}]
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:46:56.144981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create template_data_0

    params_0 = dict(
        files=['file1', 'file2'],
        paths=['/path/to', '/path/to/other']
    )

    # Get an instance of the current Ansible class
    cur_ans = Ansible()

    # Instantiate LookupModule object using cur_ans
    lookup_module_0 = LookupModule(cur_ans)

    # Test passing empty terms, as it's optional,
    # passing empty terms should generally not fail
    lookup_module_0.run([])

    # Test passing params_0
    lookup_module_0.run([params_0])

    # Test passing params_0,
    # passing positional arguments instead of a list
    lookup_module_0.run(params_0)

    # Test passing empty terms, as it's

# Generated at 2022-06-25 10:47:01.209845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    kwargs = {"terms": ["foo", "bar", "baz"]}
    result = lookup_module.run(**kwargs)
    assert result == []

# Generated at 2022-06-25 10:47:03.149725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([], []) == []


# Generated at 2022-06-25 10:47:04.693700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run()
    assert result == None

# Generated at 2022-06-25 10:47:12.110403
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with a single string
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:47:23.069273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # class ansible.module_utils.six.string_types(basestring)
    test_instance_0 = string_types
    # class ansible.module_utils.six.string_types(basestring)
    test_instance_1 = string_types

    # ansible.module_utils.six.string_types(basestring)
    test_run_1 = test_instance_0.__mro__[0]
    # True
    assert test_run_1 == basestring

    # ansible.module_utils.six.string_types(basestring)
    test_run_2 = test_instance_1

    # ansible.module_utils.six.string_types(basestring)
    test_run_3 = test_instance_1.__mro__[1]
    # True


# Generated at 2022-06-25 10:47:27.090186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = [u'foo.txt', u'bar.txt', u'biz.txt', u'baz.txt']
    variables_1 = {}
    kwargs_1 = {}
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == []


# Generated at 2022-06-25 10:47:35.286201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = jinja2.Environment()
    lookup_module.run("/test_file_does_not_exist")


# Generated at 2022-06-25 10:47:39.990862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []


# Generated at 2022-06-25 10:47:50.370892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    array = [2, 3, 4]
    kwargs = {"files": ["first_found.py", "test_first_found.py"], "paths": ["lookup_plugins"]}
    result_1 = lookup_module.run(array, None, **kwargs)
    kwargs = {"files": "first_found.py, test_first_found.py", "paths": ["lookup_plugins"]}
    result_2 = lookup_module.run(array, None, **kwargs)
    assert(result_1 == ["lookup_plugins/first_found.py"])
    assert(result_2 == ["lookup_plugins/first_found.py"])

# Generated at 2022-06-25 10:47:57.831420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{'files': 'default.conf', 'skip': False}, 'foo.conf']
    variables = {'foo': 'foo.conf'}
    assert lookup_module.run(terms, variables) == ['foo.conf']


# Generated at 2022-06-25 10:48:05.319153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test_1', 'test_2'], variables=['test_variables'], skip=False) == []
    assert lookup_module.run(terms=['test_1', 'test_2'], variables=['test_variables'], skip=True) == []

# Generated at 2022-06-25 10:48:06.920682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:48:17.947509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test a list of file names to find
    lookup_module_0 = LookupModule()
    files_0 = ['foo', 'bar.txt']
    paths_0 = ['', 'tasks']
    terms_0 = [{'files': files_0, 'paths': paths_0}]
    variables_0 = {'foo': 'bar'}
    skip_0 = True

    lookup_module_0._process_terms(terms_0, variables_0, kwargs={'skip': skip_0})
    lookup_module_0.run(terms_0, variables_0, kwargs={'skip': skip_0})
    # for testing purposes, this test case should never try to raise an exception
    assert True == True



# Generated at 2022-06-25 10:48:23.498206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run('/path/to/a/file', {}) == ['/path/to/a/file']



# Generated at 2022-06-25 10:48:31.252333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First create the object to test with
    lookup_module_0 = LookupModule()

    # Next call the method you wish to test
    # Note that you may have to provide other arguments as noted
    # in the description of the method
    # lookup_module_0.run(terms, variables, **kwargs)
    assert test_case_0()


# Generated at 2022-06-25 10:48:41.708248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: the default behavior is to ignore undefined variables which
    # result in the '_' being ignored and only the ansible_os_family is evaluated.
    # The lookup will not fail. A warning will be generated if show_custom_warnings is enabled.
    terms2 = [{'files': '{{ ansible_os_family }}.yml,{{ _ }}.yml', 'paths': 'vars'}]
    variables2 = {"ansible_os_family": "RedHat", "_": "default"}
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(terms2, variables2, skip=False) == [os.path.join("vars", "RedHat.yml")]

    # NOTE: the default behavior is to ignore undefined variables which
    # result in the '_' being ignored

# Generated at 2022-06-25 10:48:56.103430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['bar.txt']
    kwargs = {}
    ret = lookup_module.run(terms, {}, **kwargs)
    print(ret)
    assert ret == ['/tmp/bar.txt']

# Generated at 2022-06-25 10:49:05.541972
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Create a MockDataLoader object
    # and mock its method load
    loader_0 = DataLoader()
    def mock_load(path):
        if path == u'files/foo':
            return u'bar', False
        else:
            return u'baz', False
    loader_0.load = mock_load

    # Create a MockTemplar object
    # and mock its methods template and is_template
    templar_0 = Templar(loader=loader_0)
    templar_0.is_template = lambda s: False
    templar_0.template = lambda s: s

    lookup_module_

# Generated at 2022-06-25 10:49:11.795617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    total_search = lookup_module.run({'files': 'foo.yml', 'paths': '/tmp/foo'}, variables={}, skip=False)
    assert total_search == '/tmp/foo/foo.yml'



# Generated at 2022-06-25 10:49:14.124424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        term = 'something'
        result = LookupModule().run(term=term, variables=None, **{})[0]
        assert term == result

# Generated at 2022-06-25 10:49:17.861752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mylookup = LookupModule()
    # terms = {'files': pathlib.Path("/path/to/file"), 'paths': pathlib.Path("/path/to/file2")}
    # mylookup.run(terms, None)
    pass

# Generated at 2022-06-25 10:49:24.942367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    file_names = ['foo', 'bar', 'biz']
    base_dir = '/tmp/dir'
    terms = [{'files': file_names, 'paths': [base_dir]}]
    variables = ["foo", "bar", "biz", "baz"]
    kwargs = {'test': "foo=bar"}
    actual = lookup_module_0.run(terms, variables, **kwargs)
    assert actual is not None and actual != ""


# Generated at 2022-06-25 10:49:29.051612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['a', 'b'], []) == ['a', 'b']
    assert lookup_module.run([1, 2], []) == [1, 2]

# Generated at 2022-06-25 10:49:34.794339
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up test variables
    terms = ['some/value', 'other/value']
    variables = {'test_var': 'real/value'}
    kwargs = {'test_kwarg': 'test/value'}

    # Initialize instance of class LookupModule
    lookup_module = LookupModule()

    # Run method run of class LookupModule
    result = lookup_module.run(terms, variables, **kwargs)

    # Assert the result
    assert result == ['some/value', 'other/value']

# Generated at 2022-06-25 10:49:39.535679
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    term_0 = ['ansible.cfg', '/home/user/.ansible.cfg']
    variables_0 = {}
    kwargs_0 = {}
    kwargs_0['display_skipped_hosts'] = False
    expected_result_0 = []

    result_0 = lookup_module_0.run(term_0, variables_0, **kwargs_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-25 10:49:50.925696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 1 failed"
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 2 failed"
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 3 failed"
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 4 failed"
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 5 failed"
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 6 failed"
    assert lookup_module_1.run() == [], "LookupModule_run: Test case 7 failed"
    assert lookup_module

# Generated at 2022-06-25 10:50:12.040662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._loader = 'foo'
    lookup_module_0._templar = 'foo'
    lookup_module_0._basedir = 'foo'

    # sumo_h2_vnf: create_dir(dir_name)
    # sumo_h2_vnf: create_dir(dir_name)
    # sumo_h2_vnf: create_dir(dir_name)
    # sumo_h2_vnf: create_dir(dir_name)
    # sumo_h2_vnf: create_dir(dir_name)
    # sumo_h2_vnf: create_dir(dir_name)
    # sumo_

# Generated at 2022-06-25 10:50:13.634982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = None
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, list_0)



# Generated at 2022-06-25 10:50:15.407852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=None, variables={})
    assert var_0 == []



# Generated at 2022-06-25 10:50:18.556113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = None
    variables_1 = {}
    kwargs_1 = {"files": "str_1", "paths": "str_2"}
    path_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    path_expected_1 = "str_1"
    assert path_1 == path_expected_1



# Generated at 2022-06-25 10:50:29.131725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    dict_0 = {}
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(var_0, dict_0)

if __name__ == "__main__":
    test_case_0()



# -*- encoding: utf-8 -*-
#
# (c) 2013, seth vidal <skvidal@fedoraproject.org> red hat, inc
# (c) 2014, Jan-Piet Mens <jpmens()gmail.com>
# (c) 2017 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# Generated at 2022-06-25 10:50:34.941616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import ansible_galaxy_lookup_dest.plugins.lookup.first_found as first_found
        lookup_module_0 = first_found.LookupModule()
        lookup_module_0.run([], {})
    except UndefinedError as err_0:
        print(err_0)


# Generated at 2022-06-25 10:50:46.265641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: during refactor noticed that the 'using a dict' as term
    # is designed to only work with 'one' otherwise inconsistencies will appear.
    # see other notes below.

    # Using a list as term
    lookup_module_0 = LookupModule()
    list_0 = ["foo/bar-0.txt", "foo/bar.txt"]
    dict_0 = {}
    var_0 = lookup_run(dict_0, list_0)
    assert(var_0[0] == lookup_module_0._loader.path_dwim(list_0[1]))

    # Using a dict as term
    lookup_module_1 = LookupModule()
    dict_1 = {"files": "foo/bar-1.txt", "skipped": "foo/skipped.txt", "paths": "foo"}


# Generated at 2022-06-25 10:50:51.982124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = {}
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 10:50:53.169014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(test_case_0())

test_case_0()

# Generated at 2022-06-25 10:50:59.803578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["foo.conf", "biz.conf"]
    terms_1 = "foo.conf"
    terms_2 = None
    terms_3 = ["foo.conf", "biz.conf", "{{ ansible_virtualization_type }}_foo.conf"]
    variables_0 = None
    variables_1 = {}
    variables = __builtins__
    obj = eval("__import__('os')", variables)
    variables['os'] = obj
    var_0 = lookup_run(variables_0, terms_0)
    var_1 = lookup_run(variables_1, terms_1)
    var_2 = lookup_run(variables_1, terms_2)
    var_3 = lookup_run(variables_1, terms_3)
   

# Generated at 2022-06-25 10:51:22.769524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    import os
    import pytest

    # Test for type isinstance(obj, type) or issubclass(cls, classinfo)
    # Check if obj is of a type specified, or if it is a subclass of a type or a class.
    Mapping

    # Test for Sequence
    # A generalization of lists and tuples that is an ordered container with random access.
    # Examples of sequences include tuples, lists and strings.
    Sequence

    # Test for os.path.join
    # Join one or more path components intelligently.
    # The return value is the concatenation of path and any members of *paths with exactly one directory separator (os.sep)
    # following each non-empty part except the last, meaning that the result will only

# Generated at 2022-06-25 10:51:30.287343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instantiate class as a mock
    lookup_module_1 = LookupModule()
    # mock return value
    setattr(lookup_module_1, 'find_file_in_search_path', lambda *args: 'mock_value')

    list_1 = [None]
    dict_1 = {'skip': True, 'paths': 'test_value_2'}
    var_1 = lookup_run(dict_1, list_1)
    assert var_1 == []



# Generated at 2022-06-25 10:51:34.546655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 10:51:39.700626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = None
    dict_0 = {}
    var_0 = lookup_run(dict_0, list_0)

    # Assert
    assert var_0 is None, 'Assertion Failed'


# Generated at 2022-06-25 10:51:40.406546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    t.run(terms=[], variables={})

# Generated at 2022-06-25 10:51:42.481633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    list_0 = []
    var_0 = lookup_module_0.run(list_0, dict_0, (dict_1, list_0), skip=False, paths=[], files=[])
    assert var_0 == []



# Generated at 2022-06-25 10:51:52.492197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests that ensure that we can skip a task by returning an empty list.
    lookup_module = LookupModule()
    list_0 = ['bacon', {'files': ['bacon', 'eggs'], 'paths': ['.']}]
    dict_0 = {}
    var_0 = lookup_run(dict_0, list_0)
    list_1 = ['bacon', {'files': ['bacon', 'eggs'], 'paths': ['.']}, {'files': ['bacon', 'eggs'], 'paths': ['.'], 'skip': True}]
    dict_1 = {}
    var_1 = lookup_run(dict_1, list_1)
    assert var_1 == []

# Generated at 2022-06-25 10:51:58.639834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {
        'a': 0,
        'b': 1,
        'c': 2,
        'd': 3
    }
    list_0 = [4, 5, 6]
    var_0 = lookup_module_0.run(dict_0, list_0)
    assert(var_0 == [4, 5, 6])


# Generated at 2022-06-25 10:52:02.332722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = None
    dict_0 = {}
    var_0 = lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:52:09.052053
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    lookup_module_0 = LookupModule()
    list_0 = [
        {},
        '',
        [
            '',
            {
                'files': '',
            },
        ],
    ]
    dict_0 = {}
    var_0 = lookup_run(dict_0, list_0)
    print(repr(var_0))


# Generated at 2022-06-25 10:52:33.140065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    lookup_module_0.set_environment()
    var_0 = ['files']
    var_1 = 'default'
    lookup_module_0._subdir = 'files'
    lookup_module_0.set_options(var_options=None, direct={'files': ['first.txt'], 'paths': ['paths'], 'skip': False})
    lookup_module_0._loader = FileLoader(paths=[])
    lookup_module_0._loader.set_basedir('.')
    lookup_module_0._loader._searchpaths = ['/path/to/first.txt']
    lookup_module_0._loader.path_exists('/path/to/first.txt')
    lookup_module_0

# Generated at 2022-06-25 10:52:34.877984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables)
    assert var_0 == var_1

# Generated at 2022-06-25 10:52:38.546603
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test list of dicts
    lookup_module = LookupModule()
    assert lookup_module.run(['test'], None) == ['/test']

    # Test list of ints
    lookup_module = LookupModule()
    assert lookup_module.run([0], None) == ['/0']

# Generated at 2022-06-25 10:52:43.127978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    var_0 = lookup_module_0.run(list_0, dict_0)
    var_1 = lookup_module_0.run(list_0, dict_0)
    assert (var_0 is not var_1)
    assert (var_0 is not list_0)


# Generated at 2022-06-25 10:52:54.724955
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_obj_0 = LookupModule()
    list_0 = ['first_found', 'files', 'paths']
    dict_0 = {}
    var_0 = lookup_run(dict_0, list_0)

    lookup_module_obj_1 = LookupModule()
    list_1 = ['first_found', 'files', 'paths']
    dict_1 = {}
    var_1 = lookup_run(dict_1, list_1)

    lookup_module_obj_2 = LookupModule()
    list_2 = ['first_found', 'files', 'paths']
    dict_2 = {}
    var_2 = lookup_run(dict_2, list_2)

    lookup_module_obj_3 = LookupModule()

# Generated at 2022-06-25 10:52:58.001967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list = ['test_value_0', 'test_value_1']
    dict = {'key_1': 'test_value_0', 'key_2': 'test_value_1'}
    var = LookupModule.run(list, dict)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:53:03.538428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleUndefinedVariable
    lookup_module_0 = LookupModule()
    terms_0 = 'foo'
    terms_1 = 'foo'
    lookup_run(terms_0, terms_1)
    list_0 = []
    list_1 = []
    list_0.append(list_1)
    var_0 = lookup_run(terms_0, list_0)
    terms_2 = 'bar'
    var_2 = lookup_run(list_0, terms_2)
    path_0 = '/usr/local/etc/ansible/plugins/lookup/foo'
    path_1 = 'foo'
    subdir_0 = 'lookup'
    subdir_1 = 'lookup'
    subdir_2 = 'lookup'

# Generated at 2022-06-25 10:53:08.320060
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # refer: https://github.com/ansible/ansible/blob/devel/test/units/plugins/lookup/test_first_found.py#L7
    file_0 = 'test_file_0'
    file_1 = 'test_file_1'
    file_2 = 'test_file_2'
    file_3 = 'test_file_3'
    file_4 = 'test_file_4'
    file_5 = 'test_file_5'

    # arrange
    params = {'file_0': file_0,
              'file_1': file_1,
              'file_2': file_3,
              'file_3': file_4,
              'file_4': file_5}

    lookup_module_0 = LookupModule()