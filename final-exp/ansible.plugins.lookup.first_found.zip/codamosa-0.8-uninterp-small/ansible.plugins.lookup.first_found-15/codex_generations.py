

# Generated at 2022-06-25 10:43:19.512482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([], {})


# Generated at 2022-06-25 10:43:28.004789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    terms_0 = ['test_value_1', 'test_value_2']
    variables_0 = {}
    kwargs_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except AnsibleLookupError as err:
        assert err.args[0] == "Invalid term supplied, can handle string, mapping or list of strings but got: <class 'str'> for test_value_1"
    else:
        raise RuntimeError('Expected exception: AnsibleLookupError')


# Generated at 2022-06-25 10:43:37.888421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The following example shows how to use this method
    terms = '''str0 = "str0"
str1 = "str1"
str2 = "str2"
'''
    variables = '''str3 = "str3"
str4 = "str4"
str5 = "str5"
'''
    kwargs = '''str6 = "str6"
str7 = "str7"
str8 = "str8"
'''
    lookup_module_1 = LookupModule(variables)
    result = lookup_module_1.run(terms, variables, **kwargs)
    print(result)
    assert True



# Generated at 2022-06-25 10:43:48.124623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_params_0 = ["/tmp/foo", "/tmp/bar"]
    test_params_1 = {}
    lookup_module_0 = LookupModule(False)
    bool_0 = lookup_module_0.run(test_params_0, test_params_0)
    assert bool_0 is True
    bool_0 = lookup_module_0.run(test_params_0, test_params_1)
    assert bool_0 is True
    bool_0 = lookup_module_0.run(test_params_1, test_params_1)
    assert bool_0 is True
    bool_0 = lookup_module_0.run(test_params_1, test_params_0)
    assert bool_0 is True

# Generated at 2022-06-25 10:43:51.142057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('running test_LookupModule_run')
    lookup_module_0 = LookupModule()
    terms_0 = [{}]
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 10:43:55.024066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(True)
    test_terms_0 = "example.conf"
    test_variables_0 = "vars"
    result_0 = lookup_module_0.run(test_terms_0, test_variables_0)


# Generated at 2022-06-25 10:44:03.540573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar = Template(bool_0, bool_0)

    lookup_module_0.set_options(var_options=variables, direct="path/")
    lookup_module_0.set_options(var_options=variables, direct=kwargs)

    lookup_module_0.get_option('files')
    lookup_module_0.get_option('paths')
    lookup_module_0.get_option('skip')

    lookup_module_0.find_file_in_search_path(variables, subdir, fn, ignore_missing=True)
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:44:14.805793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_0._subdir = 'files'
    lookup_module_0.set_options(var_options={ 'paths': '', 'files': 'foo.txt' }, direct={ 'paths': '', 'files': 'foo.txt' })
    lookup_module_0.get_option('paths')
    lookup_module_0.get_option('foo.txt')
    lookup_module_0._templar.template('foo.txt')
    lookup_module_0.find_file_in_search_path({ 'paths': '', 'files': 'foo.txt' }, 'files', 'foo.txt', ignore_missing=True)

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_

# Generated at 2022-06-25 10:44:19.905217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    terms_0 = [10]
    variables_0 = {
        'ansible_env': {
            'HOME': 'HOME'
        },
        'path': 'path'
    }
    kwargs_0 = {
        'paths': 'paths',
        'skip': True
    }
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)



# Generated at 2022-06-25 10:44:27.286278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = LookupModule(False)
    str_0 = None
    str_1 = None
    str_3 = None
    str_4 = None
    str_2 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None

    # Test case 4

# Generated at 2022-06-25 10:44:42.647882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/home/kazuhira/Projects/ansible/plugin/lookup/jboss/src/main/resources/../../../docs/jboss_deployment_descriptor.yml']
    variables_0 = {}
    kwargs_0 = {}
    arg_0 = terms_0[0]
    lookup_module_0._process_terms(arg_0, variables_0, kwargs_0)
    kwargs_0 = {'skip': True}
    arg_1 = terms_0[0]
    lookup_module_0._process_terms(arg_1, variables_0, kwargs_0)
    lookup_module_0.run(terms_0, variables_0, skip=True)

# Generated at 2022-06-25 10:44:45.593876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tp = {}
    tp['terms'] = 'test'
    tp['variables'] = [[1,2,3]]
    assert(LookupModule.run(tp))

# Generated at 2022-06-25 10:44:54.763572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case 1
    kwargs = {'skip': True}
    lookup_module_0.run([['bar']], {}, **kwargs)

    # test case 2
    kwargs = {'skip': True}
    lookup_module_0.run([{'files': 'foo', 'paths': 'bar'}], {}, **kwargs)

    # test case 3
    kwargs = {'skip': True}
    lookup_module_0.run([{'files': 'foo,bar'}], {}, **kwargs)

    # test case 4
    kwargs = {'skip': True}
    lookup_module_0.run([{'files': 'foo', 'paths': 'bar:baz'}], {}, **kwargs)

   

# Generated at 2022-06-25 10:45:05.059573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_list_0 = ['lookup_module_0', 'lookup_module_1', 'lookup_module_2', 'lookup_module_3', 'lookup_module_4']
    variables_dict_0 = {'inventory_hostname': 'inventory_hostname_1', 'vars': {'name': 'name_1', 'priority': 'priority_1', 'version': 'version_1'}, 'foo': 'foo_1', 'bar': 'bar_1', 'foo_bar': 'foo_bar_1'}
    kwargs_dict_0 = {} # Empty dict
    ret_val = lookup_module_0.run(terms=terms_list_0, variables=variables_dict_0, **kwargs_dict_0)
    assert isinstance

# Generated at 2022-06-25 10:45:05.760450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:45:15.152611
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup_module_0 = LookupModule()
    terms_0 = [
        'file1',
        'file2',
        'file3',
        'file4',
        'file5',
        'file6',
        'file7',
        'file8',
        'file9',
        'file10',
    ]
    variables_0 = {
        'playbook_dir': '/usr/local/ansible/playbooks',
        'roles_path': '/usr/local/ansible/playbooks/roles:/etc/ansible/roles:/usr/share/ansible/roles',
    }

    # Invoke method
    result_0 = lookup_module_0.run(terms_0, variables_0)

    # Check

# Generated at 2022-06-25 10:45:25.283414
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check first_found lookup find a file in a given path
    lookup_module_0 = LookupModule()
    terms_0 = ['/test/example']
    variables_0 = { }
    kwargs_0 = { }
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == ['/test/example']

    # Check first_found lookup find a file in a given path
    lookup_module_1 = LookupModule()
    terms_1 = ['/test/example']
    variables_1 = { }
    kwargs_1 = { 'files': ['foo.txt', 'bar.txt'] }
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == ['/test/example']

    # Check first_found lookup find

# Generated at 2022-06-25 10:45:30.933867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo.txt', {'files': ['bar.txt']}]
    variables = {}
    kwargs = {'errors': 'ignore', 'skip': True}
    lookup_module = LookupModule()

    path = '/path/to/foo.txt'
    lookup_module._templar.template = lambda x: path if path in x else x
    lookup_module.find_file_in_search_path = lambda a, b, c, d=None: path
    total_search, skip = lookup_module._process_terms(terms, variables, kwargs)
    assert total_search == [path]

    path = None
    lookup_module._templar.template = lambda x: path if path in x else x

# Generated at 2022-06-25 10:45:33.586385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-25 10:45:43.673213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={})
    lookup_module_0._templar.template = lambda x: x

    # parametrized tests

# Generated at 2022-06-25 10:45:54.222875
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    terms_0 = ['bar.txt']
    variables_0 = {'homedir': '/home/vagrant'}
    var_1 = lookup_run(terms_0, variables_0, lookup_module_0)

    # Assert
    assert var_1 == ['/home/vagrant/files/bar.txt']


# Generated at 2022-06-25 10:45:57.449714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    set_0 = {lookup_module_0}
    var_0 = lookup_run(dict_0, set_0)
    assert len(var_0) == 0

# vim:ft=python

# Generated at 2022-06-25 10:46:06.424240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with just one term
    terms = ['some/file', 'other/file']
    variables = {'_ansible_lookup_dirs': ['.']}
    result = get_LookupModule().run(terms, variables)
    assert len(result) == 1 and result[0] == 'some/file'
    # Test with more than one term
    terms = ['some/file', 'other/file', 'another/file']
    variables = {'_ansible_lookup_dirs': ['.']}
    result = get_LookupModule().run(terms, variables)
    assert len(result) == 1 and result[0] == 'some/file'
    # Test with multiple terms and lookup-dir
    terms = ['some/file', 'other/file', 'another/file']

# Generated at 2022-06-25 10:46:06.881046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:46:17.193748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_case_1 = {}
    try:
        lookup_module_1.run(terms=dict, variables=dict, *args, **kwargs)
    except AnsibleLookupError:
        pass
    else:
        assert False
    try:
        lookup_module_1.run(terms=list, variables=list, *args, **kwargs)
    except AnsibleLookupError:
        pass
    else:
        assert False
    try:
        lookup_module_1.run(terms=set, variables=set, *args, **kwargs)
    except AnsibleLookupError:
        pass
    else:
        assert False

# Generated at 2022-06-25 10:46:21.384253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj_0 = WrappedLookupModule()
    assert isinstance(lookup_obj_0, LookupBase)



# Generated at 2022-06-25 10:46:32.051962
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:46:36.717938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest


# Generated at 2022-06-25 10:46:39.194864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0}
    try:
        lookup_module_0.run(terms=[], variables={})
    except AnsibleLookupError:
        raise AssertionError

# Generated at 2022-06-25 10:46:50.177326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_0 = ['', '', '', '', '', '', '', '', '', '', '', 'a', 'b', 'c', '', '', '', '', '', '', '', '']
    variable_0 = {}
    variable_1 = {'errors': ['ignore']}
    variable_2 = {'errors': ['ignore']}
    variable_3 = {'errors': ['ignore']}
    variable_4 = {'errors': ['ignore']}
    variable_5 = {'errors': ['ignore']}
    variable_6 = {'errors': ['ignore']}
    variable_7 = {'errors': ['ignore']}
    variable_8 = {'errors': ['ignore']}
    variable_9 = {'errors': ['ignore']}
   

# Generated at 2022-06-25 10:46:55.601321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # NOTE: no params in constructor
    assert lookup_module.run('', '')

# Generated at 2022-06-25 10:47:04.183408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "fQr6b"
    variables_0 = {'file': 'ip.txt', 'ut_var_1': 'vxPpX', 'src': 'file.txt', 'inventory_hostname': 'localhost'}
    kwargs_0 = {'skip': False, 'terms': 'fQr6b', 'dest': '/etc/foo.conf'}
    lookup_run(terms_0, variables_0, kwargs_0)


# Generated at 2022-06-25 10:47:10.450183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'files': 'foo', 'paths': 'bar', 'skip': True})
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar = None
    dict_0 = {}
    set_0 = {lookup_module_0}
    var_0 = lookup_run(dict_0, set_0)
    assert var_0 == []



# Generated at 2022-06-25 10:47:15.469788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    set_0 = {lookup_module_0}
    var_0 = lookup_run(dict_0, set_0)


# Generated at 2022-06-25 10:47:19.915729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'files': [], 'paths': [], 'skip': False})
    terms_0 = []
    variables_0 = {}
    lookup_run(terms_0, variables_0)


# Generated at 2022-06-25 10:47:23.346176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    set_0 = {lookup_module_0}
    var_0 = lookup_run(dict_0, set_0)

# Generated at 2022-06-25 10:47:26.720227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_1 = ['test' * 5, 'test' * 5, 'test' * 5, 'test' * 5, 'test' * 5]
    var_0 = test_lookup_module(lookup_module_0, term_1)


# Generated at 2022-06-25 10:47:33.294357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module = LookupModule()
    # Assume
    assert isinstance(lookup_module, LookupModule)
    # Act
    dict={}
    set={lookup_module}
    var = lookup_run(dict, set)
    # Assert
    assert var == []


# lookup plugins must implement the run method and can optionally implement the
# methods search_in_path and get_loader.  The lookup_run function is used by
# Ansible to execute the lookup.  This function is provided a dictionary of
# variables accessible to Ansible which can be used to perform templating on the
# lookup arguments.  The lookup function returns a Python list.

# Generated at 2022-06-25 10:47:35.889645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    tuple_0 = (None,)
    res_0 = module_0.run(list_0, dict_0, terms=tuple_0)


# Generated at 2022-06-25 10:47:40.561295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_0.run([],{})
    var_1 = lookup_module_1.run([],{})
    var_2 = lookup_module_2.run([],{})


# Generated at 2022-06-25 10:47:46.791554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_module_0.run(str_0, lookup_module_0, **str_0)


# Generated at 2022-06-25 10:47:57.030591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0, str_1, str_2, str_3, str_4, func_0, var_0, var_1, var_2, var_3, var_4 = ('' for i in range(11))
    var_0 = [var_1]
    var_2 = 'first_found'
    var_3 = [var_4, 'test_Namespace_0']
    var_0 = lookup_run(var_1, var_2, var_3, str_0, str_1, str_2, str_3, str_4, func_0)


# Generated at 2022-06-25 10:47:59.682087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = ''
    str_1 = str_0
    dict_0 = {}
    dict_1 = dict_0
    ret_0 = lookup_module_1.run(str_1, dict_1)
    assert type(ret_0) == list



# Generated at 2022-06-25 10:48:10.008997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    var_0 = lookup_module_0.run(str_0, str_1)
    str_0 = 'var_0'
    str_1 = 'var_1'
    var_1 = lookup_module_0.run(str_0, str_1)
    str_0 = 'var_2'
    str_1 = 'var_3'
    var_2 = lookup_module_0.run(str_0, str_1)
    str_0 = 'var_4'
    str_1 = 'var_5'
    var_3 = lookup_module_0.run(str_0, str_1)
    str_0 = 'var_6'

# Generated at 2022-06-25 10:48:19.701311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # var_0 = '-d debug_facts=True'

    # cwd = 'file:///mnt/c/Users/Harry-Laptop/Documents/ansible_tower_projects/ansible_monkey/the_project'
    cwd = '/mnt/c/Users/Harry-Laptop/Documents/ansible_tower_projects/ansible_monkey/the_project'

    # vars = {'debug_facts': True, 'ansible_config': '~/.ansible.cfg'}
    # found = lookup_module_0.run(var_0, vars)
    # print('found = ' + str(found))

    # path = lookup_module_0.find_file_in_search_path('test', subdir=cwd, check=False)


# Generated at 2022-06-25 10:48:30.207637
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    assert (os.path.exists('ansible.cfg'))
    assert (not os.path.exists('/etc/ansible/ansible.cfg'))
    param1_0 = ('',)
    param2_0 = ('',)
    param3_0 = {'files':['ansible.cfg']}
    lookup_module_0 = LookupModule()
    lookup_module_0._lookup_plugin_class = LookupBase
    lookup_module_0.set_options(var_options={'ansible_config_file':'/etc/ansible/ansible.cfg'}, direct=param3_0)

    # run

# Generated at 2022-06-25 10:48:35.074868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    var_0 = lookup_run(str_0, str_1)


# Generated at 2022-06-25 10:48:43.000902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = ''
    str_1 = 'test_value'
    dict_1 = dict()
    dict_1['test_key'] = 'test_value'
    list_0 = list()
    list_0.append('test_value')
    var_0 = lookup_run(str_0, str_1, dict_1, list_0)
    str_2 = 'test_key'
    str_3 = 'test_value'
    var_1 = lookup_run(str_2, str_3)
    str_4 = ''
    str_5 = 'test_value'
    var_2 = lookup_run(str_4, str_5)
    str_6 = ''
    var_3 = lookup_run(str_6)


# Generated at 2022-06-25 10:48:54.150320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'foo'
    str_2 = 'bar'
    assert 'foo' in lookup_module_1.run(str_1, str_2)
    str_3 = 'ansible'
    str_4 = 'docs'
    var_1 = lookup_module_1.run(str_3, str_4)
    assert 'docs' in var_1
    str_5 = 'bar'
    str_6 = 'foo'
    var_2 = lookup_module_1.run(str_5, str_6)
    assert 'foo' not in var_2
    str_7 = 'hello'
    str_8 = 'world'
    var_3 = lookup_module_1.run(str_7, str_8)

# Generated at 2022-06-25 10:48:57.163457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    list_0 = list()
    dict_0 = dict()
    var_0 = lookup_module_0.run(list_0, dict_0)



# Generated at 2022-06-25 10:49:04.457336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: everything below is not up to date
    # TODO: update
    # TODO: fix
    assert True is False
    # lookup = LookupModule()
    # assert lookup.run('#', '#') is None

# Generated at 2022-06-25 10:49:08.918495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    dict_2 = {}
    dict_3 = {}
    var_0 = lookup_module_0.run(str_0, str_0, **dict_2, **dict_3)


# Generated at 2022-06-25 10:49:15.342987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize class arguments
    terms_0 = ['files_0', 'files_1']
    terms_1 = ['files_0', 'files_1']

    # Run method
    returned = LookupModule.run(terms_0, terms_1)

    # Check if result is correct type
    assert isinstance(returned, list)

    # Check if result is correct value
    assert returned == ['files_0']  # TODO: test case


# Generated at 2022-06-25 10:49:21.327006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '<path>'
    file_1 = 'dummy_file'
    str_1 = 'file'
    str_2 = ''
    var_1 = lookup_run(str_0, str_0)
    var_0 = lookup_run(str_1, str_2)
    var_2 = lookup_run(file_1, str_2)
    str_3 = '<path>'
    str_4 = 'file'
    str_5 = ''
    var_3 = lookup_run(str_3, str_4)
    assert var_0 == []
    assert var_1 == []
    assert var_2 == []
    assert var_3 == []


# Generated at 2022-06-25 10:49:22.547136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = ''
# # TODO: place an assertion here


# Generated at 2022-06-25 10:49:27.705971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    # TBD: Create a terms having a value of a list type
    var_0 = lookup_run(str_0, str_0)


# Generated at 2022-06-25 10:49:30.572907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    var_0 = lookup_run(str_0, str_1)
    assert var_0 == [var_0]

# Generated at 2022-06-25 10:49:33.074120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    var_0 = lookup_module_0.run(str_0, str_1)

# Generated at 2022-06-25 10:49:34.526873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    var_0 = lookup_run(str_0, str_1)
    assert var_0 == None

# Generated at 2022-06-25 10:49:41.734355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = ''
    str_21 = ''
    str_22 = ''
    str_23 = ''
    str_24 = ''
    str_25 = ''
    str_26 = ''


# Generated at 2022-06-25 10:49:48.101845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_0 = 'files/foo'
    str_0 = 'files'
    os_path_join_0 = os.path.join(str_0, file_0)

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, str_0)



# Generated at 2022-06-25 10:49:53.664072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'foo'
    dict_0 = dict()
    dict_0['foo'] = str_0
    dict_0['bar'] = str_0
    str_1 = 'bar'
    dict_1 = dict()
    dict_1[str_0] = dict_0
    dict_1[str_1] = dict_0
    dict_1['baz'] = str_1
    list_0 = list()
    list_0.append(dict_1)
    list_0.append(dict_1)
    lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 10:49:56.623717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)
    assert '_raw' == var_0[0]

# Unit test case for LookupModule

# Generated at 2022-06-25 10:50:03.523120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'b.txt'
    str_2 = '/tmp/a.txt'
    str_3 = 'b.txt'
    list_1 = [str_1]
    dict_1 = {"files":list_1,"paths":[str_2]}
    str_4 = 'bar.txt'
    list_2 = [str_3, str_4]
    dict_2 = {"files":list_2,"paths":[str_2]}
    dict_3 = {'results':['file_path']}
    dict_4 = {'results':['file_path']}
    var_1 = lookup_run(str_4, dict_2)
    # ['/tmp/bar.txt']

# Generated at 2022-06-25 10:50:08.066341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:50:16.964623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    termin_0 = [str_0, str_0, str_0]
    var_0 = lookup_run(termin_0, str_0)
    str_1 = 'unknown-var'
    termin_0 = [str_1, str_0]
    var_1 = lookup_run(termin_0, str_1)
    str_2 = 'unknown-var'
    termin_1 = [str_2, [str_2, str_0]]
    var_1 = lookup_run(termin_1, str_1)

# Generated at 2022-06-25 10:50:27.376726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    # AssertionError: expected AnsibleLookupError('No file was found when using first_found.'), got None
    var_0 = lookup_run(str_0, str_0)
    return var_0

# TODO: refactor to use 'files' and 'paths' as the option (as documented) and a list as a term.

# TODO: this needs real unit testing
# TODO: add compat option to return the found file or path
# TODO: additional notes
# TODO: seems that 'term' is treated as a list or a file name or path to file (with optional subdir prepended)
# this is not documented and should be fixed.

# TODO: if files is a list but paths is a string, does paths split on comm

# Generated at 2022-06-25 10:50:37.465502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assume
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar = None
    # verify
    assert lookup_module_0._get_file_in_search_path('', '', '', False) == None
    lookup_module_0._get_file_in_search_path('', '', '', True) == None
    # assume
    lookup_module_0._loader = None
    # verify
    assert lookup_module_0._get_file_loader_path('', '', '', False) == None
    lookup_module_0._get_file_loader_path('', '', '', True) == None
    # assume
    lookup_module_0._loader = None
    lookup_module_0._searchpath = None


# Generated at 2022-06-25 10:50:40.411706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    lookup_module_0._run(str_0, str_0)

# Generated at 2022-06-25 10:50:46.089325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'str_0'
    var_0 = lookup_run(str_0, str_0)
    assert_equals(var_0, ['/var/tmp/str_0'])


# Generated at 2022-06-25 10:50:58.761197
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except AnsibleLookupError:
        pass

    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = {}
    kwargs_1 = {}
    bool_0 = True
    try:
        lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    except AnsibleLookupError:
        bool_0 = False
    assert bool_0


# Generated at 2022-06-25 10:51:09.419169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    str_1 = ''
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    str_2 = 'files'

# Generated at 2022-06-25 10:51:12.962568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_module_0.run(str_0, str_0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')


# Generated at 2022-06-25 10:51:17.001211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    str_0 = ''
    # verify case 0
    lookup_module_0.set_options(str_0, str_0)
    # assert that case 0 passes
    assert(lookup_module_0.run(str_0, str_0, str_0) == 1)

# Generated at 2022-06-25 10:51:18.830379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = ''
    var_0 = lookup_module.run(str_0, str_0, str_0)


# Generated at 2022-06-25 10:51:20.625124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    var_0 = lookup_run(str_0, str_1)



# Generated at 2022-06-25 10:51:22.474653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_module_0.run([str_0], str_0)


# Generated at 2022-06-25 10:51:23.783406
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: Enforce check-in of unit tests

    # there is no module to test at this time
    pass

# Generated at 2022-06-25 10:51:30.549769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'a/b/c'
    str_2 = 'a/b'
    str_3 = 'a'
    str_4 = 'b'
    str_5 = 'a/b/b'
    str_6 = 'a/b/a'
    str_7 = 'a/a/b'
    var_1 = lookup_run(str_1, str_2)
    var_2 = lookup_run(str_1, str_3)
    var_3 = lookup_run(str_1, str_4)
    var_4 = lookup_run(str_1, str_5)
    var_5 = lookup_run(str_1, str_6)

# Generated at 2022-06-25 10:51:39.012513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'skip': True})
    # Case 1: No files found
    lookup_module.set_options(var_options={}, direct={'files': [], 'paths': []})
    assert_equal(lookup_module.run([''], {}), [])
    # Case 2: A file found
    lookup_module.set_options(var_options={}, direct={'files': ['file1'], 'paths': []})
    assert_equal(lookup_module.run([''], {}), ['file1'])

# Generated at 2022-06-25 10:52:01.297242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_path_0 = '/'
    lookup_module_0 = LookupModule()
    str_0 = '/'
    var_0 = lookup_module_0.run(str_0, file_path_0)
    print(var_0)

# Generated at 2022-06-25 10:52:06.326744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = {'files': 'file_path', 'paths': 'file_path'}
    lookup_module_0 = LookupModule(**args_0)
    str_0 = ''
    var_0 = lookup_module_0.run(str_0, str_0)


# Generated at 2022-06-25 10:52:09.811282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Variables used in test case
    str_0 = 'dummy'
    var_0 = lookup_run(str_0, str_0)
    return var_0



# Generated at 2022-06-25 10:52:12.472473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_module_0.run(str_0, str_0)

# Generated at 2022-06-25 10:52:17.018793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'foo'
    var_1 = lookup_run(str_1, str_1)
    str_2 = 'bar'
    var_2 = lookup_run(str_2, str_2)
    str_3 = ''
    var_3 = lookup_run(str_3, str_3)


# Generated at 2022-06-25 10:52:19.825980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    lookup_run(str_0, str_1, str_2)


# Generated at 2022-06-25 10:52:22.514195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  return_value = LookupModule.run(self, terms, variables, **kwargs)
  assert [return_value]


# Generated at 2022-06-25 10:52:29.443845
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # run unit tests
    test_cases = [
        (test_case_0)
    ]
    for i, test_case in enumerate(test_cases):
        test_case()
        print("Test case %d passed" % i)

    # run integration tests
    integration_test_cases = [
    ]

    for i, test_case in enumerate(integration_test_cases):
        test_case()
        print("Integration test case %d passed" % i)

# Generated at 2022-06-25 10:52:32.972886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 10:52:37.770463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    lookup_module_0.set_options(var_options=str_0, direct={'files': str_0, 'paths': str_1})
    str_2 = ''
    str_3 = ''
    var_0 = lookup_module_0.run(str_0, str_0)
