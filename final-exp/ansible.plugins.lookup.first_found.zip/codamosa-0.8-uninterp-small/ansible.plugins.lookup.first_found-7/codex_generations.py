

# Generated at 2022-06-25 10:43:16.839016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Assertions
    # AssertionError: could not locate file in lookup: 'foo'
    lookup_module_0.run(['foo'], None)

# Generated at 2022-06-25 10:43:28.071832
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_case_0
    lookup_module_0 = LookupModule()
    test_terms_0 = ['test_file_0']
    test_variables_0 = {}

    # Test template lookup
    try:
        lookup_module_0._templar = None
        result = lookup_module_0.run(test_terms_0, test_variables_0)
        assert result == []
    except (AnsibleLookupError, AnsibleUndefinedVariable, UndefinedError):
        pass

    # Test non-template lookup

# Generated at 2022-06-25 10:43:31.830406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['file1', {'skip': True}]
    variables = []
    status = lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:43:34.969424
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create test LookupModule object
    lookup_module_1 = LookupModule()


    # unit test calls with arguments
    terms = ['foo', 'bar', 'biz']
    variables = dict()

    path = lookup_module_1._terms
    lookup_module_1.run(terms, variables, kwargs=path)

    # assert statements to test method run
    assert True

# Generated at 2022-06-25 10:43:44.583287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/ansible/hosts', './hosts', 'foo.txt']
    variables_0 = dict()
    path_0 = lookup_module_0.run(terms_0, variables_0)
    path_1 = lookup_module_0.run(terms_0, variables_0)
    path_2 = lookup_module_0.run(terms_0, variables_0)
    assert path_0 and path_1 and path_2
    assert path_0[0] and path_1[0] and path_2[0]
    assert os.path.exists(path_0[0])
    assert os.path.exists(path_1[0])
    assert os.path.exists(path_2[0])

# Generated at 2022-06-25 10:43:50.238886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._subdir = 'test'
    lookup_module._basedir = 'test/test_lookup_fixtures/test_0'
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing : 'test/test_lookup_fixtures/test_0/test_file' if fn == 'test_file' else None

    result = lookup_module.run(['test_file'], {}, skip=False)
    assert result == ['/home/ansible/ansible/test/test_lookup_fixtures/test_0/test_file']

# Generated at 2022-06-25 10:43:57.949096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['']
    kwargs = {'errors': 'ignore'}
    lookup_module_0.vars = {'test_var': {'test_dict': {'test_list': []}}, 'test_list': []}
    lookup_module_0.loader = {'lookup_loader': {}}
    output_0 = lookup_module_0.run(terms_0, variables, **kwargs)
    # AssertionError: None != []
    assert output_0 == [], "Output of Run does not match expected value"


# Generated at 2022-06-25 10:44:02.315471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # invalid terms
    terms = (1, 2, 3)
    variables = {}
    lookup_module.run(terms, variables)

    terms = ( {'files': 'f1'}, 1)
    lookup_module.run(terms, variables)

    # valid terms
    terms = {'files': 'f1'}
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:44:10.164352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run("", test_case_0())
    lookup_module_run_1 = LookupModule()
    lookup_module_run_1.run("", "")
    lookup_module_run_2 = LookupModule()
    lookup_module_run_2.run("", test_case_0())


# Generated at 2022-06-25 10:44:20.668176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test invalid kwarg handling
    terms_1 = ['terms_1']
    variables_1 = {'current_task': 'current_task_1', 'vars': {'fact1': 'value1', 'fact2': 'value2'}}
    kwargs_1 = {'kwarg_1': 'value1'}
    # test missing file handling
    terms_2 = 'missing.krb5.cfg'
    variables_2 = {'current_task': 'current_task_2', 'vars': {'fact1': 'value1', 'fact2': 'value2'}}
    kwargs_2 = {'files': ['missing.krb5.cfg'], 'paths': ['/tmp/does-not-exist/']}
    # test missing path

# Generated at 2022-06-25 10:44:33.243729
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test example 1:
    lookup_module_1 = LookupModule()
    lookup_module_1._subdir = 'files'
    lookup_module_1._templar = None
    assert lookup_module_1.run(terms=['foo'], variables={}) == []

    # test example 2:
    lookup_module_2 = LookupModule()
    lookup_module_2._subdir = 'files'
    lookup_module_2._templar = None
    assert lookup_module_2.run(terms=[{'files': 'foo', 'skip': True}], variables={}) == []

    # test example 3:
    lookup_module_3 = LookupModule()
    lookup_module_3._subdir = 'files'
    lookup_module_3._templar = None

# Generated at 2022-06-25 10:44:41.397137
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init
    lookup_module_0 = LookupModule()

    # set params
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}

    # call
    # NOTE: this should fail, to do this first_found will try to find this file in the current directory.
    # In this case it won't be there, so it will raise an exception
    return_value = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:44:45.774973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/ansible/hosts']
    variables_0 = {}

    assert lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:44:49.958634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module = LookupModule()
        assert lookup_module.run(terms=None, variables=None, **{'files': 'comma separated filenames', 'paths': 'comma separated paths', 'skip': True}) is None

# Generated at 2022-06-25 10:44:56.469450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = _split_on("test:test2", ["test:test3"])
    total_search_3, skip_4 = lookup_module_1._process_terms(terms_2, None, None, )
    assert total_search_3 == ["test2"]

# Generated at 2022-06-25 10:44:59.409226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    total_search, skip = lookup_module_0._process_terms(['test_dir/test_file'], 'test_variables', 'test_kwargs')
    assert total_search == ['test_dir/test_file']

# Generated at 2022-06-25 10:45:08.551749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._subdir = None
    lookup_module_1._loader = None
    lookup_module_1._templar = None
    lookup_module_1.set_options = None
    lookup_module_1.get_option = None
    lookup_module_1.find_file_in_search_path = None
    terms_1 = []
    variables_1 = []
    kwargs_1 = {}
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == []



# Generated at 2022-06-25 10:45:15.886923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar._available_variables = {}
    lookup_module_0._templar._available_variables = {'ansible_virtualization_type': 'docker'}
    lookup_module_0.run(['foo.conf'], lookup_module_0._templar._available_variables, skip=False)


# Generated at 2022-06-25 10:45:20.355524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    x = lookup_module.run(terms=['a', 'b', 'c'], variables={})
    assert x == []
    assert lookup_module._loader_rx.regex.pattern == '.*(\\.yml|\\.yaml)$'

# Generated at 2022-06-25 10:45:23.872279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['bar.txt']
    variables_1 = {'inventory_hostname': 'host1'}
    lookup_module_1.run(terms_1, variables_1)

# Generated at 2022-06-25 10:45:44.516518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = [
    'foo',
    {
        "files": [
            "foo",
            "bar"
        ]
    },
    'foo',
    {
        "paths": [
            "foo",
            "bar"
        ],
        "skip": True
    },
    'foo',
    {
        "files": [
            "foo",
            "bar"
        ],
        "paths": [
            "foo",
            "bar"
        ],
        "skip": True
    },
    'foo'
  ]
  variables = {}
  kwargs = {
    'files': [
      "foo",
      "bar"
    ],
    'skip': True,
    'paths': [
      "foo",
      "bar"
    ]
  }
  lookup

# Generated at 2022-06-25 10:45:47.914649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options = {}, direct = {'files':['foo', 'bar'], 'paths':['somewhere', 'otherside']})
    assert False == lookup_module.run([],{})


# Generated at 2022-06-25 10:45:52.617004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([{
        'paths': ['/some/path1', '/some/path2'],
        'files': ['file.txt']
    }], {'some_var': 'some_value'}) == ['/some/path1/file.txt']

# Generated at 2022-06-25 10:46:02.999172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit: test run when values exists in multiple files
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={})
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run([""], {}, files=[""], paths=[])
    # Unit: test run when no matching files are there
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={}, direct={})
    with pytest.raises(AnsibleLookupError):
        lookup_module_1.run([""], {}, files=[""], paths=[])
    # Unit: test run when values exists in a file
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options

# Generated at 2022-06-25 10:46:13.879074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    templar_0 = Templar(loader=None, variables={})
    ansible_variable_1 = {"src": "../../../../../../../../../home/cloud/.ansible/rabbitmq/.ssh/id_rsa", "dest": "~/.ssh/id_rsa"}
    terms_0 = [{"files": ["id_rsa"]}]
    test_Runner_result_0 = {"test": {"hosts": ["localhost"], "vars": {"hostvars": {"localhost": {"ansible_connection": "local"}}}}}
    runner_0 = ansible_variable_1
    search_path_0 = 'files'
    test_lookup_base_filename_0 = 'id_rsa'
    # OK for our testcase

# Generated at 2022-06-25 10:46:15.321186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run test
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=None, variables=None, **{})

# Generated at 2022-06-25 10:46:15.738702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-25 10:46:20.761783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()

    lookup_module_0.run([], {})

    lookup_module_1.run(["/usr/bin/file"], {'vars': {}})


# Generated at 2022-06-25 10:46:23.553376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run method run of LookupModule with simple argument
    # test with module
    lookup_module_0 = LookupModule()
    #assert_equal (lookup_module_0.run('C(foo)', 'C(bar)'), '')


# Generated at 2022-06-25 10:46:34.374862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # init return values
    p = ['foo']
    l = ['bar']
    total = [os.path.join(w, z) for z in p for w in l]
    # first match
    lookup_module.find_file_in_search_path = lambda x, y, z, **kwargs: total[0] if z == total[0] else ''
    lookup_module._templar = lambda z: z
    lookup_module.get_option = lambda x: [p, l] if x == 'files' else []

    # should be ok with string terms due to intro of _process_terms
    # first match found
    assert lookup_module.run(['foo', 'bar'], {}) == [total[0]]

    # no match
    lookup_module.find_file

# Generated at 2022-06-25 10:46:49.700285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(dict_0, dict_0)
    print(var_0)
    dict_1 = {}
    var_1 = lookup_run(dict_1, dict_1)
    print(var_1)

# Generated at 2022-06-25 10:46:56.867267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {'foo': ''}
    dict_2 = {'foo': ''}
    dict_3 = {'foo': 'bar'}
    dict_4 = {'foo': 'bar'}
    dict_5 = {'foo': 'bar'}
    dict_6 = {'foo': 'bar'}
    dict_7 = {'foo': 'bar'}
    dict_8 = {'foo': 'bar'}
    dict_9 = {'foo': 'bar'}
    dict_10 = {'foo': 'bar'}
    dict_11 = {'foo': 'bar'}
    dict_12 = {'foo': 'bar'}
    dict_13 = {'foo': 'bar'}
    dict_14 = {'foo': 'bar'}


# Generated at 2022-06-25 10:47:02.960515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    dict_0['files'] = 'files'
    dict_0['paths'] = 'paths'
    dict_0['skip'] = 'skip'
    var_0 = lookup_run(dict_0, dict_1)


# Generated at 2022-06-25 10:47:05.139423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {}
    variables_0 = {}
    kwargs_0 = {}
    path_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert path_0 is None

# Generated at 2022-06-25 10:47:14.258873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {'item': {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}}
    var_0 = {'lookup_file_in_search_path': lookup_file_in_search_path, 'lookup_file': lookup_file, 'lookup_jinja2_templa': lookup_jinja2_templa, 'lookup_jinja2_native': lookup_jinja2_native}
    var_0 = {'item': {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS'}, 'kwargs': {'skip': False, 'errors': 'strict', 'paths': [], 'files': ['foo', 'bar']}}

# Generated at 2022-06-25 10:47:18.315924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    dict_2 = {'files': '', 'paths': ''}
    dict_3 = {'files': '', 'paths': ''}
    list_0 = [dict_0, dict_1, dict_2, dict_3]
    var_0 = lookup_module_0.run(list_0, dict_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:47:25.107995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['files'] = 'files'
    dict_1['files'] = dict_2
    dict_0['files'] = dict_1
    dict_0['paths'] = 'paths'
    var_0 = LookupModule()
    var_0.run(dict_0)



# Generated at 2022-06-25 10:47:30.440397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'default'
    lookup_module_0._loader = 'default'
    lookup_module_0._templar = 'default'
    lookup_module_0.get_option = 'default'
    lookup_module_0.set_options = 'default'
    lookup_module_0.find_file_in_search_path = 'default'
    dict_0 = {}
    var_0 = lookup_run(dict_0, dict_0)

# Generated at 2022-06-25 10:47:37.629803
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1: if skip is false and no file was found when using first_found, it should raise an exception
    dict_1 = {}
    dict_1['_terms'] = ['/path/to/bar.txt']
    dict_1['skip'] = False
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleLookupError) as result_1:
        lookup_module_1.run(dict_1['_terms'], dict_1)

    # test case 2: if skip is True and no file was found when using first_found, it should return an empty list
    dict_2 = {}
    dict_2['_terms'] = ['/path/to/bar.txt']
    dict_2['skip'] = True
    lookup_module_2 = LookupModule()
    result_

# Generated at 2022-06-25 10:47:39.405271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(dict_0, dict_0)
    return var_0




# Generated at 2022-06-25 10:48:12.538585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    dict_1['files'] = None
    dict_1['paths'] = None
    dict_1['skip'] = None
    dict_2 = {}
    dict_2['files'] = None
    dict_2['paths'] = None
    dict_2['skip'] = None
    dict_3 = {}
    dict_3['files'] = None
    dict_3['paths'] = None
    dict_3['skip'] = None
    dict_4 = {}
    dict_4['files'] = None
    dict_4['paths'] = None
    dict_4['skip'] = None
    dict_4['_ansible_tmpdir'] = None
    dict_4['_ansible_no_log']

# Generated at 2022-06-25 10:48:17.716107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/passwd']
    variables_0 = {}
    lookup_module_0._load_name = None
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0.set_options = set_options
    lookup_module_0.get_option = get_option
    lookup_module_0.find_file_in_search_path = find_file_in_search_path
    var_0 = lookup_module_0.run(terms_0, variables_0)
    assert len(var_0) == 1 and var_0[0] == '/etc/passwd'



# Generated at 2022-06-25 10:48:25.844020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # (used by Ansible under certain conditions)
    loader = DataLoader()

    # Create inventory, use path to host config file as source or hosts in a comma separated string
    inventory = InventoryManager(loader=loader, sources='localhost,')

    # Set variables (can be done in other ways)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create play with tasks

# Generated at 2022-06-25 10:48:29.925151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run("", "", "", "", "")
    assert var_1 == None


# Generated at 2022-06-25 10:48:40.452580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
    dict_18 = dict_17
    dict_19 = dict_18
    dict_20 = dict_19


# Generated at 2022-06-25 10:48:45.428102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [True, False]
    subdir_0 = [True, True]
    var_0 = lookup_module_0.run(terms_0, subdir_0)
    assert var_0 != None


# Generated at 2022-06-25 10:48:48.493226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 10:48:50.182804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=[], variables={}) == []



# Generated at 2022-06-25 10:48:55.401812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_dict_1 = {}
    variables_dict_1 = {}
    lookup_dict_1 = {}
    var_0 = lookup_module_1.run(terms_dict_1, variables_dict_1, terms_dict_1)


# Generated at 2022-06-25 10:48:56.332052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    test_case_0()


# Generated at 2022-06-25 10:49:21.961739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    var_0 = lookup_run(dict_0, dict_1)



# Generated at 2022-06-25 10:49:33.616347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={u'paths': [u'foo', u'bar']})
    assert lookup_module_0.run(terms=[u'foo'], variables={}) == [[u'foo']]

    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={}, direct={u'paths': [u'foo', u'bar']})
    assert lookup_module_1.run(terms=[u'foo', u'bar'], variables={}) == [[u'foo', u'bar']]

    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:49:35.656653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(dict_0, dict_0)

# Generated at 2022-06-25 10:49:38.850186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(dict_0, dict_0)
    assert var_0 == None


# Generated at 2022-06-25 10:49:40.956728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(dict_0, dict_0)
    assert var_0 is not None


# Generated at 2022-06-25 10:49:51.512022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # should return ['file1.conf', 'file2.conf']
  lookup_module = LookupModule()
  terms = [{'files': 'file1.conf,file2.conf',
            'paths': '/etc/foo,/etc/bar'}]
  variables = {}
  kwargs = {}
  result = lookup_module.run(terms, variables, **kwargs)
  assert result == ['file1.conf', 'file2.conf']

  terms = [{'files': 'file1.conf,file2.conf',
            'paths': '/etc/foo,/etc/bar',
            'skip': True}]
  result2 = lookup_module.run(terms, variables, **kwargs)
  assert result2 == ['file1.conf', 'file2.conf']

  # should return ['file

# Generated at 2022-06-25 10:49:59.673192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test case with a list of file names (no paths)
    dict_0 = {'skip': False}
    dict_1 = {}
    dict_2 = {'files': ['file1'], 'paths': []}
    var_0 = lookup_run(dict_0, dict_1)
    var_1 = lookup_run(dict_2, dict_1)
    # Test case with a list of file names (with paths)
    dict_3 = {'skip': False}
    dict_4 = {}
    dict_5 = {'files': ['file2'], 'paths': ['/tmp/tests']}
    var_2 = lookup_run(dict_3, dict_4)
    var_3 = lookup_run(dict_5, dict_4)


# Generated at 2022-06-25 10:50:08.829271
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test case
    terms = [
        {
            'files': [
                'foo.txt',
                'bar.txt'
            ],
            'paths': [
                'path/to',
                'path/to/file'
            ]
        }
    ]
    variables = {}
    kwargs = {}

    # Return value
    return_value = lookup_module_0.run(terms, variables, **kwargs)


test_LookupModule_run()

# Generated at 2022-06-25 10:50:17.019804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [var_1, var_2]
    terms_1 = [var_1, var_2]
    var_3 = dir_name_0 = test_path_0 = roles_0 = None
    params_0 = var_2
    params_1 = var_2
    params_2 = var_2
    params_3 = var_2
    params_4 = var_1
    params_5 = var_1
    params_6 = var_1
    params_7 = var_1
    var_4 = lookup_run(params_0, test_case_0)
    var_5 = lookup_run(params_1, test_path_0)
    var_6 = lookup_run(params_2, roles_0)
    var_7

# Generated at 2022-06-25 10:50:27.478833
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # 1
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)

    # 2
    lookup_module_1 = LookupModule()
    dict_0 = {}
    var_1 = lookup_module_1.run(dict_0, dict_0)

    # 3
    lookup_module_2 = LookupModule()
    dict_0 = {}
    var_2 = lookup_module_2.run(dict_0, dict_0)

    # 4
    lookup_module_3 = LookupModule()
    dict_0 = {}
    var_3 = lookup_module_3.run(dict_0, dict_0)

    # 5
    lookup_module_4 = LookupModule()
    dict_

# Generated at 2022-06-25 10:51:28.260639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)
    if True:
        assert ((var_0 == []))

    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)
    dict_0 = {}
    var_0 = lookup_module_0.run(dict_0, dict_0)
    dict_0 = {}

# Generated at 2022-06-25 10:51:33.954382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    setup_loader()

    # setup test env
    temp_dir = tempfile.mkdtemp()
    base_path = os.path.join(temp_dir, "test_LookupModule_run")
    sub_path = os.path.join(base_path, "sub_path")
    os.mkdir(sub_path)
    os.makedirs(os.path.join(temp_dir, "files"))
    test_file = "foo.txt"
    test_file_path = os.path.join(base_path, test_file)
    with open(test_file_path, 'wt') as f:
        f.write('foo')

    test_file = "bar.txt"
    test_file_path = os.path.join(sub_path, test_file)

# Generated at 2022-06-25 10:51:44.473069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_2 = {"files": "files_0", "paths": "paths_0"}
    dict_3 = {}
    dict_3["files"] = ["files_0"]
    dict_3["paths"] = ["paths_0"]
    dict_3["paths"] = dict_3["paths"] + ["paths_1"]
    dict_4 = {"files": "files_0", "paths": "paths_0", "skip": "skip_0"}
    dict_5 = {}
    dict_5["files"] = ["files_0"]
    dict_5["paths"] = ["paths_0"]
    dict_5["paths"] = dict_5["paths"] + ["paths_1"]
    dict

# Generated at 2022-06-25 10:51:48.822378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_module_1 = lookup_module_2 = lookup_module_3 = LookupModule()
    lookup_module_4 = lookup_module_5 = lookup_module_6 = lookup_module_7 = lookup_module_8 = lookup_module_9 = LookupModule()
    #  test 'test_case_0'
    try:
        lookup_module_0._process_terms()
        assert False
    except TypeError:
        assert True
    try:
        lookup_module_1._process_terms(terms=dict_0)
        assert False
    except TypeError:
        assert True
    #  test 'test_case_1'

# Generated at 2022-06-25 10:51:50.649342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(terms=[['port.yml', '80', '443']])
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(**args) == ["80", "443"]

# Generated at 2022-06-25 10:51:57.555868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {"foo": "bar"}
    resul_0 = lookup_module_0.run(["foo"], dict_0)
    assert isinstance(resul_0)
    assert isinstance(resul_0, list)
    assert resul_0 == []


# Generated at 2022-06-25 10:52:07.752450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    dict = {}
    dict['items'] = ['item_1', 'item_2', 'item_3']
    dict['files'] = 'file_1, file_2, file_3'
    dict['paths'] = 'path_1:path_2:path_3'
    dict['skip'] = False

    lookup_module.set_options(dict)

    # test case if the given term is string and file present in the file path
    assert lookup_module.run('item_1', dict) == ['item_1']

    # test case if the given term is string and file not present in the file path
    assert lookup_module.run('item_4', dict) == []

    # test case if the given term is list and file present in the file path

# Generated at 2022-06-25 10:52:13.175439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['terms_0']
    variables_1 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables_1)
    test_result_0 = lookup_module_0.run(terms_0, variables_1)

    # assert test_result_0 == ['terms_0'], 'Expected ["terms_0"], but got: %s' % test_result_0



# Generated at 2022-06-25 10:52:22.288992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_0_terms = 'term_0'
    test_0_variables = 'variable_0'
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_0['test_0'] = test_0_terms
    dict_0['test_1'] = test_0_variables
    var_0 = lookup_run(dict_0, dict_0)
    return var_0



# Generated at 2022-06-25 10:52:32.702933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = {}
    dict_3 = {}
    dict_4 = dict_2
    dict_5 = dict_4

    dict_6 = dict_5

    dict_7 = {}
    dict_8 = dict_7

    dict_9 = dict_8

    dict_10 = dict_9

    dict_11 = dict_10

    dict_12 = dict_11

    dict_13 = dict_12

    dict_14 = dict_13

    dict_15 = dict_14

    dict_16 = dict_15

    dict_17 = dict_16

    dict_18 = dict_17

    dict_19 = dict_18

    dict_20 = dict_19

    dict_21 = dict