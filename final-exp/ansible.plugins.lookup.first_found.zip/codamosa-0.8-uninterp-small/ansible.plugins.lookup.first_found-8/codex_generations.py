

# Generated at 2022-06-25 10:43:18.667542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:43:28.558184
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # from https://docs.pytest.org/en/latest/getting-started.html#create-your-first-test
    terms = [
        '/path/to/foo.txt',
        'bar.txt',  # relative to role or play dir
        '/path/to/biz.txt'
    ]

    lookup_module_0 = LookupModule()
    original_method_0 = lookup_module_0.find_file_in_search_path
    lookup_module_0.find_file_in_search_path = lambda x,y,z,w: '/path/to/foo.txt'

    return_value = lookup_module_0.run(terms, 'just_a_string_that_should_never_be_used_as_variables')

# Generated at 2022-06-25 10:43:39.211878
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # load testcases
    with open('./lookup_plugins/tests/test_first_found.yml') as f:
        testcases = yaml.safe_load(f)

    # run tests
    lookup_module_0 = LookupModule()
    for case_name, testcase in testcases.items():
        if isinstance(testcase, dict) and 'skip' in testcase.keys():
            continue

        # load test data
        if isinstance(testcase, dict):
            params = testcase.get('params', [])
            expected = testcase.get('expected', [])
        else:
            params = testcase
            expected = None

        assert lookup_module_0.run(params, {}) == expected, \
            "failed test: %s" % case_name

# Generated at 2022-06-25 10:43:41.310248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('some_term', 'some_variable', skip=True) == []



# Generated at 2022-06-25 10:43:43.992169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ''
    variables = ''
    kwargs = ''
    assert lookup_module_0.run(terms, variables, kwargs) == 'test_data'

# Generated at 2022-06-25 10:43:51.413691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_file_path = 'my_file_path.txt'
    templar = 'my_templar'
    lookup_module._templar = templar
    lookup_module._loader = templar
    search_path = 'my_search_path'
    subdir = 'my_subdir'
    lookup_module._subdir = subdir
    file_found = True
    path = 'my_path'
    callback = 'my_callback'
    variables = 'my_variables'
    ansible_lookup_error = False
    terms = 'my_terms'
    kwargs = 'my_kwargs'
    lookup_module._process_terms = MagicMock(return_value = (terms, kwargs))
    lookup_module.find_file

# Generated at 2022-06-25 10:43:57.629896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    path_0 = ""
    status_0 = False
    return_value_0 = lookup_module_0.run(terms_0, variables_0, path_0, status_0)
    assert return_value_0 == None

# Generated at 2022-06-25 10:44:05.543035
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:44:16.416887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Method init return value
    lookup_module_0 = LookupModule()

    # Test cases
    lookup_module_0.set_options( direct={
        'files': ['file1', 'file2'],
        'paths': ['path1', 'path2'],
        'skip': False,
        'undefined_var': '{{ foo }}'
    })
    yield run_LookupModule_run, lookup_module_0, [''], {'foo': 'bar'}, AnsibleLookupError
    yield run_LookupModule_run, lookup_module_0, [], {}, AnsibleLookupError

# Generated at 2022-06-25 10:44:25.051395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initial params
    terms = [
        ['/etc/foo.conf', 'etc_foo.conf'],
        ['/etc/bar.conf', 'etc_bar.conf']
    ]
    variables = {'ansible_virtualization_type': 'foo', 'ansible_os_family': 'bar'}

    # run
    lookup_module = LookupModule()
    path = lookup_module.run(terms, variables)[0]
    assert path == '/etc/foo.conf'


# Generated at 2022-06-25 10:44:32.447162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    from ansible.module_utils.six import string_types
    try:
        type(str())
    except NameError:
        try:
            string_types()
        except NameError:
            pass
        else:
            raise Exception('Failed to catch NameError.')
    else:
        raise Exception('Failed to catch NameError.')


# Generated at 2022-06-25 10:44:41.591935
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    params = dict(files=['a.txt', 'b.txt', 'c.txt'], paths=['/tmp/p1', '/tmp/p2', '/tmp/p3'])
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._templar = MockTemplar()
    result = lookup.run([params])

    assert result == ['/tmp/p1/a.txt', '/tmp/p2/a.txt', '/tmp/p3/a.txt']



# Generated at 2022-06-25 10:44:52.822018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'Dw}#CYGD<.2/XQjEl{'
    str_2 = 'bJ<)y+AQ2N^|,;Oo-)'
    str_3 = 'Dw}#CYGD<.2/XQjEl{'
    str_4 = 'bJ<)y+AQ2N^|,;Oo-)'
    str_5 = 'j;L/&T/TJZMx/D1^QaN'
    str_6 = 'bJ<)y+AQ2N^|,;Oo-)'
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    lookup_module_1._loader = None
    lookup_module_1._basedir = None
   

# Generated at 2022-06-25 10:45:00.077059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 's&'
    str_1 = 'mT:+H"mWn'
    dict_0 = {str_0: str_0, str_0: str_0, str_1: str_0}
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 10:45:07.660199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    str_0 = '@7'
    dict_0 = {str_0: str_0, str_0: str_0}

    # Invoke method
    var_0 = lookup_module_0.run(str_0, dict_0, **dict_0)

    # Check assertions
    assert var_0 == []

# Generated at 2022-06-25 10:45:18.768014
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    import sys

    if 'first_found' not in sys.modules:
        pytest.skip('No first_found')

    if not sys.modules['first_found'].__loader__.is_package(sys.modules['first_found'].__name__):
        pytest.skip('first_found not a package')

    if not sys.modules['first_found.plugins'].__spec__.name.startswith('ansible.plugins.lookup'):
        pytest.skip('first_found not a lookup plugin')

    import ansible.plugins.lookup.first_found

    if not hasattr(ansible.plugins.lookup.first_found, 'LookupModule') or not ansible.plugins.lookup.first_found.LookupModule.__name__ == 'LookupModule':
        py

# Generated at 2022-06-25 10:45:24.568730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'Dw}#CYGD<.2/XQjEl{'
    dict_0 = {str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, dict_0, **dict_0)
    if (var_0 is None):
        raise Exception('AssertionError')


# Generated at 2022-06-25 10:45:27.672171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, dict_0, **dict_0)
    assert var_0 is None


# Generated at 2022-06-25 10:45:29.468297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0, dict_0, **dict_0)


# Generated at 2022-06-25 10:45:37.347720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We need to capture the output of run for a specific set of arguments for
    # test comparison.  We can't save any part of these as the file system
    # location is part of the test.
    #
    # In the short term we will leave this as a repeated string
    search_paths = ['/home/ansible/ansible/test/units/module_utils/ansible_test/_data/lookup_plugins/first_found/dir0',
                    '/home/ansible/ansible/test/units/module_utils/ansible_test/_data/lookup_plugins/first_found/dir1',
                    '/home/ansible/ansible/test/units/module_utils/ansible_test/_data/lookup_plugins/first_found/dir2']

# Generated at 2022-06-25 10:45:45.669744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    adict = {}
    terms = []
    variables = {}
    kwargs = {}
    lookup_module_1.run(terms, variables, **kwargs)



# Generated at 2022-06-25 10:45:51.271474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    set_1 = set()
    var_0 = lookup_run(set_0, set_1)
    

# Generated at 2022-06-25 10:45:56.754627
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    set_0 = set(['lookup_first_found_test_0.txt', 'lookup_first_found_test_1.txt'])
    str_0 = lookup_module_0.run(set_0, set_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:46:01.968237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test environment
    vars = dict()
    terms = dict()
    keywords = dict()
    set_0 = set()
    lookup_module_0 = LookupModule()
    lookup_run(set_0, set_0)


# Generated at 2022-06-25 10:46:06.122482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add tests for run
    assert False


# Generated at 2022-06-25 10:46:15.562281
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext

    set_0 = set()
    lookup_module_0 = LookupModule()

    terms_0 = set_0
    variables_0 = set_0

    lookup_module_0._subdir = 'files'
    lookup_module_0.set_options(var_options=variables_0, direct=set_0)

    var_0 = lookup_module_0.run(terms_0, variables_0)



# Generated at 2022-06-25 10:46:23.869714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_names = ["LookupModule", "Set", "Set", "LookupModule", "LookupModule"]
    param0 = [set(), {}, {}, {}, {'files': set(), 'paths': set()}]
    param1 = [{}, {}, {'files': set(), 'paths': set()}, {'files': set(), 'paths': set()}, {'files': set(), 'paths': set()}]
    param2 = [{}, {}, {'files': set(), 'paths': set()}, {'files': set(), 'paths': set()}, {'files': set(), 'paths': set()}]
    assert_raises(AnsibleLookupError, "test_case_0()", globals())

# Generated at 2022-06-25 10:46:27.298280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['foo'], None)
    lookup_module_0.get_option('files')



# Generated at 2022-06-25 10:46:29.913549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)

# Generated at 2022-06-25 10:46:33.562605
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    print("Testing lookup_module_run")
    # TODO: check returned results
    assert lookup_module_run(lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:46:46.403746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    set_0 = set()
    lookup_module_0 = LookupModule()

    # unit test for run of method LookupModule
    lookup_module_0.run([{'files': ['f'], 'paths': []}])

    # unit test for run of method LookupModule
    lookup_module_0.run([{'files': ['f'], 'paths': []}])

# Generated at 2022-06-25 10:46:48.568629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    var_1 = set()
    var_2 = lookup_module_0.run(var_0, var_1)


# Generated at 2022-06-25 10:46:52.896158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = 's'
    variables_0 = 's'
    kwargs_0 = {'s': 's'}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 10:47:03.867974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    local_var = os.path.join(sys.path[0], '../lookup_plugins/first_found.py')
    lookup_module_0 = LookupModule(local_var)
    test_terms = os.path.join(sys.path[0], '../lookup_plugins/')
    variables = ('foo', 'bar')
    paths = ('file', 'search', 'path')
    kwargs = {'f': 'bar', 'paths': paths, 'bar': 'baz', 'foo': 'foo'}
    set_0 = set()
    var_0 = lookup_module_0.run(test_terms, set_0, kwargs)
    assert len(var_0) == 1


# Generated at 2022-06-25 10:47:06.371017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    set_0 = lookup_module_0.run('bar.txt', 'foo.txt')


# Generated at 2022-06-25 10:47:10.702845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={}, direct={})
    var_1 = lookup_module_1.run(["/etc/passwd"])


# Generated at 2022-06-25 10:47:17.248590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n\n test_LookupModule_run:")

    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)

    print("\n\nvar_0.get(0): " + var_0.get(0))
    print("\n\nvar_0.get(1): " + var_0.get(1))
    print("\n\nvar_0.get(2): " + var_0.get(2))
    print("\n\nvar_0.get(3): " + var_0.get(3))
    print("\n\nvar_0.get(4): " + var_0.get(4))



# Generated at 2022-06-25 10:47:24.989256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #The method run() of LookupModule class need four parameters: terms, variables, **kwargs.
    terms = set()
    variables = set()
    kwargs = set()
    lookup_module_1 = LookupModule(terms, variables, kwargs)

    #The method run() of LookupModule instance can run successfully.
    assert True == lookup_module_1.run()


# Generated at 2022-06-25 10:47:28.684828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)



# Generated at 2022-06-25 10:47:34.002746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    set_1 = set()
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(set_1, set_1)



# Generated at 2022-06-25 10:47:48.456276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module_0 = LookupModule()
    terms_0 = set()

    # Act
    var_0 = lookup_module_0.run(terms_0, 0)

    # Assert
    assert var_0 == 0


# Generated at 2022-06-25 10:47:58.623829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'files': []}]

# Generated at 2022-06-25 10:48:01.003731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_name_0 = "/etc/motd"
    set_0 = set()
    set_0.add(file_name_0)
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)



# Generated at 2022-06-25 10:48:06.777432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    var_0 = set()
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_0.run(set_0, set_0)
    assert lookup_module_1._process_terms(set_0, set_0, var_0) == (var_0, var_0)

# Generated at 2022-06-25 10:48:15.030860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    lookup_module_1 = LookupModule()
    # Test if the method run of class LookupModule raises a ValueError when called with parameters var_1 and var_2
    with pytest.raises(ValueError):
        lookup_module_1.run(var_1, var_2)


# Generated at 2022-06-25 10:48:16.964736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)
    assert var_0 == set_0

# Generated at 2022-06-25 10:48:21.800141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set
    lookup_module_0 = LookupModule()
    var_0 = set_0()
    set_0 = set
    lookup_run = lookup_module_0.run
    var_1 = set_0()
    with pytest.raises(AnsibleLookupError):
        test_case_0()

# Generated at 2022-06-25 10:48:23.018024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    assert_equal(lookup_module_0.run(set_0, set_0), [])



# Generated at 2022-06-25 10:48:31.559311
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    # required for argument parsing
    lookup_module_0 = LookupModule()
    set_0 = set()

    # test
    with pytest.raises(AnsibleLookupError) as excinfo:
        var_0 = lookup_run(lookup_module_0, set_0, set_0)

    assert excinfo.value.message == "No file was found when using first_found."

# Generated at 2022-06-25 10:48:35.289769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)


# Generated at 2022-06-25 10:49:05.860293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    lookup_module_1._loader = None
    lookup_module_1._filter_loader = None
    lookup_module_1._terms = None
    lookup_module_1._options = None
    lookup_module_1._context = None
    lookup_module_1._display = None
    lookup_module_1._result = None
    lookup_module_1._plugin_data_cache = dict()
    lookup_module_1._plugin_data_cache['lookup_cache'] = None
    lookup_module_1._plugin_data_cache['lookup_templar'] = None
    lookup_module_1._plugin_data_cache['lookup_loader'] = None

# Generated at 2022-06-25 10:49:12.009970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    terms_1 = set_1
    variables_1 = set_1
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms_1, variables_1)
    except LookupError:
        pass


# Generated at 2022-06-25 10:49:15.090559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 10:49:17.926270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)
    try:
        var_0 = lookup_module_0.run(set_0)
    except:
        var_0 = False


# Generated at 2022-06-25 10:49:22.842165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)

    test_case_0()

# Generated at 2022-06-25 10:49:27.629259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)


# Generated at 2022-06-25 10:49:32.130310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    terms = set_0
    variables = set_0
    kwargs = set_0
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    assert var_0 is not None
    assert var_0 is not True
    assert var_0 is not False
    assert var_0 == []


# Generated at 2022-06-25 10:49:35.777129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)
    var_1 = lookup_run(set_0, set_0)
    var_2 = lookup_run(set_0, set_0)



# Generated at 2022-06-25 10:49:39.914922
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    set_0 = set()
    set_1 = set()

    # Act
    lookup_module_0 = LookupModule()
    actual_result_0 = lookup_module_0.run(set_0, set_1)

    # Assert
    assert(actual_result_0 is None)


# vim: filetype=python

# Generated at 2022-06-25 10:49:51.187740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None
    assert lookup_module.run(LookupModule, LookupModule) == None

# Generated at 2022-06-25 10:50:45.377348
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests for method run of class LookupModule with
    # parameters: (0) ([])
    test_case_0()
    # parameters: (0) ([])



# Generated at 2022-06-25 10:50:53.485018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)
    if var_0 is None:
        print(('Test Failed, Expected RetVal Not Found, Correct Functionality Not Verified'))
    else:
        print(('Test Passed, Expected RetVal Found, Functionality Verified, Expected RetVal = %s' % var_0))


# Generated at 2022-06-25 10:50:55.937364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, set_0)
    assert var_0 == []


# Generated at 2022-06-25 10:50:59.985725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: refactor to mock or pytest
    return
    lookup_module_0 = LookupModule()
    set_0 = set()
    set_0 = {'', None}
    set_1 = lookup_module_0.run(set_0, set_0, '9')


# Generated at 2022-06-25 10:51:03.769679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test vars
    test_terms = list()
    test_var = dict()
    test_kwargs = dict()
    test_module = LookupModule()

    # Run test
    test_module.run(test_terms, test_var, test_kwargs)

    # Assert
    assert True

# Generated at 2022-06-25 10:51:08.035450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    assert lookup_run(var_0, var_0).run(var_0, var_0) is None


# Generated at 2022-06-25 10:51:18.884431
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests if the method run is generating an exception when there are no arguments.
    # Should return a REQUIREMENT of nargs=1.
    set1 = set()
    lookup_module1 = LookupModule()
    with pytest.raises(AnsibleLookupError) as execinfo1:
       lookup_module1.run(set1, set1)
    assert 'nargs=1' in str(execinfo1.value)

    # Tests if the method run is generating a correct path when the file exists.
    # Should return the path of the file.
    set2 = set(["test.txt"])
    lookup_module2 = LookupModule()
    lookup_module2.set_loader(loader=MockLoader())
    file_path2 = lookup_module2.run(set2, set2)
    assert file_

# Generated at 2022-06-25 10:51:21.005278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:51:30.476810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._collections_compat import Mapping

    set_0 = set()
    assert issubclass(Mapping, object)

    lookup_module_0 = LookupModule()
    terms_0 = lookup_module_0._split_on(set_0, set_0)
    variables_0 = lookup_module_0._split_on(set_0, set_0)
    var_0 = lookup_run(terms_0, variables_0, set_0)
    var_1 = lookup_run(terms_0, variables_0, set_0)
    var_2 = lookup_run(terms_0, variables_0, set_0)
    assert var_2 == var_1
    assert var_1 == var_0

# Generated at 2022-06-25 10:51:35.591282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    path_0 = Path()
    var_0 = lookup_run(lookup_module_0, path_0)


# Unit tests for class LookupModule