

# Generated at 2022-06-25 10:43:27.935036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = Jinja2Template()
    lookup_module._templar._loader = DictLoader({})

    # setup params
    params = {
        'paths': 'foo,bar',
        'files': ['test1.yml', 'test2.yml'],
        'skip': True,
    }
    params_by_key = ['paths=foo,bar,files=test1.yml,test2.yml,skip=True'.split(',')]

    # setup templar
    lookup_module._templar.available_variables = {'foo': 'bar'}

    lookup_module.set_options(var_options={}, direct=params)
    # NOTE: the dict input 'test' does not allow a list of dicts

# Generated at 2022-06-25 10:43:36.638266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(terms=[], variables={}, skip=False)
    if res is not None:
        raise Exception('test_LookupModule_run failed test_case_2')
    lookup_module_0.run(terms=[{}], variables={}, skip=False)


from ansible_collections.community.network.tests.unit.compat import unittest
from ansible_collections.community.network.tests.unit.compat.mock import Mock, patch



# Generated at 2022-06-25 10:43:39.739434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    terms = []
    variables = {}
    
    for fn in total_search:
        # TODO: the above test is not calling _process_terms to handle this
        lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 10:43:48.036816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for method run of class LookupModule
    #
    # Ensure we get the expected result for the run method of the LookupModule
    #
    # Call the run method in config context with one file and one path and ensure
    # that we get the expected file and path names
    #
    # Call the run method in config context with one file and one path and ensure
    # that we get a failure
    #
    # Call the run method in config context with two files and one path and ensure
    # that we get the expected file and path names
    #
    # Call the run method in config context with two files and one path and ensure
    # that we get a failure
    #
    pass



# Generated at 2022-06-25 10:43:52.570080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run("foo", "bar", skip=True) == []


# Generated at 2022-06-25 10:44:00.781563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # First test case
    terms_0 = ['mappings', 'templates', 'name', 'name']
    variables_0 = dict({'lookup_plugin': 'first_found', '__': {'name': 'name'}})
    lookup_module_0.run(terms_0, variables_0)
    # Second test case
    terms_1 = ['mappings', 'templates', 'name', 'name']
    variables_1 = dict({'lookup_plugin': 'first_found', '__': {'name': 'name'}})
    lookup_module_0.run(terms_1, variables_1)


# Generated at 2022-06-25 10:44:10.084138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #test with complete valid input 
        #parameter 1 (valid)
    terms=[{'files': ['foo.txt','bar.txt','biz.txt'], 'paths': ['/path/to']}]
    variables={}
    kwargs={}
    #parameter2 (valid)
    #parameter3 (valid)
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms,variables,**kwargs) == ['/path/to/foo.txt']


# Generated at 2022-06-25 10:44:17.488212
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # lookup_module.run(terms, variables, **kwargs)
    #   Lookup module first_found, find first existing file
    #   :kwargs: extra arguments passed to lookup
    #   :returns: path to file found

    # TODO: NEED UNIT TESTING
    # test if lookup_module.find_file_in_search_path(variables, subdir, fn, ignore_missing=True)
    #   calls self._loader.path_dwim(variables[x], subdir) or self._loader.get_real_file(fn)
    #   and returns result. If none found raise AnsibleError
    #   :kwarg subdir: subdirectory in which to search for the relative filename
    #   :kwarg ignore_missing: if True, ignore errors from file

# Generated at 2022-06-25 10:44:23.830296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # if nobody trips on this it will be removed in the next version
    lookup_module = LookupModule()
    tasks_file = 'tasks.yaml'
    terms = [tasks_file, 'other_tasks.yaml']
    variables = {}
    assert lookup_module.run(terms, variables, errors='ignore')[0] == tasks_file

# Generated at 2022-06-25 10:44:28.955158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Tests LookupModule.run() behaves as expected."""
    lookup_module = LookupModule()
    lookup_module.set_options(dict(files='file1,file2', paths=''))
    terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    files = ['/path/to/foo.txt', 'bar.txt', 'biz.txt']
    assert lookup_module.run(terms, '', files=files) == ['/path/to/foo.txt']

# Generated at 2022-06-25 10:44:43.386116
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:44:48.154841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ':*J'
    variables_0 = '+'
    lookup_module_0 = LookupModule(terms_0)
    assert lookup_module_0.run(terms_0, variables_0) == []


# Generated at 2022-06-25 10:44:52.024121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_0 = LookupModule()
    str_0 = 'w{%Z]#bAF^X'
    list_0 = []
    set_0 = set()
    var_0 = lookup_plugin_0.run(str_0, set_0, list_0)
    assert var_0 is not None

# Generated at 2022-06-25 10:44:55.622525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  set_0 = set()
  lookup_module_0 = LookupModule(set_0)
  var_0 = lookup_run(set_0, lookup_module_0)


# Generated at 2022-06-25 10:44:56.347955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return


# Generated at 2022-06-25 10:44:59.421193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule(set_0)
    #
    #
    #
    lookup_module_0._subdir = 'files'
    lookup_module_0.run(set_0, set_0)
    lookup_module_0.run(set_0, set_0)
    #


# Generated at 2022-06-25 10:45:09.709797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test simple string
    findme = ['foo.txt']
    lookup_module_0 = LookupModule(findme)
    set_0 = set()
    var_0 = lookup_run(set_0, lookup_module_0)
    assert var_0 == ['/vagrant/foo.txt']

    # test list of strings
    findme = ['foo.txt', 'bar.txt']
    lookup_module_0 = LookupModule(findme)
    set_0 = set()
    var_0 = lookup_run(set_0, lookup_module_0)
    assert var_0 == ['/vagrant/foo.txt']

    # test using paths
    findme = ['foo.txt', 'bar.txt']
    paths = ['../test/lookups']

# Generated at 2022-06-25 10:45:16.380728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'A>/iLW/.aR<*'
    lookup_module_1 = LookupModule(str_1)
    set_1 = set()

    # Call method run
    # Parameters:
    #   terms:
    #       description:
    #   variables:
    #       description:
    try:
        lookup_module_1.run(set_1)
    except Exception as e:
        assert type(e) is AnsibleLookupError



# Generated at 2022-06-25 10:45:26.318880
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # From /usr/lib/python2.7/site-packages/ansible/plugins/lookup/first_found.py

    # unless set it will complain
    set_0 = set()
    lookup_module_0 = LookupModule('Hello World')

    # NOTE: in this case the terms is a 'list' which will fail
    # the _process_terms function which assumes 'a list of terms'
    # and not a list of list of terms.
    # NOTE: since only the last option will be used it will only look for
    # the files in the /tmp/staging directory.
    # NOTE: global skip wont matter, only last 'skip' value in dict term


# Generated at 2022-06-25 10:45:33.902168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'A>/iLW/.aR<*'
    lookup_module_0 = LookupModule(str_0)
    set_0 = set()
    init_0 = len(lookup_module_0._terms)
    var_0 = lookup_module_0.run(set_0, set_0)
    return var_0


# Generated at 2022-06-25 10:45:45.005036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = {'values': ['a', 'b', 'c']}
    var_2 = lookup_module_0.run(var_1, var_0)
    assert var_2 == ['a', 'b', 'c'], var_2
    var_1 = {'values': ['a']}
    lookup_module_0.run(var_1, var_0)
    var_3 = {'values': ['a', 'x', 'c'],'skip': True}
    var_4 = lookup_module_0.run(var_3, var_0)
    assert var_4 == [], var_4
    var_5 = {}
    var_

# Generated at 2022-06-25 10:45:53.973620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [
        {
            'files': '',
            'paths': '',
        },
        {
            'files': '',
            'paths': '',
        },
    ]
    var_1 = {
        'files': '',
        'paths': '',
    }
    lookup_module_0 = LookupModule(var_0)
    lookup_module_0.run(var_0, var_1)


# Generated at 2022-06-25 10:46:00.899489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = set()
    var_2 = dict()
    var_3 = str()
    lookup_module_2 = lookup_module_0.run(var_1, var_2, **var_3)
    return lookup_module_2

if __name__ == "__main__":
    print(test_LookupModule_run())

# Generated at 2022-06-25 10:46:12.580159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = { 'a':1 }
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_module_0.run(var_0, var_0)
    var_2 = lookup_module_0.run(var_0, var_0, {'a':1})
    var_3 = lookup_module_0.run(var_0, var_0, {'b':1})
    var_4 = lookup_module_0.run(var_0, var_0, {'a':1, 'b':1})
    var_5 = lookup_module_0.run(var_0, var_0, {'a':1, 'b':1, 'c':1})

# Generated at 2022-06-25 10:46:18.143422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class with mock attributes and methods
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = var_0
    var_2 = var_0
    var_3 = var_0
    var_4 = var_0
    var_5 = var_0
    var_6 = var_0
    var_7 = var_0
    var_8 = var_0
    var_9 = var_0
    var_10 = var_0
    var_11 = var_0
    var_12 = var_0
    var_13 = var_0
    var_14 = var_0
    var_15 = var_0
    var_16 = var_0
    var_17 = var_0
    var_18 = var_0
   

# Generated at 2022-06-25 10:46:26.987709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 'foo'
    # Note: this is invalid - but the option is not set at load time
    # the error will occur when run() is called.
    var_1 = {var_0: var_0}
    var_2 = {'files': [var_0], 'paths': []}
    lookup_module_0 = LookupModule()
    current_dir = os.path.dirname(os.path.abspath(__file__))
    lookup_module_0._basedir = current_dir
    var_3 = lookup_module_0.run([var_1], {}, skip=True)
    assert var_3 == []
    var_3 = lookup_module_0.run([var_2], {}, skip=True)
    assert var_3 == []
    assert var_3 == []


# Generated at 2022-06-25 10:46:36.600127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: all examples have 'files' and paths are in vars, we only pick 'one'
    lookup_module_0 = LookupModule(sorted(['set_fact', 'filter', 'lookup_plugin']))
    var_0 = lookup_module_0.run(sorted(['set_fact', 'filter', 'lookup_plugin']), sorted(['set_fact', 'filter', 'lookup_plugin']), skip=True, files='files', paths=['/tmp/production'])
    assert (var_0 == [])
    lookup_module_1 = LookupModule(sorted(['set_fact', 'filter', 'lookup_plugin']))

# Generated at 2022-06-25 10:46:39.140272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0)
    # Assertion



# Generated at 2022-06-25 10:46:50.087235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = dict()
    var_0['lookup_plugin_0'] = 'lookup_file_0'
    var_0['lookup_file_0'] = 'lookup_file_1'
    var_0['lookup_file_1'] = 'lookup_file_2'
    var_0['lookup_file_2'] = 'lookup_file_3'
    lookup_module_0 = LookupModule(var_0)
    var_1 = dict()
    var_1['lookup_plugin_0'] = 'lookup_file_1'
    var_1['lookup_file_0'] = 'lookup_file_2'
    var_1['lookup_file_1'] = 'lookup_file_3'

# Generated at 2022-06-25 10:46:57.484647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = lookup_run
    var_1 = set()
    var_2 = {'files': 'a.txt, b.txt, c.txt', 'paths': 'P1:P2', 'skip': False}
    lookup_module_0 = LookupModule(var_1)
    var_3 = lookup_module_0.run(var_2, var_2)
    assert var_3 == ['a.txt', 'b.txt', 'c.txt', 'P1/a.txt', 'P1/b.txt', 'P1/c.txt', 'P2/a.txt', 'P2/b.txt', 'P2/c.txt']


# Generated at 2022-06-25 10:47:08.134907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = set()
    var_0 = LookupModule(var_1)
    # test if _process_terms returns a tuple of len 2
    var_2 = var_0._process_terms([])
    assert isinstance(var_2, tuple)
    assert len(var_2) == 2
    # test if _process_terms returns a tuple whose first item is a list
    var_3 = var_0._process_terms([])
    assert isinstance(var_3[0], list)
    # test if _process_terms returns a tuple whose second item is a bool
    var_4 = var_0._process_terms([])
    assert isinstance(var_4[1], bool)
    # test if _split_on returns a list
    var_5 = _split_on([])

# Generated at 2022-06-25 10:47:13.703634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'z': {'paths': ['z']}}
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0, skip=True)
    assert var_1 == [], 'ansible/test/test_lookup_plugins/test_first_found/test_case_5, ERROR'


# Generated at 2022-06-25 10:47:22.778981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest
    import ansible.plugins.loader as plugin_loader
    import ansible.errors as errors

    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../lookup_plugins'))

    var_0 = dict(paths=['/etc/network/interfaces'], files=['interfaces_ubuntu'], skip=False)
    var_1 = dict(paths=['/etc/network/interfaces'], files=['interfaces_ubuntu'], skip=False)

    lookup_module_0 = plugin_loader.get('first_found', class_only=True)
    lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 10:47:30.743614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock for LookupBase
    class MockLookupBase:
        def __init__(self):
            self._templar = create_lookup_templar()
            self._loader = None
            self._basedir = './tests/fixtures/lookup_plugins/first_found'
            self._file_root_var = None
            self._role_root_var = None
        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing=True):
            return filename

    mock_lookup_base = MockLookupBase()

    # Mock for TaskExecutor
    class MockTaskExecutor:
        def __init__(self):
            self._owner = None
            self._loader = None
        def set_loader(self, loader):
            self._loader = loader

# Generated at 2022-06-25 10:47:33.908585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    kwargs = {}
    LookupModule.run(test_case_0.lookup_module_0, args, kwargs)

# Generated at 2022-06-25 10:47:39.482370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = set()
    lookup_module_0 = LookupModule(vars_0)
    var_1 = lookup_run(vars_0, vars_0)


# Generated at 2022-06-25 10:47:44.563425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = sets()
    lookup_module_0.run(var_0)


# Generated at 2022-06-25 10:47:50.371661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_instance_0 = LookupModule(var_0)
    var_1 = set()
    var_2 = dict()
    try:
        var_3 = lookup_instance_0.run(var_1, var_2)
    except Exception as e:
        var_4 = str(e)
        print("[{}]".format(var_4))
    else:
        var_5 = str(var_3)
        print("[{}]".format(var_5))


# Generated at 2022-06-25 10:47:54.883550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: create a test which tests the run method of class LookupModule
    assert True == True



# Generated at 2022-06-25 10:48:00.464564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = set()
    var_2 = {}
    # Calling run with args
    # Calling process_terms with args
    # Calling set_options with args
    var_3 = {}
    var_3['files'] = []
    var_3['paths'] = []
    var_3['skip'] = False
    var_4 = {}
    lookup_module_0.set_options(var_options=var_1, direct=var_3)
    # Calling set_options with args
    var_3 = {}
    var_3['files'] = []
    var_3['paths'] = []
    var_3['skip'] = False
    var_4 = {}
    lookup_module_0.set_options

# Generated at 2022-06-25 10:48:07.402438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run the test case
    test_case_0()

# Generated at 2022-06-25 10:48:18.392842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = set()
    var_2 = lookup_module_0.run(var_1, var_0)
    assert var_2 == [], "lookup_module_0.run returned %s instead of %s" % (var_2, [])
    var_1 = []
    var_2 = lookup_module_0.run(var_1, var_0)
    assert var_2 == [], "lookup_module_0.run returned %s instead of %s" % (var_2, [])
    var_1 = [get_path("first_found.py")]
    var_2 = lookup_module_0.run(var_1, var_0)

# Generated at 2022-06-25 10:48:27.325816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    terms_0 = set()
    variables_0 = set()
    kwargs_0 = {
        'skip': False,
        'files': '',
        'paths': ''
    }
    # Act
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

    # Assert
    assert result == [], "Expected [], Actual {}".format(result)



# Generated at 2022-06-25 10:48:35.679193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(SingleValue(000))
    lookup_module_1 = LookupModule(SingleValue(000))
    lookup_module_2 = LookupModule(SingleValue(000))
    lookup_module_3 = LookupModule(SingleValue(000))
    lookup_module_4 = LookupModule(SingleValue(000))
    lookup_module_5 = LookupModule(SingleValue(000))
    lookup_module_6 = LookupModule(SingleValue(000))
    lookup_module_7 = LookupModule(SingleValue(000))
    lookup_module_8 = LookupModule(SingleValue(000))
    lookup_module_9 = LookupModule(SingleValue(000))
    lookup_module_10 = LookupModule(SingleValue(000))

# Generated at 2022-06-25 10:48:38.613551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set = dict(
        files=[],
        paths=[]
    )
    lookup_module = LookupModule(set)
    var_1 = lookup_module.run(set, set)
    assert type(var_1) == list



# Generated at 2022-06-25 10:48:45.679738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = set()
    var_2 = dict(var_1)
    var_3 = lookup_module_0.run(var_1, var_2)
    assert len(var_3) == 0
    var_1 = ('{ ansible_virtualization_type }_foo.conf', 'default_foo.conf')
    var_2 = dict(var_1)
    var_3 = lookup_module_0.run(var_1, var_2)
    assert len(var_3) == 1


# Generated at 2022-06-25 10:48:55.769464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import ansible.utils.module_docs_fragments
    import ansible.plugins.lookup
    lookup_module_0 = LookupModule(ansible.plugins.lookup.LookupBase)
    lookup_module_0.lookup_loader = ansible.plugins.lookup.LookupBase()
    class ansible_loader(object):

        def get_basedir(self, ):
            return os

        def get_basedir(self, ):
            return os
    lookup_module_0.lookup_loader.loader = ansible_loader()
    lookup_module_0.set_options(var_options=None, direct={'paths': ['path'], 'files': ['file'], 'skip': False})
    lookup_module_0.run(['path'], None)
    lookup_module_

# Generated at 2022-06-25 10:49:01.555088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_1)
    test_case_0()


# Generated at 2022-06-25 10:49:06.437533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    # Call of the method run with some arguments
    assert lookup_module_0.run(var_0) == None

# Generated at 2022-06-25 10:49:18.698181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = 'examples/files/'
    var_3 = os.path.curdir
    var_4 = os.path.dirname(os.path.dirname(__file__))
    var_4 = os.path.join(var_4, var_2)
    var_5 = os.path.join(var_4, 'test_lookup_first_found.txt')
    var_6 = dict()
    var_6['vars'] = set()
    lookup_module_0 = LookupModule(var_6['vars'])
    var_6['vars']._templar = var_0 = os.path.join(var_4, 'test_lookup_first_found.txt')
    var_7 = []
    var_8 = []
    var_7.append

# Generated at 2022-06-25 10:49:38.645519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = tuple()

# Generated at 2022-06-25 10:49:43.227725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'new_value': 'old_value', 'key_1': 'old_value', 'key_2': 'value', 'key_3': 'value'}
    var_1 = var_0.copy()
    for var_2 in var_1:
        var_0[var_2] = var_1[var_2]
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0)
    print(var_1)


# Generated at 2022-06-25 10:49:45.672735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0)


# Generated at 2022-06-25 10:49:48.256618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:49:53.607787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0)
    var_2 = {}
    var_3 = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
    var_4 = set()
    try:
        var_5 = lookup_module_0.run(var_1, var_4, **var_2)
        assert var_5 == var_3
    except AnsibleLookupError as e:
        assert False


# Generated at 2022-06-25 10:49:56.894464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = "bar"
    var_1 = {
        "skip": True
    }
    lookup_module_0 = LookupModule(var_0)
    var_2 = lookup_run(var_0, var_1)


# Generated at 2022-06-25 10:50:03.689688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = set(['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt'])
    var_2 = {'skip': True, 'files': ['/path/to/foo.txt', '/path/to/bar.txt'], 'paths': ['/extra/path']}
    var_3 = [{'files': ['foo', '{{ inventory_hostname }}', 'bar']}]

# Generated at 2022-06-25 10:50:05.773107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_0 = [1, 2, 3]
    var_1 = set()
    var_2 = 'foo'
    var_3 = lookup_run(var_0, var_1, var_2)
    print(var_3)


# Generated at 2022-06-25 10:50:16.651015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)

    var_0 = ['test_file_name_0']
    var_1 = dict()
    var_1['skip'] = True
    var_2 = lookup_run(var_0, var_0)
    var_3 = dict()
    var_3['skip'] = True
    var_4 = lookup_run(var_0, var_1)
    var_5 = dict()
    var_5['skip'] = True
    var_6 = lookup_run(var_0, var_0, var_3)
    var_7 = dict()
    var_7['skip'] = True

    # NOTE: this 'looks' wrong!
    # these should mostly fail as they are set to 'skip' and
    #

# Generated at 2022-06-25 10:50:22.559022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    name_0 = 'ansible_loader'
    path_0 = '/usr/lib/python2.7/site-packages/ansible/plugins/late_loader.py'
    _import_module(name_0, path_0)
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(var_0, var_0)

# Generated at 2022-06-25 10:50:52.149478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)

    # Call method run of class LookupModule with arguments

    # Destroy the object lookup_module_0 of type LookupModule
    lookup_module_0._LookupModule__del__()

# Generated at 2022-06-25 10:50:54.019621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    var_1, var_2 = LookupModule.run(var_0, var_0)


# Generated at 2022-06-25 10:50:55.793963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == "test_result"

test_LookupModule_run()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 10:51:05.237541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    total_search = list()
    skip = False
    subdir = "files"
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_module_0._process_terms(total_search, var_0, var_0)
    var_2 = lookup_module_0._templar.template(total_search)
    path = lookup_module_0.find_file_in_search_path(var_0, subdir, total_search, ignore_missing=True)
    if var_1 is not None:
        return [path]
    if skip:
        return []
    raise AnsibleLookupError("No file was found when using first_found.")


if __name__ == '__main__':
    test_LookupModule_run()
   

# Generated at 2022-06-25 10:51:10.987553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = 'var_1'
    var_2 = lookup_run(lookup_module_0, var_1)
    print(var_2)


# Generated at 2022-06-25 10:51:13.528606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['foo.txt', 'bar.txt']
    var_1 = ['foo', 'bar']
    lookup_result = lookup_module_0.run(var_0, var_1)
    assert not lookup_result



# Generated at 2022-06-25 10:51:18.328503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data_0 = set()
    lookup_module_0 = LookupModule(data_0)
    data_1 = lookup_run(data_0, data_0)



# Generated at 2022-06-25 10:51:23.812018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = set()
    var_2 = dict()
    var_3 = lookup_module_run(var_0, var_1, var_1, var_2)
    print(var_3)


# Generated at 2022-06-25 10:51:26.532557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_module_0.run(var_0, var_0)
    assert isinstance(var_1, list)
    assert var_1 is var_1



# Generated at 2022-06-25 10:51:32.869333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    file_path_0 = get_file_path('', 'wget_0.1.4_8.deb', var_0)
    var_1 = Mapping()
    var_2 = LookupModule(var_1)
    var_3 = list_str()
    var_3.append(file_path_0)
    var_3.append('Test')
    var_3.append('./baz')
    var_4 = '/usr/bin/ls'
    var_5 = '/usr/bin/cat'
    var_6 = 'Test'
    var_7 = './baz'

# Generated at 2022-06-25 10:52:36.893929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_path = os.path.join(os.path.dirname(__file__), '_data/UnitTests/lookup_plugins/first_found')
    var_0 = dict(paths=var_path)
    lookup_module_0 = LookupModule(var_0)
    var_1 = lookup_run(lookup_module_0, dict(files=['bleh']))
    assert var_1 == []



# Generated at 2022-06-25 10:52:44.606905
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # params
    terms=['findme_1.txt', 'findme_2.txt', 'findme_3.txt']
    variables={'inventory_file': 'playbooks/inventory'}

    # set up and run
    resource = {}
    lookup_module_0 = LookupModule(resource)
    results = lookup_module_0.run(terms, variables)

    # assert
    assert results == []



# Generated at 2022-06-25 10:52:48.952979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file = {"src": "/home/user/foo.txt", "dest": "/home/user/bar.txt"}
    lookup_module = LookupModule(file, loader=None, templar=None)
    lookup_module.run()


# Generated at 2022-06-25 10:52:53.200570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        lookup_module.run(terms = [], variables = [])
    except Exception as exception:
        print("Test case lookup_module_run failed")
        print("Exception: " + str(exception))
    finally:
        # Cleanup
        pass


# Generated at 2022-06-25 10:52:54.520386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:52:58.001830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'a': 'b'}
    var_1 = {'c': 'd'}
    var_2 = [var_0, var_1]
    var_3 = {}
    lookup_module_0 = LookupModule(var_2)
    assert lookup_module_0.run(var_2, var_3) is None


# Generated at 2022-06-25 10:53:05.028137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = set()
    lookupModule = LookupModule(var)
    var_1 = {'a':'a'}
    var_2 = 'blah'
    var_3 = (var_1, var_2)
    # Test the edge cases
    try:
        ret_val = lookupModule.run(terms=var_3, variables=var)
        print(ret_val)
    except Exception as err:
        print(err)
    var_1 = ['a', {'a':'a'}]
    var_2 = 'blah'
    var_3 = (var_1, var_2)
    # Test the edge cases

# Generated at 2022-06-25 10:53:06.899916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    lookup_module_0 = LookupModule(var_0)
    var_0 = {}
    var_1 = {}
    var_2 = lookup_module_0.run(var_0, var_1)

