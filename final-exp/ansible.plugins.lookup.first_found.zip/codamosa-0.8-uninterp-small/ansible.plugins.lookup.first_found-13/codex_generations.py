

# Generated at 2022-06-25 10:43:12.425050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run([], {})
    except AnsibleLookupError:
        pass
    lookup_module_2 = LookupModule()
    try:
        lookup_module_2.run([''], {})
    except AnsibleLookupError:
        pass

# Generated at 2022-06-25 10:43:18.262170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        'first',
        'second',
        [
            'third',
            'fourth',
            {
                'files': [
                    'fifth',
                    'sixth'
                ]
            }
        ]
    ]
    variables = dict()
    lookup_module._process_terms(terms, variables, dict())
    terms = [
        {
            'files': [
                'fifth',
                'sixth'
            ],
            'paths': [
                'seventh',
                'eighth'
            ]
        }
    ]
    variables = dict()
    lookup_module._process_terms(terms, variables, dict())

# Generated at 2022-06-25 10:43:28.410093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['my_file']
    terms_1 = ['my_file_1', 'my_file_2']
    terms_2 = ['my_file_1', 'my_file_2', 'my_file_3']
    variables_0 = {'files': ['file_1', 'file_2'], 'paths': ['path_1', 'path_2']}
    kwargs_0 = {}
    actual = lookup_module_0._process_terms(terms_0, variables_0, kwargs_0)
    expected = (['file_1', 'file_2'], False)
    assert actual == expected
    pass
    actual = lookup_module_0._process_terms(terms_1, variables_0, kwargs_0)
   

# Generated at 2022-06-25 10:43:33.231420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_object = LookupModule()
    lookup_module_object.set_options(var_options={}, direct={'files': 'file1,file2', 'paths': 'path1,path2', 'skip': False})
    lookup_module_object_result = lookup_module_object.run([])
    assert lookup_module_object_result is None


# Generated at 2022-06-25 10:43:37.446165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case data
    test_terms = '  '
    test_variables = {}
    test_kwargs = {}

    # Perform the test
    object_0 = LookupModule()
    object_0.run(test_terms, test_variables, **test_kwargs)


# Generated at 2022-06-25 10:43:42.115202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test ansible_version does not exist
    lookup_module_0.ansible_version = None
    terms = [{'files': ['etc/resolv.conf']}]
    variables = {}
    lookup_module_0.run(terms, variables)

    # test ansible_version exists
    lookup_module_0.ansible_version = 'ansible_version_value'
    terms = [{'files': ['etc/resolv.conf']}]
    variables = {}
    lookup_module_0.run(terms, variables)

    # test ansible_version exists
    lookup_module_0.ansible_version = 'ansible_version_value'
    terms = [{'files': ['etc/resolv.conf']}]
    variables = {}

# Generated at 2022-06-25 10:43:45.885473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run("foo.txt", {})

# Generated at 2022-06-25 10:43:46.576533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise AnsibleLookupError("NOT IMPLEMENTED")

# Generated at 2022-06-25 10:43:57.344085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test no. of arguments
    args = dict(
        terms=[],
        variables=dict(),
    )
    kwargs = dict()
    tries = [
        (args, kwargs),
        (args, None),
        (None, kwargs),
        (None, None),
        (None, dict()),
    ]
    for arg, argv in tries:
        try:
            lookup_module.run(*arg, **argv)
        except TypeError as e:
            assert "lookup_module.run expected at least 2 arguments, got 1" in str(e)


# Generated at 2022-06-25 10:44:05.852809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def do_test(t):
        terms = t['terms']
        variables = t['variables']
        expected = t['expected']
        lookup_module = LookupModule()
        actual = lookup_module.run(terms, variables)
        # assert actual == expected
        assert actual == expected
    test_data = [
        {
            'terms': [],
            'variables': {},
            'expected': []
        },
        {
            'terms': ['a term'],
            'variables': {},
            'expected': []
        },
        {
            'terms': {'a': 'term'},
            'variables': {},
            'expected': []
        }
    ]
    for t in test_data:
        yield do_test, t

# Generated at 2022-06-25 10:44:20.666831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["list-0", "list-1", "list-2", "dict-3", "dict-4", "dict-5", "list-6", "list-7", "list-8", "list-9", "list-10", "dict-11", "dict-12", "dict-13", "list-14", "list-15", "list-16", {"skip": "skip-17"}]
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 10:44:27.856604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Force parameter ignore_undefined = False as well as provide a value for that parameter
    # This should cause an exception.
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms=["test"], variables=["test"], ignore_undefined=False)
    except SystemExit as err:
        assert(err.code == 1)
    assert(lookup_module_1.run(terms=["test"], variables=["test"]) == ["test"])
    # Force parameter ignore_errors = True
    # That should cause the function to return [].
    assert(lookup_module_1.run(terms=[], variables={}, ignore_errors=True) == [])
    # Force parameter ignore_errors = True
    # That should cause the function IgnoreErrors.

# Generated at 2022-06-25 10:44:29.912414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms = [ "term_1", "term_2"], variables = 5, errors = None) == [ ]

# Generated at 2022-06-25 10:44:39.884947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # summary: Return first file found from a list of files
    #   parameters:
    #     terms - list of files to search for
    #     variables - extra variables available to jinja2
    #     kwargs - extra arguments
    #   returns:
    #       list of files found (empty list if no files found)
    #       dict with extra info
    terms = None
    variables = None
    kwargs = {'foo': 'bar'}
    assert lookup_module_0.run(terms, variables, **kwargs) == [None]


# Generated at 2022-06-25 10:44:49.083031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert isinstance(param1, dict)
    # assert isinstance(param2, dict)
    # Test case of missing params
    # Test case of empty list
    # Test case of file list with valid files
    # Test case of path list with valid files
    # Test case of mixed list with valid files
    # Test case of invalid files
    # Test case of valid file with no param
    # Test case of valid file with path param
    # Test case of valid file with files and path param
    # Test case of valid file with files and path params as lists
    # Test case of valid file with files and path params as dict
    print("Testing run of class LookupModule")

# Generated at 2022-06-25 10:44:55.504943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar = Templar(loader=DictDataLoader(), variables={})
    lookup_module_0.set_options(var_options={}, direct={'paths': ['docs', 'examples', 'lib', 'plugins']})
    lookup_module_0.set_loader(loader=DictDataLoader({'examples/ansible.cfg': b''}))
    assert lookup_module_0.run(["ansible.cfg"], variables={}) == [b'examples/ansible.cfg']



# Generated at 2022-06-25 10:45:01.646746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    kwargs = {'_terms': [{'files': ['foo', 'bar'], 'paths': ['/tmp/production', '/tmp/staging']}]}
    lookup_module_1.run(terms=['foo', 'bar'], variables={}, **kwargs)

# Generated at 2022-06-25 10:45:09.474985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    dict = {}
    dict['var_options'] = {}
    dict['direct'] = {}
    dict['direct']['files'] = None
    dict['direct']['paths'] = None
    dict['direct']['skip'] = False
    terms = [{'files': ['test.txt'], 'paths': ['/home/user/'], 'skip': False}, {'files': ['test.txt'], 'paths': ['/home/user/'], 'skip': False}]
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:45:20.250252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._subdir = './ansible/plugins/lookup/'
    lookup_module._loader = './ansible/plugins/lookup/'
    lookup_module._templar = './ansible/plugins/lookup/'
    lookup_module._shared_loader_obj = './ansible/plugins/lookup/'
    ansible_variable = './ansible/plugins/lookup/'
    terms = './ansible/plugins/lookup/'
    kwargs = './ansible/plugins/lookup/'
    result = lookup_module.run(terms, ansible_variable, **kwargs)
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], str)

# Generated at 2022-06-25 10:45:28.526064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["path/file.txt", "path/file.txt"]
    variables = {"path": "/home/user/ansible"}
    kwargs = {"errors": "ignore"}
    test_case_0 = LookupModule()
    path = test_case_0.run(terms, variables, **kwargs)
    assert path == '/home/user/ansible/path/file.txt'

    terms = ["path/file.txt", "path/file.txt"]
    variables = {"path": "/home/user/ansible"}
    kwargs = {"errors": "ignore"}
    test_case_0 = LookupModule()
    path = test_case_0.run(terms, variables, **kwargs)
    assert path == '/home/user/ansible/path/file.txt'

# Generated at 2022-06-25 10:45:41.878821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'x'
    variables_0 = 'x'
    try:
        lookup_module_0.run(terms_0, variables_0, x=x)
    except:
        pass
    else:
        assert False, 'expected exception not raised'


# Generated at 2022-06-25 10:45:51.239122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = [
        'foo_bar',
        'foo_baz',
    ]
    variables_0 = {}
    kwargs_0 = {
        'files': 'foo_bar,foo_baz',
        'paths': 'baz_qux',
    }

    try:
        total_search_0, skip_0 = lookup_module_0._process_terms(terms_0, variables_0, kwargs_0)
    except Exception as e_0:
        print("Exception: %s" % str(e_0))
    else:
        print("Total search: %s" % str(total_search_0))
        print("Skip: %s" % str(skip_0))


# Generated at 2022-06-25 10:46:01.959451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar = None
    lookup_module_0._basedir = None
    lookup_module_0._loader = None
    lookup_module_0._options = {}
    lookup_module_0.run(terms=['first_found.py'], variables={'hostvars': {'hostvars': {'hostvars': {'hostvars': {'hostvars': {'hostvars': {'host_name': 'invalid_host'}}}}}}})
    lookup_module_0.run(terms=['first_found.py'], variables={})

# Generated at 2022-06-25 10:46:05.825479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._terms = [{'files': ['foo', 'bar'], 'paths': ['.']}]

    # tests will raise AnsibleLookupError, which is fine for now
    # part of the test will be to see if the exception raises
    assert lookup_module_0.run([{'files': ['foo', 'bar'], 'paths': ['.']}], {},)

# Generated at 2022-06-25 10:46:14.184976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = 'test_value_1'
    test_0_args = 'test_value_2'
    test_0_kwargs = 'test_value_3'
    result_1 = lookup_module_1.run(test_0_args, test_0_kwargs)
    # Validate the test case
    assert result_1 == 'test_value_1'

    # Test case 2
    lookup_module_2 = LookupModule()
    lookup_module_2._templar = 'test_value_2'
    test_1_args = 'test_value_3'
    test_1_kwargs = 'test_value_4'

# Generated at 2022-06-25 10:46:18.218289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['test_terms', 'vars', 'files']
    variables = {'files': ['file_entry'], 'test_terms': 'test_terms', 'paths': ['paths_entry'], 'vars': {'paths': ['paths_entry'], 'files': ['file_entry']}}
    assert lookup_module_0.run(terms, variables) == ['paths_entry/file_entry']

# Generated at 2022-06-25 10:46:26.989202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import jinja2
    from ansible.module_utils.six import PY3

    class LookupModuleMock(LookupModule):
        def __init__(self):
            pass

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return self.file_found

        def run(self, terms, inject=None, variables=None, **kwargs):
            return super(LookupModuleMock, self).run(terms, {})

    class TestLookupModule(unittest.TestCase):
        def test_terms_is_none_or_empty(self):
            for terms in (None, ""):
                lookup_module = LookupModuleMock()
                result = lookup_module.run(terms, {})
                self

# Generated at 2022-06-25 10:46:29.574981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert type(lookup_module.run(['simpletest.j2'], None)) is type([])

# Generated at 2022-06-25 10:46:32.363460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #assert_raises(exception, lookup_module_0.run, terms, variables, **kwargs)



# Generated at 2022-06-25 10:46:39.929132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._subdir = 'file'
    test_dir = '../plugins/lookup/'
    lookup_module.find_file_in_search_path = lambda *a, **kw: test_dir + 'test_file.txt'
    lookup_module._templar = lambda *a, **kw: 'test_file.txt'
    lookup_module._loader = lambda *a, **kw: test_dir + 'test_file.txt'
    lookup_module.set_options = lambda *a, **kw: None
    lookup_module.get_option = lambda *a, **kw: None

    terms = [['test_file.txt']]
    result = lookup_module.run(terms, {})
    assert result == [test_dir + 'test_file.txt']

# Generated at 2022-06-25 10:46:58.220577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testcase 1
    _terms = ["/path/to/foo.txt", "bar.txt", "/path/to/biz.txt"]
    lookup_module_1 = LookupModule()
    path = lookup_module_1.run(_terms, {})
    assert path == ['/path/to/foo.txt']

    # Testcase 2
    files = ["/path/to/foo.txt", "/path/to/bar.txt"]
    paths = ["/extra/path"]
    lookup_module_2 = LookupModule()
    path = lookup_module_2.run(files, paths, skip=True)
    assert path == []

    # Testcase 3
    files = ['tasks.yaml', 'other_tasks.yaml']
    lookup_module_3 = LookupModule()
    path = lookup_module

# Generated at 2022-06-25 10:47:03.318955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(["some_file.txt", "some/path"], {'paths': "/path/to/look/in"})
    except AnsibleLookupError as e:
        print("Exception message: {0}".format(e.message))

# Generated at 2022-06-25 10:47:05.486835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert False, "No test found"


# Generated at 2022-06-25 10:47:12.675765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        {
            'files': 'files',
            'paths': 'paths'
        }
    ]
    testcase_LookupBase_vars_0 = {
        'ansible_net_hostname': '',
        'ansible_job_id': '',
        'ansible_env': '',
        'ansible_distribution': '',
        'ansible_python': '',
        'ansible_module_name': '',
        'ansible_processor_count': '',
        'ansible_architecture': '',
        'ansible_net_interfaces': ''
    }
    lookup_module_0.run(terms_0, testcase_LookupBase_vars_0)


# Generated at 2022-06-25 10:47:19.554543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = ["path/to/file.txt"]

  try:
    lookup_module.run(terms, None)
  except AnsibleLookupError as e:
    # Expected exception
    print(e)
    assert True
  else:
    # Unexpected exception
    assert False


# Generated at 2022-06-25 10:47:28.885348
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test succeed
    params_0 = [
        {
            'files': 'file1.txt',
            'paths': 'path1.txt',
            'skip': True
        },
        {
            'files': 'file1.txt',
            'paths': 'path1.txt',
            'skip': True
        },
        {
            'files': 'file1.txt',
            'paths': 'path1.txt',
            'skip': True
        },
        {
            'files': 'file1.txt',
            'paths': 'path1.txt',
            'skip': True
        },
        {
            'files': 'file1.txt',
            'paths': 'path1.txt',
            'skip': True
        }
    ]


# Generated at 2022-06-25 10:47:36.405809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict(files=['test_LookupModule_run1', 'test_LookupModule_run2'], paths=[], skip=False))
    lookup_module._templar = None
    lookup_module.find_file_in_search_path = (lambda a, b, c, d: c)
    lookup_module.run(['test_LookupModule_run1'], dict())
    lookup_module.run(['test_LookupModule_run2'], dict())
    lookup_module.run([{'files':['test_LookupModule_run3', 'test_LookupModule_run4'], 'paths':[], 'skip':False}], dict())

# Generated at 2022-06-25 10:47:47.132116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['test_value_1'], variables={'test_value_2': 'test_value_3'}, test_value_4={'test_value_5': 'test_value_6'}) == ['test_value_1']
    assert lookup_module_0.run(terms=['test_value_7'], variables={'test_value_8': 'test_value_9'}, test_value_10='test_value_11') == ['test_value_7']
    assert lookup_module_0.run(terms=['test_value_12'], variables={'test_value_13': 'test_value_14'}, test_value_15='test_value_16') == ['test_value_12']
    assert lookup_

# Generated at 2022-06-25 10:47:55.787960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = [{'files': 'foo,bar', 'paths': '/tmp/production'}, {'files': 'foo', 'paths': '/tmp/staging'}]
    variables_1 = {}
    skip_1 = True
    retval_1 = lookup_module_1.run(terms_1, variables_1)

    # retval_1 is None. Check if this is the expected result.
    assert retval_1 is None

# Generated at 2022-06-25 10:47:57.873871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test run
    '''
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run is not None


# Generated at 2022-06-25 10:48:15.730206
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module_1 = LookupModule()


    # test_data
    # idx: 0 => lookup_options
    #     1 => variables
    #     2 => expected_results

# Generated at 2022-06-25 10:48:26.415895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []

# Generated at 2022-06-25 10:48:35.307174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # comment below line when testing with ansible
    lookup_module.set_options(var_options=dict(), direct=dict())
    terms = [ "../hi.txt" ]
    variables = dict()
    kwargs = dict()
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == []
    lookup_module.set_options(var_options=dict(), direct=dict())
    terms = [ "../hi.txt" ]
    variables = dict()
    kwargs = dict()
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == []
    lookup_module.set_options(var_options=dict(), direct=dict())
    terms = [ "../hi.txt" ]
    variables = dict()


# Generated at 2022-06-25 10:48:38.252118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["/tmp/file1.txt", "/tmp/file2.txt", "/tmp/file3.txt"]
    variables = {}
    lookup_module_obj = LookupModule()
    lookup_module_obj.run(terms, variables)

# Generated at 2022-06-25 10:48:46.267719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(" Testing lookup_run()")
    lookup_module_0 = LookupModule()
    result_terms_0 = []
    result_terms_0.append("file1")
    result_terms_0.append("file2")
    result_terms_0.append("file3")
    result_terms_0.append("file4")

    result = lookup_module_0.run(result_terms_0, "whatever")
    assert result == result_terms_0, "Result: " + str(result) + "  Expected: " + str(result_terms_0)
    print(" Test Passed: lookup_run()")
    print(" Testing lookup_run()")
    lookup_module_0 = LookupModule()
    result_terms_0 = []
    result_terms_0.append("file1")
    result_

# Generated at 2022-06-25 10:48:54.508633
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case with no input parameters
    test_input = dict()
    test_input['terms'] = [dict(files=['file', 'file2'], paths=['path'])]
    test_input['variables'] = dict()
    test_input['kwargs'] = dict()
    test_input['kwargs']['_terms'] = [dict(files=['file', 'file2'], paths=['path'])]

    retval = LookupModule.run(test_input['terms'], test_input['variables'], **test_input['kwargs'])
    assert retval == ['path/file']

    # test case with input parameter skip=True

    test_input = dict()

# Generated at 2022-06-25 10:48:57.420978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []
    assert type(lookup_module_1.run(['a'])) == list


# Generated at 2022-06-25 10:49:01.555320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test for a case class LookupModule test case
    test_case_0()

# Generated at 2022-06-25 10:49:11.420635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:49:12.262944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 10:49:30.451978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._process_terms = Mock(return_value=('/etc/motd', False))
    set_1 = set(['/etc/motd', '/etc/passwd'])
    dict_1 = None
    result_1 = lookup_module_1.run(set_1, dict_1)
    assert repr(result_1) == repr([])


# Generated at 2022-06-25 10:49:31.966435
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # path = test_case_0()
    test_case_0()

# Generated at 2022-06-25 10:49:35.112983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    dict_1 = None
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(set_1, dict_1)
    assert var_1 == [], "Error in test_LookupModule_run"


# Generated at 2022-06-25 10:49:37.483525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, dict_0)
    assert var_0 == true

# Generated at 2022-06-25 10:49:39.697837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    var_0 = lookup_run(set_0, dict_0)


# Generated at 2022-06-25 10:49:44.073016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test_case_0
    set_0 = set()
    dict_0 = None
    var_0 = lookup_module_0.run(set_0, dict_0)

# Generated at 2022-06-25 10:49:50.733054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = {'_': '-', ',': ',', '.': '.'}
    lookup_module_0 = LookupModule()
    str_0 = ' '
    var_0 = lookup_module_0.run(set_0, dict_0, str_0)
    assert isinstance(var_0, bool)


# Generated at 2022-06-25 10:49:54.050767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    
    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(set_0, dict_0)
    assert lookup_module_0.run(set_0, dict_0) == var_1



# Generated at 2022-06-25 10:50:01.772155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()

    terms_0 = ['']
    terms_1 = ['', '']
    terms_2 = ['']
    terms_3 = ['', '']

    variables_0 = dict()
    variables_1 = dict()
    variables_2 = dict()
    variables_3 = dict()

    total_search_0 = set()
    total_search_1 = set()
    total_search_2 = set()
    total_search_3 = set()

    path_0 = None
    path_1 = None
    path_2 = None
    path_3 = None

    # TODO: how to test file_exists/

# Generated at 2022-06-25 10:50:08.459213
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, dict_0)
    assert "lookup_module_0.run(set_0, dict_0)" == repr(var_0)



# Generated at 2022-06-25 10:50:22.830903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except Exception:
        test_case_0()
    else:
        test_case_0()

# Generated at 2022-06-25 10:50:34.446414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, dict_0)

    # run with no parameters or data
    terms = [
        # default to files/
        'myfile1',
        {'files': 'myfile2'},
        {'paths': '/path/to, /another/path/'},  # same as files: myfile3, myfile4
        {'files': 'myfile5', 'paths': '/path/to/myfile6'},  # same as files: myfile5, /path/to/myfile6
    ]

    total_search, skip = lookup_module_0._process_terms(terms, dict_0, dict_0)

# Generated at 2022-06-25 10:50:36.033384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = LookupModule()
    var_0.run()



# Generated at 2022-06-25 10:50:40.229327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = dict()
    dict_0['files'] = set()
    dict_0['skip'] = 0
    dict_0['paths'] = set()
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = dict()
    lookup_module_0._templar['lookup'] = dict()
    lookup_module_0._templar['lookup']['first_found'] = set()
    var_0 = lookup_run(set_0, dict_0)
    assert not var_0



# Generated at 2022-06-25 10:50:49.201728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = [{'files': 'foo.txt', 'paths': 'path/to/'}]
    params = {'errors': 'ignore', 'encoding': 'utf-8', 'variable_start_string': '[[', 'variable_end_string': ']]'}

# Generated at 2022-06-25 10:50:52.126692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, dict_0)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:50:56.411746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # from ansible.plugins.lookup import LookupBase

    # Code to execute before running module
    lookup_module_0 = LookupModule()
    set_0 = set()
    dict_0 = None
    try:
        lookup_module_0.run(set_0, dict_0)
    except Exception as exception_0:
        assert True
    else:
        assert False

    


# Generated at 2022-06-25 10:50:59.143434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params_0 = [{}]
    var_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(params_0, var_0)

# Generated at 2022-06-25 10:51:09.643491
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup ansible environment for testing.
    import ansible.constants as C
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.debug import debug
    from ansible.utils.path import basedir, unfrackpath, makedirs_safe
    import ansible.module_utils.common._collections_compat as collections_compat
    import ansible.compat.six as six
    import os
    import sys
    import yaml
    import json
    import ast

    # TODO: this is just imported so it can be mocked
    # in the tests below.
    from ansible.plugins.lookup import LookupBase

    # TODO: this is not being mocked
    from ansible.plugins.loader import lookup_loader, module_loader

    # TOD

# Generated at 2022-06-25 10:51:15.493397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_0.run(set_0, dict_0)

    set_0 = set()
    dict_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0, dict_0)

# Generated at 2022-06-25 10:51:33.322997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:51:41.272318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    var_1 = lookup_run(var_0, var_0)
    assert var_1 == 0, "lookup_module_0.run() error on line {0}".format(inspect.getframeinfo(inspect.currentframe()).lineno)


# Generated at 2022-06-25 10:51:43.595049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.first_found
    lookup_module_0 = ansible.plugins.lookup.first_found.LookupModule()
    var_0 = set()
    var_1 = lookup_run(var_0, var_0)

# Complex test for method run of class LookupModule

# Generated at 2022-06-25 10:51:51.788938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = {
        'params': {
            'files': [
                'foo',
                'biz',
                'baz'],
            'paths': [
                'foo',
                'baz']}}
    var1 = {}
    var2 = {}
    var1 = lookup_module._process_terms(var, var1, var2)
    var1_1, var1_2 = var1
    assert var1_1 == [
        'foo/foo',
        'foo/biz',
        'foo/baz',
        'baz/foo',
        'baz/biz',
        'baz/baz']

# Generated at 2022-06-25 10:51:57.660611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'file'
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    var_0 = set()
    var_1 = lookup_module_0.run(var_0, var_0)

# Generated at 2022-06-25 10:52:00.757706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    assert lookup_module.run(terms, variables, **kwargs) == [], "Test Failed"

#Unit tests for method process_terms of class LookupModule

# Generated at 2022-06-25 10:52:10.031567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_0.set_options(var_options=None, direct={'paths': ['paths']})
    var_0.run(terms={"skip": True}, variables={}, skip=True)
    var_0.run(terms={"skip": False}, variables={}, skip=False)
    var_0.run(terms=None, variables={}, skip=True)
    var_0.run(terms=None, variables={}, skip=False)
    var_0.run(terms=None, variables={}, skip=True)
    var_0.run(terms=None, variables={}, skip=False)
    var_0.run(terms=None, variables={}, skip=True)
    var_0.run(terms=None, variables={}, skip=False)
    var_0

# Generated at 2022-06-25 10:52:14.415830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = {}
    var_2 = ''
    var_3 = var_0.run(var_1, var_2)

    assert var_3 == '', 'Expected empty string as empty list is returned'


# Generated at 2022-06-25 10:52:19.345455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = dict()
    var_1 = []
    var_2 = lookup_run(var_0, var_1, **var_2)


# Generated at 2022-06-25 10:52:27.590193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = set()
    variables_0 = set()
    lookup_run(terms_0, variables_0)
    kwargs_0 = { }
    kwargs_1 = { 'spam': 'eggs' }
    lookup_run(terms_0, variables_0, **kwargs_0)
    lookup_run(terms_0, variables_0, **kwargs_1)


# Generated at 2022-06-25 10:53:02.039611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    var_1 = lookup_run(var_0, var_0)


# Generated at 2022-06-25 10:53:02.757290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:53:04.076457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    var_1 = lookup_run(var_0, var_0)