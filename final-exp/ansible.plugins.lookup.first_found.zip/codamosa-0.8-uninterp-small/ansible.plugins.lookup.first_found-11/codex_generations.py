

# Generated at 2022-06-25 10:43:25.552723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #args[0] is a list of input to lookup_module_0.run
    #args[1] is a list of output that lookup_module_0.run should return
    args = [
            [['/etc/default/rpcbind'], {}],
            [['/etc/default/rpcbind'], {}]
            ]
    lookup_module_0 = LookupModule()
    output_0 = lookup_module_0.run(args[0][0], args[0][1])
    assert(output_0 == args[1])


# Generated at 2022-06-25 10:43:27.195495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  lookup_module_1.find_file_in_search_path(variables,subdir,fn,ignore_missing=True)

# Generated at 2022-06-25 10:43:35.671379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._connection = "localhost"
    lookup_module_0._templar = "undefined"
    lookup_module_0._loader = "undefined"
    lookup_module_0._options = dict()
    term1 = dict()
    term1['files'] = "foo,bar"
    term1['paths'] = "/tmp/production,/tmp/staging"
    term2 = dict()
    term2['files'] = "{{ ansible_distribution }}.yml,{{ ansible_os_family }}.yml,default.yml"
    term2['paths'] = "vars"
    term3 = dict()
    term3['files'] = "{{ ansible_virtualization_type }}_foo.conf,default_foo.conf"

# Generated at 2022-06-25 10:43:40.344989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # test for lookup_module_1.run
    assert lookup_module_1.run([]) == []

# NOTE: to test use template example, content can be 'Hello world', it will be printed
#
# - name: print test
#   debug:
#     msg: "{{ lookup('first_found', files=['test_case_1_file'], paths=['/tmp', '/tmp'], skip=True, errors='ignore') }}"


# Generated at 2022-06-25 10:43:50.701342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._subdir = 'files' # value added to environment when executing Ansible task
    lookup_module._templar = None
    total_search, skip = lookup_module._process_terms([{'files': ['foo','bar'],
                                                        'paths': ['/tmp/production','/tmp/staging']}], {}, {})
    assert total_search == ['/tmp/production/foo',
                            '/tmp/production/bar',
                            '/tmp/staging/foo',
                            '/tmp/staging/bar']
    assert skip == False

    total_search, skip = lookup_module._process_terms([{'files': 'foo, bar',
                                                        'paths': 'one, two',
                                                        'skip': True}], {}, {})

# Generated at 2022-06-25 10:43:58.020332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    variables_0 = None
    kwargs_0 = None
    x = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    try:
        assert x is None
    except AssertionError as e:
        raise AssertionError(str(e) + '\nrun(terms_0, variables_0, **kwargs_0) returned: ' + str(x))

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:44:01.851415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_terms = ['first_found']
    lookup_variables = {'ansible_virtualization_type': 'default'}

    file_path = lookup_module.run(lookup_terms, lookup_variables)
    assert file_path[0] == 'default.conf'
    return file_path

# Not implemented

# Generated at 2022-06-25 10:44:02.824651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:44:07.822035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(
        [True], dict(),
        files=[True],
        paths=[True]) == (
            [True, True],
            False
        )


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:44:17.946838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'files': ['admin.conf']})
    lookup_module_0.set_options(direct={'paths': []})
    # LookupModule::run(terms, variables, **kwargs)
    run_terms = [{"files": "admin.conf", "paths": ""}]
    run_variables = []
    run_kwargs = {"paths": [""]}
    actual = lookup_module_0.run(run_terms, run_variables, **run_kwargs)
    # LookupModule::run(terms, variables, **kwargs)
    run_terms = [{"files": "admin.conf", "paths": ""}]
    run_variables = []

# Generated at 2022-06-25 10:44:29.075736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    var_2 = lookup_module_3.run('X1\xeb\x8d\xa5\x84\xf6\x1c\xfb\x83', lookup_module_3)
    var_1 = lookup_module_3.run('\xc7\x99\x82\x80\xd0\x82\x9f\xdf\x1b\xc0\xaa\x81\x08\x1f\xcb\x9d\x07', lookup_module_3)
    var_0 = lookup_module_3.run('\xac\xdc\xf6\x0a\x12\x97\x19A\xc6\x1b', lookup_module_3)


# Generated at 2022-06-25 10:44:32.865321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    bytes_0 = b'\xb2\xee\x9f\x9do\xab\x03\xb0\x84\xa1+\xec\xbc9\xe9'
    result_0 = lookup_module_0.run(bytes_0, dict_0)
    assert isinstance(result_0, list) or isinstance(result_0, tuple)


# Generated at 2022-06-25 10:44:43.623310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    bytes_0 = b' \x8c\xe5\x19\xd6\xef\xac\xdfM\xb1\xe6\xeb\x0b\x93\xc3\xfb7\x0b\xe7'
    var_0 = lookup_module_0.run(bytes_0, lookup_module_0)
    lookup_module_1 = LookupModule()
    assert isinstance(var_0, list)
    assert len(var_0) == 1
    assert var_0[0] == 'test_file'

    var_1 = lookup_module_0.run(bytes_0, lookup_module_1)
    assert isinstance(var_1, list)

# Generated at 2022-06-25 10:44:50.041697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bytes_0 = b'\xa9A}V\xb2\xd2\x8bs\xf7L$'
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(bytes_0, lookup_module_0)
    assert result == []


# Generated at 2022-06-25 10:44:56.256716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [None]
    var_0 = lookup_module_0.run(list_0, list_0)
    assert isinstance(var_0, list)
    assert var_0 == []



# Generated at 2022-06-25 10:44:58.848667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Create an instance of of class LookupModule
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    # Invoke method run of LookupModule
    lookup_module_1.run(lookup_module_0, lookup_module_1)



# Generated at 2022-06-25 10:45:05.515192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameter 1
    # Parameter 2
    # Parameter 3
    # Get the lookup module
    lookup_module = LookupModule()
    lookup_module._subdir = 'templates'

    # Variable with the absolute path of the test files
    file_path = os.path.dirname(os.path.realpath(__file__))

    # Testing run method with terms as a list of strings
    terms = [
        "{0}/templates/file_0".format(file_path),
        "{0}/templates/file_1".format(file_path)
    ]
    # The expected result is file_path/templates/file_0
    result = lookup_module.run(terms=terms, variables=None)[0]

# Generated at 2022-06-25 10:45:15.584805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bytes_0 = b'\xa9A}V\xb2\xd2\x8bs\xf7L$'
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    # 1 Assertion Error
    # assert lookup_module_0.run(b'\n', lookup_module_0) == ['\n']
    # 2 Assertion Error
    # assert lookup_module_0.run(b'_', lookup_module_0) == ['_']
    # 3 Assertion Error
    # assert lookup_module_0.run(b'', lookup_module_0) == ['']
    # 4 Assertion Error
    # assert lookup_module_0.run(b'\r', lookup_module_0) == ['\r']
    #

# Generated at 2022-06-25 10:45:25.710950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'files': ['foo', 'bar'], 'paths': ['.', '..']}
    bytes_0 = b'\x01\x02\x03\x04\x05\x06'
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    lookup_module_0.run(bytes_0, dict_0)
    lookup_module_0.run(bytes_0, dict_0)
    lookup_module_1 = LookupModule()
    dict_1 = {'files': ['foo', 'bar'], 'paths': ['.', '..']}
    bytes_1 = b'\x01\x02\x03\x04\x05\x06'
    lookup_module_1.run(bytes_1, dict_1)
    lookup

# Generated at 2022-06-25 10:45:30.828633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        pprint(test_case_0())
    except Exception as e:
        print('Python exception raised:')
        print(e)

# Generated at 2022-06-25 10:45:44.080275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    int_0 = 0
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    arg_0 = {}
    arg_1 = {}
    arg_0[bytes_0] = arg_1
    arg_0[int_0] = lookup_module_1
    arg_0[bytes_1] = lookup_module_0
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(**arg_0)



# Generated at 2022-06-25 10:45:46.583796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The next line throws a TypeError for an unsupported keyword argument
    try:
        LookupModule().run()
    except TypeError:
        pass
    else:
        assert False, "unreachable"

# Generated at 2022-06-25 10:45:54.139963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'direct': {}}
    bytes_0 = b'\xa9A}V\xb2\xd2\x8bs\xf7L$'
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(bytes_0, lookup_module_0)
    lookup_module_2 = LookupModule()
    assert var_0 == []

# Generated at 2022-06-25 10:46:01.725852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  dict_0 = {}
  bytes_0 = b'\xa9A}V\xb2\xd2\x8bs\xf7L$'
  lookup_module_0 = LookupModule(dict_0, **dict_0)
  lookup_module_1 = LookupModule()
  var_0 = lookup_module_1.run(bytes_0, lookup_module_0)
  lookup_module_2 = LookupModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:46:07.817670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bytes_0 = b'\xa9A}V\xb2\xd2\x8bs\xf7L$'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(bytes_0, lookup_module_1)
    assert var_0 == None, "Returned: {}".format(var_0)

    lookup_module_2 = LookupModule()
    var_1 = lookup_module_2.run(bytes_0, lookup_module_1)
    assert var_1 == None, "Returned: {}".format(var_1)

    lookup_module_3 = LookupModule()
    var_2 = lookup_module_3.run(bytes_0, lookup_module_1)

# Generated at 2022-06-25 10:46:15.504845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bytes_0 = b'\xa9A}V\xb2\xd2\x8bs\xf7L$'
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(bytes_0, lookup_module_0)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:46:20.278694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
# Params
    terms = None
    variables = None
# Output
    result = True
    result = (result and (LookupModule(None, None).run(terms, variables) == True))
    return result


# Generated at 2022-06-25 10:46:26.431208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    bytes_0 = b'\xecT\xcd\xd6d\xc1\x9a\xe7\x0e\x8f\xac\x82\x98u\xeeB\xb4\xf4`\x16\x1c\xa8\xdaI'
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    lookup_module_1 = LookupModule()
    dict_1 = {}
    assert lookup_module_1.run(bytes_0, lookup_module_0) == dict_1

# Generated at 2022-06-25 10:46:32.135536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_module_1.run(dict_0, dict_0)
    lookup_module_2 = LookupModule()
    return var_0


# Generated at 2022-06-25 10:46:36.777857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    var_0 = lookup_module_1.run(lookup_module_0, lookup_module_2)
    var_0 = lookup_module_3.run(lookup_module_1, lookup_module_2)


# Generated at 2022-06-25 10:46:49.992479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False

    # Test case for method run of class LookupModule
    #
    # Test first_found lookup.
    # Option 'skip' is set to False.
    #
    try:
        lookup_run(dict_0, bool_0)
    except AnsibleLookupError:
        pass

    # Test case for method run of class LookupModule
    #
    # Test first_found lookup.
    # Option 'skip' is set to True.
    #
    try:
        lookup_run(dict0, True)
    except AnsibleLookupError:
        pass

# Generated at 2022-06-25 10:46:53.958918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {"foo": "bar"}
    dict_1 = {"yay": "bur"}
    dict_2 = {"foo": "bar", "yay": "bur"}
    path = ['']
    vars = []
    lookup_module_0.run(path, vars)

# Generated at 2022-06-25 10:47:04.613856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for run
    # NOTE: the test is incomplete, does not cover all cases.
    dict_0 = {}
    str_0 = "foo"

    map_0 = {"files": str_0}
    list_0 = ["foo"]
    str_1 = "bar"
    list_1 = ["bar"]
    list_2 = [map_0]

    lookup_module_0 = LookupModule()

    # NOTE: using a list as a term will do different things than using a dict as
    # term.
    result_0 = lookup_module_0.run(list_0, dict_0)
    result_1 = lookup_module_0.run(list_2, dict_0)
    assert result_0[0] == result_1[0]


# Generated at 2022-06-25 10:47:05.496341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    var = lookup.run()
    assert var is None

# Generated at 2022-06-25 10:47:08.297605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['']
    variables = ['']
    lookup_module_run = lookup_module.run(terms, variables)
    expected = None
    assert expected == lookup_module_run


# Generated at 2022-06-25 10:47:12.763485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    # TODO: Need to test with valid arguments
    # bool_0 = lookup_module_0.run(list_0, dict_0)
    test_case_0()

# Generated at 2022-06-25 10:47:23.091360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    g_var_0 = LookupModule()
    g_var_1 = [{}]
    g_var_2 = {}
    g_var_2['first_found'] = g_var_0
    g_var_2['ansible_lookup_plugin_version'] = '0'
    g_var_2['_terms'] = 'a'
    g_var_2['params'] = 'a'
    g_var_2['files'] = 'a'
    g_var_2['paths'] = 'a'

# Generated at 2022-06-25 10:47:26.513290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Declare argument as dictionary
    dict_0 = {}
    # Declare argument as dictionary
    dict_1 = {}
    # Declare argument as dictionary
    dict_2 = {}
    lookup_run(dict_0, dict_1, dict_2)

# Generated at 2022-06-25 10:47:28.551957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)


# Generated at 2022-06-25 10:47:30.887557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_module_0.run(dict_0, bool_0)


# Generated at 2022-06-25 10:47:43.092655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variables_0 = {}
    list_0 = []
    str_0 = lookup_module_0.run(list_0, variables_0, skip=False)

# Generated at 2022-06-25 10:47:46.702080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    lookup_module_0.set_options(dict_0)
    lookup_module_0.run(dict_0, dict_0, bool_0)

# Generated at 2022-06-25 10:47:53.588063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'b',
        'a'
    ]
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0, skip=False)


# Generated at 2022-06-25 10:48:00.834984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list_1 = []
    dict_0 = {}
    dict_1 = {}
    dict_1['files'] = dict_0
    dict_1['paths'] = list_1
    dict_1['skip'] = False
    dict_1['_terms'] = []
    dict_2 = {}
    dict_2['_terms'] = dict_1
    dict_2['files'] = dict_0
    dict_2['paths'] = list_1
    dict_2['skip'] = False
    dict_3 = {}
    dict_3['files'] = dict_0
    dict_3['paths'] = list_1
    dict_3['skip'] = False
    dict_3['_terms'] = []
    dict_4 = {}

# Generated at 2022-06-25 10:48:05.088605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {'paths': [], 'files': []}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)


# Generated at 2022-06-25 10:48:13.469092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['default.yml', 'rhel.yml']
    variables_0 = {}
    lookup_module_0.set_options(var_options=variables_0, direct={'files': ['default.yml', 'rhel.yml'], 'paths': ['vars'], 'skip': False}, validate_files=True, basedir=None, context='', task_vars=None, variable_manager=None, loader=None, templar=None, shared_loader_obj=None, original_loader=None, is_playbook=False, is_task=False, is_handler=False)

# Generated at 2022-06-25 10:48:23.590742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # NOTE: on return lookup_run(args) will pass the retun through 'from_json'
    # but the original method returns a list.
    # This is the hack to get around this while building the tests
    _lookup_run = lookup_run
    lookup_run = lambda *x: _lookup_run(x)[0]

    # Check for missing files
    assert lookup.run(["badfile"], dict()) == [], "No file found, should have returned empty list"

    # Check for bad filter
    assert lookup.run(["badfile"], dict(), filter='bad') == [], "Bad filter, should have returned empty list"

    # Check for first match
    # NOTE: unittests will have this file in the same dir as the unittest

# Generated at 2022-06-25 10:48:34.965491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    list_0 = []
    list_1 = [dict_0]
    str_0 = 'files'
    str_1 = 'paths'
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    list_7 = ['genesis.vmlinuz']
    list_8 = ['wrong/path/genesis.vmlinuz']
    list_9 = ['wrong/path/genesis.vmlinuz']
    list_10 = []
    list_11 = ['genesis.vmlinuz', 'wrong/path/genesis.vmlinuz']
    list_12 = []
    list_13 = []
    list_14 = []
    list_15

# Generated at 2022-06-25 10:48:42.920819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    if PY2:
        from ansible.vars.unsafe_proxy import UnsafeProxy
    else:
        from ansible.vars.unsafe_proxy import AnsibleUnsafeText as UnsafeProxy

    try:
        # pass in some bogus variables
        lookup_module.run([], dict(var_0=UnsafeProxy('foo'), var_1=UnsafeProxy(1, 'str')), skip=True)
        assert False
    except AnsibleLookupError:
        assert True


# Generated at 2022-06-25 10:48:54.109343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {"abc": "abc", "def": "def", "files": [], "skip": False, "xyz": "xyz"}
    list_0 = ["abc", "def", "xyz"]
    bool_0 = False
    var_0 = lookup_module_0.run(list_0, dict_0, skip=bool_0)
    assert var_0 == []

# Generated at 2022-06-25 10:49:11.441987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:49:17.113647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    names_0 = ["foo.txt", "bar.txt", "biz.txt"]
    path_0 = "foo.txt"
    test_LookupModule_Class_0 = LookupModule()
    test_LookupModule_Class_0._subdir = "files"
    temp_var_0 = test_LookupModule_Class_0.find_file_in_search_path(names_0, path_0, False)
    assert temp_var_0 is not None


test_LookupModule_run()
test_case_0()

# Generated at 2022-06-25 10:49:20.714694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    dict_0 = {}
    bool_0 = False
    bool_1 = True
    var_1 = lookup_run(dict_0, bool_0)
    path_0 = VarTest(var_1)
    path_1 = VarTest(var_0)
    assert_equals(path_0, path_1)


# Generated at 2022-06-25 10:49:24.177953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._terms = []
    lookup_module_0._subdir = 'files'
    lookup_module_0.paths = []
    lookup_module_0.files = []
    lookup_module_0.errors = None
    variables_0 = {}
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(lookup_module_0._terms, variables_0)


# Generated at 2022-06-25 10:49:34.554471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _lookup_module = LookupModule()
    _lookup_module._templar = ['']
    with pytest.raises(AnsibleLookupError) as excinfo:
        _lookup_module.run([''], [''])
    msg = "Got a template string when expecting a list"
    assert str(excinfo.value) == msg
    with pytest.raises(AnsibleLookupError) as excinfo:
        _lookup_module.run(['a', ''], [''])
    msg = "Got a template string when expecting a list"
    assert str(excinfo.value) == msg
    _lookup_module_1 = LookupModule()
    _lookup_module_1._templar = ['']

# Generated at 2022-06-25 10:49:45.001978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_case_0():
        lookup_module_0 = LookupModule()
        dict_0 = {}
        bool_0 = False
        var_0 = lookup_run(dict_0, bool_0)
        return var_0

    def lookup_run(terms, variables):
        total_search, skip = lookup_module_0._process_terms(terms, variables, kwargs)
        return total_search

    lookup_module_0 = LookupModule()
    dict_0 = {
        'a': 'aaaaa',
        'b': 'bbbbb',
        'c': 'ccccc',
    }
    assert lookup_run(dict_0, dict_0) == ['aaaaa', 'bbbbb', 'ccccc']

    assert lookup_run([], dict_0) == []

    dict

# Generated at 2022-06-25 10:49:47.725292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    str_0 = "run"
    var_0 = lookup_module_0.run(dict_0, bool_0, method=str_0)
    assert var_0  == []


# Generated at 2022-06-25 10:49:50.138742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement tests
    pass

# Generated at 2022-06-25 10:49:53.197221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)
    assert var_0 == [], 'assertion failed'


# main function call
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:49:56.788359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    dict_0.update(dict_1)
    bool_0 = False
    str_0 = lookup_run(dict_0, bool_0)
    print(str_0)


# Generated at 2022-06-25 10:50:29.729489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin=LookupModule()
    assert plugin.run(['foo'], [{'hostvars': {'galaxy.server': {}}}, {'hostvars': {'galaxy.client': {}}}]) is None

# Generated at 2022-06-25 10:50:34.560086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create test object
    LookupModule_obj_0 = LookupModule()

    # create expected result
    list_0 = []

    # test the run function
    assert LookupModule_obj_0.run([],{}) == list_0



# Generated at 2022-06-25 10:50:40.705421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)
    

# Generated at 2022-06-25 10:50:49.399246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("[+] Testing LookupModule.run")
    dict_0, dict_1, dict_2 = {}, {}, {}
    dict_0[" 1 "] = "2"
    dict_2[" 3 "] = dict_1
    dict_1[" 4 "] = "5"
    dict_2[" 6 "] = "7"
    dict_0[" 8 "] = dict_2
    bool_0 = True
    text_0 = "FALSE"
    dict_2[" 9 "] = text_0
    dict_0[" 10 "] = dict_2
    bool_1 = False
    dict_0[" 11 "] = bool_1
    lookup_module_0 = LookupModule()
    bool_2 = True
    dict_0[" 12 "] = bool_2

# Generated at 2022-06-25 10:50:51.344058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)


# Generated at 2022-06-25 10:50:58.577138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}

# Generated at 2022-06-25 10:51:09.220938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # compile and run
    compileString('from ansible.plugins.lookup import first_found\nlookup_module = first_found.LookupModule()\nvars = {}\nlookup_module.run(["foo.txt", "bar.txt"], vars)\n')
    # unit test

# Generated at 2022-06-25 10:51:15.196822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This should raise an error.
    lookup_module = LookupModule()
    dict_0 = {}
    bool_0 = False
    try:
        lookup_module.run(dict_0, bool_0)
    except AnsibleLookupError:
        pass
    else:
        raise Exception("AnsibleLookupError expected.")


# Generated at 2022-06-25 10:51:18.473900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([{'paths': '/tmp'}, {'files': 'foo.txt'}], None)

# Generated at 2022-06-25 10:51:26.021962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Declare object of class LookupModule without argument
  lookup_module = LookupModule()
  # Declare variables
  terms = ["foo.txt", "biz.txt", "bar.txt"]

# Generated at 2022-06-25 10:52:35.098152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  dict_0 = {}
  bool_0 = False
  var_0 = lookup_run(dict_0, bool_0)
  assert var_0 == 'path'


# Generated at 2022-06-25 10:52:40.061143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if last find file in search path value is not equal to none.
    assert not path is None

# Generated at 2022-06-25 10:52:45.425179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    # TODO: Test probably doesn't work because no role or play in
    # env# TODO: Test probably doesn't work because no role or play in
    # env
    lookup_module_0.run(dict_0, bool_0)



# Generated at 2022-06-25 10:52:48.582079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)



# Generated at 2022-06-25 10:52:56.957830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import os

    # create a temporary directory
    temp_dir = tempfile.mkdtemp()
    lookup_module_0 = LookupModule()
    with open(os.path.join(temp_dir, "file0.txt"), 'w') as f:
        f.write('Hello\n')
    with open(os.path.join(temp_dir, "file1.txt"), 'w') as f:
        f.write('hello\n')
    dict_0 = {'files': 'file0.txt'}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)

    # lookup_module_0.run(dict_0, bool_0):
    assert dict_0['files'] == var_0[0]

# Generated at 2022-06-25 10:53:02.932274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {
      "paths": [
      ],
      "files": [
      ]
    }
    bool_0 = False
    var_0 = lookup_module_0.run(dict_0, bool_0)


# Generated at 2022-06-25 10:53:05.273322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    bool_0 = False
    var_0 = lookup_run(dict_0, bool_0)

# Generated at 2022-06-25 10:53:08.784077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert isinstance(LookupModule().run(terms, variables, **kwargs), list)
    assert True

