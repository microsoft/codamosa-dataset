

# Generated at 2022-06-25 10:43:14.766640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_0 = ['test_file']
    test_variables_0 = {}
    test_kwargs_0 = {'skip': False}
    test_method_result_0 = lookup_module_0.run(test_terms_0, test_variables_0, **test_kwargs_0)
    assert test_method_result_0 == ['test_file']


# Generated at 2022-06-25 10:43:25.292982
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:43:31.057783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['/etc/hosts'], None) == ['/etc/hosts']


# Generated at 2022-06-25 10:43:38.003727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo.txt', 'bar.txt']
    kwargs_0 = dict()
    # kwargs_0 = dict(default='')
    kwargs_0['skip'] = False
    variables_0 = dict()
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == ['/tmp/foo.txt']


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:43:42.241586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['abc', {'files': [], 'paths': []}]
    terms[0] = 'abc'
    terms[1] = {'files': [], 'paths': []}
    variables = dict()
    kwargs = dict()
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == []


# Generated at 2022-06-25 10:43:48.176338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Test with required arguments
    try:
        lookup_module_1.run(['bar.txt', 'foo.txt'])
        assert False, "An error was not raised for function run"
    except:
        assert True

# Running the tests
if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:43:54.392816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = dict()
    hostvars['ansible_virtualization_type'] = 'kvm'
    hostvars['ansible_os_family'] = 'RedHat'
    hostvars['ansible_distribution'] = 'CentOS'

    lookup_module_0 = LookupModule()

    terms = list()
    terms.append({
        'files': 'kvm_foo.conf',
        'paths': '/tmp/production,/tmp/staging',
        'skip': True
    })
    terms.append({
        'files': '{{ ansible_os_family }}.yml, {{ ansible_distribution }}.yml, default.yml',
        'paths': 'vars',
        'skip': True
    })

# Generated at 2022-06-25 10:43:57.847324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  fnlist = ['../../../../../ansible/plugins/lookup/first_found.py']
  f = open(fnlist[0], 'r')
  file_txt = f.read()
  f.close()
  assert file_txt[0] == 'f'


# Generated at 2022-06-25 10:44:06.621256
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # setup test
  test_dict = {
    'files': 'foo.txt,bar.txt',
    'paths': 'path/to/file1/,path/to/file2/,path/to/file3/',
  }

  test_list = [test_dict] * 3

  lookup = LookupModule()
  lookup.set_options(var_options=None, direct=test_dict)
  total_search, skip = lookup._process_terms(test_list, variables=None, kwargs={})


# Generated at 2022-06-25 10:44:12.650410
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Expected result: []

    terms_0 = []

    variables_0 = []

    kwargs_0 = {}

    assert lookup_module_0.run(terms_0,variables_0,**kwargs_0) == []

# Generated at 2022-06-25 10:44:19.841321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    terms = {}
    variables = {}
    kwargs = {}
    assert isinstance(lookup_module_0.run(terms, variables, **kwargs), list)
    assert isinstance(lookup_module_0.run(terms, variables, **kwargs)[0], str)


# Generated at 2022-06-25 10:44:28.143869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    assert module.run([{
        'files': 'foo,bar',
        'paths': '/tmp/staging:/tmp/production',
        'skip': True
    }], dict()) == []

    assert module.run(['foo', 'bar'], dict()) == []

    assert module.run([{
        'files': 'foo,bar',
        'paths': '/tmp/staging:/tmp/production',
        'skip': False
    }], dict()) == []

    assert module.run([{
        'files': 'foo,bar',
        'paths': '/root/foo/bar',
        'skip': False
    }], dict()) == []

    assert module.run(['/root/foo/bar/foo'], dict()) == []


# Generated at 2022-06-25 10:44:30.212134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # TODO: add cases
    # lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:44:42.240232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'_raw': 'raw', 'files': 'files', 'paths': None, 'skip': True})

# Generated at 2022-06-25 10:44:48.535074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ '', '', '' ]
    variables_0 = {}
    kwargs_0 = {}
    returned_value_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert returned_value_0 is not None


# Generated at 2022-06-25 10:44:49.979786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
    ]
    kwargs_0 = {
    }
    assert lookup_module_0.run(terms_0, terms_0, **kwargs_0) == None

# Generated at 2022-06-25 10:44:59.645936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'files': 'bar.txt', 'paths': '/path/to', 'skip': False})
    output_of_run = lookup_module_0.run(_split_on(['foo.txt', 'bar.txt', 'baz.txt']), {'hostvars': {'host_0': {'ansible_host': 'host_0'}}})
    assert len(output_of_run) == 1
    assert isinstance(output_of_run, list)
    assert output_of_run[0] == '/path/to/bar.txt'



# Generated at 2022-06-25 10:45:08.552360
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Case 0
    orig_terms = 'some_string' # file name to use in search
    variables = dict() # dict or AnsibleVars object
    kwargs = dict() # dict or AnsibleVars object
    expected_result = list() # expected result of the call to the method run
    actual_result = lookup_module.run(orig_terms, variables, **kwargs)
    assert actual_result == expected_result, 'expected:%s actual:%s' % (expected_result, actual_result)



# Generated at 2022-06-25 10:45:13.773393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_obj = LookupModule()

    # Not sure how to provide input for method run, got error as
    # **kwargs not found,
    # So not running the test case
    # lookup_module_run_obj.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:45:18.713311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()
    # Get inputs for the Ansible lookup
    lookup_result = lookup_module_0.run({'a':1, 'b': 2})
    print(lookup_result)
    return lookup_result


if __name__ == '__main__':
    print(test_LookupModule_run())

# Generated at 2022-06-25 10:45:29.758142
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [{
        "skip": True,
        "paths": "/home/foo/bar",
        "files": "id_rsa"}]

    variables = {"ansible_hostname": "localhost"}

    expected_result = "/home/foo/bar/id_rsa"
    actual_result = LookupModule().run(terms, variables)

    assert actual_result == expected_result, "Test Failed: expected result is %s, but got %s" % (expected_result, actual_result)


# Generated at 2022-06-25 10:45:37.495417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First parameter is a string
    # Second parameter is a dict
    # Third parameter is a dict
    test_case_run_0(['foo'], {}, {})
    test_case_run_1(['foo'], {'files': ['bar']}, {})
    test_case_run_2(['foo'], {'files': ['bar'], 'paths': ['baz']}, {})
    test_case_run_3(['foo'], {'files': ['bar'], 'paths': ['baz']}, {})
    test_case_run_4(['foo'], {'files': ['bar'], 'paths': ['baz']}, {})
    test_case_run_5(['foo'], {'files': ['bar'], 'paths': ['baz']}, {})
   

# Generated at 2022-06-25 10:45:38.626719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:45:48.492804
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms = [
        {
            "files": "foo",
            "paths": "/tmp/production;/tmp/staging"
        },
    ]
    variables = {
        "ansible_virtualization_type": "",
        "foo": "bar"
    }
    kwargs = {
    }
    # test raises exception: Invalid term supplied, can handle string, mapping or list of strings but got: <class 'dict'> for {'files': 'foo', 'paths': '/tmp/production;/tmp/staging'}
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:46:00.246496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 'a' case
    lookup_module_1 = LookupModule()
    terms_1 = None
    variables_1 = None
    args_1 = {'skip': None}
    expected_result_1 = False
    return_result_1 = lookup_module_1.run(terms_1, variables_1, **args_1)
    assert return_result_1 == expected_result_1
    # Test 'b' case
    lookup_module_2 = LookupModule()
    terms_2 = None
    variables_2 = None
    args_2 = {'skip': True}
    expected_result_2 = True
    return_result_2 = lookup_module_2.run(terms_2, variables_2, **args_2)
    assert return_result_2 == expected_result_2
    # Test

# Generated at 2022-06-25 10:46:11.755133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_1 = LookupModule().run(terms=['test_terms_0', 'test_terms_1'], variables={
        'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1'})
    lookup_module_run_2 = LookupModule().run(terms=['test_terms_2', 'test_terms_3'], variables={
        'test_key_2': 'test_value_2', 'test_key_3': 'test_value_3'})
    assert lookup_module_run_1 is None
    assert lookup_module_run_2 is None


# Generated at 2022-06-25 10:46:15.590756
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup context for test call
    lookup_module_run_0_obj = LookupModule()

    str_0_var = 'terms'
    list_0_var = []
    dict_0_var = {}

    lookup_module_run_0_return = lookup_module_run_0_obj.run(list_0_var, dict_0_var)



# Generated at 2022-06-25 10:46:23.126969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # testing without any parameters
    assert len(LookupModule().run(None, None)) == 0

    # testing with valid parameters
    assert len(LookupModule().run(['test_values'], None)) == 1

    # testing with invalid parameters of correct type
    assert len(LookupModule().run([0], None)) == 0

    # testing with invalid parameters of incorrect type
    try:
        LookupModule().run(0)
    except Exception as e:
        if isinstance(e, TypeError) and e.args[0] == 'run() takes at least 2 arguments (1 given)':
            pass
        else:
            raise AssertionError(str(e))

# Generated at 2022-06-25 10:46:33.808828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mPath = os.path.join(os.path.dirname(__file__), "vars")
    for _, _, files in os.walk(mPath):
        for f in files:
            matched_file = f.split('.')
            if matched_file[0] == "test_file":
                test_file_path = os.path.join(mPath, f)
                test_file = open(test_file_path, "r")
                test_case = test_file.readline().rstrip()
                test_file_content = test_file.readline().rstrip()
                test_file.close()
                data = eval(test_file_content)
                path = os.path.dirname(os.path.dirname(__file__))
                lookup_module = LookupModule()
               

# Generated at 2022-06-25 10:46:38.533780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    assert lookup_module_0 is not None
    assert lookup_module_1 is not None
    assert lookup_module_2 is not None

    assert lookup_module_0 is not lookup_module_1
    assert lookup_module_0 is not lookup_module_2

    assert lookup_module_1 is not lookup_module_2

# Generated at 2022-06-25 10:46:57.107893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupBase)
    lookup_module_0._subdir = 'files'
    terms = (None, 'default')

# Generated at 2022-06-25 10:47:00.804653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["foo", "bar", "baz"]
    variables = {}

    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:47:08.844255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'terms': [{'paths':['/tmp/'], 'files':'file1,file2'}, '/tmp/file3'], 'variables': {}}
    kwargs = {'errors': 'ignore'}
    lookup_module_ = LookupModule()
    result = lookup_module_.run(**args)
    assert result == ['']

# Generated at 2022-06-25 10:47:14.507366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={'files': ['foo', 'bar'], 'paths': ['path', 'path2']}, validate=True)

    lookup_module_0._templar.template = lambda x: '{0}/{1}'.format('path', x)

    lookup_module_0.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: '{0}/{1}'.format(subdir, fn)

    lookup_module_0._subdir = 'files'

    lookup_module_0.run(terms=['foo', 'bar'], variables={}, skip=False)

# Generated at 2022-06-25 10:47:18.078952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._subdir='files'
    lookup_module_1._templar='-template-'
    lookup_module_1.find_file_in_search_path=lambda x, y, z, ignore_missing=False: '/'+z
    # test function run of class LookupModule
    assert lookup_module_1.run('_term', '_variables') == ['/_term']

# Generated at 2022-06-25 10:47:28.722556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test Cases for the first varient of run method

    # TODO: I am not able to test if the file exists in /etc/ansible/ directory of ansible.
    #       I am bypassing the test case.
    #assert lookup_module_0.run('rc.local', {}) == ['/etc/ansible/rc.local']

    assert lookup_module_0.run('rc.local', {}, paths=['/etc/ansible']) == ['/etc/ansible/rc.local']

    assert lookup_module_0.run('rc.local', {}, files='rc.local', paths='/etc/ansible') == ['/etc/ansible/rc.local']

    # Test Cases for the second varient of run method

    # TODO: I am not able

# Generated at 2022-06-25 10:47:33.971719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms = ["MyTerm1","MyTerm2"]
    variables = "MyVariables"
    kwargs = {
      '_aaa': 'My_aaa'
    }
    try:
        lookup_module_run.run(terms, variables, **kwargs)
    except Exception as e:
        assert "AnsibleLookupError: Invalid term supplied, can handle string, mapping or list of strings but got: <class 'str'> for MyTerm1" == str(e)


# Generated at 2022-06-25 10:47:36.200679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['foo.txt']
    variables_1 = dict()
    assert lookup_module_1.run(terms_1, variables_1) == []

# Generated at 2022-06-25 10:47:38.795016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_options = set_options_test()
    _process_terms = _process_terms_test()
    test_case_0()
    test_output = LookupModule.run(lookup_module_0, _process_terms, set_options, skip=True)
    assert test_output == []


# Generated at 2022-06-25 10:47:50.384019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    variables_0 = {}
    kwargs_0 = {}
    subdir_0 = ''
    lookup_module_0._subdir = subdir_0
    path_0 = 'hello'
    fn_0 = 'hello'
    variables_1 = {}
    lookup_module_0._templar = variables_1._templar
    lookup_module_0.find_file_in_search_path = variables_1.find_file_in_search_path
    lookup_module_0.set_options = variables_1.set_options
    lookup_module_0.get_option = variables_1.get_option
    assert lookup_module

# Generated at 2022-06-25 10:48:09.500225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{
        "files": [
            "foo",
            "bar"
        ],
        "paths": [
            "/tmp/production",
            "/tmp/staging"
        ]
    }]
    variables = [{
        "ansible_distribution": "debian",
        "ansible_os_family": "Debian"
    },
    {
        "inventory_hostname": "foo"
    }]
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:48:12.654382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    lookup_module_0._templar = 'files'
    terms_0 = []
    vars_0 = 'files'
    lookup_module_0.run(terms_0, vars_0)

# Generated at 2022-06-25 10:48:17.616646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up object
    lookup_module = LookupModule()

    # set up mocks
    lookup_module._process_terms = MagicMock(return_value=[['first_found_param']], name='_process_terms')
    lookup_module._templar = MagicMock(name='_templar')
    lookup_module._templar.template = MagicMock(return_value='first_found_param')
    lookup_module.find_file_in_search_path = MagicMock(return_value=True)

    # call unit under test
    result = lookup_module.run([[{'param1': 'value1'}]])

    # assert results
    assert result == True

# Generated at 2022-06-25 10:48:22.937591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    path = lookup_module_0.run([], {})
    assert path == []

# Generated at 2022-06-25 10:48:30.161217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['foo.txt', 'bar.txt']
    variables = ''
    kwargs = {'files':'', 'paths':'', 'skip':'False'}
    lookup_module._process_terms(terms, variables, kwargs)

# Generated at 2022-06-25 10:48:41.319071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Method run of module LookupModule has errors

# Generated at 2022-06-25 10:48:49.096424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "Ansible"
    terms_1 = "\"Ansible\""
    terms_2 = "'''Ansible'''"
    terms_3 = "['Ansible']"

    assert lookup_module_0.run(terms_0) == lookup_module_0.run(terms_1)
    assert lookup_module_0.run(terms_0) == lookup_module_0.run(terms_2)
    assert lookup_module_0.run(terms_0) == lookup_module_0.run(terms_3)


# Generated at 2022-06-25 10:48:53.772859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module_0 = LookupModule()
        def raiser_func():
            raise Exception
        lookup_module_0._loader = raiser_func
        lookup_module_0._templar = raiser_func
        assert lookup_module_0.run(['']) == []

# Generated at 2022-06-25 10:48:54.316814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:48:59.998891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    setattr(lookup_module_0, '_templar', lookup_module_0.templar)
    lookup_module_0._templar.available_variables = {}
    var_options = {}
    direct = {'files': []}
    lookup_module_0.set_options(var_options=var_options, direct=direct)
    terms = []
    var_options = {}
    lookup_module_0.run(terms=terms, variables=var_options)


# Generated at 2022-06-25 10:49:14.242499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)

# Generated at 2022-06-25 10:49:19.668975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup:
    import tests.unit.plugins.lookup.platforms.linux.fixtures.first_found_terms as terms
    from ansible.utils.path import unfrackpath

    lookup_module = LookupModule()
    lookup_module._subdir = 'templates'

    # Exercice:
    for term, expected in terms.TEST_CASES:
        result = lookup_module.run(term, {}, terms=term)

        # Check:
        assert_equal(len(result), 1)
        assert_equal(unfrackpath(result[0]), unfrackpath(expected))


# Generated at 2022-06-25 10:49:21.704539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = '_terms'
    var_3 = None
    lookup_module_1 = LookupModule()
    var_4 = {}
    var_1 = lookup_run(var_4, lookup_module_1, **var_4)
    assert var_1 == []


# Generated at 2022-06-25 10:49:27.083005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = {}
    lookup_module_2 = lookup_module_1.run(var_0, var_0)

# Generated at 2022-06-25 10:49:30.291811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # list of Strings
    var_0 = ['foo', 'bar', 'baz', 'bat', 'boo', 'bat']
    var_1 = lookup_run(var_0, lookup_module_0)


# Generated at 2022-06-25 10:49:33.033379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule.run
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(lookup_module_0, **var_0)

# Generated at 2022-06-25 10:49:40.524806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with path arguments
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)
    # test with files arguments
    lookup_module_1 = LookupModule()
    var_2 = {}
    var_3 = lookup_run(var_2, lookup_module_1, **var_2)
    # test with paths arguments
    lookup_module_2 = LookupModule()
    var_4 = {}
    var_5 = lookup_run(var_4, lookup_module_2, **var_4)
    # test with skip arguments
    lookup_module_3 = LookupModule()
    var_6 = {}

# Generated at 2022-06-25 10:49:51.492241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # unit test for error condition
    # throw exception with message "No file was found when using first_found."
    with pytest.raises(AnsibleLookupError) as pytest_wrapped_e:
        var_2 = {}
        lookup_run(var_2, lookup_module, **var_2)
    assert pytest_wrapped_e.type == AnsibleLookupError
    assert pytest_wrapped_e.value.args[0] == "No file was found when using first_found."
    # cleanup function call stack
    # cleanup function call stack
    recursive_delfile("unit_test/test/test_first_found_lookup_plugin/test_1/files/found")

# unit test for method _process_terms of class LookupModule

# Generated at 2022-06-25 10:49:56.585675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {
        'paths': ['/tmp/test_dir'],
        'file1': 'testfile.txt',
        'file2': 'testfile2.txt',
        'file3': 'testfile3.txt',
    }
    lookup_module = LookupModule()

    var_1 = lookup_run(None, lookup_module, [params])
    var_2 = lookup_run(None, lookup_module, [params])



# Generated at 2022-06-25 10:50:02.196094
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import io
    import sys
    import unittest

    # init
    lookup_module_0 = LookupModule()

    # testcase0: no file found, raise Error
    terms_0 = ['/tmp/does_not_exist.txt']
    var_0 = {}
    expected_0 = False

    try:
        result_0 = lookup_run(var_0, lookup_module_0, terms=terms_0, **var_0)
        result_0 = True if result_0 else False
    except Exception:
        result_0 = False

    assert expected_0 == result_0

# Generated at 2022-06-25 10:50:16.175805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = {}
    lookup_module_3 = LookupModule()
    lookup_module_3.run(var_2, var_2, var_2)


# Generated at 2022-06-25 10:50:19.877586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, var_0)


# Generated at 2022-06-25 10:50:30.417541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate class LookupModule
    lookup_module_2 = LookupModule()

    # Call method run on the class LookupModule
    var_1 = lookup_run(var_0, lookup_module_2, **var_0)
    var_1 = lookup_run(var_0, lookup_module_2, **var_0)
    var_1 = lookup_run(var_0, lookup_module_2, **var_0)
    var_1 = lookup_run(var_0, lookup_module_2, **var_0)
    var_1 = lookup_run(var_0, lookup_module_2, **var_0)
    var_1 = lookup_run(var_0, lookup_module_2, **var_0)

# Generated at 2022-06-25 10:50:34.328617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)


# Generated at 2022-06-25 10:50:36.185788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)

# Generated at 2022-06-25 10:50:46.333709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    lookup_module_0 = LookupModule()

    lookup_module_0._subdir = 'files'
    var_0 = {}

    # NOTE: this is a 'bug' in the interface that requires a dict but templates any list
    # because the interface is a list and not dict
    # if we pass a dict, any value can clobber previous ones
    lookup_module_0.set_options(var_options=var_0, direct={'files': ['foo', 'bar'], 'paths': ['files']})
    var_1 = lookup_module_0.run(['foo', 'bar'], var_0, skip=True)

    # if we pass a list, the first value is what we get
    # however, if all the dicts use the same name, that value is 'valid'
   

# Generated at 2022-06-25 10:50:54.549046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {'skvidal': 'skvidal', 'path': '/var/cache/something'}
    lookup_module_0.set_options(var_options=var_0, direct={'files': ['skvidal'], 'paths': ['/var/cache/something']})
    var_1 = lookup_module_0.run('skvidal', var_0)
    assert var_1 == ['/var/cache/something/skvidal']



# Generated at 2022-06-25 10:50:57.125435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)



# Generated at 2022-06-25 10:51:08.250751
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:51:13.097706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_module_0.run(var_0, var_0)


# Generated at 2022-06-25 10:51:41.786536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    var_0 = {}
    try:
        var_1 = lookup_run(var_0, lookup_module_0, **var_0)
    except AnsibleLookupError as e:
        assert False


# Generated at 2022-06-25 10:51:48.785556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_14 = {}
    var_14['skip'] = False
    var_15 = lookup_run(var_14, lookup_module_0, **var_14)


# Generated at 2022-06-25 10:51:50.404653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  with pytest.raises(AnsibleLookupError) as error:
    assert LookupModule().run(terms='', variables={}) == 'No file was found when using first_found.'

# Generated at 2022-06-25 10:52:01.911878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    var_0 = {}
    var_1 = {}
    var_1['environment'] = 'prod'
    var_1['lookup_terms'] = 'terms'
    var_1['_templar'] = 'templar'
    var_1['templar'] = 'templar'
    var_1['_loader'] = 'loader'
    var_1['paths'] = 'paths'
    var_1['skip'] = 'skip'
    var_1['files'] = 'files'
    var_1['_plugin_name'] = 'plugin_name'
    var_1['_orig_basename'] = 'orig_basename'

# Generated at 2022-06-25 10:52:06.587387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)
    # assertEquals(var_1, var_0)

# Generated at 2022-06-25 10:52:12.923114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)
    var_2 = lookup_run(var_0, lookup_module_1, **var_0)
    var_3 = lookup_run(var_0, lookup_module_2, **var_0)

# Generated at 2022-06-25 10:52:15.144295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    print("Test case 0")
    return True


# Generated at 2022-06-25 10:52:18.128743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: update unit test
    assert True



# Generated at 2022-06-25 10:52:20.296650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)

# Generated at 2022-06-25 10:52:26.348226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, lookup_module_0, **var_0)


if __name__ == '__main__':
    test_case_0()