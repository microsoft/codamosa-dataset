

# Generated at 2022-06-25 10:43:18.695477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b''
    lookup_module_0 = LookupModule(bytes_0)

    params_0 = [ (dict()), (dict(bytes_0, )), ]
    _vars_0 = dict()

    # Returns a path to the first file found in the supplied list of paths, it uses the `first_found` lookup plugin.
    #
    # Syntax:
    #
    #    - first_found:
    #        files:
    #          - foo
    #          - bar
    #        paths:
    #          - /tmp/production
    #          - /tmp/staging
    #
    # This lookup uses a list for `paths` and a list for `files`.
    # If `files` is defined then it will take precedence over any file(s) defined in the list of paths.
   

# Generated at 2022-06-25 10:43:28.559762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b''
    lookup_module_0 = LookupModule(bytes_0)

    # Case 1 - not used as a task
    try:
        lookup_module_0.run(terms, variables, **kwargs)
        assert False, "AnsibleLookupError not raised"
    except AnsibleLookupError:
        pass

    try:
        lookup_module_0.run(terms, variables, **kwargs)
        assert False, "AnsibleLookupError not raised"
    except AnsibleLookupError:
        pass

    # Case 2 - Simple
    terms = []
    variables = {}
    kwargs = {}

# Generated at 2022-06-25 10:43:39.182260
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    # NOTE: when running tests from parent, this will not work
    # unfortunately python can not just import a 'global' file
    import ansible.plugins.lookup.first_found
    ansible.plugins.lookup.first_found.LookupBase = LookupBase

    # TODO: try to assign this to the module globals?
    params = {'files': 'hosts', 'paths': '/etc/ansible'}
    lookup_module_0 = LookupModule(params)

    # fake 'variables'
    class VariableModule():
        def __init__(self):
            self.vars = {}

    # test with 'skipping' on and empty file list
    variables_0 = VariableModule()
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run

# Generated at 2022-06-25 10:43:40.088817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test not easy to do
    pass


# Generated at 2022-06-25 10:43:47.096634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We don't have a lookup_module object to work with, we need to create it
    bytes_0 = b''
    lookup_module_0 = LookupModule(bytes_0)
    # check that 'terms' is required param
    try:
        lookup_module_0.run()
    except TypeError:
        pass
    else:
        raise TypeError
    # Check that 'variables' is required param
    try:
        lookup_module_0.run(b'')
    except TypeError:
        pass
    else:
        raise TypeError
    return


# Generated at 2022-06-25 10:43:52.044651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule('_context')
    assert 0, "No test exists"



# Generated at 2022-06-25 10:43:57.698061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = {}
    lookup_module_0 = LookupModule(terms_0, variables_0)
    try:
        lookup_module_0.run(terms_0, variables_0)
    except Exception as e:
        print(e)

## Unit tests for private methods

# Generated at 2022-06-25 10:44:00.628895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_0 = str()

    lookup_module_0.run(str_0, str_0)
    lookup_module_1.run(str_0, str_0)

# Generated at 2022-06-25 10:44:06.332837
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    lookup_module_0 = LookupModule('./lookup_plugins')
    terms_0 = []
    variables_0 = []
    kwargs_0 = {}

    bytes_0 = b'first_found'
    string_0 = bytes_0.decode(encoding='UTF-8')
    bytes_1 = b'common_dns_records'
    string_1 = bytes_1.decode(encoding='UTF-8')
    bytes_2 = b'common_errors'
    string_2 = bytes_2.decode(encoding='UTF-8')
    bytes_3 = b'common_ip'
    string_3 = bytes_3.decode(encoding='UTF-8')
    bytes_4 = b'common_packages'

# Generated at 2022-06-25 10:44:15.864789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tmpl_str_0 = 'default.yml'
    params_0 = {'files': [tmpl_str_0]}
    tmpl_str_2 = 'vars'
    params_0['paths'] = [tmpl_str_2]
    term_0 = params_0
    var_0 = {}
    lookup_module_0 = LookupModule(term_0)
    term_1 = [term_0]
    assert lookup_module_0.run(term_1, var_0) == ['/tmp/ansible_test/files/vars/default.yml']


# Generated at 2022-06-25 10:44:28.108884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_list_0 = ['abc', 'Test/setup.py', 'Test/setup.py']
    _variable_manager_0 = VariableManager()
    lookup_module_0 = LookupModule(_variable_manager_0,loader.get_basedir())
    var_1 = lookup_module_0.run(file_list_0, _variable_manager_0._fact_cache)
    assert len(var_1) == 1
    assert var_1[0] == 'Test/setup.py'


file_list_1 = ['abc', 'Test/setup.py', 'Test/setup.py']
_variable_manager_1 = VariableManager()
lookup_module_1 = LookupModule(_variable_manager_1,loader.get_basedir())

# Generated at 2022-06-25 10:44:30.687107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = lookup_module_0.run(var_1, var_1)
    assert var_2 == var_0


# Generated at 2022-06-25 10:44:37.265178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = [{}]
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = lookup_module_0.run(var_1, var_1)
    assert var_2 == [], "error"


# Generated at 2022-06-25 10:44:41.362294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = []
    var_2 = lookup_module_0.run(var_1, var_0)
    assert type(var_2) == list
    assert var_2 == []


# Generated at 2022-06-25 10:44:45.723555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_data
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run(var_0, var_0)



# Generated at 2022-06-25 10:44:54.193202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('##############')
    print('# TEST CASE 0 #')
    print('##############')
    test_case_0()


if __name__ == "__main__":

    # Set up
    var_0 = []
    var_0 = []

    # Run
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run(var_0, var_0)

    # Test
    print('##############')
    print('# TEST CASE 0 #')
    print('##############')
    test_case_0()

    # Clean up
    del lookup_module_0
    del var_1

# Generated at 2022-06-25 10:44:55.115699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(var_0, var_0) == var_1

# Generated at 2022-06-25 10:45:03.571816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ['a', 'b', 'c', 'd']
    var_1 = {'files': var_0}
    lookup_module_0 = LookupModule(var_1, var_1)
    var_2 = {'files': var_0}
    terms_1 = var_2
    variables = test_case_0()
    type(var_1)
    path_1 = lookup_module_0.run(terms_1, variables)
    print(path_1)
    print('\n')

# Generated at 2022-06-25 10:45:08.167753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = {'files': [], 'paths': []}
    lookup_module_0 = LookupModule(var_0, var_0)
    var_3 = lookup_run(var_1, var_2)



# Generated at 2022-06-25 10:45:13.086060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = ['vars/default.yml', 'vars/{{ ansible_os_family }}.yml', 'vars/{{ ansible_distribution }}.yml']
    lookup_module_0 = LookupModule(var, var)
    var_1 = lookup_run(var, var)
    print(var_1)
    assert var_1 == ['/home/travis/build/thehive-project/thehive4py/ansible/vars/default.yml']


# Generated at 2022-06-25 10:45:26.428754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = [{'var_0': 'var_0'}]
    var_2 = []
    var_2.append(var_1)
    var_3 = []
    var_3.append({'var_0': 'var_0'})
    var_3.append({'var_0': 'var_0'})
    var_3.append({'var_0': 'var_0'})
    var_4 = 'var_4'
    lookup_module_0.set_options(var_0, direct=var_4, files='var_4', paths='var_4')

# Generated at 2022-06-25 10:45:30.033082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = {}
    var_1 = {'foo': var_0, 'bar': var_1}
    lookup_module_0 = LookupModule(var_0, var_0)
    var_2 = lookup_run(var_0, var_1)
    assert var_2 == []


# Generated at 2022-06-25 10:45:34.832535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = ['foo.conf']
    var_2 = {}
    var_3 = lookup_module_0.run(var_1, var_2)
    assert var_3 is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:45:42.106680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = []
    var_2 = []
    var_3 = lookup_module_0.run(var_1, var_2)

# Generated at 2022-06-25 10:45:46.027101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0)


# Generated at 2022-06-25 10:45:53.089565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = []
    var_2 = { 'skip' : False, 'files' : [], 'paths' : [] }
    var_3 = lookup_module_0.run(var_1, var_2)
    print(var_3)



# Generated at 2022-06-25 10:46:04.677333
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var_1 = []
    var_2 = {'files': ['foo.yml'], 'paths': ['vars']}
    var_3 = []
    var_4 = {'files': ['foo.yml', 'bar.yml'], 'paths': ['vars']}
    lookup_module_0 = LookupModule(var_1, var_2)
    var_5 = lookup_module_0.run(var_3, var_4)
    assert var_5[0] == 'vars/foo.yml'
    var_7 = []
    var_8 = {'files': ['foo.yml', 'bar.yml'], 'paths': ['vars']}
    var_9 = []

# Generated at 2022-06-25 10:46:17.127229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = {}
    var_2 = {}
    # error - too few arguments
    with pytest.raises(TypeError):
        lookup_module_0 = LookupModule(var_0, var_1)
        var_3 = lookup_module_0.run()

    # error - too many arguments
    with pytest.raises(TypeError):
        lookup_module_1 = LookupModule(var_0, var_1)
        var_3 = lookup_module_1.run(var_0, var_0, var_2)

    # error - first argument has wrong type
    with pytest.raises(AnsibleLookupError):
        lookup_module_2 = LookupModule(var_0, var_1)
        var_3 = lookup_module_2.run

# Generated at 2022-06-25 10:46:26.928828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = [
        {
            'files': [
                '{{ansible_virtualization_type}}_foo.conf',
                'default_foo.conf'
            ],
            'paths': [
                'vars'
            ]
        },
        {
            'paths': [
                'tmp/production',
                'tmp/staging'
            ]
        },
        [
            'foo',
            '{{inventory_hostname}}',
            'bar'
        ],
        {
            'paths': [
                'extra/path'
            ]
        },
        [
            '/path/to/foo.txt',
            'bar.txt'
        ]
    ]
    lookup_module_0 = LookupModule(var_0, var_0)

# Generated at 2022-06-25 10:46:35.357091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = []
    # args = [{'files': ''}, {'paths': ['/usr/local/var/log/venafi/cpes/vtu/logs']}]
    kwargs = {}

    var_0 = []
    var_1 = []
    lookup_module_0 = LookupModule(var_0, var_0)

    # Exception raises due to invalid arguments
    with pytest.raises(AnsibleLookupError):
        # lookup_module_0.run(var_0, var_1, kwargs)
        var_2 = lookup_run(var_0, var_1, kwargs)



# Generated at 2022-06-25 10:46:43.798327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO - implement unit test
    pass

# Generated at 2022-06-25 10:46:46.388270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = {}
    lookup_module_0 = LookupModule(var_0, var_1)
    lookup_module_0.run(var_0, var_1, **var_2)


# Generated at 2022-06-25 10:46:49.082249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:46:52.636478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = []
  boost = Boost('boost_nwpp_0', '{}', '{}', var_0, var_0)
  var_1 = boost.run(var_0, var_0)

# No main function to run

# Generated at 2022-06-25 10:46:57.282323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0)



# Generated at 2022-06-25 10:47:05.027144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # lookup_module_0 = LookupModule(terms=(), variables={}, files=(), paths=(), skip=False)
    lookup_module_0 = LookupModule(None, None)
    lookup_module_0._process_terms(None, None, None)
    var_0 = []
    var_1 = None
    var_2 = lookup_run(var_0, var_1)
    assert var_0 == var_2


# Invoke the entry point for this module
if __name__ == '__main__':
    test_LookupModule_run()
    print('Test passed')

# Generated at 2022-06-25 10:47:08.074797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = []
    var_2 = {}
    var_3 = lookup_run(var_1, var_2)

    # TODO: Why is this here?
    if True:
        assert False



# Generated at 2022-06-25 10:47:12.319918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    param_0 = []
    param_1 = []
    param_2 = []
    lookup_module_0 = LookupModule(param_0, param_1)
    var_0 = lookup_module_0.run(param_2)

# Generated at 2022-06-25 10:47:13.832514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(dict(), dict())
    lookup_module._subdir = 'files'

    with pytest.raises(AnsibleLookupError) as error_info:
        lookup_module.run(dict(), dict(), skip=False)


# Generated at 2022-06-25 10:47:16.190797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# vim: ft=python

# Generated at 2022-06-25 10:47:26.709081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = []
    lookup_module_1 = LookupModule(var_2, var_2)
    var_3 = { 'skip': False, 'paths': [], 'files': [ 'foo', 'bar', 'far', 'boo' ] }
    var_4 = lookup_module_1.run([ var_3 ], var_2)
    assert var_4 == []


# Generated at 2022-06-25 10:47:29.052624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0)


# Generated at 2022-06-25 10:47:36.590463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ["playbook.yml"]
    var_1 = "ansible_playbook_python"
    var_2 = "name of config file"
    var_3 = "ansible_playbook_dir"
    var_4 = var_0
    var_5 = var_0
    var_6 = "ansible_config_dir"
    var_7 = "/path/to/ansible/config"
    var_8 = "/etc/ansible"
    var_9 = "/etc/ansible"
    var_10 = [var_9]
    var_11 = "/etc/ansible"
    var_12 = var_11
    var_13 = var_11
    var_14 = "ansible_data_dir"
    var_15 = var_14
    var_16 = var_14

# Generated at 2022-06-25 10:47:47.423354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = list()
    var_2 = dict()
    var_3 = dict()
    var_3['files'] = ['default.conf']
    var_2['files'] = var_3['files']
    var_3['paths'] = ['path/to']
    var_2['paths'] = var_3['paths']
    var_3['skip'] = True
    var_2['skip'] = var_3['skip']
    var_0 = [var_2]
    ll = []
    ll.append(var_0)
    lm = LookupModule(ll, var_1)
    var_4 = lm.run(var_0, var_1)

    var_5 = True
    if(var_4 != []):
        var_5 = False
    assert var_5

# Generated at 2022-06-25 10:47:55.206405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [] # mock needed
    var_1 = 'foo' # mock needed
    var_2 = [] # mock needed
    var_3 = {} # mock needed
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_1, var_0)
    lookup_module_0.run(var_2, var_0, **var_3)


# Generated at 2022-06-25 10:48:02.252081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('test_LookupModule_run')
    var_0 = []
    var_1 = []
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = lookup_module_0.run(var_1, var_0)
    var_3 = lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 10:48:06.300152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = lookup_module_0.run(var_1, var_0, **kwargs)
    ok_(var_0 == [])


# Generated at 2022-06-25 10:48:13.562404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = []
    lookup_module_1 = LookupModule(var_1, var_1)
    var_2 = []
    var_3 = dict()
    var_3['files'] = var_1
    var_3['paths'] = var_2
    var_4 = lookup_run(var_1, var_2, files=var_1, paths=var_2)
    var_5 = dict()
    var_5['files'] = var_1
    var_5['paths'] = var_2
    var_6 = lookup_run(var_1, var_2, files=var_1, paths=var_2)
    var_7 = dict()
    var_7['files'] = var_1
    var_7['paths'] = var_2
    var_8 = lookup

# Generated at 2022-06-25 10:48:23.274517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    jinja2_template_0 = LookupModule(['files/foo.txt'],['files/foo.txt'])
    setattr(jinja2_template_0, '_subdir', 'files')
    jinja2_template_0.run(['files/foo.txt'], ['files/foo.txt'])
    jinja2_template_0.run(['files/foo.txt'], ['files/foo.txt'], skip='skip')
    jinja2_template_0.run(['files/foo.txt'], ['files/foo.txt'], skip=True)
    jinja2_template_0.run(['files/foo.txt'], ['files/foo.txt'], skip=False)

# Generated at 2022-06-25 10:48:34.496015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {
        'terms': [
            {
                'files': 'foo.txt',
                'paths': 'path/to/'
            }
        ],
        '_ansible_lookup_plugin': 'first_found',
        '_ansible_lookup_args': {
            'files': 'foo.txt',
            'paths': 'path/to/'
        }
    }
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0)
    assert var_1 == [
        'path/to/foo.txt'
    ], 'tests/test_lookup_plugins/first_found.py:44'


# Generated at 2022-06-25 10:48:50.245017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = __file__
    var_1 = ['test_first_found.py', 'test_first_found.py']
    var_2 = lookup_module_0.run(var_1, var_0)
    assert (isinstance(var_2, list))
    assert (len(var_2) == 1)
    assert (var_2[0] == var_0)

# Generated at 2022-06-25 10:48:54.786062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = []
    var_2 = []
    lookup_module_1 = LookupModule(var_1, var_2)
    var_3 = lookup_module_1.run(var_1, var_2)

# Generated at 2022-06-25 10:48:58.337491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        var_0 = []
        var_1 = []
        lookup_module_0 = LookupModule(var_0, var_0)
        var_1 = lookup_module_0.run(var_0, var_0)
    except Exception as e:
       raise e
    finally:
       pass


# Generated at 2022-06-25 10:49:04.361386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = []
    var_2 = []
    var_3 = {}
    var_3['files'] = []
    var_3['paths'] = []
    var_2.append(var_3)
    var_4 = {}
    var_4['skip'] = False
    var_2.append("")
    var_1.append(var_2)
    assert lookup_module_0.run(var_1, var_0, **var_4) == []
    var_5 = []
    var_6 = []
    var_7 = {}
    var_7['files'] = []
    var_7['paths'] = []
    var_6.append(var_7)


# Generated at 2022-06-25 10:49:07.977684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0)
    assert var_1 in var_0

# Generated at 2022-06-25 10:49:11.048436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = []
    var_3 = []
    var_4 = {}
    var_5 = lookup_module_0.run(var_2, var_3, **var_4)
    assert var_5 == []



# Generated at 2022-06-25 10:49:14.802402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    lookup_module_0 = LookupModule(var_0, var_1)
    assert lookup_module_0.run(var_2, var_1) == [], 'Unexpected outcome of assert'


# Generated at 2022-06-25 10:49:17.609772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run(var_0, var_0)



# Generated at 2022-06-25 10:49:20.903745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ["/home/abhishek/Desktop/dat.txt"]
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run(["/home/abhishek/Desktop/dat.txt"],var_0,skip=0)
    assert(var_1 == ["/home/abhishek/Desktop/dat.txt"])

# Generated at 2022-06-25 10:49:21.948937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)

# Generated at 2022-06-25 10:49:52.478826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = {}
    lookup_module_0 = LookupModule(var_0, var_1)
    var_3 = lookup_module_0.run(var_0, var_1, args=var_2)
    assert var_3 == []
    var_4 = ['test_case_0.py']
    var_5 = ['test_case_0.py']
    var_6 = {}
    lookup_module_1 = LookupModule(var_4, var_5)
    with raises(AnsibleLookupError):
        var_7 = lookup_module_1.run(var_4, var_5, args=var_6)
    var_8 = ['test_case_0.py']

# Generated at 2022-06-25 10:49:59.852997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = dict()
    var_0['files'] = '/etc/passwd'
    var_0['paths'] = None
    var_0['skip'] = False
    var_1 = []
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = ['/etc/passwd']
    var_3 = lookup_module_0._process_terms(var_2, var_0, var_0)
    assert var_3 == (['/etc/passwd'], False)
    try:
        lookup_module_0.run(var_2, var_0)
        raise Exception('AssertionError')
    except LookupError:
        pass

# Generated at 2022-06-25 10:50:10.776879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = []
  var_1 = 'foo'
  var_2 = '/path/to/foo.txt'
  var_3 = 'bar.txt'
  var_4 = 'biz.txt'
  var_5 = [var_1, var_2, var_3]
  var_6 = {'files': var_5}
  var_7 = 'foo'
  var_8 = 'bar'
  var_9 = 'biz'
  var_10 = ['/path/to/foo.txt', '/path/to/bar.txt']
  var_11 = {'files': var_10}
  var_12 = 'default_foo.conf'
  var_13 = 'default.yml'
  var_14 = [var_1, '{{ inventory_hostname }}', var_8]

# Generated at 2022-06-25 10:50:15.350434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = []
    try:
        var_2 = lookup_module_0.run(var_1, var_0)
    except MetaUndefinedError:
        msg = "the '%s' lookup expects the first lookup argument to be a list"
        raise AnsibleLookupError(msg % var_0)


# Generated at 2022-06-25 10:50:18.444656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0, skip=False)



# Generated at 2022-06-25 10:50:23.301781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule([], {})
    assert isinstance(lookup_module_0, LookupBase)
    var_0 = []
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:50:34.905239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    lookup_module_0 = LookupModule(var_0, var_1)
    lookups = {'first':'first_found'}
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'myvar': 'myvalue'}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-25 10:50:46.242981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = []
    var_2 = dict()
    var_2["skip"] = True
    var_3 = dict()
    var_3["files"] = []
    var_3["paths"] = []
    var_4 = dict()
    var_4["term"] = dict()
    var_4["term"]["files"] = []
    var_4["term"]["paths"] = []
    var_5 = dict()
    var_5["path"] = None
    var_5["skip"] = False
    lookup_module_0 = LookupModule(var_0, var_1)
    lookup_module_0._process_terms(var_4, var_0, var_2)
    var_6, var_7 = lookup_module_0._process_terms

# Generated at 2022-06-25 10:50:51.641737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule([], {})
    var_1 = {}
    var_0.run(var_1, var_1)
    # assert True # TODO for jinja2.exceptions.UndefinedError


# Generated at 2022-06-25 10:50:57.698113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization for unit test
    var_0 = []
    var_1 = {}
    lookup_module_0 = LookupModule(var_0, var_0)
    try:
        var_1 = lookup_module_0.run(var_0, var_0)
    except Exception:
        # Unit test for exception handling
        pass
    finally:
        # Unit test for normal use
        var_0 = ['var_0']
        var_1 = lookup_module_0.run(var_0, var_0)
        print('lookup_module_0.run() function returns: %s' % var_1)


# Generated at 2022-06-25 10:51:57.431050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_28 = LookupModule([], {})
    var_28._process_terms(['file_name'], {}, {'files': ['file_name']})
    var_28._process_terms(['file_name'], {}, {'files': ['file_name']})
    var_28._process_terms(['file_name'], {}, {'files': ['file_name']})
    var_28._process_terms(['file_name'], {}, {'files': ['file_name']})
    var_28._process_terms(['file_name'], {}, {'files': ['file_name']})
    var_28._process_terms(['file_name'], {}, {'files': ['file_name']})

# Generated at 2022-06-25 10:52:01.758473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run(var_0, var_0)

# Testing:
if __name__ == "__main__":
    import sys
    sys.exit(test_LookupModule_run())

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 10:52:05.857607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = LookupModule(None, None)

# Generated at 2022-06-25 10:52:12.093613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    var_0 = ''
    var_1 = LookupModule(var_0, var_0)
    var_2 = [var_0]
    var_3 = {'files': '', 'paths': '', 'skip': True}
    var_4 = var_1.run(var_2, var_3)
    var_2 = [{'files': '', 'paths': '', 'skip': True}]
    var_4 = var_1.run(var_2, var_3)
    var_2 = [{'files': '', 'paths': '', 'skip': True}]
    var_4 = var_1.run(var_2, var_3)

# Generated at 2022-06-25 10:52:15.779263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run([], [])
    assert var_1 == [], "'run' function returned incorrect value"

# Generated at 2022-06-25 10:52:20.363849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_module_0.run(var_0, var_0)
    assert var_1 is None, var_1


# Generated at 2022-06-25 10:52:28.999176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = []
    var_1.append((var_0, var_0))
    lookup_module_0 = LookupModule(var_1, var_1)
    var_2 = []
    var_2.append(var_1)
    var_2.append(var_1)
    var_3 = {}
    var_3['files'] = var_2
    var_3['paths'] = var_2
    var_4 = lookup_module_0.run(var_3, var_3)

# Generated at 2022-06-25 10:52:34.074553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = lookup_run(var_0, var_0)
    assert var_1 == None, "%s == None" % var_1

# Mock from ansible.plugins.lookup

# Generated at 2022-06-25 10:52:39.519448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [{'files': [], 'paths': []}, {}]
    var_2 = {}

    # Arrange
    #var_1 = [{'files': [], 'paths': []}, {}]
    #var_2 = {}
    lookup_module_0 = LookupModule(var_1, var_2)

    # Act
    lookup_run(var_1, var_2)

    # Assert
    var_1.assert_called_with([{'files': [], 'paths': []}, {}], {})


# Generated at 2022-06-25 10:52:47.863597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term0 = "abc,cde" # should be a list
    term1 = "abc:cde,fgh" # should be a list
    term2 = "abc cde" # should be a list
    term3 = "abc,cde,fgh" # should be a list
    term4 = "abc cde fgh" # should be a list
    term5 = "/etc/hosts /etc/ntp.conf" # should be a list
    term6 = "/etc/hosts:/etc/ntp.conf" # should be a list

    terms = [term0, term1, term2, term3, term4, term5, term6]

    for term in terms:
        result = _split_on(term)

    assert len(terms) == len(result)

