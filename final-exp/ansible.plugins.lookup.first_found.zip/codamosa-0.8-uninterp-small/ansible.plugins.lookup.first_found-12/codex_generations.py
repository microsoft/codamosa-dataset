

# Generated at 2022-06-25 10:43:13.911426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    variables_0 = {}
    terms_0 = list_0
    kwargs_0 = {'a': 'apple'}
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except AnsibleLookupError as e:
        pass

    # AssertionError: No file was found when using first_found.


# Generated at 2022-06-25 10:43:16.071826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words_0 = ['']
    variables_0 = {}
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(words_0, variables_0)
    assert result_0 == []

# Generated at 2022-06-25 10:43:28.007293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['default.conf']
    variables_0 = {'play_hosts': ['foo', 'bar', 'baz'], 'hostvars': {'foo': {'ansible_ssh_host': '127.0.0.1'}, 'bar': {'ansible_ssh_host': '127.0.0.1'}, 'baz': {'ansible_ssh_host': '127.0.0.1'}}}
    paths_0 = '/etc/systemd/system/'
    files_0 = 'default.conf'
    result_0 = lookup_module_0.run(terms_0, variables_0, kwargs={'files' : files_0, 'paths' : paths_0})

# Generated at 2022-06-25 10:43:35.792023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args = []
    kwargs = dict()

    # Pass empty strings as parameters
    if lookup_module_1.run(args, kwargs) is not None:
        return False

    # Pass an empty list as parameters
    list_1 = []
    if lookup_module_1.run(list_1, kwargs) is not None:
        return False
    return True

# Generated at 2022-06-25 10:43:36.599749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 10:43:37.067150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:43:40.232882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    terms_0 = [list_0]
    variables_0 = dict()
    assert lookup_module_0.run(terms_0, variables_0) == [], 'Expected [], but got: ' + str(lookup_module_0.run(terms_0, variables_0))


# Generated at 2022-06-25 10:43:50.876965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Mock function 'find_file_in_search_path'
    lookup_module_0.find_file_in_search_path = Mock(return_value=None)
    # Mock function 'template'
    lookup_module_0._templar.template = Mock(side_effect=ansible.errors.AnsibleUndefinedVariable())
    # Mock function 'get_option'
    lookup_module_0.get_option = Mock(return_value=None)
    # Mock function '_split_on'
    lookup_module_0._split_on = Mock(return_value=None)

    # Call function under test!
    # This should throw an exception because of the mock 'template' function
    with pytest.raises(AnsibleLookupError):
        assert lookup_

# Generated at 2022-06-25 10:43:54.925228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run("test")


# Generated at 2022-06-25 10:43:58.767470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = ['foo.txt']
    var_0 = {}
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(term_0, var_0)
    assert isinstance(result_0, list)
    assert result_0 == ['foo.txt']


# Generated at 2022-06-25 10:44:03.623952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run(LookupBase(), None)


# Generated at 2022-06-25 10:44:11.249514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_1]
    var_0 = lookup_run(list_0, lookup_module_0)

    # Call method run of class LookupModule
    var = LookupModule()
    terms = 'test_value'
    variables = 'test_value'
    var.run(terms, variables)

# Generated at 2022-06-25 10:44:17.555932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        list_0 = [lookup_module_0, lookup_module_0]
        lookup_module_0.run(list_0, lookup_module_0)
    except:
        print('Exception caught')


# Generated at 2022-06-25 10:44:25.326319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = "files"
    var_1 = ['12', '34']
    var_2 = ["12", "34"]
    var_3 = "34"
    var_4 = None
    var_5 = "12"
    var_6 = "34"
    var_7 = {'files': var_6, 'paths': var_6}
    var_8 = "34"
    var_9 = {'files': var_1, 'paths': var_8}
    var_10 = ["12", "34"]
    var_11 = "12"
    var_12 = "34"
    var_13 = {'files': var_11, 'paths': var_12}

# Generated at 2022-06-25 10:44:31.966872
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        LookupModule.run(LookupModule, None, None)
    except Exception as e:
        print("LookupModule: test_run: caught exception: {}".format(e))
    try:
        LookupModule.run(LookupModule, None, None, None)
    except Exception as e:
        print("LookupModule: test_run: caught exception: {}".format(e))
    try:
        LookupModule.run(LookupModule, None, None, None, None)
    except Exception as e:
        print("LookupModule: test_run: caught exception: {}".format(e))

# Generated at 2022-06-25 10:44:37.891095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0)


# Generated at 2022-06-25 10:44:40.573064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run({'foo': 'bar'}, {'bar': 'foo'})



# Generated at 2022-06-25 10:44:51.657500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(['tasks.yaml', 'other_tasks.yaml'])
    lookup_module_0._templar = Templar()
    lookup_module_0.set_basedir(None)
    lookup_module_0.set_environment(None)
    lookup_module_0.set_vars(None)
    lookup_module_0.set_options(None)
    lookup_module_0.set_task_vars(None)
    lookup_module_0.set_play_context(None)
    lookup_module_0._templar.set_available_variables(None)
    lookup_module_0._file_name = None
    lookup_module_0._name = None
    lookup_module_0._add

# Generated at 2022-06-25 10:44:57.599882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    # ['/opt/ansible/lib/ansible/plugins/lookup/first_found.py']
    var_0 = lookup_run(list_0, lookup_module_0)
    assert var_0 == ['/opt/ansible/lib/ansible/plugins/lookup/first_found.py']


# Generated at 2022-06-25 10:45:05.673015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [lookup_module_0, lookup_module_0]
    var_1 = lookup_module_0
    var_2 = lookup_module_0
    var_1._subdir = ''
    var_0.append(var_1)
    var_0.append(var_2)
    var_3 = lookup_run(var_0, lookup_module_0)



# Generated at 2022-06-25 10:45:15.294734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0)


# Generated at 2022-06-25 10:45:23.788615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    loader_0 = DictDataLoader({})
    inventory_0 = InventoryManager(loader=loader_0, sources=['localhost'])
    variables_0 = VariableManager(loader=loader_0, inventory=inventory_0)
    lookup_module_0 = LookupModule()
    # TODO: Needs more variables
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0, variables=variables_0)
    assert var_0 == [], "LookupModule.run returned %s instead of %s" % (var_0, [])

# Generated at 2022-06-25 10:45:29.458014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ["foo", "foo"]
    var_0 = lookup_module_0.run(list_0, lookup_module_0)
    # Testing for equality
    assert var_0 == ["foo", "foo"]
    
    # Testing for exceptions
    with pytest.raises(AnsibleLookupError) as pytest_wrapped_e:
        str_0 = "foo"
        lookup_module_0.run(str_0, lookup_module_0)
    assert "No file was found when using first_found." in pytest_wrapped_e.value.args[0]



# Generated at 2022-06-25 10:45:37.322224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = list()
    var_0 = lookup_run(list_0, lookup_module_0)
    var_1 = lookup_run(list_0, lookup_module_0)
    var_2 = lookup_run(list_0, lookup_module_0)
    var_3 = lookup_run(list_0, lookup_module_0)
    assert isinstance(var_0, Mapping) == True
    assert isinstance(var_1, Mapping) == True
    assert isinstance(var_2, Mapping) == True
    assert isinstance(var_3, Mapping) == True
    assert isinstance(lookup_module_0.run(list_0, var_3), Mapping) == True

# Generated at 2022-06-25 10:45:43.177142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = MockTemplar()
    lookup_module_0._filesfinder = MockFilesFinder()
    test_terms = ['test_file']
    test_variables = {}
    test_expected = ['/tmp/./test_file']
    assert test_expected == lookup_module_0.run(test_terms, test_variables)


# Generated at 2022-06-25 10:45:51.348160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = "ASWFXyhjqhiqVuSwFs6U9"
    lookup_module.find_file_in_search_path = "ZeGRyN0DYjvf0zJmL8Qg"
    terms_0 = "wHg7W8Jb6mFskVq3v6uO"
    variables_0 = "1D2QwJwSlxVsnOGJEXfC"
    kwargs_0 = {'params': 'lookup_module'}
    result_0 = lookup_module.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == "ZeGRyN0DYjvf0zJmL8Qg"
    terms_1

# Generated at 2022-06-25 10:45:54.350862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1]
    var_1 = lookup_run(list_1, lookup_module_1)


# Generated at 2022-06-25 10:46:04.758401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0)
    # even though '_split_on' uses isinstance(terms, string_types), added test to assure the function works with bytes
    var_0 = lookup_run([b'a1'], lookup_module_0)
    # even though '_split_on' uses isinstance(terms, string_types), added test to assure the function works with str
    var_0 = lookup_run(['a2'], lookup_module_0)
    # even though '_split_on' uses isinstance(terms, string_types), added test to assure the function works with lists
    var

# Generated at 2022-06-25 10:46:06.493445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert hasattr(lookup_module_0, 'run')
    

# Generated at 2022-06-25 10:46:07.341648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# vim:expandtab

# Generated at 2022-06-25 10:46:24.133847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [lookup_module_0, lookup_module_0]
    variables_0 = lookup_module_0
    kwargs_0 = lookup_module_0
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

    assert ret_0 == [lookup_module_0]

# Generated at 2022-06-25 10:46:35.049247
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleLookupError
    from ansible.utils.unicode import to_bytes
    from ansible.module_utils._text import to_text


# Generated at 2022-06-25 10:46:42.772228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.__dict__.update(dict(
        _subdir='files',
        _loader='loader',
        _templar='templar',
        _options=dict(
            skip=False,
            errors='',
            paths=[],
            files=[]),
        _templated_options=dict()
    ))
    var_0 = lookup_module_0.run(
        terms=[],
        variables='variables'
    )
    assert isinstance(var_0, list)
    assert len(var_0) == 1
    assert type(var_0).__name__ == 'list'

# Generated at 2022-06-25 10:46:46.575239
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check if path exists and is a file
    # TODO: add tests for this case.
    path = "ansible/plugins/lookup/__init__.py"

    try:
        assert os.path.exists(path)
    except:
        pass
    else:
        assert True

    try:
        assert os.path.isfile(path)
    except:
        pass
    else:
        assert True

# Generated at 2022-06-25 10:46:52.654218
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup

    # no files provided
    # NOTE: why is this returning a list of empty items
    # is it because we are filtering on a string and there are
    # multiple list items, actually yes it is!
    list_0 = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
    lookup_module_0 = LookupModule()
    # NOTE: looks like all the rest of the regex is just to strip away these items
    # to make the regex simpler.
    # NOTE: this is also inconsistent and breaks things
    # because the regex is to match a list not a single item
    # if we pass a list and then the list is split into items
    # then expect it to always return a list

# Generated at 2022-06-25 10:47:04.492163
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:47:06.331153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(terms, var)) > 0



# Generated at 2022-06-25 10:47:09.858245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_0.run(None, None), list)
    assert isinstance(lookup_module_1.run(None, None), list)


# Generated at 2022-06-25 10:47:11.654103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:47:17.145893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   lookup_module_1 = LookupModule()
   test_case_0()


# Generated at 2022-06-25 10:47:45.215946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(lookup_module_0, lookup_module_0, lookup_module_0)



# Generated at 2022-06-25 10:47:47.982871
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    params = dict(
        subdir='files',
        files=['inv.ini'],
        paths=['/etc/ansible'],
        skip=False
    )

    lookup_module = LookupModule()

    result = lookup_module.run(terms=['inv.ini'], variables=['inv.ini'], **params)

    assert ['inv.ini'] == result

# Generated at 2022-06-25 10:47:50.895188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'lookup_module_1'
    var_0 = lookup_module_0.run([], {})
    assert var_0 == [], var_0


# Generated at 2022-06-25 10:47:56.844649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    lookup_module_0 = LookupModule()
    list_0 = []
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 10:47:59.549714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words = "abc"
    dic = {}
    lookup_module_0 = LookupModule()
    ret_obj = lookup_module_0.run(words, dic)
    #assert (ret_obj == )

# TEST CASE: test_case_1

# Generated at 2022-06-25 10:48:10.010047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [lookup_module_0, lookup_module_0, lookup_module_0]
    variables_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(terms_0, variables_0)
    assert var_0 is not None
    assert var_0 == [path]
    terms_1 = [lookup_module_0, lookup_module_0, lookup_module_0]
    variables_1 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_1 = lookup_run(terms_1, variables_1)
    assert var_

# Generated at 2022-06-25 10:48:19.732604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    scripts_dir = os.path.join(os.path.dirname(__file__), "test_scripts")
    input_variables = {
        "lookup_test_variable": "lookup_test_value",
        "lookup_test_list_variable": [
            "test_list_value1",
            "test_list_value2",
            "test_list_value3"
        ],
        "lookup_test_dictionary_variable": {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        }
    }

# Generated at 2022-06-25 10:48:23.504130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: needs implementation
    assert True


# Generated at 2022-06-25 10:48:33.279543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0)
    try:
        term_0 = list_0
        variables_1 = None
        keyword_arguments_1 = None
        var_0.run(term_0, variables_1, kwargs=keyword_arguments_1)
    except Exception as e_0:
        assert False
    else:
        assert True
# =========================================

# Generated at 2022-06-25 10:48:35.784373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0)



# Generated at 2022-06-25 10:49:07.140327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_terms = [1, 2]
    test_variables = {'test_name0':'test_value0'}
    test_kwargs = {'test_name1':'test_value1'}
    lookup_module.run(test_terms, test_variables, **test_kwargs)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 10:49:10.569209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms,[])



# Generated at 2022-06-25 10:49:13.476027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = list()
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0, list_0, list_0)
    assert var_0 is not None


# Generated at 2022-06-25 10:49:24.284926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = test_parameters()
    var_1 = lookup_module_0
    var_2 = []
    var_3 = {"skip": True, "files": [], "paths": ["/path/to/one", "/path/to/two"]}
    bool_0 = True
    var_4 = []
    if (True and True):
        var_5 = []
    elif (var_3["files"] == var_4):
        bool_1 = False
    else:
        bool_1 = True
    if True:
        var_6 = []
    elif bool_1:
        var_7 = []
    else:
        var_7 = []
    var_8 = {}

# Generated at 2022-06-25 10:49:30.785255
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_0 = ('bar', 'baz')
    lookup_module_0 = LookupModule()
    list_0 = [terms_0, lookup_module_0, lookup_module_0]
    assert_equal(lookup_module_0._process_terms(list_0, lookup_module_0, lookup_module_0), terms_0)
    assert_equal(lookup_module_0._process_terms(list_0, lookup_module_0, lookup_module_0), terms_0)
    assert_equal(lookup_module_0.run(list_0, lookup_module_0, lookup_module_0), list_0)
    assert_equal(lookup_module_0._process_terms(list_0, lookup_module_0, lookup_module_0), terms_0)


# Generated at 2022-06-25 10:49:31.675130
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True



# Generated at 2022-06-25 10:49:38.108902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = "files"
    terms_0 = [lookup_module_0, lookup_module_0]
    variables_0 = lookup_module_0
    kwargs_0 = dict()
    kwargs_0["files"] = lookup_module_0
    kwargs_0["skip"] = True
    kwargs_0["paths"] = lookup_module_0
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 is None


# Generated at 2022-06-25 10:49:40.725312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    var_0 = lookup_run([lookup_module_0, lookup_module_0], lookup_module_0)
    assert var_0 == ['']


# Generated at 2022-06-25 10:49:43.401256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['']
    dict_0 = {}
    var_0 = lookup_module_0.run(list_0, dict_0)


# Example testing code, see ansible/test/lib/ansible/library/tests/

# Generated at 2022-06-25 10:49:50.187026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_1]
    lookup_module_0._templar = lookup_module_0
    lookup_module_0.run(list_0, lookup_module_0)


# Generated at 2022-06-25 10:50:47.319536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1]
    var_1 = lookup_module_1.run(list_1, lookup_module_1)
    assert var_1 is None, "Expected None but received %r" % var_1


# Generated at 2022-06-25 10:50:53.092362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Case 0
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(list_0, lookup_module_0)
    print("var_0: "  + str(var_0)) # print("var_0: " + str(var_0))


# Generated at 2022-06-25 10:50:56.412414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # TODO: Test the case where no_found is true

    # TODO: Test the case where no_found is false
    try:
        lookup_module.run()
    except Exception as e:
        assert e.__class__ == AnsibleLookupError

# Generated at 2022-06-25 10:51:04.636260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=dict())
    lookup_module_0.set_options(direct=dict())
    lookup_module_0._templar = template()
    lookup_module_0._templar.template = template()
    lookup_module_0.find_file_in_search_path = find_file_in_search_path()
    assert lookup_module_0.run(list(), set())
    lookup_module_0.set_options(var_options=set(), direct=set())
    assert not lookup_module_0.run(list(), set())


# Generated at 2022-06-25 10:51:12.186230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1, LookupModule)
    assert hasattr(lookup_module_1, 'run')
    # Error message: 'LookupModule' object is not callable

    list_1 = [lookup_module_1, lookup_module_1]
    dict_1 = dict()
    var_1 = lookup_run(list_1, dict_1)
    assert isinstance(var_1, list)


# Generated at 2022-06-25 10:51:20.367832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_2._subdir = "files"
    lookup_module_3 = LookupModule()
    lookup_module_3.set_options(var_options=lookup_module_2, direct=lookup_module_1)
    lookup_module_4 = LookupModule()
    lookup_module_4._subdir = "files"
    lookup_module_4.set_options(var_options=lookup_module_2, direct=lookup_module_1)
    lookup_module_5 = LookupModule()
    lookup_module_5._subdir = "files"
    lookup_module_6 = LookupModule()
    lookup_module_6._subdir = "files"

# Generated at 2022-06-25 10:51:29.870636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_var_0 = dict({'varkey0': 'varval0'})

    lookup_module_0 = LookupModule()

    list_0 = [dict({'files': 'varval0', 'varkey0': 'varval0', 'paths': 'varval0'})]
    var_0 = lookup_module_0.run(list_0, my_var_0)

    list_1 = [dict({'files': 'varval0', 'varkey0': 'varval0', 'paths': 'varval1'}), dict({'files': 'varval0', 'varkey0': 'varval0', 'paths': 'varval1'})]
    var_1 = lookup_module_0.run(list_1, my_var_0)

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:51:35.750157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1]
    var_1 = lookup_run(list_1, lookup_module_1)
    assert var_1 != ''


# Generated at 2022-06-25 10:51:39.245247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for t in ['a', True, 1, 2, -1, 0]:
        inp_0 = terms_create(t)
        var_0 = lookup_run(inp_0, LookupModule())
        assert var_0


# Generated at 2022-06-25 10:51:45.288377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # W0631:assert 'lookup_module_0' is not declared and used
    lookup_module_0 = LookupModule()
    # W0631:assert 'lookup_module_0' is not declared and used
    lookup_module_0 = LookupModule()
    # W0631:assert 'lookup_module_0' is not declared and used
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list(), dict())
    lookup_module_0.set_options(dict(), dict())
    lookup_module_0.get_option(str())