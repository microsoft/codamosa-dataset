

# Generated at 2022-06-25 10:43:22.523192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b''
    class_0 = LookupBase()
    variables = class_0
    class_0.find_file_in_search_path = lambda *args, **kwargs: (b'tasks.yaml', False)
    lookup_module_0._templar = variables
    kwargs = {'errors': 'ignore'}
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    lookup_module_0._subdir = 'files'
    kwargs = {'files': b'*', 'paths': b'path', 'skip': False}
    lookup_module_0.set_options(var_options=variables, direct=kwargs)

# Generated at 2022-06-25 10:43:24.191215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test if method run works correctly

    :return:
    """
    # Testing the following input
    terms = []
    variables = {}
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(terms, variables), list)

# Generated at 2022-06-25 10:43:35.561479
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    lookup_module = LookupModule()

    lookup_module._templar = templar = MagicMock()
    # NOTE: this is used by find_file_in_search_path if self._loader is not set
    lookup_module._loader = MagicMock()

    # the terms for the lookup
    terms = [
        'one',
        'two',
        'three',
        {'skip': True},
        {'files': 'four'},
        {'paths': 'five'}
    ]

    # NOTE: this looks wrong, there is no 'find_file_in_search_path'
    # TODO:  fix 'test_LookupModule_run'.
    # TODO: setup 'test_LookupModule_run'
    # TODO: mock 'test_LookupModule_run

# Generated at 2022-06-25 10:43:37.298326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = lookup_module_0.run(['abc', 'abc', 'abc'], {})

# Generated at 2022-06-25 10:43:38.103945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass # test call failed, but we are ok with that

# Generated at 2022-06-25 10:43:40.176312
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  terms = ["src.txt", "dst.txt"]
  variables = {}
  lookup_module = LookupModule()
  lookup_module.run(terms, variables)
  assert lookup_module


# Generated at 2022-06-25 10:43:45.856914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize test
    lookup_module_0 = LookupModule()
    # Define method input
    terms_0 = ['/', '/']
    variables_0 = {}
    kwargs_0 = {}
    # Execute test
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    # Verify expected output
    assert result_0 == ['/']


# Generated at 2022-06-25 10:43:52.242312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b''
    dict_0 = {'files': [], 'paths': []}
    dict_1 = {'files': [], 'paths': []}
    dict_2 = {'files': [], 'paths': []}
    dict_3 = {'files': [], 'paths': []}
    dict_4 = {'files': [], 'paths': []}
    dict_5 = {'files': [], 'paths': []}
    dict_6 = {'files': [], 'paths': []}
    dict_7 = {'files': [], 'paths': []}
    dict_8 = {'files': [], 'paths': []}

# Generated at 2022-06-25 10:43:57.254744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    kwargs = {}
    kwargs['files'] = ''
    kwargs['paths'] = ''
    kwargs['skip'] = False
    x = LookupModule()
    x.run(args, kwargs)


# Generated at 2022-06-25 10:44:03.576459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_1 = b'\n\n\n\n'
    terms_0 = _split_on(bytes_1)
    variables_0 = {}
    #args_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print('result_0: %s' % result_0)
    #assert result_0 == None


# Generated at 2022-06-25 10:44:17.874758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'first_fo'
    unicode_1 = u'f'
    unicode_2 = u'first_fou'
    str_1 = 'first_found'

    # Execute the run() method of LookupModule
    try:
        str_2 = 'N'
        if str_2 == 'N':
            str_2 = 'first_found'
        found_0 = lookup_run(lookup_module_1, bytes_1, str_2)
    except Exception as raised_0:
        # Check if the exception was raised correctly
        if str(raised_0) == ("No file was found when using first_found."):
            pass
    # Check if the returned value is what we expected
    str_3 = 'N'

# Generated at 2022-06-25 10:44:28.006917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b''
    str_0 = 'N'
    var_0 = lookup_module_0.run(bytes_0, str_0)
    bytes_1 = b''
    str_1 = 'J'
    var_1 = lookup_module_0.run(bytes_1, str_1)
    bytes_2 = b''
    str_2 = '6'
    var_2 = lookup_module_0.run(bytes_2, str_2)
    bytes_3 = b''
    str_3 = ';'
    var_3 = lookup_module_0.run(bytes_3, str_3)
    bytes_4 = b''
    str_4 = '4'

# Generated at 2022-06-25 10:44:37.744555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  file_path = os.path.abspath(__file__)
  lookup_module_0 = LookupModule()
  bytes_0 = b''
  str_0 = 'NONE'
  list_0 = []
  dict_0 = {'files': list_0}
  str_1 = lookup_module_0.run(dict_0, bytes_0)
  assert str_1 == []
  dict_1 = {'files': list_0}
  dict_1['paths'] = list_0
  str_2 = lookup_module_0.run(dict_1, bytes_0)
  assert str_2 == []



# Generated at 2022-06-25 10:44:41.115546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b''
    str_0 = 'N'
    var_0 = lookup_run(bytes_0, str_0)
    assert 'l' not in var_0

# Generated at 2022-06-25 10:44:52.342716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with: 'file1' in the play's relative path, this will be used, 'file2' in role's relative path will not.
    lookup_module_1 = LookupModule()
    lookup_module_1.find_file_in_search_path = lambda x, y, z, i: 'file'
    str_1 = 'file1'
    var_1 = lookup_module_1.run(str_1, 'hostname')
    # Test with: looking in relative directories from where the task is defined and including any play objects that contain it
    lookup_module_2 = LookupModule()
    lookup_module_2.find_file_in_search_path = lambda x, y, z, i: 'file'
    str_2 = 'foo bar biz'

# Generated at 2022-06-25 10:44:54.677172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x01\x00\x04\x00\x00\x00'
    str_0 = 'N'
    assert True


# Generated at 2022-06-25 10:45:04.989835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'P'
    dict_0 = {}
    dict_5 = dict_0
    dict_5['files'] = str_0
    dict_5['paths'] = str_0
    dict_1 = dict_5
    str_1 = 'H'
    dict_6 = dict_5
    dict_6['files'] = str_1
    dict_6['paths'] = str_1
    dict_2 = dict_6
    list_0 = []
    list_0.append(dict_1)
    list_0.append(dict_2)
    dict_3 = {}
    dict_4 = {}
    dict_4['terms'] = list_0
    dict_3['kwargs'] = dict_4

# Generated at 2022-06-25 10:45:10.785002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test 1")
    lookup_run = LookupModule()
    lookup_run.run(["test_file"], None)

print("Test 2")
lookup_run = LookupModule()
lookup_run.run("test_file", None)

# How do you want to test the following cases?
# lookup_run.run(["test_file"], None)
# lookup_run.run("test_file", None)

# Generated at 2022-06-25 10:45:14.397777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run.run(bytes_0, str_0)


# Generated at 2022-06-25 10:45:16.011801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b''
    str_0 = 'N'
    var_0 = lookup_module_0.run(bytes_0, str_0)

# Generated at 2022-06-25 10:45:23.575084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)


# Generated at 2022-06-25 10:45:24.791224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1==1


# Generated at 2022-06-25 10:45:26.700394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    str_0 = '\x00'
    var_0 = lookup_run(b'\x00', str_0)

# Generated at 2022-06-25 10:45:29.428463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)


# Generated at 2022-06-25 10:45:37.295852
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use fixture from class LookupBase
    lookup_base = LookupBase()
    lookup_base.get_basedir = lambda self, variables: 'fake'
    lookup_base.find_file_in_search_path = lambda self, variables, subdir, file, ignore_missing: 'fake'

    # Setup the instance to be tested
    lookup_module = LookupModule()
    lookup_module._templar = object
    lookup_module._loader = object
    lookup_module._get_file_contents = lambda self, path: 'fake'
    lookup_module._get_file_encoding = lambda self, path: 'fake'
    lookup_module._convert_contents = lambda self, contents, path: 'fake'

    # TODO: this method is 'not callable' so not sure why I need to mock it?


# Generated at 2022-06-25 10:45:49.117171
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule( )

    str_0 = '\x00'
    str_1 = '\x00\x00'
    str_2 = '\x00\x00'
#     str_2 = '\x00\x00\x00'
#     str_2 = '\x00\x00\x00'
    exception_0 = None
    try:
        lookup_module_0.run(str_0, str_1, str_2)
    except Exception as exception_0:
        pass

    str_3 = '\x00\x00\x00'
    str_4 = '\x00\x00\x00\x00'
    exception_1 = None

# Generated at 2022-06-25 10:45:51.688277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'\x01'
    str_1 = '\x01'
    var_1 = lookup_run(bytes_1, str_1)
    assert var_1 == None


# Generated at 2022-06-25 10:45:56.174165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)

# Generated at 2022-06-25 10:46:01.020164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  bytes_0 = b'\x00'
  str_0 = '\x00'
  var_0 = lookup_run(bytes_0, str_0)


# Generated at 2022-06-25 10:46:08.940694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'\x00'
    str_1 = '\x00'
    var_1 = lookup_run(bytes_1, str_1)
    #assert var_1 == '\x00'


# Generated at 2022-06-25 10:46:22.849296
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_run = LookupModule.run
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)



# Create a wrapper for LookupModule.run method that can be used in Try, Except blocks

# Generated at 2022-06-25 10:46:33.481241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test with a simple term
  lookup_module_0 = LookupModule()
  lookups_0 = 'lookups'
  t_0 = lookup_module_0.run(lookups_0, {}, files=[], paths=[])

  # Test with a dict
  lookup_module_1 = LookupModule()
  lookups_1 = 'lookups'
  t_1 = lookup_module_1.run(lookups_1, {},
                            files={'default', 'paths', 'files', 'skip'}, paths=[])

  # Test with a complex term
  lookup_module_2 = LookupModule()
  lookups_2 = 'lookups'

# Generated at 2022-06-25 10:46:37.950361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    data = b'\x00'
    data_1 = '\x00'
    try:
        data_2 = lookup_module.run(data, data_1, errors='strict')
    except ValueError as err:
        # NotImplemented
        pass
    else:
        data_2 = lookup_module.run(data, data_1, errors='strict')


# Generated at 2022-06-25 10:46:41.125494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)


# or class attributes and as a method

# Generated at 2022-06-25 10:46:44.765465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0  = LookupModule()
    terms_0 = [{'feed': b'\x00'}]
    variables_0 = {'feed': {}}
    kwargs_0 = {'skip': True}
    dict_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert type(dict_0) == list
    assert dict_0 == [] # why is this empty?



# Generated at 2022-06-25 10:46:49.288401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:46:53.416394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = '\x00'
    str_2 = '\x00'
    str_3 = '\x00'
    var_1 = lookup_run(str_1, str_2, str_3)
    assert var_1 == var_1


# Generated at 2022-06-25 10:47:02.552836
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # FIXME: NetBeans NuSMV plugin cannot handle Python exception
    # lookup_module_0 = unittest.expectedFailure(LookupModule())
    # bytes_0 = b'\x00'
    # str_0 = '\x00'

    # with self.assertRaises(AnsibleLookupError) as error:
    #     lookup_module_0.run(bytes_0, str_0)
    # self.assertEqual(
    #     "No file was found when using first_found.",
    #     str(error.exception))

    pass


# Generated at 2022-06-25 10:47:04.316758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)

# Generated at 2022-06-25 10:47:09.945123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ''
    variables = ''
    # FIXME: I do not know how to fix this test
    lookup_module_0 = LookupModule()
    lookup_module_0.__init__(terms, variables)
    # FIXME: this should be working whether it is a bytes object, or
    # a string object.
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_module_0.run(bytes_0, variables)
    assert var_0 == None, 'var_0 wrong value'

# Generated at 2022-06-25 10:47:23.480731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    lookup_module_0.run(bytes_0, str_0)


# Generated at 2022-06-25 10:47:28.908943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Assign parameter 'var_name'
    var_name = b'\x01'

    # Assign parameter 'loader'
    loader = None # TODO - implement loader

    # Assign parameter 'templar'
    templar = decode_object(b'\x02')

    # Call method 'run' with parameter 'var_name'
    var_0 = lookup_module_1.run(var_name, loader, templar)
    return var_0


# Generated at 2022-06-25 10:47:36.427315
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:47:43.801232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)
    try:
        assert var_0 == bytes_0
    except:
        print('Condition not met')
    try:
        assert var_0 == lookup_module_0.run(bytes_0, str_0)
    except:
        print('Condition not met')


# Generated at 2022-06-25 10:47:49.673483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._subdir = 'files'
    lookup_module._templar = '_templar'
    lookup_module._finder = '_finder'
    lookup_module._hashes = '_hashes'
    lookup_module._original_base = '_original_base'
    lookup_module._original_task_vars = '_original_task_vars'
    lookup_module._loader_cache = '_loader_cache'
    lookup_module._loader = '_loader'
    lookup_module._task_vars = {'ansible_distribution': 'ansible_distribution', 'ansible_os_family': 'ansible_os_family', }
    lookup_module._basedir = '_basedir'
    lookup_module._display = '_display'


# Generated at 2022-06-25 10:47:52.813627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run == run

# Ignore

# Generated at 2022-06-25 10:47:55.906354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = [1, 2, 3]
    lookup_module = LookupModule()
    vars = {}
    assert items == lookup_module.run(items, vars)


# Run test for method run of class LookupModule
test_LookupModule_run()



# Generated at 2022-06-25 10:47:58.354027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_0 = 1
    str_0 = '\x00'
    lookup_result_0 = lookup_module_1.run(int_0, str_0)

# Unit tests for method _process_terms of class LookupModule

# Generated at 2022-06-25 10:48:03.645765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)

# Generated at 2022-06-25 10:48:11.557895
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0.echo = MethodType(echo, lookup_module_0)
    lookup_module_0.find_file_in_search_path = MethodType(find_file_in_search_path, lookup_module_0)
    lookup_module_0.set_options = MethodType(set_options, lookup_module_0)
    var_0 = 'total_search'
    var_1 = 'skip'
    var_2 = lookup_module_0.run()
    var_3 = 'path'
    var_4 = lookup_module_0.run()
# END

# Generated at 2022-06-25 10:48:26.576576
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize vars
    lookup_module_0 = LookupModule()
    str_0 = '\x00'
    str_1 = '\x00'
    str_2 = '\x00'

    # Call method run
    assert lookup_module_0.run(str_0, str_1, str_2) == []


# Generated at 2022-06-25 10:48:35.330108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: this is kind of wrong but 'works' as the plugin will use the last found 'skip' value
    # there is a test for _process_terms that tests this but that is a private method.

    lookup_module_1 = LookupModule()
    sequence_0 = [{"files": "file0,file1", "paths": "path1,path2", "skip": False}, {"files": "file3,file2", "paths": "path1,path2", "skip": True}, {"files": "file1,file2", "paths": "path3,path4", "skip": True}, {"files": "file4,file6", "paths": "path1,path2", "skip": False}, {"files": "file5,file2", "paths": "path1,path2", "skip": False}]
   

# Generated at 2022-06-25 10:48:39.952496
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    term_0 = [0]
    var_0 = lookup_module_0.run(term_0, bytes_0)

    lookup_module_1 = LookupModule()
    bytes_1 = b'\x00'
    term_1 = [0]
    var_1 = lookup_module_1.run(term_1, bytes_1)

# Generated at 2022-06-25 10:48:44.735608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ['path']
    variables_1 = {}
    result = lookup_module_0.run(terms_1, variables_1)
    assert result == ["path"]

# Tests for jinja2 template variable lookups (using variable)

# Generated at 2022-06-25 10:48:48.434102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        if lookup_module.run() != 0:
            return 1
    except Exception:
        return 1
    return 0

# Generated at 2022-06-25 10:48:57.973334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        '\x00',
        '->\x00',
        '\x00',
        '\x00',
        '\x00',
        '\x00',
        '\x00',
    ]
    file_0 = variables_0 = dict(
        files = [
            '\x01',
            '\x02',
        ],
        paths = [
            '\x00',
            '\x00',
        ],
        skip = '\x00',
    )
    lookup_run(lookup_module_0, terms_0, file_0, **variables_0)
# test method run of class LookupModule


# Generated at 2022-06-25 10:49:00.324518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)


# Generated at 2022-06-25 10:49:08.092754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "\x00"
    str_1 = "\x00"
    str_2 = "\x00"
    str_3 = "\x00"
    dict_0 = dict()
    dict_0[str_0] = str_1
    dict_0[str_2] = str_3
    var_0 = lookup_module_0.run(dict_0)
    assert isinstance(var_0, list)
    test_case_0()

# Generated at 2022-06-25 10:49:11.682520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # test
  lookup_module_0 = LookupModule()
  bytes_0 = b'\x00'
  str_0 = '\x00'
  var_0 = lookup_run(bytes_0, str_0)

# Generated at 2022-06-25 10:49:16.038976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    src = "/temp/src.txt"
    dest = "/temp/dest.txt"
    lookup_module = LookupModule()
    byte_list = [src, dest]
    str_0 = "test"
    var_0 = lookup_module.run(src, dest)
    var_1 = lookup_module.run(byte_list, dest)


# Generated at 2022-06-25 10:49:36.209264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    result = lookup_module_0.run(bytes_0, str_0)
    assert result == [b'\x00']

# os.path.join(path, fn)

# Generated at 2022-06-25 10:49:39.193652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = '\x00'
    variables = '\x00'
    kwargs = '\x00'
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:49:45.287000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test raise exception for missing terms param
    with pytest.raises(AnsibleLookupError) as err:
        lookup_module.run(None, None)
    assert 'Missing required terms argument' in str(err.value)

    # Test raise exception for missing variables param
    with pytest.raises(AnsibleLookupError) as err:
        lookup_module.run([], None)
    assert 'Missing required variable argument' in str(err.value)

    # Test raise exception for invalid value for terms param
    with pytest.raises(AnsibleLookupError) as err:
        lookup_module.run('', {})
    assert 'Invalid term supplied' in str(err.value)

    # Test raise exception for invalid value for variables param

# Generated at 2022-06-25 10:49:51.667900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_params = dict()
    test_params['terms'] = ['/path/to/foo.txt', '/path/to/bar.txt']
    test_params['files'] = ['/path/to/foo.txt', '/path/to/bar.txt']
    test_params['paths'] = ['/path/to']
    test_params['skip'] = False
    test_params['lookup_type'] = 'first_found'
    test_params['runner'] = 'filesystem'
    params = dict()
    params['files'] = '/path/to/foo.txt'
    params['paths'] = '/path/to'
    params['skip'] = False
    # result = lookup_module_0.run(**test_params)
    # print(result)



# Generated at 2022-06-25 10:49:57.432344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define arguments and expected results.
    kwargs = {'paths': '\x00', 'files': '\x00'}
    lookup_instance_0 = LookupModule(**kwargs)
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)

    # Perform test
    result = lookup_instance_0.run(bytes_0, str_0, **kwargs)
    assert result == var_0

# Generated at 2022-06-25 10:50:00.365703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)
    assert var_0 is not None
    assert var_0 == list()

# Generated at 2022-06-25 10:50:05.758103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = '\x00'
    str_1 = '\x00'
    var_0 = lookup_run(str_0, str_1)


# Generated at 2022-06-25 10:50:09.133679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)



# Generated at 2022-06-25 10:50:13.575712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for args in [
        { 'terms': [['dict', 'dict'], [['dict'], 'dict', ['dict']]], 'variables': {}, 'kwargs': {} },
        ]:

        m0 = LookupModule()
        r0 = m0.run(**args)
        print("result is: %s" % r0)

# Generated at 2022-06-25 10:50:15.856545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    assert lookup_module_0.run(bytes_0, str_0)


# Generated at 2022-06-25 10:50:39.377991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == True

# Generated at 2022-06-25 10:50:43.515549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assume that the first_found playbook
    # doesn't use the "args" keyword argument.
    lookup_module = LookupModule()
    # Assume that the first_found playbook
    # uses "terms" and "variables" parameters.
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)



# Generated at 2022-06-25 10:50:49.694723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_0 = {'name': 'bar', '_terms': ['foo'], 'foo': 'bar', 'undefined': 'bar', 'otherdict': {'foo': 'bar', 'undefined': 'bar'}, 'otherlist': ['foo', 'bar', 'baz'], 'otherlistdict': [{'foo': 'bar', 'undefined': 'bar'}, {'foo': 'baz', 'undefined': 'baz'}], 'otherlistlist': [['foo', 'bar', 'baz'], ['list', 'of', 'lists']]}
    var_2 = {'files': ['files/foo.txt', 'files/bar.txt'], 'paths': ['files/foo', 'files/bar']}
    var_3 = 'bar'
    var_

# Generated at 2022-06-25 10:50:58.298992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = 'files/foo/bar.yml'
    tuple_1 = (
        'files/foo/bar.yml',
        {
            'files': 'bar.yml',
            'paths': 'files/foo'
        }
    )
    str_2 = 'files/foo/bar.yml'
    tuple_2 = (
        'files/foo/bar.yml',
        {
            'files': 'bar.yml',
            'paths': 'files/foo'
        }
    )

    # Test basic function
    assert lookup_module_1.run([tuple_1], None) == lookup_module_1.run([tuple_2], None)

    # Test special case
    assert lookup_module_1.run

# Generated at 2022-06-25 10:51:08.961343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'
    str_0 = '\x00'


# Generated at 2022-06-25 10:51:19.093290
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: mock find_file_in_search_path()
    # TODO: mock _templar.template()

    # setup
    lookup_module = LookupModule()

    # setup
    terms = [{'files': ['foo', 'bar'], 'paths': ['foo', 'bar']}, 'baz']

# Generated at 2022-06-25 10:51:28.679419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        assert isinstance(lookup_module_0, LookupModule)
    except:
        print('Expected an instance of LookupModule')
    try:
        assert isinstance(bytes_0, bytes)
    except:
        print('Expected an instance of bytes')
    try:
        assert isinstance(str_0, str)
    except:
        print('Expected an instance of str')
    try:
        assert lookup_module_0.run(bytes_0, str_0) is None
    except:
        print('Expected None')
    try:
        assert isinstance(var_0, list)
    except:
        print('Expected an instance of list')

# Generated at 2022-06-25 10:51:40.880012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    fd_0 = open('/tmp/ansible_lookup_plugin_first_found_0_file', 'w')
    fd_0.write('[example.org]\nserver\n')
    fd_0.close()
    os.chmod('/tmp/ansible_lookup_plugin_first_found_0_file',
             stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
    lookup_module_0._templar = Templar()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    str_1 = '\x00'
    str_2 = '\x00'

# Generated at 2022-06-25 10:51:42.461008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)


# Generated at 2022-06-25 10:51:45.409892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:52:16.177373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # with_first_found: ['/home/demo/First.txt', '/home/demo/Second.txt']
    bytes_1 = b'/home/demo/First.txt'
    str_1 = '/home/demo/First.txt'
    var_1 = lookup_run(bytes_1, str_1)
    # with_first_found: ['/home/demo/First.txt', '/home/demo/Third.txt']
    bytes_1 = b'/home/demo/First.txt'
    str_1 = '/home/demo/First.txt'
    var_2 = lookup_run(bytes_1, str_1)
    # with_first_found: ['/home/demo/Second.txt', '/home/demo/

# Generated at 2022-06-25 10:52:18.236149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert run(self, terms, variables, **kwargs, **b_kwargs) == 0

# Generated at 2022-06-25 10:52:19.375137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: Add tests for first_found.
    assert False



# Generated at 2022-06-25 10:52:25.864461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x80'
    str_0 = '\x80'
    str_1 = '\x7F'
    var_0 = lookup_module_0.run(bytes_0, str_0, files=[str_1])

# Generated at 2022-06-25 10:52:29.795493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = b'\x00'
    var_1 = ''
    var_2 = {'skvidal': 'skvidal', '_terms': ('/tmp/foo.txt', 'foo.txt', '/tmp/bar.txt')}
    lookup_module_0.run(var_0, var_1, **var_2)


# Generated at 2022-06-25 10:52:33.773503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)


# Generated at 2022-06-25 10:52:39.274504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b"FOO"
    str_0 = ''
    kwargs_0 = test_module_kwargs()
    var_0 = lookup_run(bytes_0, str_0, **kwargs_0)
    # assert_equal(var_0, ['default_foo.conf'])
    # assert_equal(var_0, ['/home/lk/alu/ansible/v2.2.0.0/lib/ansible/plugins/lookup/first_found.py'])


# Generated at 2022-06-25 10:52:42.537082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init LookupModule class
    lookup_module_0 = LookupModule()

    # Initialise any argument or class variable needed for test
    # Check if the run() method is returning the required data
    str_0 = '\x00'

    # Call the run() method of LookupModule class
    LookupModule.run(lookup_module_0, str_0)

# Generated at 2022-06-25 10:52:47.437475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00'
    str_0 = '\x00'
    var_0 = lookup_run(bytes_0, str_0)

# Test method run is not defined

# Generated at 2022-06-25 10:52:51.104138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    result = my_lookup.run('10.0.0.1', '../test/test.txt')
    assert result == ['test.txt'], "test_LookupModule_run failed"

