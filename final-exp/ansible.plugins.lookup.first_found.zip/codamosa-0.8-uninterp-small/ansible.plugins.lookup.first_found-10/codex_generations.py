

# Generated at 2022-06-25 10:43:18.461388
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with var_options set to empty dict or None
    total_search, skip = lookup_module_0._process_terms(terms=[], var_options={}, kwargs={})
    assert total_search == []
    assert skip == False

    # Test with var_options set to dict with 'files' and 'paths' keys
    total_search, skip = lookup_module_0._process_terms(terms=[
        {
            'files': ['foo', 'bar'],
            'paths': ['/tmp/production', '/tmp/staging']
        }
    ], var_options={}, kwargs={})
    assert total_search == ['/tmp/production/foo', '/tmp/production/bar', '/tmp/staging/foo', '/tmp/staging/bar']
    assert skip == False

    # Test with var_

# Generated at 2022-06-25 10:43:25.309911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['foo.txt', 'bar.txt', 'biz.txt']
    test_variables = {'foo': 'bar'}
    test_fail_on_undefined = True
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run(test_terms, test_variables, fail_on_undefined=test_fail_on_undefined) is not None


# Generated at 2022-06-25 10:43:30.768550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._lookup_for_first_found('', '', '')

# Generated at 2022-06-25 10:43:39.707048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n\nTest run\n")
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    lookup_module_1._basedir = './'
    lookup_module_1._subdir = 'test/test_data/test_case_0'
    lookup_module_1._loader = None
    lookup_module_1._templar = None
    lookup_module_1._display = None
    terms = [
        {'paths': './test/test_data/test_case_0/first_found_path/', 'files': 'file.txt'}
        ]

    variables = {}
    kwargs = {}

# Generated at 2022-06-25 10:43:48.682641
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # -------
    # setup
    # -------

    locale = 'us'
    terms = [
        {'name': 'foo', 'key': 'bar'},
        {'name': 'foo', 'key': 'bar'},
        {'name': 'foo', 'key': 'bar'}
    ]
    variables = {
        'exclude': 'spam,eggs',
        'max_age': '10',
        '_terms': ['foo', 'bar'],
    }
    kwargs = {
        'files': 'baz,biz',
        'paths': 'path1,path2',
        'skip': True
    }

    # --------
    # testing
    # --------

    look_mod_0 = LookupModule()

    total_search, skip = look_mod_0._process_terms

# Generated at 2022-06-25 10:43:50.617501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert not lookup_module_0
    assert lookup_module_0.run(["file1", "file2", "file3"]) == []


# Generated at 2022-06-25 10:43:59.793156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'first_found': {'skip': 'True'}}, direct={'skip': 'True'})
    lookup_module.set_options(var_options={'first_found': {'files': '/path/to/foo.txt,bar.txt'}}, direct={'files': '/path/to/foo.txt,bar.txt'})
    lookup_module.set_options(var_options={'first_found': {'paths': '/tmp/production,/tmp/staging'}}, direct={'paths': '/tmp/production,/tmp/staging'})
    assert lookup_module.get_option('skip') == 'True'

# Generated at 2022-06-25 10:44:06.110453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # all possible ways of calling 'run()'
    lookup_module_0 = LookupModule()
    tc_0_0 = lookup_module_0.run(['/etc/group'], None, [])
    tc_0_0 = lookup_module_0.run(['/etc/group'], None, None)
    tc_0_0 = lookup_module_0.run(None, None, None)
    tc_0_0 = lookup_module_0.run('/etc/group', None, [])
    tc_0_0 = lookup_module_0.run('/etc/group', None, 'files')
    tc_0_0 = lookup_module_0.run('/etc/group', None, None)

# Generated at 2022-06-25 10:44:16.814127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    def run_0(terms, variables, **kwargs):
        subdir = getattr(lookup_module_0, '_subdir', 'files')
        path = None
        for fn in terms:
            try:
                fn = lookup_module_0._templar.template(fn)
            except (AnsibleUndefinedVariable, UndefinedError):
                continue

            path = lookup_module_0.find_file_in_search_path(variables, subdir, fn, ignore_missing=True)

            if path is not None:
                return [path]

        raise AnsibleLookupError('nothing')

    lookup_module_0.run = run_0


# Generated at 2022-06-25 10:44:25.944572
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["test1.conf", "test2.conf", "test3.conf", "test4.conf"]
    variables = {"testvar": {}}

    lookup_module_0 = LookupModule()

    total_search, skip = lookup_module_0._process_terms(terms, variables, {})

    assert isinstance(total_search, list)
    assert isinstance(skip, bool)
    assert len(total_search) == 4

    for fn in total_search:
        assert isinstance(fn, string_types)
        assert len(fn) > 0


# Generated at 2022-06-25 10:44:43.584850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # TODO: add test for abs paths

    term = 'test_term'
    variables = {}
    kwargs = {'files': 'a.ini', 'paths': 'files'}
    assert lookup_module_0.run(term, variables, **kwargs) == ['/files/a.ini']
    kwargs = {'files': 'b.ini', 'paths': 'files'}
    assert lookup_module_0.run(term, variables, **kwargs) == ['/files/b.ini']
    assert lookup_module_0.run('a.ini', variables) == ['/files/a.ini']
    assert lookup_module_0.run('b.ini', variables) == ['/files/b.ini']

# Generated at 2022-06-25 10:44:53.758233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:45:04.365254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._subdir = 'files'
    lookup_module_1.current_chained_task = None
    lookup_module_1.current_task = None
    lookup_module_1.role = None
    lookup_module_1.play = None
    lookup_module_1.current_block = None
    lookup_module_1._data_cache = {}

    #test with terms [], variables={}, kwargs={}
    try:
        result = lookup_module_1.run([], {}, skip=False)
    except AnsibleLookupError as e:
        result = lookup_module_1.run([], {}, skip=True)
    assert result == []

    #test with terms [u'bar.txt'], variables={}, kwargs={}

# Generated at 2022-06-25 10:45:14.749069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:45:15.296198
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:45:19.699767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TEST CASE: Default: no files
    lookup_module = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(terms, variables, **kwargs)



# Generated at 2022-06-25 10:45:27.336476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run._subdir = 'files'

    mock_terms = [
        'vars/distribution.yml',
        'vars/os_family.yml',
        'vars/default.yml'
    ]

    mock_variables = 'variables'

    lookup_module_run._templar = 'templar'
    lookup_module_run.find_file_in_search_path = 'find_file_in_search_path'

    # run test
    lookup_module_run.run(mock_terms, mock_variables)

    # assert
    assert True

# Generated at 2022-06-25 10:45:35.232620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_distribution.yml', 'ansible_os_family.yml', 'default.yml']
    terms_1 = ['ansible_distribution.yml', 'ansible_os_family.yml', 'default.yml']
    variables_0 = "bar"
    kwargs_0 = {'paths': 'ambassadors'}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    result_1 = lookup_module_0.run(terms_1, variables_0, **kwargs_0)
    assert result_0 == result_1


# Generated at 2022-06-25 10:45:49.054781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0._subdir = 'files'

    # Test cases for LookupModule._process_terms

# Generated at 2022-06-25 10:45:51.616399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == ['']

# Generated at 2022-06-25 10:46:09.818264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    subdir = getattr(lookup_module_0, '_subdir', 'files')
    path = [lookup_module_0.find_file_in_search_path('foo', subdir, 'foo', True)]

    assert path == ['foo'], 'Unexpected value for path'


# Generated at 2022-06-25 10:46:16.748718
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:46:21.717622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testargs = {'errors': 'ignore'}
    test_LookupModule = LookupModule()
    terms = [{'files': ['test_file1.txt', 'test_file2.txt'], 'paths': ['/test/path']}]
    variables = {'test_var': 'test_value'}
    assert test_LookupModule.run(terms, variables) == ['/test/path/test_file1.txt']

# Generated at 2022-06-25 10:46:32.405562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo = LookupModule()
    result = foo.run(['/etc/foo.conf'], [])
    assert result == ['/etc/foo.conf']

    result = foo.run(['/etc/foo.conf', '/etc/bar.conf'], [])
    assert result == ['/etc/foo.conf']

    result = foo.run([{'files': 'foo.conf', 'paths': '/etc'}], [])
    assert result == ['/etc/foo.conf']

    result = foo.run([{'files': ['foo.conf', 'bar.conf'], 'paths': '/etc'}], [])
    assert result == ['/etc/foo.conf']


# Generated at 2022-06-25 10:46:33.603346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-25 10:46:43.444069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['foo', 'bar', 'baz']
    variables = {'t0_ansible_foo': 't0_ansible_foo', 't0_ansible_bar': 't0_ansible_bar', 't0_ansible_baz': 't0_ansible_baz', 't0_ansible_fiebaz': 't0_ansible_fiebaz'}
    kwargs = {'t0_ansible_foo': 't0_ansible_foo', 't0_ansible_bar': 't0_ansible_bar', 't0_ansible_baz': 't0_ansible_baz', 't0_ansible_fiebaz': 't0_ansible_fiebaz'}

# Generated at 2022-06-25 10:46:49.959292
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # kwargs is the dict of the named arguments, access values like below:
    #kwargs["paths"] or kwargs.get("paths")
    #kwargs["files"] or kwargs.get("paths")
    kwargs = {}
    kwargs["paths"] = "/tmp"
    kwargs["files"] = "foo"

    variable_manager =  {}
    variable_manager["foo"] = "bar"

    # Below is the return values, use it like below:
    # return_value.get("_raw")
    return_value =  {}
    return_value["_raw"] =  "bar"

    assert return_value.get("_raw") == LookupModule().run("", variable_manager, **kwargs)

# Generated at 2022-06-25 10:46:51.237246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([1], {}, {}) == []


# Generated at 2022-06-25 10:46:58.252070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case for the LookupModule's run function
    """
    # create instance of LookupModule
    lookup_module_obj = LookupModule()

    # test 1
    # test with empty terms

# Generated at 2022-06-25 10:47:05.357402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	##############
	# Initialize #
	##############
    terms = []
    variables = {}
    kwargs = {}

    lookup_module_0 = LookupModule()

	###################
	# Test the method #
	###################
    result = lookup_module_0.run(terms, variables, kwargs)
    assert result == None, "result should be 'None' but is: %s" % result

    # TODO: add more tests here
    print("\nAll tests for method 'run' passed")


# Generated at 2022-06-25 10:47:28.407711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run([],{},dict()),list)

# Generated at 2022-06-25 10:47:37.538573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0_0 = ['foo', 'bar', 'biz']
    term_1_0 = ['foo', 'bar', 'biz']
    term_2_0 = ['foo', 'bar', 'biz']
    variables = {"bar": "bar"}
    result = lookup_module_0.run(term_0_0, variables, files=['foo', 'bar', 'biz'], paths=['foo', 'bar', 'biz'], skip=False)
    assert result == []

    result = lookup_module_0.run(term_1_0, variables, files=['foo', 'bar', 'biz'], paths=['foo', 'bar', 'biz'], skip=False)
    assert result == []


# Generated at 2022-06-25 10:47:44.925135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    lookup_module_0.run(['foo'], {'bar': 'baz'}, **{'bar': 'baz'})
    lookup_module_0.run(['foo'], {'bar': 'baz'}, **{'bar': 'baz'})
    try:
        lookup_module_0.run(['foo'], {'bar': 'baz'}, **{'bar': 'baz'})
    except AnsibleLookupError:
        pass
    else:
        raise Exception("unexpected test case 0")

    lookup_module_0.run(['foo'], {'bar': 'baz'}, **{'bar': 'baz'})


# Generated at 2022-06-25 10:47:50.635161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test case 0

    terms_0 = ['foo.txt']
    variables_0 = {}
    kwargs_0 = {'errors': 'ignore'}

    lookup_module_0._process_terms = lambda x, y, z: ([], False)
    retval_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert retval_0 == []

    # test case 2
    # TODO: add test cases


# Generated at 2022-06-25 10:48:01.106132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # get a sample lookuptree
    lookup_terms = [
        {
            'files': [
                'foo.txt',
                'bar.txt',
                '{{ inventory_hostname }}.txt',
            ],
            'paths': [
                'path/to/file',
            ],
            'skip': True,
        },
        'baz.txt',
        ['spam.txt', 'ham.txt'],
    ]

    # variables should have a '_terms' attribute set to the terms used
    # in the lookup call
    variables = {
        '_terms': lookup_terms,
    }

    # call the function
    lookup_file = lookup_module.run(lookup_terms, variables)

    # check the results

# Generated at 2022-06-25 10:48:11.130240
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:48:17.403827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        {
            'files': '/tmp',
            'paths': 'foo'
        },
        'bar',
        'baz'
    ]
    variables_0 = dict()
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == [
        'files/bar',
        'files/baz'
    ]



# Generated at 2022-06-25 10:48:23.791845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['abc', 'xyz'], [{'abc': 'def'}]), list)
    assert isinstance(lookup_module_0.run([], []), list)
    assert isinstance(lookup_module_0.run(['abc'], [{'abc': 'def'}]), list)
    assert isinstance(lookup_module_0.run([], [{'abc': 'def'}]), list)
    assert isinstance(lookup_module_0.run([], [{'abc': 'def'}]), list)

# Generated at 2022-06-25 10:48:34.995263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run(['foo.txt']) == ['foo.txt']
    assert lookup_module_0.run(['foo.txt', 'bar.txt']) == ['foo.txt']
    assert lookup_module_0.run([{'skip': True}]) == []
    assert lookup_module_0.run([{'skip': False}]) == []
    assert lookup_module_0.run([{'files': 'foo.txt'}]) == ['foo.txt']
    assert lookup_module_0.run([{'files': 'foo.txt', 'paths': 'bar/'}]) == ['bar/foo.txt']

# Generated at 2022-06-25 10:48:40.181489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/ansible/hosts']
    variables = {}
    paths = ['']
    kwargs = {'paths': paths, '_': '/usr/local/bin/ansible', '__file__': '/etc/ansible/roles/role_under_test/library/my_module.py', '__line__': 2, '__name__': '__main__'}
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:49:23.635080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()

    # Invoke method
    result = lookup_module_0.run(terms=["1", "2", "3"], variables=["1", "2", "3"])

    # Verify results
    assert result == ["1"]


# Generated at 2022-06-25 10:49:28.389538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    file_list_0 = ['string_0']
    variable_dict_0 = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'}
    res_0 = lookup_module_0.run(file_list_0, variable_dict_0)
    assert res_0 != None


# Generated at 2022-06-25 10:49:36.831145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # setting variables
    variables = {}
    # checking the results
    assert lookup_module.run([''], variables) == ['']
    # second run
    assert lookup_module.run([''], variables) == ['']
    # third run
    assert lookup_module.run([''], variables) == ['']
    # calling the run with arguments
    # setting terms
    terms = ['']
    # setting variables
    variables = {}
    # checking the results
    assert lookup_module.run(terms, variables) == ['']
    # second run
    assert lookup_module.run(terms, variables) == ['']
    # third run
    assert lookup_module.run(terms, variables) == ['']
    # calling the run with arguments
    # setting terms
    terms

# Generated at 2022-06-25 10:49:45.772078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # from ansible.parsing.dataloader import DataLoader
    # from ansible.vars import VariableManager
    # from ansible.inventory import Inventory
    # from ansible.playbook.play_context import PlayContext
    # loader = DataLoader()
    # variable_manager = VariableManager()
    # inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='/etc/ansible/hosts')
    # variable_manager.set_inventory(inventory)
    # play_context = PlayContext()
    # terms = [ """{{ foo }}""", """{{ lookup('first_found', [ '{{ foo }}']) }}""", """bar""" ]
    # result = lookup_module_0.run(terms, variable_manager=variable_manager, play_

# Generated at 2022-06-25 10:49:49.675988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:49:53.014800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["/etc/hosts"]
    variables_0 = {}
    keyword_args_0 = {"errors": True}
    assert lookup_module_0.run(terms_0, variables_0, **keyword_args_0) == ['/etc/hosts'], "Function run failed"


# Generated at 2022-06-25 10:50:00.292227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = ['test/test_case_0.test_LookupModule_run.test_LookupModule_run', 'test/test_case_0.test_LookupModule_run.test_LookupModule_run.test_LookupModule_run']
    variables = dict()
    kwargs = dict()
    result = lookup_module.run(term, variables, **kwargs)
    assert('test/test_case_0.test_LookupModule_run.test_LookupModule_run' in result)
    assert('test/test_case_0.test_LookupModule_run.test_LookupModule_run.test_LookupModule_run' in result)

# Generated at 2022-06-25 10:50:11.029008
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # minimal path
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    variables_0 = {}
    kwargs = {'files': ['foo.yml'], 'paths': ['.']}
    lookup_module_0.run(['foo.yml'], variables_0, **kwargs)

    # maximal path
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    variables_0 = {}
    kwargs = {'files': ['foo.yml'], 'paths': ['.']}
    lookup_module_0.run(['foo.yml'], variables_0, **kwargs)

    # minimal path an error
    from ansible.errors import AnsibleLookupError
    lookup_module_

# Generated at 2022-06-25 10:50:11.739309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # TODO: wizzy edit
  assert True == True

# Generated at 2022-06-25 10:50:14.594093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["test1.txt","test2.txt"], variables={}) == ['/test1.txt']


# Generated at 2022-06-25 10:50:59.779156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0, list_0)
    assert True


# Generated at 2022-06-25 10:51:10.093473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    params_0 = {'skip': True, 'files': ['null', 'null'], 'paths': ['null', 'null']}
    terms_0 = [params_0]
    variables_0 = {'null': None}
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == []

    params_1 = {'files': ['null', 'null'], 'paths': ['null', 'null']}
    terms_1 = [params_1]
    variables_1 = {'null': None}
    lookup_module_1 = LookupModule()
    ret_1 = lookup_module_1.run(terms_1, variables_1)
    assert ret_1 is None


# Generated at 2022-06-25 10:51:19.160709
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    var_terms_0 = list_0
    var_kwargs_0 = {}
    var_0 = lookup_module_13

# Generated at 2022-06-25 10:51:24.798788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # constructor test
    lookup_module_obj = LookupModule()
    assert lookup_module_obj.list_0 == 0, 'The constructor call of the LookupModule object did not create a valid object'

    # Parameterized tests
    lookup_module_obj.run(list_0, list_0)

    # test assertions
    assert 0 == 0, 'The lookup_module_obj.run() method call did not return the expected value'

# Generated at 2022-06-25 10:51:30.048977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    List = []
    lookup_module_0 = LookupModule()
    #var_0 = LookupModule.run(List, List, List)
    #var_1 = LookupModule.run(List, List, List)
    #var_2 = LookupModule.run(List, List, List)
    #var_3 = LookupModule.run(List, List, List)
    #var_4 = LookupModule.run(List, List, List)


# Entry point for program
if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:51:39.034076
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # 
    # global skip wont matter, only last 'skip' value in dict term
    lookup_module_0._process_terms([{'files': ['foo'], 'paths': [], 'skip': True}], [], {})

    # AssertionError: [] != None
    lookup_module_0.run([{'files': ['foo'], 'paths': [], 'skip': True}], [], {})
    # AssertionError: [] != None
    # lookup_module_0.run([{'files': ['foo'], 'paths': [], 'skip': True}], [], {})

# Generated at 2022-06-25 10:51:43.191921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    list_1 = []
    list_2 = [1]

    assert lookup_module_0.run(list_0, list_1) == list_2

# ---------- test ----------

# Generated at 2022-06-25 10:51:48.419284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0, list_0)


# Generated at 2022-06-25 10:51:51.871054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(['foo', 'bar'], [{}])
    assert var_1 == []
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run([], [{}])
    assert var_2 == []



# Generated at 2022-06-25 10:51:56.796786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_virtualization_type']
    variables = ['file_found']
    kwargs = {}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables, **kwargs)
    assert True

# Generated at 2022-06-25 10:52:56.735576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Mock Ansible templar object
templar = MockTemplar()

# Mock Ansible lookup module
lookup_module_0 = MockLookupModule()

# Mock Ansible task executor
task_executor = MockTaskExecutor()

# Mock Ansible variable manager
variable_manager = MockVariableManager()

# Mock Ansible loader
loader = MockLoader()

# The 'ansible' global variable
ansible = MockAnsibleObject()

# This is the expected start value
expected_value = 'Mock module'

# Generated at 2022-06-25 10:52:59.061954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = []
    dict_1 = {}
    list_2 = []
    lookup_run(list_0, list_1, dict_1, list_2)


# Generated at 2022-06-25 10:53:04.035065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = []
    list_0.append(list_1)
    testcase_0 = [[], list_0, list_1]
    for testcase_1 in testcase_0:
        var_0 = lookup_module_0.run(testcase_1, list_0)
        test_case_0()
