

# Generated at 2022-06-25 10:43:15.625893
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:43:22.537448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["foo.txt", "bar.txt", "baz.txt"]
    variables = dict()
    assert lookup_module_0.run(terms, variables) == []


# Generated at 2022-06-25 10:43:28.132515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # setup
   lookup_module = LookupModule()
   lookup_module._templar = MockTemplar()

   # expect
   mock_find_file_in_search_path = lookup_module.find_file_in_search_path = Mock()
   mock_find_file_in_search_path.return_value = None

   # result
   result = lookup_module.run([
      {
         "paths": "path"
      }
   ], {})

   # verify
   assert result == []


# Generated at 2022-06-25 10:43:36.080889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize test object
    lookup_module_0 = LookupModule()
    # Test empty argument
    try:
        lookup_module_0.run([], {})
    except AnsibleLookupError:
        pass
    except Exception:
        assert False, "Unexpected exception"
    else:
        assert False, "Expected exception"
    # Test with simple argument
    try:
        lookup_module_0.run([], {}, files=['abc.txt', 'def.txt'])
    except AnsibleLookupError:
        pass
    except Exception:
        assert False, "Unexpected exception"
    else:
        assert False, "Expected exception"
    # Test with multiple arguments

# Generated at 2022-06-25 10:43:40.732380
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = 'foo,bar.txt'
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, None)
    assert result == ['foo', 'bar.txt']

    terms = 'foo,bar'
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, None)
    assert result == ['foo', 'bar']

    terms = 'foo,bar:baz'
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, None)
    assert result == ['foo', 'bar', 'baz']

    terms = 'foo,bar:baz, test'
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, None)

# Generated at 2022-06-25 10:43:46.355009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    values = lookup_module_0.run(terms=[{'files': 'foo.txt', 'paths': 'foo.txt'}], variables=None, **{'files': ['foo.txt']})
    assert isinstance(values, list)
    # assert values == []

# Generated at 2022-06-25 10:43:50.423923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0 = [0, 1, 2]
    kwargs_0 = {'elements': 3, 'direct': 4}
    # Should work with or without the self argument
    assert lookup_module_0.run(args_0, kwargs_0) == lookup_module_0.run(*args_0, **kwargs_0)


# Generated at 2022-06-25 10:43:54.111359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['filename.txt']
    variables_0 = {}
    __retval_0 = lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:43:58.132033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term1 = "test_term1"
    terms = [term1]

    # call the run function of LookupModule
    result = lookup_module_0.run(terms, "variables")

    # assert that it returns value as expected
    assert (result == ["test_term1"])


# Generated at 2022-06-25 10:44:09.815097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run')

    # Setup test variables
    lo_kwargs = dict(files=['/tmp/production', '/tmp/staging'], paths=[])
    lo_terms = [(['foo', 'bar', 'baz'], dict(paths=['/tmp/staging'])), dict(files=['/tmp/production', '/tmp/staging'])]
    lo_variables = {'ansible_os_family': 'Debian', 'ansible_distribution': 'Debian', 'inventory_hostname': 'Debian'}
    # Run test
    expected_return = ['/tmp/production']
    returned_value = LookupModule().run(lo_terms, lo_variables, **lo_kwargs)

    # Assertion for the test
    assert returned_value == expected_return

    # Setup test

# Generated at 2022-06-25 10:44:22.156433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    searchpath = "/"
    searchpath_0 = lookup_module_0.find_file_in_search_path(None, "files", "test/test.txt", ignore_missing=False)
    assert searchpath_0 == "/root/Github/test/test.txt"

    searchpath_1 = lookup_module_0.find_file_in_search_path(None, "files", "test/test.txt", ignore_missing=True)
    assert searchpath_1 == "/root/Github/test/test.txt"

    searchpath_2 = lookup_module_0.find_file_in_search_path(None, "files", "test/test2.txt", ignore_missing=False)
    assert searchpath_2 == "test/test2.txt"



# Generated at 2022-06-25 10:44:29.338453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path_0 = '/etc/ansible/roles/role_under_test/files/a_file'
    subdir_0 = 'files'
    lookup_module_0 = LookupModule()
    variables_0 = {
        'lookup_variables': {},
        'roles': [
            {
                'name': 'role_under_test',
                'role_path': '/etc/ansible/roles/role_under_test',
                'vars': {},
                'defaults': {},
                'vars_files': [],
            },
        ],
    }
    results_0 = ['/etc/ansible/roles/role_under_test/files/a_file']

# Generated at 2022-06-25 10:44:30.801576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert '' == lookup_module.run()


# Generated at 2022-06-25 10:44:38.942319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('')

    # parameters
    kwargs = {'files': '/bad/file.txt', 'paths': 'bad/path'}
    terms = ['foo.txt', 'bar.txt', 'biz.txt']
    variables = {}

    # return
    expected = []
    lookup_module = LookupModule()
    actual = lookup_module.run(terms, variables, **kwargs)
    assert actual == expected



# Generated at 2022-06-25 10:44:41.436394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # run will naturally fail if templar is not set etc
  lookup_module_0 = LookupModule()
  assert lookup_module_0.run(['something'], {}) == []

# Generated at 2022-06-25 10:44:52.695883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test one arg
    print("")
    print("test LookupModule.run() with one arg")
    lookup_module_1 = LookupModule()
    params = [
        (["test_file", "tests/files/test_file"], {}, {}),
        (["test_file,test_file2", "tests/files/test_file"], {}, {}),
        (["test_file,test_file2", "tests/files/test_file"], {}, {"files": ["test_file", "test_file2"], "paths": ["tests/files"]}),
    ]
    for arg, variables, kwargs in params:
        print("         run(%s, %s, %s)" % (arg, variables, kwargs))

# Generated at 2022-06-25 10:45:03.510132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This code block is executed when the script is run directly from the command line
    # Create a LookupModule object and test if the run method functions as expected
    lookup_module_1 = LookupModule()

    terms = [{'files': ['foo', 'bar'], 'paths': ['/tmp/', '/var']}]
    variables = {}
    res = lookup_module_1.run(terms, variables)
    assert res == [os.path.join(path, 'foo') for path in ['/tmp/', '/var']] + [os.path.join(path, 'bar') for path in ['/tmp/', '/var']]

    terms = [{'files': ['foo', 'bar'], 'paths': []}]
    variables = {}
    res = lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 10:45:12.896321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        '_terms': [
            {
                'skip': False,
                'files': [
                    'foo',
                    'bar',
                    'biz'
                ],
                'paths': [
                    '/tmp/test/test_case_0'
                ]
            }
        ],
        '_templar': None,
        '_loader': None
    }
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(**args)
    assert res == ['/tmp/test/test_case_0/foo']

# Generated at 2022-06-25 10:45:15.978035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  terms = "foo"
  variables = {}
  lookup_plugin_run_result = lookup_module.run(terms, variables)
  assert isinstance(lookup_plugin_run_result, list)

# Generated at 2022-06-25 10:45:23.745648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: basic test case to test with simple values
    lookup_module_0 = LookupModule()
    terms = ('answer.txt', )
    variables = {}
    kwargs_expect = {'skip': False, 'paths': [], 'files': []}
    kwargs_got = {}
    result_expect = []
    result_got = lookup_module_0.run(terms, variables, **kwargs_got)
    assert result_expect == result_got
    assert kwargs_expect == kwargs_got


# Generated at 2022-06-25 10:45:30.534337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 10:45:35.843164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = ['file1', 'file2']
    paths = ['/tmp/production', '/tmp/staging']
    skip = False
    files = ['file1', 'file2']
    variables = {'file1': '/tmp/file1', 'file2': '/tmp/file2'}
    expected = ['/tmp/file1']
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(params, variables, paths=paths, skip=skip, files=files)
    assert result == expected


# Generated at 2022-06-25 10:45:45.104173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['file1', 'file2']
    variables = {}
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)
    lookup_module_0 = LookupModule()
    terms = [1, 2]
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:45:53.301193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{"paths": ["/tmp"], "files": "foo.txt"}, "bar.txt", "baz.txt", "blargh.txt", {"paths": ["/tmp/production"], "files": "bazz.txt"}]
    lookup_module.run(terms, [])

# vim: set et ts=4 sw=4 sts=4 ai :

# Generated at 2022-06-25 10:46:03.068437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{"paths": "/etc/ansible/playbooks/"}, {"paths": []}, {"paths": []}, {"paths": []}, {"paths": []}, {"paths": []}]
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == "AnsibleLookupError: No file was found when using first_found."


# Generated at 2022-06-25 10:46:04.195028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert ...
    assert lookup_module_0.run() == expected_result_0


# Generated at 2022-06-25 10:46:13.311505
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    tests = []
    tests.append(({'_terms': {'files': ['foo', 'bar']}, '_variables': None}, ['/etc/foo', '/etc/bar']))

    for (args, result) in tests:
        assert LookupModule().run(*args) == result

# Generated at 2022-06-25 10:46:15.530810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'hello'
    variables_0 = 'hello'
    assert lookup_module_0.run(terms_0, variables_0) == 'hello'


# Generated at 2022-06-25 10:46:22.277570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    setattr(lookup_module_0, '_templar', templar_0_templar)
    setattr(lookup_module_0, '_loader', loader_0_loader)
    lookup_module_0.set_options(direct={'skip': False, 'files': 'foo.txt', 'paths': '../'})
    lookup_module_0.run(['../', 'foo.txt'], dictionary={"ansible_connection": "local", "ansible_user": "root"})

test_case_0()

# Generated at 2022-06-25 10:46:32.985631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    x_0 = [u'files.yml', u'files.yml', 'files.yml', u'files.yml']
    x_1 = dict()
    x_2 = dict()
    x_2[u'files'] = u'foo1,foo2'
    x_2[u'paths'] = u'bar1,bar2'
    x_3 = dict()
    x_3[u'files'] = u'foo3'
    x_3[u'paths'] = u'bar3'
    x_4 = dict()
    x_4[u'paths'] = u'bar4'
    x_4[u'files'] = u'foo4'
    x_4[u'skip'] = u'False'


# Generated at 2022-06-25 10:46:43.441026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:46:53.552366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['file.txt', 'file.yml']
    variables = {'hostvars': {'host_2': {'ansible_distribution': '', 'ansible_os_family': 'RedHat'}, 'host_3': {'ansible_distribution': 'RedHat', 'ansible_os_family': 'RedHat'}, 'host_1': {'ansible_distribution': 'Debian', 'ansible_os_family': 'Debian'}}}
    kwargs = {'files': [], 'paths': []}
    assert lookup_module.run(terms, variables, **kwargs) == []
    terms = ['file.txt', 'file.yml']

# Generated at 2022-06-25 10:47:04.573313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the following case
    # 1. Test the run() method of LookupModule with following parameters
    #    i.   ['/path/to/foo.txt', 'bar.txt']
    #    ii.  {'files': ['/path/to/foo.txt', '/path/to/bar.txt'], 'paths': ['/extra/path'], 'skip': 'True'}
    #    iii. {'terms': [{'files': ['/path/to/foo.txt', '/path/to/bar.txt'], 'paths': ['/extra/path'], 'skip': 'True'}]}

    lookup_module_1 = LookupModule()

    # Test the case where find_file_in_search_path() finds the file

# Generated at 2022-06-25 10:47:12.055546
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup_module_0 = LookupModule()
    with mock.patch('ansible.plugins.lookup.first_found.LookupModule._process_terms', new_callable=mock.PropertyMock, create=True) as mock_process_terms:
        lookup_module_0._process_terms = mock_process_terms
        lookup_module_0._process_terms.return_value = [], False

        terms = []
        variables = {}
        kwargs = {}

        # Invoke method
        result = lookup_module_0.run(terms, variables, **kwargs)

        # Assertions
        assert lookup_module_0._process_terms is mock_process_terms
        assert isinstance(lookup_module_0._process_terms, mock.PropertyMock)
        lookup_module_0._

# Generated at 2022-06-25 10:47:17.459110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with an empty list
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([], {}) == [])



# Generated at 2022-06-25 10:47:23.441792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_obj = LookupModule()
    try:
        lookup_module_run_obj.run("", "")
    except AnsibleLookupError as e:
        return "AnsibleLookupError raised"

# Generated at 2022-06-25 10:47:33.095690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_dir = "/tmp/ansible_test_dir"
    test_file = "test_file"
    test_content = "test_content"
    terms = terms = [{'files': test_file, 'paths': test_dir}]
    variables = {}
    kwargs = {}


# Generated at 2022-06-25 10:47:35.975842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # assert that temp_dir in search_path is present in template result
    assert(temp_dir in lookup_module_1.run(terms = [temp_dir_str], variables = {}, skip = True)[0])

# Generated at 2022-06-25 10:47:43.205409
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test default, found file
    _ = os.environ.pop('ANSIBLE_LOOKUP', None)
    lookup_module_0 = LookupModule()
    from ansible.template import Templar
    _ = os.environ.pop('ANSIBLE_LOOKUP', None)
    lookup_module_0._templar = Templar(loader=None, variables={})
    _ = os.environ.pop('ANSIBLE_LOOKUP', None)
    lookup_module_0._templar.available_variables = dict()
    _ = os.environ.pop('ANSIBLE_LOOKUP', None)
    lookup_module_0._loader = None
    _ = os.environ.pop('ANSIBLE_LOOKUP', None)
    lookup_module_0.set_loader(None)

# Generated at 2022-06-25 10:47:51.565386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # 'lookup' is an instance of ansible.plugins.lookup.LookupModule
    # _process_terms should return a tuple of (['path1', ...., 'pathN'], skip)
    # where skip is a boolean.
    # The same file name is given five times. `a` is an instance of ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode
    # and it is encrypted by default.
    lookup.set_options(direct={'_raw': ['test/test.txt', 'test/test.txt', 'test/test.txt', 'test/test.txt', 'test/test.txt'], 'paths': ['/home/ubuntu'], 'skip': False, 'a': 'encrypted'})

# Generated at 2022-06-25 10:48:03.401168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)


# Generated at 2022-06-25 10:48:08.632349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)
    if var_0 == 'foo':  # <<<<<<<<<<<<<<
        assert True
    elif var_0 == 'bar':
        assert True
    else:
        assert False

# Unit test boilerplate

# Generated at 2022-06-25 10:48:15.564471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()
    lookup_module_16 = LookupModule()

# Generated at 2022-06-25 10:48:21.649260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = '/Users/Albert/PycharmProjects/Ansible/lib/ansible/plugins/lookup/first_found.py'
    var_1 = lookup_module_1.run(str_1, str_1)
    assert(isinstance(var_1, list))


# Generated at 2022-06-25 10:48:33.031682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_module_0()
    var_0 = None
    var_1 = None
    str_0 = ''
    str_1 = ''
    var_2 = lookup_run(var_0, var_0)
    var_2 = lookup_run(var_0, str_0)
    var_2 = lookup_run(var_0, var_0)
    var_2 = lookup_run(var_0, str_0)
    var_2 = lookup_run(var_0, var_0)
    var_2 = lookup_run(var_0, str_0)
    var_2 = lookup_run(var_0, var_0)
    var_2 = lookup_run(var_0, str_0)

# Generated at 2022-06-25 10:48:36.944145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([], []) == []


# Generated at 2022-06-25 10:48:45.553731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    list_0 = []
    list_1 = []
    list_2 = []
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_3 = ''
    str_4 = '|'
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}

# Generated at 2022-06-25 10:48:48.396812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string_0 = 'xqk-*9Y<E'
    string_1 = '*^`f#'
    string_2 = '*^`f#'
    test_case_0(string_0, string_1, string_2)


# Generated at 2022-06-25 10:48:52.181699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)


# Generated at 2022-06-25 10:48:54.190281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    # TODO: add tests for class LookupModule
    pass



# Generated at 2022-06-25 10:49:11.099103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)



# Generated at 2022-06-25 10:49:13.885648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  str_0 = ''
  str_1 = ''
  var_0 = lookup_module_0.run(str_0, str_1)


# Generated at 2022-06-25 10:49:22.972244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{'files': 'foo.txt', 'paths': '/tmp'}]
    mock_variables = {'extravars': {'ansible_env': {'HOME': '/home/me'}}}
    _skip = True
    path_0 = '/home/me/files/foo.txt'
    result_0 = lookup_module.run(terms, mock_variables, _skip=_skip)

    assert result_0 == [path_0]


# This is a helper function that is called to find the path to a file

# Generated at 2022-06-25 10:49:28.811700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    kwargs_0 = ''
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 10:49:36.050973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)
    str_1 = ''
    var_1 = lookup_run(str_1, str_1)
    str_2 = ''
    var_2 = lookup_run(str_2, str_2)
    str_3 = ''
    var_3 = lookup_run(str_3, str_3)
    str_4 = ''
    var_4 = lookup_run(str_4, str_4)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:49:39.421739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [str_0]
    dict_0 = {}
    list_1 = lookup_module_0.run(list_0, dict_0)
    assert list_1 == ['str_0']


# Generated at 2022-06-25 10:49:42.017194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'foo'
    var_0 = None
    var_1 = 'foo'
    var_2 = lookup_run(str_0, var_0, var_1)


# Generated at 2022-06-25 10:49:53.777540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 10:50:01.567257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case where parameters 'terms' is undefined
    lookup_module_1 = LookupModule()
    str_1 = ''
    var_1 = lookup_run(str_1, str_1)
    assert var_1 == []

    # Test case where parameters 'terms' is of type string
    lookup_module_2 = LookupModule()
    str_2 = 'bar.txt'
    str_3 = 'files'
    str_4 = 'foo.txt'
    str_5 = 'bar.txt'
    str_6 = 'foor'
    lookup_run(str_2, str_3, str_4, str_5, str_6)

    # Test case where parameters 'terms' is of type list
    lookup_module_3 = LookupModule()
    list_0 = ['bar.txt']
   

# Generated at 2022-06-25 10:50:08.380082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    list_0 = []
    dict_0 = dict()
    str_1 = lookup_run(str_0, list_0)
    str_2 = lookup_run(str_0, dict_0)


# Generated at 2022-06-25 10:50:40.365333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = ''
    int_0 = 1
    var_0 = lookup_run(str_0, str_0)

# Generated at 2022-06-25 10:50:45.858389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)
    var_0 = lookup_run(str_0, str_0, str_0)


# Generated at 2022-06-25 10:50:56.852298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_1 = ''
    list_1 = []
    dict_2 = dict()
    lookup_module_1.run(list_1, dict_2)
    dict_3 = dict()
    dict_3['files'] = dict_2
    dict_3['paths'] = dict_2
    dict_4 = dict()
    dict_4['skip'] = dict_2
    dict_4['path'] = dict_2
    dict_4['var_options'] = dict_2
    dict_4['direct'] = dict_3
    dict_4['filelist'] = dict_2
    dict_4['pathlist'] = dict_2
    dict_3['files'] = dict_2
    dict_3['paths'] = [str_1]
    lookup_

# Generated at 2022-06-25 10:51:07.960074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '$^Qd8x}q3?#'
    str_1 = 'm8wv'
    dict_0 = dict({u'aX8z' : dict({u'h' : 'F'}), u'~' : '\x1a\'uC', u'X' : 'z2\x7f\x0b', u's6f' : '\x1f\x06\x05\x0e', u'*' : '\x01W8\x11', u'+' : '\x0fy', u'Dz' : '\x1b\x04\x00\r', u'QG' : '(l\x1d', u'x' : '\x1e;\x0e'})

# Generated at 2022-06-25 10:51:18.872363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    lookup_module_1 = LookupModule()
    terms_1 = ''
    variables_1 = ''
    kwargs_1 = {}
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    lookup_module_2 = LookupModule()
    terms_2 = ''
    variables_2 = ''
    kwargs_2 = {}
    result_2 = lookup_module_2.run(terms_2, variables_2, **kwargs_2)
    lookup_module_3 = LookupModule

# Generated at 2022-06-25 10:51:20.958802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule()
    str_0 = ''
    var_0 = lookup_run.run(str_0, str_0)
    assert var_0 == []

test_LookupModule_run()

# Generated at 2022-06-25 10:51:25.991388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_0 = LookupModule()
    terms = ''
    variables = ''
    # exercise
    var_0 = lookup_module_0.run(terms, variables)
    # verify
    assert var_0[0] == ''


# Generated at 2022-06-25 10:51:27.894079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    var_0 = lookup_run(str_0, str_0)


# Generated at 2022-06-25 10:51:34.001630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options(var_options={}, direct={'files': [], 'paths': [], 'skip': False})
    lookup_module_2.run([], [])
    lookup_module_3 = LookupModule()
    lookup_module_3.set_options(var_options={}, direct={'files': [], 'paths': [], 'skip': False})
    lookup_module_3.run(['', ''], [])
    lookup_module_4 = LookupModule()
    lookup_module_4.set_options(var_options={}, direct={'files': [], 'paths': [], 'skip': False})
    lookup_module_4.run([{}], [])
    lookup_module_5 = LookupModule()
    lookup

# Generated at 2022-06-25 10:51:41.314563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, str_0)
    assert type(var_0) is list
    assert var_0[0] is None


# Generated at 2022-06-25 10:52:48.654713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = ''
    var_0 = lookup_module.run(str_0, str_0)
    assert var_0 == []


# Generated at 2022-06-25 10:52:56.259403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = {}
    kwargs['subdir'] = None
    kwargs['template'] = None
    kwargs['configfile'] = None

    lookup_module_0 = LookupModule()
    str_0 = 'files/lookup_files/c'
    str_1 = 'files/lookup_files/c'
    result_0 = lookup_module_0.run(str_0, str_1, **kwargs)
    result_1 = lookup_module_0.run('files/lookup_files/a', None, **kwargs)
    result_2 = lookup_module_0.run('files/lookup_files/b', None, **kwargs)


# Generated at 2022-06-25 10:53:06.751302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    dict_0 = dict()
    dict_0 = dict()
    dict_1 = dict()
    dict_1['type'] = 'yaml'
    dict_1['groups'] = dict_0
    str_1 = ''
    dict_2 = dict()
    dict_2['lookup_plugin'] = 'yaml'
    dict_2['_ansible_verbosity'] = 0
    dict_2['no_log'] = False
    dict_2['_ansible_tmpdir'] = '~/.ansible/tmp'
    dict_2['role_paths'] = ['..']
    dict_2['run_once'] = False

# Generated at 2022-06-25 10:53:13.215008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = 'undefined'
    var_0 = lookup_run(str_0, str_1)

