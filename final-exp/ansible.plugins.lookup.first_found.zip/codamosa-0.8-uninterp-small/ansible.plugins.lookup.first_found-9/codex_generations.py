

# Generated at 2022-06-25 10:43:12.924256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['']
    variables = ''
    kwargs = {}
    lookup_module.run(terms, variables, kwargs)

# Generated at 2022-06-25 10:43:18.717398
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test template:
    # name: Set _found_file to the first existing file, raising an error if a file is not found
    #   set_fact:
    #     _found_file: "{{ lookup('first_found', findme) }}"
    #   vars:
    #     findme:
    #       - /path/to/foo.txt
    #       - bar.txt  # will be looked in files/ dir relative to role and/or play
    #       - /path/to/biz.txt

    # set desired variables:
    variables = dict()
    variables['ansible_env'] = dict()
    variables['ansible_env']['HOME'] = '/home/ansible'
    variables['ansible_env']['USER'] = 'ansible'

# Generated at 2022-06-25 10:43:22.994834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  par = []
  variables = {}
  lookup_module_0 = LookupModule(loader=None, variables=variables)
  res = lookup_module_0.run(par, variables)
  return res

# Generated at 2022-06-25 10:43:33.382254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # test_run_0
    terms_0 = [
        '../tasks/main.yln',
        '../tasks/yum.yml',
    ]
    variables_0 = {} # type: dict
    errors_0 = 'ignore'
    kwargs_0 = {
        'paths': [
            '../host_vars',
            '../group_vars',
            '../vars',
            'vars',
        ],
    }
    assert lookup_module_1.run(terms_0, variables_0, **kwargs_0) == ['../tasks/main.yml']

    # test_run_1

# Generated at 2022-06-25 10:43:41.535381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader({'module_utils': {'common': {'_collections_compat': {'Mapping' : Mapping}}}})
    lookup_module_0.set_available_variables({'lookup_dirs' : ['/root/ansible/ansible/lookup/files']})
    terms_0 = ['non_existing.yml']
    variables_0 = {'lookup_dirs' : ['/root/ansible/ansible/lookup/files']}
    assert lookup_module_0.run(terms_0, variables_0, magic=0, magic_2=0) == []

# Generated at 2022-06-25 10:43:47.887704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    terms_0 = "tests/test.sh"
    variables_0 = {}
    kwargs_0 = {}
    xfail_0 = False
    if (not xfail_0):
        assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == [u'tests/test.sh']
    else:
        try:
            lookup_module_0.run(terms_0, variables_0, **kwargs_0)
        except AnsibleLookupError:
            pass


# Generated at 2022-06-25 10:43:55.443775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    mock_terms = 'lookup_terms'
    mock_variables = 'variables'
    try:
        lookup_module_0.run(mock_terms, mock_variables)
    except AnsibleLookupError:
        # test exception is raised
        pass
    else:
        # The path should be raise error
        assert False, 'Should be raise error'


# Generated at 2022-06-25 10:44:05.389188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # TODO: fix this test
    terms0 = ['/a/b/c', 'd/e/f']
    variables0 = {'ansible_playbook_python': '/usr/bin/python', 'any_errors_fatal': True}
    kwargs0 = {'any_errors_fatal': True}

    # NOTE: it seems that any inline options will take precedence over config in a file?
    # NOTE: this seems wrong as the last term will clobber any config from file or:
    #       - the only real way to 'inline' a dict term is to have a dict term as the last one?
    #       - and the only real use for a dict term would be to override/clobber other settings
    # NOTE: in 'dual' mode (dict term) the

# Generated at 2022-06-25 10:44:16.299628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [{'files':['bar.txt'], 'paths':[]}]
    variables_1 = []

# Generated at 2022-06-25 10:44:19.815375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleLookupError) as ErrorInfo:
        lookup_module_1.run("FirstParam", [])
    assert 'No file was found when using first_found.' in str(ErrorInfo.value)


# Generated at 2022-06-25 10:44:28.142606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(direct={'files': 'observatory.txt', 'paths': './lib'})
    lookup_module_1.run(('red_herring.txt', '../lib/ocean.txt'), {})
    lookup_module_1.set_options(direct={'files': 'observatory.txt', 'paths': './lib'})
    lookup_module_1.run(('red_herring.txt', '../lib/ocean.txt'), {})

# Generated at 2022-06-25 10:44:29.528630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []

# Generated at 2022-06-25 10:44:41.591696
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0 = ['foo']
    global_variables_0 = {u'hostvars': {}, u'skip_ansible_lint': True, u'skip_list': [], u'vars_files': [], u'playbook_dir': u'/etc/fstab'}

    skip_0 = False

    global_variables_1 = global_variables_0

    # have to test what happens if a file is not found
    global_variables_2 = global_variables_1

    # have to make sure that the search path is checked
    global_variables_3 = global_variables_2

    # have to test what happens if a file is not found
    global_variables_4 = global_variables_3

    # have to test what

# Generated at 2022-06-25 10:44:52.814035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # empty params list
    rs = lm.run([], {})
    assert rs == []

    # non empty params list but no files found
    rs = lm.run(['a.txt'], {})
    assert rs == []

    # non empty params list but no files found
    # add a missing file
    rs = lm.run(['a.txt', 'b.txt'], {})
    assert rs == []

    # non empty params list but no files found
    # add a missing file but set skip
    rs = lm.run(['a.txt', 'b.txt'], {}, skip=True)
    assert rs == []

    # non empty params list but no files found
    # add a missing file but set skip

# Generated at 2022-06-25 10:45:03.282801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({u'paths': [u'/home/sashajeltuhin/miniconda3/envs/ansible_tutorial/lib/python3.7/site-packages/ansible-2.8.2-py3.7.egg/ansible/plugins/lookup/files']})
    assert lookup_module_0.run(terms=['apt.yml'], variables=dict()) == [u'/home/sashajeltuhin/miniconda3/envs/ansible_tutorial/lib/python3.7/site-packages/ansible-2.8.2-py3.7.egg/ansible/plugins/lookup/files/apt.yml']

# Generated at 2022-06-25 10:45:07.805765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule
    """
    lookup_module_1 = LookupModule()
    params = {}
    terms = []
    variables = {}
    lookup_module_1.run(terms, variables, **params)


# Generated at 2022-06-25 10:45:18.500553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=None, variables=None, **{'skip': False}) == []
    assert lookup_module_0.run(terms=['tests/unit/lookup_plugins/first_found_data/file1.txt'], variables={'foo': 'bar'}, **{'skip': False}) == ['tests/unit/lookup_plugins/first_found_data/file1.txt']
    assert lookup_module_0.run(terms=['tests/unit/lookup_plugins/first_found_data/file2.txt'], variables={'foo': 'bar'}, **{'skip': False}) == ['tests/unit/lookup_plugins/first_found_data/file2.txt']

# Generated at 2022-06-25 10:45:27.612014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # default case for run()
    params = dict(terms=['/path/to/foo.txt', 'bar.txt'])
    assert lookup_module.run(**params) == ['/path/to/foo.txt']

    # default case for run()
    params.update(
        dict(
             terms=[
                    '/path/to/foo.txt',
                    'bar.txt'
                    ],
             kwargs=dict(
                         files=['/path/to/foo.txt'],
                         paths=['']
                         )
             )
        )
    assert lookup_module.run(**params) == ['/path/to/foo.txt']

    # default case for run()

# Generated at 2022-06-25 10:45:35.898510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test case with params=none and variable.id_lookup_plugins is none
    lookup_module._split_on = _split_on
    lookup_module._templar = None
    lookup_module._variables = None
    lookup_module.set_options = None
    lookup_module.get_option = None
    lookup_module.find_file_in_search_path = None

    try:
        lookup_module.run(None, None)
    except AnsibleLookupError:
        pass

    # test case with params=none and variable.id_lookup_plugins is not none
    lookup_module._split_on = _split_on
    lookup_module._templar = None

# Generated at 2022-06-25 10:45:38.447944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    lookup_module.run('path')

# Generated at 2022-06-25 10:45:44.362032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 10:45:48.160138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Make the arguments
    # test_terms = undefined
    # test_variables = undefined
    # test_kwargs = undefined
    lookup_module._process_terms(test_terms, test_variables, test_kwargs)



# Generated at 2022-06-25 10:45:51.402591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict(paths=['/etc/ansible']))
    lookup_module.run([], dict())

# Generated at 2022-06-25 10:45:57.066237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {'files': ['test_case_0.txt'], 'paths': ['test_case_0.txt', 'test_case_0.txt']}
    variables_0 = object()
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == ['test_case_0.txt']


# Generated at 2022-06-25 10:46:05.404333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test for single path
    lookup_module_0._search_path = ['/etc/ansible/roles/test_role/files']

    assert lookup_module_0.run(['test_file1']) == ['/etc/ansible/roles/test_role/files/test_file1']

    # test for multiple paths
    lookup_module_0._search_path = ['/etc/ansible/roles/test_role/files', '/etc/ansible/roles/test_role/files2']
    assert lookup_module_0.run(['test_file1']) == ['/etc/ansible/roles/test_role/files/test_file1']

    # test for multiple paths with wrong file name
    lookup_module_0._search_path

# Generated at 2022-06-25 10:46:14.381269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # First test case
    # Unsatisfied Assertion: The set of paths to search is not empty.
    total_search = []
    subdir = 'files'
    terms = []
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs) # TypeError: run() takes at least 2 arguments (1 given)

# Generated at 2022-06-25 10:46:17.224989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    # Testing expected exception
    lookup_module_run_0.run([], {})

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:46:26.958918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    search_path = [ "/etc/ansible/host_vars/localhost" ]
    variables = { "hostvars": { "localhost": { 'ansible_loop_var': 'inventory_hostname' } } }

    # Test case with positive input
    # Expects to return a list containing single file path
    terms = [ "/etc/ansible/host_vars/localhost" ]
    path = lookup_module_0.run(terms, variables, search_path=search_path)
    assert len(path) == 1
    assert path[0] == "/etc/ansible/host_vars/localhost"

    # Test case with negative input
    # Expects to raise an exception AnsibleUndefinedVariable
    terms = [ "/etc/ansible/host_vars/localhost" ]

# Generated at 2022-06-25 10:46:36.608531
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:46:37.699964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test case not implemented"


# Generated at 2022-06-25 10:46:45.578316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['hello', 'world']
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)

# Method lookup_run of class LookupModule

# Generated at 2022-06-25 10:46:56.169475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()
    # Create the variable terms which is the parameter for method run of class LookupModule
    var_terms = []
    # Create the variable variables which is the parameter for method run of class LookupModule
    var_variables = {}
    # Invoke method run of class LookupModule and set the result to the variable var_LookupModule_run_0
    var_LookupModule_run_0 = lookup_module.run(var_terms, var_variables)
    # Create the variable expected_result_0 from the file /home/kevin/ansible/ansible/build/temp/_ansible_tmp_22_file_first_found_py.out

# Generated at 2022-06-25 10:47:02.238425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)
    assert len(var_2) == 0


# Generated at 2022-06-25 10:47:05.820991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    var = [ 1, 2, 3 ]
    var_arg = {}
    var_ret_val = lookup.run(var, var_arg)
    assert var_ret_val == [ 1, 2, 3 ], 'Return value of `run` must be [1, 2, 3]'


# Generated at 2022-06-25 10:47:09.145653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)

# Generated at 2022-06-25 10:47:12.469290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    lookup_module_0.run(var_0, var_1)

# test case for run

# Generated at 2022-06-25 10:47:20.350204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    lookup_run = LookupModule.run
    var_0 = []
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)
    assert isinstance(var_2, list)
    assert len(var_2) == 0
    assert isinstance(var_2[0], AnsibleUnsafeText)


# Generated at 2022-06-25 10:47:23.116810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)

# Generated at 2022-06-25 10:47:32.992833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ['/tmp/test', '/tmp/test2']
    lookup_run_0 = ['/tmp/test', '/tmp/test2']
    # ['/tmp/test/test3.txt', '/tmp/test/test4.txt']
    lookup_run_1 = ['/tmp/test/test3.txt', '/tmp/test/test4.txt']
    # [['/tmp/test', '/tmp/test2'], ['/tmp/test/test3.txt', '/tmp/test/test4.txt']]
    lookup_run_2 = [['/tmp/test', '/tmp/test2'], ['/tmp/test/test3.txt', '/tmp/test/test4.txt']]
    # '/tmp/test/test3.txt'
    lookup_run_3 = '/tmp/test/test3.txt'

# Generated at 2022-06-25 10:47:39.580146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Normal case
    var_0 = []
    var_1 = {}
    lookup_module_0 = LookupModule()
    var_2 = lookup_run(var_0, var_1)
    assert var_2 == []
    # Normal case
    var_0 = ["1.txt"]
    var_1 = {}
    lookup_module_0 = LookupModule()
    var_2 = lookup_run(var_0, var_1)
    assert var_2 == ["1.txt"]
    # Normal case
    var_0 = ["1.txt","2.txt"]
    var_1 = {}
    lookup_module_0 = LookupModule()
    var_2 = lookup_run(var_0, var_1)
    assert var_2 == ["1.txt","2.txt"]
    # Normal case

# Generated at 2022-06-25 10:47:46.671680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._subdir = 'foo'
    terms = [{'paths': ['foo', 'bar'], 'files': 'baz', 'skip': True}]
    variables = {'var': 'val'}
    path = lookup_module.find_file_in_search_path(variables, 'foo', 'baz', ignore_missing=True)
    assert lookup_module.run(terms, variables) is not None

# Generated at 2022-06-25 10:47:58.513619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = {'_ansible_no_log': False}
    var_1.update(var_0)
    var_2 = {'extensions': ['.jinja2', '.j2']}
    var_1.update(var_2)
    var_3 = {'files': []}
    var_1.update(var_3)
    var_4 = {'paths': []}
    var_1.update(var_4)
    var_5 = 'files'
    var_6 = ['']
    var_7 = [var_6]
    var_8 = 'paths'
    var_9 = []
    var_10 = {'files': var_6, 'paths': var_9}

# Generated at 2022-06-25 10:48:09.516882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {
        "foo": "/path/to/foo.txt",
        "bar": "bar.txt",
        "biz": "/path/to/biz.txt",
    }
    var_1 = {
        "foo": "/path/to/foo.txt",
        "bar": "/path/to/bar.txt",
    }
    var_2 = {
        "skip": False,
    }
    lookup_module_0 = LookupModule()
    var_3 = {}
    var_4 = lookup_run(var_3, var_0)
    assert var_4 == ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']


# Generated at 2022-06-25 10:48:11.693265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    res = lookup_obj.run(['foo'], 'bar')

    # Fail
    assert res is not None



# Generated at 2022-06-25 10:48:18.582337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  var = {}
  fn = 'test_run_0.txt'
  lookup_module_0 = lookup_module.run(fn, var)
  assert lookup_module_0 == ['/tmp/test_run_0.txt'], 'Expected [\'/tmp/test_run_0.txt\'], but got: %s' % lookup_module_0
  #assert lookup_module_0 == ['/tmp/test_run_0.txt'], 'Expected [\'/tmp/test_run_0.txt\'], but got: %s' % lookup_module_0
  return


# Generated at 2022-06-25 10:48:23.991989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_module_0.run(var_0, var_0)

test_case_0()

# Generated at 2022-06-25 10:48:30.316435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, var_0)
    # assert that the expected exception is raised
    raise AssertionError('No exception raises, expected one')


# Generated at 2022-06-25 10:48:36.714956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run_test_result(expected_result, kwargs):
        obj = LookupModule()
        result = obj.run(**kwargs)
        if result != expected_result:
            raise Exception(result)
            
    # 1 test
    kwargs = { 
        "terms": [],
        "variables": {},
    }
    expected_result = [
        'ansible.cfg',
        "ansible/ansible.cfg",
        "/etc/ansible/ansible.cfg",
        "/etc/ansible/ansible.cfg",
    ]
    run_test_result(expected_result, kwargs)
    
    # 2 test

# Generated at 2022-06-25 10:48:39.450737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = lookup_module_0.run(var_0, var_1, var_2)


# Generated at 2022-06-25 10:48:44.189718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._subdir = 'files'
    test_case_result = lookup_module_1.run([1, 2], 'test')
    assert test_case_result[0] == '1'


# Generated at 2022-06-25 10:48:55.402024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    terms_0 = ["foo"]
    variables_0 = {}
    path_0 = lookup_module_0.run(terms_0, variables_0)
    assert path_0 == [], path_0


# Generated at 2022-06-25 10:49:02.582758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    var_2 = 'LookupBase'
    var_3 = lookup_module_0.run(var_0, var_1, ansible_env=var_2, ansible_loop=var_1, ansible_play_hosts=var_2)

# Generated at 2022-06-25 10:49:11.817748
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    var_2 = 'file2'
    var_3 = {}
    var_4 = {'files': var_2}
    var_5 = 'file1'
    var_6 = {'files': var_5, 'paths': '/tmp/test'}
    var_7 = 'file3'
    var_8 = {'files': 'file3'}
    var_9 = [var_4, var_2, var_6, var_7]
    var_10 = {'files': 'file1', 'paths': '/tmp/test'}
    var_11 = [var_6, var_2, var_10, var_8]

# Generated at 2022-06-25 10:49:15.633019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    terms = list()
    terms.append("foo.conf")
    terms.append("bar.conf")
    terms.append("biz.conf")
    variables = {}
    res = lookup_module_obj.run(terms, variables)


# Generated at 2022-06-25 10:49:17.145778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('**** Unit test for LookupModule.run() ****')

# Make sure that each test has a unique, non-conflicting variable name

# Generated at 2022-06-25 10:49:23.109923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Call run() method of class LookupModule with arguments [list list] and keyword arguments {}.
    lookup_module_0.run([list,list], {})

if __name__ == '__main__':
    test_case_0()
    # Unit testing of class LookupModule is not supported.

# Generated at 2022-06-25 10:49:28.980874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [('a', 'b')]
    variables = {}
    kwargs = {}
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == ['./a', './b']

# Generated at 2022-06-25 10:49:37.298160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_path = '/home/travis/build/ansible/ansible-modules-core/library'
    var_content = '------\n\n'
    var_encoding = 'utf-8'
    name_0 = '/etc/ansible/roles/test_role_0/library/'
    name_1 = 'test_library.py'
    path_0 = os.path.join(var_path, name_0)
    path_1 = os.path.join(path_0, name_1)
    with open(path_1, 'w') as var_file:
        var_file.write(var_content)
    with open(path_1, 'r') as var_file:
        var_content_0 = var_file.read()
    var_file.close()
    var_

# Generated at 2022-06-25 10:49:46.113074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = MagicMock()
    lookup_module_0._templar.template.return_value = 'bar'
    lookup_module_0._find_needle.return_value = 'foo'
    lookup_module_0.find_file_in_search_path = MagicMock()
    lookup_module_0.find_file_in_search_path.return_value = '/foo/bar'
    lookup_module_0._validate_file = MagicMock()
    lookup_module_0._validate_file.return_value = None
    lookup_module_0.set_options = MagicMock()
    lookup_module_0.set_options.return_value = None
    lookup_module_0.get_option = MagicM

# Generated at 2022-06-25 10:49:52.828366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import string_types

    class MockTemplar():
        def __init__(self, arg_0, arg_1=''):  # NOQA
            self.arg_1 = arg_1
            self.arg_0 = arg_0

        def template(self, arg_0):  # NOQA
            self.arg_0 = arg_0
            return self.arg_0

    class MockArgs():
        def __init__(self, arg_0, arg_1=''):  # NOQA
            self.arg_1 = arg_1
            self.arg_0 = arg_0

        def dictcopy(self):  # NOQA
            return self.arg_0



# Generated at 2022-06-25 10:50:00.999379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_0 = {}
    test_case_0()

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-25 10:50:06.396196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_module_0.run('/etc/hosts', var_0)
    assert isinstance(var_1, list)



# Generated at 2022-06-25 10:50:13.259290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    var_0 = {}
    var_1 = {}

# Generated at 2022-06-25 10:50:19.038004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ['/anaconda/ks.cfg', 'foo']
    var_1 = {'files': [], 'paths': []}
    var_2 = {'files': ['/etc/hosts'], 'paths': []}
    var_3 = {'files': ['/etc/hosts', '/etc/resolv.conf'], 'paths': ['/etc', '/etc/default']}
    var_4 = {'files': [], 'paths': ['/etc/default']}
    var_5 = {'files': [], 'paths': ['/etc', '/etc/default']}
    var_6 = {'files': [], 'paths': []}
    var_7 = {'files': [], 'paths': []}

# Generated at 2022-06-25 10:50:27.916225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test Case:
    # Inputs:
    #      * self - LookupModule
    #      * terms - ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    #      * variables - {}
    lookup = LookupModule()
    terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    variables = {}
    lookup._file_find_result = None
    assert(lookup.run(terms, variables) == ['/path/to/foo.txt'])
    lookup._file_find_result = None
    lookup.run(terms, variables)


# Generated at 2022-06-25 10:50:35.916778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = {
        'foo': 'bar'
    }
    var_2 = lookup_module_0.run(var_0, var_1)
    assert isinstance(var_2, list)
    assert var_2 == []

    var_3 = {
        'baz': 'foo'
    }
    var_4 = lookup_module_0.run(var_3, var_1)
    assert var_4 == []

# Generated at 2022-06-25 10:50:41.556402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = {}
    var_2 = lookup_run(var_0, var_0, var_0)


if __name__ == "__main__":
    var_0 = {}

# Generated at 2022-06-25 10:50:45.500511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_module_0.run(var_0, var_0)

# Generated at 2022-06-25 10:50:52.574076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "abcd efgh"
    str_1 = "a,b;c,d;e"
    var_0 = lookup_run(str_0, str_1)
    assert var_0 == ['a,b;c,d;e']


# Generated at 2022-06-25 10:50:54.664152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_module_0.run(var_0, var_0)


# Generated at 2022-06-25 10:51:10.895763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    with raises(AnsibleLookupError):
        lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 10:51:14.603426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_2 = {}
    var_3 = [{'files': ['etc/network/interfaces'], 'paths': ['../../../../../tmp/ansible/file_lookup/jinja2']}]
    var_4 = lookup_run(var_2, var_3)

    assert_equal(var_4, ['../../../../../tmp/ansible/file_lookup/jinja2/etc/network/interfaces'])



# Generated at 2022-06-25 10:51:21.110277
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:51:28.653825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_5['first-found'] = var_6
    var_7 = {}
    var_6['lookup_first_found'] = var_7
    var_8 = {}
    var_7['lookup_plugins'] = var_8
    var_9 = {}
    var_8['lookup'] = var_9
    var_10 = {}
    var_9['lookup'] = var_10
    var_11 = {}
    var_10['lookup'] = var_11
    var_12 = {}
    var_11['lookup'] = var_12
    var_13 = {}

# Generated at 2022-06-25 10:51:38.394153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Generate an instance of the object
    lookup_module = LookupModule()

    # Generate the variables to be used for the test
    terms = ['rtp', 'block', 'update']
    variables = {'lookup_file': 'lookup_file'}

    # Execute the method and fetch the results
    results = lookup_module.run(terms, variables)

    # Generate the expected results
    expected = ['rtp', 'block', 'update']

    # Assert that the two lists are equal
    assert_equals(results, expected)


# Generated at 2022-06-25 10:51:43.244712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Initialize and set 'skip'
    var_0 = {}
    var_0['skip'] = False
    # Call method run of class LookupModule
    var_1 = lookup_module_0.run([], var_0, terms=[])


# Generated at 2022-06-25 10:51:48.419057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = lookup_run(var_0, var_0)


# Generated at 2022-06-25 10:51:49.580629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = {}
    var1 = lookup_module.run(var, var)

# Generated at 2022-06-25 10:52:00.043220
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    files = [
        "/path/to/foo.txt", 
        "bar.txt", 
        "/path/to/biz.txt"
        ]
    paths = [
        "/extra/path"
        ]
    skip = True
    ans_var = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=ans_var, direct={'files': files, 'paths': paths, 'skip': skip})
    var_2 = lookup_module_0.run(terms="", variables=ans_var)
    assert var_2 == []



# Generated at 2022-06-25 10:52:02.790468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_2 = ['file_0']
    var_1 = LookupModule(var_0)
    var_3 = var_1.run(var_2, var_0)


# Generated at 2022-06-25 10:52:26.140384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    try:
        lookup_run(var_0, var_0)
    except AnsibleLookupError as e:
        if str(e) == 'No file was found when using first_found.':
            pass
        else:
            raise AssertionError
    else:
        raise AssertionError

# Generated at 2022-06-25 10:52:28.679859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {}
    var_1 = {}
    var_2 = lookup_run(var_0, var_1)



# Generated at 2022-06-25 10:52:38.489158
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup scenario (test data)
    lookup_module_0 = LookupModule()
    var_0 = [
        'C:/Users/tpatil/ansible-test/test.txt',
        {
            '_terms': 'test.txt'
        }
    ]
    var_1 = {}
    var_2 = {
        'files': 'test.txt',
        'paths': 'C:/Users/tpatil/ansible-test'
    }

    # Execute operation under test
    result = lookup_module_0.run(var_0, var_1, **var_2)

    # Verify (assert) output
    assert result == ['C:/Users/tpatil/ansible-test/test.txt']


# Generated at 2022-06-25 10:52:47.589828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'paths': '', 'files': ''})
    terms_0 = ""
    var_0 = {'total_search': [], 'skip': False}
    lookup_module_0._process_terms(terms_0, var_0, var_0)
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)
    var_0 = {'term': {}, 'variables': {}, 'total_search': [{}], 'skip': False}
    lookup_module_0._process_terms(terms_0, var_0, var_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:52:52.225886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0) == LookupModule
    var_0 = ["a"]
    var_1 = {}
    var_2 = {}
    var_3 = lookup_module_0.run(var_0, var_1, )
    assert var_3 == ["a"]


# Generated at 2022-06-25 10:52:54.312571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {}
    variables_0 = {}
    var_0 = lookup_module_0.run(terms_0, variables_0)
    var_1 = lookup_module_0.run(terms_1, variables_1)
    var_2 = lookup_module_0.run(terms_2, variables_2)


# Generated at 2022-06-25 10:53:04.284149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "5f79c4ffa4b94aa4c4bcf4b77e7ab48d2817d63a"
    dict_0 = {}
    dict_1 = {}
    dict_0["files"] = "cb6d45f0ccbfe6a10e8012b3dea58a17a94c0b14"
    dict_0["paths"] = "961e8b8a9a9f2b1f6c7a8a13d05a34efd167ce86"
    dict_1["files"] = "cb6d45f0ccbfe6a10e8012b3dea58a17a94c0b14"