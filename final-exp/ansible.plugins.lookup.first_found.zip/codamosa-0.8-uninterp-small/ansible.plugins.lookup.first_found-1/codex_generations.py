

# Generated at 2022-06-25 10:43:25.291434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # TODO: mock out self.find_file_in_search_path
    # TODO: test with templating
    # TODO: test passing params as term

    # test var input
    test_terms = ["foo"]
    test_variables = {"foo": "bar"}
    assert lookup_module.run(test_terms, test_variables) == ["foo"]

    # test 'global' skip
    test_terms = ["foo"]
    test_variables = {"foo": "bar"}
    test_kwargs = {"skip": True}
    assert lookup_module.run(test_terms, test_variables, **test_kwargs) == []

    # test 'global' skip false (should be ignored)
    test_terms = ["foo"]

# Generated at 2022-06-25 10:43:30.456638
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    results = []
    results_expected = []

    # unit test 0: test: lookup_module._process_terms(terms, variables, kwargs))
    results_0 = []
    results_expected_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={'files': ['foo'], 'paths': []})
    lookup_module_0.set_options(var_options={}, direct={'files': ['bar'], 'paths': []})
    results_0.append(lookup_module_0.get_option('files'))
    results_expected_0.append(['bar'])
    results_0.append(lookup_module_0.get_option('paths'))
    results_expected_0.append([])


# Generated at 2022-06-25 10:43:34.142477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=None, variables=None, **{}) == []

# Generated at 2022-06-25 10:43:37.907338
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    arg_0_0 = ["/path/to/first", "barename", "/path/to/third"]
    arg_0_1 = {}
    arg_0_2 = {}
    ret_0 = lookup_module_0.run(arg_0_0, arg_0_1, **arg_0_2)
    assert ret_0 is None


# Generated at 2022-06-25 10:43:39.641714
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    variables = {}
    terms = []
    lookup_plugin_kwargs = {"errors": ""}
    assert lookup_module.run(terms, variables, lookup_plugin_kwargs) == [('')]

# Generated at 2022-06-25 10:43:44.384129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._subdir = 'files'
    lookup_module_1._templar = '_templar'
    lookup_module_1._loader = '_loader'
    assert lookup_module_1.run('params', 'variables') == ""

# Generated at 2022-06-25 10:43:49.156414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Correct initialization result
    assert lookup_module != None
    assert lookup_module._subdir == 'files'

    # Initialization incorrect arguments
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(None, None)
    except Exception:
        assert True

    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(list(), list())
    except Exception:
        assert True


# Generated at 2022-06-25 10:43:59.144758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert len(lookup_module.run(terms=[], variables={})) == 0

    assert lookup_module.run(terms=["test"], variables={}) == ['test']
    assert lookup_module.run(terms=["test"], variables={}, paths="") == ['test']
    assert lookup_module.run(terms=["test"], variables={}, paths="/") == ['test']
    assert lookup_module.run(terms=["test"], variables={}, paths=["/"]) == ['test']

    # No files
    assert lookup_module.run(terms=[], variables={}, files=[], paths=[], skip=True) == []
    # Only one file
    assert lookup_module.run(terms=[], variables={}, files=["test"], paths=[], skip=True) == ['test']
    # Same

# Generated at 2022-06-25 10:44:10.902525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    term_0 = [{'paths': [], 'files': []}]
    variables_0 = {}
    assert lookup_module_obj.run(term_0, variables_0) == []

    term_1 = [{'paths': [], 'files': []}]
    variables_1 = None
    assert lookup_module_obj.run(term_1, variables_1) == []

    term_2 = [{'paths': [], 'files': []}]
    variables_2 = {}
    assert lookup_module_obj.run(term_2, variables_2) == []

    term_3 = [{'paths': [], 'files': []}]
    variables_3 = None

# Generated at 2022-06-25 10:44:17.935845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0_i = ['test_case_0_i1_v', 'test_case_0_i2_v']
    test_case_0_vars = {'test_case_0_k1_v': 'test_case_0_v1_v', 'test_case_0_k2_v': 'test_case_0_v2_v'}
    test_case_0_kwargs = {'test_case_0_k3_v': 'test_case_0_v3_v', 'test_case_0_k4_v': 'test_case_0_v4_v'}

# Generated at 2022-06-25 10:44:27.222688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    #method_test_run
    lookup_module_0 = LookupModule()

    tmp = []

    total_search, skip = lookup_module_0._process_terms(tmp, 'variables', 'keyword')
    assert_test(total_search is not None, "unit test 0 FAILED")
    assert_test(skip is not None, "unit test 1 FAILED")
    assert_test(skip is True, "unit test 2 FAILED")

    return


# Generated at 2022-06-25 10:44:29.104175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print (lookup_module.run(terms=[], variables=None, **{'files': 'namespace.txt', 'paths': '.'}))

# Generated at 2022-06-25 10:44:37.218068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files/'
    lookup_module_0.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: fn
    lookup_module_0._templar = lambda t: t
    lookup_module_0.run(terms='foo', variables=None, skip=False)
    lookup_module_0.run(terms='foo', variables=None, skip=True)

# Generated at 2022-06-25 10:44:44.175951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # LookupBase test
    # LookupBase.run()
    assert lookup_module_0.run(['foo', 'bar'], [{'ansible_facts': {}}]) == ['/etc/ansible/files/foo', '/etc/ansible/files/bar']
    assert lookup_module_0.run(['foo'], [{'ansible_facts': {}}]) == ['/etc/ansible/files/foo']
    assert lookup_module_0.run(['foo', 'bar'], [{'ansible_facts': {}}]) == ['/etc/ansible/files/foo', '/etc/ansible/files/bar']

# Generated at 2022-06-25 10:44:48.486911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.run(terms=[], variables=dict(), kwargs=dict())

# run unit tests
# test_case_0()
# test_LookupModule_run()

# Generated at 2022-06-25 10:44:53.758268
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['foo.txt', 'bar.txt'], variables=None) == ['']

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=['foo.txt', 'bar.txt'], variables=None, skip=True) == []
    assert lookup_module_1.run(terms=['foo.txt', 'bar.txt'], skip=True) == []



# Generated at 2022-06-25 10:45:02.049551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "foo"
    variables_0 = {"a" : "b"}
    kwargs_0 = {"files" :  "bar", "paths" :  "biz"}
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except LookupError as exc:
        assert 'No file was found when using first_found.' in str(exc.message)


# Generated at 2022-06-25 10:45:14.948659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [
        {'files': 'foo', 'paths': '/tmp'},
        {'files': 'foo', 'paths': '/tmp'},
    ]


# Generated at 2022-06-25 10:45:19.700409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run(['abcd'], dict(), skip=True) == []
    assert lookup_module_0.run(['abcd'], dict(), skip=True, files=['abcd']) == []

# Generated at 2022-06-25 10:45:20.318712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 10:45:28.884310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

    assert var_0 is None

if __name__ == "__main__":
    pass

# Generated at 2022-06-25 10:45:36.888863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LOOKUP_MODULE_DICT_VAL = {'files': ['foo', 'bar'], 'paths': ['baz', 'baw']}
    LOOKUP_MODULE_LOOKUP_RESULT = ['baz/foo', 'baw/foo', 'baz/bar', 'baw/bar']
    LOOKUP_MODULE_LOOKUP_RESULT_FOUND = 'baw/bar'
    LOOKUP_MODULE_LOOKUP_RESULT_NOT_FOUND = None
    LOOKUP_MODULE_RUN_RESULT = [LOOKUP_MODULE_LOOKUP_RESULT_FOUND]
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:45:45.004218
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:45:57.333472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = {}
    lookup_module_0.set_options(direct=dict({u'files': ''}))
    lookup_module_0.set_options(direct=dict({u'files': ''}))
    path = "files/"
    filename = "test.txt"
    filepath = os.path.join(path, filename)
    open(filepath, 'a').close()
    loopvar = [dict({u'files': u'', u'paths': path}), "test.txt"]
    res = lookup_module_0.run(loopvar, vars, **dict({u'files': ''}))
    assert filepath in res
    os.remove(filepath)

if __name__ == "__main__":
    import doctest
    doctest

# Generated at 2022-06-25 10:46:03.548668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bytes_arg = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_arg = [bytes_arg, bytes_arg, lookup_module]
    var = lookup_run(bytes_arg, list_arg)


# Generated at 2022-06-25 10:46:10.979071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'lookup_hosts':'192.168.1.1'})
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

# Generated at 2022-06-25 10:46:18.376687
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # 1. Create a new instance of lookup module LookupModule, and
  # store it in lookup_module.

  lookup_module = LookupModule()

  # 2. Create a new instance of the class set, and store it in set_0.
  set_0 = set()

  # 3. Store the value  in string_0.
  string_0 = 'baz'
  set_0.add(string_0)

  # 4. Store the value  in string_1.
  string_1 = 'foo'
  set_0.add(string_1)

  # 5. Store the value  in string_2.
  string_2 = 'bar'
  set_0.add(string_2)

  # 6. Create a new instance of the class set, and store it in set_1.
  set_1

# Generated at 2022-06-25 10:46:27.011929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert not lookup_module.run('/f', '/f', paths=['/f'])
    assert lookup_module.run(['', '', '', ''], 'pytest', paths=['pytest', 'ansible'])
    assert not lookup_module.run(['', '', '', ''], 'pytest', paths=['', 'ansible'])
    assert not lookup_module.run(['', '', '', ''], 'pytest', skip=True)
    assert lookup_module.run('/tests/test_lookup_plugin/test_case_0.py', 'pytest', paths=['ansible'])

# Generated at 2022-06-25 10:46:32.208694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params:
    terms = b'\xb7\x0e\x1b\x05\x9b\x88\xd0\x08>'
    variables = b'\x1c\xa4\x9e\x9c\x05\x14\x87\xb1\t'

    # Output params:
    output_params = b'should never have bytes'

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == output_params

# Generated at 2022-06-25 10:46:37.663594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleLookupError):
        LookupModule.run('/etc/resolv.conf')

# Generated at 2022-06-25 10:46:44.956139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = lookup_module_0.run([], [])
    assert int_0 is None



# Generated at 2022-06-25 10:46:51.444925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    var_1 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'

    # test with third parameter
    var_2 = LookupModule()

    # expected value
    list_0 = [var_0, var_1, var_2]

    # create object
    obj_0 = LookupModule()

    # call method
    var_3 = obj_0.run(var_0, list_0)

    assert var_3 == [var_0]

# Generated at 2022-06-25 10:46:53.838978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    user_0 = User()
    # User.run() called with arguments 'player' and '['a', 'b', 'c']'
    user_0.run('player', ['a', 'b', 'c'])

    int_0 = LookupModule()
    int_0.run(['a', 'b', 'c'], ['d', 'e', 'f'])



# Generated at 2022-06-25 10:46:59.998969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

    assert True


# Generated at 2022-06-25 10:47:06.332292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(list_0, bytes_0)


# Generated at 2022-06-25 10:47:12.141063
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Full input parameters
    params = dict(
        terms=[],
        variables=dict(),
    )
    lookup_module = LookupModule()
    result = lookup_module.run(**params)
    assert result == [], "Return value from run is {value}.".format(value=result)

    # No input parameters
    result = lookup_module.run()
    assert result == [], "Return value from run is {value}.".format(value=result)


if __name__ == "__main__":

    test_case_0()

    # Unit tests for LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 10:47:16.335459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == NotImplemented


# Generated at 2022-06-25 10:47:21.783449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, str_0)


# Generated at 2022-06-25 10:47:27.244179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = '\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [str_0, list, lookup_module]
    lookup_module.run('FOO', list_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:47:34.883821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0]
    lookup_module_0 = LookupModule()
    list_1 = [lookup_module_0, lookup_module_0, list_0]
    str_0 = '\x03\x0b\x11\x12\x0f\x0e\x14\x10\x13\x16\x0d\x15\x01\x04\x0c\x0a\x08\x02\x07\x06'
    bool_0 = bool(str_0)
    bool_1 = bool(list_0)

# Generated at 2022-06-25 10:47:45.626793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_1]
    assert lookup_module_1.run(list_0, bytes_0) == None


# Generated at 2022-06-25 10:47:48.690807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

# Generated at 2022-06-25 10:47:53.442434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    int_0 = lookup_module_0.run('foo', [])
    assert(int_0 == 0)


# Generated at 2022-06-25 10:47:58.800940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [1, 2, 3, 4]
    dict_0 = {'_': list_0}
    str_0 = 'dict._'
    dict_1 = {'_': str_0}
    var_0 = lookup_module_0.run(str_0, dict_1)
    var_1 = lookup_module_0.run(dict_0, dict_1)
    var_2 = lookup_module_0.run([dict_0], dict_1)



# Generated at 2022-06-25 10:48:01.173043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1,2]
    variables = [3,4]
    options = {'key': 'value'}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, options)
    assert result == [1,2]



# Generated at 2022-06-25 10:48:07.023007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = [
            ("files", ["files", "files", "files"], dict(files="files", paths="paths"), True)
        ]
    for parameter in parameters:
        assert parameter["expected"] == LookupModule(parameter["parameter"]).run(parameter["terms"], parameter["variables"], parameter["kwargs"])


# Generated at 2022-06-25 10:48:15.808583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0]
    var_0 = lookup_run(bytes_0, list_0)
    assert var_0 == 0

# Generated at 2022-06-25 10:48:25.747043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_legacy_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    bytes_1 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    bytes_2 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'

# Generated at 2022-06-25 10:48:32.644768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    lookup_module.run(b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2')


# Generated at 2022-06-25 10:48:44.658443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_1 = dict()
    dict_0['files'] = 'files_0'
    dict_1['files'] = 'files_1'
    dict_1['paths'] = 'paths_0'
    var_1 = [dict_0, dict_1, dict_0, dict_1]
    dict_1 = dict()
    dict_1['files'] = 'files_0'
    dict_1['paths'] = 'paths_1'
    var_2 = [dict_1, dict_1, dict_0, dict_0]
    var_3 = [var_2, var_1, var_2, var_1]

# Generated at 2022-06-25 10:49:02.782841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    search_strings = ["None", "None", "None"]
    variables = {}
    kwargs = {}

    # Invoke method
    result = lookup_module.run(search_strings, variables, **kwargs)

    # 
    assert result == [], "Expected result to be []"

# Generated at 2022-06-25 10:49:11.820060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0
    dict_0['test'] = dict_0

# Generated at 2022-06-25 10:49:15.632250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x9b\x1b\x1b'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

# Generated at 2022-06-25 10:49:22.915381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for method run representation format
    lookup_run = LookupModule.run
    list_0 = [None]
    var_0 = lookup_run(None, list_0)
    lookup_module_0 = LookupModule()
    list_1 = [None]
    var_1 = lookup_run(None, list_1)
    test_case_0()


# Generated at 2022-06-25 10:49:27.706141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True

if __name__ == "__main__":
    # Unit test for method run of class LookupModule
    test_LookupModule_run()


# Generated at 2022-06-25 10:49:36.358932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

    # check type
    assert type(var_0) is str


# Generated at 2022-06-25 10:49:45.568589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the case where all the parameters are passed

    lookup_module = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module]
    var_0 = lookup_run(bytes_0, list_0)

    # Test the case where all the parameters are not passed

    lookup_module = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'

# Generated at 2022-06-25 10:49:48.132895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert_raises(AnsibleLookupError, LookupModule.run, 'baz', 'bar')
    assert_raises(AnsibleLookupError, LookupModule.run, None, None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:49:52.524988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_8['files'] = lookup_module_1
    dict_8['paths'] = lookup_module_2
    dict_8['skip'] = lookup_module_3
    dict_7['files'] = lookup_module_

# Generated at 2022-06-25 10:50:00.468241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2', b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2', lookup_module_0]
    var_0 = lookup_run(b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2', list_0)
    assert var_0 is None


# Generated at 2022-06-25 10:50:26.918862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['abc'], {}) is not None


# Generated at 2022-06-25 10:50:30.618830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    types = LookupModule()
    types.run(terms=['first_arg', 'second_arg'], variables=['first_arg', 'second_arg'])

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:50:37.999820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)
    assert var_0 == b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'

# Generated at 2022-06-25 10:50:46.006403
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    dict_0 = {}
    dict_1 = {bytes_0: dict_0, bytes_0: list_0}

    # Act
    var_0 = lookup_module_0.run(list_0, dict_1)

    # Assert




# Generated at 2022-06-25 10:50:56.852086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test case with a dict and a simple string input
    # Mock return values for run
    lookup_module_0._templar = mock.MagicMock()
    lookup_module_0._find_needle = mock.MagicMock()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)

    # Test case with simple string inputs
    # Mock return values for run
    lookup_module_0._templar = mock.MagicMock()
    lookup_module

# Generated at 2022-06-25 10:51:00.310933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_module_0.run(list_0, None)


# Generated at 2022-06-25 10:51:03.769027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    int_0 = 0
    input_0 = 0
    list_0 = [lookup_module_1, int_0, input_0]
    lookup_module_1.run(int_0, list_0)

# Generated at 2022-06-25 10:51:13.072229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    # Python 3 compatible unicode string
    str_0 = '\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    var_0 = lookup_module_0.run(list_0, bytes_0)
    assert var_0 == [bytes_0]


# Generated at 2022-06-25 10:51:23.627486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = random.randint(0, 10)
    float_0 = random.uniform(0, 100)
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    bytes_1 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bool_0, bytes_1, lookup_module_0]
    int_1 = random.randint(0, 10)
    float_1 = random.uniform(0, 100)


# Generated at 2022-06-25 10:51:30.388599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2', b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2', lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)
    assert var_0 != None



# Generated at 2022-06-25 10:52:01.401546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)
    assert var_0 == var_0


# Generated at 2022-06-25 10:52:10.431065
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # define the input variables
    l_dir = "/home/johndoe/ansible"
    l_vars = {
        'inventory_dir': '/home/johndoe/ansible/inventory',
        'playbook_dir': '/home/johndoe/ansible/playbooks',
        'play_basedir': '/home/johndoe/ansible/playbooks',
        'role_path': '/home/johndoe/ansible/roles',
        'some_dir': '/home/johndoe/some_dir',
        'ansible_search_dirs': ['/home/johndoe/some_dir'],
    }

# Generated at 2022-06-25 10:52:17.161300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(
        terms=(b'\xb1\x16\x89\xcc\x99\x19\x07\xb5\xcd\xd1\x88\xac\xce\x8b\xc9\x1a\x11\xfd\x01\x19\xe7\x10\x0b\xb9\x9f\x14\x1c\x8d',),
        variables={},
    )


# Generated at 2022-06-25 10:52:27.194382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()
    vars_0 = dict()
    kwargs_0 = dict()
    list_0 = [kwargs_0]
    run_0 = lookup_0.run(list_0, vars_0, **kwargs_0)
    assert run_0 == []
    vars_0 = dict()
    kwargs_0 = {'paths': [], 'files': []}
    list_0 = [kwargs_0]
    run_1 = lookup_0.run(list_0, vars_0, **kwargs_0)
    assert run_1 == []


# Generated at 2022-06-25 10:52:38.631719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'skip': True})
    assert lookup_module.get_option('skip') is True
    assert lookup_module.get_option('files') == []
    lookup_module.run([{'skip': True, 'files': ['foo.txt', 'bar.txt'], 'paths': []}], {}) == []
    lookup_module.run([{'skip': True, 'files': ['foo.txt', 'bar.txt'], 'paths': ['bar.txt', 'foo.txt']}], {}) == []
    lookup_module.run([{'skip': True, 'files': ['foo.txt', 'bar.txt'], 'paths': ['bar.txt', 'foo.txt']}], {}) == []

# Generated at 2022-06-25 10:52:44.863430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x0c\x15"\xb6U\xae\xf6\xe3#\xebQ\xab\xa3\x8b\x95\xd2'
    list_0 = [bytes_0, bytes_0, lookup_module_0]
    var_0 = lookup_run(bytes_0, list_0)


# Generated at 2022-06-25 10:52:52.003915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._subdir = 'files'
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    str_0 = 'files'
    str_1 = 'files'
    list_1 = []
    lookup_module_0.run(list_0, str_0, subdir=str_1)


# Generated at 2022-06-25 10:52:58.951686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(['test.list', 'test.list'], None)
    assert result_1 is not None
    assert type(result_1) == list
    assert result_1 == []


# Generated at 2022-06-25 10:53:00.702311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = list()
    list_0.append(lookup_module_0.run(bytes_0, list_0))


# Generated at 2022-06-25 10:53:03.335105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()