

# Generated at 2022-06-23 11:39:12.163259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.template import Templar
    from ansible.utils.boolean import boolean

    from io import StringIO
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 11:39:19.047725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    module = LookupModule()
    args = [
        'puppet.conf.j2',
        {'files': 'puppet.conf.j2', 'paths': ''},
        'ansible.cfg'
    ]

    # When
    results = module.run(args,'')

    # Then
    assert results is not None
    assert len(results) == 1
    assert 'puppet.conf.j2' in results[0]


# Generated at 2022-06-23 11:39:19.852343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:39:31.120341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display

    lookup_module = LookupModule(Display())

    # test _process_terms() with no terms
    terms, skip = lookup_module._process_terms([], {}, {})
    assert terms == []
    assert skip is False

    # test _process_terms() with terms
    terms, skip = lookup_module._process_terms([
        'files/'
    ], {}, {})
    assert terms == ['files/']
    assert skip is False

    # test _process_terms() with terms
    terms, skip = lookup_module._process_terms([
        {
            'files': 'file1, file2',
            'paths': [
                '/tmp/'
            ]
        }
    ], {}, {})

# Generated at 2022-06-23 11:39:33.776827
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # noinspection PyTypeChecker
    LookupModule(None, None, None)



# Generated at 2022-06-23 11:39:42.831399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['passwd', ['nope', 'nope_again'], {
        'files': ['passwd'],
        'paths': ['/'],
        'skip': False
    }]

    variables = dict()
    module.set_options(var_options=variables, direct={})
    data = module.run(terms, variables)

    assert data[0] == '/passwd'

    module.set_options(var_options=variables, direct={'skip': True})
    data = module.run(terms, variables)

    assert len(data) == 0

    module.set_options(var_options=variables, direct={'skip': False})
    module.set_options(var_options=variables, direct={'paths': []})


# Generated at 2022-06-23 11:39:52.526449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method `run()` of class LookupModule"""
    import pytest
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Initialize Ansible objects
    options = pytest.AnsibleOptions()
    variable_manager = VariableManager()
    inventory = Host(name='localhost', port='22')
    loader = DataLoader()
    inventory._variable_manager = variable_manager
    variable_manager.set_inventory(inventory)

    lookup_name = 'first_found'
    lookup_instance = lookup_loader.get(lookup_name, loader=loader,
                                        templar=None, **options.__dict__)
    # Change the

# Generated at 2022-06-23 11:39:57.454959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = [
        {'files': 'foo', 'paths': 'bar'},
        {'files': 'foo', 'paths': 'bar'}
    ]

    # Expecting error as there are multiple files|paths values
    assert lookup._process_terms(terms, None, None)[0] == None

# Generated at 2022-06-23 11:39:59.533722
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result

# Generated at 2022-06-23 11:40:05.274552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.skip == False
    terms = ['foo', {'files': 'bar.conf', 'paths': '/some/dir'}]
    param = ["files", "bar.conf"]
    assert lookup_plugin._process_terms(terms, param, {}) == (["/some/dir/bar.conf"], False)

# Generated at 2022-06-23 11:40:14.228302
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test basic lookup
    l = LookupModule()
    results = l.run(terms=['doesnotexist1.txt', 'doesnotexist2.txt'], vars={}, **{})
    print(results)
    assert len(results) == 0

    l = LookupModule()
    results = l.run(terms=['doesnotexist1.txt', 'doesnotexist2.txt'], vars={}, **{'skip': True})
    print(results)
    assert len(results) == 0

    # test dict term, notice that dict term is only processed once,
    # so valid path will be ignored
    l = LookupModule()
    results = l.run(terms=[{'files': 'doesnotexist1.txt,doesnotexist2.txt', 'skip': True}], vars={}, **{})


# Generated at 2022-06-23 11:40:23.400374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = 'ansible.plugins.lookup.first_found'
    path = 'fixtures/1'

    class Options():
        def __init__(self):
            self.files = ['foo', 'bar']
            self.paths = ['.']

    options = Options()
    # first file found is a file in the fixture directory 'fixtures/1/foo'
    # Test passing in a dict with a list of strings
    assert LookupModule().run([{'files': options.files, 'paths': options.paths}], {})[0] == os.path.join(path, options.files[0])

    # Test passing in a dict with just a string
    assert LookupModule().run([{'files': options.files[0], 'paths': options.paths}], {})[0] == os.path.join

# Generated at 2022-06-23 11:40:34.633613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import wrap_var

    base = LookupModule()
    base._loader = DictDataLoader({'term_3': "abcd", 'term_4': "efgh"})
    base._templar = DictTemplate()

    # we need _templar and _loader for _process_terms to work

# Generated at 2022-06-23 11:40:43.042594
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_plugin = LookupModule()
  assert lookup_plugin.run([{
    "files": [
      "a.txt",
      "b.txt"
    ],
    "path": [
      "path/file/files"
    ],
    "skip": True
  }, {
    "files": [
      "A.txt",
      "B.txt"
    ],
    "path": [
      "Path/file/files"
    ]
  }], None) == []

# Generated at 2022-06-23 11:40:47.807027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar = FakeTemplar()
    lm._loader = FakeLoader()
    files = ["foo.txt", "bar.txt"]
    firstFound = lm.run(terms=files, variables=None)
    assert firstFound[0] == "foo.txt"

# Fake class to avoid import of Ansible class from template.py

# Generated at 2022-06-23 11:41:00.556045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing first_found options
    # a file is found, return the full path to the file found
    test_term = [{"files": ["bar.txt"], "paths": ["."]}, "bar.txt"]
    current_path = "."
    expected = ["bar.txt"]
    assert LookupModule().run(test_term, {}, current_path) == expected

    # a file is not found, An error is raised
    test_term = [{"files": ["bar.txt"], "paths": ["."]}, "foo.txt"]
    current_path = "."
    expected = LookupError
    assert LookupModule().run(test_term, {}, current_path) == expected

    # a file is not found, return an empty list

# Generated at 2022-06-23 11:41:01.045642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-23 11:41:06.280691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test LookupModule object creation
    lookup = LookupModule()
    # Test that run method returns a list
    assert isinstance(lookup.run([], {}), list)
    # Test that run method returns a value when finding a file
    assert isinstance(lookup.run([{'paths': '/etc/', 'files': 'hosts'}], {}), list)

# Generated at 2022-06-23 11:41:16.980406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = ['file1', 'file2']
    paths = ['path1', 'path2']
    terms = []
    terms.append({'files':files, 'paths':paths})
    paths = ['path3', 'path4']
    files = ['file3', 'file4']
    terms.append({'files':files, 'paths':paths})
    variables = {}
    kwargs = {}

    look = LookupModule()
    total_search, skip = look._process_terms(terms, variables, kwargs)
    assert total_search == ['path1/file1', 'path2/file1', 'path1/file2', 'path2/file2', 'path3/file3',
                            'path4/file3', 'path3/file4', 'path4/file4']

# Generated at 2022-06-23 11:41:19.077877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._subdir = 'files'

# Generated at 2022-06-23 11:41:26.231287
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Check if LookupModule runs as required
    lookup = LookupModule()
    lookup.set_options(var_options={'ansible_virtualization_type': 'docker'})
    lookup.set_options(direct={'files': 'foo.conf', 'paths': '/path/to'})
    assert lookup.get_option('files') == 'foo.conf'
    assert lookup.get_option('paths') == '/path/to'

# Generated at 2022-06-23 11:41:38.142892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test default variables
    assert lookup_module._subdir == 'files'

    # test with no path
    lookup_module._templar = object()
    with pytest.raises(AnsibleLookupError) as exc:
        lookup_module.run(terms=['test_file'], variables={})
    assert "No file was found when using first_found." in str(exc)

    # test with path
    lookup_module._templar = object()
    lookup_module.find_file_in_search_path = lambda var, subdir, term, ignore_missing: '/test/test_file'
    assert lookup_module.run(terms=['test_file'], variables={}) == ['/test/test_file']

    # test with path, creation of pathlist, file

# Generated at 2022-06-23 11:41:46.800126
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    lookup = LookupModule()

    def run_assert(terms, expected=[], **kwargs):
        skip = False
        if 'skip' in kwargs:
            skip = kwargs.get('skip')
        total_search, skip = lookup._process_terms(terms, variable_manager, kwargs)
        assert terms == total_search, "terms: %s - total_search: %s" % (terms, total_search)
        assert skip == kwargs.get('skip')

    run_assert(['a.yaml'])

# Generated at 2022-06-23 11:41:48.598367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: do we want to test that the constructor is doing the right things?
    tmpl = LookupModule()

# Generated at 2022-06-23 11:41:57.908282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    obj.set_loader()

    result = []
    result = obj._process_terms({'files': 'bar', 'paths': 'foo'}, {}, {})
    assert result == (['foo/bar'], False)
    result = obj._process_terms([{'files': 'bar', 'paths': 'foo'}], {}, {})
    assert result == (['foo/bar'], False)
    result = obj._process_terms([{'files': 'bar', 'paths': 'foo', 'skip': True}], {}, {})
    assert result == (['foo/bar'], True)
    result = obj._process_terms([{'files': 'bar', 'paths': 'foo', 'skip': False}], {}, {})

# Generated at 2022-06-23 11:42:09.231004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock some variables for the lookup
    terms = [
        'item1',
        'item2',
        {
            "files": ["file2", "file3"],
            "paths": ["path2", "path3"]
        },
        {
            "files": ["file4", "file5"],
            "paths": ["path4", "path5"]
        },
        {
            "files": ["file6", "file7"],
            "paths": ["path6", "path7"]
        },
    ]
    variables = dict(
        item1="value1",
        item2="value2",
    )
    kwargs = {
        "files": ["file1"],
        "paths": ["path1"],
        "skip": False,
    }

    # Mock the find_file_in_

# Generated at 2022-06-23 11:42:16.900834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    # test on a list of dict
    lookup = LookupModule(loader=loader)
    result = lookup.run([[{'files': ['foo', 'bar'], 'paths': ['/tmp/production', '/tmp/staging']}, {'files': ['baz']}]])
    assert result == [], result

    # test on a list of non-dict
    lookup = LookupModule(loader=loader)
    result = lookup.run([['foo', 'bar'], ['baz']])
    assert result == [], result

    # test on a dict
    lookup = LookupModule(loader=loader)

# Generated at 2022-06-23 11:42:27.104337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a file as term
    lookup = LookupModule()
    lookup.set_options(None, {}, {'files': 'foo', 'paths': '/path1,/path2'})
    total_search, skip = lookup._process_terms(['bar.txt'], {}, {})
    assert ("/path1/bar.txt" in total_search and
            "/path1/foo" in total_search and
            "/path2/bar.txt" in total_search and
            "/path2/foo" in total_search)
    assert (len(total_search) == 4)
    assert (skip == False)

    # Test with a mapping as term
    lookup = LookupModule()

# Generated at 2022-06-23 11:42:38.997992
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case where no file found and skip is True

    # create a path
    test_path = "/etc/ansible/test_data/test_path"

    # create module instance
    lookup = LookupModule()

    # set subdir to test_path so we don't search in actual ansible location
    lookup._subdir = test_path

    # create test terms
    terms = [
        {
            "files": "test_file1.txt",
            "paths": test_path,
            "skip": True
        },
        {
            "files": "test_file2.txt",
            "paths": "/etc/ansible/test_data/test_path"
        }
    ]

    # try to run lookup with the terms defined above
    assert lookup.run(terms) == []

    # Test case where

# Generated at 2022-06-23 11:42:39.381108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:42:40.200528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write this test for first_found
    pass

# Generated at 2022-06-23 11:42:42.483011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-23 11:42:44.332767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: https://github.com/ansible/ansible/issues/59002
    assert 0

# Generated at 2022-06-23 11:42:46.234464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l,LookupModule)

# Generated at 2022-06-23 11:42:57.181446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    # Create a mock templar for handling template path
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.display import Display

    class LookupModuleTest(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()

            display = Display()
            vault = VaultLib(None, None, None, None, None)

# Generated at 2022-06-23 11:43:07.955180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    # getattr needed to mock methods of LookupBase which are dynamically generated
    lm.set_options = getattr(lm, 'set_options')
    # mocked method
    lm.run = getattr(lm, 'run')

    # mocks
    lm.find_file_in_search_path = lambda x, y, z, **kwargs: z
    # to test we need to return the expected search structure
    # however in the actual code it is just fed to find_file_in_search_path
    # thus the mocked method give us the same result
    lm._process_terms = getattr(lm, '_process_terms')

    # tests

# Generated at 2022-06-23 11:43:20.062013
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t.run(terms=[], variables={}) == []
    assert t.run(terms=['testfile.cfg'], variables={}) == []
    assert t.run(terms=['foobar.cfg'], variables={}) == []
    assert t.run(terms=[['testfile.cfg']], variables={}) == []
    assert t.run(terms=['testfile.cfg'], variables={'files': 'testfile.cfg'}) == []
    assert t.run(terms=['foobar.cfg'], variables={'files': 'testfile.cfg'}) == []
    assert t.run(terms=[['testfile.cfg']], variables={'files': 'testfile.cfg'}) == []



# Generated at 2022-06-23 11:43:29.991007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        {'files': 'my-file', 'paths': 'path1,path2'},
        {'files': 'my-file2'},
        'my-file3',
        ['my-file4', 'my-file5'],
    ]

    # TODO: For now, skip the 5th option (should be ['my-file6', 'my-file7']), due to the undefined spliters.
    total_search, skip = lookup._process_terms(terms, [], {})
    assert not skip
    assert len(total_search) == 10
    assert total_search[0] == 'path1/my-file'
    assert total_search[1] == 'path2/my-file'
    assert total_search[2] == 'my-file2'

# Generated at 2022-06-23 11:43:40.032189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Creating an instance of class LookupModule
    LookupModule_instance = LookupModule()
    # For testing, we normally create an instance of class LookupBase, named LookupBase_instance
    LookupBase_instance = LookupBase()
    # Creating an instance of class AnsibleTemplate, named template_instance
    template_instance = AnsibleTemplate()
    # Calling run method of class LookupModule with arguments terms = ['hello', 'world'] and variables = {}
    # Notice that we are also passing the common instance created above as an argument, so that we can refer to it
    # In the run method, we call the find_file_in_search_path_instance method with the argument variables = {}
    # In the find_file_in_search_path_instance method, the method template of class AnsibleTemplate is called
    # with the argument data = '

# Generated at 2022-06-23 11:43:44.219146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._templar = True
    lookup_module._loader = True
    lookup_module._final_state_results = 'woozles'
    lookup_module._basedir = 'woozles'
    lookup_module._display.verbosity = 2
    return lookup_module


# Generated at 2022-06-23 11:43:52.713695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This creates a dummy classs which inherits from the class LookupModule
    class DummyLookupModule(LookupModule):
        def __init__(self, terms, variables, **kwargs):
            super(DummyLookupModule, self).__init__(terms, variables, **kwargs)

        def run(self, terms, variables=None, **kwargs):
            return 'success'

    # This creates a new object of the class LookupModule
    lookup_obj = LookupModule()

    # This creates a new object of the class DummyLookupModule
    dummy_obj = DummyLookupModule(None, None)

    # This checks if the 2 objects are not the same
    assert lookup_obj is not dummy_obj

    # This checks if the 2 classes are not the same

# Generated at 2022-06-23 11:44:01.371675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=no-self-use

    def _test_first_found(terms, paths, module, files, exception_msg=None):
        """Test first found.

        Since this is a class method, we need to setup the module
        before passing it to the lookup.
        """
        lm = LookupModule()
        lm.set_loader(module._loader)   # pylint: disable=protected-access
        lm.set_basedir(module._basedir)
        lm.set_collections_paths(module._collection_paths)
        return lm.run(terms, {}, paths=paths, files=files)


# Generated at 2022-06-23 11:44:05.924729
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule('first_found') is None
    assert not LookupModule('path/to/first_found') is None
    assert not LookupModule('path/to/first_found', load_plugins=False) is None

# Generated at 2022-06-23 11:44:07.015826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' in dir(LookupModule)

# Generated at 2022-06-23 11:44:17.339213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # For cases where no files and paths are given
    terms = [None] # this is actually a task created by, for example: - name: INTERFACES | Create Ansible header for /etc/network/interfaces
    vars = {}
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup.run(terms, vars)
    assert 'No file was found' in str(excinfo.value)
    # For cases where only file names are given, i.e. a total of 2 file names are given
    terms = ['foo', 'bar', 'baz']
    vars = {}
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup.run(terms, vars)

# Generated at 2022-06-23 11:44:26.822497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(direct=dict(first_option='value_of_first_option'))
    # test that the right option is set
    assert l.get_option('first_option')

    if not hasattr(l, '_templar'):
        l._templar = DummyTemplar()
    assert l.run(terms=['/path/to/no/file'], variables={'first_option': 'value_of_first_option'}) == []


# Generated at 2022-06-23 11:44:28.761008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 11:44:39.384848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os, tempfile
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import text_type

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'test_lookup_plugin_first_found_file')

    open(tmpfile, 'w').close()

    l = LookupModule()

    # terms is a dictionary: no such file
    assert l.run({'files': 'does_not_exist'}, dict(searchpath=[tmpdir]), skip=True) == []
    assert l.run({'files': 'does_not_exist'}, dict(searchpath=[tmpdir]), skip=False) == []

    # terms is a list: no such file

# Generated at 2022-06-23 11:44:47.696931
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test no files found
    terms = [
        {
            "files": ['tasks.yaml', 'other_tasks.yaml'],
            "paths": ['/tmp', '/extra/dir'],
            "skip": True
        }
    ]
    lm = LookupModule()
    assert lm.run(terms, {}) == []


    # test file found
    terms = ['hello.txt', 'world.txt', {'files': ['test.txt'], 'paths': ['test_dir']}]
    lm._templar = Templating(MockVars())
    assert lm.run(terms, {}) == ['/tmp/test_dir/test.txt']


    # test error due to no files found

# Generated at 2022-06-23 11:44:48.811520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 11:44:49.943470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()
    assert LookupModule().run

# Generated at 2022-06-23 11:44:51.727751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 11:44:52.598092
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:45:04.094355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule: run

    input:
        - terms:
            - string1
            - string2
            - string3
        - variables:
            - path: /path/to/file
            - other_path: /path/to/other/file

    output:
        - string1
    """
    import os
    import sys

    sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/../../../'))
    from lib.ansible.plugins.lookup.first_found import LookupModule

    def _subdir(self, path, subdir):
        return subdir

    lookup = LookupModule()
    lookup._subdir = _subdir
    lookup._subdir = _subdir
    lookup._loader = None


# Generated at 2022-06-23 11:45:05.184073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:45:15.725961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves.urllib.parse import quote as urlquote
    from ansible.plugins.loader import lookup_loader

    # create 'inline' calls, list of files/paths
    search = [
        'a.txt',
        {'files': 'b.yaml', 'paths': 'p1'},
        {'files': 'b.txt,b.yaml', 'paths': 'p1:p2,p3;p4'},
        ['c.txt', 'd.txt'],
    ]

    # create 'logged' calls, list of files/paths

# Generated at 2022-06-23 11:45:16.876329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule(), 'run')

# Generated at 2022-06-23 11:45:28.370027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test case for LookupModule.run"""
    lookup_plugins_path = "%s/../.." % os.path.dirname(os.path.realpath(__file__))
    ansible_path = os.path.dirname(lookup_plugins_path)
    local_lookup_plugins_path = "%s/lookup_plugins" % ansible_path
    os.sys.path.insert(0, local_lookup_plugins_path)

    from ansible.plugins import module_utils
    module_utils.basic._ANSIBLE_ARGS = None
    from ansible.vars.manager import VariableManager
    vm = VariableManager()

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader(display)

# Generated at 2022-06-23 11:45:31.018942
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule

    :return:
    """
    Lm = LookupModule()
    assert Lm is not None

# Generated at 2022-06-23 11:45:33.076947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 11:45:36.476821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    args = [
        'first_found',
        './tests/files/first_found_files',
        'paths=./tests/files/first_found_paths',
        'files=first_found_file_01,first_found_file_02',
        'skip=True'
    ]
    lookup_mod = LookupModule()
    lookup_mod.run(args, {})
    assert lookup_mod._options['skip'] == True

# Generated at 2022-06-23 11:45:47.496443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing the instance of the LookupModule class
    test_instance = LookupModule()

    # Initializing the variables used in the test_instance.run method
    terms = [
        "path/to/some/file",
        "{{ inventory_hostname }}"
    ]
    variables = {
        "inventory_hostname": "host1"
    }
    kwargs = {
        "files": [
            "foo",
            "bar",
            "baz"
        ],
        "paths": [
            "/tmp",
            "/var",
        ],
        "skip": False
    }

    # Performs a test for the test_instance.run method 
    # Expects a list with a single string as return
    test_result = test_instance.run(terms, variables, **kwargs)
   

# Generated at 2022-06-23 11:45:55.843210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for python 2.6
    if not hasattr(LookupBase, '_get_file_in_search_path'):
        return

    # basic test
    lookup_module = LookupModule()
    lookup_module._subdir = 'files'
    lookup_module._templar = '_templar'
    lookup_module.set_options({
        '_original_path': None,
        '_search_paths': [],
        '_loader': '_loader'
    })

    fake_file1 = os.path.join(os.path.dirname(__file__), 'fixtures', 'fake_file1')
    fake_file2 = os.path.join(os.path.dirname(__file__), 'fixtures', 'fake_file2')
    mocked_file_in_search

# Generated at 2022-06-23 11:45:58.045240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:46:08.623816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import tempfile
    from ansible.module_utils.six import PY3

    # The tests herein basically try the lookup plugin using Ansible 2.5.5,
    # because that is the last version before the module got rewritten by
    # k0ste:
    # https://github.com/ansible/ansible/commit/73d2a7e3e3c95f7d90a0c420b7fcc73e6b409f95
    test_dir = tempfile.mkdtemp()
    file_dir = os.path.join(test_dir, "file_dir")
    file_dir_2 = os.path.join(test_dir, "file_dir_2")
    os.mkdir(file_dir)
    os.mkdir(file_dir_2)

# Generated at 2022-06-23 11:46:09.132577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:46:15.201435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #setup
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 11:46:16.362614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.first_found


# Generated at 2022-06-23 11:46:17.239577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule("")


# Generated at 2022-06-23 11:46:28.726966
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    class DummyLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            self._templar = DummyTemplar()
            self._searchpath = ['files/path/', 'files/path/1/', 'files/path/2/',]
            self._files = ['b.txt', 'd.txt',]

    class DummyTemplar:
        def template(self, source):
            return source

    lookup_module = DummyLookupModule()
    search_path = ['files/path/', 'files/path/1/', 'files/path/2/',]


# Generated at 2022-06-23 11:46:36.270654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    # This unit test is a copy paste of the LookupModule_runUnitTest.
    # It should be modified to test the current implementation
    # instead of the previous implementation.
    #
    # Most of the changes are to make the test more general
    # because the lookup can be called with more than one file.
    #
    # For now the test only verifies that the result of the
    # lookup is a list.
    module = LookupModule()

    # Test a simple file that exists
    files = ['/home/ubuntu/test.txt']
    result = module.run(terms=files, variables=dict())
    assert isinstance(result, list)

    # Test a file that does not exist
    files = ['/home/ubuntu/test1.txt']

# Generated at 2022-06-23 11:46:43.056652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = MockTemplar()

    # test case with file not found
    example1 = [
        {'files': 'foo', 'paths': 'bar'},
        {'files': 'foo', 'paths': 'bar'},
    ]
    assert lookup.run(example1, {}) == []

    # test case with file found
    example2 = [
        {'files': 'foo', 'paths': 'bar/'},
    ]
    assert lookup.run(example2, {}) == ['bar/foo']

    # test case with file found
    example3 = [
        {'files': 'bar/foo', 'paths': 'foo'},
    ]
    assert lookup.run(example3, {}) == ['bar/foo']

    # test case with

# Generated at 2022-06-23 11:46:44.903602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 11:46:52.247774
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()

    options = dict(
        files=[],
        paths=[],
        skip=False,
    )
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variables=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    lookup_instance = lookup_loader.get('first_found')
    lookup_instance.set_options(var_options=variable_manager, direct=options)
    result = lookup_instance.run([], variable_manager)

   

# Generated at 2022-06-23 11:47:04.909645
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 11:47:14.878722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupModule(LookupModule):
        _subdir = 'files'

        def __init__(self, *args, **kwargs):
            self._templar = kwargs.get('templar', None)

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            return fn

        def set_options(self, variables, direct):
            self.files = direct.get('files', [])
            self.paths = direct.get('paths', [])
            self.skip = direct.get('skip', False)

        def get_option(self, opt):
            if opt == 'files':
                return self.files
            return getattr(self, opt, None)

    # Test that terms 'findme' is correctly split

# Generated at 2022-06-23 11:47:27.617186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._lookup_plugin_check_conditional_cache = lambda x: x
    lookup.set_options({
        '_errors': 'ignore',
        '_variables': {},
        '_templar': {},
    })

    assert lookup.run(['/path/to/file'], {}) == ['/path/to/file']
    assert lookup.run(['{{ template }}'], {'template': '/path/to/file'}) == ['/path/to/file']
    assert lookup.run(['{{ template }}', 'default.txt'], {'template': '/path/to/file'}) == ['/path/to/file']

# Generated at 2022-06-23 11:47:28.809669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Generated at 2022-06-23 11:47:38.322996
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    assert lookup._process_terms([], {}, dict(files=['a'], skip=True)) == (['a'], True)

    lookup = LookupModule()
    assert lookup._process_terms(['a'], {}, dict(skip=True)) == (['a'], True)

    lookup = LookupModule()
    assert lookup._process_terms([{'files': ['a'], 'paths': ['b'], 'skip': True}], {}, dict(skip=True)) == (['b/a'], True)

    lookup = LookupModule()
    assert lookup._process_terms([{'files': ['a'], 'paths': ['b', 'c']}], {}, dict(skip=True)) == (['b/a', 'c/a'], True)

    lookup = Lookup

# Generated at 2022-06-23 11:47:40.228327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test
    assert test._subdir == 'files'

# Generated at 2022-06-23 11:47:46.178871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_type = 'first_found'
    lookup = LookupModule(loader=None, templar=None, **dict())
    assert lookup._loader is None
    assert lookup._templar is None
    assert lookup._loader_cache is None
    assert lookup._use_cache is True
    assert lookup._find_file_in_search_path_cache is None
    assert lookup.lookup_type == lookup_type

# Generated at 2022-06-23 11:47:56.963356
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Unit test: non existing file
    assert lookup_module.run(terms=["./ansible/plugins/lib/ansible/plugins/lookup/tests/file_not_exist.conf"], variables={}) is None

    # TODO: make file name as parameter of method test
    #       so that we can use always the same file for unit tests
    #       instead of making a new file for each unit test
    with open('file_with_content.txt', 'w') as file_with_content:
        file_with_content.write("Hello world")

    with open('file_empty.txt', 'w') as file_empty:
        file_empty.write("")

    # Unit test: existing file

# Generated at 2022-06-23 11:48:06.411065
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a terms list to use
    terms = [
        'play1/dir1/file1.txt',
        'play1/dir1/file2.txt',
        'play1/dir1/file3.txt',
        {'files': 'file1.txt, file2.txt', 'paths': 'play2/dir2, play2/dir3'},
        'play1/dir1/file4.txt',
        'file5.txt',
        {'files': 'file6.txt, file7.txt', 'paths': 'play2/dir2'},
        'file8.txt',
    ]

    # create the lookup object and run it against the test terms
    lm = LookupModule()

# Generated at 2022-06-23 11:48:08.064157
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule()) == LookupModule


# Generated at 2022-06-23 11:48:20.414230
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:48:26.449863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    search = ['a', 'b', 'c']
    terms = ['d', 'e']
    expected = [('a', 'd'),
                ('b', 'd'),
                ('c', 'd'),
                ('a', 'e'),
                ('b', 'e'),
                ('c', 'e'),]
    found = []
    for t in terms:
        for s in search:
            found.append((s, t))
    terms = lu.run(terms=terms, variables={}, files='a', paths='b', skip=False)
    assert terms == found



# Generated at 2022-06-23 11:48:37.625800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [
        "../data/file1.txt",
        "../data/file2.txt",
    ]

    # Returns the full path to the first combination found.
    path = lookup.run(terms, variables={}, perms_mode=744, follow=True)
    assert "../data/file1.txt" == path[0]

    terms = [
        {"files": "../data/file1.txt"},
        {"files": "../data/file2.txt"},
    ]

    # Returns the full path to the first combination found.
    path = lookup.run(terms, variables={}, perms_mode=744, follow=True)
    assert "../data/file1.txt" == path[0]


# Generated at 2022-06-23 11:48:49.147898
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar

    from ansible.module_utils._text import to_bytes

    # setup lookup module instance
    L = LookupModule()
    L.set_options(var_options={'test': to_bytes("{{ 'test/test' }}")}, direct=dict(paths=["{{ test }}"]))

    # setup required arguments for method run
    terms = ['bar.txt', 'foo.txt']

    # call the run method and store the result in returned_value
    returned_value = L.run(terms, None)

    # assert the returned value is correct
    assert returned_value == ["test/test/bar.txt"]

    # setup lookup module instance
    L = LookupModule()

# Generated at 2022-06-23 11:48:59.406332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.errors import AnsibleLookupError

    File = namedtuple('File', ['name', 'size', 'uid', 'gid', 'mode', 'atime', 'mtime', 'ctime'])
    file = File('file', 0, 0, 0, 0, 0, 0, 0)
    file_path = '/tmp/test/' + file.name

    # Mock AnsibleVaultEncryptedUnicode
    class VaultUnicode:
        def __init__(self, value):
            self.vault_text = value
        def __repr__(self):
            return self.vault_text
        def __str__(self):
            return self.vault_text
        def _get_decrypted(self):
            return self.vault_text


# Generated at 2022-06-23 11:49:09.205644
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert not LookupModule.run([], dict())
    assert not LookupModule.run(None, dict())
    assert not LookupModule.run(None, {}, files=None)

    test_terms = [
        dict(files=['file1', 'file2'], paths=['test_path'], skip=False),
        dict(files=['file1', 'file2'], skip=False),
    ]
    assert len(LookupModule.run(test_terms, dict())) == 0

    test_terms = [
        dict(files=['file1', 'file2'], paths=['test_path'], skip=True),
        dict(files=['file1', 'file2'], skip=True),
    ]
    assert len(LookupModule.run(test_terms, dict())) == 0
