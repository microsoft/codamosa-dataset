

# Generated at 2022-06-23 11:39:02.891490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lu._subdir = 'files'
    lu._templar = None
    result = lu.run([{'files': 'foo', 'paths': 'path'}], {})
    assert result == []


# Generated at 2022-06-23 11:39:08.736421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.get_option('files') is None
    assert lookup_plugin.get_option('paths') is None
    lookup_plugin = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert lookup_plugin.get_option('files') is None
    assert lookup_plugin.get_option('paths') is None

# Generated at 2022-06-23 11:39:10.222940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

LookupModule._run = test_LookupModule_run

# Generated at 2022-06-23 11:39:11.434021
# Unit test for constructor of class LookupModule
def test_LookupModule():

    m = LookupModule(None)
    assert isinstance(m, LookupModule)

# Generated at 2022-06-23 11:39:13.651390
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 11:39:15.056228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test constructor initialization
    """
    assert not LookupModule()

# Generated at 2022-06-23 11:39:18.777959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options()
    assert lookup._terms is None
    assert lookup._variables is None
    assert lookup._loader is None
    assert lookup._templar is None


# Generated at 2022-06-23 11:39:30.176510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TEST-1
    lookup_plugin = LookupModule()
    files = ["/path/1","/path/2"]
    paths = ["/foo","/bar"]
    dict_vars = dict(files=files,paths=paths)
    terms = [dict_vars]
    total_search,skip = lookup_plugin._process_terms(terms,None,None)
    assert skip == False
    assert total_search == ["/foo/path/1", "/foo/path/2", "/bar/path/1", "/bar/path/2"]
    # TEST-2
    lookup_plugin = LookupModule()
    files = ["/path/1"]
    paths = []
    dict_vars = dict(files=files,paths=paths,skip=True)
    terms = [dict_vars]


# Generated at 2022-06-23 11:39:36.432499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()

    # Test for LookupBase's constructor
    with pytest.raises(AnsibleLookupError) as lookup_err:
        test_lookup.run([''])

    assert 'Must define at least one file in first_found lookup' in str(lookup_err.value)



# Generated at 2022-06-23 11:39:37.854979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()


# Generated at 2022-06-23 11:39:39.486872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)


# Generated at 2022-06-23 11:39:46.949296
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # test set_options method
    # test cases to cover variable undefined and subdir/files/paths missing
    # when term is a string
    term = "subdir/filename"
    lm.run(term)
    assert lm._subdir == 'subdir'
    term = "/subdir/subsubdir/filename"
    lm.run(term)
    assert lm._subdir == 'subsubdir'
    term = "subdir/subsubdir/filename"
    lm.run(term)
    assert lm._subdir == 'subsubdir'
    # when term is a list
    term = ["subdir/subsubdir/filename"]
    lm.run(term)
    assert lm._subdir == 'subsubdir'
    # when term is

# Generated at 2022-06-23 11:39:48.997724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:39:50.273701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert str(LookupModule()) == LookupModule.__doc__

# Generated at 2022-06-23 11:40:00.703865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_native

    # env['ANSIBLE_LOOKUP_PLUGINS'] = os.path.abspath(os.path.join(os.path.dirname(__file__), '../lookup_plugins'))

    lookup_mod = LookupModule()

    assert lookup_mod.run([['a.txt']], dict(foo='bar')) == [to_bytes('/etc/ansible/files/a.txt')]
    assert lookup_mod.run([{'files': 'a.txt'}], dict(foo='bar')) == [to_bytes('/etc/ansible/files/a.txt')]

# Generated at 2022-06-23 11:40:11.335582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, sources=[])
    play_source = dict(
        name="test",
        hosts="test",
        gather_facts="test",
        tasks=[
            dict(name="test", first_found=dict(files=["/tmp/test"]))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    variable_manager.set_inventory(inventory)

    ret = play.tasks[0].args["first_found"]

# Generated at 2022-06-23 11:40:15.474736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as loader
    loader.add_directory(os.path.join(os.getcwd(), 'lib'))
    lookup = loader.get('lookup', 'first_found')
    assert type(lookup) == LookupModule

# Generated at 2022-06-23 11:40:17.184998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule('first_found', {}, {}, {}, None)
    assert len(lookup) == 1

# Generated at 2022-06-23 11:40:30.244991
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys

    # Check if ansible version is >= 2.6
    if sys.version_info[0] == 2 and sys.version_info[1] <= 5:
        return

    lm = LookupModule()

    # Test if generating file list and sub list if the file name is a dict
    # and list is fine
    assert(lm._process_terms(
        ['hello.txt',
         {'files': 'foo.txt', 'paths': 'world.txt'},
         'list'], None, {}) ==
        (['./hello.txt', './foo.txt', './world.txt', 'list'], False))

    # Test if handling if the file name is a dict and list in dict is fine

# Generated at 2022-06-23 11:40:30.998882
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:40:33.118538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    # Test that LookupModule instance is of type LookupBase
    assert isinstance(foo, LookupBase)

# Generated at 2022-06-23 11:40:36.370862
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Input
    lookup_module = LookupModule()
    # Expected
    expected = "first_found"
    # Actual
    actual = lookup_module.PLUGIN_NAME
    # Assertion
    assert expected == actual

# Generated at 2022-06-23 11:40:42.216763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the object constructor
    lookup_plugin = LookupModule()

    # Test __new__
    assert lookup_plugin

    # Test __init__
    assert not hasattr(lookup_plugin, 'set_options')
    assert not hasattr(lookup_plugin, 'get_option')


# Generated at 2022-06-23 11:40:50.242567
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _replace_lookup(self, term):
        return ''

    # Monkey patch this function as it calls LookupModule
    LookupBase._replace_lookup = _replace_lookup

    # Test with string as term
    terms = 'test'
    kwargs = {
        'files': '',
        'paths': '',
        'skip': False,
    }

    # Mock the template method of the templar class
    variables = {
        'ansible_virtualization_type': '',
        'ansible_distribution': '',
        'ansible_os_family': '',
    }

    literal_lookup = LookupModule()
    result = literal_lookup.run(terms, variables, **kwargs)
    assert result == []

    # Test with list as term

# Generated at 2022-06-23 11:41:01.816226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = []
    terms.append("a")
    terms.append("b")
    terms.append("c")
    variables = {}
    kwargs = {}
    kwargs['files'] = ["a", "b", "c"]
    assert lookup_module.run(terms, variables, **kwargs) == ['a', 'b', 'c']
    terms[0] = {"files": ["a", "b", "c"]}
    assert lookup_module.run(terms, variables, **kwargs) == ['a', 'b', 'c']
    terms[0] = {"files": ["a", "b", "c"], "skip": True}
    assert lookup_module.run(terms, variables, **kwargs) == ['a', 'b', 'c']

testLookupModule

# Generated at 2022-06-23 11:41:13.246220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: some of the tests are done with a 'current working dir'
    #       that is not the default one, as the search path includes it too.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar


# Generated at 2022-06-23 11:41:17.615172
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    """
    Test for method run of class LookupModule.
    """

    # TODO:
    #  - mocking of self.find_file_in_search_path(variables, subdir, fn, ignore_missing=True)
    #  - mocking of self._templar.template(fn)
    #  - mocking of self.set_options(var_options=variables, direct=kwargs)
    assert test_LookupModule_run()


# Generated at 2022-06-23 11:41:18.768890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:41:29.779192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' test run method of class LookupModule '''

    from ansible.module_utils.six.moves import builtins
    builtins.open = open

    lookup_module = LookupModule()

    # Test all validations

    # Test case when terms is an instance of dict
    terms = {"files": "/tmp/a.file", "paths": "/tmp"}
    variables = {}
    ret = lookup_module.run(terms, variables)
    assert ret == ['/tmp/a.file']

    # Test case when terms is a valid path
    terms = "/tmp/a.file"
    variables = {}
    ret = lookup_module.run(terms, variables)
    assert ret == ['/tmp/a.file']

    # Test case when terms is a list of valid paths

# Generated at 2022-06-23 11:41:33.871536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subdir = 'files'
    term = ['foo', 'bar']
    terms = [term, term]
    variables = {}
    kwargs = {}
    total_search, skip = LookupModule()._process_terms(terms, variables, kwargs)
    assert(isinstance(total_search, list) and len(total_search) == 4)
    assert(skip == False)

# Generated at 2022-06-23 11:41:35.027573
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 11:41:41.059332
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_instance = LookupModule()
    lookup_module_instance._loader = 'fake_loader'
    lookup_module_instance._templar = 'fake_templar'
    lookup_module_instance.set_options(direct={'files': ['file1', 'file2'], 'paths': ['path1']})

    lookup_module_instance.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: fn
    assert lookup_module_instance.run([], variables={}) == ['file1']

    lookup_module_instance.set_options(direct={'files': ['file1'], 'paths': []})
    lookup_module_instance.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None

# Generated at 2022-06-23 11:41:47.672481
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    klass = LookupModule()
    # mocks
    klass._templar = object()
    klass._templar.template = lambda x: x
    klass.find_file_in_search_path = lambda *args: True

    # test
    assert klass.run(["foo"]) == ["foo"]
    assert klass.run([{'files': "foo"}]) == ["foo"]
    assert klass.run([{'files': "foo"}, {'files': "bar"}]) == ["bar"]



# Generated at 2022-06-23 11:41:49.247680
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookup = LookupModule()
    assert(myLookup)



# Generated at 2022-06-23 11:41:50.957078
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 11:41:52.832748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:42:03.842183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = "subdir"
    l._loader = 'loader'
    l.basedir = "/basedir"

    # First-level integration test
    l._templar = 'templar'
    l.find_file_in_search_path = 'find_file_in_search_path'
    l._templar.template = lambda x: x
    l.find_file_in_search_path.return_value = "/file"

    terms = [
        {"files": "a", "paths": "b"},
        {"files": "c", "paths": "d"},
    ]
    variables = "variables"
    kwargs = "kwargs"

    assert ['/file'] == l.run(terms, variables, **kwargs)

# Generated at 2022-06-23 11:42:12.457525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    vars = {}
    kwargs = {}

    lookup_module._process_terms(
        [{'files': 'file1,file2', 'paths': '/path1:/path2'}],
        vars, kwargs)
    assert lookup_module._search_path[-2] == '/path1'
    assert lookup_module._search_path[-1] == '/path2'
    assert lookup_module._search_files[-2] == 'file1'
    assert lookup_module._search_files[-1] == 'file2'

    lookup_module._process_terms(
        [{'files': 'file1,file2', 'paths': ['/path1', '/path2']}],
        vars, kwargs)
    assert lookup_module._

# Generated at 2022-06-23 11:42:23.004584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # Test if constructor set up initial attributes correctly
    assert l.set_options(var_options={}, direct={})
    test_dict = {"a":1}
    assert l.get_option("a") == test_dict["a"]
    assert l.get_option("b", "default-value") == "default-value"
    assert l._templar == l._loader.get_basedir()
    assert l._loader.get_basedir() == l._loader.path_dwim("./")
    assert l.find_file_in_search_path({"_original_file": "some-file"}, "", "some-file") == "some-file"

# Generated at 2022-06-23 11:42:33.750793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{
        'files': 'alice, bob',
        'paths': 'foo.txt, bar.txt'
    }, {
        'files': 'main.yaml, main.json',
        'paths': 'conf.d'
    }]

    variables = {}
    kwargs = {}

    myobj = LookupModule()
    myobj._subdir = 'files'
    total_search, skip = myobj._process_terms(terms, variables, kwargs)

    assert total_search == ['foo.txt/alice', 'bar.txt/alice', 'foo.txt/bob', 'bar.txt/bob',
                            'conf.d/main.yaml', 'conf.d/main.json']
    assert skip is False


# Generated at 2022-06-23 11:42:41.486186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # set up parameters
    params = {'files': 'test_find.yml', 'paths': '/home/federicot'}
    lm = LookupModule(None)
    assert lm.get_option('files') == []
    assert lm.get_option('paths') == []

    lm.set_options(direct=params)
    assert lm.get_option('files') == ['test_find.yml']
    assert lm.get_option('paths') == ['/home/federicot']

# Generated at 2022-06-23 11:42:46.127675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        "foo.txt",
        "bar.txt",
        "biz.txt"
    ]
    lm = LookupModule()
    paths, skip = lm._process_terms(terms, None, None)
    assert skip == False
    assert len(paths) == 3

# Generated at 2022-06-23 11:42:57.112125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of class LookupModule
    LookupModule_instance = LookupModule()
    # set private variable _subdir
    LookupModule_instance._subdir = 'files'

    # create an instance of class AnsibleUndefinedVariable
    AnsibleUndefinedVariable_instance = AnsibleUndefinedVariable('')

    # replace method find_file_in_search_path with mock
    original_ansible_find_file_in_search_path = LookupModule_instance.find_file_in_search_path
    def mock_ansible_find_file_in_search_path(variables, subdir, fn, ignore_missing):
        if fn == '/path/to/bar.txt':
            return fn

# Generated at 2022-06-23 11:43:07.920189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No file found
    lm = LookupModule()
    assert lm.run(terms=['test.yml'], variables={}, skip=False) == None
    assert lm.run(terms=['test.yml'], variables={}, skip=True) == []

    # One file found
    lm = LookupModule()
    lm._loader.path_dwim_rel_paths = {}
    lm._loader.path_dwim_rel_paths['files/'] = ['/dir1', '/dir2/dir3']
    assert lm.run(terms=['test.yml'], variables={}, skip=False) == ['/dir1/test.yml']

# Generated at 2022-06-23 11:43:20.949778
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    os.environ['ANSIBLE_CONFIG'] = '/dev/null'
    os.environ['ANSIBLE_CONFIG_FILE'] = '/dev/null'

    from ansible import context
    context.CLIARGS = {'module_path': ['/dev/null'], 'module_language': 'python'}

    # Import the class to test
    from ansible.plugins.lookup.first_found import LookupModule

    # Intantiate the class
    lookup = LookupModule()

    # Get a list of fake arguments
    terms = [
        {
            'files': 'foo, bar',
            'paths': '/tmp/production, /tmp/staging',
        }
    ]

    # Intantiate a fake ansible variables dictionary

# Generated at 2022-06-23 11:43:30.514094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run(['test_run'], {}, files=[], paths=[])
    assert lookup.run([], {}, files=[], paths=[])

    try:
        lookup.run(['test_run'], {}, files=[], paths=[])
        assert False
    except Exception as e:
        assert str(e) == "No file was found when using first_found."

    assert lookup.run([{'files': [], 'paths': []}], {}, files=[], paths=[])
    assert lookup.run([{'files': [], 'paths': []}], {}, files=[], paths=[], skip=True)

# Generated at 2022-06-23 11:43:40.466244
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    # test variable _subdir
    lookup._subdir = 'test_subdir'
    assert lookup._subdir == 'test_subdir'

    # test variable _templar
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    from ansible.executor.task_queue_manager import TaskQueueManager

    import jinja2

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources="localhost,")
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()
    play_

# Generated at 2022-06-23 11:43:49.152598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run(
        [{'files': ['a.txt', 'b.txt'], 'paths': ['abc', 'def'], 'skip': False}],
        dict()
    ) == [os.path.join('abc', 'a.txt'), os.path.join('abc', 'b.txt'), os.path.join('def', 'a.txt'), os.path.join('def', 'b.txt')]
    assert LookupModule(None, None).run(
        [{'files': ['a.txt', 'b.txt'], 'paths': ['abc', 'def'], 'skip': True}],
        dict()
    ) == []

# Generated at 2022-06-23 11:43:57.792458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest.mock import MagicMock

    kwargs_dict = {'skip': False, '_jid': '123'}
    terms_list = ['lookup_test_file.txt']
    variables = {}
    looker = LookupModule()
    looker._templar = MagicMock()
    looker._templar.template = MagicMock(return_value='lookup_test_file.txt')
    looker.find_file_in_search_path = MagicMock(return_value='/root/lookup_test_file.txt')
    result = looker.run(terms_list, variables, **kwargs_dict)
    assert result == ['/root/lookup_test_file.txt']



# Generated at 2022-06-23 11:43:59.250683
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm._templar is not None
    assert lm._loader is not None

# Generated at 2022-06-23 11:44:03.304017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(remote_user='root')

    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:44:04.920997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup)


# Generated at 2022-06-23 11:44:06.489390
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create object of class lookupModule
    lookup = LookupModule()

# Generated at 2022-06-23 11:44:15.229074
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking
    args = ['src.rst']
    variables = {'_terms': ['../files/first_found.rst']}
    kwargs = {'files': ['../files/first_found.rst'],
              'paths': ['../files/first_found.rst'],
              'skip': False}

    # Initializing
    lookup = LookupModule()
    lookup.set_options(var_options=variables, direct=kwargs)

    # Executing
    result = lookup.run(args, variables, **kwargs)

    # Asserting
    assert result == ['../files/first_found.rst']

# Generated at 2022-06-23 11:44:16.826625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 11:44:18.849317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:44:31.166794
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _run(terms, search_path=None, **kwargs):

        # FIXME: This is a hack to get the unittest framework to run these tests
        #        in the ansible package context.
        from ansible.plugins.lookup.first_found import LookupModule
        l = LookupModule()
        l._get_search_paths = lambda: search_path or list()
        return l.run(terms, dict(), **kwargs)

    def _run_vars(terms, search_path=None, var_dir=None):

        # FIXME: This is a hack to get the unittest framework to run these tests
        #        in the ansible package context.
        from ansible.plugins.lookup.first_found import LookupModule
        l = LookupModule()


# Generated at 2022-06-23 11:44:33.348123
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    if lookup_plugin is None:
        raise Exception("Failed to create class LookupModule")

# Generated at 2022-06-23 11:44:37.677192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    runner = RunnerMock()
    lk = LookupModule(runner=runner)
    terms = ['first_found_example.txt', 'localhost.txt']
    variables = {'inventory_hostname': 'localhost'}
    result = lk.run(terms, variables)

    assert result == ['localhost.txt'], result

# Generated at 2022-06-23 11:44:46.312980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # vars, options
    vars = {}
    options = {'files': ['file1', 'file2'], 'paths': []}
    params = [options]
    terms = [params]
    lu = LookupModule()
    lu._loader.path_exists.return_value = False
    assert lu.run(terms=terms, variables=vars) == [], "Should return empty list when file does not exist"

    terms = ['file1']
    lu._loader.path_exists.return_value = True
    lu._loader.is_file.return_value = True
    lu._loader.find_file_in_search_path.return_value = 'file1'

# Generated at 2022-06-23 11:44:58.736390
# Unit test for constructor of class LookupModule
def test_LookupModule():

    options = {}
    options["files"] = ["file1"]
    options["paths"] = ["path1"]

    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    lookup_module.set_options(var_options=None, direct=options)

    assert lookup_module.get_option('files') == options["files"]
    assert lookup_module.get_option('paths') == options["paths"]

    # Test filelist creation
    files = "file1, file2"
    values = _split_on(files)
    assert len(values) == 2
    assert values[0] == "file1"
    assert values[1] == "file2"

    files = "file1:file2"
    values = _split_on(files)
   

# Generated at 2022-06-23 11:45:07.009640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test.set_options({'paths': ['/etc/ansible']})
    a = ['/usr/local/bin/ansible-playbook', '/etc/ansible/ansible.cfg', '/etc/ansible/hosts']
    test._subdir = 'files'
    test._loader = 'files'
    test.set_loader(test._loader)
    test._templar = 'files'
    test.set_templar(test._templar)

    test.run(terms=a, variables={'role_path': ['/etc/ansible/playbooks']})

# Generated at 2022-06-23 11:45:08.437729
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a._subdir is None

# Generated at 2022-06-23 11:45:20.748857
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()
    lookup_plugin._subdir = 'files'

    # Test with missing file
    with pytest.raises(AnsibleLookupError) as error:
        assert lookup_plugin.run(terms=['non_existent_file'], variables={})
    assert str(error.value) == 'No file was found when using first_found.'

    # Test with existing file
    assert lookup_plugin.run(terms=['README.md'], variables={}) == ['/home/ansible/ansible/lib/ansible/plugins/lookup/README.md']

    # Test with missing file and skip
    assert lookup_plugin.run(terms=['non_existent_file'], variables={}, skip=True) == []

    # Test with existing file in a subdir

# Generated at 2022-06-23 11:45:31.152825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with dict, list and some combination
    lookup = LookupModule()
    list_terms = ["first_file.txt", "second_file.txt", ["third_file.txt", "fourth_file.txt"]]
    dict_terms = [{'files': 'first_file.txt'}]
    list_terms_dict = ["first_file.txt", "second_file.txt", {"files": "third_file.txt"}]
    dict_terms_list = [{'files': 'first_file.txt'}, "second_file.txt"]
    dict_list_list = [{'files': 'first_file.txt', 'paths': '/first/path'}, "second_file.txt"]
    # Any term of dict should be the same

# Generated at 2022-06-23 11:45:32.241142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()


# Generated at 2022-06-23 11:45:44.060020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the LookupModule
    lm = LookupModule()
    # Set the subdir and path
    lm._subdir = 'files'
    lm.path = ['test/test1', 'test/test2']
    # Set the term
    term = 'test_test4_1.txt'
    # Set the variables
    variables = {}
    # Call method run
    try:
        lm.run(term, variables)
    except AnsibleLookupError:
        pass
    else:
        assert False

    # Set the term
    term = 'test.txt'
    # Call method run
    lm.run(term, variables)
    # Set the term
    term = 'test_test4.txt'
    # Call method run
    lm.run(term, variables)

# Generated at 2022-06-23 11:45:53.279508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Tests for LookupModule::run"""
    class MockTemplar:
        def __init__(self):
            self.template_errors = []
        def template(self, value):
            if value.startswith('template_error:'):
                raise AnsibleUndefinedVariable() # or UndefinedError for jinja2
            return value

    class MockSearchPathDict(Mapping):
        def __init__(self):
            self._list = []
        def __getitem__(self, key):
            return self._list
        def __setitem__(self, key, value):
            self._list.extend(value)
        def __iter__(self):
            for i in self._list:
                yield i
        def __len__(self):
            return len(self._list)

    # Default values

# Generated at 2022-06-23 11:46:01.531833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # _process_terms tests
    lookup = LookupModule()
    result = lookup._process_terms(['foo'], variables={}, kwargs={})
    assert result == ([], False)

    result = lookup._process_terms(['foo', 'bar'], variables={}, kwargs={})
    assert result == ([], False)

    result = lookup._process_terms(['foo.bar'], variables={}, kwargs={})
    assert result == ([], False)

    result = lookup._process_terms(['foo.bar'], variables={}, kwargs={'files': ['foo.bar']})
    assert result == ([], False)

    result = lookup._process_terms(['foo.bar'], variables={}, kwargs={'files': ['foo.bar'], 'paths': ['baz']})
    assert result

# Generated at 2022-06-23 11:46:10.966062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    test_terms = u'first-file.yml'
    test_term_dict = {'files': 'first-file.yml'}
    test_term_dict_with_path = {'files': 'first-file.yml', 'paths': '/tmp/directory/'}

    # Method run returns a list
    assert isinstance(LookupModule().run(test_terms, dict()), list)

    # Method run returns the file path of a file if provided
    assert LookupModule().run(test_terms, dict())[0] == u'/tmp/directory/first-file.yml'

    # Method run returns the file path of a file if provided in a dict

# Generated at 2022-06-23 11:46:17.634527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #   creating a LookupModule instance
    lkm = LookupModule()
    #   creating a terms list
    terms = [{'files':'file1', 'paths':'path1'},{'files':'file2', 'paths':'path2'}]
    #   creating a kwargs dictionary
    kwargs = {}
    #   creating a variables dictionary
    variables = {}
    #   calling the run method of class LookupModule
    lkm.run(terms,variables,**kwargs)

# Generated at 2022-06-23 11:46:19.455944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None

# Generated at 2022-06-23 11:46:21.158433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-23 11:46:31.608122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # When first_found lookup is called
    # and provided a non-existing file
    # then exception AnsibleLookupError is raised
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    my_play_context = PlayContext()
    my_play_context.searchpath = ["/my_basedir/foobar"]
    my_templar = Templar(variables=dict(), loader=None, shared_loader_obj=None, play_context=my_play_context)

    my_lookup_module = LookupModule()
    my_lookup_module._templar = my_templar

# Generated at 2022-06-23 11:46:39.643475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        {
            'files': '',
            'paths': '',
        },
    ]
    variables = {
        '__role_path': 'tests/'
    }
    kwargs = {}
    expected_result = {
        'terms': [
            {
                'paths': [
                    'tests/'
                ],
                'files': [],
                'skip': False,
                'errors': 'strict',
            }
        ],
    }
    result = lookup._process_terms(terms, variables, kwargs)
    assert result == expected_result


# Generated at 2022-06-23 11:46:41.095057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Generated at 2022-06-23 11:46:42.703253
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:46:44.315350
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run is not None, "Expected run method to be defined"

# Generated at 2022-06-23 11:46:52.000466
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:47:04.586206
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:47:13.269120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleLookupError, match="No file was found when using first_found."):
        # Call LookupModule.run() with empty `terms` param and empty `paths` param
        LookupModule().run(terms='', paths='')
    with pytest.raises(AnsibleLookupError, match="No file was found when using first_found."):
        # Call LookupModule.run() with empty `terms` param and non-existent `paths` param
        LookupModule().run(terms='', paths="/nonexistent")

# Generated at 2022-06-23 11:47:18.683470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize LookupModule object
    lookupModule = LookupModule()

    # Add description
    # lookupModule.__doc__ = DOCUMENTATION

    # Test constructor
    lookupModule.run([['playbook/files/foo.txt']], None)


# Generated at 2022-06-23 11:47:29.688518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = {}
    lookup._loader = {}
    lookup._templar.template = lambda x: x
    lookup.find_file_in_search_path = lambda *a, **kw: 'a'
    assert lookup.run(['a', 'b'], {}) == ['a']
    lookup.find_file_in_search_path = lambda *a, **kw: None
    assert lookup.run(['c', 'd'], {}) == []
    lookup.find_file_in_search_path = lambda *a, **kw: 'e'
    assert lookup.run(['e', 'none'], {}, skip=True) == ['e']
    assert lookup.run(['f', 'none'], {}, skip=True) == []

# Generated at 2022-06-23 11:47:32.389188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Basic term
    assert lookup_module.run(["foobar"], {}) == ['/home/ansible/playbooks/foobar']

# Generated at 2022-06-23 11:47:34.240682
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test build of LookupModule constructor
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:47:42.735919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import tempfile
    import pytest
    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    cur_dir = os.path.dirname(os.path.realpath(__file__))
    project_dir = cur_dir + '/../../'

    # Create temporary directory
    tmp_dir = tempfile.gettempdir() + '/ansible_first_found_lookup_plugin'

    testdata_dir = tmp_dir + '/testdata'
    testdata2_dir = tmp_dir + '/testdata2'

    # make directories if not exist

# Generated at 2022-06-23 11:47:44.387012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:47:54.225656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # NOTE: only one of 'files' and 'paths' can be used !?!?

    terms = [
        {'files': 'foo', 'paths': 'bar, baz'},
        {'files': 'foo, bar', 'paths': 'baz'},
        {'files': 'foo', 'paths': 'bar'},
        ]

    search_terms = []
    for term in terms:
        total_search, skip = lookup._process_terms([term], None, None)
        search_terms.extend(total_search)

    assert search_terms == [
        'bar/foo', 'baz/foo',
        'baz/foo', 'baz/bar',
        'bar/foo',
        ]



# Generated at 2022-06-23 11:47:56.826466
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:47:59.659630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_loader({})
    mod._templar = {}
    mod._templar.template = lambda a: a
    return mod

# Generated at 2022-06-23 11:48:06.918909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    x._subdir = 'files'
    x.set_options(direct={'paths': ['/base']})

    # 1
    res = x.run(terms=['test1', 'test2'], variables={'item': 'test'})

    assert(res[0] == '/base/test1')

    # 2
    res = x.run(terms=['test0', 'test1', 'test2'], variables={'item': 'test'})

    assert(res[0] == '/base/test0')

    # 3
    res = x.run(terms=[{'files': 'test0,test1,test2', 'paths': '/path1:/path2'}], variables={'item': 'test'})


# Generated at 2022-06-23 11:48:19.161963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._templar = object
    lookup._templar.template = lambda x: x
    lookup.find_file_in_search_path = lambda a, b, c, d: '/bar'
    paths = ['terms', 'terms']
    paths[0] = [{'paths':'/foo', 'files':'baz'}, {'paths':'/foo', 'files':'bar'}]
    paths[1] = [{'paths':'/foo', 'files':'bar', 'skip':True}]
    assert lookup.run(paths[0], {}) == ['/bar']
    assert lookup.run(paths[1], {}) == []


# Generated at 2022-06-23 11:48:29.652393
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader

    # NOTE: Add tests for both using dict as term and list of dicts as term
    #       use first_found and last_found to test
    # FIXME: fix case where list of dict is used as term

    # No files is also a valid test

# Generated at 2022-06-23 11:48:33.306711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    result = list(lookup.run(["a","b","c"]))
    assert result == ['found']


# Generated at 2022-06-23 11:48:34.553684
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    print(lookup_mod)

# Generated at 2022-06-23 11:48:40.915288
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    # get the base class we need
    from ansible.plugins.lookup.first_found import LookupModule

    this = LookupModule()

    # setup a dict as a dict term, should be same result as list

    terms = [{'files': 'foo.txt,bar.txt',
              'paths': '/tmp/production,/tmp/staging',
              'skip': True
              }]

    files = ['/path/to/foo.txt', '/path/to/bar.txt']
    variables = Imm

# Generated at 2022-06-23 11:48:51.689622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t_module = LookupModule()

    # Test when expected value not found
    with pytest.raises(AnsibleLookupError) as err:
        t_module.run([""], {}, skip=False, paths=["/etc/ansible"], files=["foo.conf", "bar.conf"])
    assert "No file was found when using first_found." == str(err.value)

    # Test when expected value found
    with patch("ansible.plugins.lookup.first_found.LookupModule.find_file_in_search_path") as mock_lookup:
        mock_lookup.return_value = True
        assert ["true"] == t_module.run([""], {}, skip=False, paths=["/etc/ansible"], files=["foo.conf", "bar.conf"])

# Generated at 2022-06-23 11:49:02.686035
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #
    # Tests with options files + paths
    #

    # test files + paths - one of the 3 exist
    total_search = ['/path/to/bar.txt', '/path/to/biz.txt', 'bar.txt']
    # mock `search_dirs`, 'files' subdir is added in first_found.run
    search_dirs = ['/path/to', os.getcwd()]
    action = 'find_file_in_search_path'
    module_name = 'first_found'

    lookup = None
    for fn in total_search:
        lookup = first_found.run_unit_test(module_name, action, fn, search_dirs)
        if lookup is not None:
            break

    assert lookup == '/path/to/bar.txt'

    # test files + paths