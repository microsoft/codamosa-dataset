

# Generated at 2022-06-23 11:39:01.604211
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:39:03.892880
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # assert that the constructor does not raise an exception
    l.assert_constructor_exception()

# Generated at 2022-06-23 11:39:12.294678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # case 1
    # test for method run with args:
    # terms = [{'files': 'foo', 'paths': '/tmp'}]
    # kwargs = {}
    # expected = ['/tmp/foo']
    terms = [{'files': 'foo', 'paths': '/tmp'}]
    kwargs = {}
    results = module.run(terms, {}, **kwargs)
    assert results == expected

    # case 2
    # test for method run with args:
    # terms = ['foo', {'files': 'bar', 'paths': '/tmp'}, 'baz', 'boo']
    # kwargs = {}
    # expected = ['/tmp/foo', '/tmp/bar', 'baz', 'boo']

# Generated at 2022-06-23 11:39:22.492830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def fail(msg):
        raise AssertionError(msg)

    import ansible.plugins.lookup

    from ansible.module_utils._text import to_text

    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import is_sequence

    variable_manager = VariableManager()
    variable_manager.extra_vars = {u'first': u'Foo', u'last': u'Bar'}
    display = Display()

    # Set up vault
    vault_secrets = {'password_file': 'file.txt'}
    vault_secrets_from_file = {'password_file': 'file.txt'}

# Generated at 2022-06-23 11:39:24.908047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test that the constructor of abstract class LookupModule works.
    # The constructor should not throw an error.
    LookupModule()

# Generated at 2022-06-23 11:39:25.538883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:39:29.000460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # tests for method run
    terms = ['a.yml']
    result = lookup.run(terms, {})
    # verify the result
    assert result == []



# Generated at 2022-06-23 11:39:31.762468
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # construct an instance of LookupModule class
    # verify that the instance is of type LookupModule
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:39:33.138976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-23 11:39:42.413362
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # import datetime
    # import sys
    # import subprocess
    #
    # print(AnsibleLookupError)
    # print(e)
    # print(e.message)
    # print(type(e).__name__)
    # print(e.args)
    # print(sys.exc_info())
    # print(datetime.datetime.now())
    # print(e)
    # print(datetime.datetime.now())
    # print(datetime.datetime.now())
    #
    # subprocess.call(['ls'])

    m = LookupModule()

    print('---m---')
    print(m)
    print('---m.run()---')
    print(m.run())

    # print m.run(['/etc/hosts', '/etc

# Generated at 2022-06-23 11:39:44.046507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-23 11:39:45.002215
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:39:45.966303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:39:56.215929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test set up
    # From example
    terms = [
        {'files': ['foo.txt'], 'paths': ['/tmp/production', '/tmp/staging']},
        {'files': ['bar.txt']},
        {'files': ['biz.txt'], 'paths': ['/tmp/production', '/tmp/staging']},
    ]
    variables = {'ansible_facts': {
        'ansible_mounts': [{'mount': '/', 'device': '/dev/disk1s1', 'fstype': 'apfs'}]}}
    options = {'_valid_file_types': ['.txt']}
    # Test assertion : test first case
    look = LookupModule(None, variables, **options)
    assert look.run(terms, variables) == []
    # Test assertion

# Generated at 2022-06-23 11:39:58.354100
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert (lookup_module.__class__.__name__ == 'LookupModule')

# Generated at 2022-06-23 11:40:04.589436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['file1',
             {'files': 'file2',
              'paths': 'path1'},
             {'files': ['file3', 'file4'],
              'paths': ['path2', 'path3']},
             'file5']
    variables = {}
    kwargs = {'skipp': False}
    total_search, skip = lookup_module._process_terms(terms, variables, kwargs)
    assert total_search == ['file1', 'file2', 'path1/file2', 'file3', 'path2/file3', 'file4', 'path3/file4', 'file5']

# Generated at 2022-06-23 11:40:09.481244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [{'files': 'first_file', 'paths': 'first_path:second_path'}, 'first_file', 'second_file']
    variable_manager = 'test'
    kwarg = {}
    results = lookup.run(terms, variable_manager, **kwarg)
    assert results == 'first_file'

# Generated at 2022-06-23 11:40:13.426659
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()

    assert(isinstance(lookup_module, LookupBase))

    # TODO: add more tests

# Generated at 2022-06-23 11:40:22.775919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    test_obj = LookupModule()
    # Simple term
    terms = ['relt/ive/path/1.conf', 'another/relative/path/2.conf']
    # Mock variables and look into the mocked call
    with mock.patch.object(LookupModule, "_process_terms", return_value=(terms, False)):
        with mock.patch.object(LookupModule, "find_file_in_search_path", return_value="./relt/ive/path/1.conf"):
            assert test_obj.run(terms) == ['./relt/ive/path/1.conf']
    # Mapping term
    terms = [{'files': 'foo.conf', 'paths': '/tmp/'}, {'files': 'bar.conf', 'paths': '/tmp/'}]

# Generated at 2022-06-23 11:40:34.324154
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # test_terms_not_a_string_or_list_or_dict
    test_terms = 2
    for items in lookup.run(test_terms,[]):
        pass
    #with pytest.raises(AnsibleLookupError) as excinfo:
    #   lookup.run(test_terms,[])
    #assert str(excinfo.value) == 'Invalid term supplied, can handle string, mapping or list of strings but got: %s for %s' % (type(test_terms), test_terms)

    # test_terms_list_of_not_dict_or_string
    test_terms = [2,'r',3]
    for items in lookup.run(test_terms,[]):
        pass
    #with pytest.raises(AnsibleLookupError)

# Generated at 2022-06-23 11:40:46.149066
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule.run(LookupModule, [{'files': 'ansible_facts', 'paths': 'doc/'}, 'lookup_plugins/', 'README.md'], {})
    LookupModule.run(LookupModule, ['doc/lookup_plugins/', {'files': 'ansible_facts', 'paths': 'doc/'}, 'README.md'], {})
    LookupModule.run(LookupModule, ['doc/lookup_plugins', 'doc/ansible_facts', 'doc/README.md', {'files': 'ansible_facts', 'paths': 'doc/'}], {})

# Generated at 2022-06-23 11:40:52.221135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_variable = ['foo.txt']
    variables = dict(
        ansible_my_variable=my_variable,
        ansible_foo='bar'
    )

    terms = [
        dict(
            files='foo.txt',
            paths='path1:path2',
            skip=True
        ),
        dict(
            files='bar.txt',
            paths='path3:path4',
            skip=False
        )
    ]

    # NOTE: this is an undocumented feature of the base class
    # that should be corrected
    # as it is unclear what it is/does
    module = LookupBase()
    module._shared_loader_obj = type('', (), {})()
    module._shared_loader_obj._basedir = '/'
    module._shared_loader_obj._searchpath = ['.']


# Generated at 2022-06-23 11:41:03.310252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    def mock_find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        assert variables == {}
        assert subdir == 'files'
        assert ignore_missing == True
        expected = {
            'files': [
                '/path/to/foo.txt',
                '/path/to/bar.txt',
            ],
            'paths': [
                '/extra/path',
            ],
        }
        assert fn in expected['files'] or fn in expected['paths']
        return fn
    obj.find_file_in_search_path = mock_find_file_in_search_path


# Generated at 2022-06-23 11:41:06.112431
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ test constructor of class LookupModule """

    lookup_plugin = LookupModule()

    # check if it is an instance of LookupModule
    assert isinstance(lookup_plugin, LookupModule)

    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:41:07.875738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

    # TODO: when pytest is added, run tests with options and other
    # parameters provided

# Generated at 2022-06-23 11:41:09.694341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:41:10.370224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:41:19.617420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    class Options(object):
        def __init__(self, verbosity=None, intent=False, inventory=None):
            self.verbosity = verbosity
            self.connection = 'local'
            self.module_path = ['.']
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.listhosts = None
            self.listtasks = None

# Generated at 2022-06-23 11:41:30.762371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    def mock_get_basedir(self, variables):
        return '/etc/ansible/'

    def mock_path_dwim(self, basedir, given):
        # NOTE: NOT the full implimentation of path_dwim this is just to force it to
        # return a 'known file' so we are not testing path_dwim as well.
        return '/etc/ansible/' + given

    lookup = LookupModule()

    # setup test data and mock functions
    terms = [
        {
            'files': 'testfile',
            'paths': '/etc/ansible/'

        },
        'testfile2'
    ]
    variables = {'role_path': '/etc/ansible/'}
    loader = Data

# Generated at 2022-06-23 11:41:40.420710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(LookupModule, [
        'first_file.yml',
        {
            'files': 'second_file.yml',
            'paths': 'third_file.yml'
        },
        {
            'paths': 'fourth_file.yml',
            'files': 'fifth_file.yml'
        },
        {
            'paths': 'sixth_file.yml',
            'files': 'seventh_file.yml',
            'skip': True,
        },
        'eighth_file.yml'
    ])


# Generated at 2022-06-23 11:41:48.230704
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up
    class DummyTemplar():
        def template(self, fn):
            return fn
    class DummyPlugin():
        def __init__(self, subdir=None):
            self._templar = DummyTemplar()
            if subdir is not None:
                self._subdir = subdir
    lookup_module = LookupModule()
    lookup_module.set_loader(DummyPlugin())
    lookup_module.set_environment(DummyPlugin())
    lookup_module.set_task_vars(dict())

    # This is a list of tuple with (inputs, expected output)

# Generated at 2022-06-23 11:41:48.882385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 11:41:58.086170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import os
    import pytest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.lookup import first_found

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.lookup = first_found.LookupModule()

        def tearDown(self):
            pass


# Generated at 2022-06-23 11:41:59.823799
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module



# Generated at 2022-06-23 11:42:10.721175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: this would be nicer if 'self' was an instance of class
    base = LookupModule()
    # NOTE: this has to be a valid path or an exception will be raised during test
    base._subdir = 'test/test_one'

    # NOTE: this raises an exception when no valid term is found
    #       but when the test is run the exception is not caught
    #       so the error is raised instead
    terms = [
        'test_one_file',
        'test_one_file2',
        'test_one_dir/test_one_file',
    ]

    # NOTE: this also raises an exception when no valid term is found

# Generated at 2022-06-23 11:42:11.753159
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule



# Generated at 2022-06-23 11:42:23.409175
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # define test_datacenter variables
    test_datacenter_variables = {"test_var_A": "abc", "test_var_B": 123}

    # init LookupModule with the test_datacenter variables
    lookups = LookupModule(loader=None, variables=test_datacenter_variables)

    # define helper function to convert path to absolute path
    # if the file exists
    def convert_to_absolute_path(path):

        # get the absolute path of the file
        abs_path = os.path.abspath(path)

        # verify if the file exists
        if os.path.isfile(abs_path):
            return [abs_path]
        else:
            return []

    # test with template strings

# Generated at 2022-06-23 11:42:34.883324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    l = LookupModule()

    # We should have no parameter
    assert len(l.run) == 3

    # Short test
    l._templar = None
    assert l.run(['test'], {}) == [u'test']

    # Test with path (one term must not be long enough to be considered as a list)
    l.find_file_in_search_path = lambda x, y, z, **k: z + '-found'
    assert l.run(['test:test2'], {}, paths='test1') == [u'test2-found']

    # Test with split (':' and ';' must be supported)

# Generated at 2022-06-23 11:42:36.514506
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-23 11:42:41.973466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    class DummyTemplar:
        def __init__(self):
            self.template_data = {}

        def set_available_variables(self, variables):
            self.template_data = variables

        def template(self, path):
            return path

    class DummyLoader:
        def __init__(self, path):
            self.path = path

        def get_basedir(self):
            return self.path


# Generated at 2022-06-23 11:42:49.749388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if not os.path.exists('files/test.txt'):
        os.mkdir('files')
        f = open('files/test.txt', 'w')
        f.close()
    if not os.path.exists('files/test2.txt'):
        f = open('files/test2.txt', 'w')
        f.close()
    if not os.path.exists('subdir/test.txt'):
        os.mkdir('subdir')
        f = open('subdir/test.txt', 'w')
        f.close()
    if not os.path.exists('subdir/subsubdir/test.txt'):
        os.mkdir('subdir/subsubdir')
        f = open('subdir/subsubdir/test.txt', 'w')
        f

# Generated at 2022-06-23 11:42:51.587107
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    assert lookup is not None
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 11:42:54.496944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    if not isinstance(l, LookupBase):
        raise AssertionError('LookupModule is not an instance of LookupBase')

# Generated at 2022-06-23 11:43:06.748579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable, AnsibleFileNotFound
    from ansible.module_utils.six import string_types
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    lookup_plugin = lookup_loader.get('first_found')

    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    class PlayContextMock:
        def __init__(self):
            self.connection = 'local'
            self.remote_addr = None
            self.port = None
            self.remote_user = 'root'


# Generated at 2022-06-23 11:43:07.550965
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:43:10.558155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    option_parser = None
    assert lookup_plugin.run([{}], option_parser) != []

# Generated at 2022-06-23 11:43:11.893214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:43:13.514739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:43:14.672399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 11:43:15.890951
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:43:26.960098
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule
    lookup = LookupModule()

    # Create the parameters and set the options
    terms = [dict(files=["/test1"], paths=["/test/path/1", "/test/path/2"])]
    lookup.set_options(var_options={}, direct=dict(files=["/test2"], paths=["/test/path/3", "/test/path/4"]))

    # Create a list of strings and a dict with the string and list of strings
    terms.append("/test3")
    terms.append(dict(files=["/test4"], paths=["/test/path/5", "/test/path/6"]))

    # Create a list of strings and list with a dict and string

# Generated at 2022-06-23 11:43:28.953235
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module is not None)


# Generated at 2022-06-23 11:43:39.301776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Plain old files
    tlm = LookupModule()
    tlm._subdir = 'files'
    tlm._loader = get_loader_mock({})
    tlm._templar = get_templar_mock({})
    # TODO: use env vars
    assert tlm.run(['roles/one/files/foo', 'roles/two/files/foo']) == ['roles/one/files/foo']
    assert tlm.run(_split_on('roles/one/files/foo, roles/two/files/foo')) == ['roles/one/files/foo']

    # use first_found to load vars from a specific order of files
    tlm = LookupModule()
    tlm._subdir = 'files'
    tl

# Generated at 2022-06-23 11:43:40.835064
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert len(l.run([], {}))

# Generated at 2022-06-23 11:43:41.739967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-23 11:43:50.475374
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    # the default values
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') is False

    # inline config with dict term
    terms = [{"files": 'foo,bar', "paths": 'path1:path2'}]
    lookup.run(terms, [])

    # inline config with dict term
    terms = [{"files": 'foo,bar', "paths": 'path1:path2', "skip": True}]
    lookup.run(terms, [])

    # inline config with dict term
    terms = [{"files": 'foo,bar', "paths": 'path1:path2', "skip": False}]
    lookup.run(terms, [])

    # inline config with

# Generated at 2022-06-23 11:43:58.375912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_dict = {'files': ['file1.txt', 'file2.txt'], 'paths': ['path1', 'path2']}
    test_dict_skip = {'files': ['file1.txt', 'file2.txt'], 'paths': ['path1', 'path2'], 'skip': True}
    test_list1 = ['file1.txt', 'file2.txt']
    test_list2 = ['path1', 'path2']

    assert LookupModule().run([test_dict_skip], variables={}, **{}) == []

    with pytest.raises(AnsibleLookupError):
        assert LookupModule().run([test_dict], variables={}, **{})

# Generated at 2022-06-23 11:44:02.793742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['file1', 'file2']
    kwargs = {'files':'file1', 'paths': 'path1'}

    lookup = LookupModule()
    total_search, skip = lookup._process_terms(terms, None, kwargs)
    assert set(total_search) == set(['path1/file1'])

# Generated at 2022-06-23 11:44:03.580965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:44:05.835858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._subdir == 'files'


# Generated at 2022-06-23 11:44:07.728700
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_tasks = LookupModule()
    assert type(lookup_tasks) == LookupModule



# Generated at 2022-06-23 11:44:09.612156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test LookupModule constructor
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:44:11.583635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupBase)

# Generated at 2022-06-23 11:44:13.510727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_obj = LookupModule()
    assert isinstance(lookup_module_obj, LookupModule)

# Generated at 2022-06-23 11:44:21.389169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test first_found lookup for lookup module.
    '''
    # Test for LookupModule._process_terms function
    assert LookupModule._process_terms(['first', 'second', 'third']) == [['first', 'second', 'third'], False]
    assert LookupModule._process_terms(['first', 'second', 'third'], skip=True) == [['first', 'second', 'third'], True]
    assert LookupModule._process_terms(['first']) == [['first'], False]
    assert LookupModule._process_terms(['first', ['second', 'third']]) == [['first', 'second', 'third'], False]

# Generated at 2022-06-23 11:44:33.865013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from units.mock.loader import DictDataLoader

    # prepare a mock loader
    data = dict(
        variable_manager=dict(
            extra_vars=dict(
                ansible_distribution='RedHat',
                ansible_os_family='RedHat',
                ansible_virtualization_type='vmware',
            ),
            host_vars=dict()
        ),
        inventory=dict(
            host_list=dict(),
            get_hosts=lambda pattern='*': list(),
        )
    )

    # prepare a lookup plugin
    lp = LookupModule()
    lp.set_loader(DictDataLoader(data))

    # run all tests

# Generated at 2022-06-23 11:44:44.502406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # file_name is not used for this test
    # pylint: disable=unused-argument,invalid-name
    def _read_vars(file_name):
        return {'foo': 'bar'}

    templar_mock = LookupBase._create_content_temp_fn(
        LookupBase._create_temp_plugins(
            _read_vars=_read_vars))
    file_lookup = LookupModule()

    # Test two parameters, files and paths
    terms = ['foo', 'bar.txt']
    paths = ['/tmp/', '/tmp2/']
    results = file_lookup.run(terms, {}, files=terms, paths=paths)

    assert results[0] == '/tmp/bar.txt'

# Generated at 2022-06-23 11:44:45.032060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 11:44:48.122697
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: fix tests
    lookup = LookupModule()

    assert lookup._templar is not None, "_templar is None"

    args = (['item1', 'item2'], None, {})
    assert lookup._process_terms(*args) is not None, "_process_terms is None"

# Generated at 2022-06-23 11:44:50.688102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test the module was initialized correctly
    obj = LookupModule()
    assert obj
    assert obj.run


# Generated at 2022-06-23 11:45:01.777927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mysubdir(subdir):
        l = LookupModule()
        l._subdir = subdir
        return l

    def myrun(subdir, terms, variables, **kwargs):
        l = mysubdir(subdir)
        return l.run(terms, variables, **kwargs)

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 11:45:04.726105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize class LookupModule
    lookupModule = LookupModule()

    # Check the method run
    lookupModule.run([], [])

# Generated at 2022-06-23 11:45:06.680926
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 11:45:09.341540
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Creating object for class LookupModule
  test_obj = LookupModule()
  # Testing the constructor
  assert test_obj.__class__.__name__ == 'LookupModule'



# Generated at 2022-06-23 11:45:13.455505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # lookupmodule = LookupModule('inventory', 'playbook', 'loader', 'templar', [], [])
    lookupmodule = LookupModule()
    assert isinstance(lookupmodule, LookupModule)

# Generated at 2022-06-23 11:45:25.391889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This tests the full flow of the run method.

    The method is complex due to the 'magic' we support for some options
    and we want to test all the possible paths.
    This is done by mocking the method find_file_in_search_path which
    does the actual file finding and which does not need to be tested.

    LookupModule._split_on is trivial and does not need to be tested.

    LookupModule._process_terms is tested in the code that follows the
    test_LookupModule_run function.
    It is not trivial to test it via unit tests and it is not worth the time.
    """

    # Mocking the find_file_in_search_path method
    real_find_file_in_search_path = LookupModule.find_file_in_search_path

# Generated at 2022-06-23 11:45:33.809695
# Unit test for constructor of class LookupModule
def test_LookupModule():

    global_params = dict(
        files=[],
        paths=[],
        skip=False
    )

    params = dict(
        files=['file1', 'file2'],
        paths=['path1', 'path2'],
        skip=True
    )

    assert LookupModule._process_terms([], {}, global_params) == ([] ,False)
    assert LookupModule._process_terms([], {}, {}) == ([] ,False)

    # defaults
    assert LookupModule._process_terms(['term1', 'term2'], {}, global_params) == ([], False)

    # terms as dict
    assert LookupModule._process_terms([params], {}, global_params) == (['file1', 'file2'], True)

    # terms as string with comma
    assert LookupModule._

# Generated at 2022-06-23 11:45:36.003232
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:45:47.117316
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pprint

    ls = LookupModule()

    test_terms = [ 'file4', 'file5',
                   { 'files' : 'file1', 'paths' : '/path1:/path2', 'skip' : True },
                   ['file2','file3', 'file4'],
                   { 'files' : 'file4', 'paths' : 'path4/path5/path6', 'skip' : True },
                   { 'files' : 'file5', 'paths' : 'path7:path8' }
                 ]

    print("Testing values:\n" + pprint.pformat(test_terms))

    # NOTE: this is the main interest unit test
    searchlist, skip = ls._process_terms(test_terms, {}, {})


# Generated at 2022-06-23 11:45:55.590392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import tempfile

    os.environ["ANSIBLE_LOOKUP_COMMAND"] = "first_found"
    lookup = LookupModule()

    # Test with non-existent file
    os.environ["ANSIBLE_LOOKUP_COMMAND_TERM"] = "non-existent.txt, temp.txt"
    assert lookup.run(variables=dict()) == [], "Demo file does not exist, skip=True should return empty list"

    os.environ["ANSIBLE_LOOKUP_COMMAND_TERM"] = "non-existent.txt, temp.txt"
    assert lookup.run(variables=dict()) != []

    # Test with existing file
    temp = tempfile.NamedTemporaryFile(mode="w", delete=False)
    temp.write("Test")
    temp

# Generated at 2022-06-23 11:46:07.262504
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = ['vars/main.yml', 'vars/{{ os_family }}.yml', 'vars/{{ distribution }}.yml']
    args_dict = [{'files': ['myhost.yml', '{{ inventory_hostname }}.yml', '{{ ansible_hostname }}.yml', '{{ ansible_nodename }}.yml']}, 'vars/specific_vars.yml', 'vars/{{ os_family }}.yml']

    # case 1: no input, no result
    LookupModule().run([], {})

    # case 2: args defined as a list, no result
    LookupModule().run(args, {})

    # case 3: args defined as a list, no result
    LookupModule().run(args, {'distribution': 'Debian'})



# Generated at 2022-06-23 11:46:13.287528
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_native
    import json

    # Create a class of LookupBase for run method test
    class LookupBase4test(LookupBase):
        def find_file_in_search_path(self, variables, search_path, filename, ignore_missing=False):

            # Create a file in the search path
            open(search_path + '/' + filename, 'a').close()
            return search_path

        def get_option(self, option):
            return self._options.get(option, None)

    # Create a LookupModule, subclass of LookupBase
    lookup_module = LookupModule()

    # Get the run method of LookupModule
    lookup_module_run = lookup_module.run

    # Create a LookupBase4test object

# Generated at 2022-06-23 11:46:21.601534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # FIXME: how to get a real task, play, varmgr?
    # FIXME: how to call set_loader?
    # FIXME: how to call _load_vars_files?
    lookup.load()
    assert lookup.run(
        terms = [
            {
                'files': 'foo',
                'paths': 'path/to/foo'
            },
            'bar.txt',
            {
                'files': 'invalid',
                'skip': True
            }
        ],
        variables = {},
        skip = True
    ) == []

# Generated at 2022-06-23 11:46:24.692047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    test_lookup_module = LookupModule()
    assert isinstance(test_lookup_module, LookupModule)

# Generated at 2022-06-23 11:46:32.138555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    is_error = None
    error_list = []
    # This instantiation is to check that arguments are correct and in the right order
    try:
        l = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    except Exception as e:
        is_error = True
        error_list.append(type(e).__name__)
    assert (is_error is None), "LookupModule initialization returns error %s" % ','.join(error_list)



# Generated at 2022-06-23 11:46:33.084136
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:46:39.326122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin._subdir = 'my_subdir'

    with patch("ansible.plugins.lookup.first_found.LookupModule.find_file_in_search_path", MagicMock(return_value='/tmp/myfile.txt')):
        ret = lookup_plugin.run("", MagicMock(undefined=AnsibleUndefinedVariable), terms=[])
        assert ret == ["/tmp/myfile.txt"]

# Generated at 2022-06-23 11:46:41.528754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()
    assert isinstance(my_lookup_module, LookupModule)


# Generated at 2022-06-23 11:46:42.794021
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:46:50.033556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stub for LookupModule.run
    def run(self, terms, variables, **kwargs):
        #assert 0, "Failure message: {0}".format(terms)
        assert terms == [['first_found.yml', 'default.yml'], 'second_found.yml']
        assert variables == {'grid': 'mygrid', 'name': 'myname'}
        assert kwargs == {'injected': 'yes'}
        return [['found'], ['found2']]

    # Stub for LookupModule.run
    def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
        #assert 0, "Failure message: {0}".format(fn)
        assert variables == {'grid': 'mygrid', 'name': 'myname'}


# Generated at 2022-06-23 11:47:02.187949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    assert lm._process_terms(terms=['file1'], variables={}, kwargs={}) == \
        ([os.path.join(os.path.dirname(__file__), 'first_found', 'file1')], False)

    assert lm._process_terms(terms=['file1', 'file2'], variables={}, kwargs={}) == \
        ([os.path.join(os.path.dirname(__file__), 'first_found', 'file1'),
          os.path.join(os.path.dirname(__file__), 'first_found', 'file2')], False)


# Generated at 2022-06-23 11:47:12.006488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with valid options
    terms = ['relative/file1.txt', 'relative/file2.txt', 'relative/file3.txt']
    variables = {}
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == [os.path.join(os.getcwd(), 'relative/file1.txt')]

    # Test with multiple files in a single path
    terms = [os.path.join(os.getcwd(), 'relative'), 'relative/file2.txt', 'relative/file3.txt']
    variables = {}
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-23 11:47:24.566864
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # dummy instance, just to test __init__
    m = LookupModule()

    # basic __init__
    assert m.run( terms=['not used'], variables={}, **{}) == []

    # simple string
    assert m.run( terms='some/file.txt', variables={}, **{}) == [('some/file.txt', 'files', False)]

    # test _split_on
    assert m._split_on(['a,b,  c']) == ['a', 'b', 'c']
    assert m._split_on(['a;b,  c']) == ['a', 'b', 'c']
    assert m._split_on('a,b,  c') == ['a', 'b', 'c']

# Generated at 2022-06-23 11:47:35.097867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup = LookupModule()
    expect = ['unit_test_data/test.file1']

    # has to be defined, but not used
    class FakeVars:
        pass
    variables = FakeVars()

    # test first_found(['test.file1', 'test.file2'])
    terms = ['test.file1', 'test.file2']
    result = lookup.run(terms=terms, variables=variables)
    assert result == expect

    # test first_found(['test.file1'])
    terms = ['test.file1']
    result = lookup.run(terms=terms, variables=variables)
    assert result == expect

    # test first_found(['test.file2', 'test.file1'])

# Generated at 2022-06-23 11:47:36.724523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 11:47:46.758670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # Empty list
    terms = []
    variables = {}
    with pytest.raises(AnsibleLookupError):
        lookup_plugin.run(terms, variables)
    # Invalid term
    terms = {'foo': 'bar'}
    variables = {}
    with pytest.raises(AnsibleLookupError):
        lookup_plugin.run(terms, variables)
    terms = [
        {'files': 'foo.conf', 'paths': '/path/to/foo'},
        {'files': 'bar.conf', 'paths': '/path/to/bar'}
    ]
    variables = {}
    assert lookup_plugin.run(terms, variables) == []

# Generated at 2022-06-23 11:47:47.710248
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()


# Generated at 2022-06-23 11:47:58.145346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display

        display = Display()

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    block = dict(
        _terms=dict(
            files=['foo','bar'],
            paths=['/tmp/production','/tmp/staging'],
            skip=True,
        )
    )
    terms = [
         block,
         'foo',
         'bar'
    ]

    pc = PlayContext()
    pc.remote_addr = 'gondor'
    pc.connection = 'smart'
    pc.port = 22

    variable_manager = VariableManager()
    variable_manager.set_inventory

# Generated at 2022-06-23 11:48:03.850395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of files
    lm = LookupModule()
    lookup_file_list = ["/tmp/test.txt", "/tmp/test.txt", "/tmp/test.txt"]
    lm.run(lookup_file_list, None)
    
    # test with dict of files
    lookup_file_dict = dict()
    lm.run(lookup_file_dict, None)

# Generated at 2022-06-23 11:48:09.797915
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    x = LookupModule()
    path = x.run(['test1.txt'])
    assert path == ['/home/joe/test1.txt']

    path = x.run([['test1.txt', 'test2.txt']])
    assert path == ['/home/joe/test1.txt']

    path = x.run([['test1.txt', 'test2.txt'], 'test3.txt'])
    assert path == ['/home/joe/test1.txt']

    path = x.run([{'files': 'test1.txt', 'paths': '/path/t1'}, 'test3.txt'])
    assert path == ['/home/joe/test1.txt']


# Generated at 2022-06-23 11:48:21.640848
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Test with terms as a single str
    terms = 'hosts'
    variables = {}
    lookup_module.run(terms, variables)
    assert lookup_module.run_terms == [{'files': ['hosts'], 'paths': []}]

    # Test with terms as a list of str
    terms = ['hosts', 'aliases']
    variables = {}
    lookup_module.run(terms, variables)
    assert lookup_module.run_terms == [{'files': ['hosts'], 'paths': []},
                                       {'files': ['aliases'], 'paths': []}]

    # Test with terms as a dict with files and paths as str
    terms = {'files': 'hosts', 'paths': 'nodir'}

# Generated at 2022-06-23 11:48:34.506229
# Unit test for constructor of class LookupModule
def test_LookupModule():


    def _test_lookup_module(terms_in, variables, kwargs_in, expected_result, expected_skip):
        terms_in = terms_in

        test_obj = LookupModule()

        result = test_obj._process_terms(terms_in, variables, kwargs_in)

        assert result == (expected_result, expected_skip)


    # Make sure exceptions are raised when template is used but variables is None and when
    # variables is not a dictionary
    with pytest.raises(AnsibleUndefinedVariable):
        result = _test_lookup_module(
            terms_in=[{'files': "{foo}"}],
            variables=None,
            kwargs_in={},
            expected_result=[],
            expected_skip=False,
        )


# Generated at 2022-06-23 11:48:36.052768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:48:37.707832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:48:40.741162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'
    assert LookupModule.__doc__.splitlines()[0] == 'Return first found file from list.'


# Generated at 2022-06-23 11:48:51.526381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    #
    # Test with a list of strings
    #
    terms = ['/path/to/file', 'file']
    variables = {}
    ret = lookup_mod.run(terms, variables, skip=True)
    assert ret == ['/path/to/file']
    #
    # Test with a list of strings and a list
    #
    terms = ['/path/to/file', 'file', ['file1', 'file2'], 'file3']
    variables = {}
    ret = lookup_mod.run(terms, variables, skip=True)
    assert ret == ['/path/to/file']
    #
    # Test with a list of strings, a list and a mapping
    #

# Generated at 2022-06-23 11:48:55.023614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    args = [{'files': ['/tmp/foo.txt'], 'paths': ['/tmp'], 'skip': True}]
    test._process_terms(args, {}, {})
    return test

# Generated at 2022-06-23 11:49:05.911116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: This test is not used for now but left for future development.
    lookup = LookupModule()


    # NOTE: This test is not used for now but left for future development.
    terms = [
        {"files": ["baz.txt", "biz.txt"], "paths": ["/path/to/", "/path/to/other/"]},
        {"files": ["foo.txt", "bar.txt"], "paths": ["/tmp/production", "/tmp/staging"]},
    ]
    variables = {}

    test_1 = lookup.run(terms, variables)


    # NOTE: This test is not used for now but left for future development.
    terms = "foo.txt, bar.txt, baz.txt"
    variables = {}

    test_2 = lookup.run(terms, variables)


    #