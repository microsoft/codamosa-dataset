

# Generated at 2022-06-23 11:39:10.037547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        unicode = str

    # Create an instance of LookupModule to test its run method.
    lookup_instance = LookupModule()

    # This lookup module can be called with a list of arguments, so
    # here we present some of them

    # First, list of arguments without the needed ones
    arguments = {
        'terms': [],
        'variables': {},
        'files': [],
        'paths': ['/tmp']
    }

    # Now let's test the behavior when to many arguments are given

# Generated at 2022-06-23 11:39:15.579122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("start test_LookupModule_run")

# Generated at 2022-06-23 11:39:21.713031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {'files': 'foo', 'paths': '/tmp/production,/tmp/staging', 'skip': True}
    terms = ['bar', 'baz', params]
    variables = {}
    l = LookupModule()
    l.set_options(var_options=variables, direct=params)
    assert l.get_option('files') == 'foo'
    assert l.get_option('paths') == '/tmp/production,/tmp/staging'

# Generated at 2022-06-23 11:39:26.490026
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: this is broken and should be refactored
    raise SkipTest

    # init
    lookup_obj = LookupModule()
    lookup_obj._templar = Dictable()

    # test
    lookup_obj.run(['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt'], {}, {}, [])
    lookup_obj.run(['foo', '{{ inventory_hostname }}', 'bar'], {'inventory_hostname': 'total.something.tld'}, {}, ['files'])

# Generated at 2022-06-23 11:39:35.305670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    looker = LookupModule()
    terms = [
        {
            'files': ['foo.txt', 'bar.txt'],
            'paths': ['path/to/foo/', '/another/path', '/tmp/']
        },
        {
            'files': ['biz.txt'],
            'paths': ['/tmp/', '/another/path']
        },
        {
            'files': ['blah.txt']
        }
    ]
    variables = []
    kwargs = {
        'skip': False
    }
    total_search, skip = looker._process_terms(terms, variables, kwargs)
    assert len(total_search) == 6
    assert total_search[0] == 'path/to/foo/foo.txt'

# Generated at 2022-06-23 11:39:41.482820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_params = {
        'files': 'foo',
        'paths': 'bar'
    }

    lm = LookupModule()
    lm.set_options(lookup_params)
    assert lm.get_option('files') == 'foo'
    assert lm.get_option('paths') == 'bar'
    lm.set_options(var_options={}, direct={})
    assert lm.get_option('files') == None
    assert lm.get_option('paths') == None


# Generated at 2022-06-23 11:39:51.237395
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockTemplar(object):
        def __init__(self, templar):
            self.templar = templar
        # Mock instantiation and template execution
        def template(self, terms):
            return self.templar.template(terms, convert_bare=True)

    mock_templar = MockTemplar("")
    variable_manager = "fake variable_manager"
    loader = "fake loader"

    class MockLookupBase(object):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return subdir, fn

    obj = LookupModule(loader=loader, variable_manager=variable_manager)
    obj._templar = mock_templar
    mock_base = MockLookupBase()
    obj.set_

# Generated at 2022-06-23 11:39:53.648323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  parameters = None
  obj = LookupModule()
  result = obj.run(parameters)

  assert result is not None, "Failed to run test_LookupModule_run."

# Generated at 2022-06-23 11:40:02.825618
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') == False

    lookup = LookupModule()
    lookup._process_terms(['first_file.txt'], {}, {})
    assert lookup.get_option('files') == ['first_file.txt']
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') == False

    lookup = LookupModule()
    lookup._process_terms(['file', 'other_file.txt'], {}, {'files': 'file'})
    assert lookup.get_option('files') == ['file', 'other_file.txt']
    assert lookup.get_option('paths') == []

# Generated at 2022-06-23 11:40:09.048792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'test_subdir'
    # NOTE: this is a hack at best, it tests the _process_terms internally and
    # should be made explicit
    assert l.run(['notfound1', 'notfound2']) == [], "function return not empty"
    assert l.run(['notfound1', 'notfound2'], skip=True) == [], "function return not empty"


# Generated at 2022-06-23 11:40:14.149890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    os.path.exists = lambda x: True
    assert LookupModule().run(terms=[{'files': 'foo', 'paths': '/tmp'}], variables=dict())


# Generated at 2022-06-23 11:40:23.336744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the Mock variable before running the test
    mock_variable = 'mock'
    mock_kwargs = {'file': 'file'}
    mock_self = {
        '_subdir': 'subdir',
        'find_file_in_search_path': 'search path',
        '_templar': 'templar'
    }
    mock_terms = [
        'first_file',
        {'paths': 'path1,path2'},
        {'files': 'file1,file2'}
    ]
    mock_variables = dict()

    # Run the test
    results = LookupModule.run(mock_self, mock_terms, mock_variables, **mock_kwargs)

    # Assert the results
    assert list in results.__class__.__b

# Generated at 2022-06-23 11:40:27.337997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = []
    variables = {}
    total_search, skip = lm._process_terms(terms, variables, {})
    assert total_search == []
    assert skip == False

# Generated at 2022-06-23 11:40:29.541018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:40:33.158187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['test_file'], variables={}, errors='ignore') == ['/etc/ansible/test_file']
    assert lookup.run(terms=['test_file'], variables={}, skip=True) == []

# Generated at 2022-06-23 11:40:37.963997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookupModule = LookupModule()

    # test empty term
    assert my_lookupModule.run([], {}) == [], 'test fail with empty terms'

    # test not list term
    assert my_lookupModule.run('', {}) == [], 'test fail with not list terms'
    assert my_lookupModule.run('foo', {}) == [], 'test fail with not list terms'

    # test list of string term
    assert my_lookupModule.run(['foo', 'bar', 'baz'], {}) == [], 'test fail with list string term'

# Generated at 2022-06-23 11:40:46.189153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    compteur = 0
    # Test if all types of variables are correctly handled
    for test_param in ["dict", ["dict"], "list", ["list"], "string", ["string"], "other"]:
        compteur += 1
        print("############## Test "+str(compteur)+" for "+str(test_param)+" value ##############")
        res = lookup_module.run(test_param, [], [])
        if isinstance(test_param, Mapping):
            assert res == []
        else:
            assert res == None

# Generated at 2022-06-23 11:40:50.067793
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule(None, None).run(terms=['foo', 'bar'], variables={'ansible_distribution': 'redhat'})
    assert result == []
    assert result is not None

# Generated at 2022-06-23 11:40:54.265759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.module_utils.ansible_release import __version__
    except ImportError:
        __version__ = "2.4.0.dev0"
    from ansible.module_utils.six.moves import unittest

    class File_Obj(object):
        def __init__(self):
            self.path = None
        def find_file(self, *args, **kwargs):
            return self.path

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.path = None
            self.args = None

    class LookupModule_Test(unittest.TestCase):
        def setUp(self):
            self.lookup_obj = LookupModule()
            self.lookup_obj._file_obj = File_

# Generated at 2022-06-23 11:40:57.100984
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify that Lookup module can be instantiated.
    lookup_plugin = LookupModule()

    assert lookup_plugin

# Generated at 2022-06-23 11:41:06.081899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Assert that the function _split_on does split correctly
    assert lookup_module._split_on(['foo,bar']) == ['foo', 'bar']
    assert lookup_module._split_on(['foo, bar']) == ['foo', 'bar']
    assert lookup_module._split_on(['foo,bar,', 'bar,foo']) == ['foo', 'bar', 'bar', 'foo']

    # Assert that the function _process_terms can handle a string
    total_search, skip = lookup_module._process_terms('foo', dict(), dict())
    assert total_search == ['foo']
    assert skip is False

    # Assert that the function _process_terms can handle a list of strings

# Generated at 2022-06-23 11:41:16.816598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    modules = ('ansible.plugins.lookup.first_found')
    for module_name in modules:
        module = __import__(module_name)
        for part in module_name.split(".")[1:]:
            module = getattr(module, part)
        globals()[module.__name__] = module
    # Creating a LookupModule object
    lm = LookupModule()
    # Creating a LookupBase object
    lb = LookupBase()
    # Creating a variables object
    variables = {'test_variable': 'test_value'}
    # Creating a options object
    options = {'files': ['test_files'], 'paths': ['test_paths']}
    # Setting the options
    lm.set_options(direct=options)
    # Creating a templar object
    tem

# Generated at 2022-06-23 11:41:28.597347
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: this test is 'hack' as normally this class is only used as a plugin
    l = LookupModule()

    # build test cases, with expected results

    # cases that should fail

# Generated at 2022-06-23 11:41:30.196042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-23 11:41:32.297754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes

    assert 0 # TODO: implement your test here



# Generated at 2022-06-23 11:41:33.402377
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 11:41:37.509224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Set up for call to LookupModule.__init__
    LookupModule._load_plugins(class_only=True)
    # test init
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:41:38.277389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-23 11:41:39.405079
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupBase)


# Generated at 2022-06-23 11:41:45.160585
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_LookupModule_run: test return single file

    terms = ['lookup.py']
    variables = {
        'ansible_current_user': 'vagrant',
        'ansible_facts': {
            'ansible_fqdn': 'vagrant.local',
            'ansible_machine_id': '12345678-1234-1234-1234-123456789012',
            'ansible_nodename': 'vagrant.local',
        },
    }

    print("\nFile lookup.py")
    result = LookupModule().run(terms, variables)
    assert len(result) == 1
    assert result[0] == "lookup.py"

    # test_LookupModule_run: test return single file in subdir


# Generated at 2022-06-23 11:41:45.860982
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:41:46.909416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:41:56.796027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = (
        {'paths': '/etc', 'files': 'foo.txt'},
        {'paths': '/etc', 'files': 'foo.txt'},
        {'paths': '/etc', 'files': 'foo.txt', 'skip': True},
        {'paths': '/etc', 'files': 'foo.txt', 'skip': False}
    )
    variables = {}
    kwargs = {}
    results = []

    lm = LookupModule()
    for t in terms:
        paths = lm._process_terms(t, variables, kwargs)
        results.append(paths)


# Generated at 2022-06-23 11:42:08.510901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create instance of LookupModule
    lm = LookupModule()

    # create dict of arguments
    kwargs = dict()

    # create variable with value
    cwd = os.path.dirname(os.path.realpath(__file__))
    kwargs["cwd"] = cwd

    # create variable with value
    tests_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    kwargs["tests_dir"] = tests_dir

    # define terms
    terms = list()

    # define list of files that should not be found
    fn1 = "data/file1.txt"
    terms.append(fn1)

    # define list of files that should not be found
    fn2 = "data/file2.txt"
    terms

# Generated at 2022-06-23 11:42:09.672177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:42:21.353014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Create a new lookup module
    lookup_module = LookupModule()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    test_input_file_default_paths = {}
    test_input_file_default_paths['files'] = []
    test_input_file_default_paths['paths'] = []
    test_input_file_default_paths['paths'].append(os.path.expanduser('~/ansible_test'))
    test

# Generated at 2022-06-23 11:42:24.393429
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate the class
    lm = LookupModule()
    assert isinstance(lm, LookupModule), "object is not an instance of LookupModule"
    return True
# END unit test

# Generated at 2022-06-23 11:42:24.974678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:42:26.310170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-23 11:42:38.480914
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    my_dict = {'files': 'file1,file2,file3', 'paths': '/tmp/production:/tmp/staging'}
    assert lookup._process_terms(my_dict) == {'files': ['file1', 'file2', 'file3'], 'paths': ['/tmp/production', '/tmp/staging']}
    assert lookup._process_terms([my_dict]) == {'files': ['file1', 'file2', 'file3'], 'paths': ['/tmp/production', '/tmp/staging']}
    assert lookup._process_terms([my_dict, my_dict]) == {'files': ['file1', 'file2', 'file3'], 'paths': ['/tmp/production', '/tmp/staging']}

# Generated at 2022-06-23 11:42:47.660937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule(None, None, {})

    def test_file_exists(path):
        if path in ['/some/path/some_file.txt', '/some/path/other_file.txt']:
            return True
        return False

    # Note: the template method is a stub and will not work as it is
    module._templar.template = lambda x: x
    module.find_file_in_search_path = lambda *args, **kwargs: '/some/path/some_file.txt'
    module.path_exists = test_file_exists


# Generated at 2022-06-23 11:42:48.912447
# Unit test for constructor of class LookupModule
def test_LookupModule():
  my_lookup = LookupModule()

# Generated at 2022-06-23 11:42:50.675950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert not l.lookup("test")

# Generated at 2022-06-23 11:42:52.760793
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._get_file_contents("test")

# Generated at 2022-06-23 11:42:54.493676
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:43:06.749824
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Test with one correct file in file list
    # Test with option 'skip' is True
    params = [
        {'files': 'file1',
         'paths': 'path1',
         'skip': True}]

    ret = lookup_module.run(
        [params],
        {'path1': '/path/to',
         'file1': 'file1.txt'},
        wantlist=True)

    assert ret == ['/path/to/file1.txt']

    # Test with one correct file in file list
    # Test with option 'skip' is False
    params = [
        {'files': 'file1',
         'paths': 'path1',
         'skip': False}]


# Generated at 2022-06-23 11:43:13.176701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check constructor creation
    #
    # "os" module is mocked and will be used to
    # prevent any call to the filesystem
    #
    lookup_cls = LookupModule()

    # os.path is a module and will be used later to prevent
    # any call to find_file_in_search_path()
    lookup_cls._templar = os


# Generated at 2022-06-23 11:43:24.927977
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: more tests
    from ansible.module_utils.six.moves import builtins
    lookup = LookupModule()

    # walk the structure
    # term is list => process terms
    # term is string => process string
    # term is mapping => process mapping, override terms with mapping options
    # term is dict => process dict, override terms with dict options

    # if something comes down the wire with a dict we should raise
    # this is to catch mistakes, who knows maybe a feature later.


# Generated at 2022-06-23 11:43:27.940988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(LookupModule(), terms=[{'files': 'foo.txt', 'paths': '/path'}], variables={})


# Generated at 2022-06-23 11:43:29.015328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:43:32.037423
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:43:33.536876
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, object)


# Generated at 2022-06-23 11:43:43.927340
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # First test: no parameter given, _terms = []
    assert(LookupModule()._terms == [])

    # Second test: a term and an option given, _terms = [{'files': 'foo', 'paths': []}]
    assert(LookupModule('foo', paths=[])._terms == [{'files': 'foo', 'paths': []}])

    # Third test: two terms and an option given, _terms = [{'files': 'foo', 'paths': []}, {'files': 'bar', 'paths': []}]
    assert(LookupModule(['foo', 'bar'], paths=[])._terms == [{'files': 'foo', 'paths': []}, {'files': 'bar', 'paths': []}])

    # Fourth test: a term given as a list, _terms =

# Generated at 2022-06-23 11:43:44.900228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule is not None)

# Generated at 2022-06-23 11:43:46.486594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 11:43:52.064977
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Inputs for constructor
    params = dict()
    params['_loader'] = "string"
    params['basedir'] = "string"
    params['vars'] = dict()
    params['_templar'] = "string"

    obj = LookupModule(**params)
    # Check class instantiation
    assert obj
    # Check for module's function run
    assert obj.run

# Generated at 2022-06-23 11:44:00.773383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # _subdir can be set by task executor, or not.
    # if it is set it must be set before calling run
    # [NOTE: could get around this by having a method that actually makes a _subdir if it' none or not...]
    del module._subdir
    # try none terms, should raise error
    terms = None
    variables = {}
    kwargs = {}
    result = module.run(terms, variables, **kwargs)
    assert result == []


    # try empty list, should raise error
    terms = []
    variables = {}
    kwargs = {}
    result = module.run(terms, variables, **kwargs)
    assert result == []

    # try list of empty strings, should raise error
    terms = [""]
    variables = {}
    kw

# Generated at 2022-06-23 11:44:07.736890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule(None)
    assert L.run(terms = ['string'], variables = {'foo': 'bar'}, skip = False, wantlist = True) == []

    assert L.run(terms = ['string'], variables = {'foo': 'bar'}, skip = True, wantlist = True) == []
    assert L.run(terms = ['string'], variables = {'foo': 'bar'}, skip = 'True', wantlist = True) == []
    assert L.run(terms = ['string'], variables = {'foo': 'bar'}, skip = 'None', wantlist = True) == []
    assert L.run(terms = ['string'], variables = {'foo': 'bar'}, skip = True, wantlist = False) == ''

# Generated at 2022-06-23 11:44:17.844802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mock_terms = ['/vagrant/ansible/plugins/lookup/test/test.txt', '/vagrant/ansible/plugins/lookup/test/test2.txt']

# Generated at 2022-06-23 11:44:20.414241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(["file1", "file2"], dict())

# Generated at 2022-06-23 11:44:32.574374
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestObject(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    # NOTE: this does not test 'global' skip but seeing behaviors (skip clobber for dict term)
    #       that it is not used so commented out for now.
    #
    # class TestTemplar(object):
    #
    #     # acts like the result from _templar.template()
    #     def template(self, v):
    #         return v

    # class TestVariables(object):
    #
    #      # acts like the result from variables.
    #     def get(self, v, default=None):
    #         return v.split(',')


# Generated at 2022-06-23 11:44:40.191063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = [[{'paths': '/tmp/production'}, {'files': 'foo.txt'}, {'paths': ['/tmp/staging', '/tmp/production']}, {'files': ['hosts.txt', 'hosts.ini']}],
             {'files': 'hosts.csv', 'paths': '/tmp/staging'}]
    variables = None
    kwargs = {'skip': True}
    fail = False
    try:
        l.run(terms, variables, **kwargs)
    except Exception:
        fail = True
    assert fail

# Generated at 2022-06-23 11:44:48.265923
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # arrange
    import os
    from ansible.module_utils.six import string_types

    class DummyException(Exception):
        pass

    class DummyTemplar():

        def __init__(self):
            self.rendered_templates = []

        def template(self, value):
            self.rendered_templates.extend(value)
            if isinstance(value, string_types):
                return value
            return tuple([v.format(0) if '{' in v else v for v in value])

    class DummyModule():

        def __init__(self, args):
            self.args = args


# Generated at 2022-06-23 11:44:54.982069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test._templar = type('Templar', (object,), dict())
    test._templar.template = lambda x: x
    test.find_file_in_search_path = lambda a, b, c, d, e: '/tmp/foo'
    result = test.run(terms=['/tmp/foo', 'foobar'], variables={})
    assert result == ['/tmp/foo']

# Generated at 2022-06-23 11:45:06.141343
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create mock variables
    variables = dict()

    # create mock class in order to test LookupModule
    class MockLookupModule(LookupModule):
        def get_option(self, option):
            return kwargs.get(option)

        def set_options(self, var_options, direct):
            pass

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            # The lookup.first_found does not need to find a real file,
            # so we just mock the method and return the searched file
            # or None if the file is not in the list of searched files.
            return fn if fn in searched_files else None

    # create mock classes to use in tests
    class MockAnsibleLookupError(Exception):
        pass


# Generated at 2022-06-23 11:45:12.926544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os

    terms = [{"files": "foo.conf,bar.conf", "paths": "/tmp/production,/tmp/staging"}, "baz.conf,foobar.conf"]
    lookup_module = LookupModule()
    search, skip = lookup_module._process_terms(terms, {}, {})
    os.pathsep.join(search) == '/tmp/production/foo.conf,/tmp/production/bar.conf,/tmp/staging/foo.conf,/tmp/staging/bar.conf,baz.conf,foobar.conf'
    assert skip == False

    terms = [{"files": "foo.conf,bar.conf", "paths": "/tmp/production,/tmp/staging", "skip": True}, "baz.conf,foobar.conf"]
    lookup_module = Lookup

# Generated at 2022-06-23 11:45:14.643030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm != None

# Generated at 2022-06-23 11:45:16.128646
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()



# Generated at 2022-06-23 11:45:27.801158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # NOTE: this will raise an error during construction on purpose
    # passing a mapping that has no 'files' or 'paths' when using 'dict' as term.
    # For example invalid:
    #   lookup('first_found', {'skip': True})
    try:
        assert LookupModule({})
    except AnsibleLookupError:
        pass
    # test list of strings as term
    assert LookupModule(['foo.txt', 'bar.txt'], {})
    # test dictionary as term
    assert LookupModule({'files': ['foo.txt', 'bar.txt']}, {})
    # test another dictionary as term
    assert LookupModule({'files': ['foo.txt', 'bar.txt'], 'paths': ['.']}, {})
    # test list of dictionaries

# Generated at 2022-06-23 11:45:39.306310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_config = {
        'ansible_virtualization_type': 'kvm',
        'ansible_distribution': 'debian',
        'ansible_os_family': 'debian',
        'inventory_hostname': 'test_host',
    }

    test_plugin = LookupModule()
    test_plugin._templar = FakeTemplar(test_config)
    test_plugin.set_loader(FakeLoader())


    # Test with a list of strings
    test_terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    test_results = test_plugin.run(
        test_terms,
        test_config,
        paths=[],
        files=[],
        skip=False
    )

    assert len(test_results) == 1
   

# Generated at 2022-06-23 11:45:40.992171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The test is not finished yet.
    test_LookupModule_run_return_list()
    test_LookupModule_run_return_list_with_error()
    test_LookupModule_run_return_empty()


# Generated at 2022-06-23 11:45:51.113596
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This first case is for a single term given to the run function.
    # Checking the case when the file doesn't exists.
    terms = "/tmp/nonExistentFile"
    variables = {}
    kwargs = {}
    m_LookupModule = LookupModule()
    m_LookupModule._subdir = "files"
    with pytest.raises(AnsibleLookupError):
        m_LookupModule.run(terms, variables, **kwargs)


    # This second case is for a single term given to the run function.
    # Checking the case when the file exists.
    terms = __file__
    variables = {}
    kwargs = {}
    m_LookupModule = LookupModule()
    m_LookupModule._subdir = "files"
    assert [__file__] == m_Look

# Generated at 2022-06-23 11:46:00.675801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes

    class TestVariables(object):
        _fact_cache = dict()

    # Find file in a dict
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup.set_options(var_options=TestVariables(), direct={'files': 'foo', 'paths': '/path/to/a/dir:/path/to/another/dir'})
    assert lookup.get_option('files') == 'foo'
    assert lookup.get_option('paths') == '/path/to/a/dir:/path/to/another/dir'
    assert lookup.get_option('skip') is False

    # found the file
    lookup._loader.path_exists = lambda x: True
    lookup._loader.path_mtime = lambda x: True


# Generated at 2022-06-23 11:46:10.313366
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:46:15.083542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_from_datastructure({'files': 'foo', 'paths': '.'})
    assert lookup.run(['test/test.txt'], {}) == [os.path.join(os.getcwd(), 'test/test.txt')]

# Generated at 2022-06-23 11:46:22.377731
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Test case: No file found:
    file_terms = []
    variables = {}
    kwargs = dict()
    result = lookup_module.run(file_terms, variables, **kwargs)
    assert result == []

    file_terms = ['filename', 'filename1']
    variables = {}
    kwargs = {}
    result = lookup_module.run(file_terms, variables, **kwargs)
    assert result == []

    # Test case: Input provided as list of file names
    file_terms = ['filename', 'filename1']
    variables = {}
    kwargs = {'files': 'filename1'}
    result = lookup_module.run(file_terms, variables, **kwargs)

# Generated at 2022-06-23 11:46:31.641881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    terms = [
        dict(files=['foo', 'bar'], paths=['/extra/path']),
        dict(files=['baz', 'biz'], paths=['/extra/path2']),
    ]
    variables = dict()
    kwargs = dict()

    res, skip = lu._process_terms(terms, variables, kwargs)

    assert len(res) == 4
    assert res[0] == '/extra/path/foo'
    assert res[1] == '/extra/path/bar'
    assert res[2] == '/extra/path2/baz'
    assert res[3] == '/extra/path2/biz'
    assert skip is False

# Generated at 2022-06-23 11:46:37.961843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    terms = ['module_utils/basic.py']

    mock_loader = Mock()
    mock_loader.paths = ['/test/test_lookup', '/test']
    mock_loader.path_dwim = lambda x: x

    mock_templar = Mock()
    mock_templar.template = lambda x: x

    lookup = LookupModule()
    lookup.loader = mock_loader
    lookup.templar = mock_templar

    options = Options(files=terms, paths=['/anotherpath'])
    assert lookup.run([options], dict()) == ['module_utils/basic.py']

# Generated at 2022-06-23 11:46:40.528285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lookup_args = {}
    lookup_args['files'] = ['file1', 'file2']
    lookup_args['paths'] = '/path/to/files'

    lm._process_terms(['file1'], {}, lookup_args)

# Generated at 2022-06-23 11:46:41.834242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert(module.run([], {}) == [])

# Generated at 2022-06-23 11:46:49.425856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Testing valid cases
    #####################

    # No file found
    terms1 = [
        {
            "files": "file1",
            "paths": "/tmp"
        },
        {
            "files": "file2",
            "paths": "/tmp"
        }
    ]
    variables1 = {}
    kwargs1 = {}
    result1 = lookup_plugin.run(terms1, variables1, **kwargs1)
    assert result1 == []

    # One file found
    terms2 = [
        {
            "files": "subdir_temp.yml",
            "paths": "/tmp"
        },
        {
            "files": "subdir_test.yml",
            "paths": "test"
        }
    ]

# Generated at 2022-06-23 11:47:01.569025
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    # without 'skip'
    try:
        lm.run("")
        assert False, "File not found and no skip"
    except Exception:
        pass

    # with skip
    lm.set_options(var_options={}, direct={'skip': True})
    assert not lm.run(""), "File not found with skip"

    # 'files' with 'skip'
    lm.set_options(var_options={}, direct={'files': ['file1', 'file2'], 'skip': True})
    assert not lm.run(""), "File not found with skip"

    # 'paths' with 'skip'
    lm.set_options(var_options={}, direct={'paths': ['path1', 'path2'], 'skip': True})

# Generated at 2022-06-23 11:47:08.884654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class OptionsModule:
        def __init__(self):
            self.verbosity = 0
            self.connection = 'local'
            self.timeout = 10
            self.remote_user = 'Sybren'
            self.sudo_user = 'Sybren'
            self.check = 'False'
            self.force_handlers = 'False'
            self.flush_cache = 'False'
            self.become = 'False'
            self.become_method = 'sudo'
            self.become_user = 'Sybren'
            self.ask_pass = 'False'
            self.private_key_file = 'tests/files/private_key'

    lookup_module = LookupModule()
    lookup_module._options = OptionsModule()

    # Init the class

# Generated at 2022-06-23 11:47:15.701326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import string_types

    # process_terms
    l = LookupModule()
    total_search, skip = l._process_terms([{'files': None, 'paths': None, 'skip': None}], None, None)
    assert not total_search
    assert not skip

    total_search, skip = l._process_terms([{"files": "file1.txt,      file2.txt", "paths": "path1.txt, path2.txt", "skip": False}], None, None)
    assert total_search
    assert not skip

# Generated at 2022-06-23 11:47:25.196290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Setup
    files = ['file1', 'file2']
    paths = ['path1', 'path2']
    skip = True
    terms = [{'files': files, 'paths': paths, 'skip': skip}]

    # Exercise and verify
    lookup_plugin = LookupModule()
    lookup_plugin.run(terms, dict())
    assert lookup_plugin.get_option('files') == files
    assert lookup_plugin.get_option('paths') == paths
    assert lookup_plugin.get_option('skip') == skip

# Generated at 2022-06-23 11:47:34.191575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar as it is not used in the method and it is needed to initialize the object
    class _MockTemplar:
        def __init__(self):
            pass
    templar = _MockTemplar()
    lookup_plugin = LookupModule(templar)
    lookup_plugin._subdir = 'files'
    lookup_plugin._loader = None

    # Handle the case where there is no file match
    assert lookup_plugin.run([{'files': 'foo.txt', 'paths': '/path/to/'}], None) == []

    # TODO: find a test case where a file match is returned

# Generated at 2022-06-23 11:47:42.327140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    lookup_mod.set_options({'files': 'foo, bar', 'paths': 'baz'})
    search_terms = ['baz', 'file1', 'file2']
    total_search, skip = lookup_mod._process_terms(search_terms, None, None)
    assert total_search == ['baz/foo', 'baz/bar', 'file1', 'file2']
    assert skip is False

    lookup_mod.set_options({'files': 'foo', 'paths': 'baz:,:bar:y:', 'skip': True})
    search_terms = ['baz', 'file1', 'file2']
    total_search, skip = lookup_mod._process_terms(search_terms, None, None)

# Generated at 2022-06-23 11:47:49.516898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # Test with multiple files, one path
    # Test with multiple files, multiple paths
    # Test with one file, one path
    # Test with one file, multiple paths
    # Test with one file, no path
    # Test with multiple files, no path
    # Test with no file, one path
    # Test with no file, multiple paths
    # Test with no file, no path
    # Test with one file
    # Test with multiple files
    # Test with nothing
    # Test with invalid inputs

# Generated at 2022-06-23 11:47:52.386579
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.template import Templar
    t = Templar(loader=None, variables={})
    test = LookupModule(loader=None, templar=t, variables={})
    assert isinstance(test, LookupModule)

# Generated at 2022-06-23 11:47:54.842082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    from ansible.parsing.dataloader import DataLoader
    l = LookupModule()
    l._templar = DataLoader()
    return l



# Generated at 2022-06-23 11:47:57.870902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    terms = []
    variables = {}
    total_search = lookupModule.run(terms, variables)
    assert total_search is None

# Generated at 2022-06-23 11:48:06.957011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First file found
    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: fn if fn == 'foo' else None
    assert lookup_module.run(terms=['foo'], variables={}, errors='strict') == ['foo']

    # Second file found
    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: fn if fn == 'foo2' else None
    assert lookup_module.run(terms=['foo', 'foo2'], variables={}, errors='strict') == ['foo2']

    # None found
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:48:19.553373
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class VarsMod(object):
        def __init__(self, d):
            self.vars = d

    class OptionsMod(object):
        def __init__(self, d):
            self.options = d

    lookup_plugin = LookupModule()

    # test with just a string for a term
    term = 'test string'
    got = lookup_plugin._process_terms([term], VarsMod({}), OptionsMod({}))
    assert got == ([term], False)

    # test with a string and a comma
    term = 'test, string'
    got = lookup_plugin._process_terms([term], VarsMod({}), OptionsMod({}))
    assert got == ([term], False)

    # test with a string and a semicolon
    term = 'test; string'
    got = lookup_plugin

# Generated at 2022-06-23 11:48:27.307312
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = [
        {
            'files': 'foo.conf,bar.conf',
            'paths': 'host_foo.conf,host_bar.conf'
        },
        {
            'files': 'foo.conf,bar.conf',
            'paths': 'host_foo.conf,host_bar.conf'
        }
    ]

    obj = LookupModule()

    # TODO: this test is broken, kwargs are consumed and not passed on
    partial, skip = obj._process_terms(terms, None, None)

    assert ["host_foo.conf/foo.conf",
            "host_foo.conf/bar.conf",
            "host_bar.conf/foo.conf",
            "host_bar.conf/bar.conf"] == partial

    assert skip is False

# Generated at 2022-06-23 11:48:38.047865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    with pytest.raises(AnsibleLookupError) as excinfo:
        l.run("")
    assert 'No file was found when using first_found.' in str(excinfo.value)

    # case: it is a string
    res = l.run("foo.txt")
    assert res == ['foo.txt']

    # case: list of strings
    res = l.run(["foo.txt", "/path/to/bar.txt"])
    assert res == ['/path/to/bar.txt']

    # case: list of string with skip=True
    res = l.run(["foo.txt", "/path/to/bar.txt"], skip=True)
    assert res == ['foo.txt']

    # case: list of dict

# Generated at 2022-06-23 11:48:47.104887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class ArgSpec():
        def __init__(self, args):
            self.args = args

    options = {}
    templar = None
    shared_loader_obj = None
    loader = None

    args = ArgSpec(args=['terms', 'variables', '**kwargs'])
    lookupModule = LookupModule(loader=loader, templar=templar, loader_object=shared_loader_obj, var_templar=templar, var_templar_common=templar, args=args, module_vars=options)
    assert isinstance(lookupModule, LookupModule)

# Generated at 2022-06-23 11:48:47.956477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True



# Generated at 2022-06-23 11:48:48.608854
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 11:48:55.951273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # Test 1: test _process_terms with a string
    terms = "test_file,test_file2"
    variables = dict(path='/test/')
    kwargs = dict(files=terms, paths=variables)
    lookup.reset_options()
    lookup.set_options(var_options=variables, direct=kwargs)
    search_list, skip = lookup._process_terms([terms], variables, kwargs)
    assert ['test_file', 'test_file2'] == search_list

    # Test 2: test _process_terms with a dict of options
    lookup.reset_options()
    lookup.set_options(var_options=variables, direct=kwargs)
    search_list, skip = lookup._process_terms([kwargs], variables, kwargs)

# Generated at 2022-06-23 11:49:02.994043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x_path = None
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'files': '*', 'path': 'path'})
    assert lookup_plugin.get_option('files') == '*'
    assert lookup_plugin.get_option('path') == 'path'
    assert lookup_plugin._process_terms([""]) == ([], False)
    assert lookup_plugin._process_terms([{'files': '*', 'path': 'path'}]) == ([], False)