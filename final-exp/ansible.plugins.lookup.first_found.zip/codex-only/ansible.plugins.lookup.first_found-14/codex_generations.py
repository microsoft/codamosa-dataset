

# Generated at 2022-06-23 11:39:01.029149
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = True
    try:
        LookupModule()
    except:
        result = False

    assert result == True

# Generated at 2022-06-23 11:39:12.950575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import OrderedDict

    with open('tests/files/first_found_file_1', 'w') as f:
        f.write('first file')
    with open('tests/files/first_found_file_2', 'w') as f:
        f.write('second file')

    # fake variables to pass to the lookup
    variables = dict(
        ansible_playbook_basedir=os.path.dirname(os.path.dirname(__file__)),
        ansible_lookup_cache_dir='/var/lookup_cache',
        ansible_local=dict(
            paths=dict(
                basedir=os.path.dirname(os.path.dirname(__file__)),
            )
        )
    )

   

# Generated at 2022-06-23 11:39:22.743308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def item_to_str(r):
        return " ".join(r)

    def assert_run(terms, variables, expresult):
        result = LookupModule.run(LookupModule(), terms, variables)
        item_result = map(item_to_str, result)
        item_expresult = map(item_to_str, expresult)
        assert item_result == item_expresult

    assert_run(
        terms=['foo.1','foo.2','foo.3'],
        variables=dict(
            paths=['path/to/dir_1', 'path/to/dir_2'],
            files=['foo.1' , 'foo.2' , 'foo.3']
        ),
        expresult=["path/to/dir_1/foo.1"]
    )

    assert_run

# Generated at 2022-06-23 11:39:33.070699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock class to prevent the call to the real template and find_file_in_search_path
    class TestLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            super(TestLookupModule, self).__init__(*args, **kwargs)
            self.run_was_called = False
            self.subdir = None

        def template(self, var):
            return var

        def find_file_in_search_path(self, *args, **kwargs):
            path = None
            if self.subdir == 'files':
                path = 'path'
            self.subdir = None
            return path

    # unit test for an empty term to check exception is raised
    lookup_obj = TestLookupModule()

# Generated at 2022-06-23 11:39:35.201523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:39:43.736316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result1 = LookupModule('first_found').run(
        terms=['foo'],
        variables={'role_path': '', 'playbook_dir': ''},
        files=['/etc/passwd'],
        paths=[''],
        skip=True
    )
    assert result1 == ['/etc/passwd']
    result2 = LookupModule('first_found').run(
        terms=['foo'],
        variables={'role_path': '', 'playbook_dir': ''},
        files=['/etc/passwd'],
        paths=[''],
        skip=True
    )
    assert result2 == ['/etc/passwd']

# Generated at 2022-06-23 11:39:53.820227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    error = Exception()
    class TestTemplar:
        def template(this, fn):
            return fn

    class TestLookupModule(LookupModule):
        def find_file_in_search_path(this, variables, subdir, fn, ignore_missing=False):
            return fn
    test_instance = TestLookupModule()
    test_instance._templar = TestTemplar()

    # test1
    exp_path = "/path/to/foo.txt"
    total_search, skip = test_instance._process_terms(
        [
            {
                "files": "/path/to/foo.txt",
                "paths": "",
            },
        ],
        {}
    )

    total_search, skip = test_instance._process_terms([], {})

    # assert total_search


# Generated at 2022-06-23 11:39:58.268706
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    my_vars = dict(
        ansible_distribution='RedHat',
        ansible_os_family='RedHat',
    )
    with pytest.raises(AnsibleError):
        res = lookup_plugin.run([], my_vars)


# Generated at 2022-06-23 11:40:09.800289
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # 1) If file is not found, the function should raise an error
    # 1.1) Without providing paths and files values
    terms = ['example.txt']
    try:
        LookupModule().run(terms, variables, ansible_play_basedir = "~/Desktop")
    except AnsibleLookupError:
        assert True
    else:
        assert False

    # 1.2) Providing paths and files, but which don't exist
    terms = [{'files': ['example.txt'], 'paths': ['~/Desktop/Ansible/tests']}]
    try:
        LookupModule().run(terms, variables, ansible_play_basedir = "~/Desktop")
    except AnsibleLookupError:
        assert True
    else:
        assert False

    # 2) If skip has true value,

# Generated at 2022-06-23 11:40:20.896879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up plugin and mock environment
    lookup_plugin = LookupModule()
    lookup_plugin._templar = MagicMock()
    lookup_plugin.find_file_in_search_path = MagicMock()

    # Set up mock_args

# Generated at 2022-06-23 11:40:22.043176
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Setup
    module = LookupModule()

    # Test
    assert module

# Generated at 2022-06-23 11:40:24.196186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testobj = LookupModule()
    assert isinstance(testobj, LookupModule)



# Generated at 2022-06-23 11:40:24.572851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:40:30.998776
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create mock LookupBase
    mock_LookupBase = type('LookupBase', (object,), {'get_option': lambda self, key: None,
                                                      'set_options': lambda self, **kwargs: None,
                                                      'find_file_in_search_path': lambda self, variables, subdir, fn, ignore_missing: None})
    mock_LookupModule = type('LookupModule', (LookupModule, mock_LookupBase), {})

    # create mock templar
    mock_templar = type('Templar', (object,), {'template': lambda self, fn: fn})
    mock_variables = type('Variables', (object,), {'_templar': mock_templar()})

    # create mock 'self'
    #self = mock_LookupModule

# Generated at 2022-06-23 11:40:37.595876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule instance
    lm = LookupModule()

    # Create an AnsibleTemplate
    class AnsibleTemplate:
        def __init__(self):
            self.template = self._template

        def _template(self, fn):
            return fn

    # Create an AnsibleVariable
    class AnsibleVariable:
        def __init__(self):
            self.variables = self._variables

        def _variables(self, variables):
            return variables

    # Create an AnsibleFindFile
    class AnsibleFindFile:
        def __init__(self):
            self.find_file_in_search_path = self._find_file_in_search_path


# Generated at 2022-06-23 11:40:44.910745
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    from ansible.module_utils._text import to_bytes

    def my_find_file_in_search_path(*args, **kwargs):
        return os.path.join(args[3], 'files', 'bar.txt')

    # test good case
    terms = [u'/path/to/foo.txt', u'foo.txt', u'bar.txt']
    lookup_module = LookupModule(terms)
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.find_file_in_search_path = my_find_file_in_search_path

    files = lookup_module.run(terms, {})
    assert files is not None
    assert files[0] == to_bytes('/path/to/foo.txt')

    # test bad case


# Generated at 2022-06-23 11:40:57.986451
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    import shutil
    import pytest
    from ansible.utils import context_objects as co

    @pytest.fixture
    def tmppaths(request):
        tmpdir = tempfile.mkdtemp()
        orig_var_path = os.path.expanduser("~/.ansible/tmp")
        os.mkdir(orig_var_path)
        request.addfinalizer(lambda: shutil.rmtree(tmpdir))
        return tmpdir, orig_var_path

    @pytest.fixture
    def temp_roles_path(request, tmppaths):
        tmpdir, orig_var_path = tmppaths
        temp_roles_path = os.path.join(tmpdir, 'roles')

# Generated at 2022-06-23 11:41:09.849411
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get("first_found")

    search = lookup.run(terms=[
        'file1',
        {'files': 'file2', 'paths': '/path/to', 'skip': True},
        'file3',
    ], variables={})

    assert search == ['/path/to/file2']

    search = lookup.run(terms=[
        {'files': ['file1', 'file2'], 'paths': '/path/to', 'skip': True},
    ], variables={})

    assert search == []

    # when skip is not set or False, skip=False should be returned for backward compatibility
    search = lookup.run(terms=[
        {'files': 'file1', 'paths': '/path/to'}
    ], variables={})

# Generated at 2022-06-23 11:41:19.221807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2, b
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # test PY3 first
    if not PY2:
        class TestYamlObject(AnsibleBaseYAMLObject):
            @staticmethod
            def to_yaml(dumper, data):
                return dumper.represent_sequence(u'tag:yaml.org,2002:seq', data.value)

        class TestTerm(list):
            yaml_loader = TestYamlObject

            def __init__(self, items):
                super(TestTerm, self).__init__(items)
                self.value = items

        # no file found
        test_value = TestTerm([])
        assert LookupModule().run([test_value], None)

# Generated at 2022-06-23 11:41:25.563632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule class
    lookup_module = LookupModule()

    # Create path
    path = "first_found/tests/files/file.txt"

    # Run method run of LookupModule class
    result = lookup_module.run(terms=path, variables={})

    # Check result
    assert result == [path]


# Generated at 2022-06-23 11:41:27.763019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 11:41:38.196280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    # Test the failure of run method when skip option is not passed 
    lookup_module = LookupModule()
    terms = ['tests/lookup/test_test.yaml']
    with pytest.raises(AnsibleLookupError) as exc:
        lookup_module.run(terms, variables=[], skip=False)
    assert "No file was found when using first_found." in str(exc)
    # Test the success of run method when skip option is True
    lookup_module = LookupModule()
    terms = ['tests/lookup/test_test.yaml']
    assert lookup_module.run(terms, variables=[], skip=True) == []

# Generated at 2022-06-23 11:41:44.109296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_text
    def _stderr_contents(lookuperr):
        if isinstance(lookuperr, ansible.errors.AnsibleError):
            stderr = StringIO()
            lookuperr.display(stderr=stderr)
            return stderr.getvalue()
        return None

    import ansible.plugins.lookup.first_found
    lookup_module = ansible.plugins.lookup.first_found.LookupModule()

    # This test only has access to data within this module
    # No tests for params that look outside the module
    # No tests for 'file' values, since that is searched on the system
    # TODO: add tests for 'file' values, create temp dirs

# Generated at 2022-06-23 11:41:55.153775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # tuples of (
    #     args to run method,
    #     expected return,
    #     exceptions to raise during execution,
    #     side effects of execution,
    # )

    # first_found, paths=['/tmp/production', '/tmp/staging']
    # missing file in first, then find file in second

# Generated at 2022-06-23 11:41:58.735478
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert 'run' in dir(lookup_module)

# simple test to make sure it works at all

# Generated at 2022-06-23 11:42:00.683811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule instance
    lookup_module = LookupModule()
    # Instance was created
    assert lookup_module

# Generated at 2022-06-23 11:42:02.147254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test with empty list
    assert lookup_module._process_terms([], None, None) == ([], False)

# Generated at 2022-06-23 11:42:07.345474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize and set instance parameters
    terms = ['first.txt', 'second.txt', {'paths': ['pathone', 'pathtwo'], 'files': 'test.txt'},
                 {'paths': ['otherpath'], 'files': ['t1.txt', 't2.txt']}]
    variables = {}
    path = os.getcwd()
    module = LookupModule(terms, variables, path)

    # Call method under test
    result = module.run(terms, variables)

    # Assert result
    assert result == [os.path.join(path, 'pathone', 'test.txt')]

# Generated at 2022-06-23 11:42:09.524168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a module obj
    lm = LookupModule()
    # test constructor
    assert lm is not None

# Generated at 2022-06-23 11:42:21.140903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize
    # ToDo: Fill with actual data
    variables = {}
    kwargs = {}
    lookup_mod = LookupModule()

    # ToDo: Fill with actual data
    terms = ["D:/git/Training/ansible-netmiko/roles/lookup-first-found/tasks/file2.txt",
             {"files": "file1.txt", "paths": "D:/git/Training/ansible-netmiko/roles/lookup-first-found/tasks"}]
    result = ["D:/git/Training/ansible-netmiko/roles/lookup-first-found/tasks/file2.txt"]

    # Test
    # ToDo: Fix parameters if needed

# Generated at 2022-06-23 11:42:21.772678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-23 11:42:29.788872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    # define '_loader' for this test.
    class _loader:
        def __init__(self, path):
            self._data = path
    class _variable_manager(object):

        def __init__(self, _loader, path):
            self._loader = _loader(path)
            self._extra_vars = {}

        def get_vars(self):
            return self._extra_vars

        def get_vars(self, loader=None, play=None, task=None, include_hostvars=True, include_delegate_to=True):
            return self._extra_vars


# Generated at 2022-06-23 11:42:30.600639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:42:42.484352
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test case: 1
    # Should return the file found
    terms = ['a', 'b', 'c']
    kwargs = {
        'errors': 'ignore',
        'skip': False
    }

    # Complete the path
    def find(variables, subdir, filename, ignore_missing):
        if filename == 'a':
            return "1"
        else:
            return None

    variables = { }
    lkp = LookupModule()
    lkp._find_file_in_search_path = find
    lkp._templar = lambda f: f
    assert lkp.run(terms, variables, **kwargs) == ['1']

    # Unit test case: 2
    # Should return empty list as only file was found
    terms = ['a', 'b', 'c']


# Generated at 2022-06-23 11:42:54.851914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test requires test files to exist and is not an Ansible unit test.
    # It is not a unit test because the testing of the _process_terms method would be redundant.
    # This test is not standalone, it is invoked after test_LookupBase_find_file_in_search_path.
    # See module test for details on the test files.

    import pytest
    from ansible.module_utils.testing.sanity import sanity_check

    sanity_check.skip_if_missing_module('yaml')

    from ansible.plugins.lookup.first_found import LookupModule

    # Setup test files
    import tempfile
    import os
    import shutil
    orig_dir = os.getcwd()
    work_dir = tempfile.mkdtemp(prefix='ansible_test_lookup')
    os

# Generated at 2022-06-23 11:43:04.604989
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    look = LookupModule()

    assert look.run(terms=["./files/files_relative.txt"], variables=dict(play_hosts=['localhost'])) == ['./files/files_relative.txt']

    assert look.run(terms=["./files/files_relative.txt"], variables=dict(play_hosts=['localhost'])
                                                                , skip=True) == []

    assert look.run(terms=["./files/files_relative.txt"], variables=dict(play_hosts=['localhost'])
                    , skip=True, files=["./files/files_relative.txt"]) == []

# Generated at 2022-06-23 11:43:07.802432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test object
    lookup_module = LookupModule()

    # Create test data
    terms = ['foo.txt', 'bar.txt']
    variables = {}
    kwargs = {
        'skip': False
    }

    # Call method that is tested
    assert lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-23 11:43:20.792559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    def _jinja2_template(template):
        return template

    class _first_found(LookupModule):
        def find_file_in_search_path(self, variables, subdir, filename, **kwargs):
            test_files = {
                'files': [
                    'default_foo.conf',
                    ],
                'files/bar': [
                    'bar.txt',
                    ],
                }

            if filename in test_files[subdir]:
                return os.path.join(subdir, filename)

            return None


# Generated at 2022-06-23 11:43:24.924987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Basic unit tests for LookupModule.run() method.
    """
    lookup = LookupModule()

    assert lookup.run([], dict()) == [], "Empty search path did not produce empty result list."

    assert lookup.run(["example.txt"], dict()) == ["example.txt"], "Simple file name did not produce correct result."
    
    assert lookup.run(["example.txt", "example.yml", "test.txt"], dict()) == ["example.txt"], "Wrong first found file."

# Generated at 2022-06-23 11:43:32.584699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule = ansible.plugins.lookup.LookupModule

    # path is always relative to the task location,
    # exp format:   subdir/filename
    # subdir can be empty or missing
    def _mock_find_file_in_search_path(variables, subdir, filename, ignore_missing=True):
        if '/' not in filename:
            if filename in ['foo.txt', 'biz.txt']:
                return subdir + '/' + filename
            elif filename == 'bar.txt':
                return subdir.replace('dir1', 'dir2') + '/' + filename
            else:
                return None
        return filename

    def _mock_template(data):
        if data == '{{ inventory_hostname }}':
            return 'host'

# Generated at 2022-06-23 11:43:42.120820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    key_options = 'files,paths,skip'.split(',')
    # Helper to run the method with various args
    def run_method(method, files='file1, file2', paths='path1,path2', skip=False):
        # Construct a dummy AnsibleModule to use when looking up
        class DummyModule:
            def __init__(self, path):
                self.params = {}
                self.params['file'] = path
            def fail_json(self, *args, **kwargs):
                pass
        # TODO: integrate this sort of test into the normal unit test framework
        lookup = LookupModule()
        lookup.set_options({'files': files.split(','), 'paths': paths.split(','), 'skip': skip})
        for key in key_options:
            value = lookup.get

# Generated at 2022-06-23 11:43:50.849625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
     lm = LookupModule()


# Generated at 2022-06-23 11:43:53.170973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run([{'files': 'file1,file2', 'paths': '/path/to'}, 'file1'], {}) == ['/path/to/file1']

# Generated at 2022-06-23 11:43:54.377348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    first_found_module = LookupModule()
    assert first_found_module is not None

# Generated at 2022-06-23 11:44:04.378847
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:44:15.413134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import tempfile
    import types
    import unittest
    import shutil

    # import module snippets
    sys.path.append(os.path.join(os.path.dirname(__file__), '../..', 'unit', 'module_utils'))
    sys.path.append(os.path.join(os.path.dirname(__file__), '../..', '..'))

    from ansible.module_utils.facts import Facts

    # import plugin snippets
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..', 'lookup_plugins'))
    from ansible.plugins.lookup import first_found


# Generated at 2022-06-23 11:44:22.068653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of files
    # Test for a file in the same directory as the playbook
    options = {
        'files': [],
        'paths': []
    }
    terms = [
        'hello.py',
        'local.py',
        'world.py'
    ]
    lookup_module = LookupModule()
    _results = lookup_module.run(terms, options)
    # There is no file 'hello.py' in the same directory as the playbook
    # relative to the lookups directory
    assert len(_results) == 1
    assert 'local.py' in _results
    # Test with a dict with 'files' and 'paths' keys
    # Test for a file in a path configured in the dict
    # Test for a file in a path configured in the options

# Generated at 2022-06-23 11:44:34.471831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a lookupModule object
    lookup_module = LookupModule()
    # setting terms
    terms = "a.conf,b.conf"
    variables = {'a': 'foo'}
    kwargs = {'files': ["a.conf", "b.conf"], 'paths': ['/tmp/production', '/tmp/staging']}
    
    result = lookup_module._process_terms(terms, variables, kwargs)
    if (result[0] == ['/tmp/production/a.conf', '/tmp/staging/a.conf', '/tmp/production/b.conf', '/tmp/staging/b.conf'] and result[1] == False):
        print("test passed!")
    else:
        print("test failed!")

if __name__ == '__main__':
    test_Look

# Generated at 2022-06-23 11:44:35.426180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:44:40.596887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert type(lookup) == LookupModule

# Unit tests for constructor of class LookupModule
'''
test_LookupModule(unittest.TestCase):
    def test_none(self):
        lookup = LookupModule()
        self.assertEqual(lookup, LookupModule)
'''

# Generated at 2022-06-23 11:44:46.730145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    module = LookupModule()
    dataset = ['path/to/foo.txt', 'bar.txt', 'path/to/biz.txt']
    assert module.run(terms=dataset) == ['/path/to/foo.txt']
    assert module.run(terms=dataset, skip=True) == []
    dataset = ['foo', 'bar', 'biz']
    assert module.run(terms=dataset) == ["/bar/foo", "/foo", "/bar/biz"]
    assert module.run(terms=dataset, skip=True) == []

# Generated at 2022-06-23 11:44:48.548572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module



# Generated at 2022-06-23 11:45:00.160243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random

    result = None
    m = LookupModule()

    # setup templar for templates
    loader = DictDataLoader({
        None: {
            'template': '{{ item }}'},
        'files': {
            'foo_file': 'foo file content'
        }})
    inv = InventoryManager(loader=loader)
    m._templar = Templar(loader=loader, variables=inv.get_vars())

    # set subdir to files, otherwise can't find files
    m._subdir = 'files'

    # NOTE: needs to be a list
    terms = [{'files': 'foo_file_.txt', 'paths': '{{ item }}'}]

    # NOTE: needs to be a mapping
    variables = {
        'item': ['.', '/tmp'],
    }

   

# Generated at 2022-06-23 11:45:09.839769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ["files1", "files2"]
    variables = dict(files=["files3", "files4"], paths=["path1", "path2"])
    kwargs = dict()
    lookup.run(terms, variables, **kwargs)
    assert lookup.run(["undefined", "undefined"], dict(), **kwargs) == []
    assert lookup.run(terms, variables, **kwargs) == []
    assert lookup.run(["path1/files1", "path1/files2"], dict(), **kwargs) == []
    assert lookup.run(["path1/files1", "path1/files2"], variables, **kwargs) == []

# Generated at 2022-06-23 11:45:22.382024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: fix this
    # this test operation is not independent, will fail if run after other tests
    #     that use other lookups

    lookup = LookupModule()
    terms = [{"files": "file1"}]
    actual = lookup.run(terms, {})
    assert actual == []  # or you get an expected error

    terms = [{"paths": "/does/not/exist"}, "file1"]
    actual = lookup.run(terms, {})
    assert actual == []

    # make sure the file we look for actually exists
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'myfile')
    open(tmp_file, 'w').close()
    terms = [{"paths": tmp_dir}, "myfile"]

# Generated at 2022-06-23 11:45:24.804714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert type(result) == LookupModule


# Generated at 2022-06-23 11:45:33.481513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing _process_terms
    lm = LookupModule()
    expected = ['/path/to/foo.txt', '/path/to/bar.txt', '/path/to/biz.txt']
    test = []
    assert expected == lm._process_terms(['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt'], None, None)[0]

    # Testing multiple paths
    test = []
    expected = ['/path/to/foo.txt', '/other_path/to/foo.txt', '/path/to/bar.txt', '/other_path/to/bar.txt', '/path/to/biz.txt', '/other_path/to/biz.txt']
    lm = LookupModule()

# Generated at 2022-06-23 11:45:41.032560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run([], [])
    lookup.run(['a', 'b'], [])
    lookup.run([{'files': ['a', 'b']}, 'c'], [])
    lookup.run([{'files': [], 'paths': ['a', 'b']}, 'c'], [])
    lookup.run([{'files': ['a', 'b'], 'paths': ['a', 'b'], 'skip': True}, 'c'], [])



# Generated at 2022-06-23 11:45:43.299451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._subdir is None


# Generated at 2022-06-23 11:45:49.335309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.first_found import LookupModule

    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._fact_cache = None

    # check that the first file is found when two files
    # exist in the search paths 
    files = [
        "file1",
        "file2"
    ]
    paths = [
        "/path/to",
        "/path/to/other"
    ]
    expected_output = [
        "/path/to/file1"
    ]
    params = {"files": files, "paths": paths}

    output = lookup_module.run([params], None)
    assert output == expected_output

    # check that the correct file is found
    # when a third file exists

# Generated at 2022-06-23 11:45:57.103380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    lk._get_file_loader = lambda x: lk
    lk.find_file_in_search_path = lambda a, b, c, ignore_missing=False: '{}/{}/{}'.format(a, b, c)
    lk._templar = lambda x: '{}/'.format(x)
    lk._options = {}

    # test without find file
    lk.find_file_in_search_path = None
    assert lk.run('test') == []

    # test with find file
    lk.find_file_in_search_path = lambda a, b, c, ignore_missing=False: '{}/{}/{}'.format(a, b, c)

# Generated at 2022-06-23 11:46:08.296505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    source1 = '''
                    - name: test_first_found
                      copy:
                        src: "{{ lookup('first_found', terms)  }}"
                        dest: /some/file
                      vars:
                        terms:
                          - /path/to/foo.txt
                          - bar.txt  # will be looked in files/ dir relative to role and/or play
                          - /path/to/biz.txt
                    '''

# Generated at 2022-06-23 11:46:17.977114
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    display = Display()
    import os
    import logging
    testhost = os.path.abspath(__file__)
    testfile = os.path.join(os.path.dirname(testhost), 'test_file.yml')
    hostvars = {
        'inventory_hostname': 'testhost',
        'ansible_playbook_basedir': os.path.dirname(testfile),
        'ansible_path': os.path.dirname(testfile),
    }
    lookup = LookupModule(display=display)
    assert lookup.run([testfile]) == [testfile]
    #assert lookup.run([testfile], variables=hostvars) == [os.path.join(os.path.basename(testfile), testfile)]
   

# Generated at 2022-06-23 11:46:29.111462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        'vars': {},
        '_subdir': 'files',
        '_templar': None,
        '_loader': None,
        'basedir': None,
    }

    lookup_module = LookupModule(**args)

    # test _process_terms
    lookup_module.set_options(params={'files': ['a', 'b']})
    lookup_module.set_options(params={'paths': ['c', 'd']})

    terms = ['a']
    total_search, skip = lookup_module._process_terms(terms, args['vars'], {})
    assert terms == total_search
    assert skip is False

    terms = ['b']
    total_search, skip = lookup_module._process_terms(terms, args['vars'], {})
   

# Generated at 2022-06-23 11:46:38.693692
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()

    # test parsing string
    terms = 'file'
    files, paths, skip = lookup_plugin._process_terms(terms, variables=None, kwargs=None)[0]
    assert files == ['file']
    assert paths == []
    assert skip == False

    # test parsing string of two path
    terms = 'file,file2'
    files, paths, skip = lookup_plugin._process_terms(terms, variables=None, kwargs=None)[0]
    assert files == ['file', 'file2']
    assert paths == []
    assert skip == False

    # test parsing string of two path and one path
    terms = 'file,file2:path1'

# Generated at 2022-06-23 11:46:39.993586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a is not None

# Generated at 2022-06-23 11:46:48.283573
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TaskMock():
        def __init__(self):
            self.name = 'NAME_MOCK'
            self.dep_chain = []
            self.hidden = False
            self.environment = ['ENV_MOCK']
            self.module_vars = {}

    class PlayMock():
        def __init__(self):
            self.name = 'NAME_MOCK'
            self.dep_chain = []
            self.environment = []
            self.roles = []

    class PlayContextMock():
        def __init__(self):
            self.vars = {}

    class RunnerMock():
        def __init__(self):
            self.sudo = 'SUDO'
            self.sudo_user = 'SUDO_USER'
            self.su = 'SU'
            self.su

# Generated at 2022-06-23 11:46:50.367809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    assert hasattr(lookup, 'run')

# Generated at 2022-06-23 11:47:02.848015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock constants and variables
    terms = [
                {'files':'some_file', 'paths':'some_path1,some_path2'},
                {'files':'some_file', 'paths':'some_path1,some_path2'},
                {'files':'some_file', 'paths':'some_path1,some_path2'},
            ]
    variables = {}
    kwargs = {}
    subdir = getattr(LookupModule, '_subdir', 'files')

    # Mock find_file_in_search_path

# Generated at 2022-06-23 11:47:12.296100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    import os
    source_dir = os.path.dirname(os.path.realpath(__file__))
    test_path = os.path.join(source_dir, 'test_lookup_first_found.py')
    test_path2 = os.path.join(source_dir, '__init__.py')

    # Basic use
    # Test if a file is found
    first_found_plugin = lookup_loader.get('first_found')
    # Should find test_lookup_first_found.py
    found = first_found_plugin.run(['test_lookup_first_found.py'], None)
    assert found == [test_path]
    # Should find __init__.py

# Generated at 2022-06-23 11:47:19.268202
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # given
    terms = [
        '/test/one',
        {'paths': '/test/two'},
        {'files': 'a,b,c'},
    ]

    # with
    lu = LookupModule()

    # when
    lookup_result = lu.run(terms, {})

    # then
    assert lookup_result == ['/test/one', '/test/two/c']



# Generated at 2022-06-23 11:47:21.268994
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._subdir is None

# Generated at 2022-06-23 11:47:30.697857
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    lookup._subdir = 'role/vars/'

    templar = MockTemplar()

    lookup._templar = templar

    # create default list
    terms = terms_data[0]["terms"]
    kwargs = terms_data[0]["kwargs"]

    total_search, skip = lookup._process_terms(terms, dict(), kwargs)

    assert total_search == ['path/to/foo.txt', 'role/vars/bar.txt', 'path/to/biz.txt']

    # create search using dict instead of list
    total_search, skip = lookup._process_terms(terms_data[1]["terms"], dict(), terms_data[1]["kwargs"])


# Generated at 2022-06-23 11:47:33.456900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.first_found
    lookup = ansible.plugins.lookup.first_found.LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:47:41.192700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import tempfile

    class FakeAnsibleModule():
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def fail_json(self, *args, **kwargs):
            raise Exception('fail_json')

    def fake_get_option(self, option):
        return self.params.get(option)

    def fake_find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
        return os.path.join(self.search_path, subdir, fn)

    # backup args
    b_sys_argv = sys.argv

    for case in CASES:
        # get fake vars and options
        cvars = case.get('vars', {})
        coptions

# Generated at 2022-06-23 11:47:44.719137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test module constructor
    assert LookupModule

    # Test module class members
    assert LookupModule._plugins



# Generated at 2022-06-23 11:47:52.688465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [{'files': 'foo', 'paths': '/tmp/production,/tmp/staging'}, 'foobar,barfoo',['foo', 'bar']]
    variables = {'ansible_virtualization_type': 'kvm', 'ansible_distribution': 'Debian'}
    kwargs = {'skip': 'True'}
    for term in terms:
        lookup_module = LookupModule()
        total_search, skip = lookup_module._process_terms(term, variables, kwargs)
        assert len(total_search) > 0
        assert skip


# Generated at 2022-06-23 11:47:59.323721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import stat
    import tempfile

    # Build a temporary file system to test the first_found lookup
    # plugin. This lets us have a safe and portable test set up.
    file_system = {
        '/play_dir/tasks/main.yml': '',
        '/play_dir/roles/first/tasks/main.yml': '',
        '/play_dir/roles/first/files/first.txt': 'first.txt',
        '/play_dir/roles/second/tasks/main.yml': '',
        '/play_dir/roles/second/files/second.txt': 'second.txt'
    }
    dir_system = {}

    # Create a temporary file system and change to it
    cwd = os.getcwd()

# Generated at 2022-06-23 11:48:07.509743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import shutil
    import tempfile
    loader = '_foo'
    basedir = '_bar'
    env = 'test'
    tuple_args = (loader, basedir, env)
    tmp_dir = tempfile.mkdtemp()
    tmp_file1 = os.path.join(tmp_dir, 'file1')
    tmp_file2 = os.path.join(tmp_dir, 'file2')
    shutil.copy(__file__, tmp_file1)
    shutil.copy(__file__, tmp_file2)

    # Test __init__
    lm = LookupModule(*tuple_args)
    assert isinstance(lm, LookupBase)
    assert lm._loader == loader
    assert lm._basedir == basedir
    assert lm._tem

# Generated at 2022-06-23 11:48:20.010776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with term as a list
    t = ['foo.conf', 'bar.conf', 'biz.conf']
    l = LookupModule()
    found, skip = l._process_terms(t, None, {})
    assert skip is False
    assert found == t

    # Test with term as a single string
    t = 'foo.conf, bar.conf'
    found, skip = l._process_terms(t, None, {})
    assert skip is False
    assert found == ['foo.conf', 'bar.conf']

    # Test with term as a dict
    t = dict(
        files='foo.conf,bar.conf',
        paths='/tmp',
        skip=True
    )
    found, skip = l._process_terms(t, None, {})
    assert skip is True

# Generated at 2022-06-23 11:48:21.089082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:48:22.026195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-23 11:48:34.548650
# Unit test for constructor of class LookupModule
def test_LookupModule():
    input_terms = ['file1.txt', 'file2.txt']
    input_kwargs = {'files':'file1.txt,file2.txt', 'paths':'path1,path2'}
    input_variables = {'roles_path': '/path/to/roles/'}

    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    test_module = TestAnsibleModule(**input_kwargs)

    lookup_module = LookupModule()
    lookup_module.set_options({'parameter': 'value'})
    lookup_module.basedir = '/path/to/role/'
    lookup_module.set_loader(object)
    lookup_module.set_environment(test_module)

   

# Generated at 2022-06-23 11:48:35.754976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule("first_found")

# Generated at 2022-06-23 11:48:36.313156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:48:47.734209
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import tempfile

    # Create some temporary files
    t = tempfile.mkdtemp()
    f1 = tempfile.NamedTemporaryFile(dir=t)
    f2 = tempfile.NamedTemporaryFile(dir=t)
    f3 = tempfile.NamedTemporaryFile(dir=t)

    term = ['f1', 'f2', 'f3']

    # Initialize variables and options
    variables = {}
    options = {}

    # Create an object of LookupModule class
    lm = LookupModule()

    # Invoke run() method with parameters
    (total_search, skip) = lm._process_terms(term, variables, options)

    # Close temporary files
    f1.close()
    f2.close()
    f3.close()

    # Delete temporary

# Generated at 2022-06-23 11:48:55.546035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Test LookupModule.__init__() """

    # Try simple dict
    search = {'files': '*.txt', 'paths': '/path/to/foo', 'skip': True}
    terms = [search]
    variables = {}
    l = LookupModule()
    l._subdir = 'files2'
    (searchlist, skip) = l._process_terms(terms, variables, {})
    assert searchlist == ['/path/to/foo/' + search['files']]
    assert skip

    # Try dict with list, then simple string
    search = {'files': ['*.txt', '*.jpeg', '*.png'], 'paths': ['/path/to/foo', '/path/to/bar'], 'skip': True}
    terms = [search, '*.mp3']
    variables = {}


# Generated at 2022-06-23 11:49:06.146602
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    __LookupModule = LookupModule()

    with open("tests/fixtures/test-file.txt") as test_file:
        expected_text = test_file.read()

    # NOTE: this test requires that the test file is present in the path.
    # It also assumes  that the role 'parent' directory is in the path when
    # the test is run.

    # successful find in files/
    result = __LookupModule.run(terms=['test-file.txt'], variables={})
    assert type(result) is list
    assert os.path.basename(result[0]) == 'test-file.txt'
    with open(result[0]) as found_file:
        found_text = found_file.read()
    assert expected_text == found_text

    # successful find in files/files/
   