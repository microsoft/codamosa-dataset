

# Generated at 2022-06-23 11:39:01.957066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = 'ansible.plugins.lookup.first_found'
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    assert lm.run is not None



# Generated at 2022-06-23 11:39:04.656802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__ == ''

    assert LookupModule.run.__doc__ == '''Execute the lookup, with the given terms and variables.'''

# Generated at 2022-06-23 11:39:10.730096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create obj
    # ref: not sure this will be the way to do this, but it is working for now, need to add args
    # but from an argspec looks too complex
    lookup_obj = LookupModule()

    # method is callable
    assert callable(getattr(lookup_obj, 'run', None))

# todo: add tests for run method

# Generated at 2022-06-23 11:39:13.082791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._lookup_type == 'first_found'

# Generated at 2022-06-23 11:39:13.710768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:39:23.263096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupm = LookupModule()
    terms = [{'files': '/tmp/bar.txt,/tmp/foo.txt', 'paths': '/path/to/'}]
    variables, kwargs = {}, {}
    paths, skip = lookupm._process_terms(terms, variables, kwargs)
    assert paths == ['/path/to/bar.txt', '/path/to/foo.txt']
    assert skip == False
    assert lookupm.run(terms, variables, **kwargs) == []
    terms = [{'files': '/tmp/bar.txt', 'paths': '/path/to/'}]
    assert lookupm.run(terms, variables, **kwargs) == ['/path/to/bar.txt']

# Generated at 2022-06-23 11:39:33.447749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In order to get the file paths right, we need to make the ansible_builtin_runtime_path
    # be a relative path. This will allow us to load files in the current directory.
    # We will set this back to the original value, so that it won't interfere with any other tests.
    # In order to get all the modules and plugins to load, we need to "reset" the __file__ attribute
    # for the current file and for the directory that contains the current file.
    import ansible.plugins
    import ansible.utils.module_docs_fragments
    from ansible.utils.module_docs_fragments import _get_fragment_path
    import ansible.utils.module_docs_fragments
    from ansible.utils.module_docs_fragments import _get_fragment_path
   

# Generated at 2022-06-23 11:39:42.554514
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Normal operation, with terms in list
    terms = [dict(files = ['foo', 'bar'], paths = ['path1', 'path2'])]
    result = LookupModule().run(terms=terms, variables={}, ansible_options={})
    assert len(result) == 1
    assert result[0] == 'path1/foo'


    terms = [dict(files = 'foo', paths = ['path1', 'path2'])]
    result = LookupModule().run(terms=terms, variables={}, ansible_options={})
    assert len(result) == 1
    assert result[0] == 'path1/foo'

    terms = [dict(files = 'foo', paths = 'path1:path2')]
    result = LookupModule().run(terms=terms, variables={}, ansible_options={})

# Generated at 2022-06-23 11:39:43.819963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:39:50.388871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.params['file'] = 'tmp.yml'
    lookup = LookupModule(AnsibleModule(), dict(paths=['/tmp']))
    assert 'file' in lookup._options
    assert lookup._options['file'] == 'tmp.yml'
    assert 'paths' in lookup._options
    assert lookup._options['paths'] == ['/tmp']
    assert lookup._error_on_missing == False

# Generated at 2022-06-23 11:39:51.991952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    s = LookupModule()
    assert s is not None

# Generated at 2022-06-23 11:40:03.038181
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()

    # Test the error behavior of run
    with pytest.raises(AnsibleLookupError) as execinfo:
        lookup_plugin.run([], None)
    assert 'No file was found when using first_found' in str(execinfo.value)

    base_terms = [{'files': '*', 'paths': '/path/to/foo'}]
    variables = {}

    with pytest.raises(AnsibleLookupError) as execinfo:
        lookup_plugin.run(base_terms, variables)
    assert 'No file was found when using first_found' in str(execinfo.value)

    # Test the success behavior of run
    current_dir = os.path.dirname(os.path.realpath(__file__))

    search_path = os

# Generated at 2022-06-23 11:40:04.916756
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupBase) == type(LookupModule)

# Generated at 2022-06-23 11:40:07.136067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, '_templar')
    assert hasattr(lookup, 'run')

# Generated at 2022-06-23 11:40:17.306973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  assert lookup.run([
      '/path/to/foo.txt',
      'bar.txt',
      '/path/to/biz.txt',
    ],
    variables=None,
    skip=False,
  ) == ['/path/to/foo.txt']
  assert lookup.run([
      '/path/to/baz.txt',
      'bar.txt',
      '/path/to/biz.txt',
    ],
    variables=None,
    skip=False,
  ) == ['/path/to/baz.txt']
  assert lookup.run([
      '/path/to/baz.txt',
      'bar.txt',
      '/path/to/biz.txt',
    ],
    variables=None,
    skip=True,
  ) == []
  #

# Generated at 2022-06-23 11:40:18.638759
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == LookupBase.load('first_found', '', {})

# Generated at 2022-06-23 11:40:20.147188
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 11:40:22.249716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(LookupModule, terms, variables, **kwargs) == ["/etc/foo.conf"]

# Generated at 2022-06-23 11:40:32.512210
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule = LookupModule()

    # Test for multiple input parameters and nested data
    input_parameters = ['/etc/passwd', 'file1', 'file2']
    with open('/proc/version_signature') as fh:
        version = fh.read().strip()
    nested_data = ['{{ ansible_virtualization_type }}_foo.conf', "{0}_foo.conf".format(version)]
    # Test for input parameters
    assert lookupModule.run(input_parameters) == ['file1']
    # Test for nested data
    assert lookupModule.run(nested_data) == ["{{ ansible_virtualization_type }}_foo.conf"]

# Generated at 2022-06-23 11:40:34.006694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:40:37.589047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # TODO: remove
    print("TODO: LookupModule_run")
    pytest.skip(reason="TODO: LookupModule_run")


# Generated at 2022-06-23 11:40:44.910332
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a MockLookupModule
    lookup = LookupModule()

    # test with a single file
    ret = lookup.run(terms=['/root/foo.txt'], variables={'ansible_env': {'HOME': '/root'}})
    assert ret == ['/root/foo.txt']

    # test with a list of files
    ret = lookup.run(terms=['/root/foo.txt', '/root/bar.txt'], variables={'ansible_env': {'HOME': '/root'}})
    assert ret == ['/root/foo.txt']

    # test with a list of files and a path
    ret = lookup.run(terms=[{'files': '/root/foo.txt', 'paths':'/root/bar'}], variables={'ansible_env': {'HOME': '/root'}})

# Generated at 2022-06-23 11:40:49.635290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """This is a test to see if the constructor of class LookupModule works as expected"""

    #create an instance
    temp_instance = LookupModule()

    #check if it is an instance of LookupModule
    assert isinstance(temp_instance, LookupModule)

# Generated at 2022-06-23 11:41:01.566342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils.basic import AnsibleModule

    # on failure raises an exception
    module = AnsibleModule(argument_spec={})

    # include empty list as it is an empty input
    test_terms=[None, [], dict(), dict(files=[], paths=[]), dict(files='', paths=''), dict(files='does_not_exist.txt', paths='/tmp'), dict(files='does_not_exist.txt', paths='/etc')]
    l = LookupModule()

    result = l.run(test_terms, dict())
    assert result == []

    lookup_path = ""
    my_file = 'myfile.txt'
    test_terms.append(my_file)

# Generated at 2022-06-23 11:41:12.991739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_run_instance = LookupModule()

# Generated at 2022-06-23 11:41:21.120163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    lookup_plugin.first_found: LookupModule.run()
    """
    from ansible.module_utils._text import to_bytes

    import pytest
    from ansible.module_utils.six import StringIO

    #
    # Basic test of Run
    #
    file1 = ( '/here/is/my/file1.txt' )
    file2 = ( 'file2.txt' )
    file3 = ( '/there/is/my/file3.txt' )
    my_files = [ file1, file2, file3 ]
    my_paths = [ '/here/is/my', '/there/is/my' ]

    #
    # look up file1
    #
    result = LookupModule()
    result._templar = result.loader._templar
    result._check

# Generated at 2022-06-23 11:41:31.953737
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin._subdir='files'
    for spliters in [',', ';', ',']:
        termlist = _split_on(['/path/a.conf', 'b.conf', 'c.conf'], spliters)
        assert termlist == ['/path/a.conf', 'b.conf', 'c.conf']
        termlist = _split_on('/path/a.conf', spliters)
        assert termlist == ['/path/a.conf']
        termlist = _split_on('/path/a.conf', spliters)
        assert termlist == ['/path/a.conf']
        termlist = _split_on(['/path/a.conf, /path/b.conf'], spliters)

# Generated at 2022-06-23 11:41:43.337519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test with empty params
    assert lookup_module.run([], {}) == []

    # TODO: test with _subdir defined

    # test with a single 'file' param
    assert lookup_module.run(['foo'], {}) == ['foo']

    # test with a single 'file' param and a path
    assert lookup_module.run(['foo'], {}, paths=['/tmp']) == ['/tmp/foo']

    # test with a single 'file' param and 2 paths
    assert lookup_module.run(['foo'], {}, paths=[',/tmp,/etc']) == ['/tmp/foo', '/etc/foo']

    # test with a single 'file' param and 3 paths

# Generated at 2022-06-23 11:41:54.487978
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cPickle as pickle

    # Using real LookupModule object as a mock object
    # That is why need to use the same methods name and parameters
    # as in real Ansible objects
    class MockModule(LookupModule):

        def __init__(self, verbose=False):
            super(MockModule, self).__init__()

        @staticmethod
        def _load_name(buf):
            buf = StringIO(buf)
            unq = pickle.Unpickler(buf)
            try:
                return unq.load()
            except Exception:
                return None


# Generated at 2022-06-23 11:42:05.768354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import shutil
    import random
    import string
    import os

    # create temporary directory
    tempdir = tempfile.mkdtemp()

    # create temporary files
    file_list = []
    for x in range(0, random.randint(0, 100)):
        file_name = "".join([random.choice(string.ascii_letters) for i in range(0, random.randint(0, 100))])
        file = open(os.path.join(tempdir, file_name), "w")
        # add file to file_list for reference
        file_list.append(file_name)
        # close file
        file.close()

    # randomize file_list so there isn't a specific order
    random.shuffle(file_list)

    # create instance of Look

# Generated at 2022-06-23 11:42:10.256864
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["foo.txt", {'files': ['bar.txt', 'biz.txt'], 'paths': ['/tmp/production', '/tmp/staging']}]
    lookup_module = LookupModule()
    assert 'foo.txt' in lookup_module._process_terms(terms, '', '')[0]

# Generated at 2022-06-23 11:42:12.299186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the default constructor of class LookupModule"""
    lookup_module = LookupModule()
    assert lookup_module.templar is None

# Generated at 2022-06-23 11:42:23.642247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_object = LookupModule()
    terms = [{"files": ["data01.csv", "data02.csv", "data03.csv", "data04.csv"], "paths": ["/path1/data/", "/path2/data/", "/path3/data/"]},
             {"files": ["data10.csv", "data20.csv", "data30.csv", "data40.csv"], "paths": ["/path1", "/path2", "/path3"]}]
    variables = {}

    for term in terms:
        total_search, skip = LookupModule_object._process_terms(term, variables, {})
        assert isinstance(skip, bool)
        assert isinstance(total_search, Sequence)
        assert total_search != []

# Generated at 2022-06-23 11:42:24.888344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, "Failed to instantiate the LookupModule."

# Generated at 2022-06-23 11:42:31.313596
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os

    # Derived class to add the attributes usefull to tests
    class LookupModule_Test(LookupModule):
        def __init__(self, basedir=None, **kwargs):
            self._basedir = basedir
            self.warn_if_no_file = False
            super(LookupModule_Test, self).__init__(**kwargs)

        def find_file_in_search_path(self, variables, search_path, file_name, ignore_missing=False):
            file_found = None

            for directory in search_path:
                path = os.path.join(self._basedir, directory, file_name)

                # Check if file exists:
                if os.path.isfile(path):
                    file_found = path
                    break


# Generated at 2022-06-23 11:42:33.300524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None


# Generated at 2022-06-23 11:42:34.989531
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup != None



# Generated at 2022-06-23 11:42:36.614079
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 11:42:37.667300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No tests for this module"

# Generated at 2022-06-23 11:42:39.045709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:42:47.470224
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean


# Generated at 2022-06-23 11:42:56.744803
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    # assert default configuration
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') == False

    # assert that we produce no error when the passed files is a list
    lookup.set_options(var_options={}, direct={'files': []})

    # assert that we fail if the files variable is not a list
    options = {'files': 'foo.txt', 'paths': []}
    with pytest.raises(AnsibleLookupError, match=r"Invalid term supplied"):
        lookup.set_options(var_options={}, direct=options)

# Generated at 2022-06-23 11:43:01.160318
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    assert lookup.get_option('skip') == False
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []

# Generated at 2022-06-23 11:43:09.909724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _do_test(terms, variables, kwargs, expected):
        try:
            kwargs['errors'] = 'ignore'
        except KeyError:
            pass
        l = LookupModule()
        l.set_options(**kwargs)
        l._templar = DummyTemplar()
        actual = l.run(terms, variables, **kwargs)
        assert actual == expected, "'%s' does not match '%s'" % (actual, expected)
    # Test cases
    # no path given
    _do_test(
        terms=['/path/firstfile.txt', '/another/file.txt'],
        expected=[],
    )
    # existing path given

# Generated at 2022-06-23 11:43:22.682752
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test: tests the case where no file is found and skip is not true
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._templar = MockTemplar()
    lookup_module._loader = MockLoader()
    lookup_module_instance = lookup_module.run(terms=[{'files': 'foo1.txt', 'paths': './tests/lookup_plugins/first_found_test/file_list_1'}, 'foo2.txt', 'foo3.txt'], variables={'ansible_env': {'HOME': '/Users/sam'}})

# Generated at 2022-06-23 11:43:23.333253
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:43:25.016550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    l = LookupModule()
    l.run()

# Generated at 2022-06-23 11:43:35.860390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    f = open(os.path.join(tmpdir, 'test_file'), 'w')
    f.close()
    test_file_path = os.path.join(tmpdir, 'test_file')
    test_file_name = 'test_file'
    test_path1 = tmpdir
    test_path2 = os.getcwd()

    # test with a list of file names
    lookup = LookupModule()
    # simple file in current directory
    assert lookup.run([test_file_name], {})[0] == test_file_path
    # simple file in other directory
    assert lookup.run([test_file_name], {}, paths=[test_path1])[0] == test_file_path
    # multiple files on multiple paths


# Generated at 2022-06-23 11:43:38.179972
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert isinstance(lm._templar, LookupModule)

# Generated at 2022-06-23 11:43:39.626057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test we can create a LookupModule
    LookupModule()

# Generated at 2022-06-23 11:43:47.209538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = [
        {'files': 'foo', 'paths': '/some/path/:/some/other/path/', 'skip': False},
        {'files': 'foo', 'paths': '/some/path/:/some/other/path/', 'skip': False},
        {'files': 'foo', 'paths': '/some/path/:/some/other/path/', 'skip': False},
    ]

    variables = {'foo': 'bar'}

    # TODO: kwarges
    # kwargs = {}

    # TODO: more tests, this is basically only initial testing.
    assert module.run(terms, variables)

# Generated at 2022-06-23 11:43:58.302608
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test default lookup
    test_terms = [ 'test.txt' ]
    test_variables = {}
    test_kwargs = {}
    test_lm = LookupModule()
    assert test_lm.run(test_terms, test_variables, **test_kwargs) == []

    # test default lookup with skip
    test_terms = [ 'test.txt' ]
    test_variables = {}
    test_kwargs = {}
    test_lm = LookupModule()
    assert test_lm.run(test_terms, test_variables, skip=True, **test_kwargs) == []

    # test parameter lookup
    test_terms = [ {'files': 'test.txt', 'paths':'fake/path'} ]
    test_variables = {}

# Generated at 2022-06-23 11:44:03.298835
# Unit test for constructor of class LookupModule
def test_LookupModule():

    params = [
        {'files': ['a.txt'], 'paths': ['.']},
        {'files': ['a.txt']},
    ]

    for param in params:
        instance = LookupModule()
        result, skip = instance._process_terms(param, {}, {})
        assert len(result) == 1


if __name__ == "__main__":
    test_LookupModule()

# Generated at 2022-06-23 11:44:14.260125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    # create a mock playtarget
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{ lookup(\"first_found\", params) }}')))
             ]
        )


# Generated at 2022-06-23 11:44:21.475273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [
        {'files': ['file1', 'file2'], 'paths': ['path1', 'path2']},
        'file3',
        ['file4', 'file5'],
        {'files': ['file7', 'file8']},
        'file9',
    ]
    expected_results = [
        "path1/file1",
        "path1/file2",
        "path2/file1",
        "path2/file2",
        "file3",
        "file4",
        "file5",
        "file7",
        "file8",
        "file9",
    ]
    variables = {}
    kwargs = {}
    # Testing if method _process_terms returns the expected list of filenames
    total_

# Generated at 2022-06-23 11:44:33.905961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook import Playbook
    from ansible.plugins import lookup_loader
    from ansible.template import Templar
    from ansible.executor import task_queue_manager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='tests/inventory')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 11:44:34.812062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:44:45.293927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters for LookupModule.run
    terms = [
        '',
        [],
        ['file1'],
        ['file2'],
        [{'files': 'file1'}],
        [{'files': [['file1']]}],
        [{'files': [['file1'], 'file2']}],
        [{'files': [['file1'], 'file2'], 'paths': 'path1'}],
        [{'files': [['file1'], 'file2'], 'paths': ['path1', 'path2']}],
        [{'files': [['file1'], 'file2'], 'paths': ['path1', 'path2']}, 'file3'],
    ]

    # Expected output generated by LookupModule.run
    output

# Generated at 2022-06-23 11:44:58.054042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_fail(terms):
        # this is a bit of a hack but it allows us to reuse the main test structure
        # and also return python exceptions, which don't get caught by assertRaises
        # see https://stackoverflow.com/questions/2656322/in-python-how-do-i-programmatically-raise-a-raised-exception
        calls = 0
        _old_debug = None
        _old_display = None
        _old_verbosity = None

        def mock_debug(msg):
            nonlocal calls
            if calls == 0:
                assert msg.startswith("No file was found when using first_found.")
            calls += 1


# Generated at 2022-06-23 11:45:05.178420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock variable class
    class MockVariableManager:
        def __init__(self):
            self.vars = dict()

        def get_vars(self, loader, path, entities, cache=True):
            return self.vars

        def set_vars(self, vars_):
            self.vars = vars_

    # Create mock objects for testing
    class MockTerms(object):
        pass

    class MockFacts(object):
        pass

    class MockPlayContext(object):
        pass

    class MockTemplate(object):
        def __init__(self, loader):
            self.loader = loader

    class MockOptions(object):
        pass

    # Create a dict of mock options for testing

# Generated at 2022-06-23 11:45:06.596891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 11:45:09.658444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['file1', 'file2', 'vars/file3']
    lookups = lookup.run(terms, dict())

    assert len(lookups) == 1
    assert lookups == ['/etc/ansible/file1']


# Generated at 2022-06-23 11:45:22.224585
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = [{'files': 'default.conf, service.conf'}]
    variables = {}
    files, skip = lm._process_terms(terms, variables, {})
    assert files == ['default.conf', 'service.conf']
    assert skip is False

    terms = [{'files': 'default.conf, service.conf', 'skip': True}]
    variables = {}
    files, skip = lm._process_terms(terms, variables, {})
    assert files == ['default.conf', 'service.conf']
    assert skip is True

    terms = ['default.conf', 'service.conf']
    variables = {}
    files, skip = lm._process_terms(terms, variables, {})
    assert files == ['default.conf', 'service.conf']
    assert skip

# Generated at 2022-06-23 11:45:32.118890
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    self_obj = type("self_obj", (), {})();
    self_obj.find_file_in_search_path = lambda _1, _2, _3, _4: "/path/to/file"

    def test(terms_input, terms_output, search_output):
        total_search, skip = LookupModule._process_terms(self_obj, terms_input, {}, {})
        assert total_search == search_output
        assert skip == False

        result = LookupModule.run(self_obj, terms_output, {}, errors='ignore')
        assert result == ["/path/to/file"]


# Generated at 2022-06-23 11:45:38.015411
# Unit test for constructor of class LookupModule
def test_LookupModule():
    files = ["file1", "file2"]

    # call constructor without arguments
    params = {'_raw': ''}

    with pytest.raises(AnsibleLookupError) as excinfo:
        LookupModule(None, params, None, None)

    # call constructor with arguments
    params['_raw'] = files
    assert LookupModule(None, params, None, None)

# Generated at 2022-06-23 11:45:48.716137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test _split_on()
    testlist = lookup._split_on(["one,two", "three;four"])
    assert ["one", "two", "three", "four"] == testlist

    # mock class for templar
    class Templar(object):
        def __init__(self):
            pass
        def template(self, str):
            return str

    # mock class for variables
    class Vars(object):
        pass

    # mock class for module_utils
    class ModuleUtils(object):
        @staticmethod
        def run(terms, variables, **kwargs):
            return "a.txt"

    # mock class for lookup_base
    class LookupBase():
        def __init__(self):
            self._templar = Templar()
            self.run

# Generated at 2022-06-23 11:45:56.689706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock module util
    class MockLookupBase(LookupBase):
        def find_file_in_search_path(self, variables, loader, path, ignore_missing=False):
            # Mock method find_file_in_search_path
            if path == "file1.yml" or path == "file2.yml":
                return "/home/user/file1.yml"
            return None
    class MockTemplar:
        def template(self, value):
            return value

    lookup = LookupModule(loader=None, templar=MockTemplar())
    lookup._lookup_plugin = MockLookupBase()

# Generated at 2022-06-23 11:46:08.214203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # See https://github.com/mjhecht/ansible_testing/blob/master/test_lookup_plugins.py
    
    # Test the normal cases
    params = { 'files' : [ '/etc/hosts' ] , 'paths' : [ '/tmp' ] }
    terms = [ params ]
    variables = {}
    l = LookupModule()
    l.set_loader(None)
    l.set_inventory(None)
    l.set_templar(None)
    l._subdir = None
    results = l.run(terms, variables, **params)
    assert results[0] == '/etc/hosts', 'Expected /etc/hosts, but got: ' + results[0]
    print('Success')
    
    # Test without 'files'

# Generated at 2022-06-23 11:46:08.701383
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:46:16.102245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleLookupError
    terms = [
        '/etc/hosts',
        {'files': 'hosts', 'paths': '/etc'},
        {'files': 'hosts', 'paths': '/etc:/bin'},
        ['hosts', 'services'],
        {'files': 'hosts', 'paths': '/bin'}
    ]
    lookup = LookupModule()
    with pytest.raises(AnsibleLookupError):
        lookup.run(terms, variables={}, errors='ignore')

# Generated at 2022-06-23 11:46:27.906738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


    fake_loader = DataLoader()
    fake_templar = Templar(loader=fake_loader, variables=dict())

    good_paths = ['/foo', '/bar']
    good_files = ['good.txt', 'better.txt']
    good_terms = [{'paths': good_paths, 'files': good_files}]

    bad_paths = ['/bad', '/path']
    bad_files = ['bad.txt', 'worse.txt']
    bad_terms = [{'paths': bad_paths, 'files': bad_files}]

    good_path = '/foo/good.txt'

    test_good = Look

# Generated at 2022-06-23 11:46:37.986321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    x = LookupModule()
    lookup_opts = {
        'files': ['foo.conf', 'bar.conf'],
        'paths': ['vars/production', 'vars/staging'],
        'skip': False,
        'debug': False,
        'show_path': False}
    x.set_options(direct=lookup_opts)
    x.set_options(var_options={'ansible_distribution': 'Debian', 'ansible_os_family': 'Debian'})

    total_search, skip = x._process_terms(['', ''], {}, lookup_opts)
    assert len(total_search)

# Generated at 2022-06-23 11:46:39.244497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # tests
    expected = LookupModule()
    assert expected != None


# Generated at 2022-06-23 11:46:47.775897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.plugins.loader import lookup_loader

    class TestClass(unittest.TestCase):
        """
        This test class tests the lookup plugin first_found
        """

        def setup_class(self):
            self.terms = ["foo.txt", "bar.txt", "foobar.txt", "foo", "bar", "foobar"]
            self.files = [("foo.txt", True), ("bar.txt", True), ("foobar.txt", False)]
            self.files_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "files")
            self.default_subdir = "files"

# Generated at 2022-06-23 11:47:00.142394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = ['a.yml', 'b.yml']
    paths = ['paths_a', 'paths_b']

    terms = ['dict_a', 'dict_b']
    dict_a = dict(files=files, paths=paths, skip=False)
    dict_b = dict(files=files, paths=paths, skip=True)
    dict_terms = [dict_a, dict_b]

    kwargs = dict(files=files, paths=paths, skip=False)

    class DummyTemplar:
        def template(self, fn):
            return fn

    class DummyPlugin:
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            if ignore_missing:
                return fn


# Generated at 2022-06-23 11:47:02.197235
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    result = LookupModule()
    result.set_options({
        'files': 'some_file.txt',
        'paths': '.',
        'skip': False
    })
    print(result.run('some_file.txt'))

# Generated at 2022-06-23 11:47:10.227722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class LookupModule
    lookup = LookupModule()
    
    # Create instance of class AnsibleTemplar
    templar = AnsibleTemplar()
    
    # Create instance of class AnsibleVars (can't be mocked)
    variables = AnsibleVars(ignore_errors=False, variables=None)
    
    #Create instance of class AnsibleLoader (can't be mocked)
    loader = AnsibleLoader(None, variables=variables)
    
    # Add attributes to lookup object in order for the unit test to pass
    lookup._loader = loader
    lookup._templar = templar
    lookup._subdir = 'files'
    
    # Create a directory to contain the file to be used in the test

# Generated at 2022-06-23 11:47:12.116221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 11:47:13.093179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, {}, {}, None, None, None) is not None

# Generated at 2022-06-23 11:47:14.793075
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert type(lookup) == LookupModule

# Generated at 2022-06-23 11:47:16.497875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule('foo'))

# Generated at 2022-06-23 11:47:18.365538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:47:29.515485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic test
    search_dir = 'files'
    def_files = 'files'
    def_paths = 'files'
    def_skip = False

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 11:47:38.933183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup

    # Backup of original plugin, to restore it when test finish
    old_lookup_plugins = ansible.plugins.lookup.lookup_loader.lookup_plugins
    old_lookup_pristine = ansible.plugins.lookup.lookup_loader._lookup_plugins_peek

    # Mock of LookupBase class for test
    class LookupMock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # Mock version of LookupBase.find_file_in_search_path()

# Generated at 2022-06-23 11:47:40.113397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:47:41.584404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._subdir == 'files'

# Generated at 2022-06-23 11:47:50.068747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()

    terms = [
        {
            'files': 'file1',
            'paths': '/path1/'
        },
        {
            'files': 'file2,file3',
            'paths': '/path1/,/path2/'
        },
        {
            'files': 'file4',
            'paths': '/path3/'
        }
    ]
    variables = {}
    result = instance.run(terms, variables, debug=True)

    assert result == ['/path1/file1']



# Generated at 2022-06-23 11:47:57.100849
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # get the class we are testing
    test_class = globals()["LookupModule"]

    # setup the test class
    test_obj = test_class()

    # define the value for the argument `terms`
    terms = [[], [], []]

    # define the value for the argument `variables`
    variables = "dummy"

    # run the method
    result = test_obj.run(terms, variables)

    # Check the result
    assert result == []



# Generated at 2022-06-23 11:48:06.498642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    # NOTE: dict term, order is important
    terms = [
        {'files': 'bar', 'paths': '/a'},
        {'files': 'foo', 'paths': '/b', 'skip': False},
    ]
    total_search, skip = lm._process_terms(terms, dict(), dict())
    # NOTE: returns last 'skip'
    assert skip is False
    assert len(total_search) == 3
    # NOTE: will return 'path' in order of option setting, not order of terms!
    assert total_search == ['/a/bar', '/b/foo', {'files': 'foo', 'paths': '/b', 'skip': False}]

    # NOTE: list term, order is important

# Generated at 2022-06-23 11:48:08.116979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: create unit tests
    pass


# Generated at 2022-06-23 11:48:11.976899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('first_found', loader=None, templar=None)
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:48:22.997469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types

    l = LookupModule()
    l._subdir = 'files'

    # Test 1: Error: No module_utils/common/collections.py
    terms = ['/path/a', '/path/b']
    variables = {}
    kwargs = {}
    result = l.run(terms, variables, **kwargs)
    assert len(result) == 1
    assert result[0] == '/path/a'

    # Test 2: Error: No module_utils/common/collections.py
    terms = ['/path/a', '/path/b']
    variables = {}
    kwargs = {'files': '/path/b',
              'paths': '/path/b'}
    result = l.run(terms, variables, **kwargs)


# Generated at 2022-06-23 11:48:24.098809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule  # silence pyflakes

# Generated at 2022-06-23 11:48:30.951307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run([{'skip': True, 'paths': ['/tmp/production', '/tmp/staging']}], dict())
    lookup_plugin = LookupModule()
    lookup_plugin.run(['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt'], dict())

# Generated at 2022-06-23 11:48:32.982249
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    # Testing the __init__() method
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 11:48:43.644301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test lookup fails with error
    lookup_module = LookupModule()
    lookup_module._set_templar(None)

    # Test lookup fails with error
    terms = [{
        "files": "foo.bar",
        "paths": "/tmp"
    }]
    variables = {}
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(terms, variables)

    # Test lookup parser
    lookup_module = LookupModule()
    lookup_module._set_templar(None)
    terms = [{
        "files": "foo.txt,bar.txt",
        "paths": "/tmp,/tmp2"
    }, "test"]
    variables = {}
    total_search, skip = lookup_module._process_terms(terms, variables, {})

   

# Generated at 2022-06-23 11:48:53.437262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #pylint: disable=protected-access
    #pylint: disable=attribute-defined-outside-init
    lk = LookupModule()

    f = open('./first_found.txt', 'w')
    f.write('First found file')
    f.close()

    f = open('./second_found.txt', 'w')
    f.write('Second found file')
    f.close()

    # call protected method
    lk.set_loader()
    lk.set_environment()
    lk.set_fact_cache()

    # Test with a list of terms
    terms = ['./first_found.txt', './second_found.txt']

# Generated at 2022-06-23 11:49:04.819022
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=["tests/inventory"]))