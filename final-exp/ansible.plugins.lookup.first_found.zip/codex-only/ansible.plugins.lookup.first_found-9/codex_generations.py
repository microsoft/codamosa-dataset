

# Generated at 2022-06-23 11:39:00.210565
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test class creation
    _ = LookupModule()

# Generated at 2022-06-23 11:39:11.789557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add more unit tests
    terms = [
        {'files': 'ssh_host_dsa_key.pub ssh_host_rsa_key.pub', 'paths': '/etc/ssh'},  # string path and files
        {'files': ['ssh_host_dsa_key.pub', 'ssh_host_rsa_key.pub'], 'paths': '/etc/ssh'},  # list path and files
        {'files': ['ssh_host_dsa_key.pub', 'ssh_host_rsa_key.pub'], 'paths': ['/etc/ssh']},  # list path, list files
        {'files': ['ssh_host_dsa_key.pub', 'ssh_host_rsa_key.pub']}  # list files only
    ]
    variables = {}


# Generated at 2022-06-23 11:39:22.106585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import inspect
    import mock
    import os
    import re
    import sys
    import tempfile

    # Mock os.path.exists with side_effect
    with mock.patch('os.path.exists') as mock_exists:
        mock_exists.side_effect = lambda x: x in [
            '/tmp/propath/foo',
            '/tmp/propath/biz',
            '/tmp/propath/conf.d/abc',
            '/tmp/propath/conf.d/default.conf',
            '/tmp/propath/qux',
        ]

        # Mock SearchPath.search with side_effect

# Generated at 2022-06-23 11:39:24.803179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    del(lm)


# Generated at 2022-06-23 11:39:25.432694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:39:34.846470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    def get_plugin(plugin_type):
        return LookupModule(loader=loader)

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_source = dict(name="whatever", hosts='all', gather_facts='no', tasks=[])
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None

# Generated at 2022-06-23 11:39:35.782998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 11:39:44.082473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['file'], variables=dict()) == ['file']
    assert lookup.run(terms=[dict(files=['file'], paths=[])], variables=dict()) == ['file']
    assert lookup.run(terms=[dict(files=['file'], paths=['.'])], variables=dict()) == ['./file']
    assert lookup.run(terms=[dict(files=['file'], paths=['./path'])], variables=dict()) == ['./path/file']
    assert lookup.run(terms=[dict(files=['file', 'file2'], paths=['./path'])], variables=dict()) == ['./path/file', './path/file2']

# Generated at 2022-06-23 11:39:45.785673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 11:39:56.068977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given:
    _templar = MagicMock()
    _templar.template.side_effect = lambda fn: fn
    module = LookupModule(_templar)

    # When:
    # Then:
    assert module.run(['path/foo.txt'], {}) == ['path/foo.txt']
    assert module.run(['path/foo.txt', 'path/bar.txt'], {}) == ['path/foo.txt']

    # Given:
    _templar.template.side_effect = lambda fn: fn
    module = LookupModule(_templar)
    # When:
    # Then:
    assert module.run(['path/foo.txt', 'path/bar.txt'], {}) == ['path/foo.txt']

    # Given:
    module = LookupModule

# Generated at 2022-06-23 11:40:01.690042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test `LookupModule` object creation
    """

    from ansible.utils.display import Display
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    display = Display()
    vault_secrets = VaultLib(None, display)
    templar = Templar(display, vault_secrets=vault_secrets)

    lookup = LookupModule(templar)

    assert lookup
    assert lookup._templar == templar

# Generated at 2022-06-23 11:40:09.005229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    files = ["foo.txt", "bar.txt"]
    paths = ["/tmp"]
    terms = [files, paths]
    variables = {"files":files}
    kwargs = {"files":files}

    # recursive test
    total_search = []
    skip = []
    result = lookup._process_terms(terms, variables, kwargs)
    assert result == (total_search, skip)




# Generated at 2022-06-23 11:40:15.340857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    class MyLookupModule(LookupModule):
        pass
    my_lookup_module =  MyLookupModule()
    assert MyLookupModule is not None

# Generated at 2022-06-23 11:40:19.181677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

    files = [
        "foo",
        "bar",
        "baz"
    ]
    lookup_plugin.set_options(var_options={ "files": files })
    assert files == lookup_plugin.get_option("files")

# Generated at 2022-06-23 11:40:23.240718
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    # The test passes only if 'type(lookup_plugin) == LookupModule' returns 'True'
    assert type(lookup_plugin) == LookupModule

# Generated at 2022-06-23 11:40:25.154441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    assert test_LookupModule.run([], None) == []

# Generated at 2022-06-23 11:40:26.727104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None, 'Unable to instantiate class LookupModule'


# Generated at 2022-06-23 11:40:31.954326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['/tmp/'], variables={}) == ['/tmp']
    assert lookup.run(terms=['/tmp'], variables={}) == ['/tmp']
    assert lookup.run(terms=[], variables={}) == []


# Generated at 2022-06-23 11:40:34.171241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        assert False, 'Unable to instantiate: {0}'.format(e.message)

# Generated at 2022-06-23 11:40:35.589713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:40:36.592677
# Unit test for constructor of class LookupModule
def test_LookupModule():

    test = LookupModule()
    assert test is not None

# Generated at 2022-06-23 11:40:37.139041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:40:47.910274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    lookup_module = LookupModule()
    lookup_module._templar = 'hola'
    lookup_module._loader = 'bla'
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: '/path/to/file ' + fn if fn == 'b.txt' else None
    # When

# Generated at 2022-06-23 11:40:50.060154
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lu = LookupModule()

    assert isinstance(lu, LookupBase)

# Generated at 2022-06-23 11:40:56.560118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 11:40:58.137827
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:40:58.681350
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:41:00.829285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:41:02.511523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert cls.run is not None

# Generated at 2022-06-23 11:41:13.652872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {
            "files": ["test_file"],
            "paths": ["path1", "path2"]
        },
        {
            "files": "test_file2",
            "paths": "path3:path4"
        },
        {
            "files": ["test_file3"],
            "paths": ["path5", "path6"]
        }
    ]
    variables = {
        "_terms": ["test_file", "test_file2", "test_file3"],
        "_files": ["test_file", "test_file2", "test_file3"],
        "_paths": ["path1", "path2", "path3", "path4", "path5", "path6"]
    }
    lookup = LookupModule()
    assert lookup.run(terms, variables)

# Generated at 2022-06-23 11:41:19.386349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    builtin_open = open
    lk = LookupModule()

    if PY3:
        open_name = 'builtins.open'
    else:
        open_name = '__builtin__.open'

    builtins.open = None
    try:
        lk.run([], dict())
    except AnsibleLookupError as e:
        assert e.args[0].startswith('Unable to load LookupModule')
    else:
        raise AssertionError('Expected AnsibleLookupError to be raised. BUG!')
    finally:
        builtins.open = builtin_open

# Generated at 2022-06-23 11:41:30.563492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    inventory = loader.load_inventory(loader.load_from_file('tests/unit/ansible/inventory.yml'))
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    assert isinstance(LookupModule().run(['not', 'existing'], variable_manager, play_context=play_context), list)

    # TEST items that are ONLY included if in the path that the task is in

# Generated at 2022-06-23 11:41:32.740263
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_LookupModule = LookupModule()
    assert test_LookupModule


# Generated at 2022-06-23 11:41:43.879750
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import unittest
    import ansible.template as template
    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves import builtins

    class TestTemplar(template.Templar):

        def __init__(self, module_vars, loader):
            super(TestTemplar, self).__init__(module_vars, loader)

        def _add_toplevel_filters(self, filters):
            pass

    class TestLookupModule(LookupModule):

        _subdir = None
        _basedir = '/usr/local'

        def __init__(self, basedir=None, runner=None, templar=None, loader=None):
            self._templar = templar
            self._loader = loader
            self

# Generated at 2022-06-23 11:41:47.151451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupBase()
    assert module.lookup_type == "first_found"
    assert isinstance(module.DEFAULT_TERMS, string_types)
    assert module._plugins

# Generated at 2022-06-23 11:41:56.968254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # first argument for method run is the list of terms.
    terms = []

    # second argument for method run is a dict of variables
    variables = dict()

    # third argument for method run is a dict of keyword arguments
    kwarg = dict()

    # initialize first_found lookup
    lookup_module = LookupModule()

    # test case 1 - default test case
    # total_search
    # ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    # path
    # true
    # bar.txt
    # /files

    # to run this case, unmark the following comment
    # terms.append([
    #     '/path/to/foo.txt',
    #     'bar.txt',
    #     '/path/to/biz.txt',
    # ])



# Generated at 2022-06-23 11:42:08.642397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()

    # check initial constructor state of Lookup
    assert lu is not None
    assert lu.get_option('files') == []
    assert lu.get_option('paths') == []
    assert lu.get_option('skip') is False

    # check class methods
    options = {'paths': ['test/path1', 'test/path2'], 'files': ['test/file1', 'test/file2']}
    lu.set_options(var_options=None, direct=options)
    assert lu.get_option('files') == ['test/file1', 'test/file2']
    assert lu.get_option('paths') == ['test/path1', 'test/path2']
    assert lu.get_option('skip') is False

   

# Generated at 2022-06-23 11:42:16.349532
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyTemplar:
        def __init__(self):
            self.template_values = {}
            self.variables = {}

        def get_vars(self):
            return self.variables

    class DummyVariables:
        pass

    from ansible.parsing.vault import VaultLib

    dummy = DummyTemplar()
    dummy.template_values = {'var': 'var_value'}
    dummy.variables = {'var': 'var_value'}
    dummy.vault_password = VaultLib(None).decrypt()

    lookup_obj = LookupModule()
    lookup_obj._templar = dummy
    lookup_obj._loader = None
    lookup_obj._find_needle = lambda x, y, z: None


# Generated at 2022-06-23 11:42:17.479427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 11:42:19.029993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ll = LookupModule()
    assert ll == LookupModule()

# Generated at 2022-06-23 11:42:20.772651
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj._subdir is None

# Generated at 2022-06-23 11:42:21.864983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 11:42:29.839911
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Using a list of files
    lookup_module = LookupModule()
    lookup_module._loader = None
    lookup_module._templar = None
    result = lookup_module.run(terms=['foo'], variables={}, files=['foo'], paths=None, skip=True)
    assert result == ['foo'], result
    try:
        result = lookup_module.run(terms=['foo'], variables={}, files=['bar'], paths=None, skip=False)
    except:
        pass
    else:
        assert False, result
    assert lookup_module.run(terms=['foo'], variables={}, files=['bar'], paths=None, skip=True) == [], result

    # Using a dictionary (to set options)
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:42:34.186071
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule.__repr__() == '<ansible.plugins.lookup.first_found.LookupModule object at 0x7fa297bcc6a0>'


# Generated at 2022-06-23 11:42:35.879810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:42:45.953872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with empty terms
    terms = []
    variables = {}
    kwargs = {
        'files': [],
        'paths': [],
        'skip': False
    }
    l = LookupModule()
    total_search, skip = l._process_terms(terms, variables, kwargs)
    assert total_search == []
    assert skip == False

    # Test with valid terms but empty files and paths
    terms = [
        '/path/to/file1',
        '/path/to/file2',
        '/path/to/file3'
    ]
    variables = {}
    kwargs = {
        'files': [],
        'paths': [],
        'skip': False
    }
    l = LookupModule()

# Generated at 2022-06-23 11:42:48.240397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('', '', '', '', '', {}, {}, {}, {})


# Generated at 2022-06-23 11:42:58.195435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import BytesIO

    # TODO: these are not good tests...
    #       - a lot of code is not tested
    #       - the 'skip' option is not tested

    lm = LookupModule()
    # No file found
    lm._templar = None
    with pytest.raises(AnsibleLookupError) as e:
        lm.run({"files": ["dummy_file1.txt", "dummy_file2.txt"], "paths": ["dummy_path1", "dummy_path2"]})
    assert e.value.message == "No file was found when using first_found."

    # File found
    with open("dummy_file1.txt", "w") as text_file:
        text_file.write("ok1")

# Generated at 2022-06-23 11:43:04.508171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    # Return a list [path] when found
    assert l.run(['foo']) == ['foo']
    # Return an empty list when not found
    assert l.run(['bar'], None, skip=True) == []
    # Return an empty list in case of syntax error
    assert l.run(['{{ foo'], None, skip=True) == []

# Generated at 2022-06-23 11:43:08.331330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    terms = [{'files': '/etc/passwd', 'paths': '/etc/', 'skip': True}]
    total_search, skip = lookup._process_terms(terms, {}, {})
    assert '/etc/passwd' in total_search
    assert '/etc/' in total_search
    assert skip is True

# Generated at 2022-06-23 11:43:09.544487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:43:17.962335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test._subdir = 'files'
    test._templar = None
    result = test.run([], {})
    assert result == []


    # test_LookupModule_run_case1
    test = LookupModule()
    test._subdir = 'files'
    test._templar = None
    result = test.run(["file1", "file2"], {})
    assert result == []

# Generated at 2022-06-23 11:43:28.500760
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:43:29.661814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup is not None)



# Generated at 2022-06-23 11:43:38.066129
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = [
        {'files': 'foo,bar', 'paths': 'one,two'},
        [{'files': 'foo', 'paths': 'one'}, {'files': 'bar', 'paths': 'two'}],
        'foo',
    ]
    res, skip = lookup._process_terms(terms, {}, {})
    assert res == ['one/foo', 'two/foo', 'one/bar', 'two/bar', 'foo'], "Unexpected result: %s" % res
    assert skip is False, "Unexpected result: %s" % skip

# Generated at 2022-06-23 11:43:47.209676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    def teardown_module(module):
        # (module.)_files created by the lookup
        if hasattr(module, '_files'):
            for f in module._files:
                try:
                    os.remove(f)
                except OSError:
                    pass

    # setup
    lookup = LookupModule()
    testdir = os.path.dirname(os.path.realpath(__file__))
    datadir = os.path.join(testdir, 'data')
    lookup._basedir = datadir

    # config
    files = ['afile.txt', 'bfile.txt']
    paths = ['file1', 'file2']

    def create_files(lookup, files=files, paths=paths):
        # create data
        lookup._files = []
       

# Generated at 2022-06-23 11:43:58.307571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_result = []
    search_path = ['path1', 'path2']
    files_data = ['fileA', 'fileB', 'fileC']

    class test_templar:
        def template(self, param):
            return param

    # instantiation of class LookupModule
    lookup_obj = LookupModule()

    # mockup of find_file_in_search_path
    def find_file_in_search_path_mockup(variables, subdir, file, ignore_missing=True):
        lookup_result.append(file)
        return None

    lookup_obj.find_file_in_search_path = find_file_in_search_path_mockup
    lookup_obj._templar = test_templar()

    # call to the _process_

# Generated at 2022-06-23 11:44:00.995822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# TODO: test using dict does not work as expected
# TODO: test using list does not work as expected

# Generated at 2022-06-23 11:44:04.557418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Empty arguments
    lookup_module = LookupModule()
    assert(type(lookup_module) == LookupModule)

    assert (type(lookup_module._separator) == str)
    assert ('/' in lookup_module._separator)
    assert ('/' == lookup_module._separator[-1])



# Generated at 2022-06-23 11:44:15.452482
# Unit test for constructor of class LookupModule
def test_LookupModule():

    def empty_undefined_elem(terms, variables):
        return [variables.get('empty', None), variables.get('undefined', None)]


# Generated at 2022-06-23 11:44:16.378787
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: implement test
    pass

# Generated at 2022-06-23 11:44:29.494250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = Templar()

    # 1. File found from dict term
    search_results = [
        'files/foo.yml',
        'files/biz.yml',
        'files/bar.yml'
    ]
    fake_result = (
        ['files/foo.yml'],
        False
    )
    lookup_module.find_file_in_search_path = lambda variables, subdir, filename, ignore_missing: search_results.pop(0)

    term = dict(
        files=dict(
            paths=['/extra/path'],
            files=['foo.yml', 'biz.yml', 'bar.yml']
        )
    )
    result = lookup_module.run([term], dict())
   

# Generated at 2022-06-23 11:44:39.512413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    # These need to be moved to the fixturesdir, and a better approach used to find
    # them at runtime.
    sys.path.append('/usr/share/ansible/plugins/modules')
    from action.copy import ActionModule as amod

    am = amod(None)
    am._shared_loader_obj = None
    am._task = type('Task', (), {})()
    am._task._role_name = ''
    am._task.action = 'copy'
    am._task.args = {}
    am._task.module_vars = {}
    am._templar = None

    am._task.args = {}
    am._task.args['files'] = ['etc', 'usr']
    am._task.args['paths'] = ['/']
    am._task.args['skip']

# Generated at 2022-06-23 11:44:43.849011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test without subdir
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['foo'], variables={}, skip=False) == ['foo']

    # test with subdir
    lookup_plugin._subdir = 'roles'
    assert lookup_plugin.run(terms=['foo'], variables={}, skip=False) == ['roles/foo']

# Generated at 2022-06-23 11:44:45.959163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert 'test/test.txt' == module.run(terms=['test/test.txt'], variables=dict())[0]

# Generated at 2022-06-23 11:44:58.637331
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameter variable
    kwargs = {}
    kwargs['_terms'] = [
        {'files': 'foo.txt', 'paths': '/path/to/foo,/path/to/bar', 'skip': 'False'},
        {'files': 'bar.txt', 'paths': '/path/to/foo,/path/to/bar', 'skip': 'True'}
    ]

    # Unit test for method run of class LookupModule
    LM = LookupModule()

    # Test 1: set skip to True and no path to be found
    LM.run(['foo.txt'], {}, **kwargs)
    # Test 2: set skip to False and no path to be found


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:45:05.824745
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory


# Generated at 2022-06-23 11:45:12.764989
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_obj = LookupModule()

    # First test a string
    term = 'test/test.yml'
    variables = None

    expected_ret = [term]

    ret = lookup_obj._process_terms(term, variables, None)
    assert ret[0] == expected_ret
    assert ret[1] == False

    # test a dict with files and paths
    term = {
        'files': 'test/test.yml',
        'paths': 'test/'
    }

    variables = None
    expected_ret = [
        os.path.join('test/', 'test/test.yml'),
    ]

    ret = lookup_obj._process_terms(term, variables, None)
    assert ret[0] == expected_ret
    assert ret[1] == False
    # test a dict

# Generated at 2022-06-23 11:45:24.913639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = Mapping()
    lookup._templar.template = lambda x: x
    lookup._subdir = 'files'
    lookup.find_file_in_search_path = lambda x, y, z, **kwargs: 'return_path'
    assert lookup.run(['term']) == ['return_path']
    assert lookup.run(['term'], {}, skip=False) == ['return_path']
    assert lookup.run(['term'], {}, skip=True) == ['return_path']
    assert lookup.run(['term'], {}, skip=True, files=['.'], paths=[]) == []
    assert lookup.run(['term'], {}, skip=True, files=['.'], paths=[{'paths': '/path'}]) == []


# Generated at 2022-06-23 11:45:33.791744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins import lookup_loader

    loader = lookup_loader.get("first_found")

    assert loader.lookup("", {}, "") == []
    assert loader.lookup("default.conf", {"vars": {"ansible_virtualization_type": "not-kvm"}}, "") == ["default.conf"]
    assert loader.lookup("default.conf", {"vars": {"ansible_virtualization_type": "kvm"}}, "") == ["default.conf"]
    assert loader.lookup("default.conf", {}, "") == ["default.conf"]
    assert loader.lookup("foo.conf", {"vars": {"ansible_virtualization_type": "kvm"}}, "") == ["kvm_foo.conf"]

# Generated at 2022-06-23 11:45:34.461140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:45:45.966104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    result = x.run(terms=[{'files': 'adam.txt', 'paths': 'AdamFiles'}, {'files': 'dave.txt', 'paths': 'DaveFiles'}], variables={})
    assert result == ["adam.txt", "dave.txt"]

    result = x.run(terms=['adam.txt', 'dave.txt'], variables={}, files='adam.txt', paths='AdamFiles')
    assert result == ["adam.txt"]

    result = x.run(terms='adam.txt,dave.txt', variables={}, files='adam.txt', paths='AdamFiles')
    assert result == ["adam.txt"]

    result = x.run(terms='adam.txt,dave.txt', variables={}, paths='AdamFiles')

# Generated at 2022-06-23 11:45:54.777221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variables = {}
    loader = None
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variables)

    lookup = LookupModule(variables=variables, loader=loader, play_context=play_context, templar=templar)
    lookup.basedir = 'lookup_plugins/files'

    search = [
        {'files': 'foo,bar', 'paths': '/path1,/path2'},
        'spam,eggs',
        {'files': 'foo,spam', 'paths': '/path1/bar,/path2/bar'},
    ]

    # Case 1: Template error is thrown

# Generated at 2022-06-23 11:46:02.288399
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Define some test values
    terms = [
        '/path/to/foo.txt',
        {'files': 'bar.txt', 'paths': '/extra/path'}
    ]

    # test with skip = True
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'skip': True})
    result = lookup_instance.run(terms=terms, variables={})
    assert result == [], "test_LookupModule_run::test#1 failed."

    # test with skip = False
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'skip': False})
    result = lookup_instance.run(terms=terms, variables={})

# Generated at 2022-06-23 11:46:05.206713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check base class
    assert issubclass(LookupModule, LookupBase)
    # check instance of class LookupModule
    assert isinstance(LookupModule(None), LookupBase)

# Generated at 2022-06-23 11:46:16.372931
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupBase, LookupModule
    from ansible.module_utils.common._collections_compat import Sequence
    import ansible.utils.unsafe_proxy

    class LookupModule2(LookupModule):

        def find_file_in_search_path(self, variables, type, fn, ignore_missing=False):
            return fn

    def _test_run(terms, variables, kwargs, expected):
        lookup = LookupModule2()
        result = lookup.run(terms, variables, **kwargs)
        assert result == expected, "expected {0}, got {1}".format(expected, result)

    # test terms is string
    _test_run("../hello.txt", {}, {}, ["../hello.txt"])

    # test terms is list and list has term like

# Generated at 2022-06-23 11:46:28.364295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule._run() returns a list of a files that exist first """
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.errors import AnsibleLookupError

    # Mock calls to os.path.exists
    # First exists call for file1.txt
    mock_exists_1 = patch('ansible.plugins.lookup.first_found.os.path.exists')
    mock_exists_1.start()
    mock_exists_1.return_value = True
    # Secondly exists call for file2.txt
    mock_exists_2 = patch('ansible.plugins.lookup.first_found.os.path.exists')
    mock_exists_2.start()

# Generated at 2022-06-23 11:46:38.242331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    result = lookup.run([['/path/to/file1.txt','/path/to/file2.txt','file2.txt']], dict(ansible_user_dir='/root/ansible', ansible_facts=dict(os_family='RedHat')))
    if result != ['/root/ansible/roles/role_under_test/files/file2.txt']:
        return (False, "Unexpected result for path, expected: '/root/ansible/roles/role_under_test/files/file2.txt', but got: {}".format(result))


# Generated at 2022-06-23 11:46:38.742132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:46:47.639075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    variables = dict()
    variables["_original_file"] = "some_file"
    # testing if return is a empty list when no file is found and skip is set to True
    assert lookup.run([], variables, files=["foo.txt", "bar.txt"], paths=["/tmp/production", "/tmp/staging"], skip=True) == []
    # testing if exception is raised when a file is not found and skip is set to False
    try:
        lookup.run([], variables, files=["foo.txt", "bar.txt"], paths=["/tmp/production", "/tmp/staging"], skip=False)
    except AnsibleLookupError as e:
        assert str(e) == "No file was found when using first_found."
    # testing if

# Generated at 2022-06-23 11:46:59.041944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Testing method LookupModule.run"""
    
    dummy_results = ""
    test_path = "test_path"
    test_fn = "test_fn"

    def test_find_file_in_search_path(variables, subdir, fn, ignore_missing=False):
        return test_path

    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = test_find_file_in_search_path

    dummy_variables = []
    dummy_kwargs = dict(
        files=test_fn
    )

    results = lookup_module.run(dummy_results, dummy_variables, **dummy_kwargs)

    assert results == [test_path]

# Generated at 2022-06-23 11:47:00.539499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert look is not None


# Generated at 2022-06-23 11:47:07.456724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up test
    terms = ['a']
    variables = {}
    kwargs = {}

    # create object
    look = LookupModule()

    # verify instance
    assert(isinstance(look, LookupModule))

    # temporary fix test in lookupbase, when fixed remove this
    look._subdir = 'files'

    # run test
    results = look.run(terms, variables, **kwargs)
    # verify results
    assert(results == [])


# Generated at 2022-06-23 11:47:16.814808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.set_options(var_options={}, direct={})
    assert lm.get_option('files') == [], 'files option not set'
    assert lm.get_option('paths') == [], 'paths option not set'
    assert lm.get_option('skip') == False, 'skip option not set'
    assert lm.get_option('errors', default='strict') == 'strict', 'erros option not set'

    lm.set_options({})
    assert lm.get_option('files') == [], 'files list not empty'
    assert lm.get_option('paths') == [], 'paths list not empty'
    assert lm.get_option('skip') == False, 'skip is not False'


# Generated at 2022-06-23 11:47:28.617947
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l._subdir = 'files'  # as set by task executor

    def find_file_in_search_path_FAKE_FUNC(var, subdir, fn, ignore_missing):
        if fn == 'a/b/c':
            return fn
        return None

    l.find_file_in_search_path = find_file_in_search_path_FAKE_FUNC

    lookup_options = {}
    lookup_options['skip'] = False

    def get_option_FAKE_FUNC(key):
        return lookup_options[key]

    l.get_option = get_option_FAKE_FUNC

    def set_options_FAKE_FUNC(var_options, direct):
        lookup_options['files'] = ['a/b/c']

   

# Generated at 2022-06-23 11:47:29.889510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj != None


# Generated at 2022-06-23 11:47:39.233988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.get_option('files') == []
    assert lm.get_option('paths') == []
    assert lm.get_option('skip') is False

    lm = LookupModule(files='a.txt')
    assert lm.get_option('files') == ['a.txt']
    assert lm.get_option('paths') == []
    assert lm.get_option('skip') is False

    lm = LookupModule(files='a.txt', paths='.')
    assert lm.get_option('files') == ['a.txt']
    assert lm.get_option('paths') == ['.']
    assert lm.get_option('skip') is False

    lm = LookupModule(paths='.', skip=True)

# Generated at 2022-06-23 11:47:40.194946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:47:51.324462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: this is a very bad test.  It shouldn't depend on the local filesystem.
    lookup = LookupModule()
    # file does exist
    results = lookup.run(['files/first_file'], [])
    assert results == ['/home/bm/workspace/ansible/lib/ansible/plugins/lookup/files/first_file']
    # file and path exists
    results = lookup.run(['files/first_file', {'paths': '/home/bm/workspace/ansible/lib/ansible/plugins/lookup'}], [])
    assert results == ['/home/bm/workspace/ansible/lib/ansible/plugins/lookup/files/first_file']
    # file and path exists but no skip
    import copy

# Generated at 2022-06-23 11:47:52.762445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 11:47:59.374101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader

    # create a simple temp file to work with
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file_name = tmp_file.name

    # a simple test file that the lookup searches for
    test_file = 'test_file'
    tmp_file = tempfile.NamedTemporaryFile(mode='w+t', dir=os.getcwd(), delete=False)
    tmp_file.write(test_file)
    tmp_file.close()

    # create a lookup that searches for a file
    lookup = lookup_loader.get('first_found')

    # create a context and loader for the lookup
    context = {}
    loader = Data

# Generated at 2022-06-23 11:48:01.425983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 11:48:08.277218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    lm = LookupModule()
    lm._templar = DummyTemplar()

    # Set up a dummy search path
    mock_loader = DummyLoader()
    mock_loader.paths = os.getcwd()

    lm._loader = mock_loader

    # Use a ControlResolver as a no-op
    mock_resolver = DummyResolver()
    lm._resolver = mock_resolver

    # Set up dummy content
    mock_file = 'test.txt'
    mock_file_content = "This is the content of the test file."

# Generated at 2022-06-23 11:48:20.550090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Testing for expected AnsibleLookupError exception
    with pytest.raises(AnsibleLookupError) as excinfo:
        assert lookup_module.run([], {})
    assert 'No file was found when using first_found.' in str(excinfo.value)
    # Testing for expected AnsibleLookupError exception
    with pytest.raises(AnsibleLookupError) as excinfo:
        assert lookup_module.run([{'files': 'foo', 'paths': 'bar'}], {})
    assert 'No file was found when using first_found.' in str(excinfo.value)
    # Testing for expected AnsibleLookupError exception

# Generated at 2022-06-23 11:48:27.889031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with first_found lookup with terms of type string
    terms = [
        'test_files', 'test_files2'
    ]
    lookup_module.run(terms = terms, variables = {})

    # Test with first_found lookup with terms of type list
    terms = [
        ['test_files', 'test_files2'],
        ['test_files', 'test_files2'],
    ]
    lookup_module.run(terms = terms, variables = {})

    # Test with first_found lookup with terms of type dictionary
    terms = [
        { 'files': 'test_files', 'paths': 'test_dir'},
        { 'files': 'test_files2', 'paths': 'test_dir2'}
    ]
    lookup_module.run

# Generated at 2022-06-23 11:48:38.314422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for run with no errors
    import pytest
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3

    collection_lookup = LookupModule()

# Generated at 2022-06-23 11:48:49.799851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: during refactor noticed that the 'using a dict' as term
    # is designed to only work with 'one' otherwise inconsistencies will appear.
    # i) seeing dicts merged (overwritten) see above
    # ii) 'skip' is only handled at the end, and has to be passed in 'last'
    # NOTE: this test uses a dict to test all cases exactly as the code handles them.

    # setup test
    t = LookupModule()
    t._subdir = 'files'

    # use templates to ensure the variables are replaced

# Generated at 2022-06-23 11:48:50.300307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:49:01.219374
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import from __main__ context to avoid import loop
    from ansible.playbook.play_context import PlayContext

    # some inputs to file lookup
    terms = [
        'yo',
        {'files': 'foo', 'paths': 'xyz'},
        {'files': 'foo;bar', 'paths': 'xyz,abc'},
        {'files': 'foo', 'paths': 'xyz,abc'},
        'one',
        ['two', 'three'],
        'four',
        ['five', {'files': 'six', 'paths': 'xyz'}],
    ]

    # setup a play context
    variables = PlayContext()

    # setup lookup
    lookup = LookupModule()

    # run lookup