

# Generated at 2022-06-23 11:39:10.391185
# Unit test for constructor of class LookupModule
def test_LookupModule():
    values1 = [['a.txt', 'b.txt', 'c.txt'], ['d/', 'e/', 'f/'], ['foo.txt', 'bar.txt', 'baz.txt'], ['--skip']]
    values2 = [['a.txt', 'b.txt', 'c.txt'], ['d/', 'e/', 'f/'], ['foo.txt', 'bar.txt', 'baz.txt'], ['--skip', '--foo']]

    module = LookupModule()
    module.get_option = lambda x: x
    module.set_options = lambda x1, x2: None
    module.find_file_in_search_path = lambda a, b, c, d: 'ret'

    result1 = module._process_terms(values1, None, None)
   

# Generated at 2022-06-23 11:39:11.830959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an object of the LookupModule class
    lm = LookupModule()
    assert lm


# Generated at 2022-06-23 11:39:22.146125
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking Input Variables
    moduleArgs = dict(
        _terms=[{'files': 'file1,file2', 'paths': '/tmp/production,/tmp/staging'}
                , {'files': 'file3,file4', 'paths': '/tmp/production/dir1,/tmp/staging/dir2'}],
        _task_vars={'role_path': "/Users/abcd/myrole/tasks/main.yml"},
        _role_path="/Users/abcd/myrole",
        _role_name="myrole",
        _loader=dict(
            _basedir="/Users/abcd/myrole/tasks/main.yml",
            path_plugins=["/Users/abcd/myrole/filter_plugins"]
        )
    )

    # Mocking actual

# Generated at 2022-06-23 11:39:30.766064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = [
        {'files': 'foo.bar', 'paths': '.'},
        'foo.bar',
        ['foo.bar', 'bar.foo']
    ]
    variables = {}
    kwargs = {}
    lookupModule = LookupModule()
    lookupModule._find_file_in_search_path = lambda x, y, z: y+'/'+z

    # Act
    retval = lookupModule.run(terms, variables, **kwargs)

    # Assert
    assert retval == ['./foo.bar']


# Generated at 2022-06-23 11:39:41.369522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    import os

    terms = [
        {
            'files': 'foo.txt,bar.txt',
            'paths': 'vars,host_vars,group_vars',
            'skip': True
        }, 'vimrc',
        [
            {
                'files': 'foo.txt,bar.txt',
                'paths': 'vars,host_vars,group_vars',
                'skip': True
            }, 'vimrc'
        ]
    ]

    if PY3:
        from importlib import reload
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader

    lookup_instance = lookup_

# Generated at 2022-06-23 11:39:47.977429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # basic search
    terms = ['file_in_play', 'file_in_role']
    terms_with_subdir = os.path.join(os.curdir, 'subdir', 'file_in_play')
    subdir = 'subdir'

    # Create a path to test file_in_play
    lookup._subdir = subdir
    lookup._basedir = os.path.join(os.curdir, subdir)
    lookup._loader = DictDataLoader()
    lookup._loader.set_basedir(lookup._basedir)

    # Create file_in_play
    f = open(os.path.join(lookup._basedir, terms[0]), 'a')
    f.close()

    # Create file_in_role

# Generated at 2022-06-23 11:39:49.982464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l=LookupModule()
    #l.run(terms,variables,**kwargs)
    assert True

# Generated at 2022-06-23 11:40:00.504423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing function run of class LookupModule")
    import os
    import sys
    import inspect
    from ansible.parsing.dataloader import DataLoader  # noqa pylint: disable=unused-import
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0,parentdir)

    from ansible.plugins.lookup.first_found import LookupModule

    lookup_obj = LookupModule()
    # Testing with given test_file
    lookup_obj.set_options(direct={'files': 'test_file', 'paths': os.path.join(parentdir,'test_files')})

# Generated at 2022-06-23 11:40:08.785659
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.plugins.lookup.first_found import LookupModule

    l = LookupModule()
    # test defaults
    assert l.get_option('files') == []
    assert l.get_option('paths') == []
    assert l.get_option('skip') == False

    l = LookupModule(loader=None, templar=None)
    # test defaults
    assert l.get_option('files') == []
    assert l.get_option('paths') == []
    assert l.get_option('skip') == False


# Generated at 2022-06-23 11:40:13.342698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Testing when raise an error
    with pytest.raises(AnsibleLookupError) as err:
        lookup.run([], [])

    assert str(err.value) == "No file was found when using first_found."

    # Testing when no files found, but skip is True
    lookup.run([{'files': None, 'paths': None, 'skip': True}], []) == []

# Generated at 2022-06-23 11:40:22.524188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing class
    lookup = LookupModule()

    # Mock the templar class, so we don't actually try to render some jinja2
    # code that is not present in the test environment.
    lookup._templar = type('Templar', (), {'template': lambda self, value: value})

    # Mock the find_file_in.. method to simply return the value of the file name
    # for all the tests bellow in this test_LookupModule_run() function.
    # This avoids tests errors, since the find_file_in.. method simply raises
    # an exception if the file is not found.
    # In our case, we don't try to actually find the file, since we don't
    # have the whole ansible code base to do that, and we don't need to. We
    # just want to test the behaviour

# Generated at 2022-06-23 11:40:34.126628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test of the run method of LookupModule.
    See: https://travis-ci.org/ansible/ansible/jobs/366799982
    """

    import os
    import tempfile
    import pytest

    def create_files(file_list, directory):
        """Create files in the specified directory."""

        for filename in file_list:
            full_filename = os.path.join(directory, filename)
            if not os.path.exists(full_filename):
                os.mknod(full_filename)

    def make_fake_file_list(file_list, directory):
        """Return a list of fake file names."""

        fake_file_list = []

        for filename in file_list:
            full_filename = os.path.join(directory, filename)
            fake_

# Generated at 2022-06-23 11:40:45.945555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(
        [
            {
                'files': ['file1', 'file2', 'file3'],
                'paths': ['/path/to', '/path/to2'],
            },
            {
                'files': ['file4', 'file5', 'file6'],
                'paths': ['/path/to', '/path/to2'],
            },
        ],
        {},
    ) == ['/path/to/file1']


# Generated at 2022-06-23 11:40:53.053380
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    t.set_options(var_options=None, direct={'skip': True})
    t.set_options(var_options=None, direct={'paths': "c:\;d:\,e:\:/tmp:/usr/local/bin"})
    t.set_options(var_options=None, direct={'files': "f1.txt;f2.txt,f3.txt:f4.txt"})

# Generated at 2022-06-23 11:40:54.350120
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test

# Generated at 2022-06-23 11:41:03.265956
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:41:14.394029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    self = LookupModule()
    terms = [
        {'files': 'foo', 'paths': 'bar', 'skip': 'True'},
        {'files': 'baz', 'paths': 'qux', 'skip': 'True'},
    ]
    variables = dict()
    result = self.run(terms, variables)
    assert result == []

    error = None
    try:
        result = self.run(terms, variables, bar=True)
    except AnsibleLookupError as err:
        error = err
    assert error.message == "Invalid term supplied, can handle string, mapping or list of strings but got: <type 'bool'> for True"

    terms = ['foo', 'bar']
    result = self.run(terms, variables)
    assert result == []

    error = None

# Generated at 2022-06-23 11:41:20.585797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = ["file1.yml", "file2.yml"]
    paths = ["/home/user/ansible", "/var/tmp"]
    terms = [{"files": files, "paths": paths, "skip": False}, "file3.yml"]
    variables = ["ansible_user_id"]
    kwargs = {"errors": "ignore"}

    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('first_found')

    try:
        result = lookup.run(terms=terms, variables=variables, **kwargs)
    except Exception as e:
        raise Exception(e)

    assert isinstance(result, list)

    from ansible.module_utils.six import PY2
    if not PY2:
        assert isinstance(result[0], bytes)


# Generated at 2022-06-23 11:41:31.767144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    # Create a temporary file for testing.
    tmp_file = os.tmpfile()
    tmp_file.write(b"LookupModule")
    tmp_file.seek(0)

    # Check that run returns the correct file path
    lookup_module = LookupModule()
    lookup_module.set_options(dict(files=[tmp_file.name]))
    assert tmp_file.name == lookup_module.run([], {})[0]

    # Check that run raises the correct error
    lookup_module = LookupModule()
    try:
        lookup_module.run([], {})
        assert False
    except AnsibleLookupError as e:
        assert "No file was found" in str(e)

    # Clean up the temporary file
    tmp_file.close()



# Generated at 2022-06-23 11:41:43.293600
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # todo:
    #   - test with fact cache
    #   - improve test coverage
    #   - fix issues in notes
    #   - test with more 'broken' terms
    #   - test both ways to use 'skip' param and make sure it works
    #   - test with 'relative' paths (def find_file_in_search_path)

    import tempfile

    from ansible.vars import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.parsing.dataloader import DataLoader

    distro = Distribution({})
    distro.version_string = '7'

    lookup = LookupModule()

# Generated at 2022-06-23 11:41:54.445248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ####################################################################################################################
    # Tests with a list as term
    ####################################################################################################################
    # Tests with a list of strings
    lookup_module = LookupModule()
    list_of_strings = ['file1', 'file2', 'file3']
    assert lookup_module.run(list_of_strings, {}) == []

    # Tests with a list of strings and a list of paths
    lookup_module = LookupModule()
    list_of_strings = ['file1', 'file2', 'file3']
    list_of_paths = ['path1', 'path2']
    assert lookup_module.run(list_of_strings, {}, paths=list_of_paths) == []

    # Tests with a list of strings, a list of paths and skip
    lookup_module = LookupModule()
   

# Generated at 2022-06-23 11:42:05.768535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that if no file is found, skip=False, a LookupError is raised
    lookup = LookupModule()
    lookup.set_options(direct={'skip': False})
    terms = [
        'foo',
        'bar',
        'baz',
    ]
    lookup.find_file_in_search_path = lambda *args, **kwargs: None
    try:
        lookup.run(terms=terms, variables={})
    except AnsibleLookupError:
        pass
    else:
        assert False

    # Test that if no file is found, skip=True, an empty list is returned
    lookup = LookupModule()
    lookup.set_options(direct={'skip': True})
    terms = [
        'foo',
        'bar',
        'baz',
    ]
    lookup.find

# Generated at 2022-06-23 11:42:06.515237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:42:15.231234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()
    terms = '''
    - some/path
    - some/other/path
    - name:
        files:
          - file1
          - file2
        paths:
          - path1
          - path2
    - name:
        files:
          - file3
          - file4
        paths:
          - path3
          - path4
    '''
    expected = [
        'some/path',
        'some/other/path',
        'path1/file1', 'path1/file2',
        'path2/file1', 'path2/file2',
        'path3/file3', 'path3/file4',
        'path4/file3', 'path4/file4',
    ]
    variables = dict()
    kwargs

# Generated at 2022-06-23 11:42:25.008877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = LookupModule()
    assert results._process_terms([], {}, {}) == ([], False)
    lookup_params = [
        {
            "files": "foo",
            "paths": "bar"
        },
        {
            "files": "foo",
            "paths": "bar"
        }
    ]
    assert results._process_terms(lookup_params, {}, {}) == (['bar/foo', 'bar/foo'], False)
    lookup_params = [
        {}
    ]
    assert results._process_terms(lookup_params, {}, {"files": "foo", "paths": "bar"}) == (['bar/foo'], False)

# Generated at 2022-06-23 11:42:27.471938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 11:42:33.567563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo.txt',{'files': ["bar.txt","biz.txt"], 'paths':[]},'false.txt']
    lookup_obj = LookupModule()
    total_search, skip = lookup_obj._process_terms(terms, {}, {})
    assert lookup_obj.run(total_search, {}) == []
    assert skip == False

# Generated at 2022-06-23 11:42:44.458737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        if fn == '/path/to/foo.txt':
            return fn
        elif fn == 'bar.txt':
            if subdir == 'files':
                return 'test_files/bar.txt'
            elif subdir == 'files_subdir':
                return 'files_subdir/bar.txt'
        elif fn == 'biz.txt':
            raise AnsibleLookupError("No file was found.")

    class LookupModule_class:
        def __init__(self):
            self._subdir = None
        def set_options(self, var_options=None, direct=None):
            pass
        def get_option(self, key):
            if key == 'files':
                return

# Generated at 2022-06-23 11:42:45.921327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: to be implemented
    return

# Generated at 2022-06-23 11:42:51.956357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Testing dictionary in terms.
    terms = [{'files': ['foo', 'bar'], 'paths': []}]
    assert lookup_module._process_terms(terms, None, None) == ([['foo'], ['bar']], False)

    # Testing list of strings in terms.
    terms = [["/path/to/foo.txt", "/path/to/bar.txt"]]
    assert lookup_module._process_terms(terms, None, None) == ([['/path/to/foo.txt'], ['/path/to/bar.txt']], False)

    # Testing only files in terms.
    terms = ['/path/to/foo.txt']

# Generated at 2022-06-23 11:43:03.881965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    #
    # Test parameter validation
    #
    try:
        lu.run([1], {})
    except AnsibleLookupError as e:
        assert "Invalid term supplied, can handle string" in str(e)
    except Exception as e:
        raise AssertionError("AnsibleLookupError not raised")
    #
    # Test that the file "test1" is found
    #
    result = lu.run(["test1"], {})
    expect = ["test1"]
    assert result == expect
    #
    # Test that the file "test2" is found
    #
    result = lu.run(["test2"], {})
    expect = ["test2"]
    assert result == expect
    #
    # Test that the file "test3" is found

# Generated at 2022-06-23 11:43:10.927162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: test split on parts
    # TODO: test multiple dicts for files and paths
    # TODO: test with search paths + files
    # TODO: test files with search paths
    # TODO: test files without search paths
    # TODO: test paths without files
    # TODO:
    """Test for lookup value in different directories"""
    
    module = LookupModule()

    # Test for no dict as term in files without search paths
    options = {
        'files': ['file1', 'file2'],
        'paths': ['/tmp/production', '/tmp/staging']
    }
    module.set_options(var_options={}, direct=options)
    result, skip = module._process_terms(['file0', 'file1', 'file2'], {}, {})

# Generated at 2022-06-23 11:43:14.610219
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.__doc__ == DOCUMENTATION
    assert lookup_plugin.run.__doc__ == RETURN

# Generated at 2022-06-23 11:43:16.250791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_test_instance = LookupModule()
    assert lookup_test_instance is not None

# Generated at 2022-06-23 11:43:20.997205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run.__doc__ = LookupModule.run.__doc__
    '''
    Tests for method run of class LookupModule
    '''
    lm = LookupModule()
    assert lm
    assert lm.run
    assert callable(lm.run)

# Generated at 2022-06-23 11:43:29.028587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    # create the inventory, use path to host config file as source or hosts in a comma separated string
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a single file, found file
    test_terms = [
        '/tmp/first_found_test/file2',
        '/tmp/first_found_test/file3',
    ]

    first_found = LookupModule()
    first_found.set_options(direct={'skip': True})


# Generated at 2022-06-23 11:43:29.578167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:43:31.212620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, '')

# Generated at 2022-06-23 11:43:41.220295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Mock data
    inventory_manager = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    play_context = PlayContext()

    templar = Templar(loader=DataLoader(), variables=variable_manager,
                   shared_loader_obj=False, fail_on_undefined=True)

    variable_manager.set_inventory(inventory_manager)

    variable_manager.set_play_context(play_context)

    lookup_module = LookupModule()
    lookup

# Generated at 2022-06-23 11:43:51.097242
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_subdir = 'files'
    mock_terms = [
        {
            'files': 'file1',
            'paths': 'path1, path2',
        },
        {
            'files': 'file2',
            'paths': 'path3, path4',
        },
        'file3',
        'file4',
        ['file5', 'file6']
    ]
    mock_variables = {'hostvars': {'host1': {'ansible_port': '0'}}}
    mock_kwargs = {'skip': False}

    mock_path = '/path/to/existing/file'

    # Mock method find_file_in_search_path from LookupBase
    # Method find_file_in_search_path return mock_path in first call,
    # in next calls

# Generated at 2022-06-23 11:43:55.198475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from . import units_init
    units_init()

    # Unit test for 'lookup('first_found')'
    result = LookupModule().run(terms=['bsd_foo.conf', 'default_foo.conf'], variables={})
    assert result == []

# Generated at 2022-06-23 11:43:57.725756
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #The following creates an object of class "LookupModule".
    lu = LookupModule()

# Generated at 2022-06-23 11:44:05.608455
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    result = module._process_terms(["one:"], {}, {'skp': False})
    assert result == ([], False)


# Generated at 2022-06-23 11:44:16.213753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy AnsibleFileLoader, which has its lookups_loader() method
    # modified to return LookupModule instead of the real one
    class AnsibleFileLoaderDummy(object):
        def __init__(self, path=None, module_loader=None, templar=None, shared_loader_obj=None, looked_up_file=None):
            self._path = path
            self._module_loader = module_loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj
            self._looked_up_file = looked_up_file

        def get_basedir(self, task_vars):
            return '/tmp'

        def get_loader(self, path):
            return self

        def get_real_file(self, filename):
            return filename

# Generated at 2022-06-23 11:44:17.050635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:44:29.851766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # globals
    expected_path = '/path/to/file'
    expected_error = 'No file was found when using first_found.'
    expected_empty_list = []

    # init
    terms = ['wrong_file1', 'file']
    variables = {}
    kwargs = {}

    # mock
    class FakeTemplar:
        def template(self, text):
            if 'wrong_file' in text:
                raise ValueError

            return text

    class FakeLookupBase:
        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing):
            if 'wrong_file' in filename:
                return None

            return expected_path

    # patch
    mod = LookupModule()
    mod._templar = FakeTemplar()
    mod.FindFile

# Generated at 2022-06-23 11:44:31.015911
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup



# Generated at 2022-06-23 11:44:32.295551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:44:33.382812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test creation of class
    assert LookupModule()

# Generated at 2022-06-23 11:44:36.049111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    check_dict = ['a', 'b']
    assert lookup_plugin._process_terms(check_dict, None, None) == ([], False)

# Generated at 2022-06-23 11:44:37.793667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([], {}, skip=True) == []

# Generated at 2022-06-23 11:44:46.418387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: this test was added due to observed inconsistent behavior
    # NOTE: fixed behavior, 'fixed' test to be more useful
    invalid_cases = {
        'files': [],
        'paths': [],
        'skip': True,
        '_terms': []
    }

    with pytest.raises(AnsibleLookupError) as e:
        LookupModule().run(**invalid_cases)

    assert "No file was found when using first_found." in str(e.value)

    invalid_cases = {
        'files': [],
        'paths': [],
        'skip': True,
        '_terms': [
            { 'files': [], 'paths': []}
        ]
    }


# Generated at 2022-06-23 11:44:58.736516
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_class = LookupModule()
    lookup_module_class._templar = None

    # Test run with invalid (unsupported) terms data type
    terms = 123
    variables = None
    kwargs = {}
    expected_value = [u'No file was found when using first_found.']
    value = lookup_module_class.run(terms, variables, **kwargs)
    assert value == expected_value

    # Test run with valid terms data type
    terms = [u'/path/to/foo.txt']
    variables = {}
    kwargs = {}
    expected_value = []
    value = lookup_module_class.run(terms, variables, **kwargs)
    assert value == expected_value

    # Test run with valid terms and files data type

# Generated at 2022-06-23 11:45:05.905678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.parsing.yaml import objects

    t_file1 = tempfile.NamedTemporaryFile()
    t_file2 = tempfile.NamedTemporaryFile()
    t_file3 = tempfile.NamedTemporaryFile()
    t_file4 = tempfile.NamedTemporaryFile()

    f1 = os.path.basename(t_file1.name)
    f2 = os.path.basename(t_file2.name)
    f3 = os.path.basename(t_file3.name)
    f4 = os.path.basename(t_file4.name)

    d1 = os.path.dirname(t_file1.name)

# Generated at 2022-06-23 11:45:12.814401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    file1 = 'file1'
    file2 = 'file2'
    file3 = 'file3'
    file4 = 'file4'

# Generated at 2022-06-23 11:45:24.965917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test: _process_terms with a string term
    term = "test1_file1.txt"
    lookup._process_terms([term], None, {})
    # test: _process_terms with a list term
    term = ["test2_file2.txt", "test2_file3.txt"]
    lookup._process_terms([term], None, {})
    # test: _process_terms with a mapping term
    term = {"files": ["test3_file4.txt", "test3_file5.txt"], "paths": ["/tmp", "/etc"]}
    lookup._process_terms([term], None, {})
    # test: _process_terms with a list of all kind of terms

# Generated at 2022-06-23 11:45:33.956594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError

    # Construct a fake context for LookupModule
    import tempfile
    fake_dir = tempfile.mkdtemp()
    fake_variables = {
        'role_path': fake_dir,
        'subdir': 'fake',
        '_role_name': 'fake_role',
        '_role_path': '/fake/path/to/fake_role',
    }
    fake_searchpath = ['/fake/path/to/fake_role/fake']

    # Declare a LookupModule with subdir set to fake
    lookup_instance = LookupModule()
    lookup_instance._subdir = 'fake'
    lookup_instance._templar = None

    # Declare a test file in fake_dir

# Generated at 2022-06-23 11:45:45.564708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import os.path
    import tempfile
    import shutil
    import unittest
    import textwrap

    class LookupModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.lookup = LookupModule()
            self.maxDiff = None

        def test_failed(self):
            '''Error when no file was found'''
            term = [
                'nonexisting.txt',
                'unexisting.txt',
            ]
            with self.assertRaisesRegexp(AnsibleLookupError, "No file was found when using first_found."):
                self.lookup.run(term, dict())

        def test_failed_no_path(self):
            '''Error when no file was found'''

# Generated at 2022-06-23 11:45:54.449581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: unit tests should use a lookup plugin and not call code directly
    #from ansible.plugins.lookup.first_found import LookupModule
    #lookup = LookupModule

    # no file
    l = LookupModule()
    terms = ['foo']
    assert l.run(terms, {}) == [], "foo should not be found"
    # but it should be if we explicitly say we are ok with that
    assert l.run(terms, {}, errors='ignore') == []

    # one file - basic
    terms = ['files/foo']
    assert l.run(terms, {}) == ['./files/foo'], "Should be found as a relative path"

    # one file - files: in vars
    terms = []
    vars = {'files': ['files/foo']}
    assert l

# Generated at 2022-06-23 11:46:06.645738
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    lookup = LookupModule()
    module.set_options(var_options={"A":1}, direct={"a":3})
    assert module.get_option("a") == 3
    assert module.get_option("A") == 1

    # empty string arg
    assert lookup._split_on("", ",") == []
    assert lookup._split_on("", ",;") == []
    assert lookup._split_on("") == []

    # string arg
    assert lookup._split_on("a", ",") == ["a"]
    assert lookup._split_on("a,b", ",") == ["a", "b"]
    assert lookup._split_on("a,b", ",;") == ["a", "b"]

# Generated at 2022-06-23 11:46:07.565142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:46:13.514562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    lookup_module = LookupModule()

    # Prepare
    vars_ ={}

    # Test
    total_search, skip = lookup_module._process_terms([
        {
            'files': 'file1',
            'paths': 'path1',
            'skip': True
        },
        {
            'files': 'file2',
            'paths': '',
            'skip': True
        },
        {
            'files': 'file3',
            'paths': 'path3',
            'skip': False
        }
    ], vars_, {})

    assert (total_search == ['path1/file1', 'path3/file3'])
    assert (skip == False)


# Generated at 2022-06-23 11:46:21.724623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins import lookup_loader
    inmemory_loader = lookup_loader.get('first_found')
    assert inmemory_loader is not None, 'first_found lookup plugin not found.'

    terms = [
        'test_single_term.txt'
    ]
    variables = {}
    result = inmemory_loader.run(terms, variables)
    assert len(result) == 1

    terms = [
        'test_single_term.txt',
        'test_single_term_2.txt'
    ]
    variables = {}
    result = inmemory_loader.run(terms, variables)
    assert len(result) == 1


# Generated at 2022-06-23 11:46:31.992278
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # fixtures
    # should raise errors in run()
    not_string_terms_dict = {"files": 42, "paths": 42, "skip": 42}
    not_string_terms_tuple = ({"files": 42, "paths": 42, "skip": 42},)

    # should pass
    empty_terms_dict = {"files": [], "paths": [], "skip": False}
    empty_terms_tuple = ({"files": [], "paths": [], "skip": False},)
    empty_terms_str = ""
    empty_terms_str_tup = ("",)
    no_files_terms_dict = {"files": [], "paths": ["some_path"], "skip": False}
    no_files_terms_str = "some_path"
    no_files_terms_str

# Generated at 2022-06-23 11:46:37.305665
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    parameters = {'files': ['/path/to/foo.txt', '/path/to/bar.txt']}
    lookup_module.set_options(var_options=None, direct=parameters)
    assert lookup_module.get_option('files') == ['/path/to/foo.txt', '/path/to/bar.txt']


# Generated at 2022-06-23 11:46:37.939470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(issubclass(LookupModule, LookupBase))

# Generated at 2022-06-23 11:46:40.260915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = 'test'
    res = LookupModule(terms, dict(), dict()).run(terms, dict(), dict())
    assert res == []

# Generated at 2022-06-23 11:46:48.468448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = MockClass()
    mock_self._templar = MockClass()

    # test with valid term
    term = "something"
    variables = {}
    kwargs = {}

    mock_self.set_options = Mock()
    mock_self._process_terms = Mock()
    mock_self.find_file_in_search_path = Mock()
    mock_self.run(term, variables, **kwargs)

    mock_self.set_options.assert_called()
    mock_self._process_terms.assert_called()
    mock_self.find_file_in_search_path.assert_called()

    # test with invalid term
    term = 1234
    variables = {}
    kwargs = {}

    mock_self.set_options = Mock()
    mock_self._process_terms

# Generated at 2022-06-23 11:47:00.742494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ['/test/test.conf']
    variables = {'test': 2}
    assert lm._process_terms(terms, variables, {}) == (terms, False)
    terms = [['/test/test.conf']]
    assert lm._process_terms(terms, variables, {}) == (terms[0], False)
    terms = [{'file': '/test/test.conf'}]
    assert lm._process_terms(terms, variables, {}) == (terms[0], False)
    terms = [{'file': '/test/test.conf', 'path': '/test/test'}]

# Generated at 2022-06-23 11:47:11.035711
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Create a LookupModule object
  lookup_module = LookupModule()

  # Check the type of lookup_module
  assert isinstance(lookup_module, LookupModule)

  # Create a list of terms
  terms = ['term1', 'term2']

  # Create a dictionary of variables
  variables = {'var1': 'val1', 'var2': 'val2'}

  # Run lookup_module with terms and variables as parameters
  results = lookup_module.run(terms, variables)

  # Check that lookup_module ran without errors (returned None)
  assert results == []

  # Check that the _process_terms function returns two values
  results = lookup_module._process_terms(terms, variables, {'files':'file1', 'paths':'path1'})
  assert len(results) == 2



# Generated at 2022-06-23 11:47:19.661915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Create a dummy variables class
    class Variables:
        def get_vars(self, loader, path, entities, cache=True):
            return {u'ansible_distribution': u'CentOS', u'ansible_os_family': u'RedHat'}

    variables = Variables()

    # Define some paths
    lookup.set_options({'paths': ['/tmp/staging', '/tmp/production']})
    # Define some files
    lookup.set_options({'files': ['foo.txt', 'default_foo.conf']})

    # Create a list of terms
    terms = ['foobar', 'staging_foo.conf', 'production_foo.conf', 'CentOS_foo.conf', 'RedHat_foo.conf', 'default_foo.conf']
   

# Generated at 2022-06-23 11:47:21.920189
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'

# Generated at 2022-06-23 11:47:32.342153
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # 1. First with variable 'files'
    terms = [
        {'files': 'first_file', 'paths': '/path/of/first_path'},
        {'files': 'second_file', 'paths': '/path/of/second_path'},
    ]

    # 1.1. The file first_file should be found
    variables = {}
    options = {'files': 'first_file', 'paths': '/path/of/first_path'}
    l = LookupModule()
    l.set_loader(None)
    l.set_options(var_options=variables, direct=options)

    # For this we do not need a real path
    def _find_file_in_search_path(variables, subdir, fn):
        return fn

    l.find_file_in

# Generated at 2022-06-23 11:47:40.581036
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    import sys
    import os
    import shutil
    import inspect
    import yaml

    test_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))) + "/LookupModule_run_tests"
    os.makedirs(test_dir)

    # Create known files and folders
    with open(os.path.join(test_dir, "known_file"), "w") as f:
        f.write("known content")
    with open(os.path.join(test_dir, "known_folder/known_file2"), "w") as f:
        f.write("known content2")

# Generated at 2022-06-23 11:47:50.108464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._process_terms([], [], {})

    # NOTE: it seems that supplying a 'dict' as option/term
    #  will clobber all other terms
    lookup = LookupModule()
    lookup._process_terms([{'files': 'foo', 'paths': 'bar'}], [], {})
    lookup._process_terms([{'files': 'bar'}, {'paths': 'foo'}], [], {})

    # note: supplying a list will concat all list together
    lookup = LookupModule()
    lookup._process_terms([{'files': 'bar'}, ['foo']], [], {})

# Generated at 2022-06-23 11:47:50.861491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:48:01.789538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert ["/etc/resolv.conf"] == lookup.run(terms=[
        "{{ lookup('env', 'HOME') }}/resolv.conf",
        "/etc/resolv.conf",
        "{{ lookup('env', 'HOME') }}/not_found_file"
    ], variables={
        'item': 'my_item',
        'paths': 'my_paths',
        'files': 'my_files',
        'skip': True
    })


# Generated at 2022-06-23 11:48:08.558360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing the following types of inputs
    # 1. terms is a list of files
    #
    # 2. terms could contain a list of files in a dict, the other values in the dict will be ignored

    lkup = LookupModule()
    lkup.set_options()
    lkup.get_option = lkup.get_option  # stub the get_option method

    # Generate a fake lookup ( for testing )
    def _find_file_in_search_path(variables, subdir, filename, ignore_missing=False):
        paths = [
            '/tmp/test_lookup_first_found/',
            '/home/ansible/test_lookup_first_found',
            '/home/ansible/test_lookup_first_found/',
        ]


# Generated at 2022-06-23 11:48:17.665639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Testing for LookupModule.run()
    """
    lookup_obj = LookupModule()  #Create the object of LookupModule class
    files = ['/path/to/foo.txt', 'bar.txt','/path/to/biz.txt'] #list of files
    paths = [] #list of paths
    skip = "False" #False values are not skipped
    ans = lookup_obj.run(files,paths,skip)
    assert ans == ['/path/to/foo.txt'] #calling the run() same files and paths and skip as used in example


# Generated at 2022-06-23 11:48:18.827183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:48:19.271145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:48:20.149006
# Unit test for constructor of class LookupModule
def test_LookupModule():
    first_found = LookupModule()
    assert(first_found is not None)

# Generated at 2022-06-23 11:48:31.441459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    terms = [
        'home.conf',
        {
            'files': 'kubernetes.conf',
            'paths': '/usr/local/ansible/data/etc',
        },
        {
            'files': 'docker.conf',
            'paths': '/usr/local/ansible/data/etc',
        },
        {
            'files': 'kubernetes.conf,docker.conf',
            'paths': '/usr/local/ansible/data/etc',
            'skip': True,
        },
        'default.conf',
    ]
    variables = {}
    kwargs = {'errors': 'ignore'}
    test_lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-23 11:48:33.255685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 11:48:44.262694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Config the class
    lm = LookupModule()
    lm.set_options(var_options={})
    lm.set_options(direct={"files": ["foo.txt"],
                           "paths": ["/tmp/foo", "/tmp/bar"],
                           "_subdir": [""]})
    assert lm._subdir == "", "_subdir does not equals None, something wrong"
    assert lm._terms == [{"files": ["foo.txt"],
                          "paths": ["/tmp/foo", "/tmp/bar"],
                          "_subdir": [""]}], \
        "Term does not equals None, something wrong"
    assert lm.get_option('_subdir') == "", "_subdir does not equals None, something wrong"

# Generated at 2022-06-23 11:48:53.716864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # case 1:
    # [{'files': 'file1, file2', 'paths': '/path1:/path2'}, {'files': 'file3', 'paths': '/path3'}]
    # expected output:
    # ['/path1/file1', '/path1/file2', '/path2/file1', '/path2/file2', '/path3/file3']
    #
    # case 2:
    # [{'files': 'file1, file2', 'paths': '/path1:/path2'}, 'file3']
    # expected output:
    # ['/path1/file1', '/path1/file2', '/path2/file1', '/path2/file2', 'file3']
    #
    # case 3:
    # ['file

# Generated at 2022-06-23 11:49:05.265938
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLookupModule(LookupModule):
        """
        Add some magic to the LookupModule class to expose the private method _process_terms
        """

        def __init__(self):
            LookupModule.__init__(self)

        def _process_terms(self, terms, variables, kwargs):
            return self.process_terms(terms, variables, kwargs)

    # Create test cases for the LookupModule method run

    # Test case for method run of class LookupModule
    # Test of use first existing file, raising an error if a file is not found
    # Input parameters:
    #       :param term: List of files to be tested
    #       :param kwargs: Dictionary with options
    # Output:
    #       :return: Full path to the first existing file
    #
    # Test case with