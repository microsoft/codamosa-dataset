

# Generated at 2022-06-23 11:39:04.064773
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') is False



# Generated at 2022-06-23 11:39:15.972349
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # fake variables necessary for the lookup module.
    # the variables are normally passed to the lookup module by ansible
    variables = {'ansible_virtualization_type': 'KVM'}

    # fake terms sent to the lookup module by ansible
    terms = ['{{ ansible_virtualization_type }}_foo.conf', 'default_foo.conf']

    # python native function to retrieve the path of the module
    import os
    import sys
    my_path = os.path.dirname(os.path.abspath(__file__))
    # append the path of the module to the python path so that it can be found
    sys.path.insert(0, my_path)

    from ansible.plugins.lookup import first_found
    # create the instance of the class
    lm = first_found.LookupModule()


# Generated at 2022-06-23 11:39:20.724550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an object of class LookupModule
    l = LookupModule()
    # Create a dictionary with 'files' and 'paths' keys
    terms = dict(files=['foo.txt'],paths=['/tmp/production','/tmp/staging'])
    # Call function run
    l.run(terms, {})

# Generated at 2022-06-23 11:39:32.011134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import pytest
    test_dir = os.path.join(os.path.dirname(__file__), 'lookup_plugins', 'first_found')
    file_name = 'test_first_found_file.yml'
    file_name1 = 'test_first_found_file1.yml'
    file_name2 = 'test_first_found_file2.yml'
    file_name3 = 'test_first_found_file3.yml'
    file_name4 = 'test_first_found_file4.yml'
    file_name5 = 'test_first_found_file5.yml'
    file_name6 = 'test_first_found_file6.yml'

# Generated at 2022-06-23 11:39:41.672890
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def fail_run(terms, variables, **kwargs):
        import pytest
        pytest.fail("LookupModule.run() does not handle %s" % terms)

    class FakeLookupModule(LookupModule):

        def __init__(self_):
            self_._match = None
            self_._subdir = "files"
            self_._path = None

        def find_file_in_search_path(self_, variables, subdir, fn, ignore_missing):
            fn = fn.replace("/", os.sep)
            if fn == os.sep:
                return "FOO_BAR_PATH"
            if not self_._match:
                return None
            if self_._match != fn[len(self_._path)+1:]:
                return None
            return self_._path



# Generated at 2022-06-23 11:39:43.665879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with defined parameeters
    lookup_plugin = LookupModule()

    # Test with empty parameeters
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:39:53.741250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase

    # Dummy class for test
    module = LookupBase()

    # Dummy lookup module for test
    module.find_file_in_search_path = \
        lambda variables, subdir, fn, ignore_missing: "foo"

    # Dummy templar for test
    module._templar = \
        lambda fn: "foo"

    # List of terms to test

# Generated at 2022-06-23 11:39:54.700983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:39:55.239905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:40:06.420637
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: this way of overriding the base class was chosen to keep the methods as close as possible
    # to the original, as it's too much for me to test (both original and new versions).
    # It would be much simpler to rewrite the entire method (But who knows if it will break later)

    class TestLookupModule(LookupModule):

        class variables():
            pass

        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing=False):
            search = "/test/the/search/"
            if filename == "test_file1":
                return os.path.join(search, filename)
            elif filename == "test_file2":
                return os.path.join(search, filename)
            elif filename == "test_file3":
                return None
            else:
                raise Exception

# Generated at 2022-06-23 11:40:16.300488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            if fn.endswith('_fail'):
                return None
            else:
                return fn

    class TTemplar:
        def template(self, fn):
            return fn

    class TTaskVars:
        def __init__(self, data):
            self.vars = data

        def __contains__(self, key):
            return key in self.vars

        def __getitem__(self, key):
            return self.vars[key]


# Generated at 2022-06-23 11:40:20.602090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    return lookup_module.run(['file1',{'paths': ["path/to/dir"], 'files': ["file2"]}, 'file2'],{})

# Generated at 2022-06-23 11:40:22.198728
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:40:24.160330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    results = l._process_terms([{"files": "a", "paths": "b"}])
    assert results == ([], False)


# Generated at 2022-06-23 11:40:29.949703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(None, loader=None)

    # create object
    lookup_module = LookupModule()
    lookup_module._templar = templar

    # set terms

# Generated at 2022-06-23 11:40:30.521386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:40:31.909245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:40:43.875706
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ls = LookupModule()
    ls.set_loader(None)

    assert ls.run([], {}, files=[], paths=[], skip=True) == []

    assert ls.run(['foo'], {}, files=['foo'], paths=[], skip=True) == []

    assert ls.run(['foo'], {}, files=['bar'], paths=[], skip=True) == []

    assert ls.run(['foo'], {}, files=['foo'], paths=[]) == ['foo']

    assert ls.run(['/bar'], {}, files=['foo'], paths=['/bar']) == ['/bar/foo']


# Generated at 2022-06-23 11:40:45.219969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module



# Generated at 2022-06-23 11:40:58.383363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # test _process_terms
    assert lookup_module._process_terms(
        ["foo", "bar"], None, {}) == (["foo", "bar"], False)
    assert lookup_module._process_terms(
        ["foo", "bar"], None, {'skip': True}) == (["foo", "bar"], True)
    assert lookup_module._process_terms(
        [{'files': 'foo,bar', 'paths': 'baz:qux'}],
        None, {}) == (["foo", "bar"], False)
    assert lookup_module._process_terms(
        ["foo", "bar"], None, {'files': 'spam,eggs'}) == (["foo", "bar"], False)

# Generated at 2022-06-23 11:41:10.262345
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.utils.template as template
    t = template.Templar()
    lookup = LookupModule(Loader())

    # Test error if neither files nor paths are supplied
    terms = ['f1', 'f2']
    variables = {}
    lookup.run(terms, variables, t)
    assert lookup._options.get('paths') == []

    # Test files and paths if supplied
    terms = [{'files': 'f1', 'paths': '/path/to'}]
    variables = {}
    lookup.run(terms, variables, t)
    assert lookup._options.get('paths') == ['/path/to']

    # Test multiple paths
    terms = [{'files': 'f1', 'paths': '/path/to,/path/to/file'}]
    variables = {}
    lookup

# Generated at 2022-06-23 11:41:11.874174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)



# Generated at 2022-06-23 11:41:20.490529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    LookupModule_instance = LookupModule()

    # set _terms attribute
    LookupModule_instance._terms = ['/path/to/file1']
    # set _subdir attribute
    Getattr_return_value_1 = 'files'
    setattr(LookupModule_instance, '_subdir', Getattr_return_value_1)
    # set find_file_in_search_path
    def Find_file_in_search_path_helper(variables, subdir, fn, ignore_missing):
        if (fn == '/path/to/file1'):
            return "/path/to/file1"
        else:
            return None
    LookupModule_instance.find_file_in_search_path = Find_file_in_search_path_helper


# Generated at 2022-06-23 11:41:31.692715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six.moves import builtins

    # test with relative path
    assert LookupModule().run(["../test.txt"], dict(), _tc=dict(basedir='.')) == ["../test.txt"]

    # test with absolute path
    assert LookupModule().run(["./test.txt"], dict(), _tc=dict(basedir='.')) == ["./test.txt"]

    # test with a list
    assert LookupModule().run([["../test.txt", "./test.txt"]], dict(), _tc=dict(basedir='.')) == ["../test.txt", "./test.txt"]

    # test with a dict

# Generated at 2022-06-23 11:41:32.961039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([]) == []

# Generated at 2022-06-23 11:41:35.012882
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 11:41:35.814583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:41:45.833029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = list()
    terms.append({'files': 'something.yml', 'paths': './path1:./path2:./path3'})

    variables = dict()
    variables['ansible_ignore_file_lookup_errors'] = False

    result = lookup_module.run(terms, variables, skip=True)

    assert result is not None
    assert result == []



# Generated at 2022-06-23 11:41:55.976030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    lookup_plugin = LookupModule()

    # First test, no lookup parameter

    # Single parameter, string
    terms = "test_LookupModule_run.txt"
    assert lookup_plugin.run(terms, dict()) == [terms]

    # List of parameters, strings
    terms = ["test_LookupModule_run_1.txt", "test_LookupModule_run_2.txt", "test_LookupModule_run_3.txt"]
    assert lookup_plugin.run(terms, dict()) == terms

    # Dictionary parameters
    # parameters should be mapped
    # files and paths should be split and then mapped
    # skip should be mapped

# Generated at 2022-06-23 11:42:07.825333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # pylint: disable=protected-access
    # pylint: disable=unused-variable,unused-argument
    def _loader(self, templar, file_name):
        pass

    # pylint: disable=protected-access
    # pylint: disable=unused-variable,unused-argument
    def _loader_existing(self, templar, file_name):
        return file_name

    real_loader = lm._loader

# Generated at 2022-06-23 11:42:14.735452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=missing-docstring
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    terms = ['first', 'second']
    variable_manager = VariableManager()

    lookup = LookupModule()
    lookup.set_loader(loader)
    lookup.set_play_context(VariableManager())

    result = lookup.run(terms, variable_manager)
    assert [] == result

# Generated at 2022-06-23 11:42:16.147732
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ansible = AnsibleModule()
    lookup = LookupModule(ansible=ansible)
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:42:22.690057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    files_to_find = ["test_src"]
    directories_to_search = ["/tmp"]

    lookup_module = LookupModule()
    lookup_module.set_options({"files" : files_to_find, "paths" : directories_to_search})
    assert lookup_module.get_option("files") == files_to_find
    assert lookup_module.get_option("paths") == directories_to_search

# Generated at 2022-06-23 11:42:32.547433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest

    with pytest.raises(AnsibleLookupError) as exec_info:
        LookupModule()
    assert "lookup expects to be called with a list" in str(exec_info.value)

    # test of _process_terms
    with pytest.raises(AnsibleLookupError) as exec_info:
        LookupModule([{'works': 'yay'}])._process_terms([1])
    assert "Invalid term supplied, can handle string, mapping or list of strings but got: <type 'int'> for 1" in str(exec_info.value)

    lookup = LookupModule([{'files': 'yay'}])._process_terms([1])
    assert lookup == ([1], False)


# Generated at 2022-06-23 11:42:43.899707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # This method has been changed in PR #2675 to raise AnsibleLookupError if no file was found.
    # For compatibility with older versions of Ansible, this test expects a list containing None
    # instead of AnsibleLookupError to be raised.
    assert [] == l.run(terms=[''], variables={})

    # for now tests are very simplistic, but work well enough for now.
    # Test single string
    assert ['me'] == l.run(terms=['me'], variables={})

    # Test single string with options
    assert ['me'] == l.run(terms=['me'], variables={}, files='me')

    # Test complex path
    assert ['me'] == l.run(terms=['me'], variables={}, files='me', paths='/somewhere')

    # Test list

# Generated at 2022-06-23 11:42:55.878554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test #1 - check correct file name returned from list
    test_obj = LookupModule()
    test_terms = []  # list of files to search for
    test_variables = {}  # Ansible variables

    test_terms.append('/etc/ansible/foo.conf')
    test_terms.append('/etc/ansible/bar.conf')
    test_terms.append('/etc/ansible/biz.conf')

    test_expected_result = ['/etc/ansible/foo.conf']
    test_result = test_obj.run(test_terms, test_variables)

    assert test_result == test_expected_result

    # Test #2 - check correct file name returned from dict
    test_obj = LookupModule()
    test_terms = []
    test_variables = {}

    test

# Generated at 2022-06-23 11:43:02.789143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import jinja2

    class FakeTemplar():
        def __init__(self):
            self.environment = jinja2.Environment()

        def template(self, v):
            return self.environment.from_string(v).render()

    templar = FakeTemplar()
    lookup_plugin = LookupModule(loader=None, templar=templar)
    assert templar == lookup_plugin._templar


# Generated at 2022-06-23 11:43:10.490570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    my_vars = dict()
    loader = DataLoader()
    my_vars = VariableManager()

    lookup_object = LookupModule()

    # tests for method run of class LookupModule
    # first test
    terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    setattr(lookup_object, '_templar', my_vars)
    setattr(lookup_object, '_loader', loader)
    total_search, skip = lookup_object._process_terms(terms, my_vars, dict())

    assert total_search == terms and skip == False

    # second test

# Generated at 2022-06-23 11:43:13.238149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['not_existing_file'], {}) == []

# Generated at 2022-06-23 11:43:24.973124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock
    from ansible_collections.ansible.community.tests.unit.plugins.lookup.test_lookup import TestLookupBase
    from ansible_collections.ansible.community.tests.unit.plugins.lookup.test_lookup import mock

    lm = LookupModule()

    ansible_search_path = ['home', 'root']
    with patch.object(os.path, 'expanduser', lambda x: x):
        with patch.object(os.path, 'exists', lambda x: x == 'home/root'):
            m = Mock()

            m.check_mode = False
            m._templar = Mock()
            m._templar.template.return_

# Generated at 2022-06-23 11:43:32.609316
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mod = LookupModule()

    terms = [
        {
            'plop': 'plop',
            'files': 'bar1,bar2',
            'paths': 'path1,path2'
        },
        {
            'plop': 'plop',
            'files': 'foo1,foo2',
            'paths': 'path3,path4'
        },
        {
            'plop': 'plop',
            'files': 'baz1,baz2',
            'paths': 'path5,path6',
            'skip': False
        },
    ]


# Generated at 2022-06-23 11:43:34.053103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:43:35.854502
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        class_object = LookupModule()
    except:
        assert False, "Can't create class object"

# Generated at 2022-06-23 11:43:45.790113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_templar(None)

    # Test that a one item list with a dict is handled correctly
    terms = [
        {'files': '/path/to/your.yml', 'paths': ''}
    ]
    total_search, skip = lookup._process_terms(terms, None, None)
    assert (len(total_search) == 1)
    assert (total_search[0] == '/path/to/your.yml')
    assert not skip

    # Test that a one item list with a string is handled correctly
    terms = [
        '/path/to/your.yml'
    ]
    total_search, skip = lookup._process_terms(terms, None, None)

# Generated at 2022-06-23 11:43:46.858664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:43:58.184922
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms1 = [{'files': ['s_file1', 's_file2'], 'paths': ['s_path1', 's_path2']}, {'files': ['s_file3', 's_file4'], 'paths': ['s_path3', 's_path4']}]
    terms2 = [{'files': 's_file1', 'paths': 's_path1'}, {'files': 's_file3', 'paths': 's_path3'}]
    terms3 = [{'files': 's_file1,s_file2', 'paths': 's_path1,s_path2'}, {'files': 's_file3,s_file4', 'paths': 's_path3,s_path4'}]

# Generated at 2022-06-23 11:44:06.129609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test first_found lookup plugin
    lookup = LookupModule()
    # Test file exist and is found
    print("")
    print("Test file exist and is found using 'run' method")
    print("-----------------------------------------------")
    result = lookup.run([
        "/etc/hosts",
        "/etc/hosts",
        ["/etc/hosts", "/etc/hosts"],
        {"files": "/etc/hosts", "paths": "/etc"}
    ], {})
    assert result[0] == "/etc/hosts"
    result = lookup.run([
        {"files": "/etc/hosts", "paths": "/etc"},
        ["/etc/hosts", "/etc/hosts"],
        "/etc/hosts",
        "/etc/hosts",
    ], {})

# Generated at 2022-06-23 11:44:08.462104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   with pytest.raises(AnsibleLookupError):
      LookupModule().run(terms=[], variables={}, **{})


# Generated at 2022-06-23 11:44:18.264948
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test a valid string list of terms
    terms = ['value1', 'value2']
    lookup = LookupModule()
    assert lookup._process_terms(terms, {}, {})[0] == ['value1', 'value2'], 'Invalid result from _process_terms()'

    # Test invalid type of terms
    terms = ['value1', {}, 'value2']
    try:
        lookup = LookupModule()
        lookup._process_terms(terms, {}, {})
    except AnsibleLookupError:
        pass
    else:
        assert False, 'Invalid type of terms not detected'

    # Test a valid string of terms
    term = 'value'
    lookup = LookupModule()
    assert lookup._process_terms([term], {}, {})[0] == ['value'], 'Invalid result from _process_terms()'

# Generated at 2022-06-23 11:44:30.864795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = "templar"
    lookup_module._loader = "loader"
    lookup_module._basedir = "basedir"

    # term1
    term1 = []
    term1.append("file1.txt")
    term1.append("file2.txt")

    # term2
    term2 = {}
    term2["files"] = "files1.txt"
    term2["paths"] = "paths1.txt"
    term2["skip"] = True

    # term3
    term3 = {}
    term3["files"] = "files2.txt"
    term3["paths"] = "paths2.txt"
    term3["skip"] = False

    # terms
    terms = []

# Generated at 2022-06-23 11:44:31.831212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:44:35.061297
# Unit test for constructor of class LookupModule
def test_LookupModule():

    LM = LookupModule()
    LM.set_options(var_options={}, direct={'files':'file1', 'paths':'path1,path2'})
    LM.run([], {})

# Generated at 2022-06-23 11:44:45.460105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ut_instance = LookupModule()
    result = ut_instance.run([{'files': ["foo.txt", "bar.txt"], 'paths': ['/tmp/production']}, {'files': ["foo.txt", "bar.txt"], 'paths': ['/tmp/staging']}], {})
    assert result == ['/tmp/production/foo.txt']

    result = ut_instance.run([{'files': ["foo2.txt", "bar.txt"], 'paths': ['/tmp/production']}, {'files': ["foo.txt", "bar.txt"], 'paths': ['/tmp/staging']}], {})
    assert result == ['/tmp/staging/foo.txt']


# Generated at 2022-06-23 11:44:47.743127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test constructor of class LookupModule")
    lookup = LookupModule()


# Generated at 2022-06-23 11:44:59.508694
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    search_list = {'findme':
                       {'files': ['foo.txt', 'bar.txt'], 'paths': ['/tmp/production', '/tmp/staging']},
                   'findme2': ['foobar.txt'],
                   'findme3':
                       {'files': ['foo.txt', 'bar.txt'], 'paths': ['/tmp/production', '/tmp/staging']}}
    
    def find_file_in_search_path(variables, subdir, fn, ignore_missing=False):
        return fn

    def _templar(term):
        return term
        
    var_options = {}
    setattr(module, '_templar', _templar)

# Generated at 2022-06-23 11:45:00.421965
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule != None


# Generated at 2022-06-23 11:45:10.042137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # type: () -> None
    # mock loader object
    import sys
    import types
    import ansible.utils.unsafe_proxy

    # mock _loader
    class MockLoader():
        def __init__(self):
            self.path_matches = {}

        def path_dwim_relative(self, x, y, z):
            # return dummy paths for test mode
            if y in self.path_matches:
                return [self.path_matches[y]]
            return None

    # mock finder
    class MockPluginFinder():
        def get_all(self):
            return []

    # mock module_utils
    class MockModuleUtils():
        def __init__(self):
            self.plugins = MockPluginFinder()

    # mock templar

# Generated at 2022-06-23 11:45:22.632574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=['local'])
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info={"git_repo": "skvidal", "git_commit": "ansible_first_found_hash", "git_version": "ansible_first_found_version"})

    lookup

# Generated at 2022-06-23 11:45:23.279471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:45:32.737254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import pytest
    import tempfile
    from ansible.module_utils.six import PY3

    my_dir = tempfile.mkdtemp()
    my_file = os.path.join(my_dir, "myfile")
    with open(my_file, "w") as f:
        f.write("hello world\n")

    class AnsibleModuleFake(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise RuntimeError('fail_json should not be called')

    class AnsibleVarsFake(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-23 11:45:44.461610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # with skip param to True
    lookup_module = LookupModule()  # , loader, templar, shared_loader_obj
    terms = ['/tmp/fileone.yml', '/tmp/filetwo.yml', {'files': 'filethree.yml', 'paths': '/tmp', 'skip': True}]
    variables = {'skip': True}
    lookup_module._templar._available_variables = variables
    result = lookup_module.run(terms, variables)
    assert result == [], 'Result should be an empty list, but found: %s' % result

    # with skip param to False
    lookup_module = LookupModule()  # , loader, templar, shared_loader_obj
    lookup_module._templar._available_variables = variables

# Generated at 2022-06-23 11:45:45.464979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:45:48.047593
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: missing tests, look at LookupModule.py
    dummy_lookup_plugin = LookupModule(loaders=None, variables={})
    # missing test cases - /usr/lib/python3.6/site-packages/ansible/plugins/lookup/__init__.py
    pass

# Generated at 2022-06-23 11:45:52.132168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._templar = None # FIXME: mock it
    l._loader = None # FIXME: mock it

    path = '/path/to/file.txt'
    terms = 'test'
    res = l._process_terms(terms, None)
    assert res == ({path}, True)

# Generated at 2022-06-23 11:46:01.242122
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # defaults
    options = {
        'skip': True,
        '_file_name': '',
        '_files': [],
        '_paths': [],
        '_subdir': 'files',
    }

    files = ['one', 'two', 'three']
    paths = ['path/to/one', 'path/to/two']
    terms = [files, paths]

    options['_files'] = files
    options['_paths'] = paths

    # create the object
    lm = LookupModule()
    lm.set_options(var_options={}, direct=options)

    # test the defaults
    assert(lm.run(terms, {}) == [])

    # test first file found
    options['_file_name'] = files[0]

# Generated at 2022-06-23 11:46:10.780746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = [
        [
            [
                '/test/test',
                '/test/test2',
                {
                    'files': [
                        'test'
                    ],
                    'paths': [
                        '/test'
                    ]
                },
                {
                    'files': [
                        'test3'
                    ],
                    'paths': []
                },
                {
                    'files': [
                        'test4'
                    ]
                }
            ],
            {
                'files': [
                    'test'
                ],
                'paths': [
                    '/test'
                ],
                'skip': False
            }
        ],
        [
            '/test/test2'
        ]
    ]

    obj = LookupModule(*args)
    assert obj.run() == ['/test/test2']

# Generated at 2022-06-23 11:46:20.098194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_name = LookupModule

# Generated at 2022-06-23 11:46:30.252793
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Simple test for first_found lookup module
    # Expected behaviour;
    #   return the first existing file in the list
    #   return an empty list if skip=True and no files are found
    #   return an empty string on error if errors='ignore'

    # Fixture setup
    lookup = LookupModule()

    # Test if an empty input list returns an empty list (skip=False)
    # or an empty string (errors="ignore")
    lookup.set_options(direct={'skip': False, 'errors': 'strict'})
    res = lookup.run(['/path/to/bar.txt', '/path/to/foo.txt'])
    assert res == ['/path/to/bar.txt']

    lookup.set_options(direct={'skip': False, 'errors': 'ignore'})

# Generated at 2022-06-23 11:46:37.766508
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #
    # Original run() method
    #
    template_path = './templates'
    jinja2_env = jinja2.Environment(loader=jinja2.FileSystemLoader(template_path))
    templar = jinja2_env.get_template('basic.j2')

    lookup_inst = LookupModule()
    lookup_inst._templar = templar

    lookup_inst._find_file_in_search_path = MagicMock()

    # perform test
    term = [
        'debian.yml',
        {'files': ['centos.yml'], 'paths': ['vars']},
        'default.yml'
    ]
    result = lookup_inst.run(term=term, variables={}, **{'paths': './'})
   

# Generated at 2022-06-23 11:46:45.561688
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test that LookupModule.run works as expected and that it raises an error when given the wrong arguments"""
    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class Options(object):
        def __init__(self, verbosity=None, connection=None, module_path=None, forks=None, become=None,
                     become_method=None, become_user=None, check=None, diff=None):
            self.verbosity = verbosity
            self.connection = connection
            self.module_path = module_path
            self.forks = forks
            self.become = become

# Generated at 2022-06-23 11:46:52.596011
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import os.path
    import tempfile

    # pylint: disable=E0602
    # pylint: disable=undefined-variable
    # pylint: disable=too-many-arguments

    LookupModule._templar = None  # pylint: disable=protected-access
    LookupModule._loader = None  # pylint: disable=protected-access

    # Create temporary files to use for the tests
    # One for the case of the file extension NOT being part of the file names
    file_content = b''
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(file_content)

    # Create another temporary file for the test case of the file extension being part of the file names
    tmp_file_2 = tempfile.NamedTem

# Generated at 2022-06-23 11:46:56.620552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a basic call to without params
    assert LookupModule().run( ["foo.txt","bar.txt"], "", "") == [], "Basic call to run() with no params must return an empty list"



# Generated at 2022-06-23 11:47:07.855620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml import objects
    from ansible.utils.path import gen_grok_candidates
    from ansible.utils.unicode import to_bytes
    import sys
    import os.path
    import os

    # From method _process_terms of class LookupModule
    # Method _process_terms directly calls gen_grok_candidates and find_file_in_search_path
    #       so we mocked them
    def gen_grok_candidates2(path, path_scroll, basedir):
        return ['%s/%s' % (basedir, path_scroll)]

    def find_file_in_search_path2(variables, subdir, fn, ignore_missing=True):
        path = '%s/%s' % (subdir, fn)


# Generated at 2022-06-23 11:47:17.294774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()

    # test using dictionary as term
    term_dict = {'files':'file1', 'paths':'/tmp'}
    total_search, skip = test_module._process_terms([term_dict], None, None)
    assert total_search == ['/tmp/file1'], "Failed to split files and paths correctly"
    assert skip == False, "Failed to set skip correctly"

    # test using list of dictionary as term
    term_dict = [{'files':'file1', 'paths':'/tmp'}, {'files':'file2', 'paths':'/tmp,/var', 'skip':True}]
    total_search, skip = test_module._process_terms(term_dict, None, None)

# Generated at 2022-06-23 11:47:19.109327
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: write unit test for LookupModule.run()

    pass

# Generated at 2022-06-23 11:47:21.055435
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert lm


# Generated at 2022-06-23 11:47:30.781775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''

    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Init VariableManager and Templar
    mock_iterator = DictDataLoader({
        "/playbooks/files/foo": "foo_content",
        "/playbooks/files/bar": "bar_content",
        "/playbooks/files/bar/baz": "baz_content",
        "/playbooks/files/qux": "qux_content",
        "/playbooks/files/file1": "file1_content"
    })

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 11:47:38.446532
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # a helper method to generate a mock class with members
    def _mock_type(**kwargs):
        class MockLookupModule(object):
            def __init__(self):
                for kwarg in kwargs:
                    setattr(self, kwarg, kwargs[kwarg])
        return MockLookupModule

    # create a parameter mapping to test combinations

# Generated at 2022-06-23 11:47:50.149059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    file_name = 'test_LookupModule.py'
    path_name = 'ansible/plugins/lookup'
    l = LookupModule(loader=None, templar=None, **{})
    assert l.find_file_in_search_path(variables=None, searchpath='ansible/plugins/lookup', filename=file_name, ignore_missing=True) == path_name + '/' + file_name
    assert l.find_file_in_search_path(variables=None, searchpath=None, filename=file_name, ignore_missing=True) == None
    assert l.find_file_in_search_path(variables=None, searchpath=None, filename=file_name, ignore_missing=False) == None

# API call to lookup

# Generated at 2022-06-23 11:47:57.569259
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:48:06.767285
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:48:19.384942
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    obj = LookupModule()
    # set up
    obj._templar = object()
    obj._templar.template = lambda x: str(x).lower()
    obj.find_file_in_search_path = lambda *args: None
    obj._subdir = 'files'

    # execute
    with pytest.raises(AnsibleLookupError) as exc:
        obj.run([], {})
    assert exc.value.args[0] == "No file was found when using first_found."
    assert obj.run([], {}, skip=True) == []

    with pytest.raises(AnsibleLookupError) as exc:
        obj.run(['foo'], {})
    assert exc.value.args[0] == "No file was found when using first_found."
    assert obj

# Generated at 2022-06-23 11:48:27.189317
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    Mock = Mock = __import__('mock').Mock


# Generated at 2022-06-23 11:48:30.470682
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    # todo: add more tests
    assert not isinstance(lookup._process_terms(["a b c"], {}, {})[1], bool)

# Generated at 2022-06-23 11:48:40.846433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_tmplar = mock_tmplar = Mock()
    mock_tmplar.template.side_effect = lambda x: x

    lookup = LookupModule()
    lookup._templar = mock_tmplar

    lookup.run(
        terms=[
            {'files': 'fn0', 'paths': './path0.1,./path0.2'},
            {'files': 'fn1', 'paths': './path1.1'},
            "fn2"
        ],
        variables={'role_path': './roles/this-role', 'inventory_dir': '/etc/ansible/hosts'}
    )


# Generated at 2022-06-23 11:48:42.361554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:48:43.211256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:48:53.153783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    # NOTE:
    #  currently all calls to set_options, etc below needs to be redone
    #  for the new api to work.

    # Basic test of constructor of LookupModule
    assert isinstance(L, LookupModule)

    # Simple tests to support testing with or without the listify function in vars
    assert L._split_on('one,two:three', ',:;') == ['one', 'two', 'three']
    assert L._split_on(['one,two', 'three:four'], ',:;') == ['one', 'two', 'three', 'four']
    assert L._split_on(('one,two', 'three:four'), ',:;') == ['one', 'two', 'three', 'four']

# Generated at 2022-06-23 11:48:55.206905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:48:55.971716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:48:57.818029
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test._subdir == 'files'

# Generated at 2022-06-23 11:49:00.154291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-23 11:49:09.636193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""

    class TestLookupModule(LookupModule):
        def __init__(self, **kwargs):
            # Workaround to mock self._loader.path_dwim
            self._loader = MockLoader()
            super(TestLookupModule, self).__init__(**kwargs)

    # Mocked self._loader.path_dwim
    class MockLoader:
        def __init__(self): pass
        def path_dwim(self, terms):
            return terms
