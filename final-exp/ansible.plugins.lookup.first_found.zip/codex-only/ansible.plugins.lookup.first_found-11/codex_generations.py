

# Generated at 2022-06-23 11:39:14.266084
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # Inputs for this test script
    terms = [
        '/etc/hostname',
        {'files': 'hostname2'},
        '/etc/hostname',
    ]

    variables = dict()
    kwargs = dict()

    # Outputs of this test script
    result = lookup.run(terms, variables, **kwargs)
    assert result == ['/etc/hostname']

    # Inputs for this test script
    terms = [
        {'files': 'hostname3', 'paths': '/etc'},
    ]

    variables = dict()
    kwargs = dict()

    # Outputs of this test script
    result = lookup.run(terms, variables, **kwargs)
    assert result == ['/etc/hostname3']

    # Inputs for this test

# Generated at 2022-06-23 11:39:16.070368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 11:39:24.812804
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    term = [
        '/path/to/file1.txt',
        {'files': ['foo1', 'foo2'], 'paths': ['bar1', 'bar2']},
        '/path/to/file3.txt'
    ]

    terms, skip = lookup_plugin._process_terms(term, None, None)

    assert terms == [
        '/path/to/file1.txt',
        '/bar1/foo1',
        '/bar2/foo1',
        '/bar1/foo2',
        '/bar2/foo2',
        '/path/to/file3.txt'
    ]
    assert skip is False

    term = ['/path/to/file1.txt']
    terms, skip = lookup_plugin._process_terms(term, None, None)

# Generated at 2022-06-23 11:39:32.010932
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.module_utils._text import to_bytes

    # test basic instantiation
    c1 = LookupModule()
    assert isinstance(c1, LookupModule)

    # test instantiation with an inventory
    with open(os.path.join(os.path.dirname(__file__), 'inventory'), 'rb') as f:
        inv_data = to_bytes(f.read())

    c1 = LookupModule()
    c1.set_loader(inv_data)
    assert isinstance(c1, LookupModule)

# Generated at 2022-06-23 11:39:41.672843
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1
    lookup_mod = LookupModule(loader=None, templar=None, variables=None)
    terms = [{'files': 'foo.txt', 'paths': '.'}]
    result = lookup_mod.run(terms=terms, variables=None)
    print("result: %s" % result)

    # test case 2
    lookup_mod = LookupModule(loader=None, templar=None, variables=None)
    terms = [{'files': 'foo.txt,bar.txt', 'paths': '.'}]
    result = lookup_mod.run(terms=terms, variables=None)
    print("result: %s" % result)

    # test case 3
    lookup_mod = LookupModule(loader=None, templar=None, variables=None)
   

# Generated at 2022-06-23 11:39:45.997637
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    testObj = LookupModule()
    results = testObj.run(
        terms=[
            {
                'files': 'foo.conf,bar.conf',
                'paths': '/tmp/production,/tmp/staging',
                'skip': False
            },
            'baz.conf'
        ],
        variables={}
    )
    assert results == [], \
            'No file was found when using first_found.'


# Generated at 2022-06-23 11:39:48.379073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert hasattr(lookup_module, 'run')


# Generated at 2022-06-23 11:39:59.317489
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class VarsModule:

        def __init__(self, dict):
            self.vars = dict

        def get_vars(self, loader, path, entities, cache=True):
            return self.vars

    # GET /usr/dfw/lib/ansible/module_utils/common/__init__.py
    # GET /usr/dfw/lib/ansible/module_utils/common/_collections_compat.py
    # GET /usr/dfw/lib/ansible/module_utils/six/__init__.py
    # GET /usr/lib/python2.7/site-packages/six.py
    # GET /usr/lib64/python2.7/site-packages/_six.py
    # GET /usr/dfw/lib/ansible/plugins/loader.py
    # GET

# Generated at 2022-06-23 11:40:10.089114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    simple_params = [
        {'files': 'a,b', 'paths': ":, /tmp"},
        {'files': 'c,d', 'paths': ":, /tmp"},
    ]
    simple_result = [
        'a',
        'b',
        'c',
        'd',
        '/tmp/a',
        '/tmp/b',
        '/tmp/c',
        '/tmp/d',
    ]

    # NOTE: used to be an example
    # 'foo, bar', {'paths': ":, /tmp"}
    # but it is wrong because results in "foo, bar" and not 'foo', 'bar', '/tmp/foo', '/tmp/bar'
    mixed_params = [
        'a, b', {'paths': ":, /tmp"},
    ]
    mixed_

# Generated at 2022-06-23 11:40:16.913487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    path1 = 'foo'
    path2 = 'bar'
    term = {'paths': path1, 'files': path2}
    lookup = LookupModule()
    lookup.set_options(var_options=None, direct=term)
    assert lookup.get_option('paths') == path1
    assert lookup.get_option('files') == path2
    assert lookup.get_option('skip') == False
    return

# Generated at 2022-06-23 11:40:30.005683
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = (LookupModule())

    # tests for dict files
    assert lookup.run([{'files': 'foo'}], [], []) == ['foo']
    assert lookup.run([{'files': 'foo', 'skip': True}], [], []) == []
    assert lookup.run([{'files': 'foo', 'paths': 'bar'}], [], []) == ['bar/foo']
    assert lookup.run([{'files': 'foo', 'paths': 'bar', 'skip': True}], [], []) == []
    assert lookup.run([{'files': 'foo,bar'}], [], []) == ['foo', 'bar']
    assert lookup.run([{'files': 'foo,bar', 'skip': True}], [], []) == []

# Generated at 2022-06-23 11:40:40.945632
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.vault import VaultEditor
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    single_file = "file1"
    single_file_list = ["file1"]
    multiple_files = ["file1", "file2"]
    multiple_paths = ["dir1", "dir2"]
    files_in_paths = ["file1", "file2", "dir1", "dir2"]
    single_file_and_path = ["file1", "dir1"]
    list_in_list = ["file1", ["file2", "file3"]]

    single_file_and_list = ["file1", ["file2", "file3"]]


# Generated at 2022-06-23 11:40:45.733896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    examples = EXAMPLES
    # Execute
    from ansible.plugins.lookup import LookupBase
    lookupBase = LookupBase()
    try:
        lookupBase.run(examples, None)
    # Assert
    except:
        assert False, 'Raised exception.'
    # Assert
    assert True

# Generated at 2022-06-23 11:40:58.792691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    # run is called from the task executor, so task_queue_manager is needed
    from ansible.plugins.callback import CallbackBase
    class CallbackModule(CallbackBase):
        """A fake callback plugin used to test the lookup plugins."""

# Generated at 2022-06-23 11:41:00.974527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 11:41:05.147337
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # passing in an empty list or params
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 11:41:16.040672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: note this is a mock, not a real type!
    module_utils_common_collections_compat_Mapping = type("Mapping", (Mapping,), {})
    module_utils_common_collections_compat_Sequence = type("Sequence", (Sequence,), {})
    class a(object):
        def __init__(self, template=None):
            self.template = template
    class b(dict):
        def get_option(self, option, default=None):
            return self.get(option, default)
        def set_options(self, var_options, direct):
            self.update(direct)
    class c(object):
        def __init__(self):
            self.TEST_VAR = "test"

# Generated at 2022-06-23 11:41:28.332391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.loader import lookup_loader

    # save original open() to restore at the end of this unit test
    if PY3:
        original_open = builtins.open
    else:
        original_open = open

    # mock open the file lookup was expected to find
    def mock_open_ok(file_name, *args, **kwargs):
        class s(object):
            def __init__(self, file_name, *args, **kwargs):
                self.file_name = file_name
            def read(self):
                return "find me"
            def close(self):
                pass

# Generated at 2022-06-23 11:41:40.182131
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ###############################################
    # 1. Basic usage                              #
    ###############################################

    # Use a list of files and relative paths
    data_in = [
        '/path/to/foo.txt',
        'bar.txt',
        '/path/to/biz.txt',
    ]
    expected = '/path/to/foo.txt'

    lookup = LookupModule()
    result = lookup.run(data_in, variables={}, **{})
    assert result[0] == expected, result

    ###############################################
    # 2. Use a dictionary with files and paths    #
    ###############################################

    # Use a list of files and absolute paths

# Generated at 2022-06-23 11:41:40.698170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-23 11:41:44.902531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test case with invalid term input
    assert lookup.run(['bb'], {}) == ['bb']

    # Test case with valid term input
    lookup.find_file_in_search_path = lambda  variable, subdir, fn: 'first_found'
    assert lookup.run('first_found', {}) == ['first_found']

# Generated at 2022-06-23 11:41:46.618265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule("first_found",{},"terms")


# Generated at 2022-06-23 11:41:47.624436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: LookupModule test
    pass

# Generated at 2022-06-23 11:41:48.273472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:41:57.725628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    # directory created with os.makedirs
    makedirs_path = os.path.abspath(os.path.join(
        os.path.frozenglobals()['__file__'],
        "..", "..", "test", "makedirs_tmp"))
    # directory created when running test for ansible
    # not cleaned up by test/__init__.py
    ansible_path = os.path.abspath(os.path.join(
        os.path.frozenglobals()['__file__'],
        "..", "..", "test", "units", "files", "ansible_tmp"))
    ansible_files = ["hello", "world", "ansible", "file"]

    # create tmp directory

# Generated at 2022-06-23 11:42:02.543522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\nTesting LookupModule.run()")
    # Need to mock LookupModule class, module_utils/ and jinja2/
    # See https://docs.python.org/3/library/unittest.mock.html

    # TODO: fix mock, use it and correct the module

# Generated at 2022-06-23 11:42:05.174700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']
    variables = dict()
    lookup_instance = LookupModule()
    assert Terms == type(terms)
    assert dict == type(variables)
    assert LookupModule == type(lookup_instance)
    assert None == lookup_instance.run(terms, variables)

# Generated at 2022-06-23 11:42:08.376398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Lookup module doesn't work without run() method
    if hasattr(lookup, 'run'):
        return True

    return False


# Generated at 2022-06-23 11:42:10.472604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm._subdir == 'files'
    assert not lm._loader

# Generated at 2022-06-23 11:42:22.011277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = DummyTemplar()

    # create a mock collection loader
    loader = DummyCollectionLoader()

    # create a mock finder
    finder = DummyFinder()

    # create a test class with in-memory vars
    lookup_module = LookupModule(loader=loader, templar=templar, finder=finder)
    # create a mock variables
    variables = dict()

    # setup finder
    finder.paths = ['/play/roles/role/tasks/']

# Generated at 2022-06-23 11:42:27.024311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    fn = '/usr/local/file.txt'
    with patch.multiple(x, _get_file_contents=DEFAULT, _get_file_contents_encoding=DEFAULT, _get_file_size=DEFAULT, _process_terms=DEFAULT, _resolve_search_path=DEFAULT):
        x._process_terms.return_value = [fn], False
        ret = x.run([{'files': 'file.txt', 'paths': '/usr/local'}], None, skip=True)
        expected = [fn]
        assert ret == expected, "'%s' != '%s'" % (ret, expected)

# Generated at 2022-06-23 11:42:38.905160
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test using two files as arguments
    terms = ['file1', 'file2']
    mock_loader = ansible.parsing.dataloader.DataLoader()
    mock_loader.set_basedir('/some/path')
    mock_templar = ansible.template.Templar(loader=mock_loader)
    lookup_module = LookupModule(loader=mock_loader, templar=mock_templar)

    assert lookup_module._process_terms(terms, dict(), dict())[0] == ['/some/path/file1', '/some/path/file2']

    # Test using a dictionary in the arguments
    parameters = dict()
    parameters['files'] = ['file1', 'file2']

# Generated at 2022-06-23 11:42:47.045989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.json_utils import _json_decode

    def _mock_load_file(*args):
        return "test_file"

    def _mock_load_from_file(*args):
        mock_data = _json_decode('{"files": ["foo","bar"], "paths": ["/tmp"]}')
        return mock_data


# Generated at 2022-06-23 11:42:52.936404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.errors import AnsibleLookupError
    from ansible.utils.display import Display

    # initializing parameters
    display = Display()

    # creating a fake file_name and path
    file_name = os.path.join(os.path.expanduser("~"), "test_run.txt")

    # creating the file in the home directory
    fo = open(file_name, "wb")
    fo.write("Test File")

    # initializing class LookupModule
    lookup = LookupModule(loader = None, display = None)
    lookup_class = type(lookup)

    # creating the object
    lookup_obj = lookup_class()

    # initializing parameters to test method
    lookup_obj.set_loader(loader = None)

# Generated at 2022-06-23 11:43:05.344055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.path import unfrackpath

    class LookupModuleFake(LookupModule):
        def __init__(self, terms, variables=None, **kwargs):
            self.set_options(direct=dict(extensions=['yaml', 'yml']))
            return

        def find_file_in_search_path(self, variables, searchpath, file, ignore_missing=False):
            file_path = unfrackpath("/etc/ansible/ansible.cfg")
            return file_path

        def run(self, terms, variables=None, **kwargs):
            return terms


# Generated at 2022-06-23 11:43:17.901922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_1 = LookupModule()
    lookup_1.set_options('my_lookup', {'extensions': 'txt, pdf'})
    lookup_2 = LookupModule()
    lookup_2.set_options('my_lookup', {'extensions': 'xml'})
    lookup_2.set_options('my_lookup', {'extensions': 'yml'})
    lookup_3 = LookupModule()
    lookup_3.set_options('my_lookup', {'extensions': ''})
    lookup_4 = LookupModule()
    lookup_4.set_options('my_lookup', {})
    lookup_5 = LookupModule()


# Generated at 2022-06-23 11:43:20.498309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test LookupModule constructor
    # create a LookupModule object
    p = LookupModule()
    # test the constructor
    assert p

# Generated at 2022-06-23 11:43:30.252832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = []
    terms.append({'files': 'file1.txt,file2.txt', 'paths': 'path1,path2'})
    terms.append({'files': 'file1.txt,file2.txt'})
    terms.append({'files': 'file1.txt,file2.txt', 'paths': 'path1,path2', 'skip': False})
    terms.append({'files': 'file1.txt,file2.txt', 'paths': 'path1,path2', 'skip': True})
    lookup._process_terms(terms, None, None)
    terms = []
    terms.append({'files': ['file1.txt', 'file2.txt'], 'paths': ['path1', 'path2']})

# Generated at 2022-06-23 11:43:40.307178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    lookup = lookup_loader.get('first_found')

    paths = [ "/dev" ]
    path_file1 = "/dev/null"

    file_name1 = "null"
    file_name2 = "ttyS1"

    file_list = [ file_name1, file_name2 ]

    file_list_dict = { "files": [ file_name1, file_name2 ] }
    file_list_dict_and_path = { "files": [ file_name1, file_name2 ], "paths": paths }


# Generated at 2022-06-23 11:43:41.154031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:43:45.584653
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup._subdir == 'files'
    assert lookup._basedir is None
    assert lookup._loader is None
    assert len(lookup.case_sensitive_suffixes) == 0
    assert lookup.get_option('paths') == []
    assert lookup.get_option('files') == []
    assert lookup.get_option('skip') == False

# Generated at 2022-06-23 11:43:54.004946
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert LookupModule().run([], dict(), []) == [], 'should return empty list'
    assert LookupModule().run([1], dict(), []) == [1], 'should return list of one item'
    assert LookupModule().run([1, 2, 3], dict(), []) == [1, 2, 3], 'should return list of three items'
    assert LookupModule().run(1, dict(), []) == [1], 'should return list of one item'
    assert LookupModule().run(None, dict(), []) == [], 'should return empty list'

    errors = []

# Generated at 2022-06-23 11:44:01.750250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # load module
    from ansible import context
    import ansible.utils
    import ansible.module_utils.basic

    # use a fake file as we don't want to create a file
    terms = [{"files": "default.yml", "paths": ansible.utils.path.getcwd()}]
    plugin = LookupModule()
    ret = plugin.run(terms, context.CLIARGS)
    assert ret == [ansible.utils.path.getcwd() + "/default.yml"]

# Generated at 2022-06-23 11:44:13.661598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # define a dict type class to be used as term in lookup
    class ParamsDict(Mapping):
        def __init__(self, files=None, paths=None):
            self.files = files
            self.paths = paths

        def __getitem__(self, key):
            if key == 'files':
                return self.files
            if key == 'paths':
                return self.paths
            raise KeyError('Invalid key "%s"' % key)

        def __len__(self):
            return 2


# Generated at 2022-06-23 11:44:15.951942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_instance = LookupModule()
    assert isinstance(LookupModule_instance.run([1, 2, 3], {}), list)

# Generated at 2022-06-23 11:44:28.967243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Call the create_lookup_plugin() method of the LookupBase class.
    # This will create an instance of the LookupModule class
    module = LookupBase.create_lookup_plugin('first_found')

    # Get the "run" method from the LookupModule class
    method = getattr(module, 'run')

    # Get the docstring for the "run" method.
    docstring = method.__doc__

    # The following assert checks if the class has the "run" method.
    assert docstring, 'The LookupModule class does not have the "run" method'

    # The following assert checks if the "run" method has the "terms" argument.
    assert 'terms' in method.__code__.co_varnames, 'The "run" method does not have a "terms" argument'

    # The

# Generated at 2022-06-23 11:44:39.384541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.first_found as first_found

    lookup_module = first_found.LookupModule()

    # test _split_on
    result = first_found._split_on(None)
    assert len(result) == 0

    result = first_found._split_on('a,b,c:d')
    assert len(result) == 4
    assert 'a' in result
    assert 'b' in result
    assert 'c' in result
    assert 'd' in result

    result = first_found._split_on(['a,b', 'c:d'])
    assert len(result) == 4
    assert 'a' in result
    assert 'b' in result
    assert 'c' in result
    assert 'd' in result

    # test _process_terms
    result,

# Generated at 2022-06-23 11:44:47.664558
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # dictionary to simulate a term
    term_mock = {
        "files": "foo",
        "paths": "bar",
        "skip": False,
    }

    # instance of class LookupModule for testing
    lookup_module_instance = LookupModule()

    # when term is a dictionary that is empty
    test_result = lookup_module_instance.run({}, variables={}, **{})
    assert test_result == []

    # when term is a dictionary that have one item
    test_result = lookup_module_instance.run({term_mock}, variables={}, **{})
    assert test_result == []

    # when term is a dictionary that have one item, the item have multi items
    test_result = lookup_module_instance.run([term_mock, term_mock], variables={}, **{})


# Generated at 2022-06-23 11:44:49.678901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run([''], {}) == ['']


# Generated at 2022-06-23 11:44:55.458124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    if lm is None:
        raise Exception("creation of 'LookupModule' object failed")

    if lm.run is None:
        raise Exception("member 'run' not found in 'LookupModule' object")

    if lm._process_terms is None:
        raise Exception("member '_process_terms' not found in 'LookupModule' object")

# Generated at 2022-06-23 11:44:59.137433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l1 = LookupModule()
    result = l1.run([{"files": "foo,bar,baz", "paths": "p1,p2,p3"}], {})
    assert result == []

# Generated at 2022-06-23 11:45:00.286657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 11:45:09.942877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup = LookupModule()
    
    # Method run() with empty terms
    terms = []
    variables = {}
    assert lookup.run(terms, variables) == [], "Returned unexpected result"
    
    # Method run() with single term given as string
    terms = ["file.txt"]
    variables = {}
    assert lookup.run(terms, variables) == [], "Returned unexpected result"
    
    # Method run() with single term given as dictionary
    terms = [{"paths": ["/tmp/production"], "files": ["foo.txt"]}]
    variables = {}
    assert lookup.run(terms, variables) == [], "Returned unexpected result"
    
    # Method run() with multiple terms given as list of strings
    terms = ["file.txt", "file.txt"]
    variables = {}
   

# Generated at 2022-06-23 11:45:22.533630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import ansible.plugins.loader as plugins

    class TestLookupModule(unittest.TestCase):

        def test_lookup_files_paths_1(self):
            terms = ["{'files': ['foo.txt'], 'paths': ['path/to/dir']}"]
            ret = plugins.lookup_loader.get('first_found').run(terms, None, files=['foo.txt'], paths=['path/to/dir'])
            assert ret == ['path/to/dir/foo.txt'], ret

        def test_lookup_files_paths_2(self):
            terms = ["{'files': ['foo.txt'], 'paths': ['path/to/dir', 'path/to/other']}"]
            ret = plugins.lookup_loader.get

# Generated at 2022-06-23 11:45:32.310549
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

    # missing required option
    with pytest.raises(AnsibleLookupError):
        lookup.run(['file1'])

    lookup.set_options(direct={'files': 'file1'})
    assert lookup.get_option('files') == ['file1']

    # no error on empty list
    lookup.set_options(direct={'files': []})
    assert lookup.get_option('files') == []

    # empty list as term is also empty list
    assert lookup.run([]) == []

    lookup.set_options(direct={'files': 'file1'})
    assert lookup.get_option('files') == ['file1']

    # error on bad option

# Generated at 2022-06-23 11:45:34.010516
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:45:39.952448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'files'

    # Test common behaviour (1 path, 1 file)
    result = l.run([{"files": "foo", "paths": "/tmp"}], dict())
    assert result == ['/tmp/foo']

    # Test common behaviour (1 path, 2 file)
    result = l.run([{"files": "foo,bar", "paths": "/tmp"}], dict())
    assert result == ['/tmp/foo']

    # Test common behaviour (2 path, 1 file)
    result = l.run([{"files": "foo", "paths": "/tmp,/etc"}], dict())
    assert result == ['/tmp/foo']

    # Test common behaviour (2 path, 2 file)

# Generated at 2022-06-23 11:45:41.659807
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:45:43.452294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:45:49.453826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    cache = dict()

    results = []
    results.append(
        LookupModule(
            loader=loader,
            variables=variables,
            basedir=None
        ).run(
            terms=["UNIT_TEST"],
            variables=variables,
            inject=cache,
            filters=None,
            fail_on_undefined=True,
            search_paths=['files']
        )
    )

    # Get the first item in the results list
    result = results[0]

# Generated at 2022-06-23 11:45:55.966065
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.file_root is None
    assert lookup_plugin.files_root is None
    assert lookup_plugin.templar is None
    assert lookup_plugin.runner is None
    assert lookup_plugin.loader is None
    assert lookup_plugin.vars is None
    assert lookup_plugin._filter_loader is None
    assert lookup_plugin.basedir is None
    assert lookup_plugin._display is None
    assert lookup_plugin._last_searchpaths is None
    assert lookup_plugin._uuid is None
    assert lookup_plugin._SUFFIXES is None



# Generated at 2022-06-23 11:45:59.239224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate class
    lm = LookupModule()
    
    # Execute the run method
    result = lm.run([])
    assert result == []

# Generated at 2022-06-23 11:46:02.280353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_plugin = LookupModule()
    except:
        lookup_plugin = None
        assert lookup_plugin, "failed to instantiate LookupModule"

# Generated at 2022-06-23 11:46:11.415923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run'), 'hasattr(lm, "run")'
    assert hasattr(lm, 'run'), 'hasattr(lm, "run")'
    assert hasattr(lm, '_process_terms'), 'hasattr(lm, "_process_terms")'
    assert hasattr(lm, '_split_on'), 'hasattr(lm, "_split_on")'

    # test _split_on function
    test_string_list = ['bar', 'baz', 'foo']
    assert test_string_list == lm._split_on(test_string_list), 'test_string_list == lm._split_on(test_string_list)'
    test_string = 'foo,bar,baz'
    assert test_string

# Generated at 2022-06-23 11:46:13.104883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 11:46:21.489013
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # validate that 'files' and 'paths' are correct
    def _validate(data, result):

        # check if LookupModule is initialised
        assert isinstance(data, LookupModule)

        # check if terms were processed well
        assert result == data.run(terms, variables=variables, with_file_content=True)

    # create LookupModule instance
    module = LookupModule()
    # create variables which can be used for templating
    variables = dict(
        file1="file1",
        value1="value1",
        path1="path1",
        path2="path2",
    )

    # test that first_found lookup works with a list of strings
    terms = ["file1", "file2", "file3"]
    result = ["file1"]

# Generated at 2022-06-23 11:46:31.815404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   import pytest
   from ansible.module_utils.six import string_types
   from ansible.plugins.lookup.first_found import LookupModule
   from ansible.module_utils.ansible_release import __version__
   from ansible.utils.version import LooseVersion

   lookup_module = LookupModule()
   assert LooseVersion(__version__) >= LooseVersion("2.5.0"), "It is not guaranteed that LookupModule.run() works with Ansible 2.4.x or below."

   ### Check that it handles "strings" (not lists) as arguments
   assert lookup_module.run("foo", {}) == [], "LookupModule.run() should return an empty list if skip=True (default)"
   # ********* Check that it handles "strings" (not lists) as arguments *********
  

# Generated at 2022-06-23 11:46:32.781846
# Unit test for constructor of class LookupModule
def test_LookupModule():

    obj = LookupModule()
    assert obj

# Generated at 2022-06-23 11:46:42.744290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    from ansible.utils.path import write_file
    from ansible.errors import AnsibleLookupError
    lookup = LookupModule()
    lookup._subdir = tempfile.mkdtemp()
    write_file("{0}/dummy_file".format(lookup._subdir), 'dummy_file')

    # Test for success when file is found
    rc = lookup.run(['dummy_file'])
    assert rc == ['dummy_file']
    # Test for failure when file is not found
    rc = lookup.run(['dummy_file_missing'])
    assert isinstance(rc, AnsibleLookupError)

    # Test for success when file is found taking into account the subdir
    rc = lookup.run([lookup._subdir + '/dummy_file'])

# Generated at 2022-06-23 11:46:50.007004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # simple test
    terms_val = ['bar', 'this/is/a/path/foo.txt', 'foo', {'files': ['bar', 'foo'], 'paths': ['lookup_does_this/does_not_exist/', 'this/is/a/path']}]
    variables_val = {}
    kwargs_val = {}
    file_found, skip = lookup._process_terms(terms_val, variables_val, kwargs_val)

# Generated at 2022-06-23 11:46:51.165277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 11:47:03.656419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # 1st test:
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={"files": ["/tmp/foo.txt"], "paths": ["/tmp", "/etc/passwd"], "skip": True})
    result = lookup_module.run([], {})
    assert result == [], "Error at test_LookupModule_run(): result should be [] but is {}".format(result)
    # 2nd test:
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={"files": ["/tmp/foo.txt"], "paths": ["/tmp", "/etc/passwd"], "skip": False})

# Generated at 2022-06-23 11:47:08.295509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    files = ['test2.txt', 'test1.txt']
    kws = {'files': files}
    terms = [kws, 'test3.txt']

    results = LookupModule().run(terms, {}, **kws)

    assert results == ['/default/path/to/test1.txt'], "LookupModule failed to run"

# Generated at 2022-06-23 11:47:13.934290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm._subdir = 'files'
    lm._templar = None
    assert lm.run(
        terms=[{'files': ['foo', 'bar']}, 'biz'],
        variables={},
        parameters={'paths': ['/etc/hosts', '/tmp']},
    ) == []



# Generated at 2022-06-23 11:47:27.090246
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [dict(files=['file1', 'file2'],
                  paths=['/path/1', '/path/2'],
                  skip=True),
             dict(files=['file3', 'file4'],
                  paths=['/path/3', '/path/4'],
                  skip=False)]

    variables = {}
    options = dict(files=['fileA', 'fileB'],
                   paths=['/path/A', '/path/B'],
                   skip=True)
    options.update(kwargs = dict(files=['file1', 'file2'],
                           paths=['/path/1', '/path/2'],
                           skip=True))

    module = LookupModule()

    # checking parameter search in _process_terms()

# Generated at 2022-06-23 11:47:29.795371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    assert lookup is not None


# Generated at 2022-06-23 11:47:31.184174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 11:47:35.690142
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    # test name
    assert lm.name == "first_found", "Test 'name' attribute."

    # test run
    assert lm.run(terms=["vars/base.yml", "vars/{{ ansible_distribution }}.yml"], variables={}, skip=False), "Test 'run' method."

# Generated at 2022-06-23 11:47:38.212325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options({'one':1, 'two':2})
    assert lookup.get_option('one') == 1
    assert lookup.get_option('two') == 2
    assert lookup.get_option('nonexistant', 'default') == 'default'

    

# Generated at 2022-06-23 11:47:40.139133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')



# Generated at 2022-06-23 11:47:49.512911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(AnsibleLookupError, match=r'Invalid term supplied, can handle string, mapping or list of strings but got: <class \'list\'> for'):
        LookupModule(loader=None, templar=None, **{}).run(terms=[], variables=None)
    with pytest.raises(AnsibleLookupError, match=r'Invalid term supplied, can handle string, mapping or list of strings but got: <class \'dict\'> for'):
        LookupModule(loader=None, templar=None, **{}).run(terms={}, variables=None)


# Generated at 2022-06-23 11:47:53.518286
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert lookup_module != None

    # https://docs.python.org/2/library/unittest.html#assert-methods
    assert lookup_module.__class__.__name__ == 'LookupModule'



# Generated at 2022-06-23 11:47:58.992760
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test config in terms
    terms = [{'files': 'foo.1', 'paths': 'bar1;bar2'}]
    mod = LookupModule()
    mod._process_terms(terms, {}, {})
    assert mod.get_option('files') == ['foo.1'], 'Files option should be ["foo.1"], is %s' % mod.get_option('files')
    assert mod.get_option('paths') == ['bar1', 'bar2'], 'Paths option should be ["bar1", "bar2"], is %s' % mod.get_option('paths')

    terms = [{'files': 'foo.1,foo.2', 'paths': 'bar1,bar2'}]
    mod = LookupModule()
    mod._process_terms(terms, {}, {})

# Generated at 2022-06-23 11:48:07.368118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance._templar = lambda x: x
    lookup_instance.find_file_in_search_path = lambda x, a, b, c: b

    # Test invalid type of terms
    try:
        lookup_instance.run(1, {})
        assert False
    except AnsibleLookupError:
        assert True
    except:
        assert False

    # Test invalid types in terms list
    try:
        lookup_instance.run(["a", 1], {})
        assert False
    except AnsibleLookupError:
        assert True
    except:
        assert False

    # Test with no path or file and skip=False
    try:
        lookup_instance.run(["a"], {})
        assert False
    except AnsibleLookupError:
        assert True


# Generated at 2022-06-23 11:48:19.880451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    orig_find_file_in_search_path = lookup.find_file_in_search_path
    def mocked_find_file_in_search_path(variables, subdir, fn, ignore_missing=False):
        if fn == '/path/to/foo.txt':
            return True
        return orig_find_file_in_search_path(variables, subdir, fn, ignore_missing)
    lookup.find_file_in_search_path = mocked_find_file_in_search_path

    # Basic lookup

# Generated at 2022-06-23 11:48:20.810328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:48:26.233911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Tests the constructor of class LookupModule"""
    mock_loader = MagicMock()
    mock_templar = MagicMock()
    params = {
        '_loader': mock_loader,
        '_templar': mock_templar
    }
    lookup_obj = LookupModule(**params)
    assert lookup_obj
    assert lookup_obj._loader == mock_loader
    assert lookup_obj._templar == mock_templar

# Copied from ansible/plugins/lookup/__init__.py

# Generated at 2022-06-23 11:48:37.624815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    parameters = {
        'files': ['file1', 'file2'],
        'paths': ['/path1', '/path2'],
        'skip': False
    }
    terms = [parameters]
    variables = {}
    kwargs = {}
    lookup_module._templar = Fake_Templar()
    # Test successful search
    lookup_module.find_file_in_search_path = fake_find_file_in_search_path_success
    expected_output = ['/path1/file1']
    assert lookup_module.run(terms, variables, **kwargs) == expected_output
    # Test unsuccessful search
    lookup_module.find_file_in_search_path = fake_find_file_in_search_path_failure
    assert lookup

# Generated at 2022-06-23 11:48:49.147581
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # build mock_loader to test static methods
    class mock_loader(object):
        def __init__(self):
            self.path_data = {}
            self.searchpath = []
            self.basedir = ''
            self.current_basedir = ''

        def path_dwim(self, basedir, given_path):
            return self.path_data[given_path]

        def get_basedir(self, task_vars=None):
            return self.basedir

        def set_basedir(self, basedir):
            pass

        def set_current_basedir(self, basedir):
            self.current_basedir = basedir

        def get_searchpath(self):
            return self.searchpath

        def _add_ansible_search_path(self, path):
            self.search

# Generated at 2022-06-23 11:48:50.149930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule("first_found", None, {}, {})

# Generated at 2022-06-23 11:48:51.402618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:48:52.702391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ToDo: write unit tests
    pass


# Generated at 2022-06-23 11:48:55.957695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupBase)
    assert isinstance(instance, LookupModule)

# Test '_process_terms' method of class LookupModule
# !UNKNOWN

# Generated at 2022-06-23 11:48:58.681992
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, '_process_terms')

# Generated at 2022-06-23 11:49:09.135043
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lu = LookupModule()

    # process_terms test
    lu._subdir = 'files'
    total_search, skip = lu._process_terms(['foo'], {}, {})
    assert total_search == ['foo']
    assert skip is False

    total_search, skip = lu._process_terms(['foo', 'bar'], {}, {})
    assert total_search == ['foo', 'bar']
    assert skip is False

    # set skip
    total_search, skip = lu._process_terms(['foo', 'bar'], {}, {'skip': True})
    assert total_search == ['foo', 'bar']
    assert skip is True

    # set skip