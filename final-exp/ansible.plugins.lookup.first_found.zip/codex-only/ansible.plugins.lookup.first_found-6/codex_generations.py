

# Generated at 2022-06-23 11:39:01.078352
# Unit test for constructor of class LookupModule
def test_LookupModule():
    unit = LookupModule()


# Generated at 2022-06-23 11:39:09.858773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    terms = [{'files': 'foo.txt', 'paths':'bar.txt', 'skip':True }, 'file2.txt', [ 'files', 'paths' ]]
    variables = {}
    parameters = {}
    obj_lookup = LookupModule()

    # Object.get_option() is not patched so will use default set in clas
    total_search, skip = obj_lookup._process_terms(terms, variables, parameters)

    assert sorted(total_search) == ['bar.txt/foo.txt', 'file2.txt', 'files', 'paths']
    assert skip


test_LookupModule_run()

# Generated at 2022-06-23 11:39:11.017389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:39:11.894268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:39:13.237110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()

# Generated at 2022-06-23 11:39:15.486905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    if not isinstance(lookup, LookupBase):
        raise AssertionError('Must be of class LookupBase')

# Generated at 2022-06-23 11:39:17.059598
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 11:39:25.316012
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test _process_terms
    # nothing set, single string
    terms = ["/some/file"]
    variables = {}
    lookup = LookupModule()
    search, skip = lookup._process_terms(terms, variables, {})
    assert (search[0] == "/some/file")
    assert (len(search) == 1)
    assert (skip == False)

    # we invert the input of ansible to better test spliting
    # on ',' or ';'
    # nothing set, list of strings
    terms = ["one,two;five"]
    variables = {}
    lookup = LookupModule()
    search, skip = lookup._process_terms(terms, variables, {})
    assert (search[0] == "one")
    assert (search[1] == "two")

# Generated at 2022-06-23 11:39:34.785238
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ['foo.txt', 'bar.txt', 'biz.txt']

    # test with list
    lookup = LookupModule()

    test_result = lookup._process_terms(terms, variables=None, kwargs=None)
    assert test_result == ([], True)

    # test with dictionary
    lookup = LookupModule()

    test_result = lookup._process_terms(terms, variables=None, kwargs={'files': 'foo.txt', 'skip': False})
    assert test_result == ([], False)
    test_result = lookup._process_terms(terms, variables=None, kwargs={'paths': 'meh.txt', 'skip': False})
    assert test_result == ([], False)

    # test with mixed list
    lookup = LookupModule()

    test_result = lookup._process

# Generated at 2022-06-23 11:39:43.446728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugins
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from copy import deepcopy
    from ansible.utils.display import Display

    def _process_terms(terms, variables, kwargs):
        # simulate the real _process_terms method
        return terms, variables

    # tests can be found in test/units/plugins/lookup/test_first_found.py

    # define args for unit tests

# Generated at 2022-06-23 11:39:45.139080
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._process_terms == LookupModule._process_terms

# Generated at 2022-06-23 11:39:55.515945
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:40:03.637496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    list_terms_file = ['/tmp/file1.txt', '/tmp/file2.txt']
    list_terms_file_with_dict = ['/tmp/file1.txt', {'files': '/tmp/file2.txt', 'paths': '/tmp'}]
    list_terms_paths = [{'paths': '/tmp', 'files': 'file1.txt'}, '/tmp/file2.txt']

    # test first with no file in list
    list_terms_file.append('not_exist')
    try:
        module.run(terms=list_terms_file, variables=None)
        assert False
    except AnsibleLookupError:
        pass

    # test with a file in the list
    list_terms_file.pop()

# Generated at 2022-06-23 11:40:09.396598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_mapping = [{'files': 'foo', 'paths': 'bar'}, {'files': 'foo', 'paths': 'bar'}]
    var_option = {}
    variables = {}
    expected_result = ['/tmp/bar/foo', '/tmp/bar/foo']
    lookup_instance = LookupModule()
    assert lookup_instance.run(terms_mapping, variables) == expected_result

# Generated at 2022-06-23 11:40:20.857329
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:40:32.801331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import stat
    import tempfile
    import pytest

    @pytest.fixture
    def setup_test_module(request):
        # create fake module
        fd, temp_file = tempfile.mkstemp(prefix='test_doc_template')
        module_args = dict(
            _original_file=temp_file,
            path=[os.path.dirname(temp_file)],
        )
        os.chmod(temp_file, stat.S_IRUSR | stat.S_IWUSR)

        @request.addfinalizer
        def cleanup():
            os.remove(temp_file)

        return temp_file, 'fake_module', module_args

    @pytest.fixture
    def setup_valid_args(request):
        temp_file, module_name,

# Generated at 2022-06-23 11:40:44.728110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_native

# Generated at 2022-06-23 11:40:55.916327
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = [
        dict(files=['test1', 'test2'], paths=['/test/path1', '/test/path2']),
        dict(files=['test3']),
        dict(paths=['/test/path3']),
    ]
    variables = None
    lookup_instance = LookupModule()
    total_search, skip = lookup_instance._process_terms(terms, variables, {})
    assert total_search == ['/test/path1/test1', '/test/path1/test2', '/test/path2/test1', '/test/path2/test2', 'test3', '/test/path3']
    assert skip is False

# Generated at 2022-06-23 11:41:05.113089
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    variables = dict()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=combine_vars(None, variables))
    lookup = LookupModule(loader=loader, templar=templar)

    # input data
    # could use ansible.utils.unsafe_proxy.AnsibleUnsafeText, but in some versions it is not available (ansible 2.4)
    # TODO: try to use again after removing system-python
    # subdir = AnsibleUnsafeText('template')
    subdir = 'template'

# Generated at 2022-06-23 11:41:15.983944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # tests for first_found with paths and files
    terms = [{'paths': 'foo,bar', 'files': 'hoo,far'}]
    expect = [os.path.join('foo', 'hoo'), os.path.join('bar', 'hoo'),
              os.path.join('foo', 'far'), os.path.join('bar', 'far')]
    assert expect == lookup.run(terms, {}, undefined=None)

    terms = [{'paths': ['foo', 'bar'], 'files': ['hoo', 'far']}]
    expect = [os.path.join('foo', 'hoo'), os.path.join('bar', 'hoo'),
              os.path.join('foo', 'far'), os.path.join('bar', 'far')]

# Generated at 2022-06-23 11:41:28.012318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simulate the conditions for a lookup module run
    # Module parameters
    terms = [
        # Mapping
        {'files': '/etc/profile, /etc/bash.bashrc',
         'paths': '/etc,/usr/local/etc',
         'skip': False,
         '_terms': ['meow']},
        # List
        ['/etc/resolve.conf, /etc/hosts'],
        # Strings
        'foo.sh, baz.sh', 'bar.sh', 'baz.sh'
    ]

# Generated at 2022-06-23 11:41:29.834351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(['tests/fixtures/test_first_found'], {})
    # TODO

# Generated at 2022-06-23 11:41:30.802410
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:41:31.895412
# Unit test for constructor of class LookupModule
def test_LookupModule():
     l = LookupModule()

# Generated at 2022-06-23 11:41:34.408175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 11:41:45.058859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # init with arguments
  lookup = LookupModule()
  lookup.set_loader('/path/to/ansible')

  # define test data
  terms = [{"_terms": ["/path/to/foo", "bar"]}]
  variables = {'toto': 'tata'}
  kwargs = {}

  # call method run
  ret = lookup.run(terms, variables, **kwargs)

  # assert against result
  assert ret == ['/path/to/foo']

  # init with arguments
  lookup = LookupModule()
  lookup.set_loader('/path/to/ansible')

  # define test data
  terms = [{"_terms": ["toto", "tata"], "paths": "/tmp/test"}]
  variables = {'toto': 'tata'}
  k

# Generated at 2022-06-23 11:41:47.007320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:41:48.018241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:41:50.052232
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # We can not test this method because is looking for files on the file system
    return



# Generated at 2022-06-23 11:41:52.756666
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test without any parameter
    assert None == LookupModule()

    # test with parameters
    assert None == LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 11:42:03.738708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.plugins import lookup_loader

    current_dir = os.getcwd()

    lookup = lookup_loader.get('first_found')

    # NOTE: this replaces many calls and more
    # todo: moved to module_utils named common 
    #   test_get_config() / test_load_config_file() / test_set_options()
    def run(terms, paths=[], files=[], **kwargs):
        options = {'paths': paths, 'files': files}
        options.update(kwargs)
        options['run_once'] = True
        return lookup.run(terms, self.loader, self.templar, **options)


    # NOTE: this replaces many calls, but should it be 'common' to all lookups???
   

# Generated at 2022-06-23 11:42:04.184101
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert LookupModule()

# Generated at 2022-06-23 11:42:04.877212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



# Generated at 2022-06-23 11:42:14.321134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test dict option
    lookup = LookupModule()
    lookup._subdir = 'files'

    (total_search, skip) = lookup._process_terms(
        terms=[{'files': 'file1', 'paths': '/path1'}],
        variables={},
        kwargs={}
    )

    assert total_search == ['/path1/file1']
    assert skip is False

    # test list option
    lookup = LookupModule()
    lookup._subdir = 'files'

    (total_search, skip) = lookup._process_terms(
        terms=[[{'files': 'file1', 'paths': '/path1'}]],
        variables={},
        kwargs={}
    )

    assert total_search == ['/path1/file1']
    assert skip is False

   

# Generated at 2022-06-23 11:42:25.456533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    test1 = lm.run([{'paths': '/xyz/mydirectory'}], {})
    assert test1 == []

    test2 = lm.run([{'paths': '/xyz/mydirectory'}], {'_original_file': '/tmp/playbooks/play.yml',
                                                    '_original_path': '/tmp/playbooks'},
                                                    files='test.yml')
    assert test2 == []


# Generated at 2022-06-23 11:42:28.097584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm,LookupModule)


# Generated at 2022-06-23 11:42:29.548911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:42:41.757784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize test variable
    test_run = LookupModule()

    # Create test option dict
    test_data = {
        'terms': [
            'foo'
        ],
        'variables': {
            'test_var_1': 'test_value_1',
            'test_var_2': 'test_value_2',
            'test_var_3': 'test_value_3',
            'test_var_4': 'test_value_4',
            'test_var_5': 'test_value_5',
            'test_var_6': 'test_value_6'
        }
    }

    # Execute method run of class LookupModule

# Generated at 2022-06-23 11:42:45.029817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test for __init__ of class LookupModule
    # Since there are a lot of private methods in this or parent class, we test
    # the constructor only
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 11:42:56.434891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test LookupModule()
    lookup_module = LookupModule()

    # Test LookupModule._process_terms()
    #   Test case where term is a mapping
    class TestVariables:
        def get_vars(self, loader, path, entities, cache=True):
            return {'paths': ['/test'], 'files': ['test.txt']}
    variables = TestVariables()
    search_results, _ = lookup_module._process_terms([{}, '', []], variables, {})
    assert search_results == ['/test/test.txt']

    #   Test case where term is a string

# Generated at 2022-06-23 11:43:00.359966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(
        [{'files': 'foo', 'paths': '/tmp/production'}, 'bar.txt'],
        {},
        skip=True
    ) == [], lookup._plugin_options

# Generated at 2022-06-23 11:43:09.519602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible = importlib.import_module('ansible')

    lu = LookupModule()
    lu._templar = ansible.parsing.dataloader.DataLoader().load_basedir(".")
    lu.set_options(dict())

    files = [
        "a/b/c.txt",
        "foo.txt",
        "bar.txt",
        "baz.txt",
        "b.txt",
        "a.txt",
        "d.txt",
        "e.txt",
    ]

    (os.makedirs('a/b') if not os.path.isdir('a/b') else None)
    (os.makedirs('a/c') if not os.path.isdir('a/c') else None)

# Generated at 2022-06-23 11:43:22.643180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    # relative file
    terms = ('foo')
    variables = {'ansible_playbook_basedir': '/etc/ansible/tmp',
                 'playbook_dir': '/etc/ansible/tmp',
                 'hostvars': {}}

    lm = LookupModule()

    # mock the _templar.template() to return the same value
    lm._templar = type('', (), {'template': lambda a, b: b})
    # mock the ansible.plugins.lookup.LookupBase.find_file_in_search_path() to return None
    lm.find_file_in_search_path = lambda a, b, c, d: None

    assert lm.run(terms, variables) == []

    # Test 2
    # absolute file

# Generated at 2022-06-23 11:43:26.160576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    p = lookup.run(terms=["a"],variables={},files=["files","files1"],paths=["paths","paths1"])
    assert p[0] == "files"

# Generated at 2022-06-23 11:43:37.265960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # add lookup module to path
    import sys, os
    sys.path.insert(1, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins')))
    # Maybe append 'loaders' to sys.path, since that's where the parent class of TemplateFileLookup is
    # located. Not sure if this is needed.
    sys.path.insert(1, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'loaders')))


# Generated at 2022-06-23 11:43:46.491488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class OptionModule(object):
        def __init__(self):
            self.task_vars = {}
            self.templar = {}

    # test option variable
    terms = dict(files=['/etc/passwd', '/etc/shadow'],
                 paths=['/tmp', '/etc'],
                 skip=False)
    om = OptionModule()
    lm = LookupModule(loader=None, runner=om)
    om.task_vars = dict(ansible_virtualization_type='dummy')
    lm.set_options(var_options=om.task_vars, direct=terms)
    assert len(lm.get_option('files')) == 2
    assert len(lm.get_option('paths')) == 2
    assert lm.get_option('skip') == False

# Generated at 2022-06-23 11:43:50.798690
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # 
    lu = LookupModule()
    # 
    lu._templar = "foo"

    #
    lu.run(terms, variables, **kwargs)

    #
    lu.run(terms, variables, **kwargs)



# Generated at 2022-06-23 11:43:51.341894
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-23 11:43:52.628949
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_subject = LookupModule()
    assert test_subject is not None

# Generated at 2022-06-23 11:43:59.069987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    terms.append([{"paths": "/etc"}, {"paths": "/tmp"}])
    terms.append(["foo.conf", "bar.conf"])
    terms.append([{"paths": "/etc", "files": "foo.conf"}, {"paths": "/tmp", "files": "bar.conf"}])

    for term in terms:
        file_found = LookupModule().run(term, variables={}, wantlist=True)
        assert len(file_found) == 1
        assert os.path.isfile(file_found[0])


# Generated at 2022-06-23 11:44:05.644882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint bug: https://github.com/PyCQA/pylint/issues/511
    # pylint: disable=no-member
    from ansible.plugins.lookup.first_found import LookupModule

    # init module
    lookup = LookupModule()

    # init vars
    terms = [
        {'name': 'foo.yml'},
        {'name': 'bar.yml'},
        {'name': 'some.yml', 'paths': '/tmp/some/path:/tmp/some/path2'}]
    variables = {'names': ['foo', 'bar', 'some']}

    # call method
    total_search, skip = lookup._process_terms(terms, variables, variables)

    # check results

# Generated at 2022-06-23 11:44:15.544823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test when no file exists
    #subdir is not set
    assert LookupModule.run(["a.b"]) == []
    #subdir is set
    LookupModule._subdir = "subdir"
    assert LookupModule.run(["a.b"]) == []
    del LookupModule._subdir
    #Test when a file exists
    #subdir is not set
    assert LookupModule.run(["README.md"])[0] == "README.md"
    #subdir is set
    LookupModule._subdir = "subdir"
    assert LookupModule.run(["README.md"])[0] == "README.md"
    del LookupModule._subdir


# Generated at 2022-06-23 11:44:17.103763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 11:44:19.353624
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # FIXME: this is a mock, not a real test
    assert True

# Generated at 2022-06-23 11:44:31.468798
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:44:37.117032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        {'files': 'a/a.txt', 'paths': 'b/b.txt'},
        'foo',
        ['a', 'b', 'c']
    ]
    variables = dict()
    assert lookup_module.run(terms=terms, variables=variables, skip=False) == ["a/a.txt"]


# Generated at 2022-06-23 11:44:45.821699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lb = LookupBase()
    lm = LookupModule()
    lm._templar = lb._templar
    lm._loader = lb._loader
    lm.set_options(var_options={'_': {'vars': {}}})
    lm._subdir = 'test'

    test_path = "/path/to/test/run" # Should find test_file_in_test_run
    terms = [test_path + "/file1.yaml", test_path + "/file2.yaml"]
    result = lm.run(terms, {}, listify_results=True)
    assert result == [test_path + "/test_file_in_test_run"], "Expected one file, found: %s" % result

    test_path = "/path/to/test/run" #

# Generated at 2022-06-23 11:44:48.226358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 11:44:49.375110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:44:50.638822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-23 11:44:52.048792
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import ansible.plugins.lookup.first_found

    lookup = ansible.plugins.lookup.first_found.LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:45:03.597675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup class first
    lm = LookupModule()
    lm.set_options(var_options={}, direct={})
    my_terms = [{
        'files': ['file1', 'file2', 'file3'],
        'paths': ['path1', 'path2', 'path3'],
        'skip': True
    }, {
        'files': 'file4',
        'paths': 'path4',
        'skip': False
    }, {
        'files': 'file5',
        'paths': ['path5', 'path6'],
        'skip': True
    }, {
        'files': 'file6',
        'paths': 'path7'
    }
    ]
    # define function to run and return path of files

# Generated at 2022-06-23 11:45:04.930520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:45:06.378622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' constructor __init__ '''

    assert LookupModule(runner=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 11:45:11.715600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    try:
        assert isinstance(lookup_module, LookupModule)
    except:
        raise
    assert lookup_module._subdir == 'files'

    # Test templar for function _process_terms
    variables = getattr(lookup_module, '_templar', None)
    assert variables is not None

    print("LookupModule is tested")

# Generated at 2022-06-23 11:45:13.678312
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 11:45:23.755884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'files': 'z.txt',
         'paths': './test/lookup_plugins/pr/files'},
        {'files': 'z.txt',
         'paths': './test/lookup_plugins/pr/files'},
        "z.txt",
        "z.txt"
    ]
    variables = dict()
    # Act
    lm = LookupModule()
    result = lm.run(terms, variables, paths=[], files=[], skip=False)
    assert result == ['/home/jenkins/workspace/ansible-system-test/test/lookup_plugins/pr/files/z.txt']

# Generated at 2022-06-23 11:45:31.690144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    res = LookupModule()
    assert len(res._options) == 4
    assert 'paths' in res._options
    assert isinstance(res._options['paths'], dict)
    assert res._options['paths'].get('type') == 'list'
    assert 'files' in res._options
    assert isinstance(res._options['files'], dict)
    assert res._options['files'].get('type') == 'list'
    assert 'skip' in res._options
    assert isinstance(res._options['skip'], dict)
    assert res._options['skip'].get('type') == 'bool'


# Generated at 2022-06-23 11:45:43.658885
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Construct a LookupModule instance to use for testing.
    lookup_plugin = LookupModule()

    # Test with an empty file list.
    files = []
    search_path = []
    terms = [files, search_path]
    (total_search, skip) = lookup_plugin._process_terms(terms, [], {})
    assert total_search == [], \
        "Failed to create correct search list from empty file list."

    # The following tests will use the file 'sample.txt' in the files
    # subdirectory of the directory in which the unit test file
    # resides.

    # Test with one file and no search path.
    file1 = 'sample.txt'
    files = [file1]
    search_path = []
    terms = [files, search_path]
    (total_search, skip)

# Generated at 2022-06-23 11:45:53.002545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display

    # Necessary to init the config
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    def test(terms, files, paths, expected_fact, expected_file_path):
        lookup_plugin = LookupModule()
        lookup_plugin._templar = variable_manager._templar
        lookup_plugin.set_options(is_playbook=False)

        results_fact = lookup_plugin.run(terms, variable_manager._fact_cache)[0]
        assert results

# Generated at 2022-06-23 11:46:03.947503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import StringIO

    # Init lookup module
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._find_needle = None
    lookup_module._basedir = None
    lookup_module._subdir = None

    # Init fake params
    findme = StringIO(b('/etc/resolv.conf\n'))
    file_name = '/tmp/test_file'
    variables = {}

    # Init fake methods
    def templar_template(path):
        # This function returns the same that is received
        return path


# Generated at 2022-06-23 11:46:05.254197
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 11:46:14.407691
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class FakeVars:
        def __init__(self):
            self.ansible_virtualization_type='system'

    module = LookupModule()

    fake_vars = FakeVars()

    test_terms = [{'files': '{{ansible_virtualization_type}}_foo.conf', 'paths': '.'}, 'default_foo.conf']
    test_params, skip = module._process_terms(test_terms, fake_vars, None)
    assert 'system_foo.conf' in test_params
    assert 'default_foo.conf' in test_params
    assert len(test_params) == 2
    assert skip == False

# Generated at 2022-06-23 11:46:22.082911
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'test', 'unit', 'test_data')
    lookup.set_options(direct={'files': 'test.txt,test_some.txt', 'paths': 'files'})
    result = lookup.run([], dict())
    assert result[0] == os.path.join(lookup.basedir, 'files', 'test.txt')

    lookup.set_options(direct={'files': 'test.txt,test_some.txt', 'paths': 'files:'})
    result = lookup.run([], dict())
    assert result[0] == os.path.join(lookup.basedir, 'files', 'test.txt')


# Generated at 2022-06-23 11:46:24.046720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:46:25.298887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'


# Generated at 2022-06-23 11:46:27.250071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)

# Generated at 2022-06-23 11:46:28.633719
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:46:34.317357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = [
        '/path/to/foo.txt',
        '/path/to/bar.txt',
        '/path/to/biz.txt',
    ]
    paths = [
        '/path/to',
        '/path/from',
    ]
    params = {'files': files, 'paths': paths}

    lookup_module = LookupModule()
    found = lookup_module.run(terms=params, variables={}, **params)
    assert found[0] == '/path/to/foo.txt'



# Generated at 2022-06-23 11:46:44.016073
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    lu = LookupModule()
    assert lu is not None

    # test _process_terms
    with pytest.raises(AnsibleLookupError):
        total_search, skip = lu._process_terms(['..', {'files': 'foo', 'paths': 'bad'}, '../bar'], {}, {})

    # test dict term
    total_search, skip = lu._process_terms([{'files': 'foo', 'paths': 'bar'}], {}, {})

    assert type(total_search) == list
    assert len(total_search) == 1
    assert total_search[0] == 'bar/foo'

    # test one string term
    total_search, skip = lu._process_terms(['foo'], {}, {})

    assert type

# Generated at 2022-06-23 11:46:46.446111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test constructor.
    """
    lookup_module = LookupModule()
    assert lookup_module._subdir is None

# Generated at 2022-06-23 11:46:58.304372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test: method run of class AnsibleLookupModule
    #    Test: first_found lookup plugin

    from ansible.utils.unicode import to_bytes
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # mock a module and its args
    module = object()
    terms = ['foo.txt']
    variables = {
        'ansible_playbook_python' : '/usr/bin/python',
        'ansible_python_interpreter': '/usr/bin/python',
        'inventory_hostname': 'localhost',
        'group_names': [],
        'omit': '__omit_place_holder__123123',
        'playbook_dir': '/root/ansible/playbooks',
    }

    # mock a templar
    templar = object()
    tem

# Generated at 2022-06-23 11:46:58.994292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:46:59.887420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-23 11:47:00.547989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:47:07.501999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()

    term1 = '/test/fixtures/bar.txt'
    term2 = {'files': 'bar.txt', 'paths': '/test/fixtures'}
    terms = [term1, term2]

    total_search, skip = instance._process_terms(terms, variables=dict(), kwargs=dict())

    assert total_search == ['/test/fixtures/bar.txt', 'bar.txt']
    assert skip == False

    subdir = 'files'
    path = instance.find_file_in_search_path(variables=dict(), searchpath=subdir, filename=total_search[0], ignore_missing=True)

    # get dirname to file
    directory = os.path.dirname(path)

    assert directory == '/test/fixtures'

# Generated at 2022-06-23 11:47:09.019455
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 11:47:15.775871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict(skip=False))
    global_vars = {}
    magic_kwargs = {}
    terms = ["anyfile", dict(files=[], paths=[]), dict(files=[], paths=["path1", "path2"])]

    def returns_true():
        return True
    lookup_module.find_file_in_search_path = returns_true
    res = lookup_module.run(terms, global_vars, **magic_kwargs)
    assert res == ["anyfile"]

    def returns_false():
        return False
    lookup_module.find_file_in_search_path = returns_false
    lookup_module.set_options(dict(skip=True))

# Generated at 2022-06-23 11:47:16.525614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: use test framework implementation
    pass

# Generated at 2022-06-23 11:47:23.261136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # TODO: need more testing, especially for the 'global' skip
    # if user specifies a list of lists the results are not as expected
    terms = [{'files': "files=foo.txt,dog.txt"}]
    variables = {}
    kwargs = {}
    lookup.run(terms, variables, **kwargs)


# Generated at 2022-06-23 11:47:33.029247
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule.module_utils.module_runner = True
    LookupModule.module_utils.connection = "local"

    # run function
    # need to pass in a valid loader or all hell breaks loose
    lookup_module = LookupModule(loader=None)
    lookup_module._templar = lookup_module._loader.load_contrib_plugin('lookup', 'template')  # pylint: disable=protected-access
    lookup_module._loader._basedir = os.getcwd()  # pylint: disable=protected-access
    lookup_module._subdir = "files"
    lookup_module.set_options({})
    ret = lookup_module.run([
        "/path/to/foo.txt",
        "bar.txt",
        "/path/to/biz.txt"
    ], {})



# Generated at 2022-06-23 11:47:34.804735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(isinstance(lookup, LookupBase))
    assert(isinstance(lookup, LookupModule))


# Generated at 2022-06-23 11:47:38.129758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    for term in [
        '',
        {},
        ['a', 'b', 'c'],
        ['d', {'e': 'f'}, 'g'],
        {'a': ['b', 'c'], 'd': 'e'},
    ]:
        assert isinstance(l._process_terms(term, {}, {})[0], list)


# Generated at 2022-06-23 11:47:40.315785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 11:47:51.395004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    import sys
    if sys.version_info[0] == 2:
        from backports import mock
    else:
        from unittest import mock

    import os
    import tempfile
    import shutil

    fd, srcpath = tempfile.mkstemp()

    class MockTemplar(object):
        def template(self, x):
            return x

    class MockVariables(object):
        def __init__(self, tmpdir):
            self._tmpdir = tmpdir


# Generated at 2022-06-23 11:47:53.961515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.get_option('files') == []
    assert lookup_module.get_option('paths') == []
    assert lookup_module.get_option('skip') == False

# Generated at 2022-06-23 11:47:54.474489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 11:48:04.937682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set lookup module environment
    lu = LookupModule()
    lu._templar = None

    # create search structure to test
    search_structure = {'files':['foo.txt', 'bar.txt'], 'paths':['/tmp/production', '/tmp/staging']}
    # test term name in search_structure
    terms = [ search_structure ]

    # create list of files to be looked for in ansible directories
    ansible_files = ['foo.txt', 'bar.txt']

    # create list of files to be looked for in ansible directories
    ansible_paths = ['/tmp/production', '/tmp/staging']

    # create list of files to be looked for in ansible directories
    total_search = []

    # build list of files to be looked for in ansible directories
   

# Generated at 2022-06-23 11:48:17.070901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    terms = [{
        u'files': u'foo,bar.txt',
        u'paths': u'one,two\three'
    }, u'a', [u'b', u'c']]
    terms_py2 = [{
        'files': 'foo,bar.txt',
        'paths': 'one,two\three'
    }, 'a', ['b', 'c']]

# Generated at 2022-06-23 11:48:19.743532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test if the class constructor works.
    """
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 11:48:24.265907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule({
        '_templar': {
            'template': lambda x: x
        },
        'find_file_in_search_path': lambda x,y,z,**kwargs: {
            'foo': 'bar',
            'a': 'b'
        }[z]
    }).run(["{foo}", "{a}"], {}) == ['bar']


# Generated at 2022-06-23 11:48:36.665581
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.display import Display
    from ansible_collections.ansible.community.tests.unit.mock.loader import DictDataLoader

    def ansible_loader(*args, **kwargs):
        if 'path_sep' in kwargs:
            kwargs['path_sep'] = ':'
        return DictDataLoader(*args, **kwargs)

    # Mock display class
    display = Display()
    display.verbosity = 1

    # Mock templar class
    templar = MockTemplar(loader=ansible_loader())

    # Mock search path
    variables = {'playbook_dir': '/home/user/ansible_dir',
                 '_original_file': '/home/user/ansible_dir/playbook.yml'}

    # Search for existing files


# Generated at 2022-06-23 11:48:38.907700
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule
    assert lookup_class
    lookup_class = LookupModule('foo')
    assert lookup_class

# Generated at 2022-06-23 11:48:40.117538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:48:46.792067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    desired_values = {'message': 'No file was found when using first_found.',
                      'obj': None}
    try:
        lookup = LookupModule()
        lookup.run(['/tmp/filedoesnotexist.conf'], {})
        assert False
    except AnsibleLookupError as e:
        assert e.message == desired_values['message']

# tests: noinspection PyUnusedLocal

# Generated at 2022-06-23 11:48:55.085941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    # file to tempfile
    cipher_text = VaultLib.encrypt(b'testpassword', to_bytes(('plaintext')))
    plain_text = VaultLib.decrypt(b'testpassword', cipher_text)
    import tempfile
    tempdir = tempfile.mkdtemp()
    tempfile.tempdir = tempdir
    tf = tempfile.mktemp()
    f = open(tf, "w")
    f.write(plain_text)
    f.close()
    print(tf)

    # all kwargs set
    lm = LookupModule()
    terms = [{'files': "plaintext", 'paths': "."}]
    result = lm.run

# Generated at 2022-06-23 11:49:05.939511
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test that the constructor of LookupModule works
    def test_constructor():
        assert LookupModule() is not None

    def test_constructor_subdir():
        assert LookupModule(subdir='roles') is not None

    # test that the return type of run is a list
    def test_run_return_type():
        lookup_module = LookupModule()
        assert isinstance(lookup_module.run(['findme']), list)

    # test that the constructor of LookupBase works
    def test_constructor_lookupbase():
        assert LookupBase() is not None

    # test that the LookupBase constructor raises an exception when called with wrong parameters