

# Generated at 2022-06-11 15:22:33.744650
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This test is quite indicative of a 'not needed' feature in this lookup
    # the inline config is really 'unneeded' and should be removed
    class _VarsModule():
        def __init__(self, dic):
            self.vars = dic

    def _ex(terms, variables={}, **kwargs):
        return LookupModule().run(terms, variables=_VarsModule(variables), **kwargs)

    # NOTE: 'files' and 'paths' should be handled as list, not strings
    # TODO: refactor these tests
    assert _ex(['myfile'], {}, paths=['path1']) == ['path1/myfile']
    assert _ex(['myfile'], {}, paths='path1') == ['path1/myfile']

# Generated at 2022-06-11 15:22:41.511392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._loader = None

    # no file found, no template errors
    lm._templar = FakeTemplar()
    assert lm.run(['foo']) == []

    # no file found, with template errors
    lm._templar = FakeTemplar(error=AnsibleUndefinedVariable)
    assert lm.run(['foo']) == []

    # find a file
    lm._templar = FakeTemplar()
    assert lm.run(['bar']) == ['bar_file']

    # find a file with a query parameter
    lm._templar = FakeTemplar()
    assert lm.run(['bar'], extra_param=True) == ['bar_file']


# Generated at 2022-06-11 15:22:46.793494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [dict(files=['file1', 'file2'], paths=['/path1', '/path2']), 'file3', 'file4', ['file5', 'file6']]
    variables = {}
    result = module.run(terms, variables)
    assert result == ['file3']

# Generated at 2022-06-11 15:22:58.045434
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    from ansible.plugins.lookup.first_found import LookupModule

    terms = [
        'foo/bar.txt',
        {
            'files': 'foo.txt',
            'paths': 'stuff,sam,fun'
        },
        'file_b.txt',
        'file_c.txt',
        {
            'files': 'file_d.txt,file_e.txt',
            'paths': 'path1,path2,path3'
        }
    ]

    # testing where one of central parameters is missing
    with pytest.raises(AnsibleLookupError) as excinfo:
        LookupModule(terms=[], variables={}).run(terms, {})
    assert 'Invalid term supplied, can handle string, mapping or list of strings but got: ' in str

# Generated at 2022-06-11 15:23:09.020173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test 1
    terms = ['files/file1', 'files/file2', {'files': ['file3', 'file4'], 'paths': ['./files/']}]
    variables = {}
    kwargs = {}
    total_search, skip = lookup_module._process_terms(terms, variables, kwargs)
    assert total_search == ['files/file1', 'files/file2', 'file3', 'file4', './files/file3', './files/file4']

    # test 2
    terms = ['files/file1, files/file2', {'files': 'file3, file4', 'paths': './files/'}]
    variables = {}
    kwargs = {}
    total_search, skip = lookup_module._process

# Generated at 2022-06-11 15:23:22.204857
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    with pytest.raises(AnsibleLookupError) as ex:
        module.run([], [])

    assert str(ex.value) == 'No file was found when using first_found.'

    # set to 'files' because this is the default in lookups
    module._subdir = 'files'

    # test simple lookup
    with pytest.raises(AnsibleLookupError) as ex:
        module.run([''], [])

    assert str(ex.value) == 'No file was found when using first_found.'

    # test lookup in directory
    assert ['/files/somefile'] == module.run(['somefile'], [])

    # test lookup in directory with file and directory

# Generated at 2022-06-11 15:23:31.591074
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test terms as a list of strings
    def _test_strlist_terms(strlist, expected_return_result, expected_total_search, filelist=["foo", "bar"]):
        lookup = LookupModule()
        lookup._loader = FakeLoader()
        lookup.set_options(var_options=None, direct={'files': filelist})
        total_search, _skip = lookup._process_terms(strlist, None, {})
        assert total_search == expected_total_search
        assert lookup.run(strlist, None) == expected_return_result

    _test_strlist_terms(["a", "b"], ["a"], ["foo", "a", "bar", "b"])

# Generated at 2022-06-11 15:23:43.467012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar object
    templar = MockTemplar()

    # Create a fixture object first_found
    fixture_obj = LookupModule()
    fixture_obj._templar = templar 

    # Create a sequence of terms
    term1 = 'test1_file.txt'
    term2 = 'test2_file.txt'
    terms_seq = [term1, term2]

    # Create a dictionary containing result from method _process_terms
    # Mock the _split_on
    term1 = 'test1_file.txt'
    term2 = 'test2_file.txt'
    terms_seq = [term1, term2]
    files = ['test1_file.txt', 'test2_file.txt', 'not_found.txt']
    paths = ['.']
   

# Generated at 2022-06-11 15:23:50.726037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = [{
        'terms': [
            {
                'files': 'foo.conf',
                'paths': 'bar.conf'
            }
        ],
        'variables': 'foo.conf'
    }]

    obj = LookupModule()
    try:
        assert obj.run(params[0]['terms'], params[0]['variables']) is not None
    except Exception as e:
        assert False

# Generated at 2022-06-11 15:24:00.737078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: needs to be re-worked to not use the global/internal set_options
    # as that is not a public interface, nor should it ever be called by anything
    # other than the class itself.

    # NOTE: this should be removed, this was an old format that is no longer supported.
    # I am keeping it here temporarly to test the new format w/o breaking this.
    # kwargs:
    #    files: ['/path/to/foo','/path/to/bar']
    #    paths: ['/path/to/baz']
    LookupModule.set_options = LookupBase._set_options

    # valid test
    lookup = LookupModule()

# Generated at 2022-06-11 15:24:15.345263
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for parameter 'terms'
    # Test for case of an empty list
    lookup_instance = LookupModule()
    lookup_instance._subdir = 'files'
    try:
        lookup_instance.run([], {})
    except AnsibleLookupError:
        pass
    else:
        assert False, "AnsibleLookupError not raised"
    # Test for case of a list of two string elements
    try:
        lookup_instance.run(["files", "files"], {})
    except AnsibleLookupError:
        pass
    else:
        assert False, "AnsibleLookupError not raised"
    # Test for case of a list of two Mapping elements
    lookup_instance.run([{}, {}], {})
    # Test for case of a list of two Sequence elements

# Generated at 2022-06-11 15:24:23.871214
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    l._subdir = 'files'

    _terms = [
        ['/path/1', '/path/2'],
        '/path/3',
        {'files': ['path/4', 'path/5'], 'paths': ['path/6']}
    ]
    _variables = {}
    _kwargs = {}

    _files = l._process_terms(_terms, _variables, _kwargs)

    assert _files == (['/path/1', '/path/2', '/path/3', 'path/4', 'path/6/path/4', 'path/5', 'path/6/path/5'], False)

# Generated at 2022-06-11 15:24:33.760200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method _run of class LookupModule
    """
    # Setup a test env
    lookup_module = LookupModule()
    # Setup a variables dict
    variables = dict()
    # Setup a terms list
    terms = ['host_vars', 'group_vars']
    # Run the code to test
    code = lookup_module.run(terms, variables)
    # Assert the result
    assert isinstance(code, list)
    assert len(code) == 2
    assert isinstance(code[0], str)
    assert isinstance(code[1], str)
    assert code[0].endswith('host_vars')
    assert code[1].endswith('group_vars')

# Generated at 2022-06-11 15:24:44.288035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create test object
    lookup = LookupModule()
    terms = [[{'files': 'test00.txt'}],{"files":["test01.txt"]}]
    # test with none value
    res = lookup.run(terms=terms, variables={}, skip=False)
    assert res == []
    # test with string type
    res = lookup.run(terms=terms, variables={}, skip=False)
    assert res == []
    # test with valid file type
    res = lookup.run(terms=terms, variables={}, skip=False)
    assert res == []
    # test with invalid file type
    res = lookup.run(terms=terms, variables={}, skip=False)
    assert res == []

# Generated at 2022-06-11 15:24:55.503742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = 'file1,file2'
    paths = 'path1,path2'
    params = {'files': files, 'paths': paths}

    # Already a list, should be ignored
    term0 = [files]
    # A string, should be processed as list
    term1 = files
    # A wrong type, should raise an exception
    term2 = files.split(',')
    # A dict
    term3 = params

    # TODO: add more tests using templating, but the tests should not include actual files
    # TODO: add tests with actual files of different sizes
    # TODO: add tests with different file types
    # TODO: add test with recursive files/dirs
    assert(test_LookupModule_run_aux(terms=term0, params=params, expected=term0) == 0)


# Generated at 2022-06-11 15:25:03.665616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic lookup
    lookup_obj = LookupModule()
    lookup_obj._loader = DictDataLoader({
        'files/foo': 'foo',
        'files/bar': 'bar',
        'files/biz/baz': 'biz',
    })
    # Basic
    assert lookup_obj.run(['foo', 'baz'], dict(
        _host=None,
        _task=None,
        _play_context=None,
        _loader=None,
    )) == ['foo']
    # Test paths
    assert lookup_obj.run(['foo', 'biz/baz'], dict(
        _host=None,
        _task=None,
        _play_context=None,
        _loader=None,
    )) == ['foo']
    # Test paths with dict
    assert lookup_obj

# Generated at 2022-06-11 15:25:15.718889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ unit testing of LookupModule class run method """

    # Prepare mocks
    class Options(object):
        # Mock class for options
        def __init__(self, files=None, paths=None, skip=None):  # noqa
            self.files = files
            self.paths = paths
            self.skip = skip

    class LookupBase(object):
        # Mock class for LookupBase
        def __init__(self):
            self.options = Options()
            self._subdir = None

        def set_options(self, var_options=None, direct=None):
            # Mock method for set_options
            if direct:
                self.options = Options(direct.get('files', None),
                                       direct.get('paths', None),
                                       direct.get('skip', None))

# Generated at 2022-06-11 15:25:21.822658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'paths': './files'},
        {'files': 'file', 'paths': ''}
    ]

    variables = {}
    lm = LookupModule()
    lm.set_loader(None)
    #total_search, skip = lm._process_terms(terms, variables, {})
    ret = lm.run(terms, variables, {})
    assert ret == []

# Generated at 2022-06-11 15:25:28.330015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._templar = {}

    # test basic use
    test_path = '/path/to/file'
    term = ['/path/to']
    result = lookup.run(term, {}, files='file', paths=['/path'])
    assert result == [test_path]

    # test multiple files, only the first one should return the path
    term = ['/path/to']
    result = lookup.run(term, {}, files='file,file2', paths=['/path'])
    assert result == [test_path]

    # test multiple paths, only the first one should return the path
 

# Generated at 2022-06-11 15:25:32.556315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # create a dummy input to test with
    terms = ['hello.txt', 'bleh.txt']
    variables = {}
    # test the run method of lookup_module
    lookup_module.run(terms, variables)

# Generated at 2022-06-11 15:25:43.354489
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.first_found import LookupModule

    class FakeVars(object):
        def __init__(self):
            self.vars = {}
        def get(self, varname):
            return self.vars.get(varname)
        def __contains__(self, varname):
            return varname in self.vars

    # fake templar
    class FakeTemplar(object):
        def __init__(self):
            self.vars = {}
        def set_available_variables(self, variables):
            self.vars = variables
            self.vars['first_found_dir'] = './tests/unittests/support/first_found'
            self.vars['inventory_hostname'] = 'localhost'

# Generated at 2022-06-11 15:25:52.195523
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:26:04.197240
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class AnsibleVars(object):

        def __init__(self, vars):
            self.vars = vars

        def get(self, key):
            return self.vars.get(key)

    class MyTemplar(object):

        def __init__(self, vars):
            self.vars = vars

        def template(self, template):
            return template

    class Myself(LookupModule):

        def __init__(self, vars):
            self._templar = MyTemplar(vars)

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            if 'raise' in fn:
                raise AnsibleLookupError
            elif 'test' in fn:
                return fn


# Generated at 2022-06-11 15:26:17.081586
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock the templar class
    class Templar:
        def template(self, term):
            # make the templar return the same unmodified string
            return term

    # mock the find_file_in_search_path method of class LookupModule
    class LookupModuleTest:
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            # make the method return the same unmodified string
            return fn

    # create an empty object for variables
    variables = {}

    # create an empty object for class LookupModule
    lookup_plugin = LookupModule()

    # assign the mocked templar to the templar attribute of class LookupModule
    lookup_plugin._templar = Templar()

    # assign the mocked find_file_in_search_path method to

# Generated at 2022-06-11 15:26:24.911095
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock AnsibleModule
    class MockAnsibleModule():
        def __init__(self, fail_json=True, **kwargs):
            self.fail_json = fail_json
            self.params = kwargs

    name = 'mail.conf'
    paths = 'roles/ansible/defaults/'
    terms = [paths+name]
    # Mock the ansible module
    module = MockAnsibleModule(
        name=name,
        paths=paths
    )


    # Mock File module
    class MockFile():
        def __init__(self):
            self.exists = False


# Generated at 2022-06-11 15:26:31.522490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new instance of LookupModule
    lookup_module = LookupModule()
    # create a set of inputs for the function
    terms = ['/path/to/term.txt']
    variables = {'variable': 'value'}
    kwargs = {'files': 'kwargs_file', 'paths': 'kwargs_path'}

    # try to call the run() method
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-11 15:26:39.922625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    class DummyLookupModule(LookupModule):

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            assert subdir == 'files'
            assert fn == 'testFile'

            # Act
            if ignore_missing:
                return None
            else:
                raise Exception("No such file or directory")

    module = DummyLookupModule()
    terms = ["testFile"]
    variables = {}
    kwargs = {}
    expected_return = []

    # Act
    actual_return = module.run(terms, variables, **kwargs)

    # Assert
    assert actual_return == expected_return

# Generated at 2022-06-11 15:26:50.272451
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def setup_module(paths, terms, terms_check, **kwargs):
        class MockLookupModule(LookupModule):
            def __init__(self, loader, **kwargs):
                pass # do not load the plugin base class

            def find_file_in_search_path(self, variables, subdir, fn, ignore_missing, **kwargs):
                return paths.pop(0) if len(paths) > 0 else None

        self.lookup = MockLookupModule(loader)
        self.terms = terms
        self.terms_check = terms_check
        self.kwargs = kwargs

    def test_LookupModule_run_simple_string(self):
        # simple string test
        paths = ['path1', 'path2']
        terms = 'findme'

# Generated at 2022-06-11 15:26:53.917861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None, None).run([{'files': 'foo.txt', 'paths': '.'}], None, None) == ['foo.txt']

# Generated at 2022-06-11 15:27:02.827354
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameters to test method LookupModule.run
    #   args: []
    #   kwargs: {u'_raw_params': [u'ansible_foo.conf'], u'_original_file': u'/tmp/ansible_test_file.yaml', u'_task': {u'debug': {u'msg': u'bar', u'var': u'ansible_foo'}, u'private': False, u'name': u'ansible_test'}, u'_parent': {u'private': False, u'name': u'playbook'}}

    lookup = LookupModule()

    # Run method and assert result
    result = lookup.run(terms=[u'ansible_foo.conf'], variables={u'ansible_foo': u'foo'})

# Generated at 2022-06-11 15:27:15.479684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ['ANSIBLE_LOOKUP_PLUGIN_DEBUG'] = '1'
    os.environ['ANSIBLE_LOOKUP_PLUGINS'] = '..'
    class EmptyModule(object): pass
    terms = [{'files': 'in.txt',
              'paths': './files,./files/sub/subsub'},
             {'files': 'does_not_exist.txt',
              'paths': './files,./files/sub/subsub',
              'skip': False},
             {'files': 'does_not_exist.txt',
              'paths': './files,./files/sub/subsub',
              'skip': True}]
    variables = EmptyModule()
    assert len(LookupModule(terms, variables).run(terms, variables)) == 1

    terms

# Generated at 2022-06-11 15:27:18.380309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    print(m.run(terms=[{"files": ["/tmp/filepath"]}], variables={"ansible_basedir": "/potato/ansible"}))

# Generated at 2022-06-11 15:27:30.087030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Regular case
    test_object = LookupModule()
    test_object._LoaderModule__importer = None
    mock_variables = {'inventory_hostname': 'localhost',
                      'ansible_distribution': 'Debian',
                      'ansible_os_family': 'Debian'}
    test_object._templar = mock_templar('Debian_foo.conf', 'default_foo.conf')
    test_object._finder = mock_finder('/tmp/debian')
    test_object.tty = mock_tty()
    test_object.run([{'files': '{{ ansible_virtualization_type }}_foo.conf,default_foo.conf',
                      'paths': '/tmp/production,/tmp/staging'}], mock_variables)
    assert True

    # File not found case

# Generated at 2022-06-11 15:27:31.320585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 15:27:41.143160
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # We need to create a mock to return a template value
    class TestTemplar:
        def template(self, template_string, **kwargs):
            if template_string == 'bar':
                return 'bar'
            if template_string == '{{ ansible_os_family }}':
                return 'RedHat'
            if template_string == '/tmp/production':
                return '/tmp/production'
            if template_string == '{{ ansible_virtualization_type }}_foo.conf':
                return 'virtualization_type_foo.conf'
            if template_string == '{{ ansible_distribution }}.yml':
                return 'CentOS.yml'
            if template_string == '{{ ansible_os_family }}.yml':
                return 'RedHat.yml'

# Generated at 2022-06-11 15:27:50.574545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyTemplar(object):
        def __init__(self, templated_str):
            self.templated_str = templated_str

        def template(self, str, preserve_trailing_newlines=False, escape_backslashes=True, fail_on_undefined=True):
            # This method ignores its arguments and always returns templated_str
            return self.templated_str

    class DummyLookupBase(LookupBase):
        def __init__(self, search_result):
            self.search_result = search_result

        def find_file_in_search_path(self, variables, subdir, file, ignore_missing=False):
            return self.search_result

    class DummyVars(object):
        def __init__(self):
            self.host

# Generated at 2022-06-11 15:27:59.518539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar(object):
        def __init__(self, templar):
            self._templar = templar
        def template(self, fn):
            return self._templar.template(fn)

    class MockVariables(object):
        def __init__(self, variables):
            self._variables = variables
        def get(self, subdir, fn, ignore_missing=True):
            return self._variables.get(subdir, fn, ignore_missing)

    class TestLookupModule(LookupModule):
        def __init__(self, templar, variables, **kwargs):
            self._templar = MockTemplar(templar)
            self._variables = MockVariables(variables)

# Generated at 2022-06-11 15:28:00.557719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  raise AnsibleError("test not implemented")

# Generated at 2022-06-11 15:28:09.742787
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_text

    class FakeTemplar(object):
        def __init__(self):
            self.vars = dict()

        def template(self, value):
            try:
                return self.vars[value]
            except KeyError:
                raise UndefinedError("foo")

    class FakeRunner(object):
        # a fake runner module to use the lookup plugins from
        def __init__(self):
            self.plugins = dict()
            self.templar = FakeTemplar()
            self.basedir = '/'
            self.config = configparser.SafeConfigParser()

# Generated at 2022-06-11 15:28:21.210332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = {
        'params': dict(files = ['/path/to/foo.txt', '/path/to/bar.txt'],
                       paths = ['/extra/path'],
                       skip = True),
        'files': ['/path/to/foo.txt', '/path/to/bar.txt'],
        'paths': ['/extra/path'],
        'skip': True,

        # case from test
        'terms': ['/path/to/foo.txt', '/path/to/bar.txt'],
    }
    assert data['params']['files'] == data['terms']

    # case of dict term
    result = LookupModule().run(terms = [data['params']], variables = {})
    assert len(result) == 0 and result == []

    # case of string term
    result = Look

# Generated at 2022-06-11 15:28:38.064864
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # _process_terms is tested in each test, we will only test run code
    # so methods and variables are mocked, see `_process_terms`

    # Arrange
    terms = [
        'file1.txt',
        {'files': ['file2.txt'], 'paths': ['dir1', 'dir2']},
        {'files': ['file3.txt'], 'paths': ['dir3']},
    ]
    variables = {}
    kwargs = {}
    # We will not test `_process_terms`, so mock the result
    terms_processed = [
        'file1.txt',
        'dir1/file2.txt',
        'dir2/file2.txt',
        'dir3/file3.txt',
    ]
    skip = False

    # Mock `_process_terms

# Generated at 2022-06-11 15:28:49.236274
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest


# Generated at 2022-06-11 15:29:01.215364
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with no files and skip undefined
    terms = [{'files': 'foo', 'skip': True}]
    variables = {}
    kwargs = {}

    lookup = LookupModule()
    ret = lookup.run(terms, variables, **kwargs)

    assert ret == []

    # Test with one file and skip undefined
    terms = [{'files': 'foo', 'paths': '/tmp'}]
    variables = {}
    kwargs = {}

    lookup = LookupModule()
    ret = lookup.run(terms, variables, **kwargs)

    assert len(ret) == 1 and ret[0] == '/tmp/foo'

    # Test with one file and skip defined as True
    terms = [{'files': 'foo', 'paths': '/tmp', 'skip': True}]
    variables = {}


# Generated at 2022-06-11 15:29:08.534560
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class my_lookup(LookupModule):
        def __init__(self, *args, **kwargs):
            LookupModule.__init__(self)
            self.params = kwargs

        def _process_terms(self, *args, **kwargs):
            return LookupModule._process_terms(self, *args, **kwargs)

        def run(self, *args, **kwargs):
            return LookupModule.run(self, *args, **kwargs)

        def find_file_in_search_path(self, *args, **kwargs):
            return LookupModule.find_file_in_search_path(self, *args, **kwargs)

    # basic usage
    findme = ['/path/to/foo.txt', 'bar.txt']

# Generated at 2022-06-11 15:29:18.812617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar()

    f = l.find_file_in_search_path({}, "files", "bar.txt")
    t = [f, f]
    assert l.run(t, {}) == t

    f = l.find_file_in_search_path({}, "files", "baz.txt")
    t = ['foo.txt', 'bar.txt', 'baz.txt']
    assert l.run(t, {}) == [f]

    f = l.find_file_in_search_path({}, "files", "foo.txt")

# Generated at 2022-06-11 15:29:30.588441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import b, PY3
    from ansible.module_utils.six.moves import StringIO

    # test various combinations of paths and files, contained in files
    fixtures_dir = os.path.join(os.path.dirname(__file__), 'fixtures', 'first_found')
    class MockLookupModule(LookupModule):
        def __init__(self):
            self._plugin_name = 'first_found'
            self._return = {}
            self._templar = None
            super(MockLookupModule, self).__init__()

        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing=True):
            if PY3:
                return self._return

# Generated at 2022-06-11 15:29:34.277808
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with basic parameters only
    file_name = 'test_file_name.txt'
    params = {
        'files': file_name,
    }
    terms = [params]
    test_module = LookupModule()
    result = test_module.run(terms, {})
    assert(result == [file_name])



# Generated at 2022-06-11 15:29:45.266564
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: this class is not used by ansible core.
    #       But it can be used by other modules that use 'first_found'
    #       Here we test the class directly, it is not specific to lookup modules.

    # NOTE: the test covers 'both' the 'positional' and 'kwonly' modes used by 'first_found'

    # Create a new instance of class LookupModule
    lkpm = LookupModule()

    # Save the params
    params = dict(
        files=["file", "file2"],
        paths=["/a/b/c", "/d/e/f"]
    )

    # Set the options
    lkpm.set_options(var_options={}, direct=params)

    # Save the options
    files = lkpm.get_option('files')
    paths = lk

# Generated at 2022-06-11 15:29:47.065303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupBase, LookupModule)


# Generated at 2022-06-11 15:29:55.681529
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:30:15.270406
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # on success
    lookup_inst = LookupModule()
    result = lookup_inst.run(['/path/to/file1', '/path/to/file2'], variables=None, **{})
    assert result == ['/path/to/file1']

    # on failure and skip False
    lookup_inst = LookupModule()
    try:
        lookup_inst.run(['/path/to/nofile'], variables=None, **{})
        assert False
    except AnsibleLookupError as e:
        assert 'was found' in str(e)

    # on failure and skip True
    lookup_inst = LookupModule()
    result = lookup_inst.run(['/path/to/nofile'], variables=None, **{'skip': True})
    assert result == []

# Generated at 2022-06-11 15:30:26.400259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test the method run of class LookupModule.
    '''
    # Dummy class for LookupModule
    class DummyLookupModule():
        def __init__(self, variables):
            self._templar = DummyTemplar(variables)
            self._subdir = 'files'

        def _templar(self):
            return self._templar

        def _subdir(self):
            return self._subdir

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            '''
            Return the first partial file found with subdir and fn.
            '''
            fn = self._templar.template(fn)
            if fn == 'Any':
                return 'found_any'

# Generated at 2022-06-11 15:30:36.897273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test error cases
    # term is not list or string
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import PY3

    def to_text(x):
        if PY3:
            return x
        else:
            return x.decode('utf-8', 'strict')

    class MockLookupBase(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    mock_lookup = MockLookupBase()

    with pytest.raises(AnsibleLookupError):
        assert mock_lookup.run(terms=1) == 1

    # test skip is True when no file found

# Generated at 2022-06-11 15:30:46.755815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Setup for unit test
    #
    import ansible.plugins.loader as plugin_loader
    import ansible.parsing.dataloader

    fake_loader = ansible.parsing.dataloader.DataLoader()
    lookup = plugin_loader.get_lookup_plugin('first_found')

    #
    # The test cases
    #
    class test_case:
        def __init__(self, params, expected, msg):
            self.params = params
            self.expected = expected
            self.msg = msg
        def __repr__(self):
            return '%s(%s)' % (self.__class__, self.msg)

    test_cases = []
    from os import path

# Generated at 2022-06-11 15:30:47.768550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-11 15:30:49.058050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: add unit tests
    pass



# Generated at 2022-06-11 15:30:58.852051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test basic case.
    options = dict()
    options['_terms'] = ['file1', 'file2', 'file3']
    options['_subdir'] = 'test'
    options['basedir'] = '.'
    options['_lookup_name'] = 'first_found'

    assert LookupModule(**options).run(options['_terms'], options) == ['test/file1']

    # Test case with path.
    options['paths'] = 'test2'
    assert LookupModule(**options).run(options['_terms'], options) == ['test2/file1']
    options['files'] = 'file4'
    assert LookupModule(**options).run(options['_terms'], options) == ['test2/file4']

    # Test case with list for path, files

# Generated at 2022-06-11 15:31:01.146474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["myfile"]
    variables = {}
    kwargs = {}
    lookup = LookupModule()
    return lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-11 15:31:11.338158
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Master lookup test.

    # TODO: test everything, how to do it?
    # this is the main method, how to test?
    # should be more lookup_plugin unit tests

    # TODO: add 'skip' test
    search_list = []
    # test, first use
    search_list.append(([], {}, {}, []))

    # test, skip option
    search_list.append((['foo'], {}, {'skip': True}, []))

    # test, alternate path option
    search_list.append((['foo.yml', 'bar.yml'], {}, {'paths': '/path'}, []))

    # test, alternate path option, with list

# Generated at 2022-06-11 15:31:22.789354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.encrypt as encrypt
    # Imports
    import ansible.utils as utils
    import ansible.constants as C
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')
    # Function name used by import
    plugin_name = "first_found"
    lookup = utils.plugins.lookup_loader.get(plugin_name, basedir=C.DEFAULT_LOOKUP_PLUGIN_PATH)
    # Create a lookup object
    lookup_object = lookup()
    # Generate valid terms for the test
    # Build terms for the test
    terms = {}
    terms[0] = ['network_debian.conf', 'default_debian.conf']
    terms[1] = {}
    terms[1]['paths'] = []

# Generated at 2022-06-11 15:31:52.719484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    result = l.run([{"files": "foo",
                     "paths": ['.', './bar']},
                    'foo',
                    ['foo1', 'foo2', 'foo3'],
                    {'files': ['foo4', 'foo5', 'foo6'],
                     'paths': ['.', './bar', './baz']}],
                   variables=dict())
    assert result == ['foo'], result



# Generated at 2022-06-11 15:32:00.142767
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: mock up setup with tested methods.
    # TODO: test for return values (path)
    # TODO: add test for testing exception
    # TODO: test for skip file not found
    # TODO: test for skip from command line
    # TODO: test for skip from option
    # TODO: test for files not found
    # TODO: test for files not found with skip commandline
    # TODO: test for files not found with skip option
    # TODO: test for files not found with errors='ignore'
    # TODO: test for files not found with skip=true and errors='ignore'
    return True

# Generated at 2022-06-11 15:32:01.492211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement
    assert False, "No test implemented"

# Generated at 2022-06-11 15:32:11.677909
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes, to_text

    # Prepare instance of LookupModule
    lookup_plugin = LookupModule()

    if PY3:
        unicode = str

    # --------------------------------------------------
    # Test 1: terms is:
    #    - 'myfile_in_files_dir.txt'
    # path of current file is:
    #    - /test_Ansible/test_plugins/test_lookup/test_lookup_plugins/test_first_found.py
    # path of role directory is:
    #    - /test_Ansible/test_plugins/test_lookup/
    # Execute method run
    # --------------------------------------------------

# Generated at 2022-06-11 15:32:18.351114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Library import
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    input_data = dict(
        _hosts=['server1'],  # normally set by inventory plugin
        ansible_facts=dict(system=dict(distribution='Fedora'),
                           system_vendor=dict(manufacturer='FedoraProject')),
        vars=dict(var1='value1'),
    )
    current_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_dir = 'inventory/dir'