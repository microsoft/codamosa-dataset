

# Generated at 2022-06-11 15:22:33.364919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    lookup_module = LookupModule()

    # Test that result is a list
    assert type(lookup_module.run([])) is list
    # Test that result is a list of strings
    for result_element in lookup_module.run([]):
        assert type(result_element) is str

    # Test that result is a list
    assert type(lookup_module.run([], skip=True)) is list
    # Test that result is a list of strings
    for result_element in lookup_module.run([], skip=True):
        assert type(result_element) is str

    # Test that result is a list
    assert type(lookup_module.run([], skip=False)) is list
    # Test that result is a list of strings

# Generated at 2022-06-11 15:22:38.620505
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-11 15:22:46.504757
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # All tests should return an empty list or a single full path
    # Otherwise an exception should be raised

    # create a pseudo class to see if the plugin works correctly
    class MockTemplar:
        def template(self, template):
            return template

    class MockVarManager:
        def get_vars(self):
            return {}
        def extra_vars(self):
            return {}

    class MockLoader:
        def path_dwim(self, filepath):
            if filepath == 'foo':
                return 'foo-file'
            # relative '/foo' file not found
            return None

    class MockTask:
        def __init__(self):
            self._parent = self
            self._play = self
            self._play_context = self


# Generated at 2022-06-11 15:22:47.154375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:22:58.044010
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3

    if PY3:
        import unittest.mock as mock
    else:
        import mock

    with mock.patch('os.path.exists') as e:
        e.return_value = True

        class FakeLookupModule(LookupModule):
            def __init__(self, *args):
                self._subdir = 'fake_subdir'
                self.find_file_in_search_path = mock.Mock()

        lu = FakeLookupModule('')
        lu.find_file_in_search_path.return_value = 'foo'

        res = lu.run(['foo', 'bar'], dict(), {})

        assert res == ['foo']

# Generated at 2022-06-11 15:23:00.958121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test._templar = False
    test._loader = False
    test._find_file_in_search_path = lambda x,y,z,**a: z
    test.run([], dict())


# Generated at 2022-06-11 15:23:11.473502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    import os
    import pytest
    from ansible.module_utils.six import string_types


    # test missing arguments
    with pytest.raises(AnsibleLookupError):
        LookupModule._process_terms([], {})

    # test invalid argument
    with pytest.raises(AnsibleLookupError):
        LookupModule._process_terms([{'a': 1}], {})

    # test searching terms
    assert ([], False) == LookupModule._process_terms(
        ["/path/to/file1", "/path/to/file2"],
        {})

# Generated at 2022-06-11 15:23:13.151519
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True == False
    return True

# Generated at 2022-06-11 15:23:20.019770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["a.txt"], {}) == []
    assert lookup_module.run([{"files": ["a.txt"], "paths": ["/etc/ansible"]}], {}) == []
    assert lookup_module.run([{"files": ["a.txt"], "paths": ["/etc/ansible"], "skip": True}], {}) == []

# Generated at 2022-06-11 15:23:30.067493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/passwd', '/etc/passwd2']
    variables = {}
    skip = False
    value = LookupModule()._process_terms(terms, variables, {'skip': skip})
    assert value[0] == ['/etc/passwd', '/etc/passwd2']
    assert value[1] == skip

    terms = ['/etc/passwd', '/etc/passwd2', {'skip': True}]
    variables = {}
    skip = True
    value = LookupModule()._process_terms(terms, variables, {'skip': skip})
    assert value[0] == ['/etc/passwd', '/etc/passwd2', '/etc/passwd', '/etc/passwd2']
    assert value[1] == skip


# Generated at 2022-06-11 15:23:44.189995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_module = LookupModule()
    assert my_module.run(['roles/role1/vars/main.yaml', 'roles/role1/vars/main.yml'], dict()) == ['roles/role1/vars/main.yaml']
    assert my_module.run(['roles/role1/vars/main.yml', 'roles/role1/vars/main.yaml'], dict()) == ['roles/role1/vars/main.yml']
    assert my_module.run(['roles/role1/vars/main.yaml', 'roles/role1/vars/main.yml'], dict()) == ['roles/role1/vars/main.yaml']

# Generated at 2022-06-11 15:23:56.931995
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_self = type('', (object,), {
        '_subdir': 'files',
        'find_file_in_search_path': lambda *args, **kwargs: None,
        'set_options': lambda *args, **kwargs: None,
        'get_option': lambda *args, **kwargs: None,
        '_templar': type('', (object,), {'template': lambda *args, **kwargs: None}),
    })

    # Test with invalid type for terms
    mock_terms = [42]
    mock_variables = {}
    mock_kwargs = {}
    lookup_obj = LookupModule()

# Generated at 2022-06-11 15:24:03.838527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: this is not a proper unit test as it is coupled with the filesystem
    import tempfile

    tempdir = tempfile.mkdtemp()
    x = LookupModule().run(['nope.txt', 'first_found_test.txt'], {}, paths=tempdir)
    assert len(x) == 1
    assert x[0] == os.path.join(tempdir, 'first_found_test.txt')

# Generated at 2022-06-11 15:24:15.441549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar = None
    lm._find_file_in_search_path = None
    params = {
        'files': ['a/b/foo.conf', 'a/b/bar.conf'],
        'paths': ['c/d/e/f', 'g/h/i/j']
    }
    total_search = ['c/d/e/f/a/b/foo.conf',
                    'g/h/i/j/a/b/foo.conf',
                    'c/d/e/f/a/b/bar.conf',
                    'g/h/i/j/a/b/bar.conf']
    assert lm._process_terms([params], None, None)[0] == total_search

# Generated at 2022-06-11 15:24:25.481686
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:24:35.461653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.vault import VaultLib
    import yaml


    # NOTE: this is not a complete test as os.path.exists
    # will return False due to lack of a path in the file system

    # NOTE: this is not a complete test as os.path.exists
    # will return False due to lack of a path in the file system

    # NOTE: this is not a complete test as os.path.exists
    # will return False due to lack of a path in the file system

    # NOTE: this is not a complete test as os.path.exists
    # will return False due to lack

# Generated at 2022-06-11 15:24:46.431837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from .unit_test import TestCase

    # needed to make the templar call, since it's really a jinja2 call
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeVars:
        ansible_virtualization_type = 'kvm'
        ansible_os_family = 'Debian'
        ansible_distribution = 'Debian'

    class DummyTemplar:
        def __init__(self):
            self.calls = []

        def template(self, txt):
            self.calls.append(txt)
            if txt == 'kvm_foo.conf':
                return txt
            elif txt == 'Debian_foo.conf':
                return txt
            el

# Generated at 2022-06-11 15:24:57.694186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_paths = ['/tmp', '/tmp2']

    # test known good and not found cases
    for name in ['/tmp/f1.txt', '/tmp/f2.txt', '/tmp/f3.txt']:
        with open(name, 'w') as f:
            f.write('hi\n')

    # test calling with a string
    lu = LookupModule()
    assert ('/tmp/f1.txt', True) == lu._process_terms(['f1.txt'], {}, {'paths': test_paths})
    assert ('/tmp/f2.txt', True) == lu._process_terms(['f2.txt'], {}, {'paths': test_paths})

# Generated at 2022-06-11 15:25:02.045793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._load_name = "first_found"
    lookup._templar = Template()
    lookup._loader = DataLoader()
    assert lookup.run(['foo'], dict(
        ansible_env=dict(
            PATH='/usr/local/bin:/usr/bin:/bin',
        ),
    )) == ['/usr/local/bin/foo']


# Generated at 2022-06-11 15:25:05.250665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = []
    test1_terms = ['hello', 'world']

    lookup = LookupModule()
    results = lookup.run(test1_terms, {}, {})
    print(results)



# Generated at 2022-06-11 15:25:23.222049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleUndefinedVariable, AnsibleError

    class LoaderModule(object):

        def __init__(self, *args, **kwargs):
            pass

        def get_basedir(self, *args, **kwargs):
            return os.getcwd()

    class RunnerModule(object):

        def __init__(self, *args, **kwargs):
            pass

    # class under test
    lookup = LookupModule()

    # test subject
    lookup._loader = LoaderModule()
    lookup._templar = RunnerModule()

    def _file_exists(file_name, *args, **kwargs):
        return os.path.isfile(file_name)

    lookup._loader.path_exists = _file_exists

    # test data

# Generated at 2022-06-11 15:25:34.201375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  src = "/path/to/foo.txt"
  dest = "/etc/foo.conf"
  vars = {'ansible_virtualization_type': "kvm", 'ansible_os_family': "rhel"}
  terms = [src, "{{ ansible_virtualization_type }}_foo.conf", "default_foo.conf"]
  lookup.set_options({'var_options': vars, 'direct': terms})
  assert lookup.run(terms, vars, skip=False) == [src]
  terms = ["{{ ansible_virtualization_type }}_foo.conf", "default_foo.conf", src]
  lookup.set_options({'var_options': vars, 'direct': terms})

# Generated at 2022-06-11 15:25:42.806839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar()
    l._loader = DummyLoader()
    l._loader._basedir = '/a'
    l._basedir = '/a'
    l.run([{'files': 'b,c=;d,e', 'paths': '/f:/g;/h,/i'}], {'a': 'b'})
    l.run([{'files': 'b,c=;d,e'}], {'a': 'b'})
    l.run([{'paths': '/f:/g;/h,/i'}], {'a': 'b'})
    l.run([{'files': 'b,c', 'paths': '/f:/g'}], {'a': 'b'})



# Generated at 2022-06-11 15:25:50.549564
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    kwargs = None

    def _get_variables_mock(self):
        return {'lookup_file_paths': {'files': './files'}}

    LookupModule.get_vars = _get_variables_mock
    LookupModule._subdir = 'files'

    expected = './files/test_lookup_module_run.txt'
    # Method run of class LookupModule needs to return: './files/test_lookup_module_run.txt'
    assert LookupModule.run(None, None, terms=['test_lookup_module_run.txt'], **kwargs) == [expected]

# Generated at 2022-06-11 15:26:02.715528
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import pytest
    import tempfile

    # Create some temporary files to use.
    TEST_FILE1 = tempfile.NamedTemporaryFile(prefix='ansible_first_found_lookup_test1_', delete=False)
    TEST_FILE2 = tempfile.NamedTemporaryFile(prefix='ansible_first_found_lookup_test2_', delete=False)
    TEST_FILE3 = tempfile.NamedTemporaryFile(prefix='ansible_first_found_lookup_test3_', delete=False)
    TEST_FILE4 = tempfile.NamedTemporaryFile(prefix='ansible_first_found_lookup_test4_', delete=False)

# Generated at 2022-06-11 15:26:14.889825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.ec2 import HAS_BOTO3
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    if not HAS_BOTO3:
        raise ImportError("the ec2_region lookup cannot be tested without boto installed")

    lookup = lookup_loader.get('first_found')

    terms = ['/path/to/foo.txt', '/path/to/bar.txt', 'hello']
    result = lookup.run(terms, VariableManager())
    assert result == ['/path/to/bar.txt']

    lookup = lookup_loader.get('first_found')

# Generated at 2022-06-11 15:26:23.978214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Check that if no files/paths are supplied, term is taken
    term = '/my/cool/file.yml'
    total_search, skip = lm._process_terms([term], {}, {})
    assert(total_search == [term])
    assert(skip is False)

    # Check that if only path is supplied, base file name is taken
    term = {'paths': '/my/cool/'}
    total_search, skip = lm._process_terms([term], {}, {})
    assert(total_search == ['/my/cool/'])
    assert(skip is False)

    # Check that if only file is supplied, it is taken
    term = {'files': '/my/cool/file.yml'}
    total_search, skip = lm

# Generated at 2022-06-11 15:26:35.549568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._loader = object()
    lookup._templar = object()
    lookup._templar._available_variables = {'ansible_distribution': 'debian'}

    assert lookup.run(terms=['wrong.yml', 'other_wrong.yml'], variables={}, paths='files/') == []

    assert lookup.run(terms=[{'files': ['debian.yml', 'default.yml'], 'paths': ['files/']}], variables={},
                      paths='files/') == ['/tmp/ansible/files/debian.yml']


# Generated at 2022-06-11 15:26:43.175625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testFn = "fakefile.txt"
    testSubDir = "fakeSubDir"
    testFn = "fakefile.txt"
    testPath = "fakePath"
    testOptions = {'files':[testFn], 'paths':[testPath]}

    # When supplied paths contain directory and file, return path to file
    obj = LookupModule()
    obj._subdir = testSubDir
    obj._templar = "templar"
    obj.find_file_in_search_path = lambda x, y, z, ignore_missing=False: testPath
    result = obj.run([testOptions], {})
    assert result == [testPath]

    # When supplied paths do not contain directory and file, raise AnsibleLookupError
    obj = LookupModule()
    obj._subdir = testSubDir

# Generated at 2022-06-11 15:26:51.307845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.vars.reserved import Reserved
    from ansible.utils.display import Display
    display = Display()
    context.CLIARGS = None
    reserved_vars = Reserved()
    reserved_vars.update(dict(inventory_dir="/test/dir", playbook_dir='/test/dir/playbooks'))

    lookup_plugin = LookupModule()

    search_paths = lookup_plugin.get_search_paths(variables=reserved_vars, templar=None)

    # search_paths = ['/test/dir', '/test/dir/playbooks/files']

    assert search_paths == ['/test/dir', '/test/dir/playbooks/files'], search_paths


# Generated at 2022-06-11 15:27:06.937937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example lr = LookupModule()
    # msg = lr.run(terms, variables, **kwargs)
    pass

# Generated at 2022-06-11 15:27:15.986521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.mock import mock_open, patch
    from ansible.module_utils.six.moves import reduce

    listType = type([])
    strType = type('')
    dictType = type({})
    unicodeType = type(u'')
    # setup mocks
    m_open = mock_open()

    # mocks
    mock_path = patch('ansible.plugins.lookup.first_found.os.path')
    mock_isfile = mock_path.isfile
    mock_isfile.return_value = True
    mock_isdir = mock_path.isdir
    mock_isd

# Generated at 2022-06-11 15:27:28.110700
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.basedir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

    # basic test, no paths
    terms = 'yaddayadda'
    result = lookup_module.run(terms, mock_variables, **mock_kwargs)
    assert result == ['yaddayadda']

    # test paths with a path that doesn't exist
    terms = 'yaddayadda'
    mock_kwargs = {
        'files': 'test_files.yml',
        'paths': 'test/non/existing/path/',
    }
    result = lookup_module.run(terms, mock_variables, **mock_kwargs)

# Generated at 2022-06-11 15:27:36.112033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test case 1
    assert lookup.run(params = {'files' : ['foo.conf'], 'paths' : ['/tmp/production','/tmp/staging']}, variables = {}, config = {}) == []
    # test case 2
    assert lookup.run(params = {'files' : [], 'paths' : []}, variables = {}, config = {}) == []
    # test case 3
    assert lookup.run(params = {'files' : ['foo.conf'], 'paths' : ['/tmp/production','/tmp/staging']}, variables = {}, config = {'files' : ['foo.conf'], 'paths' : ['/tmp/production','/tmp/staging']}) == []
    # test case 4

# Generated at 2022-06-11 15:27:47.072038
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test 'no paths'
    result = LookupModule().run([{'files': "etc/fstab, var/lib/volume.cfg", 'paths': ""}], {}, skip=False)
    assert result == [u'etc/fstab', u'var/lib/volume.cfg']

    # test 'paths'
    result = LookupModule().run([{'files': "etc/fstab, var/lib/volume.cfg", 'paths': "/tmp/foo, bar"}], {}, skip=False)
    assert result == [u'/tmp/foo/etc/fstab', u'/tmp/foo/var/lib/volume.cfg', u'bar/etc/fstab', u'bar/var/lib/volume.cfg']

    # test error when no file is found

# Generated at 2022-06-11 15:27:49.111685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['test'], {}) == ['/test']


test_LookupModule_run()

# Generated at 2022-06-11 15:27:58.461270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests for method first_found
    # args: terms, variables, **kwargs
    import os
    from unittest.mock import patch

    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    from ansible.errors import AnsibleUndefinedVariable, AnsibleLookupError

    from ansible.plugins.lookup import LookupBase

    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib

    from ansible.utils.boolean import boolean

    lookup = LookupModule()

    def test_condition(terms, expected, files='', paths='', skip=False, expmsg=None):
        # set up all the junk
        variables = dict(foo='bar')


        # set up all the junk
        variables = dict(foo='bar')

       

# Generated at 2022-06-11 15:28:08.599667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(terms=['file1', 'file2'], variables={},
                             paths=["/path/to/first/file", "/path/to/second/file"])
    assert ret == ['/path/to/first/file/file1']

    ret = LookupModule().run(terms=['file3', 'file4'], variables={},
                             paths=["/path/to/first/file", "/path/to/second/file"])
    assert ret == ['/path/to/second/file/file3']

    ret = LookupModule().run(terms=['file5', 'file6'], variables={},
                             paths=["/path/to/first/file", "/path/to/second/file"])
    assert ret == []


# Generated at 2022-06-11 15:28:20.166324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Single file, existing
    assert lookup.run(['lookup_gather_timeout']) == ['/etc/ansible/ansible.cfg']

    # Single file, existing, with ignore_missing=True
    assert lookup.run([{'files': 'lookup_gather_timeout', 'ignore_missing': True}]) == ['/etc/ansible/ansible.cfg']

    # Single file, without ignore_missing
    try:
        lookup.run([{'files': 'non_existing_file', 'ignore_missing': False}])
        assert False
    except AnsibleLookupError:
        assert True

    # Single file, with ignore_missing=True
    assert lookup.run([{'files': 'non_existing_file', 'ignore_missing': True}]) == []

    # Multiple

# Generated at 2022-06-11 15:28:27.355883
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import unittest2

    # Creating mock class to replace AnsibleModule class
    class AnsibleModuleMock():
        def __init__(self, params={}):
            self.params = params

    # Creating mock class to replace LookupBase class
    class LookupBaseMock():
        def __init__(self, basedir=None, runner=None, variables=None, loader=None, templar=None):
            self._basedir = basedir
            self._runner = runner
            self._loader = loader
            self._templar = templar
            self._lookup_plugin = None
            self._options = {}
            self._all_vars = []

        def set_loader(self, loader):
            self._loader = loader

        def add_variable(self, varname):
            self._all_vars

# Generated at 2022-06-11 15:29:03.090358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_plugin = lookup_loader.get('first_found')
    options = {'paths': ['/tmp/c', '/tmp/d']}
    files = ['/tmp/a', '/tmp/b']
    assert lookup_plugin._process_terms([{'paths': '/tmp/c:/tmp/d'}], {}, options)[0] == ['/tmp/c/a', '/tmp/c/b', '/tmp/d/a', '/tmp/d/b']
    assert lookup_plugin._process_terms([['/tmp/a', '/tmp/b']], {}, options)[0] == ['/tmp/c/a', '/tmp/c/b', '/tmp/d/a', '/tmp/d/b']

# Generated at 2022-06-11 15:29:13.870502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #mock variables parameter
    mock_variable_manager = Mapping()
    mock_variable_manager.variable_manager = MagicMock()

    mock_variable_manager.variable_manager.get_vars = MagicMock(return_value={"foo": "bar"})
    mock_variable_manager.variable_manager.extra_vars = MagicMock(return_value={"foo": "bar"})

    mock_variable_manager.get_vars = MagicMock(return_value={"foo": "bar"})
    mock_variable_manager.get_fact_vars = MagicMock(return_value={"foo": "bar"})
    mock_variable_manager.extra_vars = MagicMock(return_value={"foo": "bar"})
    
    #mock context parameter
    mock_context = M

# Generated at 2022-06-11 15:29:21.481841
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    # test with skip, no file found
    assert lm.run(terms=[{'files': ['abc'], 'paths': ['/tmp'], 'skip': True}], variables={}) == []

    # test with skip, one file found
    assert lm.run(terms=[{'files': ['abc'], 'paths': ['/tmp']}], variables={}) == []

    # TODO: test for file found, loop in dict, dict not used by just 'listify'

# Generated at 2022-06-11 15:29:22.142213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:29:27.742412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/test/test1.yml', '/test/test2.yml']
    params = {'files': terms, 'paths': ['/none/existing/path']}

    lm = LookupModule()
    lm.set_options(var_options=None, direct=params)

    assert lm.run(terms, None) == []



# Generated at 2022-06-11 15:29:30.371617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import pytest
    # import itertools
    #
    # from ansible.plugins.lookup import LookupModule
    #
    #
    assert False


# Generated at 2022-06-11 15:29:37.488307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test basic search
    terms = ["hello", "world"]
    files = lookup.run(terms, variables={}, errors='ignore')
    assert isinstance(files, list)
    assert len(files) == 0

    # test dict search
    terms = [
        {
            'files': ['hello', 'world'],
            'skip': True,
        }
    ]
    files = lookup.run(terms, variables={}, errors='ignore')
    assert isinstance(files, list)
    assert len(files) == 0

    # test list of dicts search should raise Error

# Generated at 2022-06-11 15:29:45.430525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    first_found_lookup = LookupModule()
    terms = ['first_file.txt', 'second_file.txt', 'third_file.txt']
    files={'first_file.txt':'File1', 'second_file.txt':'File2', 'third_file.txt':'File3', 'fourth_file.txt':'File4'}
    subdir=None
    variables=None
    vars_str='NA'
    assert first_found_lookup.run(terms, variables, **vars_str) == ['File1']

# Generated at 2022-06-11 15:29:55.027797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LocalLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            super(LocalLookupModule, self).__init__(loader=loader, templar=templar, **kwargs)
            self.results = list()

        def _find_file_in_search_path(self, name):
            self.results.append(name)
            return 0 if name == 'bar.txt' else -1

    lookup = LocalLookupModule()
    result = lookup.run(['foo.txt', 'bar.txt', 'baz.txt'])
    assert result == ['bar.txt']
    assert lookup.results == ['foo.txt', 'bar.txt', 'baz.txt']

    lookup = LocalLookupModule()
    result = lookup.run

# Generated at 2022-06-11 15:30:06.206277
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:31:01.659940
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule_obj = LookupModule()

    # on a dict term, skip option at dict level will not work, only last
    assert LookupModule_obj.run(terms=[{'skip': True, 'files': ['a']}, {'skip': False, 'files': ['b']}], variables={}) == []

    # on a list of dict, skip option at dict level will not work, only last
    assert LookupModule_obj.run(terms=[[{'skip': True, 'files': ['a']}, {'skip': False, 'files': ['b']}]], variables={}) == []

    # on a string term, skip option will work
    assert LookupModule_obj.run(terms=['a'], variables={}, skip=True) == []

    # on a list of string, skip option will work
    assert LookupModule

# Generated at 2022-06-11 15:31:12.079529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    lu = lookup_loader.get("first_found")

    var_manager = VariableManager()

# Generated at 2022-06-11 15:31:17.725651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms = {'file1','file2','file2'}
    variables = {}
    expected_result = ['file1','file2',]
    result = m.run(terms, variables)
    # the order of the elements in the result is not deterministic, so we have to do a sorted check
    assert sorted(result) == sorted(expected_result)

# Generated at 2022-06-11 15:31:21.190932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo']
    test = LookupModule()
    total_search, skip = test._process_terms(terms, None, None)


# Generated at 2022-06-11 15:31:28.196849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setting up
    mock_templar = [
        {"value":"{{ ansible_virtualization_type }}_foo.conf",
         "result": {'failed': False,
                    'msg': 'All items completed',
                    'results': ['foo_foo.conf']}},
        {"value":"default_foo.conf",
         "result": {'failed': False,
                    'msg': 'All items completed',
                    'results': ['default_foo.conf']}}
    ]
    mock_templar_index = 0


# Generated at 2022-06-11 15:31:30.813377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.
    """
    assert LookupModule.run == LookupModule._process_terms



# Generated at 2022-06-11 15:31:40.233411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    play_context._roles_paths = []
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    terms = [{'files': 'foo', 'paths': 'file1,file2'}, ['bar', 'baz']]
    test_lookup_plugin = LookupModule()

# Generated at 2022-06-11 15:31:50.133029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy
    import os
    input_data={
        'terms':[
            # one term is a list
            ['foo.txt', 'bar.txt'],
            # one term is a file path
            '/tmp/biz.txt',
            # one term is a mapping
            {'files': 'biz.txt', 'paths': ['/tmp']}
        ],
        'variables':{
            # global scope
            'ansible_tmpdir': '/tmp',
            # task scope
            'ansible_local': {'ansible_tmpdir': '/tmp'},
            'ansible_self': {'ansible_tmpdir': '/tmp'}
        }
    }

# Generated at 2022-06-11 15:31:59.460220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader

    def _get_loader(data):
        my_lookup = lookup_loader.get('first_found', class_only=True)
        # Fake the templar
        my_lookup._templar = Dictable(data)
        return my_lookup

    class Dictable:

        def __init__(self, data):
            self.data = data
            self.variables = {}


# Generated at 2022-06-11 15:32:05.696309
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    from ansible.plugins.lookup import LookupModule
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    lookup_module = LookupModule()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.set_inventory(InventoryManager(loader=DataLoader(), sources=['localhost']))

    terms = ["/path/to/foo.txt", "/path/to/bar.txt"]
    variables = variable_manager._available_vari