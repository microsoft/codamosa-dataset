

# Generated at 2022-06-11 15:22:30.169891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['file.txt', {'files': '*', 'paths': ['tests/lookup_plugins/data/first_found', 'tests/lookup_plugins/data/ignore_missing']}]
    variables = {'Foo': {}}
    subdir = 'files'
    lookup = LookupModule()
    return lookup.run(terms, variables, subdir=subdir)

# Generated at 2022-06-11 15:22:31.000348
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: write unit tests for lookup methods
    pass

# Generated at 2022-06-11 15:22:40.315440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock up an ansible variable context
    variables = {}

    # Create a dummy ansible variable context, for use later
    setattr(variables, '_ansible_no_log', False)
    setattr(variables, '_ansible_debug', False)
    setattr(variables, '_ansible_verbosity', 1)
    setattr(variables, 'ansible_version', '2.0.0')

    # Create a LookupModule, which we will use to test the run method of the same class
    lookup_module = LookupModule()

    # create a dummy loader, which will be used by LookupModule to load the template
    loader_mock = AnsibleLoaderMock()

# Generated at 2022-06-11 15:22:52.612381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=[{'files': ['foo'], 'paths': ['..']}]) == ['../foo']
    assert LookupModule().run(terms=[{'files': ['foo'], 'paths': ['..'], 'skip': True}]) == []
    assert LookupModule().run(terms=['foo']) == ['foo']
    assert LookupModule().run(terms=[{'files': ['foo']}]) == ['foo']
    assert LookupModule().run(terms=[{'files': ['foo'], 'paths': ['..']}]) == ['../foo']
    assert LookupModule().run(terms=[{'files': ['foo'], 'paths': ['..'], 'skip': True}]) == []

# Generated at 2022-06-11 15:23:02.499756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([], dict()) == []

    assert LookupModule().run(['first_found.py'], dict()) == []

    assert LookupModule().run(['first_found.py'], dict(), files=['first_found.py'], paths=['test/test_first_found'], skip=True) == []

    assert LookupModule().run(['first_found.py'], dict(), files=['first_found.py'], paths=['test/test_first_found'], skip=False) == 'test/test_first_found/first_found.py'

    assert LookupModule().run(['first_found.py'], dict(), files=['first_found.py'], skip=True) == []


# Generated at 2022-06-11 15:23:12.212069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import os.path
    import pytest

    # Build test fixtures
    fixtures = {
        "expected_found": [os.path.join('expected_path', 'sub_dir', 'file_name')],
        "expected_not_found": [],
        "expected_error": [os.path.join('expected_path', 'sub_dir', 'file_name')],

        "lookup_module": LookupModule(),
        "templar": LookupModule._templar,
        "root_dir": "some_dir_some_where",
        "subdir": "sub_dir",
        "expected_path": "expected_path",
        "files": "file_name",
    }
    fixtures["templar"].available_variables = {"root": fixtures["root_dir"]}

   

# Generated at 2022-06-11 15:23:13.903175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass
# TODO: write test

# Generated at 2022-06-11 15:23:25.972448
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class VarsModule(object):
        def __init__(self):
            self.ansible_env = dict(HOME='/home/user', ANSIBLE_CONFIG='/etc/ansible/ansible.cfg')

# Generated at 2022-06-11 15:23:35.794632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    lookup = lookup_loader.get('first_found', loader=DataLoader(), templar=None, shared_loader_obj=None)
    assert lookup is not None
    assert hasattr(lookup, 'run')

    # test using a list of filenames
    filenames = ('hostname_file1.txt', 'hostname_file2.txt', 'hostname_file3.txt')
    expected = {'path': ['files/hostname_file1.txt'], 'skip': False}
    actual = lookup.run(filenames, VariableManager(loader=DataLoader()).get_vars())

# Generated at 2022-06-11 15:23:46.575306
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule class
    lookup = LookupModule()

    # set a var (used by methods)
    lookup._templar._available_variables = dict(
        ansible_virtualization_type='kvm'
    )

    # Run the lookup

# Generated at 2022-06-11 15:23:59.943476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader

    # prepare for testing
    class FakeInventory():
        def __init__(self):
            self.hosts = {
                'host1': 'host1',
                'host2': 'host2',
                'host3': 'host3',
                'host4': 'host4',
                'host5': 'host5',
            }

# Generated at 2022-06-11 15:24:11.119703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyClass(object):
        def __init__(self, name, path=None):
            if path is not None:
                self.name, self.path = name, path
            else:
                self.name = name

    # Create a fake self
    class DummyObject(object):
        def __init__(self, lookup_loader_mock, finder_mock, templar_mock, use_cache=False):
            self._templar = templar_mock
            self._loader = lookup_loader_mock
            self._finder = finder_mock

# Generated at 2022-06-11 15:24:17.497966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes

    ds = dict(
        lookup_plugin='first_found',
        lookup_terms=dict(
            files=['/unix_config/main.cfg', '/win_config/main.cfg'],
            paths=['/etc', '/c/etc'],
        ),
        skipped=False,
        playbook_path='/playbooks/main.yml',
    )
    # ds = {
    #         'lookup_plugin': 'first_found',
    #         'lookup_terms': [
    #            

# Generated at 2022-06-11 15:24:18.851485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(terms=['var/lib/foo'], variables=None)

# Generated at 2022-06-11 15:24:25.692764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.lookup import LookupBase
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    mock_module = AnsibleModule(argument_spec={
        'arg1': dict(type='str')
    })
    mock_module.params = dict(
        arg1='contents'
    )
    lookup_base = LookupBase()
    lookup_base._templar = Templar(extra_vars=mock_module.params)
    lookup_base._loader = mock_module._loader

    files_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'lookup_plugins', 'files')

# Generated at 2022-06-11 15:24:26.710539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False), "No tests written"

# Generated at 2022-06-11 15:24:33.597315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    assert t.run([None], {'foo': 'bar'}) == [], "Expected empty list back"
    assert t.run([], {'foo': 'bar'}) == [], "Expected empty list back"
    assert t.run(['/tmp/foo'], {'foo': 'bar'}) == [], "Expected empty list back"
    assert t.run([{}], {'foo': 'bar'}) == [], "Expected empty list back"


# Generated at 2022-06-11 15:24:45.260931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # checks that a list of files are looked up and the first one that exists is returned
    # also checks that the search will stop when encountering a file that exists
    lookup_module = LookupModule()
    search_paths = ["/tmp/unknown/path/file1.txt", "file2.txt", "file3.txt", "file4.txt"]
    lookup_module.set_options(direct={'files': search_paths})
    found_files = lookup_module.run(None, None)
    assert found_files == ["/tmp/unknown/path/file1.txt"]

    # checks that a list of files are looked up and an exception is raised when none of them exist
    lookup_module = LookupModule()

# Generated at 2022-06-11 15:24:47.192008
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # lookup = LookupModule()
    # assert lookup.run() == []
    pass

# Generated at 2022-06-11 15:24:58.179746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    # Get a reference to the class instantiation created by the helper functions in test_loader
    # Otherwise, we would have to import the module using a relative path.
    lookup = sys.modules['ansible.plugins.lookup.first_found']

    # We need to use the information provided by the real lookup to find the
    # files required by its tests.
    terms = ['fake_file', 'fake_file2']
    dir_paths = ['/tmp/ansible/files']

    # Call method run of class LookupModule with the values required to test it
    result = lookup.LookupModule().run(terms, dir_paths, files=['fake_file'], paths=['/tmp/ansible/files'])

    assert result == ['/tmp/ansible/files/fake_file']

    result = lookup.Look

# Generated at 2022-06-11 15:25:16.005348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    assert lookup.run(terms=[], variables={}, **{}) == [], "Checking return value for run with no terms"

    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup.run(terms=[{}], variables={}, **{})
    assert excinfo.value.args[0] == "No file was found when using first_found."

    assert lookup.run(terms=[{'paths': '', 'files': ''}], variables={}, **{}) == [], ("Checking return value for run with no file"
                                                                                 "or path.")


# Generated at 2022-06-11 15:25:25.941094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Loader used to load templates
    loader = DataLoader()

    # Variable manager takes care of merging all the different sources to give you a unifed view of variables available in each context.
    variable_manager = VariableManager()

    # Create a lookup module
    lookup_module = LookupModule()

    file_path = 'test1.txt'

    # Set the searchpath to a path that has the test file
    lookup_module._searchpaths = [os.path.abspath('./tests/fixtures/files')]

    # Create a path to test1.txt
    terms = [file_path]

    # Create a variables object
    variables = {}

    # Create a empty kwargs
    k

# Generated at 2022-06-11 15:25:36.167378
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l.set_options(direct={'files': 'file1.yaml', 'paths': '/tmp'}, var_options=dict())
    result = l._process_terms(['foo'], {}, {'skip': False})
    assert result[0] == [os.path.join('/tmp', 'file1.yaml')], result

    l = LookupModule()
    l.set_options(direct={'paths': '/tmp'}, var_options=dict())
    result = l._process_terms(['foo'], {}, {'skip': False})
    assert result[0] == [os.path.join('/tmp', 'foo')], result

    l = LookupModule()

# Generated at 2022-06-11 15:25:42.712271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the lookup object
    lookup = LookupModule()
    # Create the test parameters
    terms = [
        {'paths': ['/extra/path'], 'files': ['/path/to/foo.txt', '/path/to/bar.txt']},
        {'paths': ['/extra/path'], 'files': ['/path/to/foo.txt', '/path/to/bar.txt']},
    ]
    variables = {}
    kwargs = {}
    # Run the code
    result = lookup.run(terms, variables, **kwargs)
    # Verify the result
    assert result == ['/path/to/foo.txt']

# Generated at 2022-06-11 15:25:51.828723
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestTemplar:
        def __init__(self):
            pass

        def template(self, src):
            return src

    class TestLookupBase:
        def __init__(self):
            pass

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return True

    templar = TestTemplar()
    lookup_base = TestLookupBase()

    # Note: testing will be done one param variation at a time.
    #       ideally each run call variation should be tested.

    lookup = LookupModule()
    lookup._templar = templar
    lookup._subdir = 'files'

    # Test with terms is string.
    terms = 'foo.txt'
    lookup.set_loader(None)
    result = lookup.run

# Generated at 2022-06-11 15:25:53.928627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']
    assert LookupModule().run(terms, {}) == ['foo.bar']

# Generated at 2022-06-11 15:26:05.199880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    # setup
    import ansible.plugins.loader as plugin_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import io

    lookup_plugins = plugin_loader.LookupModule()
 
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager, host_list=['test_host'])
    variable_manager.set_inventory(inventory)
 
    variable_manager.extra_vars = {'inventory_hostname': 'test_host'}
    variable_manager.extra_vars = {'ansible_virtualization_type': 'test_type'}
 

# Generated at 2022-06-11 15:26:18.156801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialize the module
    module = LookupModule()

    # set up some test config and execute.
    terms = ['a', 'b', 'c']
    variables = {'inventory_hostname': 'd'}
    result = module.run(terms, variables)
    assert result == []

    # test method 'run' with no config and no search path
    terms = ['a', 'b', 'c']
    variables = {'inventory_hostname': 'd'}
    result = module.run(terms, variables)
    assert result == []

    # test method 'run' with config and no search path
    terms = ['a', 'b', 'c']
    variables = {'inventory_hostname': 'd'}
    result = module.run(terms, variables)
    assert result == []

    # test method 'run'

# Generated at 2022-06-11 15:26:30.090663
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    lookup_module = LookupModule()

    # these are basically just testing the 'subdir' handling, so no need to mock out find_file_in_search_path
    assert ['/tmp/production/foo'] == lookup_module.run([
        {
            'files': 'foo',
            'paths': '/tmp/production'
        }
    ])
    assert ['/tmp/production/foo', '/tmp/staging/foo'] == lookup_module.run([
        {
            'files': 'foo',
            'paths': '/tmp/production,/tmp/staging'
        }
    ])

# Generated at 2022-06-11 15:26:39.816785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # all values are the same and are the same as expected
    assert LookupModule(None, None).run([], {}) == []

    # files will be used, because they are in the dict
    assert LookupModule(None, None).run([{'files': 'file1'}], {}) == ['file1']

    # none of the files will be used, because they are not in the dicts
    assert LookupModule(None, None).run([{'files': 'file1'}, {'files': 'file2'}], {}) == ['file1']
    assert LookupModule(None, None).run([{'paths': 'path1'}, {'paths': 'path2'}], {}) == []

    # first list item will be used, because it is a string

# Generated at 2022-06-11 15:27:01.551478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    # Test case function parameters
    _terms = [{
        "files": "testfile",
        "paths": "/the/path",
        "skip": True
    }]
    _variables_has_key = {
        "testvar": "testvalue"
    }
    _variables_hasnt_key = {}

# Generated at 2022-06-11 15:27:12.588783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make a fake lookup module
    class FakeLookupModule(object):
        def __init__(self):
            self._templar = None
        def set_options(self, *args, **kwargs):
            pass
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            return fn
    flm = FakeLookupModule()

    # Assume the following variables are passed in to the lookup
    # module.
    variables = {
        'ansible_virtualization_type': 'kvm',
        'ansible_os_family': 'RedHat',
        'ansible_distribution': 'Fedora'
    }

    # The following files exist.

# Generated at 2022-06-11 15:27:24.297862
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile

    # set up base
    lookup = LookupModule()
    lookup.set_loader()

    # set up temp files
    tmp = tempfile.mkdtemp()
    f1 = os.path.join(tmp, 'a1')
    f2 = os.path.join(tmp, 'a2')
    f3 = os.path.join(tmp, 'b1')
    f4 = os.path.join(tmp, 'b2')
    open(f1, 'a').close()
    open(f2, 'a').close()
    open(f3, 'a').close()
    open(f4, 'a').close()

    # test single file
    rt = lookup.run([f1], {}, errors='ignore')
    assert rt == [f1]


# Generated at 2022-06-11 15:27:25.369650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add unit test
    pass

# Generated at 2022-06-11 15:27:34.802385
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = [
        "foo1.txt",
        "foo2.txt",
        {"foo3.txt": "/some/extra/path"},
        "foo4.txt"
    ]

    # check we can set defaults not set in module
    module.set_options(direct={"skip": False})

    try:
        result = module.run(terms, variables=None)
        assert False, "run() did not raise a LookupError when no files found"
    except AnsibleLookupError:
        pass

    # add some fake file paths to the search path
    module.set_fs_relative_paths([
        "/tmp/some/path/files",
        "/tmp/another/path/files",
        "/another/files/path"
    ])

    # create a list of 'files

# Generated at 2022-06-11 15:27:46.065674
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class for jinja2.Environment
    class MockTemplar:
        def __init__(self):
            pass
        def template(self, fn):
            return fn

    # Mock class for ansible.plugins.lookup.LookupBase (LookupModule)
    class MockLookupModule:
        def __init__(self):
            self._templar = MockTemplar()  # Mock for jinja2.Environment
            self.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: fn

    # Mock class for ansible.parsing.dataloader.DataLoader
    class MockDataLoader:
        def __init__(self):
            pass
        def path_dwim(self, fn):
            return fn

    lookupplugin = MockLook

# Generated at 2022-06-11 15:27:56.374452
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking class AnsibleModule
    class AnsibleModule:
        def __init__(self, name, argument_spec, **kwargs):
            pass
        def fail_json(self, **kwargs):
            pass

    # Mocking class AnsibleUndefinedVariable
    class AnsibleUndefinedVariable:
        pass

    # Mocking class Jinja2.UndefinedError
    class UndefinedError:
        pass

    # Mocking class Templar
    class Templar:
        def __init__(self, variables, **kwargs):
            pass
        def template(self, fn):
            return fn

    # Mocking class LookupBase
    class LookupBase:
        _templar = Templar({})
        def __init__(self, loader=None, run_once=False, **kwargs):
            pass

# Generated at 2022-06-11 15:28:07.064465
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options:
        connection = 'local'
        module_path = ''
        forks = 10
        remote_user = 'root'
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        verbosity = None
        check = False
        listhosts = None


# Generated at 2022-06-11 15:28:18.701802
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import cStringIO

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.plugins.loader import lookup_loader

    def _get_lookup(name):
        return lookup_loader._create_lookup_instance(name)

    def _save_sys_stdout_and_stderr():

        return sys.stdout, sys.stderr

    def _replace_sys_stdout_and_stderr():

        tmp = cStringIO()

        sys.stdout = tmp
        sys.stderr = tmp

    def _restore_sys_stdout_and_stderr(out, err):

        sys.stdout = out
        sys.stderr = err


# Generated at 2022-06-11 15:28:26.609493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: used to be at the top of this file, but it was inaccesible
    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return [(terms, variables, kwargs)]

    class DummyVarManager:
        def __init__(self, vars):
            self._vars = set(vars)

        def __contains__(self, item):
            return item in self._vars

    class DummyVars(dict):
        def __init__(self, _vars=None):
            _vars = _vars or {}
            super(DummyVars, self).__init__(_vars)
            self.variable_manager = DummyVarManager(set(_vars.keys()))


# Generated at 2022-06-11 15:29:01.412690
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # error when term is not a String
    try:
        LookupModule.run(terms=1, variables=None)
    except AnsibleLookupError as e:
        assert str(e) == "Invalid term supplied, can handle string, mapping or list of strings but got: <class 'int'> for 1"
    # error when term is not a String
    try:
        LookupModule.run(terms=dict(), variables=None)
    except AnsibleLookupError as e:
        assert str(e) == "Invalid term supplied, can handle string, mapping or list of strings but got: <class 'dict'> for {}"
    # error when term is not a String

# Generated at 2022-06-11 15:29:13.117106
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    files = []
    paths = ["/test_LookupModule_run_paths_1", "/test_LookupModule_run_paths_2"] # files
    skip = False
    terms = []
    variables = dict()
    terms.append(files)  # files
    terms.append(paths)  # paths
    terms.append(skip)
    findme = []
    findme.append("foo.txt")
    findme.append("bar.txt")
    variables.update({"findme": findme})
    variables.update({"inventory_hostname": "myfakehostname.com"})

    # Assert
    lookup_module = LookupModule()
    path = lookup_module.run(terms, variables)

    # Assert
    assert len(path) == 1

# Generated at 2022-06-11 15:29:15.826885
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: rewrite this tests with libraries available in ansible
    print()


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:29:27.693166
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Deflate the variables and kwargs args that are not used in the method
    def _run(terms, variables, **kwargs):

        lookup_module = LookupModule()
        return lookup_module.run(terms, variables, **kwargs)

    find_file_in_search_path_module_result = ['/foo/bar']

    # monkey patch in a mocked find_file function
    def _mock_find_file_in_search_path(variables, subdir, filename, ignore_missing):

        # NOTE: normally dict will be 'first' and remove other options from the list
        if isinstance(filename, dict):
            return None
        else:
            return '/foo/bar'

    LookupModule._find_file_in_search_path = _mock_find_file_in_search_path

    #

# Generated at 2022-06-11 15:29:36.040020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    kwargs = {'files': 'file1,file2', 'paths': '/tmp/test_paths'}
    terms = ['foo', {'files': 'file3'}, 'bar']

    # Mocked subclass
    class MockLookupModule(LookupModule):

        # Attribute to be set by the test
        _templar = None
        _subdir = 'files'

        def find_file_in_search_path(self, variables, basedir, fn, ignore_missing=True):

            # If the path contains one of the keys in the tests list, return it
            tests = {'foo': os.path.join(basedir, '/tmp/path1/file1'),
                     'bar': os.path.join(basedir, '/tmp/path2/file3')}

# Generated at 2022-06-11 15:29:46.955459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["test_file"]) == LookupModule().run([{"skip": False, "files": "test_file"}])
    assert LookupModule().run([{"skip": False, "files": "test_file", "paths": "test_path"}]) == ['test_path/test_file']
    assert LookupModule().run([{"skip": False, "files": ["test_file1", "test_file2"]}]) == ['test_file1']
    assert LookupModule().run([{"skip": False, "files": ["test_file1", "test_file2"], "paths": ["test_path1", "test_path2"]}]) == ['test_path1/test_file1']

# Generated at 2022-06-11 15:29:55.630618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l=LookupModule()
    l._subdir = 'files'

# Generated at 2022-06-11 15:30:00.940033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The call to run is just a return, so we cannot get back any information
    # to test it.  Just calling it is enough
    # Create an object of class LookupModule
    this_object = LookupModule()
    # Call run
    this_object.run(terms = ['test',], variables = [])

# Generated at 2022-06-11 15:30:11.253712
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_lookupModule(terms, variables, **kwargs):

        class MockLookupModule(LookupModule):

            def __init__(self, **kwargs):
                self.find_file_in_search_path_called = False
                self.iterated_terms = []

            def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
                self.find_file_in_search_path_called = True
                return None

        # Initialize
        lookup_plugin = MockLookupModule()
        lookup_plugin.set_loader(list)

        # Run
        ret = lookup_plugin.run(terms, variables, **kwargs)

        # Asserts
        assert ret == []
        assert lookup_plugin.find_file_in_search_path_called
       

# Generated at 2022-06-11 15:30:21.442890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule(None, None, None, None).run([{'files': 'foo', 'paths': '/etc'}], None)
    assert result[0] == '/etc/foo'

    result = LookupModule(None, None, None, None).run([{'files': 'foo', 'paths': '/etc/foo'}], None)
    assert result[0] == '/etc/foo/foo'

    result = LookupModule(None, None, None, None).run([{'files': 'baz/bar,foo', 'paths': '/etc/foo'}], None)
    assert result[0] in ['etc/foo/baz/bar', 'etc/foo/foo']


# Generated at 2022-06-11 15:31:18.321682
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO:
    # - test skip
    # - test errors='ignore'
    # - test different templates
    # - test search depth
    # - test dict as params
    # - test dict as params where two entries have same fn (both will be checked?)

    # WARNING: be careful running the tests, some of the paths are hardcoded
    #          and if the tests are run in another path, the paths need to be changed.
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_text
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    # the `mocker` fixture is the mock

# Generated at 2022-06-11 15:31:25.110398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = ('file1', 'file2', 'file3')
    for file in files:
        try:
            f = open(file, "w")
            f.close()
        except IOError:
            print("Problem creating file: %s" % (file))

    # creation of LookupModule object
    lm = LookupModule()

    # test with a file name only
    terms = ('file1',)
    actual = lm.run(terms, variables={}, ignore_errors=True)
    expected = [os.path.join(os.getcwd(), 'file1')]
    for act, exp in zip(map(os.path.abspath, actual), map(os.path.abspath, expected)):
        assert act == exp

    # test multiple file names with a sub directory

# Generated at 2022-06-11 15:31:29.790354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Basic test for class LookupModule
    """
    # create class instance 'lookup'
    lookup = LookupModule()

    # call 'run'
    lookup.run('some_terms', 'some_variables', files='some files', paths='some paths', skip='some skip')

test_LookupModule_run()

# Generated at 2022-06-11 15:31:38.852571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for method run of class LookupModule."""

    # testing empty terms
    terms1 = []
    variables1 = {'ansible_check_mode': False}
    kwargs1 = {'warn_only': False}
    ans1 = ['_ansible_no_log']
    assert LookupModule(terms1, variables1, kwargs1).run() == ans1

    # testing empty variables
    terms2 = ["foo"]
    variables2 = {}
    kwargs2 = {}
    ans2 = ['_ansible_no_log']
    assert LookupModule(terms2, variables2, kwargs2).run() == ans2

    # testing empty kwargs
    terms3 = ["foo"]
    variables3 = {'ansible_check_mode': False}
    kwargs3 = {}

# Generated at 2022-06-11 15:31:49.080277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = LookupModule()

    # Test1
    a = LookupModule()
    b = a.run(terms=['foo', 'bar'], variables=[])
    assert b == ['foo', 'bar']

    # Test2
    a = LookupModule()
    b = a.run(terms=['foo', 'bar'], variables=['/usr/share/ansible/'])
    assert b == ['/usr/share/ansible/foo', '/usr/share/ansible/bar']

    # Test3
    a = LookupModule()
    b = a.run(terms=[], variables=[])
    assert b == []

    # Test4
    a = LookupModule()
    b = a.run(terms=['foo'], variables=['/usr/share/ansible/'])

# Generated at 2022-06-11 15:31:58.577047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.plugins.loader import lookup_loader

    loader = lookup_loader._get_loader()
    LookupModule = loader.load('first_found')

    hostvars = {
        'ansible_env': {'HOME': 'home_dir'},
        'ansible_distribution': 'centos',
        'ansible_distribution_version': '7',
        'ansible_os_family': 'RedHat',
        'ansible_virtualization_type': 'kvm',
    }


# Generated at 2022-06-11 15:32:05.225738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=[dict(files=['/tmp/1.txt', '/tmp/2.txt', '/tmp/3.txt'], skip=True)])
    assert result == [], result

    result = LookupModule().run(terms=[dict(files=['/tmp/1.txt', '/tmp/2.txt', '/tmp/3.txt'])])
    assert result == [], result

    result = LookupModule().run(terms=['/tmp/1.txt', '/tmp/2.txt', '/tmp/3.txt'])
    assert result == [], result

    result = LookupModule().run(terms=[dict(files=['/tmp/1.txt', '/tmp/2.txt', '/tmp/3.txt'], skip=False)])
    assert result == [], result

    result = Look

# Generated at 2022-06-11 15:32:14.843209
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:32:25.748502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    # fmt: off