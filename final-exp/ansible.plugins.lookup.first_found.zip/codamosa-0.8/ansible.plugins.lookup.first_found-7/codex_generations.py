

# Generated at 2022-06-11 15:22:34.153018
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    m = LookupModule()
    terms = []
    variables = {}

    # Test 1
    terms.append("findme")
    total_search, skip = m._process_terms(terms, variables, {})
    assert(total_search == ["findme"] and skip == False)

    # Test 2
    terms.clear()
    terms.append("findme1")
    terms.append("findme2")
    terms.append("findme3")
    terms.append("findme4")
    total_search, skip = m._process_terms(terms, variables, {})
    assert(total_search == ["findme1", "findme2", "findme3", "findme4"] and skip == False)

    # Test 3

# Generated at 2022-06-11 15:22:39.151097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile


# Generated at 2022-06-11 15:22:46.818832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath

    terms = [
        {'files': 'test_files__test_first_found_1.txt,test_files__test_first_found_2.txt',
         'paths': '../test/integration/files/'},
        'test_files__test_first_found_3.txt'
    ]

    variables = dict()
    variations = [
        (terms, variables),
        (terms, dict(ansible_lookup_find='find_here_first')),
        (terms, dict(ansible_lookup_find='find_here_first', ansible_lookup_find_subdir='specific_subdir'))
    ]

    for term, variables in variations:
        l = LookupModule()

# Generated at 2022-06-11 15:22:58.091002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    t = Templar(loader=DataLoader())
    assert(LookupModule(basedir='').run([], t, skip=True) == [])

    class DataLoader(object):
        class FileFinder(object):
            def find_file_in_search_path(self, subdir, filename, ignore_missing):
                filename_list = filename.split('/')
                if filename_list[-1] == 'b':
                    return filename
                return None
    t = Templar(loader=DataLoader())


# Generated at 2022-06-11 15:23:08.753581
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # As is the result of the template we need to mock search path.
    def find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        return "/home/docs/file1.txt"

    # Mock a templar
    def template(value):
        return value

    lookup_module.get_option = lambda a, b: b
    lookup_module._templar = type('TestTemplar', (object,), {'template': template})()
    lookup_module.find_file_in_search_path = find_file_in_search_path

    assert lookup_module.run(['file1.txt'], {}) == ['/home/docs/file1.txt']

# Generated at 2022-06-11 15:23:22.148905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            if fn == '/path/to/foo.txt':
                return '/path/to/foo.txt'
            elif fn == 'bar.txt':
                return '/path/to/bar.txt'
            elif fn == '/path/to/biz.txt':
                return '/path/to/biz.txt'
            elif fn == 'foo':
                return '/path/to/foo'
            elif fn == '/tmp/production/foo':
                return '/tmp/production/foo'
            elif fn == 'bar':
                return '/path/to/bar'
            elif fn == '/tmp/production/bar':
                return '/tmp/production/bar'
           

# Generated at 2022-06-11 15:23:31.553540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _files_dir = os.path.join(os.path.dirname(__file__), 'files', 'first_found')

    _expected_result_1 = [os.path.join(_files_dir, 'file2')]
    _params_1 = {
        'files': 'file1,file2,file3',
        'paths': [_files_dir]
    }
    _terms_1 = ['file1,file2,file3']
    _params_2 = {
        'files': 'file2,file3,file1',
        'paths': [_files_dir]
    }
    _terms_2 = ['file2,file3,file1']

# Generated at 2022-06-11 15:23:40.300956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init and run
    import os
    import os.path
    lookup_return = None
    files = ["file1.txt","file2.txt"]
    paths = ["/tmp"]

    findme = [{ "files": files, "paths": paths, "skip": False}]
    variables = {}
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    lookup_run = LookupModule().run(findme, variables, **{})

    # Assertion
    assert lookup_run[0] == '/tmp/file1.txt'

# Generated at 2022-06-11 15:23:49.046028
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # testing LookupModule._process_terms
    # with all kinds of abusable data

    # testing var override
    expected = ['/path/to/bar.txt'], False
    result = LookupModule._process_terms(None, [
        {'files': '/path/to/bar.txt'}],
        {'files': '/path/to/foo.txt', 'paths': '/path/to/'},
    )
    assert result == expected, 'failed to process files overridden by variable'

    expected = ['/path/to/bar.txt', '/path/to/biz.txt'], False

# Generated at 2022-06-11 15:23:59.640159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _assert(terms, variables, kwargs, expected_run, expected_terms):
        lookup_obj = LookupModule()
        lookup_obj.set_options(var_options=variables, direct=kwargs)
        run_result = lookup_obj.run(terms, variables)
        assert run_result == expected_run
        assert lookup_obj._terms == expected_terms

    # test 1
    terms = [
        'foo.txt',
        'bar.txt',
        'biz.txt'
    ]
    variables = {}
    kwargs = {}
    expected_run = ['/path/to/foo.txt']
    expected_terms = ['/path/to/foo.txt', '/path/to/bar.txt', '/path/to/biz.txt']

# Generated at 2022-06-11 15:24:03.898858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:24:15.487072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule = None
    # test 1.1 - successful lookup with ignore missing
    def fake_find_file(self, variables, subdir, fn, ignore_missing=False):
        return fn
    LookupModule.find_file_in_search_path = fake_find_file
    terms = ['/some/path/file1', '/some/path/file2']
    search_result = LookupModule.run(terms, None)
    assert search_result == ['/some/path/file1']
    # test 1.2 - unsuccessful lookup with ignore missing
    def fake_find_file(self, variables, subdir, fn, ignore_missing=False):
        return None
    LookupModule.find_file_in_search_path = fake_find_file
    search_result = LookupModule.run(terms, None)

# Generated at 2022-06-11 15:24:18.952715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['test.txt']
    lookup_obj = LookupModule()
    # create a file
    with open(terms[0], 'w') as f:
        f.write('test')
    # assert returned value
    assert lookup_obj.run(terms, {}) == [os.path.abspath(terms[0])]

# Generated at 2022-06-11 15:24:30.660915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = [
        {
            'initial_terms': ['/etc/foo.conf', 'foo'],
            'dict_terms': {
                'files': ['/etc/foo.conf', 'foo'],
                'paths': ['/etc/bar.conf', 'bar'],
            },
            'initial_vars': {},
            'expected_results': ['/etc/foo.conf']
        },
        {
            'initial_terms': [],
            'dict_terms': [{
                'files': [],
                'paths': ['/etc/bar.conf'],
            }],
            'initial_vars': {},
            'expected_results': []
        },
    ]


# Generated at 2022-06-11 15:24:37.939202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    lookup_instance = LookupModule()
    lookup_instance._subdir = 'files'

    # test that given a string, a list of file is built from comma separated values
    assert lookup_instance._split_on("foo.txt,bar.txt") == ['foo.txt', 'bar.txt']

    # test that given a list of items, the returned list is a concatenation of the list of files built
    # from the comma separated items
    assert lookup_instance._split_on(["foo.txt,bar.txt", "baz.txt, quux.txt"]) == ['foo.txt', 'bar.txt', 'baz.txt', 'quux.txt']

    # test that given a list of items, a list of file is built from the list items excepted if they are

# Generated at 2022-06-11 15:24:46.525808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    variables = dict(
        ansible_virtualization_type='os',
        ansible_virtualization_role='guest',
        ansible_distribution='RedHat',
        ansible_os_family='RedHat',
    )
    result = lookup_plugin.run([
        {'files': 'foo,bar', 'paths': ['/path/to/bar', '/path/to/foo']},
        {'files': 'foo,bar', 'paths': ['/path/to/bar', '/path/to/foo']},
    ], variables, skip=False, errors='ignore')
    assert result == [None, None]

# Generated at 2022-06-11 15:24:57.739755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lookup_module = LookupModule()

    # create test data
    # we would like to test that the run method of LookupModule correctly
    # checks if a file is present in a list of files and paths,
    # and if it exists in one of them it returns the full path
    # to first found file, else it raises the exception AnsibleLookupError
    # (this is the same as the first_found lookup plugin)
    #
    # looking for tmp file to use
    import tempfile
    tmpfile = tempfile.mkstemp()[1]

    # we will use the var1.yml file from test/unit/plugins/lookup_plugins/files as template
    # we will also use the lookup_plugins directory
    # as the search path
    # we will use the created tmp file as the

# Generated at 2022-06-11 15:25:04.898652
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common.collections import ImmutableDict

    FindFiles = LookupModule()
    FindFiles.set_options(var_options=ImmutableDict(), direct={'skip': False})

    # Define a using a list of string
    try:
        assert [fn.strip()
                for fn in open("../test/test.conf").readlines()] == FindFiles.run("test.conf", ImmutableDict())
    except OSError:
        if fn.strip() != 'test.conf':
            raise

    # Define a using a list of string as second item

# Generated at 2022-06-11 15:25:11.982848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    cwd = os.getcwd()
    os.chdir(cwd)

    lm = LookupModule()
    lm._subdir = 'files'

    terms = ['foo', 'bar', 'baz']
    terms = lm._process_terms(terms, {}, {})
    result = lm.run(terms, {}, lookup_file='first_found')
    assert result == []

# Generated at 2022-06-11 15:25:23.561118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(direct={'paths': ['1']})
    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing=False: fn

    assert lookup.run(terms=['bar'], variables={}) == ['bar']
    assert lookup.run(terms=['bar', 'bar'], variables={}) == ['bar']
    assert lookup.run(terms=['bar', 'foo'], variables={}) == ['bar']

    assert lookup.run(terms=[{'files': 'bar'}], variables={}) == ['bar']
    assert lookup.run(terms=[{'files': 'bar'}, {'files': 'bar'}], variables={}) == ['bar']

# Generated at 2022-06-11 15:25:39.565859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    # Create a dummy jinja2 template object
    class DummyTemplate():
        def __init__(self, path):
            self.path = path
        def template(self, fn):
            return os.path.join(self.path, fn)
    # Create a dummy "AnsibleModule" object
    class DummyAnsibleModule():
        def __init__(self, path):
            self.template = DummyTemplate(path)
    # Create a dummy variable object
    variables = {}
    lookup_module = LookupModule(DummyAnsibleModule('/dummy'))
    # Test input is string with space, comma, ';' as delimiters
    # and output is a list with expected file paths joined with
    # '/dummy' by the jinja2 template template()
    assert lookup_

# Generated at 2022-06-11 15:25:47.862538
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # a file that exists
    path = '/etc/ansible/ansible.cfg'

    # terms to simulate a task
    terms = [
        {'files': path, 'paths': '::/tmp'},
        {'files': path, 'paths': '::/tmp'},
    ]

    # given class LookupModule
    lm = LookupModule()

    # when we call run
    result = lm.run(terms, None)

    # then we expect path to file found
    result == [path]

# unit tests for method _process_terms of class LookupModule

# Generated at 2022-06-11 15:25:58.954606
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import fixture
    import pytest

    # create dummy module
    obj = fixture.DummyModule()

    # create LookupModule object
    lm = LookupModule(obj)

    # create terms dictionary
    terms = {
        'files': 'file1,file2',
        'paths': 'path1,path2:path3',
        'skip': True,
    }

    # create terms list with terms dictionary
    terms_list = [
        terms,
    ]

    # create file list with files
    files = [
        'file1',
        'file2',
    ]

    # create file list with files and paths

# Generated at 2022-06-11 15:26:05.986744
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_loader_obj = MockLoader()
    mock_ds_obj = MockData()

    # Creating instance of LookupModule
    mock_lookup_obj = LookupModule(loader=mock_loader_obj,
                                   basedir=os.path.join(os.getcwd(), 'test', 'unit', 'lookup_plugins'))

    # Get the class object of the MockLoader class
    mock_loader_class_obj = getattr(mock_loader_obj, '_loader')

    # Get the class object of the MockData class
    mock_ds_class_obj = getattr(mock_ds_obj, '_ds')

    # Get the values of the instance variables of MockLoader class
    mock_loader_finder_obj = mock_loader_class_obj._finder
    mock_loader_paths = mock

# Generated at 2022-06-11 15:26:12.668704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_object = LookupModule()
    lookup_object._subdir = 'files'
    variables = {}
    terms = [{'files': 'foo.conf', 'paths': '/tmp/production:/tmp/staging'}]
    result = lookup_object.run(terms, variables)
    assert result == ['/tmp/production/foo.conf']


# Generated at 2022-06-11 15:26:22.804604
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: testing with Python 2 and 3
    try:
        from __builtin__ import unicode
    except ImportError:
        unicode = str

    from ansible.module_utils._text import to_bytes

    # NOTE: not sure why/how but it seems that the lookup db is part of this test
    from ansible.plugins.loader import lookup_loader
    LookupModule(loader=lookup_loader)

    # NOTE: this is a static method, so it is a bit odd to test it with self==None
    terms = [
        "{{ undefined_var }}",
        ["{{ undefined_var }}", "default.yml"],
        {"files": "{{ undefined_var }}", "paths": "/tmp/production"}
    ]


# Generated at 2022-06-11 15:26:26.708444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return True

if __name__ == '__main__':
    print('Test of module "first_found.py"')
    if test_LookupModule_run():
        print('PASSED')
    else:
        print('FAILED')

# Generated at 2022-06-11 15:26:37.566699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    # Create the lookup object
    lookup = LookupModule()

    # Create the temp files
    temp_dir = tempfile.mkdtemp()
    look_path = os.path.join(temp_dir, 'look.txt')
    file1_path = os.path.join(temp_dir, 'file1.txt')
    file2_path = os.path.join(temp_dir, 'file2.txt')
    file3_path = os.path.join(temp_dir, 'file3.txt')

# Generated at 2022-06-11 15:26:48.882646
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    
    # case if no file found
    files = ['file.txt', 'file.md']
    paths = ['src/configs', './src/configs']
    result = lookup_module.run(['test.txt'], {}, files=files, paths=paths)
    assert result == []

    # case if no file found, skip=False
    files = ['file.txt', 'file.md']
    paths = ['src/configs', './src/configs']
    with pytest.raises(AnsibleLookupError) as e:
        result = lookup_module.run(['test.txt'], {}, files=files, paths=paths, skip=False)
    assert str(e.value) == "No file was found when using first_found."

   

# Generated at 2022-06-11 15:27:00.337089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict

    # When using a list of strings
    lookup = LookupModule(None, None)
    result = lookup.run(["file1.conf","file2.conf"])
    assert result == ["file1.conf"]

    # When using a dictionary
    result = lookup.run([{"files": "file1.conf,file2.conf"}])
    assert result == ["file1.conf"]

    # When using a list of dictionaries
    result = lookup.run([{"files":"file1.conf"},{"files":"file2.conf,file3.conf"}])
    assert result == ["file1.conf"]

    # When using a list of tuple
    result = lookup.run([("file1.conf",),("file2.conf","file3.conf",)])


# Generated at 2022-06-11 15:27:25.971393
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    module_name = LookupModule.__module__
    lookup_name = LookupModule.__name__

    class FakeLookupModule(LookupModule):

        def __init__(self, terms, variables, **kwargs):

            self._templar = FakeTemplar()
            self.options = {}

        def set_options(self, var_options=None, direct=None):
            if direct:
                self.options.update(direct)

        def get_option(self, value):

            try:
                return self.options[value]
            except KeyError:
                pass

            return None

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):

            self._subdir = subdir
            return '/path/to/file'


   

# Generated at 2022-06-11 15:27:35.197856
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    kwargs = dict(files=[], paths=[], skip=False)
    ret = LookupModule._process_terms(None, ['foo.txt'], kwargs)
    assert ret == (['foo.txt'], False), dict(terms=['foo.txt'], ret=ret)

    ret = LookupModule._process_terms(None, ['foo.txt', {'files': 'bar.txt'}], kwargs)
    assert ret == (['foo.txt', 'bar.txt'], False), dict(terms=['foo.txt', {'files': 'bar.txt'}], ret=ret)

    ret = LookupModule._process_terms(None, [{'files': 'foo.txt'}, {'files': 'bar.txt'}], kwargs)

# Generated at 2022-06-11 15:27:46.484043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the potential files are in paths and files, in the order given
    # first_found should find the only existing file and return it
    terms = [
        {'files': 'file1', 'paths': '/potential/file1'},
        {'files': 'file1', 'paths': '/no/file1'},
        {'files': 'file2', 'paths': '/no/file2'},
        {'files': 'file2', 'paths': '/potential/file2'},
    ]
    variables = {}
    kwargs = {}
    expected = '/potential/file1'
    # 'file1' exists in path '/potential'
    # 'file2' exists in path '/potential'
    # first file found is 'file1' in path '/potential'
    lup = Lookup

# Generated at 2022-06-11 15:27:56.538532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    module = LookupModule()
    terms = [{'files': 'f1', 'paths': 'p1'}, {'files': 'f2', 'paths': 'p2'}]
    module._find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: ''.join([subdir, fn])
    module._templar = Mapping()
    module._templar.template = lambda text: text
    assert module.run(terms, None, skip=False) == ['filesp1f1', 'filesp2f2']
    class customError(Exception): pass
    module._find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None
    module._templ

# Generated at 2022-06-11 15:28:01.844992
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test 1st case:
    #   lookup_options:
    #     terms:
    #       - /path/to/foo.txt
    #       - bar.txt  # will be looked in files/ dir relative to role and/or play
    #       - /path/to/biz.txt
    #
    #   expected result:
    #     ['/path/to/foo.txt'], None

    lookup_options = {
        'terms': [
            '/path/to/foo.txt',
            'bar.txt',
            '/path/to/biz.txt'
        ],
        'files': ['foo.txt', 'bar.txt', 'biz.txt'],
        'paths': ['/path/to/'],
    }

    l = LookupModule()

    # set search_path for unit test


# Generated at 2022-06-11 15:28:10.146809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test terms that raise an exception
    terms = [1.1, {'name': 'test'}]
    variables = {}
    kwargs = {}
    for term in terms:
        try:
            lookup.run(term, variables, **kwargs)
        except Exception as e:
            assert 'Invalid term supplied' in str(e)

    # test term without 'paths' or 'files'
    terms = ['test']
    variables = {}
    kwargs = {}
    try:
        lookup.run(terms, variables, **kwargs)
    except Exception as e:
        assert 'No file was found when using first_found' in str(e)

    # test term with 'paths' or 'files'
    terms = ['test1', 'test2']
    variables = {}

# Generated at 2022-06-11 15:28:21.598266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest
    #
    # test data
    #

# Generated at 2022-06-11 15:28:32.521638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock the lookup base class to test class LookupModule
    class MockLookupBase(LookupBase):
        def find_file_in_search_path(self, variables, searchpath, filename, ignore_missing=False):
            return self._full_path_to_file


    # Mock ansible context to test class LookupModule
    class MockAnsibleContext(object):
        class MockAnsibleUndefinedVariable(Exception):
            pass

        class MockUndefinedError(Exception):
            pass

        class MockAnsibleLookupError(Exception):
            pass

        class MockAnsibleVariableManager(object):
            class MockTemplar(object):
                def __init__(self):
                    self._template_data = {'test_template': 'test-template-value'}


# Generated at 2022-06-11 15:28:33.851829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mocking of
    assert True == False


# Generated at 2022-06-11 15:28:42.224066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setUp
    file_name = 'file_name'
    subdir = 'file'
    path = '/path_to/file_name'
    terms = [file_name]
    variables = {}

    def find_file_in_search_path(variables, subdir, file_name, ignore_missing):
        if file_name == 'file_name':
            return path
        raise AnsibleLookupError()

    # mock
    class File:
        def mock_method(self, terms, variables, **kwargs):
            # assert
            self.assertEqual(terms, [file_name])
            self.assertEqual(subdir, 'file')
            self.assertEqual(variables, {})
            return []
    
    # act
    instance = File()
    instance.run = File.m

# Generated at 2022-06-11 15:29:22.451681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'files': ['file.txt',], 'paths': ['path1', 'path2', 'path3'],},
             {'files': ['file1.txt', 'file2.txt'], 'paths': ['path1',],},
             {'files': ['file3.txt', 'file4.txt'], 'paths': ['path1', 'path2',],},]

# Generated at 2022-06-11 15:29:32.739690
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:29:43.881840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files' # used in find_file_in_search_path method

    with open('examples') as fp:
        playbook_path = fp.readline()[:-1]

    class Options(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Variables(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    terms = [{
        'files': ['examples'],
        'paths': [os.path.join(playbook_path, 'lookup_plugins')],
        'skip': False
    }]


# Generated at 2022-06-11 15:29:54.443578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._lookup_plugin_check_conditional = True
    lookup._templar = DummyTemplar()
    lookup._loader = DummyLoader()
    lookup._searchpath_cache = {}

    # test with a relative path
    terms = ['foo']
    variables = {'playbook_dir': 'bar'}
    result = lookup.run(terms, variables, paths=['foo'], files=[])
    assert result == [os.path.join('bar', 'foo', 'foo')]

    # test with a absolute path
    terms = ['/baz']
    variables = {'playbook_dir': 'bar'}
    result = lookup.run(terms, variables, paths=['foo'], files=[])
    assert result == ['/baz']

    # test with a relative path

# Generated at 2022-06-11 15:30:06.537806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pickle
    import os
    import shutil

    #Test variables
    testLocation = 'testPath'
    testFile1 = 'testFile1.txt'
    testFile2 = 'testFile2.txt'
    testFile3 = 'testFile3.txt'
    subtestFile1 = 'subtestFile1.txt'
    subtestFile2 = 'subtestFile2.txt'
    subtestFile3 = 'subtestFile3.txt'
    subtestFile4 = 'subtestFile4.txt'
    testContent = 'Hello'

    lm = LookupModule()

    #Create a new test folder
    os.mkdir(testLocation)
    os.chdir(testLocation)

    #Create a new file
    testFile1write = open(testFile1, 'w')
    testFile1

# Generated at 2022-06-11 15:30:14.618155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Note: the test values are the ones used in the README file,
    # which can get out of sync if not modified in both locations

    lookup = LookupModule()

    # Test the case where files is not present at all
    term = {}
    files = ""
    paths = "/path/to/file/1,/path/to/file/2"

    term['paths'] = paths
    total_search = []
    for path in paths.split(','):
        for fn in files.split(','):
            total_search.append(os.path.join(path, fn))

    assert total_search == lookup._process_terms([term], {}, {})[0]

    # Test the case where paths is not present at all
    term = {}
    files = "foo/file1,bar/file2"

# Generated at 2022-06-11 15:30:25.556891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    module = LookupModule()

    # test with files and paths used
    params = {
        'files': ['file1', 'file2'],
        'paths': ['/tmp/production', '/tmp/staging'],
    }
    results = module.run(terms=[params], variables=variable_manager)
    assert results == ['/tmp/production/file1']

    # test with files used
    params = {
        'files': ['file1', 'file2'],
    }

# Generated at 2022-06-11 15:30:32.173765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils import module_docs
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    lookup = LookupModule()
    lookup._templar = lookup._loader.load_plugin('template')

    # Note: does not test the 'complex' form as the code is not consistent
    # in how it handles the data. basically the 'when' will only work once.

    # target file is missing
    terms = ['foo/bar.conf']
    variables = {}
    ret = lookup.run(terms, variables)
    assert ret == [], ret

    # target file is missing
    terms = ['foo/bar.conf']
    variables = {}
    kwargs = {'skip': True}
    ret = lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-11 15:30:43.999141
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    template_dir_path = os.path.dirname(os.path.abspath(__file__))
    lookup = LookupModule()
    lookup._subdir = 'lookup_plugins'
    path = '/home/test/test.txt'
    search_path = ['.', 'lookup_plugins'] + lookup._searchpath

    with patch.object(lookup, 'find_file_in_search_path', return_value=path) as mocked_find_file_in_search_path:
        # testing with valid terms
        assert lookup.run(['test.txt'], {}) == [path]
        mocked_find_file_in_search_path.assert_called_with({}, 'files', 'test.txt', ignore_missing=True)

        # testing with valid expanded path

# Generated at 2022-06-11 15:30:55.279663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        'file1',
        '/path/file2',
        {'files': 'file3'},
        {'files': 'file4', 'paths': '/path'},
        [
            'file5',
            {'files': 'file5.5'},
            [
                {'files': 'file5.75', 'paths': 'path/path2'},
                {'files': 'file5.8'}
            ]
        ]
    ]
    variables = {
        'ansible_distribution': 'centos',
        'ansible_os_family': 'redhat'
    }
    kwargs = {
        'files': 'file0',
        'paths': '/path1'
    }

# Generated at 2022-06-11 15:31:53.923892
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:32:02.574054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if list of files is searched correctly
    assert LookupModule(loader=None, templar=None).run(terms=["a", "b", "c", "d"], variables={}) == ["a"]
    assert LookupModule(loader=None, templar=None).run(terms=["e", "f", "g", "h"], variables={}) == ["e"]
    assert LookupModule(loader=None, templar=None).run(terms=["i", "j", "k", "l"], variables={}) == ["i"]
    # Test if list of paths and files is searched correctly
    assert LookupModule(loader=None, templar=None).run(terms=["m", "n", "o", "p"], variables={}, paths="a,b,c", files="d") == ["a/d"]
   

# Generated at 2022-06-11 15:32:13.265360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = FakeTemplar()

    lookup._loader = FakeLoader()

    # testing different variations of inputs
    findme = ['foo']
    assert lookup.run(['foo'], None) == ['/tmp/ansible/files/foo']

    findme = ['foo', {'paths': ['path0', 'path1']}]
    assert lookup.run(findme, None) == ['/tmp/ansible/path0/foo', '/tmp/ansible/path1/foo']

    findme = ['foo', {'paths': ['path0', 'path1']}, 'bar']

# Generated at 2022-06-11 15:32:24.497585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    if PY3:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    else:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes as AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    path = '/some/fake/path'
    files = ['foo.txt', 'bar.txt']
    paths = ['/extra/path']
    terms = [files, paths, True]

    terms_list = [[files, paths, True], [files, paths, False]]
