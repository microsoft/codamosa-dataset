

# Generated at 2022-06-11 15:22:34.269061
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # first file found in search is returned otherwise raises an exception
    # Note this removes the need for the 'lookup fail' plugin which can be
    # removed at some point.

    # NOTE: when using a dict terms, the options in the dict clobber previous.

    lu = LookupModule()

    with pytest.raises(AnsibleLookupError):
        lu.run(terms=['does_not_exist.sh'], variables={})

    with pytest.raises(AnsibleLookupError):
        lu.run(terms=['does_not_exist.sh', 'still_does_not.sh'], variables={})


# Generated at 2022-06-11 15:22:37.721390
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_data = {
        'terms': [],
        'variables': {},
        'expected': [],
        'err_expected': Exception,
        'err_match': 'No file was found when using first_found.'
    }

    return test_data

# Generated at 2022-06-11 15:22:45.766189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict

    # test passing a list of file names
    lookup = LookupModule()
    terms = ['file1', 'file2']
    variables = {'_terms': terms}
    kwargs = {'lookup/foo': 'bar'}
    total_search, skip = lookup._process_terms(terms, variables, kwargs)
    assert len(total_search) == 2
    assert not skip

    # test passing a list of paths
    lookup = LookupModule()
    terms = ['file1', 'file2']
    variables = {'_terms': terms}
    kwargs = {'files': ['file1', 'file2'], 'paths': ['/path/to/foo', '/path/to/bar']}
    total_search,

# Generated at 2022-06-11 15:22:49.959095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup = LookupModule()
   assert lookup.run(['foo'], {}, skip=False) == [], 'No file was found when using first_found.'
   assert lookup.run(['foo'], {}, skip=True) == [], 'No file was found when using first_found.'

# Generated at 2022-06-11 15:23:00.550224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is a mess but it works. Refactoring is needed.
    class Tester(object):
        def __init__(self):
            self.name = 'Tester'

        def template(self, value):
            return value

    source_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..'))
    test_path = os.path.join(source_path, 'test', 'files')
    files_path = os.path.join(test_path, 'first_found')

    lookup_obj = LookupModule()
    lookup_obj._templar = Tester()
    lookup_obj._basedir = source_path
    lookup_obj._loader = None

# Generated at 2022-06-11 15:23:09.690108
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms = [
        dict(skip=True)
    ]

    variables = dict()

    assert [], lookup_module.run(terms, variables)

    terms = [dict(files=['a', 'b'])]

    variables = dict()

    lookup_module._finder = MockFileFinder(files=['files/a'])

    assert ['files/a'], lookup_module.run(terms, variables)

    variables = dict()

    lookup_module._finder = MockFileFinder(files=[])

    assert [], lookup_module.run(terms, variables)


# Generated at 2022-06-11 15:23:22.785922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('some.file', '', paths={'paths': '/some/path'}) == ['/some/path/some.file']
    assert lookup_module.run('some.file', '', paths={'files': 'some.file', 'paths': '/some/path'}) == ['/some/path/some.file']
    assert lookup_module.run('some.file', '', paths={'files': 'some.file', 'paths': '/some/path'}) == ['/some/path/some.file']
    assert lookup_module.run('some.file', '', paths={'files': 'some.file', 'paths': '/some/path'}, skip=True) == ['/some/path/some.file']

# Generated at 2022-06-11 15:23:29.321618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar and variables
    templar = MockTemplar()
    variables = {}

    # Create a LookupModule object and run the module
    lookup_module = LookupModule()
    result = lookup_module.run([[['file1'], ['file1a', 'file2'], {'files': ['file1'], 'paths': ['path1', 'path2']}]], variables)
    result = sorted(result)

    assert(result == ['path1/file1', 'path2/file1'])


# Generated at 2022-06-11 15:23:40.747672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-variable, wildcard-import
    import yaml
    from ansible import context
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    class OptionsModule(object):
        def __init__(self, become_user=None, become_method=None, become_flags=None, connection=None, remote_user=None, private_key_file=None,
                     diff=False, ansible_vault_password=None, true_vault_password=None, ansible_vault_password_file=None):
            self.connection = connection
            self.become = become_user
            self.become_method = become_

# Generated at 2022-06-11 15:23:49.280273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # pylint: disable=no-self-use
    class LookupModuleMock(LookupModule):
        def find_file_in_search_path(self, variables, paths, file, ignore_missing):
            return file is not None and '/tmp/file1'

    # raise an exception if no file found
    lookup = LookupModuleMock()
    res = lookup.run([{'files': 'file1', 'paths': '/tmp', 'skip': False }], 'variables', **{'files': 'file1', 'paths': '/tmp'})
    assert res == ['/tmp/file1']

    # return empty list if no file found and skip=True
    lookup = LookupModuleMock()

# Generated at 2022-06-11 15:24:01.182770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.
    """

    # Initialize the lookup module.
    lookup_module = LookupModule()

    # Run the method.
    # Initialize the path.
    path = "/root/ansible/lookup_plugins/first_found.py"
    # Initialize the absolute path.
    absolute_path = os.path.dirname(os.path.abspath(path)) + "/files"

    # Run the method.
    result = lookup_module.run("", "", files="first_found.py", paths=absolute_path)

    # Initialize the expected result.
    expected_result = ['files/first_found.py']

    # Assert that the results are the same.
    assert result == expected_result

# Generated at 2022-06-11 15:24:01.801593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-11 15:24:06.751169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_getattr(self, attr, default):
        return 'files'

    module = LookupModule()
    module._getattr = mock_getattr
    module.run(terms=['/etc/ansible/foo.conf'], variables={'role_path': '/etc/ansible'})


# Generated at 2022-06-11 15:24:07.763827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-11 15:24:18.676524
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # get parameters
    mock_self = LookupModule()
    mock_self._templar = MockTemplar()
    mock_variables = {'test': 'success'}
    mock_terms = ['hello']
    mock_kwargs = {'test': 'success'}

    # mock _process_terms
    mock_total_search = ['foo']
    mock_skip = False
    mock_self._process_terms = Mock(return_value=(mock_total_search, mock_skip))

    # mock _subdir
    mock_self._subdir = 'files'

    # mock find_file_in_search_path
    mock_path = ['foo']
    mock_find_file_in_search_path = Mock(return_value=mock_path)
    mock_self.find_file_in_

# Generated at 2022-06-11 15:24:30.361269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Handle term as a list of strings
    ansible_options = {}
    ansible_options["src"] = "https://github.com/ansible/ansible/modules/core/cloud/cloudscale/cloudscale_server.py"
    ansible_options["skip"] = False
    lookup_module._templar = 'template'

    # Handle term as a string
    try:
        lookup_module.run(["cloudscale_server.py"], ansible_options)
    except Exception as e:
        assert str(e) == "Invalid term supplied, can handle string, mapping or list of strings but got: <class 'str'> for cloudscale_server.py"

    # Handle term as a mapping
    terms = [{"files": "cloudscale_server.py", "skip": False}]


# Generated at 2022-06-11 15:24:34.904467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar = None
    lm._loader = lm._loader = None
    lm._find_file_in_search_path = None

    params = {'files': ['inventory_file'], 'paths': None}
    while True:
        print(lm._process_terms([params]))
        break

# Generated at 2022-06-11 15:24:45.405035
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Example 1.

    items = [
        {'files': 'foo.txt', 'paths': ['/path/to']},
        'bar.txt',
        {'files': 'foo.txt', 'paths': ['/path/to/biz']},
    ]

    assert LookupModule().run(items, {}, skip=False) == ['/path/to/foo.txt']

    # Example 2.

    items = [
        {'files': 'foo.txt', 'paths': ['/path/to']},
        'bar.txt',
        {'files': 'foo.txt', 'paths': ['/path/to/biz']},
    ]

    assert LookupModule().run(items, {}, skip=True) == []

# Generated at 2022-06-11 15:24:57.043263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader
    import os

    lm = lookup_loader.get('first_found')
    assert lm.run(['test', ['test2'], 'test3'], {})[0] == to_bytes(os.path.join(os.path.dirname(__file__), 'test'))
    lm.set_options(direct={'paths': 'test'}, var_options={})
    assert lm.run([['test2'], 'test3'], {})[0] == to_bytes(os.path.join(os.path.dirname(__file__), 'test', 'test2'))
    lm.set_options(direct={'files': 'test2'}, var_options={})
   

# Generated at 2022-06-11 15:25:04.535299
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock class to test run method
    class MockLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            if fn in ['test', 'test1', 'test2', 'test3']:
                return self._loader.path_dwim_relative_to_file(self._basedir, 'files', subdir, fn)

    lookup = MockLookupModule()
    lookup._loader = object
    lookup._loader.path_dwim_relative_to_file = lambda x, files, subdir, fn: '/path/to/files/'

    res = []

    # test with list terms and list paths

# Generated at 2022-06-11 15:25:22.613357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.plugins.lookup.first_found import LookupModule

    lookup_plugin = LookupModule()

    # test 1
    terms = [
        {'files': 'file1, file2', 'paths': '/path1, /path2'},
        'file3',
    ]

# Generated at 2022-06-11 15:25:33.376942
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:25:34.430992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO add some tests here
    print('no tests')

# Generated at 2022-06-11 15:25:40.436133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()

    # set up
    my_lookup._subdir = 'files'
    my_lookup._templar = """Ansible Templating Engine"""
    # test input
    my_terms = ["""/path/to/first_found.py"""]

    # test result
    test_result = my_lookup.run(my_terms, {})
    # check result
    assert test_result == ["""/path/to/first_found.py"""]

# Generated at 2022-06-11 15:25:50.445240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set it up
    terms = "https://example.com/foo.tar.bz2"
    variables = {}
    params = {}
    lookup_module = LookupModule()
    lookup_module._subdir = "files"
    lookup_module.set_options(var_options=variables, direct=params)
    lookup_module._templar = MockTemplar()
    lookup_module.find_file_in_search_path = MockFindFileInSearchPath()

    # Test if the method raises or returns a value, then return the correct Ansible error

# Generated at 2022-06-11 15:26:02.556978
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockedLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing):
            if filename == '1':
                return '/files/1'
            elif filename == '2':
                return '/files/2'
            elif filename == '3':
                return '/files/3'
            elif filename == '4':
                return '/files/4'
            else:
                return None

    # see note above about single dict, this is a placeholder to also test that
    # when using kwargs in run, it does not clash with the method opts.

# Generated at 2022-06-11 15:26:14.640260
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    L = LookupModule()
    terms = ['foo.yml', 'bar.yml']
    variables = None

    kwargs = {
        'skip': True,
        'ext': '.yml',
        '_terms': ['foo.yml', 'bar.yml']
    }
    ret = L.run(terms, variables, **kwargs)
    assert ret == []

    kwargs = {
        'skip': False,
        'ext': '.yml',
        '_terms': ['foo.yml', 'bar.yml']
    }
    try:
        L.run(terms, variables, **kwargs)
    except Exception as err:
        assert str(err) == 'No file was found when using first_found.'
    else:
        assert False


# Generated at 2022-06-11 15:26:23.827938
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: 'None' is used to ensure it errors if paths is not optional
    #       'No file was found when using first_found'

    assert LookupModule().run(terms=['/path/to/file1']) == ['/path/to/file1']

    assert LookupModule().run(terms=['/path/to/file1'], paths=['/path/to']) == ['/path/to/file1']

    assert LookupModule().run(terms=['/path/to/file1', '/path/to/file2'], paths=['/path/to']) == ['/path/to/file1']


# Generated at 2022-06-11 15:26:35.360009
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test a valid file
    class TestLookupModule(LookupModule):
        def __init__(self):
            self.test_config = {
                'files': 'bar.txt',
                'paths': '/tmp'
            }
            self.path = None

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            self.path = '/tmp/bar.txt'

    lookup = TestLookupModule()
    result = lookup.run('foo', {})
    assert result == ['/tmp/bar.txt']
    assert lookup.path == result[0]

    # Test a missing file

# Generated at 2022-06-11 15:26:43.043729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # dict term
    lm = LookupModule()
    assert lm.run([{'file': 'f1', 'paths': 'p1'}], dict()) == ['p1/f1']
    # dict term with skip
    lm = LookupModule()
    assert lm.run([{'file': 'f1', 'paths': 'p1', 'skip': True}], dict()) == []
    # dict term with skip and missing file
    lm = LookupModule()
    assert lm.run([{'file': 'f2', 'paths': 'p1', 'skip': True}], dict()) == []
    # list term
    lm = LookupModule()

# Generated at 2022-06-11 15:27:03.530490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'files'
    l._basedir = '/path/to/place'
    l._templar = None
    assert l.run([['a'], {'files':['b']}, 'c']) == ['/path/to/place/a']
    assert l.run([['e'], {'files':['f']}, 'g'], False) == ['/path/to/place/f']
    assert l.run([['a','d'], {'files':['b','e']}, 'c'], False) == ['/path/to/place/b']
    assert l.run(['i', 'h', 'g']) == ['/path/to/place/i']

# Generated at 2022-06-11 15:27:14.354714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.first_found as module

    class LookupModule_run_Tests(unittest.TestCase):

        def setUp(self):
            self.lookup = module.LookupModule()

        def tearDown(self):
            del self.lookup

        def test_1(self):

            result = self.lookup.run([
                {
                    'files': 'file1.yml',
                    'paths': 'path1:path2'
                },
                {
                    'files': 'file2.yml',
                    'paths': 'path1:path2'
                }
            ], {}, module.LookupBase._Variables({}), {})
            self.assertEqual(result, [])


# Generated at 2022-06-11 15:27:15.394871
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: write

    pass

# Generated at 2022-06-11 15:27:27.209613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test without 'files' and 'paths' variables
    test_1_var = LookupModule()

# Generated at 2022-06-11 15:27:35.746586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    def test_assert(expected, actual):
        if expected != actual:
            raise AssertionError('Expected "%s", got "%s"' % (expected, actual))

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  host_list=[])
    variable_manager.set_inventory(inventory)
    context.CLIARGS = {'module_path': ''}
    LookupModule_obj = LookupModule()


# Generated at 2022-06-11 15:27:46.949448
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    from ansible.vars import VariableManager

    from io import BytesIO

    FINDME = b'''
    ---
    '''

    REF = b'''
    ---
    '''

    v = VaultLib(password=b'ANSIBLE')
    f = BytesIO(v.encrypt(FINDME))
    f.name = 'findme.yml'

    module = basic.AnsibleModule({}, {}, bypass_checks=True)
    templar = Templar(loader=None, variables=VariableManager())
    plugin = lookup_

# Generated at 2022-06-11 15:27:47.738253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test for run
    pass

# Generated at 2022-06-11 15:27:57.461975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    assert lu.run([{'files': 'foo, bar'}], {}, files='bar', paths='/tmp') == ['/tmp/bar'], "one file, one path"
    assert lu.run([{'files': 'foo, bar'}], {}, paths=['/tmp', '/tmp2'], files='bar') == ['/tmp/bar', '/tmp2/bar'], "one file, two path"
    assert lu.run([{'files': 'foo, bar'}], {}, paths=['/tmp', '/tmp2'], files='bar, baz') == ['/tmp/bar', '/tmp2/bar', '/tmp/baz', '/tmp2/baz'], "two files, two path"

# Generated at 2022-06-11 15:28:00.856865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = [{'files': 'foo.txt', 'paths': '/tmp/production, /tmp/staging'}]
    variables = {}
    assert l.run(terms, variables) == []


# Generated at 2022-06-11 15:28:09.864486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    # Test with relative paths
    # Test with one file relative to ansible_cwd
    # Test with one file relative to first relative path
    # Test with one file relative to play
    # Test with one file relative to include
    # Test with one file relative to role
    # Test with multiple files relative to ansible_cwd
    # Test with multiple files relative to first relative path
    # Test with multiple files relative to play
    # Test with multiple files relative to include
    # Test with multiple files relative to role
    # Test with one file relative to ansible_cwd and one file relative to play
    # Test with one file relative to ansible_cwd and one file relative to include
    # Test with one file relative to ansible_cwd and one file relative to role
    #

# Generated at 2022-06-11 15:28:42.246392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Create an instance
    instance = LookupModule()

    # Create a test fixture and configure it.
    test_fixture = { '_files': [] }
    instance.set_options(var_options=None, direct=test_fixture)

    # Create a test fixture for the first parameter of method run
    terms = None
    variables = None
    kwargs = {'paths': ['dir']}

    # Execute method run
    test_result = instance.run(terms, variables, **kwargs)

    # Check the result
    actual = test_result
    expected = []
    assert actual == expected, "Expected: %s, Actual: %s" % (expected, actual)

    # Create a test fixture for the first parameter of method run
    terms = ['file1']
    variables = None


# Generated at 2022-06-11 15:28:49.053005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(terms=['/tmp/file1.txt',
                               {'files': 'file2.txt',
                                'paths': '/tmp'},
                               'file3.txt',
                               {'files': 'file4.txt',
                                'paths': '/another_tmp'},
                               '/tmp/file5.txt'],
                         variables={})
    assert result == ['/tmp/file1.txt']

# Generated at 2022-06-11 15:29:01.214072
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l._templar = lambda: None
    l._templar.template = lambda s: s

    # Test the case of 'findme' being a string
    findme = '/path/to/foo.txt'
    total_search, skip = l._process_terms(findme, {}, {})
    assert total_search == [findme]
    assert skip is False

    # Test the case of 'findme' being a list
    findme = ['foo_1.txt', 'bar.txt', '/path/to/foo.txt']
    total_search, skip = l._process_terms(findme, {}, {})
    assert total_search == ['foo_1.txt', 'bar.txt', '/path/to/foo.txt']
    assert skip is False

    # Test the case

# Generated at 2022-06-11 15:29:08.536734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.plugins import lookup_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar

    class TestLookupBase(LookupBase):
        def __init__(self, loader, templar, **kwargs):
            LookupBase.__init__(self, loader, templar, **kwargs)

        def find_file_in_search_path(self, variables, searchpath, filename, ignore_missing=False):
            return "/fake_root/%s" % filename

    test_lookup = lookup_loader.get('first_found', loader=None, templar=Templar())
    test_lookup._lookup

# Generated at 2022-06-11 15:29:16.708014
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # define global variables
    global variables
    variables = {}

    # create instance of lookup module
    lookup_module = LookupModule()

    # define terms and kwargs to pass to LookupModule
    terms = ['{{ item }}', '{{ item2 }}']
    kwargs = {'item': '/path/to/file', 'item2': 'other_file'}

    # run method run of class LookupModule
    result = lookup_module.run(terms, variables, **kwargs)

    # define expected result
    expected_result = ['/path/to/file']

    # assert result
    assert result == expected_result

# Generated at 2022-06-11 15:29:22.399362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    data = {"album": "Rattle and Hum", "artist": "U2", "tracks": []}
    result = lookup_plugin.run(["/tmp/a.mp3", "/tmp/b.mp3"], data)
    assert result == ["/tmp/a.mp3"]



# Generated at 2022-06-11 15:29:32.699378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    this_dir = os.path.dirname(__file__)
    lookup = lookup_loader.get('first_found')
    lookup.set_loader(loader)

    # Test 1
    # First file found
    file_name = lookup.run(['files/first.cfg', 'files/second.cfg'], {})
    assert file_name == [os.path.join(this_dir, 'files/first.cfg')]

    # Test 2
    # Some files are not found
    file_name = lookup.run(['files/first.cfg', 'files/third.cfg'], {})

# Generated at 2022-06-11 15:29:43.758954
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    ###############################################################
    # Common code
    ###############################################################

    # Code taken from LookupBase
    environment = []

    loader = D

# Generated at 2022-06-11 15:29:54.411249
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def __init__(self):
        self._templar = '_templar'
        self._loader = '_loader'
        self._basedir = '_basedir'

    def set_options(self):
        pass

    def find_file_in_search_path(self):
        pass

    lu = LookupModule()

    import base64
    b64_findme_files = b'WyJmYSIsImYiLCJmYyIsImZkIl0='

    # some data
    vars = dict(
        JINJA2_BYTES=b64_findme_files,
        JINJA2_STRING=base64.b64decode(b64_findme_files)
    )


# Generated at 2022-06-11 15:29:57.097652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['foo'], variables=dict()) == ['foo']

# Generated at 2022-06-11 15:30:59.217241
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: not started yet
    # TODO: dict mode not supported yet
    # TODO: more test cases

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # 1. prepare
    # 1.1 prepare class
    instance = LookupModule()

    # 1.2 prepare terms

# Generated at 2022-06-11 15:31:09.230848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule._subdir = 'files'
    # AnsibleLookupError: No file was found when using first_found.
    with pytest.raises(AnsibleLookupError) as e:
        LookupModule().run(terms=['fake_file1.txt'], variables={})
    assert 'AnsibleLookupError: No file was found when using first_found.' in str(e)
    # NOTE: None is returned but wrapped in a list
    assert LookupModule().run(terms=['fake_file1.txt', 'fake_file2.txt'], variables={}) == [None, None]

    # NOTE: only one of the following test cases should be uncommented at any one time
    # NOTE: failure of any of the following tests may be due to subdir not being set
    # to 'files' for the lookup plugin

# Generated at 2022-06-11 15:31:20.844386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes, to_text

    # create a temp dir & file
    test_dir = to_text(tempfile.mkdtemp(), errors='surrogate_or_strict')
    file_name = 'test.yml'
    file_path = os.path.join(test_dir, file_name)
    with open(file_path, 'wb') as f:
        f.write(b'#!/bin/bash/\n')

    # add temp dir to module utils path
    sys.path.append(test_dir)

    # create an instance of LookupModule
    lookup_obj = LookupModule()
    orig_find_file_in_search_path = lookup_obj.find_file_in_

# Generated at 2022-06-11 15:31:28.019986
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # tests that terms is a Sequence
    def check_sequence(terms):
        terms_returned = terms
        terms_type = type(terms)
        lookup_module = LookupModule()
        if not isinstance(terms, Sequence):
            terms_returned = [terms_type]
        return lookup_module.run(terms_returned, {})

    # tests that term is a string
    def check_string(term):
        term_returned = term
        term_type = type(term)
        lookup_module = LookupModule()
        if not isinstance(term, string_types):
            term_returned = term_type
        try:
            lookup_module.run(term_returned, {})
        except AnsibleLookupError as e:
            return e.message
        return None


# Generated at 2022-06-11 15:31:37.056311
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: During tests several noticed issues appeared, not critical but should be fixed in future.
    # 1. handling of multiple search paths in 'dict' or 'list of paths' terms is not tested.
    # 2. handling of multiple file names in 'dict' or 'list of file names' terms is not tested.

    # 1. test with missing 'params' - should raise a LookupError
    params = {}
    lm = LookupModule()
    try:
        lm.run(params, {})
    except LookupError:
        pass

    # 2. test with invalid 'params'
    params = ['invalid']
    lm = LookupModule()
    try:
        lm.run(params, {})
    except LookupError:
        pass

    # 3. test with missing 'term' - should raise a LookupError

# Generated at 2022-06-11 15:31:47.553462
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.utils.unsafe_proxy
    ansible.utils.unsafe_proxy.AnsibleUnsafeText = str
    lookup = LookupModule()

    # No files found
    # skip: False
    args = ([{
        'files': 'f1',
        'paths': '/p1',
    }], {}, {})
    assert not lookup.run(*args)

    # skip: True
    args = ([{
        'files': 'f1',
        'paths': '/p1',
        'skip': True,
    }], {}, {})
    assert lookup.run(*args) == []

    # File found
    # skip: False
    lookup._loader.path_exists = lambda path: path == '/p1/f1'

# Generated at 2022-06-11 15:31:55.285880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mocks
    class class_return_value():
        def __init__(self):
            self.subdir = 'subdir'
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            if fn == 'foo':
                return 'foo'
            else:
                return None
    class_return_value_instance = class_return_value()

    # tests
    test_terms = [
        'foo'
    ]
    test_variables = 'test variables'
    ret = LookupModule.run(LookupModule, test_terms, test_variables)
    assert ret == ['foo']



# Generated at 2022-06-11 15:32:03.512892
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # variables used for test
    test_variables = {}
    test_variables['ansible_os_family'] = 'Debian'

    # tests for method run
    # first test
    terms_first = [
        {
            "paths": "/path/to/foo.txt",
            "files": "bar.txt",
        },
        "path/to/biz.txt"
    ]
    test_kwargs_first = {
        "skip": False
    }
    test_ret_first = [
        "/path/to/foo.txt/bar.txt"
    ]

    # second test

# Generated at 2022-06-11 15:32:14.062444
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # testing a list of paths and files with skip=False
    terms = [
        {'paths': '/path1', 'files': 'file1.txt'},
        {'paths': '/path2', 'files': 'file2.txt'},
        {'paths': '/path3', 'files': 'file3.txt'},
        {'paths': '/path4', 'files': 'file4.txt'},
    ]

    # This test mocks the method find_file_in_search_path to always return None
    # It asserts that the method run returns [] with skip = False
    with mock.patch.object(lookup, 'find_file_in_search_path', return_value=None):
        assert [] == lookup.run(terms, dict(), skip=False)

    #

# Generated at 2022-06-11 15:32:25.205076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'tests/unit/testing/data/lookup_plugins/first_found'
    l._templar = DummyTemplar()