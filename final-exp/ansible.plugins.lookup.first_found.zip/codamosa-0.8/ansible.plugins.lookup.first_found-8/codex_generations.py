

# Generated at 2022-06-11 15:22:32.249467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    # One file exists
    l = LookupModule()
    l.basedir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../..'))
    l.check_conditional_dependencies()
    # file exists
    if PY3:
        assert l.run([to_bytes(os.path.realpath(__file__))]) == [to_bytes(os.path.realpath(__file__))]
    else:
        assert l.run([os.path.realpath(__file__)]) == [os.path.realpath(__file__)]

    # No file exists
    non_existing_file = os.path.real

# Generated at 2022-06-11 15:22:40.999588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options = {'app_name': 'AppOne'}, direct = { 'files': ['file1.txt', 'file2.txt'] })
    lookup._subdir = 'files/'
    result = lookup.run([{}])
    assert result == ['/files/file1.txt']

    lookup = LookupModule()
    lookup.set_options(var_options = {'app_name': 'AppTwo'}, direct = { 'files': ['file3.txt', 'file4.txt'] })
    lookup._subdir = 'files/'
    result = lookup.run([{}])
    assert result == ['/files/file3.txt']

    lookup = LookupModule()

# Generated at 2022-06-11 15:22:43.020158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write more tests
    pass

# Generated at 2022-06-11 15:22:54.131222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.lookup.first_found import LookupModule

    class VarManager:
        def get_vars(self, loader, path, entities, cache=True):
            return {'test': 'test'}

    class DataLoader:
        def __init__(self, basedir):
            self.basedir = basedir

        def path_dwim(self, filename):
            return ''

        def _get_cache_prefix(self):
            return 'test/test'

    class PlayContext:
        def __init__(self):
            self.basedir = ''
            self.loader = DataLoader('test')
            self.variable_manager = VarManager()


# Generated at 2022-06-11 15:23:03.297459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    class LookupModule_test(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._subdir = kwargs.get('subdir')
            super(LookupModule, self).__init__(loader=loader, templar=templar, **kwargs)

        def run(self, terms, variables, **kwargs):
            return super(LookupModule_test, self).run(terms, variables, **kwargs)
    #
    lookup_plugin = LookupModule_test(subdir='roles/test/library')
    #
    class Dummy(object):
        pass
    #
    variables = Dummy()
    variables.hostvars = {}
    variables.hostvars['localhost'] = {}
    variables.hostvars

# Generated at 2022-06-11 15:23:11.833655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'skip': True})
    assert l.run(["file1.txt"], {}) == []

    l = LookupModule()
    l.set_options({'skip': False})
    try:
        l.run(["file1.txt"], {})
        assert False
    except Exception as e:
        assert str(e) == "No file was found when using first_found."

    l = LookupModule()
    l.set_options({'skip': True})
    l.find_file_in_search_path = lambda *args: "/etc/fstab"
    assert l.run(["file1.txt"], {}) == ["/etc/fstab"]

# Generated at 2022-06-11 15:23:19.716339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    ibl = pytest.importorskip("ansible.utils.lookup_plugins.ibm_zos_utils.ibm_zos_lookup_base")
    lm = ibl.LookupModule()

    assert lm

    # TODO: capture output of run to do test
    #run_ret = lm.run("xx")
    #print("Returned: %s" % run_ret)

# Generated at 2022-06-11 15:23:23.264449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([{'files': u'test.txt,test2.txt', 'paths': u'bar/foo.txt'}],{}) == ['bar/foo.txt']

# Generated at 2022-06-11 15:23:32.164812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
        "var_a": "A",
        "var_b": "B"
    }
    # Test with list as terms, and dictionary as kwargs
    terms = [
        "{{ var_a }}_file.txt",
        "{{ var_b }}_file.txt",
        {"files": "var_c_file.txt"},
        "var_d_file.txt",
        {"files": "var_e_file.txt"}
    ]
    kwargs = {
        "files": "{{ var_f }}_file.txt"
    }
    obj = LookupModule()
    total_search, _ = obj._process_terms(terms, variables, kwargs)

# Generated at 2022-06-11 15:23:43.915312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # First test: all ok, list of strings
    #
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._basedir = '/'
    lookup._templar = []

    # mock the function find_file_in_search_path to return a path and test it
    def mock_find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        return '/tmp'
    lookup.find_file_in_search_path = mock_find_file_in_search_path

    #
    # First test: all ok, list of strings
    #
    terms = ['/path/file1', 'file2', '/path/file3']
    variables = None
    result = lookup.run(terms, variables)

# Generated at 2022-06-11 15:23:59.878930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    class Args:
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 1
            self.become = False
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None

# Generated at 2022-06-11 15:24:10.961144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    # Namespace(case_sensitive=True, list_files=False, path='/abc')

    terms = ['foo.conf', {'paths': 'bar'}]
    kwargs = {'_ansible_module_name': 'foo', '_ansible_module_internal_path': '/playbook/path'}
    variables = {'inventory_hostname': 'localhost'}
    # See: https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/test/test_module_common.py#L93
    # See: https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/basic.py#L5
    # See: https://github.

# Generated at 2022-06-11 15:24:17.218993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Make sure the module is not broken without params
    lookup.run(None, None)

    paths = [
        'path/to/file1',
        'path/to/file2',
    ]

    files = [
        'file1',
        'file2',
    ]

    params = {
        'files': files,
        'paths': paths,
    }

    # Make sure the module is not broken with params
    lookup.run(params, None)

    # Make sure the module is not broken with list of terms
    terms = [
        'path/to/file1',
        'path/to/file2',
    ]

    lookup.run(terms, None)

    # test with a list of files
    lookup.run(files, None)

    # test with a

# Generated at 2022-06-11 15:24:24.777883
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    fmt = '%s:%s'
    args = [list, dict, str]
    for arg in args:

        input = {
            'files': [],
            'paths': [],
        }

        if arg is list:
            input['files'] = ['file1', 'file2']
        else:
            input = {
                'files': 'file1,file2',
                'paths': ',:;',
            }

        if arg is str:
            input = ','.join(map(fmt, *input.items()))

        # run without subdir
        lu = LookupModule()
        lu._subdir = None
        assert [ 'file1' ] == lu.run(input, dict())

        # run with subdir
        lu._subdir = 'my_path'


# Generated at 2022-06-11 15:24:35.011151
# Unit test for method run of class LookupModule
def test_LookupModule_run():  
	
	# Tests for valid term
	obj = LookupModule()
	obj.set_options({'paths': ['/path/to'], 'files': ['foo.txt', 'bar.txt', 'biz.txt']})
	terms = obj.run(terms=['foo.txt'], variables={})
	assert terms == ['/path/to/foo.txt']

	# Tests for valid term
	obj = LookupModule()
	obj.set_options({'paths': ['/path/to'], 'files': ['foo.txt', 'bar.txt', 'biz.txt']})
	terms = obj.run(terms=['foo.txt'], variables={})
	assert terms == ['/path/to/foo.txt']

	# Tests for invalid term
	obj = LookupModule()

# Generated at 2022-06-11 15:24:46.054444
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # define test case
    import unittest

    # TODO: make this a real test as it's totally broken
    class MyTestCase(unittest.TestCase):
        def test_run(self):
            self.assertTrue(False) # ensure test fails until it is fixed
            #constants
            CURRENT_DIR = "current_dir"
            HOME_DIR = "/home/user"
            OTHER_DIR = "/other/dir"


            #TODO: doesn't work needs more work.
            # set up search paths
            temp_plugin = LookupModule()
            #case 1
            params = {}
            total_search, skip = temp_plugin._process_terms(params, {})
            self.assertEqual(total_search, [])
            self.assertEqual(skip, False)


    # call

# Generated at 2022-06-11 15:24:57.645421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ first_found: Make sure that run works correctly
    """
    # Make sure that run works correctly
    import os
    from ansible.plugins.loader import LookupModule

    plugin = LookupModule('first_found')
    plugin._templar = None

    assert plugin.run([], {}, files='hi,hey', skip=True) == [], 'run() should return the correct failure value'
    assert plugin.run([], {}, files='hi,hey', skip=False) == [], 'run() should return the correct failure value'
    assert plugin.run([], {}, paths='/tmp,:hey:', skip=True) == [], 'run() should return the correct failure value'

# Generated at 2022-06-11 15:25:04.636305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ls = LookupModule()
    ls.set_options(direct=dict(paths=['/var/tmp'], skip=True))
    assert ls.run(['/etc/hosts']) == [], 'missing file should return []'
    assert ls.run(['/etc/hosts']) == [] and ls.run(['hosts']) == [], 'missing file should return []'
    assert ls.run(['hosts', 'hosts_2']) == [], 'missing file should return []'
    assert ls.run(['/etc/hosts', 'README']) == [], 'missing file should return []'
    assert ls.run(['hosts', '/etc/hosts', 'README']) == [], 'missing file should return []'

# Generated at 2022-06-11 15:25:16.770963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock class vars
    class LookupModuleTest(LookupModule):
        SEARCH_PATH_SEPARATOR = ':'
        SEARCH_PATH_VARIABLE_NAME = 'SEARCH_PATH'

        def find_file_in_search_path(self, variables, dir_name, file_name, ignore_missing=False):
            if dir_name == 'files' and file_name == 'A.txt':
                return 'A.txt'
            elif dir_name == 'files' and file_name == 'B.txt':
                return 'B.txt'
            else:
                return None

    # run test
    lookup_module = LookupModuleTest()
    assert lookup_module.run([{'files': 'A.txt'}], {}) == ['A.txt']
    assert lookup_module.run

# Generated at 2022-06-11 15:25:26.453066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: no test is currently done on the 'variable' params
    # we only check the list of files and/or paths

    lookup = LookupModule()

    # basic list of files
    files = ['file1', 'file2', 'file3']
    # a file that exists
    path = lookup.find_file_in_search_path(None, 'files', files[0], ignore_missing=True)
    assert path is not None

    # basic list of paths
    paths = ['/tmp', '/usr/tmp']
    # look for files in paths that do not exist
    path = lookup.find_file_in_search_path(None, 'files', 'junk', paths, ignore_missing=True)
    assert path is None

    # empty list of files or paths
    # should not find anything, but not raise
    terms

# Generated at 2022-06-11 15:25:34.215724
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False

# Generated at 2022-06-11 15:25:39.369437
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize the lookup module
    lookupModule = LookupModule()

    # Initialize the variables
    variables = {}

    files = ['/path/to/foo.txt', 'bar.txt', 'biz.txt']

    paths = []

    # Call the lookup module run function
    result = lookupModule.run(files, variables, paths=paths, skip=True)

    # Check the expected result
    assert result == []

# Generated at 2022-06-11 15:25:49.648794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: *Had* to use a 'global skip' as found that the inner
    # dict usage has no concept of global, so the inner skips
    # are ignored, which is a problem if you only want to skip
    # certain files...

    fake_result = ['some/file/path']
    def fake_find_file_in_search_path(*args, **kwargs):
        if args[-1] in fake_result:
            return 'some/file/path'

    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = fake_find_file_in_search_path

    test_dict = {'files': ['foo.txt'], 'paths': ['/path/to']}

    # with dict

# Generated at 2022-06-11 15:26:01.642753
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms = []
    variables = {}
    kwargs = {}
    results = lookup_module.run(terms, variables, **kwargs)
    assert len(results) == 0
    assert lookup_module._subdir == "files"

    terms = 'something'
    results = lookup_module.run(terms, variables, **kwargs)
    assert results == ['something']
    assert lookup_module._subdir == "files"

    terms = ['something', 'something else']
    results = lookup_module.run(terms, variables, **kwargs)
    assert results == ['something', 'something else']
    assert lookup_module._subdir == "files"

    terms = [{'paths':'a'}]
    results = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-11 15:26:03.536488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['first', 'second', 'third'], variables={}) == ['first']

# Generated at 2022-06-11 15:26:16.404096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    verify the result of run method
    """
    lm = LookupModule()
    lm._subdir = 'files'
    lm._templar = 'templar'

    # test the case nothing is found
    total_search = ['file1', 'file2']
    lm.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None
    lm.run_errors = ['AnsibleLookupError']
    assert lm.run(['str'], 'variables') == lm.run_errors

    # test the case something is found
    total_search = ['file1', 'file2']
    lm.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: 'path_found'

# Generated at 2022-06-11 15:26:24.558514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lkp = LookupModule()
    test_terms = ["{{ test1 }}", {'files': "{{ test2 }}", 'paths': "{{ test3 }}"}, "{{ test4 }}"]
    test_variables = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3', 'test4': 'test4'}
    assert lkp.run(terms=test_terms, variables=test_variables) == ["test1", "test2", "test3", "test4"]

    test_terms = ["{{ test1 }}", {'files': "{{ test2 }}", 'paths': "{{ test3 }}", 'skip': True}, "{{ test4 }}"]

# Generated at 2022-06-11 15:26:36.103569
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # File in inventory file
    x = LookupModule('')
    terms = [['./lookup_plugins/test_data/foo.txt'],
             ['./lookup_plugins/test_data/bar/bar.txt'],
             {'paths': './lookup_plugins/test_data/bar'},
             'bar.txt',
             {'paths': '.'}
             ]
    x._subdir = './lookup_plugins'
    x.run(terms, '')

    # File in 'relative' path to task
    terms = ['foo.txt',
             'bar/bar.txt',
             {'paths': 'bar'},
             'bar.txt',
             {'paths': '.'}
             ]

# Generated at 2022-06-11 15:26:47.230888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    def mock_template(temp, variables=None, fail_on_undefined=True, overrides=None, convert_bare=True, convert_json=False, fail_on_undefined_errors=False, filters=None, tests=None, context=None, loader=None):
        return temp


# Generated at 2022-06-11 15:26:47.985304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:27:13.595576
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin = LookupModule()

    # Test valid calls
    assert plugin.run(['a', 'b'], {}) == []

    assert plugin.run(['a', 'b'], {}, files=['a', 'b'], paths=['/etc/ansible']) == []

    # Test invalid calls
    try:
        plugin.run(['a', 'b'], {}, paths=['/etc/ansible'])
        assert False, "If a list of files isn't passed, an error should be raised"
    except AnsibleLookupError:
        assert True

    try:
        plugin.run(['a', 'b'], {}, files=['a', 'b'])
        assert False, "If a list of paths isn't passed, an error should be raised"
    except AnsibleLookupError:
        assert True

# Generated at 2022-06-11 15:27:16.115665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1
# TODO: Add unit test
# def test_LookupModule_run(self):
#   assert 1 == 1

# Generated at 2022-06-11 15:27:28.262507
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # get an instance of LookupModule
    lookup = LookupModule()
    # assign LookupModule._subdir explicitly as LookupModule.run()
    # will read this private class attribute if set
    lookup._subdir = 'files'

    # test that first_found lookup fails with empty or wrong parameter 'terms'
    try:
        lookup.run(terms=[], variables={}, errors='ignore')
        assert False, "first_found lookup should have failed with empty list of files"
    except AnsibleLookupError:
        pass

    try:
        lookup.run(terms={}, variables={})
        assert False, "first_found lookup should have failed with empty list of files"
    except AnsibleLookupError:
        pass


# Generated at 2022-06-11 15:27:33.495973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test actual lookup
    total_search = []
    for srch in total_search:
        assert LookupModule().run(terms=srch, variables={})[0] == 'everything'
    # test validation and lookup skipping
    for srch in total_search:
        assert LookupModule().run(terms=srch, variables={}) == []


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:27:40.553760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    method run of class LookupModule

    :return:
    """
    from ansible.plugins.loader import lookup_loader
    # print(lookup_loader.get('first_found'))

    terms = ['file.txt']
    variables = {}
    lookup_first_found = lookup_loader.get('first_found')
    obj = lookup_first_found()
    results = obj.run(terms, variables)
    print(results)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-11 15:27:50.182323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    assert lookup.run(['file1', 'file2'], {}) == ['file1']
    assert lookup.run(['file1', 'file2'], {}, skip=True) == []
    assert lookup.run(['file1', 'file2'], {}, files=['file1'], paths=['/path']) == ['/path/file1']
    assert lookup.run(['file1', 'file2'], {}, files=['file1'], paths=['/path'], skip=True) == []
    assert lookup.run(['file1', 'file2'], {}, paths=['/path']) == ['/path/file1', '/path/file2']

# Generated at 2022-06-11 15:27:59.275326
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule
    # Instance of LookupModule
    lookup_instance = LookupModule()

    # Directories list
    directories = ['share', 'doc']

    search_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib', 'ansible', 'modules', 'Network')

    # Directories joined with the search_path
    joined_directories = [os.path.join(search_path, directory) for directory in directories]

    # Expected returned value
    expected_returned_value = [os.path.join(joined_directories[0], 'network_meta.yml')]

    # Parameter value
    param_value = ['network_meta.yml']

    # Returned value
    returned

# Generated at 2022-06-11 15:28:09.041949
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test module has passed in the 'expected' methods from the
    # class asked for and these return a 'mocked' class instance
    # This method will be tested separately.
    def get_module_mock(cls):
        # test module has passed in the 'expected' methods from the
        # class asked for and these return a 'mocked' class instance
        # This method will be tested separately.
        def get_class_mock(name, methods):
            class Mock(name):
                def __init__(self, *args, **kwargs):
                    self.return_values = []
                    self.mocked_methods = methods

                def __getattr__(self, name):
                    if name not in self.mocked_methods:
                        raise AttributeError("Attribute %s not mocked" % name)


# Generated at 2022-06-11 15:28:20.597673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'files': ['test1'], 'paths': ['/1', '/2']},
        {'files': ['test2'], 'paths': ['/3', '/4']},
        {'files': ['test3'], 'paths': ['/5', '/6']},
    ]
    variables = {}
    kwargs = {}
    lookup = LookupModule()
    total_search, skip = lookup._process_terms(terms, variables, kwargs)
    #expected: /1/test1, /2/test1, /3/test2, /4/test2, /5/test3, /6/test3

# Generated at 2022-06-11 15:28:27.579175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # def run(self, terms, variables, **kwargs):

    from ansible.plugins.loader import lookup_loader
    lookup_plugin = lookup_loader.get('first_found')

    # Test with a plain string as input
    terms = 'foo.txt'
    variables = dict()
    kwargs = dict()
    result = lookup_plugin.run(terms, variables, **kwargs)
    assert result == []

    # Test with a single element list as input
    terms = ['foo.txt']
    variables = dict()
    kwargs = dict()
    result = lookup_plugin.run(terms, variables, **kwargs)
    assert result == []

    # Test with a list as input
    terms = ['foo.txt', 'bar.txt']
    variables = dict()
    kwargs = dict()
    result

# Generated at 2022-06-11 15:29:06.624321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from pprint import pprint

    print("\nTesting")
    print("-------")

    mock_variables = {'foo': 'bar'}
    mock_kwargs = {'_filters': ['to_nice_json']}

    l = LookupModule()
    l.set_loader({})

    # create a class to mock the template method since it calls a templar and we don't want that
    class MockTemplar(object):
        def template(self, y):
            return y

    l._templar = MockTemplar()


# Generated at 2022-06-11 15:29:16.530928
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, variables=None)
    variable_manager._extra_vars = {}  # TODO: fix this in Ansible code
    templar = Templar(loader=None, variables=variable_manager)

    lookup_plugin = LookupModule()
    lookup_plugin._load_name = "first_found"
    lookup_plugin._templar = templar

    # Test by mocking the search_path method and validating the result
    results = []
    func = lambda this, variables, subdir, fn: results.append(fn) or None

# Generated at 2022-06-11 15:29:23.070246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[
        {'files': 'foo', 'paths': ''},
        {'files': 'bar', 'paths': 'path1'},
        {'files': 'foo', 'paths': ''},
        {'files': 'foo', 'paths': ''}
    ]]
    variables = {}
    result = LookupModule().run(terms, variables)
    assert result == ['bar']

# Generated at 2022-06-11 15:29:33.169528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Valid input
    total_search, skip = lookup._process_terms(['/test_file.txt'], [], [])
    assert len(total_search) == 1
    assert skip == False

    # Valid input
    total_search, skip = lookup._process_terms(['/test_file1.txt', '/test_file2.txt'], [], [])
    assert len(total_search) == 2
    assert skip == False

    # Valid input
    total_search, skip = lookup._process_terms([{'files': '/test_file1.txt,/test_file2.txt', 'paths':'/test_path1.txt:/test_path2.txt'}], [], [])
    assert len(total_search) == 4
    assert skip == False

    # Valid

# Generated at 2022-06-11 15:29:44.411522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class ModMock(object):
        def __init__(self, return_value):
            self._return_value = return_value

        def get_option(self, option):
            return self._return_value

        def template(self, value):
            return value

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return self._return_value

    mod_mock = ModMock(object())

    lookup_mod = LookupModule(loader=None, templar=None, **dict(basedir='/', runner_basedir='/'))
    lookup_mod._templar = mod_mock
    lookup_mod.set_options = mod_mock.get_option

    # term is mapping

# Generated at 2022-06-11 15:29:54.534778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_class = LookupModule()
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    lookup_class._templar = lambda x: AnsibleUnsafeText(x).unicode()
    # Testing multiple string terms
    terms = ['/etc/file1', '/etc/file_that_doesnt_exist', '/etc/file2']
    result = lookup_class.run(terms, dict())
    assert len(result) == 1
    assert isinstance(result[0], string_types)
    assert result[0] == '/etc/file1'
    #Testing multiple lists of strings term

# Generated at 2022-06-11 15:30:06.655470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    def _mock_loader_all(self, path, **kwargs): # pylint: disable=unused-argument
        return 'path/to/foo.txt'
    def _mock_loader_one(self, path, **kwargs): # pylint: disable=unused-argument
        if path == 'path/to/foo.txt':
            return 'path/to/foo.txt'
        elif path == 'path/to/biz.txt':
            return 'path/to/biz.txt'
        return None

    lookup_module = LookupModule()

    # When one of the files is found in the list of files and path 
    lookup_module.set_loader(loader=_mock_loader_one)

# Generated at 2022-06-11 15:30:08.876941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .fixtures.lookup_tests_first_found_run import TestLookupModule_run
    TestLookupModule_run()


# Generated at 2022-06-11 15:30:12.621079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def input_mock(terms, variables, **kwargs):
        lookup = LookupModule()
        return lookup.run(terms, variables, **kwargs)

    output = input_mock(["first"], None)
    assert isinstance(output, list)
    assert len(output) == 1
    assert output[0] == "first"



# Generated at 2022-06-11 15:30:23.779173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 15:31:32.681230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # No files found
    terms = [
        {
            'files': 'a, b',
            'paths': 'c, d',
        },
        {
            'files': ['a', 'b'],
            'paths': ['c', 'd'],
        },
        {
            'paths': ['c', 'd'],
            'files': ['a', 'b'],
        },
        {
            'paths': ['c', 'd'],
        },
        'c/a, d/a',
        'c/a',
        [
            'a/a',
            'b/a',
        ],
        'a/a',
    ]

# Generated at 2022-06-11 15:31:34.260953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        LookupModule(None, None).run(None, None)
    except:
        pass
    return True

# Generated at 2022-06-11 15:31:41.555924
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    path = "/tmp/playbooktmp"

    os.makedirs(path)
    os.system("touch %s/foo.txt" % path)
    os.system("touch %s/bar.txt" % path)

    terms = ['foo' , 'bar', dict(files=['foo', 'bar'], paths=[path])]

    files = ["/tmp/playbooktmp/foo.txt", "/tmp/playbooktmp/bar.txt"]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, dict())

    assert result == files

# Generated at 2022-06-11 15:31:51.528954
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock module_utils and templar
    class FP(object):
        def __init__(self, filename, mode='r'):
            self.filename = filename
        def close(self):
            pass
    class Templar(object):
        def template(self, filename):
            return filename
    class ModuleUtils(object):
        def _search_lookup_plugins(self, *args, **kwargs):
            return FP("any_file")
        def _search_path(self, *args, **kwargs):
            return "any_path"
        def _loader(self, *args, **kwargs):
            return FP("any_file")

    # mock the looker-upper
    class Lookup(object):
        def __init__(self, *args, **kwargs):
            pass

# Generated at 2022-06-11 15:32:00.615619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    lookup._templar.template = lambda x: x
    lookup.find_file_in_search_path = lambda x,y,z,w: z if z != "foo.txt" else None

    # Testing first use case: list of filenames as terms
    _got = lookup.run(["foo.txt", "bar.txt", "biz.txt"], {})
    try:
        assert _got == ['bar.txt']
    except AssertionError:
        # Failure case: Exception is raised
        raise AssertionError(_got)

    # Testing second use case: list of dicts as terms

# Generated at 2022-06-11 15:32:10.945808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic test. Create instance.
    #
    # Note that 'first_found' is the first entry in plugins/lookup/__init__.py

    lookup_inst = LookupModule()

    # create fake variables
    variables = {
        'ansible_virtualization_type' : 'foo',
        'ansible_os_family' : 'bar',
        }

    # create fake paths
    searchpath = [
        os.path.join('/tmp/test_lu', 'files'),
        ]

    # define tests

# Generated at 2022-06-11 15:32:17.962304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()
    lookup.set_loader(DataLoader())

    # Test1, bare minimum
    terms = ['foo']
    assert ['/test/files/foo'] == lookup.run(terms, {})

    # Test2, path is ignored and other files not found
    terms = ['foo2']
    assert ['/test/files/foo'] == lookup.run(terms, {})

    # Test3, path is ignored and other files found
    terms = ['foo', 'bar']
    assert ['/test/bar'] == lookup.run(terms, {})

    # Test4, path is ignored and other files found, with a relative path
    terms = ['foo', '../bar']