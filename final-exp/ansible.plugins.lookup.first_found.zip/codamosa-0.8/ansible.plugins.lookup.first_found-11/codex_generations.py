

# Generated at 2022-06-11 15:22:32.906366
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import shutil
    import tempfile

    # generate a temporary directory and files for testing.
    lookup_dir = tempfile.mkdtemp()
    lookup_file = tempfile.NamedTemporaryFile(dir=lookup_dir, delete=False)
    lookup_file.close()

    # prep parameters.
    terms = [lookup_file.name]
    variables = {}
    kwargs = {}

    # run the test.
    lookup_module = LookupModule()
    result = lookup_module.run(terms=terms, variables=variables, **kwargs)

    # cleanup the temp data
    os.remove(lookup_file.name)
    shutil.rmtree(lookup_dir)

    # verify the result
    assert len(result) == 1

# Generated at 2022-06-11 15:22:41.320595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def find_file_in_search_path(self, variables, subdir, filename, ignore_missing=False):
        if subdir == 'files':
            if filename in ['foo.txt', 'bar.txt', 'biz.txt']:
                return filename
        return None

    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup.find_file_in_search_path = find_file_in_search_path

    # Set up test environment
    # Dictionary of tests:
    # Desc: Short description of the test
    # Input: Input to the lookup
    # Output: Expected output from the lookup

# Generated at 2022-06-11 15:22:52.862704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO

    # no search terms
    lookup = LookupModule()
    assert lookup.run([], {}, skip=True) == []
    try:
        lookup.run([], {})
        assert False, "Exception expected"
    except AnsibleLookupError as e:
        assert str(e) == "No file was found when using first_found."

    # no search terms, with bad file
    lookup = LookupModule()
    assert lookup.run([], {}, skip=True) == []
    try:
        lookup.run([], {})
        assert False, "Exception expected"
    except AnsibleLookupError as e:
        assert str(e) == "No file was found when using first_found."

    # with terms and bad file
    lookup = LookupModule()
   

# Generated at 2022-06-11 15:23:02.680987
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.first_found import LookupModule as LookupModuleFirstFound
    lookup_module_first_found = LookupModuleFirstFound()

    # find_file_in_search_path method return value
    find_file_in_search_path_ret = None
    # find_file_in_search_path method call count
    find_file_in_search_path_called = 0
    def find_file_in_search_path_mock(variables, subdir, fn, ignore_missing=True):

        global find_file_in_search_path_called
        find_file_in_search_path_called += 1

        return find_file_in_search_path_ret

    # _templar.template method return value
    template_ret = None
    # _templar.

# Generated at 2022-06-11 15:23:12.334678
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:23:25.135973
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class mock_self():
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return None

        def set_options(self, var_options=None, direct=None):
            pass

        def get_option(self, option):
            return None

    lm = LookupModule()
    lm.set_options = mock_self.set_options
    lm.get_option = mock_self.get_option
    lm.find_file_in_search_path = mock_self.find_file_in_search_path

    # test _process_terms with a single path and file
    total_search, skip = lm._process_terms(['/path/to/foo.txt'], dict(), dict())

# Generated at 2022-06-11 15:23:34.480053
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.template import Templar

    my_lookup = LookupModule()

    my_lookup._subdir = 'files' # NOTE: normally set by task executor (see role/play)

    # NOTE: templates normally prepared by task executor (see role/play)
    my_templar = Templar(loader=None, variables={'foo': 'bar.txt', 'inventory_hostname': 'server1.site.com'})

    # TODO: not sure test coverage is correct, it seems to test 'dict' param only
    # this should test all combinations, but at least shows how to use it.

    # test 1: simple dict

# Generated at 2022-06-11 15:23:45.582784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run with minimal valid argument set - the list of terms is empty
    #
    # This shouldn't raise an exception

    terms = []
    variables = {}

    lookup_plugin = LookupModule()
    lookup_plugin.run(terms, variables)

    # Test run with a list of terms that contains an empty string
    #
    # This also shouldn't raise an exception

    terms = [""]
    variables = {}

    lookup_plugin = LookupModule()
    lookup_plugin.run(terms, variables)

    # Test run with a list of terms that contains a string with a newline
    #
    # This also shouldn't raise an exception

    terms = ["\n"]
    variables = {}

    lookup_plugin = LookupModule()
    lookup_plugin.run(terms, variables)

    # Test run with a valid term
    #

# Generated at 2022-06-11 15:23:57.719029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up class to test
    lookup_module = LookupModule()

    # Mock the following required parameters
    terms = ['first_found.py']
    variables = {'ansible_env': {'HOME': '/Users/seth'}, 'ansible_version': {'full': 'v2.11.0'}}
    # Mock the ansible lookup plugin environment variables
    os.environ['ANSIBLE_CONFIG'] = '/Users/seth/ansible.cfg'
    os.environ['ANSIBLE_CONFIG_DATA'] = '{}'

    # Test the run method, by attempting to find the module itself
    # NOTE: This test is dependent on the current working directory being the plugin directory/
    # Since this is not a good assumption, it will be removed in a future commit.

# Generated at 2022-06-11 15:24:05.262945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup the test
    # Note that the class is used directly since we don't want to look at the configuration file
    obj_LookupModule = LookupModule()
    terms = ['default.conf', {'files': 'etc.conf', 'paths': '/home/user/ansible'}, 'ssh/config']
    variables = {}
    kwargs = {}
    # Verify the result
    assert ["/home/user/ansible/etc.conf"] == obj_LookupModule.run(terms, variables, **kwargs)

# Generated at 2022-06-11 15:24:19.353686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/files/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Basic test
    lookup_obj = LookupModule()
    lookup_obj._templar = VariableManager.set_default_templar(variable_manager)
    lookup_obj._loader = loader
    lookup_obj._inventory = inventory
    terms = [
      '/path/to/first.txt',
      'simple.txt',
      '/path/to/second.txt',
    ]

# Generated at 2022-06-11 15:24:31.271848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.first_found as first_found
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader, action_loader

    class Playbook():
        def __init__(self):
            self.name = 'host'

        def get_variable_manager(self):
            return None

        def get_loader(self):
            return loader

    class TestLookupModule(first_found.LookupModule):

        def __init__(self, loader, templar, **kwargs):
            self.subdir

# Generated at 2022-06-11 15:24:32.643935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert type(lookup) == LookupModule

# Generated at 2022-06-11 15:24:33.390752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: add unit test!
    pass

# Generated at 2022-06-11 15:24:45.141120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    class ModulesMock(object):
        def __init__(self, params):
            self.params = params

    def find_file_in_search_path(variables, subdir, fn, ignore_missing=False):
        assert isinstance(variables, dict)

        assert isinstance(subdir, str)
        assert subdir in ('files', )

        assert isinstance(fn, str)
        assert fn in ("test_find_file_in_search_path", None)

        assert isinstance(ignore_missing, bool)

        # list of lists to simulate
        # 1) file found
        # 2) file not found
        # 3) file not found


# Generated at 2022-06-11 15:24:56.684647
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:24:57.749708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test not implemented"



# Generated at 2022-06-11 15:25:07.956101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'lookup_plugins')

    # Tests for defined 'file' and no 'path'

# Generated at 2022-06-11 15:25:09.257452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Unit tests not implemented yet"

# Generated at 2022-06-11 15:25:21.213964
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a list of file names as _terms
    terms_list = [
        "/path/to/foo.txt",
        "bar.txt",
        "/path/to/biz.txt"
    ]

    # Test with a key files in the params
    params_list = {
        "files": [
            "/path/to/foo.txt",
            "/path/to/bar.txt"
        ],
        "paths": [
            "/extra/path"
        ],
        "skip": True
    }

    # Test if the search order of files is correct
    terms_order = [
        "/path/to/foo.txt",
        "/path/to/biz.txt",
        "/path/to/bar.txt"
    ]

    # Test if only paths are considered in search order
    terms_path_

# Generated at 2022-06-11 15:25:26.270933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False), "Missing documentation on test_LookupModule_run"

# Generated at 2022-06-11 15:25:32.007707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # not implemented
    obj = LookupModule()
    try:
        obj.run(terms=[], variables={})
        assert False, "LookupModule run didn't raise"
    except AssertionError:
        assert False, "LookupModule doesn't raise an error"
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-11 15:25:33.862471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testing this one is difficult, as we don't have a way to test file lookup from dir A,
    # and then B, with no other location data.
    pass

# Generated at 2022-06-11 15:25:42.519808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic run
    lookup = LookupModule()
    lookup._subdir = 'files'
    assert lookup.run(terms=['somefile'], variables={}) == ['/etc/ansible/files/somefile']

    # Find file in a list of files
    lookup = LookupModule()
    lookup._subdir = 'files'
    assert lookup.run(terms=['somefile', 'existingfile'], variables={}) == ['/etc/ansible/files/existingfile']

    # Return empty list if no file is found
    lookup = LookupModule()
    lookup._subdir = 'files'
    assert lookup.run(terms=['somefile'], variables={}) == ['/etc/ansible/files/somefile']

    # Paths option
    lookup = LookupModule()
    lookup._subdir = 'files'
   

# Generated at 2022-06-11 15:25:44.237488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # TODO: add some tests

# Generated at 2022-06-11 15:25:52.441725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    class FakeFileLoader(object):

        def __init__(self, path):
            self.stored_path = path

        def path_dwim(self):
            return self.stored_path

    class FakeAnsibleModule(object):

        def __init__(self, d=None):
            self.params = d

    class FakeAnsible(object):

        def __init__(self, d=None):
            self.params = d

        def __getitem__(self, key):
            return self.params[key]

        def __setitem__(self, key, value):
            self.params[key] = value


# Generated at 2022-06-11 15:25:56.451394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader()

    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup.run({'files': '', 'paths': ''}, {}, skip=False)
    assert 'No file was found' in str(excinfo.value)

    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup.run('', {}, skip=False)
    assert 'No file was found' in str(excinfo.value)

    lookup.run({'files': '', 'paths': ''}, {}, skip=True) == []
    lookup.run('', {}, skip=True) == []

    lookup.run(['', ''], {}, skip=False)
    lookup.run(['', ''], {}, skip=True) == []

# Generated at 2022-06-11 15:26:06.436471
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # this here to make sure the jinja2.exceptions is accessible
    from jinja2.exceptions import UndefinedError
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    vault_pass = to_bytes('$ANSIBLE_VAULT;1.1;AES256', errors='surrogate_or_strict')
    vault_secret = to_bytes('ansible', errors='surrogate_or_strict')
    vault = VaultLib(vault_pass)
    encrypted_data = vault.encrypt(vault_secret)


# Generated at 2022-06-11 15:26:11.187189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests for no lookup errors
    # check for when file is found
    # check for when files is not found

    # Setup
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.hostvars import HostVarsVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = DummyTemplar()
    variables = HostVarsVars(loader=None, variables={'inventory_hostname': 'foo'})

    terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    terms = listify_lookup_plugin_terms(terms, templar, variables, None)

    lookup_params = {'_terms': terms}

# Generated at 2022-06-11 15:26:22.161881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: This test will fail if _process_terms is changed
    #       as it currently relies on the 'special' order of
    #       operations in the for loop
    #       A more realistic test is needed for this changes
    #       are made in _process_terms
    #       This test can be removed as it is no longer effective.
    lookup = LookupModule()
    expected_result = []
    terms = [{'files': 'foo,bar', 'paths': '/a,/b'}, 'baz', ['/c/d', '/e/f']]
    actual_result = lookup.run(terms, [], [], {})
    # The second term ('baz') is not found, because the 'paths'
    # option was not specified.
    assert actual_result == expected_result
    # This test was added to

# Generated at 2022-06-11 15:26:36.329799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar = DummyTemplar()
    # lm._find_file_in_search_path = Dummyfind_file_in_search_path()
    lm.find_file_in_search_path = Dummyfind_file_in_search_path()

    # Term with a dict
    term = [dict(files=['file1', 'file2'], paths=['path1', 'path2'])]
    files, skip = lm._process_terms(term, dict(), dict())

    assert files == ['path1/file1', 'path2/file1', 'path1/file2', 'path2/file2']
    assert skip == False

    # Term with a string
    term = ['file1']
    files, skip = lm._process_

# Generated at 2022-06-11 15:26:40.384708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._basedir = os.path.dirname(__file__)

    lookup_module.run(["tests/test_lookup_first_found.py"])

# Generated at 2022-06-11 15:26:50.451334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    lookup_plugin = LookupModule()

    def run_playbook(playbook_path=None, variables=None):
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources='localhost,')
        variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 15:26:52.231859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['main.yml']) is not None

# Generated at 2022-06-11 15:27:02.259744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    # load the module in question
    lookup_module = LookupModule()

    # return value of the method run
    ret_run = None
    ret_run_skip = None

    # test path
    test_file_path = '/etc/ansible/roles/test'

    # create the test file if does not exist
    if os.path.exists(test_file_path) is False:
        test_file = open(test_file_path, 'w')
        test_file.close()

    # create the list of files


# Generated at 2022-06-11 15:27:13.314049
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocks
    class MockAnsibleFile():
        def __init__(self, ret_value=None):
            self.ret_value = ret_value

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=None):
            return self.ret_value

    class MockAnsibleTemplar():
        def __init__(self, ret_value=None):
            self.ret_value = ret_value

        def template(self, fn=None):
            return self.ret_value

    class MockAnsibleModule():
        def __init__(self, ret_value=None):
            self.ret_value = ret_value

        def get_option(self, option):
            return self.ret_value


# Generated at 2022-06-11 15:27:20.147593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    params = {'terms': [
        [
            '/etc/hosts'
        ]
    ], 'variables': {
        'inventory_hostname': 'notused',
        'ansible_distribution': 'notused',
        'ansible_os_family': 'notused'
    }}
    lookup_module.run(**params)
    assert False, "Test not implemented."

# Generated at 2022-06-11 15:27:31.576080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile

    # Given a temp file
    with tempfile.NamedTemporaryFile('w') as f:
        f.write('''The quick brown fox jumps over the lazy dog''')

        # And no files but a path
        params = dict(paths=tempfile.gettempdir())
        # And an instance of LookupModule
        lk = LookupModule()
        # And an instance of ansible_vars
        ansible_vars = dict()
        # And an instance of ansible module params
        module_params = dict()

        # When trying to read the temp file with lookup first_found
        # and given the params are in a list
        result = lk.run([params], ansible_vars, module_params)
        # Then result is a list of the file

# Generated at 2022-06-11 15:27:34.353390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule() 
    terms = ["test.cf", "{{ ansible_virtualization_type }}_foo.conf"]
    res = lookup.run(terms)
    assert res == ['/etc/ansible/test.cf']

# Generated at 2022-06-11 15:27:45.379840
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test object
    lookup_obj = LookupModule()

    # Test case 1
    lookup_obj._templar.available_variables = {"foo": "foo.txt", "bar": "bar.txt"}
    terms = [{"files": "{{ foo }},{{ bar }}", "paths": "/tmp/production,/tmp/staging"}]
    variables = {"foo": "foo.txt", "bar": "bar.txt"}
    kwargs = {}
    ret = lookup_obj.run(terms, variables, **kwargs)
    assert ret == ['/tmp/production/foo.txt']

    # Test case 2
    lookup_obj._templar.available_variables = {"foo": "foo.txt", "bar": "bar.txt"}

# Generated at 2022-06-11 15:27:58.183476
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NotImplementedError: Caught this runtime error when running the test:
    # RuntimeError: dictionary changed size during iteration
    # TODO: fix this
    return

    class MockTemplar:
        @staticmethod
        def template(filename):
            return filename

    mock_templar = MockTemplar()

    terms = [
        'test',
        {'files': 'foo,bar',
         'paths': './:../'},
        ['test2', 'test3', {'files': 'foo,bar',
                            'paths': './:../'}]
    ]
    variables = {'role_path': '.'}
    mock_first_found = LookupModule()

# Generated at 2022-06-11 15:27:59.345828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()


# Generated at 2022-06-11 15:28:02.993305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    expected_result = ['/tmp/file.tmp']
    result = module.run(['/tmp/file.tmp'], {})
    assert expected_result == result

# Generated at 2022-06-11 15:28:07.580889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options = {}, direct = {'skip': False})

    actual_result = lookup_module.run(['/etc/hosts', '/etc/hosts'])
    expected_result = ['/etc/hosts']
    assert actual_result == expected_result


# Generated at 2022-06-11 15:28:19.425854
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Dummy_LookupBase(LookupBase):
        _subdir = 'files'
        # NOTE: as this specificed no .find_file_in_search_path it should be pretty safe to use for unit tests
        def _find_file_in_search_path(self, searchpath, filepath, **kwargs):
            return filepath

    class Dummy_AnsibleUndefinedVariable(AnsibleUndefinedVariable):
        def __init__(self, *args, **kwargs):
            super(Dummy_AnsibleUndefinedVariable, self).__init__(*args, **kwargs)
            self.message = 'some message'

    class Dummy_UndefinedError(UndefinedError):
        def __init__(self, *args, **kwargs):
            super(Dummy_UndefinedError, self).__

# Generated at 2022-06-11 15:28:26.997541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Because of the meta information passed in, we have to be careful in
    # testing that the proper values are returned.
    lookup_module = LookupModule()
    lookup_module._subdir = 'files'
    assert lookup_module._process_terms(['file1']) == (['files/file1'], False)
    assert lookup_module._process_terms(['file1', 'file2']) == (['files/file1', 'files/file2'], False)
    assert lookup_module._process_terms([{}, 'file2']) == (['files/file2'], False)
    assert lookup_module._process_terms([{'skip': True}, 'file2']) == (['files/file2'], True)

# Generated at 2022-06-11 15:28:37.983902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule: run
    """
    from ansible.parsing.dataloader import DataLoader

    class VarsModule:
        def vars(self, loader, path, entities, cache=True):
            return {'ansible_distribution': 'dist'}

    lm = LookupModule(loader=DataLoader())
    # test with file and list
    file = 'terms'
    params = [file]
    search = ['/path/to/files/terms']
    assert lm.run(params, {}, wantlist=True) == search
    assert lm.run([file], {}, wantlist=True) == search

    # test with path and list
    params = {'files': file, 'paths': '/path/to/files'}

# Generated at 2022-06-11 15:28:49.200467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.template.template import AnsibleTemplate
    from ansible.utils.path import makedirs_safe
    from six import PY3
    from shutil import rmtree

    from tempfile import mkstemp, mkdtemp


# Generated at 2022-06-11 15:29:01.215047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = [
        {'files': 'foo', 'paths': 'a:b:c'},
        'foobar',
        {'files': 'fizz, buzz', 'paths': 'a.b.c'},
        ['foo, bar', 'bizz , buzz'],
        {'files': 'foo', 'paths': 'a:b:c', 'skip': '1'},
        {'files': 'foo', 'paths': 'a:b:c', 'skip': 'yes'},
    ]
    variables = {}
    kwargs = {}
    result = lm._process_terms(terms, variables, kwargs)

# Generated at 2022-06-11 15:29:03.993469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance
    lookup_mod = LookupModule()
    # Execute run method using non existing files
    lookup_mod._subdir = 'files'
    assert lookup_mod.run(["non_existing_file.txt"]) is None

# Generated at 2022-06-11 15:29:17.149913
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    look = LookupModule()
    look._templar = None
    look.basedir = "/tmp"

    # call 'run' with a valid term
    term = ["/etc/passwd"]
    ret = look.run(term, None)

    assert ret == ["/etc/passwd"]

    # call 'run' with an invalid term
    term = ["/etc/invalid"]
    ret = look.run(term, None)

    assert ret == []

# Generated at 2022-06-11 15:29:28.784065
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:29:36.719951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mk = LookupModule()
    mk._loader = DictDataLoader()
    mk._templar = Templar(loader=mk._loader)
    mk._display = Display()
    # Only one of the files exists in the mock files
    terms_list = [
        'file1',
        {'files': ['file2'], 'paths': ['path1']},
        {'files': ['file3'], 'paths': ['path2']},
        'file4',
        {'files': ['file5'], 'paths': ['path1']}
    ]
    res = mk.run(terms=terms_list, variables={}, **{u'subdir': None})
    assert res == [u'path1/file2']
    # Only one of the files exists in the mock files and it's the only one
    #

# Generated at 2022-06-11 15:29:45.874582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A LookupModule
    lookup = LookupModule()

    # Args for run
    terms = [
        "bar.txt",
        {
            "files": ["foo.txt", "baz.txt"],
            "paths": ["test/", "test2/"],
            "skip": True
        },
        {
            "files": ["foo.txt", "ok.txt"],
            "paths": ["test/", "test2/"],
            "skip": False
        }
    ]
    variables = dict()

    # Test the return value.
    assert lookup.run(terms, variables) == ['test/foo.txt']

# Generated at 2022-06-11 15:29:53.728119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables
    terms = [
        'nf',
        'some_file',
        {
            'files': 'wifi,ipv6,bond,team',
            'paths': '/etc/network:~/network:./network',
            'skip': True
        }
    ]
    variables = ['ansible_playbook_python', 'ansible_playbook_python']

    # Instantiate lookup
    lookup_mod = LookupModule()
    lookup_mod._subdir = 'files'

    # Assertion
    assert lookup_mod.run(terms, variables) == []

# Generated at 2022-06-11 15:29:54.464820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:30:06.609417
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import string_types

    lookup = LookupModule()

    with patch.object(lookup, '_find_file_in_search_path', return_value=None):
        with patch.object(lookup._lookup_loader, 'get_basedir') as mock_basedir:
            mock_basedir.return_value = None

            with patch.object(lookup._templar, 'template', return_value=None):

                search, skip = lookup._process_terms('', {}, {})
               

# Generated at 2022-06-11 15:30:07.563556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add unit test
    pass

# Generated at 2022-06-11 15:30:15.198800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os, os.path
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from ansible.plugins.loader import lookup_loader
    lookup_obj = lookup_loader._create_lookup_instance('first_found')
    lookup_obj.get_basedir = lambda: '/tmp/XXXX'
    lookup_obj._templar = lambda: None
    lookup_obj._templar.template = lambda param: param
    lookup_obj.get_option = lambda: None
    lookup_obj.get_option.return_value = False
    assert lookup_obj.run(terms=['any'], variables={}) == ['/tmp/XXXX/any']



# Generated at 2022-06-11 15:30:26.297888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test calls
    assert LookupModule.run([]) == None
    assert LookupModule.run({}) == None
    assert LookupModule.run([{u'files': ['foo.txt']}]) == None
    assert LookupModule.run([{u'files': [u'foo.txt']}]) == None
    assert LookupModule.run('') == None
    assert LookupModule.run({'files': [u'foo.txt']}) == None
    assert LookupModule.run({'files': ['foo.txt']}) == None
    assert LookupModule.run([{}]) == None
    assert LookupModule.run([{'files': [u'foo.txt']}]) == None

# Generated at 2022-06-11 15:30:42.214658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Need to pass:
    # terms
    # variable

    # TODO
    # set up env?
    # test cases
    #   None or []
    #   simple str?
    #   2 str?
    #   bad type?
    #   mapping w/ files, paths?
    #   list w/ mixed types?
    #   mixed w/ mapping/str?
    pass

# Generated at 2022-06-11 15:30:49.818393
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _find_file_in_search_path(**kwargs):
        return kwargs['fn']

    LookupModule._find_file_in_search_path = _find_file_in_search_path

    lookup = LookupModule()
    lookup._templar = AnsibleTemplar()

    # Case: invalid term
    with pytest.raises(AnsibleLookupError) as err:
        lookup.run(terms=dict(key='value'), variables={})
    assert 'can handle string' in str(err.value)

    # Case: no lookup needed
    result = lookup.run(terms=['/path/to/foo.txt'], variables={})
    assert result == ['/path/to/foo.txt']

    # Case: exists

# Generated at 2022-06-11 15:30:59.400741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.template import Templar
    t = Templar(loader=None, variables=dict(foo='/tmp/foo', bar='/tmp/bar', baz='/tmp/baz'))
    l = LookupModule()
    l._templar = t

    def mock_find_file_in_search_path(*args, **kwargs):
        return '/tmp/qux'

    l.find_file_in_search_path = mock_find_file_in_search_path

    assert '/tmp/qux' in l.run(terms=[], variables=dict())

    def mock_find_file_in_search_path(*args, **kwargs):
        return None

    l.find_file_in_search_path = mock_find_file_in_

# Generated at 2022-06-11 15:31:09.438690
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.lookup_utils import LookupModule as _LookupModule
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import mock
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import unittest

    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch


# Generated at 2022-06-11 15:31:10.164652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:31:14.537368
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert lookup_module.run(['first_found.txt'], {}, errors='ignore', skip=True) == []

    assert lookup_module.run(['first_found.txt'], {}) == ['file:///home/user/first_found.txt']

# Generated at 2022-06-11 15:31:24.395558
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # UnitTest: test first_found lookup module
    assert LookupModule().run([], {},
                              files='foo,bar',
                              paths='some/path',
                              skip=True) == []
    assert LookupModule().run(['foo'], {},
                              files='foo,bar',
                              paths='some/path',
                              skip=True) == []
    assert LookupModule().run(['foo'], {},
                              files='baz,bar',
                              paths='some/path',
                              skip=True) == []
    assert LookupModule().run(['foo'], {},
                              files='foo,bar',
                              paths='other/path',
                              skip=True) == []

# Generated at 2022-06-11 15:31:33.025925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def _format_path(self, path):
            return path
    lookup = TestLookupModule()

    # Test with 3 files in different subfolders
    # Expected result: path of first file found
    lookup.set_options(direct={'files':'file1,file2'})
    terms = ['path/', 'path_not_found/']
    result = lookup.run(terms)
    assert result[0] in ['path/file1', 'path/file2']

    # Test with 3 files in same subfolder
    # Expected result: path of first file found
    lookup.set_options(direct={'files':'file1,file2'})
    terms = ['path/']
    result = lookup.run(terms)

# Generated at 2022-06-11 15:31:42.057892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __main__
    vars_dict = {'inventory_hostname': 'test_host'}
    __main__.set_fact(vars_dict)
    lookup_obj = LookupModule()
    assert 'path/foo.txt' == lookup_obj.run([{'files': 'foo.txt', 'paths': 'path'}], vars_dict)[0]
    assert [] == lookup_obj.run([{'files': 'bar.txt', 'paths': 'path'}], vars_dict, skip=True)
    with pytest.raises(AnsibleLookupError):
        lookup_obj.run([{'files': 'bar.txt', 'paths': 'path'}], vars_dict)

# Generated at 2022-06-11 15:31:52.003097
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create argument lists
    t_first_found = LookupModule()

    # Initialize variables
    search_paths = os.environ['PATH'].split(os.pathsep)
    self = None

    # Attempt to add paths to search_paths
    try:
        search_paths.append('/usr/bin')
        search_paths.append('/usr/sbin')
    except:
        pass

    # Use these lists to test method run
    terms = [{'files': 'ls'}, {'paths': search_paths}]
    variables = {'foo': 'bar', 'value': 34}
    kwargs = {'skip': True}

    total_search, skip = t_first_found._process_terms(terms, variables, kwargs)

    path = None