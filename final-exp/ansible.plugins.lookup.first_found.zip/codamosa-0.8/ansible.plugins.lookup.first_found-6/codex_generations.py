

# Generated at 2022-06-11 15:22:33.912235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    cwd = os.getcwd()
    os.chdir("../")
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    # create the variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    # Create inventory, use path to host config file as source or hosts in a comma separated string
    inventory = InventoryManager(loader=loader, sources='./test/unit/files/test_lookup_first_found/hosts')
    # add hosts to inventory
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 15:22:41.566545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleModuleMock:
        class AnsibleModuleMock2:
            class AnsibleModuleMock3:
                _context = "/tmp"
                _ds = "/"
                dirname = "/tmp"
            _templar = AnsibleModuleMock2()
            _ds = "/"
            _load_name = "_load_name"
            _basedir = "/tmp"
            def __init__(self, content):
                self._templar = self
                self._result = content

            def template(self, content):
                return content

        lookup_loader = AnsibleModuleMock2()
        params = 'content'
        lookup_loader._loader = AnsibleModuleMock2()
        _shared_loader_obj = AnsibleModuleMock3()

    class MockVars:
        pass

    module = Ans

# Generated at 2022-06-11 15:22:47.973913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeVarManager(object):
        def __init__(self):
            self._vars = dict()
            
        def get_vars(self, loader, path, entities):
            return dict(foo='bar')

    class FakePathFinder(object):
        def find_file_in_search_path(self, variables, subdir, path, ignore_missing=False):
            if subdir == 'files':
                return path
            return None

    class FakeTemplar(object):
        def __init__(self):
            self._variables = dict()

        def set_available_variables(self, variables):
            self._variables = variables


# Generated at 2022-06-11 15:22:58.931536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template.template import Templar

    variables = dict()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader,
                      variables=variable_manager,
                      fail_on_undefined=True,
                      disable_lookups=False)

    module = LookupModule()
    module._templar = templar
    module._loader = loader
    module._find

# Generated at 2022-06-11 15:23:10.175790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single file
    lookup_plugin = LookupModule()
    lookup_plugin._subdir = 'files'

    assert lookup_plugin.run('exists.txt', dict()) == ['/etc/ansible/files/exists.txt']

    # Test with a multiple file
    lookup_plugin = LookupModule()
    lookup_plugin._subdir = 'files'

    assert lookup_plugin.run(['exists.txt', 'doesnt_exist.txt'], dict()) == ['/etc/ansible/files/exists.txt']

    # Test with additional paths
    lookup_plugin = LookupModule()
    lookup_plugin._subdir = 'files'


# Generated at 2022-06-11 15:23:23.314501
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Make mock class and give it required methods
    class LookupModuleMock(LookupModule):
        def __init__(self):
            pass
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            return None

    lookup = LookupModuleMock()

    # Set _templar mock object
    class Templet:
        def template(self, x):
            return x
    lookup._templar = Templet()

    # Set _subdir
    lookup._subdir = 'files'

    # Create expected results
    expected = []

    # Execute the run method for LookupModule
    result = lookup.run([], {})

    # Assert the expected and results

# Generated at 2022-06-11 15:23:32.200035
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import tempfile
    import shutil

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestLookupModule(unittest.TestCase):

        def setUp(self):

            self.base_path = tempfile.mkdtemp()
            self.test_path = os.path.join(self.base_path, 'files')
            os.makedirs(self.test_path)


# Generated at 2022-06-11 15:23:43.968103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # this test needs to be python 2.6 compatible
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    # to be able to mock self.find_file_in_search_path()

    test_path, _sep, test_file = 'path/to/file.txt'.rpartition('/')
    test_file = [test_file]

    lookup_obj = LookupModule()

    mock_self = Mock(name='lookup_obj')
    mock_self.get_option = Mock(name='get_option')
    mock_self.get_option.return_value = None
    mock_self.find_file_in_search_path = Mock(name='find_file_in_search_path')

    # test_run_with_valid_path

# Generated at 2022-06-11 15:23:54.964271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()  # creates an object
    # function run is tested
    # args: terms, variables, **kwargs
    terms = [
        {
            "files": "file1",
            "paths": "path1"
        },
        {
            "files": "file2",
            "paths": "path2"
        },
        {
            "files": "file3",
            "paths": "path3"
        },
        "path4",
        "path5"
    ]
    variables = {}
    kwargs = {}
    obj.run(terms, variables, kwargs)

# Generated at 2022-06-11 15:24:02.410067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_module = LookupModule()

    ################################################################################
    # test_LookupModule_run: test arg terms and variable in dict, check file to be found
    ################################################################################

    lookup_module._subdir = 'files'
    assert lookup_module.run([{'files': ['default.yml'], 'paths': '../../../../../'}], None) == ['../../../../../default.yml']

    ################################################################################
    # test_LookupModule_run: test arg terms, variable in dict and skip, check file to be found
    ################################################################################

    lookup_module._subdir = 'files'

# Generated at 2022-06-11 15:24:12.904403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.

    """
    # Calling the LookupModule constructor
    lookup_module = LookupModule()

    # Defining the variables term, variables and kwargs
    term = {'files': 'impr.txt', 'paths': '/usr/lib/python2.7/impr.txt'}
    variables = {}
    kwargs = {}

    # Calling Run method of class LookupModule
    lookup_module.run(term, variables, kwargs)

# Generated at 2022-06-11 15:24:21.196318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paths = ['/foo', '/bar', '/baz']
    files = ['file1', 'file2', 'file3', 'file4']
    terms = [{
        'paths': paths,
        'files': files
    }]

    # I'm not sure how to unit test this.
    # I also don't see how this is called.
    # So I'm going to stub out the things that are hard
    # to test, and leave this here for now.
    lookup = LookupModule()
    lookup._templar = None
    # Can't be tested.
    #lookup.find_file_in_search_path = None
    lookup.run(terms, None)



# Generated at 2022-06-11 15:24:27.030946
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test 1, fail without files and paths option
    try:
        lu = LookupModule()
        lu.run(terms=['fake.txt'], variables={})
        raise AssertionError('Expected AnsibleLookupError')
    except AnsibleLookupError:
        pass

    # test 2, fail with files option with existing files and paths with non-existent files
    try:
        lu = LookupModule()
        lu.run(terms=[{'files': ['fake.txt'], 'paths': ['a/b/c']}], variables={})
        raise AssertionError('Expected AnsibleLookupError')
    except AnsibleLookupError:
        pass

    # test 3, fail with files option with empty list and paths with non-existent files

# Generated at 2022-06-11 15:24:36.330876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import lookup_loader

    fake_variables = {'inventory_hostname': 'fake_host'}
    fake_play_context = {'variable_manager': {'extra_vars': {}}}

    class FakeLoader():
        def __init__(self):
            self._templar = fake_loader

        def get_basedir(self, hostname):
            return 'files'

        def path_dwim(self, x):
            return x

    lookup_plugin = lookup_loader.get('first_found', loader=FakeLoader())

    # test_terms: list of valid tests
    # test_terms[i][0]: list of valid input vars for lookup
    # test_terms[i][1]: exception expected for this specific

# Generated at 2022-06-11 15:24:37.823622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add unit test
    pass

# Generated at 2022-06-11 15:24:38.592128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:24:48.310330
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:24:59.007722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.modules.extras.source_control.git.git import GitRepo
    from ansible.template import Templar

    repo = GitRepo('/', '/', '/', 'master', 'https://github.com/ansible/ansible-modules-core.git')
    templar = Templar(loader=None, variables={}, fail_on_undefined=True, filters=None)

    current_file = os.path.realpath(__file__)
    current_dir = os.path.dirname(current_file)
    role_dir = os.path.join(current_dir, '../../../../../')
    role_files_dir = os.path.join(role_dir, 'files')
    play_files_dir = os.path.join(current_dir, 'files')

    # test no file

# Generated at 2022-06-11 15:25:10.377992
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prepare instance for testing
    class DummyVarsModule(object):
        vars = dict()
    dummyVarsModule = DummyVarsModule()

    lookup = LookupModule()
    lookup._templar = DummyVarsModule()
    lookup.set_options(var_options=dummyVarsModule.vars)

    # find_file_in_search_path
    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: (fn in ['/etc/network/interfaces', '/run/systemd/network/10-dhcp-en.network'])

    # test one item
    assert lookup.run(terms=['/etc/network/interfaces'], variables=dummyVarsModule.vars) == ['/etc/network/interfaces']

    # test one

# Generated at 2022-06-11 15:25:22.325796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _plugin = LookupModule()

    # NOTE: The module_utils/common/_collections_compat.py
    #       is used to fake python2 dict 2/3 compatibility.
    #       as there is no proper support for Mapping,
    #       we need to fake it with a class.
    class FakeMapping(dict, Mapping):
        def __getitem__(self, key):
            return super(FakeMapping, self).__getitem__(key)

    # test with a list of terms

# Generated at 2022-06-11 15:25:37.654138
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # term as string, wrong type of variables, empty kwargs
    lookup = LookupModule()
    assert lookup.run(terms='myfile', variables={}, kwargs={}) == []

    # term as string, no variables, empty kwargs
    lookup = LookupModule()
    assert lookup.run(terms='myfile', variables=None, kwargs={}) == []

    # term as string, variables, empty kwargs
    lookup = LookupModule()
    assert lookup.run(terms='myfile', variables=dict(ansible_distribution='foo'), kwargs={}) == []

    # term as string, variables, 'files' kwargs
    lookup = LookupModule()

# Generated at 2022-06-11 15:25:48.545224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # check that no file is found
    kwargs = {
        'paths': ['my_path'],
        'files': ['my_file']
    }
    terms = [kwargs]
    result = lookup_module.run(terms, dict())
    assert not result

    path_cwd = os.getcwd()
    tmp_test_file = "%s/test_file" % path_cwd
    open(tmp_test_file, 'a').close()

    # check that a file is found
    kwargs['files'] = ['test_file']
    terms = [kwargs]
    result = lookup_module.run(terms, dict())
    assert result == ['test_file']

    # check that when a file is found, the second file doesn't return an error

# Generated at 2022-06-11 15:25:59.622256
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:26:07.944862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    os.environ["ANSIBLE_LOOKUP_FIRST_FOUND_FOR_TESTING"] = "1"
    os.environ["ANSIBLE_LOOKUP_FIRST_FOUND_FOR_TESTING_2"] = "1"
    os.environ["ANSIBLE_LOOKUP_FIRST_FOUND_FOR_TESTING_3"] = "1"
    os.environ["ANSIBLE_LOOKUP_FIRST_FOUND_FOR_TESTING_4"] = "1"
    os.environ["ANSIBLE_LOOKUP_FIRST_FOUND_FOR_TESTING_5"] = "1"
    os.environ["ANSIBLE_LOOKUP_FIRST_FOUND_FOR_TESTING_6"]

# Generated at 2022-06-11 15:26:19.912508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import shutil
    import tempfile
    from ansible.parsing.dataloader import DataLoader

    # setup
    temp_dir1 = tempfile.mkdtemp()
    temp_dir2 = tempfile.mkdtemp()
    temp_dir3 = tempfile.mkdtemp()
    file1 = tempfile.NamedTemporaryFile(mode='w', dir=temp_dir1, suffix='.txt', delete=False)
    file2 = tempfile.NamedTemporaryFile(mode='w', dir=temp_dir1, suffix='.txt', delete=False)
    file3 = tempfile.NamedTemporaryFile(mode='w', dir=temp_dir2, suffix='.txt', delete=False)

# Generated at 2022-06-11 15:26:31.726124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import u
    from ansible.module_utils.common._collections_compat import UserDict

    # The unit tests below are based on the code. The changes here are to
    # remove internal code calls, which are not tested.

    class LookupBaseTest(object):

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            if fn == u('/tmp/production/foo') or fn == u('/tmp/staging/foo'):
                return u('/foo')
            else:
                if ignore_missing:
                    return None
                raise AnsibleLookupError("No file was found when using first_found.")


# Generated at 2022-06-11 15:26:40.817020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.plugins.lookup import LookupBase

    # Setup lookup module input
    lu = LookupModule()
    lu._templar = None

    # Setup test directories
    # TODO: need better error handling on create/remove of directory
    # TODO: setup temp directory with known files
    TMPDIR = tempfile.mkdtemp(prefix='ansible-test-file')
    TMPDIR2 = tempfile.mkdtemp(prefix='ansible-test-file')
    TESTFILE1 = os.path.join(TMPDIR, 'test1')

# Generated at 2022-06-11 15:26:50.537529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookuper(LookupModule):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            file_name = fn.split('/')[-1]
            if file_name == 'redhat':
                return '/etc/redhat-release'
            elif file_name == 'debian':
                return '/etc/debian-release'
            elif file_name == 'suse':
                return '/etc/suse-release'
            elif file_name == 'centos':
                return '/etc/centos-release'
            elif file_name == 'fedora':
                return '/etc/fedora-release'
            elif file_name == 'ubuntu':
                return '/etc/ubuntu-release'
            return None

    vars_options = {}

# Generated at 2022-06-11 15:27:01.481300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    import mock
    import pytest
    from ansible.plugins.lookup import first_found
    from ansible.module_utils.six import BytesIO

    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import string_types

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # ==================================================
    # Tests for module load, usage and exceptions
    # ==================================================
    # Use module to raise exception when using invalid path
    with pytest.raises(AnsibleLookupError):
        assert first_found._lookup_module('test').run('test', 'test')

    assert isinstance(first_found._lookup_module('test').run('test', 'test', errors='ignore'), list)

    # Use module with invalid args
   

# Generated at 2022-06-11 15:27:12.138732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    for terms, variables, kwargs, result in [
        [
            [{'files': ['foo', 'bar'], 'paths': '/tmp'}],
            {'hostvars': {}},
            {},
            ['/tmp/foo']
        ],
        [
            [
                {'files': ['foo', 'bar'], 'paths': '/tmp'},
                {'files': ['old', 'new'], 'paths': '/var'}
            ],
            {'hostvars': {}},
            {},
            ['/tmp/foo', '/var/old']
        ],
    ]:
        assert lookup_module.run(terms, variables, **kwargs) == result



# Generated at 2022-06-11 15:27:29.689666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_find_file_in_search_path(self, variables, subdir, filename, ignore_missing=False):
        return '/var/run/' + filename
    import unittest.mock as mock
    # Init
    LookupModule.find_file_in_search_path = mock.MagicMock(side_effect=mock_find_file_in_search_path)
    inst = LookupModule()
    # Case 1: fn is a string
    fn = 'passwd'
    # Case 1-subcase 1: fn is found
    res_1_1 = inst.run(fn)
    assert res_1_1 == ['/var/run/passwd']
    # Case 1-subcase 2: fn is not found

# Generated at 2022-06-11 15:27:39.872259
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.constants import DEFAULT_TEMPLATE_UNDEFINED_ERROR
    from jinja2.exceptions import UndefinedError
    from jinja2.runtime import Context, StrictUndefined

    # Mocking _get_plugin_options method of LookupBase class
    def _get_plugin_options(self):
        return self._plugin_args

    # Mocking _templar.template
    def _template(self, term):
        return term

    # Mocking _get_search_paths method of LookupBase
    def _get_search_paths(self):
        return ["path_1", "path_2"]

    # Mocking find_file_in_search_path method of LookupBase

# Generated at 2022-06-11 15:27:49.830392
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #TODO: need to test exception on no file found with skip=False
    #TODO: need to test exception on empty list for terms
    #TODO: need to test exception on no file found with skip=True
    #TODO: need to test variable substitution
    #TODO: need to test multiple files found
    #TODO: need to test multiple files found in multiple paths

    def test_cases_run(self, terms, variables, expected, skip, paths=None, files=None):

        l = LookupModule()  # TODO: need to create a mock templar
        l._subdir = None

        if paths is None and files is not None:
            kwargs = {'paths': paths, 'files': files, 'skip': skip}

# Generated at 2022-06-11 15:27:59.038421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Test_LookupModule(LookupModule):
        def __init__(self):
            self.templar = {'var': 'foo',
                            'ansible_distribution': 'foo_distribution',
                            'ansible_os_family': 'foo_os',
                            'ansible_virtualization_type': 'foo_virtualization_type'}
            self.registry = {'foo': ['bar', 'baz'],
                             'foo_distribution': ['bar_distribution', 'baz_distribution'],
                             'foo_os': ['bar_os', 'baz_os'],
                             'foo_virtualization_type': ['bar_virtualization_type', 'baz_virtualization_type']}


# Generated at 2022-06-11 15:28:08.908647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

# Generated at 2022-06-11 15:28:20.462649
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    # I don't know how to test module.set_options, so just set the attributes explicitly
    module._options = {}
    module._errors = []
    module._templar = None # TODO: I don't know how to test this
    module._display = None # TODO: I don't know how to test this
    module._templar = None # TODO: I don't know how to test this
    module._connection = None # TODO: I don't know how to test this
    module._loader = None # TODO: I don't know how to test this
    module._basedir = "."

    lookup_list = [{"files": ["bar.txt"], "paths": ["."]}]
    variables = {}
    kwargs = {}

    expected_list = ["./bar.txt"]

# Generated at 2022-06-11 15:28:27.513823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from shutil import rmtree

    # Setup temp directory to serve as file source
    temp_dir = tempfile.mkdtemp()

    # Create a file in temp directory and set the source
    temp_content = "file1\n"
    temp_file = open(os.path.join(temp_dir, "file1"), "w+")
    temp_file.write(temp_content)
    temp_file.close()

    temp_content = "file2\n"
    temp_file = open(os.path.join(temp_dir, "file2"), "w+")
    temp_file.write(temp_content)
    temp_file.close()

    temp_content = "file3\n"

# Generated at 2022-06-11 15:28:38.217181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    def set_attr(name, value):
        setattr(lookup, name, value)

    set_attr('_templar', None)
    set_attr('_loader', None)
    set_attr('_basedir', None)

    def find_file_in_search_path(variables, subdir, fn, ignore_missing=False):
        print('running find_file_in_search_path')

    set_attr('find_file_in_search_path', find_file_in_search_path)

    # test case 1: terms is not a str and not list of strings
    set_attr('_subdir', 'files')
    lookup._templar = None
    lookup._loader = None
    lookup._basedir = None


# Generated at 2022-06-11 15:28:49.369705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string = 'ssssssssssssssssssssssssssss'
    lst = ['strings', string, 'st']
    tup = ('tuple', string, 42)
    dct = {'dictionary': string, 'int': 42}

    dct_no_files = {'path': '/tmp/'}
    dct_invalid = {'files': 'list', 'paths': 'list'}

    # Fixed.
    total_search = []
    values = ('file1', 'file2', 'file3')
    for file in values:
        for path in ('/tmp/', '/tmp/another'):
            total_search.append(os.path.join(path, file))

    # Fixed.

# Generated at 2022-06-11 15:29:01.295363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test data
    args = dict(
        files=['test_file'],
        paths=['test_path'],
        skip=True,
    )
    data = [
        ('test_dir/test_file', True),
        ('test_dir/unknown_file', False),
    ]

    for (fn, succeed) in data:
        lm = LookupModule()
        lm._subdir = 'test_dir'
        if succeed:
            assert lm.run(terms=[fn], variables={}, **args) == [fn]
        else:
            assert lm.run(terms=[fn], variables={}, **args) == []

    # coverage test
    lm = LookupModule()
    assert lm.run(terms=['string'], variables={}, **args) == []

# Generated at 2022-06-11 15:29:24.688562
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    from ansible.module_utils.six import StringIO

    class Options(object):
        def __init__(self, verbosity=None, inventory=None):
            self.verbosity = verbosity
            self.inventory = inventory
            self.module_path = None
            self.connection = None
            self.remote_user = None
            self.private_key_file = None
            self.timeout = 10
            self.ssh_common_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.become_ask_pass

# Generated at 2022-06-11 15:29:34.386114
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.plugins.lookup.first_found import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    
    # Initialize object to test LookupModule class
    lookup_obj = LookupModule()

    # Define all the objects needed to test the method run of class LookupModule
    # First we need to initialize the DataLoader class
    data_loader = DataLoader()
    variable_manager = VariableManager()

    # Create a data structure which is used as input to the method under test
    variable_manager._fact_cache = {}
    variable_manager._vars_cache = {}

    # Create a data structure which is used as input to the method under test
    # The paramater paths is a list that can contain 1 or 2 elements

# Generated at 2022-06-11 15:29:45.266230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar()
    l._loader = DummyLoader()

    # check 'file found'
    assert l.run([{'files': 'one.yml', 'paths': 'files/'}], {}) == ['/home/tester/files/one.yml']

    # check 'file not found'
    try:
        l.run([{'files': 'three.yml', 'paths': 'files/'}], {})
    except AnsibleLookupError:
        pass
    else:
        assert False, 'failed to raise error on lookup lookup'

    # check skip on missing file
    assert l.run([{'files': 'three.yml', 'paths': 'files/', 'skip': True}], {}) == []

   

# Generated at 2022-06-11 15:29:54.936600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    l = LookupModule()
    l._templar = basic.AnsibleTemplar()
    l._templar.available_variables = {
        'ansible_virtualization_type': 'virtualbox',
        'ansible_os_family': 'RedHat',
        'ansible_distribution': 'Fedora',
        'inventory_hostname': 'host1',
    }

    # No path and no file
    i = [
        {
            'files': '1.txt',
            'paths': ['/tmp/production', '/tmp/staging']
        },
        {
            'files': '2.txt'
        }
    ]
    r = l.run(i, {})

# Generated at 2022-06-11 15:29:59.927565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testTerm = [{'files': 'file1,file2', 'paths': 'path1:path2'}, 'file3', ['file4', 'file5']]
    assert LookupModule().run(testTerm, {}) == ['file1']



# Generated at 2022-06-11 15:30:10.526738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stub
    lookup = LookupModule()
    # should find first_file.txt
    files = ['files/first_file.txt', 'files/second_file.txt']
    lookup.set_options(var_options={}, direct={'files': files})
    assert lookup.run(terms=[], variables={}) == ['files/first_file.txt']
    # should find first_file.txt
    files = ['files/second_file.txt', 'files/first_file.txt']
    lookup.set_options(var_options={}, direct={'files': files})
    assert lookup.run(terms=[], variables={}) == ['files/first_file.txt']
    # should throw exception
    lookup = LookupModule()

# Generated at 2022-06-11 15:30:20.553082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Test_LookupModule(object):
        def __init__(self, templar, loader):
            self.templar = templar
            self.loader = loader

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            if fn == 'FAIL':
                raise AnsibleLookupError()
            return fn

    def Test_Templar(self, variables, all_vars=None, **kwargs):
        if variables == 'FAIL':
            raise AnsibleUndefinedVariable()
        return variables

    class Test_Loader(object):
        def __init__(self):
            self._paths = ['/path/to/role/tasks']

    templar = Test_Templar(None)
    loader = Test_Loader()

   

# Generated at 2022-06-11 15:30:29.664067
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # create plugin instance
    lookup_plugin = LookupModule()

    # create templar object
    vault_secrets = dict(vault_password='secret')
    vault = VaultLib(vault_secrets)
    templar = Templar(loader=None, variables={}, vault_secrets=vault_secrets)

    # Test options
    test_terms = [
        {'files': 'foo', 'paths': 'bar'},
        'bar.txt',
        ['baz1.txt', 'baz2.txt', 'baz3.txt'],
        {'files': 'foo', 'paths': 'bar'},
    ]


# Generated at 2022-06-11 15:30:40.862139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class DummyModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception('fail_json')

        def exit_json(self, **kwargs):
            pass

    class DummyPlayContext(object):
        def __init__(self):
            self.prompt = None
            self.check_mode = False

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 15:30:49.174639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    lookup = lookup_loader.get('first_found')
    vars = {}
    templar = Templar(loader=None)

    # First test without subdir specified
    results = lookup.run([
        'bar.txt',
        'foo.txt',
        {'files': ['biz.txt', 'baz.txt'], 'paths': ['more', 'less']},
        {'files': ['baz.txt', 'biz.txt'], 'paths': ['more', 'less']},
    ], vars, templar=templar)
    assert results == ['foo.txt']

    # Define subdir, and test again
    lookup._subdir = 'subdir'

# Generated at 2022-06-11 15:31:22.538855
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # arrange
    class FakeLookupModule:

        def __init__(self):
            self._subdir = 'files'
            self._templar = None

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            if fn == 'template_file':
                return 'template_file_path'
            else:
                return None

    lookup_module = FakeLookupModule()

    # act
    result = lookup_module.run(['default_file', {'files': 'fake_file', 'paths': 'fake_path'}, 'template_file'], {})

    # assert
    assert result == ['template_file_path']

# Generated at 2022-06-11 15:31:32.103138
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:31:41.748509
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:31:51.701315
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:32:00.767130
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:32:10.946304
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockModuleExecutor(object):
        # Test for direct invocation
        def __init__(self, module, task_vars, *args, **kwargs):
            self._result = dict(
                ansible_hostname=kwargs.get('hostname'),
                ansible_check_mode=kwargs.get('check'),
            )
        def get_basedir(self):
            return '/tmp/foo'

    class MockOptions(object):
        def __init__(self, task_vars, **kwargs):
            self._variables = task_vars
            for key in kwargs:
                setattr(self, key, kwargs[key])

    class MockTemplar(object):
        def __init__(self, variables):
            self._variables = variables


# Generated at 2022-06-11 15:32:17.962713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_LookupModule_run_assertions(args, kwargs, result, should_raise):
        lu = LookupModule()
        try:
            actual_result = lu.run(*args, **kwargs)
            if should_raise:
                raise AssertionError("AnsibleLookupError was not raised")
            assert result == actual_result
        except AnsibleLookupError:
            if not should_raise:
                raise AssertionError("AnsibleLookupError was raised")

    # Test: Split terms
    # list
    terms = ['file1.txt', 'file2.txt', '/path/to/file3.txt']
    kwargs = {}
    result = ['file1.txt', 'file2.txt', '/path/to/file3.txt']
    test_LookupModule