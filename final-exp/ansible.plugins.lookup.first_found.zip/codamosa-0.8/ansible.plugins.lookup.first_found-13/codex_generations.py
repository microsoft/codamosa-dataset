

# Generated at 2022-06-11 15:22:33.081696
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockVarManager(object):

        def __init__(self, return_value):
            self.return_value = return_value

        def add_host_var(self, *args, **kwargs):
            pass

        def add_group_var(self, *args, **kwargs):
            pass

        def set_nonpersistent_facts(self, *args, **kwargs):
            pass

        def set_fact(self, key, value):
            setattr(self, key, value)

        def set_host_variable(self, *args, **kwargs):
            pass

        def get_vars(self, *args, **kwargs):
            return self.return_value


# Generated at 2022-06-11 15:22:41.370986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _dummy_find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        return subdir + '/' + fn

    terms = [
        'file1',
        'file2',
        { 'files': 'file12.txt,file11.txt', 'paths': 'path1,path2:path3,path4' },
        { 'files': 'file13.txt,file14.txt', 'paths': 'path5,path6:path7,path8' },
        { 'files': 'file15.txt,file16.txt', 'paths': 'path9,path10:path11,path12' }
    ]

    variables = {}

    lookup = LookupModule()
    lookup._find_file_in_search_path = _dummy_find_file

# Generated at 2022-06-11 15:22:52.863037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Please note that the emulated lookup is not a class but a funcion,
    because I can't mock a class method and I have to mock the function
    lookups.lookup_loader.get.

    This is because ``_lookup_plugin_loader.get()`` returns a function.
    """

    import os
    import sys
    import unittest

    import mock

    # Mock the lookup plugin loader
    lookup_plugin_loader = mock.Mock()
    loader = mock.MagicMock()
    loader.get = mock.Mock(return_value=LookupModule)
    lookup_plugin_loader.get = mock.Mock(return_value=loader)

    # Mock the class LookupBase
    LookupBase_mock = mock.Mock()
    LookupBase_mock.find_file_in

# Generated at 2022-06-11 15:22:58.487439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tm = LookupModule()
    assert tm.run([
        'test.yml',
        {'files': 'test.yml', 'paths': 'test-path'},
        'test.yml',
        {'files': 'test.yml', 'paths': 'test-path'},
    ], {}) == ['test.yml']

# Generated at 2022-06-11 15:23:03.835199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup:
    terms = [{"files": "", "paths": "./path_to/some/files"}]
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()

    # Test:
    # Expected:
    #   lookup_module to have the given attributes.
    assert lookup_module.run(terms, variables, **kwargs) == [['./path_to/some/files']]


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:23:12.870640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'files'
    l._templar = object
    l._templar.template = lambda x: x
    l.find_file_in_search_path = lambda var, sub, file, ignore: 'nothing'

    # Test with no file found, no skip
    terms = ['/tmp/file1', '/tmp/file2', '/tmp/file3']
    ret = l.run(terms, None)
    assert(ret == [])

    # Test with no file found, skip=True
    terms = [{'files': '/tmp/file1', 'paths': '/tmp', 'skip': True}, '/tmp/file2', '/tmp/file3']
    ret = l.run(terms, None)
    assert(ret == [])

    # Test with one file found

# Generated at 2022-06-11 15:23:25.235200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # pylint: disable=line-too-long
    import pytest

    test_cases = []

    # test case #1
    test_cases.append([
        ['/path/to/foo.txt'],
        dict(),
        dict(
            files=[],
            paths=[]
        ),
        dict(
            abc=['/path/to/foo.txt']
        )
    ])

    # test case #2

# Generated at 2022-06-11 15:23:34.648647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import tempfile
    import sys
    import os

    class TestModule(object):
        def __init__(self, current_directory, module_name, module_args):
            self.current_directory = current_directory
            self.module_name = module_name
            self.module_args = module_args

    tmp_config = tempfile.NamedTemporaryFile(mode='w+b')
    tmp_skip = tempfile.NamedTemporaryFile(mode='w+b')
    tmp_found = tempfile.NamedTemporaryFile(mode='w+b')
    tmp_notfound = tempfile.NamedTemporaryFile(mode='w+b')


# Generated at 2022-06-11 15:23:45.734276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list as input argument terms
    terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    variables = None
    kwargs = dict()

    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(terms, variables, **kwargs)

    assert ret is not None
    assert len(ret) == 1
    assert ret[0] == '/path/to/foo.txt'

    # Test with a dict as input argument terms
    terms = [dict(files='foo.txt', paths='/path'), dict(files='bar.txt', paths='/other/path')]
    variables = None
    kwargs = dict()

    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(terms, variables, **kwargs)



# Generated at 2022-06-11 15:23:51.695419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader()

    test = ['one', 'two', 'three']
    result, skip = l._process_terms(test, {}, {})
    assert result == ['one', 'two', 'three']
    assert skip is False

    test = ['one', {'files': 'two', 'paths': 'three'}]
    result, skip = l._process_terms(test, {}, {})
    assert result == ['one', 'two', 'three']
    assert skip is False

    test = ['one', {'files': 'two', 'paths': ['three', 'four']}]
    result, skip = l._process_terms(test, {}, {})
    assert result == ['one', 'three/two', 'four/two']
    assert skip is False


# Generated at 2022-06-11 15:24:08.026343
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import collections

    li = collections.namedtuple('LookupModule', ['find_file_in_search_path','_templar','_subdir','get_option','set_options'])

    def create_li(dict_terms, dict_kwargs):
        li.find_file_in_search_path_returns = None
        li.find_file_in_search_path_called = False
        li.find_file_in_search_path_args = []
        li.find_file_in_search_path = lambda variables, subdir, filename, *args, **kwargs: li.find_file_in_search_path_called_once(variables, subdir, filename, args, kwargs)

        li.template_called = False
        li.template_args = []
        li.template_returns

# Generated at 2022-06-11 15:24:15.532675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO:
    # test with a mock get_option and template
    # test with a mock find_file_in_search_path that fails
    # test with a mock find_file_in_search_path that finds file
    # test with a mock _process_terms that finds files
    # test with a mock _process_terms that finds no files
    # test with a mock _process_terms that finds no files and skip=True

    return

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 15:24:23.871360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test for run method of class LookupModule"""

    # create a valid path in /tmp directory
    file_path = "/tmp/sometestfile.txt"
    with open(file_path, "w") as f:
        f.write("some content")

    # call method under test
    lookup = LookupModule()
    result = lookup.run(terms=["/tmp/sometestfile.txt"], variables={}, **{})

    # TODO: make sure that result is a valid path.
    # Right now I am not sure how to implement it.
    assert result[0] == file_path

    # delete file
    os.remove(file_path)

# Generated at 2022-06-11 15:24:34.391239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.utils.unsafe_proxy import wrap_var
    else:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    lookup_module = LookupModule()

    # Check if the method fail with an invalid term
    try:
        lookup_module.run(12345, None)
        assert False, "AnsibleLookupError not raised"
    except AnsibleLookupError:
        pass

    # Check if the method fail with an invalid type in the list
    try:
        lookup_module.run([12345], None)
        assert False, "AnsibleLookupError not raised"
    except AnsibleLookupError:
        pass

    # Check if the method works with a list containing strings
   

# Generated at 2022-06-11 15:24:37.836018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._subdir = 'files'
    lookup_module.run()

# Generated at 2022-06-11 15:24:47.467305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    def mock_set_options(self, term, var_options=None, direct=None):
        self.var_options = var_options
        self.direct = direct

    lookup.set_options = mock_set_options

    # Test dict as term in run
    terms = [
        {
            'files': 'test_file',
            'paths': '/tmp/path',
            'skip': False,
        },
        {
            'files': 'test_file2',
            'paths': '/tmp/path2',
            'skip': False,
        },
    ]

    variables = {
        'test': {
            'var_options': 'test_var_options',
            'direct': 'test_direct',
        }
    }


# Generated at 2022-06-11 15:24:58.315362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [
        '/path/to/foo.txt',
        {'files': ['bar.txt'], 'paths': ['/path/to']},  # dict term mixed with regular term
        {'files': ['biz.txt'], 'paths': ['/other/path']},  # dict term only
    ]
    lu = LookupModule()
    lu._subdir = 'files'
    lu.set_options(direct={'skip': True})  # global skip to force return of empty list for all terms
    total_search, skip = lu._process_terms(test_terms)
    assert skip == True

# Generated at 2022-06-11 15:24:59.201245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-11 15:25:10.415480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._find_needle = lambda subdir, needle: None

    # set_options - use nested dict to pass settings and bypass the args parsing
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(terms={'bad_option': 'value'}, variables={})

    # run - no (file) search terms given
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(terms=[{'paths': '/some/path'}], variables={})

    # run - search term is valid but not found
    lookup_module._find_needle = lambda subdir, needle: None

# Generated at 2022-06-11 15:25:22.386018
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup LookupModule
    lookup_module = LookupModule()

    # Mock lookup_base.set_options
    lookup_base = LookupModule()
    orig_set_options = lookup_base.set_options

    def mock_set_options(self, var_options=None, direct=None):
        return orig_set_options(self, var_options, direct)

    lookup_base.set_options = mock_set_options

    lookup_module._templar = lookup_base._templar
    lookup_module.find_file_in_search_path = lookup_base.find_file_in_search_path
    lookup_module.get_option = lookup_base.get_option

    # Setup variables
    variables = {}

    # Setup arguments
    args = {'files': [], 'paths': []}

# Generated at 2022-06-11 15:25:26.990999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import collections
    assert callable(LookupModule.run)


# Generated at 2022-06-11 15:25:28.451876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No tests for method run"


# Generated at 2022-06-11 15:25:37.693950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath

    lm = LookupModule()

    # Test with a list of files and paths
    lm._subdir = 'files'
    assert lm.run(terms = [{'files': 'first,second', 'paths': '/tmp/first,/tmp/second'}],
                  variables = dict(myvar='myval'),
                  files=['first', 'second'], paths=['/tmp/first', '/tmp/second']) == []

# Generated at 2022-06-11 15:25:47.552579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()

    #with total_search check
    total_search = []
    total_search.append('/something/file1')
    total_search.append('/something/file2')
    total_search.append('/something/file3')

    #NOTE: this will not be hit, but shows how the 'global' skip var is used
    skip = False

    path = None
    path = '/something/file1'
    assert lookup_mod.run(total_search, skip) == path

    #without total_search check
    total_search = []
    skip = False

    path = None
    assert lookup_mod.run(total_search, skip) == path

# Generated at 2022-06-11 15:25:57.056572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, filename, **kwargs):
            if filename == 'test.cfg':
                return filename
            return None
    options = {'paths': '', 'files': 'test.cfg'}
    lookup = TestLookupModule(**options)
    filename = ['first_found', options]
    results = lookup.run(filename, None, **options)
    assert results == 'test.cfg'

    options = {'paths': '', 'files': 'debug.cfg'}
    results = lookup.run(filename, None, **options)
    assert results == []

# Generated at 2022-06-11 15:26:06.588735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global _mock_module_args, _mock_module_kwargs
    # Global variable value initialization
    _mock_module_args = dict(
        files=['test_file1', 'test_file2'],
        paths=['/test/path1', '/test/path2'],
        skip=True
    )

    _mock_module_kwargs = dict(
        files=['test_file1', 'test_file2'],
        paths=['/test/path1', '/test/path2'],
        skip=True
    )

    lookup_obj = LookupModule()

    # Unit test cases
    total_search, skip = lookup_obj._process_terms([], {}, _mock_module_kwargs)
    lookup_obj._subdir = 'files'
    path = lookup_obj

# Generated at 2022-06-11 15:26:14.936586
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialize class object
    LookupModule_obj = LookupModule()

    # initialize arguments to LookupModule function
    terms = [{'files': 'foo.txt', 'paths': '/tmp'}, {'files': 'foo.txt', 'paths': '/tmp'}]
    variables = {'foo': 'bar'}

    # call LookupModule function
    inout = LookupModule_obj.run(terms, variables)

    # check output of call LookupModule function
    assert inout == []

# Generated at 2022-06-11 15:26:23.978365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # dummy objects to bypass templated lookup plugin load
    class DummyTask:
        def __init__(self):
            self.basedir = None

    class DummyPlayContext:
        def __init__(self):
            self.cur_task = None

    class DummyPlay:
        def __init__(self):
            self.basedir = None
            self.cur_task = None


    class DummyEncoder:
        pass

    class DummyTemplar:
        class Template:
            def __init__(self, string):
                self.string = string

    dummmy_task = DummyTask()
    dummmy_task.basedir = "dummy_task"

    dummmy_play_context = DummyPlayContext()
    dummmy_play_context.cur_task = dumm

# Generated at 2022-06-11 15:26:35.506803
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    terms = [
        {
            "files": "foo.conf,bar.conf",
            "paths": "/tmp/production:/tmp/staging",
            "skip": True
        },
        "foo,bar",
        [
            "foo,bar",
            "baz,biz",
            "bam,foo",
        ],
        {
            "files": "foo.conf,bar.conf",
            "paths": "/tmp/production:/tmp/staging",
            "skip": False
        }
    ]
    variables = {}
    kwargs = {}

    total_search, skip = module._process_terms(terms, variables, kwargs)


# Generated at 2022-06-11 15:26:43.141900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #function to make a temporary copy of the ansible.cfg file
    #and set the lookup plugin paths to include the test directory,
    #then restore the original ansible.cfg file when the object is garbage collected
    class modify_ansible_cfg():
        def __init__(self, lookup_dir):
            self.cfgfile = os.path.join(lookup_dir, 'ansible.cfg')
            self.backup = self.cfgfile + '.bak'
            self.original_cfgfile = os.path.join(lookup_dir, '../../', 'ansible.cfg')
            shutil.copy2(self.original_cfgfile, self.backup)
            # Add the test directory to the list of lookup plugin directories

# Generated at 2022-06-11 15:27:00.777637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the functionality of the class LookupModule of lookup_plugin.py.
    """
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.plugin.get_all_plugin_loaders import get_all_plugin_loaders
    from ansible.template import Templar
    from jinja2.exceptions import UndefinedError
    from ansible.errors import AnsibleLookupError
    from ansible.template.template import AnsibleTemplate

    def get_loader_mock(loader_class):
        mock_loader = mock.create_autospec(loader_class)
       

# Generated at 2022-06-11 15:27:11.959261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule"""
    # NOTE: copied from test_template that was copied from test_copy
    #       See PR-11875

# Generated at 2022-06-11 15:27:23.229291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    import os

    dummy_hosts = [
        '192.168.1.1',
        '192.168.1.2',
        '192.168.1.3',
    ]

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=dummy_hosts)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    lookup_plugin = LookupModule()

    playbook_path = 'test_playbook.yaml'
   

# Generated at 2022-06-11 15:27:33.386692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an object of class LookupModule
    lookup_module = LookupModule()
    # Get the path of the current file
    this_file_path = os.path.dirname(os.path.realpath(__file__))
    # Create dirs and files in system, fill paths with them
    os.mkdir(os.path.join(this_file_path, "first_found_test"))
    with open(os.path.join(this_file_path, "first_found_test", "file1"), 'a') as the_file:
        the_file.write('foo\n')
    with open(os.path.join(this_file_path, "first_found_test", "file2"), 'a') as the_file:
        the_file.write('foo\n')

# Generated at 2022-06-11 15:27:44.203272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # template data
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), 'lookup_plugins'))
    vm = VariableManager()
    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, variable_manager=vm, host_list=[])
    vm.set_inventory(inventory)
    templar

# Generated at 2022-06-11 15:27:52.591886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Make sure LookupModule._return_empty function is called
    # when skip option set to True
    terms = [{'skip':True}]
    try:
        lookup.run(terms,{})
    except Exception as e:
        assert False, "Unexpected lookup exception: %s" % e
    else:
        assert True, "Unexpected success!"
    # Make sure LookupModule._return_empty function is not called
    # when skip option is not set
    terms = [{}]
    try:
        lookup.run(terms,{})
    except Exception as e:
        assert True, "Unexpected lookup exception: %s" % e
    else:
        assert False, "Unexpected success!"
    # Make sure LookupModule._return_empty function is called when
    # skip option

# Generated at 2022-06-11 15:27:57.719215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # Initialise variables to be used in this method
   test_LookupModule_run.mock = LookupModule()
   test_LookupModule_run.terms = {}
   test_LookupModule_run.variable = {}

   # Check the values returned by run method of class LookupModule
   assert test_LookupModule_run.mock.run(run.terms, run.variable, []) == []

# Generated at 2022-06-11 15:28:07.997572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = ["foo", {"files": "baz, bar", "paths": "path/to/bar"}, "second"]
    look = LookupModule()  # FIXME: mock
    look.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: os.path.join("path", "to", fn)
    assert look.run(term, {}) == [
        'foo',
        'path/to/bar',
        'path/to/baz',  # FIXME: hmmm...
        'second',
    ]
    assert look.run([term[0]], {}) == ['foo']
    assert look.run([term[1]], {}) == [
        'path/to/bar',
        'path/to/baz',
    ]

# Generated at 2022-06-11 15:28:19.918841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing=False):
            if filename == '/path/file.conf':
                return filename
            else:
                return None

    mock = TestLookupModule()

    # no options, return the first found
    total_search = ['/path/file.conf', '/no/file.conf']
    actual = mock.run(total_search, variables={}, skip=False)
    expected = ['/path/file.conf']
    assert actual == expected, 'actual: %s expected: %s' % (actual, expected)

    # raise exception if no file found
    total_search = ['/no/file.conf', '/no/file.conf']

# Generated at 2022-06-11 15:28:27.260553
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Note: The below tests are not complete, many more are likely needed
    # however the code is currently much too complex to be easily unit tested

    # TODO: split this unit test up, it is very long and confusing

    # Test: Test that kwargs with a list results in each element being processed by themselves
    #       skipping any other arguments passed
    lookup_module = LookupModule()
    search, skip = lookup_module.run(
        terms=[
            {
                'skip': True,
                'paths': ['path1'],
                'files': 'file1'
            },
            {
                'skip': False,
                'paths': ['path2'],
                'files': 'file2'
            },
        ],
        variables={},
    )

# Generated at 2022-06-11 15:28:40.554680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:28:50.787979
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:29:02.126950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'paths': '/path1:/path2', 'files': 'file1.txt,file2.txt'},
             {'paths': 'path3', 'files': 'file3.txt'}]
    variables = {}
    kwargs = {}
    lm = LookupModule()
    lookups = lm.run(terms, variables, **kwargs)
    path = '/path1/file1.txt'
    assert lookups[0] == path
    path = '/path3/file3.txt'
    assert lookups[1] == path

#from ansible.utils.color import stringc
from ansible.plugins.lookup.first_found import LookupModule, test_LookupModule_run
from ansible.plugins.lookup.first_found import _split_on
import pytest


# Generated at 2022-06-11 15:29:13.553927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule and assign params to it
    lookup_module_instance = LookupModule()
    lookup_module_instance._subdir = 'files'

    # call method run
    # NOTE:
    #   - the value returned by lookup_module_instance.run() depends on the
    #     current directory in which plugin get loaded
    #     the relative path is relative to the directory in which the plugin
    #     gets loaded
    #   - by now the plugin is not loaded by ansible framework and relative
    #     path is relative to the directory in which the file lookups/first_found
    #     is located.
    #       - relative path in file __init__.py
    #       - relative path in file first_found.py
    #   - the test case can be considered as successfull only if the method run
    #    

# Generated at 2022-06-11 15:29:24.878764
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        dict(paths=[
            '/path/to/foo/',
            '/path/to/bar/',
            '/path/to/biz/',
        ],
             files=['foo.txt', 'bar.txt', 'biz.txt']),
        dict(paths=[
            '/path/to/foo/',
            '/path/to/bar/',
            '/path/to/biz/',
        ],
             files=['foo.txt', 'bar.txt', 'biz.txt']),
    ]
    results = [
        '/path/to/foo/foo.txt',
        '/path/to/foo/foo.txt',
    ]

    for term, result in zip(terms, results):
        lookup = LookupModule()
        ansible_vars = dict()

        found = lookup.run

# Generated at 2022-06-11 15:29:34.455856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test LookupModule._run()."""

    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    # Create LookupModule object
    lookup_module = LookupModule()

    # Declare test input

# Generated at 2022-06-11 15:29:43.804196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    lm = LookupModule()

    # check _process_terms
    terms = [{
        'files': 'foo',
        'paths': 'path'
    }, [
        'bar'
    ], {
        'files': 'foo',
        'paths': 'path'
    }]

    search_list, skip = lm._process_terms(terms, {}, {})
    assert len(search_list) == 5
    assert 'foo' in search_list
    assert skip is False

    # check _run
    res = lm.run(terms, {}, {})

    assert res == [json.dumps('foo')]

# Generated at 2022-06-11 15:29:50.934280
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing the method run of class LookupModule

    class TestLookupModule(LookupModule):

        def __init__(self, **kwargs):
            super(TestLookupModule, self).__init__(**kwargs)

        # Mock the method find_file_in_search_path of class LookupModule
        def find_file_in_search_path(self, variables, file_paths, file_name, ignore_missing):

            # Testing list of file_name is returned when one of the file is found

            path = None

            file_name = variables if file_name is None else file_name

# Generated at 2022-06-11 15:29:53.091070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['a', 'b', 'c']
    assert module.run(terms, {}) == []

# Generated at 2022-06-11 15:30:04.668042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: this 'lookup' is called in many plugins and sorting out the
    # 'global' skip/errors combination will not be easy as many plugins
    # can call it with different variable state in the executor
    #
    # eg: list of terms (list of files) can be passed that can have a skip parameter
    # but they will be searched one by one, so any skip true will cause it to return.
    #
    # in the case of only a list of files, all will be searched, but any error
    # faced that is not file not found will cause the lookup to error.
    #
    # in the case of a dict (that can hold a list of files), skip must be set
    # in a 'global way' but skip=True will cause errors to be ignored, as well as
    # no file found errors.
    pass

# Generated at 2022-06-11 15:30:41.096377
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:30:45.647877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  files = 'a.yml'
  paths = '.'
  term_dict = {'files': files, 'paths': paths}
  terms = [term_dict]
  variables = None
  kwargs = {}
  lookup_module = LookupModule()
  lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-11 15:30:56.626786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()
    lookup_mock._templar = object()

    # first test: no terms supplied, so this should raise exception
    try:
        lookup_mock.run(terms=[])
        assert False
    except AnsibleLookupError as err:
        assert "Must define a file or files to search for" in str(err)

    # second test: one invalid term supplied, so this should raise exception
    try:
        lookup_mock.run(terms=[{}])
        assert False
    except AnsibleLookupError as err:
        assert "Invalid term supplied, can handle" in str(err)

    # third test: multiple invalid terms supplied, so this should raise exception

# Generated at 2022-06-11 15:31:05.090214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Testing lookup `first_found` method run"""
    # Setup test data
    #
    # NOTE:
    # - This test method only test run() method of class LookupModule at this time.
    # - Parameters do not have any effects on run() method at this time.
    # - Values of all parameters should be matched to the expected result.
    #
    # Parameters and their values are:
    #   - terms: ["/tmp/test_files/a_file_does_not_exist"]
    #   - variables:
    #   - **kwargs: {
    #     "files": "file_does_not_exist",
    #     "paths": "/tmp/test_files",
    #     "skip": "False"
    #   }

    # Obtain values of parameters

# Generated at 2022-06-11 15:31:16.153464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module_run('first_found', LookupModule, expected_results={
        'basic_test': ['/root/test'],
        'mixed_list_test': ['/root/test2'],
        'skip_test': None,
        'list_with_dict': ['/root/test2'],
        'dotfile_test': ['/root/.dotfile'],
        'path_test': ['/root/path/test'],
        'path_dict_test': ['/root/path/test'],
        'files_in_path_test': ['/root/path/test/one'],
        'path_in_files_test': ['/root/path/test2'],
        'path_in_files_dict_test': ['/root/path/test2'],
    })
# Unit

# Generated at 2022-06-11 15:31:25.855993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    def _fixture_template(lookup, template, variables=None, include_missing=False, omit_unknown=False,
                          escape_backslashes=False, language='jinja2', loader=None):
        # https://github.com/ansible/ansible/blob/devel/lib/ansible/parsing/dataloader.py#L528-L537
        # test files in first_found/lookup_templates/
        variables = variables or {}
        loader = loader or DataLoader()

# Generated at 2022-06-11 15:31:33.974485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.plugins.lookup.first_found import LookupModule

    lookup = LookupModule(loaders=[], basedir='')

    ###############
    # file        #
    ###############
    terms = ['file']
    ret = lookup.run(terms, None, {}, [])
    assert ret == []

    terms = ['file']
    ret = lookup.run(terms, None, {}, ['file'])
    assert ret == ['file']

    terms = ['file']
    ret = lookup.run(terms, None, {}, ['file', 'file2'])
    assert ret == ['file']

    terms = ['file1', 'file2']
    ret = lookup.run(terms, None, {}, [])
    assert ret == []


# Generated at 2022-06-11 15:31:43.702845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Empty Parameters
    terms = []
    variables = {}
    skip = False

    total_search, skip = lookup._process_terms(terms, variables, {})

    assert skip == False
    assert total_search == []

    # Dictionary with no keys
    terms = [{}]
    variables = {}
    skip = False

    total_search, skip = lookup._process_terms(terms, variables, {})

    assert skip == False
    assert total_search == []

    # Single String
    terms = ['foo']
    variables = {}
    skip = False

    total_search, skip = lookup._process_terms(terms, variables, {})

    assert skip == False
    assert total_search == ['foo']

    # Single String with skip=True
    terms = ['bar']
    variables = {}

# Generated at 2022-06-11 15:31:53.617753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    import pytest

    class my_tmplr(object):
        def _init__(self, fail_on_undefined=False, undefined_missing_variables=False, follow_imports=True):
            self._fail_on_undefined = fail_on_undefined
            self._undefined_missing_variables = undefined_missing_variables
            self._follow_imports = follow_imports


# Generated at 2022-06-11 15:32:02.382648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    terms = []

    # NOTE: this test shows an error in the logic of the run method.
    # if used like 'first_found(dict1, dict2)' then dict2 will overwrite dict1
    # if used like 'first_found(dict1, dict1)' then dict1 will overwrite dict1
    # this means that sometimes 'files' is used, sometimes 'paths' is used and
    # sometimes both are used.

    # test first_found(dict1, dict1)
    terms.append({'paths': './test/', 'files': 'file1'})
    terms.append({'paths': './test/', 'files': 'file1'})

    module = LookupModule()
    module.set_runner({})
    result = module.run(terms=terms, variables={})