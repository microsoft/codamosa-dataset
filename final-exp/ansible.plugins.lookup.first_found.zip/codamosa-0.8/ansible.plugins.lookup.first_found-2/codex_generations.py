

# Generated at 2022-06-11 15:22:38.073209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.lookup import LookupModule
    from ansible.template import Templar
    from ansible.compat.tests import mock
    from io import StringIO
    import os

    class VarManager:
        def __init__(self):
            self.vars = dict()

        def get_vars(self, loader, path, entities, cache=True):
            pass

    with mock.patch.object(os, 'getcwd', return_value=''):
        varmgr = VarManager()
        templar = Templar(loader=None, variables=varmgr.vars)

        # Test with empty terms
        actual_result = LookupModule().run([], variables=varmgr.vars)
        assert actual_result is None

        # Test with empty files

# Generated at 2022-06-11 15:22:46.065626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re

    class MockStringTemplate:
        def __init__(self):
            self.template = []

        def template(self, fn):
            return fn
    templar = MockStringTemplate()

    class MockPluginOptions:
        def __init__(self):
            self.get_option = []

        def get_option(self, key):
            return None

    class MockLookupModule(LookupModule):
        def __init__(self):
            self._templar = templar
            self.get_option = MockPluginOptions()


# Generated at 2022-06-11 15:22:52.712408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()

    # case 0: no file
    term1 = '*.conf'
    term2 = {'files': 'foo*.conf', 'paths': '/tmp/production'}
    term3 = {'files': 'bar*.conf', 'paths': '/tmp/staging'}
    terms = [term1, term2, term3]
    expected = ['/tmp/production/foo1.conf']
    obj.run(terms, variables={}, skip=True)

# Generated at 2022-06-11 15:23:02.536987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = [
        'a file',
        'other file',
        {'files': 'file1 file2 file3', 'paths': '/tmp/path'},
        'another file',
        {'files': ['f1', 'f2', 'f3'], 'paths': ['/path1', '/path2']},
        ['f4', 'f5'],
        {'files': 'f6', 'paths': 'path3:path4'},
    ]
    vars = {}
    kwargs = {'run_once': True}
    ret_val = lm._process_terms(terms, vars, kwargs)
    assert(ret_val[1] is False)

# Generated at 2022-06-11 15:23:12.244188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create mock versions of the required data items
    mock_variables = {
        'groups': {
            'first_group': ['first_host'],
            'second_group': ['second_host'],
            'last_group': ['last_host'],
        },
    }

    # Create an instance of the class
    test_instance = LookupModule()

    # Test the use of this class to find a real file
    test_result = test_instance.run(['ansible.cfg'], mock_variables)
    assert test_result[0] == '/etc/ansible/ansible.cfg'

    # Test the use of this class to find a file that does not exist

# Generated at 2022-06-11 15:23:16.640158
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:23:27.641465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This method tests the LookupModule run method
    """
    # pylint: disable=unused-argument
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-locals

    test_paths = ['/tmp/testing/first_found',
                  '/tmp/testing/first_found/files/test/',
                  '/tmp/testing/first_found/vars/test/',
                  '/tmp/testing/first_found/other/test/']

    # create lookup plugin instance
    lookup_instance = LookupModule()

    # create a file which will be used as a test/result
    test_path_file = "%s/first_found_testfile" % test_paths[0]

# Generated at 2022-06-11 15:23:34.952786
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # file 'test.tmpl' is present in ../files/test.tmpl
    # file 'test.tmpl' is present in ../files/test1.tmpl
    # file 'test.htm' is present in ../files/test.htm

    lm = LookupModule()

    # Test _process_terms with different directories
    lm._basedir = os.path.join(os.path.dirname(__file__), '..', 'files')
    search, skip = lm._process_terms([{'files': 'test.htm,test.tmpl', 'paths': ''}], {}, {})
    assert search == ['test.htm', 'test.tmpl'], search


# Generated at 2022-06-11 15:23:37.686998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = LookupModule()
    a.run(terms=['foo.txt', 'bar.txt'], variables=['files', 'path'])

# Generated at 2022-06-11 15:23:42.254600
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This is a unit test and is not to be used in production
    # it is only to help with the conversion to pytest and remove the dependency on ansible.
    # it is also to provide a template for how to write a test for a lookup plugin.

    # code required to properly fake the state of a task, just for testing

    class FakeTask(object):
        def __init__(self):
            self._role = None
            self._play = None

        def _get_parent_attribute(self, key):
            self._play = dict(ROLE_PATH='/some/fake/path', ROLE_NAME='a fake role')
            return self._play[key]


# Generated at 2022-06-11 15:23:49.865588
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert LookupModule(None, None, None)._split_on(['foo,bar', 'baz', 'moo'], [',', ':']) == ['foo', 'bar', 'baz', 'moo']



# Generated at 2022-06-11 15:23:58.124871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This function tests the run method of class LookupModule.
    """

    fn = 'testfirstfound.txt'
    lookup_module = LookupModule()

    # test with no parameters passed
    assert lookup_module.run([],{}) == [], "Test with no parameters failed"

    # test with single parameter
    assert lookup_module.run([fn],{}) == [], "Test with single parameter failed"

    # test with a list of parameters
    assert lookup_module.run([fn,fn],{}) == [], "Test with a list of parameters failed"

# Generated at 2022-06-11 15:23:59.687568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement test case
    pass


# Generated at 2022-06-11 15:24:07.062516
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={'_terms': ['foo.bar']})

    # mock
    lookup._templar.template = lambda x: x
    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: 'foo.bar'

    # exercise
    result = lookup.run(lookup._terms, None)

    # verify
    assert result == ['foo.bar']


# Generated at 2022-06-11 15:24:18.024896
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: the following tests are skipped as they are expected to fail
    # and are currently in a state which will tell us what is broken
    # in the module and/or tests. this is to avoid having lots of
    # 'fake' tests just to cover code.

    # NOTE: the module has an inconsistent call interface.
    # if you use a dict as term then it will parse only one entry
    # and ignore all others. thus the 'same' behavior can be acheived
    # using a list of dict's - which is not expected to a human.
    #
    # NOTE: there are also many hard coded fallbacks which means
    # that the same input can give different results.

    lookup_module = LookupModule()

    #############
    # _process_terms
    #############

    # NOTE: needs fix for path, file and skip handling

# Generated at 2022-06-11 15:24:25.250743
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: does not test skip
    lu = LookupModule()
    lu._templar = DictTemplar()

# Generated at 2022-06-11 15:24:35.360643
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: finish this
    # get lookup module
    lookup = LookupModule()

    # TODO: fix this test to do more
    # get test data
    #test_data = load_test_data("test_LookupModule_get_all_keys.json")

    # validate test data
    #assert type(test_data) is dict

    # TODO: create test
    def test_get_all_keys(self):
        pass

    # set class attribute
    #LookupModule.test_data = test_data
    #LookupModule.test_data = None

    # get test data
    #test_data = LookupModule.test_data

    # iterate over each test item
    #for test_item in test_data:

        # TODO: create test
        #result = test_item['result

# Generated at 2022-06-11 15:24:46.380835
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:24:52.382970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {
        'files': ['/path/to/foo.txt'],
        'paths': ['/extra/path']
    }
    total_search = ['/path/to/foo.txt']
    skip = False
    lookup_module = LookupModule()
    assert lookup_module._process_terms([params], None, None) == (total_search, skip)

# Generated at 2022-06-11 15:25:01.733178
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    from ansible.module_utils._text import to_bytes
    # Just a few of the many possible values. See some of the tests below.
    f1 = to_bytes('random_file')
    f2 = to_bytes('another_file')
    terms = [ f1, f2 ]
    variables = {}
    cwd = '/dummy_cwd'
    path = '/dummy_path'
    mpath = '/dummy_path/' + f1
    fn = '/dummy_path/' + f2
    subdir = 'files'
    searchpath = '/dummy_cwd/.'
    skip = False

    # Create a mock class to replace the actual LookupBase
    mock_LookupBase = type('MockLookupBase', (object,), dict())
    # Create a class

# Generated at 2022-06-11 15:25:20.417846
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term1 = "lookup_data"
    term2 = [term1, "more_data"]
    terms = [term1, term2]

    variables = "variables"
    kwargs = "kwargs"

    find_file_in_search_path_orig = LookupModule.find_file_in_search_path

    class LookupModuleStub(LookupModule):

        def __init__(self):
            self.files = ""
            self.paths = ""

        def _process_terms(self, terms, variables, kwargs):
            return "total_search", False

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            if fn == "lookup_data":
                return "lookup_data_found"
            return None



# Generated at 2022-06-11 15:25:21.872599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    # TODO: write the test
    return

# Generated at 2022-06-11 15:25:29.246491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Set _terms
    lm._terms = ['file1', 'file2']

    # We need a _filename here to avoid looking for it.
    lm._filename = 'somefile'

    # Create a _loader and test the exception
    lm._loader = None

    assert lm.run(lm._terms) == [], '_loader cannot be None.'

    # Create a _loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    lm._loader = DataLoader()
    lm._templar = VariableManager()

    # Make sure that the find_file_in_path_dir behaves correctly

# Generated at 2022-06-11 15:25:35.914304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display

    display = Display()

    lm = LookupModule()
    test_index = 0
    expected_path = ""
    excepted_error = None

    # A
    test_index += 1
    # Assign
    terms = [{
        'files': "$HOME/foo.txt",
        'paths': '/tmp',
        'skip': True
    }, {"files": "bar.txt"}]
    # Run
    actual_path = lm.run(terms, {})
    # Test

# Generated at 2022-06-11 15:25:43.681920
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule_run = LookupModule.run

    assert LookupModule_run([{'files': ['/foo'], 'skip': False}], {}, {}) == ['/foo']
    assert LookupModule_run([{'files': ['/foo'], 'skip': True}], {}, {}) == []

    assert LookupModule_run(['--files=/foo'], {}, {}) == ['/foo']
    assert LookupModule_run(['--files=/foo', '--skip'], {}, {}) == []

    assert LookupModule_run([{'files': ['/foo', '/baz']}], {}, {}) == ['/foo', '/baz']

# Generated at 2022-06-11 15:25:51.919928
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: this should be a better unit test

    # NOTE: this is an over simple test, does not check dict term, or complex term mixes or skip behaviour

    # TODO: mock
    # NOTE: will fail on missing _find_file_in_path as not mocked, would need to mock/mock_method
    lm = LookupModule()
    lm.set_options(direct={'paths': './', 'files': 'testfile'})

    try:
        # NOTE: return is a list
        assert lm.run([], {}) == ['./testfile']
        assert lm.run(['testfile', 'testfile2'], {}) == ['./testfile']
    except AnsibleLookupError:
        pass

# Generated at 2022-06-11 15:25:54.045228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(["default_foo.conf", "{{ ansible_virtualization_type }}_foo.conf"])

# Generated at 2022-06-11 15:26:05.266439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.plugins.lookup.first_found import LookupModule
    lookupModule = LookupModule()
    file_name = os.path.basename(__file__)
    file_path = os.path.split(__file__)[0]
    lookupModule._subdir = 'files'
    TestVariables = namedtuple('TestVariables', 'files')
    file_path = os.path.join(file_path, "files")
    lookupModule.basedir = file_path
    test_vars = TestVariables(['*'])
    result = lookupModule.run(terms=[file_name], variables=test_vars, skip=False)
    assert result
    assert result[0].endswith(file_name)

# Generated at 2022-06-11 15:26:12.937478
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:26:22.940576
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    cwd = os.getcwd()
    files_path = os.path.join(cwd, 'my_files_dir')
    files_path_other = os.path.join(cwd, 'my_other_files_dir')

# Generated at 2022-06-11 15:26:30.151069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:26:34.778280
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestClass(LookupModule):
        def find_file_in_search_path(self, variables, subdir, filename, ignore_missing=False):
            self.filename = filename
            self.subdir = subdir
            self.variables = variables
            return None

    lookup_module = TestClass()

    # Test processing of files
    files = ['file1', 'file2']
    paths = ['path1', 'path2']
    terms = [{'files': files, 'paths': paths}]
    terms, skip = lookup_module._process_terms(terms, variables=dict(), kwargs=dict())
    assert skip is False
    assert len(terms) == len(files) * len(paths)

# Generated at 2022-06-11 15:26:42.317247
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.path import unfrackpath

    from ansible.plugins.lookup.first_found import LookupModule

    _ = to_bytes
    kw = AnsibleBaseYAMLObject

    # get test dir
    current_test_dir = os.path.dirname(os.path.abspath(__file__))
    oldwd = os.getcwd()
    os.chdir(current_test_dir)

    # setup and create some test files
    os.mkdir('fake_dir')

# Generated at 2022-06-11 15:26:43.460863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run()


# minimal test

# Generated at 2022-06-11 15:26:51.420575
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:27:02.030999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    import errno
    from contextlib import contextmanager

    from ansible.utils.path import unfrackpath

    from ansible.plugins.lookup.first_found import LookupModule

    @contextmanager
    def cd(new_dir, cleanup=lambda: True):
        prev_dir = os.getcwd()
        os.chdir(os.path.expanduser(new_dir))
        try:
            yield
        finally:
            os.chdir(prev_dir)
            cleanup(prev_dir)

    @contextmanager
    def mkdtemp(*args, **kwargs):
        tmpdir = tempfile.mkdtemp(*args, **kwargs)
        old_dir = os.getcwd()
        os.chdir(tmpdir)


# Generated at 2022-06-11 15:27:13.070875
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:27:14.538329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

# Generated at 2022-06-11 15:27:26.067149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    l = LookupModule()
    l._subdir = "my_subdir"

    pc = PlayContext()
    l._templar = Templar(loader=None, variables=pc.variables)

    def _test(terms, expected):
        actual = l.run(terms, pc.variables)
        assert actual == expected, "expected:\n\n%s\n\nbut got\n\n%s\n\nfor terms %s" % (expected, actual, terms)

    test_path = "/path/to/foo.txt"
    test_file = "foo.txt"
    test_path2 = "/path/to/biz.txt"
    test_file2 = "bar.txt"

    _test

# Generated at 2022-06-11 15:27:35.258182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Set up for test
    
    # Expected result
    expected = ["new data"]
    
    # Service under test
    # LookupModule is a subclass of ModuleLoader so it has to be mocked as well

    class MockModuleLoader:
        def __init__(self, *args, **kwargs):
            pass

    class MockTemplar:
        def template(self, fn):
            return "new data"

    class MockLookupBase(LookupModule, MockModuleLoader):
        def __init__(self, *args, **kwargs):
            pass

    lookup_base = MockLookupBase()
    lookup_base._templar = MockTemplar()
    
    # Actual result

# Generated at 2022-06-11 15:27:57.461286
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import unittest

    # Mock all ansible modules, since we don't want to depend on any of them
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollectorFallback
    from ansible.module_utils.facts.system.distribution import DistributionFactCollectorRedhat
    from ansible.module_utils.facts.system.distribution import DistributionFactCollectorSuSE
    from ansible.module_utils.facts.system.distribution import DistributionFactCollectorWindows
    from ansible.module_utils.facts.system.distribution import DistributionFactCollectorAIX

# Generated at 2022-06-11 15:28:07.774712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock of LookupModule
    class MockLookupModule(LookupModule):
        def __init__(self, basedir=None):
            pass

        # Mock to get the 'run' method of the class LookupModule
        def get_run(self, terms, variables, **kwargs):
            return self.run(terms, variables, **kwargs)

        # Mock to get the '_process_terms' method of the class LookupModule
        def get_process_terms(self, terms, variables, **kwargs):
            return self._process_terms(terms, variables, kwargs)

    # Test Case 1:
    # Test the 'run' method with two object type list without files ans paths
    # and files ans paths with a list of only one file and one path

    lookup_obj = MockLookupModule()

    # Test Case

# Generated at 2022-06-11 15:28:19.715287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestVars(object):
        def __init__(self, hostvars, vars_copy={}):
            self._hostvars = hostvars
            self._vars = vars_copy
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            if include_hostvars:
                return dict(self._vars, **self._hostvars)
            else:
                return self._vars

    lookup_module = LookupModule()

    def mock_find_file_in_search_path(variables, subdir, fn, ignore_missing):
        if fn == total_search[0]:
            return '/' + os.path.join(subdir, fn)


# Generated at 2022-06-11 15:28:27.134106
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class ansible_vars:
        ansible_virtualization_type = 'lxc'


# Generated at 2022-06-11 15:28:38.064678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [
        'foo.yml',
        'baz.yml'
    ]
    test_variables = {
        'hostvars': {
            'host1': {
                'role': 'master'
            }
        },
        'group_names': ['master', 'slave'],
        'groups': {
            'master': {
                'hosts': ['host1', 'host1'],
                'vars': {
                    'master_role': 'master',
                    'slave_role': 'slave'
                }
            },
            'slave': {
                'hosts': ['host2', 'host2'],
                'vars': {
                    'master_role': 'slave',
                    'slave_role': 'master'
                }
            }
        }
    }
   

# Generated at 2022-06-11 15:28:39.101268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(__file__)

# Generated at 2022-06-11 15:28:49.963471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()

    # Test when skip=True
    lookup_mod.set_options(dict(files='file', paths='path', skip=True))
    lookup_mod.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None
    assert lookup_mod.run('terms', 'variables') == []

    # Test when skip=True and look_in_plugin_dirs=False
    lookup_mod.set_options(dict(files='file', paths='path', skip=True, look_in_plugin_dirs=False))
    lookup_mod.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None
    assert lookup_mod.run('terms', 'variables') == []

    # Test when skip=False
    lookup_

# Generated at 2022-06-11 15:29:01.568790
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # _split_on testing
    assert _split_on(",") == []
    assert _split_on(", , ") == []
    assert _split_on("a,b") == ["a", "b"]
    assert _split_on(",a,b") == ["a", "b"]
    assert _split_on("a,b,") == ["a", "b"]
    assert _split_on(",") == []
    assert _split_on(",a,") == ["a"]
    assert _split_on(",,") == []
    assert _split_on(", , ,") == []
    assert _split_on(['a,b,c']) == ["a", "b", "c"]

# Generated at 2022-06-11 15:29:13.331028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-11 15:29:24.785926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""
    class TestException(Exception):
        pass

    # We are not testing the class itself, but the run method
    # In case it tries to access anything other than what is passed in
    # as parameter we raise an exception

    LookupModule.get_option = lambda *args, **kwargs: "nope"
    LookupModule._templar = lambda *args, **kwargs: "nope"
    LookupModule.find_file_in_search_path = lambda *args, **kwargs: "nope"
    LookupModule._subdir = "files"

    def fake_get_option(*args, **kwargs):
        if args[1] == "skip":
            return "skip"
        raise TestException("called")


# Generated at 2022-06-11 15:29:50.794583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Tests not implemented yet"

# Generated at 2022-06-11 15:30:02.113100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ##############################################
    # run unit test for method LookupModule.run #
    ##############################################
    import unittest
    import copy
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.lookup import LookupBase, AnsibleLookupError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Util class to compare two items.
    class EqualUtil(object):
        def __init__(self):
            pass

        # Compare two item.
        # @param left: Item to be compared.
        # @param right: Item to be compared.
        # @return: True if two item are equal.

# Generated at 2022-06-11 15:30:12.007966
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    t = LookupModule()

    # only test one entry
    total_search, skip = t._process_terms(terms=['files_dir'], variables={}, kwargs={})
    assert total_search == ['files_dir']
    assert skip is not True

    # test one entry as dict
    total_search, skip = t._process_terms(terms=[{'files': 'test1.txt', 'paths': 'test_path'}], variables={}, kwargs={})
    assert total_search == ['test_path/test1.txt']
    assert skip is not True

    # test one entry with multiple files
    total_search, skip = t._process_terms(terms=[{'files': 'test1.txt, test2.txt', 'paths': 'test_path'}], variables={}, kwargs={})

# Generated at 2022-06-11 15:30:22.539579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test term definition
    # Test mix between string, dictionary and list
    terms = [
        'file1',
        {'files': ['file2', 'file3']},
        ['file4', 'file5']
    ]

    # Test default options, same behavior as previous function
    variables = {}
    kwargs = {}
    total_search, skip = module._process_terms(terms, variables, kwargs)
    assert isinstance(total_search, list)
    assert len(total_search) == 5
    assert isinstance(skip, bool)
    assert skip == False
    assert total_search == ['file1', 'file2', 'file3', 'file4', 'file5']

    # Test default options, same behavior as previous function
    # Adding a global paths in kwargs


# Generated at 2022-06-11 15:30:23.656840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:30:31.081136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l._subdir = 'files'
    returned = l.run(terms=['test.txt', '/notfound'],
                     variables={'test_var': 'test.txt'},
                     paths=['/path1', 'path2'])

    assert returned[0] == '/path1/test.txt'

    returned = l.run(terms=['test.txt', '/notfound'],
                     variables={'test_var': 'test3.txt'},
                     paths=['/path1', 'path2'])

    assert returned[0] == '/path1/test3.txt'


# Generated at 2022-06-11 15:30:34.326621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = LookupModule()
    terms = [{'files': 'master.cfg,dev.cfg', 'paths': '~,.'}, {'files': 'main.cfg', 'skip': False}]
    r.run(terms, {})

# Generated at 2022-06-11 15:30:41.095450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This isn't meant to actually run, but only test the run method
    # of the LookupModule class.
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.run([
        'tests/test.ini',
        {},
        ['tests/test.ini', {'paths': 'tests'}],
    ], {}) is None

# Generated at 2022-06-11 15:30:47.967434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader(None)
    l._templar.template_vars = {}
    l._templar.set_available_variables(l._templar.template_vars)

    files = ["foo.txt"]
    paths = ["/tmp"]
    kwargs = {'files': files, 'paths': paths}
    terms = [{'files': files, 'paths': paths}]
    terms = [terms]
    paths = l.run(terms, l._templar.template_vars, **kwargs)

    if not paths:
        raise AssertionError("No files found")

# Generated at 2022-06-11 15:30:58.000069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    # First test with missing file
    b_terms = ['non-existing_file']
    b_kwargs = dict()
    b_variables = dict()
    b_loader = DataLoader()
    b_lookup_plugin = LookupModule()
    assert b_lookup_plugin.run(b_terms, b_variables, **b_kwargs) == []

    # Then test with existing file
    c_terms = ['test/ansible/test_lookup.py']
    c_kwargs = dict()
    c_variables = dict()
    c_loader = DataLoader()
    c_lookup_plugin = LookupModule()

# Generated at 2022-06-11 15:32:00.265312
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: the class is re-instantiated for each test, this prevents problems
    # with the 'global' skip option.
    class MyLookupModule(LookupModule):
        MOCK_FILES = {
            os.path.join('/foo', 'bar.txt'): '',
            os.path.join('/foo', 'baz.txt'): '',
        }

        MOCK_MODULES = {'ansible.plugins.lookup.first_found': (None, None)}

        def __init__(self):
            self._subdir = 'files'
            self.find_file_in_search_path = lambda self, variables, subdir, fn, ignore_missing=False: self.MOCK_FILES.get(fn, None)


# Generated at 2022-06-11 15:32:10.425057
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _mock_find_file_in_search_path(variables, subdir, fn, ignore_missing):
        return fn

    def _mock_template(fn):
        return fn

    lookup_module = LookupModule()
    lookup_module._subdir = 'test_subdir'
    lookup_module._templar = MockTemplar()
    lookup_module._templar.template = _mock_template
    lookup_module.find_file_in_search_path = _mock_find_file_in_search_path


# Generated at 2022-06-11 15:32:17.286788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'files': 'bar.conf', 'paths': '/etc/ansible'},
        {'files': 'foo.conf', 'paths': '/etc/ansible/:local_path', 'skip': True},
        {'files': 'baz.yaml', 'paths': 'ansible_path'},
        {'files': 'bar_2.txt', 'paths': '/etc/ansible'}
    ]
    variables = {}
    lookup = LookupModule()
    files = lookup.run(terms, variables, ignore_missing=True)
    assert files == ['/etc/ansible/bar.conf'], "lookup return is wrong, should be ['/etc/ansible/bar.conf']"


# Generated at 2022-06-11 15:32:27.374295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_lookup = LookupModule()
    terms = ['{{ ansible_virtualization_type }}_foo.conf', 'default_foo.conf']
    variables = dict()
    variables['ansible_virtualization_type'] = 'kvm'
    path = file_lookup.run(terms,variables)
    assert(path == ['kvm_foo.conf'])
    variables['ansible_virtualization_type'] = 'unknown_type'
    path = file_lookup.run(terms,variables)
    assert(path == ['default_foo.conf'])
    variables['ansible_virtualization_type'] = 'kvm'
    terms = ['foo']
    path = file_lookup.run(terms,variables)
    assert(path == ['foo'])
    variables = dict()
    path = file