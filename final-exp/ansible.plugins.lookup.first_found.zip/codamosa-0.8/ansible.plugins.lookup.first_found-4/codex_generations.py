

# Generated at 2022-06-11 15:22:34.564238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get a template to test with
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=DataLoader())
    variables = VariableManager()

    # set options
    files = ['test1', 'test2', 'test3']
    paths = ['test1', 'test2', 'test3']

    # execute with options
    lookup_plugin = lookup_loader.get('first_found')
    lookup_plugin.set_options(var_options=variables, direct={'files': files, 'paths': paths})
    result = lookup_

# Generated at 2022-06-11 15:22:44.348007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set it up
    terms = [
        "vars/foo.yml",
        "vars/default.yml"
    ]
    variables = {}
    kwargs = {
        "skip": False,
        "errors": "strict",
    }
    lookup_module = LookupModule()

    # Call first_found.LookupModule.run
    result = lookup_module.run(terms, variables, **kwargs)

    # Make assertions
    assert result == [
        "/Users/svdab/Projects/ansible/lib/ansible/plugins/lookup/first_found/vars/default.yml"
    ]

    # Set it up
    terms = [
        "vars/foo.yml",
        "vars/default.yml"
    ]
    variables = {}

# Generated at 2022-06-11 15:22:55.665180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lm = LookupModule()
    
    # method run is called by a template by ansible
    def _test_run(terms, variables=None, **kwargs):
        
        if variables is None:
            variables = {}
        
        lm._connection = None
        lm.set_loader()
        lm._loader_backup = lm._loader
        lm._templar = lm._loader.load_basedir(basedir='.')
        
        return lm.run(terms, variables, **kwargs)
    
    # 1st test

# Generated at 2022-06-11 15:23:04.060865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    TODO: Clean up the below test
    """
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, variables=combine_vars(basic.AnsibleModule(argument_spec={}).params, {}))
    lm = LookupModule(templar=templar)
    lm._loader = templar._loader

    # Test 1
    terms = [None]
    lm.run(terms, {})

    # Test 2
    terms = ['some_file.conf']
    lm.run(terms, {})

    # Test 3
    terms = ['some_file.conf', 'some_other_file.conf']

# Generated at 2022-06-11 15:23:12.973775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    lookup = LookupModule()
    mock_loader = MagicMock()
    mock_loader.get_basedir.return_value = 'test/basedir'

    # Test with terms being a string
    assert lookup.run("foo.txt", {}) == ['test/basedir/files/foo.txt'], 'Returned unexpected value'

    # Test with terms being a list with one string
    assert lookup.run(['foo.txt'], {}) == ['test/basedir/files/foo.txt'], 'Returned unexpected value'

    # Test with terms being a dict with two strings

# Generated at 2022-06-11 15:23:19.339144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # See https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/__init__.py#L243
    lookup = LookupModule()
    lookup.set_options(dict(first_found="test"))
    results = lookup.run([ "/etc/passwd" ], [], skip=True)
    assert results == []

# Generated at 2022-06-11 15:23:29.616364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    ret = t.run( terms = [{"paths":["/usr/local/bin"],"files":["ls"]}], variables={}, skip=False)
    assert ret == ['/usr/local/bin/ls'] or ret == []
    ret = t.run( terms = [{"paths":[],"files":["ls"]}], variables={}, skip=False)
    assert ret is None
    ret = t.run( terms = ["ls"], variables={}, skip=False)
    assert ret == ['/usr/local/bin/ls'] or ret == []
    try:
        ret = t.run( terms = ["foo"], variables={}, skip=False)
        assert False
    except AnsibleLookupError:
        assert True
    ret = t.run( terms = ["foo"], variables={}, skip=True)

# Generated at 2022-06-11 15:23:41.049416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # missing files
    for test_vars in ([], ['file1'], ['file1', 'file2'], ['file1', 'file2', 'file3']):
        res = LookupModule().run(terms=test_vars)
        assert res == [], 'There is no file exist but function returned: %s' % res

    # missing file1
    res = LookupModule().run(terms=['file1', 'file2'], paths=['path1'])
    assert res == [], 'There is no file exist but function returned: %s' % res

    # missing file2
    res = LookupModule().run(terms=['file1', 'file2'], paths=['path2'])
    assert res == [], 'There is no file exist but function returned: %s' % res

    # missing file3


# Generated at 2022-06-11 15:23:49.451736
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        {
            'files': ['file1', 'file2'],
            'paths': ['path1', 'path2']
        },
        'file3',
        ['file4', 'file5'],
        {
            'files': ['file6', 'file7'],
            'paths': ['path3', 'path4']
        },
    ]

    lookup_module = LookupModule()

    expected_result = ['path1/file1', 'path2/file1', 'path1/file2', 'path2/file2', 'file3', 'file4', 'file5', 'path3/file6', 'path4/file6', 'path3/file7', 'path4/file7']
    result = sorted(lookup_module._process_terms(terms, {}, {})[0])

# Generated at 2022-06-11 15:23:59.910697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['ansible.cfg'], {}, verbosity=1) == ['/etc/ansible/ansible.cfg']
    assert '%s' %LookupModule().run(['doesnotexist'], {}, verbosity=1) == 'AnsibleLookupError: No file was found when using first_found.'
    assert '%s' %LookupModule().run([{'files': 'ansible.cfg'}], {}, verbosity=1) == 'AnsibleLookupError: No file was found when using first_found.'
    assert '%s' %LookupModule().run([{'files': 'ansible.cfg', 'paths': './'}], {}, verbosity=1) == 'AnsibleLookupError: No file was found when using first_found.'
    assert '%s'

# Generated at 2022-06-11 15:24:16.705986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyLookupModule(LookupModule):
        pass

    # fail on no files provided
    dummy = DummyLookupModule()
    try:
        dummy.run([], {})
    except AnsibleLookupError:
        pass
    else:
        raise AssertionError("AnsibleLookupError was not raised")

    # fail on files not found
    dummy = DummyLookupModule()
    try:
        dummy.run([{"files": "foo_123.json"}], {})
    except AnsibleLookupError:
        pass
    else:
        raise AssertionError("AnsibleLookupError was not raised")

    # fail on wrong type
    dummy = DummyLookupModule()

# Generated at 2022-06-11 15:24:24.448881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import textwrap
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import os

    # test relative
    terms_str = textwrap.dedent("""
        - { files: 'file1', paths: 'path1' }
        - { files: 'file2', paths: 'path2' }
    """)
    terms_str_obj = AnsibleUnsafeText(terms_str)
    terms_raw = [{'files': 'file1', 'paths': 'path1'}, {'files': 'file2', 'paths': 'path2'}]
    terms_res = terms_raw

    variables = dict(ansible_basedir=os.getcwd())

    l = LookupModule()
    l._subdir = 'file_dir'
    l._templar = None


# Generated at 2022-06-11 15:24:34.760988
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    lm = LookupModule()

    # NOTE: this is the documented way of using this plugin,
    # the result does not change if you add more entries,
    # therefore this lookup can be used in 'dual mode' (dict and list)
    # but the result is not predictable.

    result = lm.run([{'files': 'foo'}, 'bar.txt'], {}, paths=['foo/bar'], skip=True)
    assert result == ['foo/bar/foo'] or result == ['foo/bar/bar.txt']

    # test relative path
    result = lm.run(['path/to/foo', 'bar.txt'], {}, skip=True)

# Generated at 2022-06-11 15:24:45.840486
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing run against code is probably good
    # make sure to update docs as well

    # these tests need to be done with storage backends or other ways
    # as they test execution of the class not the 'script'

    # Test from class comments
    # TODO: add other cases

    # Test if

    # Empty List
    assert LookupModule.run([], {}) is None

    # Test if

    # Empty List
    assert LookupModule.run([1, 2, 3], {}) is None

    # Test if

    # Empty List
    assert LookupModule.run(['a/b/c.yml'], {}) is None

    # Test if

    # Empty List
    assert LookupModule.run({}, {}) is None

    # Test if

    # Empty List

# Generated at 2022-06-11 15:24:57.442707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = {
        'terms': [
            '/path/to/file1',
            {'files': 'file2', 'paths': '/path/to'},
            {'foo': 'bar'},
        ],
        'variables': {
            'ansible_env': {
                'PATH': '/usr/local/bin:/bin:/usr/bin',
            },
        },
        'task_vars': {
            'dirs': [
                'files',
            ],
        },
    }

    def mock_find_file_in_search_path(variables, subdir, filename, ignore_missing):
        if subdir == 'files':
            if 'path' in filename:
                return filename
        return None

    lookup = LookupModule()
    lookup._templar = None
    lookup.find_

# Generated at 2022-06-11 15:25:04.719616
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:25:14.030412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_LookupModule_run_1():
        lookup = LookupModule()

        lookup.run([{'files': 'foo', 'paths': 'bar'}], dict())

    def test_LookupModule_run_2():
        lookup = LookupModule()

        lookup.run([{'files': ['foo'], 'paths': ['bar']}], dict())

    def test_LookupModule_run_3():
        lookup = LookupModule()

        lookup.run(['foo'], dict())

    def test_LookupModule_run_4():
        lookup = LookupModule()

        lookup.run([['foo']], dict())

# Generated at 2022-06-11 15:25:24.976887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    # mock lookup_base._load_name_from_term
    lookup_base_load_name_from_term = LookupBase._load_name_from_term
    LookupBase._load_name_from_term = lambda self, term: "first_found"
    # mock path.exists
    path_exists = os.path.exists

# Generated at 2022-06-11 15:25:28.662382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance
    ds = LookupModule()

    # invoke run with valid terms, variables and kwargs
    ret = ds.run(['foo', 'bar'], {}, skip=True)
    assert ret == []



# Generated at 2022-06-11 15:25:37.852957
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:25:51.475530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    terms = []
    terms.append('foo')
    terms.append({'files': 'foo', 'paths': 'bar'})
    terms.append({'files': 'foo', 'paths': 'bar:baz'})
    terms.append({'files': 'foo, bar', 'paths': 'bar:baz'})
    terms.append({'files': 'foo, bar', 'paths': 'bar:baz'})

    vars = {}
    results = lm.run(terms, vars)
    assert(results == [])

    # TODO: this will be a proper test if we get the 'already set' bug fixed
    assert(False)

# Generated at 2022-06-11 15:26:03.657388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(terms, variables, kwargs, expected_return, expected_exception=None):

        if expected_exception is None:
            expected_output_error_message = ""
            expected_output_return = expected_return
        else:
            expected_output_error_message = expected_exception
            expected_output_return = None
        test_output = LookupModule().run(terms, variables, **kwargs)
        assert expected_output_error_message == "", "Expected to not raise an exception, but raised one"
        assert expected_output_return == test_output, (
            "Expected output: %s\nOutput: %s"
            % (expected_output_return, test_output)
        )

    #Possible outputs:
    #  if path is not None:
    #      return [path

# Generated at 2022-06-11 15:26:16.586457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    searchpath = [os.path.join(os.path.dirname(__file__), "files"),
                  os.path.join(os.path.dirname(__file__), "files2"),
                  os.path.join(os.path.dirname(__file__), "files"),
                  os.path.join(os.path.dirname(__file__), "files3")]
    terms = [{'files': 'i_can_be_found.txt'}]
    variables = {'ansible_search_path': searchpath}
    assert lookup.run(terms, variables) == [os.path.join(os.path.dirname(__file__), "files", "i_can_be_found.txt")]


# Generated at 2022-06-11 15:26:24.636021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import modules
    import shutil
    import tempfile
    import ansible.plugins.lookup.first_found

    # Create temporary folder
    tmp_dir = tempfile.mkdtemp()

    # Create folder tree
    path_foo = tmp_dir + '/foo'
    path_bar = tmp_dir + '/bar'
    path_baz = tmp_dir + '/baz'

    path_a = path_foo + '/a'
    path_b = path_bar + '/b'
    path_c = path_baz + '/c'

    path_hello = path_a + '/hello'
    path_goodbye = path_b + '/goodbye'

    os.makedirs(path_hello)
    os.makedirs(path_goodbye)

    # Create files

# Generated at 2022-06-11 15:26:36.149105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    
    def get_dirs(dir):
        return [os.path.join(dir, dirname) for dirname in os.listdir(dir)]
    # create a test file in /tmp
    test_dir = tempfile.mkdtemp()
    test_subdir = tempfile.mkdtemp(dir=test_dir)
    test_file = tempfile.mkstemp(dir=test_subdir)[1]
    
    
    lookup_plugin = LookupModule()
    
    # test 1
    assert get_dirs(test_dir) == lookup_plugin.run([], {}, paths=[test_dir])
    
    # test 2

# Generated at 2022-06-11 15:26:47.261669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test case 1: path and file are given
    lookup_module._subdir = 'files'
    terms = dict(
        files=['test_file.txt'],
        paths=['test_path/'],
        skip=0
    )
    kwargs = dict(
        _search_paths=[('files', 'test_path/')]
    )
    assert lookup_module.run(terms, kwargs) == ['test_path/test_file.txt']

    # Test case 2: path and file are given
    # This is for coverting to list
    terms = [
        ['test_file.txt'],
        'test_path/',
        0
    ]

# Generated at 2022-06-11 15:26:50.258341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = dict()
    variables = dict()
    lookup_module = LookupModule()
    lookup_module._process_terms([terms], variables, {'files': [''], 'paths': ['']})

# Generated at 2022-06-11 15:27:01.272307
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Subclassed LookupModule to workaround one private attribute of LookupModule
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, variables=None):
            super(TestLookupModule, self).__init__(loader, templar, variables)
            self._subdir = None

    # initialize LookupModule
    #
    # templar      : mock jinja2 template
    # loaders      : mock AnsibleFileSystemLoader
    # results      : what we expect from the lookup
    # vars         : parameters for the lookup
    def init(templar, loaders, results, vars):
        class TestUndefined(object):
            def __getitem__(self, key):
                raise UndefinedError(key)


# Generated at 2022-06-11 15:27:06.939623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args = dict()
    module_args['terms'] = [{'files': 'foo.txt', 'paths': '.'}, 'bar.txt']
    module_args['paths'] = '.'
    module_args['files'] = 'bar.txt'
    assert LookupModule.run(module_args) == ['/tmp/ansible/files/bar.txt']

# Generated at 2022-06-11 15:27:11.410347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    plugin = LookupModule()
    plugin._templar = Templar(loader=None, variables={})
    
    # test case 1: 
    # filelist = {'file1', 'file2'}, pathlist = {'path1', 'path2'}
    # path = path1/file1
    total_search, skip = plugin._process_terms([
        {
            'files': 'file1,file2',
            'paths': 'path1,path2'
        }
    ], {}, {})
    
    assert total_search == ['path1/file1', 'path1/file2', 'path2/file1', 'path2/file2']
    assert skip == False
    
    # test case 2: 
    # filelist = {'file1'},

# Generated at 2022-06-11 15:27:28.792815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'files'
    l._loader = None
    l._templar = None
    l._options = None

    terms = [
        {'files': 'myfile', 'paths': '/tmp'},
        {'files': 'myfile', 'skip': True},
        {'files': 'myfile', 'paths': '/tmp', 'skip': True},
        'myfile',
        ['myfile'],
        {'files': 'myfile'},
        {'paths': '/tmp'}
    ]

    for term in terms:
        assert l.run(term, {}) == ['/tmp/myfile']

    for term in terms:
        assert l.run(term, {}, files='myfile') == ['/tmp/myfile']


# Generated at 2022-06-11 15:27:35.434486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [
        {"files": "test_files/test.txt",
         "paths": "test_paths/test.txt"
        },
        {"files": "test_files/test.txt",
         "paths": "test_paths/test.txt",
         "skip": True
        }
    ]

    # test if file exists
    results = lookup.run(terms, {}, variables={})
    assert(results[0] == "test_paths/test.txt")

    results = lookup.run(terms, {}, variables={})
    assert(results == [])

# Generated at 2022-06-11 15:27:39.590081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    result = lm.run(['ansible', 'foo'], {}, skip=False)
    assert result == [], result
    result = lm.run(['ansible', 'foo'], {}, skip=True)
    assert result == [], result

# Generated at 2022-06-11 15:27:49.623390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        terms = [
            dict(files=['file1', 'file2'], paths=['/etc']),
            dict(files=['file3', 'file4'], paths=['/etc/pki']),
            dict(files=['file1', 'file2'], paths=['/etc/pki/tls']),
            dict(files=['file1', 'file2'], paths=['/etc/pki/tls/private']),
        ],
        variables = dict(),
        kwargs = dict(extension='',
                      ignore_missing=False,
                      skip=False,
                      ),
    )
    # A mock class object to simulate the LookupModule class object

# Generated at 2022-06-11 15:27:58.870618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # test no existing file
    args = ("tests/unit/files/first_found/no_existing_file", dict(terms={"files": ["first_found_test_file"], "paths": ["tests/unit/files/first_found"]}))
    expected = []
    assert lookup_plugin.run(*args) == expected

    # test existing file
    args = ("tests/unit/files/first_found/existing_file", dict(terms={"files": ["first_found_test_file"], "paths": ["tests/unit/files/first_found"]}))
    expected = ["tests/unit/files/first_found/first_found_test_file"]
    assert lookup_plugin.run(*args) == expected

    # test existing file in dict term

# Generated at 2022-06-11 15:28:08.773742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = [{u'files': [u'some_file'], u'paths': [u'some_path']},
           {u'files': [u'other_file'], u'paths': [u'other_path']},
           {u'files': [u'missing_file'], u'paths': [u'last_path']}
          ]
  lu = LookupModule()
  lu._loader = FakeLoader('')
  lu._templar = FakeTemplar()
  acutal_result = lu.run(terms, None)
  assert acutal_result == [(u'some_path', u'some_file')], "unexpected result: %s" % acutal_result

# Fake class for FakeLoader, used in unit test

# Generated at 2022-06-11 15:28:20.427910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with terms as a list of strings
    terms = ["C:\\Users\\Administrator\\Desktop\\file1.txt", "/etc/hosts", "/etc/passwd"]
    l = LookupModule()
    l._subdir = 'files'
    result = l.run(terms, variables=dict())
    assert result == ["C:\\Users\\Administrator\\Desktop\\file1.txt"]

    # test with terms as a list of dicts
    terms = [{"files": "file1.txt", "paths": ["C:\\Users\\Administrator\\Desktop", "/etc", "/etc/test"]},
             {"files": "hosts,passwd", "paths": ["/etc"]}]
    l = LookupModule()
    l._subdir = 'files'
    result = l.run(terms, variables=dict())

# Generated at 2022-06-11 15:28:21.005486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-11 15:28:32.162256
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: commented out notes are indicating that the yaml
    # option is not really supported, if one is used all other
    # options/terms will be ignored, so dont use it.

    # NOTE: all of the 'terms' should be listed, otherwise only the last one will be used
    # NOTE: do not use list when using ?: option

    # Test with one term as a list, the element should be: a :-separated path of paths and files
    # the path for the first file found is returned
    test_terms = [
        [
            "/etc/ansible/test1.txt:/etc/ansible/test2.txt:/etc/ansible/test3.txt"
        ]
    ]

    # test lookup with list as param.
    # if a term is a list it will be serialized to a string and templated


# Generated at 2022-06-11 15:28:41.085493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Setup _lookups
    lookup.__dict__['_lookups'] = {}
    lookup.__dict__['_lookups']['files'] = ['/tmp/']
    lookup.__dict__['_lookups']['paths'] = []

    # Set up ansible
    lookup.__dict__['_templar'] = None

    # Test run with a good file name
    terms = ['good']
    result = lookup.run(terms, {})
    assert result == ['/tmp/good']

    # Test run with an invalid file name
    terms = ['bad']
    try:
        lookup.run(terms, {})
        assert "Error not thrown" == True
    except AnsibleLookupError:
        # Expected exception
        pass

    # Test run with skip=True

# Generated at 2022-06-11 15:29:04.110508
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Define test data
    terms = [
        {
            'files': 'foo1.txt,bar1.txt',
            'paths': 'path1,path2'
        }
    ]

    variables = {
        'file1': 'path/to/file1.txt',
        'file2': 'path/to/file2.txt',
    }

    # Define test class

# Generated at 2022-06-11 15:29:08.056857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [None, '', [], {}, [{}], {'foo': 'bar'}, 'foo']
    expected = [None, None, None, None, None, AnsibleLookupError, None]
    actual = []
    for term in terms:
        try:
            actual.append(LookupModule.run(term))
        except Exception as e:
            actual.append(type(e))
    assert actual == expected

# Generated at 2022-06-11 15:29:08.700134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:29:10.179841
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: Implement a unit test for this method.
    return

# Generated at 2022-06-11 15:29:18.346900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # pylint: disable=protected-access
    lookup_module = LookupModule()
    lookup_module._subdir = 'files'
    lookup_module._loader = 'fake_loader'

    # Test when files is not found
    lookup_module._templar = 'fake_templar'
    lookup_module.get_option = lambda x: []

    class TestException(Exception):
        """ Test Exception"""
    try:
        lookup_module.run(terms=[], variables={})
    except TestException:
        assert True
        return

    assert False


# Generated at 2022-06-11 15:29:29.951818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_data_dirs = lookup_dirs()
    this_dir = os.path.dirname(__file__)
    data_dir = os.path.join(this_dir, 'unit/data')
    if os.path.exists(data_dir):
        test_data_dirs.insert(0, data_dir)
    else:
        # catch the case where someone has run the unit tests from someplace else
        data_dir = os.path.join(this_dir, 'data')
        if os.path.exists(data_dir):
            test_data_dirs.insert(0, data_dir)

    # This is only called by the unit test and doesn't actually work with Ansible
    # so we need to work around the imports and get a LookupBase to test

# Generated at 2022-06-11 15:29:37.359977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock module instantiation
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display

    # this can only be run on a machine with the file
    # 'files/changeme_file.txt' present in directory
    # and a file with contents "foo"

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory_manager)

    play_source = {}

# Generated at 2022-06-11 15:29:47.804729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with wrong input
    lm = LookupModule()
    try:
        terms = 'wrong'
        lm.run(terms)
    except AnsibleLookupError:
        pass

    # Test with multiple input
    lm = LookupModule()
    try:
        terms = ['wrong', 'wrong']
        lm.run(terms)
    except AnsibleLookupError:
        pass

    # Test with proper input
    lm = LookupModule()
    try:
        terms = ['wrong', '/']
        lm.run(terms)
    except AnsibleLookupError:
        pass

    # Test with proper input
    lm = LookupModule()

# Generated at 2022-06-11 15:29:48.372099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:29:53.482429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.inventory import Inventory
    import os.path
    from ansible.errors import AnsibleLookupError


    # setting up a fake env (just as a pretend)
    # first we need a dummy file and a fake dir name
    # we put them in a temp file
    import tempfile
    s = os.path.join(tempfile.gettempdir(), 'test_first_found.py')
    with open(s, 'w') as f:
        f.write('x')

    # we set the task to point to a fake included file
    # which we have no intention to have

# Generated at 2022-06-11 15:30:16.763440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:30:17.457868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 2

# Generated at 2022-06-11 15:30:27.985747
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # patching os.path.exists, kind of ugly but functional
    def mock_exists(path):
        return path in ['/path1/foo', '/path2/bar', '/path3/baz']

    import sys
    import unittest
    from unittest.mock import patch

    # adding test to path, so we can import jinja2
    sys.path.insert(0, '.')
    with patch.object(os.path, 'exists', mock_exists):
        from ansible_collections.ansible.community.tests.unit.compat.mock import mock_open, patch, MagicMock
        from ansible_collections.ansible.community.plugins.lookup import first_found


# Generated at 2022-06-11 15:30:39.037981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("TESTING METHOD LookupModule.run()")
    module = LookupModule()

    # test with a list of 2 strings
    terms = ["../files/file1.txt", "../files/file2.txt"]
    variables = {}
    expected_results = os.path.normpath('../files/file1.txt')
    assert module.run(terms, variables) == [expected_results], \
        "Expected: %s , Actual: %s" % ([expected_results], module.run(terms, variables))

    # test with a list of 2 strings with paths
    terms = ["/../files/file1.txt", "../files/file2.txt"]
    variables = {}
    expected_results = os.path.normpath('/../files/file1.txt')

# Generated at 2022-06-11 15:30:47.794584
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: fix test
    print("\n@TODO: fix test:\n")
    return


# Generated at 2022-06-11 15:30:54.249250
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Prepare
    def _split_on(terms, spliters=','):
        return terms

    mod = LookupModule()
    mod._split_on = _split_on
    mod.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None

    # Exercise
    result = mod.run(terms=['a', 'b'], variables={'a': 'a', 'b': 'b'})

    # Verify
    assert result == []



# Generated at 2022-06-11 15:31:01.444446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''This test use first_found module to test module.
    '''
    import os
    import tempfile
    import shutil
    from ansible.parsing.vault import VaultLib

    vault_file = tempfile.NamedTemporaryFile()

    # Create temp directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_1 = tempfile.TemporaryDirectory()
    
    # Create temparary sub directories
    temp_sub_dir = tempfile.TemporaryDirectory(dir=temp_dir.name)
    temp_sub_dir_1 = tempfile.TemporaryDirectory(dir=temp_dir_1.name)
    temp_sub_dir_2 = tempfile.TemporaryDirectory(dir=temp_dir_1.name)

    # Setting ansible global vars

# Generated at 2022-06-11 15:31:11.744727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar(dict(a=1, b=2))
    l._loader = DummyLoader({'files/foo': 'foo', 'files/bar': 'bar'})

    # No arguments => AnsibleLookupError
    try:
        l.run()
        assert False, "AnsibleLookupError should be raised"
    except AnsibleLookupError:
        pass

    # a file does not exist => AnsibleLookupError
    try:
        l.run(terms="aaa")
        assert False, "AnsibleLookupError should be raised"
    except AnsibleLookupError:
        pass

    # a file exists => path to file
    assert l.run(terms="files/foo") == ['files/foo']

    # list of files where

# Generated at 2022-06-11 15:31:23.076127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Injecting a dummy class instead of a real one to make tests faster
    # and to cover some hard to reach areas.
    class FakePath(object):
        def __init__(self, path):
            self.path = path
    class FakeTemplar(object):
        def __init__(self, templar):
            self.templar = templar
        def template(self, terms):
            return terms
    class FakeVariables(object):
        def __init__(self, variables):
            self.variables = variables
    class FakeLookupBase(object):
        def __init__(self, searchpath):
            self.searchpath = searchpath

# Generated at 2022-06-11 15:31:32.408746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    host = Host(name="test_host")
    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=None)
    templar = Templar(loader=None, variables=variable_manager,
                      shared_loader_obj=None)
    lookup_mod = LookupModule()
    lookup_mod._templar = templar
    lookup_mod.set_options(var_options=variable_manager, direct={'skip': False})
