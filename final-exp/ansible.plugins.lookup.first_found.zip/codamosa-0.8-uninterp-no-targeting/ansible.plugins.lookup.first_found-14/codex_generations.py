

# Generated at 2022-06-21 06:04:04.297554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    kwargs = {'skip': False, 'errors': 'strict'}
    ret = lookup.run(['not_a_file'], {}, **kwargs)
    assert ret == []

    kwargs = {'skip': False, 'errors': 'strict'}
    ret = lookup.run(['not_a_file'], {}, **kwargs)
    assert ret == []

    kwargs = {'skip': True, 'errors': 'strict'}
    ret = lookup.run(['not_a_file'], {}, **kwargs)
    assert ret == []

    kwargs = {'skip': False, 'errors': 'ignore'}
    ret = lookup.run(['not_a_file'], {}, **kwargs)
    assert ret == []



# Generated at 2022-06-21 06:04:11.175114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    lookup_module = LookupModule()
    lookup_module._templar = VariableManager._GET_TEMPLAR(variable_manager)

    args = [
        "{{ lookup('first_found', params) }}"
    ]

    kwargs = {
        'files': ['foo', 'bar', 'biz'],
        'paths': ['path/to'],
        'skip': True
    }
    # Check we get the first file name

# Generated at 2022-06-21 06:04:23.665288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prerequisites
    import os
    import tempfile
    import shutil
    import os.path

    dirpath = tempfile.mkdtemp()

# Generated at 2022-06-21 06:04:26.876831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    test_module = LookupModule()
    assert test_module is not None


# Generated at 2022-06-21 06:04:29.627139
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    # The rest of the unit tests will test the run method
    assert hasattr(module, 'run'), "The module has no method run"

# Generated at 2022-06-21 06:04:32.137118
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:04:34.229416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(LookupModule(), [['1.txt']], []) == ['1.txt']


# Generated at 2022-06-21 06:04:39.626819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Basic class instantiation
    x = LookupModule()
    assert isinstance(x, LookupModule)
    assert(x, LookupModule)

    # Test all of the attributes
    assert x._loader is not None
    assert x._templar is not None
    assert x._available_variables is not None
    assert x._options is not None
    assert x._display is not None
    assert x._plugin_name is not None


# Generated at 2022-06-21 06:04:40.432468
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:04:43.970179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class Test(object):
        def __init__(self, *args, **kwargs):
            self._subdir = "files"

    lookup = LookupModule(basedir=None, runner=Test())
    assert(lookup)


# Generated at 2022-06-21 06:04:49.421738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('first_found')

# Generated at 2022-06-21 06:05:02.077124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.utils.path as path

    # Shorten paths
    # Reused from ansible.utils.unsafe_proxy.AnsibleUnsafeText.__init__()

# Generated at 2022-06-21 06:05:07.242802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup = LookupModule()

    params = {
        'files': ['foo', 'bar'],
        'paths': '/tmp/production:/tmp/staging'
    }

    expected = []

    # Execute
    actual = lookup.run(params, {})

    # Verify
    assert actual == expected

# Generated at 2022-06-21 06:05:19.731264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.errors import AnsibleLookupError
    lm = LookupModule()
    lm._templar = Templar(loader=None, variables={})
    terms = ["foo", {"files": "foo.txt", "paths": "/tmp"}]

    # No file found
    got = lm.run(terms, {}, is_playbook=True)
    assert len(got) == 0

    # First file found
    got = lm.run(terms, {}, is_playbook=True)
    assert len(got) == 1
    assert got[0] == "foo.txt"

    # No path found
    terms = ["foo", {"files": "foo.txt", "paths": "/foo"}]

# Generated at 2022-06-21 06:05:25.960658
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._load_name = lambda _: None
    lookup.run = lambda _, __, ___, ____: "Test string"
    assert lookup.run(terms=[{'foo': 'bar'}], variables={'lookup_file': ['foo.txt']}) == "Test string"

# Generated at 2022-06-21 06:05:27.633666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module
    assert module._templar is None

# Generated at 2022-06-21 06:05:41.498530
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = (['apple', {'files': "ab,cd", 'paths': '/,//'}, 13],)
    assert isinstance(
        LookupModule._split_on(terms),
        list
    )
    # test the usage scenario where files and paths are both in a list and in kwargs
    # Expected result: both files and paths are in the list
    assert LookupModule._process_terms(terms, '', {'files': 'ef', 'paths': '/'}) == (
        ['apple', 'ab', 'cd', 13, 'ef'], False)
    # test the usage scenario where files and paths are both in a list and in kwargs
    # Expected result: only files in the list

# Generated at 2022-06-21 06:05:45.214981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check if the 'LookupModule' class is able to create a
    # instance with 'LookupBase' as an argument
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:05:51.144640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    # create a dummy variable manager that returns a variable that can be used for later templating.
    variable_manager = DictDataManager({'inventory_hostname':'test_hostname'}, loader=DataLoader())

    lookup_plugin = LookupModule(loader=DataLoader(), variable_manager=variable_manager)
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:06:04.731433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def _test_LookupModule_first_found(terms, kwargs):
        lookup_obj = LookupModule()
        expected_paths, expected_skip = lookup_obj._process_terms(terms, variables={}, kwargs=kwargs)

        # always sort paths, as order is not expected in dict and we are not testing search
        # and order of search does not matter in test
        expected_paths = sorted(expected_paths)

        return expected_paths, expected_skip

    def _test_LookupModule_first_found_raises(terms, kwargs):
        lookup_obj = LookupModule()
        expected_paths, expected_skip = lookup_obj._process_terms(terms, variables={}, kwargs=kwargs)

        # always sort paths, as order is not expected in dict and we are not

# Generated at 2022-06-21 06:06:09.439984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    return NotImplementedError()

# Generated at 2022-06-21 06:06:10.316089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, type)

# Generated at 2022-06-21 06:06:11.523567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule()) > 0

# Generated at 2022-06-21 06:06:15.836980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()  # Constructor without any argument
    assert lookup_module_instance is not None


# Generated at 2022-06-21 06:06:26.173920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleLookupError):
        """
        Case when no files found
        """
        lookup_module = LookupModule()
        lookup_module._process_terms([{
            'files': [],
            'paths': ['abc']
        }], {}, {})
        assert False

    with pytest.raises(AnsibleLookupError):
        """
        Case when no files and no paths defined
        """
        lookup_module = LookupModule()
        lookup_module._process_terms([{
            'files': [],
            'paths': []
        }], {}, {})
        assert False

    # Case when path is not empty
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:06:28.476809
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l.set_options(var_options={}, direct={'files': ['bar.txt'], 'paths': ['/tmp/']})
    assert l.run(['foo.txt']) == []

# Generated at 2022-06-21 06:06:31.252329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # check if class variables have been correctly set
    assert lookup.IS_JINJA2 is True

    # check if filter_loader and filter_class are correctly set
    assert lookup.filter_loader is None
    assert lookup.filter_class is None

# Generated at 2022-06-21 06:06:32.038960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:06:32.797081
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-21 06:06:40.276027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Test results of run method of class LookupModule
    '''
    import pytest
    import tempfile
    import os.path

    # define temporary directory to host a test directory
    tempdir = tempfile.mkdtemp()

    # define temporary test file
    tempfh = tempfile.NamedTemporaryFile(dir=tempdir, delete=False)

    # write some contents to temporary test file
    tempfh.write(b'test_LookupModule_run')
    tempfh.close()

    # define temporary test file 2
    tempfh2 = tempfile.NamedTemporaryFile(dir=tempdir, delete=False)

    # write some contents to temporary test file 2
    tempfh2.write(b'test_LookupModule_run2')
    tempfh2.close()

    #

# Generated at 2022-06-21 06:06:57.127808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = [
        {'files': ['/tmp/file1', 'file2'], 'paths': ['/tmp/path1', '/tmp/path2']},
        {'files': ['/tmp/file3', 'file4'], 'paths': ['/tmp/path3']},
        'file5',
        {'files': ['file6', 'file7'], 'paths': ['path6', 'path7']},
        ['file8', 'file9']
    ]
    variables = {}
    subdir = 'files'
    expected = ['/tmp/path1/file1', '/tmp/path2/file1', '/tmp/path3/file3']

    # Exercise
    lookup = LookupModule()
    actual = lookup.run(terms, variables, subdir=subdir)

    #

# Generated at 2022-06-21 06:07:03.285055
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test Empty: lookup('first_found', files=[foo])")
    try:
        LookupModule(loader=None, templar=None).run([{"files": ["foo"]}], {}, variables={})
        return False
    except AnsibleLookupError as e:
        assert 'No file was found when using first_found' in str(e)

    print("Test lookup('first_found', files=[foo])")
    l = LookupModule(loader=None, templar=None)
    l._loader.path_dwim = lambda: '.'
    ret = l.run([{"files": ["foo"]}], {}, variables={})
    assert ret == ['foo']

    print("Test lookup('first_found', files=[files/bar])")

# Generated at 2022-06-21 06:07:10.553460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.plugins.lookup import LookupModule

    #assert false, "this test needs writing"

    lookup_mod = LookupModule()

    # test what the run() method returns when different options are sent in
    # NOTE: not tested any 'extra' logic of how different options are handled (ie what happens in _process_terms)
    # note: these test value are  hard to test, so just test the end result is as expected
    #       as this method is in the lookup plugin and not exposed, they are stable and hard to mess up

    # empty params, only will fail as it raises exception
    assert lookup_mod.run([], None, None) == []

    # kwarg files is a list, so will return the list
    assert lookup_mod

# Generated at 2022-06-21 06:07:21.592590
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupBase

    class TestLookupBase(LookupBase):
        def __init__(self):
            pass

        def find_file_in_search_path(self, variables, path, filename, ignore_missing=False):
            return "test"

        @staticmethod
        def set_loader(loader):
            pass

    def test_run_no_paths_and_no_file_and_default_global_skip_to_false(mocker):
        mock_templar_template = mocker.patch("ansible.plugins.lookup.lookup_plugins.LookupBase._templar.template")
        mock_templar_template.side_effect = [None, None]
        my_lookup = TestLookupBase()
        variables = dict()

# Generated at 2022-06-21 06:07:27.930590
# Unit test for constructor of class LookupModule
def test_LookupModule():

  # Test Object instantiation with no arguments
  testobj = LookupModule()
  # Test correct object creation and attr assignments
  assert isinstance(testobj, LookupModule)
  assert isinstance(getattr(testobj, '_subdir'), string_types)
  


# Generated at 2022-06-21 06:07:30.514898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # TODO: find a way to test lookup.run()

# Generated at 2022-06-21 06:07:32.904355
# Unit test for constructor of class LookupModule
def test_LookupModule():
   test_obj = LookupModule()
   assert test_obj != None


# Generated at 2022-06-21 06:07:35.508636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:07:43.302673
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # construct template
    lookup = LookupModule()

    # constructor
    assert(lookup.lookup_type == 'first_found')

    # test with paths
    paths_result = lookup._process_terms(
        terms=['test1.txt'],
        variables={},
        kwargs={'paths': '/path'}
    )
    assert(paths_result == (['/path/test1.txt'], False))
    paths_result = lookup._process_terms(
        terms=['test1.txt'],
        variables={},
        kwargs={'paths': '/path:/path2'}
    )
    assert(paths_result == (['/path/test1.txt', '/path2/test1.txt'], False))

# Generated at 2022-06-21 06:07:54.745614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    obj = lookup.flatten(["/tmp/foo.txt", "bar.txt", "/tmp/biz.txt"])
    assert obj == "/tmp/foo.txt,bar.txt,/tmp/biz.txt"
    obj = lookup.flatten([["/tmp/foo.txt", "bar.txt"], "/tmp/biz.txt"])
    assert obj == "/tmp/foo.txt,bar.txt,/tmp/biz.txt"
    obj = lookup.flatten(["/tmp/foo.txt", ["bar.txt", "/tmp/biz.txt"]])
    assert obj == "/tmp/foo.txt,bar.txt,/tmp/biz.txt"

# Generated at 2022-06-21 06:08:18.736890
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test_LookupModule_should_raise_AnsibleLookupError_if_terms_are_not_valid()
    lookup = LookupModule()
    with pytest.raises(AnsibleLookupError):
        lookup._process_terms('an invalid type', 'whatever', 'whatever')

    # test_LookupModule_should_raise_AnsibleLookupError_if_term_is_not_string_or_list_or_dict()
    with pytest.raises(AnsibleLookupError):
        lookup._process_terms(2, 'whatever', 'whatever')

    # test_LookupModule_should_create_total_search_from_string_terms()
    total_search, skip = lookup._process_terms(['a term'], 'whatever', 'whatever')

# Generated at 2022-06-21 06:08:20.855861
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert isinstance(lookup_mod, LookupModule)


# Generated at 2022-06-21 06:08:25.590771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule:

        def test_no_terms(self):
            """
            Test with no terms given
            """
            terms = []
            variables = {}
            lookup_module = LookupModule()
            assert lookup_module.run(terms, variables) == []

        def test_term_dict(self):
            """
            Test with 'term' as dictionary, (inline options)
            """
            terms = [{'paths': "/foo/bar/roles/dummy_role/files/", 'files': "dummy.ini"}]
            variables = {}
            lookup_module = LookupModule()
            result = lookup_module.run(terms, variables)
            assert result is not None


# Generated at 2022-06-21 06:08:26.749194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None



# Generated at 2022-06-21 06:08:33.474096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    lookup_module = LookupModule()

    # assert the abstract methods of LookupBase
    assert lookup_module._get_file_contents('') is None
    assert lookup_module._load_file('') is None

    assert hasattr(lookup_module, 'run')
    assert callable(lookup_module.run)

# Generated at 2022-06-21 06:08:38.382121
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    # dummy vars
    terms = [
        {'files': 'one,two', 'paths': 'path1,path2'},
        {'files': 'three,four', 'paths': 'path3', 'skip': True},
        {'files': 'five,six', 'paths': 'path4'}
    ]
    variables = {}

    # check that nothing is changed on input
    l._process_terms(terms, variables, {})
    assert terms[0]['files'] == 'one,two'
    assert terms[0]['paths'] == 'path1,path2'

    # TODO: add a test using the find_file_in_search_path to test lookups
    #       and do a proper mock of the search path.
    # This is not finished and it

# Generated at 2022-06-21 06:08:46.309777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib

    lookup = LookupModule()
    res = lookup.run([{'files': 'foo/bar.yml, baz/boz.yml'}, 'foo.yml'], {}, skip=True)
    assert ['foo.yml'] == res

    res = lookup.run(['foo/bar.yml'], {}, skip=True, files=['foo/bar.yml', 'baz/boz.yml'])
    assert ['foo/bar.yml'] == res

    res = lookup.run('foo/bar.yml, baz/boz.yml', {}, paths=['foo', 'baz'])
    assert [] == res

    lookup = LookupModule()

# Generated at 2022-06-21 06:08:55.822204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Opts():
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    # mock a find_file_in_search_path method
    def find_file_in_search_path(variables, subdir, fn, **kwargs):
        """ Mock the find_file_in_search_path method """
        if fn in ['/path/to/find.file', 'file.for.find.file']:
            return fn


    # mock a _split_on method
    def _split_on(terms):
        if isinstance(terms, string_types):
            return [terms]
        else:
            return terms

    def templar_template(template):
        return template



# Generated at 2022-06-21 06:09:06.217845
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLookupBase(LookupBase):
        def find_file_in_search_path_in_nested_folder(self, variables, subdir, filename, ignore_missing=False):
            file_found = ""
            if filename == 'first':
                file_found = "file1"
            elif filename == 'config':
                file_found = "config1"
            return file_found

    lookup_module = LookupModule()
    lookup_modul._templar = MockLookupBase

    # Test 1: If file is not found, it should raise exception
    total_search = ['file1', 'file2']
    try:
        lookup_module.run(total_search, '')
    except AnsibleLookupError as e:
        assert str(e) == 'No file was found when using first_found.'

# Generated at 2022-06-21 06:09:14.175734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    paths = ['/path1/', '/path2/']
    terms = ['first_file.yml', 'second_file.yml']

    mock_searcher = MockSearch()
    mock_searcher.add_path(paths)
    mock_searcher.add_path(terms)

    # Setup LookupModule instance
    mock_variables = {}
    mock_plugin = LookupModule()
    mock_plugin.set_loader(mock_searcher)
    mock_plugin._templar = None
    mock_plugin._subdir = 'files'

    # Setup keyword arguments
    mock_kwargs = {}

    # First path should be found
    mock_searcher._found_file = paths[0] + terms[0]

# Generated at 2022-06-21 06:09:44.105385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    results = lookup._process_terms(["hello"], {"somevariable": "somevalue"}, {})
    assert results[0] == ["hello"], ("_process_terms failed on LookupModule")
    

# Generated at 2022-06-21 06:09:51.429038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms='test.txt', variables={}, skip=True) == []
    assert lookup.run(terms='test.txt', variables={}, skip=True) != ['test.txt']
    assert lookup.run(terms='test.txt', variables={}, skip=False) == ['test.txt']

# Generated at 2022-06-21 06:10:00.279602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #basic_all_found
    assert LookupModule.run(None, [
                            {'files': 'a.txt,b.txt', 'paths': 'path1,path2'},
                            {'files': 'c.txt,d.txt', 'paths': 'path2,path1'}],
                            # cant test this in a unit test :)
                            # _original_file = 'unit_tester.yaml',
                            _connection = None,
                            _loader = None,
                            ) == [['path1/c.txt'], ['path1/d.txt']]
    #basic_only_first_found

# Generated at 2022-06-21 06:10:08.095359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    error_message = "test_LookupModule failed"

    # Test that it is a class instance
    assert isinstance(lookup_module, LookupModule), error_message

    # Test it has 'run' method
    assert hasattr(lookup_module, 'run'), error_message

    # Test it has 'run' method
    assert hasattr(lookup_module, 'set_options'), error_message

# Generated at 2022-06-21 06:10:15.695170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    my_variable = {u'foo': u'bar', u'ansible_current_user': u'root', u'ansible_play_hosts': [u'10.0.0.1']}
    # This test will pass as the term is a sequence
    term = {'files': ['/tmp/foo.txt', '/tmp/bar.txt'], 'paths': ['/tmp']}
    search, skip = lookup_plugin._process_terms([term], my_variable, {})
    assert search == ['/tmp/foo.txt', '/tmp/bar.txt']
    # This test will fail as the term is not a sequence
    term = {'files': '/tmp/foo.txt', 'paths': ['/tmp']}

# Generated at 2022-06-21 06:10:29.226703
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test for legacy 'findme'
    findme = ['/path/to/file', 'file', '/path/to/other']

    lookup = LookupModule()
    # pylint: disable=protected-access
    assert lookup._process_terms(findme) == (['/path/to/file', 'file', '/path/to/other'], False)

    # more complex version without multiple relative paths
    findme = [{'files': '/path/to/file,file', 'paths': '/path/to/path'}]

    lookup = LookupModule()
    # pylint: disable=protected-access
    assert lookup._process_terms(findme) == (['/path/to/path/file', '/path/to/path/file', '/path/to/path/file'], False)

    # more complex

# Generated at 2022-06-21 06:10:36.060348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # setup
    lookup_plugin = LookupModule()

    # execution
    result = lookup_plugin._process_terms(['file', 'file2'], 'variables', {})
    assert result == ['file', 'file2'], "Result must be ['file', 'file2']. Result: %s" % result

    result = lookup_plugin._process_terms(['file'], 'variables', {'files': 'file2'})
    assert result == ['file2'], "Result must be ['file2']. Result: %s" % result

    result = lookup_plugin._process_terms(['{file}'], 'variables', {'files': 'file2'})
    assert result == [], "Result must be []. Result: %s" % result


# Generated at 2022-06-21 06:10:50.249042
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create 'manager' object
    lookup = LookupModule()

    # NOTE: this is a really hacky way to get setup,
    # but makes it easy to unit test without need for playcontext etc
    lookup._loader = lambda *args, **kwargs: None
    lookup.get_basedir = lambda *args: None
    lookup._templar = lambda *args, **kwargs: None
    lookup._templar.template = lambda val: val
    lookup._loader = lambda *args, **kwargs: lookup
    lookup._loader.get_basedir = lambda *args: None
    lookup._loader.get_basedir = lambda *args: None

    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: True

    # NOTE: do not test the various modes with files and paths,
   

# Generated at 2022-06-21 06:11:01.910359
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_obj = LookupModule()

    # Test 1 - path found
    terms_1 = ['/a/b/test.txt']
    variables_1 = {'test': 'test_variables1'}

    assert lookup_obj.run(terms_1, variables_1) == ['/a/b/test.txt']

    # Test 2 - path not found
    terms_2 = ['/a/b/test.txt']
    variables_2 = {'test': 'test_variables2'}

    assert lookup_obj.run(terms_2, variables_2) == ['/a/b/test.txt']

    # Test 3 - path found
    # NOTE: this is an odd use case, as setting skip=True will cause the 'global' to be set
    # despite the dict skip=False.
    terms_3

# Generated at 2022-06-21 06:11:12.253859
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with no term, catch exception
    lookup_module = LookupModule()
    try:
        result = lookup_module.run([], {})
    except Exception:
        assert True

    # Test with empty term, look up error
    lookup_module = LookupModule()
    try:
        result = lookup_module.run([{}], {})
    except AnsibleLookupError:
        assert True

    # Test with empty term, look up error
    lookup_module = LookupModule()
    try:
        result = lookup_module.run([{"files": []}], {})
    except AnsibleLookupError:
        assert True



# Generated at 2022-06-21 06:12:14.311221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from collections import namedtuple

    named_tuple = namedtuple("named_tuple", "terms variables")

    # Case 1: Should return the path of the given file.
    lookup = LookupModule()
    lookup.find_file_in_search_path = lambda variables, subdir, filename: "/etc/foo.conf"
    lookup.set_options(var_options={"foo": "bar"})
    lookup._subdir = "files"

    assert lookup.run(named_tuple(terms=["foo"], variables={}),
                      variables={}, skip=False) == ['/etc/foo.conf']

    # Case 2: Should return an empty list.
    lookup = LookupModule()
    lookup.find_file_in_search_path = lambda variables, subdir, filename: None

# Generated at 2022-06-21 06:12:15.245400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Write unit tests for method run of class LookupModule
    assert True

# Generated at 2022-06-21 06:12:15.842273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:12:18.200768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert isinstance(my_lookup, LookupModule)


# Generated at 2022-06-21 06:12:25.944759
# Unit test for constructor of class LookupModule
def test_LookupModule():

    with open('test_file.yaml', 'w') as f:
        f.write('test: test')

    lookup = LookupModule()

    for term in ['test_file.yaml', {'files': 'test_file.yaml'}]:
        files = lookup.run([term], {})
        assert files == [os.path.abspath(term)]
        os.unlink('test_file.yaml')

    # check that list of files is honored
    with open('test_file_1.yaml', 'w') as f:
        f.write('test: test')
    with open('test_file_2.yaml', 'w') as f:
        f.write('test: test')
    with open('test_file_3.yaml', 'w') as f:
        f.write

# Generated at 2022-06-21 06:12:36.817680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """
  Test that default args of run() return the expected result.
  """
  lookup_module = LookupModule()

  # Unit test for first_found lookup plugin.

  # test that 'files' of size 0 returns nothing
  assert lookup_module.run(terms=[], variables={}, files=[], paths=[], skip=False) == []

  # test that 'files' of size 1 returns the first file
  assert lookup_module.run(terms=[], variables={}, files=["./test_first_found.py"], paths=[], skip=False) == ["./test_first_found.py"]

  # test that 'files' of size 2 returns only the first file found

# Generated at 2022-06-21 06:12:47.927057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # No file is passed in terms.
  terms = []
  variables = {}
  lookup_res = LookupModule().run(terms, variables, paths='.')
  assert len(lookup_res) == 0

  # One file is passed in terms.
  terms = ['test_file_for_run.py']
  variables = {}
  lookup_res = LookupModule().run(terms, variables, paths='.')
  assert lookup_res == [os.path.abspath(__file__)]

  # One file is passed in terms and one in paths.
  terms = ['test_file_for_run.py']
  variables = {}
  lookup_res = LookupModule().run(terms, variables, paths=['.', '..'])

# Generated at 2022-06-21 06:12:58.482446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test "run" method of class LookupModule
    This test does not cover the case where LookupModule is instantiated with a
    play and a loader.
    If a play is used, the method _get_parent_role_paths is called which uses the
    attribute play to get the path of the role.
    If a loader is used, _loader_find_file is called to find the file.
    """

    import os
    os.environ['ANSIBLE_LOOKUP_FIRST_FOUND'] = 'True'
    from ansible.plugins.lookup.first_found import LookupModule as Lm
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

# Generated at 2022-06-21 06:13:04.136884
# Unit test for constructor of class LookupModule
def test_LookupModule():

    LM = LookupModule()
    LM._subdir = "files"
    LM._loader = None
    LM._templar = None

    # Initialize options for LookupModule
    LM.set_options(var_options=None, direct=dict(files=[], paths=[]))

    # Test LookupModule._process_terms
    terms = [dict(files=["my_file.conf", "my_file.txt"],
                 paths=["C:\\foo"])]

    total_search, skip = LM._process_terms(terms, None, dict(files=[], paths=[]))
    assert skip == False
    assert total_search == ["C:\\foo\\my_file.conf", "C:\\foo\\my_file.txt"]


# Generated at 2022-06-21 06:13:14.745515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.display import Display

    data_loader = DataLoader()
    variable_manager = VariableManager()
    display = Display()

    collector = lookup_loader.get('first_found', loader=data_loader, templar=Templar(variable_manager), display=display)

    # test when option files is not set
    terms = ['bar']
    variables = {}
    returned_value = collector.run(terms, variables)
    assert returned_value == ['bar']

    # test when option files is set
    terms = [{'files': 'bar'}]
    variables = {}
    returned_value = collector