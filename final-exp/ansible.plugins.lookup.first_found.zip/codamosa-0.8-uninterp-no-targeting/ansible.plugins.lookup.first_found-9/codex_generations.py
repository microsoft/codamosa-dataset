

# Generated at 2022-06-21 06:03:53.563800
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert LookupModule is not None

# Generated at 2022-06-21 06:03:55.698696
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert isinstance(L, LookupModule)


# Generated at 2022-06-21 06:04:06.262933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = 'test'
    class_name = 'LookupModule'
    import ansible.plugins
    # ansible_lookup_plugins = ansible.plugins.lookup.__path__[0]
    # import os
    # path = os.path.join(ansible_lookup_plugins, module + '.py')
    # module = imp.load_source('ansible.plugins.lookup.' + class_name, path)
    mod = getattr(__import__('ansible.plugins.lookup.' + module, fromlist=[class_name]), class_name)
    lookup = mod()


# Generated at 2022-06-21 06:04:11.158922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor test
    """
    # kwargs
    assert LookupModule(task=None, variables=dict()).run(terms=None, variables=None, **dict()) == []

# Generated at 2022-06-21 06:04:14.020779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['a', 'b'], variables={'a': 'b'}) == ['a', 'b']

# Generated at 2022-06-21 06:04:25.854763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing parameter terms, the value of terms is fixed.
    terms = [{'files': 'foo, bar', 'paths': ''}]
    # Testing parameter variables, the value of variables is fixed.
    variables = {}
    # Testing parameter kwargs, the value of kwargs is fixed.
    kwargs = {}

    # Testing the return value of function run.
    # The return value of this function is tested in ansible-test integration tests.
    lookup_plugin = LookupModule()
    lookup_plugin._LoaderModule__loaders = []
    result = lookup_plugin.run(terms, variables, **kwargs)
    assert result == ['foo', 'bar']

    # Testing parameter terms, the value of terms is fixed.

# Generated at 2022-06-21 06:04:30.367281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:04:31.968784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    # Assert constructor is not empty
    assert my_lookup.run

# Generated at 2022-06-21 06:04:38.113492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options={}, direct={})

    with pytest.raises(AnsibleLookupError):
        lookup_obj.run([], {})

    with pytest.raises(AnsibleLookupError):
        lookup_obj.run([], {}, files=[], paths=[])

# Generated at 2022-06-21 06:04:44.483284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='str', default=[]),
            paths=dict(type='list', elements='str', default=[]),
            files=dict(type='list', elements='str', default=[]),
            skip=dict(type='bool', default=False),
        )
    )

    lookup = LookupModule()
    lookup.set_options(dict(files=['foo', 'bar'], paths=['/tmp'], _terms=['baz', 'bam']))

    # Test _split_on
    assert _split_on('foo,bar') == ['foo', 'bar']
    assert _split_on('foo;bar') == ['foo', 'bar']

# Generated at 2022-06-21 06:05:05.648986
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _get_file1_path(dir):
        return os.path.join(dir, 'file1.txt')
    def _get_file_in_module_dir_path(dir):
        return os.path.join(dir, 'module_dir', 'file_in_module_dir.txt')

    class MockTemplar:
        def __init__(self, dir):
            self.dir = dir
        def template(self, fn):
            return os.path.join(self.dir, fn)

    class MockPlay:
        def __init__(self, dir, name='test', basedir=None):
            self.basedir = basedir if basedir is not None else dir
            self.name = name


# Generated at 2022-06-21 06:05:19.667439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from . import (
        AnsibleLookupError,
        AnsibleUndefinedVariable,
        LookupBase,
        LookupModule,
        Mapping,
        Sequence,
    )
    from .compat import Mock, mock_open, patch, sentinel
    from .compat.mock import call

    actual = LookupModule()
    assert isinstance(actual, LookupBase)
    assert isinstance(actual, LookupModule)


# Generated at 2022-06-21 06:05:32.028922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for _file in ['dict_file', 'string_file']:
        _lookup = LookupModule(loader=None, templar=None, **{'_filesystems': {'file': {_file: True}}})
        _res = ['/path/to/file/1']
        assert _lookup.run(['file'], dict()) == _res
        _res = ['/path/to/file/1']
        assert _lookup.run(['file'], dict()) == _res
        assert _lookup.run([['file']], dict()) == _res
        assert _lookup.run([{'file': True}], dict()) == _res
        _lookup = LookupModule(loader=None, templar=None, **{'_file': {_file: True}})

# Generated at 2022-06-21 06:05:33.559554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule._process_terms, classmethod)

# Generated at 2022-06-21 06:05:34.432304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:05:35.851030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:05:36.532083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:05:46.181631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'files': 'file1.txt,file2.txt', 'paths': 'path1,path2'},
        {'files': 'file3.txt,file4.txt', 'paths': 'path3,path4'},
        {'files': 'file5.txt,file6.txt'},
        {'paths': 'path5,path6'}
    ]
    variables = None
    kwargs = {'skip': True}
    assert LookupModule().run(terms, variables, **kwargs) == []


# Generated at 2022-06-21 06:05:46.736747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:05:48.687633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance

# Generated at 2022-06-21 06:05:56.734873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule() is not None)

# Generated at 2022-06-21 06:06:03.948406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    _this_dir = os.path.dirname(os.path.realpath(__file__))
    _module_dir = os.path.dirname(_this_dir)
    sys.path.append(_module_dir)
    from test_filelookup import *

    terms = terms_from_path(os.path.join(_module_dir, '../lookup_plugins'))
    terms.append({'files': 'distro.yml', 'paths': 'vars'})
    terms.append('/path/to/foo.txt')
    terms.append('bar.txt')
    terms.append('biz.txt')
    terms.append('{{ inventory_hostname }}')

    module_results = []

# Generated at 2022-06-21 06:06:04.896475
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:06:09.207109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(var_options=dict(), direct={})
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') is False
    assert lookup._loader_name == 'files'



# Generated at 2022-06-21 06:06:10.716301
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:06:11.382120
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:06:15.197287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, '_process_terms')

# Generated at 2022-06-21 06:06:15.962073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-21 06:06:17.165403
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup_module = LookupModule()
   assert lookup_module is not None

# Generated at 2022-06-21 06:06:28.839470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test if run method of LookupModule class return what is expected.

    The run method should take a list of files and a list of paths and return
    the first path and file combination that exists.
    """

    # Mock this module
    from ansible.plugins.lookup import first_found
    first_found.LookupModule = LookupModule

    # Mock jinja2 filters
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib

    j2_env = ImmutableDict()
    vlt = VaultLib(None)

    # Create a lookup module instance
    lookup_instance = first_found.LookupModule()

    # Set _templar attribute
    import jinja2
    lookup_instance._templar = jinja

# Generated at 2022-06-21 06:06:44.097020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # TODO: add tests for all methods!
    # see: https://github.com/ansible/ansible/pull/36175
    # https://github.com/ansible/ansible/pull/36171

# Generated at 2022-06-21 06:06:56.577832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
    from ansible.template import Templar

    from ansible_collections.ansible.lookup_plugins.tests.unit.compat import mock, unittest

    def _mk_templar(vars_):
        variables = wrap_var(vars_)
        templar = Templar(loader=None, variables=variables)
        return templar

    class TestLookupModule(unittest.TestCase):
        def test__process_terms(self):
            lookup = LookupModule()
            templar = _mk_templar({})
            lookup._templar = templar

            # Test 1: single file in list

# Generated at 2022-06-21 06:06:59.329708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check that LookupModule works with no parameters
    l = LookupModule()
    l.set_options(direct=dict())
    # Check that LookupModule works with one parameter
    l = LookupModule('')
    l.set_options(direct=dict())

# Generated at 2022-06-21 06:07:10.358547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'skip': False})

    terms = None
    variables = {}
    try:
        lookup.run(terms, variables)
    except AnsibleLookupError as ex:
        assert ex.message == 'No file was found when using first_found.'

    terms = []
    try:
        lookup.run(terms, variables)
    except AnsibleLookupError as ex:
        assert ex.message == 'No file was found when using first_found.'

    terms = ['file1']
    result = lookup.run(terms, variables)
    assert result == []

    terms = [{'files': ['file1'], 'paths': '/path'}]
    result = lookup.run(terms, variables)
    assert result == []


# Generated at 2022-06-21 06:07:17.502233
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test _process_terms method for valid inputs
    LookupModule.run(terms=[], variables={}, kwargs={})
    LookupModule.run(terms={'files': 'f1,f2,f3', 'paths': 'p1,p2,p3'}, variables={}, kwargs={})
    LookupModule.run(terms=['files1,files2,files3'], variables={}, kwargs={})
    LookupModule.run(terms=['files1', 'files2', 'files3'], variables={}, kwargs={})
    LookupModule.run(terms=[{'files': 'f1,f2,f3', 'paths': 'p1,p2,p3'}], variables={}, kwargs={})

# Generated at 2022-06-21 06:07:20.124238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()
    assert (callable(lookup_module_instance.run)) == True

# Generated at 2022-06-21 06:07:32.975611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(terms=['/tmp/foo.txt', '/tmp/bar.txt', '/tmp/bar_baz.txt'])
    assert result == [], "should return [] as no file is found"

    result = lookup.run(terms=[{'files': 'foo.txt', 'paths': '/tmp'}, {'files': 'bar.txt', 'paths': '/tmp'}])
    assert result == [], "should return [] as no file is found"

    result = lookup.run(terms=[{'files': 'foo.txt,bar.txt', 'paths': '/tmp'}, {'files': 'bar.txt', 'paths': '/tmp'}])
    assert result == [], "should return [] as no file is found"


# Generated at 2022-06-21 06:07:42.557572
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    vars = {}
    lu = LookupModule()
    lu._templar = MockTemplar()
    lu._loader = MockLoader()

    # test lookup failure
    def check_failure(terms, msg):
        try:
            lu.run(terms, vars)
            assert False, "Expected AnsibleLookupError: %s Got: None" % msg
        except AnsibleLookupError as e:
            assert str(e) == msg, "Expected: %s Got: %s" % (msg, str(e))

    check_failure([None], 'No file was found when using first_found.')
    check_failure(None, "Invalid term supplied, can handle string, mapping or list of strings but got: <type 'NoneType'> for None")

# Generated at 2022-06-21 06:07:54.544903
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ["test.yaml"]
    assert lookup_module._process_terms(terms)[0] == terms
    terms = [{"files": "test.yaml"}]
    assert lookup_module._process_terms(terms)[0] == terms
    terms = [{"files": ["test1.yaml", "test2.yaml"],
              "paths": "foo/bar"}]
    assert lookup_module._process_terms(terms)[0] == terms
    terms = ["test1.yaml", "test2.yaml", "test3.yaml"]
    assert lookup_module._process_terms(terms)[0] == terms
    terms = [["test1.yaml", "test2.yaml", "test3.yaml"]]

# Generated at 2022-06-21 06:08:02.389372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f1 = 'file1'
    f2 = 'file2'
    f3 = 'file3'
    p1 = 'path'
    p2 = 'path2'
    p3 = 'path3'

    # NOTE: this case is not tested
    # no file no path no skip no found
    # terms = []
    # lookup = LookupModule()
    # ansible_result = lookup.run(terms, {})
    # assert ansible_result == []
    #
    # no file  no path  no skip
    terms = [{}]
    lookup = LookupModule()
    with pytest.raises(AnsibleLookupError) as e_info:
        lookup.run(terms, {})
    assert "No file was found" in str(e_info.value)

    # no file 

# Generated at 2022-06-21 06:08:37.863853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    context = {}

    # Assert that skip option, when enabled, returns empty list
    lookup_object = LookupModule()
    lookup_object.set_options(var_options={}, direct={'skip': True})
    result = lookup_object.run(['missing_file'], context, files=['missing_file'])
    assert result == []

    # Assert that the module raises AnsibleLookupError if skip is disabled
    with pytest.raises(AnsibleLookupError):
        lookup_object = LookupModule()
        result = lookup_object.run(['missing_file_2'], context, files=['missing_file_2'])

# Generated at 2022-06-21 06:08:46.257978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.context import context
    from ansible.template.template import AnsibleEnvironment
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    test_inventory = InventoryManager(loader=loader, sources=['tests/unit/files/lookup_plugins/inventory.ini'])
    variables = combine_vars(loader=loader, variables=None, inventory=test_inventory)
    templar = AnsibleEnvironment(loader=loader).get_template_class()()

    # Mock a task
    from ansible.playbook.task import Task
    setattr(context, 'task', Task())

    # Mock a role
    from ansible.playbook.role.include import Include


# Generated at 2022-06-21 06:08:55.776429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    from ansible.errors import AnsibleLookupError
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.path import unfrackpath

    lookup_instance = LookupModule()

    terms = "not, a path;"

    with pytest.raises(AnsibleLookupError, match="No file was found when using first_found."):
        lookup_instance._process_terms(terms, None, None)

    terms = []
    terms.append({'paths': '/tmp', 'files': 'existing, file'})
    terms.append({'paths': '/tmp', 'files': 'not, existing, file'})
    terms.append({'paths': '/tmp', 'files': 'not, existing, file'})


# Generated at 2022-06-21 06:09:06.187569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.context import context
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash

    context.CLIARGS = {}
    context._init_global_context()

    play_context = PlayContext()
    play_context._ansible_no_log = True
    templar = Templar(loader=None, variables=merge_hash(play_context.CLIARGS, play_context.CLIARGS, play_context.extra_vars),
                      fail_on_undefined=False)

    lookup_plugin = LookupModule()

    # test with a good path

# Generated at 2022-06-21 06:09:06.643338
# Unit test for constructor of class LookupModule
def test_LookupModule():

    LookupModule()

# Generated at 2022-06-21 06:09:07.548653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:09:15.463113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This is a test, which will fail unless you have created a file named
    # /root/test_file_for_first_found_lookup
    lookup_file = LookupModule()
    lookup_file._loader = None
    # a file named /root/test_file_for_first_found_lookup must exist, and have
    # some content in it.
    lookup_file.run(terms=[{"files": "test_file_for_first_found_lookup", "paths": "/root"}],
                    variables=dict(),
                    persistresult=False)

# Generated at 2022-06-21 06:09:19.668600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule._split_on('') == []
    assert LookupModule._split_on('one,two') == ['one', 'two']
    assert LookupModule._split_on(['one,two']) == ['one', 'two']
    assert LookupModule._split_on(['one', 'two']) == ['one', 'two']
    assert LookupModule._split_on(['one', ['two', 'three']]) == ['one', 'two', 'three']

# Generated at 2022-06-21 06:09:20.571583
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:09:27.169188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # a simple test for first_found lookup
    lookup = LookupModule()

    src = ['/etc/foo.conf', '/other/foo.conf', '/other/hope/foo.conf']
    subdir = 'files'
    path = lookup.find_file_in_search_path(dict(), subdir, src[0], ignore_missing=True)
    assert path is not None
    assert path == '/etc/foo.conf'

    subdir = 'files'
    terms = [{'files': 'foo.conf', 'paths': ['/etc', '/other/foo.conf', '/other/hope']}]
    path = lookup.run(terms, dict())
    assert path == ['/etc/foo.conf']


# Generated at 2022-06-21 06:10:18.294990
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:10:20.806420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:10:31.643584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    lookup_instance = LookupModule()
    assert lookup_instance._get_terms(terms=['first', 'second'], templar=None, loader=None, variable_manager=None) == ['first', 'second']
    if not PY3:
        assert lookup_instance._get_terms(terms=('first', 'second'), templar=None, loader=None, variable_manager=None) == ['first', 'second']

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'class_keys': {'files': ['file1.yml'], 'paths': ['path1', 'path2']}}
    loader

# Generated at 2022-06-21 06:10:41.329875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = 'test_result'

    class LookupModule_run_obj:
        def _process_terms(self, terms, variables, kwargs):
            return terms, variables, kwargs

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            assert variables == 'variables'
            assert subdir == 'subdir'
            assert fn == 'test_fn'
            assert ignore_missing == True
            return result

    lmr = LookupModule_run_obj()

    terms = 'test_terms'
    variables = 'variables'
    kwargs = 'kwargs'

    assert lmr.run(terms, variables, **kwargs) == result



# Generated at 2022-06-21 06:10:51.122805
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._subdir = 'tests'

    # NOTE: the following may fail to find file depending
    # on which directory the unit test is run from
    # and may fail if the path is too long
    # add the value __file__ below to see where the
    # test is being run from.
    global_dict = dict(__file__='tests/test_utils.py', ansible_distribution='Linux')
    # global_dict = dict(__file__='test_utils.py', ansible_distribution='Linux')

    # NOTE: if local_dict is used with ansible_distribution,
    # then it is used to find files instead of the global_dict.
    # local_dict = dict

# Generated at 2022-06-21 06:10:58.561944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar.environment.loader.searchpath = []
    lookup._templar.environment.loader.files = { "f1" : None }
    lookup._templar.template = lambda x: x
    lookup._validate_paths = lambda : None
    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: "f1" if fn=="f1" else None
    assert len(lookup.run([["f1", "f2"], "f3"], {}, {})) == 1
    assert lookup.run([["f1", "f2"], "f3"], {}, {})[0] == "f1"

# Generated at 2022-06-21 06:11:12.021856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    lookup_plugin = LookupModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    assert lookup_plugin.run(terms=[], variables=variable_manager)[0] == 'localhost'
    assert lookup_plugin.run(terms=['--private-key', '~/.ssh/id_rsa'], variables=variable_manager)[0] == 'localhost'
    assert lookup_plugin.run(terms=['-u', 'root'], variables=variable_manager)[0] == 'localhost'

# Generated at 2022-06-21 06:11:24.158112
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test of the method run of class LookupModule
    import unittest
    import sys
    import os
    import inspect
    import copy

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.module_name = 'lookup_plugins.first_found.LookupModule'
            self.module_dynamic = __import__(self.module_name, fromlist=['lookup_plugins'])

        def test_method_exists(self):
            method = 'run'
            self.assertTrue(hasattr(self.module_dynamic.LookupModule, method),
                            msg="Class '%s' has no method '%s'" % (self.module_name, method))


# Generated at 2022-06-21 06:11:35.046660
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LOOKUP = LookupModule()
    LOOKUP._subdir = 'test'
    assert LOOKUP.run([{'files': 'one two', 'paths': 'path:path2', 'skip': 'yes'}], {},
                    errors='ignore') == ['/tmp/ansible_test/test/path/one', '/tmp/ansible_test/test/path/two',
                                         '/tmp/ansible_test/test/path2/one', '/tmp/ansible_test/test/path2/two']

# Generated at 2022-06-21 06:11:36.674800
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()



# Generated at 2022-06-21 06:13:38.144541
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:13:49.188975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    variables = {}
    kwargs = {'files': 'file1,file2', 'paths': 'path1,path2', 'skip': True}
    lm.set_options(var_options=variables, direct=kwargs)
    filelist = _split_on(lm.get_option('files'), ',;')
    pathlist = _split_on(lm.get_option('paths'), ',:;')
    total_search = []
    for path in pathlist:
        for fn in filelist:
            f = os.path.join(path, fn)
            total_search.append(f)
    assert total_search == ['path1/file1', 'path1/file2', 'path2/file1', 'path2/file2']