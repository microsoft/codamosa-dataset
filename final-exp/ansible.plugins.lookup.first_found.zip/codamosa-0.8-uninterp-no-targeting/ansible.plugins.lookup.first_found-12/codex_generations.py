

# Generated at 2022-06-21 06:03:54.327023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 06:04:05.388516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = DummyTemplar()
    searchpath = ['/path/to/roles/myrole/defaults',
                  '/path/to/roles/myrole/vars']

    # _split_on tests
    assert _split_on(42) == []
    assert _split_on([42, 'foo']) == ['42', 'foo']
    assert _split_on(['foo', 42]) == ['foo', '42']
    assert _split_on('foo,bar') == ['foo', 'bar']
    assert _split_on('foo,bar,baz') == ['foo', 'bar', 'baz']

# Generated at 2022-06-21 06:04:05.869227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:04:19.077934
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # NOTE: reading from file system from testing setup is a bit of a pain
    #       during refacotring realized that 'scope' is 'global' but the option
    #       is set for each 'loop' in the 'terms' being processed. This can lead
    #       to 'unexpected' results when setting a dict as 'term' with more than
    #       one dict as they wll all override the global.
    #       not changing this now since it is a 'breaking' change
    lookup = LookupModule()

    # file / path lists only
    terms = [ '/tmp/foo', '/tmp/bar' ]
    total_search, skip = lookup._process_terms(terms, variables={}, kwargs={})
    assert total_search == terms
    assert skip is False

    # file + path list

# Generated at 2022-06-21 06:04:23.664354
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This unit test simply checks that `LookupModule` the constructor works.
    """
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:04:25.078185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Placeholder to test the run method
    pass

# Generated at 2022-06-21 06:04:25.967738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:04:38.965484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.plugins.loader import lookup_loader

    def get_data_file(TOKEN, TOKEN_VALUE):
        # type: (str, str) -> str
        return os.path.join(os.path.dirname(__file__), 'test_data', 'first_found', TOKEN_VALUE, TOKEN_VALUE)


# Generated at 2022-06-21 06:04:41.611444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["test_file.txt"], {"var": "value"})
    assert result == ['test_file.txt']

# Generated at 2022-06-21 06:04:49.148110
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # use first_found lookup as a template
    terms = [
        {
            u'files': u'default.json',
            u'paths': u'',
            u'skip': True
        }
    ]

    # Use currect directory as base
    basedir = os.path.realpath(os.path.join(os.path.dirname(__file__)))

    # set the first search path
    searchpath = {u'file': [os.path.join(basedir, u'files')]}

    # set the variables
    variables = dict()

    # set the options
    kwargs = None

    # create the object for use
    obj = LookupModule()

    # run the method
    obj._subdir = u'file'

# Generated at 2022-06-21 06:05:02.019153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = [
        "../files/files/bar.txt",
        "../files/files/bar.txt",
        "../files/files/bar.txt",
        "../files/files/bar.txt"
    ]
    paths = [
        "../files",
        "../files",
        "../files",
        "../files"
    ]
    kwargs = {
        "files": files,
        "paths": paths,
        "skip": False
    }
    module = LookupModule()
    assert module.run(files, None, **kwargs) == ["../files/files/bar.txt"]

# Generated at 2022-06-21 06:05:06.071844
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(basedir='/home/username/ansible/',
                 runner='/home/username/ansible/runner/',
                 module_name='/home/username/ansible/module_name.py')


# Generated at 2022-06-21 06:05:07.719514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create instance of LookupModule
    lookup_plugin = LookupModule()
    return lookup_plugin

# Generated at 2022-06-21 06:05:19.823873
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mod = LookupModule()

    valid_file = ['/tmp/ansible_file']
    assert mod.run(terms=['/tmp/ansible_file'], variables={}) == valid_file, \
        "It should return '%s' but returns '%s'" % (valid_file, mod.run(terms=['/tmp/ansible_file'], variables={}))

    assert mod.run(terms=['/tmp/ansible_file', '/tmp/ansible_file2'], variables={}) == valid_file, \
        "It should return '%s' but returns '%s'" % (valid_file, mod.run(terms=['/tmp/ansible_file', '/tmp/ansible_file2'], variables={}))


# Generated at 2022-06-21 06:05:27.678675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_base_case_no_results
    lookup = LookupModule()
    lookup._subdir = 'tasks'
    try:
        lookup.run([],{})
    except Exception as e:
        assert type(e) == AnsibleLookupError
        assert str(e) == "No file was found when using first_found."

    # test_base_case_with_results
    lookup = LookupModule()
    lookup._subdir = 'tasks'
    result = lookup.run(['task1.yaml'],{})
    assert result == [os.path.normpath('%s/../../tasks/task1.yaml' % os.path.dirname(__file__))]

    # test_var_template
    lookup = LookupModule()
    lookup._subdir = 'tasks'


# Generated at 2022-06-21 06:05:41.405027
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # class with mocks for testing method run
    class TestLookupModule(LookupModule):

        # ensure no caching
        _cache = {}

        # mock templar
        class TestTemplar:

            # mock template
            def template(self, fn):
                return fn

        # mock find_file_in_search_path
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            if fn == "test_one":
                return fn
            else:
                return None

    # init LookupModule
    terms = ["test_one"]
    variables = {}
    tlm = TestLookupModule()
    tlm._templar = TestLookupModule.TestTemplar()

    # execute run

# Generated at 2022-06-21 06:05:51.345266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.errors import AnsibleLookupError
    from ansible.plugins.lookup import LookupBase

    class TestLookupBase(LookupBase):

        def __init__(self, loader=None, templar=None, **kwargs):
            pass

        def find_file_in_search_path(self, variables, search_for, path, **kwargs):
            if search_for == 'files/index.html':
                return 'index.html'
            return None

        def _get_file_contents(self, path):
            return []


# Generated at 2022-06-21 06:06:04.731186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test creating object
    import units.compat.mock as mock

    mock_loader = mock.Mock()
    mock_loader.get_basedir.return_value = '/tmp/'
    mock_templar = mock.MagicMock()
    mock_templar.template.return_value = 'fn'
    mock_display = mock.MagicMock()
    mock_vars = mock.MagicMock()

    lookup_plugin = LookupModule(loader=mock_loader,
                                 templar=mock_templar,
                                 display=mock_display)

    # Test getting splitter lists
    assert lookup_plugin._split_on(',', ',') == ['']
    assert lookup_plugin._split_on(',', ':') == [',']
    assert lookup_plugin._

# Generated at 2022-06-21 06:06:11.748998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{'files': '*.txt', 'paths': '/path/to'}, '{{ inventory_hostname }}.yml', dict(files='*.yml'), dict(files=['*.yml', '*.j2'])]
    lookup_module.run(terms, variables={'inventory_hostname': 'test1'})
    lookup_module.run(terms, variables={'inventory_hostname': 'test.j2'})
    lookup_module.run(terms, variables={'inventory_hostname': 'test2'}, skip=True)

# Generated at 2022-06-21 06:06:24.813436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._split_on('test1') == ['test1']
    assert lookup_module._split_on('test1,test2') == ['test1', 'test2']
    assert lookup_module._split_on('test1,test2;test3,test4:test5') == ['test1', 'test2', 'test3', 'test4', 'test5']
    assert lookup_module._split_on('test1 test2') == ['test1', 'test2']
    assert lookup_module._split_on(['test1', 'test2']) == ['test1', 'test2']
    assert lookup_module._split_on(['test1', ['test2']]) == ['test1', 'test2']

# Generated at 2022-06-21 06:06:32.076526
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_lookup = LookupModule()

    # use dict as term to mimic direct use of module, see other notes in code
    terms = [{'files': 'foo', 'paths': 'path'}]
    variables = {}
    kwargs = {}
    results = test_lookup.run(terms=terms, variables=variables, **kwargs)
    assert results == []



# Generated at 2022-06-21 06:06:39.831318
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    modul = LookupModule()
    terms = ['default.conf', {'files': 'foo,bar', 'paths': '/tmp/1,/tmp/2'}, 'baz.conf']
    variables = {'ansible_virtualization_type': 'lxc'}

    # Modify the instance to make it compatible with this test.
    # This method is not accessible in the test context.
    modul.set_options = LookupModule.set_options
    modul.get_option = LookupModule.get_option

    modul._templar = LookupModule._templar = MagicMock()
    modul.find_file_in_search_path = LookupModule.find_file_in_search_path = MagicMock()

    # With first_found option activated
    # This contains the behaviour of the actual

# Generated at 2022-06-21 06:06:44.173490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the LookupModule class"""
    from ansible.plugins.lookup import LookupModule
    lookup_module = LookupModule()
    # method get_option() is tested elsewhere, for now simply ensure
    # get_option() does not raise exception
    lookup_module.get_option('files')


# Generated at 2022-06-21 06:06:56.577204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Initializations
  lookup=LookupModule()
  lookup._loader=object()
  lookup._templar=object()
  lookup._loader.get_basedir=lambda: ':'.join(['path1','path2','path3'])
  lookup.find_file_in_search_path=lambda variables: 'found'
  lookup._subdir='files'

  # Case 1 : file found in first path
  assert lookup.run(['abc'],{'abc':'def'})[0] == 'found'

  # Case 2 : file found in first path only
  lookup.find_file_in_search_path=lambda variables, subdir, fn, ignore_missing: None
  assert lookup.run(['abc'],{'abc':'def'})[0] == 'found'

  # Case 3 : No paths configured

# Generated at 2022-06-21 06:07:09.351113
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # first tests for code not covered by ansible as is for 'internal' return/error

    # test: no options given
    terms = [{}]
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()
    try:
        result = lookup_module.run(terms, variables, **kwargs)
    except AnsibleLookupError:
        result = 'AnsibleLookupError'
    assert result == 'AnsibleLookupError'

    # test: invalid term is not string, dict or list
    terms = [1]
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:07:21.301917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_native
    from ansible.module_utils.plugins.loader import lookup_loader

    lookup = lookup_loader.get('first_found', loader=None)

    # testing '_process_terms'
    # TODO: add tests once we work out how to use them (as they call 'self.find_file_in_search_path')
    # NOTE: they will need to use a class to be able to use the 'self.find_file_in_search_path' method.
    # NOTE: the 'skip' option works but not for the 'extend' of the 'for' loop

    # testing when dict is provided
    # checks 'files' and 'paths' add to the list
    # checks 'skip' override
   

# Generated at 2022-06-21 06:07:23.747035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:07:34.335290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()

    # Test blank terms
    assert test.run([], dict()) == [], 'failed to handle no terms'

    # Test blank strings
    assert test.run(['foo'], dict()) == [], 'failed to handle no files given'

    # Test paths and list of files
    assert test.run([{'files': ['foo'], 'paths': ['/tmp']}], dict()) == [], 'failed to handle no existing file given'

    # Test that the first file is taken
    assert test.run([{'files': ['one', 'two'], 'paths': ['/tmp']}], dict(ansible_env={'HOME': '/tmp'})) == ['/tmp/one'], 'failed to handle list of files'

    # Test that no file is selected if all of them does not exist

# Generated at 2022-06-21 06:07:39.197750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Method run returns data type list
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(terms = ['hello-world.txt'], variables = {'ansible_distribution': 'Ubuntu', 'ansible_os_family': 'Debian'}), list)


# Generated at 2022-06-21 06:07:52.874040
# Unit test for constructor of class LookupModule
def test_LookupModule():
    
    # Test #1
    def mocked_term(terms, variables, kwargs):
        
        total_search = []
        skip = False
        
        # can use a dict instead of list item to pass inline config
        for term in terms:
            if isinstance(term, Mapping):
                pass
            elif isinstance(term, string_types):
                pass
            elif isinstance(term, Sequence):
                partial, skip = mocked_term(term, variables, kwargs)
                total_search.extend(partial)
                continue
            else:
                raise AnsibleLookupError("Invalid term supplied, can handle string, mapping or list of strings but got: %s for %s" % (type(term), term))
        
        # create search structure
        #if pathlist:
        #    for path in path

# Generated at 2022-06-21 06:08:00.018415
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert False, "Test not implemented"

# Generated at 2022-06-21 06:08:12.293637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # setup env
    lookup.loader = DictDataLoader({})
    lookup._load_name_to_path_cache()
    lookup._templar = DummyTemplar()

    # test
    dummy_variables = DummyVars()
    for testcase in testcases:
        if testcase.name != 'test_run':
            continue
        if testcase.version != '20201016':
            continue
        if testcase.expected:
            if testcase.skip_if_not_found:
                lookup.set_options({'skip': True})
            else:
                lookup.set_options({'skip': False})

            # run method

# Generated at 2022-06-21 06:08:21.624658
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class FakeVars:
        ansible_virtualization_type = 'other'
        ansible_os_family = 'other'

    class FakeSubdir:
        _subdir = 'files'

    class FakeTemplar:
        def template(self, fn):
            return fn
        def find_file_in_search_path(self, subdir, fn, ignore_missing=True):
            return 'default_foo.conf'

    lookup = LookupModule()
    lookup._templar = FakeTemplar()
    lookup._subdir = FakeSubdir()
    lookup.run([{'files': '{{ ansible_virtualization_type }}_foo.conf'}, '{{ ansible_os_family }}.yml'], FakeVars())
    lookup.run(['foo'], FakeVars())
    lookup.run

# Generated at 2022-06-21 06:08:34.796415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    import os, sys
    import test.support
    import unittest
    from ansible.plugins.lookup.first_found import LookupModule
    test_file = os.path.join(os.path.dirname(__file__), '../../../test/templates/lookup_modules/dummy.txt')
    module = LookupModule('/root/.ansible/tmp/ansible-tmp-1568883233.11-197015552767463/templates')
    terms = [os.path.join(os.path.dirname(__file__), test_file)]
    module._subdir = 'files'
    self = unittest.TestSuite()

# Generated at 2022-06-21 06:08:42.873231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = {
        'terms': [
            {'files': ['test1']},
            {'files': ['test2']},
            {'files': ['test3'],'paths': ['test1_path']},
            {'files': ['test4'],'paths': ['test2_path']},
            {'files': ['test5'],'paths': ['test1_path','test2_path']},
        ],
        'variables': {},
        'kwargs': {},
        'expected': [
            ['test1'],
            ['test2'],
            ['test1_path/test3'],
            ['test2_path/test4'],
            ['test1_path/test5','test2_path/test5'],
        ],
    }
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:08:49.928803
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Will not create an object of class LookupModule and will not
    # give AssertionError as LookupModule is an abstract class.
    # It is not possible to invoke LookupModule as it is an abstract class.
    with pytest.raises(AssertionError) as error:
        assert test_object is LookupModule

# Generated at 2022-06-21 06:08:52.925598
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule instance
    lm = LookupModule()
    # Get attributes of LookupModule
    attr = lm.get_option('')
    # Check if lookup module is empty
    assert(not attr)


# Generated at 2022-06-21 06:09:05.252685
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Chainable dicts and lists are needed to test _process_terms
    class ChainableDict(dict):
        def __or__(self, other):
            return ChainableDict(self, **other)

    class ChainableList(list):
        def __or__(self, other):
            return ChainableList(self + other)

    # Test cases.
    # Test dictionaries have the following meaning:
    #     'terms' - terms to be passed as parameter to run method of LookupModule
    #     'expected_search' - expected total_search after running _process_terms
    #     'expected_skip' - expected skip after running _process_terms
    #     'files_folder' - files to be created for tests
    #     'maxDiff' - maximum difference for strings
    # The following strings have a special meaning when found in

# Generated at 2022-06-21 06:09:15.795544
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    terms = [{'name': 'foo'}, "{{ inventory_hostname }}", {'name': 'bar'}]
    variables = {}
    paths = ['/tmp/production', '/tmp/staging']
    expected_result = [
        "/tmp/production/foo",
        "/tmp/staging/foo",
        "/tmp/production/{{ inventory_hostname }}",
        "/tmp/staging/{{ inventory_hostname }}",
        "/tmp/production/bar",
        "/tmp/staging/bar"
    ]
    result = lm._process_terms(terms, variables, {'paths': paths})
    assert result[0] == expected_result

# Generated at 2022-06-21 06:09:17.514983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testLookupModule = LookupModule()
    # Check if internals exist
    assert hasattr(testLookupModule, '_templar')

# Generated at 2022-06-21 06:09:39.725044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.lookup.plugins.first_found import LookupModule

    opts = ImmutableDict({'files': '*.txt', 'paths': ['/path/to/foo', 'bar']})
    m = AnsibleModule(
        argument_spec={
            'terms': {
                'type': 'str', 'default': '{{ ansible_hostname }}.conf',
                'elements': str
            }
        },
        supports_check_mode=False,
    )
    lookup_module = LookupModule()
    r = lookup_module.run(terms=['.txt'], variables={'ansible_hostname': 'foo'})

# Generated at 2022-06-21 06:09:44.106540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'get_option')
    assert hasattr(lookup_module, 'find_file_in_search_path')

# Generated at 2022-06-21 06:09:46.869667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # As _process_terms is failing, it is not useful to implement full unit tests.
    pass


# Generated at 2022-06-21 06:09:48.398855
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None)

# Generated at 2022-06-21 06:09:51.338329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:10:00.209640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ["/tmp", "/usr/tmp"]
    total_search, skip = lm._process_terms(terms, None, None)
    assert False == skip
    assert 2 == len(total_search)
    assert "/tmp" in total_search
    assert "/usr/tmp" in total_search

    terms = [{"trace_adds": True, "paths": "/tmp"}]
    total_search, skip = lm._process_terms(terms, None, None)
    assert False == skip
    assert 1 == len(total_search)
    assert "/tmp" in total_search

    terms = [{"skip": True, "paths": "/tmp"}]
    total_search, skip = lm._process_terms(terms, None, None)
    assert True == skip
    assert 1

# Generated at 2022-06-21 06:10:09.208277
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    files = "/tmp/file1,file2,/tmp/file3"
    paths = "/tmp,/opt"
    terms = files.split(',')
    variables = {}

    try:
        total_search, skip = module._process_terms(terms, variables, None)
    except Exception as ex:
        assert False, "Error while calling method _process_terms of class LookupModule: %s" % str(ex)

    assert total_search == [files], "Error while calling method _process_terms of class LookupModule: wrong value of total_search"
    assert skip == False, "Error while calling method _process_terms of class LookupModule: wrong value of skip"

    files = "/tmp/file1,/tmp/file2,/tmp/file3"

# Generated at 2022-06-21 06:10:16.404603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    errors = []
    filename = os.path.dirname(os.path.realpath(__file__)) + '/../files/testfiles/foo.conf'
    try:
        result = lookup.run([filename], {})
        assert result == [filename]
    except Exception as e:
        errors.append(str(e))
    assert not errors

# Generated at 2022-06-21 06:10:29.573821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # 1.
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['/var/tmp/1.txt', 'var/tmp/2.txt'], variables=None, **{'skip': True}) == []
    # 2.
    lookup_module = LookupModule()
    lookup_module._templar = Templar(None)
    lookup_module._templar.available_variables = {}
    arg1 = [
        {
            'paths': ['/var/tmp'],
            'files': ['1.txt', '2.txt']
        },
        '/var/tmp/3.txt'
    ]
    assert lookup_module.run(terms=arg1, variables=None, **{'skip': True}) == ['/var/tmp/1.txt']
    # 3.

# Generated at 2022-06-21 06:10:36.257195
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create an instance of plugin class
    lookup_plugin = LookupModule()

    # create a dict containing the arguments in plugin call
    kwargs = dict()
    kwargs['files'] = 'foo.txt'
    kwargs['paths'] = 'files'
    kwargs['skip'] = False

    # create a list of dicts containing the file and path to each file
    files = list()
    files.append(dict())

    terms = list()
    terms.append('foo.txt')
    terms.append(kwargs)

    files[0]['file'] = 'files/foo.txt'
    files[0]['path'] = 'files/foo.txt'

    # create a dict containing the variables in plugin call

    # as we do not have any variable this dict is empty
    variables = dict()

   

# Generated at 2022-06-21 06:11:00.407517
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:11:01.766536
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:11:14.000533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock class LookupBase
    class LookupBaseMock():
        subdir = 'files'
        _templar = ""
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return ""

        def set_options(self, var_options, direct):
            return ""
        def get_option(self, option):
            return ""

    # Mock class AnsibleLookupError
    class AnsibleLookupErrorMock(Exception):
        pass

    # Mock class AnsibleUndefinedVariable
    class AnsibleUndefinedVariableMock(Exception):
        pass

    # Mock class UndefinedError
    class UndefinedErrorMock(Exception):
        pass

    # Mock class AnsibleUndefinedVariable
    class AnsibleUndefinedVariableMock(Exception):
        pass



# Generated at 2022-06-21 06:11:21.765475
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # test terms list
    terms = [
        dict(paths=['c:/windows/temp']),
        "foo",
        dict(paths=['c:/users/wilsonmar/foo']),
        ]

    result = lookup.run(terms, dict(ansible_env=dict(TEMP="C:\\Users\\wilsonmar\\AppData\\Local\\Temp")))
    assert result is not None



# Generated at 2022-06-21 06:11:33.864191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests.mock import patch

    # Arrange
    lookup_module = LookupModule()
    lookup_module._subdir = 'files'
    lookup_module._templar = object()
    lookup_module._loader = object()
    lookup_module.set_options(var_options={}, direct={'files': ['foo.txt', 'bar.txt'], 'paths': ['path/to/files']})
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: 'path/to/files/bar.txt'

    # Act
    with patch.object(lookup_module, '_process_terms', return_value=('path/to/files/bar.txt', False)) as mock_process_terms:
        found_files = lookup_

# Generated at 2022-06-21 06:11:36.451022
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:11:46.042728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    lookup = LookupModule()
    lookup_method = getattr(lookup, 'run')
    lookup._templar._available_variables = { 'inventory_hostname': 'hostname' }
    lookup._loader = 'fake_loader'
    lookup._templar.set_loader('fake_loader')

    # Term is string
    term = 'file_to_find.txt'
    ret = lookup_method([term], {})
    assert ret == ['./file_to_find.txt'], "%s != %s" % (ret, ['./file_to_find.txt'])

    # Term is list of string
    term1 = 'file_to_find1.txt'
    term2 = 'file_to_find2.txt'

# Generated at 2022-06-21 06:11:56.898812
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create mock imports

    class AnsibleUndefinedVariable:
        pass

    class UndefinedError:
        pass

    class Mapping:
        pass

    class Sequence:
        pass

    class Templates:
        def __init__(self, template):
            self.template = template

    # Create mock class of the module LookupBase
    class LookupBase():
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return None

    # Create mock class of the module LookupModule
    class LookupModule(LookupBase):
        def __init__(self):
            self._subdir = 'files'
            self._templar = Templates("test")

        def set_options(self, var_options=[], direct={}):
            pass


# Generated at 2022-06-21 06:12:03.589306
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # first_found should return the path to first existing file in the list
    lookup = LookupModule()
    assert lookup._templar.template("{{ lookup('first_found', 'afile,bfile') }}") == "afile"

    lookup = LookupModule()
    assert lookup._templar.template("{{ lookup('first_found', ['afile']) }}") == "afile"

    assert lookup._templar.template("{{ lookup('first_found', ['afile', 'cfile']) }}") == "afile"

    assert lookup._templar.template("{{ lookup('first_found', ['afile', 'bfile']) }}") == "afile"

    # this will error since 'afile' and 'bfile' are not found
    lookup = LookupModule()

# Generated at 2022-06-21 06:12:11.889693
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_obj = LookupModule()
    lookup_obj._subdir = 'files'

    terms = [{'files': 'some_file.txt', 'paths': '/tmp'}, {'files': 'some_file.txt', 'paths': '/tmp'}]
    vars = {'inventory_hostname': 'localhost'}
    kwargs = {}

    expected_total_search = ['/tmp/some_file.txt', '/tmp/some_file.txt']
    skip = False

    total_search, skip_value = lookup_obj._process_terms(terms, vars, kwargs)
    assert total_search == expected_total_search
    assert skip_value == skip

# Generated at 2022-06-21 06:13:13.926888
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameterization
    my_vars = {
        'foo': 'bar'
    }
    # NOTE: for path searches 'paths' is not supported, but it is used in unit tests elsewhere
    my_kwargs = {
        'files': [
            'foo.conf',
            '{{ foo }}.conf'
        ],
        'paths': [
            '/path/to/file',
            '/path/to/another/'
        ]
    }
    my_terms = ['test.conf']
    my_terms_invalid = ['test.conf', {'files': [], 'paths': []}]

    # Expected result
    my_result = ['/path/to/file/foo.conf']

    # Expected exception type
    my_exception_type = AnsibleLookupError

    #

# Generated at 2022-06-21 06:13:23.788618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        {'files': 'foo.txt', 'paths': '/tmp'},
        {'files': [ 'bar.txt', 'baz.txt' ], 'paths': [ 'one', 'two' ]}
    ]

    variables = {}
    result = lookup.run(terms, variables)
    assert result == ['/tmp/foo.txt']

    result = lookup.run(terms, variables)
    assert result == ['one/bar.txt', 'one/baz.txt', 'two/bar.txt', 'two/baz.txt']


# Generated at 2022-06-21 06:13:38.143484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    look = LookupModule()

    # Set the variables
    variables = dict()
    variables['role_path'] = "DEFAULT"
    variables['role_name'] = "DEFAULT"
    variables['role_uuid'] = "DEFAULT"
    variables['playbook_dir'] = "DEFAULT"
    variables['play_name'] = "DEFAULT"
    variables['task_name'] = "DEFAULT"
    variables['include_role_tasks'] = "DEFAULT"

    # Set the class variables
    look._basedir = "DEFAULT"
    look._loader = "DEFAULT"
    look._templar = "DEFAULT"

    # Test when terms and dicts are okay
    terms = [{"files": ["test_file.txt"], "paths": ["."]}]

# Generated at 2022-06-21 06:13:49.189304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import __builtin__
    sys.modules['__builtin__'] = __builtin__

    class Templar(object):
        def template(self, fn):
            return fn

    class AnsibleUndefinedVariable(object):
        pass

    class AnsibleLookupError(Exception):
        pass

    class LookupModule(object):
        def __init__(self, templar, subdir, find_file_in_search_path):
            self._templar = templar
            self._subdir = subdir
            self.find_file_in_search_path = find_file_in_search_path
