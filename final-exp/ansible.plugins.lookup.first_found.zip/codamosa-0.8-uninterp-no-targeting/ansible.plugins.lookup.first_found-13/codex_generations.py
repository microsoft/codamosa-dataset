

# Generated at 2022-06-21 06:03:53.705938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None



# Generated at 2022-06-21 06:04:04.745122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = MockTemplar()

    # Set up mock 'variables'
    variables = {}
    variables['role_path'] = 'test/roles/role_role'
    variables['playbook_dir'] = '/test/playbooks/playbook_playbook'
    variables['hostvars'] = {'localhost': {}}
    variables['hostvars']['localhost']['inventory_dir'] = '/test/playbooks/inventory_inventory'
    variables['hostvars']['localhost']['play_hosts'] = ['localhost']

    # Set up mock file system
    mock_file_system = {}
    mock_file_system['test/roles/role_roles/files/role_file1'] = 'role_file1'
    mock_file_system

# Generated at 2022-06-21 06:04:11.383395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None
    assert lookup.run([], variables=None, **{}) == [], "first_found lookup with an empty file list and no template-based variables should return an empty list"
    assert lookup.run([Sentinel('Executor.run')], variables=None, **{}) == [], "first_found lookup with an empty file list and a Sentinel value should return an empty list"
    assert lookup.run(['file1'], variables=None, **{}) == [], "first_found lookup with one file and no template-based variables should return an empty list"

# Generated at 2022-06-21 06:04:21.980940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader

    my_play = Play()
    my_play.vars = {}
    my_play.vars.update({
        'my_file_list': [
            'foo.txt',
            'bar.txt',
            'baz.txt'
        ]
    })


# Generated at 2022-06-21 06:04:29.626787
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run(terms=['hoge'], variables={}) == []
    assert l.run(terms=['hoge'], variables={}, skip=True) == []
    assert l.run(terms=['hoge'], variables={'hoge': 'fuga'}) == []
    assert l.run(terms=['hoge'], variables={'hoge': False}) == []
    lookup_result = l.run(terms=[], variables={})
    assert lookup_result[0] == 'LookupError: No file was found when using first_found.'

# Generated at 2022-06-21 06:04:30.454792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:04:34.475989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # expected parameters to lookup module
    terms = ['/tmp/hello1.txt','/tmp/hello2.txt']
    # create an object of class module
    lookup_obj = LookupModule(terms, "", {}, None, "")
    # call the run method of the class and run the test
    actual_results = lookup_obj.run(terms, {}, skip=True)
    expected_results = []
    # for the test to pass the actual and expected results must be the same
    assert actual_results == expected_results

# Generated at 2022-06-21 06:04:42.422548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()

    # Use method run to test unit test
    files = ['file1']
    lookupModule.set_options(var_options=None, direct={'files': files})
    assert lookupModule.run(terms=['/path/to/foo.txt'], variables=None, skip=True) == []

    lookupModule.set_options(var_options=None, direct={'files': files})
    assert lookupModule.run(terms=[], variables=None, skip=True) == []

    lookupModule.set_options(var_options=None, direct={'files': files})
    assert lookupModule.run(terms=['/path/to/foo.txt'], variables=None, skip=False) == []

# Generated at 2022-06-21 06:04:43.683044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert lookup_mod is not None

# Generated at 2022-06-21 06:04:49.144103
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create basic LookupModule class with default values
    lookup_module = LookupModule()

    # assert default values
    assert(lookup_module._subdir == 'files')

    # set subdir to new value and assert it
    lookup_module._subdir = 'vars'
    assert(lookup_module._subdir == 'vars')

# Generated at 2022-06-21 06:04:57.350031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # E0102: Resolved by type checker
    # pylint: disable=E0102
    # C0111: Missing docstring
    # pylint: disable=C0111
    assert all([
            # args
            (isinstance(LookupModule.run, staticmethod)),
            ])
    return True

# Generated at 2022-06-21 06:05:07.155298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # test no args
    assert lm.run([], {}) == None
    # test terms is not a list
    assert lm.run("badterm", {}) == None
    # test terms is a list and subdir is not there
    res = lm.run(["foo"], {})
    assert res == None
    # test terms is a list and subdir is there
    lm._subdir = 'foo'
    res = lm.run(["foo"], {})
    assert res == None
    lm._subdir = None
    # test terms is a list and subdir is there
    res = lm.run(["foo"], {})
    assert res == None
    del lm

# Generated at 2022-06-21 06:05:09.464465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:05:19.290429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test implementation of run() of class LookupModule"""
    from hyperscript import load_js
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    lookup = lookup_loader.get(u'first_found', class_only=True)

    # manager = basic.AnsibleModule(
    #     argument_spec = dict(
    #     ),
    # )
    # manager._socket_path = u'/var/ansible/test'
    # manager._ansible_version = '2.9.9.9'
   

# Generated at 2022-06-21 06:05:31.806298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._templar = None
    l._loader = None

    terms = "foo"
    total_search, skip = l._process_terms(terms, None, None)
    assert total_search == ['foo'], "test_LookupModule:test_1"

    # test skip=True
    terms = "foo"
    total_search, skip = l._process_terms(terms, None, {'skip': True})
    assert total_search == ['foo'], "test_LookupModule:test_2"
    assert skip == True, "test_LookupModule:test_3"

    # test skip=False
    terms = "foo"
    total_search, skip = l._process_terms(terms, None, {'skip': False})

# Generated at 2022-06-21 06:05:33.279710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:05:43.136968
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    # check _split_on function
    #
    # test with string
    assert _split_on('/tmp/ansible.cfg,/tmp/hosts', ',') == ['/tmp/ansible.cfg', '/tmp/hosts']
    assert _split_on('/tmp/ansible.cfg;/tmp/hosts', ';') == ['/tmp/ansible.cfg', '/tmp/hosts']
    #
    # test with list of strings
    assert _split_on(['/tmp/ansible.cfg,/tmp/hosts'], ',') == ['/tmp/ansible.cfg', '/tmp/hosts']

# Generated at 2022-06-21 06:05:45.639069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Unit test function for LookupModule._split_on

# Generated at 2022-06-21 06:05:52.042206
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_skip = True
    global_files = 'foo.yaml'
    global_paths = '/tmp'

    terms_list = ['foo', 'bar']
    terms_dict = {'files': global_files, 'paths': global_paths, 'skip': global_skip}
    global_terms = [terms_list, terms_dict]

    lookup = LookupModule()

    assert lookup._process_terms(global_terms, None, None) == (['/tmp/foo.yaml'], global_skip)

# Generated at 2022-06-21 06:05:55.095684
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule._plugins is not None

# Generated at 2022-06-21 06:06:08.349629
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:06:16.873880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Check for successful lookup
    data = lookup_plugin.run(['test1.yml'], {}, variable_manager='', loader='', templar='', shared_loader_obj='')
    assert type(data) is list and len(data) == 1 and data[0].endswith('lookup_plugins/test1.yml')

    # Check for failure on invalid term, the templar will raise an exception while attempting to cast non-string term to a string
    try:
        data = lookup_plugin.run([{'files':'test.yml'}], {}, variable_manager='', loader='', templar='', shared_loader_obj='')
    except AnsibleLookupError:
        data = None
    assert data is None

    # Check for failure on invalid

# Generated at 2022-06-21 06:06:17.753669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:06:26.882316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    with pytest.raises(AnsibleLookupError):
        module.run(['abc'])
    with pytest.raises(AnsibleLookupError):
        module.run([''], {'files': "abc"})
    with pytest.raises(AnsibleLookupError):
        module.run([''], {'paths': "abc"})
    with pytest.raises(AnsibleLookupError):
        module.run([''], {'files': "abc", 'paths': "abc"})
    with pytest.raises(AnsibleLookupError):
        module.run([''])
    assert module.run([''], {'files': "", 'paths': ""}, skip=True) == []

# Generated at 2022-06-21 06:06:28.143379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  module = LookupModule()
  assert module.run(terms = [], variables = {}, skip = False) == None

# Generated at 2022-06-21 06:06:33.444504
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: use fixtures instead of hardcoding?
    subdir = 'files'
    fn = 'test_LookupModule_run.txt'

    # create the class to test
    item = LookupModule()
    item._subdir = subdir

    # mock return of find_file_in_search_path()
    def mock_find_file_in_search_path(variables, subdir, fn, ignore_missing=True):
        return None
    item.find_file_in_search_path = mock_find_file_in_search_path

    # test it
    # test where no files are found
    terms = ['/tmp']
    variables = {}
    expected = []
    result = item.run(terms, variables, skip=True)
    assert result == expected

    # test where no files are found


# Generated at 2022-06-21 06:06:41.276880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This tests the run method of the LookupModule class
    # The testing of the first_found lookup is done through the tests for the
    # lookup itself.
    # TODO: This should be replaced with something better...
    module = LookupModule()
    params = dict(files=['file1', 'file2'], paths=['/abc/'])
    module.run([params], dict())

# Generated at 2022-06-21 06:06:42.165545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:06:44.645021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupmodule = LookupModule()

    lookupmodule._loader = None
    lookupmodule._templar = None
    lookupmodule._display = None

    lookupmodule.run([{'paths': '/dev/null'}], {}, [])

    assert False

# Generated at 2022-06-21 06:06:55.369697
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    import os
    import tempfile

    # setup
    temp_dir = tempfile.mkdtemp()

    # create a set of files
    temp_file_path_1 = os.path.join(temp_dir, 'file1')
    fh = open(temp_file_path_1, 'w')
    fh.write('first')
    fh.close()

    temp_file_path_2 = os.path.join(temp_dir, 'file2')
    fh = open(temp_file_path_2, 'w')
    fh.write('second')
    fh.close()

    lookup = LookupModule()

# Generated at 2022-06-21 06:07:03.119309
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup.run(terms='a,b,c', variables={}) == ['a', 'b', 'c']


# Generated at 2022-06-21 06:07:11.325263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test empty list
    assert LookupModule().run([], {}) == []
    # test return value
    assert LookupModule().run([{'files': ['/path/to/file1', '/path/to/file2'], 'paths': ['/path/to/']}], {}) == ['/path/to/file1']
    # test return value with template
    assert LookupModule().run([{'files': ['file{{ test1 }}', 'file2', 'file3'], 'paths': ['path/to/', 'path/to/']}], {'test1': '1'}) == ['path/to/file1']
    # test skip option

# Generated at 2022-06-21 06:07:11.829962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0

# Generated at 2022-06-21 06:07:20.799539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader

    if PY3:
        # python3 made non-string keys illegal
        lookup_args = {'_raw': ['/path/to/file']}
    else:
        lookup_args = {u'_raw': ['/path/to/file']}
    lookup = LookupModule()
    lookup.set_loader({})
    assert lookup.run(['foo.txt'], dict(), errors="ignore") == []
    assert lookup.run(['foo.txt'], dict(), skip=True) == []

# Generated at 2022-06-21 06:07:33.189627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pre-setup
    from ansible.module_utils.six import StringIO
    from ansible.errors import AnsibleError
    from ansible.module_utils.six.moves import configparser
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    # parsed CLI options
    display = Display()
    variable_manager = VariableManager()

    # Ansible inventory
    ini_file = StringIO()
    config = configparser.RawConfigParser()
    config.add_section('inventory')
    config.set('inventory', 'host_one', '')
    config.write(ini_file)
    ini_file.seek(0)


# Generated at 2022-06-21 06:07:42.629385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """
  Test for method run of class LookupModule

  """

# Generated at 2022-06-21 06:07:46.277837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-21 06:07:55.502532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import builtins

    class File(object):
        def __init__(self, name):
            self.name = name
            self.closed = False
            self.mode = 'r'

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def close(self):
            self.closed = True

    # A file to be 'found'
    found_file = File('found')

    # A file to be 'not found'
    not_found_file = File('not_found')

    class FakeTemplar(object):
        def template(self, value):
            return value

   

# Generated at 2022-06-21 06:08:03.277614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    params = dict(
        _terms=['vars', '/tmp/production', '/tmp/staging'],
        files=['{{ ansible_distribution }}.yml'],
        paths=['vars'],
        skip=False
    )
    with pytest.raises(AnsibleLookupError) as excinfo:
        module.run(**params)
    assert 'No file was found when using first_found.' in str(excinfo.value)

# Generated at 2022-06-21 06:08:12.910156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test defaults
    lookup_mod = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    opts = lookup_mod._options
    assert opts['skip'] is False
    assert opts['files'] == []
    assert opts['paths'] == []

    # test constructor with args
    lookup_mod = LookupModule(loader=None, templar=None, shared_loader_obj=None, paths=['/tmp'], files=['foo', 'bar'])
    opts = lookup_mod._options
    assert opts['skip'] is False
    assert opts['files'] == ['foo', 'bar']
    assert opts['paths'] == ['/tmp']

    # test constructor with dict

# Generated at 2022-06-21 06:08:20.977152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:08:22.068105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)

# Generated at 2022-06-21 06:08:25.144973
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LK = LookupModule()
    assert isinstance(LK, LookupModule)


# Generated at 2022-06-21 06:08:36.760974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    string_terms = 'file1,file2,file3'
    list_terms = [
         'file1',
         'file2',
         'file3',
         'file4',
         ]
    dict_terms = [
         {'files': 'file1, file2, file3', 'paths': '/path/to/file1, /path/to/file2'}
         ]
    kwargs = {'files': 'file1, file2, file3', 'paths': '/path/to/file1, /path/to/file2'}


# Generated at 2022-06-21 06:08:39.595409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:08:53.354043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types

    # Test _split_on with a list
    arg = ["one,two", "three,four:five:six:seven,eight"]
    assert _split_on(arg, ',:;') == ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight']

    # Test _split_on with a string
    arg = "one,two,:three:four;five,six;seven:eight"
    assert _split_on(arg, ',:;') == ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight']

    # Test _split_on with a list of strings
    arg = ["one,two", ";three,four;", ":five:", "six;seven,eight"]

# Generated at 2022-06-21 06:09:05.505788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    # Test for error when term is a dictionary and does not contains "files"
    try:
        lu.run(terms=dict(paths=['/tmp', '/etc']), variables=dict())
        assert(False)
    except AnsibleLookupError:
        pass

    # Test for error when term is a dictionary and contains "files" but not contain a list
    try:
        lu.run(terms=dict(files=dict(), paths=['/tmp', '/etc']), variables=dict())
        assert(False)
    except AnsibleLookupError:
        pass
    # Test for error when term is a list but does not contains a dictionary
    # and contains "files" but not contain a list

# Generated at 2022-06-21 06:09:12.481533
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:09:14.097082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:09:25.843063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._flattened = False
    assert lookup._flattened is False

    lookup.flatten_hash(dict(a=dict(b=5)))
    assert lookup._flattened == dict(a__b=5)

    lookup._flattened = dict(a__b=5)
    lookup.unflatten_hash()
    assert lookup._flattened == dict(a=dict(b=5))

    lookup._terms = [1, 2, 3]
    lookup._flattened = dict(a=dict(b=5))
    lookup._task_vars = dict(x=dict(y=6))
    lookup._variables = dict(a=1, b=2, c=3)
    lookup._loader = dict(list=list, map=map, zip=zip)


# Generated at 2022-06-21 06:09:48.847718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import shutil
    from ansible.constants import DEFAULT_TASK_INCLUDE_ROLE_PATHS
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'a', 'b': 'b', 'c': 'c', 'd': '/tmp/d', 'e': '/tmp/e'}
    variable_manager.options_vars = {'ansible_verbosity': 0}

    # test with role path where role is

# Generated at 2022-06-21 06:09:59.276962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import unittest

    class options:
        files = ['file1']
        paths = ['/tmp']
        skip = True

    class environment:
        def __init__(self):
            pass

    class variables:
        def __init__(self):
            pass

    class Jinja2:
        def __init__(self):
            self.undefined = UndefinedError

    class LookupBase:
        def __init__(self):
            self._subdir = None
            self._templar = Jinja2()

        def set_options(self, var_options, direct):
            self.files = direct.get('files', []) or var_options.files
            self.paths = direct.get('paths', []) or var_options.paths
            self.skip

# Generated at 2022-06-21 06:10:07.404433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = 'template/templar'
    lookup_module._loader = 'loader'
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: './' + fn
    lookup_module._process_terms = lambda terms, variables, kwargs: (['./foo.txt', './bar.txt'], True)

    assert lookup_module.run(['foo.txt', 'bar.txt'], {}) == ['./foo.txt']

# Generated at 2022-06-21 06:10:19.518225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pl = LookupModule()

# Generated at 2022-06-21 06:10:24.253361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #######################################################################
    # LookupModule.run() Test
    #######################################################################
    # 1.1. Test run without data in file
    #######################################################################
    print("Test 1.1. run without data in file")
    lm = LookupModule()
    terms = ['file1.txt']
    variables = {}
    kwargs = {}
    result = lm.run(terms, variables, **kwargs)
    assert result == ['/tmp/file1.txt']

    # 1.2. Test run without data in file
    #######################################################################
    print("Test 1.2. run without data in file")
    lm = LookupModule()
    terms = ['file1.txt']
    variables = {}
    kwargs = {}

# Generated at 2022-06-21 06:10:25.475756
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._subdir is None

    # Set _subdir
    lookup._subdir = "test"
    assert lookup._subdir == "test"

# Generated at 2022-06-21 06:10:27.199824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:10:39.723951
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup = LookupModule()
    lookup._templar = None

    # Action

    # This testing is for the following case:
    # [(u'a', u'my_files/01.txt'), (u'b', u'my_files/02.txt'), (u'c', u'my_files/03.txt')]

    total_search, skip = lookup._process_terms([{
        'files': '01.txt, 02.txt, 03.txt',
        'paths': 'my_files'
    }], None, None)

    # Assert
    assert total_search[0] == 'my_files/01.txt'
    assert total_search[1] == 'my_files/02.txt'
    assert total_search[2] == 'my_files/03.txt'

# Generated at 2022-06-21 06:10:40.268671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:10:41.916167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 06:11:19.417678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test of LookupModule.run"""
    # parameter setup
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._basedir = ''
    lookup_module._subdir = 'files'
    lookup_module._datastore = None
    lookup_module._fallback = []
    lookup_module._play_context = None

    lookup_module.run(['/tmp/foo', '/tmp/bar'], None)

# Generated at 2022-06-21 06:11:23.070938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:11:34.528662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from collections import namedtuple

    # set up looker helper
    LookupModuleTestHelper = namedtuple("Looker",("find_file_in_search_path",))
    looker = LookupModuleTestHelper(find_file_in_search_path = lambda variables, subdir, fn, ignore_missing=False: "/some/file/found.txt")

    # set up templater helper
    TemplarTestHelper = namedtuple("Templar",("template"))
    templar = TemplarTestHelper(template = lambda fn: fn)

    # set up variables
    vars_namedtuple = namedtuple("Vars",("template",))
    variables = vars_namedtuple(template = {"my_var" : "hi"})

    # set up the instance
    instance = LookupModule()

# Generated at 2022-06-21 06:11:45.375475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    base_dir = '/var/tmp/ansible-lookup'

    # Test with a list that contains one file in the base_dir
    assert lookup_instance.run([os.path.join(base_dir, 'foo')], {}) == ['/var/tmp/ansible-lookup/foo']

    # Test with a list that contains an absolute path
    assert lookup_instance.run(['/tmp/foo'], {}) == ['/tmp/foo']

    # Test with a list that contains a relative path
    assert lookup_instance.run(['tmp/foo'], {}) == ['tmp/foo']

    # Test with a list that contains a file in a sub-directory of base_dir

# Generated at 2022-06-21 06:11:56.605899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.utils.encrypt import do_encrypt as encrypt
    from ansible.utils.encrypt import do_decrypt as decrypt
    import sys

    puppet_module_path = '/etc/puppetlabs/code/environments/production/modules'
    puppet_files = ['%s/%s/%s' % (puppet_module_path, module, 'lookup_plugin.py') for module in ['nfs', 'apache', 'haproxy', 'ntp']]

    # Setup test data

# Generated at 2022-06-21 06:12:03.487471
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # non-existing module name
    lookup_module_name = 'no_exist'

    # empty terms
    terms = []

    # empty vars
    variables = {}

    # minimize the arguments
    kwargs = {}

    # create lookup module
    lookup_module = LookupModule()

    # test initialization
    try:
        lookup_module._init_lookup_module(lookup_module_name, terms, variables, **kwargs)
    except AnsibleLookupError:
        pass



# Generated at 2022-06-21 06:12:13.340164
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    For testing first using 'dual mode' and then using the new simplified format
    """
    lookup = LookupModule()

    # create search structure
    terms = 'foo,bar.txt'
    lookup.set_options(direct={'files': terms})
    filelist = _split_on(terms, ',;')

    paths = '/extra/path'
    lookup.set_options(direct={'paths': paths})
    pathlist = _split_on(paths, ',:;')

    search, skip = lookup._process_terms([{'files': 'foo', 'paths': '/extra/path'}, 'bar.txt'], {}, {})
    assert pathlist[0] in search
    assert filelist[0] in search
    assert filelist[1] in search

    # check simplified format
    search,

# Generated at 2022-06-21 06:12:16.651159
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L  # L, otherwise no assert at all fails, I think it should...
    assert isinstance(L, LookupModule)

# Generated at 2022-06-21 06:12:25.443169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test uses the test/lookups/runner.py script.
    Note that Ansible's test framework does not have a direct way to test lookups.
    """
    def test_LookupModule_run():
        from ansible.module_utils.six.moves import builtins
        from ansible.module_utils.six import StringIO

        class FakeModule:
            def __init__(self, **kwargs):
                self.params = kwargs

        class FakeVars:
            def __init__(self):
                self._vars = {}

            def get(self, k):
                return self._vars.get(k)

            def __getitem__(self, k):
                return self._vars[k]


# Generated at 2022-06-21 06:12:25.922867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:13:37.017841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._loader.set_basedir(u'/')
    assert lookup.run([u'file1', u'file2']) == [u'/file1']
    assert lookup.run([{u'files': u'file2'}]) == [u'/file2']
    assert lookup.run([{u'files': u'file4'}], skip=True) == []
    assert lookup.run([{u'paths': u'/extra/path', u'files': u'file3'}]) == [u'/extra/path/file3']
    assert lookup.run([{u'paths': u'/extra/path:/extra/path-2', u'files': u'file3'}]) == [u'/extra/path/file3']

# Generated at 2022-06-21 06:13:45.579422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for class LookupModule
    """
    # TODO: need to mock 'find_file_in_search_path'
    # or have 'find_file_in_search_path' find a file that we can use.
    # OTOH this lookup plugin has NOT been tested.
    # so even a test of no file existing is better than no tests at all.
    assert True