

# Generated at 2022-06-21 06:03:54.372518
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, '_templar')

# Generated at 2022-06-21 06:03:56.807415
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:04:07.244703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestTemplar:
        def template(self, path):
            return path

    l = LookupModule()
    l._templar = TestTemplar()

    class TestVars:
        def get(self, var, default=None, boolean=None, integer=False,
                float=False, list=False, string=False, version=False,
                secret=False, other=None, vars=None):
            return default

    class TestLoader:
        def path_dwim(self, path):
            return path

    class TestTask:
        def __init__(self):
            self._loader = TestLoader()
            self._variable_manager = TestVars()

    class TestPlayContext:
        def __init__(self):
            self.task = TestTask()
            self.variable_manager = Test

# Generated at 2022-06-21 06:04:20.200073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a dict as term.
    # This can't be tested easily with the normal unit tests of Ansible as they don't factor in the lookup_loader.
    # Test with a dict as term
    test_terms = [{'files': 'file1.txt', 'paths': '/tmp'}, 'file2.txt']
    lm = LookupModule()
    total_search, skip = lm._process_terms(test_terms, variables=None, kwargs=None)
    assert '/tmp/file1.txt' in total_search   # This will be equal if the code works as expected. Currently it is not, you get '/tmp/file1.txt /tmp/file2.txt'
    assert skip is False

    # Test with a list as term

# Generated at 2022-06-21 06:04:21.609989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert(lookup_plugin._subdir is None)

# Generated at 2022-06-21 06:04:31.437897
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModuleSubclass(LookupModule):
        def __init__(self):

            def MockPathExists(path):
                return str(path) in ['test_path1/file1', 'test_path1/file2']

            def MockPathDir(path):
                return ['test_path2/file3', 'test_path2/file4']

            def MockTemplarTemplate(obj):
                return str(obj)

            self._templar = MockTemplar(MockTemplarTemplate)
            self.find_file_in_search_path = MockFindFileInSearchPath(MockPathExists, MockPathDir)

    # expects list of files.

# Generated at 2022-06-21 06:04:37.139732
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup._loader = None
    lookup._templar = None
    lookup._get_file_contents = None

    terms = ['one', {'files': 'two', 'paths': ['path1', 'path2']}]

    # No errors but empty list
    expected = []
    result = lookup.run(terms, {})
    assert result == expected

    # Error
    try:
        result = lookup.run(terms, {}, skip=False)
        assert result == expected
        raise Exception('An exception has not been raised')
    except Exception as e:
        assert type(e) == AnsibleLookupError

    # Error

# Generated at 2022-06-21 06:04:44.082100
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    files = 'file1,file2,file3'
    paths = 'path1,path2,path3'
    kwargs = dict(files=files, paths=paths)
    term1 = 'file1/file2'
    term2 = 'file1'
    term3 = 'file4'
    term4 = 'file2'
    term = term1, term2, term3, term4
    terms = term
    total_search = lookup._process_terms(terms, None, kwargs)
    # test when files and paths are both defined

# Generated at 2022-06-21 06:04:49.213566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # creating a class object
  look = LookupModule()


  terms = ['/etc/passwd', '/no/file/found']

  # invoking the run() method
  res = look.run(terms, {})

  # checking the result
  assert(res[0] == '/etc/passwd')

# Generated at 2022-06-21 06:04:50.603897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None


# Generated at 2022-06-21 06:05:05.613190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    options = {'files': ['foo'], 'paths': ['bar']}
    lookup._templar = MockTemplar()
    lookup.find_file_in_search_path = lambda v, s, fn, ignore_missing: 'bar/foo'
    results = lookup.run([options], {}, variables={})
    assert results == ['bar/foo']

    options = {'files': ['foo'], 'paths': ['bar']}
    lookup.find_file_in_search_path = lambda v, s, fn, ignore_missing: None
    results = lookup.run(['a', options, 'b'], {}, variables={})
    assert results == []

    options = {'files': ['foo'], 'paths': ['bar']}
    lookup.find_file_in_

# Generated at 2022-06-21 06:05:09.267563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # TODO: write unit test
  assert 0 == 1

# Generated at 2022-06-21 06:05:20.460553
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()

    # Test the normal usage
    assert lookup_plugin.run([['foo/bar.txt', 'test/test.txt', 'foo/foo.txt']], {}, skip=False) == ['test/test.txt']

    # Test when skip=True
    assert lookup_plugin.run([['foo/bar.txt', 'test/test.txt', 'foo/foo.txt']], {}, skip=True) == []

    # Test when skip=True and there is no file found
    assert lookup_plugin.run([['1.txt', '2.txt']], {}, skip=True) == []

    try:
        # Test when skip=True and there is no file found
        lookup_plugin.run([['1.txt', '2.txt']], {})
    except:
        pass

# Generated at 2022-06-21 06:05:21.827277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []

# Generated at 2022-06-21 06:05:23.205802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement test
    pass



# Generated at 2022-06-21 06:05:25.748926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert (lm._subdir is None)


# Generated at 2022-06-21 06:05:27.808473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__init__.__code__.co_varnames) == 3

# Generated at 2022-06-21 06:05:41.405294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._templar = None
    lookup._loader = None
    lookup.set_options(var_options=None, direct={u'skip': False, u'paths': u'/mnt/shared'})
    terms = [{u'files': u'cp_test.xml', u'paths': u'/mnt/shared'}]
    res = lookup.run(terms, None)
    assert res == ['/mnt/shared/cp_test.xml']

    lookup.set_options(var_options=None, direct={u'skip': False, u'paths': u'/mnt/shared'})
    terms = [{u'files': u'cp_test.xml'}]
    res = lookup.run(terms, None)

# Generated at 2022-06-21 06:05:44.011886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([], {}) == []

# Generated at 2022-06-21 06:05:45.997329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None


# Generated at 2022-06-21 06:05:59.899281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.parsing.dataloader

    loader = ansible.parsing.dataloader.DataLoader()
    my_vars = ansible.vars.UnsafeDict({"a": {"b": 2}})
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=ansible.vars.VariableManager(loader=loader, inventory=inventory))

    lookup_plugin = plugin_loader.get('first_found', class_only=True)
    lookup_plugin._load_name = 'first_found'
    obj = lookup_plugin()

    # test with a few of the parameters that are currently available

# Generated at 2022-06-21 06:06:01.079505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-21 06:06:13.747440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # givens
    terms = [
        ['/path1/path2/file1'],
        {'files': '/path1/path2/file2'},
        {'paths': '/path1/path2/file3'}
    ]
    variables = {}
    kwargs = {}
    lookup_instance = LookupModule()

    # whens
    searched_files, skip = lookup_instance._process_terms(terms, variables, kwargs)

    # thens
    expected_searched_files = ['/path1/path2/file1', '/path1/path2/file2', '/path1/path2/file3']
    assert searched_files == expected_searched_files
    assert skip is False

# Generated at 2022-06-21 06:06:21.903048
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_params = {'files': [], 'paths': []}

    empty_terms = []
    empty_terms_result = ([], False)

    onearg_terms = [lookup_params]
    onearg_terms_result = ([], False)

    string_terms = ['a']
    string_terms_result = (['a'], False)

    list_terms = [['a', 'b', 'c']]
    list_terms_result = (['a', 'b', 'c'], False)

    list_of_list_terms = [
        {'files': ['a'], 'paths': ['c']},
        {'files': ['a', 'b'], 'paths': ['d']}
    ]

# Generated at 2022-06-21 06:06:34.726015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # the files in the list below are generated at runtime, thus they don't exist.
    # they're assembled as follows:
    # 'ansible_virtualization_type' : "{{ ansible_virtualization_type }}"
    # 'ansible_os_family' : "{{ ansible_os_family }}"
    # 'default' : "default"
    # 'empty' : ""

    # the tests below are meant to call this method with a list of file names, and
    # validate the returned filepath with an expected result .

    ansible_virtualization_type = "docker" # or "kvm"
    ansible_os_family = "Debian" # or "RedHat"


# Generated at 2022-06-21 06:06:48.246554
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    params = {'files':['foo.conf'], 'paths':'/tmp/staging'}
    term = 'default.conf'
    # run method should return None as no file found
    assert LookupModule(Loader()).run(term, variables={}, **params) is None

    params = {'files':['foo.conf'], 'paths':'/tmp/staging'}
    term = {'files':['default.conf'], 'paths':'/tmp/staging'}
    # run method should return None as no file found
    assert LookupModule(Loader()).run(term, variables={}, **params) is None

    params = {'files':['foo.conf'], 'paths':'/tmp/staging'}
    term = ['default.conf']
    # run method should return None as no file found
   

# Generated at 2022-06-21 06:06:52.890949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-argument
    lookup = LookupModule()

    # TODO: needs to be fixed, enable and modify
    # assert lookup.run([], []) == []

    # TODO: needs to be fixed, enable and modify
    # assert lookup.run(['test.txt'], []) == []


# Generated at 2022-06-21 06:06:58.036053
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()
  assert lookup_module is not None, "Failed to create LookupModule"

# Generated at 2022-06-21 06:07:02.281811
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {}
    terms = ['foo/bar', 'bar/bar/foo', {'files': 'bar, foo', 'paths': '/foo, /bar'}, 'foo/bar/bz']

    l = LookupModule()

    # return value of _process_terms is set of files to be searched,
    # and if a failure to find a file is okay (skip)
    files, skip = l._process_terms(terms, variables, {})

    # return values of find_file_in_search_path are a path to a file or None
    results = []
    for f in files:
        # Assume f is a path to a file that exists
        if f == 'foo/bar':
            results.append('bar')
            continue
        # Assume f is a path to a file that does not exist

# Generated at 2022-06-21 06:07:03.180127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)


# Generated at 2022-06-21 06:07:11.420325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: mock file search
    assert False



# Generated at 2022-06-21 06:07:21.944396
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import pytest
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import string_types
    import ansible.plugins.lookup.first_found as first_found
    from ansible.plugins.lookup.first_found import LookupModule

    tmpdir = os.path.realpath(str(pytest.helpers.tmpdir))

    lookup = LookupModule()

    kwargs = {}
    terms = ["file_in_files"]
    result = lookup.run(terms=terms, variables={}, **kwargs)
    assert result == [os.path.join(tmpdir, "files", "file_in_files")]

    kwargs = {}
    terms = ["file_in_files.conf"]

# Generated at 2022-06-21 06:07:31.349938
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    terms = [
        {'files': ['foo', 'bar'], 'paths': 'one', 'skip': False},
        {'files': 'baz', 'paths': ['one'], 'skip': False},
        {'files': ['foo', 'bar'], 'paths': 'one', 'skip': False},
    ]
    variables = dict()
    total_search, skip = module._process_terms(terms, variables, dict())
    assert not skip, 'skip should be False'
    assert len(total_search) == 5, '_process_terms should return 5 elements'

# Generated at 2022-06-21 06:07:42.045727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()

    # Test for case when 'term' is not a dict
    terms = ['foo']
    test.set_options(direct={'skip': False})
    total_search, skip = test._process_terms(terms, {}, {})
    assert(total_search == ['foo'])
    assert(skip is False)

    # Test for case when 'term' is a dict
    terms = [{'files': ['foo'], 'paths': ['bar/baz']}]
    total_search, skip = test._process_terms(terms, {}, {})
    assert(total_search == ['bar/baz/foo'])
    assert(skip is False)

    # Test for case when 'term' is a dict containing a skip option

# Generated at 2022-06-21 06:07:45.649537
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None, "Unable to instantiate LookupModule"

# Generated at 2022-06-21 06:07:55.326878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule._templar = LookupModule._loader = LookupModule._display = None

    assert LookupModule(None, '').run(['unknown.file'], dict()) == [], "test_LookupModule_run #1 failed!"
    assert LookupModule(None, '').run(['default.yml'], dict(ansible_os_family='Debian')) == [], "test_LookupModule_run #2 failed!"
    assert LookupModule(None, '').run(['default.yml', 'RedHat.yml'], dict(ansible_os_family='Debian')) == ['default.yml'], "test_LookupModule_run #3 failed!"


# Generated at 2022-06-21 06:07:57.681631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:08:00.280398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:08:12.345341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # load module
    import os
    import tempfile
    import ansible.plugins.loader
    lookup = ansible.plugins.loader.lookup_loader.get('first_found')

    # create files for tests
    temp_dir = tempfile.mkdtemp(prefix='ansible')
    os.symlink(os.path.join(temp_dir, 'file_link'), os.path.join(temp_dir, 'file'))
    files = (
        'file1',
        'file2',
        'file3',
        'test_module.py',
        'file4',
        'file5',
        'file6',
    )

    for file in files:
        f = open(os.path.join(temp_dir, file), 'a')
        f.close()

    # methods and attributes

# Generated at 2022-06-21 06:08:21.753812
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lkp = LookupModule()
    params = {
        'files': ['f1', 'f2'],
        'paths': ['/z', '/a/b'],
        'skip': False
    }
    find = [
        params,
        ['f1', 'f2'],
        'x/f1,y/f2',
        '/a/b/f1,/a/b/f2',
        'x/f1;y/f2',
        '/a/b/f1;/a/b/f2',
        'x/f1,y/f2:/a:/b/f1,/a/b/f2',
        {'files': 'f1,f2', 'paths': '/a/b'}
    ]

# Generated at 2022-06-21 06:08:35.342634
# Unit test for constructor of class LookupModule
def test_LookupModule():
  LI = LookupModule()
  assert type(LI) == LookupModule
  assert LI.get_option('errors') == 'strict'

# Unit tests for _split_on

# Generated at 2022-06-21 06:08:43.086858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os, pytest

    current_dir = os.path.dirname(os.path.realpath(__file__))
    terms = [['/path1/file1', '/path1/file2'], ['/path2/file1', '/path2/file2']]
    lookups = LookupModule()

    assert lookups.run(terms, {}) == ['/path1/file1']
    assert lookups.run([[]], {}) == ['/path1/file1']

    with pytest.raises(AnsibleLookupError):
        lookups.run([['playbooks/test/docs/test_first_found/invalid_file']], {})

    with pytest.raises(AnsibleLookupError):
        lookups.run([], {})


# Generated at 2022-06-21 06:08:52.575242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [
        {'files': 'foo', 'paths': 'path1:path2'},
        {'files': 'bar', 'paths': 'path3'},
        'myfile'
    ]
    variables = {'ansible_virtualization_type': 'some_provider'}
    result = lookup_module._process_terms(terms, variables, kwargs=None)

    # test if _process_terms() returned an empty list
    assert result == ([], False)

# Generated at 2022-06-21 06:09:05.071527
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:09:16.679319
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.context import define_ansible_context
    define_ansible_context()

    lm = LookupModule()

    # test with string term
    # test without fail
    assert ['roles/my_role/files/foo.txt'] == lm.run(
        terms='foo.txt',
        variables={
            'some_var': 'a_value'
        },
        **{
            '_subdir': 'roles/my_role',
            'warn_only': False,
        }
    )

    # test with list term
    # test with fail

# Generated at 2022-06-21 06:09:22.681978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    # Initialize objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost')
    variable_manager.set_inventory(inventory)

    # Force use of relative path using `subdir`
    variable_manager._options['subdir'] = './../plugins/lookup/'

    # Use play context
    play_context = PlayContext()
    play_context.CLIARGS = None
    play_context.connection = None
    play_context.network_os = None
    play_context.become

# Generated at 2022-06-21 06:09:36.312651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create_module is used here because it is easier to mock the class and
    # the function is used by all plugins to test just one
    LookupModule.create_module = lambda self, terms, variables, **kwargs: True

    # basic test, no arguments
    module = LookupModule()
    assert module.run([], {})

    # basic test, files, paths and skip
    module = LookupModule()
    assert module.run([{'files': 'foo', 'paths': 'bar', 'skip': True}], {})

    # basic test, files and paths
    module = LookupModule()
    assert module.run([{'files': 'foo', 'paths': 'bar'}], {})

    # basic test, only paths
    module = LookupModule()

# Generated at 2022-06-21 06:09:39.359772
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)



# Generated at 2022-06-21 06:09:41.590959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:09:49.344613
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple

    def test_data():

        #
        # 'terms' data
        #
        yield {
            'description': 'single string',
            'terms': ['foo'],
            'expected': (
                ('foo', True, None),
            )
        }

        yield {
            'description': 'list with single string',
            'terms': [['foo']],
            'expected': (
                ('foo', True, None),
            )
        }

        yield {
            'description': 'list with multiple strings',
            'terms': [['foo', 'bar', 'baz']],
            'expected': (
                ('foo', True, None),
                ('bar', True, None),
                ('baz', True, None),
            )
        }


# Generated at 2022-06-21 06:10:13.231251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:10:20.647003
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('first_found')

    terms = [
        'foo',
        {'files': ['bar'], 'paths': ['foo', 'bar']},
        {'files': ['bar', 'foo'], 'paths': ['foo', 'bar']},
    ]

    # TODO: improve this test, it does not actually test anything functional?!
    instance = LookupModule().run(terms, variables={}, **{})
    assert isinstance(instance, list)
    instance = lookup.run(terms, variables={}, **{})
    assert isinstance(instance, list)
    assert 'bar' in instance

# Generated at 2022-06-21 06:10:22.836270
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-21 06:10:29.264073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create instant of LookupModule
    lookup_module = LookupModule()

    # use first found lookup module
    lookup_module._lookup_name = 'first_found'

    terms = ['/usr/local/etc/foo.conf', '/usr/local/etc/bar.conf']
    variables = {}

    # run and check the result
    assert sorted(terms) == sorted(lookup_module.run(terms, variables))


# Generated at 2022-06-21 06:10:40.665366
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:10:50.678548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add a test for every public interface, including ones with and without error conditions

    # NOTE: the tests only test what is considered a valid input and
    # that the output is semi-sane. It does not verify the code is
    # actually doing what is intended.

    args = {}
    # TODO: add the variables parameter, needs a proper class
    args['variables'] = 'fake_variables'

    # TODO: check the constructor and figure out if other arguments are required
    lookup_module = LookupModule()

    # Run the method _process_terms of class LookupModule

# Generated at 2022-06-21 06:11:02.039425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import collections

    # TODO: need to add acutal tests or replace with ansible test architecture
    # notes:
    #    This is an incomplete test-plan, but it should give some insight into how the method works.
    #    method _split_on is not tested
    #    method find_file_in_search_path() not tested
    #    class LookupBase() is not mocked out, so errors can happen
    #
    #    method _process_terms()
    #        term can be a string, dict or list
    #            seems if first item is list then it will ignore all 'real' terms?
    #            no way to add a list of 'real' terms?
    #        dict can contain keys: files, paths, skip
    #            files, paths are combined with the method _split_on
    #            skip must be true

# Generated at 2022-06-21 06:11:07.815437
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:11:09.247499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().__class__.__name__ == 'LookupModule'

# Generated at 2022-06-21 06:11:12.056142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Instantiante the class LookupModule"""
    l = LookupModule()
    assert l


# Generated at 2022-06-21 06:11:59.710933
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run() is None


# Generated at 2022-06-21 06:12:00.575298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:12:02.495618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: write tests
    pass

# Generated at 2022-06-21 06:12:04.147932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Create an instance of the LookupModule class """
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:12:10.143836
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of LookupModule with empty param
    lookup_module = LookupModule()

    # Check the value of variables and kwargs
    # Variable should be None
    assert lookup_module.variables is None
    # kwargs should be empty
    assert lookup_module.kwargs == {}


# Generated at 2022-06-21 06:12:16.708221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    import os

    lookup_plugin = LookupModule()

    terms = [
        'foo',
        'bar',
        {'files': 'a.txt,b.txt', 'paths': 'one,two,three'},
        {'paths': 'one,two,three'},
        {'files': '/tmp/a.txt,/tmp/b.txt', 'paths': '/tmp/one;/tmp/two,/tmp/three'},
        {'files': 'a.txt', 'paths': 'one,two;three'},
        {'files': '/tmp/a.txt'},
    ]
    variables = {}

    # Normal case
    total_search, skip = lookup_plugin._process_terms(terms, variables, {})

    # regular

# Generated at 2022-06-21 06:12:18.458043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-21 06:12:20.936164
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._subdir = 'test'
    lookup._loader = 'test'
    lookup._templar = 'test'
    assert lookup

# Generated at 2022-06-21 06:12:22.203307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:12:35.687087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()

    terms = ('a.conf', 'b.conf', 'c.conf')
    variables = {'a': 'a.conf', 'b': 'b.conf', 'c': 'c.conf'}
    kwargs = {'files': 'a.conf', 'paths': 'b.conf', 'skip': 'c.conf'}
    t.run(terms, variables, kwargs)

    terms = ('a.conf', 'b.conf', 'c.conf')
    variables = {'a': 'a.conf', 'b': 'b.conf', 'c': 'c.conf', 'd': 'd.conf'}
    kwargs = {'files': 'a.conf', 'paths': 'b.conf', 'skip': 'c.conf'}