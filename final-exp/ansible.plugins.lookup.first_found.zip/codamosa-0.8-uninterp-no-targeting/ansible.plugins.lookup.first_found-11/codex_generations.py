

# Generated at 2022-06-21 06:04:03.189880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.first_found

    my_vars = dict()
    my_vars['ansible_virtualization_type'] = 'test'

    # A LookupModule object with following params:
    #   _basedir = current working directory
    #   basedir =  None
    #   _loader = DictDataLoader()
    #   _templar = None
    #   _inventory = None
    #   args = None
    lookup_module = ansible.plugins.lookup.first_found.LookupModule()

    # A list of terms:
    #   *mapping - a dict that represents a term
    #   *mapping - a dict that represents a term
    #   *string - a string that represents a term

# Generated at 2022-06-21 06:04:10.592515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    result = lookup_module._process_terms(
        terms=["/etc/passwd", "/etc/group"],
        variables={}, kwargs={})
    assert len(result) == 2
    assert result[0] == ['/etc/passwd', '/etc/group']
    assert result[1] == False
    result = lookup_module._process_terms(
        terms=["/etc/passwd"],
        variables={}, kwargs={})
    assert len(result) == 2
    assert result[0] == ['/etc/passwd']
    assert result[1] == False

# Generated at 2022-06-21 06:04:18.557606
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Setup
    global module_name
    module_name = 'test_plugin_name'
    class_name = 'LookupModule'

    # Exercise
    # Note: Ansible no longer looks for any class from the plugin file; global plugin variables are passed to class constructor
    #module = __import__(module_name)
    #class_def = getattr(module, class_name)
    #instance = class_def()

    # Verify
    assert class_name == 'LookupModule'


# Generated at 2022-06-21 06:04:20.923753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a new instance
    tester = LookupModule()
    assert tester != None


# Generated at 2022-06-21 06:04:23.662235
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l != None


# Generated at 2022-06-21 06:04:25.812286
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:04:38.113116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule()
    terms = ['/tmp/something/a.txt', '/tmp/base/b.txt', {'paths': ['/tmp/something', '/tmp/base'], 'skip': True}]
    lookup = LookupModule()
    lookup._subdir = '/tmp'
    lookup.run(terms, None)
    terms = ['/tmp/something/a.txt', '/tmp/base/b.txt', {'paths': ['/tmp/something', '/tmp/base'], 'skip': False}]
    lookup = LookupModule()
    lookup._subdir = '/tmp'
    lookup.run(terms, None)

# Generated at 2022-06-21 06:04:45.731697
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with empty options
    lookup_module = LookupModule()
    lookup_module.run([], {})
    # Test with 'undefined' options
    lookup_module = LookupModule()
    lookup_module.run([{}], {})
    # Test with 'empty' options
    lookup_module = LookupModule()
    lookup_module.run([{'files': [], 'paths': []}], {})
    # Test with 'empty' options
    lookup_module = LookupModule()
    lookup_module.run(['', '', {}], {})



# Generated at 2022-06-21 06:04:48.608133
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert lm._plugin_version == 1
  assert lm._plugin_type == 'lookup'
  assert lm._plugin_name == 'lookup_plugin'


# Generated at 2022-06-21 06:05:00.664095
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module_class = LookupModule()

    # assert file exists, regardless of path
    assert module_class._super_init("/etc/hosts"), "Unexpected file 'hosts' not found."

    # assert assertion
    try:
        module_class._super_init("/etc/does_not_exist")
    except AssertionError:
        assert True, "Test passes as file not found."
    except:
        assert False, "Unexpected error."

    # return file path
    filepath = module_class._super_init("/etc/hosts")
    assert filepath, "Unexpected error with filepath."
    assert filepath.find("/etc/hosts"), "Unexpected error with filepath."

# Generated at 2022-06-21 06:05:06.469542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # minimal test of return of object if no failures
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-21 06:05:19.701791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test lookup module
    test_variables = {
        'homes': [
            '/home/foo',
            '/home/bar',
        ],
    }

    lookup_module = LookupModule()

# Generated at 2022-06-21 06:05:21.439936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    assert LookupModule

# Generated at 2022-06-21 06:05:23.965639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar is not None


# Generated at 2022-06-21 06:05:25.392269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: add additional tests
    assert LookupModule

# Generated at 2022-06-21 06:05:36.665086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1: check that we fail without a term
    terms = []
    variables = {}
    kwargs = {}
    lookup_inst = LookupModule()

    with pytest.raises(AnsibleLookupError):
        assert lookup_inst.run(terms, variables, **kwargs)

    # Test 2: check that we fail if we have a term that is not a string (number)
    terms = [1]
    variables = {}
    kwargs = {}
    lookup_inst = LookupModule()

    with pytest.raises(AnsibleLookupError):
        assert lookup_inst.run(terms, variables, **kwargs)

    # Test 3: check that we fail if we have a term that is not a string (list)
    terms = [[]]
    variables = {}
    kwargs = {}


# Generated at 2022-06-21 06:05:38.652853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:05:48.126892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    # when state is an empty dict
    values = l._process_terms([], dict(), dict())
    assert values == ([], False)

    # when state contains only the first_found value
    values = l._process_terms([{'first_found': [{'paths': 'fake-path', 'skip': True}]}], dict(), dict())
    assert values == ([], True)

# Generated at 2022-06-21 06:05:49.508898
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:06:03.690273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests with broken configs
    # list in place of dict
    terms1 = ['a']
    variables1 = {}
    kwargs1 = {}
    assert LookupModule(terms1, variables1, **kwargs1).run() == []

    # empty config
    terms2 = ['']
    variables2 = {}
    kwargs2 = {}
    assert LookupModule(terms2, variables2, **kwargs2).run() == []

    # config without paths
    terms3 = [{'files': ''}]
    variables3 = {}
    kwargs3 = {}
    assert LookupModule(terms3, variables3, **kwargs3).run() == []

    # config without files
    terms4 = [{'paths': ''}]
    variables4 = {}
    kwargs4 = {}
   

# Generated at 2022-06-21 06:06:08.102011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:06:09.580789
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check members
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:06:17.883816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    var_options = {
        'skip' : { False: False, True: True },
        'files' : { [ 'test1', 'test2' ] : [ 'test1', 'test2' ], 'test3' : [ 'test3' ] },
        'paths' : { [ 'test1', 'test2' ] : [ 'test1', 'test2' ], 'test3' : [ 'test3' ] }
    }

# Generated at 2022-06-21 06:06:30.067166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import pytest
    import shutil

    # test setup
    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a file test/file.ext
    test1_dir = os.path.join(tmpdir, 'test1')
    os.mkdir(test1_dir)
    test1_file = os.path.join(test1_dir, 'file1.ext')
    with open(test1_file, 'w') as f:
        f.write('test\n')
    # create a file test2/file.ext
    test2_dir = os.path.join(tmpdir, 'test2')
    os.mkdir(test2_dir)

# Generated at 2022-06-21 06:06:34.291033
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create object
    obj = LookupModule()

    # test defaults
    assert obj._templar is None
    assert obj._loader is None
    assert obj._datastore is None
    assert obj._basedir is None
    assert obj._display is None

    # test methods
    # TODO: test methods

# Generated at 2022-06-21 06:06:44.532631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = [
        {'files': 'file1,file2', 'paths': '/path1:/path2'},
        {'files': 'file3,file4', 'paths': '/path3:/path4'},
        {'files': 'file5,file6', 'paths': '/path5:/path6'},
    ]
    variables = {}
    args = {}
    lookup = LookupModule()

    # Exercise
    # Assert
    try:
        ret = lookup.run(terms, variables, **args)
        assert False, 'AnsibleLookupError should be raised'
    except AnsibleLookupError as e:
        assert "'No file was found when using first_found.'" in str(e), 'actual: %s' % str(e)


# Generated at 2022-06-21 06:06:50.334730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test_LookupModule
    # Constructor LookupModule
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert id(lookup_module) != None

# Generated at 2022-06-21 06:06:52.887411
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 06:06:57.575452
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-21 06:06:58.463586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:07:06.683428
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert (isinstance(LookupModule(), object))

# Generated at 2022-06-21 06:07:09.029720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l._subdir == 'files'

# Generated at 2022-06-21 06:07:11.638926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-21 06:07:23.897160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = []

    #NOTE: dirname static method return the directory name of a pathname path.
    path_lookup = os.path.join(os.path.dirname(__file__), '../lookup_plugins')
    file_relative = [
        'file1',
        {
            'files':  'file2',
            'paths':  'path2',
        },
        'file3',
        {
            'paths':  'path3',
        },
    ]
    non_existing_paths = [
        'path1',
        'path2',
        'path3',
        'path4',
    ]
    kwargs = {}
    lookup_module = LookupModule()
    variables = {}

    ##################
    # Test 1
    ##################


# Generated at 2022-06-21 06:07:29.946201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['file1.conf']
    variables = {}
    expected = ['file1.conf']
    result = lm.run(terms, variables)
    assert(result == expected)
    terms = ['file1.conf', 'file2.conf']
    variables = {}
    expected = ['file1.conf']
    result = lm.run(terms, variables)
    assert(result == expected)


# Generated at 2022-06-21 06:07:41.568216
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create instance of class LookupModule
    inst = LookupModule()

    # test _process_terms method
    (l1, sk1) = inst._process_terms([], dict(), dict())
    assert l1 == []
    assert sk1 == False
    (l2, sk2) = inst._process_terms(["foo"], dict(), dict())
    assert l2 == ['foo']
    assert sk2 == False
    (l3, sk3) = inst._process_terms(["foo", "bar"], dict(), dict())
    assert l3 == ['foo', 'bar']
    assert sk3 == False

    dict1 = dict()
    dict1['files'] = 'file1, file2'
    dict1['paths'] = 'path1, path2'
    dict1['skip'] = True
    dict2 = dict()

# Generated at 2022-06-21 06:07:46.437151
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # NOTE: should add tests that ensure all failure cases fail,
        # and all the non-failure cases work as expected
    # adding this in place of those until we can test them
    assert True

# Generated at 2022-06-21 06:07:55.551997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six import PY3

    class FakeTemplar():
        def __init__(self):
            pass

        def template(self, fn):
            return fn

    class FakeVars():
        def __init__(self):
            pass

        def __getitem__(self, key):
            return 'bar'

    class FakeVariables():
        def __init__(self):
            pass

        def __getitem__(self, key):
            if key == 'ansible_current_play':
                return {'play': {'_role_path': []}}

    class FakeFile():
        def __init__(self, path):
            self.path = path
            self.content = 'bar'


# Generated at 2022-06-21 06:07:56.974088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:07:59.643231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run(terms, variables, **kwargs):
    # FIXME: how to test this is good?
    pass

# Generated at 2022-06-21 06:08:14.205254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, '')

# Generated at 2022-06-21 06:08:25.389972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    class Options(object):
        connection = 'local'
        module_path = None
        forks = 100
        remote_user = 'vagrant'
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = None
        become_method = None
        become_user = None
        verbosity = 5
        check = False
        diff = False
        listhosts = 'localhost'
        listtasks = None
        listtags = None
        syntax = None
       

# Generated at 2022-06-21 06:08:31.143483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # TODO: add tests for all cases of this complex lookup plugin
    #       the test_templar.py should be a reference
    #       or at least have an example for this type of test
    #       not a placeholder
    pass



# Generated at 2022-06-21 06:08:32.451109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:08:34.837133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-21 06:08:44.326602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    loader = '''
- debug:
    msg: "{{ lookup('first_found', findme, skip=False) }}"
  vars:
    findme:
      - /path/to/foo.txt
      - bar.txt  # will be looked in files/ dir relative to role and/or play
      - /path/to/biz.txt
'''

    results = [
        {'msg': '/path/to/foo.txt'}
    ]

    # load data from yaml
    import yaml
    data = yaml.safe_load(loader)

    # create mock playbook
    from collections import namedtuple
    MockPlaybook = namedtuple('MockPlaybook', ['extra_vars'])

# Generated at 2022-06-21 06:08:55.270008
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    def _test_run(terms, expected_list, expected_skip=False, **kwargs):
        total_search, skip = l._process_terms(terms, variables={}, kwargs={})
        assert total_search == expected_list
        assert skip == expected_skip
        return total_search, skip

    _test_run(terms=[],
              expected_list=[],
              expected_skip=False)

    _test_run(terms=['*'],
              expected_list=['*'],
              expected_skip=False)

    _test_run(terms=['a', 'b'],
              expected_list=['a', 'b'],
              expected_skip=False)


# Generated at 2022-06-21 06:09:06.038450
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    lookup_module = LookupModule()

    # First test with automatic template expansion on
    variable_manager = VariableManager()
    variable_manager._extra_vars = {"secret": "password"}
    templar = Templar(loader=None, variables=variable_manager)
    contained_vars = {"file_name": "{{ secret }}-deploy.txt"}
    variation = {'direct': contained_vars}
    variation['vault_password'] = 'ASecret'
    vault = VaultLib(variation['vault_password'])

# Generated at 2022-06-21 06:09:13.745428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    def _lookup_loader(self, name):
        return None

    lookup_loader = type('LookupLoader', (object,), {
        'get_basedir': lambda self, hostname: '/playbook/directory',
        'get_loader': _lookup_loader,
    })
    terms = [
        'foo.txt',
        {'files': 'foo.txt', 'paths': ['/path/one', '/path/two', 'relative/path/three']},
        ['/path/four', 'relative/path/five/ansible.txt'],
    ]
    dict_mock = {
        'inventory_hostname': 'localhost',
        'ansible_virtualization_type': 'virtualmachine',
    }

# Generated at 2022-06-21 06:09:25.738693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # Create the lookup
    lookup = LookupModule()
    lookup._subdir = 'files'
    lookup._templar = VariableManager()
    lookup._loader = DataLoader()

    # Test normal behavior
    result = lookup.run([
        {'files': 'foo.txt', 'paths': '/test/inventory/first_found'},
        '/test/inventory/first_found/bar.txt'
    ], variable_manager)

# Generated at 2022-06-21 06:09:53.184883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize the LookupModule
    try:
        test_lookup = LookupModule()
    except Exception as e:
        print('Failed to initialize the LookupModule: ' + repr(e))


# Generated at 2022-06-21 06:09:54.274407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO
    pass


# Generated at 2022-06-21 06:09:56.771619
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:09:58.776936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod._process_terms(["foo.txt"], {})

# Generated at 2022-06-21 06:10:08.836097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module, terms, variables, kwargs = _init_test_data()

    # 1. Test normal case
    lookup_module._templar._available_variables = {"a": "path", "b": "first.txt", "c": "second.txt"}
    lookup_module._loader._search_paths = ["/some/path/", "/other/path/"]
    term_list, skip = lookup_module._process_terms(terms, variables, kwargs)
    lookup_module._file_finders = [{"finder": mock_file_finder}]
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ["/some/path/first.txt"]

    # 2. Test case where no file was found

# Generated at 2022-06-21 06:10:10.060052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:10:11.552059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert instance is not None

# Generated at 2022-06-21 06:10:15.608768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of LookupModule
    lookup = LookupModule()

    # valid instance of LookupModule
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 06:10:26.478863
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' unit test for constructor of class LookupModule '''
    # pylint: disable=redefined-outer-name
    lookup_name = 'first_found'
    params = {
        'files': 'test1',
        'paths': 'test2'
    }
    results = LookupModule(lookup_name, **params)
    assert results.lookup_name == lookup_name
    assert results.get_option('files') == 'test1'
    assert results.get_option('paths') == 'test2'


# Generated at 2022-06-21 06:10:31.794131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    testing the constructor of LookupModule
    '''
    # for testing
    class TestRunner(object):

        def __init__(self):
            self.inventory = None

    class TestLoader(object):
        pass

    class TestTemplar(object):
        pass

    # testing
    lm = LookupModule(TestLoader())
    lm._templar = TestTemplar()
    lm._loader = TestLoader()
    lm._runner = TestRunner()

# Generated at 2022-06-21 06:11:34.916278
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # To test this whole method
    lookup_module = LookupModule()
    terms1 = [{'files': 'file1.txt', 'paths': ['/path/to/files', '/other/path', 'to/files']},
              {'files': ['file2.txt', 'file3.txt'], 'paths': ['/path/to/files', '/other/path', 'to/files']},
              {'files': 'file2.txt,file3.txt', 'paths': '/path/to,/other/path:to/files'}]
    variables1 = {}
    kwargs1 = {'files': 'file4.txt', 'paths': '/path/to,/other/path:to/files'}
    lookup_module.run(terms1, variables1, **kwargs1)

    #

# Generated at 2022-06-21 06:11:42.280037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import OrderedDict

    # path='/some/path/bar.txt' list
    files = ['foo.txt', '/some/other/path/foo.txt', '/some/path/bar.txt']
    paths = []
    skip = False
    terms = OrderedDict([('files', files), ('paths', paths), ('skip', skip)])
    variables = dict()
    lookup_module = LookupModule()
    # Check with the test-case inputs.
    assert lookup_module.run(terms, variables) == ['/some/path/bar.txt']

    # path=None list
    files = ['foo.txt', '/some/other/path/foo.txt', '/some/path/bar.txt']
    paths = []
    skip = False


# Generated at 2022-06-21 06:11:47.951236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    assert t.run([[{'files': ['foo'], 'paths': ['/tmp']}]], dict()) == ['/tmp/foo']

# Generated at 2022-06-21 06:11:55.032605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run(
        [{'files': 'file1.txt', 'paths': 'path1:path2'},
         {'files': ['file2.txt'], 'paths': ['path3', 'path4']},
         'file3.txt',
         ['file4.txt'],
         'file5.txt'], {})

    assert len(result) == 1, "expected only one result"

# Generated at 2022-06-21 06:11:56.772702
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:12:06.696528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # create dummy variables
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {}}
    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=False)

    # create first_found
    lookup_m = LookupModule()

    # Create some dummy files
    import os, tempfile, shutil
    tempdir = tempfile.mkdtemp()
    filepath_a = os.path.join(tempdir, 'a.txt')
   

# Generated at 2022-06-21 06:12:15.498448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    files = None

    class TestingTemplate():
        def __init__(self):
            pass
        def template(self, filename):
            files.append(filename)
            if filename.endswith('c'):
                return '/path/to/c'
            elif filename.endswith('b'):
                return '/path/to/b'
            else:
                return filename

    class TestingFileSearch():
        def __init__(self):
            pass
        def find_file_in_search_path(self, variables, search_path, paths, ignore_missing=False):
            if '/path/to/c' in paths:
                return '/path/to/c'
            elif '/path/to/b' in paths:
                return '/path/to/b'
            else:
                return None


# Generated at 2022-06-21 06:12:23.606064
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  ################################################################################
  # NOTE: this test is far from being complete because the actual code contains
  # a lot of state shared across many methods of class LookupModule.
  # Hence, the current state of the class is necessary to write a proper
  # test. Due to the complex nature of the class, this test is working
  # on the assumption that the code is already tested on a lower level
  # (i.e. without mocking) and it is only testing the interaction with
  # the other methods.
  ################################################################################

  class LookupFakeClass(LookupModule):
    def __init__(self):
      super(LookupFakeClass, self).__init__()


# Generated at 2022-06-21 06:12:25.867302
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()

    assert isinstance(instance, LookupModule)

# Generated at 2022-06-21 06:12:32.301340
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [
        {'files': 'test_template', 'paths': 'tests/templates'},
        'test_lookup_simple'
    ]
    variables = {
    }

    print(lookup_plugin._process_terms(terms, variables, {}))

# Generated at 2022-06-21 06:13:34.598255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupModule.run_ansible_module_unit_tests(__file__))

# Generated at 2022-06-21 06:13:47.970810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run([], {}) == []
    assert lm.run([{'files': 'foo.txt', 'paths': './tmp'}], {}) == []
    # test that paths and files have precedence over terms
    assert lm.run(['bar.txt', 'foo.txt'], {'foo': 'foo.txt'}) == ['bar.txt']
    # test pathlist extension
    assert lm.run(['foo.txt'], {'paths': './tmp', 'files': 'foo.txt, bar.txt'}) == [
        './tmp/foo.txt', './tmp/bar.txt']
    # test pathlist extension with multiple paths