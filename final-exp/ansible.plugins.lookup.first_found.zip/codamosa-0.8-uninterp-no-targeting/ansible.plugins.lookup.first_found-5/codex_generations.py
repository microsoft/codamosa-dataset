

# Generated at 2022-06-21 06:04:05.761389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test reading options from dict
    lookup_module._process_terms([{'files': '10-eth0.cfg', 'paths': '01:02:03'}], {}, {})
    assert lookup_module.get_option('files') == ['10-eth0.cfg']
    assert lookup_module.get_option('paths') == ['01', '02', '03']
    # test reading options from string
    lookup_module._process_terms(['interface.cfg'], {}, {})
    assert lookup_module.get_option('files') == []
    assert lookup_module.get_option('paths') == []
    # test reading options from sequence

# Generated at 2022-06-21 06:04:06.909646
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup



# Generated at 2022-06-21 06:04:19.837674
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # preparing mock class object for test
    class LookupModuleMock(LookupModule):
        _subdir = ''
        get_option = lambda s, x: ''
        find_file_in_search_path = lambda s, x, y, z: 'file_found'

    obj = LookupModuleMock()
    obj.set_options = lambda x, y: ''
    obj.get_option = lambda x: ''

    # actual test

# Generated at 2022-06-21 06:04:21.563150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("--- test LookupModule ---")
    lookup_object = LookupModule()

# Generated at 2022-06-21 06:04:27.960229
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    loader = 'whatever'
    templar = 'youwant!'

    lookup_plugin = TestLookupModule(loader=loader, templar=templar)

    assert lookup_plugin._loader is loader
    assert lookup_plugin._templar is templar


# Generated at 2022-06-21 06:04:30.897830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('lookup_name', 'lookup_args', 'lookup_options')

# Generated at 2022-06-21 06:04:38.113548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:04:41.538508
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule("test_LookupModule")
    except Exception as e:
        # Lint complains that using Exception here is too broad, but the
        # python docs say to use it this way.
        print("Exception creating LookupModule Exception: %s" % e)



# Generated at 2022-06-21 06:04:49.109510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert '/path/to/foo.txt' in lookup.run(
        terms=[
            '/path/to/foo.txt'
        ],
        variables={},
        **{})
    assert '/path/to/foo.txt' in lookup.run(
        terms=[
            {
                'files': 'foo.txt',
                'paths': '/path/to/'
            }
        ],
        variables={},
        **{})
    assert '/path/to/foo.txt' in lookup.run(
        terms=[
            {
                'files': ['foo.txt']
            },
            {
                'paths': '/path/to/'
            }
        ],
        **{})

# Generated at 2022-06-21 06:05:01.115357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mock = LookupModule()
    lookup_mock.set_options(direct={'files': '', 'paths': ''})

    # test case of empty 'files', 'paths'
    assert lookup_mock._process_terms(['file1', 'file2'], {}, {}) == ([], False)
    # test case of empty 'files'
    assert lookup_mock._process_terms(['file1', 'file2'], {}, {'paths': ['path1']}) == ([], False)
    # test case of empty 'paths'
    assert lookup_mock._process_terms(['file1', 'file2'], {}, {'files': ['path1']}) == ([], False)



# Generated at 2022-06-21 06:05:09.451616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    search_path = ['files/bar.conf', 'files/bar.conf']
    look = LookupModule()
    assert look.find_file_in_search_path({}, 'files', 'bar.conf', ignore_missing=True) == search_path[0]


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-21 06:05:10.169063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:05:12.129487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert test_obj is not None

# Generated at 2022-06-21 06:05:14.370783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_first_found = LookupModule()
    assert lookup_first_found is not None

# Generated at 2022-06-21 06:05:21.059092
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: Add unit test for lookup_module
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    LookupModule(play_context=play_context, loader=loader, variable_manager=variable_manager, templar=None)

# Generated at 2022-06-21 06:05:21.683356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:05:23.012706
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:05:35.676768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'tests'

    # Expect first file found in path
    total_search = ['/etc/ansible/facts.d', '/etc/ansible/tests']
    path = lookup.run(total_search, None,
                      files=['os', 'distribution', 'profile', 'lsb'])

    # Expect first file found using paths

# Generated at 2022-06-21 06:05:42.460736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: do we want to add a disable jinja2 support for test?
    from ansible.module_utils.six import PY3
    if PY3:
        raise AssertionError("Not yet ported to py3")

    # TODO: mock jinja2 and everything to properly test this
    #       might be a lot of work, so deferring
    pass

# Generated at 2022-06-21 06:05:52.764350
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Mock class with run method
    class MyTemplar():
        def template(self, fn):
            return fn

    class MyLookupModule(LookupModule):
        def _find_file_in_search_path(self, terms, variables, subdir, fn, ignore_missing=False):
            return fn
        # Mocking the templar class
        def __init__(self):
            self._templar = MyTemplar()

    # Constructing a lookup module object
    lookup_module = MyLookupModule()
    # Mock class with run method
    class TaskExecutor():
        def get_file_mapping(self, variables):
            my_dict = {"files": 'files', "vars": 'vars', "templates": 'templates'}
            return my_dict

    # Mocking the task execut

# Generated at 2022-06-21 06:06:01.744544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of the LookupModule class
    # module = LookupModule()

    # TODO: method is not public
    # module.run()

    pass

# Generated at 2022-06-21 06:06:03.956304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None, None, {})

# Generated at 2022-06-21 06:06:05.800395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except NameError:
        assert False, 'Unable to construct class LookupModule'


# Generated at 2022-06-21 06:06:07.925847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-21 06:06:16.802421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader)
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

# Generated at 2022-06-21 06:06:18.392722
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._constructor_value == 'first_found'


# Generated at 2022-06-21 06:06:30.913454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance._templar = lookup_instance._loader.load_plugin('jinja2', 'lookup', shared_loader=True).LookupModule()
    lookup_instance.set_options(var_options={}, direct={})

    assert lookup_instance.run(terms=[], variables={}) == []

    assert lookup_instance.run(terms=[{'skip': True}, ], variables={}) == []

    # no files, no paths
    assert lookup_instance.run(terms=[{}, ], variables={}) == []

    # no files, no paths but skip = false
    assert lookup_instance.run(terms=[{'skip': False}, ], variables={}) == Traceback(...)

    # files and paths

# Generated at 2022-06-21 06:06:39.278399
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mod = LookupModule()
    mod._templar = None

    terms = [
        {
            'files': 'foo',
            'paths': '/one, /two'
        },
        # multiple files are split on ','
        {
            'files': 'file1, {{ notthere }}, [file3, file4]',
            'paths': '/one'
        },
        # multiple paths are split on ',' and ':'
        {
            'files': 'empty',
            'paths': '{{ notthere }}:,/one:,: /two'
        },
        # skip if set
        {
            'skip': 'True'
        }
    ]
    variables = dict()
    ret = mod.run(terms, variables)
    assert ret == []


# Generated at 2022-06-21 06:06:49.625934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock kwargs
    kwargs = dict()
    kwargs['files'] = []
    kwargs['paths'] = []
    kwargs['skip'] = False

    # mock terms
    terms = list()
    terms.append('foo.bar')

    # mock variables
    variables = dict()
    variables['foo'] = 'bar'

    # mock subdir
    setattr(LookupModule, '_subdir', 'files')

    # mock templar
    templar = object()
    setattr(LookupModule, '_templar', templar)

    # mock find_file_in_search_path
    def find_file_in_search_path(variables, subdir, filename, ignore_missing=True):
        return None


# Generated at 2022-06-21 06:06:51.480908
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:07:06.937970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:07:18.739251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test
    files = ['/path/file_one', '/path/file_two']
    paths = ['/path/dir_one', '/path/dir_two']
    params = {'files': files, 'paths': paths}
    params_list = ['something', params]

    # Mock
    lm = LookupModule()
    lm._templar = MockTemplar()
    lm.find_file_in_search_path = Mock()

    # Test
    lm.run(None, None)
    lm.run(params_list, None)

# Mock class for LookupModule tests

# Generated at 2022-06-21 06:07:21.106341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Tests for LookupModule run method are not implemented."


# Generated at 2022-06-21 06:07:22.709449
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 06:07:33.952594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.common.template as common_template
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    # Mock
    class MockTemplar(object):

        def __init__(self):
            self.is_template = False

        def template(self, string):
            self.is_template = True

            if string == 'test1':
                return 'test1'
            if string == 'test2':
                return 'test2'
            if string == 'test3':
                return 'test3'
            if string == 'test4':
                return 'test4'

        def is_template(self):
            return self.is_template


# Generated at 2022-06-21 06:07:34.672495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('first_found')


# Generated at 2022-06-21 06:07:43.044407
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLookup(LookupModule):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            if not ignore_missing:
                raise ValueError('ignore_missing should be True')
            if fn == 'error':
                return None
            return os.path.join(subdir, fn)

    lookup_mod = MockLookup()
    terms = ['file1', 'error', 'file2', {'files': ['file3'], 'paths': ['path3']}, 'error']
    res = lookup_mod.run(terms, {}, skip=True)
    assert res == ["files/file1"]

    lookup_mod = MockLookup()

# Generated at 2022-06-21 06:07:47.144385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)


# Generated at 2022-06-21 06:07:55.761220
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:08:06.074767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    params = {
        'files': ['foo/bar/quux.txt', 'baz.txt'],
        'paths': ['/tmp/production', '/tmp/staging']
    }
    terms = [{'files': ['foo.txt'], 'paths': ['/tmp/production']}, 'bar.txt', params]
    ansible_module = None
    ansible_module_func = None
    ansible_module_args = None
    variables = {}
    task_vars = {}

    # when
    lookup_module = LookupModule()
    lookup_module._templar.template = lambda self: self

# Generated at 2022-06-21 06:08:34.325517
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:08:43.473260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext

    lm = LookupModule()

    variables = PlayContext()
    variables.set_variable('ansible_virtualization_type', 'KVM')

    result, skip = lm._process_terms([{'files': 'foo'}, {'files': 'bar'}], variables, {})
    assert result == ['foo', 'bar']

    result, skip = lm._process_terms([['foo', 'bar']], variables, {})
    assert result == ['foo', 'bar']

    result, skip = lm._process_terms([{'files': 'foo', 'paths': '/path'}, 'bar'], variables, {})
    assert result == ['/path/foo', 'bar']

# Generated at 2022-06-21 06:08:55.062998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    # A small playbook to test 'first_found'

# Generated at 2022-06-21 06:09:05.945529
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    setattr(lookup, '_templar', type('Templar', (), {'template': lambda self, x: x}))
    setattr(lookup, 'find_file_in_search_path', lambda self, variables, subdir, fn, ignore_missing: ''.join(filter(None, [variables['ignore_missing'], '_path'])))


# Generated at 2022-06-21 06:09:13.261870
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    total_search=[]
    skip=False
    subdir='files'
    path='/some/path'
    terms = [{'files': 'file1,file2', 'paths': '/path/one,/path/two'}, {'files': 'file3,file4'}, 'file5']

    result, skip = lookup._process_terms(terms, 'test', {'skip': True})

    assert result == ['/path/one/file1', '/path/one/file2', '/path/two/file1', '/path/two/file2',
                      'file3', 'file4', 'file5']
    assert skip == True

    # Test with filelist only


# Generated at 2022-06-21 06:09:14.333038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:09:25.947580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # relative paths for files, current playbook dir is .
    filenames = [
        os.path.join('test_first_found_plugin', 'test_file_1'),
        os.path.join('test_first_found_plugin', 'test_file_2'),
        '/etc/fstab',
        '/no/such/file',
        'test_file_3',
    ]

    # module under test
    lookup = LookupModule()

    # used to get absolute path
    lookup._loader = DummyLoader()

    # data used as second parameter in run method
    dummy_variables = {}

    # test run without params
    # files in filenames have no common ancestor directory
    assert lookup.run(filenames, dummy_variables) == ["/etc/fstab"]

    # test run with params
    #

# Generated at 2022-06-21 06:09:32.418565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test a valid case
    try:
        module.run(['/etc/passwd', '/var/lib/foo'], {}, skip=True)
    except AnsibleLookupError:
        pass
    else:
        assert False

    # Test error handling
    for args in (1, 2.3, [], {}):
        try:
            module.run(args, {}, skip=True)
        except AnsibleLookupError:
            pass
        else:
            assert False

# Generated at 2022-06-21 06:09:40.960520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define a mock class for LookupBase
    class LookupBaseMock(object):
        def __init__(self):
            self.set_options = Mock(return_value=None)
            self.get_option = Mock(return_value=None)
            self.find_file_in_search_path = Mock(return_value=None)

    # Define a mock class for AnsibleTemplar
    class AnsibleTemplarMock(object):
        def __init__(self):
            self.template = Mock(return_value=None)

    lookup_base = LookupBaseMock()

    # Define the entrypoint parameters
    terms = ['foo.txt']
    variables = {'lookup_file': 'foo.txt'}

# Generated at 2022-06-21 06:09:42.502158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:10:40.130348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:10:42.923619
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # test constructor
    assert lookup_plugin._subdir is None

# Generated at 2022-06-21 06:10:52.775061
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    terms = ["/etc/hosts", "/path/to", "/path/to/foo", "/path/to/bar"]

    # test verbose find
    paths, skip = lookup._process_terms(terms, {}, {})
    assert paths == ['/etc/hosts', '/path/to', '/path/to/foo', '/path/to/bar']
    assert skip is False

    # test with valid dict
    terms = [{'files': ['/etc/hosts'], 'paths': ['/path/to']}]
    paths, skip = lookup._process_terms(terms, {}, {})
    assert paths == ['/path/to/etc/hosts']
    assert skip is False

    # test with valid dict with 'files' string

# Generated at 2022-06-21 06:11:00.295041
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for the error scenario
    with pytest.raises(AnsibleLookupError):
        lookup_plugin = LookupModule()
        lookup_plugin.run('/path/to/file', {}, skip=True)

    # Test for the successful scenario
    lookup_plugin = LookupModule()
    lookup_plugin.find_file_in_search_path = MagicMock(return_value='/path/to/file')
    res = lookup_plugin.run(['/path/to/file'], {}, skip=True)
    assert res == ['/path/to/file']

    # Test for the scenario where path is empty
    lookup_plugin = LookupModule()
    lookup_plugin.find_file_in_search_path = MagicMock(return_value=None)

# Generated at 2022-06-21 06:11:09.446452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['file1', 'file2']
    variables = {}
    kwargs = {}

    lookup_plugin = LookupModule()
    lookup_plugin._subdir = 'files'

    # Exercise
    retval = lookup_plugin.run(terms, variables, **kwargs)

    # Verify
    assert retval == []

    # Cleanup - none necessary

# Generated at 2022-06-21 06:11:12.189919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-21 06:11:24.235033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # creating a dummy ansible
    module_args = dict(
        _terms=[
            'foo',
        ],
    )
    lu = LookupModule()
    lu.set_options(var_options={}, direct=module_args)
    # testing run method when it doesn't find the file
    try:
        assert lu.run([], {})
    except AnsibleLookupError as e:
        assert "No file was found when using first_found." in str(e)
    # testing run method when it finds the file
    module_args = dict(
        files=[
            'foo.txt',
        ],
        paths=[
            '.',
        ],
    )
    lu.set_options(var_options={}, direct=module_args)

# Generated at 2022-06-21 06:11:35.078497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(
        terms=[{
            'files': 'foo',
            'paths': '/tmp/production',
        }]
    ) == ['/tmp/production/foo']
    assert l.run(
        terms=[{
            'files': 'foobar',
            'paths': '/tmp/production',
        }],
        variables={
            'ansible_distribution': 'Debian',
        }
    ) == ['/tmp/production/foobar']

# Generated at 2022-06-21 06:11:42.418714
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None

    # Test with only a list of file name, one being found.
    lookup.set_options(var_options={}, direct={})
    total_search, skip = lookup._process_terms(['/etc/hosts'], {}, {})
    assert total_search == ['/etc/hosts']
    assert skip is False
    assert lookup.run(['/etc/hosts'], {}) == ['/etc/hosts']

    # Test with only a list of file name, one being found when using a dict as term.
    lookup.set_options(var_options={}, direct={})
    total_search, skip = lookup._process_terms([{'files': '/etc/hosts'}], {}, {})
    assert total_

# Generated at 2022-06-21 06:11:55.636420
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    loader = get_loader_mock(
        dict(
            first_found={
                'files': ['foo', 'bar'],
                'paths': ['.'],
                },
            )
        )
    templar = Templar(loader=loader)

    l = LookupModule(loader=loader, templar=templar)

    # patching find_file to always return None
    original_find_file = l.find_file_in_search_path
    def patched_find_first_in_search_path(*args, **kwargs):
        return None
    l.find_file_in_search_path = patched_find_first_in_search_path

    # test with a list of terms
    terms = ['first_found', 'default_foo']