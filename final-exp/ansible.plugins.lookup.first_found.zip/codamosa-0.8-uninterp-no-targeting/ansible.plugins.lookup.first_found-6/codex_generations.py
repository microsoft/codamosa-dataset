

# Generated at 2022-06-21 06:04:05.345801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    def _find_file_in_search_path(variables, subdir, filename):
        if subdir == "files" and filename == "test.txt":
            return "/path/test.txt"
        return None

    options = dict(
        find_file_in_search_path = _find_file_in_search_path
    )
    options.update(getattr(LookupModule, '_lookup_plugin_options', {}))

# Generated at 2022-06-21 06:04:06.046721
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-21 06:04:19.300578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['file1', {'skip': 'on'}]
    variables = []
    total_search, skip = lookup._process_terms(terms, variables, {'files':'file1.cfg'})
    assert total_search == ['file1.cfg']
    assert skip is True
    terms = ['file1', 'file2']
    variables = []
    total_search, skip = lookup._process_terms(terms, variables, {'files': ['file1.cfg','file2.cfg']})
    assert total_search == ['file1.cfg','file2.cfg']
    assert skip is False
    terms = [['file1',{'paths': 'path1'}],['file2',{'paths': 'path2'}]]
    variables = []
    total_search, skip

# Generated at 2022-06-21 06:04:23.655172
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup

    terms = [None]

    # Ensure that the process_terms function doesn't raise an exception
    # when passed an invalid term
    lookup._process_terms(terms, {}, {})

# Generated at 2022-06-21 06:04:32.344958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test3: no files found: all paths with files (1, 2, 3), all the paths with files not specified
    term_list = [
        '',
        'fil1.txt',
        'fil2.txt',
        {'files': ['fil3.txt', 'fil4.txt'], 'paths': ['path1', 'path2', 'path3']},
        {'files': [], 'paths': ['path1', 'path2', 'path3']}
    ]
    # expected result:
    expected_result = []

# test1: first file found: the first one in first paths with files list

# Generated at 2022-06-21 06:04:38.925282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule()
    # Ignore the first argument to run()
    result = LookupModule(loader=None, templar=None, **module.params).run([{'files':'foo.txt'}], **module.params)
    assert result == ['/tmp/foo.txt']
    result = LookupModule(loader=None, templar=None, **module.params).run([{'files':'foo.txt', 'skip':'true'}], **module.params)
    assert result == []


# Generated at 2022-06-21 06:04:41.941329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._process_terms([{"_terms":"foo.txt","skip":True}, {"_terms":"bar.txt","skip":False},{"_terms": "biz.txt"}])

# Generated at 2022-06-21 06:04:49.290103
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:04:50.424411
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup is not None


# Generated at 2022-06-21 06:04:52.541639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule(testspec='', basedir='/test/test', runner_callbacks=None)
    assert lm is not None

# Generated at 2022-06-21 06:05:01.902012
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # assert that class creation doesn't fail
    lm = LookupModule()

    # assert that the class constructor fails with a LookupError when 'terms' != list
    assert_raises_AnsibleLookupError = False
    try:
        lm = LookupModule(terms='something')
    except AnsibleLookupError:
        assert_raises_AnsibleLookupError = True

    assert assert_raises_AnsibleLookupError == True

# Generated at 2022-06-21 06:05:03.983191
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()


# Generated at 2022-06-21 06:05:14.970176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Simple list
    results = LookupModule().run(["foo.txt"], {}, skip=True)
    assert results == [], "Expected empty list but got %s" % results

    # Simple list
    results = LookupModule().run(["foo.txt"], {})
    assert results == [], "Expected empty list but got %s" % results

    # Simple list
    results = LookupModule().run(["foo.txt", "bar.txt"], {})
    assert results == [], "Expected empty list but got %s" % results

    # Simple list
    results = LookupModule().run(["foo.txt", "bar.txt"], {}, skip=True)
    assert results == [], "Expected empty list but got %s" % results

    # Simple dictionary

# Generated at 2022-06-21 06:05:21.620748
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # XXX: this is currently not part of the CI, due to the module import at the file end.
    #      Ansible is not designed to be run from the test case class.
    from ansible import constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    class Options(object):
        def __init__(self, connection='local', module_path=None, forks=1, become=False,
                     become_method=None, become_user=None, check=False, diff=False):
            self.connection = connection
            self.module_path = module

# Generated at 2022-06-21 06:05:29.468431
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import StringIO
    import json

    # Simple checking with one file
    test_data = StringIO(json.dumps({
        'results': [
            "path/to/test"
        ],
        'test_args': {
            '_terms': [
                'test'
            ],
            'files': [
                'test'
            ],
            'paths': [
                'path/to'
            ]
        }
    }))

    try:
        test_results = json.load(test_data)
    except ValueError:
        assert False
    else:
        assert test_results

    lookup_module = LookupModule()

# Generated at 2022-06-21 06:05:33.485410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=[{
        'files': 'test.txt',
        'paths': 'tests/',
    }]) == ['tests/test.txt']


# Generated at 2022-06-21 06:05:35.445111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 06:05:47.608975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of class LookupModule
    """
    import os
    import tempfile
    import shutil
    import getpass
    tests_dir = os.path.dirname(os.path.abspath(__file__))
    module_path = os.path.join(tests_dir, '../../lookup_plugins/first_found.py')
    module_args = {'_raw_params': 'test.txt', '_task': None, '_ansible_check_mode': False, '_ansible_no_log': False,
                   '_ansible_debug': False, '_ansible_verbosity': 0}
    _temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 06:05:50.723177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.first_found import LookupModule
    import ansible.plugins.lookup.first_found
    x = LookupModule()
    assert x
    assert isinstance(x, LookupModule)
    assert x.run

# Generated at 2022-06-21 06:06:04.495323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    variables = dict(
        ansible_virtualization_type='foo',
        ansible_os_family=AnsibleUnsafeText('foo'),
        ansible_distribution=AnsibleUnsafeText('foo'),
    )
    kwargs = dict()

    play_context = PlayContext()
    templar = Templar(loader=None, variables=variables)

    looker = LookupModule()
    looker.set_loader(None)
    looker.set_environment(variables=variables,
                           loader=None,
                           templar=templar)
    looker._templar = templar

   

# Generated at 2022-06-21 06:06:16.549695
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleLookupError
    from ansible.plugins.lookup import LookupModule

    class FakeTemplar(object):
        def template(self, value, fail_on_undefined=True):
            return value

    class FakePlayContext(object):
        def __init__(self, options=None):

            class FakeOptions(object):
                def __init__(self, files_only=None):
                    self.files_only = files_only

            if options is None:
                options = FakeOptions()

            self.options = options

    # Create a fake play context with files_only set to 'True' (default value)
    play_context = FakePlayContext()

    # Create a fake templar
    templar = FakeTemplar()

    # Create a first_found lookup module with the fake

# Generated at 2022-06-21 06:06:17.135699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return []

# Generated at 2022-06-21 06:06:26.879820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: fails, subdir not being set correctly
    terms = [
        {'paths': '/tmp/path,tmp/path2', 'files': 'foo1,foo2'}
    ]
    variables = {}
    kwargs = {
        'skip': True,
    }

    lm = LookupModule()
    lm.get_basedir = lambda: '.'
    lm.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: 'foo'
    result = lm.run(terms, variables, **kwargs)

    assert result == ['foo']

# Generated at 2022-06-21 06:06:28.601951
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert isinstance(lm._templar, Template)

# Generated at 2022-06-21 06:06:33.720722
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    look = LookupModule()
    templar = Templar(loader=loader, variables=variable_manager)
    look._templar = templar
    # Basic constructor test
    assert isinstance(look, LookupModule)
    # Test all supported options in constructor

# Generated at 2022-06-21 06:06:35.456965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass


# Generated at 2022-06-21 06:06:39.338393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None

# Generated at 2022-06-21 06:06:43.030544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # NOTE: this is only testing if the start of the function runs,
    #       not testing actual logic.
    #
    terms = "myfile"

    vars = {}
    lookup = LookupModule()
    lookup.run(terms, vars, {})



# Generated at 2022-06-21 06:06:56.312637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible import context

    task_vars = dict(
        ansible_env=dict(
            ANSIBLE_NOCOLOR='1'
        ),
        task_vars={}
    )

    # TODO: context.CLIARGS needs to be unit tested and expanded

# Generated at 2022-06-21 06:06:58.535604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule('first_found', [], dict(), dict(), dict()))

# Generated at 2022-06-21 06:07:05.532502
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.subdir is None
    assert len(lookup.params) == 0

# Generated at 2022-06-21 06:07:10.647037
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Define a template for a term
    term_template = {'files':"foo", 'paths':"bar"}

    # Create a LookupModule instance
    l = LookupModule()

    # Define a dict containing the arguments for the method _process_terms
    args = {'terms': term_template, 'variables': {}, 'kwargs': {}}

    # Run the method
    (ret, skip) = l._process_terms(**args)

    # Check that the correct values are returned
    assert ret == ["bar/foo"]

# Unit test to test the method run

# Generated at 2022-06-21 06:07:21.622439
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert(LookupModule().run(
        [{}, {'files': ['/path/to/foo.txt', '/path/to/bar.txt'], 'paths': ['/extra/path']}],
        variables = {},
        skip = True
    ) == [])

    assert(LookupModule().run(
        [{'files': ['/path/to/foo.txt', '/path/to/bar.txt']}, {'files': ['username', 'tom', 'password'], 'paths': ['password']}],
        variables = {}
    ) == [])


# Generated at 2022-06-21 06:07:33.573158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test first_found with default parameters
    results = lookup_module.run(terms=[''], variables={})
    assert(results == [])

    # Test first_found with empty lookup_dirs
    results = lookup_module.run(terms=['/path/to/foo.txt'], variables={})
    assert(results == ['/path/to/foo.txt'])

    # Test first_found with one empty path
    results = lookup_module.run(terms=['/path/to/foo.txt'], variables={}, paths=[''])
    assert(results == ['/path/to/foo.txt'])

    # Test first_found with empty lookup_dirs and relative path
    results = lookup_module.run(terms=['foo.txt'], variables={})

# Generated at 2022-06-21 06:07:42.016459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test: no term provided
    lookup_module = LookupModule()
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run(None)  # noqa

    # test: invalid term provided
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run(123)

    # test: one string term provided
    term = '/foo/bar'
    lookup_module = LookupModule()
    response = lookup_module.run(term)
    assert response == [term]

    # test: one list provided
    term = ['/foo/bar', '/baz/qux']
    lookup_module = LookupModule()
    response = lookup_module.run(term)
    assert response == ['/foo/bar']

    # test

# Generated at 2022-06-21 06:07:54.301961
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    expected = {}
    expected[('/a/b/c/d/e/f', None, {'paths': ['a/b/c', 'd/e', 'f']}, ['/a/b/c/f'])] = \
    ['/a/b/c/f']

    expected[('/a/b/c/d/e/f', {'paths': ['a/b/c', 'd/e', 'f']}, None, ['/a/b/c/f'])] = \
    ['/a/b/c/f']


# Generated at 2022-06-21 06:08:00.710208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_gen  = LookupModule()
    assert lookup_gen._templar == None
    assert lookup_gen.basedir == None
    assert lookup_gen._basedir == None
    assert lookup_gen.no_lookup == None
    assert lookup_gen._no_lookup == None
    assert lookup_gen.run_once == False


# Generated at 2022-06-21 06:08:12.452239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([], {}) == []
    assert lookup.run([{'files': './files', 'skip': True}], {}) == []
    assert lookup.run([{'files': './files', 'skip': False}], {}) == []
    assert lookup.run([{'files': './files', 'skip': True}], {'lookup_file_found': './files'}) == ['./files']
    assert lookup.run([{'files': './files', 'skip': False}], {'lookup_file_found': './files'}) == ['./files']
    assert lookup.run([{'paths': './files', 'skip': True}], {}) == []

# Generated at 2022-06-21 06:08:13.316167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:08:14.188859
# Unit test for constructor of class LookupModule
def test_LookupModule():
  pass

# Generated at 2022-06-21 06:08:32.633413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)
    assert hasattr(lookup_obj, 'run')
    assert hasattr(lookup_obj, 'run')
    assert hasattr(lookup_obj, 'find_file_in_search_path')
    assert hasattr(lookup_obj, 'get_option')
    assert hasattr(lookup_obj, 'set_options')

# Generated at 2022-06-21 06:08:33.893667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module=LookupModule()
    assert(module is not None)

# Generated at 2022-06-21 06:08:35.687336
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:08:37.167319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None


# Generated at 2022-06-21 06:08:46.007032
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # basic test of run method
    lookup_term = 'first_found'

# Generated at 2022-06-21 06:08:48.099437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule(None, None, {})
    assert test

# Generated at 2022-06-21 06:08:53.236007
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert 'undefined_var' == lookup_module.run(None, {'undefined_var': 'undefined_var'}, errors='ignore')[0]
    assert 'undefined_var' == lookup_module.run('undefined_var', {'undefined_var': 'undefined_var'}, errors='ignore')[0]

# Generated at 2022-06-21 06:08:55.486849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:09:02.025461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    test_obj._templar = None
    terms = [{'files': 'foo,bar', 'paths': 'somedir'}, {'files': 'foo,bar', 'paths': 'somedir'}]
    result = test_obj.run(terms, {}, **{'skip': True})
    assert result == []

# Generated at 2022-06-21 06:09:09.695289
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Setup the instances
    module = LookupModule()

    # The expected result:
    expected_result = []

    # The actual result:
    actual_result = module.run([], {})

    # Assert:
    assert expected_result == actual_result, "Expected: %s, Actual: %s" % (expected_result, actual_result)

# Generated at 2022-06-21 06:09:29.914536
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory_manager)
    path_finder = LookupModule()
    path_finder.set_loader(loader)
    path_finder.set_templar(variable_manager)
    return path_finder

# Generated at 2022-06-21 06:09:35.499811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # GIVEN: all the needed args
    terms = []
    variables = {}
    kwargs = {}

    # WHEN: instantiating a LookupModule object
    lookup_module = LookupModule()

    # THEN: LookupModule object is returned and all attributes are as expected
    assert lookup_module is not None
    assert lookup_module.run(terms, variables, **kwargs) == []

# Generated at 2022-06-21 06:09:42.666138
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar

    vars_dict = dict()
    templar = Templar(loader=None, variables=vars_dict)
    lookup = LookupModule()
    lookup._templar = templar
    lookup._finder = None
    lookup._split_on = _split_on

    # NOTE: the '_process_terms' is designed to work with a dict in 'terms'
    # and so the output of _process_terms will only return the last dict read.
    # If a list is passed to 'terms' _process_terms will iterate over it and call
    # 'set_options' with each value, that will reset the options for each call.
    # That will make the result of _process_terms unpredictable depending on what
    # is the last value in the list. To avoid the issue no list is allowed, and

# Generated at 2022-06-21 06:09:44.025278
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({}, {}, '', '', '')

# Generated at 2022-06-21 06:09:46.869969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup tests
    # Setup mocks
    # Run run
    # Assert
    assert False

# Generated at 2022-06-21 06:09:48.399134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:09:59.102918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make a mock object instead of calling the real object that works with the filesystem
    lookup_obj = LookupModule()

    # Use a 'magic' method to return a specific value.
    # In this case 'find_file_in_search_path' is stubbed with a lambda that always returns a value
    lookup_obj.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: "/some/file"

    # Double-check the real method 'find_file_in_search_path' for doctest
    assert lookup_obj.find_file_in_search_path(None, None, None, None) == None

    # Call the method we are testing with a known value
    result = lookup_obj.run(terms=[], variables={})

    # Check if we have the expected value

# Generated at 2022-06-21 06:10:02.574716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result.run(terms=['/path/1', '/path/2'], variables={}, skip=True) == []

# Generated at 2022-06-21 06:10:10.445509
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.module_runner import LoggingFilters
    from ansible.module_utils.six import StringIO

    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup.first_found import LookupModule

    loader, inventory, variable_manager = get_loader()

    # Create a runner

# Generated at 2022-06-21 06:10:12.200626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(terms=[], variables=dict(), **dict())

# Generated at 2022-06-21 06:10:26.992602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__bases__[0].__name__ == 'LookupBase'
    assert LookupModule.__init__.__code__.co_varnames[0] == 'self'


# Generated at 2022-06-21 06:10:39.658422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {
        'foo': 'baz',
        'bar': 'bar',
        'ansible_foo': 'baz'
    }
    lookup._templar = Templar(loader=loader, variables=variable_manager)
    terms = ['{{ foo }}_foo.conf', '{{ bar }}_foo.conf', 'default_foo.conf']

# Generated at 2022-06-21 06:10:40.543577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:10:50.582121
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mod = LookupModule()
    mod._templar.add_template_dir('/test')
    mod._basedir = '/test'

    # Test templating of string
    assert mod._process_terms(['/test/a'], {}, {}) == ([], False)

    # Test templating of list
    assert mod._process_terms(['{{ item }}'], {'item': '/test/a'}, {}) == ([], False)
    assert mod._process_terms(['{{ item }}', '{{ item }}'], {'item': '/test/a'}, {}) == ([], False)

    # Test dict with no list
    assert mod._process_terms([{'files': 'test.conf'}], {}, {}) == ([], False)

    # Test dict with list

# Generated at 2022-06-21 06:11:02.013893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test load the module without file system access
    lookup_plugin = LookupModule()

    # test basic term list
    terms = ['foo.txt', 'bar.txt', 'biz.txt']
    result = lookup_plugin.run(terms, variables=None)
    assert result == [], 'No files found in empty filesystem'

    # test file list with paths
    terms = [{'files': 'foo.txt,bar.txt,biz.txt', 'paths': '/tmp/staging:/tmp/production'}]
    result = lookup_plugin.run(terms, variables=None)
    assert result == [], 'No files found in empty filesystem'

    # test file list with paths and spliters

# Generated at 2022-06-21 06:11:05.889603
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert hasattr(test, 'run')
    assert hasattr(test, '_process_terms')


# Generated at 2022-06-21 06:11:15.539938
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("")
    print("test_LookupModule_run")
    print("")
    # create object
    lookup_test_object = LookupModule()

    test_params_1 = {
        'files': 'foo',
        'paths': '/bar'
    }

    test_params_2 = {
        'files': 'foo',
        'paths': '/bar',
        'skip': 'False'
    }

    test_params_3 = {
        'files': ['foo', 'bar'],
        'paths': ['/foo', '/bar']
    }

    test_params_4 = {
        'files': ['foo', 'bar'],
        'paths': ['/foo', '/bar'],
        'skip': 'True'
    }


# Generated at 2022-06-21 06:11:26.469938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    import pytest
    from ansible.utils.collection_loader import _get_collection_name

    def pwd(kwargs):
        """
        Returns the current directory
        """
        return kwargs.get('ansible_playbook_dir') or os.getcwd()

    def path_join(pwd, file):
        """
        Returns the full path of a file from its name
        """
        return os.path.join(pwd, file)

    os_path_exists = os.path.exists
    os_path_join = os.path.join

    ##
    ## local_path tests
    ##
    os.path.join = path_join

# Generated at 2022-06-21 06:11:34.413069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instanciate a LookupModule object
    module = LookupModule()

    # tests lookup_module with default parameters
    def test_lookup_module_default():
        assert module.run(terms=['bar.txt', 'foo/bar.txt']) == ['bar.txt', 'foo/bar.txt']

    # test lookup_module with valid parameters
    def test_lookup_module_with_parameters():
        assert module.run(terms=[{'skip': False}, 'bar.txt', 'foo/bar.txt'], variables={'skip': True}) == ['bar.txt', 'foo/bar.txt']
        assert module.run(terms=[{'skip': True}, 'bar.txt', 'foo/bar.txt'], variables={'skip': True}) == []

    # test lookup_module with undefined parameters

# Generated at 2022-06-21 06:11:45.320006
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:12:16.028352
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class OptionsModule(object):
        def __init__(self, value):
            self.value = value

        def __getattr__(self, name):
            return self.value

    lookup = LookupModule()
    lookup.set_options(OptionsModule([]))
    lookup._templar = None
    lookup._loader = None
    lookup._find_file_in_search_path = None
    lookup._subdir = 'files'

    assert ['/tmp/foo.txt'] == lookup.run(['/tmp/foo.txt'], None)
    assert ['/tmp/bar.txt'] == lookup.run(['/tmp/foo.txt', '/tmp/bar.txt', '/tmp/biz.txt'], None)
    assert ['foo.txt'] == lookup.run(['foo.txt'], None)

# Generated at 2022-06-21 06:12:23.703374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=too-many-statements
    lookup = LookupModule()
    # test_matches

    terms = (
        {'paths': os.path.join(os.path.dirname(__file__), 'files'), 'files': 'test_1.txt,test_2.txt'},
        os.path.join(os.path.dirname(__file__), 'files', 'test_1.txt'),
        'test_3.txt',
    )
    variables = {}
    files = []
    paths = []
    skip = False

    # test_1.txt is first in the list of the search paths
    result = lookup.run(terms, variables)


# Generated at 2022-06-21 06:12:31.581811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.system import System
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 06:12:32.792084
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:12:37.129291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule), "A new instance of LookupModule should be a LookupModule"

# Unit tests for _process_terms

# Generated at 2022-06-21 06:12:40.080259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write the tests
    pass

# Generated at 2022-06-21 06:12:48.561228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # NOTE: the test does not cover all of the different 'paths' and 'files' combinations
    # as the code for 'dict as term' is broken and inconsistent, as noted above
    # results are different for files/paths as a list vs a single string
    # FIXME - Do we need to fix first_found? (see comments in the above run method)
    # TODO: fix the following tests once first_found is fixed
    assert module.run([{'files': 'test.txt',
                        'paths': 'path',
                        'skip': False}],
                      variables=None,
                      inject=dict(),
                      **{'wantlist': True}) == [os.path.join('files', 'path', 'test.txt')]


# Generated at 2022-06-21 06:12:51.087252
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Check with empty parameter
    l = LookupModule()
    assert l != None


# Generated at 2022-06-21 06:12:52.798643
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm


# Generated at 2022-06-21 06:12:56.737132
# Unit test for constructor of class LookupModule
def test_LookupModule():

    t = LookupModule()

    assert t._subdir is None

    t2 = LookupModule('default')

    assert t2._subdir == 'default'