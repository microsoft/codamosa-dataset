

# Generated at 2022-06-21 06:04:05.821976
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:04:18.993087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case for passing the file names as list of strings
    for test_file_path in ["lib_file.yml", "@lib_file.yml", "./lib_file.yml", "./lib_file"]:
        lookup_o = LookupModule()
        file_list = [test_file_path]
        result = lookup_o.run(file_list, dict())
        assert list(result) == file_list

    # Test case for passing the file names as dictionary with key 'files'
    for test_file_path in ["lib_file.yml", "@lib_file.yml", "./lib_file.yml", "./lib_file"]:
        lookup_o = LookupModule()
        file_list = [test_file_path]
        dict_input = dict(files=file_list)

# Generated at 2022-06-21 06:04:28.120548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test_terms = [
        'foo',
        {'files': 'foo', 'paths': 'path1'},
        ['bar', {'files': 'bar', 'paths': 'path2'}],
        ['foo', 'bar', 'baz'],
        ['foo', ['bar', 'baz']],
        ['foo', ['bar', ['baz', 'buz']]],
    ]
    test_variables = {
        'inventory_hostname': 'test_host',
        'ansible_virtualization_type': 'test_type',
     }
    test_kwargs = {
        'files': 'foo',
        'paths': 'path1',
        'skip': 'True',
    }

# Generated at 2022-06-21 06:04:29.292496
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:04:35.990021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    params = dict(
        files=['foo', '{{ foo }}'],
        paths=['extra/path'],
        skip=True
    )

    terms = [
        'path/file1.txt', 'path/file2.txt',
        {
            'files': ['{{ bar }}', 'bar.txt'],
            'paths': ['path/common', '{{ path }}/common']
        },
        'file4.txt',
        params
    ]

    mock_templar = MockTemplar(dict(foo='file3.txt', bar='file5.txt', path='path'))

    # The expected value is a dictionary so it can be passed to the mock object

# Generated at 2022-06-21 06:04:41.625528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert isinstance(lookup_module._templar, LookupBase._NonTemplar)
    assert lookup_module._loader is None
    assert lookup_module._basedir is None
    assert lookup_module._environment is None
    assert lookup_module._fail_on_undefined_errors is True
    assert lookup_module._available_variables is None
    assert lookup_module.params == {}
    assert lookup_module._options is None


# Generated at 2022-06-21 06:04:51.435118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Create a plugin to test
    #
    class TestLookup(LookupModule):
        def __init__(self, basedir=None, **kwargs):
            self.basedir = basedir

        def run(self, terms, inject=None, **kwargs):

            terms = super(TestLookup, self).run(terms, inject=inject, **kwargs)
            return terms

        # Use the code from the LookupModule.find_file_in_search_path()
        # method, but without the actual file search.
        def find_file_in_search_path(self, variables, searchpath, filename, ignore_missing=False):
            found = False
            dirs = self._get_search_paths(variables, searchpath)

# Generated at 2022-06-21 06:04:52.585074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



# Generated at 2022-06-21 06:04:54.470011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a class instance
    LookupModule("name", "path")


# Unit testing for class LookupModule

# Generated at 2022-06-21 06:05:06.223093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-21 06:05:19.143710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test the lookup module's run method """
    module = LookupModule()

    assert module.run(terms=[{'files': 'foo1,foo2', 'paths': '/path1:/path2'}], variables={}) == ['/path1/foo1', '/path1/foo2', '/path2/foo1', '/path2/foo2']
    assert module.run(terms=[{'files': 'foo1,foo2', 'paths': '/path1:/path2'}, 'foo3'], variables={}) == ['/path1/foo1', '/path1/foo2', '/path2/foo1', '/path2/foo2']
    assert module.run(terms=['foo1,foo2', 'foo3'], variables={}) == ['foo1', 'foo2']

# Generated at 2022-06-21 06:05:31.735818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import constants as C

    class VarsModule:
        def __init__(self, d):
            self.vars = d

        def vars(self):
            return self.vars

    # the VarsModule is the object 'variables' will resolve to
    # here we set it to a simple dic with the content {'foo': 'bar'}
    variables = VarsModule({'foo': 'bar'})

    # here we create a class where the env variable ANSIBLE_KEEP_REMOTE_FILES
    # is always set to 1, otherwise we would need to set it before executing
    # all the tests.
    class Env:
        def __init__(self, d):
            self.d = d


# Generated at 2022-06-21 06:05:42.103839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    display = Display()
    loader = DataLoader()
    paths = [os.path.realpath(__file__)]
    inventory = InventoryManager(loader=loader, sources=paths)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([{
        'files': [
            'test_LookupModule_run.py'
        ]
    }], variable_manager) == [os.path.realpath(__file__)]



# Generated at 2022-06-21 06:05:51.697542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from textwrap import dedent
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native

    # Create a simple mock class for LookupBase
    class LookupBaseMock(object):
        class Error(Exception):
            pass

        def _get_file_loader(self, search_path):
            return [ '/path/to/file' ]
            
        def expand_basedir(self, basedir, vars):
            return basedir

    # Create a simple mock class for AnsibleVariableManager

# Generated at 2022-06-21 06:06:04.849104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves.urllib.parse import quote as urlquote, unquote as urlunquote
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    lookup = LookupModule()

    # prepare the objects needed to set the 'self' variable in the lookup module
    loader = DataLoader()
    variable_manager = VariableManager()

    variable_manager.set_inventory(loader.load_inventory({'localhost': {}}))
    variable_manager.set_vars({"inventory_hostname": 'localhost'})

    # single file and path

# Generated at 2022-06-21 06:06:07.551361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 06:06:16.651575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {
            'files': 'file1.txt',
            'paths': 'dir1',
        },
        {
            'files': 'file2.txt',
            'paths': 'dir1,dir2',
        },
        {
            'files': 'file3.txt',
            'paths': 'dir3:dir4',
        },
        {
            'files': 'file4.txt,file5.txt',
            'paths': 'dir5,dir6',
        },
        {
            'files': 'file6.txt,file7.txt',
            'paths': 'dir7:dir8',
        },
        {
            'files': 'file8.txt;file9.txt',
            'paths': 'dir9',
        }
    ]

    #

# Generated at 2022-06-21 06:06:27.841219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test requires the following fixtures:
    #   - lookup_injector (mock_lookup_injector)
    #   - finder (mock_finder)
    #   - loader (mock_loader)
    #   - templar (mock_templar)
    lookup = LookupModule()
    # setup objects
    test_variables = dict()
    lookup_injector.lookup_loader = 'lookup_loader'
    lookup_injector.get_loader_for_task = lambda: 'mock_loader'
    # run test
    lookup.run(terms=['file1', 'file2'], variables=test_variables)
    # verify

# Generated at 2022-06-21 06:06:29.173475
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup
  assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 06:06:38.338840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # preparing for the test
    import tempfile
    import shutil

    path = tempfile.mkdtemp(dir='.')
    f1 = tempfile.NamedTemporaryFile(dir=path, delete=False)
    f2 = tempfile.NamedTemporaryFile(dir=path, delete=False)
    subpath = tempfile.mkdtemp(dir=path)
    f3 = tempfile.NamedTemporaryFile(dir=subpath, delete=False)

    lu_module = LookupModule()
    lu_module._templar = None

    # negative tests
    lu_module._subdir = path
    assert lu_module.run([f1.name], None) == [f1.name]

# Generated at 2022-06-21 06:06:45.679047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'files': 'foo,bar', 'paths': 'baz:biz'}, 'foo.txt', ['foo', 'bar']]
    variables = {}
    kwargs = {}
    r = LookupModule().run(terms, variables, **kwargs)
    assert r == ['/etc/ansible/files/foo.txt']

# Generated at 2022-06-21 06:06:47.265960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:06:55.073477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'files': 'hosts', 'paths': '/tmp'},
        {'files': 'hosts', 'paths': '/etc'},
        {'files': 'hosts', 'paths': '/opt/ansible'}
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None, skip=True)
    assert result == [], "Unexpected result %s" % result

# Generated at 2022-06-21 06:06:56.347817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Create class LookupModule.
    :return:
    """
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:07:02.746533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types

    # CREATE DUMMY CLASS
    class DummyInt(object):
        def __init__(self, value):
            self.value = value

        def get(self, key):
            if key == 'no_log':
                return False
            elif key == '_raw_params':
                return None
            elif key == 'task_vars':
                # TODO: more work here, just return a template var
                return {'ansible_distribution': 'debian', 'ansible_os_family': 'Debian'}
            elif key == 'play_context':
                return None
            else:
                # return a default
                return self


# Generated at 2022-06-21 06:07:09.940600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    import pytest
    from ansible.errors import AnsibleLookupError
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.lookup.first_found import LookupModule

    test_lookup_module = LookupModule()
    test_lookup_module._templar = Templar(None, vault_secrets=[])
    test_lookup_module._loader = None
    test_lookup_module._templar._vault = VaultLib(None, None, False, False)

    test_path1 = "test_path1"
    test_path2 = "test_path2"
    test_path3 = "test_path3"

    test_

# Generated at 2022-06-21 06:07:13.020957
# Unit test for constructor of class LookupModule
def test_LookupModule():
    nmInst = LookupModule()
    assert nmInst._subdir is None
    assert nmInst.get_option('error') is None
    assert nmInst.get_option('files') == []
    assert nmInst.get_option('paths') == []
    assert nmInst.get_option('skip') is False


# Generated at 2022-06-21 06:07:22.484485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.basic
    import ansible.module_utils.common.collections
    import ansible.module_utils.six
    import ansible.plugins
    import ansible.template
    import ansible.utils
    import ansible.vars
    fake_subdir = 'files'
    fake_templar = ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader())
    fake_loader = ansible.parsing.dataloader.DataLoader()
    fake_variable_manager = ansible.vars.VariableManager()
    fake_variable_manager._fact_cache = dict()
    fake_variable_manager.extra_vars = dict()
    fake_variable_manager.options_vars = dict()
    fake_variable_manager.host

# Generated at 2022-06-21 06:07:24.953572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run(['/etc/passwd'], None)) == 1

# Generated at 2022-06-21 06:07:27.485174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:07:42.049702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class AnsibleOptions:

        verbosity = 0


# Generated at 2022-06-21 06:07:54.338935
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # test string term

    # NOTE: this is a special case for a string, if it is a dict it will use 'files/paths' (see below)
    # but this 'dict' is not a dict but a string that starts with '{', '[' or '{'
    term = "{'files': 'non_existing_file.txt', 'paths': ['path1', 'path2']}"
    files, paths, skip = lookup._process_terms(term, terms=[term], kwargs={})
    assert files == ['non_existing_file.txt']
    assert paths == ['path1', 'path2']
    assert skip is False

    # test dict term

    # NOTE: this is a special case, this 'dict' is not a dict but a string that starts with '{', '[' or '{

# Generated at 2022-06-21 06:08:05.435912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    import os
    import os.path
    import shutil

    temproot = tempfile.mkdtemp()
    path1 = tempfile.mkdtemp(prefix='path1_', dir=temproot)
    path2 = tempfile.mkdtemp(prefix='path2_', dir=temproot)
    path3 = tempfile.mkdtemp(prefix='path3_', dir=temproot)
    file1 = os.path.join(path1, 'foo1.txt')
    file2 = os.path.join(path2, 'foo2.txt')
    open(file1, 'w').close()
    open(file2, 'w').close()

# Generated at 2022-06-21 06:08:14.142307
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:08:20.565889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Dummy vars and terms to create an instance of LookupModule
    terms = ['files/fqdn.txt', 'files/default.txt']
    variables = {}

    # Create an instance of LookupModule
    lm = LookupModule()
    lm.run(terms, variables)



# Generated at 2022-06-21 06:08:21.951762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:08:34.993647
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:08:44.406117
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # set up
    lookup1 = LookupModule()
    lookup2 = LookupModule()
    lookup3 = LookupModule()

    # test
    assert lookup1.get_option('skip') is False
    assert lookup2.get_option('skip') is False
    assert lookup3.get_option('skip') is False

    terms = [
        {'files': 'foo', 'paths': ['path/main']},
        'bar',
        {'files': ['baz'], 'paths': 'path/extra'},
        {'skip': True},
    ]
    lookup1._process_terms(terms, 'variables', {})
    lookup2._process_terms(terms, 'variables', {})
    lookup3._process_terms(terms, 'variables', {})


# Generated at 2022-06-21 06:08:45.755782
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test constructor with no params
    module = LookupModule()
    assert True


# Generated at 2022-06-21 06:08:46.654684
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:09:06.576706
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import MutableSequence

    lookup_module = LookupModule()

    terms = ['foo', {'files': 'bar', 'paths': 'baz'}, ['foo', 'bar', 'baz']]

    variables = {}

    kwargs = {}

    results = lookup_module._process_terms(terms, variables, kwargs)

    assert len(results) is 2
    assert isinstance(results[0], MutableSequence)
    assert len(results[0]) is 5
    assert isinstance(results[1], bool)



# Generated at 2022-06-21 06:09:07.522106
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:09:08.931781
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-21 06:09:18.141873
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from collections import namedtuple
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock


# Generated at 2022-06-21 06:09:23.732483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="lookup_test",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='lookup_first_found_runs')))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None
    lookup_plugin = Look

# Generated at 2022-06-21 06:09:25.434548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:09:31.073727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestClass:
        _templar = None
        _subdir = None
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return fn

    x = LookupModule(TestClass())
    assert x

# Generated at 2022-06-21 06:09:35.116453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    # test '_process_terms'
    lookup_class._process_terms([
        'tests/test1',
        'tests/test2',
        'tests/test3'
    ], {}, {})

# Generated at 2022-06-21 06:09:42.472257
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.module_utils.six import PY2

    # valid input

    # NOTE: test cases with correct data, but with a dict type used as 'term'
    #  are hard to test as the plugin code assumes 'one only' ever.
    #  In other words, the dict type 'term' is not really usable for more
    #  than one search as the plugin code does not handle it as a list of dicts.
    #  This is probably a bug?


# Generated at 2022-06-21 06:09:43.588884
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:10:15.696636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()

    # Default functionality, return first file found
    terms = [
        '/path/to/file1',
        '/path/to/file2',
        '/path/to/file3',
        'file4',
        'file5',
    ]
    terms_return = [
        '/path/to/file1',
        'file4',
    ]
    assert obj.run(terms, {}) == terms_return

    # Term type is Mapping, return first file found
    terms = [
        {
            'files': 'file1',
            'paths': '/path/to/',
        },
        {
            'files': 'file2',
            'paths': '/path/to/',
        },
    ]

# Generated at 2022-06-21 06:10:29.226980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Basic test for constructor of class LookupModule """
    # Test with arbitrary strings
    arbitrary_string1 = 'foobar'
    arbitrary_string2 = 'barfoo'
    arbitrary_string3 = 'foobaz'

    # Test with arbitrary integers
    arbitrary_integer = 12345

    # Test with arbitrary dict
    arbitrary_dict1 = {
        'foo': 'bar',
        'bar': 'baz'
    }

    arbitrary_dict2 = {
        'files': ['file1', 'file2'],
        'paths': ['path1', 'path2']
    }

    # Test with arbitrary dictionary with .items() method
    class MockDict:
        def items(self):
            return arbitrary_dict1.items()

    mock_dict = MockDict()

    # Test with arbitrary list
    arbitrary_

# Generated at 2022-06-21 06:10:40.627259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    files_dict = {"files": ["foo.txt", "bar.txt", "biz.txt"], "paths": ["/path/to", "/path/to/another/location"]}
    files_list = ["foo.txt", "bar.txt", "biz.txt", {"paths": ["/path/to", "/path/to/another/location"]}]
    try:
        lookup_ansible_module = LookupModule()
        assert False, "AnsibleLookupError not raised"
    except AnsibleLookupError:
        pass
    lookup_ansible_module = LookupModule(None)
    lookup_ansible_module._process_terms(files_dict)
    lookup_ansible_module._process_terms(files_list)

# Generated at 2022-06-21 06:10:41.576543
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:10:44.362567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:10:53.219510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    lm = lookup_loader.get('first_found')

    t = Templar(loader=None, variables={})

    lm._templar = t

    facts = dict()
    lm._subdir = ''

    # Without file names and paths
    lm._shared_loader_obj = type('', (), {"_find_file_in_path": _find_file_in_path_no_file, "_get_file_contents": _get_file_contents_no_file})

# Generated at 2022-06-21 06:11:02.897723
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # execute method run with empty terms
    lookup_mod = LookupModule()
    assert [] == lookup_mod.run(terms="", variables="")

    # execute method run with a string term
    lookup_mod = LookupModule()
    assert ['ThisIsATestString'] == lookup_mod.run(terms="ThisIsATestString", variables="")

    # execute method run with a list term
    terms = ["ThisIsATestString", dict(files="test_file")]
    lookup_mod = LookupModule()
    assert ['ThisIsATestString', 'test_file'] == lookup_mod.run(terms=terms, variables="")

    # execute method run with a dict term and with a dict trail
    terms = ["ThisIsATestString", dict(files="test_file")]
    lookup_mod = LookupModule()
   

# Generated at 2022-06-21 06:11:06.641784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    x = None
    try:
        x = lm.run(['foo'], ())
    except Exception as e:
        x = e

    assert(x), "No exception was raised"

    assert(isinstance(x, AnsibleLookupError))
    assert(str(x) == "No file was found when using first_found."), \
        "Unexpected error: %s" % x

# Generated at 2022-06-21 06:11:17.927819
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given
    from ansible.module_utils._text import to_bytes
    lookup_plugin = LookupModule()

    terms = (
        ('foo.txt', 'bar/bar.txt'),
        'relative/baz.txt',
        {'files': 'foo.txt,bar/bar.txt', 'paths': '/etc/ansible/'},
    )
    task_vars = {}

    # When
    try:
        path = lookup_plugin.run(terms=terms, variables=task_vars)[0]
    except Exception as e:
        if e.message == 'No file was found when using first_found.':
            path = None

    # Then
    assert path != None
    assert path.endswith('bar.txt')



# Generated at 2022-06-21 06:11:20.793431
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # testing the constructor of LookupModule
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)


# Generated at 2022-06-21 06:12:10.365771
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:12:16.783005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    def _get_mock_variable(mock_type, name, value):
        if name == 'foo':
            mock_variable = Mock()
            mock_variable.name = 'foo'
            mock_variable.value = 'bar'
            return mock_variable
        elif name == 'ansible_virtualization_type':
            mock_variable = Mock()
            mock_variable.name = 'ansible_virtualization_type'
            mock_variable.value = 'kvm'
            return mock_variable
        else:
            raise Exception('Not found')


# Generated at 2022-06-21 06:12:25.470591
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def set_cwd(dirname):
        """
        Patch os.getcwd for the duration of the test.
        """
        cwd_func = os.getcwd
        os.getcwd = lambda: dirname
        assert os.getcwd() == dirname
        return cwd_func


# Generated at 2022-06-21 06:12:36.679408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: this not needed, but locust (linting) is not smart enough to see the class method definition
    test_class = LookupModule

    # Unit testing of proof of concept (poc) and design.
    # This is a proof of concept, thus not all edge cases are covered.
    #
    # The overall design is done with test cases to verify assumptions, however the tests are
    # not intended to cover all edge cases. Doing so would not help in this case as the
    # design is very complex. Using tests to help design the code is fine and more tight
    # than designing large sections of code and then testing it.
    #
    # While not covering all edge cases, it does cover the main 'design' ideas of the
    # plugin, which is to:
    #   * split on various chars
    #   * handle a 'mapping'

# Generated at 2022-06-21 06:12:47.868942
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Testing instance creation
    instance = LookupModule()

    # Testing __doc__ attribute

# Generated at 2022-06-21 06:12:54.030346
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_text

    lookup = LookupModule()

    files = ['foo.yml', 'bar.yml']
    paths = ['/tmp/package', '/tmp/product']
    file_paths = []

    for path in paths:
        for fn in files:
            file_paths.append(os.path.join(path, fn))

    # _process_terms test, check that _split_on is working correctly
    total_search, skip = lookup._process_terms([paths, files], {}, {})
    assert total_search == file_paths

    # factory mock ansible.module_utils.basic.AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    module = Ans

# Generated at 2022-06-21 06:13:01.929296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    terms = [{'files': 'test.yaml'}]
    result = f.run(terms, {})
    assert result[0] == 'test.yaml'
    result = f.run(terms, {}, skip=True)
    assert result == []
    result = f.run(terms, {}, skip=True)
    assert result == 'test.yaml'

# Generated at 2022-06-21 06:13:08.535799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    play_context.loader = loader
    templar = Templar(loader=loader, variables=dict())

    # test1: check correct behaviour
    findme = [
        '/path/to/foo.txt',
        'bar.txt',
        '/path/to/biz.txt'
    ]
    first_found = LookupModule()
    first_found._templar = templar
    first_found.set_options(var_options=dict(), direct=dict(files=[]))  # noqa
    res = first_found

# Generated at 2022-06-21 06:13:13.297226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for single file
    assert LookupModule._split_on('/file/one') == ['/file/one']
    assert LookupModule._split_on('/file/one,/file/two') == ['/file/one', '/file/two']
    # Test for multiple files
    assert LookupModule._split_on(['/file/one', '/file/two']) == ['/file/one', '/file/two']
    assert LookupModule._split_on(['/file/one,/file/two']) == ['/file/one', '/file/two']
    assert LookupModule._split_on(['/file/one,/file/two,/file/three']) == ['/file/one', '/file/two', '/file/three']

# Generated at 2022-06-21 06:13:15.434309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    lookup_class = lookup_loader._get_lookup_plugin_class('first_found')
    lookup = lookup_class()
    assert lookup is not None