

# Generated at 2022-06-21 06:03:59.236524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_name = 'test.file'
    test_file_path = os.path.join(os.path.dirname(__file__), file_name)
    test_files = [test_file_path]
    test_paths = [os.path.dirname(__file__)]

    lookup_module = LookupModule()
    assert lookup_module.run(test_files, [], paths=test_paths) == [test_file_path]

# Generated at 2022-06-21 06:04:08.647287
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup_module = LookupModule()
    terms = [
                {
                    'files': 'foo',
                    'paths': 'path/to/some/where',
                    'skip': False
                },
                {
                    'files': 'foo2',
                    'paths': 'path/to/some/where',
                    'skip': True
                },
                {
                    'files': 'foo3',
                    'paths': 'path/to/some/where'
                },
                [
                    {
                        'files': 'foo4',
                        'paths': 'path/to/some/where'
                    },
                    {
                        'files': 'foo4',
                        'paths': 'path/to/some/where'
                    },
                ],
            ]

    # Pretend there is no file
   

# Generated at 2022-06-21 06:04:21.068516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    # set up the task queue manager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost, '])
    variable_manager.set_inventory(inventory_manager)

# Generated at 2022-06-21 06:04:29.354076
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: remove to avoid deprecation warnings
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # TODO: fake instead
    class Variables(object):
        def __init__(self, *args, **kwargs):
            pass

    class PlayContext(object):
        def __init__(self, *args, **kwargs):
            pass

    class LookupBase(object):
        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing):
            if fn == 'foo.yml':
                return '/path/to/foo.yml'
            if fn == 'bar.yml':
                return '/other/to/bar.yml'

# Generated at 2022-06-21 06:04:31.663405
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-21 06:04:40.780830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.module_utils.six import StringIO

    lookup_module = LookupModule()
    # use search path containing tempdir

    lookup_module._templar = lookup_module._loader.load_contents(StringIO(os.path.abspath(__file__)), template_vars={})

    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)


# Generated at 2022-06-21 06:04:44.214529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: use parameters here
    lookup_module = LookupModule()
    lookup_module._templar.available_variables = dict()
    lookup_module._templar.template_vars = dict()

    return lookup_module

# Generated at 2022-06-21 06:04:51.515377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    my_vars = {}
    my_loader = DataLoader()

    # NOTE: real world usage of this would be awesome
    lookup = LookupModule()

    variables = {}
    options = {"files":[], "paths":[]}
    terms = [{}, {}, {}]

    # NOTE: above is not properly constructred, but is the input expected
    # in real world usage.
    results = lookup.run(terms, variables, **options)
    assert results is None

# Generated at 2022-06-21 06:04:54.288944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'files': 'foo.txt', 'paths': 'bar/'}, 'baz.txt']
    variables = {}
    ret = LookupModule(terms, variables).run()
    assert ret == [], "The return value of LookupModule().run() is incorrect"

# Generated at 2022-06-21 06:05:00.408258
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate a sub class of LookupModule
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run') and callable(getattr(lookup_module, 'run'))
    assert hasattr(lookup_module, '_process_terms') and callable(getattr(lookup_module, '_process_terms'))

# Generated at 2022-06-21 06:05:14.631453
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule.test_1 = lambda self, terms, variables, kwargs: (terms, variables, kwargs)
    LookupModule.test_2 = lambda self, terms, variables, kwargs: (terms, variables, kwargs)

    l = LookupModule()
    l._subdir = 'test_1'

    #
    # Test 1
    #

    t, v, k = l.run('foo.txt', 'myvar')
    assert t == ['foo.txt']
    assert v == 'myvar'
    assert k == {}

    t, v, k = l.run('foo.txt', 'myvar', baz='faz')
    assert t == ['foo.txt']
    assert v == 'myvar'
    assert k == {'baz': 'faz'}

    t,

# Generated at 2022-06-21 06:05:21.441992
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This test is not really complete
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    # initialize needed objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager, loader=loader, options=None, passwords=None)

    # create some test paths
    variables = {}

# Generated at 2022-06-21 06:05:29.350667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('*** testing first_found')
    t = LookupModule()
    t._templar = None
    t._loader = None
    t._templar.loader = None
    t._templar.environment = None

# Generated at 2022-06-21 06:05:38.422102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [{
        'files': 'a,b',
        'paths': 'x:y'
    }, {
        'files': 'foo,bar',
        'paths': 'x:y'
    }, 'test1', 'test2']
    variables = {}
    kwargs = {}
    total_search, skip = lookup._process_terms(terms, variables, kwargs)

    assert total_search == ['x/a', 'y/a', 'x/b', 'y/b', 'x/foo', 'y/foo', 'x/bar', 'y/bar', 'test1', 'test2']
    assert skip is False


# Generated at 2022-06-21 06:05:48.551047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create objects
    t = LookupModule()
    terms = ['/home/user/somefile', '/opt/somedir/somefile', '/usr/somedir/somefile']
    variables = {}
    kwargs = {}
    # Call run
    actual_results = t.run(terms, variables, **kwargs)
    # Compare results with expected results
    assert actual_results == ['/home/user/somefile']

# Generated at 2022-06-21 06:05:59.519585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize LookupModule class
    lookup_module = LookupModule()

    # stub the find_file_in_search_path method
    lookup_module.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing=True : "/path/to/file"

    # Test with keyword arguments
    terms = [ "bar", "foo" ]
    variables = {}
    kwargs = { "files": "bar, foo", "paths": "path1, path2", "skip": True }
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['/path/to/file']

    # Test with one keyword arguments
    terms = [ "bar", "foo" ]
    variables = {}

# Generated at 2022-06-21 06:06:09.080444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'myfile',
        {
            'files': 'other-file',
            'paths': 'path1:path2',
            'skip': True
        },
        {
            'files': 'another-file'
        },
        [
            'file1',
            'file2'
        ]
    ]

    actual_terms = [
        'myfile',
        'path1/other-file',
        'path2/other-file',
        'another-file',
        'file1',
        'file2'
    ]

    class DummyTemplar:
        template = lambda x, y: y

    class DummySearchPath:
        path = [
            'path1',
            'path2',
        ]


# Generated at 2022-06-21 06:06:14.008564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Instantiate a LookupModule object and verify that it is properly initialized.
    """
    lookup = LookupModule()
    assert hasattr(lookup, 'run')
    assert lookup.get_option('files') is None
    assert lookup.get_option('paths') is None
    assert lookup.get_option('skip') is False
    assert lookup._subdir == 'files'

# Generated at 2022-06-21 06:06:25.420572
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:06:26.525237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.name == 'first_found'

# Generated at 2022-06-21 06:06:34.167788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert type(test) is LookupModule


# Generated at 2022-06-21 06:06:40.853923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = [
        {
            'files': ['foo.txt', 'bar.txt'],
            'paths': ['path'],
            'skip': False
        },
        {
            'files': ['baz.txt', 'qux.txt'],
            'paths': ['other/path'],
            'skip': False
        },
        'nonexistent.txt'
    ]

    variables = {
        'role_path': '/home/skvidal/playbooks/roles/foo'
    }

    test_object = LookupModule()
    test_object._subdir = 'files'

# Generated at 2022-06-21 06:06:48.436690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible import context
    from ansible.utils.vars import combine_vars

    # Create an instance of the LookupModule
    test_module = LookupModule()
    # Fake vars, just enough to pass without exception
    variables = combine_vars(context.CLIARGS['vars'], context.CLIARGS['extra_vars'])

    # Fake terms, using a list of strings
    test_terms1 = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    # Fake terms, using a dict
    test_terms2 = [{
        'files': '/path/to/foo.txt,bar.txt',
        'paths': '/path/to/biz.txt',
        'skip': False
    }]
    # Fake terms, using a

# Generated at 2022-06-21 06:06:48.903569
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:06:50.037974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:06:58.084061
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:06:59.723908
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup._subdir is None

    assert lookup._templar is None

    assert lookup._loader is None

# Generated at 2022-06-21 06:07:10.429998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with term as list of dictionaries
    params = [
        {'files': 'file_1', 'paths': 'path_1'},
        {'files': 'file_2', 'paths': 'path_2'},
    ]
    lookup = LookupModule()
    term_processed, _ = lookup._process_terms(terms=params, variables={}, kwargs={})
    assert term_processed == ['path_1/file_1', 'path_2/file_2']

    # Test with term as list of strings
    params = ['file_1', 'file_2']
    lookup = LookupModule()
    term_processed, _ = lookup._process_terms(terms=params, variables={}, kwargs={})
    assert term_processed == ['file_1', 'file_2']



# Generated at 2022-06-21 06:07:17.529876
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ####################
    # test with terms as list (deprecated)
    ####################
    # setup list of files to check
    terms = [
        "/etc/hosts",
        "hosts",
    ]

    # instantiate the module
    lookup = LookupModule()

    # confirm that that we can find the expected file
    assert lookup.run(terms, dict()) == ['/etc/hosts']

    # add a file that does not exist
    terms.append("does_not_exist")

    # confirm it still returns the first found file
    assert lookup.run(terms, dict()) == ['/etc/hosts']

    # confirm no file found causes error - remove file that does exist
    del terms[1]

    # try and run

# Generated at 2022-06-21 06:07:22.113265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('files') == []
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') == False



# Generated at 2022-06-21 06:07:38.464251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # In real use, this would use the lookup plugin's real constructor, but there's nothing to
    # test about the class's __init__ method so we just use a stub
    m = LookupModule([])
    assert isinstance(m, LookupModule)


# Generated at 2022-06-21 06:07:52.365615
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    # test passing a list to constructor
    lookup.run(['a_file.txt'], variables={}, **{})
    assert lookup.get_option('files') == ['a_file.txt']
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') is False

    # test passing a string to constructor
    lookup.run('a_file.txt', variables={}, **{})
    assert lookup.get_option('files') == ['a_file.txt']
    assert lookup.get_option('paths') == []
    assert lookup.get_option('skip') is False

    # test passing a map to constructor
    lookup.run([{'files': 'a_file.txt'}], variables={}, **{})

# Generated at 2022-06-21 06:08:03.195059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Test to ensure that list of files and paths are supported
    # Test to ensure that list of files and paths are supported
    # NOTE: can only do 'one' as a dict in all cases
    args = [
        [{
            'files': ['/path/file1'],
            'paths': ['/path/']
        }]
    ]
    result = lm.run(*args)
    assert result == ['/path/file1']

    args = [
        [{
            'files': ['/path/file1'],
            'paths': ['/path/']
        },
        [{
            'files': ['/path/file2'],
            'paths': ['/path/']
        }]]
    ]
    result = lm.run(*args)


# Generated at 2022-06-21 06:08:05.242314
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, **dict())

# Generated at 2022-06-21 06:08:07.636763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-21 06:08:18.826662
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: m_inst is not used initialization
    # m_inst = Mock(**{'get_path.side_effect': ['/tmp/ansible-hacking/', '/tmp/ansible-hacking/']})

    # NOTE: when the following is split in two lines, the second fails.
    # reason: the following code resets the execute function definitions,
    #         so the second will crash on the return unless it is mocked
    #         as well.
    instance = LookupModule()
    instance._executor = Mock()

    # NOTE: m_module is not used in the actual method.
    # m_module = Mock(**{'run.return_value': ['bar']})

    # NOTE: as per NOTE: above

# Generated at 2022-06-21 06:08:20.221442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()


# Generated at 2022-06-21 06:08:33.974395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run([], dict(), dict()) == [], 'No files specified, should return empty list'
    assert LookupModule(None, None).run([dict(files=[], paths=[])], dict(), dict()) == [], 'No paths specified, should return empty list'
    assert LookupModule(None, None).run([dict(files=['.'], paths=[])], dict(), dict()) == [], 'No paths specified, should return empty list'
    assert LookupModule(None, None).run([dict(files=[], paths=['.'])], dict(), dict()) == [], 'No files specified, should return empty list'
    assert LookupModule(None, None).run([dict(files=[''], paths=['.'])], dict(), dict()) == [], 'Invalid file specified, should return empty list'
    assert LookupModule

# Generated at 2022-06-21 06:08:34.489986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:08:36.358113
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:09:07.528241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test_LookupModule_run")
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager()

    terms = [None, None, None]

    assert LookupModule(loader, None).run(terms, vars_manager) == []

    # "normal" situation
    terms = [['good.txt', 'bad.txt', 'ugly.txt'], {'files': ['good.txt', 'bad.txt', 'ugly.txt'], 'paths': ['.']}, 'good.txt']

    assert LookupModule(loader, None).run(terms, vars_manager) == ['good.txt']

    # "normal" situation, but not the "guaranteed" file
   

# Generated at 2022-06-21 06:09:09.831116
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup

    lookup = LookupModule('foo')
    assert lookup

# Generated at 2022-06-21 06:09:18.444232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import pytest
    from ansible.module_utils.six import string_types

    with pytest.raises(AnsibleLookupError) as excinfo:
        LookupModule.run(None, None, None)

    assert 'AnsibleLookupError' in str(excinfo.value)

    with pytest.raises(AnsibleLookupError) as excinfo:
        LookupModule.run(None, None, {'paths': None})

    assert 'AnsibleLookupError' in str(excinfo.value)

    with pytest.raises(AnsibleLookupError) as excinfo:
        LookupModule.run(None, None, [1])

    assert 'AnsibleLookupError' in str(excinfo.value)


# Generated at 2022-06-21 06:09:29.841227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    test_terms = ['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt']
    test_files = []
    test_files.append(test_terms[0])
    test_files.append(test_terms[1])
    test_files.append(test_terms[2])
    test_paths = ['/tmp/production', '/tmp/staging']
    assert lookup_plugin._process_terms(test_terms) == (test_files, False)
    assert lookup_plugin._process_terms(test_terms, paths=test_paths) == (test_files, False)
    assert lookup_plugin._process_terms(test_terms, files=['filename1'], paths=test_paths) == (['filename1'], False)


# Generated at 2022-06-21 06:09:32.665684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run([],'') == []


# Generated at 2022-06-21 06:09:45.181927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    lookup = LookupModule()
    lookup._subdir = 'files'

    def find_file_in_search_path(variables, subdir, fn, ignore_missing=False):
        return lookup.find_file_in_search_path(variables, subdir, fn, ignore_missing=False)

    terms = "terms"
    variables="variables"
    find_file_in_search_path_expected_result = "expected_result"
    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: find_file_in_search_path_expected_result
    lookup._templar = FakeTemplar()
    lookup._process_terms = lambda: None
    lookup.find_file_in_search_path_first_call = True

# Generated at 2022-06-21 06:09:48.543406
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Test of constructor LookupModule')
    lookup_plugin = LookupModule()
    assert lookup_plugin._lookup_plugin != {}

# Generated at 2022-06-21 06:09:59.161758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixtures = os.path.join(os.path.dirname(__file__), 'fixtures', 'first_found')

    # execute run() module method

# Generated at 2022-06-21 06:10:03.238872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # assert that lookup_module is an instance of class LookupModule
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:10:10.812989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test run with terms containing strings
    terms = ['files/bar.txt', 'files/foo.txt']
    variables = {}
    kwargs = {}
    result = lookup.run(terms, variables, **kwargs)
    assert result == ['files/bar.txt'], 'Unexpected result returned by lookup.run using terms containing strings'
    # test run with terms containing dicts
    terms = [{'files': 'foo.txt', 'paths': ['files', 'vars']}, {'files': 'bar.txt', 'paths': ['templates']}]
    variables = {}
    kwargs = {}
    result = lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-21 06:10:44.647154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def assert_LookupModule_run(terms, paths, files, skip):
        lookupModule = LookupModule()
        variables = {}
        total_search, skip = lookupModule._process_terms(terms, variables, {'skip': skip, 'paths': paths, 'files': files})
        assert total_search
        assert skip

    # single string
    assert_LookupModule_run(terms='terms', paths=None, files=None, skip=False)

    # list of string
    assert_LookupModule_run(terms=['terms', 'terms2'], paths=None, files=None, skip=False)

    # single dictionary
    assert_LookupModule_run(terms=[{'skip': False, 'paths': None, 'files': 'files'}], paths=None, files=None, skip=False)

    #

# Generated at 2022-06-21 06:10:46.337378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule('first_found')

# Generated at 2022-06-21 06:10:53.954439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule
    """

    lookup = LookupModule()
    lookup.set_loader()
    lookup._templar = FakeTemplar()

    total_search, skip = lookup._process_terms(['test'], {}, {})

    assert total_search == ['test']
    assert skip == False

    total_search, skip = lookup._process_terms([{'files': 'test1'}], {}, {})
    assert total_search == ['test1']

    total_search, skip = lookup._process_terms([{'files': 'test2', 'skip': True}], {}, {})
    assert total_search == ['test2']
    assert skip == True


# Generated at 2022-06-21 06:10:56.006727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(['foo', 'bar'], {})

# Generated at 2022-06-21 06:10:58.871831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    # TODO: add 'test_obj.run()' unit test

# Generated at 2022-06-21 06:11:12.216017
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # TODO: testing need this, but it is not correct
    lookup._subdir = 'files'

    # NOTE: during refactor noticed that the 'using a dict' as term
    # is designed to only work with 'one' otherwise inconsistencies will appear.
    # see other notes below.

    # NOTE: have to do this trick as the lookup plugin is called with 'terms' not 'params'
    params = {
        'files': 'default.conf',
        'paths': '/some/path',
        'skip': False
    }
    terms = [params]

    search = [
        os.path.join('/some/path', 'default.conf')
    ]

    total_search, skip = lookup._process_terms(terms, {}, {})

    assert total_search == search
    assert skip

# Generated at 2022-06-21 06:11:24.269368
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar

    templar = Templar(loader=None)


# Generated at 2022-06-21 06:11:35.110132
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: the todo's below are not fixed and should not be fixed, the reason is that there can be only
    # a single element in total_search, which is a list, the dict will clobber the previous values
    # and this is probably not a bad thing, if the result is not consistent then this is a signal to the user
    # to fix their code.

    # TODO: should not be global_paths, that is set in __init__
    global_paths = ["/path/to/files/", "/path/to/files/"]

# Generated at 2022-06-21 06:11:35.815801
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None, None)

# Generated at 2022-06-21 06:11:42.942069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar:
        def __init__(self):
            self.template_data = None
        def template(self, data):
            self.template_data = data
            return data

    class MockVars:
        def __init__(self):
            self.vars = dict()
        def get(self, key):
            return self.vars.get(key, None)

    class MockLoader:
        def __init__(self):
            self.path_segments = []
        def get_basedir(self, task):
            return self.path_segments
        def path_dwim(self, task, filename):
            return filename

    mock_templar = MockTemplar()
    mock_vars = MockVars()
    mock_loader = MockLoader()
    # constructor test


# Generated at 2022-06-21 06:12:10.023381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-21 06:12:14.311810
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Mock_Templar:

        def template(self, fn):
            return fn

    lm = LookupModule()
    lm._templar = Mock_Templar()
    lm.run(terms=['foo.yml'],
           variables={},
           files=None,
           paths=None,
           skip=True
    )
    # TODO: add correct test
    assert True

# Generated at 2022-06-21 06:12:15.927323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:12:23.683553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  assert isinstance(lookup_module, LookupBase)
  assert isinstance(lookup_module, LookupModule)

  # Test normal param lookup
  test_terms = ['first_file.txt', 'second_file.txt']
  result = lookup_module.run(test_terms, variables=None, **{})
  assert result == ['first_file.txt']

  # Test normal param lookup with skip set to True
  # This will return an empty-list as no files were found in the search
  test_terms = ['first_file.txt', 'second_file.txt']
  result = lookup_module.run(test_terms, variables=None, skip=True, **{})
  assert result == []

  # In reality, there will be more testing, but this shows how to set params

# Generated at 2022-06-21 06:12:35.977061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.utils.display import Display
    display = Display()

    # Set up a bunch of files for the test cases
    test_files = [
        "a.txt",
        "b.txt",
        "c.txt",
        "d.txt",
        "e.txt",
        "f.txt",
        "g.txt",
        "h.txt",
        "i.txt",
        ]

    # Create the test files
    for fn in test_files:
        f = open(fn, "w")
        f.write(fn)
        f.flush()
        f.close()

    # We need to create a mock templar class
    class MockTemplar(object):

        def __init__(self):
            pass

       

# Generated at 2022-06-21 06:12:47.576932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils.six import PY3

    # Get temp directory
    tempdir = mkdtemp()

    # Create fake file
    if PY3:
        tempfile_content = bytes("fake content", encoding="utf-8")
    else:
        tempfile_content = "fake content"
    tempfile = os.path.join(tempdir, "fake1.txt")
    with open(tempfile, "wb") as f:
        f.write(tempfile_content)

    # Run without skip
    result = LookupModule().run([tempfile], None, skip=False)
    assert len(result) == 1
    assert result[0] == tempfile

    # Run with skip

# Generated at 2022-06-21 06:12:56.022210
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test double spliting for comma, semicolon and also for space.
    # In python3 comma and semicolon are not splited by 'split'.
    lookup_value = LookupModule()._split_on("one,two;three,four", ',;')
    assert 'one' in lookup_value
    assert 'two' in lookup_value
    assert 'three' in lookup_value
    assert 'four' in lookup_value

    # Test that there are no other elements in the returned list.
    assert len(lookup_value) == 4

# Generated at 2022-06-21 06:13:06.184668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager())
    lookup_mock = LookupModule()
    lookup_mock.set_loader(loader)
    lookup_mock.set_templar(templar)
    lookup_mock._subdir = 'files'

    def find_file_in_search_path_mock(variables, subdir, fn, ignore_missing=True):
        if fn == 'file1':
            return fn
        return 'file2'

    lookup_mock.find_file_in_search_path = find_file_in_search_path_mock


# Generated at 2022-06-21 06:13:15.969868
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.template import Templar


# Generated at 2022-06-21 06:13:24.590473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {
        'a': '1',
        'b': [
            ['c', 'd', 'e'],
            {
                'f': '2',
                'g': '3'
            },
            'h',
            'i'
        ]}
    lookup_plugin = LookupModule()
    lookup_plugin._process_terms(data['b'], data, data)

    assert lookup_plugin.get_option('files') == ['c', 'd', 'e', 'h', 'i']
    assert lookup_plugin.get_option('paths') == ['2', '3']