

# Generated at 2022-06-21 06:04:05.346014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader

    loader = DataLoader()
    variables = {}

    # for merging dict
    from ansible.utils.dictdiffer import DictDiffer

    lookup = LookupModule(loader=loader, templar=None, variables=variables)

    #
    # assert that _process_terms() works
    #
    # no files in list and no dict
    assert lookup._process_terms(terms=['foo',], variables=variables, kwargs={}) == ([], False)
    # files in list and no dict
    assert lookup._process_terms(terms=['foo', 'bar',], variables=variables, kwargs={}) == (['foo', 'bar',], False)
   

# Generated at 2022-06-21 06:04:18.242204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self, _loader, _basedir, _templar, loader=None, templar=None, **kwargs):
            self._loader = _loader
            self._basedir = _basedir
            self._templar = _templar
            self.loader = loader
            self.templar = templar

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=False):
            if fn == 'foo':
                return '/tmp/foo'
            if fn == '{{ ansible_distribution }}.yml':
                return 'bar'
            return None

    search_paths = [
        '/tmp/bar',
        '/tmp/baz'
    ]
    templar = Dict

# Generated at 2022-06-21 06:04:29.626556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # freezegun does not support utc from 3.0.0, this workaround is from https://bitbucket.org/pandas-dev/pandas/issues/10417
    import sys
    if 'freezegun==0.3.8' in sys.modules:
        import freezegun
        freezegun.stop_freezing_time()
        freezegun.freeze_time('2019-01-01')
        freezegun.freeze_time.stop_all_freezing()
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    from ansible.plugins.lookup import LookupModule

    templar = Templar(loader=DataLoader())
   

# Generated at 2022-06-21 06:04:38.113844
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    config = {
        'base_executor': "task_executor.py",
        'base_vars': "vars_cache/vars_cache.yml",
        'lookup_plugin_run_as_root': False,
        'lookup_plugin_scratch_dir': "/tmp/ansible-lookup-plugin-cache",
        'lookup_plugin_tries': 30
    }

    config_data = """
    lookup_plugin_tries: 30
    lookup_plugin_scratch_dir: "/tmp/ansible-lookup-plugin-cache"
    lookup_plugin_run_as_root: False
    """

    class MockTemplar(object):
        def template(self, template):
            return template


# Generated at 2022-06-21 06:04:48.444091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    lookup = LookupModule()

    def __getitem__(self, name):
        return self.__dict__[name]

    lookup.__dict__.__getitem__ = __getitem__
    lookup.__dict__.__setitem__ = lambda self, name, value: setattr(self, name, value)
    lookup.__dict__.get = lambda self, name, defval: self.__dict__.get(name, defval)

    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: 'test'
    lookup._templar = {}


# Generated at 2022-06-21 06:05:01.775092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()

    # NOTE: this is broken and relies on kwargs to be passed in by the
    # 'template' lookup, which it is not.
    # TODO: fix this so that the 'params' is used or not by the lookup
    # and it is not a mix of lists and dicts
    # this also implies that 'files' and 'paths' will only work for 'last'
    # item in the list of terms - and that is WRONG!
    terms = [
        {'files': 'foo', 'paths': 'baz:bar'},
        'hello',
        {'files': 'bar', 'paths': 'foo'},
        'world'
    ]

    # NOTE: this should *not* be used to pass params to the items in C(terms),
    # it is to pass params

# Generated at 2022-06-21 06:05:03.836773
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class_lookupmodule = LookupModule()
    assert class_lookupmodule is not None

# Generated at 2022-06-21 06:05:08.518263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([{'files': ['foo_bar'], 'paths': ['path/to']}, 'foo.txt'], {}) == None
    assert module.run(['foo.txt'], {}) == None
    assert module.run(['bar_baz_qux.yml'], {}) == None


# Generated at 2022-06-21 06:05:20.158171
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def assertEqual(result, expected):
        errmsg = "Expected %s, Got %s" % (expected, result)
        assert result == expected, errmsg

    # NOTE: tests are per method/class but other classes are used in method run
    # so trying to keep things simple this test relies on things working as expected.

    # NOTE: tests are per method/class but other classes are used in method run
    # so trying to keep things simple this test relies on things working as expected.

    # NOTE: tests are per method/class but other classes are used in method run
    # so trying to keep things simple this test relies on things working as expected.

    # TODO: basic tests for split_on
    # not as simple as it appears as split_on is used in _process_terms

    # TODO: basic tests for process_terms
    # not

# Generated at 2022-06-21 06:05:28.051414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugins = [
    {
        '_terms': ['path/file.yml'],
        '_subdir': 'files',
        '_file': 'file.yml',
        '_file_search': ['/path/file.yml']
    },
    {
        '_terms': ['file.yml', {'files': 'foo.yml', 'paths': ['sub/path']}],
        '_subdir': 'files',
        '_file': 'file.yml',
        '_file_search': ['/sub/path/foo.yml', '/file.yml']
    }
    ]
    for _args, _kwargs in lookup_plugins:
        lookup = LookupModule(_terms=_args, _templar=None, _loader=None)

# Generated at 2022-06-21 06:05:33.135983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:05:38.913705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize instance with parameters
    lookup_module = LookupModule()

    # set parameters for test
    terms = ['{{ my_file }}']
    variables = {
        'my_file': 'test.txt'
    }

    # run test
    result = lookup_module.run(terms, variables)

    # compare result
    assert result == ['test.txt']



# Generated at 2022-06-21 06:05:51.928787
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:06:05.005437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with a dict term
    files = ['foo', 'bar']
    paths = ['path/to/foo', 'path/to/bar']
    terms = {}
    terms['files'] = files
    terms['paths'] = paths

    # Test with a string term
    term = 'files/foo'

    # Test with a list term
    listterm = 'path/to/foo'


# Generated at 2022-06-21 06:06:14.005972
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Subdir is a required param for class constructor, default to files
    subdir = 'files'
    lookup = LookupModule(subdir=subdir)

    #########################################
    # Case 1: Single term supplied
    #########################################

    # terms: is a list of terms, typically passed in from the lookup,
    # e.g., when the template calls 'lookup('first_found', 'bar.conf')'.
    # A term can be a string or a dictionary. In this test case, a term is a string.
    terms = ['bar.conf']

    # variables: used to set the value of a lookup plugin's 'direct' option.
    # Direct option: https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html#passing-variables-on-the-command-line
   

# Generated at 2022-06-21 06:06:22.260375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check if a list of files are searched in given paths,
    # and the first file found is returned
    # create a lookup class object
    lookupclass_obj = LookupModule()
    # create a dummy class for templar
    templarclass_obj = DummyTemplar()
    # set the templar object to lookup class
    lookupclass_obj._templar = templarclass_obj
    # set the files, paths and skip to kwargs dict
    kwargs = dict()
    kwargs['files'] = ['30.txt','40.txt','50.txt']
    kwargs['paths'] = ['/tmp/some_dir']
    kwargs['skip'] = False
    # create variable dictionary
    variables = dict()
    variables['aaa'] = "hello"
    # create terms object

# Generated at 2022-06-21 06:06:25.387949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest


    # TODO: Write Unit tests for method run of class LookupModule

# Generated at 2022-06-21 06:06:35.947325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = DummyTemplar()
    lookup = LookupModule(loader=None, templar=templar, variables=None)
    terms = [
        {
            'files': [
                'foo.cfg',
                'bar.cfg'
            ],
            'path': [
                'tests/unit/modules/test_lookup/files/foo'
            ]
        },
        {
            'files': [
                'foo.cfg',
                'bar.cfg'
            ],
            'path': [
                'tests/unit/modules/test_lookup/files/bar'
            ]
        }
    ]

    expected = ['/tmp/ansible_test/tests/unit/modules/test_lookup/files/foo/foo.cfg']

# Generated at 2022-06-21 06:06:47.356879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    conn = MockConnection()
    conn._find = {
        '/dir1/dir2/dir3/file1': False,
        '/dir1/dir2/dir3/file2': True
    }

    # event_data['file'] is not used any where in this test
    event_data = {}
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})
    lookup = LookupModule()
    lookup._templar = templar
    lookup._connection = conn

    # assert the exit code
    assert lookup.run(['./file1', './file2'], event_data) == ['/dir1/dir2/dir3/file2']

# Generated at 2022-06-21 06:06:49.743009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-21 06:07:09.160847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()

    from ansible.templating import Templar
    templar = Templar(loader=None, variables={})

    test_module.set_loader(templar._loader)
    test_module._templar = templar

    test_module.set_options(var_options={'role_path': '/some/path'})

    import sys
    import locale
    locale.setlocale(locale.LC_ALL, 'C')

    # test strings
    assert test_module.run(['/some/path/file1.txt'], variables={}) == ['/some/path/file1.txt']

    # test no paths
    test_module.set_options(direct={'paths': []})
    assert test_module.run(['file1.txt'], variables={})

# Generated at 2022-06-21 06:07:17.486071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule([{'files': ['f1', 'f2'], 'paths': ['p1', 'p2']}], {}, loader=None, templar=None)
    assert LookupModule(['f1', 'f2'], {}, loader=None, templar=None)
    assert LookupModule('f1,f2', {}, loader=None, templar=None)

# Generated at 2022-06-21 06:07:22.935383
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # NOTE: run method already fails if a mapping is not the last item
    # any use of a mapping will clobber all previous items, this was unchanged
    # and is an inherent limitation on how 'run' uses the terms
    terms = [
        "file.txt",
        {"files": "file.txt", "paths": "/foo"},
        {"files": "file.txt", "paths": "/foo"},
        "file.txt",
        {'files': ['foo', 'bar'], 'paths': ['/tmp/production', '/tmp/staging']},
    ]
    variables = {'foo': 'bar'}
    kwargs = {'skip': True}

    total_search, skip = lookup_module._process_terms(terms, variables, kwargs)
    assert skip

# Generated at 2022-06-21 06:07:30.850247
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test _process_terms

    # test _split_on
    # TODO: test_LookupModule_split_on

    # TODO: test file not found (with/without skip)
    # TODO: test template lookup (with/without skip)
    # TODO: test variable lookup (with/without skip)

    # TODO: test files and paths (with/without template/variable)

    # TODO test ansible_hosts_file (with/without skip)

    print("TODO")

# Generated at 2022-06-21 06:07:33.262906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:07:34.712322
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:07:43.060939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mocks for this test
    #  The plugin is already mocked, we override here with the real one
    #  since we need it to create the mock classes with the real class
    #  (it will be automatically mocked by the plugin mock).
    #  The plugin is mocked by pytest.
    from ansible.plugins.loader import lookup_loader
    lookup_loader.get("first_found").lookup_class = LookupModule

    import pytest
    from ansible.module_utils.six import string_types
    lookup = lookup_loader.get("first_found")
    assert isinstance(lookup, LookupModule)

    # make it a class so we can override the run method (the real one is mocked)

# Generated at 2022-06-21 06:07:52.623807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test for method run of class LookupModule"""
    LookupBase._loader = None
    LookupBase._templar = "templar"
    LookupBase.find_file_in_search_path = lambda self, variables, subdir, filename, ignore_missing: "I will look for first file here"
    lookup_module = LookupModule()
    terms = ["foo_file.conf", {"files": "default_file.conf", "paths": "path_to_file/"}]
    lookup_module.run(terms, "variable")

# Generated at 2022-06-21 06:08:00.712480
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Test that it handles dicts as its argument
    LookupModule({})
    #Test that it handles lists as its argument
    LookupModule([])
    #Test that it handles strings as its argument
    LookupModule("")
    #Test that it raises an error when given regular types (int is just an example)
    try:
        LookupModule(1)
    except TypeError:
        pass
    #Test that it raises an error when given something like a class
    try:
        class test:
            pass
        LookupModule(test)
    except TypeError:
        pass

# Generated at 2022-06-21 06:08:12.260480
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ####
    ####
    ####  Setup test
    ####
    ####

    # define variables
    terms = None
    variables = dict(
        ansible_virtualization_type = "",
        ansible_os_family = "",
    )
    kwargs = dict(
        skip = False,
    )

    # define expected return values
    expected_result_zero = dict(
        result = [],
    )
    expected_result_one = dict(
        result = ["default_foo.conf"],
    )
    expected_result_two = dict(
        result = ["test_foo.conf"],
    )
    expected_result_three = dict(
        result = ["test_foo.conf"],
    )


    ####
    ####
    ####  Test with no file found


# Generated at 2022-06-21 06:08:19.068269
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:08:19.947716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:08:27.490866
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This test is suppose to all for mocking of the 'run' function,
    # however the LookupModule does alot and does not lend itself to
    # a good unit test (many dependencies). So a mock is not really
    # possible.
    #
    # This function can be used to test run and it's helper functions
    # as they are changed.
    #
    # NOTE: only change 'run' and it's helper functions when they fail
    # this test.

    # NOTE: this is not a Mocking test, it is a 'basic' test.
    # The 'run' function calls self.find_file_in_search_path(variables, subdir, fn, ignore_missing=True)
    # for now this function is 'patched'

    import collections
    import types

    # setup patch conditions

# Generated at 2022-06-21 06:08:35.384257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    lookup = LookupModule()
    lookup.basedir = os.path.join(os.path.dirname(__file__), '../../../')
    lookup.current_vars = dict(
        entity_name='entity_name_1',
        country_code='US',
        locale='en',
        supported_locales='de,en,es,it',
    )
    lookup.set_options(dict(
        files=['foo']
    ))
    lookup.run(['{{ entity_name }}.txt'], lookup.current_vars)

# Generated at 2022-06-21 06:08:44.660616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simulate a context
    class Context:
        def __init__(self):
            self.vars = {'a_var': 'var_value'}
    context = Context()

    # Simulate a templar
    class Templar:
        def __init__(self):
            self.vars = {'a_var': 'var_value'}
        def template(self, data):
            return data
    templar = Templar()

    # Simulate an inventory
    class Inventory:
        pass
    inventory = Inventory()
    # Simulate a variable manager
    class VariableManager:
        def __init__(self):
            self.inventory = inventory
            self.extra_vars = {}
            self.options = {'forks': 10, 'tags': ["a_tag"]}
    variable_manager = VariableManager

# Generated at 2022-06-21 06:08:52.385766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # in order to test run we need to make a class that 'looks like' a LookupModule
    class testLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            self._subdir = 'files'

    test_lookup = testLookupModule()

    # test for case where no files are provided
    actual_results = test_lookup.run([], {})
    expected_results = []

    # check that the expected and actual results are equal
    assert actual_results == expected_results, "Test: /path/to/foo.txt - Expected: {0}  Actual: {1}".format(expected_results, actual_results)

    # test for case where no files are found

# Generated at 2022-06-21 06:08:55.826967
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # this should be able to create an instance of the LookupModule class
    assert LookupModule()


# Generated at 2022-06-21 06:08:58.761639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_in_files = LookupModule()
    assert(lookup_in_files is not None)

# Generated at 2022-06-21 06:09:07.286388
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables=HostVars(loader=None, variables=dict()))
    module._templar = templar

    assert module.run(terms=['test/test.txt'], variables=dict()) == ['test/test.txt']

    # file not found
    try:
        module.run(terms=['test/missing.txt'], variables=dict())
        assert False, "This test should have failed"
    except AnsibleLookupError as e:
        assert "not found" in str(e)

    # files with invalid formats

# Generated at 2022-06-21 06:09:17.405999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = lambda x: x
    lookup.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing: None if fn == 'skip' else fn

    # 1, test base case
    result = lookup.run(['skip'])
    assert result == []

    # 2, test path with only file list
    result = lookup.run(['not-skip-0'])
    assert result == ['not-skip-0']

    # 3, test path with only file list and multiple file names
    result = lookup.run(['not-skip-1', 'not-skip-2'])
    assert result == ['not-skip-1']

    # 4, test path with only file list and multiple file names

# Generated at 2022-06-21 06:09:38.901887
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    from ansible.errors import AnsibleLookupError

    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None

    # with single term
    assert lookup.run(['files/foo.txt'], {}) == [os.path.join(os.path.dirname(__file__), 'files', 'foo.txt')]
    assert lookup.run(['files/foo.txt'], {}, skip=True) == [os.path.join(os.path.dirname(__file__), 'files', 'foo.txt')]

    # with single term inside dict

# Generated at 2022-06-21 06:09:42.273756
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: needs unit tests for lookup plugin's return value for skip==True or errors==True
    pass

# Generated at 2022-06-21 06:09:49.558538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_dict = {}
    global_dict['ansible_virtualization_type'] = "KVM"
    global_dict['ansible_os_family'] = "RedHat"
    global_dict['ansible_distribution'] = "Fedora"
    global_dict['inventory_hostname'] = "localhost"
    global_dict['hostvars'] = {'localhost': {'ansible_virtualization_type': "KVM", 'ansible_os_family': "RedHat",
                                              'ansible_distribution': "Fedora"}}
    lookup = LookupModule()
    lookup.get_search_paths = lambda: ("lookup_plugins",)
    lookup.get_basedir = lambda: ('.')
    lookup.set_loader = lambda x : None
    lookup.set_environment = lambda : None
   

# Generated at 2022-06-21 06:09:59.555519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader

    base_query_string = """
        {
            "terms":
            [
                %s
            ],
            "variables": %s
        }
    """

# Generated at 2022-06-21 06:10:06.866759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule.run({}, {}, _terms=[]) is None)
    assert(LookupModule.run({}, {}, _terms=['abc']) is None)
    assert(LookupModule.run({}, {}, _terms=['abc']) is None)
    assert(LookupModule.run({}, {}, _terms=['abc', 'bcd']) is None)
    assert(LookupModule.run({}, {}, files=['abc'], paths=['bcd','cde']) is None)
    assert(LookupModule.run({}, {}, files=['abc']) is None)
    assert(LookupModule.run({}, {}, _terms=['abc', 'bcd'], skip=True) is None)



# Generated at 2022-06-21 06:10:16.686738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        {
            'files': 'testfile',
            'paths': 'testpath'
        },
        {
            'files': 'testfile2',
            'paths': 'testpath2'
        }
    ]
    lm = LookupModule()
    lm._process_terms(terms, None, None)

    assert lm._options['files'] == [u'testfile2']
    assert lm._options['paths'] == [u'testpath2']

# Generated at 2022-06-21 06:10:29.683428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    # Instantiate test object
    module = LookupModule()

    import os.path
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    # set the testing current working directory to the test directory
    # os.path.dirname(__file__) is the location of this source file
    # os.path.abspath(os.path.dirname(__file__)) gives the full path of the test directory
    # os.chdir(os.path.abspath(os.path.dirname(__file__))) sets the current working directory to test directory
    os.chdir(os.path.abspath(os.path.dirname(__file__)))

    # Test

# Generated at 2022-06-21 06:10:36.882644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["foo.txt"]
    variables = {}
    kwargs = {"files": ["foo.txt"], "paths": [], "skip": True}
    (ret_val, expecting) = (lookup.run(terms, variables, **kwargs), [])
    assert ret_val == expecting

test_LookupModule_run()

# Generated at 2022-06-21 06:10:50.737228
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:10:52.699399
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init and call run
    lb = LookupModule()
    ret = lb.run(['a', 'b'])

    # check and return
    assert ret == []
    return ret

# Generated at 2022-06-21 06:11:13.574028
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:11:22.765669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._subdir = 'files'
    terms = [
        {'files': 'user.yaml'},
        'public.yaml',
        {'files': 'private.yaml', 'paths': '/etc/foo,/etc/bar'},
        ['host.yaml', 'group.yaml']
    ]
    variables = {}
    r = l.run(terms=terms, variables=variables)
    assert len(r) == 1
    assert r[0] == 'user.yaml'  # first file found


# Generated at 2022-06-21 06:11:25.370032
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:11:26.156023
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule


# Generated at 2022-06-21 06:11:35.870626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert isinstance(LookupModule.run(None, '', []), list)
    assert LookupModule.run(None, '', []) == []
    assert isinstance(LookupModule.run(None, '', [{}, {}]), list)
    assert LookupModule.run(None, '', [{}, {}]) == []
    assert isinstance(LookupModule.run(None, '', ['wget_python_async']), list)
    assert LookupModule.run(None, '', ['wget_python_async']) == [AnsibleUnsafeText('/usr/bin/wget')]

# Generated at 2022-06-21 06:11:42.983573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    signals = LookupModule()

    files = [os.path.abspath(os.path.dirname(__file__) + '/../lookup_plugins/domains.yml'),
             os.path.abspath(os.path.dirname(__file__) + '/../lookup_plugins/files/file1.txt')]

    # One file found in paths
    assert signals.run(files, None, paths=['/home/hakase']) == [os.path.abspath(os.path.dirname(__file__) + '/../lookup_plugins/files/file1.txt')]

    # One file found in path

# Generated at 2022-06-21 06:11:55.786436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._templar == None
    assert lookup_module._loader == None
    assert lookup_module._basedir == None
    assert lookup_module._display.verbosity == 0
    assert lookup_module._options == None
    # assert lookup_module._searchpath == None
    # assert lookup_module._fail_on_undefined_errors == True
    assert lookup_module._fail_on_undefined_errors == False  # FIXME: to be checked
    assert lookup_module._templated_values == None
    assert lookup_module._templated_fields == None
    assert lookup_module._lookup_plugin_cache == None
    assert lookup_module._fact_cache == None
    assert lookup_module._data_cache == None
    assert lookup_module._search_cache == None

# Generated at 2022-06-21 06:12:00.773193
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # noinspection PyProtectedMember
    lookup = LookupModule()
    assert lookup is not None
    assert lookup.get_options is not None
    assert lookup.set_options is not None
    assert lookup.run is not None

# Generated at 2022-06-21 06:12:04.273624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:12:06.706935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:12:52.327420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([], dict()) == []
    assert LookupModule().run([], dict(), skip=True) == []
    assert LookupModule().run([], dict(), skip=False) == []

# Generated at 2022-06-21 06:13:00.303349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a test file
    fd, test_file = tempfile.mkstemp()
    os.close(fd)

    # Create a test path
    test_path = tempfile.mkdtemp()

    # Create a test term
    term = [
        { 'files': 'test_file', 'paths': test_path }
    ]

    # Call the method run of the object lookup_module
    # with a test term for argument
    result = lookup_module.run(term, dict())

    # Remove the test file
    os.remove(test_file)

    # Remove the test path
    shutil.rmtree(test_path)

    # Assert the result
    assert(result == [test_file])

# Generated at 2022-06-21 06:13:12.693914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: This has not been completed
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module._options = None

    # first test - no file
    terms = [
        {
            "_terms": "file1",
            "paths": "/some/path,/another/path"
        },
        {
            "_terms": "file2",
            "paths": "/some/path,/another/path"
        }
    ]

    result = lookup_module.run(terms=terms, variables={}, skip=False)
    #assert result[0] == "file1"
    #assert result[1] == "file2"
    #assert len(result) == 2
    #assert len(result[0].splitlines()) == 3

# Generated at 2022-06-21 06:13:24.872670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.get_option = lambda option: None
    lm.find_file_in_search_path = lambda _, __, fn, ___: None
    result = lm.run(terms=['/path/to/file1.txt', '/path/to/file2.txt'], variables=dict(), skip=False)
    assert result is not None
    assert isinstance(result, list)
    assert len(result) == 0
    result = lm.run(terms=['/path/to/file1.txt', '/path/to/file2.txt'], variables=dict(), skip=True)
    assert result is not None
    assert isinstance(result, list)
    assert len(result) == 0

# Generated at 2022-06-21 06:13:26.906146
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()
  assert lookup_module is not None

# Generated at 2022-06-21 06:13:34.549397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _find_file_in_search_path_patch(variables, subdir, fn, ignore_missing=True):
        if fn == "search_path_file1":
            return fn
        return None

    lookupmodule = LookupModule()

    lookupmodule.set_loader({
        '_loader': 'AnsibleLoader',
        '_basedir': 'AnsibleLoader',
        'get_basedir': lambda: 'get_basedir',
    })

    lookupmodule._templar = "Templar"
    lookupmodule.find_file_in_search_path = _find_file_in_search_path_patch

    # test init
    assert lookupmodule._subdir is None

    # test basic search

# Generated at 2022-06-21 06:13:47.939117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class FakeTemplar(object):
        def template(self, fn):
            return fn
    class FakeTaskExecutor(object):
        def get_loader(self):
            return FakeTemplar()
        def get_basedir(self):
            return '.'
    class FakeVarManager(object):
        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=False):
            return {'foo': 'bar'}
    class FakePluginLoader(object):
        def __init__(self, basedir):
            self._templar = FakeTemplar()
        def get_basedir(self, path):
            return '.'
    class FakeLoader(object):
        def __init__(self):
            self._loader = FakeLoader()
            self._

# Generated at 2022-06-21 06:13:57.467802
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: test more cases, this is just a simple test
    # based on the example in the docstring

    lookup_module = LookupModule()

    files = ['foo', 'bar', 'biz']
    paths = '/tmp/production,/tmp/staging'

    ret = lookup_module.run(
        terms=['/path/to/foo.txt', 'bar.txt', '/path/to/biz.txt'],
        variables=dict(files=files, paths=paths),
        skip=True,
    )
    assert ret == '/path/to/foo.txt'
