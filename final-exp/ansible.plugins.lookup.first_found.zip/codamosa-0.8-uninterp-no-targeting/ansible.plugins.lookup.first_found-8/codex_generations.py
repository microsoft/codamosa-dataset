

# Generated at 2022-06-21 06:03:59.351046
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test with short hand path list
    LookupModule(['a', 'b', 'c'])

    # test with long hand path list
    LookupModule([{'files': ['a', 'b', 'c'], 'paths': ['x', 'y', 'z']}])

# Generated at 2022-06-21 06:04:08.676320
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock modules
    import ansible.plugins.lookup.first_found
    ansible.plugins.lookup.first_found.AnsibleLookupError = MockAnsibleLookupError
    ansible.plugins.lookup.first_found.LookupBase = MockLookupBase
    ansible.plugins.lookup.first_found.os = MockOs
    ansible.plugins.lookup.first_found._split_on = MockSplitOn

    # test parameters

# Generated at 2022-06-21 06:04:12.391281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._subdir = 'files'
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:04:17.365838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    temp_lookup = LookupModule()
    terms = ['/path/to/file']
    variables = {}

    # Act
    result = temp_lookup.run(terms, variables)

    # Assert
    assert result == ['/path/to/file']

# Generated at 2022-06-21 06:04:29.328665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils import context_objects as co
    from ansible.template import Templar

    lookup_module = LookupModule()
    lookup_module.set_loader(co.get_loader())

    list_of_dicts = [{'files': 'a/b/a.txt', 'paths': 'c/d/'}]
    dict_of_values = {'files': 'a/b/a.txt', 'paths': 'c/d/'}

    # Test with list of dicts
    try:
        result = lookup_module.run(list_of_dicts, co.get_vars(),
                                   templar=Templar(co.get_loader()))
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)

# Generated at 2022-06-21 06:04:31.623081
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:04:33.989378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        raise AssertionError("Constructor for LookupModule class throws exception {}".format(e))


# Generated at 2022-06-21 06:04:42.538122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-21 06:04:47.065495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule(loader=None, templar=None, **{})
    #assert module._subdir == 'files'
    assert not hasattr(module, '_subdir')
    module = LookupModule(loader=None, templar=None, **{'_subdir': 'test_subdir'})
    assert module._subdir == 'test_subdir'


# Generated at 2022-06-21 06:04:49.412485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-21 06:04:55.191583
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 06:04:56.920792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, '__init__')



# Generated at 2022-06-21 06:05:07.375614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_base = LookupBase()

    # create a fake file 'files/foo.conf' in system temp directory
    tmp_dir = lookup_base._get_tmp_dir()
    with open(os.path.join(tmp_dir, 'files/foo.conf'), 'w+') as f:
        f.write('/tmp/foo.conf')

    # prepare test list

# Generated at 2022-06-21 06:05:17.768336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test the LookupModule_run method """

    class Options(object):
        def __init__(self, var_options=None, direct=None):
            self.no_log = True
            self.no_log_values = ['password']
            self.var_options = var_options
            self.direct = direct

    class Templar(object):
        def __init__(self, variables):
            self.variables = variables

        def template(self, template):
            if template[0] == '$' and template[1] == '{':
                return self.variables[template[2:-1]]
            else:
                return template

    class VariableManager(object):
        def __init__(self, variables):
            self.variables = variables


# Generated at 2022-06-21 06:05:31.396960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    # import yaml
    # import pprint

    # create LookupModule object
    obj = LookupModule()

    # # get the templar object from lookup object
    # templar = obj._templar

    # # create varaible for unit test, using yaml and ansible-playbook private
    # # option
    # var_content = "---\n" \
    #               "string_var: 'string var'\n" \
    #               "list_var:\n" \
    #               "  - list_var1_item1\n" \
    #               "  - list_var1_item2\n" \
    #               "list_var2:\n" \
    #

# Generated at 2022-06-21 06:05:35.717208
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  print("check test_LookupModule")
  print(lookup.run(terms=["/"], variables={}, **{}))

test_LookupModule()

# Generated at 2022-06-21 06:05:44.162276
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        {'paths':'/tmp', 'files':'foo.txt,biz.txt'},
        'bar',
        ['baz', {'paths':'/tmp', 'files':'buzz.txt'}],
        {'paths':'/tmp', 'files':'foo.txt,biz.txt', 'skip': True}
    ]

    lm = LookupModule()
    results = lm.run(terms, {}, errors='ignore')
    assert results == []

# Generated at 2022-06-21 06:05:53.320045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    my_lookup.find_file_in_search_path = lambda x, y, z, **k: None

    # Below is a list of tests to be (function, args, expected result)

# Generated at 2022-06-21 06:05:57.195743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:06:02.985619
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    file_data = {
        'files': 'python_test1.yml,python_test2.yml',
        'paths': './test_data/'
    }

    found_files = lookup_loader.get('first_found').run(terms=[file_data], variables=None)
    assert found_files[0] == './test_data/python_test1.yml'

# Generated at 2022-06-21 06:06:12.235227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test case for constructor of class LookupModule
    """
    test_obj = LookupModule()
    assert test_obj.__class__ == LookupModule


# Generated at 2022-06-21 06:06:16.901391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Check for class to be of type AnsiblePlugin
    assert isinstance(lookup, LookupBase), "lookup is not of type AnsiblePlugin"

# Generated at 2022-06-21 06:06:28.408720
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test valid results
    files = os.path.join(os.path.dirname(__file__), 'files')
    result1 = LookupModule().run(['test1.txt', 'test2.txt'])
    assert result1 == [os.path.join(files, 'test1.txt')]
    result2 = LookupModule().run(['test2.txt', 'test1.txt'])
    assert result2 == [os.path.join(files, 'test2.txt')]
    result3 = LookupModule().run(['test2.txt', 'test1.txt'], {}, paths=[files])
    assert result3 == [os.path.join(files, 'test2.txt')]

# Generated at 2022-06-21 06:06:30.420870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms=None, variables=None)

# Generated at 2022-06-21 06:06:37.350635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create object LookupModule
    lookup_obj=LookupModule()

    # mock class variable _subdir
    lookup_obj._subdir='subdir'

    # mock variable return by find_file_in_search_path
    lookup_obj.find_file_in_search_path=lambda variables,subdir,fn,ignore_missing: 'path'

    # mock method template
    lookup_obj._templar=type('MockTemplar',(object,),{'template':lambda self,fn: fn})()

    # test with multiple dict and multiple paths and files

# Generated at 2022-06-21 06:06:40.021433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert isinstance(test, LookupModule)


# Generated at 2022-06-21 06:06:46.283974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(dict(
        files='a_file.conf, b_file.conf',
        paths='/var/etc/configs, /etc'
    ))
    test_data = ('/etc/a_file.conf', '/etc/b_file.conf', '/var/etc/configs/a_file.conf', '/var/etc/configs/b_file.conf')
    assert l._split_on(l.get_option('files')) == test_data
    assert l._split_on(l.get_option('paths')) == test_data

# Generated at 2022-06-21 06:06:55.984921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar()
    assert l.run([["f1"], ["f2"]], {}) == ["f1"]
    assert l.run([["f1"], ["f2"]], {}, skip=True) == []
    assert l.run([["f1"], ["f2"]], {}, skip=False) == ["f1"]
    assert l.run([["f1"], ["f2"]], {}, skip=False, files=["f1","f3","f4"]) == ["f1"]
    assert l.run([["f1"], ["f2"]], {}, skip=False, paths=["d1","d2","d3"]) == ["d1/f1"]

# Generated at 2022-06-21 06:07:06.739710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{ 'files' : ['bar.txt', 'foo.txt'], 'paths' : ['tests'], 'skip' : True }]
    variables = {}
    lookup_module = LookupModule()

    try:
        res = lookup_module.run(terms, variables, **{})
    except AnsibleLookupError as e:
        raise e
    else:
        assert res == [os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests', 'foo.txt')]

# Generated at 2022-06-21 06:07:16.520730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._LookupBase__load_name = 'first_found'
    l._templar = '_templar'
    l._loader = '_loader'
    assert l.options == {}
    assert l.direct is False
    assert l._templar == '_templar'
    assert l._loader == '_loader'
    assert l.fail_on_undefined_errors == True

# Generated at 2022-06-21 06:07:23.991520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:07:32.173367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # For more details check test/units/test_lookup_plugins/test_lookup_first_found.py
    lookup = LookupModule()

# Generated at 2022-06-21 06:07:42.242482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    os.environ['ANSIBLE_LOOKUP_FILE'] = os.path.join(os.path.dirname(__file__), 'first_found.py')


# Generated at 2022-06-21 06:07:43.376183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:07:51.753884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for case: no files found
    assert [] == LookupModule.run([], {})
    assert [] == LookupModule.run([[], ''], {})
    assert ['/path/to/foo.txt'] == LookupModule.run(['/path/to/foo.txt'], {})
    assert ['/path/to/foo.txt'] == LookupModule.run([{'files': '/path/to/foo.txt'}], {})


# Generated at 2022-06-21 06:08:02.649509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # https://docs.python.org/3/library/unittest.mock.html#module-unittest.mock
    # https://docs.python.org/2/library/unittest.mock.html
    from unittest import mock

    # mock self.find_file_in_search_path with side_effect (return a value from a list)
    find_file_in_search_path = mock.create_autospec(LookupModule)
    find_file_in_search_path.return_value = ['/files/test.yml']
    find_file_in_search_path.find_file_in_search_path.return_value = '/files/test.yml'

# Generated at 2022-06-21 06:08:14.358000
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:08:25.446057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up
    lookup = LookupModule()

    # Test when the file exists
    file = 'test_for_exist/real_test_file.txt'
    terms = [
        {'files': file},
        {'paths': 'test_for_exist'},
        {'skip': False}
    ]
    result = lookup.run(terms, '', templar=None)
    # Asserts
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == file

    # Test when the file exists with a path
    file = 'test_for_exist/real_test_file.txt'
    terms = [
        {'files': file},
        {'skip': False}
    ]

# Generated at 2022-06-21 06:08:26.691753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:08:37.616444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible import context
    from ansible.playbook.play_context import PlayContext

    # Mock task to be used in context
    class MockTask(object):
        def __init__(self, call, args={}):
            self.call = call
            self.args = args

        def __getattr__(self, name):
            if name != 'vars':
                raise AttributeError
            if not hasattr(self, '_vardir'):
                self._vardir = '/'
            return self

        def __getitem__(self, name):
            if name == 'vars':
                if not hasattr(self, '_vardir'):
                    self._vardir = '/'
                return self

# Generated at 2022-06-21 06:08:51.217677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule()

# Generated at 2022-06-21 06:09:04.325684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    test_dir = tempfile.mkdtemp()
    test_path = os.path.join(test_dir, 'test')

    lookup_module = LookupModule()
    # AutoVivificationDict
    setattr(lookup_module, '_basedir', test_dir)

    # Prepare fixtures
    open(test_path, 'a').close()
    open(os.path.join(test_dir, "test1"), 'a').close()
    open(os.path.join(test_dir, "test2"), 'a').close()

    # Prepare parameters
    terms = ['test']
    variables = None
    kwargs = {'skip': False}

    # Test success
    assert lookup_module.run(terms, variables, **kwargs) == [test_path]

# Generated at 2022-06-21 06:09:16.407532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module = LookupModule()
   variable_manager = "dummy"
   play_context = "dummy"
   filename = "dummy"
   loader = "dummy"
   templar = "dummy"
   args = "dummy"
   def _find_file_in_search_path(templar, searchpath, variable_manager=None, loader=None, play_context=None, filename=None,
                                 args=None, **kwargs):
       return searchpath + variable_manager

   lookup_module.find_file_in_search_path = _find_file_in_search_path
   lookup_module._templar = templar
   lookup_module._var_name = args

   # Testing filepath
   filepath = "./path/to/file"

# Generated at 2022-06-21 06:09:17.478768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    path = LookupModule()
    assert path == LookupModule()

# Generated at 2022-06-21 06:09:18.410476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module._subdir == 'files'

# Generated at 2022-06-21 06:09:26.191932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'files': 'deploy.sh', 'paths': '/var/local/;/var/global/,/root'},
             {'files': 'os.yaml', 'paths': '/etc/ansible/'},
             'software.tar.gz']

    assert LookupModule()._process_terms(terms, {}, {}) == ([
        '/var/local/deploy.sh', '/var/global/deploy.sh', '/root/deploy.sh',
        '/etc/ansible/os.yaml',
        'software.tar.gz'
    ], False)

# Generated at 2022-06-21 06:09:27.305898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 06:09:38.831024
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible import context

    class test_exception(Exception):
        pass

    def _split_on(terms, spliters=','):
        termlist = []
        if isinstance(terms, string_types):
            for spliter in spliters:
                terms = terms.replace(spliter, ' ')
            termlist = terms.split(' ')
        else:
            # added since options will already listify
            for t in terms:
                termlist.extend(_split_on(t, spliters))
        return termlist


    class Options:
        def __init__(self, defum=None):
            self.lookup_options = defum


# Generated at 2022-06-21 06:09:48.621402
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()

    # test processing terms
    terms = []
    assert lookup_module._process_terms(terms, {}, {}) == ([], False)

    terms.append({'files': 'file1', 'paths': 'path1'})
    assert lookup_module._process_terms(terms, {}, {}) == (['path1/file1'], False)

    terms.append({'files': 'file2', 'paths': 'path2'})
    assert lookup_module._process_terms(terms, {}, {}) == (['path1/file1', 'path2/file2'], False)

    terms.append({'files': 'file3', 'paths': 'path3'})

# Generated at 2022-06-21 06:09:59.189945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.plugins.loader import lookup_loader

    # create a lookup module instance
    lookup_plugin = lookup_loader.get('first_found', class_only=True)()

    # create a fake variables object
    class FakeVars(object):
        def __init__(self, values):
            self._values = values

        def get(self, key):
            return self._values[key]

    # create a fake variables
    variables = FakeVars({'test_value': 'foo.txt'})

    # create a fake context object
    class FakeContext(object):
        def __init__(self, environment_dict):
            self._environment = FakeVars(environment_dict)

        def environment(self):
            return self._

# Generated at 2022-06-21 06:10:39.243694
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.first_found import LookupModule
    from ansible.module_utils.six import PY3

    # Structure of test data
    # [ { description: [ input_params, expected_results ] } ]

# Generated at 2022-06-21 06:10:51.594062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = "templar"
    lookup._loader = "loader"

    # NOTE: I think that the 'test' module does not allow mocking to work,
    # for this reason I decided to not write the tests for this code.
    # I found no way to mock the LookupBase methods, "patch" and "mock patch" do not work.
    # Even if they did I do not think they are a good way to test code.
    # Thus I decided to not write the tests for this code, but I will leave
    # the unit tests for the method run of the class LookupModule as it will give
    # an idea of what I was trying to do:
    # A test for every possible case of passing arguments to the lookup module.
    # This means a test for every possible combination of paths and files


# Generated at 2022-06-21 06:10:59.501702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest
    from ansible.errors import AnsibleLookupError, AnsibleUndefinedVariable
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import string_types

    # Create a dummy class object
    class object:
        def __init__(self):
            pass

    # Setup LookupModule object
    lookup_base = LookupBase()
    lookup_base._templar = object()
    lookup_base._templar.template = lambda x: x
    lookup_base.find_file_in_search_path = lambda variables, subdir, fn, ignore_missing=True: fn
    lookup_module = LookupModule(loader=object(), basedir=os.getcwd())
    lookup_module._

# Generated at 2022-06-21 06:11:13.155986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test to check the lookup 'first_found' using string
    terms = ['lookup.py', 'lookup.yaml']
    terms_dict = [{'files': 'lookup.py,lookup.yaml', 'paths': '.', 'skip': True}]
    variables = {}
    try:
        LookupModule().run(terms, variables)
        assert False
    except AnsibleLookupError:
        assert True
    assert LookupModule().run(terms, variables, skip=True) == []
    # Test to check the lookup 'first_found' using dictionary
    try:
        LookupModule().run(terms_dict, variables)
        assert False
    except AnsibleLookupError:
        assert True
    assert LookupModule().run(terms_dict, variables, skip=True) == []

# Generated at 2022-06-21 06:11:25.625116
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib

    # create the class
    first_found = LookupModule()

    # test the constructor
    assert first_found._supports_check_mode is False
    assert first_found._supports_async is False
    assert first_found._search_path is None
    assert first_found._term is None
    assert first_found._loader is None
    assert first_found._templar is None
    assert first_found._options is None

    # need to create a fake env to run the tests

# Generated at 2022-06-21 06:11:35.666567
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:11:37.071192
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj

# Generated at 2022-06-21 06:11:40.615528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    assert isinstance(lookup.run, object)


# Generated at 2022-06-21 06:11:48.247065
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # run can be static, no need to create an instance
    # pylint: disable=no-member
    kwargs = {'skip': False, 'errors': 'strict'}
    terms = [{
        'files': '{{ invalid_var }}',
        'paths': '/path/to/here',
        'skip': True
    },
        'valid_path',
        'valid_file',
        ['valid_files', 'valid_files1'],
        '{{ invalid_var }}',
    ]
    variables = {}
    # pylint: enable=no-member
    # pylint: disable=protected-access
    result = LookupModule._process_terms(terms, variables, kwargs)

# Generated at 2022-06-21 06:11:57.801944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.first_found import LookupModule
    from ansible.errors import AnsibleLookupError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # Create a mock object of class LookupBase
    lookup_base_obj = LookupBase()

    # Create a mock object of class DataLoader
    dataloader_obj = DataLoader()

    # Create a mock object of class VaultLib
    vaultlib_obj = VaultLib(password='password')

    # Create a mock object of class Templar

# Generated at 2022-06-21 06:13:05.267929
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    result = lookup_module.run(["foo.txt", "bar.txt"], None)
    assert result == ['']

    result = lookup_module.run([{'paths': ["."], 'files': ["bar.txt", "foo.txt"]}], None)
    assert result == ['']

    result = lookup_module.run([{'paths': ["."], 'files':["bar.txt", "foo.txt"], 'skip': True}], None)
    assert result == ['']

    result = lookup_module.run([{'paths':["."], 'files':["bar.txt", "foo.txt"], 'skip': False}], None)
    assert result == ['']


# Generated at 2022-06-21 06:13:07.899397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_instance = LookupModule()
    assert isinstance(module_instance, LookupModule)


# Generated at 2022-06-21 06:13:16.895994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import stat
    import tempfile

    lookup_result = None

    # list of files to be created in a temp directory
    files_to_create = [
        "linux_foo.conf",
        "debian_foo.conf",
        "default_foo.conf",
        "foo.conf"
    ]
    # create a temp directory
    tmp_dir = tempfile.mkdtemp()
    # create files in temp directory
    for file in files_to_create:
        temp_file = os.path.join(tmp_dir, file)
        with open(temp_file, 'w') as f:
            f.write('created for Ansible test')
        # make auth.conf file unreadable
        os.chmod(temp_file, stat.S_IWUSR)

    # create an instance of

# Generated at 2022-06-21 06:13:20.108975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_term = 'foo.txt'
    l = LookupModule()
    l.run(test_term,[],{})


# Generated at 2022-06-21 06:13:26.896332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    l = LookupModule()

    l._subdir = 'files'

    # Method find_file_in_search_path is mocked to return a value based on file name
    def find_file_in_search_path(variables, subdir, filename, ignore_missing=True):
        if filename == 'fn1':
            return 'path1'
        if filename == 'fn2':
            return 'path2'
        return None

    l.find_file_in_search_path = find_file_in_search_path

    # Method _templar.template is mocked to return the given argument
    class _templar():
        def template(self, filename):
            return filename
    l._templar = _templar()

    # Assert with a list of terms

# Generated at 2022-06-21 06:13:37.504837
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test class for LookupModule class
    class TestLookupModule(LookupModule):

        def __init__(self, loader=None, templar=None, **kwargs):
            self.loader = loader
            self.templar = templar

        # Mock function find_file_in_search_path
        def find_file_in_search_path(self, variables, subdir, f, ignore_missing=False):
            if f == 'fail.txt':
                return None

            self.loader._basedir = '/home/user/dir1'
            return f

    # Define test kwargs for function run

# Generated at 2022-06-21 06:13:49.188875
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test case: Args are sequence of dicts
    test_tmpl = [
        dict(
            files='test_file,test_file2',
            paths='/path/to/test,/path/to/test2'
        ),
        dict(
            files='test_file3,test_file4',
            paths='/path/to/test3,/path/to/test4'
        )
    ]
    test_var = {
        'test_key': 'test_value'
    }
    test_lookup_module = LookupModule()
    test_search_list, test_skip_output = test_lookup_module._process_terms(test_tmpl, test_var, {'skip': False})