

# Generated at 2022-06-21 06:03:57.331791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-21 06:04:07.651199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test _process_terms()
    params = {'skip': True}
    # test as list
    files = ['foo/bar', 'bar/baz']
    paths = ['path1', 'path2']
    terms = [{'files': files, 'paths': paths, 'skip': True}]
    total_search, skip = lookup._process_terms(terms, dict(), params)
    assert total_search == [os.path.join('path1', 'foo/bar'), os.path.join('path2', 'foo/bar'),
                            os.path.join('path1', 'bar/baz'), os.path.join('path2', 'bar/baz')]
    assert skip == True

    # test as string
    files = 'foo/bar,bar/baz'


# Generated at 2022-06-21 06:04:20.585387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
    # create fake variables
    variables = {'ansible_virtualization_type': 'kvm'}
    # create fake terms
    terms = [
        {'paths': '/tmp/', 'files': 'foo'},
        '/path/to/baz.txt',
        {'paths': '/tmp/', 'files': 'bar'},
        '/path/to/fiz.txt',
        {'paths': '/tmp/', 'files': 'biz'},
        '/path/to/fop.txt',
        ]
    # create fake module

# Generated at 2022-06-21 06:04:30.870273
# Unit test for constructor of class LookupModule
def test_LookupModule():

    vars_ = dict()
    x = LookupModule()
    assert x._subdir == 'files'
    assert x._loader == None
    assert x._templar == None
    assert x._basedir == None
    assert x._environment == None
    assert x._original_file == None
    assert x._original_data == None

    vars_ = {'myvar': 'myvalue'}
    x = LookupModule(loader=None, variables=vars_)
    assert x._subdir == 'files'
    assert x._loader == None
    assert x._templar == None
    assert x._basedir == None
    assert x._environment == None
    assert x._original_file == None
    assert x._original_data == None
    assert 'myvar' in x._options['var_options']
   

# Generated at 2022-06-21 06:04:35.420127
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test with no arguments,
    #  case of lookup_plugin without arguments
    l = LookupModule()
    assert not l, "expected None because there is no argument."

    # test with correct arguments and values,
    #  case of lookup_plugin with file, path, skip
    l = LookupModule(['path1', 'path2'], dict(files=['file1', 'file2'], paths=['path3', 'path4'], skip=True))
    assert l, "expected instance of LookupModule because there is valid arguments."


# Generated at 2022-06-21 06:04:43.169545
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1 : test simple run
    # Test params
    terms = [{'files': 'foo.yaml',
              'paths': '/path/to/foo.yaml,/path/to/baz.yaml:/path/to/test.yaml'},
             'bar.yaml',
             'baz.yaml']

    variables = {'foo': 'bar',
                 'bar': 'baz'}
    kwargs = {'skip': True}

    # Expected result
    expected_result = ['/path/to/foo.yaml']

    # Expected call

# Generated at 2022-06-21 06:04:44.378235
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:04:53.954731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.parsing.dataloader import DataLoader

    # Create a mocked out Ansible lookup plugin
    mocked_lookup = {
        'first_found': {
            'run': LookupModule(loader=DataLoader()).run
        }
    }

    # Create a mocked out Ansible templar
    class MockedTemplar(object):
        def template(self, term):
            return term

    templar = MockedTemplar()

    # Create a mocked out Ansible variable manager
    class MockedVarsManager:
        def __init__(self):
            self.vars = {}

    vars_manager = MockedVarsManager()

    # Test the 'first_found' lookup plugin

# Generated at 2022-06-21 06:04:55.404488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy, to be implemented
    pass

# Generated at 2022-06-21 06:05:06.470472
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create test object and test data
    l = LookupModule()
    l.set_options(var_options={}, direct={'files': [], 'paths': []})
    terms = [{'files': ['/test1', '/test2'], 'paths': ['.']},
            'test3',
            ['test4', 'test5']]
    variables = {'test': 'value'}
    kwargs = {}
    expected_data = [
        './test1',
        './test2',
        'test3',
        'test4',
        'test5'
    ]

    # run test
    total_search, skip = l._process_terms(terms, variables, kwargs)
    assert total_search == expected_data
    assert skip is False

# Generated at 2022-06-21 06:05:13.672524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert ['/etc/hosts'] == lookup_module.run(['paths=["/tmp", "/etc"], files=["hosts"]'], {})

# Generated at 2022-06-21 06:05:21.152940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test case 1
    terms = [
        {'files': 'f1.yaml', 'paths': '/tmp', 'skip': False},
        {'files': 'f2.yaml', 'paths': '/etc', 'skip': False},
    ]

    variables = {}
    lookup_module._process_terms(terms, variables)

    assert lookup_module.get_option('files') == 'f1.yaml,f2.yaml'
    assert lookup_module.get_option('paths') == '/tmp,/etc'
    assert lookup_module.get_option('skip') == False

    # test case 2

# Generated at 2022-06-21 06:05:22.440906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:05:23.823067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:05:36.036409
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import pytest

    # Check that exception raised for invalid term supplied
    with pytest.raises(AnsibleLookupError) as ExceptionInfo:
        dummy = LookupModule()
        terms = [1, 2, 3]
        dummy.run(terms, dict())
    assert "can handle string, mapping or list of strings" in str(ExceptionInfo.value)

    # Check that exception raised for invalid term supplied
    with pytest.raises(AnsibleLookupError) as ExceptionInfo:
        dummy = LookupModule()
        terms = "foo"
        dummy.run(terms, dict())
    assert "can handle string, mapping or list of strings" in str(ExceptionInfo.value)

    # Check that exception raised for invalid term supplied

# Generated at 2022-06-21 06:05:38.696456
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()

    # test splitting string
    assert module._split_on("foo,bar,baz") == ['foo', 'bar', 'baz']



# Generated at 2022-06-21 06:05:51.900653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class ansible_module:
        def __init__(self):
            self.params = {
                'files': [
                    'first.txt',
                    'second.txt',
                    'third.txt'
                ],
                'paths': [
                    '/tmp/one/',
                    '/tmp/two/',
                    '/tmp/three/'
                ],
                'skip': True
            }

    module = ansible_module()
    L = LookupModule()
    L.set_options(var_options=None, direct=module.params)
    assert L.get_option('files') == ['first.txt', 'second.txt', 'third.txt']
    assert L.get_option('paths') == ['/tmp/one/', '/tmp/two/', '/tmp/three/']
    assert L.get_

# Generated at 2022-06-21 06:06:00.553186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=no-member
    lookup_module = LookupModule()
    files = ['default_foo.conf', 'default_other_foo.conf']
    lookup_module._subdir = 'files'
    lookup_module._loader = 'fake_loader'
    # pylint: enable=no-member
    assert lookup_module.run(files) == []

# Generated at 2022-06-21 06:06:09.540506
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # run:
    # check empty
    assert LookupModule.run([], {}) == []

    # check for bad args
    assert LookupModule.run("foo", {}) == []
    assert LookupModule.run("foo", {}) == []
    assert LookupModule.run(("foo", "bar"), {}) == []
    assert LookupModule.run([("foo", "bar")], {}) == []

    # search list
    assert LookupModule.run(("foo", "bar"), {"_original_file": None}) == ["bar"]
    assert LookupModule.run(("foo", "bar", "baz"), {"_original_file": None}) == ["bar"]
    assert LookupModule.run(("foobar", "baz"), {"_original_file": "foo"}) == ["foobar"]

    # search list

# Generated at 2022-06-21 06:06:17.151687
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test when terms is of type string
    lookup_test = LookupModule()
    result = lookup_test._process_terms(terms=['first_found_test'],variables=[], kwargs={})
    assert result == (['first_found_test'], False)

    # Test when terms is of type dict
    lookup_test = LookupModule()
    result = lookup_test._process_terms(terms=[{'files':'test1.txt', 'path':'.', 'skip': False}], variables=[], kwargs={})
    assert result == (['test1.txt'], False)

    # Test when terms is of type list
    lookup_test = LookupModule()
    result = lookup_test._process_terms(terms=[['test1.txt','test2.txt']], variables=[], kwargs={})

# Generated at 2022-06-21 06:06:37.771903
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup

    # no args, just creating object
    assert not lookup.run(terms=None, variables=None, **{})

    # empty list
    assert not lookup.run(terms=[], variables=None, **{})

    # basic test w/ string
    results = lookup.run(terms=['value'], variables=None, **{})
    assert isinstance(results, list)
    assert results[0] == 'value'

    # basic test w/ string and kwargs
    results = lookup.run(terms=['value'], variables=None, skip=True)
    assert isinstance(results, list)
    assert results[0] == 'value'

    # basic test w/ string and kwargs

# Generated at 2022-06-21 06:06:48.420549
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def _find_file_in_search_path(_, __, ___, ____):
        return '123'

    find = LookupModule.find_file_in_search_path
    LookupModule.find_file_in_search_path = _find_file_in_search_path

    lm = LookupModule()
    assert lm.run([], {}, files='', paths='') == ['123']
    assert lm.run([], {}, files='', paths='', skip=True) == []

    # now with a dict term
    assert lm.run([{'files': '', 'paths': ''}], {}, skip=True) == ['123']
    assert lm.run([{'files': '', 'paths': '', 'skip': True}], {}, skip=False) == []

   

# Generated at 2022-06-21 06:06:49.463567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:06:57.921510
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # Method run case: no term supplied
    # Expected result: AnsibleLookupError exception
    with pytest.raises(AnsibleLookupError):
        lookup.run(terms=None, variables=None)

    # Method run case: empty term supplied
    # Expected result: AnsibleLookupError exception
    with pytest.raises(AnsibleLookupError):
        lookup.run(terms='', variables=None)

    # Method run case: invalid term supplied
    # Expected result: AnsibleLookupError exception
    with pytest.raises(AnsibleLookupError):
        lookup.run(terms={}, variables=None)

    # Method run case: valid term supplied, no file found
    # Expected result: AnsibleLookupError exception

# Generated at 2022-06-21 06:07:09.846051
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:07:21.501551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock class
    class Dummy:
        def __init__(self, return_value):
            self.return_value = return_value

        def find_file_in_search_path(self, variables, subdir, fn, ignore_missing=True):
            return self.return_value

    # variables
    variables = {}

    # mock class
    lookup_mock = Dummy(None)

    # test parameters
    terms = ['file1.txt', 'file2.txt']
    subdir = 'files'

    # test 1
    LookupModule.run(lookup_mock, terms, variables)

    # test 2
    lookup_mock.return_value = '/path/to/file'
    result = LookupModule.run(lookup_mock, terms, variables)

# Generated at 2022-06-21 06:07:23.133304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:07:31.501734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lm = LookupModule()
    lm._templar = FakeTemplar()
    lm.find_file_in_search_path = FakeFindFileInSearchPath()
    terms = ['file1', 'file2']
    variables = {'var1': 'value1'}
    expected = ['first_file']
    kwargs = {'files': 'var1', 'paths': 'var2'}

    # Act
    actual = lm.run(terms, variables, **kwargs)

    # Assert
    assert actual == expected


# Generated at 2022-06-21 06:07:40.938143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test when file is found
    terms = ["foo"]
    variables = dict()
    assert lookup_module.run(terms, variables) == ["foo"]

    # test not file is found
    terms = ["bar"]
    variables = dict()
    assert lookup_module.run(terms, variables) == []

    # test when file is found using search paths
    terms = [{'files': 'foo', 'paths': './utils'}]
    variables = dict()
    assert lookup_module.run(terms, variables) == ["./utils/foo"]

    # test when file is found using search paths and jinja2 template
    terms = [{'files': 'foo', 'paths': '{{ foo }}'}]
    variables = {'foo': './utils'}

# Generated at 2022-06-21 06:07:48.939474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = []
    terms.append('/path/to/foo.txt')
    terms.append('foo.txt')
    terms.append('/path/to/biz.txt')
    variables = {}
    the_lookup = LookupModule()
    the_lookup.run(terms, variables)
    assert(variables['_terms'] == terms)

# Generated at 2022-06-21 06:08:02.732597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global LookupModule



# Generated at 2022-06-21 06:08:08.478272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['foo.txt', 'bar.txt', {'files': ['foo.txt', 'bar.txt'], 'paths': ['path/to/dir']}]
    result = lookup.run(terms, dict())
    assert result == []

# Generated at 2022-06-21 06:08:10.224704
# Unit test for constructor of class LookupModule
def test_LookupModule():


    assert LookupModule is not None

# Generated at 2022-06-21 06:08:13.670476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest

    lookup = LookupModule()
    lookup._loader = pytest.Mock()
    lookup._templar = pytest.Mock()

# Generated at 2022-06-21 06:08:14.562030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:08:25.526409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test no file found
    terms = ['foo', 'bar']
    variables = {}
    result = lookup_module.run(terms, variables)
    assert result == []

    # test file found
    terms = ['lookup_test_file_foo.txt', 'lookup_test_file_bar.txt']
    variables = {
        'ansible_playbook_dir': os.path.realpath(os.path.dirname(__file__)),
    }
    result = lookup_module.run(terms, variables)
    assert result == ['/tmp/lookup_test_file_bar.txt']

    # test with paths: file found
    terms = ['lookup_test_file_foo.txt', 'lookup_test_file_bar.txt']

# Generated at 2022-06-21 06:08:26.198758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-21 06:08:37.926993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'file_path': 'path/to'}, direct={'files': 'some_file', 'paths': 'path/list'})
    total_search, skip = lookup._process_terms(['foo'], {}, {})
    assert(total_search == ['path/list/some_file'])
    total_search, skip = lookup._process_terms(['foo'], {}, {'paths': 'another_path'})
    assert(total_search == ['another_path/some_file'])
    total_search, skip = lookup._process_terms(['foo'], {}, {'files': 'another_file', 'paths': 'another_path'})
    assert(total_search == ['another_path/another_file'])
    total

# Generated at 2022-06-21 06:08:46.262115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._subdir = 'files'

    # test correct use of key word arguments
    terms = [{"files": "test.txt"}]
    variables = {}
    kwargs = {}
    total_search, skip = lookup._process_terms(terms, variables, kwargs)
    assert total_search == ['test.txt']

    # test default value of skip
    assert skip is False

    lookup = LookupModule()
    lookup._subdir = 'files'

    # test default value of skip
    terms = ["test.txt"]
    variables = {}
    kwargs = {}
    total_search, skip = lookup._process_terms(terms, variables, kwargs)
    assert total_search == ['test.txt']
    assert skip is False

    # test default value of skip
    terms

# Generated at 2022-06-21 06:08:54.907677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule._split_on('a.txt,b.txt') == ['a.txt', 'b.txt']
    assert LookupModule._split_on(['a.txt', 'b.txt']) == ['a.txt', 'b.txt']
    assert LookupModule._split_on('a.txt;b.txt') == ['a.txt', 'b.txt']
    assert LookupModule._split_on('a.txt:b.txt') == ['a.txt', 'b.txt']
    assert LookupModule._split_on(['a.txt,b.txt', 'c.txt,d.txt']) == ['a.txt', 'b.txt', 'c.txt', 'd.txt']

# Generated at 2022-06-21 06:09:23.910220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    # TODO: Implement more tests
    assert(isinstance(module, LookupModule))

# Generated at 2022-06-21 06:09:36.854064
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.access('/etc/passwd', os.R_OK)

    # test with valid array of files
    terms = [
        '/etc/passwd',
        '/etc/group'
    ]
    loader = None
    templar = None
    x = LookupModule(loader, templar, terms, [], [], [], [], {})
    assert x is not None

    # test with valid array of files but non-existant
    terms = [
        '/etc/nonexistant',
        '/etc/group'
    ]
    loader = None
    templar = None
    x = LookupModule(loader, templar, terms, [], [], [], [], {})
    assert x is not None

    # test with valid array of files but one non-existant

# Generated at 2022-06-21 06:09:39.460647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:09:42.877157
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert lookup_module._subdir == 'files'

# Generated at 2022-06-21 06:09:44.453327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:09:57.267837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    # required for the inventory's host discovery to succeed
    module_loader = DataLoader()
    inventory = InventoryManager(loader=module_loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=module_loader, inventory=inventory)
    # create a play

# Generated at 2022-06-21 06:10:00.356288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 06:10:04.978231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([{'files': 'file1,file2', 'paths': 'path1:path2'}, {'files': 'file3,file4', 'paths': 'path3:path4'}], dict())




# Generated at 2022-06-21 06:10:18.354520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l._subdir = ''
    assert l.run(terms=['/path/to/file'], variables={}) == ['/path/to/file']

    assert l.run(terms=['foo'], variables={}) == ['foo']

    assert l.run(terms=['foo'], variables={}, files=['foo'], paths=['/path/to']) == ['/path/to/foo']

    assert l.run(terms='foo', variables={}, files='foo,bar', paths='/path/to/') == ['/path/to/foo', '/path/to/bar']
    assert l.run(terms='foo', variables={}, files='foo:bar', paths='/path/to/') == ['/path/to/foo', '/path/to/bar']
    assert l.run

# Generated at 2022-06-21 06:10:30.420746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common.collections import ImmutableDict

    from io import StringIO

    options = ImmutableDict(
        _terms=[
            ['first.txt'],
            {'files': 'second.txt', 'paths': [], 'skip': False},
            {'files': 'third.txt', 'paths': [], 'skip': True},
            {'files': 'fourth.txt', 'paths': []},
            {'files': 'fifth.txt', 'paths': []},
            'sixth.txt'
        ],
        files=[],
        paths=[],
        skip=False
    )

    class DummyTemplar:

        def __init__(self):
            self._cache = {}


# Generated at 2022-06-21 06:11:23.000351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-21 06:11:34.493234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None  # FIXME: what should i do with this?
    lookup_module._loader = None  # FIXME: what should i do with this?
    lookup_module.basedir = '/some/dir'
    lookup_module.runner = None  # FIXME: what should i do with this?
    lookup_module.vars = {}
    lookup_module._subdir = 'files'

    total_search = ['/some/dir/default_foo.conf']
    lookup_module.run(total_search, lookup_module.vars)

    total_search = ['/some/dir/default_foo.conf']
    lookup_module.run(total_search, lookup_module.vars)


# Generated at 2022-06-21 06:11:42.004882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a class instance
    instance = LookupModule()

    # define some test variable
    terms = ["/some/path/file1", "some/path/file2"]  # list of strings
    kwargs = {'skip': False, 'paths': '.', 'files': ''}
    variables = dict()

    # call to run: expected result is the list of the two input files
    assert instance.run(terms, variables, **kwargs) == terms

    # define some test variable
    terms = ["/some/path/file1", "some/path/file2"]  # list of strings
    kwargs = {'skip': True, 'paths': '.', 'files': ''}
    variables = dict()

    # call to run: expected result is the list of the two input files

# Generated at 2022-06-21 06:11:45.428951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "We need a test!"

# Generated at 2022-06-21 06:11:46.303771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:11:49.485576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, variable_manager=None,
        templar=None).run([], [], skip=True) == []

# Generated at 2022-06-21 06:11:50.946690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    #pass

# Generated at 2022-06-21 06:11:59.768715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule
    """
    class AnsibleModuleFake:
        pass

    class AnsibleMock:
        def __init__(self):
            self.utils = AnsibleModuleFake
            self.utils.module_docs = {}
            self.utils.module_docs['lookup'] = {'description': 'description'}

    class AnsibleExecutorFake:
        def __init__(self):
            self.my_vars = {}

    class AnsibleTemplarFake:
        def __init__(self):
            self.vars = AnsibleExecutorFake()
            self.template = lambda x: x

    class LookupBaseFake:
        def __init__(self):
            self.get_option = lambda x: None

# Generated at 2022-06-21 06:12:03.917719
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 06:12:14.625151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # Test arguments handling
    terms = [{'files': ['file1.txt'], 'paths': ['path/to/']}, 'file2.txt', ['file3.txt']]
    variables = {'ansible_hostname': 'host1'}
    kwargs = dict()
    total_search, skip = lm._process_terms(terms, variables, kwargs)
    assert skip == False
    assert type(total_search) == list
    assert len(total_search) == 4
    assert total_search == ['path/to/file1.txt', 'file2.txt', 'file3.txt', 'file3.txt']
    # Test file search
    # 1. Search for file that exists