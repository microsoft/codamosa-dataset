

# Generated at 2022-06-22 22:33:06.573631
# Unit test for function request_builder
def test_request_builder():
    method_ = "ansible.module_utils.network.common.utils._write_to_file_descriptor"
    fd = 1
    obj = {'a': 1, 'b': 2}
    actual = request_builder(method_, fd, obj)
    expected = {"id": "2d7a8805-b54a-4898-bbd1-7c8a28acfe58",
                "jsonrpc": "2.0",
                "method": "ansible.module_utils.network.common."
                          "utils._write_to_file_descriptor",
                "params": [1, {'a': 1, 'b': 2}]}
    assert expected == actual

# Generated at 2022-06-22 22:33:12.116678
# Unit test for function recv_data
def test_recv_data():
    from ansible.module_utils.six import StringIO

    test_data = "123456789"

    sock = StringIO()
    for d in [test_data[:4], test_data[4:]]:
        sock.write(struct.pack('!Q', len(d)))
        sock.write(d)

    # seek to beginning of the file and read
    sock.seek(0)
    assert(recv_data(sock) == test_data)



# Generated at 2022-06-22 22:33:18.000308
# Unit test for constructor of class Connection
def test_Connection():
    # When socket_path is None
    try:
        c = Connection(None)
    except AssertionError:
        pass
    # Execute test case
    try:
        c = Connection('/tmp/test_hosts')
        data = {"test_data": "abc"}
        c.send(data)
    except ConnectionError as e:
        assert isinstance(e, ConnectionError)

# Generated at 2022-06-22 22:33:26.265089
# Unit test for function send_data
def test_send_data():

    data = to_bytes('This is a test')
    expected_result = b'\x00\x00\x00\x00\x00\x00\x00\x0cThis is a test'

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', 0))
    s.listen(1)
    (cs, caddr) = s.accept()

    send_data(cs, data)
    result = recv_data(cs)
    cs.close()
    s.close()

    assert result == expected_result



# Generated at 2022-06-22 22:33:34.830057
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ce = ConnectionError("This is a test Exception")
    assert ce.args == ('This is a test Exception',)
    assert ce.message == 'This is a test Exception'
    ce = ConnectionError("This is a test Exception", code=-1)
    assert ce.args == ('This is a test Exception',)
    assert ce.message == 'This is a test Exception'
    assert ce.code == -1
    ce = ConnectionError("This is a test Exception", code=-1, err='Test error string')
    assert ce.args == ('This is a test Exception',)
    assert ce.message == 'This is a test Exception'
    assert ce.code == -1
    assert ce.err == 'Test error string'

# Generated at 2022-06-22 22:33:44.547394
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection('/tmp/ansible-conn-test')
    assert isinstance(connection.close, partial)
    assert isinstance(connection.exec_command, partial)
    assert isinstance(connection.get_option, partial)
    assert isinstance(connection.set_option, partial)
    assert isinstance(connection._send_data_to_connection, partial)
    assert isinstance(connection._send_data_to_connection, partial)
    assert isinstance(connection._socket_path, partial)
    assert isinstance(connection.__dict__, dict)
    assert isinstance(connection.__getattr__, object.__getattr__)
    assert isinstance(connection.__module__, str)
    assert isinstance(connection.__rpc__, partial)
    assert isinstance(connection.__setattr__, partial)
   

# Generated at 2022-06-22 22:33:49.817432
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils.network.common.utils import Connection
    from ansible.module_utils.network.common.jsonrpc import ConnectionError

    connection = Connection('/dev/null')

    try:
        code, out, err = exec_command(connection, 'command_that_does_not_exist')
    except ConnectionError as exc:
        assert exc.err == 'No such file or directory'

# Generated at 2022-06-22 22:33:56.686969
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile

    _, tmp_path = tempfile.mkstemp()
    with open(tmp_path, 'wb') as f:
        write_to_file_descriptor(f.fileno(), {'a': 1})
        f.seek(0)
        assert f.read() == b'29\nccopy_reg\n_reconstructor\np0\n(c__main__\nTest\np1\nc__builtin__\nobject\np2\nNtp3\nRp4\n(dp5\naS\'a\'\np6\nI1\nsb.'

# Generated at 2022-06-22 22:34:04.483972
# Unit test for function exec_command
def test_exec_command():

    class FakeModule(object):
        def __init__(self, socket_path=None):
            self._socket_path = socket_path

    module = FakeModule(socket_path='/tmp/ansible_test')

    code, out, err = exec_command(module, 'fake command')
    assert code == 0, "code should be 0"
    assert out == '', 'out should be empty'
    assert err != '', 'err should not be empty'

# Generated at 2022-06-22 22:34:12.416164
# Unit test for function exec_command
def test_exec_command():
    class FakeModule(object):
        def __init__(self):
            self._socket_path = os.path.join(os.path.expanduser('~'), '.ansible_test_sockets', 'test.sock')
    module = FakeModule()
    command = "_ansible_connection=network_cli"
    errno, stdout, stderr = exec_command(module, command)
    assert stderr == ''
    assert errno == 0
    assert stdout == 'network_cli'


# Generated at 2022-06-22 22:34:13.682540
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    error = ConnectionError("test error")
    assert error.message == "test error"

# Generated at 2022-06-22 22:34:15.163019
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    conn = Connection(socket_path='/test/path')
    assert conn.__getattr__('test')


# Generated at 2022-06-22 22:34:20.164837
# Unit test for function request_builder
def test_request_builder():

    req = request_builder('testmeth')

    assert req['jsonrpc'] == '2.0'
    assert req['params'] == ((), {})

    req = request_builder('testmeth', 'one', 'two', arg1='val1', arg2='val2')

    assert req['jsonrpc'] == '2.0'
    assert req['params'] == (('one', 'two'), {'arg1': 'val1', 'arg2': 'val2'})

# Generated at 2022-06-22 22:34:30.787877
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.network.common.utils import get_connection
    from ansible.plugins.connection.network_cli import Connection as network_cli_Connection
    from ansible.plugins.connection.local import Connection as local_Connection

    requests = {
        'network_cli': ['run_commands', 'get_diff', 'exec_command', 'send_command',
                        'send_command_timing', 'get_config', 'edit_config', 'get', 'get_capabilities',
                        'get_option', 'get_system_info', 'set_log_path', 'enable_mode', 'run_cli_commands',
                        'get_connection_info', 'get_default_flag']
    }

# Generated at 2022-06-22 22:34:43.017095
# Unit test for method send of class Connection
def test_Connection_send():
    import os
    import random
    import string
    from tempfile import mkstemp
    from six import b
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    test_data = ''.join(random.choice(string.ascii_letters) for i in range(50))
    test_data_encoded = json.dumps(test_data)
    _, path = mkstemp()
    os.remove(path)
    conn = Connection(path)
    try:
        conn.send(test_data_encoded)
    except Exception as e:
        assert (e.args == ('unable to connect to socket {0}. See the socket '
                           'path issue category in Network Debug and Troubleshooting '
                           'Guide'.format(path),))

# Generated at 2022-06-22 22:34:51.750043
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    fake_module = type('FakeModule', (object,), {
        '_socket_path': '/fake/socket/path',
    })

    def _exec_jsonrpc(name, *args, **kwargs):

        req = request_builder(name, *args, **kwargs)
        reqid = req['id']


# Generated at 2022-06-22 22:34:53.882682
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    con = Connection('path')
    assert 'open' == con.open.__name__
    try:
        con._open()
    except AttributeError:
        pass
    else:
        assert 0, 'private method should raise an exception'

# Generated at 2022-06-22 22:34:59.752817
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class _AnsibleModule(object):
        def __init__(self, socket_path):
            self._socket_path = socket_path
    module = _AnsibleModule("/tmp/ansible-connection_test")
    connection = Connection("/tmp/ansible-connection_test")
    result = connection.__rpc__("get_option", "some_option")
    assert result == "some_option"
    assert connection.get_option("some_option") == "some_option"


# Generated at 2022-06-22 22:35:09.793224
# Unit test for method send of class Connection
def test_Connection_send():
    '''Test case for sending data over socket'''
    test_cases = {
        'socket_exists': {
            'socket_path_exists': True,
            'socket_path': 'test_conn',
            's.recv.return_value': 'data',
            's.close.return_value': '',
            'expected_return': 'data'
        },
        'socket_not_exists': {
            'socket_path_exists': False,
            'socket_path': 'test_conn',
            's.recv.return_value': 'data',
            's.close.return_value': '',
            'expected_return': None
        },
    }

    con = Connection('test_conn')

# Generated at 2022-06-22 22:35:12.358347
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = '/tmp/my_socket'
    connection = Connection(socket_path)
    assert connection.socket_path == socket_path



# Generated at 2022-06-22 22:35:15.227757
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('connection failed')
    except ConnectionError as exc:
        assert exc.message == 'connection failed'
        assert exc.err is None


# Generated at 2022-06-22 22:35:23.576262
# Unit test for method send of class Connection
def test_Connection_send():

    expected_response = u"Test Text !!!"

    class MockSocket(object):

        def __init__(self):
            self.data = None

        def sendall(self, data):
            self.data = data

        def recv(self, length):
            return self.data

    class MockOs(object):
        def __init__(self):
            self.path = True

        def path(self, path):
            return self.path

    class Mock(object):
        def __init__(self):
            self.socket_path = "/tmp/test"

    mock_os = MockOs()
    mock_socket = MockSocket()
    conn = Connection("test")
    conn.send_data = Mock()

    conn.send_data.sendall(mock_socket, expected_response)
    conn.recv_

# Generated at 2022-06-22 22:35:34.104004
# Unit test for method send of class Connection
def test_Connection_send():
    # Test sending string data
    test_data = "Sample data for testing Connection.send"
    temp_socket_path = "/tmp/test_conn_send"
    socket_path = "/tmp/ansible_test_conn_send"

# Generated at 2022-06-22 22:35:42.809571
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Constructor should assign message to `message` attribute
    error = ConnectionError("message")
    assert error.message == "message"

    # Constructor should assign attributes given through kwargs
    error = ConnectionError("message", potato="potato")
    assert error.potato == "potato"

    # Make sure that constructor doesn't allow assigning `args`
    error = ConnectionError("message", args="potato")
    assert not hasattr(error, "args")

    # Make sure that constructor doesn't allow assigning `message`
    error = ConnectionError("message", message="potato")
    assert not hasattr(error, "message")

# Generated at 2022-06-22 22:35:51.653089
# Unit test for function recv_data
def test_recv_data():
    if os.getenv('TEST_SERVER') is None:
        import pytest
        pytest.skip('No TEST_SERVER env var set')

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((os.getenv('TEST_SERVER'), int(os.getenv('TEST_PORT'))))

    data_in = b"foobar"
    send_data(sock, data_in)

    data_out = recv_data(sock)
    assert data_out == data_in

# Generated at 2022-06-22 22:35:59.304470
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    connection_error = ConnectionError('message', code=1)

    # Get the value of exception
    assert connection_error.__str__() == "message"

    # Get the value of code attribute
    assert connection_error.code == 1

    # Get the value of err attribute
    assert connection_error.err == "message"

    # Assert if no custom attributes have been set
    assert len(connection_error.__dict__) == 3

# Generated at 2022-06-22 22:36:01.826813
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    conn = ConnectionError("Test message", code=2)
    assert conn.message == "Test message"
    assert conn.code == 2
    assert conn.err == None


# Generated at 2022-06-22 22:36:08.758173
# Unit test for function recv_data
def test_recv_data():
    import sys
    if sys.version_info.major == 2:
        import mock
    else:
        from unittest import mock

    def mock_recv(data):
        if len(data) == 8 and data == to_bytes("") * 8:
            return to_bytes("\x00\x00\x00\x00\x00\x00\x00\x09")
        elif len(data) == 1:
            return to_bytes("{'test': 'recv'}\x00")

        return to_bytes("")

    with mock.patch('socket.socket.recv') as mock_class:
        mock_class.side_effect = mock_recv
        assert recv_data("socket") == to_bytes("{'test': 'recv'}\x00")


# Generated at 2022-06-22 22:36:12.668370
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection(socket_path="/tmp/test.sock")
    assert str(type(connection.test)) == "<class 'function'>"
    assert str(type(connection.test1)) == "<class 'function'>"

# Generated at 2022-06-22 22:36:15.180243
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = u'/tmp/ansible_test_sockfile.sock'
    if os.path.exists(socket_path):
        os.unlink(socket_path)

    connection = Connection(socket_path)
    assert connection.socket_path == socket_path, 'Failed to create a Connection object. Expected socket path "%s", but received "%s"' % (socket_path, connection.socket_path)

# Generated at 2022-06-22 22:36:24.545175
# Unit test for function recv_data
def test_recv_data():
    test_data = b"0123456789"
    test_header_len = 8
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind('\0test_recv_data')
    sock.listen(1)

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('\0test_recv_data')

    cl, addr = sock.accept()
    send_data(sf, test_data)
    assert len(recv_data(cl)) == len(test_data)

# Generated at 2022-06-22 22:36:26.162975
# Unit test for constructor of class Connection
def test_Connection():
    obj = Connection('test')
    assert(obj.socket_path == 'test')



# Generated at 2022-06-22 22:36:31.499678
# Unit test for method send of class Connection
def test_Connection_send():
    json_data = '{"jsonrpc": "2.0", "method": "hostname", "id": "12345", "params": []}'
    socket_path = "/tmp/test_socket"
    conn = Connection(socket_path)
    expected_output = None
    output = conn.send(json_data)
    if output == expected_output:
        print("test_Connection_send: Success")
    else:
        print("test_Connection_send: Failed")

# Generated at 2022-06-22 22:36:38.469157
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('get_config', format='json') == \
           {'jsonrpc': '2.0', 'method': 'get_config', 'id': '4a4b8d4b-76b9-4b9c-9b8c-2fca5b5ab5f5',
            'params': ((), {'format': 'json'})}

# Generated at 2022-06-22 22:36:40.017912
# Unit test for constructor of class Connection
def test_Connection():
    assert isinstance(Connection("/tmp/ansible_sock"), Connection)

# Generated at 2022-06-22 22:36:43.169679
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    testobj = Connection('testrun/ansible_test_connection')
    assert testobj.__getattr__('socket_path') == 'testrun/ansible_test_connection'


# Generated at 2022-06-22 22:36:53.948974
# Unit test for function exec_command
def test_exec_command():
    class Module:
        def __init__(self, socket_path):
            self._socket_path = socket_path

    module = Module('/fake/socket/path')

    class Command:
        def __init__(self, command):
            self.command = command

    class ConnectionError(Exception):
        def __init__(self, message, *args, **kwargs):
            super(ConnectionError, self).__init__(message)
            for k, v in iteritems(kwargs):
                setattr(self, k, v)

    def request_builder(method_, *args, **kwargs):
        reqid = str(uuid.uuid4())
        req = {'jsonrpc': '2.0', 'method': method_, 'id': reqid}

# Generated at 2022-06-22 22:37:00.288737
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('./ansible-test-sock')
    data = recv_data(s)
    assert data == b'{"jsonrpc": "2.0", "id": "1", "result": "OK"}'

# Generated at 2022-06-22 22:37:04.005595
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils.connection import Connection

    assert Connection

    try:
        class FakeModule(object):
            def __init__(self):
                self._socket_path = '/tmp/ansible-ssh-fake'

        module = FakeModule()

        assert isinstance(module, object)
        assert module._socket_path == '/tmp/ansible-ssh-fake'

        ret = exec_command(module, 'ls')

        assert ret[0] == 0

    except Exception as exc:
        assert False, to_text(exc)

# Generated at 2022-06-22 22:37:12.046356
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """
    Tests if write_to_file_descriptor writes the proper characters to stdout.
    """
    import subprocess
    val_to_write = {'foo': 'bar'}
    expected_output = '{0}\n{1}\n'.format(val_to_write, hashlib.sha1(cPickle.dumps(val_to_write)).hexdigest())

# Generated at 2022-06-22 22:37:18.414464
# Unit test for function recv_data
def test_recv_data():
    data = to_bytes("test")
    buf = struct.pack('!Q' + str(len(data)) + 's', len(data), data)

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('/tmp/ansible_test_socket')

    sf.sendall(buf)
    out = recv_data(sf)

    assert (data == out)


# Generated at 2022-06-22 22:37:23.260762
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection('/var/lib/awx/venv/awx/lib/python3.6/site-packages/ansible_collections/ansible/netcommon/plugins/connection/netconf.py')
# Insert here your test cases
    assert "connection.py" in connection.socket_path
    assert "connection.py" in connection
    assert "connection.py" in connection.__dict__
    assert "connection.py" in connection._getattr__

test_Connection___getattr__()

# Generated at 2022-06-22 22:37:26.463546
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection()
    except TypeError:
        pass
    else:
        assert False, 'Expected constructor of class Connection to require argument'



# Generated at 2022-06-22 22:37:36.876703
# Unit test for constructor of class Connection
def test_Connection():
    # Assert on object creation with no socket path
    try:
        con = Connection(socket_path=None)
    except AssertionError as exc:
        assert 'must be a value' in str(exc)

    # Assert on object creation with socket path
    try:
        con = Connection(socket_path='/home/ucs')
    except AssertionError as exc:
        assert 'must be a value' in str(exc)

    # Assert on object creation with socket path
    try:
        con = Connection(socket_path='/home/ucs')
    except AssertionError as exc:
        assert 'must be a value' in str(exc)

# Generated at 2022-06-22 22:37:42.357864
# Unit test for function exec_command
def test_exec_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fd, module._socket_path = tempfile.mkstemp()
    cmd = 'show version'
    code, out, err = exec_command(module, cmd)
    assert code == 0
    assert out == '123'
    os.unlink(module._socket_path)



# Generated at 2022-06-22 22:37:46.538055
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    error = ConnectionError('some message', some_key='some value')
    assert 'some message' == error.message
    assert 'some value' == error.some_key


if __name__ == "__main__":
    test_ConnectionError()

# Generated at 2022-06-22 22:37:54.845911
# Unit test for method send of class Connection
def test_Connection_send():
    import tempfile
    import threading

    class MockConnection(Connection):
        # Mocking for method send of class Connection so that we can test
        # it without actually accessing the remote device.
        def send(self, data):
            # A fake server thread that just returns the data it received
            # from client
            class ConnectionServerThread(threading.Thread):
                def __init__(self, inc):
                    super(ConnectionServerThread, self).__init__()
                    self.sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    self.sf.bind(inc)
                    self.sf.listen(1)

                def run(self):
                    client, address = self.sf.accept()
                    received_data = recv_data(client)
                    send_data(client, received_data)

# Generated at 2022-06-22 22:38:04.845885
# Unit test for function send_data
def test_send_data():
    # create a socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("localhost", 0))
    s.listen(1)
    port = s.getsockname()[1]

    # start a thread to test the receiver
    def s_receiver():
        signal.signal(signal.SIGALRM, lambda *args: None)
        signal.alarm(5)
        s_c, _ = s.accept()
        for msg in ["hello", "world", "ansible"]:
            data = recv_data(s_c)
            assert to_bytes(msg) == data
        signal.alarm(0)
        s_c.close()

    thread = threading.Thread(target=s_receiver)
    thread.start

# Generated at 2022-06-22 22:38:07.692612
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection()
    except AssertionError as e:
        assert "socket_path must be a value" in to_text(e)

# Generated at 2022-06-22 22:38:17.296973
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    # create a test file to fd
    (r, w) = os.pipe()
    path = "/tmp/test_write_to_file_descriptor"
    fd = os.open(path, os.O_WRONLY | os.O_CREAT, 0o600)
    # write to test file fd
    write_to_file_descriptor(fd, "test_string")
    # read with r fd and validate
    os.lseek(r, 0, 0)
    buf = os.read(r, 100)

# Generated at 2022-06-22 22:38:27.517254
# Unit test for method send of class Connection
def test_Connection_send():
    import shutil
    import tempfile
    import contextlib
    import threading

    socket_path = tempfile.mktemp()

# Generated at 2022-06-22 22:38:39.247007
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    # write some stuff to a mock file descriptor
    from ansible.module_utils.six.moves import StringIO
    import sys

    class MockFileDescriptor(object):
        def __init__(self):
            self.data = b''

        def write(self, data):
            self.data += data

    mock_file_descriptor = MockFileDescriptor()

    # backup stdin and stdout
    backup_stdin = sys.stdin
    backup_stdout = sys.stdout

    # mock stdin and stout
    sys.stdin = StringIO()
    sys.stdout = mock_file_descriptor

    # write a payload with a key that is not picklable
    payload = {u'BATMAN': u'ROBIN', 'JOKER': 'HARLEY QUINN'}

# Generated at 2022-06-22 22:38:50.191064
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import unittest
    from unittest.mock import Mock
    from ansible.module_utils.connection import Connection

    module = Mock()
    module.__name__ = 'connection_utility_test'
    module._socket_path = '/dev/null'
    module.params = {}
    conn = Connection(module._socket_path)

    # If rpc is not defined in the one connection plugin, then raise exception
    with unittest.TestCase().assertRaises(AttributeError) as context:
        conn._exec_jsonrpc('test_method')
    unittest.TestCase().assertEqual('\'test_method\' object has no attribute \'test_method\'', str(context.exception))

    # If jsonrpc error is present in the response, then raise exception

# Generated at 2022-06-22 22:38:54.355955
# Unit test for method send of class Connection
def test_Connection_send():
    data = "test\n"
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind("/tmp/ansible_connection_test")
    sf.listen(1)
    connection = Connection("/tmp/ansible_connection_test")
    response = connection.send(data)
    assert response == "test\n"

# Generated at 2022-06-22 22:38:57.461698
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    pytest_connectionerror = ConnectionError('message', code=1, err='error')
    assert pytest_connectionerror.message == to_bytes('message')
    assert pytest_connectionerror.code == 1
    assert pytest_connectionerror.err == to_bytes('error')

# Generated at 2022-06-22 22:39:09.100522
# Unit test for function request_builder
def test_request_builder():
    method_ = 'test_method'
    assert request_builder(method_) == {'jsonrpc': '2.0', 'method': method_, 'id': str(uuid.uuid4()), 'params': ([], {})}
    assert request_builder(method_, 'arg1') == {'jsonrpc': '2.0', 'method': method_, 'id': str(uuid.uuid4()), 'params': (('arg1',), {})}
    assert request_builder(method_, 'arg1', 'arg2') == {'jsonrpc': '2.0', 'method': method_, 'id': str(uuid.uuid4()), 'params': (('arg1', 'arg2'), {})}

# Generated at 2022-06-22 22:39:17.498811
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("exception message",
                              **dict(code=27, var1="value1", var2="value2"))
    except ConnectionError as exc:
        # test initial attributes
        assert exc.code == 27
        assert exc.var1 == "value1"
        assert exc.var2 == "value2"

        # test args in base class
        assert exc.args[0] == "exception message"

        # test that err attribute is set by default
        assert exc.err == "exception message"

# Generated at 2022-06-22 22:39:28.612853
# Unit test for function recv_data
def test_recv_data():
    import sys

    # python2
    if sys.version_info[0] < 3:
        from mock import patch, MagicMock
        s = MagicMock()

        # normal TCP socket
        s.recv = MagicMock(return_value='HELLO')
        assert recv_data(s) == 'HELLO'

        # normal TCP socket with extra data
        s.recv = MagicMock(side_effect=['HELL', 'O'])
        assert recv_data(s) == 'HELLO'

        # normal TCP socket with empty data
        s.recv = MagicMock(side_effect=['H', 'E', 'L', 'L', 'O', ''])
        assert recv_data(s) == 'HELLO'

        # UDP socket
        s = MagicMock()

# Generated at 2022-06-22 22:39:34.085487
# Unit test for function request_builder
def test_request_builder():
    result = request_builder('method', 'arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')
    expected = {'jsonrpc': '2.0', 'method': 'method', 'id': result['id'], 'params': (('arg1', 'arg2'), {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'})}
    assert result == expected

# Generated at 2022-06-22 22:39:42.683527
# Unit test for method send of class Connection
def test_Connection_send():
    ''' This test method will test send method of class connection.
        When following parameters are passed:
            1. data is None
            2. data is of type int
            3. data is of type float
        It should raise the following exceptions:
            1. AssertionError
            2. AssertionError
            3. AssertionError
        When following parameters are passed:
            1. data is of type string
            2. data is of type dictionary
            3. data is of type list
            4. data is of type tuple
        It should return the following:
            1. data is of type string
            2. data is of type dictionary
            3. data is of type list
            4. data is of type tuple
    '''
    import json
    import struct
    import socket
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-22 22:39:54.040767
# Unit test for method send of class Connection
def test_Connection_send():
    """
    Method to unit test method send of class Connection
    """
    try:
        os.remove('/tmp/ansible_test')
    except Exception:
        pass
    try:
        os.mkfifo('/tmp/ansible_test')
    except Exception:
        pass

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('/tmp/ansible_test')


# Generated at 2022-06-22 22:39:56.620255
# Unit test for function exec_command
def test_exec_command():
    module = type('FakeModule', (), {'_socket_path': None})
    command = 'command'
    rc, out, err = exec_command(module, command)
    assert rc == 1

# Generated at 2022-06-22 22:40:00.778970
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    filename = "/tmp/ansible_module_test_file"
    fd = os.open(filename, os.O_WRONLY|os.O_CREAT, 0o600)
    write_to_file_descriptor(fd, "test string")
    os.close(fd)

    with open(filename) as f:
        data = f.read()
    os.remove(filename)
    assert data == "14\ntest string0\n"

# Generated at 2022-06-22 22:40:11.846077
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    module = None
    class ConnectionErrorTest(ConnectionError):
        def __init__(self, message, *args, **kwargs):
            self.message = message
            for k, v in iteritems(kwargs):
                setattr(self, k, v)

    class SocketMock(object):
        def __init__(self, AF_UNIX, SOCK_STREAM):
            self.AF_UNIX = AF_UNIX
            self.SOCK_STREAM = SOCK_STREAM
            self.connected = False
            self.data = None
            self.response = None

        def connect(self, socket_path):
            self.connected = True

        def sendall(self, data):
            self.data = data
            return self.response


# Generated at 2022-06-22 22:40:19.739679
# Unit test for function request_builder
def test_request_builder():
    params = ()
    kwargs = {}
    method_ = 'start'
    req = request_builder(method_, *params, **kwargs)
    assert req == {'jsonrpc': '2.0', 'id': req['id'], 'method': 'start', 'params': ((), {})}, \
        "request_builder function returns wrong jsonrpc message"

    params = ('abc', 'def')
    kwargs = {}
    method_ = 'start'
    req = request_builder(method_, *params, **kwargs)
    assert req == {'jsonrpc': '2.0', 'id': req['id'], 'method': 'start', 'params': ((), {})}, \
        "request_builder function returns wrong jsonrpc message"

    params = ()

# Generated at 2022-06-22 22:40:27.909369
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class TestConnection(Connection):
        def send(self, data):
            # in this test, rpc method is 'connection_info'
            return json.dumps({'result': {'arg1': 'arg1', 'arg2': 'arg2'}, 'id': 'testid'})
    socket_path = "/path/to/socket"
    connection = TestConnection(socket_path)
    arg1 = "arg1"
    arg2 = "arg2"
    method_name = "connection_info"
    connection_info = connection.__rpc__(method_name, arg1, arg2)
    assert connection_info['arg1'] == "arg1"
    assert connection_info['arg2'] == "arg2"

# Generated at 2022-06-22 22:40:36.787215
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection('/tmp/test')
    data = json.dumps({'jsonrpc': '2.0', 'id': 'foo', 'method': 'exec_command', 'params': ['ls']})
    assert conn.send(data) == u'{"jsonrpc": "2.0", "id": "foo", "result": [{"digest_size": 16, "digest": "31a9feb3a799ab20d215ec0ea1fa50e283b450a0", "path": "/usr/lib/python2.7"}]}'


# Generated at 2022-06-22 22:40:45.579111
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    m = type('ModuleStub', tuple(), dict())

    m.params = {
        'provider': [{
            'password': 'password',
            'host': '1.1.1.1',
            'username': 'admin'
        }]
    }
    m.params['host'] = m.params['provider'][0]['host']
    m.params['password'] = m.params['provider'][0]['password']
    m.params['username'] = m.params['provider'][0]['username']
    m.params['timeout'] = 10
    m.check_mode = False
    m.socket_path = '/Users/james.stroud/Documents/ansible-repos/nxos-ansible/test/local/test_nxapi_plugin.sock'
   

# Generated at 2022-06-22 22:40:54.652541
# Unit test for function exec_command
def test_exec_command():
    try:
        import ansible.module_utils.basic
        import ansible.module_utils.connection

        class TestConnectionModule(ansible.module_utils.basic.AnsibleModule):
            pass
    except ImportError:
        import ansible.module_utils.basic
        import ansible.module_utils.connection

        class TestConnectionModule(ansible.module_utils.basic.AnsibleModule):
            pass

    class TestModule(object):

        def __init__(self, socket_path):
            self.socket_path = socket_path

        def _exec_command(self):
            return exec_command(self, 'foo')
    module = TestModule('/tmp/ansible-command-socket')
    module._debug = True
    module._exec_command()

# Generated at 2022-06-22 22:41:00.340220
# Unit test for function request_builder
def test_request_builder():
    expected_dict = {'jsonrpc': '2.0', 'method': 'send_data', 'id': '28be7a80-6a89-4b57-94cd-4bb58c79d818',
                     'params': ((), {'data': 'this is test data'})}
    request = request_builder('send_data', data='this is test data')
    assert request == expected_dict

# Generated at 2022-06-22 22:41:03.248485
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Instantiate a Connection object
    connection = Connection('socket_path')

    # Call method
    connection._exec_jsonrpc('test__rpc__')


test_Connection___rpc__()

# Generated at 2022-06-22 22:41:12.314269
# Unit test for function send_data
def test_send_data():
    import os

    tmpfile = "/tmp/send_data_socket"
    os.unlink(tmpfile)

    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(tmpfile)
    listener.listen(1)

    data = "This is test data"

    sender = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    sender.connect(tmpfile)
    send_data(sender, data)

    conn, addr = listener.accept()
    assert data == recv_data(conn)
    sender.close()
    listener.close()
    conn.close()
    os.unlink(tmpfile)


# Generated at 2022-06-22 22:41:14.248424
# Unit test for function exec_command
def test_exec_command():
    data = {'socket_path': 'ansible-connetion.socket'}
    command = 'show run'

    exec_command(data, command)

# Generated at 2022-06-22 22:41:23.781448
# Unit test for function exec_command
def test_exec_command():
    module = MockModule(connection='network_cli')
    module._socket_path='/tmp/ansible_network_cli_socket'
    cmd = 'show version'
    rc, out, err = exec_command(module, cmd)
    assert rc == 0
    assert out == 'show version'
    assert err == ''

    module = MockModule(connection='httpapi')
    module._socket_path='/tmp/ansible_network_cli_socket'
    cmd = 'show version'
    rc, out, err = exec_command(module, cmd)
    assert rc == 0
    assert out == 'show version'
    assert err == ''



# Generated at 2022-06-22 22:41:27.118149
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('ConnectionError: test message')
    assert exc.code == 1
    assert exc.err == 'ConnectionError: test message'



# Generated at 2022-06-22 22:41:29.841942
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('test_ConnectionError')
    except Exception as e:
        assert str(e) == 'test_ConnectionError'
        assert e.args == ('test_ConnectionError',)

# Generated at 2022-06-22 22:41:33.183722
# Unit test for function exec_command
def test_exec_command():
    class LocalObj:
        _socket_path = './test_exec_command'

    assert exec_command(LocalObj, 'echo 1') == (0, '1', '')


# Generated at 2022-06-22 22:41:44.968785
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = None
    module = basic.AnsibleModule(
        argument_spec=dict(
            host=dict(required=True),
            port=dict(required=True),
        ),
        supports_check_mode=True,
    )
    module._socket_path = 'test_path'
    con = Connection(module._socket_path)

    for method_name in ['test_getattr_1', 'test_getattr_2']:
        method = getattr(con, method_name)
        assert isinstance(method, partial)
        assert method.func == con.__rpc__

        args = ('abc', 'def')
        kwargs = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-22 22:41:51.129450
# Unit test for constructor of class Connection
def test_Connection():
    fd = os.open(os.path.abspath(__file__), os.O_RDONLY)
    filename = os.path.basename(__file__)

    conn = Connection(fd)
    assert conn.socket_path == fd

    os.close(fd)
    try:
        Connection(filename)
    except ConnectionError as e:
        assert 'does not exist or cannot be found' in e.args[0]


# Generated at 2022-06-22 22:42:01.793987
# Unit test for function send_data
def test_send_data():
    test_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    test_sock.bind(b'/tmp/test_socket')
    test_sock.listen(1)
    test_data = b'my_test_data_for_send'
    connection = Connection(b'/tmp/test_socket')
    connection.send = send_data

    sf, _addr = test_sock.accept()

    # send data to the socket
    connection.send(test_data)

    # receive data from the socket
    data = recv_data(sf)

    test_sock.close()
    sf.close()

    assert data == test_data

# Generated at 2022-06-22 22:42:08.789587
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    '''
    Tests to ensure that write_to_file_descriptor returns
    the expected number of bytes written.
    '''
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    test_str = 'Test String'
    test_obj = {'test_item': 'Test String'}
    (read_fd, write_fd) = os.pipe()
    write_to_file_descriptor(write_fd, test_obj)
    (read_fd, write_fd) = os.pipe()
    write_to_file_descriptor(write_fd, test_str)
    shutil.rmtree(tmpdir)

if __name__ == '__main__':
    test_write_to_file_descriptor()

# Generated at 2022-06-22 22:42:18.813067
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    try:
        _ = Connection(None)
    except AssertionError:
        assert True
    else:
        assert False

    try:
        _ = Connection("/does/not/exist")
    except ConnectionError:
        assert True
    else:
        assert False

    try:
        _ = Connection("/dev/tty")
    except ConnectionError:
        assert True
    else:
        assert False

    try:
        _ = Connection("/dev/null")
    except ConnectionError:
        assert True
    else:
        assert False

    class Foo(object):
        def __init__(self):
            self.__name__ = "bar"

        def __getattr__(self, name):
            return None

    try:
        _ = Connection(Foo())
    except ConnectionError:
        assert True


# Generated at 2022-06-22 22:42:29.681554
# Unit test for function exec_command
def test_exec_command():
    module = {'_socket_path': '/tmp/pytest-of-ansible/ansible-tmp-1535439094.33-17711503691813/fd'}
    command = 'ping 127.0.0.1'
    code, out, err = exec_command(module, command)
    assert code == 0, "Failed to execute command '%s' got %s error" % (command, code)
    assert out, "Failed to get any output from '%s' got %s" % (command, out)
    assert err == '', "Failed to execute command no error expected but got '%s'" % err

    command = 'fake'
    code, out, err = exec_command(module, command)

# Generated at 2022-06-22 22:42:42.155525
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    distribution_fact_collector = DistributionFactCollector()
    distribution_fact_collector.collect(_get_distribution_version)
    distribution_fact_collector.populate()
    distribution_facts = distribution_fact_collector.get_facts()

# Generated at 2022-06-22 22:42:46.735931
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    msg = "msg"
    code = 1
    string = "string"
    data = "data"
    e = ConnectionError(msg, code=code, string=string, data=data)
    assert e.message == msg
    assert e.code == code
    assert e.string == string
    assert e.data == data

# Generated at 2022-06-22 22:42:50.410982
# Unit test for constructor of class Connection
def test_Connection():
    con = Connection('/some/path/to/file')
    assert con.socket_path == '/some/path/to/file'

    try:
        con = Connection(None)
    except AssertionError:
        assert True



# Generated at 2022-06-22 22:42:57.600070
# Unit test for method send of class Connection
def test_Connection_send():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind("/tmp/test")
    sf.listen(1)
    try:
        data = "string"
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect("/tmp/test")

        test_instance = Connection("/tmp/test")
        response = test_instance.send(data)
        assert data == response

    except socket.error as e:
        sf.close()
        sf = None
        raise ConnectionError
    finally:
        if sf:
            sf.close()
            sf = None



# Generated at 2022-06-22 22:43:01.466172
# Unit test for function recv_data
def test_recv_data():
    class FakeSocket(object):
        def recv(self, n):
            return b'A'

    s = FakeSocket()
    assert recv_data(s) == b'AAAAAAAA'

    s = FakeSocket()
    assert recv_data(s) is None