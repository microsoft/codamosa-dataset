

# Generated at 2022-06-22 22:33:03.231031
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    error = ConnectionError('test_message')
    assert error.code == 1
    assert error.err == "test_message"
    error = ConnectionError('test_message', code=0)
    assert error.code == 0
    assert error.err == "test_message"
    error = ConnectionError('test_message', err=['list_of_errors'])
    assert error.code == 1
    assert error.err == ['list_of_errors']
    error = ConnectionError('test_message', foo='bar')
    assert error.foo == 'bar'
    assert error.code == 1
    assert error.err == "test_message"
    error = ConnectionError('test_message', foo='bar', code=0)
    assert error.foo == 'bar'
    assert error.code == 0

# Generated at 2022-06-22 22:33:10.244209
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule.debug = True

    module = AnsibleModule(
        argument_spec=dict(
            host=dict(required=True, type='str')
        )
    )

    socket_path = "/tmp/socket"
    command = "ls"

    try:
        Connection(socket_path).__rpc__(command)
    except Exception as e:
        module.fail_json(msg=str(e))

# Generated at 2022-06-22 22:33:18.506266
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    class ConnectionTest:
        pass

    setattr(ConnectionTest, 'no_arg', 'test_no_arg')

    argument_exception = False
    try:
        test_con = Connection('test_Connection___getattr__')
        setattr(test_con, 'test_con', 'test_Connection___getattr__')
        test_con.no_arg
    except Exception:
        argument_exception = True

    assert argument_exception, "Exception is not raised"



# Generated at 2022-06-22 22:33:27.993734
# Unit test for method send of class Connection
def test_Connection_send():
    """Unit test for method send of class Connection"""
    import shutil # Used to delete socket

    # Create a socket/instance of Connection class
    socket_path = '/tmp/ansible_abc_12345'
    c = Connection(socket_path)

    # If socket does not exist
    if not os.path.exists(socket_path):
        raise AssertionError('socket path %s does not exist or cannot be found.' % socket_path)

    # Socket exists, let's proceed
    else:
        # Create a sample data to be sent
        data = json.dumps({'jsonrpc': '2.0', 'method': 'exec_command', 'id': '12345'}, cls=AnsibleJSONEncoder)
        data = to_bytes(data)

        # Create instance of class socket
        sf = socket

# Generated at 2022-06-22 22:33:34.731889
# Unit test for method send of class Connection
def test_Connection_send():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    assert sf.connect('./test_socket_file') == None
    test_data = "test data"
    test_data_len = len(to_bytes(test_data))
    packed_len = struct.pack('!Q', test_data_len)
    assert sf.sendall(packed_len + to_bytes(test_data)) == None
    response = sf.recv(test_data_len)
    assert response == to_bytes(test_data)
    sf.close()


# Generated at 2022-06-22 22:33:39.581338
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import os
    import shutil

    ansible_file_descriptor = 10

    temp_dir = "temp_dir"
    if os.path.isdir(temp_dir):
        shutil.rmtree(temp_dir)
    os.mkdir(temp_dir)

    temp_file = "temp_dir/temp_file"
    with os.fdopen(os.open(temp_file, os.O_CREAT | os.O_RDWR), 'wb') as f:
        write_to_file_descriptor(f.fileno(), ansible_file_descriptor)

    returned_ansible_file_descriptor = None
    with os.fdopen(os.open(temp_file, os.O_RDONLY)) as f:
        import pickle
        returned_ansible_

# Generated at 2022-06-22 22:33:43.084546
# Unit test for function exec_command
def test_exec_command():
    m = type('', (), {})()
    m._socket_path = '/some/path'
    code, stdout, stderr = exec_command(m, 'ls')
    assert code == 0
    assert stdout

# Generated at 2022-06-22 22:33:48.218999
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    expected_message = 'ConnectionError Message'
    expected_code = 1
    expected_err = 'ConnectionError Err'
    expected_exception = 'ConnectionError Exception'

    connection_error = ConnectionError(expected_message,
                                       code=expected_code,
                                       err=expected_err,
                                       exception=expected_exception)

    assert connection_error.message == expected_message
    assert connection_error.code == expected_code
    assert connection_error.err == expected_err
    assert connection_error.exception == expected_exception



# Generated at 2022-06-22 22:33:53.872521
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(1)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(s.getsockname())
    data = to_bytes("Hello World")
    send_data(client, data)
    data_received = recv_data(s.accept()[0])
    assert(data == data_received)

# Generated at 2022-06-22 22:33:57.016748
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    c = Connection('/tmp/ansible-connection')
    c.__getattr__("rpc_method")


# Generated at 2022-06-22 22:34:09.631792
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)
    (fd, filename) = temp_file.file.fileno(), temp_file.name
    os.close(fd)

    # test with normal data
    write_to_file_descriptor(fd, {'ansible_facts': {'test1': 1}})

    f = open(filename, 'rb')
    buf = f.read()

    # buf should be '84\n\x80\x04\x95\x02\x91\x00}q\x01(X\x13q\x02X\nq\x03X\tq\x04X\x05ansible_factsq\x05}q\x06(X\

# Generated at 2022-06-22 22:34:10.584099
# Unit test for function send_data
def test_send_data():
    send_data(None, None)


# Generated at 2022-06-22 22:34:18.684538
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('method') == {'jsonrpc': '2.0', 'method': 'method', 'id': '*', 'params': ((), {})}
    assert request_builder('method', 1, 2, a=3, b=4) ==  {
        'jsonrpc': '2.0', 'method': 'method', 'id': '*', 'params': ((1, 2), {'a': 3, 'b': 4})}
    assert request_builder('method', 1, 2, a=3, b=4) !=  {
        'jsonrpc': '2.0', 'method': 'method', 'id': '*', 'params': ((3, 4), {'a': 1, 'b': 2})}

# Generated at 2022-06-22 22:34:23.200231
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('localhost', 8888))
    send_data(s, b'send_data test')
    s.close()

# Generated at 2022-06-22 22:34:24.726088
# Unit test for constructor of class Connection
def test_Connection():
    assert Connection(None)


# Generated at 2022-06-22 22:34:35.186949
# Unit test for function recv_data
def test_recv_data():
    import socket
    import threading
    import time
    msg = "msg1"
    packed_len = struct.pack('!Q', len(msg))
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('\0test_pyez_connection')
    s.listen(1)
    done = threading.Event()
    def worker():
        conn, _ = s.accept()
        conn.sendall(packed_len + msg)
        conn.close()
        done.set()
    threading.Thread(target=worker).start()
    time.sleep(0.1)
    res = recv_data(socket.socket(socket.AF_UNIX, socket.SOCK_STREAM))
    s.close()
    done.wait(1)

# Generated at 2022-06-22 22:34:39.614381
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    s = str(uuid.uuid4())
    msg = "some message"
    e = Exception('test')
    try:
        raise ConnectionError(msg, foo=s, exception=e)
    except ConnectionError as err:
        assert err.foo == s
        assert err.exception == e
        assert str(err) == msg

# Generated at 2022-06-22 22:34:49.560338
# Unit test for method send of class Connection
def test_Connection_send():
    test_json_data = '{"jsonrpc": "2.0", "method": "ping", "id": "a"}'
    test_socket_path = "/tmp/ansible_test.sock"
    test_string = "test"

    fake_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    fake_socket.connect(test_socket_path)

    fake_socket.sendall(struct.pack("!Q", len(test_string)))
    fake_socket.sendall(test_string)

    header_len = 8
    response = b''
    while len(response) < header_len:
        d = fake_socket.recv(header_len - len(response))
        if not d:
            return None
        response += d
    data_len = struct

# Generated at 2022-06-22 22:34:54.414253
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    con = Connection(None)
    try:
        con.test_attr
    except AttributeError as e:
        pass

    try:
        con.__test_attr
    except AttributeError as e:
        pass

# Generated at 2022-06-22 22:35:01.627105
# Unit test for function request_builder
def test_request_builder():
    """ Unit test for request_builder"""
    req = request_builder('method', 1, 2, 3)
    assert req == {'jsonrpc': '2.0', 'method': 'method', 'id': req['id'], 'params': ((1,2,3),{})}

    req = request_builder('method', 1, 2, 3, foo='bar')
    assert req == {'jsonrpc': '2.0', 'method': 'method', 'id': req['id'], 'params': ((1,2,3), {'foo': 'bar'})}


# Generated at 2022-06-22 22:35:03.162523
# Unit test for constructor of class Connection
def test_Connection():
    test_object = Connection('ansible-connection.socket')
    assert test_object.socket_path == 'ansible-connection.socket'


# Generated at 2022-06-22 22:35:11.709188
# Unit test for function exec_command
def test_exec_command():

    module = 'load_config'
    command = 'show version'
    socket_path = None

    # Test assertion
    try:
        code, out, err = exec_command(module, command)
    except AssertionError:
        pass
    else:
        raise AssertionError('The assertion did not occur')

    # Test Connection error
    module._socket_path = '/fake/path'
    code, out, err = exec_command(module, command)
    assert code == 1 and out == '' and err.endswith('does not exist or cannot be found.')

    # Test socket error
    module._socket_path = '/fake/path'
    code, out, err = exec_command(module, command)
    assert code == 1 and out == '' and err.endswith('does not exist or cannot be found.')

# Generated at 2022-06-22 22:35:12.978784
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    pass



# Generated at 2022-06-22 22:35:22.093316
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import os
    import tempfile
    import time

    module = None
    test_stdin = os.fdopen(os.dup(0), 'rb')
    test_stdout = os.fdopen(os.dup(1), 'wb')
    test_stdin_path = test_stdin.name
    test_stdout_path = test_stdout.name
    assert module._socket_path is None
    fd, module._socket_path = tempfile.mkstemp()
    os.close(fd)
    test_connection = Connection(module._socket_path)
    test_method = 'test_method'
    test_arg = 'test_arg'
    test_kwarg = 'test_kwarg'
    test_arg2 = 'test_arg2'
    test_timeout = 1
    test

# Generated at 2022-06-22 22:35:33.179895
# Unit test for function send_data

# Generated at 2022-06-22 22:35:41.472385
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    module = object()
    module._socket_path = '/path/to/ansible-conn.socket'
    connection = Connection(module._socket_path)
    try:
        connection.__getattr__('_test_name')
    except Exception as ex:
        assert 'Connection' == ex.__class__.__name__
        assert '\'_test_name\' object has no attribute \'_test_name\'' in str(ex)
    else:
        assert False, 'Above statement should throw Exception'
    try:
        connection.__getattr__('test_name')
    except Exception as ex:
        assert 'Exception' == ex.__class__.__name__
        assert 'module object has no attribute \'test_name\'' in str(ex)
    else:
        assert False, 'Above statement should throw Exception'

# Generated at 2022-06-22 22:35:45.863985
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    c = Connection('test')
    c.value = 'Test Value'
    assert c.value == 'Test Value'
    assert c._UNDEFINED_METHOD() == None

# Generated at 2022-06-22 22:35:47.894093
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection('/tmp/test')
    # TODO: how to test it?
    assert True

# Generated at 2022-06-22 22:35:55.852094
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile

    fd, fn = tempfile.mkstemp()
    obj = dict(hello=u'world！')
    write_to_file_descriptor(fd, obj)

    os.lseek(fd, 0, 0)
    obj = os.read(fd, 2000)
    os.close(fd)
    obj = to_text(obj, errors='surrogate_or_strict').split(b'\n')
    assert len(obj) == 3
    assert len(obj[0]) > 0
    assert len(obj[1]) > 0
    assert len(obj[2]) > 0

# Generated at 2022-06-22 22:36:06.055730
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind('\0test_sock')
    s.listen(1)

    def target():
        conn, addr = s.accept()
        packed_len = struct.pack('!Q', len(b"Test string"))
        conn.sendall(packed_len + b"Test string")
        conn.close()

    from threading import Thread
    t = Thread(target=target)
    t.start()

    c = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    c.connect('\0test_sock')


# Generated at 2022-06-22 22:36:11.995055
# Unit test for function exec_command
def test_exec_command():
    module = MagicMock(return_value=None)
    module.__dict__ = {'_socket_path': 'test'}
    (exitcode, out, err) = exec_command(module, 'test')
    assert exitcode == 0
    assert out == 'test'
    assert err == ''

# Generated at 2022-06-22 22:36:20.754653
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("", 0))
    s.listen(1)

    data = "hi there"
    packed_len = struct.pack('!Q', len(data))
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(s.getsockname())

    client_socket.sendall(packed_len + data)
    server_socket, address = s.accept()
    assert recv_data(server_socket) == data
    server_socket.close()
    client_socket.close()

# Generated at 2022-06-22 22:36:30.716118
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """
    Unit test for function write_to_file_descriptor.
    """
    from tempfile import mkstemp
    from os import close, remove, write

    test_data = {'test': 'write_to_file_descriptor', 'test_data': [1, 2, 3, 4]}
    fd, filename = mkstemp()

# Generated at 2022-06-22 22:36:41.704985
# Unit test for function recv_data
def test_recv_data():

    # Create a socket pair.  Each connection object has a filehandle
    # (`handle` attribute), which can be used for `send`/`recv` calls.
    lsock, rsock = socket.socketpair()

    # The peercred attribute is a tuple of PID, UID and GID of the peer
    assert lsock.peercred == rsock.peercred

    # The python sendall method handles fragmented message for us.
    lsock.sendall(struct.pack('!Q', 12) + b'Hello world!')

    assert recv_data(rsock) == b'Hello world!'

    lsock.close()
    rsock.close()



# Generated at 2022-06-22 22:36:50.652262
# Unit test for constructor of class Connection
def test_Connection():
    params = {
        'connection': 'network_cli',
        'host': 'host',
        'username': 'user',
        'password': 'pass',
        'port': 22
    }
    # Create a temporary file
    with open('/tmp/socket_test', 'w') as f:
        f.write('test')
    # Get the socket path
    socket_path = 'unix:///tmp/socket_test'
    connection = Connection(socket_path)
    # Check if the socket path is set correctly
    assert connection.socket_path == socket_path, "Invalid socket path"


# Generated at 2022-06-22 22:36:52.386449
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    err = ConnectionError('test message')
    assert err.message == 'test message'



# Generated at 2022-06-22 22:36:58.292055
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common.text.converters import to_bytes

    result = Connection._exec_jsonrpc(write_to_file_descriptor, 1, 2)

    assert result == 3

# Generated at 2022-06-22 22:37:09.324525
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """Unit test for helper ``write_to_file_descriptor``
    """
    import shutil

    def write_data(fd, data, data_hash):
        """Helper to write data to file descriptor.
        """
        os.write(fd, b'%d\n' % len(data))
        os.write(fd, data)
        os.write(fd, b'%s\n' % data_hash)
        return None

    # Create temp file to write data to
    tmp_fd, tmp_fname = tempfile.mkstemp()

    # Write data to file descriptor
    test_data = {}
    test_data['k1'] = 'v1'
    test_data['k2'] = 'v2'
    write_to_file_descriptor(tmp_fd, test_data)

# Generated at 2022-06-22 22:37:19.645571
# Unit test for function send_data
def test_send_data():
    import tempfile
    # Create a unix socket
    sock_name = os.path.join(tempfile.gettempdir(), 'ansible_test')
    os.unlink(sock_name)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(sock_name)
    sock.listen(1)
    # Create a client
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.connect(sock_name)
    # Send data
    data = "Hello, World!"
    send_data(client, data)
    # Receive data
    client.shutdown(1)
    server, addr = sock.accept()
    rv = recv_data(server)
    server.close()

# Generated at 2022-06-22 22:37:26.508762
# Unit test for method send of class Connection
def test_Connection_send():
    # Create a sample socket, only to test Connection.send
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('sample_socket')
    sf.listen(1)

    # Test good data
    data = "sample send data"
    con = Connection('sample_socket')

    try:
        ret = con.send(data)
        assert ret == data
    except ConnectionError:
        print("test_Connection_send failed")

# Generated at 2022-06-22 22:37:35.516411
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    # Init
    mock_self = Mock()
    mock_self.__getattr__.return_value = 'mock_return'
    mock_self.__dict__ = {'mock_key': 'mock_value'}
    name = 'mock_name'

    # Invoke method
    retval = Connection.__getattr__(mock_self, name)

    # Check return value
    assert retval == 'mock_return'

    # Check calls
    mock_self.__getattr__.assert_called_with('mock_name')



# Generated at 2022-06-22 22:37:37.982091
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection('/tmp/ansible-conn-test')
    assert conn.send('unit test data') == 'unit test data'


# Generated at 2022-06-22 22:37:48.835556
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    class MockSocket(object):
        def __init__(self, name):
            self.name = name

        def connect(self, socket_path):
            return

        def sendall(self, data):
            return

        def recv(self, data_len):
            return data_len

        def close(self):
            return

    class MockJson(object):
        def __init__(self, name):
            self.name = name

        def dumps(self, data, cls=AnsibleJSONEncoder):
            return data

        def loads(self, data):
            return data

    class MockMethod(object):
        def __init__(self, name):
            self.name = name

            self.req = {'jsonrpc': '2.0', 'method': name, 'id': 'uuid'}

# Generated at 2022-06-22 22:38:00.921288
# Unit test for method send of class Connection
def test_Connection_send():
    data = '{"jsonrpc": "2.0", "method": "get_option", "params": ["persistent_command_timeout"], "id": "9eaacd4a-4fd6-4aa6-8f6c-1775162b7c91"}'

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('/tmp/pytest-ansible.sock')
    sf.listen(0)
    sf.settimeout(2)

    connection = Connection('/tmp/pytest-ansible.sock')
    try:
        received_data = connection.send(data)
    except socket.error as e:
        sf.close()

# Generated at 2022-06-22 22:38:03.231084
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection('/foo')
    assert c.socket_path == '/foo'


# Generated at 2022-06-22 22:38:14.478821
# Unit test for function recv_data
def test_recv_data():

    # No data received
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect(socket_path)
    assert recv_data(sf) is None

    # Data received
    send_data(sf, b'test')
    assert b'test' == recv_data(sf)

    # Data split into multiple packets
    send_data(sf, b'test')
    sf.recv(1)
    assert b'test' == recv_data(sf)

    # Data not received in the format of <str_len>str</str_len>
    send_data(sf, b'data')
    sf.recv(1)
    assert recv_data(sf) is None

    sf.close()



# Generated at 2022-06-22 22:38:20.836778
# Unit test for function exec_command
def test_exec_command():
    # Send a command that should succeed
    rc, out, err = exec_command(dict(_socket_path='/tmp/test.sock'), '{"jsonrpc": "2.0", "method": "get_config", "id": "test_id", "params": [{"format": "text"}]}')
    assert rc == 0

    # Send a command that should fail
    rc, out, err = exec_command(dict(_socket_path='/tmp/test.sock'), '{"jsonrpc": "2.0", "method": "fail", "id": "test_id", "params": [{"format": "text"}]}')
    assert rc != 0

# Generated at 2022-06-22 22:38:24.931094
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    conn = Connection(None)
    conn._exec_jsonrpc = lambda *args, **kwargs: {'id': args[0], 'result': True}
    assert conn.__rpc__('method') is True
    assert conn.arg1.arg2.arg3('method') is True

# Generated at 2022-06-22 22:38:30.194476
# Unit test for constructor of class Connection
def test_Connection():
    assert Connection('socket_path').socket_path == 'socket_path'
    assert Connection('socket_path')._Connection__rpc__('name', 'args', 'kwargs') == \
        {
            u'jsonrpc': u'2.0',
            u'id': u'name',
            u'params': ((u'args', u'kwargs'),)
        }

# Generated at 2022-06-22 22:38:40.475584
# Unit test for function recv_data
def test_recv_data():
    ''' Test recv_data.  Since it's static, we need to call it from here.'''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    test_string = to_bytes(b"test")

    # Make a fake socket to send for testing
    class TempSocket(object):

        def __init__(self, string):
            self.string = string
            self.index = 0

        def recv(self, i):
            try:
                res = self.string[self.index:self.index+i]
                self.index += i
                return res
            except IndexError:
                return None

    # Test receiving an empty buffer
    socket = Temp

# Generated at 2022-06-22 22:38:42.249825
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection("tmp_connection_path")


# Generated at 2022-06-22 22:38:53.291077
# Unit test for function recv_data
def test_recv_data():
    # first, create a socket (that will be server) and connect to it (that will be client)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 0))
    server_socket.listen(1)
    server_address = server_socket.getsockname()[1]
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', server_address))

    # wait for the server to receive the connection (it must be closed after)
    sock, addr = server_socket.accept()
    sock.close()

    # payloads to be sent

# Generated at 2022-06-22 22:39:01.038206
# Unit test for function request_builder
def test_request_builder():
    import json

    req = request_builder('test', '1', '2', '3', kwarg='4')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test'
    assert isinstance(req['id'], str)
    assert len(req['id']) == 36
    assert req['params'][0] == ('1', '2', '3')
    assert req['params'][1] == {'kwarg': '4'}

    req = request_builder('test_1')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test_1'
    assert isinstance(req['id'], str)
    assert len(req['id']) == 36
    assert req['params'][0] == ()

# Generated at 2022-06-22 22:39:05.189727
# Unit test for constructor of class Connection
def test_Connection():
    sock_path = '/dev/shm/ansible_test_sock'
    conn = Connection(sock_path)
    assert conn.socket_path == sock_path


# Generated at 2022-06-22 22:39:08.840574
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    con = Connection("path")
    assert callable(getattr(con, "exec_command"))
    assert "Connection" in str(con.exec_command)
    assert not callable(getattr(con, "_abc"))



# Generated at 2022-06-22 22:39:17.917007
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('test_method', 1, 2, 3, arg1='1', arg2='2', arg3='3') == {'jsonrpc': '2.0',
                                                                                     'method': 'test_method',
                                                                                     'id': 'ae69cde4-2b74-4e90-b1d4-4be7eae9256d',
                                                                                     'params': ((1, 2, 3), {'arg3': '3', 'arg2': '2', 'arg1': '1'})}

# Generated at 2022-06-22 22:39:28.613597
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    # mocks
    class MockConnection(Connection):
        def __init__(self):
            self.socket_path = '/tmp/ansible-test'

        def __rpc__(self, name, *args, **kwargs):
            if name == 'foo':
                return args, kwargs
    # creation
    cnx = MockConnection()
    # when called as a class method, invoke __rpc__
    res = cnx.foo()
    assert res == ((), {})
    # when called as an instance method, invoke __rpc__
    cnx.bar = MockConnection.foo
    res = cnx.bar()
    assert res == ((), {})
    # invalid
    with pytest.raises(AttributeError):
        cnx._foo

# Generated at 2022-06-22 22:39:33.215594
# Unit test for function send_data
def test_send_data():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('socket')
    sf.listen(1)
    conn, client_address = sf.accept()
    data = to_bytes('send_data')
    send_data(conn, data)
    assert len(data) == 5, 'data is not send properly'

# Generated at 2022-06-22 22:39:40.578242
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    fd = os.open("/tmp/write_to_file_descriptor.log", os.O_RDWR | os.O_CREAT)

    obj0 = dict()
    obj0['key1'] = "value1"
    obj0['key2'] = "value2"
    obj0['key3'] = "value3"

    obj1 = "value4"

    write_to_file_descriptor(fd, json.dumps(obj0))
    write_to_file_descriptor(fd, json.dumps(obj1))

    os.close(fd)

# Generated at 2022-06-22 22:39:45.048657
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(Connection._socket_path)

    data = to_bytes('test')
    send_data(s, data)
    response = recv_data(s)

    assert response == data

    s.close()

# Generated at 2022-06-22 22:39:48.063117
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    from ansible.module_utils.connection import Connection

    conn = Connection(socket_path='/path/to/socket')
    conn.send = lambda data: {'id': 1, 'result': 'Unit Test', 'jsonrpc': '2.0'}

    assert conn.unit_test() == 'Unit Test'



# Generated at 2022-06-22 22:39:51.284943
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('Test Message')
    except ConnectionError as exc:
        assert exc.args[0] == 'Test Message'
        assert repr(exc) == "ConnectionError('Test Message',)"

# Generated at 2022-06-22 22:39:56.434381
# Unit test for method send of class Connection
def test_Connection_send():
    socket_path = "/tmp/.test_socket"
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind(socket_path)
    sf.listen(1)

    conn = Connection(socket_path)
    send_data(sf, "hello")
    response = conn.send("world")
    assert response == "hello"



# Generated at 2022-06-22 22:40:02.605000
# Unit test for function exec_command
def test_exec_command():
    import os
    module = type('', (object,), {'_socket_path': None})
    command = 'get_option("foobar")'
    (rc, stdout, stderr) = exec_command(module, command)
    assert rc == 1, 'should have returned code 1'
    assert not stdout, 'should not have printed stdout'
    assert stderr is not None, 'should have returned error msg'

    class Module(object):
        def __init__(self, socket_path):
            self.socket_path = socket_path
            self.socket_path = os.path.join(os.getcwd(), socket_path)

    module = Module('test.sock')
    (rc, stdout, stderr) = exec_command(module, command)

# Generated at 2022-06-22 22:40:12.968587
# Unit test for constructor of class Connection
def test_Connection():
    print("Testing Connection")
    from ansible.plugins.connection import connection_loader
    from ansible.errors import AnsibleError
    from ansible.utils.path import unfrackpath
    from ansible import constants as C
    test_path = unfrackpath("/tmp/ansible_test_" + str(uuid.uuid4()))
    plugin_path = unfrackpath("./test/units/plugins/test_connection/")


# Generated at 2022-06-22 22:40:19.607106
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection("/dev/null")
    data = json.dumps({"jsonrpc": "2.0", "id": "some-id", "method": "some-method", "params": (42, )})
    assert data == conn.send(data)

# Generated at 2022-06-22 22:40:28.759052
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    import pytest
    from ansible_collections.cisco.asa.tests.unit.compat.mock import patch

    c = Connection(None)

    with pytest.raises(AssertionError):
        c.__getattr__('_exec_jsonrpc')

    with pytest.raises(AttributeError):
        c.__getattr__('__not_a_real_attribute')

    with pytest.raises(AttributeError):
        c.__getattr__('_exec_jsonrpc')

    with patch('ansible_collections.cisco.asa.plugins.connection.network_cli.Connection.__getattr__') as patched_getattr:
        patched_getattr.return_value = None
        c.__getattr__('_exec_jsonrpc')


# Generated at 2022-06-22 22:40:39.640422
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('name', 'a', b=2)
    expected = {'jsonrpc': '2.0', 'method': 'name', 'id': 'a', 'params': ('a', {'b': 2})}
    assert req == expected


if os.getenv('ANSIBLE_JSONRPC_DEBUG'):
    import logging
    logging.basicConfig(filename=os.getenv('ANSIBLE_JSONRPC_DEBUG'), level=logging.DEBUG)
    logger = logging.getLogger('jsonrpc')

    def _send(self, data):
        logger.debug("Sending data:\n%s", data)
        return self.__send(data)

    def _recv(self):
        data = self.__recv()
        logger.debug("Received data:\n%s", data)

# Generated at 2022-06-22 22:40:43.778782
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    rpc_method = 'read_module_config'
    data = [rpc_method]
    class_obj = Connection(socket_path=None)
    rc, out, err = exec_command(class_obj, data)
    assert rc != 0
    assert "No module file provided" in err
    assert "No socket path provided" in err



# Generated at 2022-06-22 22:40:53.748949
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import tempfile
    import json
    import threading
    import time
    from ansible.module_utils.six import PY3

    results = {}

    def responder(results, socket_path):

        # Create a temporary socket path
        try:
            (fd, path) = tempfile.mkstemp()
            os.close(fd)
        except Exception:
            raise Exception("Failed to create temporary socket path, err: %s" % traceback.format_exc())

        name = 'test_method'
        args = ['arg1', 'arg2']
        kwargs = {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}

        results['socket_path'] = path


# Generated at 2022-06-22 22:41:04.169137
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    tmp_fd, tmp_path = tempfile.mkstemp()
    obj = {'key1': 1, 'key2': 2}
    write_to_file_descriptor(tmp_fd, obj)
    # Making sure the entire obj is written to fd
    # before fd is closed.
    os.close(tmp_fd)
    # Reading back the data written to file.
    tmp_file_handle = open(tmp_path)
    data_length = tmp_file_handle.readline()
    data_length = int(data_length.rstrip('\n'))
    data = tmp_file_handle.read(data_length)
    data_hash = tmp_file_handle.readline()
    data_hash = data_hash.rstrip('\n')
    # Reconstruct

# Generated at 2022-06-22 22:41:08.083842
# Unit test for constructor of class Connection
def test_Connection():
    if os.path.exists('/tmp/ansible_service'):
        connection = Connection('/tmp/ansible_service')
        if connection.socket_path == '/tmp/ansible_service':
            return True
        else:
            raise Exception('test_Connection Failed')
    else:
        raise Exception('test_Connection Failed')

# unit test for the constructor of the class Connection

# Generated at 2022-06-22 22:41:14.713566
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from ansible_test._internal.utils.file_descriptor import FileDescriptor
    fd = FileDescriptor()
    write_to_file_descriptor(fd.fileno(), [1, 2, 3, 'a', 'b', 'c'])
    fd.seek(0)

    data_len = int(fd.readline())
    assert data_len == len(fd.read(data_len))
    data = fd.read()

    assert data.startswith('sha1')
    assert fd.tell() == len(data)

# Generated at 2022-06-22 22:41:26.126564
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        error = ConnectionError('my error')
    except Exception as error:
        assert False, 'Exception thrown but not expected'

    assert error.message == 'my error', 'Error message not correctly defined'
    assert error.code is None, 'Exception contains code which is not expected'
    assert error.err is None, 'Exception contains err which is not expected'

    try:
        error = ConnectionError('error 2', code=1, err='my error')
    except Exception as error:
        assert False, 'Exception thrown but not expected'

    assert error.message == 'error 2', 'Error message not correctly defined'
    assert error.code == 1, 'Exception contains code which is not expected'
    assert error.err == 'my error', 'Exception does not contain err which is not expected'

# Generated at 2022-06-22 22:41:34.482572
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind(b'\x00ansible-conn-test')
    s.listen(1)
    data = to_bytes("0123456789")
    packed_len = struct.pack('!Q', len(data))
    client, _ = s.accept()
    s.close()

    sent_data = packed_len + data
    for idx, d in enumerate(sent_data):
        client.sendall(sent_data[idx:idx+1])
        recv_d = recv_data(client)

# Generated at 2022-06-22 22:41:38.736373
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = '/tmp/ansible'
    try:
        os.remove(socket_path)
    except OSError:
        pass
    c = Connection(socket_path)
    assert c.socket_path == socket_path
    try:
        c = Connection('foo')
    except AssertionError:
        pass

# Generated at 2022-06-22 22:41:49.945203
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """Test that write_to_file_descriptor correctly writes data to a file descriptor

    The test is based around dumping different types of objects to the fd and
    then reading them back.
    """
    from tempfile import mkstemp
    from ansible.module_utils.basic import AnsibleModule

    # Create some data to dump to the fd
    data = {
        'foo': 'bar',
        'baz': ['qux1', 'qux2']
    }

    # Create a fake module, which we can then use to get the fd
    module = AnsibleModule(argument_spec={})
    fd, fd_path = mkstemp()

    # Write the fake data to the fd and close it
    write_to_file_descriptor(fd, data)
    os.close(fd)



# Generated at 2022-06-22 22:41:57.686205
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('ansible_version', '2.4', '2.5')
    assert req == {
        'jsonrpc': '2.0',
        'method': 'ansible_version',
        'id': '2d7f29ed-5505-4ba5-a1fe-5e046d5a2a5a',
        'params': (('2.4', '2.5'), {})
    }

# Generated at 2022-06-22 22:42:04.611268
# Unit test for method send of class Connection
def test_Connection_send():
    test_connection = Connection('/tmp/foo/bar')
    with open('/tmp/foo/bar', 'w+') as sf:
        test_connection.send(None)
        assert sf.read() == '0\n\n65a8e27d8879283831b664bd8b7f0ad4\n'

if __name__ == "__main__":
    # Json rpc class Unit Test
    import sys
    print("No unit tests available")
    sys.exit(1)

# Generated at 2022-06-22 22:42:16.953187
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('localhost', 0))
    s.listen(1)
    _, port = s.getsockname()

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(('localhost', port))

    data = 'some test data'
    client.sendall(data)
    client.close()

    conn, _ = s.accept()

    recv = recv_data(conn)

    assert recv == data

    conn.close()
    s.close()

# Generated at 2022-06-22 22:42:26.290029
# Unit test for method send of class Connection
def test_Connection_send():
    class MockSocket():
        def __init__(self):
            self.data = None

        def recv(self, size):
            return self.data

        def sendall(self, data):
            self.data = data

    mock_module = MockSocket()
    conn_obj = Connection("mock_module")
    conn_obj.socket_path = "mock_module"

    data = "This is a test string"
    expected = struct.pack('!Q', len(to_bytes(data))) + data
    conn_obj.send(data)
    assert mock_module.data == expected



# Generated at 2022-06-22 22:42:30.669295
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        e = ConnectionError("test message")
    except Exception as e:
        assert(False)

    try:
        e = ConnectionError("test message", code=1)
    except Exception as e:
        assert(False)

    try:
        e = ConnectionError("test message", err="test err")
    except Exception as e:
        assert(False)

# Generated at 2022-06-22 22:42:42.781555
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.plugin_docs import read_docstring

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    connection = Connection(module._socket_path)

    # Test for executing rpc method in connection plugin
    result = connection.__rpc__("get_connection_info", "ansible_connection")
    module.exit_json(result=result)

    # Test for executing rpc method in connection plugin with kwargs
    result = connection.__rpc__("get_option", "ansible_connection", "persistent_connection")
    module.exit_json(result=result)

    # Test for executing rpc method in connection plugin with passing args and kwargs

# Generated at 2022-06-22 22:42:53.538300
# Unit test for function send_data
def test_send_data():
    """Tests send_data function.

    * Creates dummy socket and binds it to any free port
    * Sends some data over dummy socket and receives it back
    * Sends data over dummy socket and verifies that it's the same data
      as was sent.
    """

    ip_addr = "127.0.0.1"
    port = 0  # Let the kernel assign a free port

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((ip_addr, port))
    sock.listen(1)
    _, port = sock.getsockname()

    data = "hello world!"

    cli = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cli.connect((ip_addr, port))
    send_data

# Generated at 2022-06-22 22:42:59.959250
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    errorMsg = 'error message'
    exception = 'exception'
    error = 'error'
    code = 1
    exc = ConnectionError(errorMsg, error=error, exception=exception, code=code)

    assert exc.__str__() == errorMsg
    assert exc.err == error
    assert exc.exception == exception
    assert exc.code == code
