

# Generated at 2022-06-22 22:32:59.512972
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('method', [1, 2, 3], param='value')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'method'
    assert req['params'] == ([1, 2, 3], {'param': 'value'})


# Generated at 2022-06-22 22:33:07.474547
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection('/tmp/foo')

    try:
        connection.__getattr__('foo')
    except KeyError:
        assert True
    except Exception as exc:
        assert False, 'Unexpected exception thrown: %s' % exc.__class__.__name__

    try:
        connection.__getattr__('_foo')
    except AttributeError:
        assert True
    except Exception as exc:
        assert False, 'Unexpected exception thrown: %s' % exc.__class__.__name__

    try:
        partial_func = connection.__getattr__('exec_command')
        assert partial_func.keywords == {'name': 'exec_command'}
    except Exception as exc:
        assert False, 'Unexpected exception thrown: %s' % exc.__class__.__name__

# Generated at 2022-06-22 22:33:10.632758
# Unit test for function exec_command
def test_exec_command():
    assert exec_command(None, 'echo "hello"') == (0, 'hello', '')
    assert exec_command(None, 'does_not_exist') == (1, '', 'does_not_exist: command not found')

# Generated at 2022-06-22 22:33:22.412915
# Unit test for function recv_data
def test_recv_data():
    import os
    import socket
    import tempfile

    with tempfile.TemporaryDirectory() as t_dir:
        sock_path = os.path.join(t_dir, 'test_socket')

        srv_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        srv_sock.bind(sock_path)
        srv_sock.listen()

        cln_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        cln_sock.connect(sock_path)
        cln_sock.settimeout(1)

        conn, addr = srv_sock.accept()
        conn.settimeout(1)

        header_len = 8
        data = to_bytes("")

# Generated at 2022-06-22 22:33:25.822261
# Unit test for function request_builder
def test_request_builder():
    r = request_builder('test', 1, 2, k=3)
    assert r == {'jsonrpc': '2.0', 'method': 'test', 'id': r['id'], 'params': ((1, 2), {'k': 3})}

# Generated at 2022-06-22 22:33:33.562397
# Unit test for method send of class Connection
def test_Connection_send():
    '''
    Test send method of class Connection
    '''
    conn = Connection('/var/lib/awx/tmp/awx_7865_8m1n2x/ansible-connection')
    data = {'hello': 'world'}
    response = json.loads(conn.send(json.dumps(data, cls=AnsibleJSONEncoder)))
    assert response['id'] == '00000000-0000-0000-0000-000000000000'
    assert response['jsonrpc'] == '2.0'
    assert len(response['result']) == len(json.dumps(data, cls=AnsibleJSONEncoder))
    assert response['result'].startswith('{')


# Generated at 2022-06-22 22:33:39.008812
# Unit test for function send_data
def test_send_data():
    # Send data to socket and receive response
    def _socket_server(socket_path):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            os.remove(socket_path)
        except OSError:
            pass
        sock.bind(socket_path)
        sock.listen(0)
        conn, addr = sock.accept()
        data = recv_data(conn)
        send_data(conn, data)
        conn.close()
        sock.close()
        os.remove(socket_path)

    # Create socket server using thread
    socket_path = '/tmp/test_socket'
    import threading
    t = threading.Timer(0, _socket_server, [socket_path])
    t.start()

    # send data

# Generated at 2022-06-22 22:33:49.898409
# Unit test for method send of class Connection
def test_Connection_send():
    import json
    import os
    import tempfile

    class mock_socket():
        def __init__(self):
            self.data  = b''
            self.close = lambda: None
            self.recv = lambda: self.data

        def connect(self, path):
            self.data = b''
            if os.path.exists(path):
                with open(path, 'rb') as f:
                    self.data = f.read()

        def sendall(self, data):
            self.data += data

    def mock_connect(connection, data):
        sock = None
        sf   = mock_socket()

# Generated at 2022-06-22 22:33:51.256247
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    module = Connection("/var/tmp/ansible_connection.socket")
    assert "ansible-connection" == module.module_name


# Generated at 2022-06-22 22:33:55.152332
# Unit test for constructor of class Connection
def test_Connection():
    try:
        # Executing constructor without passing any parameter
        x = Connection()
    except AssertionError as e:
        assert True
    else:
        assert False

    # Passing a valid socket path
    x = Connection("/foo/bar/file.sock")
    assert x.socket_path == "/foo/bar/file.sock"

# Generated at 2022-06-22 22:34:08.844862
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('test', 'a', 'b', 'c') == {'jsonrpc': '2.0', 'method': 'test', 'id': '3af1a7e1-6a8d-49f5-b478-633d5e5e5f5e', 'params': (('a', 'b', 'c'), {})}
    assert request_builder('test1', 'd', 'e', 'f', a='a', b='b') == {'jsonrpc': '2.0', 'method': 'test1', 'id': '3af1a7e1-6a8d-49f5-b478-633d5e5e5f5e', 'params': (('d', 'e', 'f'), {'a': 'a', 'b': 'b'})}

# Generated at 2022-06-22 22:34:12.594041
# Unit test for function exec_command
def test_exec_command():
    """Unit test function for function exec_command.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.
    """


if __name__ == '__main__':
    test_exec_command()

# Generated at 2022-06-22 22:34:17.554343
# Unit test for function request_builder
def test_request_builder():
    name = "test_method"
    args = (1, 2, 'hi there')
    kwargs = {'a': '123', 'b': 'string'}
    req = request_builder(name, *args, **kwargs)
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test_method'
    assert req['params'] == (args, kwargs)


# Generated at 2022-06-22 22:34:20.372573
# Unit test for function exec_command
def test_exec_command():
    module = object()
    module._socket_path = "fake"
    out = exec_command(module, 'command')
    assert out == (1, '', 'unable to connect to socket fake. See Troubleshooting socket path issues in the Network Debug and Troubleshooting Guide')


# Generated at 2022-06-22 22:34:22.749445
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    # arrange
    conn = Connection(socket_path="/foo")

    # act
    # assert
    assert conn.__getattr__("execute")



# Generated at 2022-06-22 22:34:31.270136
# Unit test for function send_data
def test_send_data():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    sock.listen(5)

    send_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    send_sock.connect(sock.getsockname())
    send_data(send_sock, b"test")

    (recv_sock, _) = sock.accept()

    value = recv_data(recv_sock)
    assert value == b"test"

# Generated at 2022-06-22 22:34:43.388255
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    # Need to stub out os.write
    os_write = os.write
    # Keep a list of the data written and the file descriptor.
    data_written = []
    fd_used = []

    def fake_os_write(fd, data):
        data_written.append(data)
        fd_used.append(fd)
        return len(data)
    os.write = fake_os_write

    # Create an object to serialize
    class FakeObj(object):
        def __init__(self, name):
            self.name = name

    test_object = FakeObj('foo')

    # Stub out os.read
    os_read = os.read

    def fake_os_read(fd, count):
        return data_written.pop(0)

    os.read = fake_os_read



# Generated at 2022-06-22 22:34:46.406219
# Unit test for function exec_command
def test_exec_command():
    module = type('', (), dict(params=dict(socket_path='/foo'), _socket_path='/foo'))
    assert exec_command(module, '') == (0, '', '')



# Generated at 2022-06-22 22:34:51.133455
# Unit test for method send of class Connection
def test_Connection_send():
    current_dir = os.path.dirname(__file__)
    fake_socket_path = os.path.join(
        current_dir, 'test_data/test_connection_send.sock'
    )
    data = 'This is a test string'
    expected_response = 'test_response'
    connection = Connection(fake_socket_path)
    response = connection.send(data)
    assert response == expected_response

# Generated at 2022-06-22 22:35:01.700397
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from io import BytesIO
    from tempfile import NamedTemporaryFile

    for data in [
            dict(
                stdout='foo\n',
                stderr='bar\n',
                rc=0,
            ),
            dict(
                stdout=None,
                stderr=None,
                rc=4,
            ),
        ]:
        for fd in [
                BytesIO(),
                NamedTemporaryFile(delete=False),
            ]:
            write_to_file_descriptor(fd, data)
            fd.flush()

            fd.seek(0)

            length = to_text(fd.readline().strip(), errors='surrogate_or_strict')
            length = int(length)

            copied_data = cPickle.load(fd)

            assert copied

# Generated at 2022-06-22 22:35:08.469855
# Unit test for function recv_data
def test_recv_data():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind("/tmp/socket_connection_test")
    sf.listen(1)
    client, addr = sf.accept()

    data = "Test"

    # Sending data using send_data function
    send_data(client, data)

    # recv_data returns data and assert that data len is equal to 4 bytes
    data_recv = recv_data(client)
    assert len(data_recv) == 4

# Generated at 2022-06-22 22:35:18.393566
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from tempfile import mkstemp
    test_obj = dict(x=42)

    try:
        fd, name = mkstemp()
        os.close(fd)
        # Note that we're not using the file descriptor.  This is
        # because we want to test this in a unit test which will
        # exercise more code paths than using the actual file
        # descriptor.

        with open(name, 'wb') as f:
            write_to_file_descriptor(f.fileno(), test_obj)

        with open(name, 'rb') as f:
            contents = f.read()
    finally:
        os.unlink(name)

    # Used to have a regexp here, but it started matching the
    # string for object 3, which was found in the wild.


# Generated at 2022-06-22 22:35:27.089774
# Unit test for function recv_data
def test_recv_data():
    data = '{"jsonrpc": "2.0", "method": "run_command", "id": "41f8efb6-c2a6-443d-b0e8-b7f0b0f33d7c"}'
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('/tmp/node_manager.sock')
    send_data(sf, to_bytes(data))
    response = recv_data(sf)
    assert response
    sf.close()



# Generated at 2022-06-22 22:35:32.125513
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    error = ConnectionError(
        'unable to connect to socket %s. See the socket path issue category in '
        'Network Debug and Troubleshooting Guide')

    assert error.message == 'unable to connect to socket %s. See the socket path issue category in ' \
                            'Network Debug and Troubleshooting Guide'



# Generated at 2022-06-22 22:35:43.380161
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """Testcase for function write_to_file_descriptor.

    This uses a pipe and a forked subprocess to test the function.
    """
    import subprocess
    import tempfile
    import time

    r_fd, w_fd = os.pipe()

    # open a separate write pipe from the parent process
    # write_to_file_descriptor will write data to the read end of this pipe
    # and this test will check that the data is written properly
    sub_w_fd = os.fdopen(w_fd, 'w')

    # start a child process to read the pipe
    p = subprocess.Popen([__file__, str(r_fd)], stdout=subprocess.PIPE)

    # open a separate read pipe to the child process
    # the child process will write data to the write end

# Generated at 2022-06-22 22:35:50.371748
# Unit test for method send of class Connection
def test_Connection_send():
    content = "some data"

    class MockSocket(object):
        def connect(self, path):
            self.path = path

        def sendall(self, data):
            assert len(data) == len(content) + 8  # 8 bytes of length
            assert data[8:] == content

        def close(self):
            pass

        def recv(self, length):
            return content

    def mocked_recv_data(s):
        return s.recv(len(content))

    conn = Connection("mockpath")
    conn.send_data = send_data
    conn.recv_data = mocked_recv_data
    conn.socket_class = MockSocket
    conn.send(content)
    assert content == conn.send(content)

# Generated at 2022-06-22 22:36:02.659828
# Unit test for function recv_data
def test_recv_data():
    # Test 1: Simple test
    test_data = struct.pack('!Q', len(b'Test Data')) + b'Test Data'
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(os.path.join(os.path.dirname(__file__), "recv_data.sock"))
    s.sendall(test_data)
    assert recv_data(s) == b'Test Data'
    s.close()

    # Test 2: Test for multiple packets
    test_data = (struct.pack('!Q', len(b'Test')) + b'Test' +
                 struct.pack('!Q', len(b' Data')) + b' Data')

# Generated at 2022-06-22 22:36:05.105784
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    tests = [
        (ConnectionError(u'unicode'), u'unicode'),
        (ConnectionError('str'), u'str'),
        (ConnectionError(b'bytestring'), u'bytestring'),
        (ConnectionError(b'bytestring'.decode('utf-8')), u'bytestring'),
    ]

    for t in tests:
        assert t[0].message == t[1]


# Generated at 2022-06-22 22:36:10.604774
# Unit test for function recv_data
def test_recv_data():
    # Size of data, max size of unsigned long long
    MAX_SIZE = 8 * (1 << 30)

    # Import socket module that has been mocked
    import test.connection_util
    data1 = 'teststring1'
    data2 = 'teststring2'
    data = data1 + data2

    # Mock socket object
    class MockSocket(object):
        def __init__(self):
            self._mock_data = bytes()
            self._mock_sent = 0
        def recv(self, size):
            if size > len(self._mock_data):
                return None
            tmp = self._mock_data[:size]
            self._mock_data = self._mock_data[size:]
            return tmp

# Generated at 2022-06-22 22:36:21.070068
# Unit test for function request_builder
def test_request_builder():
    # Test w/o params
    req = request_builder('test1')
    assert req == {
        'jsonrpc': '2.0',
        'method': 'test1',
        'id': req['id'],
        'params': ((), {})
    }

    # Test w/ positional args
    req = request_builder('test1', 1, 2, 3)
    assert req == {
        'jsonrpc': '2.0',
        'method': 'test1',
        'id': req['id'],
        'params': ((1, 2, 3), {})
    }

    # Test w/ args and kwargs
    req = request_builder('test1', 1, 2, 3, param1=4, param2='foo')

# Generated at 2022-06-22 22:36:32.461373
# Unit test for constructor of class Connection
def test_Connection():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader

    play_context = PlayContext()
    new_stdin = None
    new_stdout = None
    def dummy_injector(**kwargs):
        pass

    fake_inventory = Host('fakehost')
    fake_inventory.set_variable('ansible_connection', 'network_cli')

    network_cli = connection_loader.get('network_cli', play_context, fake_inventory)
    try:
        network_cli.connection._connect()
    except AttributeError:
        pass
    if hasattr(network_cli, '_socket_path'):
        assert isinstance(network_cli.connection, Connection)

# Generated at 2022-06-22 22:36:44.733950
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    # test all valid cases
    class A(Connection):
        def __init__(self):
            self.socket_path = '/tmp/socket'

        def valid_method(self, a, b=2, c=3):
            pass

        def valid_method_1(self, **kwargs):
            pass

        def valid_method_2(self, *args):
            pass

    a = A()
    a.valid_method(1)
    a.valid_method(1, 2)
    a.valid_method(1, 2, 3)
    a.valid_method_1(a='a')
    a.valid_method_2(1, 2, 3)

    # test invalid case where the method is not valid
    class B(Connection):
        def __init__(self):
            pass


# Generated at 2022-06-22 22:36:54.706662
# Unit test for function request_builder
def test_request_builder():
    # Validate Default Args
    req = request_builder('method', 'arg1', 'arg2')
    assert req == dict(jsonrpc='2.0', method='method', id=req['id'], params=('arg1', 'arg2'))
    
    # Validate Keyword Args
    req = request_builder('method', 'arg1', 'arg2', param1='arg3', param2='arg4')
    assert req == dict(jsonrpc='2.0', method='method', id=req['id'], params=('arg1', 'arg2'), param1='arg3', param2='arg4')

    # Validate No Args
    req = request_builder('method')
    assert req == dict(jsonrpc='2.0', method='method', id=req['id'], params=())

# Generated at 2022-06-22 22:37:07.655704
# Unit test for method send of class Connection
def test_Connection_send():

    import select

    server_socket_path = '/tmp/server_socket'
    client_socket_path = '/tmp/client_socket'
    data = {"foo": "bar"}

    try:
        os.remove(server_socket_path)
    except OSError:
        pass

    try:
        os.remove(client_socket_path)
    except OSError:
        pass

    ss = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    ss.bind(server_socket_path)
    ss.listen(1)

    connection = Connection(client_socket_path)
    connection.send(json.dumps(data))

    r, _, _ = select.select([ss], [], [])
    conn, _ = ss.accept()

    header = b

# Generated at 2022-06-22 22:37:10.730997
# Unit test for function exec_command
def test_exec_command():
    assert exec_command({'_socket_path': '/tmp/blah'}, 'ls') == (0, '', '')

# Generated at 2022-06-22 22:37:16.844296
# Unit test for function send_data
def test_send_data():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('/tmp/ansible_conn_test')
    data = '{"jsonrpc": "2.0", "method": "exec_command", "id": "fdasfdasfdasfdsafd", "params": ["show version"]}'
    send_data(sf, data)
    sf.close()



# Generated at 2022-06-22 22:37:19.525523
# Unit test for method send of class Connection
def test_Connection_send():
    data = "Testing Connection send"
    s = Connection("/tmp/ansible_test")
    test_data = s.send(data)
    assert test_data == data



# Generated at 2022-06-22 22:37:20.959365
# Unit test for function send_data
def test_send_data():
    func = globals()['send_data']
    assert func(None, None) == None



# Generated at 2022-06-22 22:37:23.010063
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    module = _create_module()
    connection = Connection('/tmp/testfile')
    assert connection._exec_jsonrpc is not None



# Generated at 2022-06-22 22:37:29.329400
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    socket_path = os.path.dirname(__file__) + "/ansible_connection.sock"
    connection = Connection(socket_path)
    
    # test a method that exists
    test_method = "_exec_jsonrpc"
    assert connection.__getattr__(test_method) != None

    # test a method that doesn't exist
    test_method = "test_method"
    assert connection.__getattr__(test_method) == None


# Generated at 2022-06-22 22:37:38.692974
# Unit test for function request_builder
def test_request_builder():
    req = request_builder(method_='do_something',
                          args=(1,2,),
                          kwargs={'key1': 'value1',
                                  'key2': 'value2'})
    assert req == {'jsonrpc': '2.0',
                   'method': 'do_something',
                   'id': str(uuid.uuid4()),
                   'params': ((1, 2,),
                              {'key1': 'value1',
                               'key2': 'value2'})}

# Generated at 2022-06-22 22:37:45.720774
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('/tmp/test_send_data')
    s.listen(1)

    conn, addr = s.accept()
    data = recv_data(conn)

    assert data == b'12345678'
    conn.close()
    s.close()

    os.unlink('/tmp/test_send_data')

# Generated at 2022-06-22 22:37:49.857130
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('xxxx', code=7)
    except ConnectionError as exc:
        assert exc.message == 'xxxx'
        assert exc.code == 7



# Generated at 2022-06-22 22:37:59.015599
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('\0test_send_data')
    s.listen(1)

    t = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    t.connect('\0test_send_data')

    data = os.urandom(1024)

    thread.start_new_thread(send_data, (s, data))
    data_received = recv_data(t)

    assert data == data_received

# Generated at 2022-06-22 22:38:05.249118
# Unit test for constructor of class Connection
def test_Connection():
    from ansible.errors import AnsibleConnectionFailure
    socket_file = '/tmp/ansible_test_file'
    # use of assertRaises as a Context Manager
    with open(socket_file, 'w+') as f:
        f.write('hi')
    with pytest.raises(AnsibleConnectionFailure):
        Connection(socket_file)

# Generated at 2022-06-22 22:38:15.403474
# Unit test for function recv_data
def test_recv_data():
    from ansible.module_utils.basic import AnsibleModule
    # Test case 1
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("www.google.com", 80))
    sock.sendall(to_bytes('POST / HTTP/1.1\r\n\r\n'))
    ret = recv_data(sock)
    sock.close()
    assert ret is not None

    # Test case 2
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("www.google.com", 80))
    sock.sendall(to_bytes('POST / HTTP/1.1\r\n\r\n'))

# Generated at 2022-06-22 22:38:24.009983
# Unit test for method send of class Connection
def test_Connection_send():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        send_multiple = b'hello world\n'
        conn = Connection("/tmp/ansible_test_socket")
        actual = conn.send(send_multiple)
        assert str(actual) == 'world'

        send_single = b'world'
        conn = Connection("/tmp/ansible_test_socket")
        actual = conn.send(send_single)
        assert str(actual) == 'world'
    finally:
        sf.close()


# Generated at 2022-06-22 22:38:27.550531
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    excep = ConnectionError('test', err='test error', code=10)
    assert excep.err == 'test error'
    assert excep.code == 10

# Generated at 2022-06-22 22:38:32.148230
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    con = Connection('socket')
    assert con.__getattr__('exec_command')
    assert con.__getattr__('_exec_jsonrpc')
    assert con.__getattr__('_test')



# Generated at 2022-06-22 22:38:41.633577
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    import mock

    connection = Connection(None)

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str'),
        ),
    )

    with mock.patch.object(connection, 'exec_command', return_value=b'{"ansible_facts": {"test": "test"}}'):
        rc, out, err = exec_command(module, 'show version')
        assert rc == 0
        assert err == ''
        assert out == '{"ansible_facts": {"test": "test"}}'

    with mock.patch.object(connection, 'exec_command', side_effect=ConnectionError('failed', code=1)):
        rc, out, err = exec_command

# Generated at 2022-06-22 22:38:43.011882
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    conn = Connection("socket_path")
    assert 'test' in dir(conn)
    assert not hasattr(conn, 'test')

# Generated at 2022-06-22 22:38:45.841364
# Unit test for constructor of class Connection
def test_Connection():
    con = Connection("/etc/ansible/ansible.cfg")
    assert con != None

# Generated at 2022-06-22 22:38:48.565381
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    conn_obj = Connection(socket_path=None)
    res = conn_obj.__rpc__('get_option', 'host')
    assert isinstance(res, dict)



# Generated at 2022-06-22 22:38:57.652803
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(command):
        return exec_command(AnsibleModule(argument_spec={}), command)

    rc, out, err = run_command('echo "foo"')
    assert rc == 0, rc
    assert out == "foo\n", out

    rc, out, err = run_command('exit 1')
    assert rc == 1, rc
    assert out == "", out

    rc, out, err = run_command('echo "foo""\r"')
    assert rc == 0, rc
    assert out == "foo\r", out

    rc, out, err = run_command('return_error() { echo "$1"; exit 1; }; return_error "foo\r"; echo "bar"')
    assert rc == 1, rc
    assert out

# Generated at 2022-06-22 22:39:00.108830
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('get_option', 'foo')
    assert req['method'] == 'get_option'

# Generated at 2022-06-22 22:39:10.506396
# Unit test for function recv_data
def test_recv_data():
    import tempfile
    import shutil

    def _json_rpc_2_0_response(result, id_):
        return '{"result": %s, "id": "%s", "jsonrpc": "2.0"}' % (result, id_)


# Generated at 2022-06-22 22:39:22.960505
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('method_name') == {'id': '0', 'jsonrpc': '2.0', 'method': 'method_name', 'params': ((), {})}

    assert request_builder('method_name', 1) == {'id': '0', 'jsonrpc': '2.0', 'method': 'method_name', 'params': ((1,), {})}

    assert request_builder('method_name', 1, 2, 3) == {'id': '0', 'jsonrpc': '2.0', 'method': 'method_name', 'params': ((1, 2, 3), {})}


# Generated at 2022-06-22 22:39:31.426790
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    try:
        import tempfile
        fd, path = tempfile.mkstemp()
        dummy_obj = {1: 2, 3: [4, 5]}
        write_to_file_descriptor(fd, dummy_obj)
        os.lseek(fd, 0, 0)
        data_len = int(os.read(fd, 4096))
        read_data = os.read(fd, data_len + 4097)  # + 4096 for data, +1 for \n
        out = cPickle.loads(read_data[:data_len])
        assert out == dummy_obj
    finally:
        os.close(fd)
        os.remove(path)



# Generated at 2022-06-22 22:39:34.074568
# Unit test for function exec_command
def test_exec_command():
    module = type('', (), dict(use_proxy=True, proxy_pass='localhost'))

    assert exec_command(module, 'ls') == (0, '', '')

# Generated at 2022-06-22 22:39:37.302388
# Unit test for function send_data
def test_send_data():
    test_str = "str"
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    result = send_data(s, test_str)
    assert isinstance(result, None)


# Generated at 2022-06-22 22:39:49.726641
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():

    (pipein, pipeout) = os.pipe()
    obj = {'a': 'b'}

    write_to_file_descriptor(pipeout, obj)

    os.close(pipeout)

    fd = os.fdopen(pipein)
    rlen = fd.readline()
    rlen = int(rlen.rstrip('\n'))
    obj_str = fd.read(rlen)
    obj_hash = fd.readline().rstrip('\n')
    fd.close()

    assert obj_hash == hashlib.sha1(obj_str).hexdigest()

    # The pickle needs to be decoded as base64 to be converted to py3k
    obj_b64 = to_bytes(obj_str).decode('base64')

    # Provide the

# Generated at 2022-06-22 22:39:54.139408
# Unit test for function request_builder
def test_request_builder():
    # test without kwargs
    req = request_builder('test')
    assert req['method'] == 'test'
    assert req['id'] != ''

    # test with kwargs
    req = request_builder('test', **{'arg1': 'arg1'})
    assert req['method'] == 'test'
    assert req['id'] != ''
    assert req['params'][1]['arg1'] == 'arg1'


# Generated at 2022-06-22 22:40:00.604252
# Unit test for function send_data
def test_send_data():
    try:
        sock1, sock2 = socket.socketpair(socket.AF_UNIX)
        sock1.settimeout(1)
        sock2.settimeout(1)

        test_data = b"Hello World"
        send_data(sock2, test_data)
        received_data = recv_data(sock1)

        assert received_data == test_data, "Received Data is not equal to the Sent Data"
    finally:
        if sock1:
            sock1.close()
        if sock2:
            sock2.close()

# Generated at 2022-06-22 22:40:10.367924
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('open_shell')
    assert req['id'] is not None, 'id field not set'
    assert req['method'] == 'open_shell', 'method field not set'
    assert req['params'] == ((), {}), 'params field not set'
    assert req['jsonrpc'] == '2.0', 'jsonrpc field not set'

    req = request_builder('send', 'hello')
    assert req['params'] == (('hello',), {}), 'params failed to set'

    req = request_builder('close', 'myarg', arg2='myvalue')
    assert req['params'] == (('myarg',), {'arg2': 'myvalue'}), 'params failed to set'

# Generated at 2022-06-22 22:40:11.010365
# Unit test for constructor of class Connection
def test_Connection():
    pass

# Generated at 2022-06-22 22:40:13.048745
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection(None)
    assert connection.__getattr__ == None


# Generated at 2022-06-22 22:40:25.527738
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Test jsonrpc which executes successfully
    test_obj = Connection('tests')
    test_json = {
        "jsonrpc": "2.0",
        "result": {
            "stdout": "",
            "stdout_lines": []
        },
        "id": "b7a664f8-407f-4270-a71d-84d6a0b0a693"
    }
    test_obj._exec_jsonrpc = lambda x, *args, **kwargs: test_json
    result = test_obj.__rpc__('test_name')
    assert result == test_json['result']

    # Test jsonrpc which fails

# Generated at 2022-06-22 22:40:26.458537
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    pass

# Generated at 2022-06-22 22:40:31.198264
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.connection import Connection
    conn = Connection("my_socket_path")
    try:
        conn._Connection__rpc__("name", "arg1", arg2=5)
    except AttributeError:
        assert True
    except:
        assert False


# Generated at 2022-06-22 22:40:40.797969
# Unit test for function request_builder
def test_request_builder():
    expected_return_value = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "id": "8ceecd5e-d9dc-47e5-bc14-e44fb5fc5c5a",
        "params": ([], {})
    }
    assert expected_return_value == request_builder('test_method')

    expected_return_value = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "id": "57e0e837-6bd9-4ab4-b4c4-822a6d42f309",
        "params": (("arg1",), {})
    }
    assert expected_return_value == request_builder('test_method', "arg1")

    expected_

# Generated at 2022-06-22 22:40:44.347080
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection_obj = Connection(socket_path='/tmp/path/to/socket')
    method = connection_obj.exec_command
    assert method('ansible')

# Generated at 2022-06-22 22:40:54.069830
# Unit test for method send of class Connection
def test_Connection_send():
    data = 'hello world'
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind('/tmp/unix-domain-test.sock')
    sock.listen(1)
    connection = Connection('/tmp/unix-domain-test.sock')
    response = connection.send(data)
    conn, address = sock.accept()
    conn.settimeout(1)
    data = recv_data(conn)
    try:
        assert to_text(data) == to_text(data)
    except AssertionError:
        raise AssertionError('Test of send() in Connection class failed')
    finally:
        conn.close()
        os.remove('/tmp/unix-domain-test.sock')

# Generated at 2022-06-22 22:40:56.401696
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    c = Connection('test.test')
    assert(c.test('test') == "test_test")



# Generated at 2022-06-22 22:40:58.684120
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection('/var/test/test.sock')
    assert conn.send('test') == 'test'

# Generated at 2022-06-22 22:41:07.141795
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    # create a pipe to test
    rd, wr = os.pipe()

    # send a dummy object
    obj = 42
    write_to_file_descriptor(wr, obj)

    # fetch the data from the pipe
    data = os.read(rd, 1024)

    # parse the data
    data_len, data_hash = data.split(b'\n')
    data_len = int(data_len)
    data = os.read(rd, data_len)

    # test the data
    assert obj == cPickle.loads(data)
    assert data_hash == hashlib.sha1(data).hexdigest().encode()

# Generated at 2022-06-22 22:41:12.172793
# Unit test for method send of class Connection
def test_Connection_send():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind("./tmp_socket")
    s.listen(1)

    conn = Connection("./tmp_socket")
    data = "TEST"

    try:
        assert conn.send(data) == data
    finally:
        s.close()
        os.unlink("./tmp_socket")

# Generated at 2022-06-22 22:41:14.432865
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = "/tmp/ansible-conn-test-sock"
    conn = Connection(socket_path)
    assert conn.socket_path == socket_path

# Generated at 2022-06-22 22:41:21.977475
# Unit test for method send of class Connection

# Generated at 2022-06-22 22:41:32.089101
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile

    class Args:
        data = {'test': 'data'}

    r, w = os.pipe()

    os.set_inheritable(w, True)

    a = Args()
    write_to_file_descriptor(w, a)

    os.close(w)

    with os.fdopen(r) as f:
        data_length_str = f.readline().strip()
        data_length = int(data_length_str)
        data = f.read(data_length)
        received_hash = f.readline().strip()

    received = cPickle.loads(data)

    assert(received.data == a.data)

    src = cPickle.dumps(a, protocol=0)

    # raw \r characters will not survive pty round-

# Generated at 2022-06-22 22:41:41.269724
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('foo', 1, 2, key=4, moose="socks") == {
        "jsonrpc": "2.0",
        "method": "foo",
        "id": request_builder.reqid,
        "params": ((1, 2), {"moose": "socks", "key": 4})
    }
    assert request_builder('foo', key=4, moose="socks") == {
        "jsonrpc": "2.0",
        "method": "foo",
        "id": request_builder.reqid,
        "params": ((), {"moose": "socks", "key": 4})
    }

# Generated at 2022-06-22 22:41:51.954334
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', 0))
    s.listen(1)

    port = s.getsockname()[1]
    s_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s_client.connect(('localhost', port))

    s_server, addr = s.accept()

    send_data(s_client, to_bytes('data'))
    data = recv_data(s_server)
    assert data == to_bytes('data')

    send_data(s_client, to_bytes('0123456789'))
    data = recv_data(s_server)
    assert data == to_bytes('0123456789')

    s_server

# Generated at 2022-06-22 22:42:03.253472
# Unit test for function send_data
def test_send_data():
    import socket
    import select
    import threading
    import random

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('', 0))

    def dummy_server():
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(('127.0.0.1', sock.getsockname()[1]))
        while True:
            try:
                select.select([s], [], [])
            except:
                return
            try:
                recv_data(s)
            except:
                return
            s.sendall(b'OK')

    sock.listen(1)

    t = threading.Thread(target=dummy_server)
    t.setDaemon(True)


# Generated at 2022-06-22 22:42:09.422627
# Unit test for function recv_data
def test_recv_data():
    import socket
    import threading
    import time

    data_from_server = b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 5\r\n\r\nhello'

    class ServerThread(threading.Thread):
        def run(self):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind(('', 0))
            s.listen(1)
            conn, addr = s.accept()
            time.sleep(0.01)
            conn.sendall(data_from_server)
            conn.close()

    t = ServerThread()
    t.start()

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client

# Generated at 2022-06-22 22:42:19.102192
# Unit test for method send of class Connection
def test_Connection_send():
    import tempfile
    import threading
    from time import sleep

    def read_from_socket(sock_path):
        # Create an accepter thread to accept the connection
        s_thread = threading.Thread(target=accepter, args=(sock_path,))
        s_thread.start()

        # Wait for the accepter to start
        sleep(0.5)

        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sf.connect(sock_path)

        send_data(sf, b"Hello")
        response = recv_data(sf)

        sf.close()

        return response


# Generated at 2022-06-22 22:42:29.799258
# Unit test for function recv_data
def test_recv_data():
    class FakeSocket(object):
        def __init__(self, bytes_to_send):
            self.bytes_to_send = bytes_to_send
            self.bytes_sent = 0

        def recv(self, nbytes):
            if self.bytes_sent == len(self.bytes_to_send):
                return None
            if self.bytes_sent > len(self.bytes_to_send):
                raise RuntimeError("unexpected read of bytes")
            if self.bytes_sent + nbytes > len(self.bytes_to_send):
                nbytes = len(self.bytes_to_send) - self.bytes_sent

            ret = self.bytes_to_send[self.bytes_sent:self.bytes_sent+nbytes]

            self.bytes_sent += nbytes
            return ret

    # Test

# Generated at 2022-06-22 22:42:42.195548
# Unit test for function send_data
def test_send_data():
    import tempfile
    import threading
    from select import select

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    temp = tempfile.mktemp()
    sf.bind(temp)
    sf.listen(1)


# Generated at 2022-06-22 22:42:45.110939
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("foo")
    except ConnectionError as ce:
        assert ce.message == "foo"
    else:
        raise AssertionError("ConnectionError constructor failed")

# Generated at 2022-06-22 22:42:55.004977
# Unit test for function recv_data
def test_recv_data():
    import socket
    import threading
    import time

    def test_server():
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.bind("/tmp/ansible_test_socket")
        sock.listen(1)
        conn, addr = sock.accept()
        t = recv_data(conn)
        conn.sendall(t)
        conn.close()

    def test_client():
        time.sleep(1)
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect("/tmp/ansible_test_socket")
        msg = "Test Message"
        send_data(sock, msg)
        result = recv_data(sock)
        sock.close()
