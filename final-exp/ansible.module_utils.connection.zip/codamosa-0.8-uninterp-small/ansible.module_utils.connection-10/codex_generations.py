

# Generated at 2022-06-24 21:27:42.102985
# Unit test for function recv_data
def test_recv_data():
    int_0 = -102
    assert var_0 is None


# Generated at 2022-06-24 21:27:49.859522
# Unit test for function recv_data
def test_recv_data():
    with patch('ansible.module_utils.basic.s') as s:
        var_0 = '_socket.socket'
        value = MagicMock(name=var_0)
        s.return_value = value
        var_1 = MagicMock()
        var_1.recv = MagicMock()
        s.return_value.__enter__.return_value = var_1

# Generated at 2022-06-24 21:27:54.936342
# Unit test for function exec_command
def test_exec_command():
    module = AnsibleModule(argument_spec=dict())
    command = 'test_command'
    out_code, out_stdout, out_stderr = exec_command(module, command)
    assert out_code == 0
    assert out_stdout == command
    assert out_stderr == ''

# Generated at 2022-06-24 21:28:06.565220
# Unit test for function recv_data
def test_recv_data():
    import random
    import string

    # this test is specifically for the following cases:
    # - socket.recv returns an empty string (because no data is available)
    #   and this function is able to recover and retrieve all the data sent.
    # - socket.recv does not receive the entire buffer of data at once.
    # - the socket.recv buffer is 1 byte.
    # - all of these cases apply even when the data being sent is 1 byte.

    # this test has the capability to keep track of where in the buffer
    # it is sending data, and what data has been sent, and it can
    # use this to check that all the data was received and that there
    # were no duplicates.

    # the test, however, is not currently configured to work this way.
    # it just sends a random amount of data and verifies that the

# Generated at 2022-06-24 21:28:13.977912
# Unit test for function exec_command
def test_exec_command():
    # Set up mock
    class mock_module:
        _socket_path = 'mock'
    class mock_Connection:
        def exec_command(self, arg):
            return 'mock'
    with patch('ansible.module_utils.connection._load_name_to_connection',
               new_callable=MagicMock(return_value=mock_Connection)) as mock_name_to_conn:
        module = mock_module()
        command = 'mock'

        assert exec_command(module, command) == (0, 'mock', '')

        # Called
        assert mock_name_to_conn.call_count == 1
        # Check the call args
        assert mock_name_to_conn.call_args_list[0][0] == (module, '_socket_path', 'persistent')


# Generated at 2022-06-24 21:28:16.759858
# Unit test for function recv_data
def test_recv_data():
    # Setup
    int_0 = -102
    # Procedure call
    var_0 = recv_data(int_0)


# Generated at 2022-06-24 21:28:21.653080
# Unit test for function exec_command
def test_exec_command():
    module = object
    command =''
    actual = exec_command(module, command)
    expected = (0,'','')
    assert actual == expected, 'Test Failed: exec_command(%r) returned %r' % (command, actual)
    print('Test Success: exec_command(%r) returned %r' % (command, actual))
    return True


# Generated at 2022-06-24 21:28:22.711021
# Unit test for function exec_command
def test_exec_command():
    pass


# Generated at 2022-06-24 21:28:29.454992
# Unit test for function exec_command

# Generated at 2022-06-24 21:28:32.217437
# Unit test for function exec_command
def test_exec_command():
    module = dict()
    module['_socket_path'] = to_bytes('./test_file')
    assert(exec_command(module, 'test command') == (0, '', ''))


# Generated at 2022-06-24 21:28:41.095542
# Unit test for function recv_data
def test_recv_data():
    test_case_0()


# Generated at 2022-06-24 21:28:51.774180
# Unit test for function exec_command
def test_exec_command():

    try:
        import paramiko
        pyssh = True
    except:
        pyssh = False


    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # set up
    if pyssh:
        PAN_CONNECTION_CLASS_PATH = 'ansible.modules.remote_management.panos.panos.Connection'

# Generated at 2022-06-24 21:28:57.005851
# Unit test for function exec_command
def test_exec_command():
    path_0 = (b'/home/nav/ansible-2.5.5/lib/ansible/plugins/connection/ssh')
    module_0 = imp.load_source('unittest_module_name', path_0)
    result = exec_command(module_0, '', '', '')
    print(result)




# Generated at 2022-06-24 21:29:08.280618
# Unit test for function recv_data
def test_recv_data():
    int_0 = 0
    int_1 = 0
    int_2 = 0
    str_0 = None
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_4 = (int_2 + int_3)
    int_0 = (int_2 + int_3)
    int_5 = (int_0 + int_4)
    int_3 = (int_5 + int_1)
    int_2 = (int_3 + int_3)
    int_0 = (int_2 * int_1)
    int_2 = (int_2 - int_3)
    int_5 = (int_0 * int_2)
    int_1 = (int_5 + int_5)
    int_5 = (int_1 + int_4)


# Generated at 2022-06-24 21:29:18.157677
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_1 = -433
    str_1 = "foo"
    str_2 = "bar"
    str_3 = "baz"
    flag_1 = True
    var_1 = request_builder(str_1, *(int_1,), **(str_2, str_3, flag_1))
    var_2 = var_1['id']
    flag_2 = not os.path.exists(int_1)
    if flag_2:
        error_1 = 'socket path %s does not exist or cannot be found. See Troubleshooting socket '
        error_1 += 'path issues in the Network Debug and Troubleshooting Guide' % int_1
        raise Exception(error_1)
    flag_3 = True

# Generated at 2022-06-24 21:29:21.308304
# Unit test for function recv_data
def test_recv_data():
    # Test case 0
    try:
        test_case_0()
    except:
        print('Test case 0 failed:')
        print(traceback.format_exc())

test_recv_data()

# Generated at 2022-06-24 21:29:23.623122
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    var_1 = test_case_0()


if __name__ == '__main__':
    test_Connection___rpc__()

# Generated at 2022-06-24 21:29:28.723029
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_1 = -103
    var_0 = Connection(int_1)
    str_1 = 'exec_command'
    int_2 = -106
    test_case_0()
    int_3 = -105
    var_0.__rpc__(str_1, int_2, int_3)
    assert True



# Generated at 2022-06-24 21:29:39.411608
# Unit test for method send of class Connection
def test_Connection_send():
    if os.path.exists("test_file"):
        os.remove("test_file")
    # Initializing a socket
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    # Binding the socket to the file path
    s.bind("test_file")
    # Listen for connections
    s.listen(1)
    # Accepting connection
    conn, addr = s.accept()
    # Writing data to the connection
    send_data(conn, b'{"jsonrpc": "2.0", "id": "4", "result": "pass"}')
    # Creating connection instance
    conn_instance = Connection("test_file")
    result = conn_instance.send('{"jsonrpc": "2.0", "id": "4", "result": "pass"}')
   

# Generated at 2022-06-24 21:29:50.751403
# Unit test for method send of class Connection
def test_Connection_send():
    print("Unit test for method send of class Connection")
    int_0 = -102
    var_0 = recv_data(int_0)
    var_0 = cPickle.loads(to_bytes(var_0))
    sw_0 = var_0.get("switch")
    var_0 = sw_0.get("name")
    var_0 = var_0.split(".")
    var_0 = var_0[0]
    socket_path = var_0
    sw_0 = var_0.get("switch")
    var_0 = sw_0.get("name")
    var_0 = var_0.split(".")
    var_0 = var_0[1]
    uut_ip = var_0
    sw_0 = var_0.get("switch")
    var_0

# Generated at 2022-06-24 21:30:07.893895
# Unit test for function recv_data
def test_recv_data():
    data = to_bytes("")
    try:
        with open('../fixtures/unit/modules/unit_test_data.dat', 'rb') as infile:
            to_bytes(infile.read())
    except IOError:
        print("Error opening file")
        return False

    try:
        with open('../fixtures/unit/modules/unit_test_data.dat', 'rb') as infile:
            var_0 = infile.read()
    except IOError:
        print("Error opening file")
        return False

    test_case_0()
    return True


# Generated at 2022-06-24 21:30:10.016210
# Unit test for function recv_data
def test_recv_data():
    # Case 0
    var_0 = -102
    assert test_case_0() == None


# Generated at 2022-06-24 21:30:17.971995
# Unit test for function exec_command
def test_exec_command():
    # Unit test to determine if the exec_command function returns an error code, an output and a empty error message

    socket_path = '/tmp/ansible_test_socket'
    module = MockModule(socket_path)
    module.add_cmd_output(
        '/usr/bin/ansible -m setup -a "filter=ansible_distribution*" localhost',
        '{ "msg": "Hello World !" }'
    )
    code, out, err = exec_command(module, '/usr/bin/ansible -m setup -a "filter=ansible_distribution*" localhost')

    assert code == 0
    assert '{"msg": "Hello World !"}' in out
    assert err == ''


# Generated at 2022-06-24 21:30:19.339597
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    """Test method Connection.__rpc__"""
    with pytest.raises(ConnectionError) as exc_info:
        test_case_0()


# Generated at 2022-06-24 21:30:20.664808
# Unit test for function recv_data
def test_recv_data():
    int_0 = -102
    var_0 = recv_data(int_0)
    assert var_0 == None


# Generated at 2022-06-24 21:30:28.530182
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    #
    # Test case
    #
    class Test_Connection___rpc__(Connection):
        def __rpc__(self, name, *args, **kwargs):
            if len(args) == 0 and len(kwargs) == 1 and name == 'exec_command' and 'command' in kwargs:
                return kwargs['command']

    def test_case_0():
        var_0 = Connection('/dev/tty')
        var_1 = var_0.exec_command('test_command')
        assert var_1 == 'test_command'

    def test_case_1():
        var_2 = Test_Connection___rpc__('/dev/tty')
        var_3 = var_2.exec_command('test_command')
        assert var_3 == 'test_command'


# Generated at 2022-06-24 21:30:29.905315
# Unit test for function recv_data
def test_recv_data():
    int_0 = -102
    test_case_0()


# Generated at 2022-06-24 21:30:36.517336
# Unit test for function recv_data
def test_recv_data():
    arg_0 = 0
    try:
        recv_data(arg_0)
    except ValueError as exc:
        if str(exc) == 'unpack requires a buffer of 8 bytes':
            pass
        else:
            raise AssertionError('Unexpected exception raised: %s' % exc)
    except Exception as exc:
        raise AssertionError('Unexpected exception raised: %s' % exc)

# Generated at 2022-06-24 21:30:46.732979
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    data = 'JTdCJTIycGF5bG9hZCUyMjolMjJleGVjX2NvbW1hbmQlMjIsJTIycGF5bG9hZF9uYW1lJTIyOiUyMCUyMnRlc3RfY2FzZV8xJTIyLCUyMmFyZ3MlMjI6JTIwWyUyMCUyMmZvbyUyMCUyMCUyMCUyMF0lMjIsJTIyZG9fc2ltdWxhdGUlMjIlM0EwJTdE'
    fd = open('symbolic_file_name', 'w+')

# Generated at 2022-06-24 21:30:48.137155
# Unit test for function recv_data
def test_recv_data():
    var_0 = 1
    test_case_0()


# Generated at 2022-06-24 21:30:57.967987
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = -102
    var_0 = recv_data(int_0)


# Generated at 2022-06-24 21:30:59.643724
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    conn = Connection()
    response = conn.__rpc__("name", *args, **kwargs)

# Generated at 2022-06-24 21:31:10.946514
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    mod = None
    req = (None,)
    reqid = False
    response = None
    reqid = False
    err = None
    msg = None
    code = None
    # try/catch block

# Generated at 2022-06-24 21:31:16.453218
# Unit test for function exec_command
def test_exec_command():
    ansible_socket_path_val = '/tmp/ansible-connection/ansible-connection-test.sock'
    ansible_module_command_val = 'show version'
    test_0 = exec_command(ansible_socket_path_val, ansible_module_command_val)
    assert test_0 == 0, "exec_command did not return expected value 0"


if __name__ == "__main__":
    test_exec_command()

# Generated at 2022-06-24 21:31:19.586128
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    instance_0 = Connection(None)
    try:
        var_0 = instance_0.send(None)
    except ConnectionError as error_0:
        print(error_0.message)
        print(' '.join(error_0.args))


# Generated at 2022-06-24 21:31:22.315986
# Unit test for function exec_command
def test_exec_command():
    module = object
    module._socket_path = "/tmp/ansible_wah8WL"

    command = "command"

    got = exec_command(module, command)

    assert(got == (0, '', ''))


# Generated at 2022-06-24 21:31:24.721912
# Unit test for method send of class Connection
def test_Connection_send():
    validate_Connection_send()
    test_Connection_send_0()


# Generated at 2022-06-24 21:31:29.388277
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = -102

    # Creation of the object 'Connection'
    obj_0 = Connection(int_0)

    # Calling method __rpc__ of object 'Connection' for Name '_'
    test_Connection___rpc__._0 = obj_0.__rpc__("_")



# Generated at 2022-06-24 21:31:31.387580
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    inst_0 = Connection('/tmp/ansible_dlaI4n')
    inst_0.__rpc__('close')


# Generated at 2022-06-24 21:31:34.584264
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_provider
    my_obj = Connection(AnsibleModule(argument_spec={}))
    module = load_provider(None, {}, {'transport': 'cli'})
    res = my_obj.__rpc__('_exec_jsonrpc', module, ['show version'])


# Generated at 2022-06-24 21:31:47.921806
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_1 = -102
    var_0 = test_case_0()
    var_2 = None
    var_1 = send_data(int_1, var_0)

    assert var_1 is None
    assert var_2 is None



# Generated at 2022-06-24 21:31:55.818401
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class_1 = Connection('/home/user/ansible/test/ansible_connection.py')
    str_0 = 'test_Connection___rpc__'
    int_0 = 0
    try:
        method_0 = class_1.__rpc__
        class_1.__rpc__(str_0, int_0)
    except ConnectionError as inst_0:
        var_0 = inst_0.code
        var_1 = inst_0.err
        var_2 = inst_0.message
        var_3 = inst_0.exception


# Generated at 2022-06-24 21:31:57.430818
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_1 = -103
    var_1 = recv_data(int_1)


# Generated at 2022-06-24 21:31:58.974343
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    a = Connection("")
    msg = a.__rpc__("")


# Generated at 2022-06-24 21:31:59.993792
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    pass


# Generated at 2022-06-24 21:32:01.763142
# Unit test for function recv_data
def test_recv_data():
    parameter_0 = -37
    var_0 = recv_data(parameter_0)



# Generated at 2022-06-24 21:32:09.410133
# Unit test for function recv_data
def test_recv_data():
    print("Testing function recv_data")
    try:
        test_case_0()
        print("Test case 0 passed.")
    except SystemExit:
        pass
    except:
        print("Test case 0 failed.")

# Global variables
json_0 = {
    "jsonrpc": "2.0",
    "id": str(uuid.uuid4()),
    "method": "exec_command",
    "params": (["show version"])
}

json_1 = {
    "jsonrpc": "2.0",
    "id": str(uuid.uuid4()),
    "method": "get_option",
    "params": (["persistent_command_timeout"])
}


# Generated at 2022-06-24 21:32:11.557661
# Unit test for function exec_command
def test_exec_command():
    testobj = Connection(module._socket_path)
    testobj.exec_command('test')

# Generated at 2022-06-24 21:32:14.856225
# Unit test for function exec_command
def test_exec_command():
    module = {"_socket_path": "/path/to/ansible/socket"}
    command = "do stuff"

    out = exec_command(module, command)
    print(out)


# Generated at 2022-06-24 21:32:16.331631
# Unit test for function recv_data
def test_recv_data():
    assert recv_data(0) == None


# Generated at 2022-06-24 21:32:34.713389
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = -102
    var_0 = recv_data(int_0)
    test_1 = "This is a test"
    str_0 = test_case_0()
    test_2 = json.dumps(test_1)
    test_3 = "This is a test"
    str_1 = test_case_0()
    test_4 = json.dumps(test_3)
    test_5 = "This is a test"
    str_2 = test_case_0()
    test_6 = json.dumps(test_5)
    # Test case:
    int_1 = -102
    var_1 = recv_data(int_0)


# Generated at 2022-06-24 21:32:37.261138
# Unit test for function recv_data
def test_recv_data():
    # test case 0
    try:
        test_case_0()
    except Exception as exc:
        print(exc)
        return False

    return True


# Generated at 2022-06-24 21:32:40.408130
# Unit test for function recv_data
def test_recv_data():
    int_0 = -102
    var_0 = recv_data(int_0)
    assert isinstance(var_0, bytes), "Error in unit test for recv_data"


# Generated at 2022-06-24 21:32:46.943170
# Unit test for method send of class Connection
def test_Connection_send():
    print("Testing Connection.send")
    obj = Connection("/tmp/ansible_22CbEK/.ansible_module_generated_socket_path.socket")
    var_0 = obj.send("+-1")
    print("Result: " + var_0)
    print("Success!")



# Generated at 2022-06-24 21:32:49.684010
# Unit test for function recv_data
def test_recv_data():
    print("")
    print("Unit test for function recv_data")
    print("==========================================")
    test_case_0()
    print("==========================================")


# Generated at 2022-06-24 21:32:58.210508
# Unit test for function recv_data
def test_recv_data():
    arg0 = 0
    arg1 = 0
    arg2 = 0
    arg3 = 0

    with patch("ansible.module_utils.basic.ansible_module.send_data", return_value="") as mock_send_data:
        with patch("ansible.module_utils.basic.ansible_module.recv_data", return_value="") as mock_recv_data:
            test_case_0()
            mock_send_data.assert_called_with(arg0, arg1)
            mock_recv_data.assert_called_with(arg2, arg3)


# Generated at 2022-06-24 21:33:05.052469
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    var_2 = None
    var_2 = Connection(var_2)
    var_5 = var_2.__rpc__("exec_command", var_4, var_5, var_5)
    var_5 = var_2.__rpc__("exec_command", var_4, var_5, var_5)
    var_3 = var_2.write_to_file_descriptor(var_0, var_3)
    test_case_2()


# Generated at 2022-06-24 21:33:06.283506
# Unit test for function recv_data
def test_recv_data():

    # Test case #0
    yield test_case_0



# Generated at 2022-06-24 21:33:11.324465
# Unit test for function recv_data
def test_recv_data():

    # Create a socket object
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Define the port on which you want to connect
    port = 1026

    # connect to the server on local computer
    s.connect(('127.0.0.1', port))

    # receive data from the server
    print(s.recv(1024))
    # close the connection
    s.close()

# Generated at 2022-06-24 21:33:14.739638
# Unit test for method send of class Connection
def test_Connection_send():
    connection = Connection(os.path.expanduser('~/.ansible/pc'))
    try:
        connection.send(None)
    except Exception as e:
        return
    assert False, 'An exception was not thrown'


# Generated at 2022-06-24 21:33:32.770209
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test_case_0()


# Generated at 2022-06-24 21:33:36.599163
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = -102
    var_1 = Connection(int_0)
    bytes_0 = b''
    var_2 = var_1.__rpc__(bytes_0)

if (__name__ == '__main__'):
    test_case_0()
    test_Connection___rpc__()

# Generated at 2022-06-24 21:33:47.230046
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.connection import Connection
    int_0 = -102
    var_0 = Connection(int_0)
    int_1 = 8645
    int_2 = 8645
    int_3 = 8645
    int_4 = 8645
    int_5 = 8645
    int_6 = 8645
    int_7 = 8645
    int_8 = 8645
    int_9 = 8645
    int_10 = 8645
    int_11 = 8645
    int_12 = 8645
    int_13 = 8645
    int_14 = 8645
    int_15 = 8645
    int_16 = 8645

# Generated at 2022-06-24 21:33:48.778249
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # tests will be constructed here
    pass



# Generated at 2022-06-24 21:33:49.809778
# Unit test for function exec_command
def test_exec_command():
    assert exec_command() == 0


# Generated at 2022-06-24 21:33:56.536998
# Unit test for function exec_command
def test_exec_command():
    test_command = "test_command"
    module = type('', (), {'_socket_path': None})()
    code, stdout, stderr = exec_command(module, test_command)
    if code != 0:
        print("exec_command error")
        exit(1)
    if not stdout:
        print("exec_command error")
        exit(1)


# Generated at 2022-06-24 21:34:00.774462
# Unit test for function recv_data
def test_recv_data():
    var_1 = []
    var_2 = 0
    while var_2 < 5:
        var_0 = test_case_0()
        var_1.append(var_0)
        var_2 = var_2 + 1
    return var_1



# Generated at 2022-06-24 21:34:02.054863
# Unit test for function exec_command
def test_exec_command():
    pass


# Generated at 2022-06-24 21:34:08.147170
# Unit test for method send of class Connection
def test_Connection_send():
    connection = Connection("/home/user/desktop/ansible")
    data = "hello world!"
    try:
        connection.send(data)
    except ConnectionError as err:
        print("ConnectionError: ", err.code, err.err)
    else:
        print("sucessfully sent data")

if __name__ == '__main__':
    test_Connection_send()
    test_case_0()

# Generated at 2022-06-24 21:34:11.426414
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # creating the instance of the class Connection
    obj = Connection()
    assert obj != None
    # executing the method __rpc__
    obj.__rpc__()


# Generated at 2022-06-24 21:34:54.187106
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    x = Connection(None, 'localhost')
    try:
        __rpc__(x, 'aaff')
    except Exception as e:
        assert e.message == "'Connection' object has no attribute '_Connection__rpc__'"
    try:
        __rpc__(x, 'aaff')
    except Exception as e:
        assert e.message == "'Connection' object has no attribute '_Connection__rpc__'"


# Generated at 2022-06-24 21:34:58.773035
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    try:
        assert 1 in [1, 2, 3]
        assert test_case_0() == 'foo'
        assert test_case_0() == 'foo'
    except AssertionError as exc:
        raise AssertionError(str(exc))



# Generated at 2022-06-24 21:35:02.305159
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # There is no special logic to test in the method implementation
    # Simply ensure that it does not result in any runtime errors
    for _ in range(25):
        int_1 = -102
        var_1 = recv_data(int_1)

# Test class for the method __rpc__ of the class Connection

# Generated at 2022-06-24 21:35:08.026623
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_1 = -123
    obj_0 = Connection(int_1)
    obj_1 = test_case_0()
    obj_2 = obj_1.send(obj_1)
    var_1 = obj_0.__rpc__(obj_2)
    print(var_1)


# Generated at 2022-06-24 21:35:12.749342
# Unit test for function recv_data
def test_recv_data():
    test_case_0()

# Normal invocation
if __name__ == '__main__':
    test_recv_data()

# Generated at 2022-06-24 21:35:17.124561
# Unit test for function exec_command
def test_exec_command():
    print("\n*** unit test for exec_command function ***\n")
    print("\n*** unit test for exec_command function: test case 0 ***\n")
    test_case_0()
    print("\n*** unit test for exec_command function: test case 1 ***\n")
    test_case_1()


# Generated at 2022-06-24 21:35:17.972630
# Unit test for function recv_data
def test_recv_data():
    assert test_case_0() == None

# Generated at 2022-06-24 21:35:19.473225
# Unit test for function recv_data
def test_recv_data():
    assert True

if __name__ == "__main__":
    test_recv_data()

# Generated at 2022-06-24 21:35:20.049196
# Unit test for function exec_command
def test_exec_command():
    pass

# Generated at 2022-06-24 21:35:28.326460
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    '''
    Unit test for method __rpc__ of class Connection
    '''
    var_0 = Connection("/tmp/test.sock")
    var_1 = float(7.22)
    var_2 = float(6.8)
    var_3 = float(7.22)
    var_4 = dict()
    var_4["k0"] = float(7.22)
    var_4["k1"] = float(6.8)
    var_4["k2"] = float(7.22)
    var_4["k3"] = float(6.8)
    var_4["k4"] = float(7.22)
    var_5 = dict()
    var_5["k0"] = float(7.22)

# Generated at 2022-06-24 21:36:14.331027
# Unit test for function exec_command
def test_exec_command():
    # Unit test for 'exec_command' function
    method_name = 'exec_command'
    args = []
    kwargs = {}
    function_result = exec_command(method_name, *args, **kwargs)
    assert function_result == expected_result


# Generated at 2022-06-24 21:36:17.822772
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    str_0 = '[RPC] rpc_01'
    int_0 = ''

    # Parameters accepted are given as arguments to the function
    # rpc_01('test', '0')

    # Call function under test
    result = Connection.__rpc__(str_0, int_0)



# Generated at 2022-06-24 21:36:22.631484
# Unit test for function recv_data
def test_recv_data():
    # Test case 0
    test_case_0()



# Generated at 2022-06-24 21:36:30.497770
# Unit test for method send of class Connection
def test_Connection_send():
    int_1 = -102

# Generated at 2022-06-24 21:36:36.351524
# Unit test for function exec_command
def test_exec_command():
    args = {}
    args['connection'] = Connection('socket_path')
    test_module = get_module(args)
    set_module_args(args)
    # Test exec_command
    assert exec_command(test_module, 'command') != None


# Generated at 2022-06-24 21:36:43.465187
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    kwargs = {}
    kwargs['name'] = ''
    kwargs['args'] = ''
    kwargs['kwargs'] = ''
    # Testing the validity of method: Connection.__rpc__(self, name, *args, **kwargs)
    # Invalid method name
    try:
        assert Connection.__rpc__(*kwargs)
        # Invalid method
        # Invalid arguments
        # Invalid keyword arguments
    except AssertionError:
        raise AssertionError
    except Exception:
        pass
    return None



# Generated at 2022-06-24 21:36:47.087283
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = -102
    class_1 = Connection(int_0)
    int_2 = -102
    var_1 = class_1.send(int_2)


# Generated at 2022-06-24 21:36:51.453241
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection('/tmp/ansible_local/tmp_socket_abc.sock')
    connection.__rpc__('exec_command', "show version")
    connection.__rpc__('exec_command', "show version", "show version")


# Generated at 2022-06-24 21:37:01.910613
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = -102
    var_1 = request_builder("get_option", int_0)
    var_2 = var_1.get("id")
    var_3 = os.path.exists("/proc/self/fd/0")
    var_4 = Connection("/proc/self/fd/0")
    var_5 = var_4._exec_jsonrpc("get_option", int_0)
    var_6 = var_5.get("id")
    var_7 = var_6 == var_2
    var_8 = var_5.get("result")
    var_9 = var_5.get("error")
    var_10 = var_5.get("result") == var_8
    int_1 = 0
    var_11 = var_5.get("error") == None


# Generated at 2022-06-24 21:37:12.361412
# Unit test for function exec_command
def test_exec_command():
    # Test when module._socket_path is None
    module = type('module',(object,),dict(_socket_path=None,))
    command = 'sh run'
    err = None
    try:
        exec_command(module,command)
    except AssertionError as e:
        err = e

    assert e is not None
    assert 'must be a value' in repr(e)

    # Test when module._socket_path is a socket path (string)
    module = type('module',(object,),dict(_socket_path='socket-path',))
    command = 'sh run'
    err = None
    try:
        exec_command(module,command)
    except ConnectionError as e:
        err = e

    assert e is not None
    assert 'does not exist' in repr(e)

    return
