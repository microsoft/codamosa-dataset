

# Generated at 2022-06-24 21:27:37.865702
# Unit test for function exec_command
def test_exec_command():
    pass


# Generated at 2022-06-24 21:27:41.648870
# Unit test for function recv_data
def test_recv_data():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(3.0)
    sock.connect(("google.com", 80))
    data = recv_data(sock)
    sock.close()
    assert(data is not None and len(data) > 0)


# Generated at 2022-06-24 21:27:42.879116
# Unit test for function recv_data
def test_recv_data():
    data = recv_data(sf)



# Generated at 2022-06-24 21:27:45.881819
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect("socket")
    out = recv_data(s)
    assert out == 'foo'

    s.close()


# Generated at 2022-06-24 21:27:52.114781
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    complex_0 = Connection("/tmp/ans")
    str_0 = "exec_command"
    str_1 = "show version"
    str_2 = json.dumps({'jsonrpc': '2.0', 'method': str_0, 'id': '7b552e49-c6f4-4f8c-98b4-ab701e9e9199', 'params': ((str_1,), {})}, cls=AnsibleJSONEncoder)
    str_3 = "unable to connect to socket /tmp/ans. See Troubleshooting socket path issues in the Network Debug and Troubleshooting Guide"
    complex_0.send = MagicMock(return_value=str_3)

# Generated at 2022-06-24 21:27:59.798805
# Unit test for function recv_data
def test_recv_data():
    # Data is None
    assert recv_data(None) == None

    # Data is None
    assert recv_data(None) == None

    # Data is bytes
    print("MOCK DATA |Recv Data: Data is bytes|")
    assert recv_data(to_bytes("bytes")) == None

    # Data is text
    print("MOCK DATA |Recv Data: Data is text|")
    assert recv_data(to_text("text")) == None

    return True



# Generated at 2022-06-24 21:28:09.566050
# Unit test for function exec_command
def test_exec_command():
    test_command = 'test command'
    complex_0 = None
    class ModuleStub(object):
        def __init__(self):
            self.params = {
                'socket_path': complex_0
            }

    class Module_0(object):
        def __init__(self):
            self._socket_path = complex_0

    complex_1 = ModuleStub()
    complex_2 = Module_0()
    complex_3 = exec_command(complex_1, test_command)
    complex_4 = exec_command(complex_2, test_command)
    assert complex_3 == (0, '', '')
    assert complex_4 == (0, '', '')


# Generated at 2022-06-24 21:28:13.738201
# Unit test for method send of class Connection
def test_Connection_send():
    complex_0 = None
    connection_0 = Connection(complex_0)
    data = None
    try:
        connection_0.send(data)
    except NotImplementedError:
        pass # expected exception


# Generated at 2022-06-24 21:28:17.315638
# Unit test for method send of class Connection
def test_Connection_send():
    complex_0 = None
    connection_0 = Connection(complex_0)
    data_0 = None
    out_0 = connection_0.send(data_0)
    assert out_0 == ""


# Generated at 2022-06-24 21:28:27.059260
# Unit test for function exec_command
def test_exec_command():
    command_0 = None
    module_0 = None
    code_0, out_0, err_0 = exec_command(module_0, command_0)
    assert err_0 is not None

    command_1 = None
    module_1 = None
    code_1, out_1, err_1 = exec_command(module_1, command_1)
    assert err_1 is not None

    command_2 = None
    module_2 = None
    code_2, out_2, err_2 = exec_command(module_2, command_2)
    assert err_2 is not None

    command_3 = None
    module_3 = None
    code_3, out_3, err_3 = exec_command(module_3, command_3)
    assert err_3 is not None

    command_

# Generated at 2022-06-24 21:28:33.149757
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    pass


# Generated at 2022-06-24 21:28:38.655509
# Unit test for function recv_data
def test_recv_data():
    try:
        assert True
    except AssertionError:
        raise AssertionError('Unable to execute test_recv_data')
    finally:
        pass


# Generated at 2022-06-24 21:28:41.399857
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    try:
        assert True
        return 0
    except (AssertionError, Exception) as exc:
        print("unit test for method __rpc__ of class Connection FAILED")
        return 1


# Generated at 2022-06-24 21:28:47.569898
# Unit test for function recv_data
def test_recv_data():
    fd = 4
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(Connection('').socket_path)
    obj = {'foo': 'bar'}
    write_to_file_descriptor(fd, obj)
    actual = recv_data(s)
    s.close()
    expected = cPickle.dumps(obj, protocol=0)
    assert actual == expected


# Generated at 2022-06-24 21:28:57.632095
# Unit test for function exec_command
def test_exec_command():
    test_command_0 = '''test_command_0'''
    test_module_0 = '''test_module_0'''
    test_module_0.exec_command = mock.MagicMock(name='exec_command')
    test_module_0.exec_command.return_value = None
    # Call exec_command and check the return value
    assert exec_command(test_module_0, test_command_0) is None
    # Call the mock
    test_module_0.exec_command.assert_called_with((test_command_0,))
    # Check the number of calls made
    self.assertEqual(test_module_0.exec_command.call_count, 1)

# Generated at 2022-06-24 21:29:01.027623
# Unit test for function recv_data
def test_recv_data():
    fd = 1
    data = bytes(128)
    recv_data(fd,data)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:29:04.276572
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # arrange
    connection_0 = Connection(None)

    # act
    ret = connection_0.__rpc__(None, None)

    # assert
    expected = None
    assert ret == expected


# Generated at 2022-06-24 21:29:10.902841
# Unit test for function exec_command
def test_exec_command():
    """
    exec_command unit test stub.
    """
    if os.path.exists('./exec_command_data'):
        with open('./exec_command_data', 'r') as data_file:
            data = json.load(data_file)
            assert exec_command(data['module'], data['command']) == tuple(data['result'])


# Generated at 2022-06-24 21:29:18.967577
# Unit test for function recv_data
def test_recv_data():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        s.listen(1)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s2:
            s2.connect(s.getsockname())
            send_data(s2, b'foo')
            with s.accept()[0] as conn:
                assert recv_data(conn) == b'foo'


# Generated at 2022-06-24 21:29:22.184070
# Unit test for function exec_command
def test_exec_command():
    assert "!" in exec_command("module_0", "command_0")

# Generated at 2022-06-24 21:29:28.517782
# Unit test for function exec_command
def test_exec_command():
    returned_value = exec_command(1, 256.93)
    assert returned_value == 0, "exec_command() did not return a value"


# Generated at 2022-06-24 21:29:37.763547
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Test with non-existent method
    try:
        Connection.__rpc__(test_case_0, 'foo')
        assert False, "AttributeError expected"
    except AttributeError:
        pass
    # Test with a valid method
    Connection.__rpc__ = test_case_0
    Connection.__rpc__('foo')
    # Test with self arg
    class TempConnection(Connection):
        def __init__(self):
            Connection.__init__(self, '1')

    temp_connection=TempConnection()
    temp_connection._exec_jsonrpc = test_case_0
    try:
        temp_connection.foo()
        assert False, "AttributeError expected"
    except AttributeError:
        pass

# Generated at 2022-06-24 21:29:44.438217
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    try:
        par_0 = float()
        float_0 = float()
        float_1 = float()
        float_2 = float()
        float_3 = float()
        float_4 = float()
        con_0 = Connection(par_0)
        var_0 = con_0.__rpc__(float_0, float_1, float_2, float_3, float_4)
        assert var_0 == None
    except Exception:
        assert False


# Generated at 2022-06-24 21:29:46.493594
# Unit test for function recv_data
def test_recv_data():
    data = recv_data(float_0)
    assert type(data) == unicode


# Generated at 2022-06-24 21:29:48.172432
# Unit test for function recv_data
def test_recv_data():
    pass


# Generated at 2022-06-24 21:29:58.903430
# Unit test for function recv_data
def test_recv_data():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    float_1 = -315.58045
    var_0 = recv_data(float_1)
    float_2 = -12.907
    var_0 = recv_data(float_2)
    float_3 = -102.3594
    var_0 = recv_data(float_3)
    float_4 = 10.2708
    var_0 = recv_data(float_4)
    float_5 = -395.821
    var_0 = recv_data(float_5)
    float_6 = -33.2292
    var_0 = recv_data(float_6)
    float_7 = -334.749
    var_0 = recv

# Generated at 2022-06-24 21:30:00.076613
# Unit test for function recv_data
def test_recv_data():
    test_case_0()


# Generated at 2022-06-24 21:30:05.761213
# Unit test for function recv_data
def test_recv_data():
    try:
        test_case_0()
    except Exception as exc:
        assert False, "Exception caught: {}".format(exc)

    assert True

if __name__ == '__main__':
    import sys
    print('Running tests...')
    test_recv_data()
    print('All tests passed!')

# Generated at 2022-06-24 21:30:09.617480
# Unit test for method send of class Connection
def test_Connection_send():
    connection = Connection(None)
    try:
        connection.send()
    except Exception as result:
        print('Exception!')


# Generated at 2022-06-24 21:30:14.152737
# Unit test for function exec_command
def test_exec_command():
    """
    Functional test for function exec_command
    """
    string_0 = 'rBnqRBbNz'
    int_0 = 1
    float_0 = 1.9
    var_0 = exec_command(string_0, int_0, float_0)


# Generated at 2022-06-24 21:30:25.520582
# Unit test for function exec_command
def test_exec_command():
    class module_0():
        def __init__(self):
            self._socket_path = '/root/ansible_connection.sock'
    data = exec_command(module_0(), 'show version')
    print(data)


# Generated at 2022-06-24 21:30:33.448184
# Unit test for function recv_data
def test_recv_data():
    var_0 = recv_data(5)
    var_1 = send_data(5, 5)

    if var_0 is None:
        var_2 = "Failed"
        var_3 = "Passed"
    else:
        var_2 = "Failed"
        var_3 = "Passed"

    assert var_2 == 2 or var_2 == var_3 or var_2 == float_0 or var_0 == -13.7715 or var_2 == float_0 or var_1 == var_0 or "Failed" == var_0 or var_0 == -13.7715, "Failed"

# Generated at 2022-06-24 21:30:36.404159
# Unit test for function exec_command
def test_exec_command():
    assert True

# Generated at 2022-06-24 21:30:45.731257
# Unit test for function recv_data
def test_recv_data():
    try:
        from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch
    except ImportError:
        from unittest.mock import patch

    class Bunch(object):
        def __init__(self, adict):
            self.__dict__.update(adict)

    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils.recv_data.float_0', new=Bunch(socket=Bunch(error='socket error message'))):
        with pytest.raises(ConnectionError):
            test_case_0()


# Generated at 2022-06-24 21:30:47.068095
# Unit test for function exec_command
def test_exec_command():
    pass


# Generated at 2022-06-24 21:30:50.039415
# Unit test for function recv_data
def test_recv_data():
    float_0 = -2780.86800549
    var_0 = recv_data(float_0)
    assert type(var_0) == bytes


# Generated at 2022-06-24 21:30:51.295459
# Unit test for function exec_command
def test_exec_command():
 
    assert exec_command(test_case_0,test_exec_command)==0

# Generated at 2022-06-24 21:30:52.217578
# Unit test for function recv_data
def test_recv_data():
    assert test_case_0() == None

# Generated at 2022-06-24 21:30:53.595425
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    assert True


# Generated at 2022-06-24 21:30:56.191348
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    float_0 = -734.0
    var_0 = recv_data(float_0)


# Generated at 2022-06-24 21:31:07.341422
# Unit test for function recv_data
def test_recv_data():
    file_name = raw_input("Enter the template name :")
    var_0 = file_name
    var_1 = recv_data(var_0)
    return var_1


# Generated at 2022-06-24 21:31:18.420639
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Test connection to a host on the local machine
    connection = Connection(connection._socket_path)
    response = connection.exec_command('ls')

    assert('bin' in response)
    assert('boot' in response)
    assert('dev' in response)
    assert('etc' in response)
    assert('home' in response)
    assert('lib' in response)
    assert('lib64' in response)
    assert('media' in response)
    assert('mnt' in response)
    assert('opt' in response)
    assert('root' in response)
    assert('run' in response)
    assert('sbin' in response)
    assert('snap' in response)
    assert('srv' in response)
    assert('tmp' in response)
    assert('usr' in response)

# Generated at 2022-06-24 21:31:30.407977
# Unit test for method send of class Connection
def test_Connection_send():
    if pathlib.Path('/tmp/ansible_test_Connection/test_Connection_send').exists():
        os.remove('/tmp/ansible_test_Connection/test_Connection_send')
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('/tmp/ansible_test_Connection/test_Connection_send')
    sf.listen(1)
    int_0 = 3
    int_1 = -9915
    int_2 = -525
    int_3 = -1054
    int_4 = -2607
    int_5 = -1871
    int_6 = -904
    int_7 = 4
    int_8 = 17
    int_9 = -6199
    int_10 = -1
    int

# Generated at 2022-06-24 21:31:35.121105
# Unit test for function recv_data
def test_recv_data():

    # Input Parameters Declarations
    float_0 = None  # Type: Any

    # Output:
    var_0 = None


    # Call the Function
    var_0 = recv_data(float_0)

    # Verify the Output Matches the Expected Output
    print("var_0", var_0)
    assert var_0 == None



# Generated at 2022-06-24 21:31:37.868879
# Unit test for function recv_data
def test_recv_data():
    module = mock()
    expected = b'\x0c\x00\x00\x00\x00\x00\x00\x00\x01\x02\x03\x04\x05'
    actual = recv_data(module)
    assert actual == expected


# Generated at 2022-06-24 21:31:45.357674
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    cmd = ('/usr/bin/python', '-c', 'import socket,sys;s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM);s.connect("/tmp/ansible-local-test");send_data(s, sys.stdin.read());response = recv_data(s);s.close();print(repr(response))')
    path = '/tmp/ansible-local-test'
    obj = Connection(path)
    value = obj._rpc__('exec_command', cmd)

# Generated at 2022-06-24 21:31:47.967175
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    float_0 = -3016.453
    var_0 = recv_data(float_0)



# Generated at 2022-06-24 21:31:49.744765
# Unit test for function recv_data
def test_recv_data():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    test_case_0()



# Generated at 2022-06-24 21:31:51.483456
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    obj = Connection(socket_path=None)
    # __rpc__ is not tested



# Generated at 2022-06-24 21:31:53.606770
# Unit test for function exec_command
def test_exec_command():
    module = {'socket_path':''}
    command = 'ls'
    assert exec_command(module,command) == (0,'','ls')

# Generated at 2022-06-24 21:32:02.511199
# Unit test for function exec_command
def test_exec_command():
    assert exec_command("module", "command")

# Generated at 2022-06-24 21:32:03.461848
# Unit test for function exec_command
def test_exec_command():
    assert callable(exec_command)



# Generated at 2022-06-24 21:32:09.354456
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    var_1 = Connection(var_0)
    var_2 = dict()
    var_2[0] = -10
    var_2[1] = -6
    var_2[2] = -5
    var_2[3] = -4
    var_2[4] = -3
    var_2[5] = -2
    var_2[6] = -1
    var_3 = var_1.__rpc__('test_item_2', var_2)


# Generated at 2022-06-24 21:32:11.025191
# Unit test for function exec_command
def test_exec_command():
    assert exec_command(None, None) is None


# Generated at 2022-06-24 21:32:14.048871
# Unit test for function recv_data
def test_recv_data():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    try:
        assert var_0 == None
    except Exception as e:
        print(e)
        

# Generated at 2022-06-24 21:32:15.162705
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    assert False

# Generated at 2022-06-24 21:32:24.588000
# Unit test for function recv_data
def test_recv_data():
    arr = bytearray(0)
    arr += (b'\x00\x0c\x00\x00\x00\x00\x00\x00')
    arr += (b'{')
    arr += (b'\x00')
    arr += (b'\x00\x00')
    arr += (b'\x00\x00')
    arr += (b'\x1e')
    arr += (b'\x00')
    arr += (b'\x00\x00')
    arr += (b'\x00\x00')
    arr += (b'\x00')
    arr += (b'\x00\x00')
    arr += (b'\x00\x00')
    arr += (b'\x00')

# Generated at 2022-06-24 21:32:29.635984
# Unit test for function recv_data
def test_recv_data():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    print(var_0)

if __name__ == "__main__":
    test_case_0()
    test_recv_data()

# Generated at 2022-06-24 21:32:32.682813
# Unit test for function recv_data
def test_recv_data():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    print("var_0 value: " + str(var_0))

    assert int(var_0) == 500


# Generated at 2022-06-24 21:32:38.587520
# Unit test for method send of class Connection
def test_Connection_send():
    connection = Connection(None)
    data = 'data'
    expected = None
    actual = connection.send(data)
    assert actual == expected


# Generated at 2022-06-24 21:32:47.465871
# Unit test for function exec_command
def test_exec_command():
    assert callable(exec_command)


# Generated at 2022-06-24 21:32:53.411458
# Unit test for function exec_command
def test_exec_command():

    args = {"command": "ls -l /usr/local/bin"}
    out = exec_command(Connection("/tmp/ansible"), "command")
    assert out == 0, "Expected return code 0, received " + str(out)


# Generated at 2022-06-24 21:32:58.910695
# Unit test for function exec_command
def test_exec_command():
    # Create a dummy module and command to test
    module = object()
    module._socket_path = ''
    command = '/foo/bar'
    rc, output, errmsg = exec_command(module, command)
    assert rc == 0 and output == '' and errmsg == \
        'socket path  does not exist or cannot be found. See Troubleshooting socket path issues in the Network Debug and Troubleshooting Guide'


# Generated at 2022-06-24 21:33:08.453919
# Unit test for function exec_command
def test_exec_command():
    params = {
        "command": "show lldp neighbors",
        "prompt": {
            "timeout": 180,
            "command": "show lldp neighbors detail",
            "answer": "Hello World!"
        },
        "_ansible_module_name": "ios_command",
        "action": "ios_command",
        "_ansible_no_log": False,
        "output": "text",
        "_ansible_verbosity": 0,
        "use_textfsm": True,
        "_ansible_syslog_facility": "LOG_USER",
        "transport": "cli",
        "host": "1.1.1.1",
        "_ansible_module_name": "ios_command",
        "username": "admin",
        "password": "admin"
    }

# Generated at 2022-06-24 21:33:10.990026
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    var_1 = send_data(var_0, var_0)
    return var_1



# Generated at 2022-06-24 21:33:13.420456
# Unit test for function recv_data
def test_recv_data():
    float_0 = 2960.98
    assert recv_data(float_0) is not None
    assert recv_data(float_0) is not None


# Generated at 2022-06-24 21:33:17.576613
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # test_case_0
    try:
        test_case_0()
    except:
        print("Exception in test_case_0")


# Generated at 2022-06-24 21:33:19.418319
# Unit test for function recv_data
def test_recv_data():
    assert recv_data() == '', 'Function call recv_data() failed did not return correct response'


# Generated at 2022-06-24 21:33:24.324184
# Unit test for function recv_data
def test_recv_data():
    try:
        test_case_0()
        print("Successfully ran test case: %s" % "test_case_0")
    except Exception as exc:
        print("Exception in '%s' test case: %s" % ("test_case_0", exc))

if __name__ == '__main__':
    test_recv_data()

# Generated at 2022-06-24 21:33:34.553753
# Unit test for function exec_command
def test_exec_command():
    command = valid_f5_command()
    module_mock = Mock()
    module_mock._socket_path = 'host'
    module_mock.module_name = 'ansible_module'
    ansible_module_mock = Mock()
    ansible_module_mock.params = {'network_os': 'f5-bigip-tmos', 'server': 'host', 'network_os_user': 'admin', 'provider': 'connection_method', 'password': 'admin', 'port': '80', 'network_os_pass': 'admin'}
    ansible_module_mock.DEBUG = False
    ansible_module_mock.check_mode = False

    module_mock.module_name = "test"

# Generated at 2022-06-24 21:33:45.806325
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    _file = open('C:/Python27/Lib/site-packages/ansible/plugins/connection/network_cli.py', 'r')
    out = _file.read()
    print(out)

if __name__ == '__main__':
    test_Connection___rpc__()

# Generated at 2022-06-24 21:33:57.221553
# Unit test for function exec_command
def test_exec_command():
    # Must be executed from the same directory as the test is.
    module_path = os.path.join(os.path.dirname(__file__), 'exec_command_test.py')
    test_cases = [
        {
            'command': 'python %s test_case_0' % module_path,
            'expected_output': "",
            'expected_rc': 0
        }
    ]
    for test_case in test_cases:
        print('Testing \'' + test_case['command'] + '\'')
        rc, output, err = exec_command(None, test_case['command'])
        assert rc == test_case['expected_rc']
        assert output == test_case['expected_output']
        assert err == ""

# Generated at 2022-06-24 21:34:00.043140
# Unit test for function recv_data
def test_recv_data():
    float_0 = -3016.453
    var_0 = recv_data(float_0)
    print(var_0)


# Generated at 2022-06-24 21:34:06.247910
# Unit test for function recv_data
def test_recv_data():
    float_0 = float()
    float_1 = float()
    float_1.real = float_0.real
    float_1.imag = float_0.imag
    float_1.num = float_0.num
    float_1.denom = float_0.denom
    float_1.signed = float_0.signed
    float_1.bits = float_0.bits
    float_1.prec = float_0.prec
    float_1.ldexp = float_0.ldexp
    float_0 = float_1
    test_case_0()

# Generated at 2022-06-24 21:34:13.941582
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test1_connection = Connection('socket_path')
    test1_args = argv[:0]
    test1_kwargs = {"kwarg_x": "kwarg_y"}
    test1_test_case = test_case_0()
    test1_response = test1_connection.__rpc__(test1_test_case, *test1_args, **test1_kwargs)
    assert test1_response == "test1_response"

# Generated at 2022-06-24 21:34:23.624161
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    float_0 = 5452.465
    float_1 = -0.002084
    float_2 = 0.002601
    float_3 = -1066.335
    float_4 = -2038.444
    float_5 = -2431.866
    float_6 = 0.697
    var_0 = 6596.239
    var_1 = 8147.76
    var_2 = -0.2705
    var_3 = -0.1955
    var_4 = -5337.793
    var_5 = -4453.74
    var_6 = -6532.534
    var_7 = -7586.711
    var_8 = Connection(var_0)

# Generated at 2022-06-24 21:34:28.649239
# Unit test for function recv_data
def test_recv_data():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {0}'.format(str(e)))

# General function for unit test generation

# Generated at 2022-06-24 21:34:34.332087
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    obj = Connection('file_path')
    method_name = 'method_name'
    method_args = tuple()
    method_kwargs = dict()
    result = obj.__rpc__(method_name,method_args,method_kwargs)
    assert isinstance(result, dict)


# Generated at 2022-06-24 21:34:40.031199
# Unit test for function exec_command
def test_exec_command():
    var_1 = "*"
    var_2 = "/"
    var_3 = "*"
    var_4 = exec_command(var_1, var_2)
    var_5 = var_4.split(var_3)
    var_6 = var_5[0]
    var_7 = var_6.strip()
    return var_7


# Generated at 2022-06-24 21:34:49.794968
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    reqid = str(uuid.uuid4())
    req = {'jsonrpc': '2.0', 'method': 'test_Connection___rpc__', 'id': reqid}
    req['params'] = (['args', 'kwargs'])

    if not os.path.exists('/etc/ansible/ansible-connection'):
        raise ConnectionError(
            'socket path /etc/ansible/ansible-connection does not exist or cannot be found. See Troubleshooting '
            'socket path issues in the Network Debug and Troubleshooting Guide'
        )


# Generated at 2022-06-24 21:35:09.486602
# Unit test for function exec_command
def test_exec_command():
    module_arg_spec = dict(
        command=dict(type='str', required=True)
    )
    module = AnsibleModule(argument_spec=module_arg_spec,
                           supports_check_mode=True)

    result = exec_command(module, module.params['command'])

    module.exit_json(**result)


# Generated at 2022-06-24 21:35:14.540644
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    # It is possible that errors before the call to __rpc__ will
    # leave inconsistent state so that the test here fails to
    # capture the source of the error.  This try: except:
    # block is to ensure that the test method does not exit on
    # exceptional conditions.

    try:
        float_1 = -3016.453
        var_2 = recv_data(float_1)

    except Exception as var_3:
        print("Caught exception: {}".format(var_3))



# Generated at 2022-06-24 21:35:17.085364
# Unit test for function exec_command
def test_exec_command():
    module = object()
    command = object()
    out = exec_command(module, command)
    assert out is not None


# Generated at 2022-06-24 21:35:23.144151
# Unit test for method send of class Connection
def test_Connection_send():
    parsed = {'hostname': 'test_host', 'password': 'test_pass', 'port': 22, 'username': 'test_user'}
    module = type('testmodule', (object, ), {'params': parsed})
    conn = Connection('./tmp/test_debug.sock')
    data = '{"jsonrpc":"2.0","method":"exec_command","id":"uuid_id","params":["show version"]}'
    out = conn.send(data)
    assert out == "abcd"


# Generated at 2022-06-24 21:35:28.786008
# Unit test for method send of class Connection
def test_Connection_send():
    float_0 = -3016.453
    var_0 = Connection.send(float_0)


# Generated at 2022-06-24 21:35:36.424210
# Unit test for function exec_command
def test_exec_command():
    i = 1
    for name in range(2):

        if 1:
            return
        var_0 = to_bytes(name)
        var_1 = to_text(name)
        pass
    var_0 = exec_command(var_0, var_1)

    assert var_0 == 0, 'Unexpected return value from exec_command(%s, %s)' % {'0': var_0}



# Generated at 2022-06-24 21:35:38.206373
# Unit test for function exec_command
def test_exec_command():
    assert(exec_command(module, command) == 0)


# Generated at 2022-06-24 21:35:39.327691
# Unit test for function exec_command
def test_exec_command():
    # TODO Implement unit test
    return True


# Generated at 2022-06-24 21:35:43.654132
# Unit test for function exec_command
def test_exec_command():
    globals().get('assertEqual')
    assertEqual(
        exec_command(
            globals().get('module'),
            "exec %s %s %s" % (
                globals().get('var_2'),
                globals().get('var_3'),
                globals().get('var_4')
            )
        ),
        (0, '', '')
    )


# Generated at 2022-06-24 21:35:44.531041
# Unit test for function recv_data
def test_recv_data():
    var_1 = test_case_0()



# Generated at 2022-06-24 21:36:24.492206
# Unit test for function exec_command
def test_exec_command():
    assert True


# Generated at 2022-06-24 21:36:27.953650
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    float_0 = -9.593338
    float_1 = -0.0
    var_0 = Connection(float_0)
    str_0 = '6u+RF'
    float_1 = float_1
    var_0.__rpc__(str_0, float_1)


# Generated at 2022-06-24 21:36:31.668027
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # create a new object "exp_conn" of class Connection
    exp_conn = Connection(exp_path)
    # perform rpc method "run_commands" on the connection object "exp_conn"
    response = exp_conn.run_commands(command_list=['show clock'])
    # extract the device output from the response
    response = response[0]
    # assert that the device output is non-empty
    assert response['output']
    # assert that the response error is empty
    assert not response['response_error']


# Generated at 2022-06-24 21:36:37.501001
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    try:
        var_0 = Connection(None)
        var_1 = exec_command(var_0, None)
        var_2 = var_0.exec_command(None)
    except Exception as err:
        print("Exception detected")


# Generated at 2022-06-24 21:36:38.713158
# Unit test for function exec_command
def test_exec_command():
    assert True


# Generated at 2022-06-24 21:36:40.737173
# Unit test for function recv_data
def test_recv_data():
    print("Test 0 for function recv_data")
    test_case_0()


# Generated at 2022-06-24 21:36:50.507585
# Unit test for function exec_command
def test_exec_command():
    var_0 = ConnectionError('a', 'b', 'c', d='e')
    var_1 = partial(exec_command, var_0)
    var_2 = hashlib.sha1(to_bytes(var_0)).hexdigest()
    var_3 = request_builder('a', 'b', 'c', d='e')
    var_4 = request_builder('a', 'b', 'c', d='e')
    var_5 = cPickle.dumps(var_0, protocol=0)
    var_6 = json.dumps(var_0, cls=AnsibleJSONEncoder)
    var_7 = str(uuid.uuid4())
    var_8 = dict(jsonrpc='2.0', method='a', id=var_7)
    var_8['params']

# Generated at 2022-06-24 21:36:54.389426
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    send_data(float_0, float_0)
    assert var_0 == var_0, "__rpc__(float_0, float_0) returned %s, but expected %s" % (var_0, var_0)


# Generated at 2022-06-24 21:37:03.298703
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection( "/tmp/ansible_sfdp0s/sock")
    try:
        out = connection.__rpc__(1, var_0=3000, int_0=3000)
    except ConnectionError as exc:
        var_0 = 'Failed to encode some variables as JSON for communication with ansible-connection. '
        var_0 = var_0 + 'The original exception was: %s' % to_text('Failed to encode some variables as JSON for communication with ansible-connection. ')
        status = 'error'
        msg = 'socket path /tmp/ansible_sfdp0s/sock does not exist or cannot be found. See Troubleshooting socket path issues in the Network Debug and Troubleshooting Guide'
        jsonrpc_error(status, msg, version=1)
        msg = to_text

# Generated at 2022-06-24 21:37:05.981079
# Unit test for function recv_data
def test_recv_data():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test_case_0")
        raise