

# Generated at 2022-06-24 21:27:45.443879
# Unit test for method send of class Connection
def test_Connection_send():
    reqid = str(uuid.uuid4())
    req = {'jsonrpc': '2.0', 'method': 'exec_command', 'id': reqid}
    req['params'] = ('show version', '', '')
    try:
        data = json.dumps(req, cls=AnsibleJSONEncoder)
    except TypeError as exc:
        raise ConnectionError(
            "Failed to encode some variables as JSON for communication with ansible-connection. "
            "The original exception was: %s" % to_text(exc)
        )


# Generated at 2022-06-24 21:27:49.147333
# Unit test for function recv_data
def test_recv_data():
    try:
        s = None
        data = recv_data(s)
        if (data is None):
            print("assertion:%s" % "None")
        else:
            print("assertion_failed:%s" % "None")
    except Exception as e:
        print("exception:%s" % (e))


# Generated at 2022-06-24 21:28:01.484011
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = ()
    tuple_1 = (tuple_0, )
    dict_0 = dict(dict_0=tuple_1)
    tuple_2 = (dict_0, )
    string_0 = __name__
    string_1 = '__rpc__'
    tuple_3 = (string_0, string_1)
    string_2 = '{0}.{1}'.format(*tuple_3)
    tuple_4 = ()
    tuple_5 = (tuple_4, )
    dict_1 = dict(dict_1=tuple_5)
    tuple_6 = (dict_1, )
    string_3 = '__rpc__'
    tuple_7 = (string_3, )
    string_4 = '{0}.{1}'.format(*tuple_7)

# Generated at 2022-06-24 21:28:11.186164
# Unit test for function recv_data
def test_recv_data():
    # test https://github.com/ansible/ansible/issues/41867
    # test https://github.com/ansible/ansible/issues/45194
    connection = Connection(None)
    try:
        connection._exec_jsonrpc('recv_data')
    except ConnectionError as exc:
        if exc.code != 999:
            raise
    # test https://github.com/ansible/ansible/issues/41867
    # test https://github.com/ansible/ansible/issues/45194
    try:
        connection._exec_jsonrpc('test')
    except ConnectionError as exc:
        if exc.code != 999:
            raise
    # test https://github.com/ansible/ansible/issues/41867
    # test https://github.com/ansible/ansible/issues

# Generated at 2022-06-24 21:28:15.239600
# Unit test for function exec_command
def test_exec_command():
    # Function loads from file
    try:
        exec_command(test_exec_command, "ansible-doc")
    except SystemExit:
        return 0
    return 1


# Generated at 2022-06-24 21:28:17.930282
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = ()
    connection_0 = Connection(tuple_0)
    string_0 = connection_0.__rpc__('open')


# Generated at 2022-06-24 21:28:21.082653
# Unit test for function exec_command
def test_exec_command():
    module_0 = object()
    empty_string = ''
    ret_0 = exec_command(module_0, empty_string)
    assert(ret_0 == (0, '', ''))



# Generated at 2022-06-24 21:28:29.648220
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = ()
    connection_0 = Connection(tuple_0)
    str_0 = '__rpc__'
    tuple_1 = ()
    dict_0 = {}
    try:
        response_0 = connection_0._exec_jsonrpc(str_0, *tuple_1, **dict_0)
    except Exception as e_0:
        print('Exception caught: %s' % str(e_0))
        return -1
    finally:
        # cleanup after connection_0._exec_jsonrpc
        pass
    return 0


# Generated at 2022-06-24 21:28:31.476542
# Unit test for function recv_data
def test_recv_data():
    assert recv_data(None) == None
    assert recv_data(None) == None



# Generated at 2022-06-24 21:28:35.481989
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    data = to_bytes("ansible")
    header_len = 8
    packed_len = struct.pack('!Q', len(data))
    send_data(s, packed_len + data)
    received_data = recv_data(s)
    s.close()
    if received_data == data:
        return True
    else:
        return False


# Generated at 2022-06-24 21:28:43.268548
# Unit test for method send of class Connection
def test_Connection_send():
    tuple_0 = ()
    connection_0 = Connection(tuple_0)
    with pytest.raises(ConnectionError) as excinfo:
        connection_0.send('set_connection_option')
    assert 'unable to connect to socket . See the socket path issue category in Network Debug and Troubleshooting Guide' in str(excinfo.value)

# Generated at 2022-06-24 21:28:46.526387
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # return_value = __rpc__(name, *args, **kwargs)
    # assert return_value == False
    raise TypeError("takes at least 2 arguments (1 given)")


# Generated at 2022-06-24 21:28:53.564762
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('./test')
    data = to_bytes('hello')
    send_data(s, data)
    response = recv_data(s)
    print(response)
    assert(response == data)



# Generated at 2022-06-24 21:29:01.302637
# Unit test for function recv_data
def test_recv_data():
    try:
        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sf.connect('/dev/null')
        send_data(sf, to_bytes('hello'))
        response = recv_data(sf)
    except Exception as e:
        raise e
    finally:
        sf.close()

    if response != 'hello':
        raise ConnectionError(
            'unable to connect to socket %s. See the socket path issue category in '
            'Network Debug and Troubleshooting Guide' % 'na',
            err=to_text(response, errors='surrogate_then_replace'), exception=traceback.format_exc()
        )

    if __name__ != '__main__':
        import os
        os.system('touch /tmp/test1')

# Generated at 2022-06-24 21:29:11.056700
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = ()
    str_0 = str(tuple_0)
    connection_0 = Connection(str_0)
    connection_0.close = bool
    connection_0.connect = bool
    connection_0.connect = int
    connection_0.send = bool
    connection_0.recv = bool
    connection_0.recv_exit_status = bool
    connection_0.exec_command = bool
    connection_0.put_file = bool
    connection_0.fetch_file = bool
    connection_0.expand_user = bool
    connection_0.expand_path = bool
    connection_0.normalize = bool
    connection_0.abspath = bool
    connection_0.split_path = bool
    connection_0.chdir = bool
    connection_0.chmod

# Generated at 2022-06-24 21:29:21.732636
# Unit test for method send of class Connection
def test_Connection_send():
    tuple_0 = ()
    connection_0 = Connection(tuple_0)
    # Send w/o unicode, surrogate_or_strict errors should not result
    try:
        connection_0.send(b'{}')
    except socket.error:
        raise AssertionError('socket.error exception was not expected')
    except ConnectionError as e:
        assert repr(e) == 'ConnectionError(\'unable to connect to socket (). See Troubleshooting ' + \
                         'socket path issues in the Network Debug and Troubleshooting Guide\',)'
        assert e.err is None
        assert e.code is None
        assert e.exception is None
    # Send w/ unicode, w/ surrogate_or_strict errors should

# Generated at 2022-06-24 21:29:23.672358
# Unit test for function exec_command
def test_exec_command():
    module = object
    command = None
    assert exec_command(module, command) is not None


# Generated at 2022-06-24 21:29:34.017080
# Unit test for function exec_command

# Generated at 2022-06-24 21:29:43.963052
# Unit test for function recv_data
def test_recv_data():
    with open('sample.json', 'rb') as f:
        sample_data = f.read()
    h = hashlib.sha1()
    h.update(sample_data)
    digest = h.hexdigest()
    print('digest: {}'.format(digest))
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('/tmp/my_socket_path')
    send_data(s, sample_data)
    sent = s.sendall('{}\n'.format(digest))
    print('sent: {}'.format(sent))
    s.close()

# Generated at 2022-06-24 21:29:45.654156
# Unit test for function exec_command
def test_exec_command():
    assert exec_command() == (0, out, '')


# Generated at 2022-06-24 21:29:55.780850
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(2)
    s.connect(('127.0.0.1', 9527))
    send_data(s, b'FOO')
    assert recv_data(s) == b'FOO'
    send_data(s, b'BAR')
    assert recv_data(s) == b'BAR'



# Generated at 2022-06-24 21:30:07.893241
# Unit test for method send of class Connection
def test_Connection_send():
    print("Begin to test Connection.send")
    try:
        test_case_0()
    except Exception as e:
        print('An exception is raised in test_send case_0()')
        print(e)

    print('Case 1: test with existing socket_path')
 
    var_1 = Connection('/tmp/ansible_test_socket')
    var_2 = var_1.send({'id': 'someid', 'jsonrpc': '2.0'})
    print(var_2)

    print('Case 2: test with non-existing socket_path')
    var_3 = Connection('/tmp/ansible_test_soddket')
    var_4 = var_3.send({'id': 'someid', 'jsonrpc': '2.0'})
    print(var_4)



# Generated at 2022-06-24 21:30:15.962353
# Unit test for function recv_data
def test_recv_data():
    mock_socket = []

    # Test case with non-empty data
    expected = "data"
    mock_socket.append(expected)
    actual = recv_data(mock_socket)
    assert actual == expected

    # Test case with empty data
    expected = ""
    mock_socket.append(expected)
    actual = recv_data(mock_socket)
    assert actual == expected

    # Test case with None data
    expected = None
    mock_socket.append(expected)
    actual = recv_data(mock_socket)
    assert actual == expected


# Generated at 2022-06-24 21:30:17.860404
# Unit test for function exec_command
def test_exec_command():
    assert True == True


# Generated at 2022-06-24 21:30:19.259706
# Unit test for function recv_data
def test_recv_data():
    assert recv_data(sf, data) == "hy"


# Generated at 2022-06-24 21:30:23.593857
# Unit test for function recv_data
def test_recv_data():
    # Setup test data
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    # Process and compare output
    assert recv_data(s) == None
    # Cleanup test data
    s.close()

# Generated at 2022-06-24 21:30:26.414171
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # In case of error, returns the status and output,
    # if successful returns status 0 and output
    pass

# Generated at 2022-06-24 21:30:29.439970
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    print('\nrunning unit test for method __rpc__ of class Connection')
    var_0 = request_builder()
    test_case_0()


# Generated at 2022-06-24 21:30:30.242477
# Unit test for function exec_command
def test_exec_command():
    pass


# Generated at 2022-06-24 21:30:36.145210
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    data = b'abcde'
    r = cPickle.loads(data)
    if r != b'abcde':
        print('fails')
        return
    var_0 = build_request()
    r = exec_jsonrpc(Connection(), var_0)
    if r['result'] != b'abcde':
        print('fails')
        return


# Generated at 2022-06-24 21:30:44.057975
# Unit test for function exec_command
def test_exec_command():
    t = Connection('/dev/null')

test_exec_command()

# Generated at 2022-06-24 21:30:55.871040
# Unit test for function exec_command
def test_exec_command():
    # Do not initialize the AnsibleModule, just call the function.
    args = {}
    args.update({'connection': 'local'})
    args.update({'module_name': 'test'})
    args.update({'module_path': '.'})
    args.update({'module_args': {}})
    args.update({'module_complex_args': {}})
    args.update({'module_vars': {}})
    args.update({'module_internal_info': {'no_log': False}})
    args.update({'module_supports_check_mode': False})
    args.update({'_ansible_no_log': False})
    args.update({'_ansible_supports_check_mode': False})

# Generated at 2022-06-24 21:31:03.094491
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Setup test case data
    file_descriptor = 0
    method_name = "open_shell()"
    *args = [file_descriptor]

# Generated at 2022-06-24 21:31:04.144823
# Unit test for function exec_command
def test_exec_command():
    result = exec_command


# Generated at 2022-06-24 21:31:05.648315
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test_case_0()



# Generated at 2022-06-24 21:31:08.857589
# Unit test for function recv_data
def test_recv_data():
    s = {'AF_INET': (1, 2, 3, 4, 5)}
    try:
        out = recv_data(s)
    except TypeError:
        pass



# Generated at 2022-06-24 21:31:13.079470
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    print("##### In test_Connection___rpc__ #####")

    test_case_0()


# Generated at 2022-06-24 21:31:19.622547
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    socket_path = 'socket_path'
    instance_0 = Connection(socket_path)
    name = 'name'
    args = 'args'
    kwargs = 'kwargs'
    try:
        result = instance_0.__rpc__(name, args, kwargs)
        assert False
    except ConnectionError as exception_0:
        assert exception_0.args[0] == 'invalid json-rpc id received'
        assert exception_0.args[1] == 1
    except Exception as exception_1:
        print('exception')
        assert False


# Generated at 2022-06-24 21:31:21.131271
# Unit test for method send of class Connection
def test_Connection_send():
    # Initialize the object for unit test
    obj = Connection()
    obj.send(data = None)


# Generated at 2022-06-24 21:31:22.382181
# Unit test for method send of class Connection
def test_Connection_send():
    data = "my test string"
    conn = Connection("/test/test.sock")
    conn.send(data)



# Generated at 2022-06-24 21:31:38.613879
# Unit test for function recv_data
def test_recv_data():

    # Test with valid paramater
    test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    test_sock.bind(('127.0.0.1', 5000))
    test_sock.listen(1)

    test_sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    test_sock2.connect(('127.0.0.1', 5000))

    test_sock3, (ip, port) = test_sock.accept()
    test_sock3.send(b'10\nHello World')

    data = recv_data(test_sock2)
    assert data == b'10\nHello World'

    # Test with invalid parameter
    data = recv_data(None)


# Generated at 2022-06-24 21:31:42.844370
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    module_0 = None
    tuple_0 = (module_0, )
    var_0 = Connection.__rpc__(Connection, module_0, tuple_0)
    print(var_0)


# Generated at 2022-06-24 21:31:48.985757
# Unit test for function recv_data
def test_recv_data():
    print("Test Case: exec_command")
    print("=======================================")
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('socket_data')
    data = recv_data(sf)
    sf.close()
    print("data: " + to_text(data))


# Generated at 2022-06-24 21:31:52.423806
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = None
    tuple_1 = None
    tuple_0 = Connection(tuple_1)
    tuple_0 = tuple_0.__rpc__(tuple_1, tuple_1, tuple_1)



# Generated at 2022-06-24 21:31:56.023392
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    in_obj_0 = None
    in_obj_1 = None
    try:
        var_0 = Connection(in_obj_0)
    except:
        var_0 = None
    try:
        var_1 = var_0.__rpc__(in_obj_1)
    except:
        var_1 = None


# Generated at 2022-06-24 21:31:56.913174
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    pass


# Generated at 2022-06-24 21:31:58.495616
# Unit test for function exec_command
def test_exec_command():
    module = object
    command = None
    var_1 = exec_command(module, command)


# Generated at 2022-06-24 21:32:03.150250
# Unit test for function exec_command
def test_exec_command():
    test_data = 'welcome'
    module = MockModule('test_data')
    code, out, err = exec_command(module, test_data)
    if (code != 0) or (out != test_data) or (err != ''):
        raise Exception('[FAIL] Unexpected result {0}, {1}, {2}'.format(code, out, err))



# Generated at 2022-06-24 21:32:04.729810
# Unit test for function exec_command
def test_exec_command():
    module = None
    command = None
    var_0 = exec_command(module, command)


# Generated at 2022-06-24 21:32:10.502775
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = None
    var_0 = Connection(tuple_0)

    # Default value for optional argument:
    # var_0._exec_jsonrpc = None
    # var_arg = tuple_0
    var_1 = var_0._exec_jsonrpc(tuple_0, )



# Generated at 2022-06-24 21:32:30.897327
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = None
    tuple_1 = None
    var_0 = Connection(tuple_0)
    try:
        tuple_1 = var_0.__rpc__(tuple_0, tuple_1, tuple_0)
    except ConnectionError:
        pass
    except Exception as exc:
        print((exc))


# Generated at 2022-06-24 21:32:34.878928
# Unit test for function exec_command
def test_exec_command():
    text_0 = 'does not exist'
    list_0 = [0, 0, 0]
    text_1 = 'does not exist'
    var_0 = exec_command(None, text_0)
    assert var_0 != list_0


# Generated at 2022-06-24 21:32:37.022654
# Unit test for function recv_data
def test_recv_data():
    # Test case 0
    try:
        test_case_0()
    except SystemExit:
        pass




# Generated at 2022-06-24 21:32:47.466527
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    cmd_0 = 'id'
    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    tuple_3 = None
    tuple_4 = None
    tuple_5 = None
    tuple_6 = None
    tuple_7 = None
    tuple_8 = None
    tuple_9 = None
    tuple_10 = None
    tuple_11 = None
    tuple_12 = None
    tuple_13 = None
    tuple_14 = None
    tuple_15 = None
    tuple_16 = None
    tuple_17 = None
    tuple_18 = None
    tuple_19 = None
    tuple_20 = None
    tuple_21 = None
    tuple_22 = None
    tuple_23 = None
    tuple_24 = None
    tuple_25 = None
    tuple_26 = None
   

# Generated at 2022-06-24 21:32:55.899989
# Unit test for function exec_command
def test_exec_command():
    test_command = 'cmd'
    test_module = 'module'
    test_module.setattr(test_module, '_socket_path', 'test_socket_path')
    expected_code = 0
    expected_out = ''
    expected_err = ''
    code, out, err = exec_command(test_module, test_command)
    assert code == expected_code
    assert out == expected_out
    assert err == expected_err


# Generated at 2022-06-24 21:32:57.365454
# Unit test for function recv_data
def test_recv_data():
    tuple_0 = None
    var_0 = recv_data(tuple_0)
    print(var_0)


# Generated at 2022-06-24 21:33:08.658087
# Unit test for function exec_command
def test_exec_command():
    # Command issued to the device
    command = "/bin/echo hello"
    module = importlib.import_module("ansible.modules.network.fortios")

    # Create a Fake Input data
    # Create a Fake socket path
    socket_path = "/tmp/ansible_fortios_command"

    # Create a Fake FortiOS host
    module._socket_path = socket_path
    module.fail_json = apply(type(module), ('fail_json', module))
    module.debug = apply(type(module), ('debug', module))
    module.warn = apply(type(module), ('warn', module))
    module.fail_json = apply(type(module), ('fail_json', module))
    module.exit_json = apply(type(module), ('exit_json', module))

# Generated at 2022-06-24 21:33:18.389473
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    socket_path_0 = '/var/lib/ansible/tmp/ansible-local-nmfibg9Jk8/ansible-tmp-1524702252.42-42190749628094/socket'
    arg_0 = '/usr/lib/python2.7/urllib.pyc'
    arg_1 = '/usr/lib/python2.7/httplib.pyc'
    arg_2 = '/usr/lib/python2.7/fileinput.pyc'
    arg_3 = '/usr/lib/python2.7/mimetools.pyc'
    arg_4 = '/usr/lib/python2.7/compileall.pyc'
    arg_5 = '/usr/lib/python2.7/random.pyc'

# Generated at 2022-06-24 21:33:23.865290
# Unit test for function recv_data
def test_recv_data():
    print("Testing recv_data")
    data = "test"
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.sendall(data)
    sf.close()
    if (recv_data(sf) != data):
        raise Exception("test_recv_data failed")


# Generated at 2022-06-24 21:33:34.240750
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket()
    s.bind(("", 0))
    s.listen(1)
    connect_thread = threading.Thread(target=client_thread_function, args=(s,))
    connect_thread.start()
    client, addr = s.accept()
    data = to_bytes("")
    while len(data) < 8:
        d = client.recv(8 - len(data))
        if not d:
            s.close()
            return None
        data += d
    data_len = struct.unpack('!Q', data[:8])[0]
    data = data[8:]
    while len(data) < data_len:
        d = client.recv(data_len - len(data))
        if not d:
            s.close()
            return None


# Generated at 2022-06-24 21:34:08.807982
# Unit test for function exec_command
def test_exec_command():
    try:
        # Store the variable for the assert statement.
        var_0 = exec_command(2, 2)
        assert var_0 == 0, 'AssertionError: Expected 0 but got %s' % var_0
    except AssertionError as exc:
        return False, str(exc)
    return True, ''


# Generated at 2022-06-24 21:34:16.019742
# Unit test for function recv_data
def test_recv_data():
    try:
        host = "127.0.0.1"
        port = 22
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10)
        s.connect((host, port))
        data = recv_data(s)
    except Exception as e:
        if hasattr(e, 'message'):
            print(e.message)
        else:
            print(e)
    finally:
        s.close()


# Generated at 2022-06-24 21:34:22.134877
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = None
    tuple_1 = None
    var_0 = Connection(tuple_0)
    var_1 = var_0.__rpc__(tuple_1, tuple_1, tuple_1)
    return var_1


# Generated at 2022-06-24 21:34:29.254554
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Set up mock
    Connection.send = MagicMock(side_effect = test_case_0)

    # Set up parameter values
    name = 'set_host_override'
    args = ['host_override', 'host_override']
    kwargs = dict()

    # Invoke method
    response = Connection.__rpc__(name, *args, **kwargs)

    # Check for correct result
    assert response is None




# Generated at 2022-06-24 21:34:31.592527
# Unit test for method send of class Connection
def test_Connection_send():
    connection = Connection("")
    data = ""
    try:
        connection.send(data)
    except ConnectionError as e:
        print("test_Connection_send error: {}".format(e))


# Generated at 2022-06-24 21:34:35.667391
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # instantiate an instance of class Connection
    obj = Connection(None)
    # assert parameter values
    # execute method
    result = obj.__rpc__('get_option', 'ansible_network_os')
    assert result is None
    # assert return value


# Generated at 2022-06-24 21:34:43.123955
# Unit test for function recv_data
def test_recv_data():
    data = b"123456789"
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('/var/tmp/connection_util.sock')
    send_data(s, data)
    result = recv_data(s)
    s.close()
    print(result)
    if result == data:
        print('test_recv_data passed')
    else:
        raise Exception('test_recv_data failed')


# Generated at 2022-06-24 21:34:48.161994
# Unit test for function recv_data
def test_recv_data():
    sf = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sf.connect(('127.0.0.1', 7979))
    data = recv_data(sf)
    assert data == b'test_recv_data_return'
    sf.close()


# Generated at 2022-06-24 21:34:51.854819
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    data = "This is a test"
    s.sendto(data, '/root/test-sock')
    s.close()
    assert(recv_data(s) == data)


# Generated at 2022-06-24 21:34:59.309623
# Unit test for function recv_data
def test_recv_data():
    try:
        test_case_0()
    except Exception as exc:
        print('\nException from test_recv_data: %s' % exc)
        return 1
    else:
        return 0


if __name__ == "__main__":
    try:
        ret = test_recv_data()
    except Exception as exc:
        print('\nException from __main__: %s' % exc)
        ret = 1
    sys.exit(ret)

# Generated at 2022-06-24 21:36:20.882027
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    tuple_0 = ()
    tuple_0 = ()
    str_0 = str()
    str_1 = str()
    int_0 = 0
    # create a class 'Connection'
    class_0 = Connection()
    # set local variable 'tuple_0'
    setattr(class_0, 'tuple_0', tuple_0)
    # set local variable 'var_0'
    setattr(class_0, 'var_0', var_0)
    tuple_1 = (tuple_0, tuple_0, tuple_0, tuple_0, tuple_0)
    dict_0 = dict()
    # set local variable 'var_1'
    setattr(class_0, 'var_1', var_1)
    # set local variable 'var_2'

# Generated at 2022-06-24 21:36:22.896756
# Unit test for function exec_command
def test_exec_command():
    command = dict()

    # Call the method
    out = exec_command(command, command)
    assert out[0] == 0
    assert out[1] == ''
    assert out[2] == ''


# Generated at 2022-06-24 21:36:31.307509
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    con = Connection('/tmp/ansible_network_debug_socket')
    con._exec_jsonrpc = lambda name, *args, **kwargs: 'unhandled exception'
    with pytest.raises(ConnectionError):
        con.__rpc__('get_facts')
        con.__rpc__('get_device_info')
        con.__rpc__('get_config')
        con.__rpc__('send_config')
        con.__rpc__('open')
        con.__rpc__('close')
        con.__rpc__('connected')
        con.__rpc__('get_option')
        con.__rpc__('set_option')



# Generated at 2022-06-24 21:36:42.420393
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    # --------------------------------------------------------------------------------------------------
    # define test parameters and initialize the object under test
    # --------------------------------------------------------------------------------------------------

    conn = Connection(None)

    # --------------------------------------------------------------------------------------------------
    # perform the test
    # --------------------------------------------------------------------------------------------------

    # test 1

    # name = None
    # *args = []
    # **kwargs = {}

    # expected =
    # actual = conn.__rpc__(name, *args, **kwargs)
    # assert actual == expected

    # test 2

    # name = None
    # *args = []
    # **kwargs = {}

    # expected =
    # actual = conn.__rpc__(name, *args, **kwargs)
    # assert actual == expected

# Generated at 2022-06-24 21:36:47.013022
# Unit test for function recv_data
def test_recv_data():
    try:
        assert isinstance(Connection('/var/lib/ucs-ansible/ansible-connection-ucssdk.sock').__rpc__('get_option', 'network_api'), str)
    except Exception as exc:
        print(exc)
        assert False


# Generated at 2022-06-24 21:36:51.415954
# Unit test for function exec_command
def test_exec_command():

    module = None

    # Case 0
    command = None
    try:
        exec_command(module, command)
    except AssertionError as e:
        if 'socket_path must be a value' in to_text(e):
            pass
        else:
            raise


# Generated at 2022-06-24 21:37:00.331333
# Unit test for function exec_command
def test_exec_command():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            _ansible_socket=dict(required=False, default=None)
        ),
        supports_check_mode=False,
    )
    module._socket_path = "/var/tmp/ansible-local/{0}".format(os.getpid())
    try:
        connect = Connection(module._socket_path)
        connect.exec_command('ls -l')
    finally:
        try:
            os.unlink(module._socket_path)
        except:
            pass



# Generated at 2022-06-24 21:37:02.779112
# Unit test for function exec_command
def test_exec_command():
    module = None
    command = None
    var_0 = exec_command(module, command)
    assert var_0 == (0, '', '')


# Generated at 2022-06-24 21:37:11.439956
# Unit test for method send of class Connection
def test_Connection_send():
    # Test case: valid argument
    tuple_0 = None
    var_0 = Connection(tuple_0)
    tuple_1 = None
    var_1 = var_0.send(tuple_1)
    # Test case: valid argument
    tuple_0 = None
    var_0 = Connection(tuple_0)
    tuple_1 = None
    var_1 = var_0.send(tuple_1)
    # Test case: valid argument
    tuple_0 = None
    var_0 = Connection(tuple_0)
    tuple_1 = None
    var_1 = var_0.send(tuple_1)


# Generated at 2022-06-24 21:37:14.401508
# Unit test for method send of class Connection
def test_Connection_send():
    obj_conn = Connection('socket_path')
    var_data = None
    obj_conn.send(var_data)
