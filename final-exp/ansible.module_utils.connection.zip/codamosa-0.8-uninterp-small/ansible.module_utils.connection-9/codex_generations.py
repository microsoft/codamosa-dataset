

# Generated at 2022-06-24 21:27:50.339614
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    module = AnsibleModule(
        argument_spec = dict(
            socket_path = dict(required=True, type='str'),
        ),
        supports_check_mode=False,
    )
    # Test with the socket path specified in the argument spec
    connection = Connection(module.params['socket_path'])
    result = connection.__rpc__("show_version")
    output = "* version: 2.5.5\n  build: 0.0.0\n  date: 2018-01-17\n"
    assert result == output
    # Test with the socket path specified as none
    with pytest.raises(AssertionError) as excinfo:
        connection1 = Connection(None)
    assert 'socket_path must be a value' in str(excinfo.value)


# Generated at 2022-06-24 21:27:55.860210
# Unit test for method send of class Connection
def test_Connection_send():
    out = b'{"jsonrpc": "2.0", "result": "pong", "id": "70047ac7-223d-4ef8-af3f-d1cb7c21e9e9"}'
    con = Connection('/var/tmp/connection_test')
    con.send('ping') == out

# Generated at 2022-06-24 21:27:56.940112
# Unit test for function recv_data
def test_recv_data():
    test_case_0()


# Generated at 2022-06-24 21:28:05.370140
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'N'
    bytes_1 = b'N'
    bytes_2 = b'N'
    bytes_3 = b'N'
    var_0 = recv_data(bytes_0)
    var_1 = recv_data(bytes_1)
    var_2 = recv_data(bytes_1)
    var_3 = recv_data(bytes_2)
    var_4 = recv_data(bytes_3)


if __name__ == '__main__':
    test_recv_data()

# Generated at 2022-06-24 21:28:06.899589
# Unit test for function recv_data
def test_recv_data():
    # Test case: 0
    test_case_0()



# Generated at 2022-06-24 21:28:12.348679
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Declare object
    connection = Connection('test_value_0')
    # Execute method
    with pytest.raises(ConnectionError):
        connection.__rpc__('test_value_1', 'test_value_2', 'test_value_3', test_value_4='test_value_5')


# Generated at 2022-06-24 21:28:22.012201
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'\x80\x00M'
    var_0 = recv_data(bytes_0)
    if (var_0 != b'\x80\x00M'):
        raise RuntimeError("Testcase 1 Failed: wrong value returned.")
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x01'
    var_0 = recv_data(bytes_0)
    if (var_0 is not None):
        raise RuntimeError("Testcase 2 Failed: wrong value returned.")

if __name__ == "__main__":
    test_recv_data()
    print("All Testcases passed.")

# Generated at 2022-06-24 21:28:28.448732
# Unit test for function exec_command
def test_exec_command():
    socket_path = '/path/to/socket'
    command = 'command'

    # Connection is a mock class
    Connection.send = lambda self, data: json.dumps({'result': 'value'})

    res = exec_command(
        Connection(socket_path),
        command
    )
    assert res == (0, 'value', '')

    # Connection is a mock class
    Connection.send = lambda self, data: json.dumps({'error': '{"message": "message", "code": 0}'})

    res = exec_command(
        Connection(socket_path),
        command
    )
    assert res == (1, '', 'message')



# Generated at 2022-06-24 21:28:35.822080
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    reqid = str(uuid.uuid4())
    req = {'jsonrpc': '2.0', 'method': 'a', 'id': reqid}
    req['params'] = ({'b': 'c'}, {})
    response_str = '{"jsonrpc": "2.0", "id": "a", "result": null}'
    response = json.loads(response_str)

    # copy is needed because results is a reference to a mutable object
    copy = response.copy()
    copy['result'] = cPickle.loads(to_bytes(copy['result']))
    response = copy
    conn = Connection("")
    conn._exec_jsonrpc = lambda a, *args, **kwargs: response

# Generated at 2022-06-24 21:28:45.376986
# Unit test for method send of class Connection
def test_Connection_send():
    with open(os.devnull, "w") as out:
        # Save the standard output
        stdout = sys.stdout

        # Redirect the standard output to the devnull
        sys.stdout = out

        try:
            connection = Connection('ANSIBLE_SSH_CONTROL_PATH')
            res = connection.send(data)
        except:
            res = False

        # Restore the standard output
        sys.stdout = stdout

    if res != None:
        print("Test for send of class Connection successful!")
        return True
    else:
        print("Test for send of class Connection not successful!")
        return False

# Generated at 2022-06-24 21:29:01.425004
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b''
    var_0 = recv_data(bytes_0)
    assert var_0 == None
    var_0 = recv_data(bytes_0)
    assert var_0 == None
    var_0 = recv_data(bytes_0)
    assert var_0 == None
    var_0 = recv_data(bytes_0)
    assert var_0 == None
    var_0 = recv_data(bytes_0)
    assert var_0 == None
    test_case_0()


# Generated at 2022-06-24 21:29:07.840606
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    # Arrange
    ansible_connection_0 = Connection('/tmp/ansible_connection_0')
    name_0 = 'exec_command'
    args_0 = []
    kwargs_0 = {u'command': u'ls /'}

    # Act
    result = ansible_connection_0.__rpc__(name_0, *args_0, **kwargs_0)

    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-24 21:29:11.329948
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils import connection_loader
    connection = connection_loader.get('socket', None)
    print(exec_command(connection, 'ls'))


# Generated at 2022-06-24 21:29:13.303523
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'K'
    var_0 = recv_data(bytes_0)

# Generated at 2022-06-24 21:29:21.131103
# Unit test for method send of class Connection
def test_Connection_send():
    out = Connection(b'/tmp/ansible_connection.sock').send(b'{"jsonrpc": "2.0", "method": "exec_command", "id": "c21454ce-88f1-4bcf-9b75-2a5635bc06be", "params": (["ls"])}')
    print(out)
    assert out == '{"id": "c21454ce-88f1-4bcf-9b75-2a5635bc06be", "jsonrpc": "2.0", "result": ["ansible_connection.sock"]}'

# Generated at 2022-06-24 21:29:31.647073
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # __rpc__(self, name, *args, **kwargs):
    # parameters:
    # 1. name: rpc method to be executed over connection plugin that implements jsonrpc 2.0
    # 2. args: Ordered list of params passed as arguments to rpc method
    # 3. kwargs: Dict of valid key, value pairs passed as arguments to rpc method
    # For usage refer the respective connection plugin docs.

    # Check for specific argument.
    method_name = 'connection_name'
    assert(Connection._Connection__rpc__(method_name) == 'connection_name')
    print("Test Passed")

test_Connection___rpc__()

# Generated at 2022-06-24 21:29:32.719584
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    assert True


# Generated at 2022-06-24 21:29:41.406305
# Unit test for function exec_command
def test_exec_command():

    module = MockModule()
    module._socket_path = '/tmp/ansible-test.sock'
    (ret_code, ret_stdout, ret_stderr) = exec_command(module, 'test')
    assert ret_code == 0
    assert ret_stdout == 'exec_command: test'
    assert ret_stderr == ''

    module._socket_path = None
    (ret_code, ret_stdout, ret_stderr) = exec_command(module, 'test')
    assert ret_code == 1
    assert ret_stdout == ''
    assert ret_stderr == "assertion error: socket_path must be a value\n"

    (ret_code, ret_stdout, ret_stderr) = exec_command(module, 'test')

# Generated at 2022-06-24 21:29:47.537354
# Unit test for function exec_command
def test_exec_command():
    # Initialization
    command = 'command'
    # Invocation
    result = exec_command(command)
    # Verification
    # Adding an assertion
    assert result, 'Expected and actual result do not match'


# Generated at 2022-06-24 21:29:58.754689
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Switch to network namespace in test container
    os.system("ip netns exec test ip link set lo up")

    # Start netconf connection with switch
    module = AnsibleModule(argument_spec={
        'host': dict(default="localhost"),
        'port': dict(default=22),
        'user': dict(default="root"),
        'password': dict(default="password", no_log=True),
        'timeout': dict(default=10, type='int'),
        'ssh_keyfile': dict(default=None),
        'provider': dict(type='dict')
    }
    )

# Generated at 2022-06-24 21:30:12.810374
# Unit test for function exec_command
def test_exec_command():
    int_0 = 2031
    connection_0 = Connection(int_0)
    str_0 = 'method_name_1'
    int_0 = 0
    str_1 = 'str_1'
    str_2 = 'str_2'
    str_3 = 'str_3'
    exec_command(connection_0, str_0)
    return


# Generated at 2022-06-24 21:30:21.533986
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2031
    connection_0 = Connection(int_0)
    int_1 = 1
    assert connection_0._exec_jsonrpc(int_1) == False, "_exec_jsonrpc with int failed"
    assert connection_0.send(int_1) == False, "send with int failed"
    int_1 = "ansible"
    assert connection_0._exec_jsonrpc(int_1) == False, "_exec_jsonrpc with str failed"
    assert connection_0.send(int_1) == False, "send with str failed"


# Generated at 2022-06-24 21:30:25.560082
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    connection_0 = Connection(int_0)
    test_method_name_0 = 's3cret'
    str_0 = connection_0.__rpc__(test_method_name_0)


# Generated at 2022-06-24 21:30:27.289431
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test_case_0()

# Generated at 2022-06-24 21:30:33.050237
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    connection_0 = Connection(int_0)
    str_0 = 'exec_command'
    str_1 = 'configure terminal'
    str_2 = connection_0.__rpc__(str_0, str_1)
    assert str_2 == 'end\r\n'


# Generated at 2022-06-24 21:30:37.159698
# Unit test for function exec_command
def test_exec_command():
    test_module_0 = ''
    test_command_0 = "writemem"
    expected_0 = (0, '', '')
    result_0 = exec_command(test_module_0, test_command_0)
    assert result_0 == expected_0


# Generated at 2022-06-24 21:30:47.117605
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    connection_0 = Connection(int_0)
    str_0 = '1122223333'
    int_1 = 1
    str_1 = '__rpc__'
    int_2 = -1
    str_2 = '__rpc__'

# Generated at 2022-06-24 21:30:57.215970
# Unit test for method __rpc__ of class Connection

# Generated at 2022-06-24 21:30:59.858503
# Unit test for function exec_command
def test_exec_command():
    try:
        test_case_0()
    except ConnectionError as exc:
        if exc.code != 1:
            raise
    else:
        raise AssertionError("No exception raised")

# Generated at 2022-06-24 21:31:02.389449
# Unit test for function exec_command
def test_exec_command():
    assert exec_command(Connection, str()) == (0, str(), str())


# Generated at 2022-06-24 21:31:13.835325
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2031
    connection_0 = Connection(int_0)

    str_0 = "Xxu'2SfOx{(iY'1CAsjA5<|"
    connection_0.send(str_0)


# Generated at 2022-06-24 21:31:18.083253
# Unit test for function exec_command
def test_exec_command():
    module_0 = {}
    module_0['_socket_path'] = '~/.ansible/pc'
    command_0 = 'ansible-connection'
    ret_0 = exec_command(module_0, command_0)
    assert ret_0[0] == 0
    assert ret_0[1] == ''
    assert ret_0[2] == ''



# Generated at 2022-06-24 21:31:21.956650
# Unit test for function recv_data
def test_recv_data():
    int_0 = None
    socket_0 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    recv_data(socket_0)
    socket_0.close()


# Generated at 2022-06-24 21:31:23.348515
# Unit test for function exec_command
def test_exec_command():
    assert True


# Generated at 2022-06-24 21:31:35.821007
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(b"/tmp/file.sock")
    send_data(s, b"\x00\x00\x00\x00\x00\x00\x00\x04")
    send_data(s, b"\x00\x00\x00\x00\x00\x00\x00\x04")
    send_data(s, b"\x00\x00\x00\x00\x00\x00\x00\x04")
    send_data(s, b"\x00\x00\x00\x00\x00\x00\x00\x04")

# Generated at 2022-06-24 21:31:37.085479
# Unit test for function exec_command
def test_exec_command():
    exec_command(1, 'foo')


# Generated at 2022-06-24 21:31:44.499554
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_2 = 6233
    int_3 = 6172
    int_4 = 6170
    int_5 = 6173
    int_6 = 6171
    connection_2 = Connection(int_2)
    connection_2._exec_jsonrpc = test_case_0
    connection_2.__rpc__(int_3, int_4, int_5, int_6)

if __name__ == "_main_":
    test_Connection___rpc__()

# Generated at 2022-06-24 21:31:47.806818
# Unit test for function exec_command
def test_exec_command():
    try:
        command_0 = ""
        module_0 = exec_command(command_0)
        assert False, "unreachable"
    except AssertionError as exc:
        assert exc.args[0] == "socket_path must be a value"


# Generated at 2022-06-24 21:31:56.659051
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    connection_0 = Connection(int_0)
    int_1 = -11794
    str_2 = 'f'
    dict_3 = dict()
    dict_3['Y'] = str_2
    int_4 = 336
    str_5 = 'G'
    dict_3['T'] = str_5
    int_6 = -166
    str_7 = 'd'
    dict_3['p'] = str_7
    int_8 = -23578
    str_9 = '0'
    dict_3['l'] = str_9
    int_10 = -22238
    str_11 = 'C'
    dict_3['H'] = str_11
    int_12 = -13861
    str_13 = '/'

# Generated at 2022-06-24 21:32:01.948560
# Unit test for method send of class Connection
def test_Connection_send():
    # Assigning '0' to a_0
    a_0 = 0
    # Creating an instance of class Connection
    connection_0 = Connection(a_0)
    # Assigning '"hello"' to b_0
    b_0 = "hello"
    # Sending data over connection
    c_0 = connection_0.send(b_0)
    # Evaluating assertion
    assert c_0 == "hello", 'Cannot send over connection'



# Generated at 2022-06-24 21:32:20.892902
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    str_0 = 'boolean'
    bool_0 = False
    key_val_0 = {
        'key_0': bool_0,
    }
    str_1 = 'boolean'
    bool_1 = False
    key_val_1 = {
        'key_0': bool_1,
    }
    str_2 = 'boolean'
    bool_2 = False
    key_val_2 = {
        'key_0': bool_2,
    }
    connection_0 = Connection(int_0)
    dict_0 = connection_0.__rpc__(str_0, key_val_0)
    dict_1 = connection_0.__rpc__(str_1, key_val_1)

# Generated at 2022-06-24 21:32:23.379208
# Unit test for function recv_data
def test_recv_data():
    s = None

    try:
        send_data(s, to_bytes('TEST'))
    except Exception as err:
        assert type(err) is AttributeError


# Generated at 2022-06-24 21:32:30.065576
# Unit test for function exec_command
def test_exec_command():
    args_0 = {"module_name": "module_arg_0", "module_args": "module_args_arg_0"}
    kwargs_0 = {'data': 'data_kwarg_0', 'msg': 'msg_kwarg_0'}

    # Call exec_command with correct arguments
    print("Call exec_command with correct arguments")
    retval_0 = exec_command(args_0, kwargs_0)
    assert retval_0 == args_0

# Generated at 2022-06-24 21:32:38.807840
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
  for int_0 in range(10):
    connection_0 = Connection(int_0)
    list_3 = [bool_0]
    dict_0 = dict_5
    dict_1 = dict_6
    dict_2 = dict_7
    dict_3 = dict_8
    dict_4 = dict_9
    # fail on str_0
    try:
      connection_0._exec_jsonrpc(str_1, *list_3, **dict_0)
    except ConnectionError:
      pass
    # fail on str_1
    try:
      connection_0._exec_jsonrpc(str_2, *list_3, **dict_1)
    except ConnectionError:
      pass
    # fail on str_2

# Generated at 2022-06-24 21:32:49.463487
# Unit test for method send of class Connection
def test_Connection_send():
    print('Testing send')

    int_0 = 2031
    connection_0 = Connection(int_0)

    data = '\x1b\x00\x00\x00\x02\x00\x00\x00\x11\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00\xfe\xff\xff\xff'
    expected_result = '\x1b\x00\x00\x00\x02\x00\x00\x00\x11\x00\x00\x00\x06\x00\x00\x00'


# Generated at 2022-06-24 21:32:53.675711
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2031
    connection_0 = Connection(int_0)
    data_0 = "2010-01-01"
    out_0 = connection_0.send(data_0)
    assert out_0 == "2010-01-01"


# Generated at 2022-06-24 21:32:59.874185
# Unit test for function exec_command
def test_exec_command():
    module_0 = Mock()
    module_0._socket_path = '/tmp/ansible-test-sock-0'
    command_0 = 'ls -al; touch /tmp/ansible-test-file-0'
    int_0 = 0
    int_1 = 0
    str_0 = ''

    (int_1, str_0, str_1) = exec_command(module_0, command_0)

    assert int_0 == int_1
    assert str_1 == ''


# Generated at 2022-06-24 21:33:02.105038
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2031
    connection_0 = Connection(int_0)
    str_0 = "hello"
    connection_0.send(str_0)

# Generated at 2022-06-24 21:33:07.820304
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    connection_0 = Connection(int_0)
    name_0 = "y\u0019Vw\u001c\u001fH\u000f\u000f\u0005\t\u001b\u001e\u0018"
    args_0 = []
    kwargs_0 = {}
    connection_0.__rpc__(name_0, *args_0, **kwargs_0)


# Generated at 2022-06-24 21:33:10.798683
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 2031
    connection_0 = Connection(int_0)
    str_0 = "attribute"
    # result = connection_0.__rpc__(str_0)
    # assert result == "result"


# Generated at 2022-06-24 21:33:35.664216
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 492
    str_0 = "X"
    str_1 = "q3rYrZl}SMj^zln;2t.TNy.ePX9<*a{D>7?)^qr+rpCJ!M(8z!7V>P5yF/7%5)l*upln`HN`Zu1g:@z/o*eH0%cO"
    connection_0 = Connection(int_0)

    # Test case 0
    # Call method send on Connection object connection_0 with argument str_0
    test_case_0(connection_0, str_0)
    # Test case 1
    # Call method send on Connection object connection_0 with argument str_1
    test_case_1(connection_0, str_1)

   

# Generated at 2022-06-24 21:33:37.248926
# Unit test for function exec_command
def test_exec_command():
    assert exec_command(Connection, 'exec_command') == 0


# Generated at 2022-06-24 21:33:41.217950
# Unit test for function exec_command
def test_exec_command():
    test_value_0 = ''
    test_value_1 = ''
    test_value_2 = ''
    test_value_3 = ''
    test_value_4 = ''

    assert exec_command(test_value_0, test_value_1) == (test_value_2, test_value_3, test_value_4)


# Generated at 2022-06-24 21:33:45.173074
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # _exec_jsonrpc returns a dict
    # connection plugin's rpc methods return a dict
    int_0 = 2031
    connection_0 = Connection(int_0)
    # assert connection_0.exec_command(int_0) == dict()


# Generated at 2022-06-24 21:33:55.180390
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Create int instance, named "int_0"
    int_0 = 2031

    # Create Connection instance, named "connection_0"
    connection_0 = Connection(int_0)

    # Create str instance, named "str_0"
    str_0 = "exec_command"

    # Create str instance, named "str_1"
    str_1 = "show ip arp"

    # Assert that the expression "connection_0.exec_command(str_1)" returns int_0
    assert (connection_0.exec_command(str_1) == int_0)


# Generated at 2022-06-24 21:33:58.178857
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    assert exec_command(
        *test_case_0()
    ) == (
        0,
        "",
        "error during RPC response testing"
    )

# Generated at 2022-06-24 21:34:00.088219
# Unit test for function exec_command
def test_exec_command():
    """
    Unit test for function exec_command
    """
    assert True



# Generated at 2022-06-24 21:34:03.707346
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Setup test case
    method = None
    args = None
    kwargs = None

    # Perform the test
    result = Connection.__rpc__(method, args, kwargs)

    # Verify the results



# Generated at 2022-06-24 21:34:08.054463
# Unit test for function exec_command
def test_exec_command():
    int_0 = 2031
    module_0 = None
    str_0 = 'ls -l'
    test_case_0()
    exec_command(module_0, str_0)


# Generated at 2022-06-24 21:34:09.441042
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2031
    connection_0 = Connection(int_0)


# Generated at 2022-06-24 21:34:53.719671
# Unit test for function exec_command
def test_exec_command():
    module_0 = mock.Mock()
    module_0.params = dict()
    module_0.params['host'] = 'host_1'
    module_0.params['port'] = 'port_1'
    module_0.params['remote_user'] = 'remote_user_1'
    module_0.params['password'] = 'password_1'
    module_0.params['timeout'] = 'timeout_1'
    module_0._socket_path = '_socket_path_1'
    command_0 = 'command_1'
    test_case_0(module_0, command_0)

# Generated at 2022-06-24 21:34:56.372832
# Unit test for function exec_command
def test_exec_command():
    str_0 = '2\\*?Fc<i\\p'
    result = exec_command('3.3', str_0)
    assert result[0] == 0


# Generated at 2022-06-24 21:34:58.130599
# Unit test for function recv_data
def test_recv_data():
    assert abs(recv_data(test_recv_data) - 0.36) < 1e-12


# Generated at 2022-06-24 21:35:00.371512
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2031
    connection_0 = Connection(int_0)
    int_0 = 9817
    connection_0.send(int_0)


# Generated at 2022-06-24 21:35:01.261048
# Unit test for function recv_data
def test_recv_data():
    assert True


# Generated at 2022-06-24 21:35:06.331985
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    try:
        int_0 = 2031
        connection_0 = Connection(int_0)
    except Exception as e:
        assert False, e


# Generated at 2022-06-24 21:35:07.247315
# Unit test for function recv_data
def test_recv_data():
    assert callable(recv_data)


# Generated at 2022-06-24 21:35:10.541226
# Unit test for method send of class Connection
def test_Connection_send():
    # Test for successful execution of a pass case
    try:
        int_0 = 2031
        connection_0 = Connection(int_0)

    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 21:35:12.832377
# Unit test for function exec_command
def test_exec_command():
    int_0 = 2031
    str_0 = "WxHv0m0XZf"
    int_1 = exec_command(int_0, str_0)


# Generated at 2022-06-24 21:35:15.110010
# Unit test for function exec_command
def test_exec_command():
    str_0 = 'dev'
    str_1 = 'up'
    if exec_command(str_0, str_1):
        pass
    else:
        pass


# Generated at 2022-06-24 21:35:54.936620
# Unit test for function recv_data
def test_recv_data():
    int_1 = 2031
    connection_1 = Connection(int_1)
    recv_data(connection_1)


# Generated at 2022-06-24 21:35:58.638828
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    int_0 = 4095
    connection_0 = Connection(int_0)
    arguments = [[1]]
    kwargs = {"kwargs_0": arguments}
    method_0 = "rpc_method"
    # Function call
    result_0 = connection_0.__rpc__(method_0, **kwargs)


# Generated at 2022-06-24 21:36:02.387140
# Unit test for function recv_data
def test_recv_data():
    try:
        socket_0 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    except:
        pass

    recv_data(socket_0)


# Generated at 2022-06-24 21:36:03.399110
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test_case_0()


# Generated at 2022-06-24 21:36:06.711196
# Unit test for function recv_data
def test_recv_data():
    int_0 = 2031
    connection_0 = Connection(int_0)
    class_0 = connection_0.send
    str_0 = class_0(int_0)
    return str_0


# Generated at 2022-06-24 21:36:07.292938
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    pass

# Generated at 2022-06-24 21:36:10.669696
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 1528
    connection_0 = Connection(int_0)
    data_0 = '\x00\x00\x00\x00\x00\x00\x00\x00'
    response_0 = connection_0.send(data_0)


# Generated at 2022-06-24 21:36:17.311905
# Unit test for function recv_data
def test_recv_data():
    data = '56789'

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('/tmp/ansible-systest.sock')

    send_data(sf, to_bytes(data))
    response = recv_data(sf)

    assert response == data



# Generated at 2022-06-24 21:36:22.848033
# Unit test for method send of class Connection
def test_Connection_send():
    connection_0 = Connection(22)
    connection_0.send("asdf")





# Generated at 2022-06-24 21:36:25.450805
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Setup test case
    int_0 = 2031
    connection_0 = Connection(int_0)

    # Teardown test case
    return



# Generated at 2022-06-24 21:37:03.860778
# Unit test for function exec_command
def test_exec_command():
    int_0 = 2031
    str_0 = 'a'
    int_1, str_1, str_2 = exec_command(int_0, str_0)
    assert int_1 == 0
    assert str_1 == ''
    assert str_2 == ''


# Generated at 2022-06-24 21:37:06.154193
# Unit test for function exec_command
def test_exec_command():
    # FIXME: implement a test that tests the functionality of exec_command
    pass


# Generated at 2022-06-24 21:37:11.910126
# Unit test for method send of class Connection
def test_Connection_send():
    int_1 = -15426
    connection_1 = Connection(int_1)
    str_1 = 'abc'
    with pytest.raises(Exception) as excinfo:
        connection_1.send(str_1)



# Generated at 2022-06-24 21:37:17.507967
# Unit test for method send of class Connection
def test_Connection_send():
    int_0 = 2032
    connection_0 = Connection(int_0)
    byte_0 = bytearray(1)
    byte_0[0] = 82
    str_0 = str(byte_0, encoding='ISO-8859-1')
    str_1 = connection_0.send(str_0)
    assert str_1 == ""
    assert connection_0.socket_path == 2032


# Generated at 2022-06-24 21:37:20.279311
# Unit test for function recv_data
def test_recv_data():
    # Try to retrieve data from a socket 
    args = ('socket',)
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        recv_data(s)
    except Exception as e:
        assert(e == 'File descriptor is not open')
 

# Generated at 2022-06-24 21:37:21.798488
# Unit test for function recv_data
def test_recv_data():
    assert recv_data(int_0) == int_0


# Generated at 2022-06-24 21:37:27.312998
# Unit test for function recv_data
def test_recv_data():
    try:
        int_0 = input('Enter an integer: ')
        connection_0 = Connection(int_0)
    except NameError:
        pass
    pass

