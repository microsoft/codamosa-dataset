

# Generated at 2022-06-24 21:27:44.698750
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(1)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(s.getsockname())
    server, addr = s.accept()

    send_data(client, b'test_data\n')
    assert(b'test_data\n' == recv_data(server))

    client.close()
    s.close()


# Generated at 2022-06-24 21:27:49.774482
# Unit test for function exec_command
def test_exec_command():
    """
    Test exec_command function
    """
    connection_0 = Connection(None)
    buf = bytearray(b"\xff\x00\xff\x00\x00\x00\x00\x00\xff\x00\xff\x00")
    assert connection_0.exec_command(buf) == ""


# Generated at 2022-06-24 21:28:01.957754
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    socket_0 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    socket_0.connect(bytes_0)

    packed_len = struct.pack('!Q', len(bytes_0))
    socket_0.sendall(packed_len + bytes_0)
    assert bytes_0 == recv_data(socket_0)

    packed_len = struct.pack('!Q', len(bytes_0))
    socket_0.sendall(packed_len + bytes_0)
    assert bytes_0 == recv_data(socket_0)


# Generated at 2022-06-24 21:28:03.924196
# Unit test for function exec_command
def test_exec_command():
    # exec_command(module, command)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:28:09.415174
# Unit test for function exec_command
def test_exec_command():

    module_0 = Mock()
    module_0.os = Mock()
    module_0.os.write = Mock()
    module_0._socket_path = b''
    command_0 = ''

    # Test function
    try:
        exec_command(module_0, command_0)
    except Exception as e:
        assert False, "An exception occurred during testing"


# Generated at 2022-06-24 21:28:12.784543
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # send data
    recv_data(s)


# Generated at 2022-06-24 21:28:13.672753
# Unit test for function exec_command
def test_exec_command():
    assert isinstance(exec_command(None, None), tuple)


# Generated at 2022-06-24 21:28:17.669127
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    data = dict(a = 1, b = 2)

    result = exec_command(module_0, 'run_command', data = data)
    assert result[0] == 0
    assert type(result[1]) is dict


# Generated at 2022-06-24 21:28:20.488466
# Unit test for function exec_command
def test_exec_command():
    arg1 = ''
    arg2 = bytes_0
    obj = exec_command(arg1, arg2)
    assert obj == (arg1, arg2, arg1)


# Generated at 2022-06-24 21:28:21.875152
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test_case_0()


# Generated at 2022-06-24 21:28:32.457237
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b''
    connection_0 = Connection(bytes_0)
    byte_array_0 = bytearray('c0F8)\\\xc2\xac\x07\n\xe8\xe4|\x1f\x13\xec\x98\x1c')
    byte_array_1 = bytearray('')
    unicode_0 = connection_0._exec_jsonrpc(byte_array_0, byte_array_1)



# Generated at 2022-06-24 21:28:39.369002
# Unit test for function exec_command

# Generated at 2022-06-24 21:28:44.773663
# Unit test for function exec_command
def test_exec_command():
    module_0 = type('', (), {})
    module_0._socket_path = './test_file6.txt'
    command_0 = 'test_command'
    code_0, out_0, err_0 = exec_command(module_0, command_0)
    res_0 = (code_0, out_0, err_0)
    assert res_0 == (0, '', '')


# Generated at 2022-06-24 21:28:50.802533
# Unit test for function recv_data
def test_recv_data():

    # Creating a new socket object
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect("/var/run/ansible/ansible-ssh.socket")

    # Sending data
    send_data(sf, b'a123')
    # Receving data
    data = recv_data(sf)

    # Closing socket
    sf.close()
    # Asserting
    assert data == b'a123'



# Generated at 2022-06-24 21:29:01.129508
# Unit test for function exec_command
def test_exec_command():

    # Create mock module object with all required parameters for function exec_command
    class AnsibleModule:
        def __init__(self, socket_path=None, mod=None):
            self.socket_path = socket_path
            self.params = {'mod': mod}

    # Create mock module object with all required parameters for function exec_command
    class AnsibleModule:
        def __init__(self, socket_path=None, mod=None):
            self.socket_path = socket_path
            self.params = {'mod': mod}

    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    module = AnsibleModule(bytes_0)


# Generated at 2022-06-24 21:29:10.978937
# Unit test for method __rpc__ of class Connection

# Generated at 2022-06-24 21:29:21.689749
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection_0 = Connection(b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL')
    args_0 = ()
    kwargs_0 = {}
    name_0 = 'environ_fallback'
    exception_0 = ConnectionError
    with pytest.raises(exception_0) as excinfo_0:
        connection_0.__rpc__(name_0, *args_0, **kwargs_0)
    msg_0 = "Failed to decode JSON from response to environ_fallback. Received '{}'."
    msg_0 += "\n{}"

# Generated at 2022-06-24 21:29:33.025532
# Unit test for method send of class Connection
def test_Connection_send():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    str_1 = 'GLEIMWBJTQCOKQWITJCJMUZPRPYJYKSZKVMCEFVKSGXIURJBKVQQBGCQSWKITWJZHCFPCZJYDFZKEXRLZCIKH'

# Generated at 2022-06-24 21:29:35.263115
# Unit test for function recv_data
def test_recv_data():
    res1 = recv_data(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    assert res1 == None


# Generated at 2022-06-24 21:29:40.551633
# Unit test for function exec_command
def test_exec_command():
    module_0 = test_case_0()
    command_0 = b'\x19\xda\x9ezd`\xbd\x1f\x0c\xf4\x12\xbe\xbf\xfd'
    result = exec_command(module_0, command_0)
    assert result is not None


# Generated at 2022-06-24 21:29:57.662415
# Unit test for function exec_command
def test_exec_command():

    bytes_0 = b'\xde\x92\xe8\xaa\x95s\xac\xa0\x8f\xbf\x13\x9c\xdb\xef\x00\xe6\xf4\xe4#\xad'
    dict_0 = {'hello': 'world', '2': 3.0}
    list_0 = [1, 2, 3]
    list_1 = [dict_0, b'\xde\x92\xe8\xaa\x95s\xac\xa0\x8f\xbf\x13\x9c\xdb\xef\x00\xe6\xf4\xe4#\xad', list_0]

# Generated at 2022-06-24 21:30:01.819329
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection_0 = Connection()
    try:
        connection_0.__rpc__()
    except (TypeError, AttributeError) as exc:
        assert isinstance(exc, TypeError)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:30:08.104989
# Unit test for method send of class Connection
def test_Connection_send():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    data_0 = to_bytes('$')
    try:
        connection_0.send(data_0)
    except ConnectionError:
        pass


# Generated at 2022-06-24 21:30:17.356385
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'B\x17\xae\xfb\xaa\x8a\xf3\x05\x0cr\x13\xfb\x0f\xb6\x1e\xf8r\xa3\x0b\xaf\x05$\x85\xf6l\x1d\x0c\xc2'
    socket_0 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    socket_0.connect((to_bytes('127.0.0.1'), 80))
    socket_0.send(bytes_0)
    data_0 = recv_data(socket_0)

# Generated at 2022-06-24 21:30:21.854880
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\x17\xa1\x0b\x9f\x89\x07\x0f\x8b\xd4/K\xd2\x1f\x1a\x18\x80\xa3Hx\xfd\x8c\x09\xbd\x1e'
    connection_0 = Connection(bytes_0)

    # Calling __rpc__ with arguments:
    # * (str, int)
    # ** {'arg_1': dict}
    result = connection_0.__rpc__('', 0)


# Generated at 2022-06-24 21:30:27.274021
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xecx\x83\x1e,\xbd\x94\x12\xd5v\xb9\xeb\x80\x98\xca.\x0b\xcc\xe8\x99\xa0\x9d\x02'
    connection_0 = Connection(bytes_0)
    str_0 = to_text(connection_0.__rpc__())
    print(str_0)



# Generated at 2022-06-24 21:30:39.415460
# Unit test for function recv_data
def test_recv_data():
    b"Runs the recv_data() test cases"
    # TEST CASE: Default behavior

    bytes_0 = b'p\xc0\xa7\xae\x19\xf0\x1d\x88U\x9e\x8c\xc2\xfc\xa2\x0c\x83)\xce\x89!\x9e\x8f\xb4'
    socket_0 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    recv_data(socket_0)



    # TEST CASE: Default behavior


# Generated at 2022-06-24 21:30:42.161191
# Unit test for function recv_data
def test_recv_data():
    my_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    my_socket.connect("/tmp/test-socket-%s" % os.getpid())
    send_data(my_socket, b'hello')
    resp = recv_data(my_socket)
    assert resp == b"hello"
    my_socket.close()

# Generated at 2022-06-24 21:30:49.459691
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    with pytest.raises(ConnectionError):
        connection_0._exec_jsonrpc(None)
    with pytest.raises(ConnectionError):
        connection_0._exec_jsonrpc(None)


# Generated at 2022-06-24 21:30:53.486072
# Unit test for function exec_command
def test_exec_command():
    test_command = b'echo hello world'
    # Test execution of the exec_command function
    exec_command(test_command)



# Generated at 2022-06-24 21:31:09.563615
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    str_0 = 'Cannot decode JSON'
    str_1 = 'Unable to decode JSON from response to {0}({1}). Received \'{2}\'.'
    str_2 = '2.0'
    str_3 = 'invalid json-rpc id received'
    str_4 = 'exec_command'
    str_5 = 'unable to connect to socket {0}. See the socket path issue category in Network Debug and Troubleshooting Guide'
    str_6 = ''

# Generated at 2022-06-24 21:31:18.454343
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)

# Generated at 2022-06-24 21:31:26.117049
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind("/tmp/salim.sock")
    s.listen(1)
    conn, addr = s.accept()

    data = b'Hello'
    packed_len = struct.pack('!Q', len(data))
    conn.sendall(packed_len + data)
    ret = recv_data(conn)
    assert ret == data



# Generated at 2022-06-24 21:31:36.943408
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # string -> object
    with pytest.raises(NotImplementedError) as e_info:
        Connection___rpc__('', '', '', '')
    # object -> object
    with pytest.raises(NotImplementedError) as e_info:
        Connection___rpc__(Connection, '', '', '')
    # object -> object
    with pytest.raises(NotImplementedError) as e_info:
        Connection___rpc__(Connection(), '', '', '')
    # module -> object

# Generated at 2022-06-24 21:31:43.486299
# Unit test for function exec_command
def test_exec_command():
    connection_1 = Connection(b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL')
    bytes_1 = b'\x00'
    result = exec_command(connection_1, bytes_1)
    assert result


# Generated at 2022-06-24 21:31:49.450133
# Unit test for function recv_data
def test_recv_data():
    _sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    _sf.bind('/var/tmp/ansible.sock')
    _sf.listen(5)

    client, address = _sf.accept()
    known_good_response = 'hello world'

    send_data(client, to_bytes(known_good_response))
    response = recv_data(client)

    assert response == known_good_response

    client.close()
    _sf.close()



# Generated at 2022-06-24 21:31:50.906879
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    print("")
    print("test_Connection___rpc__")


# Generated at 2022-06-24 21:31:55.736996
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)

    result_0 = connection_0._exec_jsonrpc('exec_command', 'command')


# Generated at 2022-06-24 21:31:59.616264
# Unit test for method send of class Connection
def test_Connection_send():
    try:
        bytes_0 = b''
        connection_0 = Connection(bytes_0)
        str_0 = '10'
        bytes_1 = to_bytes(str_0)
        __ret = connection_0.send(bytes_1)
    except AssertionError as e:
        __msg = e.args[0]

# Generated at 2022-06-24 21:32:07.545210
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    # This will fail if we don't pass AF_UNIX and SOCK_STREAM to socket.socket
    socket_0 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    socket_0.connect(bytes_0)


# Generated at 2022-06-24 21:32:29.065150
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)

    str_0 = '--'
    str_1 = '--'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    result_0 = connection_0._exec_jsonrpc(str_0, str_1, data=bytes_1)


# Generated at 2022-06-24 21:32:36.543168
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xa7\xf6\xd6\xce\x1f\x87\x01\x0b\x9b\x05\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    str_0 = '\x1f\x87\x01\x0b\x9b\x05\\\x931\x13 \xb3N|\xda\xc4RL'
    int_0 = connection_0.__rpc__(str_0)
    assert 0 == int_0


# Generated at 2022-06-24 21:32:46.651902
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    bytes_1 = b'this is a test'

# Generated at 2022-06-24 21:32:55.473076
# Unit test for function recv_data

# Generated at 2022-06-24 21:33:04.612593
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    string_0 = 'e\x1a\x8b\x0b\x0c\x11\x17\x0b\x1a\r\r\x06\x1b: #u\x15\x7fqx{\x1e'
    bytes_1 = b'\x8a\x04\xe0\xfd\xf6\x8d\x80\x1b`\xaa\x15\x04:R\x10)\x98\xe3\x8a\x9d'

# Generated at 2022-06-24 21:33:09.466259
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    bytes_1 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'

# Generated at 2022-06-24 21:33:18.437410
# Unit test for function recv_data
def test_recv_data():
    # The actual function returns None so we have to do tests manually.

    class MockSocket(object):
        def recv(self, data_len):
            return [b'\xad\xfc\x14\xd3', b'c*\x8b\x04\\\x931', b'\x13 \xb3N|\xda\xc4', b'RL']

    s = MockSocket()
    assert recv_data(s) == b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'

    class MockSocket(object):
        def recv(self, data_len):
            return None

    s = MockSocket()
    assert recv_data(s) is None



# Generated at 2022-06-24 21:33:27.230091
# Unit test for function exec_command
def test_exec_command():
    bytes_0 = b'?\x06\xe6\x1b9\x1a\x86`\xb9\xfa\x8d\xa8n\x0f\xcc\x9b\x9b\x02\xa2\t\xef\xa5\x1d\xbc\xb3\x9f\xee'
    module_0 = type('', (), {})()
    setattr(module_0, '_socket_path', bytes_0)
    bytes_1 = b'\x8f\x95\xc7\xac\xe4\xa8\x11,\xfc\xdb~U\xa6\xd5\x17\xb2\xd6'

# Generated at 2022-06-24 21:33:35.578100
# Unit test for function recv_data
def test_recv_data():
    bytes_0 = b'\xad\xfc\x14\xd3c*\x8b\x04\\\x931\x13 \xb3N|\xda\xc4RL'
    connection_0 = Connection(bytes_0)
    test_payload = {'name': 'test_payload'}
    data = cPickle.dumps(test_payload, protocol=0)
    packed_len = struct.pack('!Q', len(data))
    os.write(0, packed_len + data)
    os.fsync(0)
    response = connection_0.send('test_data')
    assert response['name'] == 'test_payload'


# Generated at 2022-06-24 21:33:40.276353
# Unit test for function exec_command
def test_exec_command():
    assert callable(exec_command)
    try:
        exec_command(None, None)
        assert False, "exec_command should have raised an exception"
    except AssertionError as e:
        assert True

if __name__ == "__main__":
    # execute only if run as a script
    test_case_0()
    test_exec_command()

# Generated at 2022-06-24 21:34:07.455101
# Unit test for method send of class Connection
def test_Connection_send():
    mock_send = MagicMock(side_effect=send_data)
    mock_recv = MagicMock(side_effect=recv_data)
    mock_socket = MagicMock()
    mock_socket.connect.side_effect = [None]
    mock_socket.sendall.side_effect = [None]
    mock_socket.recv.side_effect = ['xyz']
    mock_socket.close.side_effect = [None]
    str_0 = 'kI:_2tW:CH]1E'
    mock_socket.__enter__.side_effect = [mock_socket]
    mock_socket.__exit__.side_effect = [None]


# Generated at 2022-06-24 21:34:11.893158
# Unit test for function exec_command
def test_exec_command():
    module = type('AnsibleModule', (), {})
    module._socket_path = 'test_value__socket_path'
    command = 'test_value_command'
    result = exec_command(module, command)
    assert len(result) == 3


# Generated at 2022-06-24 21:34:15.104948
# Unit test for function recv_data
def test_recv_data():
    var_1 = 'kI:_2tW:CH]1E'
    var_1 = b'kI:_2tW:CH]1E'
    var_2 = recv_data(var_1)


# Generated at 2022-06-24 21:34:21.835680
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    str_0 = 'kI:_2tW:CH]1E'
    str_1 = 'kI:_2tW:CH]1E'
    var_0 = recv_data(str_1)


# Generated at 2022-06-24 21:34:26.317032
# Unit test for function exec_command
def test_exec_command():
    module = 'module'
    command = 'command'

    try:
        result = exec_command(module, command)
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-24 21:34:27.384545
# Unit test for function exec_command
def test_exec_command():
    assert True


# Generated at 2022-06-24 21:34:29.644310
# Unit test for method send of class Connection
def test_Connection_send():
    str_0 = 'kI:_2tW:CH]1E'
    assert send_data(str_0, str_0) == None, "Failed to execute method send of class Connection"


# Generated at 2022-06-24 21:34:30.747781
# Unit test for function recv_data
def test_recv_data():
    assert test_case_0() == 'CH]1E'



# Generated at 2022-06-24 21:34:40.415590
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    try:
        var_0 = Connection(str_0)
        var_0.__rpc__(str_1, *str_2, **str_3)
        var_5 = ConnectionError(str_4)
        raise var_5
    except ConnectionError as var_6:
        var_7 = var_6.err
        var_8 = var_6.message
        var_9 = var_6.exception
        print(var_7)
        print(var_8)
        print(var_9)
    except Exception as var_10:
        var_11 = str(var_10)
        print(var_11)


# Generated at 2022-06-24 21:34:42.511367
# Unit test for function exec_command
def test_exec_command():
    module = None
    command = ""
    code, out, err = exec_command(module, command)


# Generated at 2022-06-24 21:35:10.107498
# Unit test for function exec_command
def test_exec_command():
    str_0 = 'kI:_2tW:CH]1E'
    str_1 = '$N6Q?4;+q!@JG'
    str_2 = '_LH7I+]E[75}l'
    str_3 = '_LH7I+]E[75}l'
    var_0 = exec_command(str_0, str_1)
    var_1 = Connection(str_2)
    var_2 = var_1._exec_jsonrpc(str_3)


# Generated at 2022-06-24 21:35:12.120382
# Unit test for function recv_data
def test_recv_data():
    var_0 = test_case_0()
    print('var_0')
    print(var_0)
    print('var_0')



# Generated at 2022-06-24 21:35:14.453823
# Unit test for function recv_data
def test_recv_data():
    """
    Unit test for function recv_data
    """
    assert True == True


# Generated at 2022-06-24 21:35:23.787300
# Unit test for method send of class Connection
def test_Connection_send():
  # Test connection send using socket
  str_0 = 'mX9@G6]'
  int_0 = struct.unpack('!Q', str_0)
  str_1 = 'foo'
  var_0 = json.loads(str_1)
  str_2 = '_'
  if len(str_1) > int_0:
    var_1 = str_1.split(str_2)
  else:
    var_1 = str_1

  str_3 = 't:!q='
  int_1 = struct.unpack('!Q', str_3)
  if int_1 == 0:
    str_4 = 'mX9@G6]'

  if int_0 == 0:
    str_6 = ','

# Generated at 2022-06-24 21:35:28.408172
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    test_case_0()

# Generated at 2022-06-24 21:35:38.877948
# Unit test for method send of class Connection
def test_Connection_send():
    try:
        socket_path='/tmp/ansible-connection'
        data='{}'
        cls = Connection(socket_path)
        cls.send(data)
    except ConnectionError as exc:
        assert False, "ConnectionError is raise: %s" % exc

    try:
        socket_path='/tmp/ansible-connection-test'
        data='{}'
        cls = Connection(socket_path)
        cls.send(data)
        assert False, "ConnectionError is not raise"
    except ConnectionError:
        pass


#
# Test part of method '__rpc__' of class Connection
#


# Generated at 2022-06-24 21:35:46.603288
# Unit test for function exec_command
def test_exec_command():
    str_0 = 'C\x0fVDk\x8b\x19\x1f\xa7\x84\x19\xbe\xbf\xa2k\x1e\x19\xc3\xa3\x04\xb3\x8c\x18\x9e\x97H\x8b\x10\xa3\x93\x08\x8d\x0b\x9e'

# Generated at 2022-06-24 21:35:50.247779
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    var___rpc___0 = Connection('')
    var___rpc___1 = var___rpc___0.__rpc__('_6F&^Q9Iq+')


# Generated at 2022-06-24 21:35:51.260158
# Unit test for function exec_command
def test_exec_command():
    assert exec_command('module', 'command') == (0, '', '')



# Generated at 2022-06-24 21:35:52.429560
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # FIXME: We should test for something interesting instead of just a static case.
    test_case_0()

# Generated at 2022-06-24 21:36:43.383749
# Unit test for function exec_command
def test_exec_command():
    arg0 = {"_ansible_verbosity": 0, "_ansible_no_log": False, "_ansible_debug": False, "_ansible_socket": "/tmp/ansible-conn-test", "_ansible_check_mode": False, "tty": False, "diff": True}
    test_command = "uname -a"
    test_exec_command = exec_command(arg0, test_command)
    assert test_exec_command[0] == 0


# Generated at 2022-06-24 21:36:45.455070
# Unit test for function recv_data
def test_recv_data():
    str_0 = 'kI:_2tW:CH]1E'
    var_0 = recv_data(str_0)


# Generated at 2022-06-24 21:36:47.752775
# Unit test for function recv_data
def test_recv_data():
    socket = get_open_socket()
    assert recv_data(socket) == 'pong\n'
    socket.close()


# Generated at 2022-06-24 21:36:55.336137
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Uncomment to test
    # connection = Connection(None)
    # connection.__rpc__('', None, None)

    # Mock send method
    Connection.send = lambda self, data: None

    # Mock _exec_jsonrpc method
    Connection._exec_jsonrpc = lambda self, name, *args, **kwargs: {'id': None, 'result': None}

    # Test successful call
    connection = Connection(None)
    try:
        connection.__rpc__(None, None, None)
    except Exception:
        assert False
    assert True

    # Test call with exception
    connection = Connection(None)
    try:
        connection.__rpc__(None, None, None)
        assert False
    except ConnectionError:
        assert True



# Generated at 2022-06-24 21:37:00.137965
# Unit test for function recv_data
def test_recv_data():
    try:
        assert test_case_0() == ('\x19\x03\x17\x02\x12\x01\x05\x00', None)
    except:
        raise AssertionError("`test_recv_data` failed!")



# Generated at 2022-06-24 21:37:02.520866
# Unit test for function recv_data
def test_recv_data():
    str_0 = 'kI:_2tW:CH]1E'
    var_0 = recv_data(str_0)
    assert var_0 == str_0

# Generated at 2022-06-24 21:37:03.728759
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    # Test case 0
    assert(test_case_0())


# Generated at 2022-06-24 21:37:10.595567
# Unit test for method send of class Connection
def test_Connection_send():
    module = AnsibleModule(
        argument_spec=dict(
            socket_path=dict(type='str'),
            data=dict(type='str')
        )
    )
    conn = Connection(module.params['socket_path'])
    result = conn.send(module.params['data'])
    if result is not None:
        module.exit_json(msg='passed')
    else:
        module.fail_json(msg='Failed to send data.')


# Generated at 2022-06-24 21:37:11.439401
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection()
    assert True


# Generated at 2022-06-24 21:37:14.665503
# Unit test for function recv_data
def test_recv_data():
    str_0 = 'kI:_2tW:CH]1E'
    var_0 = recv_data(str_0)

