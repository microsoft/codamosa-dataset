

# Generated at 2022-06-20 16:46:37.208956
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    reqid = str(uuid.uuid4())
    data = '{"id": "%s", "jsonrpc": "2.0", "result": true}' % reqid
    c = Connection('/dev/null')
    c._Connection__exec_jsonrpc = lambda *args, **kwargs: json.loads(data)
    c.open()
    assert c.close()
    assert c.exec_command('echo ok') == 'ok\n'
    assert c.set_option('key', 'value') is True
    assert c.get_option('key') == 'value'

# Generated at 2022-06-20 16:46:47.122649
# Unit test for function send_data
def test_send_data():
    import tempfile
    import shutil
    import sys

    test_data = b'This is test data'
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:46:54.583680
# Unit test for method send of class Connection
def test_Connection_send():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('/tmp/test_socket')
    sf.listen(1)
    sf_copy = sf.dup()


# Generated at 2022-06-20 16:47:02.065875
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    class Mock(object):
        def __init__(self, socket_path):
            self.socket_path = socket_path

    module = Mock('/usr/sbin/test')
    conn = Connection(module.socket_path)
    attr = conn.__getattr__('foo')
    assert attr.func is conn.__rpc__



# Generated at 2022-06-20 16:47:09.055791
# Unit test for constructor of class Connection
def test_Connection():
    class MockModule():
        def __init__(self, socket_path):
            self._socket_path = socket_path
    m = MockModule('abc')
    c = Connection(m._socket_path)
    assert c.socket_path == 'abc'

# Test class function Connection._exec_jsonrpc

# Generated at 2022-06-20 16:47:12.893272
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('socket path does not exist')
    except ConnectionError as exc:
        assert exc.args[0] == 'socket path does not exist'


# Generated at 2022-06-20 16:47:22.626258
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('/tmp/test_recv_data')
    s.listen(1)

    conn, _ = s.accept()
    send_data(conn, to_bytes('test'))
    data = recv_data(conn)

    if data != 'test':
        raise AssertionError('test_recv_data failed')

# Generated at 2022-06-20 16:47:26.322562
# Unit test for function exec_command
def test_exec_command():
    class TModule:
        pass
    module = TModule()
    module._socket_path = 'fake_path'
    (rc, output, err) = exec_command(module, 'show version')
    assert rc == 0
    assert len(output) > 0

# Generated at 2022-06-20 16:47:39.571312
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import sys
    import os
    import tempfile
    import time
    import traceback
    import socket

    def check_socket_listening(socket_path):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            s.connect(socket_path)
        except socket.error:
            return False
        s.close()
        return True

    test_module_path = os.path.join(os.path.dirname(__file__), os.path.pardir, 'test_utils.py')
    fd, socket_path = tempfile.mkstemp()
    exec_path = os.path.join(os.path.dirname(__file__), os.path.pardir, 'lib', 'ansible_test', '__main__.py')


# Generated at 2022-06-20 16:47:41.383038
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    assert 1 is None # TODO: implement your test here


# Generated at 2022-06-20 16:47:56.044165
# Unit test for function send_data
def test_send_data():
    test_s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    # set a local temporary path for the socket
    tmp_file = "/tmp/ansible_test_send_data"
    try:
        test_s.bind(tmp_file)
        test_s.listen(1)

        test_c = Connection(tmp_file)
        send_data(test_s, b"Hello World\n")
    finally:
        test_s.close()


# Generated at 2022-06-20 16:48:03.575107
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection("test")
    try:
        partial(connection.__rpc__, "test_rpc", "test_arg", test_kwarg="test")
    except:
        return
    # rpc method "test_rpc" defintion not found in plugin
    raise Exception("Failed to get exception by calling Connection method __getattr__")

# Generated at 2022-06-20 16:48:12.946369
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('\0test_send_data')
    s.listen(1)
    req = request_builder('exec_command', 'echo hello')
    data = json.dumps(req, cls=AnsibleJSONEncoder)
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect('\0test_send_data')
    send_data(sf, to_bytes(data))
    n, addr = s.accept()
    response = recv_data(n)
    assert response == data
    s.close()
    sf.close()


from ansible.module_utils.six import PY3

# Generated at 2022-06-20 16:48:18.902333
# Unit test for function send_data
def test_send_data():
    import mock
    import sys

    if sys.version_info[0] == 3:
        return

    sock = mock.MagicMock()

    # Check that it sends TCP_MAX_SEGMENT_SIZE bytes (should hang, but not)
    send_data(sock, 'a' * 40000)

    sock.sendall.assert_called_once()
    args, kwargs = sock.sendall.call_args

    # First arg of args is all data
    assert args[0] == 'a' * 40000



# Generated at 2022-06-20 16:48:27.782130
# Unit test for function exec_command
def test_exec_command():
    # Test case 1: Unsupported command
    assert exec_command(module, 'unsupported command') == (1, '', 'unsupported command: command not found')

    # Test case 2: unsupported command with args
    assert exec_command(module, 'unsupported command arg') == (1, '', 'unsupported command arg: command not found')

    # Test case 3: Valid command
    assert exec_command(module, 'hostname') == (0, socket.gethostname(), '')


# Generated at 2022-06-20 16:48:40.425196
# Unit test for method send of class Connection
def test_Connection_send():
    file_name = os.path.realpath(__file__)
    file_dir = os.path.dirname(file_name)
    connection = Connection(file_dir + '/../tests/unit/test_connection.py')
    ansible_module = {'DEFAULT_MODULE_ARGS': '', '_socket_path': file_dir + '/../tests/unit/test_connection.py'}
    connection.exec_command = exec_command
    connection.set_become(True)

    connection.set_become_method('enable')
    connection.set_become_password('passwd')
    connection.set_host_keys_file('~/.ssh/known_hosts')
    connection.set_keepalive(30)
    connection.set_persistent_command_timeout(10)

# Generated at 2022-06-20 16:48:51.080353
# Unit test for method send of class Connection
def test_Connection_send():
    test_data = 'test_data'

    data = {'jsonrpc': '2.0', 'id': '5', 'method': 'run_command', 'params': (('ls',), {'timeout': 10})}
    temp_socket_path = '/tmp/ansible_Connection_send'

    data = json.dumps(data, cls=AnsibleJSONEncoder)

    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    # Bind the socket to the port
    server_address = temp_socket_path
    sock.bind(server_address)
    # Listen for incoming connections
    sock.listen(1)

    # send data to client and receive response
    con = Connection(temp_socket_path)

# Generated at 2022-06-20 16:49:00.259180
# Unit test for function send_data
def test_send_data():
    BUFFER_SIZE = 1024
    MESSAGE = "Hello, World!"
    sf = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sf.bind(('', 0))
    s_port = sf.getsockname()[1]
    sf.listen(1)
    thread = threading.Thread(target=send_data_worker, args=(s_port, MESSAGE))
    thread.start()

    cf, addr = sf.accept()
    data = recv_data(cf)
    cf.close()

    if data is None:
        raise Exception("recv_data failed to receive data")
    if data != MESSAGE:
        raise Exception("recv_data received incorrect message")


# Generated at 2022-06-20 16:49:09.670199
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('message')
    assert exc.err is None
    assert exc.code is None
    assert exc.exception is None

    exc = ConnectionError('message', code=1)
    assert exc.err is None
    assert exc.code is 1
    assert exc.exception is None

    exc = ConnectionError('message', err='oops')
    assert exc.err == 'oops'
    assert exc.code is None
    assert exc.exception is None

    exc = ConnectionError('message', err='oops', code=1, exception='exception')
    assert exc.err == 'oops'
    assert exc.code is 1
    assert exc.exception == 'exception'

    exc.code = 2
    assert exc.code == 2

# Generated at 2022-06-20 16:49:15.747943
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    module = Connection(None)
    # Check for TypeError for input parameters
    with pytest.raises(TypeError) as excinfo:
        response = module.__rpc__(None)
    assert 'object with buffer protocol required' in str(excinfo.value)
    response = module.__rpc__("set_host_override")
    assert response == False
    response = module.__rpc__("get_option", "persistent_command_timeout")
    assert response == 300


# Generated at 2022-06-20 16:49:34.742536
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('test', 'arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')

    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test'
    assert len(req['params']) == 2
    assert req['params'][0] == ('arg1', 'arg2')
    assert req['params'][1] == {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}
    assert len(req['id']) == 36

    # test cls
    req = request_builder('test', 'arg1', 'arg2', kwarg1=cls())
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test'
    assert len

# Generated at 2022-06-20 16:49:40.560254
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError(
            'unable to connect to socket',
            err='error message',
            exception='exception message',
            code=1
        )
    except ConnectionError as err:
        assert err.err == 'error message'
        assert err.exception == 'exception message'
        assert err.code == 1
        assert 'unable to connect to socket' in str(err)


# Generated at 2022-06-20 16:49:46.577890
# Unit test for function send_data
def test_send_data():
    import random
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    i = random.randint(1, 1000)
    data = b'x'*i
    send_data(s, data)
    s.close()


# Generated at 2022-06-20 16:49:48.476281
# Unit test for constructor of class Connection
def test_Connection():
    assert Connection is not None
    assert hasattr(Connection, '__init__')

# Generated at 2022-06-20 16:49:50.477434
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible_collections.ansible_community.plugins.module_utils.connection import Connection
    con = Connection('/dev/null')
    con.__rpc__('mym', 1, 3)

# Generated at 2022-06-20 16:49:57.974670
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    class MockConnection(Connection):
        def send(self, data):
            return json.dumps({'id': data['id'], 'jsonrpc': '2.0', 'result': "wow"})

    connection = MockConnection("/path/to/mock/socket")
    assert connection.method() == "wow"


# Generated at 2022-06-20 16:50:05.157708
# Unit test for method send of class Connection
def test_Connection_send():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind("\0/tmp/pytest_connection")
    sf.listen(5)
    sf.settimeout(5)
    try:
        sc, addr = sf.accept()
    except socket.timeout:
        raise AssertionError("Socket connection time out")

    connection = Connection("\0/tmp/pytest_connection")
    data = "simple"
    response = connection.send(data)

    assert(data == response)
    sc.close()
    sf.close()

# Generated at 2022-06-20 16:50:15.968937
# Unit test for function exec_command
def test_exec_command():
    from ansible.plugins.connection.network_cli import Connection
    from ansible.module_utils._text import to_text

    class MockModule(object):
        def __init__(self):
            self._socket_path = 'foo'

    class MockConnection(Connection):
        def __init__(self):
            self.socket_path = 'foo'

        def exec_command(self, cmd):
            return '"bar" parsed'

    class ModuleFailException(Exception):
        pass

    class BadConnection(Connection):
        def __init__(self):
            self.socket_path = 'foo'

        def exec_command(self, cmd):
            raise ValueError("Failed to json parse")

    old_conn = Connection
    Connection.implements_modules = True
    module = MockModule()
    Connection = MockConnection

# Generated at 2022-06-20 16:50:25.258010
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():

    try:
        c = Connection(None)
    except AssertionError as e:
        assert str(e) == 'socket_path must be a value'
    else:
        assert False, "Expected AssertionError"

    c = Connection("test_socket")
    assert hasattr(c, '__dict__')
    assert c.__dict__ == {}
    assert '_test' not in c.__dict__
    assert c._test == c.__rpc__
    assert c._test != c.__dict__['_test']

    c.__dict__['_test'] = 'foo'
    assert c._test != c.__dict__['_test']
    assert c._test == 'foo'



# Generated at 2022-06-20 16:50:34.064107
# Unit test for function send_data
def test_send_data():
    import hashlib
    import socket

    sp = '/tmp/ansible-test-send_data'
    try:
        os.remove(sp)
    except:
        pass

    # set up a socket and test data to test send_data
    ss = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    ss.bind(sp)
    ss.listen(5)

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect(sp)

    test_data = uuid.uuid4().hex
    send_data(sf, to_bytes(test_data))

    (cs, ca) = ss.accept()
    response = recv_data(cs)


# Generated at 2022-06-20 16:51:06.215145
# Unit test for function exec_command
def test_exec_command():
    class TestModule(object):
        pass
    test_module = TestModule()
    test_module._socket_path = "/tmp/test_socket_path"
    result = exec_command(test_module, "echo 123")
    assert result == (0, '123\n', '')

# Generated at 2022-06-20 16:51:08.394103
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc1 = ConnectionError('foo')
    exc2 = ConnectionError('bar', code=1234)
    assert exc1.err == 'foo'
    assert exc2.err == 'bar'
    assert exc2.code == 1234

# Generated at 2022-06-20 16:51:19.350953
# Unit test for method send of class Connection
def test_Connection_send():
    input_data = to_bytes('{"jsonrpc": "2.0", "method": "exec_command", "id": "095a5f5c-afc2-4e95-a1d5-d8b10ba2b12a", "params": [[], {"command": "show version"}]}')
    connection = Connection("/var/tmp/ansible-connection-test")
    assert connection.send(input_data) == '{"jsonrpc": "2.0", "id": "095a5f5c-afc2-4e95-a1d5-d8b10ba2b12a", "result": {"msg": "ok", "stdout": "IOSv 16.6.1", "stdout_lines": ["IOSv 16.6.1"], "changed": false}}'



# Generated at 2022-06-20 16:51:28.057562
# Unit test for function send_data
def test_send_data():
    import sys
    import time
    import socket
    import json

    sock_path = '/tmp/ansible_test_send_data_%s_%s.sock' % (socket.gethostname(), time.time())

    def create_server():
        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sf.bind(sock_path)
        sf.listen(1)
        return sf

    def accept(sf):
        conn, addr = sf.accept()
        return conn, addr


# Generated at 2022-06-20 16:51:31.790137
# Unit test for constructor of class Connection
def test_Connection():
    class MockModule(object):
        def __init__(self):
            self._socket_path = '/tmp/ansible/test_connection.sock'

    module = MockModule()
    connection = Connection(module._socket_path)



# Generated at 2022-06-20 16:51:44.771152
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    from io import StringIO

    # Create a temp file
    fd, path = tempfile.mkstemp()

    def cleanup():
        os.close(fd)
        os.remove(path)

    # Write data to the temp file
    write_to_file_descriptor(fd, dict(a=10, b=20))
    os.lseek(fd, 0, os.SEEK_SET)

    # Verify the data written
    s = StringIO()
    for l in os.fdopen(fd):
        s.write(l)
    s.seek(0)
    cleanup()

    parts = s.read().split()
    assert len(parts) == 3
    assert parts[2] == hashlib.sha1(parts[1].encode()).hexdigest()

# Unit

# Generated at 2022-06-20 16:51:55.108477
# Unit test for function recv_data
def test_recv_data():
    def test_helper(length, data, expected_data):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('localhost', 0))
        s.listen(1)
        _, port = s.getsockname()

        t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        t.connect(('localhost', port))
        assert send_data(t, data) is None

        conn, _ = s.accept()
        assert recv_data(conn) == expected_data

    test_helper(1, b'1', b'1')
    test_helper(1, b'12', b'1')
    test_helper(2, b'123', b'12')

# Generated at 2022-06-20 16:52:05.592478
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.network.common import register_transport, to_list

    class FakeModule(object):
        def __init__(self, socket_path):
            self._socket_path = socket_path
            self.params = dict()

    module = AnsibleModule(argument_spec=dict())
    setattr(module, '_socket_path', 'test_socket_path')
    register_transport('socket')
    register_transport('network_cli')

    try:
        os.unlink('test_socket_path')
    except OSError:
        pass

    def fake_exec_command(module, command):
        return command

    setattr(module, 'exec_command', fake_exec_command)


# Generated at 2022-06-20 16:52:16.379701
# Unit test for method send of class Connection
def test_Connection_send():
    import ansible.module_utils.connection as conn
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.settimeout(5)
    sock_path = 'test_Connection_send.sock'
    sf.bind(sock_path)
    sf.listen(1)
    client = Connection(sock_path)
    test_data = b'{"jsonrpc": "2.0", "method": "exec_command", "id": "7f5b00ba-1e2d-4f9e-93cf-8c5b25e13e04"}'

# Generated at 2022-06-20 16:52:25.544613
# Unit test for method send of class Connection
def test_Connection_send():
    import os
    import shutil
    import tempfile
    import socket

    socket_path = tempfile.mktemp()
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(socket_path)

    # Check that socket can be created and written to
    conn = Connection(socket_path)
    conn.send("foo")

    # Check that socket can be created and read from
    response = sock.recv(1024)
    assert response == b'\x00\x00\x00\x00\x00\x00\x00\x03foo'

    sock.close()
    os.unlink(socket_path)

# Generated at 2022-06-20 16:53:15.775399
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    conn = Connection('')
    conn.send = lambda x: '{}'
    assert None == conn.__rpc__('test1', None)


# Generated at 2022-06-20 16:53:18.762983
# Unit test for function request_builder
def test_request_builder():
    request = request_builder('get')

    assert request['jsonrpc'] == '2.0'
    assert request['method'] == 'get'

# Generated at 2022-06-20 16:53:23.070113
# Unit test for function exec_command
def test_exec_command():
    module = None
    module._socket_path = '/tmp/test'
    out = exec_command(module, 'protocol_version')
    print(out)


if __name__ == '__main__':

    test_exec_command()

# Generated at 2022-06-20 16:53:30.631486
# Unit test for method send of class Connection
def test_Connection_send():

    # Create a unix socket for test
    sock_path = "/tmp/ansible_test_unix_domain_socket"
    if os.path.exists(sock_path):
        os.unlink(sock_path)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(sock_path)
    sock.listen(10)

    # Test with data
    conn = Connection(sock_path)
    resp = conn.send("Hello World")
    assert resp == "", "Test with data failed"

    # Test with large data size
    data = str(b'a' * (1024*1024))
    conn = Connection(sock_path)
    resp = conn.send(data)
    assert resp == "", "Test with data failed"

# Generated at 2022-06-20 16:53:39.313214
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """
    Test write_to_file_descriptor, which takes a file descriptor and an
    object, and writes the object to the file descriptor.
    """
    # Create a temporary file.
    with open('/tmp/ansible_mod_test_file', 'w') as fd:
        # Empty dictionary object.
        obj = {}
        # Write to file descriptor.
        write_to_file_descriptor(fd.fileno(), obj)

    # Ensure that the file is created.
    if not os.path.isfile('/tmp/ansible_mod_test_file'):
        raise Exception('File not created')

    # Open the file.
    fd = open('/tmp/ansible_mod_test_file', 'r')
    # Check that a file size is written to the file.

# Generated at 2022-06-20 16:53:47.258082
# Unit test for function recv_data
def test_recv_data():
    import subprocess
    import sys
    import time

    sockpath = '/tmp/ansible_test_socket'
    # Clean up if necessary
    try:
        os.remove(sockpath)
    except OSError:
        pass


# Generated at 2022-06-20 16:53:55.512070
# Unit test for method send of class Connection
def test_Connection_send():
    def mock_sendall(data):
        global mock_sendall_called
        mock_sendall_called = True
        mock_sendall_data = data

        return

    def mock_recv(num):
        global mock_recv_called
        mock_recv_called = True

        return '{"jsonrpc":"2.0","result":"111222","id":"aaaabbbb-cccc-dddd-1111-222233334444"}'

    global mock_sendall_called, mock_sendall_data, mock_recv_called

    mock_sendall_called = mock_recv_called = False

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect = Mock()
    sf.close = Mock()
    sf.sendall

# Generated at 2022-06-20 16:53:59.087774
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("error123")
    except Exception as e:
        assert str(e) == "error123"


# Generated at 2022-06-20 16:54:06.717020
# Unit test for function recv_data
def test_recv_data():
    class Socket:
        def recv(self, *args):
            return "abcd"

        def close(self):
            pass

    s = Socket()
    data = to_bytes("")
    while len(data) < 8:
        data += s.recv(8 - len(data))

    data_len = struct.unpack('!Q', data[:8])[0]
    data = data[8:]
    while len(data) < data_len:
        data += s.recv(data_len - len(data))

    assert(data == b"abcd")
    assert(recv_data(s) == b"abcd")

# Generated at 2022-06-20 16:54:09.438634
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection("test1")
    connection.__rpc__("test2", *[2, 3], **{'key1':'value1'})


# Generated at 2022-06-20 16:55:57.825805
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    class MockedObject(object):
        def __init__(self, socket_path):
            self._socket_path = socket_path

    module = MockedObject('a_socket_path')
    m = Connection('a_socket_path')

    assert callable(m._exec_jsonrpc)
    # Tests if method __getattr__ returns a partial object for rpc methods
    assert callable(m.exec_command)
    assert callable(m.send)

    # Test if method __getattr__ raises AttributeError for private methods
    with pytest.raises(AttributeError):
        m._exec_jsonrpc


# Unit tests for method __rpc__ of class Connection
# Test 1 - raises ConnectionError if socket_path does not exist
# Test 2 - raises ConnectionError if socket_path is invalid
# Test 3 - raises

# Generated at 2022-06-20 16:56:09.261126
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    # Make a pipe
    try:
        rfd, wfd = os.pipe()
    except OSError as e:
        raise ConnectionError(
            "Unable to create pipe. Exception: %s" % to_text(e)
        )

    # Write a string to the pipe
    test_str = "NTC-Ansible"
    obj = dict(func=test_str)
    try:
        write_to_file_descriptor(wfd, obj)
    except OSError as e:
        raise ConnectionError(
            "Unable to write to pipe. Exception: %s" % to_text(e)
        )

    # Read the string back from the pipe and verify it matches
    f = os.fdopen(rfd)
    output = f.read()

# Generated at 2022-06-20 16:56:15.170524
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('foo')
    except ConnectionError as exc:
        assert exc.message == 'foo', 'message not set correctly'
        assert exc.code == 1, 'default code not set correctly'
        assert exc.err is None, 'default err not set correctly'
        assert exc.exception is None, 'default exception not set correctly'


# Generated at 2022-06-20 16:56:28.128746
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from tempfile import TemporaryFile

    fd = TemporaryFile()
    write_to_file_descriptor(fd, {'a': 1, 'b': 2})
    fd.seek(0)

    x = fd.readline().rstrip(b'\n')
    l = int(x)

    assert l == fd.read(l)


# Used to test the connection object during development.
if __name__ == '__main__':
    import sys

    def show(msg, *args, **kwargs):
        print(msg % args)

    c = Connection(sys.argv[1])
    msg = 'hello world!'

    show('sending: %s', msg)
    res = c.exec_command(msg)
    show('received: %s', res)