

# Generated at 2022-06-20 16:46:32.534771
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('method')
    assert req == {'jsonrpc': '2.0', 'method': 'method', 'id': req['id'], 'params': ((), {})}

# Generated at 2022-06-20 16:46:38.298774
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class MockSocket:
        def __init__(self, socket_path, connect_error=None, send_data=None, recv_data=None):
            self.socket_path = socket_path
            self.connect_error = connect_error
            self.send_data = send_data
            self.recv_data = recv_data

        def connect(self, path):
            if path != self.socket_path:
                raise Exception("Unexpected socket path: '%s' != '%s'" % (path, self.socket_path))
            if self.connect_error is not None:
                raise self.connect_error


# Generated at 2022-06-20 16:46:48.209809
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    module_path = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, os.path.pardir, 'lib/ansible/modules/network/nxos/nxos_bgp')
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        required_together=None,
        required_one_of=None,
        mutually_exclusive=None,
        add_file_common_args=True
    )

    connection_plugin_path = '/etc/ansible/roles/test_role_connection/connection_plugins/test_connection.py'

    # import the connection plugin

# Generated at 2022-06-20 16:46:56.111368
# Unit test for method send of class Connection
def test_Connection_send():
    data = "test123"
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind("/tmp/ansible_test_socket")
    sf.listen(1)
    sm = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sm.connect("/tmp/ansible_test_socket")
    send_data(sm, data)
    conn, addr = sf.accept()
    response = recv_data(conn)
    assert data == to_text(response, errors='surrogate_or_strict')
    sm.close()
    sf.close()
    os.remove("/tmp/ansible_test_socket")

# Generated at 2022-06-20 16:46:57.959013
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection(None)
    assert connection.__getattr__('_Connection__rpc__') is not None


# Generated at 2022-06-20 16:47:02.697683
# Unit test for method send of class Connection
def test_Connection_send():
    sockPath = "/tmp/testSocket"
    con = Connection(sockPath)
    f = open(sockPath, "wb")
    f.write(b'{"jsonrpc":"2.0","result":null,"id":"c67a10d3-3b2b-4e43-8f1d-d16bedbcaa08"}')
    f.close()

    assert con.send("") == '{"jsonrpc":"2.0","result":null,"id":"c67a10d3-3b2b-4e43-8f1d-d16bedbcaa08"}'

# Generated at 2022-06-20 16:47:12.893695
# Unit test for function request_builder
def test_request_builder():
    result = request_builder('method', 'arg1', 'arg2', kwarg1=123, kwarg2="456")
    assert result['jsonrpc'] == '2.0'
    assert result['method'] == 'method'
    assert result['params'][0] == ('arg1', 'arg2')
    assert result['params'][1] == {'kwarg1': 123, 'kwarg2': '456'}
    assert result['id'] is not None

# Generated at 2022-06-20 16:47:18.931377
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection("foo")
    assert(conn.socket_path == "foo")
    try:
        conn = Connection(None)
        assert(False)
    except AssertionError:
        assert(True)


# Generated at 2022-06-20 16:47:27.960576
# Unit test for method send of class Connection
def test_Connection_send():
    test_data = {
        'test_data1': 'test_data1',
        'test_data2': 'test_data2',
    }

    test_data_str = 'test_data1'

    for dat in [test_data, test_data_str]:
        data = json.dumps(dat, cls=AnsibleJSONEncoder)

        try:
            sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sf.connect('/tmp/ansible-connection-test')
        except Exception as e:
            err = to_text(e)
            raise ConnectionError(
                'unable to connect to socket /tmp/ansible-connection-test',
                err=err, exception=traceback.format_exc()
            )

# Generated at 2022-06-20 16:47:33.125569
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('callback', 'test')
    assert req['id'] != '0'
    assert req['method'] == 'callback'
    assert req['params'] == (('test',), {})
    req = request_builder('callback', 'test', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')
    assert req['id'] != '0'
    assert req['method'] == 'callback'
    assert req['params'] == (('test', 'arg2'), {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'})

# Generated at 2022-06-20 16:47:46.224860
# Unit test for function request_builder
def test_request_builder():
    req = request_builder("exec_command", "cmd", True)
    assert req["id"] is not None
    assert req["jsonrpc"] == "2.0"
    assert req["method"] == "exec_command"
    assert req["params"][0] == ("cmd",)
    assert req["params"][1] == {}
    assert req["params"][1]["use_persistence"] == True



# Generated at 2022-06-20 16:47:58.702087
# Unit test for function request_builder
def test_request_builder():
    expected = {'jsonrpc': '2.0', 'method': 'run_command', 'id': 'b2d2bf66-8e50-11e7-bcb3-fa163e3f6e11', 'params': ((), {})}
    assert request_builder('run_command') == expected

    expected = {'jsonrpc': '2.0', 'method': 'run_command', 'id': 'b2d2bf66-8e50-11e7-bcb3-fa163e3f6e11', 'params': ((), {'arg1': 'arg1value'})}
    assert request_builder('run_command', **{'arg1': 'arg1value'}) == expected


# Generated at 2022-06-20 16:48:09.451563
# Unit test for function send_data
def test_send_data():
    from tempfile import mkstemp

    # Create a socket
    fd, path = mkstemp()
    os.close(fd)
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind(path)
    s.listen(1)

    try:
        # Open connection
        conn, addr = s.accept()

        # Send and receive some data.
        data = to_bytes("hello")
        send_data(conn, data)
        response = recv_data(conn)
        assert data == response, "Server received unexpected data"

    finally:
        s.close()
        os.unlink(path)

# Generated at 2022-06-20 16:48:16.628524
# Unit test for function exec_command
def test_exec_command():
    class Module(object):
        def __init__(self, socket_path):
            self._socket_path = socket_path

    module = Module('/tmp/ansible-connection-test.sock')
    code, out, err = exec_command(module, "echo test")
    assert code == 0
    assert out == "test\n"
    assert err == ""

# Generated at 2022-06-20 16:48:26.417019
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    f = open("tests/unittests/test_module_utils/test_connection/_fixtures/test_Connection/Connection.json", "r")
    data = json.load(f)
    f.close()
    socket_path = "/tmp/socket_path"
    conn = Connection(socket_path)
    response = conn.__rpc__.__func__(conn, "exec_command", "/bin/true")
    assert response == data["__rpc__"]


# Generated at 2022-06-20 16:48:37.984793
# Unit test for function send_data
def test_send_data():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    pid = os.getpid()
    sockname = "/tmp/ansible.%d.sock" % pid
    sf.bind(sockname)
    sf.listen(1)
    s, _ = sf.accept()

    send_data(s, b"hello")

    try:
        assert recv_data(s) == b"hello"
    finally:
        os.unlink(sockname)
        os.close(sf.fileno())

# Generated at 2022-06-20 16:48:47.389020
# Unit test for function send_data
def test_send_data():
    test_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    test_socket.bind('/tmp/test_unix_socket')
    test_socket.listen(1)
    conn, addr = test_socket.accept()
    try:
        test_data = "This is a test data"
        send_data(conn, to_bytes(test_data))
        response = recv_data(conn)
        assert to_text(response) == test_data
    finally:
        conn.close()
        test_socket.close()
        os.remove('/tmp/test_unix_socket')

# Generated at 2022-06-20 16:48:59.284258
# Unit test for function recv_data
def test_recv_data():
    size = struct.pack('!Q', len(to_bytes("test\n")))
    # Test for size 0
    assert recv_data(None) is None
    # Test for receiving only size
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("localhost", 4444))
    s.sendall(to_bytes("test\n"))
    data = recv_data(s)
    s.close()
    assert data == to_bytes("test\n")
    # Test for receiving size and data
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("localhost", 4445))
    s.sendall(size)
    s.sendall(to_bytes("test\n"))
    data

# Generated at 2022-06-20 16:49:00.807956
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    msg = 'Exception message'
    try:
        raise ConnectionError(msg)
    except ConnectionError as e:
        assert isinstance(e, ConnectionError)
        assert msg == to_text(e)


# Generated at 2022-06-20 16:49:07.593917
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('test_msg')
    assert exc.args[0] == 'test_msg'

    exc = ConnectionError('test_msg', code=1, err='test_err')
    assert exc.code == 1
    assert exc.err == 'test_err'


if __name__ == '__main__':
    import sys
    import pytest

    sys.exit(pytest.main(args=sys.argv[1:]))

# Generated at 2022-06-20 16:49:19.167518
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from io import StringIO
    from tempfile import TemporaryFile

    tempfd = TemporaryFile()

    text_data = "This is a string"
    write_to_file_descriptor(tempfd.fileno(), text_data)
    # Set the file position back to beginning of file
    tempfd.seek(0)
    data = tempfd.read()
    assert(data == b'13\nThis is a string\n')

# Generated at 2022-06-20 16:49:24.463069
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    err = ConnectionError('error message', code=1000, err='error')
    assert err.message == 'error message'
    assert err.code == 1000
    assert err.err == 'error'


# Generated at 2022-06-20 16:49:29.978446
# Unit test for function send_data
def test_send_data():
    """
    This test is to verify the send_data function sends the byte stream
    properly.
    """
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf = s.makefile("rwb")
    sf.write(b"hello")
    sf.flush()
    assert recv_data(s) == b"hello"


# Generated at 2022-06-20 16:49:39.564443
# Unit test for function request_builder
def test_request_builder():
    print("Executing request_builder tests")
    # Test 1: Test of method name passed as parameter
    req1 = request_builder("exe", "test")
    if req1['method'] != "exe":
        return False

    # Test 2: Test of id generated
    req2 = request_builder("exe1")
    if req2['id'] == req1['id']:
        return False

    # Test 3: Test with arguments and kwargs
    req3 = request_builder("exe", "test", test="test")
    if req3['params'][0] != ("test",):
        return False
    if req3['params'][1] != {"test": "test"}:
        return False

    return True


# Generated at 2022-06-20 16:49:51.884490
# Unit test for function send_data
def test_send_data():
    import socket
    # create a test socket
    server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server_socket.bind("/tmp/test_socket")
    server_socket.listen(1)

    # create a client connection
    client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client_socket.connect("/tmp/test_socket")

    # dummy data to be sent
    msg = 'dummy test message'

    def recv_data(s):
        header_len = 8  # size of a packed unsigned long long
        data = b''
        while len(data) < header_len:
            d = s.recv(header_len - len(data))
            if not d:
                return None
           

# Generated at 2022-06-20 16:50:00.986482
# Unit test for constructor of class Connection
def test_Connection():

    # Constructor throws error if socket path is not provided
    try:
        Connection(None)
    except AssertionError:
        pass

    # Constructor throws error if socket path is not valid
    try:
        Connection("/invalid/path")
    except ConnectionError:
        pass

    # Constructor doesn't throw error if valid socket path is provided
    try:
        Connection("/tmp/ansible.socket")
    except Exception:
        pass



# Generated at 2022-06-20 16:50:06.338131
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    from ansible.module_utils.connection._internal_socket import Connection

    conn = Connection('/tmp/ansible_conn')
    string_to_send = 'Hello world'
    received_data = conn.send(string_to_send)
    assert received_data == string_to_send


# Generated at 2022-06-20 16:50:18.692859
# Unit test for function send_data
def test_send_data():
    data = to_bytes('abcd')

    # Create a couple of mock socket objects
    class socket_mock:
        def __init__(self, data):
            self.data = data

        def sendall(self, data):
            self.data += data

    sm = socket_mock(b'')
    sm2 = socket_mock(b'')

    # A few different packets to send
    send_data(sm, data)
    assert sm.data == b'\x00\x00\x00\x00\x00\x00\x00\x04' + to_bytes(data)

    send_data(sm2, b'')
    assert sm2.data == b'\x00\x00\x00\x00\x00\x00\x00\x00'

    send_

# Generated at 2022-06-20 16:50:31.102962
# Unit test for function send_data
def test_send_data():
    test_socket_path = '/tmp/ansible_test_socket'
    try:
        os.unlink(test_socket_path)
    except OSError:
        if os.path.exists(test_socket_path):
            raise

    test_message = 'This is a test message'

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind(test_socket_path)
    sf.listen(1)

    th = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    th.connect(test_socket_path)

    client, addr = sf.accept()
    send_data(client, to_bytes(test_message))
    response = recv_data(th)

    assert to_

# Generated at 2022-06-20 16:50:34.502927
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    conn = Connection('/dev/null')
    assert conn.__rpc__.__closure__[1].cell_contents == '__rpc__'
    assert conn.__rpc__.__closure__[2].cell_contents == conn


# Generated at 2022-06-20 16:51:02.140554
# Unit test for function send_data
def test_send_data():
    import os
    import threading
    import tempfile

    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    socket_path = tempfile.mktemp()
    s.bind(socket_path)
    s.listen(0)

    # Start the server in a background thread
    def server():
        sc, addr = s.accept()
        recv_data(sc)
        sc.sendall(b'world')
        sc.close()

    t = threading.Thread(target=server)
    t.start()

    # Create a client and send a message to the server
    sc = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sc.connect(socket_path)

    send_data(sc, b'hello')

# Generated at 2022-06-20 16:51:09.157868
# Unit test for method send of class Connection
def test_Connection_send():
    import tempfile
    import random
    import threading
    import time
    import socket

    tmp_dir = tempfile.mkdtemp()
    fifo_path = os.path.join(tmp_dir, 'fifo')
    os.mkfifo(fifo_path)

    # This write process will block until a reader is connected
    def writer():
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(fifo_path)
        data = json.dumps({'ok': True})
        send_data(s, to_bytes(data))

        # close the connection
        s.close()

    # This read process will read the socket,
    # and it will close the connection

# Generated at 2022-06-20 16:51:12.854785
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection(None)
    except AssertionError:
        pass

    assert Connection('ansible-connection')


# Generated at 2022-06-20 16:51:21.008517
# Unit test for function request_builder
def test_request_builder():
    expected = {'jsonrpc': '2.0', 'method': 'run', 'params': ((), {}), 'id': 'random_id'}
    test_req = request_builder('run')
    assert test_req['method'] == expected['method']
    assert test_req['id'] == expected['id']
    assert test_req['jsonrpc'] == expected['jsonrpc']
    assert test_req['params'] == expected['params']



# Generated at 2022-06-20 16:51:25.197583
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('test', code=2)
    except ConnectionError as exc:
        assert exc.code == 2
        assert exc.err == 'test'

# Generated at 2022-06-20 16:51:29.593771
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = '/path/to/ansible/connections/network_cli'
    conn = Connection(socket_path)
    assert conn.socket_path == socket_path


# Generated at 2022-06-20 16:51:39.292029
# Unit test for function recv_data
def test_recv_data():
    sfd, sfpath = tempfile.mkstemp()
    os.close(sfd)
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind(sfpath)
    sf.listen(5)

    # Test case when data not yet received
    s, _ = sf.accept()
    data = recv_data(s)
    assert data is None

    # Test case when data received partially
    s, _ = sf.accept()
    os.write(s.fileno(), b"123")
    data = recv_data(s)
    assert data is None

    # Test case when data received in one go
    s, _ = sf.accept()
    os.write(s.fileno(), b"12345")
    data

# Generated at 2022-06-20 16:51:43.586260
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection('test')
    conn.socket_path = '/dev/null'
    try:
        conn.send('test_data')
        assert False, "ConnectionError was not raised"
    except ConnectionError:
        assert True

if __name__ == '__main__':
    test_Connection_send()

# Generated at 2022-06-20 16:51:47.335685
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('test', code=1)
    except ConnectionError as inst:
        assert 'test' == inst.err
        assert 1 == inst.code

# Generated at 2022-06-20 16:51:58.001045
# Unit test for function recv_data
def test_recv_data():
    # TODO: Mock the socket input
    import socket

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('localhost', 0)
    sock.bind(server_address)
    sock.listen(1)
    connection, client_address = sock.accept()

# Generated at 2022-06-20 16:52:40.178799
# Unit test for function recv_data
def test_recv_data():
    message = 'the rain in spain'
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('/tmp/ansible_test_socket')
    sf.listen(1)
    sf.settimeout(10)
    client, addr = sf.accept()
    send_data(client, message)
    assert message == recv_data(client)
    client.close()
    sf.close()

# Generated at 2022-06-20 16:52:42.243160
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection('/var/tmp/test_path')
    rpc_response = connection._exec_jsonrpc('test_method', 1, 2, 3)
    assert rpc_response['result'] == [1, 2, 3]



# Generated at 2022-06-20 16:52:46.454214
# Unit test for function request_builder
def test_request_builder():
    request = request_builder('execute_command', '/my/test.sh')
    assert request['jsonrpc'] == '2.0'
    assert request['method'] == 'execute_command'
    assert request['params'][0] == ('/my/test.sh',)
    assert request['params'][1] == {}
    assert request['id'] is not None


# Generated at 2022-06-20 16:52:50.128881
# Unit test for function request_builder
def test_request_builder():
    expected = {'jsonrpc': '2.0', 'method': 'name', 'id': 'xxx-xxx-xxx'}
    expected['params'] = ((1, 2, 3), {'key': 'value'})

    req = request_builder('name', 1, 2, 3, key='value')

    assert req['method'] == expected['method']
    assert req['jsonrpc'] == expected['jsonrpc']
    assert req['id'] == expected['id']
    assert req['params'] == expected['params']

    assert 'error' not in req

# Generated at 2022-06-20 16:53:00.960015
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import pytest
    from subprocess import Popen, PIPE
    import os

    if not os.path.exists('/tmp/test_socket'):
        subproc = Popen(['/bin/sh', '-c', './ansible-connection -i /tmp/test_inv'],
                        stdout=PIPE, stderr=PIPE, stdin=PIPE)
        subproc.poll()
        assert subproc.returncode is None, 'ansible-connection process failed to start'
        assert os.path.exists('/tmp/test_socket'), 'test socket has not been created'
    else:
        assert os.path.exists('/tmp/test_socket'), 'test socket has not been created'


# Generated at 2022-06-20 16:53:09.812905
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():

    from tempfile import mkstemp
    import os

    data = {'test': 'data'}
    fd, fname = mkstemp()
    write_to_file_descriptor(fd, data)
    os.close(fd)

    with open(fname, 'rb') as f:
        length = to_text(f.readline().strip())
        file_data = f.read(int(length))
        file_hash = to_text(f.readline().strip())

    assert hashlib.sha1(file_data).hexdigest() == file_hash
    actual = cPickle.loads(file_data)
    assert data == actual

# Generated at 2022-06-20 16:53:15.981274
# Unit test for method send of class Connection
def test_Connection_send():
    data = json.dumps({
        'jsonrpc': '2.0',
        'method': 'hello',
        'id': str(uuid.uuid4()),
        'params': ('arg1', dict(kwarg1='kwarg1')),
    })

    connection = Connection('/tmp/ansible-conn-test')
    connection.send(data)



# Generated at 2022-06-20 16:53:19.985810
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    # Test when attribute doesn't exist in dict
    con = Connection("/connection/path")
    assert con.test_attribute == partial(con.__rpc__, "test_attribute")



# Generated at 2022-06-20 16:53:28.541408
# Unit test for function recv_data
def test_recv_data():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("127.0.0.1", 8001))
    send_data(sock, b"Hello, world!")
    data = recv_data(sock)
    sock.close()
    assert(data == b"Hello, world!")

if __name__ == "__main__":
    # Unit test the function recv_data by creating a server
    # listening to localhost 8001, sending a string and
    # checking if the same string was received back
    import threading
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# Generated at 2022-06-20 16:53:38.657170
# Unit test for function exec_command
def test_exec_command():
    # Create a temporary file
    import tempfile
    tmp_fd, tmp_name = tempfile.mkstemp()
    # Create a function that provides the temporary file
    # as being the ANSIBLE_LIBRARY
    def f():
        os.environ["ANSIBLE_LIBRARY"] = tmp_name
    # Create a module instance
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(partial(f))
    # Determine the actual socket path used by the module
    socket_path = m.run_command("python -c 'import json,sys; json.dump({\"ANSIBLE_CONNECTION\": \"%s\"}, sys.stdout)'",
                                check_rc=True)[1]
    socket_path = json.loads(socket_path)["ANSIBLE_CONNECTION"]

# Generated at 2022-06-20 16:54:54.804318
# Unit test for function recv_data

# Generated at 2022-06-20 16:55:05.121042
# Unit test for function send_data
def test_send_data():
    conn = Connection('/abc/def')
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(conn.socket_path)

    msg = "test_send_data"
    data = to_bytes(msg)
    conn.send(data)

    try:
        data = to_bytes("")
        while len(data) < len(msg):
            d = s.recv(len(msg) - len(data))
            if not d:
                return None
            data += d
        assert(data == to_bytes(msg))
    except:
        return False
    else:
        return True

# Generated at 2022-06-20 16:55:15.221628
# Unit test for method send of class Connection
def test_Connection_send():
    import tempfile
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_connection_')
    sock_path = os.path.join(tmpdir, 'ansible_connection.sock')
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind(sock_path)
    sf.listen(5)

    # Test without server
    c = Connection(sock_path)
    try:
        c.send('Junk')
        assert False, "Socket does not exist; should have raised ConnectionError."
    except ConnectionError:
        pass

    # Test with server
    # Change Connection to use new socket path
    c = Connection(sock_path)
    client, addr = sf.accept()
    # End test Connection.send()

# Generated at 2022-06-20 16:55:20.593375
# Unit test for function recv_data
def test_recv_data():
    h = bytearray(struct.pack('!Q', 1)) + b'a'

    test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    test_socket.bind(('127.0.0.1', 0))
    test_socket.listen(0)

    a = test_socket.accept()
    c, addr = a
    c.sendall(h)
    c.close()

    test_socket.settimeout(0.1)
    test_socket, addr = test_socket.accept()
    res = recv_data(test_socket)
    assert res == b'a'

# Generated at 2022-06-20 16:55:27.750577
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    try:
        connection = Connection(None)
    except AssertionError as e:
        assert "socket_path must be a value" in to_text(e)

    # set_option(s) has sensitive info, and the details are unlikely to matter anyway
    try:
        connection = Connection("/tmp/ansible_test_socket")
        connection.set_option("key", "value")
    except ConnectionError as e:
        msg = to_text(e)
        assert "Unable to decode JSON from response to set_option" in msg
        assert "key=u'value'" in msg

    try:
        connection = Connection("/tmp/ansible_test_socket")
        connection.set_option("key", "value")
    except Exception as e:
        msg = to_text(e)

# Generated at 2022-06-20 16:55:30.747875
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exception = ConnectionError("something is wrong, please check")
    assert exception.message == "something is wrong, please check"
    assert exception.code == 1

    exception = ConnectionError("something is wrong, please check", err="Permission denied")
    assert exception.err == "Permission denied"
    assert exception.code == 1

    exception = ConnectionError("something is wrong, please check", code=255)
    assert exception.message == "something is wrong, please check"
    assert exception.code == 255

# Generated at 2022-06-20 16:55:35.425335
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    path = tempfile.mktemp()

# Generated at 2022-06-20 16:55:45.095408
# Unit test for function request_builder
def test_request_builder():
    for method_ in ['ping', 'set_option']:
        for args, kwargs in [
            ((), {}),
            ((), {'key': 'value'}),
            (('foo',), {}),
            (('foo',), {'key': 'value'}),
            (('foo', 'bar'), {'key': 'value'})
        ]:
            req = request_builder(method_, *args, **kwargs)
            assert req['id']
            assert req['jsonrpc'] == '2.0'
            assert req['method'] == method_
            assert req['params'] == (args, kwargs)

# Generated at 2022-06-20 16:55:51.125985
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Should not fail when no message or args are passed
    ConnectionError()
    # Should pass when message is passed but no args
    ConnectionError("foo")
    # Should pass when args is passed but no message
    ConnectionError(123)
    # Should pass when both message and args are passed
    ConnectionError("foo", 123)

# Generated at 2022-06-20 16:55:58.478461
# Unit test for function request_builder
def test_request_builder():
    """This function unit tests function request_builder"""
    req = request_builder("test_method")
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test_method'
    assert req['id'] is not None
    assert req['params'] == ((), {})

    req = request_builder('test_method', 'arg1', 'arg2', kwarg1='arg3', kwarg2='arg4')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test_method'
    assert req['id'] is not None
    assert req['params'] == (('arg1', 'arg2'), {'kwarg1': 'arg3', 'kwarg2': 'arg4'})