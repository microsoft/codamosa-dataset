

# Generated at 2022-06-20 16:46:35.345468
# Unit test for function exec_command
def test_exec_command():
    mock_module = type('MockModule', (object,), {'_socket_path': '/tmp/ansible-conn-test'})()
    expected_value = 'test'

    # Test with good response
    connection = Connection(mock_module._socket_path)
    connection._exec_jsonrpc = classmethod(lambda cls, method, *args, **kwargs: {'result': expected_value, 'id': ''})
    code, out, err = exec_command(mock_module, 'test_command')
    assert code == 0
    assert out == expected_value
    assert err == ''

    # Test with error response
    error_message = 'test error message'
    connection = Connection(mock_module._socket_path)

# Generated at 2022-06-20 16:46:46.124874
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():

    test_data = {
            'bytes_data': to_bytes('têst'),
            'int_data': 42,
            'string_data': 'têst',
            'unicode_data': u'têst',
            'tuple_data': (1, 2, 3),
            'list_data': ['1', '2', '3'],
            'dict_data': {'key1': 1, 'key2': 2, 'key3': 3},
    }
    expected_sha1 = 'bf180461c9f85b0c86cc57e12d7a015818b0c43f'


# Generated at 2022-06-20 16:46:50.424628
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('test', 1, 2, 3, a='a', b='b')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'test'
    assert len(req['id']) == 36
    assert req['params'] == ((1, 2, 3), {'a': 'a', 'b': 'b'})

# Generated at 2022-06-20 16:46:56.477227
# Unit test for function request_builder
def test_request_builder():
    actual = request_builder('login', 'admin', 'pass')
    expected = {
        'jsonrpc': '2.0',
        'method': 'login',
        'id': actual['id'],
        'params': (('admin', 'pass'), {})
    }
    assert actual == expected

    actual = request_builder('get_config', source='running')
    expected = {
        'jsonrpc': '2.0',
        'method': 'get_config',
        'id': actual['id'],
        'params': ((), {'source': 'running'})
    }
    assert actual == expected

# Generated at 2022-06-20 16:47:02.605080
# Unit test for method send of class Connection
def test_Connection_send():
    mock_data = "message"
    try:
        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sf.bind("/tmp/socket_test")
        sf.listen(1)
        connection = Connection("/tmp/socket_test")
        connection.send("message")
        data = connection.send("message")
    except socket.error as e:
        raise("error while executing test_Connection_send()")

    assert data == mock_data

# Generated at 2022-06-20 16:47:13.134881
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    """
    Unit test for method __rpc__ of class Connection

    """

    from ansible.plugins.connection.network_cli import Connection
    conn_obj = Connection('')
    conn_obj.__getattr__ = mock_getattr()
    conn_obj._exec_jsonrpc = mock_Connection__exec_jsonrpc()
    result = conn_obj.__rpc__('send_config_set', 'test', 'test2', 'test3')
    assert result == 'test'


# Generated at 2022-06-20 16:47:26.172189
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('localhost', 0))

    # Bind to a local port
    s.listen(1)
    s.settimeout(None)

    # Connect to the server and send a small message
    c = socket.create_connection(s.getsockname())
    client = c.makefile("rb")
    server = s.accept()[0].makefile("rb")
    send_data(c, to_bytes("hello"))

    # Server should receive the message
    size = struct.unpack("!Q", server.read(8))[0]
    assert size == 5
    msg = server.read(size)
    assert to_text(msg) == "hello"

    # Disconnect and clean up
    c.close

# Generated at 2022-06-20 16:47:31.508682
# Unit test for function send_data
def test_send_data():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test-data'))
    sf.listen(1)
    s, _ = sf.accept()
    test = "hello world"
    send_data(s, to_bytes(test))
    data = recv_data(s)
    assert data == to_bytes(test)

# Generated at 2022-06-20 16:47:33.072980
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection()

    cmd = "show ip interface brief"
    response = connection.__rpc__('exec_command', cmd)

    assert response == 'Success'


# Generated at 2022-06-20 16:47:41.874669
# Unit test for function send_data
def test_send_data():
    test_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    test_socket.bind(b"/tmp/test_socket")
    test_socket.listen(1)
    client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client_socket.connect(b"/tmp/test_socket")
    test_socket.accept()
    test_data = b"test data"
    assert send_data(test_socket, test_data) == None
    assert test_socket.recv(11) == b"\x00\x00\x00\x00\x00\x00\x00\t" + test_data
    test_socket.close()
    client_socket.close()

# Generated at 2022-06-20 16:48:11.218302
# Unit test for function exec_command
def test_exec_command():
    import tempfile
    import shlex
    import json

    def test_exec_command():
        module_args = dict(
            socket_path='/foo/bar',
            _ansible_debug=False
        )

        module = AnsibleModuleMock(module_args)

        command = r'echo "hello world"'
        retval, out, err = exec_command(module, command)

        assert retval == 0
        assert out == 'hello world\n'
        assert err == ''

    def test_exec_command_with_unicode():
        module_args = dict(
            socket_path='/foo/bar',
            _ansible_debug=False
        )

        module = AnsibleModuleMock(module_args)

        command = r'echo "hola mundo"'
        retval, out, err

# Generated at 2022-06-20 16:48:18.021791
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('test')
    assert exc.code == 1
    assert exc.err == 'test'

    exc = ConnectionError('test', code=100)
    assert exc.code == 100
    assert exc.err == 'test'

    exc = ConnectionError('test', code=100, err='new')
    assert exc.code == 100
    assert exc.err == 'new'



# Generated at 2022-06-20 16:48:21.342829
# Unit test for function exec_command
def test_exec_command():
    assert exec_command(None, 'echo "foo"') == (0, 'foo', '')

# Generated at 2022-06-20 16:48:31.305146
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    import os

    obj = {'a': True, 'b': {'c': '0xface'}}
    fd, path = tempfile.mkstemp()
    os.close(fd)
    with open(path, 'w') as f:
        write_to_file_descriptor(f.fileno(), obj)
    with open(path, 'r') as f:
        data = f.read()
    assert len(data.split('\n')) == 3
    assert data.split('\n')[2] == hashlib.sha1(data.split('\n')[1]).hexdigest()
    assert cPickle.loads(data.split('\n')[1]) == obj
    os.unlink(path)

# Generated at 2022-06-20 16:48:38.113707
# Unit test for method send of class Connection
def test_Connection_send():
    """Unit test for Connection.send."""
    c = Connection(':memory')

    expected = '{"jsonrpc": "2.0", "method": "foo", "id": "e9e9b7ff-f90c-4664-a5e5-f0d931643e20"}'
    actual = c.send(expected)
    assert expected == actual



# Generated at 2022-06-20 16:48:40.003255
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection("test")
    data = {
        "test": "Manoj"
    }
    conn.send(json.dumps(data))

# Generated at 2022-06-20 16:48:50.903774
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import pytest

    def test_write_to_file_descriptor():
        # test write catch
        # import socket
        # s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # s.connect(('', 9999))
        # fd = s.fileno()

        # test hash
        from tempfile import NamedTemporaryFile
        c_file = NamedTemporaryFile()
        data = {"test": "value"}
        write_to_file_descriptor(c_file.fileno(), data)
        c_file.seek(0)
        size = int(c_file.readline().strip())
        assert size == len(cPickle.dumps(data))
        c_file.seek(0)
        c_file.readline()
        src = c

# Generated at 2022-06-20 16:48:55.817550
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    connection_error = ConnectionError("test_connection_error", err="test_connection_err", code=1)
    assert connection_error.err == "test_connection_err"
    assert connection_error.code == 1


# Generated at 2022-06-20 16:49:08.829111
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(1)

# Generated at 2022-06-20 16:49:12.961230
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('configure', 'hostname R1')
    assert req['params'] == (('hostname R1',), {})
    req = request_builder('_exec_command', 'show version')
    assert req['params'] == (('show version',), {})

# Generated at 2022-06-20 16:49:36.132444
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():

    import tempfile
    import random
    import string

    # Make sure no control character is allowed in the dump
    for i in range(0, 32):
        if i not in [9, 10, 13]:
            test_data = chr(i) * 1024
            try:
                fd, file_name = tempfile.mkstemp()
                write_to_file_descriptor(fd, test_data)
            finally:
                os.close(fd)
                os.unlink(file_name)
            raise Exception("No exception raised for control character")

    # Now test random data
    for n in range(1, 1024):
        test_data = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(n))

# Generated at 2022-06-20 16:49:37.519594
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    assert Connection('')._getattr_() == 'Connection'


# Generated at 2022-06-20 16:49:40.531859
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection("/path/to/file")
    # get an attribute that doesn't exist
    try:
        c.socket_path
    except AttributeError:
        pass
    # get an attribue that does exist
    assert c.socket_path == "/path/to/file"

# Generated at 2022-06-20 16:49:52.323734
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import tempfile
    import shutil

    env = {}

    def run_command(module, command):
        env['module'] = module
        env['command'] = command
        return 0, '', ''

    env['run_command'] = run_command

    tmpdir = tempfile.mkdtemp()

    socket_path = os.path.join(tmpdir, 'test_send.sock')

    env['module']._socket_path = socket_path

    if os.path.exists(socket_path):
        os.unlink(socket_path)

    # This is the socket code
    # Open up the socket connection
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(socket_path)
    listener.listen(1)

    c = Connection

# Generated at 2022-06-20 16:50:04.641699
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    socket_path = '/var/run/ansible/ansible-connection.socket'
    name = 'exec_command'
    module = 'setup'    # dont need to pass as part of args
    command = 'show version'

    conn = Connection(socket_path)

    # pass args as a list
    response = conn.__rpc__(name, module, command)
    assert module in response['result'].keys()
    assert response['result'][module].get('module_setup') is True
    assert response['result'][module].get('ansible_facts')['ansible_net_version'].startswith('15.')

    # pass args as a dict
    response = conn.__rpc__(name, dict(module=module, command=command))
    assert module in response['result'].keys()
    assert response

# Generated at 2022-06-20 16:50:09.023938
# Unit test for function exec_command
def test_exec_command():
    module = "test_module"
    command = "ping localhost"
    rc, out, err = exec_command(module, command)
    assert rc == 0
    assert out == "ping localhost"
    assert err == ""

# Generated at 2022-06-20 16:50:20.037397
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    import os
    import json
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.socket_path import get_socket_path

    module = AnsibleModule(argument_spec=dict())

    module_args = dict(
        socket_path=dict(type='path'),
    )
    module._socket_path = get_socket_path(module)

    def _exec_jsonrpc(name, *args, **kwargs):
        return json.dumps({"result": "ok", "id": 1})

    module.connection.socket_path = tempfile.mkstemp(prefix='test_Connection___rpc__')[1]
    module.connection._exec_jsonrpc = _exec_jsonrpc
    module.connection.get_hostname

# Generated at 2022-06-20 16:50:24.156664
# Unit test for constructor of class Connection
def test_Connection():
    class_name = "Connection"
    connection = Connection(None)
    assert class_name in str(connection.__class__)

    connection = Connection("/tmp/test_file")
    assert class_name in str(connection.__class__)


# Generated at 2022-06-20 16:50:33.334387
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    conn1 = Connection('test')
    # method 'test' must be present as per Connector class contract
    conn1.test()
    assert conn1.socket_path == 'test'

    conn2 = Connection('test')
    conn2._exec_jsonrpc = lambda x, *args, **kwargs: 'test'
    res = conn2.test()
    assert res == 'test'

    class ConnectionError(Exception):
        pass

    conn3 = Connection('test')
    conn3._exec_jsonrpc = lambda x, *args, **kwargs: 'test'

# Generated at 2022-06-20 16:50:40.515528
# Unit test for function request_builder
def test_request_builder():
    method = "test"
    args = ['arg']
    kwargs = {'kwarg':3}

    try:
        req = request_builder(method, *args, **kwargs)
    except AttributeError:
        assert False, "request_builder function does not create the proper request."

    assert req['method'] == method, "'method' value is not set correctly in the request."
    assert req['id'] is not None, "'id' is not set correctly in the request."
    assert "result" not in req, "'result' should not be in the request by default."
    assert "error" not in req, "'error' should not be in the request by default."
    assert req['params'] == (args, kwargs), "'params' is not set correctly in the request."

# Generated at 2022-06-20 16:51:11.492476
# Unit test for function request_builder
def test_request_builder():
    expected = json.loads('{"jsonrpc": "2.0", "method": "load_file", "params": [[], '
                          '{"path": "/etc/issue", "username": "root", "port": 22, '
                          '"private_key_file": "/home/foo/.ssh/id_rsa", '
                          '"host": "127.0.0.1", "password": "pass", '
                          '"become_user": "root", "become": true}], "id": "d41d8cd98f00b204e9800998ecf8427e"}')

# Generated at 2022-06-20 16:51:18.975906
# Unit test for method send of class Connection
def test_Connection_send():
    """ Unit test for method send of class Connection
    """
    try:
        conn = Connection('/tmp/ansible-test')

        # Execute the send method with input data
        conn.send('hello')

    except Exception as e:
        print("Exception {} occured during send method of class Connection".format(e))


# Generated at 2022-06-20 16:51:22.292899
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection('socket')
    connection.__dict__['test'] = 'test'
    with pytest.raises(AttributeError):
        connection._test
    with pytest.raises(AttributeError):
        connection.test
    assert getattr(connection, 'test') == 'test'


# Generated at 2022-06-20 16:51:23.814649
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    # Testing __getattr__ of class Connection
    module = Connection('/tmp/Test')
    assert isinstance(module.__getattr__, partial)

# Generated at 2022-06-20 16:51:31.593606
# Unit test for function request_builder
def test_request_builder():
    method = 'a_method'
    reqid = str(uuid.uuid4())
    req = {'jsonrpc': '2.0', 'method': method, 'id': reqid}
    args = (1, 2, 3)
    kwargs = {'kwargs1': 'string', 'kwargs2': 'string2'}
    req['params'] = (args, kwargs)
    result = request_builder(method, *args, **kwargs)
    assert result == req


# Generated at 2022-06-20 16:51:44.702238
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    from ansible.module_utils.network.common.utils import ConnectionError
    from ansible.module_utils.network.common.utils import to_text
    class MockConn(object):
        def __init__(self, socket_path):
            if socket_path is None:
                raise AssertionError('socket_path must be a value')
            self.socket_path = socket_path
        def _exec_jsonrpc(self, name, *args, **kwargs):
            req = request_builder(name, *args, **kwargs)
            reqid = req['id']

# Generated at 2022-06-20 16:51:45.203814
# Unit test for method send of class Connection
def test_Connection_send():
    pass

# Generated at 2022-06-20 16:51:48.014731
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('Message', code='1', err='test_err')

    except ConnectionError as e:
        assert e.code == '1'
        assert e.err == 'test_err'
        assert e.message == 'Message'


# Generated at 2022-06-20 16:51:58.497351
# Unit test for method send of class Connection
def test_Connection_send():
    import tempfile
    import threading
    import time

    def server(tmpfile, data):
        try:
            sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sf.bind(tmpfile)
            sf.listen(5)
            conn, addr = sf.accept()
            request = recv_data(conn)
            conn.sendall(data)
        except Exception:
            pass
        finally:
            conn.close()
            sf.close()

    data = ' data '
    response = ' response '

    with tempfile.NamedTemporaryFile() as tmpfile:
        path = tmpfile.name
        t = threading.Thread(target=server, args=(path, response))
        t.start()
        time.sleep(1)


# Generated at 2022-06-20 16:52:02.108229
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exception_class = ConnectionError("message", code=1, value="argument", exception=Exception('error'))
    assert exception_class.code == 1
    assert exception_class.value == "argument"
    assert exception_class.exception == "error"


# Generated at 2022-06-20 16:52:29.766217
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    mysocket = '/tmp/mytest.sock'
    if not os.path.exists(mysocket):
        os.mkfifo(mysocket)
    connection = Connection(mysocket)
    assert connection is not None, "Connection object is None"
    name = 'run'
    result = connection.__rpc__(name)
    assert result is not None, "Failed to execute Connection.__rpc__"
    assert result.get('stdout') is not None, "Failed to execute Connection.__rpc__"
    assert result.get('stdout') == "", "Failed to execute Connection.__rpc__"
    assert result.get('stdout_lines') is not None, "Failed to execute Connection.__rpc__"

# Generated at 2022-06-20 16:52:37.649131
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():

    class MockConnection(object):
        def __init__(self, socket_path):
            self._exec_jsonrpc = Connection._exec_jsonrpc
            self.socket_path = socket_path

    tempfile_path = 'tempfile.txt'
    conn = MockConnection(socket_path=tempfile_path)
    method_ = 'method'
    actual_obj = conn.__getattr__(method_)

    assert actual_obj.func is conn._exec_jsonrpc
    assert actual_obj.keywords['method_'] == method_

# Generated at 2022-06-20 16:52:46.453008
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    import os
    import shutil
    import errno

    # Create a file descriptor and make sure it isn't open yet
    tf = tempfile.NamedTemporaryFile(delete=False)
    name = tf.name
    os.close(tf.fileno())

    # Create a test object and make sure it can be pickled and unpickled
    obj = {'test': 123}
    data = cPickle.dumps(obj, protocol=0)
    assert cPickle.loads(data) == obj

    # Write to the file descriptor
    write_to_file_descriptor(tf.fileno(), obj)

    # Read the file and confirm the data is correct

# Generated at 2022-06-20 16:52:56.305919
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.connection import Connection
    import json
    c = Connection("/etc/ansible/ansible-connection")
    result = c.__rpc__("get_option", "timeout")
    result = json.loads(result)
    assert result["jsonrpc"] == "2.0"
    assert result["id"] == "7ddd6328-b869-43b3-a667-ea157bab8fda"
    assert result["result"] == 300


# Generated at 2022-06-20 16:53:02.901008
# Unit test for method send of class Connection
def test_Connection_send():
    import sys
    if sys.version_info[0] < 3:
        c = Connection('/tmp/ansible_test')
        assert c.send('{"jsonrpc":"2.0", "method": "test", "params": [], "id": "1"}') is not None



# Generated at 2022-06-20 16:53:06.078739
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class ConnectionUnderTest(Connection):
        pass

    connection_under_test = ConnectionUnderTest(socket_path="test_value")
    assert isinstance(connection_under_test, Connection)

# Generated at 2022-06-20 16:53:06.904469
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    assert True

# Generated at 2022-06-20 16:53:17.279483
# Unit test for function recv_data
def test_recv_data():
    """
    Exercise the recv_data function
    """
    from io import open
    import tempfile

    # Write out a file with data that can be read using recv_data
    fd, file_path = tempfile.mkstemp()
    with open(fd, mode='w') as f:
        size_ = 0
        size_ += f.write('name: foo\n')
        size_ += f.write('options:\n')
        size_ += f.write('  host: 127.0.0.1\n')
        size_ += f.write('  port: 22\n')
        size_ += f.write('  username: ansible\n')
        size_ += f.write('password: "test password"\n')
        size_ += f.write('timeout: 10\n')
        size_

# Generated at 2022-06-20 16:53:20.710671
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Try to create a ConnectionError object with a message and an arbitrary
    # keyworded argument.
    try:
        raise ConnectionError("error message", foo="bar")
    except ConnectionError as e:
        assert hasattr(e, 'foo')
        assert e.foo == "bar"

# Generated at 2022-06-20 16:53:27.243353
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Setup Mock
    mock_module = MagicMock()

    # Instantiate ansible_connection.plugins.connection.network_cli.Connection
    connection = Connection(mock_module._socket_path)

    # Setup
    mock_name = "mock_name"

    # Mock Call
    mock_response = connection._exec_jsonrpc(mock_name)

    # Assert Expected Calls
    mock_module.assert_has_calls([])

    # Assert Return value
    assert mock_response is None



# Generated at 2022-06-20 16:54:08.809678
# Unit test for method send of class Connection
def test_Connection_send():
    socket_path = '/tmp/ansible_test_socket'
    c = Connection(socket_path)
    with open(socket_path, 'wb') as f:
        f.write(b'\x00\x00\x00\x00\x00\x00\x00\x01')
        f.write(b'\x00\x00\x00\x00\x00\x00\x00\x01')

        with pytest.raises(ConnectionError):
            c.send('foo')

# Generated at 2022-06-20 16:54:10.967560
# Unit test for function exec_command
def test_exec_command():
    module = MockModule()
    command = 'show version'
    rc, out, err = exec_command(module, command)

    assert rc == 0
    assert out == 'show version\n'
    assert err == ''



# Generated at 2022-06-20 16:54:16.267806
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = os.path.join(os.getcwd(), "Connection.json")

    c = Connection(socket_path)
    assert c
    assert c.socket_path == socket_path

    try:
        c = Connection(None)
        assert False, "AssertionError is expected"
    except AssertionError:
        pass



# Generated at 2022-06-20 16:54:25.982745
# Unit test for function recv_data
def test_recv_data():

    data = to_bytes("Hello")
    packed_len = struct.pack('!Q', len(data))
    data = packed_len + data
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    server_address = './uds_socket'

    if os.path.exists(server_address):
        os.remove(server_address)
    sock.bind(server_address)

    sock.listen(1)
    csock, _ = sock.accept()
    csock.sendall(data)
    csock.close()
    sock.close()

    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(server_address)
    assert recv_data(sock) == to_bytes("Hello")


# Generated at 2022-06-20 16:54:36.496114
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.plugins.connection.socket import Connection
    import json
    import tempfile
    import socket


# Generated at 2022-06-20 16:54:38.444019
# Unit test for constructor of class Connection
def test_Connection():
    # Should accept a variable
    Connection('/var/run/netconf/ansible')
    try:
        # Should reject an empty variable
        Connection('')
    except AssertionError:
        pass

# Generated at 2022-06-20 16:54:46.591791
# Unit test for method send of class Connection
def test_Connection_send():
    try:
        conn = Connection('/tmp/test_jsonrpc.sock')
        conn.send('{"jsonrpc": "2.0", "method": "test_method", "params": {}, "id": "1234"}')
        conn.send('{"jsonrpc": "2.0", "method": "test_method", "params": {}, "id": "5678"}')
        res = conn.send('{"jsonrpc": "2.0", "method": "test_method", "params": {}, "id": "9012"}')
        # No exception means test passes, if exception is raised it will handle by except clause
    except Exception as e:
        raise AssertionError(e)

    # Check if the response is proper JSON

# Generated at 2022-06-20 16:54:51.904363
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('do_this', 'test', foo=True, bar='test')
    assert req['id'] is not None
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'do_this'
    assert req['params'] == (('test',), {'foo': True, 'bar': 'test'})

# Generated at 2022-06-20 16:55:04.966194
# Unit test for function exec_command
def test_exec_command():
    from ansible.module_utils.connection import exec_command
    from ansible.module_utils.connection import Connection
    import json
    import sys
    import os
    import tempfile

    class TestConnection(Connection):
        def __init__(self, socket_path):
            pass

        def exec_command(self, command):
            return command

    sys.modules['ansible.module_utils.connection'] = sys.modules[__name__]
    sys.modules['ansible.module_utils.connection.Connection'] = TestConnection
    os.environ['ANSIBLE_KEEP_REMOTE_FILES'] = '1'
    temp = tempfile.NamedTemporaryFile()
    os.environ['ANSIBLE_REMOTE_TEMP'] = temp.name

# Generated at 2022-06-20 16:55:15.075040
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class MockSocket(object):
        def __init__(self, family, type):
            pass

        def connect(self, path):
            return

        def sendall(self, data):
            return

        def recv(self, size):
            return

        def close(self):
            return

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(socket, 'socket', new=MockSocket):
        conn = Connection(socket_path="/path/to/socket")
        try:
            conn.banana()
        except ConnectionError as ex:
            if ex.code == 1:
                assert ex.err == 'banana method is not supported by ansible_connection'