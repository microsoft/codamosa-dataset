

# Generated at 2022-06-20 16:46:39.735678
# Unit test for method send of class Connection
def test_Connection_send():
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('/tmp/ansible_test_socket')
    sf.listen(5)
    conn, _ = sf.accept()

    data = {"test_key": "test_value"}
    data_str = json.dumps(data)

    c = Connection('/tmp/ansible_test_socket')
    r = c.send(data_str)

    assert r == data_str

# Generated at 2022-06-20 16:46:49.267973
# Unit test for function recv_data
def test_recv_data():
    test_socket_path = '/tmp/ansible_conftest_socket'
    try:
        os.remove(test_socket_path)
    except OSError:
        pass

    ss = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    ss.bind(test_socket_path)
    ss.listen(5)

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect(test_socket_path)

    csock, addr = ss.accept()
    # send data 1
    data_len = send_data(sf, to_bytes('123'))
    assert data_len == 6
    # send data 2
    data_len = send_data(sf, to_bytes('456'))

# Generated at 2022-06-20 16:46:52.657068
# Unit test for constructor of class ConnectionError
def test_ConnectionError():

    message = 'test_message'
    exc_obj = ConnectionError(message)

    assert exc_obj.message == message
    assert exc_obj.err is None
    assert exc_obj.code is None
    assert exc_obj.exception is None



# Generated at 2022-06-20 16:47:01.254473
# Unit test for constructor of class Connection
def test_Connection():
    try:
        socket_path = None
        Connection(socket_path)
        raise AssertionError('Test failed: socket_path must be a value')
    except AssertionError as exc:
        pass
    socket_path = '/var/lib/awx/venv/ansible/lib/python2.6/site-packages/ansible/plugins/connection/netconf'
    Connection(socket_path)



# Generated at 2022-06-20 16:47:07.008994
# Unit test for method send of class Connection
def test_Connection_send():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sfname = '/tmp/ansible-unix-socket'
    try:
        os.unlink(sfname)
    except OSError:
        if os.path.exists(sfname):
            raise
    s.bind(sfname)
    s.listen(1)
    data = to_bytes(json.dumps({'jsonrpc': '2.0', 'success': True}))
    packed_len = struct.pack('!Q', len(data))
    s2, _ = s.accept()

# Generated at 2022-06-20 16:47:17.102977
# Unit test for function request_builder
def test_request_builder():
    # Verify that request_builder can handle args and kwargs
    req = request_builder('foo', 'bar')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'foo'
    assert req['params'] == (('bar',), {})

    req = request_builder('foo', bar='baz')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'foo'
    assert req['params'] == ((), {'bar': 'baz'})

    req = request_builder('foo', 'bar', 'baz', foo='qux')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'foo'

# Generated at 2022-06-20 16:47:21.991229
# Unit test for function send_data
def test_send_data():
    a = "100"
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('/var/tmp/ansible-test-socket')

    send_data(s, a)
    b = recv_data(s)

# Generated at 2022-06-20 16:47:30.217052
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    socket_path = "/var/tmp/my_socket"

    # mock
    class MockSocket:
        def __init__(self):
            pass

        def connect(*args):
            pass

        def close(*args):
            pass

        def sendall(self, data):
            send_data(*args)

        def recv(self, length):
            return recv_data(*args)

    class MockStruct:
        def pack(*args, **kwargs):
            return b'\x11\x00\x00\x00'

        def unpack(*args, **kwargs):
            return 17

    class MockResponse:
        def __init__(self, id_, result):
            self.id = id_
            self.result = result

    import sys
    import io
    import json
    import traceback

   

# Generated at 2022-06-20 16:47:33.096611
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('test message')
    except ConnectionError as e:
        assert e.message == 'test message'
        assert e.args == ('test message',)
        assert e.code is None
        assert e.err is None
        assert e.exception is None
        assert str(e) == 'test message'

# Generated at 2022-06-20 16:47:36.791662
# Unit test for function exec_command
def test_exec_command():
    mod = ansible_module()
    mod._socket_path = '/tmp/ansible-9090'
    f = open(mod._socket_path, 'w')
    f.write('/bin/sh -c ls')
    f.close()
    rc, out, err = exec_command(mod, 'ls')
    os.remove(mod._socket_path)
    if rc != 0 or err:
        raise AssertionError('rc: %s, out: %s, err: %s' % (rc, out, err))


# Generated at 2022-06-20 16:47:56.004003
# Unit test for function request_builder
def test_request_builder():
    method_ = 'test_method'
    args = ('arg1', 'arg2')
    kwargs = {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}
    req = request_builder(method_, *args, **kwargs)
    assert req['jsonrpc'] == '2.0'
    assert req['id'] is not None
    assert req['method'] == 'test_method'
    assert req['params'] == (args, kwargs)

# Generated at 2022-06-20 16:48:04.505040
# Unit test for constructor of class Connection
def test_Connection():
    try:
        connection_object = Connection('sample_socket_path')
    except Exception as e:
        assert False

    try:
        connection_object = Connection(None)
        assert False
    except Exception as e:
        #TODO: Test if the message of the exception is equal to the given message
        #assert str(e) == 'socket_path must be a value'
        pass


# Generated at 2022-06-20 16:48:18.246142
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.remote_management.network.persistent.test_mock.json_rpc import \
        RPC_CLIENT_EXAMPLE, namedtuple
    from copy import copy
    from ansible.module_utils.network.common.utils import param_list_to_dict
    from ansible.module_utils._text import to_text

    mock_response = namedtuple('TestConnectionResponse', ('id', 'jsonrpc', 'result', 'error'))
    mock_error = namedtuple('TestConnectionError', ('code', 'message', 'data'))


# Generated at 2022-06-20 16:48:28.557279
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import Connection
    c = Connection(socket_path='/path/to/socket')
    assert(hasattr(c, "__rpc__"))
    assert(hasattr(c, "send"))
    assert(hasattr(c, "send_request"))
    assert(hasattr(c, "send_response"))
    assert(hasattr(c, "get_response"))
    assert(hasattr(c, "get_request"))
    assert(hasattr(c, "exec_command"))


# Generated at 2022-06-20 16:48:41.156517
# Unit test for function recv_data
def test_recv_data():
    import threading
    import time

    done = []

    class Server(threading.Thread):
        def __init__(self, s):
            threading.Thread.__init__(self)
            self.s = s

        def run(self):
            conn, addr = self.s.accept()
            while True:
                data = conn.recv(4096)
                if not data:
                    break
                total_received = 0
                while total_received < len(data):
                    sent = conn.send(data[total_received:])
                    if sent == 0:
                        raise RuntimeError("socket connection broken")
                    total_received += sent
            conn.close()
            done.append(True)

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-20 16:48:51.393376
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import PY2

    # Given a socket_path, instantiate a Connection instance
    conn = Connection(socket_path = '/tmp/ansible_test_connection')
    # Add a debug method to the Connection instance
    def debug(*text):
        print(*text)
    setattr(conn, 'debug', debug)
    # Construct the expected request
    expected_req = {'jsonrpc': '2.0', 'method': 'debug', 'id': '<a uuid>', 'params': ((('some', 'text'),), {})}
    # Insert the 'expected' uuid and expected JSON data into the expected request
    expected_req['id'] = conn.__rpc__('debug', 'some', 'text').get('id')
    expected

# Generated at 2022-06-20 16:49:00.505152
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    fd, path = tempfile.mkstemp(prefix="ansible-conn-data-")
    os.close(fd)

# Generated at 2022-06-20 16:49:04.866404
# Unit test for constructor of class Connection
def test_Connection():
    host = Connection('test')
    if host.socket_path != 'test':
        return ('FAILED: Connection class init test failed')
    return ('PASSED: Connection class init test passed')



# Generated at 2022-06-20 16:49:09.224889
# Unit test for constructor of class Connection
def test_Connection():
    socket_path = "/tmp/foo"
    connection = Connection(socket_path)
    assert connection.socket_path == socket_path

    # This should raise an assert error
    try:
        connection = Connection(None)
        assert False, "This test should raise an assert"
    except AssertionError:
        assert True


# Generated at 2022-06-20 16:49:19.619211
# Unit test for function send_data
def test_send_data():
    import tempfile
    import shutil
    import socket

    req_path = ''

    try:

        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

        req_path = tempfile.mkdtemp()
        socket_path = os.path.join(req_path, 'socket')

        sf.bind(socket_path)
        sf.listen(1)

        connection = Connection(socket_path)
        response = connection.send('Testing data')
        assert response == "Testing data"

    finally:
        sf.close()
        shutil.rmtree(req_path)

# Generated at 2022-06-20 16:49:31.308041
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    d = {'_socket_path': 'Test'}
    connection = Connection('Test')
    # Default return for object is None
    assert connection.test_getattr1() is None
    # Check for exceptions
    try:
        # Negative case
        connection.__dict__ = d
        connection._attr1
    except AttributeError as e:
        raise AssertionError("Exception raised in Connection.__getattr__") from e




# Generated at 2022-06-20 16:49:40.438445
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    # test for empty response
    assert recv_data(s) is None
    # test for invalid header length
    input_data = '\x02\x00\x00\x00\x00\x00\x00\x00'
    assert recv_data(s) is None
    # test for valid response with empty body
    input_data = '\x00\x00\x00\x00\x00\x00\x00\x00'
    assert recv_data(s) == ''
    # test for valid response with body
    input_data = '\x00\x00\x00\x00\x00\x00\x00\x03' + 'abc'
    assert recv_data

# Generated at 2022-06-20 16:49:51.775043
# Unit test for function recv_data
def test_recv_data():
    # create the socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)

    # bind the socket to port 8888 on all interfaces
    s.bind(('', 8888))

    # become a server socket
    s.listen(1)
    conn, addr = s.accept()

    # send and receive first message
    data = "a" * 8
    conn.send(data)
    assert recv_data(conn) == data

    # send and receive second message
    data2 = "b" * 16
    conn.send(data2)
    assert recv_data(conn) == data2

    # close connection
    conn.close()



# Generated at 2022-06-20 16:50:04.398500
# Unit test for method send of class Connection
def test_Connection_send():
    socket_path = "/tmp/test_Connection_socket"

    # Mock send_data and recv_data
    old_send_data = send_data
    old_recv_data = recv_data
    send_data.called = False

    # Count the number of calls to send_data and recv_data
    send_data.count = 0
    recv_data.count = 0

    def mock_send_data(s, data):
        old_send_data(s, data)
        send_data.called = True
        send_data.count += 1
        return s

    def mock_recv_data(s):
        recv_data.count += 1

        # Return data on all but last call
        if recv_data.count < 3:
            return "test"

        # Return none on last

# Generated at 2022-06-20 16:50:09.023227
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('test', a=1, b='two')
    except ConnectionError as exc:
        assert exc.a == 1
        assert exc.b == 'two'


# Generated at 2022-06-20 16:50:20.037963
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    fd, tmppath = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-20 16:50:24.315682
# Unit test for function send_data
def test_send_data():
    assert send_data(None, to_bytes('test')) is None
    assert send_data(None, to_bytes('')) is None


# Generated at 2022-06-20 16:50:32.415034
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(1)
    t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    t.connect(s.getsockname())
    f = s.accept()[0]

    send_data(t, b'hello')
    assert recv_data(f) == b'hello'

    send_data(t, b'hello' * 100000)
    assert recv_data(f) == b'hello' * 100000

    s.close()
    t.close()


# Generated at 2022-06-20 16:50:39.404904
# Unit test for function send_data
def test_send_data():
    code = to_bytes('ABCD')
    s = cPickle.dumps(code)
    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind('/tmp/send_data')
    send_data(sf, s)

    sf.listen(1)
    (conn, addr) = sf.accept()
    data = conn.recv(1024)
    assert data == s


# Generated at 2022-06-20 16:50:44.171707
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    err = ConnectionError('error')
    assert getattr(err, 'code', 'code') == 'code'
    assert getattr(err, 'err', 'err') == 'err'

    err = ConnectionError('error', code=1, err='error')
    assert getattr(err, 'code', 'code') == 1
    assert getattr(err, 'err', 'err') == 'error'
    assert str(err) == 'error'

# Generated at 2022-06-20 16:50:58.853448
# Unit test for constructor of class Connection
def test_Connection():
    # Valid Socket Path
    valid_socket_path = '/var/tmp/test'
    socket_test = Connection(valid_socket_path)
    assert socket_test.socket_path == valid_socket_path

    # Invalid Socket Path
    invalid_socket_path = ''
    try:
        socket_test = Connection(invalid_socket_path)
    except AssertionError:
        assert True

# Generated at 2022-06-20 16:51:11.701299
# Unit test for function recv_data
def test_recv_data():
    # Create a dummy socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)

    # Connect to it
    conn = socket.socket()
    conn.connect(sock.getsockname())

    # Accept the connection
    client, _ = sock.accept()

    send_data(client, b"123")
    assert recv_data(conn) == b"123"

    conn.close()
    client.close()

    # Create a dummy socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    sock.listen(1)

    # Connect to it

# Generated at 2022-06-20 16:51:22.221756
# Unit test for function request_builder
def test_request_builder():

    """
    This unit test verifies the request_builder function
    is implemented with all required functionality.
    """

    req = request_builder('func1', 'arg1', 'arg2', kwarg1='arg3', kwarg2='arg4')
    assert req['method'] == 'func1'
    assert req['params'][0] == ('arg1', 'arg2')
    assert req['params'][1] == {'kwarg1': 'arg3', 'kwarg2': 'arg4'}
    assert req['jsonrpc'] == '2.0'
    assert req['id']

    # Verify the id is unique each time the function is called
    reqid = req['id']

# Generated at 2022-06-20 16:51:34.202448
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('copy_file', 'src', 'dest') == \
        {'jsonrpc': '2.0', 'method': 'copy_file', 'id': 'src', 'params': ('dest', {})}

    assert request_builder('copy_file', 'src', 'dest', 'args') == \
        {'jsonrpc': '2.0', 'method': 'copy_file', 'id': 'src', 'params': ('dest', {'args': 'args'})}

    assert request_builder('copy_file', 'src', 'dest', 'args') == \
        {'jsonrpc': '2.0', 'method': 'copy_file', 'id': 'src', 'params': ('dest', {'args': 'args'})}


# Generated at 2022-06-20 16:51:38.438942
# Unit test for function exec_command
def test_exec_command():
    # mock a module and socket path
    module = type('module', (object,), {'_socket_path': '/tmp/ansible_network_engine.sock'})
    command = {'module': 'command', 'command': 'show version'}
    # assert success
    assert exec_command(module, command) == (0, '', '')
    # assert error
    module._socket_path = '/some_bad_path'
    assert exec_command(module, command)[0] == 1

# Generated at 2022-06-20 16:51:46.296895
# Unit test for function recv_data
def test_recv_data():
    # Set up a test TCP server
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen(1)

    # Set up a test TCP client
    c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    c.connect(('127.0.0.1', s.getsockname()[1]))

    cs, addr = s.accept()

    # Send some test data
    send_data(cs, b"123456")

    # Receive the data
    response = recv_data(c)

    # Check the data is correct
    assert response == b"123456"

# Generated at 2022-06-20 16:51:56.927960
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    msg = to_text("message")
    code = 1
    err = to_text("error")
    exception = "exception" # fake exception string

    # test with no additional kwargs
    err_obj = ConnectionError(msg)
    assert err_obj.message == msg
    assert not err_obj.args
    assert not vars(err_obj)

    # test with code kwarg
    err_obj = ConnectionError(msg, code=code)
    assert err_obj.message == msg
    assert not err_obj.args
    assert err_obj.code == code

    # test with err kwarg
    err_obj = ConnectionError(msg, err=err)
    assert err_obj.message == msg
    assert not err_obj.args
    assert err_obj.err == err

    # test with exception

# Generated at 2022-06-20 16:52:06.114828
# Unit test for function recv_data
def test_recv_data():

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    s.listen(1)
    data = to_bytes("Test string for recv_data")
    curr_thread = threading.Thread(target=partial(listener, s=s, data=data))
    curr_thread.start()
    time.sleep(3)

    sf = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sf.connect(("127.0.0.1", s.getsockname()[1]))
    send_data(sf, data)

    sf.close()
    s.close()
    curr_thread.join()


# Generated at 2022-06-20 16:52:11.329281
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('a', b='b', c=1)

    except ConnectionError as exc:
        assert exc.a == 'a'
        assert exc.b == 'b'
        assert exc.c == 1

# Generated at 2022-06-20 16:52:16.781905
# Unit test for function send_data
def test_send_data():
    """Unit testing for send_data();  The test uses a single socket
    to both send and receive data to simulate the behavior of
    the remote server and client.
    """
    test_data = [os.urandom(1024) for i in range(0, 25)]
    socks = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
    for data in test_data:
        send_data(socks[0], data)
        received_data = recv_data(socks[1])
        assert received_data == data



# Generated at 2022-06-20 16:52:39.406028
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('./test_recv_data.sock')
    s.listen(1)
    (sc, sa) = s.accept()
    data = recv_data(sc)
    assert data == b'test_recv_data'
    sc.close()
    s.close()
    os.unlink('./test_recv_data.sock')

    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('./test_recv_data.sock')
    send_data(s, b'test_recv_data')
    s.close()


# Generated at 2022-06-20 16:52:47.119583
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection(None)
    except AssertionError as e:
        assert str(e) == 'socket_path must be a value'
        assert type(e) == AssertionError
    try:
        socket_path = os.path.join(os.path.dirname(__file__), 'fixtures/test.socket')
        c = Connection(socket_path)
        assert c.socket_path == socket_path
        assert c.send('hello') == 'world'
    except Exception:
        import traceback
        traceback.print_exc()
        assert False
    finally:
        os.unlink(socket_path)

# Generated at 2022-06-20 16:52:53.488197
# Unit test for method send of class Connection
def test_Connection_send():
    conn = Connection(socket_path='/tmp/ansible_test')
    assert conn.send(data='test_data') == 'test_data'
    conn.socket_path = None
    try:
        conn.send(data='test_data')
        assert False, 'Failed to raise AssertionError'
    except AssertionError:
        pass
    conn.socket_path = '/tmp/ansible_test'

    try:
        conn.send(data='test_data')
        assert False, 'Failed to raise ConnectionError'
    except ConnectionError:
        pass

# Generated at 2022-06-20 16:52:55.420131
# Unit test for function exec_command
def test_exec_command():
    module = None
    command = 'test'
    assert exec_command(module, command)[0] == 0

# Generated at 2022-06-20 16:53:00.691172
# Unit test for function exec_command
def test_exec_command():
    class TestModule:
        pass

    test_module = TestModule()
    test_module._socket_path = '/foo'
    code, out, msg = exec_command(test_module, 'shell')
    assert code == 0

# Generated at 2022-06-20 16:53:05.918214
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ce = ConnectionError("foo")
    assert hasattr(ce, 'message')
    assert ce.message == "foo"

    ce = ConnectionError("foo", code=1, some_attr='bar')
    assert ce.some_attr == "bar"
    assert ce.code == 1

# Generated at 2022-06-20 16:53:16.945576
# Unit test for function recv_data
def test_recv_data():
    """
    Unit test for function recv_data
    """
    import os
    import signal
    import tempfile

    tempdir = tempfile.mkdtemp()
    socket_path = os.path.join(tempdir, 'socket')

    def parent():
        """
        Function used in unit test as parent
        """
        child_pid, child_fd = os.forkpty()
        if child_pid == 0:
            connection = Connection(socket_path)
            connection.exec_command("echo hello")
            os._exit(0) # pylint: disable=protected-access
        os.waitpid(child_pid, 0)

    def child():
        """
        Function used in unit test as child
        """
        os.chdir('/')

# Generated at 2022-06-20 16:53:26.710740
# Unit test for method send of class Connection
def test_Connection_send():
    socket_path = "/tmp/test.sock"

    if os.path.exists(socket_path):
        os.remove(socket_path)

    server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server_socket.bind(socket_path)
    server_socket.listen(5)

    sent_data = "test_Connection_send"

    data = request_builder("test")

    try:
        c = Connection(socket_path)
        out = c.send(json.dumps(data, cls=AnsibleJSONEncoder))
    except ConnectionError as exc:
        pass

    (client_socket, client_address) = server_socket.accept()

    data = recv_data(client_socket)
    assert sent_data == json.loads

# Generated at 2022-06-20 16:53:38.119283
# Unit test for function send_data
def test_send_data():
    test_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    def _send(s, data):
        s.sendall(struct.pack('!Q', len(data)) + data)
    send_data.__code__ = _send.__code__


# Generated at 2022-06-20 16:53:46.726999
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    my_module = AnsibleModule(argument_spec=dict())
    # Test simple string
    my_string = 'hello world'
    my_collec = ImmutableDict({'a': 'b', 'c': 1, 'd': 'e'})

    # Test collections, which would be problematic if the pickle protocol
    # was not correct.
    my_dict = {'a': 'b', 'c': 1, 'd': 'e'}
    my_list = [1, 2, 3, 'a', 'b', 'c']
    my_tuple = (1, 2, 3, 'a', 'b', 'c')

    # Create two pipes, one for sending,

# Generated at 2022-06-20 16:54:03.321260
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    error_obj = ConnectionError('error')
    assert error_obj.err == 'error'
    assert error_obj.code == None
    assert error_obj.exception == None

# Generated at 2022-06-20 16:54:08.583769
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    message = 'Connection failed'
    with pytest.raises(ConnectionError) as excinfo:
        raise ConnectionError(message)
    assert message in str(excinfo.value)


# Generated at 2022-06-20 16:54:15.492022
# Unit test for function request_builder
def test_request_builder():
    req = request_builder("load_config", "hostname foo")
    assert req == {
        'id': str(uuid.UUID('25d4c4f4-4b4c-4a1a-a05d-c58088b8c931')),
        'method': 'load_config',
        'jsonrpc': '2.0',
        'params': (("hostname foo",), {})
    }

# Generated at 2022-06-20 16:54:21.493178
# Unit test for function exec_command
def test_exec_command():
    module = ansible_module_init({'ANSIBLE_MODULE_ARGS': '{"ANSIBLE_MODULE_ARGS": "ANSIBLE_MODULE_ARGS"}'})
    assert exec_command(module, 'show version') == (0, '', '')

# Generated at 2022-06-20 16:54:29.996549
# Unit test for function request_builder
def test_request_builder():
    import sys
    import os
    import inspect
    # For this test this is needed
    sys.modules['ansible'] = type('dummy_ansible_module', (object,), {})
    test_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    lib_path = os.path.normpath(os.path.join(test_dir, '../lib/ansible/module_utils/connection.py'))

    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)
    from connection import request_builder

    method_ = 'method'
    args = [1, 'a', {'a': 1, 'b': 2}]

# Generated at 2022-06-20 16:54:38.189004
# Unit test for function recv_data
def test_recv_data():
    # Use unbuffered socket
    sock = socket.socket(type=socket.SOCK_STREAM)
    sock.setblocking(False)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1)
    # Accept data in one-byte packets
    # start with a data smaller than buffer
    data = to_bytes("*" * 10)
    # encode data length in little endian
    packed_len = list(struct.pack('<Q', len(data)))
    # put in list of char to control each send, which returns number of sent bytes
    send_string = packed_len + list(data)


# Generated at 2022-06-20 16:54:43.835666
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    err = ConnectionError("error")
    assert hasattr(err, 'code') == False
    assert hasattr(err, 'err') == False
    assert hasattr(err, 'exception') == False

    err = ConnectionError("error", code=1, err="error message", exception="exception")
    assert err.code == 1
    assert err.err == "error message"
    assert err.exception == "exception"

# Generated at 2022-06-20 16:54:53.704150
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    fd, fpath = tempfile.mkstemp()
    obj = dict(foo='bar', baz='qux')
    write_to_file_descriptor(fd, obj)
    os.close(fd)

    with open(fpath, 'r') as f:
        length = f.readline()
        assert length == '%d\n' % len(obj)
        src = f.readline(int(length))
        data_hash = f.readline()

    assert cPickle.loads(src) == obj
    assert data_hash == hashlib.sha1(src).hexdigest() + '\n'



# Generated at 2022-06-20 16:55:05.240045
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('localhost', 0))
    s.listen(1)

    conn = Connection(s.getsockname())

    socket_path = conn.socket_path
    conn.send('thisisatest')

    sock, addr = s.accept()
    data = sock.recv(1024)
    header_len = 8
    data_len = struct.unpack('!Q', data[:header_len])[0]
    assert data_len == len('thisisatest')
    received_data = data[header_len:]
    assert received_data == 'thisisatest'
    sock.close()


# Generated at 2022-06-20 16:55:15.221693
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():

    filename = '/tmp/test_write_to_file_descriptor'
    try:
        os.unlink(filename)
    except Exception:
        pass

    fd = os.open(filename, os.O_CREAT | os.O_RDWR)

    test_data = {'test': 1, 'string': 'hello', 'unicode': to_text('h\xe9llo', errors='strict')}

    write_to_file_descriptor(fd, test_data)

    os.close(fd)

    fd = os.open(filename, os.O_CREAT | os.O_RDWR)

    data_len = int(os.read(fd, 10))
    test_data_serialized = os.read(fd, data_len)

# Generated at 2022-06-20 16:55:46.350775
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    obj = [1, 2, 3]
    fd = os.pipe()
    write_to_file_descriptor(fd[1], obj)

    assert(os.read(fd[0], 1024) == b'19\n')

    data_len = os.read(fd[0], 1024)
    assert(data_len == b'\x80\x03]q\x00(K\x01K\x02K\x03e.')

    data_hash = os.read(fd[0], 1024)
    assert(data_hash == b'fd60c6e9e6d2e6f33b6e8d6f36b6d3a34caf11a3\n')

# Generated at 2022-06-20 16:55:54.501779
# Unit test for function request_builder
def test_request_builder():
    import pprint
    req = request_builder('connect', host='127.0.0.1', port=22, username='test', password='test')
    pprint.pprint(req)

    req = request_builder('exec_command', command='show version')
    pprint.pprint(req)

    req = request_builder('get_file', src='/tmp/test.txt', dest='/tmp/test.dat')
    pprint.pprint(req)

# Generated at 2022-06-20 16:55:57.079428
# Unit test for constructor of class Connection
def test_Connection():
    assert(Connection('socket_path'))


# Generated at 2022-06-20 16:56:05.405473
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-20 16:56:15.953650
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    def raise_ce(msg):
        raise ConnectionError(msg)

    assert_raises(ConnectionError, raise_ce, "test")

    try:
        raise_ce("test")
    except ConnectionError as exc:
        assert exc.err == "test"
        assert exc.code == 1

    def raise_kw_ce(msg, code, **kwargs):
        raise ConnectionError(msg, code=code, **kwargs)

    assert_raises(ConnectionError, raise_kw_ce, "test", 2)

    try:
        raise_kw_ce("test", 2)
    except ConnectionError as exc:
        assert exc.err == "test"
        assert exc.code == 2

# Generated at 2022-06-20 16:56:22.027658
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Connection object
    class_obj = Connection('/tmp/foo')

    response = class_obj._exec_jsonrpc('foo', '1', '2', kwarg='kwarg')

    assert response['id'] == '1'

    response = class_obj._exec_jsonrpc('foo', '1', '2', kwarg='kwarg')

    assert response['id'] == '2'

    # set_option(s) has sensitive info, and the details are unlikely to matter anyway
    try:
        response = class_obj._exec_jsonrpc('set_option', '1', '2', kwarg='kwarg')
    except ConnectionError as exc:
        assert exc.message == "Unable to decode JSON from response to set_option(1, 2, kwarg='kwarg'). Received ''.\n"

