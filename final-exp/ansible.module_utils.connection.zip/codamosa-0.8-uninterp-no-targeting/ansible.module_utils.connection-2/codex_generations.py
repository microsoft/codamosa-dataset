

# Generated at 2022-06-20 16:46:39.039617
# Unit test for method send of class Connection
def test_Connection_send():
    # Create an object of class Connection
    obj = Connection('/var/tmp/ansible-conn.sock')

    data = {"jsonrpc": "2.0", "id": "d0b0bc71-9ee9-405c-8909-1e910bfc846e", "method": "exec_command",
            "params": ["echo hello"]}
    obj.send(data)



# Generated at 2022-06-20 16:46:39.957845
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    assert ConnectionError('test exception')


# Generated at 2022-06-20 16:46:53.550351
# Unit test for function exec_command
def test_exec_command():

    import ansible.module_utils.common.json
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-20 16:47:04.621501
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    obj = {'foo': 'bar'}

    tmpfile = '/tmp/ansible_test_write_to_file_descriptor'
    if os.path.exists(tmpfile):
        os.unlink(tmpfile)
    fd = os.open(tmpfile, os.O_CREAT | os.O_RDWR, 0o600)

    write_to_file_descriptor(fd, obj)

    os.lseek(fd, 0, os.SEEK_SET)

    # read back the data
    strlen = to_text(os.read(fd, 1024))
    src = to_text(os.read(fd, int(strlen)))
    data_hash = to_text(os.read(fd, 1024))

    os.close(fd)

# Generated at 2022-06-20 16:47:06.242945
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ConnectionError('test message', code=1)

# Generated at 2022-06-20 16:47:08.393257
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('This is a message')
    except ConnectionError as exc:
        assert exc.message == 'This is a message'


# Generated at 2022-06-20 16:47:12.551503
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    err = ConnectionError("Failed to connect")
    assert err.message == 'Failed to connect'
    assert err.code == 1
    assert err.err == None


# Generated at 2022-06-20 16:47:14.321579
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ce = ConnectionError('ConnectionError', code=1, err='ConnectionError')
    assert ce.message == 'ConnectionError'
    assert ce.code == 1
    assert ce.err == 'ConnectionError'

# Generated at 2022-06-20 16:47:26.677876
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    # Create dummy UNIX socket used for testing
    dummy_socket_path = '/tmp/test.sock'
    dummy_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    dummy_socket.bind(dummy_socket_path)
    dummy_fd = dummy_socket.fileno()

    obj = {
        "--ANSIBLE_KEEP_REMOTE_FILES": "True",
        "--ANSIBLE_MODULE_ARGS": "{'a': 'b'}",
        "--ANSIBLE_MODULE_NAME": "test",
        "--ANSIBLE_MODULE_SETUP": "True",
        "--ANSIBLE_REMOTE_TMP": "/tmp"
    }


# Generated at 2022-06-20 16:47:38.567116
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection('/tmp/test')
    try:
        connection.test_attr
    except AttributeError:
        pass
    else:
        assert False, "Connection did not raise AttributeError when accessing non-existent method"
    connection.__dict__['test_attr'] = 'foobar'
    assert connection.test_attr == 'foobar', "Connection's __getattr__ failed to return value of existing attribute"
    connection.__dict__.pop('test_attr')
    try:
        connection.test_attr
    except AttributeError:
        pass
    else:
        assert False, "Connection did not raise AttributeError when accessing non-existent method"


# Generated at 2022-06-20 16:47:50.601164
# Unit test for constructor of class Connection
def test_Connection():

    # create a concrete class object
    connection = Connection('/path/to/a/file')

    # check the value of socket_path field
    assert connection.socket_path == '/path/to/a/file'

# Generated at 2022-06-20 16:48:00.492954
# Unit test for function exec_command
def test_exec_command():
    module = MockModule()
    code, stdout, stderr = exec_command(module, "show version")
    assert code == 0
    expected_output = """\
    Cisco IOS Software, C3750 Software (C3750-IPBASEK9-M), Version 12.2(55)SE9, RELEASE SOFTWARE (fc4)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Thu 08-Jun-17 00:17 by prod_rel_team


Switch Ports Model              SW Version            SW Image
------ ----- -----              ----------            ----------
*    1 26    WS-C3750-26TT      12.2(55)SE9            C3750-IPBASEK9-M

Configuration register is 0xF
    """

    assert std

# Generated at 2022-06-20 16:48:11.430732
# Unit test for function exec_command
def test_exec_command():
    args_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                             os.path.basename(__file__) + ".args")
    args_file = open(args_path, 'r')
    module_args = json.load(args_file)

    if 'socket_path' in module_args:
        socket_path = module_args['socket_path']
    else:
        socket_path = None

    command = module_args['command']

    code, out, err = exec_command(module_args, command)
    module_args['_ansible_version'] = 2
    module = type(str("module"), (), module_args)

    module.exit_json(command=command, stdout=out, stderr=err, rc=code)



# Generated at 2022-06-20 16:48:23.422988
# Unit test for method send of class Connection
def test_Connection_send():
    import tempfile, os
    import shutil
    import socket

    socket_path = tempfile.mkdtemp() + '/test_send'
    msg = 'This is a test message'

    # Test Case1 : Socket Path does not exist
    # Expected Result: Should throw a ConnectionError
    conn = Connection(socket_path = socket_path)
    try:
        conn.send(msg)
    except ConnectionError as e:
        assert e.code == 1
    else:
        assert False, 'ConnectionError should have been raised'

    # Test Case2 : Socket Path does exist but no file
    # Expected Result: Socket Error should be caught and raised as a ConnectionError
    try:
        os.unlink(socket_path)
    except OSError:
        pass

    # create a socket in a known state

# Generated at 2022-06-20 16:48:31.521662
# Unit test for function recv_data
def test_recv_data():
    import mock

    def mock_recv(n):
        if n > len(data):
            return None
        else:
            return data

    s = mock.MagicMock()
    s.recv = mock_recv

    # test no data
    data = ""
    assert recv_data(s) == data

    # test one character
    data = "a"
    assert recv_data(s) == data

    # test string length > 2**8
    data = "a" * 256
    assert recv_data(s) == data

    # test string length < 2**8
    data = "a" * 255
    assert recv_data(s) == data

    # test string length > 2**16
    data = "a" * 65536
    assert recv_data(s) == data

   

# Generated at 2022-06-20 16:48:39.427684
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    s.listen(1)
    (sock1, addr1) = s.accept()
    sock2 = socket.create_connection(sock1.getsockname())
    foo = b"gibberish"
    send_data(sock2, foo)
    assert(recv_data(sock1) == foo)



# Generated at 2022-06-20 16:48:41.862266
# Unit test for constructor of class Connection
def test_Connection():
    assert Connection('/my/data/socket').socket_path == '/my/data/socket'


# Generated at 2022-06-20 16:48:44.907605
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('Test Exception', err='Error')
    except Exception as e:
        assert e.args[0] == 'Test Exception'
        assert e.code == 'Error'


# Generated at 2022-06-20 16:48:46.940033
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection("/tmp/socket")
    assert c.socket_path == "/tmp/socket"



# Generated at 2022-06-20 16:48:51.131790
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection("")
    except AssertionError as e:
        assert("socket_path must be a value" in to_text(e))


# Generated at 2022-06-20 16:49:02.197506
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection()
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-20 16:49:05.547272
# Unit test for constructor of class Connection
def test_Connection():
    try:
        conn = Connection(None)
    except AssertionError:
        pass
    else:
        raise AssertionError('Connection should throw AssertionError when socket_path is None')


# Generated at 2022-06-20 16:49:07.200834
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('message')
    assert exc.message == 'message'



# Generated at 2022-06-20 16:49:08.966868
# Unit test for method send of class Connection
def test_Connection_send():
    pass

# Generated at 2022-06-20 16:49:14.287201
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    conn = Connection("/var/lib/awx/ansible_connection")
    try:
        result = conn.__rpc__("exec_command", "show version")
    except ConnectionError as exc:
        code = getattr(exc, 'code', 1)
        message = getattr(exc, 'err', exc)
        print(code, message)


# Generated at 2022-06-20 16:49:23.127918
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('foo')
    assert exc.message == 'foo'
    assert not hasattr(exc, 'err')
    assert not hasattr(exc, 'exception')
    assert not hasattr(exc, 'code')

    exc = ConnectionError('bar', err='err')
    assert exc.message == 'bar'
    assert exc.err == 'err'
    assert not hasattr(exc, 'exception')
    assert not hasattr(exc, 'code')

    exc = ConnectionError('baz', exception='exception')
    assert exc.message == 'baz'
    assert not hasattr(exc, 'err')
    assert exc.exception == 'exception'
    assert not hasattr(exc, 'code')

    exc = ConnectionError('buz', code=1)

# Generated at 2022-06-20 16:49:34.177797
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    class Test(Connection):
        def _exec_jsonrpc(self, name, *args, **kwargs):
            return {'id': None, 'result': None}

    class TestException(Exception):
        pass

    r = Test(None)
    assert r._exec_jsonrpc == r.__rpc__
    # It should return the result of the called function
    r._exec_jsonrpc = lambda name, *args, **kwargs: {'id': None, 'result': 'this is the result'}
    assert r.__rpc__('foo') == 'this is the result'
    # It should raise a ConnectionError if an error occurred
    r._exec_jsonrpc = lambda name, *args, **kwargs: {'id': None, 'error': 'this is an error'}

# Generated at 2022-06-20 16:49:37.068996
# Unit test for constructor of class Connection
def test_Connection():
    s = "ansible_connection"
    c = Connection(s)
    assert c.socket_path == s


# Generated at 2022-06-20 16:49:41.220309
# Unit test for function request_builder
def test_request_builder():
    reqid = str(uuid.uuid4())
    req = {'jsonrpc': '2.0', 'method': 'get_option', 'id': reqid}
    req['params'] = (('foo', 'bar'), {'baz': 'qux'})

    req_expected = request_builder('get_option', 'foo', 'bar', baz='qux')
    assert req == req_expected

# Generated at 2022-06-20 16:49:52.613036
# Unit test for function send_data
def test_send_data():
    import select

    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind("/tmp/test_send_data.sock")
    s.listen(1)
    r = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    r.connect("/tmp/test_send_data.sock")
    w, _, _ = select.select([r], [], [], 5)
    assert w, "server didn't get connection in time"
    c, _ = s.accept()

    send_data(c, b"helloworld")
    data = recv_data(r)

# Generated at 2022-06-20 16:50:19.840539
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError("test error")
    except ConnectionError as exc:
        assert(exc.message == "test error")
        assert(exc.code is None)
        assert(exc.err is None)

    try:
        raise ConnectionError("test error 2", code=1)
    except ConnectionError as exc:
        assert(exc.message == "test error 2")
        assert(exc.code == 1)
        assert(exc.err is None)

    try:
        raise ConnectionError("test error 3", err="test err")
    except ConnectionError as exc:
        assert(exc.message == "test error 3")
        assert(exc.code is None)
        assert(exc.err == "test err")


# Generated at 2022-06-20 16:50:27.024915
# Unit test for function recv_data
def test_recv_data():
    data = b'0123456789'
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        s.listen(1)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as cs:
            cs.connect(("127.0.0.1", s.getsockname()[1]))
            ss, _ = s.accept()
            send_data(ss, data)
            assert recv_data(cs) == data

            ss.close()
            assert recv_data(cs) is None



# Generated at 2022-06-20 16:50:33.473072
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', 0))
    s.listen(1)

    sender = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sender.connect(s.getsockname())

    receiver, _ = s.accept()

    message = 'YWJjZGVmZ2hpag==\n'
    send_data(sender, to_bytes(message))
    assert recv_data(receiver) == message


# Generated at 2022-06-20 16:50:39.255355
# Unit test for method send of class Connection
def test_Connection_send():
    socket_path = "/var/run/ansible/ansible-connection-unix.socket"

    data = {'msg': 'sample message'}
    expected_data = json.dumps(data)
    expected_response = "[]"

    connection = Connection(socket_path)
    response = connection.send(expected_data)
    assert response == expected_response



# Generated at 2022-06-20 16:50:41.881889
# Unit test for function exec_command
def test_exec_command():
    # TODO: Don't know how to test this
    pass



# Generated at 2022-06-20 16:50:50.888320
# Unit test for function send_data
def test_send_data():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))


# Generated at 2022-06-20 16:50:53.608939
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    assert ConnectionError('test')
    assert ConnectionError('test', err='test error', code=110)

# Generated at 2022-06-20 16:50:56.901249
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    result = ConnectionError('ConnectionError', code=123)
    assert result.args[0] == 'ConnectionError'
    assert result.code == 123

# Generated at 2022-06-20 16:51:04.655380
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    # Check if a ConnectionError can be instantiated
    connection_error = ConnectionError('a message')
    assert connection_error
    assert connection_error.message == 'a message'
    assert connection_error.code is None
    assert connection_error.err is None
    assert connection_error.exception is None

    # Check that all params are set when instantiating a ConnectionError
    connection_error = ConnectionError('a message', code=1, err='an error', exception='an exception')
    assert connection_error.message == 'a message'
    assert connection_error.code == 1
    assert connection_error.err == 'an error'
    assert connection_error.exception == 'an exception'

# Generated at 2022-06-20 16:51:06.027528
# Unit test for function exec_command
def test_exec_command():
    result = exec_command(None, 'echo hello')
    assert result == (0, "hello\n", '')

# Generated at 2022-06-20 16:51:46.294483
# Unit test for method send of class Connection
def test_Connection_send():
    try:
        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sf.connect("/var/tmp/test_connection_plugin")

        send_data(sf, to_bytes("some data"))
        response = recv_data(sf)

    except socket.error as e:
        sf.close()
        raise ConnectionError(
            'unable to connect to socket %s. See the socket path issue category in '
            'Network Debug and Troubleshooting Guide' % sf.socket_path,
            err=to_text(e, errors='surrogate_then_replace'), exception=traceback.format_exc()
        )

    sf.close()

    import json
    d = response.decode('utf-8')
    json.loads(d)
    return

# Generated at 2022-06-20 16:51:49.362501
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection(None)
    out = unicode(c)
    assert out == '<ansible.module_utils.connection.Connection object>'

# Generated at 2022-06-20 16:51:57.722960
# Unit test for function request_builder
def test_request_builder():
    req1 = request_builder('test_method')
    assert req1['jsonrpc'] == '2.0'
    assert req1['method'] == 'test_method'
    assert req1['id'] != ''
    assert req1['params'] == ((), {})

    req2 = request_builder('test_method2', 1, 2, 3)
    assert req2['params'] == ((1, 2, 3), {})

    req3 = request_builder('test_method3', 1, 2, 3, test='me')
    assert req3['params'] == ((1, 2, 3), {'test': 'me'})


# Generated at 2022-06-20 16:52:03.389526
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind("/tmp/test2")
    s.listen(1)
    client, address = s.accept()

    send_data(client, to_bytes("123"))
    data = recv_data(client)
    assert to_text(data, errors='surrogate_or_strict') == "123"

# Generated at 2022-06-20 16:52:06.017015
# Unit test for function exec_command
def test_exec_command():
    assert exec_command(None, "test command") == (0, '', '')

# Generated at 2022-06-20 16:52:16.006405
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    tmp = tempfile.mktemp()
    os.unlink(tmp)
    s.bind(tmp)
    s.listen(1)

    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.connect(tmp)

    data = b'this is a test'
    send_data(client, data)

    accept = s.accept()
    (conn, addr) = accept
    recv = recv_data(conn)
    client.close()

    assert data == recv

    s.close()
    conn.close()
    os.unlink(tmp)


# Generated at 2022-06-20 16:52:18.355949
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    try:
        raise ConnectionError('err message')
    except ConnectionError as inst:
        assert inst.code == 1
        assert inst.err == 'err message'
        assert inst.message == 'err message'

# Generated at 2022-06-20 16:52:19.263304
# Unit test for constructor of class Connection
def test_Connection():
    raise NotImplementedError()

# Generated at 2022-06-20 16:52:29.544823
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    connection = Connection(socket_path="ansible_test.socket")
    connection.send = mock_Connection_send = Mock(return_value = "{\"error\": {\"data\": {}, \"code\": -32602, \"message\": \"Invalid params\"}, \"id\": \"b6023a63-0eac-4db9-9a0a-6e02c6b3e8df\", \"jsonrpc\": \"2.0\"}")
    command = "show_version"
    try:
        connection._exec_jsonrpc(command)
    except ConnectionError as err:
        assert(err.message == "Invalid params")
    assert mock_Connection_send.call_count == 1

# Generated at 2022-06-20 16:52:32.220342
# Unit test for function request_builder
def test_request_builder():
    # Unimplemented function.
    # Just stub to pass the test.
    return


# Generated at 2022-06-20 16:53:42.132892
# Unit test for constructor of class Connection
def test_Connection():
    assert isinstance(Connection('/path/to/socket'), Connection)
    # Test the assert statement in the constructor
    try:
        Connection(None)
    except AssertionError:
        pass
    else:
        assert False, 'AssertionError not raised'


# Generated at 2022-06-20 16:53:54.462432
# Unit test for function request_builder
def test_request_builder():

    # test for all valid methods and arguments
    assert request_builder('method', 1, 2, kwarg=3) == {
        'jsonrpc': '2.0',
        'method': 'method',
        'id': 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX',
        'params': ([1, 2], {'kwarg': 3})
    }
    assert request_builder('method', kwarg1=1, kwarg2=2) == {
        'jsonrpc': '2.0',
        'method': 'method',
        'id': 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX',
        'params': ([], {'kwarg1': 1, 'kwarg2': 2})
    }
    # test an empty request

# Generated at 2022-06-20 16:53:58.793140
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection(socket_path='/tmp/foo.socket')
    assert c.socket_path == '/tmp/foo.socket'



# Generated at 2022-06-20 16:54:03.528445
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # Preparation
    connection = Connection(socket_path=None)

    # Action
    result = connection.__rpc__(name=None, args=None, kwargs=None)

    # Verification
    assert result is None



# Generated at 2022-06-20 16:54:16.307430
# Unit test for function recv_data
def test_recv_data():

    if not hasattr(socket, 'AF_UNIX'):
        return

    sp = '/tmp/ansible_test_socket'

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.connect(sp)

    if os.path.exists(sp):
        os.remove(sp)

    ss = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    ss.bind(sp)
    ss.listen(1)

    teststring = 'test\nasync\nstring'
    send_data(sf, to_bytes(teststring))

    conn, addr = ss.accept()
    response = recv_data(conn)

    assert response == to_bytes(teststring)

# Generated at 2022-06-20 16:54:25.717283
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    """Test write_to_file_descriptor in module_utils/common.py"""
    # write_to_file_descriptor(fd, message)

    # Need a handle to a pipe.
    r_handle, w_handle = os.pipe()

    message = {'key': 'value'}
    write_to_file_descriptor(w_handle, message)

    os.lseek(r_handle, 0, 0)
    data = os.read(r_handle, 1024)

    data_len = int(to_text(data.split(b'\n')[0]))
    data = data[len(str(data_len)):-41]

    result = cPickle.loads(data)
    json_result = json.dumps(result, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 16:54:28.287197
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection('mock')
    assert connection.socket_path == 'mock'



# Generated at 2022-06-20 16:54:36.496228
# Unit test for function request_builder
def test_request_builder():
    # Test valid request
    reqid = str(uuid.uuid4())
    req = request_builder('ping')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'ping'
    assert req['id'] == reqid
    assert req['params'] == ([], {})

    # Test invalid request
    reqid = str(uuid.uuid4())
    req = request_builder('ping', 'connect')
    assert req['jsonrpc'] == '2.0'
    assert req['method'] == 'ping'
    assert req['id'] == reqid
    assert req['params'] == ((), {})



# Generated at 2022-06-20 16:54:41.115234
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import os
    import tempfile
    import subprocess
    from ansible.module_utils.six import b

    def get_tmp_fd(tmp):
        tmp.seek(0)
        return os.dup(tmp.fileno())

    # Simple command_spec with valid input
    command_spec = dict(
        args=dict(
            arg1='arg1',
            arg2=[1, 2],
            arg3=dict(
                subarg1=True,
                subarg2=[1, 2]
            )
        )
    )
    tmp = tempfile.TemporaryFile()
    fd = get_tmp_fd(tmp)
    write_to_file_descriptor(fd, command_spec)
    fd = get_tmp_fd(tmp)

# Generated at 2022-06-20 16:54:46.659497
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    # connection_class_mock = MagicMock(name='Connection')
    connection_class_mock = type('Connection', (object, ), {})
    connection_class_mock_instance = connection_class_mock()
    connection_class_mock_instance.socket_path = 'my/socket/path'
    connection_class_mock_instance._exec_jsonrpc = MagicMock(name='_exec_jsonrpc')
    connection_class_mock_instance._exec_jsonrpc.return_value = {'id': 'fake-id', 'result': 'fake-result'}
    connection_result = connection_class_mock_instance.__rpc__('fake-name', 'fake-arg')
    assert connection_result == 'fake-result'
    connection_class_mock_instance._exec_