

# Generated at 2022-06-20 16:46:34.816436
# Unit test for function send_data
def test_send_data():
    import socket
    import time

    s = socket.socket(socket.AF_UNIX)
    path = '/tmp/test_send_data'
    s.bind(path)
    s.listen(1)

    try:
        c = socket.socket(socket.AF_UNIX)
        c.connect(path)
        sf, addr = s.accept()

        send_data(c, 'test\n')
        assert recv_data(sf) == 'test\n'

        send_data(c, 'test')
        assert recv_data(sf) == 'test'

        assert recv_data(sf) is None
    finally:
        s.close()
        os.remove(path)

# Generated at 2022-06-20 16:46:46.043270
# Unit test for function send_data
def test_send_data():
    test_socket = None

# Generated at 2022-06-20 16:46:46.917776
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    pass


# Generated at 2022-06-20 16:46:55.843862
# Unit test for function recv_data
def test_recv_data():
    data = b"\x01\x02\x03\x04\x05\x06\x07\x08"
    # This test is not portable and therefore only available when running on Unix systems
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock_path = "/tmp/ansible-conn-testsock-%s" % os.getpid()
    sock.bind(sock_path)
    sock.listen(5)
    client_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    retries = 0
    while retries < 60:
        try:
            client_sock.connect(sock_path)
            break
        except socket.error as e:
            if e.errno == 111:
                ret

# Generated at 2022-06-20 16:46:58.737506
# Unit test for constructor of class Connection
def test_Connection():
    '''Test case for constructor of class Connection'''
    conn = Connection(socket_path=None)
    assert isinstance(conn, Connection)



# Generated at 2022-06-20 16:47:07.766564
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():

    class Connection(object):

        def __init__(self, socket_path):
            if socket_path is None:
                raise AssertionError('socket_path must be a value')
            self.socket_path = socket_path

        def __getattr__(self, name):
            try:
                return self.__dict__[name]
            except KeyError:
                if name.startswith('_'):
                    raise AttributeError("'%s' object has no attribute '%s'" % (self.__class__.__name__, name))
                return partial(self.__rpc__, name)

        def _exec_jsonrpc(self, name, *args, **kwargs):

            req = request_builder(name, *args, **kwargs)
            reqid = req['id']


# Generated at 2022-06-20 16:47:12.934699
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    transport = 'socket'
    socket_path = '~/ansible.socket'
    connection = Connection(socket_path)
    func_name = 'get_config'
    connection.__getattr__(func_name)



# Generated at 2022-06-20 16:47:17.856765
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('a', b='b', c=1)
    assert exc.a == 'b'
    assert exc.c == 1
    assert exc.message == 'a'

# Generated at 2022-06-20 16:47:22.564366
# Unit test for method send of class Connection
def test_Connection_send():
    import sys
    sys.path.append("/usr/lib/python2.7/dist-packages/ansible/modules")
    import action_plugin

    module = action_plugin.ActionModule(load_attr_module=False)
    module.action_write = False

    plugin_connection = Connection(module._socket_path)

    try:
        response_data = plugin_connection.send("thisis the data")
    except Exception as e:
        print("Exception: {}".format(e))
    else:
        print("Successfully connected")
    print("Response data: {}".format(response_data))


# Generated at 2022-06-20 16:47:29.771334
# Unit test for function exec_command
def test_exec_command():
    module = object()
    module.socket_path = '/tmp/ansible_test'
    f = open(module.socket_path, 'w')
    f.write('It is a test')
    f.close()
    assert exec_command(module, 'whoami') == (0, 'It is a test', '')
    os.remove(module.socket_path)
    assert exec_command(module, 'whoami') == (1, '',
                                              'unable to connect to socket /tmp/ansible_test. See Troubleshooting socket path issues in the Network Debug and Troubleshooting Guide')

# Generated at 2022-06-20 16:47:41.157306
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    import tempfile
    import os

    fd, fname = tempfile.mkstemp()

    write_to_file_descriptor(fd, 'hello world')

    os.lseek(fd, 0, os.SEEK_SET)
    obj = os.read(fd, os.path.getsize(fname)).strip('\n')

    fd.close()
    os.remove(fname)


    assert obj == '11\nhello world\n2aae6c35c94fcfb415dbe95f408b9ce91ee846ed\n'

# Generated at 2022-06-20 16:47:49.760488
# Unit test for function recv_data
def test_recv_data():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_bytes
    import os
    import socket
    import struct

    def send_data(s, data):
        packed_len = struct.pack('!Q', len(data))
        return s.sendall(packed_len + data)

    # write small non-JSON data
    # test only validates send and recv part of the connection
    server_socket_path = '/tmp/ansible_connection_test_%d.sock' % os.getpid()

    sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sf.bind(server_socket_path)
    sf.listen(5)

    # test with empty string

# Generated at 2022-06-20 16:47:55.534358
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    """Test of class ConnectionError.
    """
    # Calling init of class ConnectionError
    try:
        raise ConnectionError("ConnectionError message", code="20", err="20")
    except ConnectionError as exc:
        assert exc.args[0] == "ConnectionError message"
        assert exc.code == "20"
        assert exc.err == "20"


# Generated at 2022-06-20 16:48:02.946363
# Unit test for method __getattr__ of class Connection
def test_Connection___getattr__():
    connection = Connection(module._socket_path)
    assert '{{ cookiecutter.connection_plugin }}_exec_command' in dir(connection)

# Generated at 2022-06-20 16:48:08.300778
# Unit test for method send of class Connection
def test_Connection_send():
    assert to_text(send_data(sf, b'{"jsonrpc": "2.0", "id": "reqid", "method": "get_capabilities", "params": ()}')) == '{"jsonrpc": "2.0", "id": "reqid", "method": "get_capabilities", "params": ()}'



# Generated at 2022-06-20 16:48:20.820868
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from __main__ import Connection
    import json
    import unittest

    class RequestBuilder(object):
        def request_builder(*args, **kwargs):
            reqid = str(uuid.uuid4())
            req = {'jsonrpc': '2.0', 'method': args[0], 'id': reqid}
            req['params'] = (args[1:], kwargs)
            return req

    class ConnectionError(Exception):

        def __init__(self, message, *args, **kwargs):
            super(ConnectionError, self).__init__(message)
            for k, v in iteritems(kwargs):
                setattr(self, k, v)
    
    class TestConnection(unittest.TestCase):
        def test_example(self):
            test = Connection('abc')


# Generated at 2022-06-20 16:48:30.866265
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind('/tmp/socket_test')
    s.listen(1)
    conn, addr = s.accept()

    data = 'test'
    packed_len = struct.pack('!Q', len(data))
    conn.send(packed_len + data)
    assert recv_data(conn) == data

    data = 'test2'
    packed_len = struct.pack('!Q', len(data))
    conn.send(packed_len + data)
    assert recv_data(conn) == data

    s.close()
    conn.close()
    os.unlink('/tmp/socket_test')

# Generated at 2022-06-20 16:48:34.842454
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    exc = ConnectionError('foo', bar='baz')
    assert exc.err == 'foo'
    assert exc.bar == 'baz'



# Generated at 2022-06-20 16:48:38.681310
# Unit test for method send of class Connection
def test_Connection_send():
    '''
    :return:
    '''
    c = Connection("/path/to/socket")
    c.socket_path = "/usr/local/bin/ansible-connection"
    data = "test_data"
    assert c.send(data) == 'test_data'

# Generated at 2022-06-20 16:48:50.261941
# Unit test for function request_builder
def test_request_builder():
    """ Unit test for function request_builder """

    from ansible.module_utils.connection import Connection

    # Test with no params
    req = Connection.request_builder('method_name',)
    assert req['jsonrpc'] == '2.0', 'jsonrpc value not set'
    assert req['method'] == 'method_name'
    assert req['id'] is not None

    # Test with empty params
    req = Connection.request_builder('method_name', (), {})
    assert req['jsonrpc'] == '2.0', 'jsonrpc value not set'
    assert req['method'] == 'method_name'
    assert req['id'] is not None

    # Test with positional params
    req = Connection.request_builder('method_name', (1, 2, 3,), {})

# Generated at 2022-06-20 16:49:20.340420
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible_collections.notstdlib.moveitallout.plugins.connection.connection_loader import ConnectionModule
    from ansible_collections.notstdlib.moveitallout.plugins.loader import connection_loader

    if connection_loader._CONNECTION_PLUGINS is None:
        # init connection plugins
        connection_loader.get_all()

    cm = ConnectionModule("connection")
    cm.socket_path = b'/var/tmp/ansible_test'
    cm.set_options(direct={"persistent_connect_timeout": 5,
                           "persistent_command_timeout": 5,
                           "persistent_connection": True})

    with open("/var/tmp/ansible_test", 'wb') as f:
        f.write(b"#!/usr/bin/env python\n")
       

# Generated at 2022-06-20 16:49:25.351189
# Unit test for function exec_command
def test_exec_command():
    module = {}
    module['_socket_path'] = '/tmp/test_socket'
    command = 'show version'
    out = exec_command(module, command)
    assert out[0] == 0
    assert out[1] == 'show version'

# Generated at 2022-06-20 16:49:32.422134
# Unit test for function send_data
def test_send_data():
    """Test send_data function
    """
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    tmp = tempfile.mkstemp()
    os.close(tmp[0])
    s.bind(tmp[1])
    s.listen(1)
    data = 'data'
    send_data(s[0], data)
    conn, addr = s.accept()
    ret = recv_data(conn)
    s.close()
    if data != ret:
        raise AssertionError('Original data not equal to received data')

# Generated at 2022-06-20 16:49:41.364697
# Unit test for function recv_data
def test_recv_data():
    import socket
    import threading

    class TestServer(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.s = socket.socket()
            self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.s.bind(('localhost', 0))
            self.s.listen(1)
            self.port = self.s.getsockname()[1]

        def run(self):
            self.client, self.address = self.s.accept()
            self.client.sendall(b'\x00\x00\x00\x00\x00\x00\x00\x05Hello')


# Generated at 2022-06-20 16:49:44.995866
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection('/path/to/socket')
    assert conn


# Test for getattr magic method with a fake attribute name and
# existing attribute name

# Generated at 2022-06-20 16:49:53.800890
# Unit test for method send of class Connection
def test_Connection_send():
    _socket_path = '/foo/bar'
    _data = '{"id": 1, "jsonrpc": 2.0, "method": "echo", "params": {"host": "10.10.10.10"}}'
    _exp_return_value = '{"id": 1, "jsonrpc": 2.0, "result": {"host": "10.10.10.10"}}'

    _connection = Connection(_socket_path)
    with patch('socket.socket') as mocked_socket_object:
        mocked_socket_object.return_value.connect.return_value = None
        mocked_socket_object.return_value.sendall.return_value = None
        mocked_socket_object.return_value.recv.return_value = to_bytes(_exp_return_value)

# Generated at 2022-06-20 16:50:05.132311
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ce = ConnectionError("message")
    assert ce.message == "message"
    assert ce.args == ()
    assert ce.code is None
    assert ce.err is None
    assert ce.exception is None

    ce = ConnectionError("message", code=100)
    assert ce.message == "message"
    assert ce.args == ()
    assert ce.code == 100
    assert ce.err is None
    assert ce.exception is None

    ce = ConnectionError("message", err="error message")
    assert ce.message == "message"
    assert ce.args == ()
    assert ce.code is None
    assert ce.err == "error message"
    assert ce.exception is None

    ce = ConnectionError("message", exception="exception message")
    assert ce.message == "message"

# Generated at 2022-06-20 16:50:09.117148
# Unit test for function send_data
def test_send_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect("./test.sock")
    send_data(s, "Test Data")


# Generated at 2022-06-20 16:50:17.767135
# Unit test for function recv_data
def test_recv_data():
    '''
    Test recv_data
    '''
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock_file = '/tmp/sock_test'
    sock.bind(sock_file)
    sock.listen(1)
    conn, addr = sock.accept()
    # Send the length of the payload, followed by the payload itself
    conn.sendall(struct.pack('!Q', 5) + b'hello')
    conn.close()
    sock.close()

    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(sock_file)

    # Receive data from the server
    read_data = recv_data(sock)

    # Check that the data was correct
    assert read

# Generated at 2022-06-20 16:50:26.378841
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    class MockModule(object):
        def __init__(self, socket_path):
            self._socket_path = socket_path

    class MockSocketError(socket.error):
        def __init__(self, *args, **kwargs):
            super(MockSocketError, self).__init__(*args, **kwargs)
            self.errno = 2

    class ConnectionTest(unittest.TestCase):
        def setUp(self):
            self.connection = Connection(MockModule('/tmp/mock'))


# Generated at 2022-06-20 16:50:54.304415
# Unit test for method send of class Connection
def test_Connection_send():
    import __builtin__
    from ansible.module_utils.network.common.utils import get_module_path
    from ansible.module_utils.network.common.config import NetworkConfig

    params = dict(
        connection='network_cli',
        host='127.0.0.1',
        port=11000,
        username='admin',
        password='cisco',
        timeout=300,
    )

    module = NetworkModule(**params)
    module.params['_ansible_verbosity'] = 4
    module.params['_ansible_debug'] = True
    module.params['_ansible_socket'] = '/Users/usmanzaheerrizvi/Documents/test_socket'

    connection = Connection(module.params['_ansible_socket'])

# Generated at 2022-06-20 16:50:57.510060
# Unit test for function exec_command
def test_exec_command():
    module = type('module', (object,), {'_socket_path': '', '_ansible_is_failed': lambda x: False})
    assert exec_command(module, 'ls')[1] != ''

# Generated at 2022-06-20 16:51:00.963551
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    conn_obj = Connection("/usr/share/ansible_plugins/connection/__init__.py")
    assert conn_obj._exec_jsonrpc("exec_command", "ansible-connection", "--version") is not None


# Generated at 2022-06-20 16:51:02.345541
# Unit test for constructor of class ConnectionError
def test_ConnectionError():
    ConnectionError('unable to connect')

# Generated at 2022-06-20 16:51:06.796026
# Unit test for function exec_command
def test_exec_command():
    import platform
    my_platform = platform.system().lower()
    if my_platform == 'linux' or my_platform == 'darwin':
        # Mac OS or Linux
        assert(exec_command('/usr/bin/ls') == 0)
    elif my_platform == 'windows':
        # Windows
        assert(exec_command('C:\\Windows\\System32\\ipconfig.exe') == 0)
    else:
        assert False



# Generated at 2022-06-20 16:51:18.384649
# Unit test for function recv_data
def test_recv_data():
    # data is a tuple which size is 1
    test_data_1 = (b"abc",)
    # data is a tuple which size is 2
    test_data_2 = (b"abc", b"def")
    # data is a tuple which size is 3
    test_data_3 = (b"abc", b"def", b"123")

    # data is a list which size is 1
    test_data_4 = [b"abc"]
    # data is a list which size is 2
    test_data_5 = [b"abc", b"def"]
    # data is a list which size is 3
    test_data_6 = [b"abc", b"def", b"123"]

    # data is a list which size is 4

# Generated at 2022-06-20 16:51:27.343813
# Unit test for function recv_data
def test_recv_data():
    # Create a pair of connected sockets
    lsock, rsock = socket.socketpair()
    # Test that recv_data returns None when socket is closed
    rsock.close()
    assert recv_data(lsock) == None

    # Test that recv_data returns right data
    lsock, rsock = socket.socketpair()
    datastr = "testdata"
    send_data(rsock, datastr)
    assert recv_data(lsock) == datastr

    # Test that recv_data returns right data with multiple calls
    rsock.close()
    rsock, lsock = socket.socketpair()
    datastr = "testdata"
    send_data(rsock, datastr)
    assert recv_data(lsock) == datastr


# Generated at 2022-06-20 16:51:36.274960
# Unit test for function send_data
def test_send_data():
    """
    This test assumes that the remote end is a socket which echoes back
    whatever it receives.
    """
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind('\x00ansible-test-%s' % os.getpid())
    sock.listen(1)
    sock.setblocking(0)
    p = os.fork()
    if p == 0:
        # child

        bufsize = 1024
        sf = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sf.connect('\x00ansible-test-%s' % os.getpid())
        while True:
            to_send = os.urandom(bufsize)
            send_data(sf, to_send)
            got = rec

# Generated at 2022-06-20 16:51:46.527732
# Unit test for function send_data
def test_send_data():
    import socket
    s = socket.socket()

    s.bind(("", 0))
    s.listen(1)

    host = s.getsockname()[0]
    port = s.getsockname()[1]

    s2 = socket.socket()
    s2.connect((host, port))
    ss, _ = s.accept()

    send_data(ss, 'foo')
    assert recv_data(s2) == 'foo'

    send_data(ss, 'f'*(2**16))
    assert recv_data(s2) == 'f'*(2**16)

    send_data(ss, 'foobar')
    assert recv_data(s2) == 'foobar'

    s.close()
    s2.close()

# Generated at 2022-06-20 16:51:54.160703
# Unit test for function request_builder
def test_request_builder():
    test = request_builder('function1', 'arg1', 'arg2', kwarg1='kwarg1', kwarg2='kwarg2')
    expected = {
        "jsonrpc": "2.0",
        "method": "function1",
        "id": test["id"],
        "params": (('arg1', 'arg2'), {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'})
    }
    assert test == expected

test_request_builder()

# Generated at 2022-06-20 16:52:49.026613
# Unit test for method send of class Connection
def test_Connection_send():

    class Mock_socket(object):
        """Mock class for socket object"""
        def __init__(self, *args, **kwargs):
            self._sent_msg = None
            self._sent_data = None
            self._recv_msg = None
            self._recv_data = None
            self._close_called = False
            self.err = None

        def sendall(self, data):
            self._sent_msg = data
            if self.err:
                raise socket.error(self.err)

        def recv(self, size):
            if self._recv_msg:
                if self._recv_data:
                    data = self._recv_data[:size]
                    self._recv_data = self._recv_data[size:]
                    return data


# Generated at 2022-06-20 16:52:54.910548
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    '''
    Unit test for method __rpc__ of class Connection
    '''
    from ansible.module_utils.connection import Connection
    con = Connection('/dev/null')
    result = con.__rpc__('exec_command', 'echo 1')
    assert result['stdout'] == "1\n"

# Generated at 2022-06-20 16:53:08.469916
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    from tempfile import mkstemp
    from os import unlink, fdopen

    testdata = {'a': 1, 'b': 2}

    # This is a python2 and python3 compatible way to create a file
    # descriptor.
    fd, filepath = mkstemp()
    f = fdopen(fd, "w")

    # write_to_file_descriptor will write the data in a binary format.
    # Need to ensure it is encoded/decoded appropriately.
    write_to_file_descriptor(fd, testdata)
    f.close()

    fd, filepath = mkstemp()
    f = fdopen(fd, "r")

    # Get the length of the data from the first line of the file.
    datalength = int(f.readline())

    # Read

# Generated at 2022-06-20 16:53:17.017669
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():
    obj = {'foo': 'bar'}

    # using a pipe as it makes it easier then using a socket
    (rfd, wfd) = os.pipe()

    write_to_file_descriptor(wfd, obj)

    # read a line, which is the length of the object
    len = int(os.read(rfd, 1024).strip())

    obj_str = os.read(rfd, len)
    obj2 = cPickle.loads(obj_str)
    data_hash = os.read(rfd, 1024).strip()

    assert hashlib.sha1(obj_str).hexdigest() == data_hash
    assert obj2 == obj

# Generated at 2022-06-20 16:53:19.553287
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection('test')
    except AssertionError:
        pass
    else:
        raise AssertionError('unexpected exception')
    Connection('/tmp/test')

# Generated at 2022-06-20 16:53:23.994636
# Unit test for function request_builder
def test_request_builder():
    req = request_builder('get_option', 'persistent_connection')
    assert req['id'] != ''
    assert req['method'] == 'get_option'
    assert req['params'] == ((['persistent_connection'], {}),)


# Generated at 2022-06-20 16:53:36.949818
# Unit test for function request_builder
def test_request_builder():
    assert request_builder('method_name') == {
        'jsonrpc': '2.0',
        'id': str(uuid.uuid4()),
        'method': 'method_name',
        'params': ((), {}),
    }
    assert request_builder('method_name', 'arg1', arg2='val2') == {
        'jsonrpc': '2.0',
        'id': str(uuid.uuid4()),
        'method': 'method_name',
        'params': (('arg1',), {'arg2': 'val2'}),
    }

# Generated at 2022-06-20 16:53:46.146179
# Unit test for method __rpc__ of class Connection
def test_Connection___rpc__():
    socket_path = '/tmp/ansible_test_socket'
    test_args = ['arg1', 'arg2']
    test_kwargs = {'kwarg1': 'val1', 'kwarg2': 'val2'}

    conn = Connection(socket_path)
    conn.send = lambda data: '''{
        "jsonrpc": "2.0",
        "result": "%s",
        "id": "13"
    }''' % (' '.join(test_args) + ' '.join(['{0}={1}'.format(k, v) for k, v in iteritems(test_kwargs)]))
    out = conn.__rpc__('my_method', *test_args, **test_kwargs)


# Generated at 2022-06-20 16:53:55.794163
# Unit test for function exec_command
def test_exec_command():
    req = {}
    req['ansible_version'] = '2.9.9'
    req['ansible_connection'] = 'network_cli'
    req['ansible_network_os'] = 'junos'
    req['ansible_user'] = 'test_user'
    req['ansible_ssh_pass'] = 'test_pass'
    req['ansible_become_password'] = 'test_pass'
    req['ansible_command_timeout'] = '60'
    req['ansible_diff'] = False
    req['ansible_become'] = True
    req['ansible_become_method'] = 'enable'
    req['ansible_become_user'] = 'test_user'
    req['ansible_become_pass'] = 'test_pass'

# Generated at 2022-06-20 16:54:06.528190
# Unit test for function write_to_file_descriptor
def test_write_to_file_descriptor():

    import cStringIO
    import sys

    # Test basic write and read
    obj = ["A", "B"]
    fake_fd = cStringIO.StringIO()
    write_to_file_descriptor(fake_fd, obj)
    fake_fd.seek(0)
    length = int(fake_fd.readline().strip())
    message = cPickle.loads(to_bytes(fake_fd.read(length)))
    assert message == obj

    # Test with redirecting stdout
    obj = ["C", "D"]
    fake_fd = cStringIO.StringIO()
    sys.stdout = fake_fd
    write_to_file_descriptor(sys.__stdout__.fileno(), obj)
    sys.stdout = sys.__stdout__

# Generated at 2022-06-20 16:55:46.742579
# Unit test for function recv_data
def test_recv_data():
    test_data = [{'data': '\x00\x00\x00\x00chunk1', 'expect': None},
                 {'data': '\x00\x00\x00\x00', 'expect': ''},
                 {'data': '\x00\x00\x00\x04\x00\x00\x00\x00chunk1', 'expect': '\x00\x00\x00\x00'},
                 {'data': '\x00\x00\x00\x04\x00\x00\x00\x04chunk1', 'expect': 'chunk1'}]

    class MockSocket(object):
        def __init__(self, data):
            self._data = data


# Generated at 2022-06-20 16:55:57.309417
# Unit test for function send_data
def test_send_data():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    sock.listen(1)
    addr = sock.getsockname()

    def connect_get():
        s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s2.connect(addr)
        resp = recv_data(s2)
        s2.close()
        return resp

    s2, addr2 = sock.accept()
    send_data(s2, 'foo')
    s2.close()
    sock.close()
    assert 'foo' == connect_get()

    # Test sending unicode that must be encoded
    s2, addr2 = sock.accept()

# Generated at 2022-06-20 16:56:02.205978
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection('test_socket_path')
    assert isinstance(c, Connection)
    try:
        c = Connection(None)
        raise AssertionError('should throw an AssertionError exception')
    except AssertionError:
        pass

# Generated at 2022-06-20 16:56:10.135448
# Unit test for constructor of class Connection
def test_Connection():
    try:
        Connection(None)
    except AssertionError:
        pass
    else:
        assert False, "Failed to raise AssertionError"

    socket_path = os.path.expandvars("$HOME/.ansible/pc")
    try:
        Connection(socket_path)
    except ConnectionError:
        pass
    else:
        assert False, "Failed to raise ConnectionError"

    socket_path = os.path.expandvars("$HOME/.ansible/tmp/ansible-test_socket")
    conn = Connection(socket_path)
    assert conn.socket_path == socket_path



# Generated at 2022-06-20 16:56:19.148321
# Unit test for function recv_data
def test_recv_data():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('./test_socket')
    packet_len = 8
    recvd_data = to_bytes("")
    while len(recvd_data) < packet_len:
        recvd_data += s.recv(packet_len - len(recvd_data))
    data_len = struct.unpack('!Q', recvd_data[:packet_len])[0]
    recvd_data = recvd_data[packet_len:]
    while len(recvd_data) < data_len:
        recvd_data += s.recv(data_len - len(recvd_data))
    s.close()
    return to_text(recvd_data)
