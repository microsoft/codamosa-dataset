

# Generated at 2022-06-26 00:30:59.742764
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:31:08.962889
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .company import Company
    from .accounts import AccountType, chart_of_accounts

    # Create a test company
    company = Company("TEST_COMPANY")

    # Create a JournalEntry with multiple post actions on 4 different accounts

# Generated at 2022-06-26 00:31:11.509205
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert JournalEntry(datetime.date(year=2020, month=9, day=1),"buy milk",Account("Expenses","Food"),Direction.INC).validate()

# Generated at 2022-06-26 00:31:12.762730
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()

# Generated at 2022-06-26 00:31:22.627582
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry: JournalEntry = JournalEntry(datetime.date(2020, 4, 20), "doc", "source")
    journal_entry.post(journal_entry.date, Account("101", "Cash", AccountType.ASSETS), 500)
    journal_entry.post(journal_entry.date, Account("201", "Inventory", AccountType.ASSETS), -500)
    journal_entry.post(journal_entry.date, Account("102", "Sales", AccountType.REVENUES), -500)
    journal_entry.post(journal_entry.date, Account("102", "Sales", AccountType.REVENUES), -0)
    journal_entry.post(journal_entry.date, Account("202", "Cost of Goods Sold", AccountType.EXPENSES), 500)
    journal_entry.validate()
    assert  journal_entry

# Generated at 2022-06-26 00:31:25.314648
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    period_0 = DateRange(datetime.date(2018, 10, 1), datetime.date(2018, 10, 2))
    assert True

# Generated at 2022-06-26 00:31:29.888357
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry()
    je.post(datetime.date(2020, 1, 30), Account(1, 'cash', AccountType.ASSETS), Quantity(100))
    je.post(datetime.date(2020, 1, 30), Account(1, 'sales', AccountType.REVENUES), Quantity(100))
    je.validate()

# Generated at 2022-06-26 00:31:32.775293
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    assert type(read_journal_entries_0(DateRange())) == Iterable[JournalEntry[_T]]


# Generated at 2022-06-26 00:31:42.989904
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import AccountType

    journal_entry = JournalEntry(date(2020, 8, 7), "Sample journal entry", "Sample source")

    account1 = Account('Account1', 1000, AccountType.ASSETS)
    account2 = Account('Account2', 1000, AccountType.EXPENSES)
    journal_entry.post(date(2020, 8, 7), account1, 100)
    journal_entry.post(date(2020, 8, 7), account2, -100)
    assert len(journal_entry.postings) == 2

    account3 = Account('Account3', 1000, AccountType.ASSETS)
    account4 = Account('Account4', 1000, AccountType.EXPENSES)
    account5 = Account('Account5', 1000, AccountType.REVENUES)

# Generated at 2022-06-26 00:31:46.292180
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_JournalEntry = JournalEntry[int]
    #test_journal_entry = test_JournalEntry(date=datetime.date, description="test", source=1)
    #assert test_journal_entry.validate() == None

# Generated at 2022-06-26 00:31:56.706652
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = JournalEntry[int](date=datetime.date(2020, 4, 12), description='test', source=1).post(datetime.date(2020, 4, 12), Account('1'), 2)\
        .post(datetime.date(2020, 4, 12), Account('2'), -2)
    a.validate()
    print(a.increments)
    print(a.decrements)
    print(a.debits)
    print(a.credits)

test_JournalEntry_validate()

# Generated at 2022-06-26 00:32:07.060516
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from decimal import Decimal
    from ..accounts import Account, AccountGroup, AccountType
    from ..books import makebook
    
    # Define book, accounts and journal entries
    book= makebook()
    income_group = book.create_group(AccountGroup.INCOME)
    account_revenue = book.create_account(AccountType.REVENUES, 'Revenues', income_group, 'Account to record revenues')
    account_expense = book.create_account(AccountType.EXPENSES, 'Expenses', income_group, 'Account to record expenses')
    account_debit  = book.create_account(AccountType.ASSETS, 'Debit', income_group, 'Account to record assets')

# Generated at 2022-06-26 00:32:15.999373
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .sources import SourceFactory
    from .currencies import CurrencyFactory
    from .accounts import AccountFactory

    usd = CurrencyFactory.usd()
    cad = CurrencyFactory.cad()
    journal = JournalEntry[SourceFactory](date=datetime.date(2017, 1, 1))
    journal.post(date=datetime.date(2017, 1, 1), account=AccountFactory.assets_usd_bank(), quantity=100)
    journal.post(date=datetime.date(2017, 1, 1), account=AccountFactory.liabilities_cad_cc(), quantity=-100)
    journal.validate()

    journal = JournalEntry[SourceFactory](date=datetime.date(2017, 1, 1))

# Generated at 2022-06-26 00:32:24.778134
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest.mock import Mock

    # Define test cases:
    test_cases = [
        (
            DateRange(),
            # Expected:
            Mock()(DateRange()),
        ),
    ]

    # Run the tests:
    for index, (input, expected) in enumerate(test_cases):
        # noinspection PyTypeChecker
        actual = ReadJournalEntries.__call__(Mock(), input)
        assert actual == expected, f"Test #{index + 1} failed."

# Generated at 2022-06-26 00:32:25.946512
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:32:35.742354
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    test_account = Account("test-account", AccountType.ASSETS)
    test_date = datetime.date.today()
    test_journal = JournalEntry[object]("test-date", "test-description", "test-object")
    test_quantity = 30
    test_account = Account("test-account", AccountType.ASSETS)
    test_journal.post(test_date, test_account, test_quantity)
    assert test_journal.postings[0].amount.value == test_quantity
    assert test_journal.postings[0].date == test_date
    assert test_journal.postings[0].account.name == "test-account"

# Generated at 2022-06-26 00:32:46.182436
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Creating journal entry
    journalEntry1 = JournalEntry[int](datetime.date(2019, 1, 1), "description1", 1, [])
    journalEntry2 = JournalEntry[int](datetime.date(2019, 1, 1), "description2", 2, [])

    ## Posting Amounts
    journalEntry1.post(datetime.date(2019, 1, 1), Account("account1", "account1", AccountType.ASSETS), 100)
    journalEntry1.post(datetime.date(2019, 1, 1), Account("account2", "account2", AccountType.EQUITIES), -100)
    journalEntry2.post(datetime.date(2019, 1, 1), Account("account3", "account3", AccountType.ASSETS), 100)

# Generated at 2022-06-26 00:32:46.744490
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:32:55.964129
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .commons.others import newguid
    from .events import Transaction, Transfer

    journal = Transaction.Create(
        date=datetime.date(2020, 1, 9),
        description="Buy 4 apples for $2 each",
        source=newguid(),
    )
    
    # create book and accounts
    book = Book("Test Book", "")
    inventory_account = book.create_account("Inventory", AccountType.ASSETS, None)
    revenue_account = book.create_account("Sales", AccountType.REVENUES, None)
    # book.create_account("Cash", AccountType.LIABILITIES, None)

    # post
    journal.post(journal.date, inventory_account, -4)

# Generated at 2022-06-26 00:33:09.801601
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2020, 1, 1), "Description", None)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), 100)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EXPENSES, "Salaries"), -95)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), 20)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EXPENSES, "Salaries"), -15)

# Generated at 2022-06-26 00:33:19.993622
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:33:29.797527
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1 = JournalEntry(datetime.date.today(), "Description", "joe", [])
    je1.validate()

    je2 = JournalEntry(datetime.date.today(), "Description", "joe", [
                       Posting(je1, datetime.date.today(), Account("Assets", AccountType.ASSETS,
                                                                  "Assets", "Description",
                                                                  None),
                               Direction.INC,
                               Amount(10, "INR")),
                       Posting(je1, datetime.date.today(), Account("Expenses", AccountType.DEC,
                                                                  "Expenses", "Description",
                                                                  None),
                               Direction.INC,
                               Amount(10, "INR"))])
    je2.validate()


# Generated at 2022-06-26 00:33:38.766185
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..trades.instruments import Stock, StockType
    from ..trades.portfolios import Portfolio, Position
    from ..trades.quotes import EquityQuotes
    from ..trades.transactions import Buy, Transaction

    abc = Stock("ABC", StockType.COMMON)
    abc_31_dec_2020 = EquityQuotes(abc).as_of(datetime.date(2020, 12, 31))
    txn_1_jan_2021 = Transaction(Buy, abc, 10, abc_31_dec_2020.price)

    def read(period: DateRange) -> Iterable[JournalEntry[Transaction]]:
        if period.start_date == datetime.date(2021, 1, 1):
            return txn_1_jan_2021.journal_entries
        else:
            return iter([])

# Generated at 2022-06-26 00:33:49.098579
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounting import Account
    from datetime import date

    je = JournalEntry[str]('2019-12-01', "Test", "")
    je.post(date.today(), Account("A1", AccountType.ASSETS, "Cash"), Quantity(100))
    je.post(date.today(), Account("A2", AccountType.ASSETS, "Bank"), Quantity(-100))

    je.validate()

    je = JournalEntry[str]('2019-12-01', "Test", "")
    je.post(date.today(), Account("A1", AccountType.ASSETS, "Cash"), Quantity(100))
    je.post(date.today(), Account("A2", AccountType.ASSETS, "Bank"), Quantity(100))

    from pytest import raises

    with raises(AssertionError):
        je.validate()

# Generated at 2022-06-26 00:33:49.746876
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:33:57.992570
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import datetime
    from .accounts import Account

    account = Account("debit", account_type=AccountType.ASSETS)

    e = JournalEntry(
        date=datetime.now().date(), description="test", source="test",
        postings=[
            Posting(journal=e, date=e.date, account=Account("credit", account_type=AccountType.EQUITIES),
                    amount=Amount(123), direction=Direction.DEC),
            Posting(journal=e, date=e.date, account=account, amount=Amount(123),
                    direction=Direction.INC)
        ]
    )

    e.validate()



# Generated at 2022-06-26 00:34:07.060931
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from . import ReadAccounts
    from .accounting_types import Currency, Money

    journal_entry: JournalEntry[None] = JournalEntry(
        date=datetime.date(2017, 4, 6),
        description="First journal entry.",
        source=None,
    )
    journal_entry.post(datetime.date(2017, 4, 6), Account(1, "1", AccountType.ASSETS, "Cash"), Money(1000, Currency.USD))
    journal_entry.post(datetime.date(2017, 4, 6), Account(2, "2", AccountType.EQUITIES, "Share Capital"), Money(-1000, Currency.USD))
    journal_entry.validate()


# Generated at 2022-06-26 00:34:07.486186
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-26 00:34:14.402819
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ie = JournalEntry[str]
    ie = JournalEntry(date=datetime.date(2020, 8, 23), description="Cash 90 days credit purchase",source="01-A")
    ie.post(date=datetime.date(2020, 8, 23),account=Account(name="Dr.Supplier A/c",fullname="Accounts Payables", type=AccountType.LIABILITIES),quantity=Quantity(1500))
    ie.post(date=datetime.date(2020, 8, 23),account=Account(name="Cr.Cash A/c",fullname="Cash", type=AccountType.ASSETS),quantity=Quantity(1500))
    ie.validate()

# Generated at 2022-06-26 00:34:22.428684
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    # Arrange
    class object:
        def __repr__(self):
            return "object"

    def old_function(period: DateRange) -> Iterable[JournalEntry[object]]:
        return []

    # Act
    abstract_function = ReadJournalEntries(object)
    old_function_return_value = old_function(period=DateRange(datetime.date(2020, 6, 20), datetime.date(2020, 6, 25)))

    # Assert
    assert len(old_function_return_value) == 0
    assert abstract_function(period=DateRange(datetime.date(2020, 6, 20), datetime.date(2020, 6, 25))) == []

# Generated at 2022-06-26 00:34:44.353097
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    from .commons import MockJournalEntrySource

    mock = MockJournalEntrySource()

    rangeObj = DateRange(datetime.date(2019,1,1), datetime.date(2019,12,31))
    entries = mock.read_journal_entries(rangeObj)
    assert entries

# Generated at 2022-06-26 00:34:52.183590
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class TestEntry:
        def __init__(self, n):
            self.n = n

    test_je = JournalEntry[TestEntry](datetime.date.today(), "Test Entry", TestEntry(5))
    test_account = Account("Test Account", AccountType.ASSETS)
    test_je.post(datetime.datetime.today(), test_account, 10)
    assert test_je.postings[0].amount == 10
    assert test_je.postings[0].account == test_account
    assert test_je.postings[0].direction == Direction.INC

# Generated at 2022-06-26 00:34:52.690675
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:35:04.283905
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..commons.others import makeguid
    from ..commons.numbers import Quantity
    from ..domain.accounts import Account, AccountType

    journal = JournalEntry(datetime.date.today(), "Test Journal Entry", makeguid())

    journal.post(datetime.date.today(), Account("SIN", AccountType.EQUITIES, "Singapore"), Quantity(100.00))
    journal.post(datetime.date.today(), Account("A", AccountType.ASSETS, "Cash"), Quantity(-100.00))

    assert len(journal.postings) == 2

    assert [p.account.name for p in journal.postings] == ["Singapore", "Cash"]
    assert [p.amount for p in journal.postings] == [Quantity(100.00), Quantity(100.00)]
   

# Generated at 2022-06-26 00:35:17.900669
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts.accounts_repo import AccountsRepo
    from .accounts.accounts_repo_impl import accounts_repo

    ## Create an accounts repository:
    accounts: AccountsRepo = accounts_repo([
        Account("101", AccountType.EXPENSES, "Meals", "Meals Expenses"),
        Account("201", AccountType.ASSETS, "Cash-at-hand", "Cash-at-hand"),
    ])

    ## Create a journal entry.

# Generated at 2022-06-26 00:35:26.008970
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date, timedelta
    from unittest.mock import Mock

    mock = Mock(ReadJournalEntries[None])
    mock.__call__.return_value = [JournalEntry(date(2020, 10, 20), "", None)]

    assert mock(DateRange(date(2020, 10, 20), date(2020, 10, 20))) == [JournalEntry(date(2020, 10, 20), "", None)]
    mock.__call__.assert_called_once_with(DateRange(date(2020, 10, 20), date(2020, 10, 20)))


# Generated at 2022-06-26 00:35:38.021522
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(datetime.date(2018, 1, 1), "Description", "Source")
    j.post(datetime.date(2018, 1, 1), Account("Debit", AccountType.ASSETS), +100)
    j.post(datetime.date(2018, 1, 1), Account("Credit", AccountType.EXPENSES), -100)

    j.validate()

    a = JournalEntry(datetime.date(2018, 1, 1), "Description", "Source")
    a.post(datetime.date(2018, 1, 1), Account("Debit", AccountType.ASSETS), +100)
    a.post(datetime.date(2018, 1, 1), Account("Credit", AccountType.EXPENSES), -50)


# Generated at 2022-06-26 00:35:40.609992
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journalentry = JournalEntry(date=datetime.date.today(), description= "Test Journal", source="Test account")
    assert (journalentry.validate)


# Generated at 2022-06-26 00:35:49.661501
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..libraries import ledger
    # Case 1:
    source = ledger.Entry("2017/12/01", "Purchase of furniture", "ASSETS:Cash", "800")
    je = JournalEntry(source.date, source.narration, source)
    je.post(source.date, "ASSETS:Cash", -800)
    je.post(source.date, "EXPENSES:Furniture", 800)
    assert len(je.postings) == 2
    total_debit = isum(i.amount for i in je.debits)
    total_credit = isum(i.amount for i in je.credits)
    assert total_debit == total_credit
    # Case 2:
    je.post(source.date, "ASSETS:Cash", 0)
    assert len(je.postings) == 2

# Generated at 2022-06-26 00:35:56.843611
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import BalanceSheetAccount, IncomeStatementAccount
    from .busobj import BusinessObject
    import datetime
    j = JournalEntry(datetime.date(2008, 12, 1), "", BusinessObject())
    j1 = j.post(datetime.date(2008, 12, 1), BalanceSheetAccount(str(1), ""), 1000)
    j2 = j1.post(datetime.date(2008, 12, 1), IncomeStatementAccount(str(1), ""), -1000)
    assert j2.postings[0].account.type == j2.postings[1].account.type.opposite()

# Generated at 2022-06-26 00:36:50.309034
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Test relation between debits and credits
    test_case_0()


# Generated at 2022-06-26 00:36:56.679954
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'L\x0cL:zAGi'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = None
    account_0 = Account.from_str(str_0)
    quantity_0 = Quantity(str_0)
    journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:03.198738
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0: str
    journal_entry_0: JournalEntry[_T]
    date_0: datetime.date
    def _ReadJournalEntries__call__(_self, date_range_0: DateRange) -> Iterable[JournalEntry[_T]]:
        return _self
    date_0 = None
    str_0 = 'L\x0cL:zAGi'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    _ReadJournalEntries__call__(journal_entry_0, journal_entry_0)


# Generated at 2022-06-26 00:37:06.179325
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_range_0 = DateRange()
    iterable_0 = [None]
    read_journal_entries = ReadJournalEntries()

    ret = read_journal_entries(date_range_0)

# Generated at 2022-06-26 00:37:08.672946
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2015, 4, 2)
    account_0 = Account(date_0, str_0)
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, 0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:13.586742
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'L\x0cL:zAGi'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = None
    str_1 = 'L\x0cL:zAGi'
    account_1 = Account(str_1, None)
    quantity_0 = None
    journal_entry_0.post(date_1, account_1, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:26.368741
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'J\x03\x1c\x1cE\x1c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool

# Generated at 2022-06-26 00:37:31.631100
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = '}*Tn-\x0b&\x1f'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = None
    guid_0 = makeguid()
    account_0 = Account(guid_0, str_0, str_0)
    int_0 = 1
    journal_entry_0.post(date_1, account_0, int_0)


# Generated at 2022-06-26 00:37:44.564118
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # create a journal entry
    date_0 = datetime.date(2020,1,1)
    str_0 = 'This is a Journal entry'
    str_1 = 'This is another Journal entry'
    str_2 = 'This is yet another Journal entry'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    account_0 = Account('Account-1', AccountType.ASSETS)
    amount_0 = Amount(10)
    date_1 = datetime.date(2020,1,1)
    date_2 = datetime.date(2020,1,2)
    date_3 = datetime.date(2020,1,3)
    date_4 = datetime.date(2020,1,4)
    date_5 = datetime.date(2020,1,5)

# Generated at 2022-06-26 00:37:48.233040
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_range_0 = None
    str_0 = 'zAGiL\x0cL:'
    journal_entry_0 = JournalEntry(date_range_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:23.481672
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(1,1,1)
    account = Account('account', AccountType.ASSETS)
    quantity = 1
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date, account, quantity)


# Generated at 2022-06-26 00:38:32.410492
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from ..accounts import Account

    accounts = {
        "Sales": Account("Sales", AccountType.REVENUES),
        "Accounts Receivable": Account("Accounts Receivable", AccountType.ASSETS),
        "Inventory": Account("Inventory", AccountType.ASSETS),
        "Cost of Goods Sold": Account("Cost of Goods Sold", AccountType.EXPENSES),
        "Accounts Payable": Account("Accounts Payable", AccountType.LIABILITIES),
    }


# Generated at 2022-06-26 00:38:39.118542
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    str_1 = 'a'
    datetime_date_0 = datetime.date(1, 1, 1)
    account_0 = Account(str_0, AccountType.ASSETS)
    quantity_0 = Quantity(1)
    journal_entry_0 = JournalEntry(datetime_date_0, str_1, str_0)
    journal_entry_0.post(datetime_date_0, account_0, quantity_0)
    journal_entry_0.validate()
    journal_entry_0.post(datetime_date_0, account_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:42.939812
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_range_0: DateRange = datetime.date(2005, 2, 14)
    read_journal_entries_0: ReadJournalEntries[_T] = ReadJournalEntries(date_range_0)
    test_0: int = 0
    assert isinstance(read_journal_entries_0(test_0), ReadJournalEntries)



# Generated at 2022-06-26 00:38:49.396812
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class _Impl0(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    _impl0 = _Impl0()
    _impl0.__call__(DateRange(datetime.date.today(), datetime.date.max))
    try:
        _impl0.__call__(DateRange(datetime.date.min, datetime.date.today()))
    except AssertionError:
        pass

# Generated at 2022-06-26 00:38:54.079442
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account(str_0, AccountType.EXPENSES)
    date_0 = datetime.date(1907, 12, 26)
    description_0 = ''
    source_0 = ''
    str_0 = ''
    journal_entry_0 = JournalEntry(date_0, description_0, source_0)
    journal_entry_0.post(date_0, account_0, 0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:57.950084
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # parameters
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, str_0)
    int_0 = 0
    # Posting test
    res = journal_entry_0.post(str_0, account_0, int_0)
    assert res is journal_entry_0
    # Validate test
    journal_entry_0.validate()

# Generated at 2022-06-26 00:39:01.687935
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Create a local function to test:
    class ReadJournalEntries_Test:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return []
    read_journal_entries_test = ReadJournalEntries_Test()
    ReadJournalEntries_Test.__call__ = read_journal_entries_test.__call__
    # Call the local function:
    read_journal_entries_test.__call__(0)

# Generated at 2022-06-26 00:39:04.975632
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str(), str(), str(), list())
    journal_entry_0.post(datetime.datetime(2020, 5, 10), Account('', AccountType.EXPENSES, list()), Quantity(10.0))
    journal_entry_0.post(datetime.datetime(2020, 5, 10), Account('', AccountType.REVENUES, list()), Quantity(-10.0))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:39:06.553904
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries(str, str)
    assert read_journal_entries_0.__call__(DateRange()) is None

# Generated at 2022-06-26 00:40:47.752934
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(2020, 8, 8), "", Quantity(10))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:40:49.020324
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ''
    crud = ReadJournalEntries()
    crud.__call__(str_0)

# Generated at 2022-06-26 00:40:54.229892
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_in_past = datetime.date.today() + datetime.timedelta(days=-1000)
    journal_entry_1 = JournalEntry(date_in_past, 'test journal entry', 'source')
    journal_entry_1.post(date_in_past, Account('account1', 'account1',AccountType.ASSETS), 123)
    journal_entry_1.post(date_in_past, Account('account2', 'account2', AccountType.REVENUES), 123)
    journal_entry_1.post(date_in_past, Account('account3', 'account3', AccountType.REVENUES), -500)
    journal_entry_1.post(date_in_past, Account('account4', 'account4', AccountType.REVENUES), -500)