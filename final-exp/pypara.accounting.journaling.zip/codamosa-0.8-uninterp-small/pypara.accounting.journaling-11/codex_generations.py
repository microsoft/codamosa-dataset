

# Generated at 2022-06-26 00:31:05.020972
# Unit test for method validate of class JournalEntry

# Generated at 2022-06-26 00:31:08.121900
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Prepare input data, and call the method under test
    journal_0 = JournalEntry(source=None, date=None)
    journal_0.validate()



# Generated at 2022-06-26 00:31:11.102560
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    instance = ReadJournalEntries()
    period = DateRange()

    # Call __call__ with valid arguments
    assert instance.__call__(period) is not None


import datetime as module_0


# Generated at 2022-06-26 00:31:20.972325
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    posting_0 = Posting()
    posting_1 = Posting()
    test_case_0()
    journal_entry_0 = JournalEntry()
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())
    journal_entry_0.post(date_0, Account(), Amount())


# Generated at 2022-06-26 00:31:28.639282
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date.today()
    date_1 = datetime.date.today()
    date_2 = datetime.date.today()
    date_3 = datetime.date.today()
    date_4 = datetime.date.today()
    _guid_0 = makeguid()
    _guid_1 = makeguid()
    _guid_2 = makeguid()
    _guid_3 = makeguid()
    _guid_4 = makeguid()
    _guid_5 = makeguid()
    _guid_6 = makeguid()
    _guid_7 = makeguid()
    _guid_8 = makeguid()
    _guid_9 = makeguid()

# Generated at 2022-06-26 00:31:30.671142
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    account_0 = Account()
    quantity_0 = int()


# Generated at 2022-06-26 00:31:32.413739
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = module_0.date(2018, 10, 15)
    jentry_0 = JournalEntry()

# Generated at 2022-06-26 00:31:40.728161
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime as module_0

    class entry_0:
        date = module_0.date()
    date_0 = module_0.date()

    def func_0(self):
        return [entry_0]

    def func_1():
        class entry_0:
            date = module_0.date()
        date_0 = module_0.date()

        def func_0(self):
            return [entry_0]

        module_0.date = __new_0__
    def func_1():
        return [entry_0]
    def func_2(self):
        return [entry_0]


# Generated at 2022-06-26 00:31:45.721805
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange()
    journal_0 = JournalEntry()
    def method_test_ReadJournalEntries___call__(self, period_0) -> Iterable[JournalEntry]:
        return journal_0
    ReadJournalEntries___call__ = method_test_ReadJournalEntries___call__.__get__(ReadJournalEntries)
    ReadJournalEntries___call__(period_0)


# Generated at 2022-06-26 00:31:47.557307
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # TEST CASE 0:
    period_0 = DateRange(date_0)
    assert True

# Generated at 2022-06-26 00:31:54.695580
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

import dataclasses as module_0


# Generated at 2022-06-26 00:31:56.544459
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # TODO: Auto-generated code
    assert False, "Auto-generated test"

import datetime as module_1


# Generated at 2022-06-26 00:32:00.776264
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange(start=datetime.date(), stop=datetime.date())
    def anonymous_0():
        pass
    anonymous_0()
    def anonymous_0():
        pass
    anonymous_0()


# Generated at 2022-06-26 00:32:04.746790
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # Test 0
    source_0 = ""
    journal_0 = JournalEntry(date_0, source_0)
    account_0 = Account(source_0, source_0)
    quantity_0 = Quantity()
    journal_0.post(date_0, account_0, quantity_0)

# Generated at 2022-06-26 00:32:08.039367
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    for i in range(100):
        date_0 = module_0.date()
        period_0 = DateRange()
        instance = ReadJournalEntries[int]()
        instance.__call__(period=period_0)

    test_case_0()


# Generated at 2022-06-26 00:32:16.762786
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(date=test_case_0(), description="test", source=test_case_0())
    account_instance = test_Account()

    # Posting with positive value
    journal.post(test_case_0(), account_instance, 1)
    assert len(journal.postings) == 1
    assert journal.postings[0].amount == Amount(1)
    assert journal.postings[0].account == account_instance
    assert journal.postings[0].journal == journal

    # Posting with negative value
    journal.post(test_case_0(), account_instance, -1)
    assert len(journal.postings) == 2
    assert journal.postings[1].amount == Amount(1)
    assert journal.postings[1].account == account_instance
    assert journal.postings[1].journal

# Generated at 2022-06-26 00:32:26.229190
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import random
    import datetime as module_0

    # param: self: JournalEntry[_T]:
    # param: date: datetime.date:
    # param: account: Account:
    # param: quantity: Quantity:
    self_0 = JournalEntry()
    date_0 = module_0.date()
    account_0 = Account()
    quantity_0 = random.randint(-10, 10)

    # Invoke method post
    result_0 = self_0.post(date_0, account_0, quantity_0)

    # Check result
    assert isinstance(result_0, JournalEntry)

# Generated at 2022-06-26 00:32:30.166805
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    f = JournalEntry()
    date_0 = datetime.date()
    account_0 = Account()
    quantity_0 = Quantity()
    f.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:32:37.679252
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = module_0.date()
    account_0 = Account(name='', type=AccountType.ASSETS)
    quantity = Quantity(1)
    journalentry = JournalEntry()
    journalentry_0 = journalentry.post(date_0, account_0, quantity)
    period_0 = DateRange(start_date=date_0, end_date=date_0)
    a_0 = ReadJournalEntries()
    journalentries = a_0(period_0)
    assert journalentries == [journalentry_0]

# Generated at 2022-06-26 00:32:47.804021
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Unit test for invocation of method validate of class JournalEntry without parameter 'self'

    from . import accounts as module_0
    from .accounts import AccountType as module_1
    from . import journal as module_2

    date_0 = module_0.Account("", module_1.EXPENSES, "", "A")

    quantity_0 = module_2.Account("A", module_1.ASSETS, "", "")
    quantity_1 = module_2.Account("A", module_1.ASSETS, "", "")

    journal_0 = module_2.JournalEntry("", "", "")
    journal_0.post("", date_0, quantity_0)
    journal_0.post("", date_0, quantity_1)

    journal_0.validate()

# Generated at 2022-06-26 00:32:58.405194
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # Test variables
    amount_1 = Amount(10)
    amount_2 = Amount(10)
    str_0 = ''
    account_0 = Account(str_0, str_0, str_0)
    date_1 = datetime.date(2020, 10, 18)
    date_2 = datetime.date(2019, 5, 31)
    journal_entry_0 = JournalEntry(date_1, str_0, str_0)
    journal_entry_0.post(date_2, account_0, amount_1)
    journal_entry_0.post(date_1, account_0, amount_2)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:33:00.806077
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:12.855356
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_1 = 'description'
    str_2 = 'source'
    journal_entry_1 = JournalEntry(str_1, str_2, str_1)
    date_0 = datetime.date(2019, 9, 2)
    account_0 = Account(str_1, str_1, None, str_1, str_1, str_1)
    journal_entry_1.post(date_0, account_0, Quantity(20))
    assert journal_entry_1.postings[0].direction is Direction.INC


# Generated at 2022-06-26 00:33:20.650374
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date.today()
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.NONE)
    journal_entry_0.post(date_0, account_0, 0)
    journal_entry_0.post(date_0, account_0, 1)
    journal_entry_0.post(date_0, account_0, -1)

# Generated at 2022-06-26 00:33:21.567503
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True


# Generated at 2022-06-26 00:33:27.230241
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    description = 'description'
    entry = JournalEntry(datetime.date.today(), description, 'source')
    account = Account(description, AccountType.ASSETS)
    entry.post(datetime.date.today(), account, 100.0)

    assert account.type in _debit_mapping[Direction.INC]
    assert entry.postings[0].direction == Direction.INC
    assert entry.postings[0].is_debit == True

# Generated at 2022-06-26 00:33:29.884377
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    expected = TypeError()
    actual = None

    try:
        test_case_0()
    except Exception:
        actual = TypeError()

    assert actual == expected

# Generated at 2022-06-26 00:33:37.001984
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source_0 = ''
    description_0 = ''
    date_0 = datetime.date(1999, 1, 1)
    journal_entry_0 = JournalEntry(date_0, description_0, source_0)
    account_0 = Account('Assets:Cash', AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, Quantity(1))
    journal_entry_0.validate()
    journal_entry_0.post(date_0, Account('Equities:Opening Balances', AccountType.EQUITIES), Quantity(-1))
    journal_entry_0.validate()



# Generated at 2022-06-26 00:33:46.835402
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date.today(), Account(str_0, AccountType.ASSETS), 3)
    journal_entry_0.post(datetime.date.today(), Account(str_0, AccountType.ASSETS), 1)
    journal_entry_0.post(datetime.date.today(), Account(str_0, AccountType.ASSETS), 1)
    str_1 = 'O'
    account_0 = Account(str_1, AccountType.ASSETS)
    journal_entry_0.post(datetime.date(2020, 2, 6), account_0, 2)

# Generated at 2022-06-26 00:33:52.664553
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('', str_0, str_0)
    account_0 = Account(str_0, AccountType.ASSETS)
    date_0 = datetime.date(1988, 12, 12)
    int_0 = 4
    with pytest.raises(Exception):
        journal_entry_0.post(date_0, account_0, int_0)


# Generated at 2022-06-26 00:34:05.338384
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account('acct_name', AccountType.ASSETS)
    account_1 = Account('acct_name', AccountType.ASSETS)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    amount_0 = Amount('1.0')
    # Call the post method of JournalEntry
    journal_entry_0.post(str_0, account_1, int_0)

# Generated at 2022-06-26 00:34:06.253257
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry(str, str, str)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:34:07.823584
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
	# All this test case does is to make sure that validate does not raise an exception
	journal_entry_0 = JournalEntry('', '', '')
	journal_entry_0.validate()

# Generated at 2022-06-26 00:34:14.192950
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = ''
    journal_entry_0.post(str_0, str_1, 2)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_1, 0)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_1, -2)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:18.417706
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..accounts.accounts_read import get_by_code

    journal_entry_1 = JournalEntry(date.today(), "test_description", "test_source")
    journal_entry_1.post(date.today(), get_by_code("1001"), 20.0)
    journal_entry_1.validate()

# Generated at 2022-06-26 00:34:28.613664
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # A JournalEntry object (journal_entry_0) with specific value of guid.
    # It is necessary to use a fixed guid to allow other tests to run.
    journal_entry_0 = JournalEntry('', '', '')
    journal_entry_0.guid = '22feb44a-30c0-44e7-b8fb-b7e2c2d04314'
    
    # A list of Account objects (accounts_0) with specific value of guid.
    # It is necessary to use a fixed guid to allow other tests to run.
    accounts_0 = [Account('', '') for _ in range(3)]
    accounts_0[0].guid = '744c9f9c-d909-440c-8b11-d5c5ad5d5b6d'
    accounts_0

# Generated at 2022-06-26 00:34:30.760740
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:32.490918
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry('', '', '')
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:38.768036
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    guid_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.date(1834, 6, 10)
    account_0 = Account(str_0, str_0)
    Quantity_0 = Quantity
    Quantity_1 = Quantity
    journal_entry_0.post(date_0, account_0, Quantity_0)
    journal_entry_0.post(date_0, account_0, Quantity_1)

# Generated at 2022-06-26 00:34:43.615846
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    date_0 = datetime.date(1960, 1, 1)
    account_0 = Account(AccountType.ASSETS)
    quantity_0 = Quantity(0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:00.336531
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:35:07.635508
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'a'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    
    account_0 = Account(str_0, AccountType.EQUITIES)
    date_0 = datetime.date(2020, 1, 1)
    quantity_0 = Quantity(100)

    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:09.876634
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(None, None, None)
    journal_entry_0.post(None, None, None)

# Generated at 2022-06-26 00:35:17.677543
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account('', None, None, '', False, False, '')
    journal_entry = JournalEntry('', '', '')
    amount = Amount(0)
    result = journal_entry.post(datetime.date.today(), account, amount)
    assert result == journal_entry


# Generated at 2022-06-26 00:35:18.218459
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:35:24.625688
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str(), str(), str())
    journal_entry_1 = JournalEntry(str(), str(), str())
    journal_entry_2 = JournalEntry(str(), str(), str())
    str_0 = ''
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()



# Generated at 2022-06-26 00:35:32.976327
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_1 = JournalEntry("test_date", "test_description", "test_source")
    journal_entry_post_1 = journal_entry_1.post("test_date", Account("test_acc_name", AccountType.ASSETS), 1)
    journal_entry_post_1.validate()
    assert journal_entry_post_1.postings[0].amount.is_equal(1)
    assert journal_entry_post_1.postings[0].account.type == AccountType.ASSETS
    assert journal_entry_post_1.postings[0].is_debit

# Generated at 2022-06-26 00:35:45.623153
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    amount_0 = Amount(0)
    account_0 = Account(AccountType.ASSETS, str_0)
    direction_0 = Direction.DEC
    direction_1 = Direction.INC
    account_1 = Account(AccountType.ASSETS, str_0)
    direction_2 = Direction.DEC
    direction_3 = Direction.INC
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(1, 1, 1), account_0, 0)
    journal_entry_0.post(datetime.date(1, 1, 1), account_0, 0)
    journal_entry_0.post(datetime.date(1, 1, 1), account_0, 0)

# Generated at 2022-06-26 00:35:53.145843
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import datetime


    def _(period):
        str_0 = '0'
        journal_entry_0 = JournalEntry(str_0, str_0, str_0)
        return list([journal_entry_0])

    protocol___call__ = _
    period_0 = DateRange(datetime(2000, 10, 10), datetime(2022, 10, 10))
    result___call__ = protocol___call__(period_0)

# Generated at 2022-06-26 00:35:55.467564
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange):
        return list()

    read_journal_entries.__call__(None)


# Generated at 2022-06-26 00:36:32.182501
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    post = journal_entry_0.post
    journal_entry_0.post(str_0, str_0, 0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:41.400436
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    str_1 = ''
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.validate()
    str_2 = ''
    journal_entry_2 = JournalEntry(str_2, str_2, str_2)
    journal_entry_2.validate()
    str_3 = ''
    journal_entry_3 = JournalEntry(str_3, str_3, str_3)
    journal_entry_3.validate()
    str_4 = ''
    journal_entry_4 = JournalEntry(str_4, str_4, str_4)
    journal_entry_

# Generated at 2022-06-26 00:36:42.200976
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:36:43.111310
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:36:45.874654
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, str_0)
    journal_entry_0.post(str_0, account_0, 1)

# Generated at 2022-06-26 00:36:55.395062
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_1 = JournalEntry('', '', '')
    journal_entry_2 = JournalEntry('', '', '')
    journal_entry_1.post('', '', '')
    journal_entry_2.post('', '', '')
    str_0 = ''
    datetime_1 = datetime.date.today()
    int_0 = 0
    str_1 = str(datetime_1)
    str_2 = str(int_0)
    # print('test_ReadJournalEntries___call__()')
    # print('str_0 = ', str_0)
    # print('datetime_1 = ', datetime_1)
    # print('int_0 = ', int_0)
    # print('str_1 = ', str_1)
    # print('str_2 = ', str

# Generated at 2022-06-26 00:37:00.127128
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    quantity_0 = Quantity(0)
    date_0 = datetime.date(1900, 1, 1)
    account_0 = Account(str_0, AccountType.ASSETS, str_0)
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:37:08.405305
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    today = datetime.date.today()
    two_days_before = today - datetime.timedelta(days=2)
    cash = Account("Cash", "Cash in hand", AccountType.ASSETS)
    bank = Account("Bank", "Bank account", AccountType.ASSETS)
    equipment = Account("Equip", "Equipment", AccountType.ASSETS)
    revenue = Account("Revenue", "Revenue", AccountType.REVENUES)

    journal_entry = JournalEntry(today, "Test journal entry", "")
    journal_entry.post(today, cash, 5000)  # Debit entry
    journal_entry.post(today, equipment, -2000)  # Credit entry
    journal_entry.post(today, equipment, -2000)  # Credit entry
    journal_entry.post(today, revenue, -1000)  #

# Generated at 2022-06-26 00:37:10.953293
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Method __call__ of class ReadJournalEntries
    """
    def test_ReadJournalEntries___call__0():
        """
        Tests the method __call__ of class ReadJournalEntries


        """
        pass



# Generated at 2022-06-26 00:37:13.516353
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def reader(period: DateRange) -> Iterable[JournalEntry[_T]]:
        journal_entry_0 = JournalEntry(str_0, str_0, str_0)
        return [journal_entry_0]



# Generated at 2022-06-26 00:38:27.284104
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, str_0)


# Generated at 2022-06-26 00:38:32.682650
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    datetime_date_0 = datetime.date(1,1,1)
    str_0 = ''
    account_0 = Account(str_0, AccountType.NONE, str_0)
    int_0 = 0
    journal_entry_0.post(datetime_date_0, account_0, int_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:38:33.823243
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert ReadJournalEntries.__call__(datetime.date.today()) is None

# Generated at 2022-06-26 00:38:34.363069
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:34.896023
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:38.786416
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date = datetime.date(1, 1, 1)
    account = Account('', '', AccountType.ASSETS)
    quantity = 1
    journal_entry = journal_entry_0.post(date, account, quantity)
    journal_entry.validate()

# Generated at 2022-06-26 00:38:47.309269
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create instance of JournalEntry
    j = JournalEntry('2019-01-01', 'j0', 's0')
    j = j.post('2019-01-01', Account('a1', AccountType.EQUITIES), 1)
    j = j.post('2019-01-01', Account('a1', AccountType.EQUITIES), -1)
    j = j.post('2019-01-01', Account('a2', AccountType.EXPENSES), -1)
    j = j.post('2019-01-01', Account('a2', AccountType.LIABILITIES), 1)
    j = j.post('2019-01-01', Account('a3', AccountType.LIABILITIES), -1)
    j = j.post('2019-01-01', Account('a3', AccountType.EXPENSES), 1)

# Generated at 2022-06-26 00:38:49.649561
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass


# Generated at 2022-06-26 00:38:53.801359
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    Iterable_JournalEntry_object = Iterable[JournalEntry]
    Iterable_JournalEntry_object_mock = Mock()
    DateRange_object_mock = Mock()
    ReadJournalEntries_object = ReadJournalEntries()
    return_value = ReadJournalEntries_object.__call__(DateRange_object_mock)
    assert return_value == Iterable_JournalEntry_object_mock

# Generated at 2022-06-26 00:38:56.798668
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    print("Starting test_JournalEntry_validate...\n")
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)

    # Exercise
    journal_entry_0.validate()

    # Teardown
    print("\nFinished test_JournalEntry_validate.")