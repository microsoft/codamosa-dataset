

# Generated at 2022-06-26 00:31:01.582369
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date = datetime.date(2015, 1, 1)
    account = Account(name="Cash on Hand", type=AccountType.ASSETS)
    quantity = Quantity(100)
    direction = Direction.INC
    amount = Amount(100)
    jentry = [JournalEntry(date, "Unittest", "Unittest", [Posting(jentry, date, account, direction, amount)])]
    jentry.validate()


# Generated at 2022-06-26 00:31:07.758493
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.date(2020,1,1), 'Monthly Rent', 'Rent')
    je.post(datetime.date(2020,1,1), Account(AccountType.LIABILITIES, 'Rent Liabilities'), 100)
    assert(je.postings[0].account.type == AccountType.LIABILITIES)
    assert(je.postings[0].amount == 100)
    assert(je.postings[0].direction == Direction.INC)



# Generated at 2022-06-26 00:31:14.696415
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_in = (
        Iterable[JournalEntry[test_case_0]],
        DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)),
    )
    expected_out = None
    actual_out = ReadJournalEntries.__call__(Iterable[JournalEntry[test_case_0]], DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))
    assert actual_out == expected_out, "{} != {}".format(actual_out, expected_out)


# Generated at 2022-06-26 00:31:16.348650
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    posting = JournalEntry
    posting.post('05/10/20', 'account A', 4)


# Generated at 2022-06-26 00:31:26.073495
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from . import accounts
    from .commons.zeitgeist import DateRange
    from .fixtures import find_journal_entries
    period = DateRange.from_date(date(2017, 1, 1))
    entries = find_journal_entries(period)
    entry_0 = entries[0]
    account_0 = accounts.other_income
    quantity_0 = Amount(1)
    entry_0.post(date(2017, 1, 1), account_0, quantity)
    entry_1 = JournalEntry(entries[0].date, entries[0].description, entries[0].source)
    entries[0].postings
    entries[0].increments
    entries[0].decrements
    entries[0].debits
    entries[0].credits
    entries[0].valid

# Generated at 2022-06-26 00:31:26.709905
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-26 00:31:36.412754
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType, GLAccount
    from .currencies import Currency
    from ..commons.numbers import Amount, Quantity
    from .business import Business
    from .persistence import InMemoryDB

    # create two businesses
    business_0 = Business.create(InMemoryDB())
    business_1 = Business.create(InMemoryDB())

    # add somes accounts to each business
    currency_0 = Currency.create(InMemoryDB())
    currency_1 = Currency.create(InMemoryDB())

    business_0.add_currency(currency_0, "USD")
    business_0.add_currency(currency_1, "INR")

    account_0 = GLAccount.create(business_0, AccountType.LIABILITY, "Vendor_0")

# Generated at 2022-06-26 00:31:46.558569
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[int](datetime.date(2020, 6, 1), "entry description", 23)
    je.post(datetime.date(2020, 6, 1), Account("revenue account", AccountType.REVENUES), -3)
    je.post(datetime.date(2020, 6, 1), Account("expense account", AccountType.EXPENSES), 4)

    print("postings", je.postings)

    assert je.increments == [Posting(je, datetime.date(2020, 6, 1), Account("expense account", AccountType.EXPENSES), Direction.INC, Amount(4))]
    assert je.decrements == [Posting(je, datetime.date(2020, 6, 1), Account("revenue account", AccountType.REVENUES), Direction.DEC, Amount(3))]
   

# Generated at 2022-06-26 00:31:55.475043
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType
    from .accounts import PnLPursuit
    from .accounts import TestAccounts
    from .businessobjects import TestBusinessObjects
    from .journalentries import JournalEntry
    from .journalentries import Posting
    from datetime import date
    from datetime import timedelta
    today = date.today()
    TestAccounts.ensure_accounts_created()
    sales_acct = TestAccounts.sales_acct
    inventory_acct = TestAccounts.inventory_acct
    income_acct = TestAccounts.income_acct
    journal_entry_0 = JournalEntry(today, 'dummy', None)
    journal_entry_0.post(today, sales_acct, Amount(1000))

# Generated at 2022-06-26 00:32:01.881640
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j1 = JournalEntry[int]("2018-10-15", "Test journal entry")
    j1.posting(datetime.date(2018, 10, 15), Account("100", AccountType.ASSETS, "Cash"), 1000)
    j1.posting(datetime.date(2018, 10, 15), Account("200", AccountType.EQUITIES, "Equity"), -1000)
    j1.validate()


# Generated at 2022-06-26 00:32:15.727714
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account, AccountType, Book

    book = Book(Account(AccountType.ASSETS, "1201", "Cash"),
                Account(AccountType.ASSETS, "1202", "Accounts Receivable"),
                Account(AccountType.LIABILITIES, "2001", "Accounts Payable"),
                Account(AccountType.EQUITIES, "3001", "Capital"),
                Account(AccountType.EQUITIES, "3002", "Retained Earnings"),
                Account(AccountType.REVENUES, "4001", "Sales"),
                Account(AccountType.EXPENSES, "5001", "Purchases"),
                Account(AccountType.EXPENSES, "5002", "Administrative Expenses"))
    

# Generated at 2022-06-26 00:32:18.082335
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Sanity check:
    assert issubclass(Iterable, ReadJournalEntries)

# Generated at 2022-06-26 00:32:28.272224
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass
    # from .accounts import AccountType, Account
    # from .books import Book
    # from .categories import Category, CategoryType
    # from .transactions import Transaction
    #
    # ## Define example book and categories:
    # book = Book("Test")
    # income = Category(book, "Income", CategoryType.INCOME, None)
    # cash = Category(book, "Cash", CategoryType.ASSETS, None)
    # bank = Category(book, "Bank", CategoryType.ASSETS, None)
    #
    # ## Create an Income transaction:
    # tran = Transaction(
    #     book,
    #     "Income",
    #     datetime.date(2020, 1, 10),
    #     [
    #         (income, +1200),
    #         (cash,

# Generated at 2022-06-26 00:32:40.281931
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import current_date
    from .accounts import AssetsAccount, EquityAccount, ExpenseAccount, LiabilitiesAccount, RevenueAccount
    def _test(journal):
        journal.validate()
        return journal

    # Setup:
    money = lambda quantity: Amount(quantity, currency='SGD')
    sales = EquityAccount('Sales')
    cash = AssetsAccount('Cash')
    fixed_expenses = ExpenseAccount('Fixed Expenses')
    liabilities = LiabilitiesAccount('Liabilities')
    interest_expense = ExpenseAccount('Interest Expense')
    revenues = RevenueAccount('Revenues')
    print_today = lambda: print(f"Today: {current_date()}")

    # Validate an equity journal entry

# Generated at 2022-06-26 00:32:44.162964
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries[int].__call__.__annotations__
    assert ReadJournalEntries[int].__call__.__annotations__['period'] == DateRange
    assert ReadJournalEntries[int].__call__.__annotations__['return'] == Iterable[JournalEntry[int]]

# Generated at 2022-06-26 00:32:53.677543
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests the __call__ method.
    """
    from dataclasses import dataclass

    # Define test data:
    from datetime import date
    from enum import Enum
    from typing import Optional
    from itertools import count

    class Account(Enum):
        ASSETS = 1
        REVENUES = 3
        EXPENSES = 4
        EQUITIES = 2
        LIABILITIES = 5

    def make_account(account: Account, currency: str = "USD") -> Account:
        class TestAccount(Account):
            pass
        setattr(TestAccount, "currency", currency)
        return TestAccount(account.value)

    @dataclass(frozen=True)
    class Vacation:
        id: int


# Generated at 2022-06-26 00:33:00.768679
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from datetime import date
    from unittest import mock

    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType

    # Mock an journal entry source:
    @dataclass(frozen=True)
    class JournalEntrySource:
        period: DateRange

    # Mock an account:
    account = mock.Mock(Account)
    account.type = AccountType.ASSETS
    account.name = "Cash"

    # Mock a journal entry:
    journal = mock.Mock(JournalEntry[JournalEntrySource])
    journal.date = date(2019, 6, 1)

# Generated at 2022-06-26 00:33:15.760219
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Assets
    
    #: Creates a dummy method which returns a set of journal entries for a given date range.
    def get_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        entry = JournalEntry(datetime.date(year=2019, month=1, day=1), "Payment", None)
        entry \
            .post(datetime.date(year=2019, month=1, day=1), Assets.BANK_ACCOUNTS.BANK_OF_AMERICA_CHECKING, +100) \
            .post(datetime.date(year=2019, month=1, day=1), Assets.BANK_ACCOUNTS.BANK_OF_AMERICA_CHECKING, -100)
        return [entry]
    
    #: Creates a reference

# Generated at 2022-06-26 00:33:25.179346
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import as_date_range

    @dataclass
    class _Item:
        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid)

    @dataclass
    class _JournalEntry(_JournalEntry):
        """
        Provides a journal entry model with an additional guid field
        """

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid)

    #: Period
    period = as_date_range(2019, 1, 2019, 2, inclusive=True)

    #: Journal entries

# Generated at 2022-06-26 00:33:31.265081
# Unit test for method validate of class JournalEntry

# Generated at 2022-06-26 00:33:47.961478
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    journal = JournalEntry(datetime.date(2019, 1, 2), "Some Description", [])
    journal.post(datetime.date(2019, 1, 2), "Assets:Current:Bank", 1000)
    journal.post(datetime.date(2019, 1, 2), "Expenses:Fuel", -1000)
    journal.post(datetime.date(2019, 1, 2), "Assets:Current:Cash", 1000)
    journal.post(datetime.date(2019, 1, 2), "Expenses:Petty Cash", -1000)


    print(journal)

# Generated at 2022-06-26 00:33:55.757182
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    j = JournalEntry[object]()
    j.post(datetime.date(2020,1,1),Account(1,AccountType.LIABILITIES,"Cash","Main cash box"),Amount(10))
    j.post(datetime.date(2020,1,1),Account(2,AccountType.ASSETS,"Bank","My bank"),Amount(10))
    j.validate()
    """
    try:
        j.validate()
        print("test passed")
    except AssertionError as e:
        print("test ignored because we are working on periode")
        print(e)
    """

# Generated at 2022-06-26 00:34:05.222965
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    # Create an instance of class JournalEntry
    j_e = JournalEntry(account=Account(code='code_0', name='Account 1', type=AccountType.ASSETS, group='Group 1'), date=datetime.date.today(), description='description_0')
    # Check that j_e is instance of class JournalEntry
    assert isinstance(j_e, JournalEntry)

    # Create an instance of class Account
    a_c = Account(code='code_1', name='Account 2', type=AccountType.ASSETS, group='Group 1')
    # Check that a_c is instance of class Account
    assert isinstance(a_c, Account)

    # Create an instance of class datetime.date
    d = datetime.date.today();
    # Check that d is instance of class dat

# Generated at 2022-06-26 00:34:11.205652
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Test case for method __call__ of class ReadJournalEntries
    """
    @dataclass
    class _T:
        """
        Test case class
        """
        number: int

    # Test case with empty date range
    date_range = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))
    journal_entries = [JournalEntry(_T(number=1)), JournalEntry(_T(number=2)), JournalEntry(_T(number=3))]
    def func(period: DateRange) -> Iterable[JournalEntry[_T]]:
        """
        Test ReadJournalEntries implementation
        """
        return [i for i in journal_entries if i.date in period]
    result = [i for i in func(date_range)]
    assert len(result)

# Generated at 2022-06-26 00:34:15.483596
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    sut = JournalEntry('#1', date(2020, 4, 4), '#1', None)
    sut.post(date(2020, 4, 4), Account('#1', '#1', None), Quantity(1))
    sut.post(date(2020, 4, 4), Account('#2', '#2', None), Quantity(1))
    sut.validate()

# Generated at 2022-06-26 00:34:25.691611
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from .ledgers import Ledger, InMemoryLedger
    from .transactions import Transaction
    from .transactors import Transactor

    ledger = InMemoryLedger()
    settle_ledger_accounts = Transactor.on(ledger)

    settle_ledger_accounts(Transaction(date="2018-10-23", credit=100, debit=100))
    settle_ledger_accounts(Transaction(date="2018-10-24", credit=100, debit=100))
    settle_ledger_accounts(Transaction(date="2018-10-25", credit=100, debit=100))

    assert len(_read_journal_entries(ledger, datetime.date(2018, 10, 20), datetime.date(2018, 10, 25))) == 3



# Generated at 2022-06-26 00:34:31.350728
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    je1 = JournalEntry[Guid](datetime.date.today(), "Entry 1", Guid(), [])
    je1.post(datetime.date.today(), Account(AccountType.EQUITIES, "Test Account 1", "Test Account 1"), 100)
    je1.post(datetime.date.today(), Account(AccountType.ASSETS, "Test Account 2", "Test Account 2"), 100)
    je1.validate()

test_JournalEntry_validate()

# Generated at 2022-06-26 00:34:31.858874
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert True



# Generated at 2022-06-26 00:34:40.665298
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..core.accounts import Account, AccountType
    from ..core.journals import JournalEntry, Direction, Posting
    from ..core.numbers import Amount, Quantity

    je = JournalEntry('2019-12-31', 'Description', 'Source')
    je.post('2019-12-31', Account('Account1', AccountType.ASSETS, 'Category'), Quantity(100))
    je.post('2019-12-31', Account('Account2', AccountType.EXPENSES, 'Category'), Quantity(-100))

    assert je.postings[0] == Posting(je, '2019-12-31', Account('Account1', AccountType.ASSETS, 'Category'), Direction.INC, Amount(100))

# Generated at 2022-06-26 00:34:44.855133
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    class DummyReadJournalEntries(ReadJournalEntries[_T]):
        pass

    dummy_read_journal_entries = DummyReadJournalEntries()

    period = DateRange.from_dates(datetime.date.today(), datetime.date.today())
    dummy_read_journal_entries(period)

# Generated at 2022-06-26 00:35:15.645718
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .tags import Tag

    account1 = Account(AccountType.ASSETS, "Cash", tags=[Tag("bank")])
    account2 = Account(AccountType.REVENUES, "Revenue")
    account3 = Account(AccountType.REVENUES, "Revenue", tags=[Tag("Cancelled")])

    assert JournalEntry(datetime.date.today(), "Cash received", Guid(), []) \
        .post(datetime.date.today(), account1, 1) \
        .post(datetime.date.today(), account2, 2) \
        .post(datetime.date.today(), account3, -2) \
        .validate() == None

# Generated at 2022-06-26 00:35:25.469287
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    from datetime import date

    #   Create a journal entry object
    j = JournalEntry.__new__(JournalEntry)
    j.date = date.today()
    j.description = "Testing"
    j.source = "Test source"

    #   Create a posting for the journal entry
    p = Posting.__new__(Posting)
    p.journal = j
    p.date = date.today()
    p.account = "Expenses:Testing"
    p.direction = Direction.DEC
    p.amount = 1

    #   Add the posting to journal entry
    j.postings.append(p)

    #   Run the validate method
    j.validate()

# Generated at 2022-06-26 00:35:33.893587
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import RootAccount
    from .globals import GLOBAL_POSTINGS_DATE
    from datetime import date
    #Debit account
    debit_account=RootAccount.ASSETS.subAccount(str(i))
    #Credit account
    credit_account=RootAccount.EQUITIES.subAccount(str(i))
    joe=JournalEntry[None](date.today(), "Joe", None)
    joe.post(GLOBAL_POSTINGS_DATE, debit_account, 1000)
    joe.post(GLOBAL_POSTINGS_DATE, credit_account, -1000)
    joe.validate()

# Generated at 2022-06-26 00:35:46.624004
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Imports
    from dataclasses import dataclass
    from enum import Enum
    from typing import List
    import unittest
    from unittest import mock

    # Defines a source type
    @dataclass(frozen=True)
    class Source:
        pass

    # Defines a journal entry class
    @dataclass(frozen=True)
    class JournalEntry(Generic[Source]):
        #: Journals
        journals: List[JournalEntry[Source]] = field(default_factory=list)

        #: Journal posted to
        journal: JournalEntry[Source] = None

        #: Journal entry
        entry: JournalEntry = None

        #: Business object as the source of the journal entry.
        source: Source = None

        #: Date of the entry.
        date: datetime.date = None

# Generated at 2022-06-26 00:35:48.404884
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert callable(ReadJournalEntries.__call__)

# Generated at 2022-06-26 00:35:49.002152
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:35:55.222717
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    JournalEntry.post
    """
    # Setup
    self = JournalEntry
    self.date, self.description, self.source = datetime.date(2019, 9, 5), "test", object()
    self.postings = []

    # Exercise
    self.post(self.date, Account(AccountType.ASSETS, 1), -1)

    # Verify
    assert self.postings == [Posting(self, self.date, Account(AccountType.ASSETS, 1), Direction.DEC, -1)]

# Generated at 2022-06-26 00:36:04.251290
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import asdict
    from operator import attrgetter
    from .accounts import AccountType, build_account, build_account_type
    from .books import ChartOfAccounts
    from .tags import build_currency


# Generated at 2022-06-26 00:36:13.344894
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AssetAccount
    from .accounts import ExpenseAccount
    from .accounts import EquityAccount
    from .accounts import LiabilityAccount
    from .accounts import RevenueAccount
    from .accounts import KnownAccount
    from numbers import Amount
    from numbers import Quantity
    from datetime import date
    import unittest

    ledger = JournalEntry[str]("An entry", "lbl")
    ledger.post(date.today(), AssetAccount("bank"), Quantity(50))
    ledger.post(date.today(), ExpenseAccount("electricity"), Quantity(50))


# Generated at 2022-06-26 00:36:22.495261
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source = "source"
    journal1 = JournalEntry[str](datetime.date.today(), "description", source)
    journal2 = JournalEntry[str](datetime.date.today(), "description", source)
    journal3 = JournalEntry[str](datetime.date.today(), "description", source)
    journal4 = JournalEntry[str](datetime.date.today(), "description", source)
    journal5 = JournalEntry[str](datetime.date.today(), "description", source)

    account1 = Account("Expenses", AccountType.EXPENSES)
    account2 = Account("Revenues", AccountType.REVENUES)
    account3 = Account("Assets", AccountType.ASSETS)
    account4 = Account("Liabilities", AccountType.LIABILITIES)

# Generated at 2022-06-26 00:37:04.381596
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Set up:
    date_0 = None
    str_0 = 'kU'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)

    ## Test:
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:09.017892
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(11122988, 13, 13)
    str_0 = 'GX'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()
    journal_entry_1 = JournalEntry(date_0, str_0, date_0)
    journal_entry_1.validate()
    def stub_function_0(arg0_0) -> Iterable[JournalEntry]:
        journal_entry_0
    stub_function_0 = ReadJournalEntries.__call__(stub_function_0, date_0, date_0)
    journal_entry_0
    journal_entry_1
    stub_function_0


# Generated at 2022-06-26 00:37:14.359337
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'kU'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = datetime.date(year=2000, month=1, day=1)
    str_1 = 'hO'
    account_0 = None
    str_2 = 'cg'
    quantity_0 = Quantity(str_2)
    assert journal_entry_0.post(date_1, account_0, quantity_0) == journal_entry_0


# Generated at 2022-06-26 00:37:18.939048
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert isinstance(ReadJournalEntries(), ReadJournalEntries)


# Generated at 2022-06-26 00:37:22.302779
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'kU'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:25.962431
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    n_0 = 500
    account_0 = Account(None, None, None)
    date_0 = None
    journal_entry_0 = JournalEntry(date_0, None, None)
    journal_entry_0.post(date_0, account_0, n_0)

# Generated at 2022-06-26 00:37:31.968563
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'W'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    account_0 = Account('jhLc', AccountType.UNKNOWN)
    date_0 = None
    journal_entry_0.post(date_0, account_0, Quantity(100))
    assert journal_entry_0.postings[0].amount.value == 100
    assert journal_entry_0.postings[0].account.type == AccountType.UNKNOWN
    assert journal_entry_0.postings[0].direction == Direction.INC


# Generated at 2022-06-26 00:37:37.578016
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'kU'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = None
    account_0 = Account('', AccountType.CASH)
    account_1 = account_0
    quantity_0 = 0
    journal_entry_0.post(date_1, account_1, quantity_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:43.434766
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(None, '', None)
    journal_entry_0.post(None, None, 0)


# Generated at 2022-06-26 00:37:46.119455
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        test_case_0()
    except AssertionError as e:
        pass
    else:
        raise AssertionError("Test case 0 failed.")

test_JournalEntry_validate()

# Generated at 2022-06-26 00:38:27.395740
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period = DateRange()
    _T = TypeVar("_T")
    journal = JournalEntry(_T, _T, _T)
    journal_entry_0 = journal.post(datetime.date, Account, float)
    journal_entry_0 = journal.post(datetime.date, Account, float)
    journal_entry_0 = journal.post(datetime.date, Account, float)
    journal_entry_0 = journal.post(datetime.date, Account, float)
    journal_entry_0 = journal.post(datetime.date, Account, float)
    journal_entry_0 = journal.post(datetime.date, Account, float)
    journal_entry_0 = journal.post(datetime.date, Account, float)

# Generated at 2022-06-26 00:38:31.690827
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'lZ'
    date_0 = datetime.date.today()
    account_0 = Account('Account')
    int_0 = 0
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, int_0)

    assert(journal_entry_0.validate())


# Generated at 2022-06-26 00:38:39.786026
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import datetime
    from datetime import date
    from datetime import timedelta
    from datetime import time

    class Source_0(Protocol[_T]):
        """
        Type of functions which read journal entries from a source.
        """
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    class Source_1(Protocol[_T]):
        """
        Type of functions which read journal entries from a source.
        """
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    class Source_2(Protocol[_T]):
        """
        Type of functions which read journal entries from a source.
        """

# Generated at 2022-06-26 00:38:40.267244
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:41.271177
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True == True


# Generated at 2022-06-26 00:38:47.814568
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'kU'
    # Input:
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = "'"
    # Input:
    str_2 = '\t'
    account_0 = Account(str_2, str_2)
    long_0 = 10
    long_1 = 0
    quantity_0 = Quantity(long_1)
    # Output:
    journal_entry_0.post(DateRange.create(DateRange.create(str_1, str_2)), account_0, quantity_0)

# Generated at 2022-06-26 00:38:52.313509
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'kU'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.EQUITIES)
    money_0 = Amount(7)
    journal_entry_0.post(str_0, account_0, money_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:55.138312
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from my_bank.events.journal_events import read_journal_events
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 31))
    result = read_journal_events(period)
    assert result


# Generated at 2022-06-26 00:39:01.194919
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '<'
    journal_0 = JournalEntry(str_0, str_0, str_0)
    journal_1 = JournalEntry(str_0, str_0, str_0)
    journal_2 = JournalEntry(str_0, str_0, str_0)
    journal_3 = JournalEntry(str_0, str_0, str_0)
    journal_4 = JournalEntry(str_0, str_0, str_0)
    journal_5 = JournalEntry(str_0, str_0, str_0)
    journal_6 = JournalEntry(str_0, str_0, str_0)
    journal_7 = JournalEntry(str_0, str_0, str_0)
    journal_8 = JournalEntry(str_0, str_0, str_0)
   

# Generated at 2022-06-26 00:39:02.758596
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry("Z", "u^z", "J7")
    journal_entry_0.post("", "", 0)



# Generated at 2022-06-26 00:39:57.187446
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    #import abc
    import typing
    class _T(typing.Protocol):
        ...
    class MockReadJournalEntries:
        def __init__(self):
            pass
        def __call__(self, period : DateRange) -> typing.Iterable[JournalEntry[_T]]:
            pass
    _MockReadJournalEntries = MockReadJournalEntries()
    _ReadJournalEntries_0 = ReadJournalEntries(_T)
    _t_0 = _ReadJournalEntries_0.__origin__
    assert issubclass(_t_0, typing.Protocol)
    assert hasattr(_ReadJournalEntries_0, '__args__')
    assert hasattr(_ReadJournalEntries_0, '__origin__')
    assert hasattr(_ReadJournalEntries_0, '__parameters__')

# Generated at 2022-06-26 00:40:02.689273
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry('a', 'b', 'c')
    j.post(datetime.date.today(), 'd', 1)
    j.validate()

    j.post(datetime.date.today(), 'e', -1)
    j.validate()

    # Test for debits and credits not equal.
    with pytest.raises(AssertionError):
        j = JournalEntry('a', 'b', 'c')
        j.post(datetime.date.today(), 'd', 1)
        j.post(datetime.date.today(), 'e', -2)
        j.validate()

# Generated at 2022-06-26 00:40:05.584572
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'mQ'
    str_1 = 'lw'
    account_0 = Account(str_1, str_1, str_1, str_1)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, account_0, int(str_1))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:40:08.377966
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    sampleAccount = Account('Personal Expenses', AccountType.EXPENSES)
    sampleJournalEntry = JournalEntry('2020-10-12', 'Meal', 'lunch')
    sampleJournalEntry.post(datetime.date(2020, 3, 3), sampleAccount, Quantity(5))
    sampleJournalEntry.validate()



# Generated at 2022-06-26 00:40:10.535571
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'o'
    def t1_ReadJournalEntries(a:DateRange)->Iterable[JournalEntry[_T]]:
        return a
    t1 = ReadJournalEntries.__call__(t1_ReadJournalEntries, str_0)

# Generated at 2022-06-26 00:40:18.528156
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    print("Testing the function named __call__ of the class ReadJournalEntries")
    print("---")

# Generated at 2022-06-26 00:40:19.169852
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_case_0()


# Generated at 2022-06-26 00:40:23.782136
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source_str = "The source string"
    journal_entry_1 = JournalEntry(datetime.date.today(), "Description", source_str)
    journal_entry_1.post(datetime.date(2017, 10, 1), Account('bank'), 100)
    assert journal_entry_1.postings[0].date == datetime.date(2017, 10, 1)
    assert journal_entry_1.postings[0].amount == 100
    assert journal_entry_1.postings[0].account.name == 'bank'

# Generated at 2022-06-26 00:40:29.890195
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, test_case_0 as account_test_case_0
    from .currencies import Currency, test_case_0 as currency_test_case_0
    from .prices import Price, test_case_0 as price_test_case_0
    from .units import Unit, test_case_0 as unit_test_case_0
    from ..commons.zeitgeist import test_case_0 as zeitgeist_test_case_0

    account_test_case_0()
    currency_test_case_0()
    price_test_case_0()
    unit_test_case_0()
    zeitgeist_test_case_0()

    def test_case_0():
        str_0 = '9V'

# Generated at 2022-06-26 00:40:36.406145
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _theCallable(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    _theCallable(DateRange(1, 2))