

# Generated at 2022-06-26 00:31:09.658310
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry(datetime.date.today(), "test description", "source")
    j1.post(datetime.date.today(), "account", 100)
    j1.validate()

    j2 = JournalEntry(datetime.date.today(), "test description", "source")
    j2.post(datetime.date.today(), "account", -100)
    j2.validate()

# Generated at 2022-06-26 00:31:17.414712
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .sources import AccountEntry

    # Arrange
    journal = JournalEntry[AccountEntry]()
    account_0 = Account(AccountType.EQUITIES, "Equity Account", "Equity")
    account_1 = Account(AccountType.ASSETS, "Asset Account", "Asset")

    # Act
    journal.post(datetime.datetime.now().date(), account_0, +1000)
    journal.post(datetime.datetime.now().date(), account_1, -1000)

    # Assert
    assert journal.debits and journal.credits and not journal.increments and not journal.decrements
    print(journal)

# Generated at 2022-06-26 00:31:23.824254
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Test '__call__' of class ReadJournalEntries.
    """
    rje = ReadJournalEntries
    period_0 = DateRange('2020-06-13', '2020-06-13')
    rje.__call__(period_0)

if __name__ == "__main__":
    try:
        test_case_0()
        test_ReadJournalEntries___call__()
    except AssertionError:
        raise

# Generated at 2022-06-26 00:31:24.874797
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-26 00:31:27.734283
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesImpl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    pass

# Generated at 2022-06-26 00:31:36.956761
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journalEntry = JournalEntry(datetime.date(2020, 1, 2), "description", None)
    journalEntry = journalEntry.post(datetime.date(2020, 1, 2), Account("a", AccountType.EXPENSES), Quantity(10))
    assert len(journalEntry.postings) == 1
    assert journalEntry.postings[0].amount == Amount(10)
    assert journalEntry.postings[0].direction == Direction.INC
    assert journalEntry.postings[0].account.type == AccountType.EXPENSES
    assert journalEntry.postings[0].date == datetime.date(2020, 1, 2)
    assert journalEntry.postings[0].is_debit == False
    assert journalEntry.postings[0].is_credit == True


# Generated at 2022-06-26 00:31:47.122294
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountVault
    from .funds import Payee, Payer
    from .funds.payments import Payment
    from .funds.transfers import Transfer
    from .taxing import TaxPayer, TaxRegime, TaxType
    from .taxing.taxes import Tax
    from .taxing.taxrates import TaxRate
    from .taxing.taxpayers import TaxableItem

    from .taxing.taxrates import TaxRateSchedule

    # Create a tax rate object
    tax_rate_obj = TaxRateSchedule.from_iterable([(DateRange.from_dates(datetime.date(1950, 1, 1), datetime.date(2050, 12, 31)), 0.3)])

    # Create a tax rate object
    tax_rate_obj_2 = TaxRateSchedule.from_iter

# Generated at 2022-06-26 00:31:53.175516
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange.from_start_and_end(
        datetime.date(year=2020, month=10, day=7),
        datetime.date(year=2020, month=10, day=15))
    instance_0 = test_ReadJournalEntries___call__.__annotations__['return']
    val = instance_0(period=period_0)
    print(val)

test_ReadJournalEntries___call__.__annotations__ = {'return': ReadJournalEntries[_T]}


# Generated at 2022-06-26 00:31:53.668452
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:31:58.182235
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    def _test_JournalEntry_post(p: JournalEntry[Guid], date: datetime.date, account: Account, quantity: Quantity):
        assert p.post(date, account, quantity) == p
        assert p.postings[0].date == date
        assert p.postings[0].is_debit == account.type.is_debit
        assert p.postings[0].amount == Amount(quantity)

    j = JournalEntry(datetime.date(2020, 6, 23), 'toto', makeguid(), List())
    _test_JournalEntry_post(j, datetime.date(2020, 6, 23),  Account("CHF"), 10)
    _test_JournalEntry_post(j, datetime.date(2020, 6, 23),  Account("CHF"), -10)
    _test_JournalEntry

# Generated at 2022-06-26 00:32:11.977426
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = "#;AlJtq){c3#y\x0b'"
    list_0 = []
    journal_entry_0 = JournalEntry(date_0, str_0, list_0)
    guid_0 = journal_entry_0.guid
    str_1 = "  mb1{19@dT"
    str_2 = "m1|m"
    date_2 = datetime.datetime.strptime(str_2, "%Y-%m-%d").date()
    account_0 = Account(str_1, date_2)
    int_0 = 1010
    posting_0 = Posting(journal_entry_0, guid_0, account_0, Direction.DEC, int_0)
    journal_entry_0.postings.append

# Generated at 2022-06-26 00:32:12.922558
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert False, "Unimplemented method."

# Generated at 2022-06-26 00:32:15.184395
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_range_0 = None
    read_journal_entries_0 = None
    read_journal_entries_0.__call__(date_range_0)


# Generated at 2022-06-26 00:32:20.750055
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    list_0 = []
    journal_entry_0 = JournalEntry(None, None, list_0)
    account_0 = Account(None, None, None)
    journal_entry_0.post(datetime.datetime(2018, 11, 8), account_0, 1)


# Generated at 2022-06-26 00:32:27.100100
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2020, 1, 1)
    account = Account('Assets:Current:Cash')
    quantity = Amount(100.0)
    journal_entry = JournalEntry(date, 'description', 'source')
    assert len(journal_entry.postings) == 0
    journal_entry.post(date, account, quantity)
    assert len(journal_entry.postings) == 1


# Generated at 2022-06-26 00:32:37.727575
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(year=1960, month=8, day=19)
    date_1 = datetime.date(year=2016, month=9, day=19)
    date_range_0 = DateRange(date_0, date_1)
    float_0 = float('-inf')
    int_0 = int()
    journal_entry_0 = JournalEntry(date_0, str(), float_0)
    list_0 = [journal_entry_0]
    # Begin of test code
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return list_0
    # End of test code
    assert read_journal_entries(date_range_0) == list_0

# Generated at 2022-06-26 00:32:48.190273
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    guid_0 = None
    description_0 = "#;oG}p\x0fBaK:*\\-s"
    account_0 = Account(guid_0, description_0)
    source_0 = None
    direction_0 = None
    amount_0 = None
    posting_0 = Posting(source_0, guid_0, account_0, direction_0, amount_0)
    postings_0 = [posting_0]
    date_0 = None
    str_0 = "\\"
    journal_entry_0 = JournalEntry(date_0, str_0, postings_0)
    date_0 = None
    quantity_0 = None
    account_1 = Account(guid_0, description_0)

# Generated at 2022-06-26 00:32:52.101770
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = "`v]\n\x19VTf\x1f$G|E"
    list_0 = []
    journal_entry_0 = JournalEntry(date_0, str_0, list_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:32:54.511201
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    server_0 = JournalEntry(None, None, None)
    server_0.post(None, None, None)

    # Unit test for method validate of class JournalEntry

# Generated at 2022-06-26 00:32:57.572217
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = "8rv}<f&V"
    list_0 = []
    journal_entry_0 = JournalEntry(date_0, str_0, list_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:33:08.950259
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _ReadJournalEntries___call__(self, period): return Iterable[JournalEntry[_T]]
    ReadJournalEntries.__call__ = _ReadJournalEntries___call__
    ReadJournalEntries._ReadJournalEntries___call__ = _ReadJournalEntries___call__



# Generated at 2022-06-26 00:33:13.478470
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    date_range_0 = DateRange(str_0, str_0)
    ReadJournalEntries.__call__(str_0, date_range_0)


# Generated at 2022-06-26 00:33:16.922267
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(1684, 1, 8)
    quantity = (1)
    account = Account('Dept. 1/Account 1')
    journal = JournalEntry(date, 'Journal Entry', 'Transaction')
    journal.post(date, account, quantity)
    journal.validate()


# Generated at 2022-06-26 00:33:26.718246
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        from .accounts import Account, AccountType
        from .journals import JournalEntry, Posting, _debit_mapping

        journal_entry_0 = JournalEntry(str_0, str_0, str_0)
        journal_entry_0.post(str_0, str_0, str_0)
        journal_entry_0.validate()
        journal_entry_0.validate()
        journal_entry_0.validate()
        journal_entry_0.validate()
        return [journal_entry_0]

    # Test function body:
    period_0 = DateRange(str_0, str_0)
    assert read_journal_entries(period_0)

# Generated at 2022-06-26 00:33:30.110671
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # Test for function validate of class JournalEntry
    # It tests the case when no error is raised
    test_case_0()

    # Test for function validate of class JournalEntry
    # It tests the case when error is raised
    test_case_1()

# Generated at 2022-06-26 00:33:33.561939
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    assert isinstance(journal_entry_0, JournalEntry)


# Generated at 2022-06-26 00:33:38.257689
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\x1b\xfc\x1f\xeba\x12\x9e\xdb\x94M\xf0\x01\x1a\x8c\xb0\x91^]\x9b'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    print(journal_entry_0)


# Generated at 2022-06-26 00:33:40.453630
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 00:33:46.180932
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    str_1 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.validate()


# Generated at 2022-06-26 00:33:51.051983
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2020, 9, 1)
    account = Account(str_0, str_0, str_0)
    amount = 0
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date, account, amount)


# Generated at 2022-06-26 00:34:05.879180
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def test_cases():
        yield (
            (lambda: '`v]u\n\x19VTf\x1f$G|E'),
            (lambda: '`v]u\n\x19VTf\x1f$G|E'),
            (lambda: '`v]u\n\x19VTf\x1f$G|E'),
        )

    for test_case in test_cases():
        source = test_case[0]
        period = test_case[1]
        expected = test_case[2]
        actual = ReadJournalEntries.__call__(source, period)
        assert actual == expected



# Generated at 2022-06-26 00:34:13.613304
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert callable(ReadJournalEntries.__call__)

    from datetime import date
    from contextlib import contextmanager
    from io import StringIO
    from dataclasses import asdict

    # Build journal entries for testing:
    purchases_date = date(2019, 9, 26)
    purchase_journal_entry_1 = JournalEntry(purchases_date, "Purchases 1", "P01")
    purchase_journal_entry_1.post(purchases_date, Account("110001", AccountType.ASSETS, "Cash"), +1)
    purchase_journal_entry_1.post(purchases_date, Account("130001", AccountType.EXPENSES, "Debit Expense account"), -1)


# Generated at 2022-06-26 00:34:18.021362
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create a test journal
    j = JournalEntry('2014-01-01', 'Test Journal', 'Test')

    # Create a test account
    a = Account('Example Account', AccountType.ASSETS)
    j.post('2014-01-01', a, Amount(5))

    # Validate the journal
    j.validate()

    # Read the journal
    print(j)

# Generated at 2022-06-26 00:34:25.137617
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2018, 12, 21)
    account = Account("test", "description", AccountType.LIABILITIES)
    quantity = 100
    expected_postings_length = 1

    journal_entry = JournalEntry(date, "JournalEntry.test", object())

    journal_entry.post(date, account, quantity)

    assert len(journal_entry.postings) == expected_postings_length
    assert journal_entry.postings[0].is_debit


# Generated at 2022-06-26 00:34:28.296712
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    assert journal_entry_0.post(str_0, str_0, str_0) is journal_entry_0



# Generated at 2022-06-26 00:34:29.793751
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # type: () -> None
    """
    Tests __call__ of class ReadJournalEntries
    """
    assert False

# Generated at 2022-06-26 00:34:30.953095
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    global ReadJournalEntries
    assert True


# Generated at 2022-06-26 00:34:39.709019
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from swagger_server.models import Period
    from datetime import date
    from typing import Dict, Type
    from swagger_server.models.amount import Amount
    from swagger_server.models.journal_entry import JournalEntry
    from swagger_server.models.posting import Posting
    from swagger_server.models.account import Account
    from swagger_server.models.account_type import AccountType

    class _TestPeriod(Period):
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            return ""

        def to_dict(self):
            return ""


# Generated at 2022-06-26 00:34:44.865345
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.date.today()
    account_0 = Account(str_0, AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, 1)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:46.722921
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__()


# Generated at 2022-06-26 00:35:04.360284
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:35:08.590679
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = JournalEntry("a", "b", "c")
    a.post("a", "a", "a")
    a.post("a", "a", "a")
    a.post("a", "a", "a")
    assert a.postings is not None


# Generated at 2022-06-26 00:35:17.400786
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test case 1
    journal_entry_1 = JournalEntry[object](object(), object(), object())
    journal_entry_1.post(datetime.date(1, 1, 1), object(), object())
    assert journal_entry_1.postings == [Posting(journal_entry_1, datetime.date(1, 1, 1), object(), Direction.INC, Amount(abs(object())))]

# Generated at 2022-06-26 00:35:27.250757
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class JournalEntries:
        def __init__(self):
            self.entry_item_0 = JournalEntry('`v]u\n\x19VTf\x1f$G|E', '`v]u\n\x19VTf\x1f$G|E', '`v]u\n\x19VTf\x1f$G|E')
            def __call__(self, period2: DateRange) -> Iterable[JournalEntry[str]]:
                entries = [self.entry_item_0]
    journal_entries_0 = JournalEntries()
    period_0 = DateRange(datetime.date(2020, 11, 13), datetime.date(2020, 11, 13))
    journal_entries_1 = journal_entries_0(period_0)

# Generated at 2022-06-26 00:35:39.333806
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Variable declaration
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    str_1 = 'o&\x05\x1d\x01\x1f\x11\x0bF\x08\x15\x0e\x0b\x05\x0e\x1a\x05Q\x0e\n\x0f\x1d\x1d'
    journal_entry_0 = JournalEntry(str_1, str_0, str_0)
    datetime_2 = datetime.datetime(2000, 3, 1, 0, 52, 14, 376000)
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()

# Generated at 2022-06-26 00:35:48.324401
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    word_0 = 'Bk\x17y%\x14\x11\x15*\x1c\x04H\\V\x0e\x14\x04\x1eD\x1c\x1a\t\x1cX\x13x\x1d\x1eM\x1d\r\x04\x14\x0c\x14\x14d\x07'
    journal_entry_0 = JournalEntry(word_0, word_0, word_0)
    int_0 = 0
    quantity_0 = Quantity(int_0)
    assert journal_entry_0.post(word_0, word_0, quantity_0) is journal_entry_0

# Generated at 2022-06-26 00:35:49.634608
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # TODO
    # pass
    test_case_0()

# Generated at 2022-06-26 00:35:50.498372
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    _test_JournalEntry_validate()


# Generated at 2022-06-26 00:35:54.440059
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:01.845552
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests __call__ method of ReadJournalEntries
    """
    obj_0 = ReadJournalEntries(str)
    journal_entry_0 = JournalEntry("`v]u\n\x19VTf\x1f$G|E", "`v]u\n\x19VTf\x1f$G|E", "`v]u\n\x19VTf\x1f$G|E")
    journal_entry_0.validate()
    assert journal_entry_0.date == "`v]u\n\x19VTf\x1f$G|E"


# Generated at 2022-06-26 00:36:26.654858
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'

    def f_0x5c5d5e5f(period: DateRange) -> Iterable[JournalEntry]:
        try:
            yield JournalEntry(str_0, str_0, str_0)
        except Exception:
            yield from []

    rj_0x5c5d5e5f = ReadJournalEntries.__call__(f_0x5c5d5e5f, str_0, str_0, str_0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    assert list(rj_0x5c5d5e5f) == [journal_entry_0]



# Generated at 2022-06-26 00:36:33.340167
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('#;~z+', '', '\x19VTf\x1f$G|E')
    journal_entry_0.post('', '', datetime.date(1, 1, 1))
    journal_entry_1 = JournalEntry(']Jt\x04t', '', '')
    journal_entry_1.post('\x19VTf\x1f$G|E', '', datetime.date(1, 1, 1))


test_JournalEntry_post()

# Generated at 2022-06-26 00:36:35.877493
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry("", "", "")
    journal_entry_0.post("", "", "")




# Generated at 2022-06-26 00:36:41.197658
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2019, 1, 25)
    direction = Direction.INC
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    account_0 = Account(str_0, AccountType.ASSETS)
    quantity_0 = Amount(4.4)
    journal_entry_0 = JournalEntry(date, str_0, str_0)

    assert journal_entry_0.post(date, account_0, quantity_0)


# Generated at 2022-06-26 00:36:42.023393
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True


# Generated at 2022-06-26 00:36:49.843843
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    def mock_JournalEntry_self(self):
        return self

    mock_journal_entry_0 = JournalEntry('', '', '')
    # Call method post of class JournalEntry on mock_journal_entry_0
    mock_journal_entry_self = mock_JournalEntry_self(mock_journal_entry_0)
    mock_date_0 = datetime.date(1946, 5, 28)
    mock_account_0 = Account('', '', '', '', '')
    mock_quantity_0 = Quantity('0')
    # Call method post of class JournalEntry on mock_journal_entry_0
    mock_journal_entry_0.post = mock_journal_entry_self.post(mock_date_0, mock_account_0, mock_quantity_0)

# Generated at 2022-06-26 00:36:59.084970
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = '1999-09-28'
    account = '{&`;h\t\x1bt\x1b'
    quantity = 694954577289568261869296220746847621714
    journal_entry = JournalEntry(date, '', '')
    journal_entry.post(date, account, quantity)
    journal_entry.validate()

    date = '1789-04-09'

# Generated at 2022-06-26 00:37:05.565064
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    def new_read_journal_entries() -> ReadJournalEntries[str]:
        return lambda period: []
    read_journal_entries_0 = new_read_journal_entries()
    str_1 = '`v]u\n\x19VTf\x1f$G|E'
    daterange_0 = DateRange(str_1, str_1)
    read_journal_entries_0(daterange_0)


# Generated at 2022-06-26 00:37:06.117246
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:37:08.784998
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('2016-11-02', "pay", str(0))
    from ..domain.accounts import Account
    from kiwi import Currency
    account_0 = Account('test', 'test', 'test', Currency.USD)
    journal_entry_0.post(datetime.date(2016, 11, 2), account_0, Amount(100))


# Generated at 2022-06-26 00:37:30.951208
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True

# Generated at 2022-06-26 00:37:43.100180
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    d0 = datetime.date(2020, 1, 1)
    a0 = Account(str_0, AccountType.ASSETS)
    q0 = 1
    # expected (regular) behavior
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(d0, str_0, str_0)
    journal_entry_0.post(d0, a0, q0)
    # expected (special) behavior
    journal_entry_0 = JournalEntry(d0, str_0, str_0)
    journal_entry_0.post(d0, a0, 0)


# Generated at 2022-06-26 00:37:45.516968
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Instantiate a ReadJournalEntries and verify that it is callable.
    def a_ReadJournalEntries():
        pass
    assert issubclass(type(a_ReadJournalEntries), ReadJournalEntries)


# Generated at 2022-06-26 00:37:50.712694
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n'
    str_1 = '\x01\x02\x03\x04\x05\x06\x07\x08\t\n'
    journal_entry_0 = JournalEntry(str_0, str_1, str_0)
    journal_entry_0.post(datetime.date(1999, 3, 22), str_0, -7)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:04.542750
# Unit test for method post of class JournalEntry

# Generated at 2022-06-26 00:38:12.504748
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_0, 1)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_0, 1)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_0, 1)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:18.095614
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test TypeError
    try:
        # str_0 = '`v]u\n\x19VTf\x1f$G|E'
        # journal_entry_0 = JournalEntry(str_0, str_0, str_0)
        # journal_entry_0.validate()
        # journal_entry_0.validate()
        # journal_entry_0.validate()

        x = ReadJournalEntries()
        x.__call__(1)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 00:38:27.548573
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\x01\x02o\x03\x1a:D\x0e\x1b!f\x13\x0e'
    date_range_0 = DateRange(str_0)
    def func_0(arg_0):
        num_0 = -179
        var_0 = Guid('\x07\x12\x14\x18\x0e\x1a\x1c\n\t\x03\x11\x15\x14\x0f\x1c\x1a\x1b\x0e\x0a\x19\x07')

# Generated at 2022-06-26 00:38:31.249134
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test case 0:
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, str_0)


# Generated at 2022-06-26 00:38:32.187245
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True
    #assert False

# Generated at 2022-06-26 00:39:19.812434
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '7\x1eAA\t\x14C\x1e\x13\x00\x19\x0f\x1c\x1e'
    source_0 = JournalEntry(str_0, [str_0, str_0])
    for i in range(10):
        str_0 = str(i)
        source_0.post(datetime.date(i, i, i), str_0, Amount(i))
    source_0.validate()

    journal_entry_0 = JournalEntry(source_0.date, source_0.description, source_0.source)
    try:
        journal_entry_0.validate()
    except AssertionError as ex:
        pass

# Generated at 2022-06-26 00:39:22.712258
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    ReadJournalEntries.__call__(journal_entry_0)


# Generated at 2022-06-26 00:39:29.044425
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date

    today = date.today()
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    str_1 = 'r\x05\x11\x02\x08\x06\x0f\x1fw\x1c\x0f**\r\x14\x17\x16\x0b\x0f\x1a\x03\x15\x04\x10\x10\x1f\x1b\x1f\x10\x07\x03\x14\x1a\x1d\x0b\x14\x1a\x17'
    account_0 = Account(str_1, int(2969177978))
    int_0 = 0
    journal_entry_

# Generated at 2022-06-26 00:39:30.004417
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert ReadJournalEntries.__call__(None, None) == None


# Generated at 2022-06-26 00:39:32.270115
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    posting_0 = Posting(str, str, str, str, str)
    def __call__(self, period:DateRange) ->Iterable[JournalEntry[_T]]: pass
    ReadJournalEntries.__call__ = __call__


# Generated at 2022-06-26 00:39:38.691575
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from aggregator import aggregator
    from aggregator import account
    from aggregator import journal
    from aggregator import result
    from aggregator import transaction
    from aggregator import witness

    # DEFINITIONS:
    class Object0:
        pass

    class Object1:
        pass

    class Object2:
        pass

    def fun_0(arg_0 : DateRange) -> Object0:
        return Object0()

    def fun_1(arg_0 : DateRange) -> Object1:
        return Object1()

    def fun_2(arg_0 : DateRange) -> Object2:
        return Object2()

    def fun_3(arg_0 : Iterable) -> None:
        pass

# Generated at 2022-06-26 00:39:41.802543
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, 0)
    journal_entry_0.post(str_0, str_0, 0)


# Generated at 2022-06-26 00:39:48.188257
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    test_0 = datetime.date(2020, 1, 1)
    test_1 = Account("account_0", AccountType.ASSETS)
    test_2 = Amount(25)
    journal_entry_0 = JournalEntry("description_0", "^\xcf\xa1\xc8\x0b\x1b\x14\x87\x7f\xd2\xa2\xa1iG\x8e\x81\x94\x1e\x04\xa9")
    journal_entry_0.post(test_0, test_1, test_2)

# Generated at 2022-06-26 00:39:50.293879
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '`v]u\n\x19VTf\x1f$G|E'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, 0.0)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_0, 0.0)



# Generated at 2022-06-26 00:39:54.253143
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_1 = '\t\x1d)z\t\x0c'
    read_journal_entries_0 = ReadJournalEntries()
    date_range_0 = DateRange(datetime.date(2010, 1, 1), datetime.date(2030, 1, 1))
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    read_journal_entries_0(date_range_0)
