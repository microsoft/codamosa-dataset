

# Generated at 2022-06-26 00:31:09.257168
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test with parameters
    # Posting[T]
    # Posting[T](date, account, direction, amount)
    # Posting[T]
    # Posting[T](date, account, direction, amount)
    pass

# Generated at 2022-06-26 00:31:13.450389
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Construction
    date = module_0.date()
    description = 'Description'
    source = None
    postings = []
    journal_entry_0 = JournalEntry(date, description, source, postings)
    # Execution
    journal_entry_0.validate()
    test_case_0()
    # Verification
    pass

# Generated at 2022-06-26 00:31:23.381539
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class MockClass_0:
        def __init__(self, arg_0, arg_1, arg_2, arg_3, arg_4):
            self.journal = arg_0
            self.date = arg_1
            self.account = arg_2
            self.direction = arg_3
            self.amount = arg_4


    class MockClass_1:
        pass


    class MockClass_2:
        def __init__(self, arg_0, arg_1, arg_2, arg_3):
            self.description = arg_0
            self.date = arg_1
            self.source = arg_2
            self.postings = MockClass_0(arg_3, module_0.date(), module_0.date(), module_0.date(), Direction.INC)



# Generated at 2022-06-26 00:31:25.276404
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ie1 = JournalEntry(
        date=date_0, description="test", source=None, postings=None
    )
    ie1.validate()

# Generated at 2022-06-26 00:31:27.693522
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Instantiate the class ReadJournalEntries
    pass

import datetime as module_1
import fnmatch as module_2


# Generated at 2022-06-26 00:31:28.546644
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entry_0 = JournalEntry()

# Generated at 2022-06-26 00:31:38.104106
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .ledgers import Ledger

    import datetime as module_0
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange

    test_case_0 = ReadJournalEntries()
    test_case_1 = Ledger(
        "Test Ledger",
        [
            Account("Expenses", AccountType.EXPENSES),
            Account("Assets", AccountType.ASSETS),
            Account("Revenues", AccountType.REVENUES),
            Account("Liabilities", AccountType.LIABILITIES),
            Account("Equities", AccountType.EQUITIES),
        ],
    )

# Generated at 2022-06-26 00:31:43.508638
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Tested method
    def __call__(self: ReadJournalEntries[_T], period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    # Test parameters
    period_0 = DateRange()

    # Invoke tested method
    value_0 = __call__(period_0)

import datetime as module_0
import datetime as module_1


# Generated at 2022-06-26 00:31:45.590251
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    def expected():
        pass
    def actual():
        pass
    # Assert
    assert expected == actual


# Generated at 2022-06-26 00:31:50.288098
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    arg_0 = None

    try:
        retval = arg_0.__call__(test_case_0())
    except TypeError as e:
        assert str(e) == "Method __call__() is not implemented."
    else:
        assert False, "Unexpected success."

JournalEntry.validate()
ReadJournalEntries.__call__()

# Generated at 2022-06-26 00:32:04.466658
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # unit test case 1
    date_1 = datetime.date(1988, 12, 8)
    str_1 = 'Malawi kwacha'
    date_range_0 = DateRange(date_1, date_1)
    def func_0():
        pass
    ReadJournalEntries.__call__(func_0, date_range_0)
    # unit test case 2
    date_2 = datetime.date(2001, 12, 11)
    str_2 = 'Saint Helena pound'
    func_0 = None
    ReadJournalEntries.__call__(func_0, date_range_0)
    # unit test case 3
    date_3 = datetime.date(1987, 8, 18)
    str_3 = 'British Virgin Islands dollar'
    account_type_0 = None
    class_0

# Generated at 2022-06-26 00:32:13.503879
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(1, 1, 1)
    date_1 = datetime.date(2, 2, 2)
    date_range_0 = DateRange(date_0, date_1)
    account_0 = Account('', None)
    amount_0 = Amount(100)
    amount_0.is_zero()
    type(journal_entry_0)
    journal_entry_1 = Entry(date_0, str_0, date_0, journal_entry_1, int_0, amount_1)
    account_0 = Account('', None)
    amount_0 = Amount(100)
    amount_0.is_zero()
    journal_entry_0.post(date_0, account_0, amount_0)
    journal_entry_0.validate()
    journal_entry_

# Generated at 2022-06-26 00:32:25.915464
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(1955, 7, 21)
    date_1 = datetime.date(1955, 8, 21)
    date_range = DateRange.new(date_0, date_1)
    str_0 = 'Sri Lanka Rupee'
    str_1 = 'Sri Lanka Rupee'
    amount_0 = Amount(0)
    amount_1 = Amount(1)
    guid_0 = makeguid()
    account_0 = Account(str_0, str_1, str_1, guid_0)
    direction_0 = Direction.INC
    amount_2 = Amount(1)
    posting_0 = Posting(date_0, account_0, direction_0, amount_2)

# Generated at 2022-06-26 00:32:33.315183
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'East Caribbean Dollar'
    date_1 = None
    account_0 = Account(str_0, date_0, date_1, date_0, date_0)
    quantity_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_2 = None
    quantity_1 = None
    journal_entry_0.post(date_2, account_0, quantity_1)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:32:44.688288
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    debit_account_0 = Account(str_0, AccountType.ASSETS, date_0)
    debit_account_1 = Account(str_0, AccountType.ASSETS, date_0)
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    debit_account_0 = Account(str_0, AccountType.ASSETS, date_0)
    debit_account_0 = Account(str_0, AccountType.ASSETS, date_0)
    debit_account_1 = Account(str_0, AccountType.ASSETS, date_0)
    debit_account_1 = Account(str_0, AccountType.ASSETS, date_0)
    debit_account_2 = Account(str_0, AccountType.ASSETS, date_0)
    debit_account_2 = Account

# Generated at 2022-06-26 00:32:54.111063
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(1998, 10, 23)
    date_1 = datetime.date(2002, 4, 2)
    account_0 = Account('account_0')
    quantity_0 = Quantity(-5)
    quantity_1 = Quantity(1)
    quantity_2 = Quantity(6)
    quantity_3 = Quantity(-7)
    quantity_4 = Quantity(-6)
    quantity_5 = Quantity(1)
    quantity_6 = Quantity(6)
    quantity_7 = Quantity(7)
    quantity_8 = Quantity(0)
    quantity_9 = Quantity(8)
    quantity_10 = Quantity(-4)
    str_0 = 'East Caribbean Dollar'
    journal_entry_0 = JournalEntry(date_0, str_0, date_1)

# Generated at 2022-06-26 00:32:58.706328
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2000, 1, 2)
    str_0 = 'East Caribbean Dollar'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    account_0 = Account(str_0, enum_0, enum_0)
    quantity_0 = 9
    journal_entry_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:33:05.288818
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:16.403277
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'Japanese Yen'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)

    date_1 = None
    account_type_0 = None
    str_1 = 'Japanese Yen'
    account_0 = Account(account_type_0, str_1)

    quantity_0 = None
    journal_entry_0.post(date_1, account_0, quantity_0)

    date_2 = None
    account_type_1 = None
    str_2 = 'Jamaican Dollar'
    account_1 = Account(account_type_1, str_2)

    quantity_1 = None
    journal_entry_0.post(date_2, account_1, quantity_1)

    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:20.650333
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'East Caribbean Dollar'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    account_1 = Account(str_0, None)
    assert journal_entry_0 == journal_entry_0.post(date_0, account_1, 0)

# Generated at 2022-06-26 00:33:25.869242
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__(None, None)
    pass


# Generated at 2022-06-26 00:33:35.315834
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #   Source:
    #       journal entry = JournalEntry({}, {}, {})
    #       journal entry.post(datetime.date(year=2019, month=9, day=4), "Accounts Payable", 4000)
    #       journal entry.post(datetime.date(year=2019, month=9, day=4), "Cash", -4000)
    #       journal entry.validate()
    var_0 = None
    var_1 = datetime.date(year=2019, month=9, day=4)
    var_2 = "Accounts Payable"
    var_3 = 4000
    var_4 = datetime.date(year=2019, month=9, day=4)
    var_5 = "Cash"
    var_6 = -4000

# Generated at 2022-06-26 00:33:36.505972
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_JournalEntry_validate_case_0()
    return

# Generated at 2022-06-26 00:33:40.510121
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    var_1 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_0.post(var_0, var_1, var_1)

# Generated at 2022-06-26 00:33:41.415363
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True == True


# Generated at 2022-06-26 00:33:43.353854
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    method_retval_0 = ReadJournalEntries.__call__(None)
    print(str(method_retval_0))


# Generated at 2022-06-26 00:33:45.580497
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_1 = None
    journal_entry_1 = JournalEntry(var_1, var_1, var_1)
    journal_entry_1.post(var_1, var_1, var_1)
    journal_entry_1.validate()

# Generated at 2022-06-26 00:33:49.173030
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    var_1 = None
    var_2 = None
    var_3 = None
    journal_entry_1 = JournalEntry(var_1, var_2, var_3)
    journal_entry_1.validate()


# Generated at 2022-06-26 00:33:51.928444
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    journal_entry_0 = ReadJournalEntries
    journal_entry_0.__call__(var_0)


# Generated at 2022-06-26 00:33:55.367291
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class _DummyImpl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return None

    assert isinstance(_DummyImpl()(DateRange()), Iterable)


# Generated at 2022-06-26 00:34:09.904145
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    # Test case with params: date, account, quantity
    journal_entry_0.post(var_0, var_0, var_0)
    # Test case with params: date, account, quantity
    journal_entry_0.post(var_0, var_0, var_0)
    # Test case with params: date, account, quantity
    journal_entry_0.post(var_0, var_0, var_0)
    # Test case with params: date, account, quantity
    journal_entry_0.post(var_0, var_0, var_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:18.836002
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    var_0 = DateRange(datetime.date(2020, 10, 1), datetime.date(2020, 10, 31))
    journal_entries = []

    # Act
    def readJournalEntries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        for journal_entry_0 in journal_entries:
            journal_entry_0.validate()
        return iter(journal_entries)  # To avoid a false-positive from the static analysis (__iter__ instead of __call__).

    def test_case_0(readJournalEntries: ReadJournalEntries[_T], journal_entry_0: JournalEntry[_T]):
        journal_entry_0.validate()

        var_1 = 1


# Generated at 2022-06-26 00:34:28.987241
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from .accounts import Account

    ## Arrange ##
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    date_0 = datetime.date(2018, 1, 1)
    account_0 = Account("0", AccountType.ASSETS)
    quantity_0 = Quantity(0)
    # The following call posts an increment event to the account.
    journal_entry_0.post(date_0, account_0, quantity_0)

    ## Act ##
    ## Assert ##
    assert len(journal_entry_0.postings) == 1
    assert journal_entry_0.postings[0].date == date_0
    assert journal_entry_0.postings[0].account == account_0

# Generated at 2022-06-26 00:34:32.377697
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    var_0 = 0
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_0.validate()
    journal_entry_0_1 = JournalEntry()
    journal_entry_0_1.validate()


# Generated at 2022-06-26 00:34:34.926964
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    var_0 = None
    var_1 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_1)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:34:36.958525
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert JournalEntry(datetime.date(2020, 1, 26), '01', '01').validate() == None


# Generated at 2022-06-26 00:34:40.933686
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests method __call__ of class ReadJournalEntries for valid values.

    Expected result:

    * Successful completion.
    """
    journal_entry_0 = None
    period_0 = None
    read_journal_entries_0 = ReadJournalEntries()
    read_journal_entries_0(period_0)

    assert True

# Generated at 2022-06-26 00:34:45.719416
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    var_1 = datetime.date(year = 2018, month = 7, day = 4)
    var_2 = Account(None, None, None)
    var_3 = Quantity(1)
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_0.post(var_1, var_2, var_3)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:51.194289
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    var_1 = DateRange()
    journal_entries_0_0 = ReadJournalEntries()

    try:
        journal_entries_0_0(var_1)
        assert False
    except AttributeError as e:
        pass
    except Exception as e:
        assert False


# Generated at 2022-06-26 00:34:55.488289
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_1 = None
    var_2 = None
    var_3 = None
    entry_0 = JournalEntry(var_1, var_2, var_3)
    entry_1 = entry_0.post(var_1, var_2, var_3)
    assert entry_1 is entry_0
    assert var_3 == 0



# Generated at 2022-06-26 00:35:19.426132
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    var_1 = None
    var_2 = None
    journal_entry_0 = JournalEntry(var_0, var_1, var_2)
    journal_entry_0.validate()
    def ReadJournalEntries___call__():
        var_3 = DateRange()
        return [journal_entry_0]


test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:35:25.391291
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)

    # Test
    journal_entry_0.post(var_0, None, 100)
    journal_entry_0.post(var_0, None, -101)

    # Verification
    journal_entry_0.validate()


# Generated at 2022-06-26 00:35:29.736778
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    journal_entry_0.post(var_1, var_2, var_3)


# Generated at 2022-06-26 00:35:37.468273
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    postings = []
    je = JournalEntry(postings, var_0, var_0, var_0)
    je.post("R1", "Debit", "Credit", "Date", "Description", "Source")
    je.validate()
    assert len(je) == 1
    assert je[0] == Posting(var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-26 00:35:39.641969
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    journal_entries_0 = ReadJournalEntries.__call__(var_0)


# Generated at 2022-06-26 00:35:43.165414
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # input data
    period = None
    # expected output
    expected_result = None

    test_case = ReadJournalEntries()
    actual_result = test_case.__call__(period)
    assert expected_result == actual_result

# Generated at 2022-06-26 00:35:49.090879
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    type_0 = TypeVar("_T")
    type_1 = TypeVar("_T")
    try:
        _x = None  # type: _T
        def ReadJournalEntries___call__(self: ReadJournalEntries[type_1], period: DateRange) -> Iterable(JournalEntry[type_0]): pass
        ReadJournalEntries___call__(ReadJournalEntries, _x)
        pass
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 00:35:53.320270
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    journal_entry_0 = JournalEntry(var_0, var_1, var_2)
    journal_entry_0.post(var_3, var_3, var_3)

# Generated at 2022-06-26 00:35:54.279249
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:35:55.147478
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:36:27.984978
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    exec(test_case_0.__doc__)
    test_case_0()
    print('Test passed')



# Generated at 2022-06-26 00:36:31.579369
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    var_1 = None
    read_journal_entries_0 = ReadJournalEntries()
    journal_entry_0 = read_journal_entries_0(var_1)
    return


# Generated at 2022-06-26 00:36:41.017806
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    var_1 = datetime.date(year=2020, month=7, day=30)
    var_2 = Account("account_0", AccountType.ASSETS)
    var_3 = 50
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_1 = journal_entry_0.post(var_1, var_2, var_3)
    
    assert isinstance(journal_entry_1, JournalEntry)
    assert len(journal_entry_1.postings) == 1
    assert isinstance(journal_entry_1.postings[0], Posting)
    assert journal_entry_1.postings[0].date == var_1
    assert journal_entry_1.postings[0].account == var_2

# Generated at 2022-06-26 00:36:43.365366
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_0.post(var_0, var_0, var_0)

# Generated at 2022-06-26 00:36:46.121151
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    assertRaises(AssertionError, journal_entry_0.validate)
    assertEquals(journal_entry_0.validate.__doc__, None)

# Generated at 2022-06-26 00:36:53.222288
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_0.validate()
    assert journal_entry_0.increments() != journal_entry_0
    assert journal_entry_0.increments() == journal_entry_0.increments()
    assert journal_entry_0.increments() != journal_entry_0.debits()
    assert journal_entry_0.increments() == journal_entry_0.increments()


# Generated at 2022-06-26 00:37:01.298255
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    import datetime

    from dataclasses import asdict

    from ..commons.numbers import Sum

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    test_case_0 = JournalEntry(date=datetime.date(2019, 1, 11), description='', source=None)
    test_case_0.post(date=datetime.date(2019, 1, 11), account=Account(code='', name='', type=AccountType.LIABILITIES), quantity=Sum(amount=10, quantity=1))
    test_case_0.post(date=datetime.date(2019, 1, 11), account=Account(code='', name='', type=AccountType.REVENUES), quantity=Sum(amount=5, quantity=1))

# Generated at 2022-06-26 00:37:04.275150
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = None
    journal_entry_0 = JournalEntry(None, None, None)
    for i in range(0, 10):
        journal_entry_0.post(None, account_0, i)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:09.236538
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = JournalEntry(datetime.date(2020, 3, 26), "", "")
    var_1 = datetime.date(2020, 3, 26)
    var_2 = Account("", AccountType.ASSETS)
    var_3 = Quantity(100)
    var_0.post(var_1, var_2, var_3)
    journal_entry_0 = var_0
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:10.878823
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    def f0(_x):
        return None

    x = ReadJournalEntries()
    x.__call__(f0)

# Generated at 2022-06-26 00:38:26.378124
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(datetime.datetime.now().year, datetime.datetime.now().month, datetime.datetime.now().day)
    source = None
    journal_entry_0 = JournalEntry(date, 'test', source)
    account = Account(1, 'name', 'bank', AccountType.ASSETS, True)

    assert journal_entry_0.post(var_9, var_10, 10).validate() != None
    assert journal_entry_0.post(var_9, var_10, -10).validate() != None

# Generated at 2022-06-26 00:38:34.621074
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Unit test for method post of class JournalEntry
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    # If the quantity is 0, nothing is posted
    var_1 = Amount(0)
    journal_entry_0.post(var_1, var_0, var_1)

    assert len(journal_entry_0.postings) == 0
    # When quantity is positive, an increment event is posted
    var_2 = Direction.INC
    var_3 = Amount(1)
    journal_entry_0.post(var_1, var_0, var_3)
    assert journal_entry_0.postings[0].direction is var_2

    # When quantity is negative, a decrement event is posted
    var_2 = Direction.DEC
   

# Generated at 2022-06-26 00:38:35.160933
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:37.857642
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Initialize
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    # Execute the method
    journal_entry_0.validate()
    # Check the result
    assert True

# Generated at 2022-06-26 00:38:41.769670
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    var_1 = DateRange(var_0, var_0)
    var_2 = None
    var_3 = ReadJournalEntries.__call__(var_2, var_1)
    var_4 = None
    var_5 = ReadJournalEntries.__call__(var_4, var_1)


# Generated at 2022-06-26 00:38:46.369055
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    var_0 = JournalEntry("Monkey", "Monkey", "Monkey")
    var_1 = datetime.date(1, 1, 1)
    var_2 = Account("Monkey", AccountType.ASSETS)
    var_3 = 1
    JournalEntry("Monkey", "Monkey", "Monkey").post(var_1, var_2, var_3)

# Generated at 2022-06-26 00:38:49.252941
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError: ', e.args)
    else:
        raise Exception('Exception not raised')

# Generated at 2022-06-26 00:38:51.302194
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    var_0 = None
    journal_entry_0 = JournalEntry(var_0, var_0, var_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:51.790814
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-26 00:38:58.437162
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    def case_0():
        var_0 = "A"
        var_1 = datetime.date(2020, 7, 19)
        var_2 = datetime.date(2020, 7, 19)
        var_3 = datetime.date(2020, 7, 19)
        var_4 = "B"
        var_5 = None
        var_6 = Account("C", AccountType.EQUITIES)
        var_7 = Amount(1)
        var_8 = Amount(1)
        var_9 = Amount(1000)
        var_10 = Amount(1000)
        var_11 = Amount(1000)
        var_12 = Amount(1000)
        var_13 = Amount(1)
        var_14 = Amount(1)
        var_15 = Amount(1000)
        var_16 = Amount(1000)