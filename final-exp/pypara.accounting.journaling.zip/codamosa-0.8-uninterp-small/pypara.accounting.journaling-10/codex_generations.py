

# Generated at 2022-06-26 00:31:06.534233
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_7 = datetime.date()


# Generated at 2022-06-26 00:31:11.857992
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    quantity_0 = Quantity()
    account_0 = Account(AccountType.EQUITIES, "EQUITIES")
    journalentry_0 = JournalEntry()
    journalentry_0.post(date_0, account_0, quantity_0)

    assert journalentry_0.post(date_0, account_0, quantity_0) is journalentry_0


# Generated at 2022-06-26 00:31:21.688002
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from commons import numbers as module_0
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from commons import numbers as module_1
    from commons import others as module_2
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass
    from dataclasses import dataclass


# Generated at 2022-06-26 00:31:29.082120
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date(1904, 9, 19)
    date_1 = datetime.date(1935, 12, 15)
    date_2 = datetime.date(1916, 12, 5)
    date_3 = datetime.date(1948, 5, 28)
    date_4 = datetime.date(2001, 5, 7)
    date_5 = datetime.date(1919, 7, 25)
    date_6 = datetime.date(1957, 11, 4)
    date_7 = datetime.date(1993, 12, 17)
    date_8 = datetime.date(2004, 8, 24)
    date_9 = datetime.date(1985, 3, 6)
    date_10 = datetime.date(1909, 12, 8)

# Generated at 2022-06-26 00:31:30.356588
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass # The implementations of this type assign variable guid to self.guid, which should be validated.

# Generated at 2022-06-26 00:31:34.093070
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange(date_0, date_0)

    # Test case 1
    # Test if the function throws expected exceptions
    with raises(TypeError):
        def func(period):
            raise TypeError()
        func(period_0)



# Generated at 2022-06-26 00:31:41.670654
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime as module_0
    date_0 = module_0.date()
    import QuickBooks.accounts as module_1
    account_0 = module_1.Account.find()
    journallentry_0 = JournalEntry()
    journallentry_0.post(date_0, account_0, 0)
    module_0.date()
    module_1.Account.find()


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-26 00:31:45.120601
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry()
    date_0 = datetime.date()
    account_0 = Account()
    quantity_0 = Quantity()
    journal_entry_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:31:47.338958
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date()
    obj_0 = JournalEntry()(date_0, "", object())
    obj_0.validate()

# Generated at 2022-06-26 00:31:56.183998
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date()
    date_1 = datetime.date()
    date_2 = datetime.date()
    date_3 = datetime.date()
    date_4 = datetime.date()
    date_5 = datetime.date()
    date_6 = datetime.date()
    date_7 = datetime.date()
    date_8 = datetime.date()
    date_9 = datetime.date()
    date_10 = datetime.date()
    date_11 = datetime.date()
    date_12 = datetime.date()
    date_13 = datetime.date()
    date_14 = datetime.date()
    date_15 = datetime.date()
    date_16 = datetime.date()
    date_17 = datetime.date()
   

# Generated at 2022-06-26 00:32:08.493943
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = '0%NP#4)'
    bytes_0 = b'\xc8\x8b/\xf7'
    journal_entry_0 = JournalEntry(date_0, str_0, bytes_0)
    journal_entry_0.validate()
    date_1 = datetime.date(1988, 9, 15)
    date_2 = datetime.date(1988, 9, 15)
    date_3 = datetime.date(1988, 9, 15)
    date_4 = datetime.date(1988, 9, 15)
    date_5 = datetime.date(1988, 9, 15)
    account_0 = Account(date_1, str_0, (False, True))

# Generated at 2022-06-26 00:32:09.396552
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:32:17.573799
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ')XnB`+'
    date_range_0 = DateRange(str_0)
    iterable_0 = (journal_entry_1 for journal_entry_1 in ((journal_entry_0) for journal_entry_0 in (date_0 for date_0 in ())) for journal_entry_2 in iterable_0 for account_0 in iterable_0 for direction_0 in iterable_0 for quantity_0 in iterable_0 for str_1 in (account_0,) for datetime_date_0 in (date_0,) for direction_1 in (direction_0,) for str_2 in (None,) for str_3 in (str_2,) for guid_0 in (makeguid(),))
    read_journal_entries_0 = ReadJournalEntries()
    iterable_1 = read_journal

# Generated at 2022-06-26 00:32:26.562436
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = '9ym\x02\xd8'
    guid_0 = None
    guid_1 = Guid(guid_0)
    journal_entry_0 = JournalEntry(date_0, str_0, guid_1)
    date_1 = None
    ## Create an account:
    account_0 = Account(AccountType.ASSETS)
    quantity_0 = 0
    journal_entry_0.post(date_1, account_0, quantity_0)

if __name__ == "__main__":
    test_JournalEntry_post()

# Generated at 2022-06-26 00:32:33.315453
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'q=&J(T'
    bytes_0 = b'E\x1d\x81'
    journal_entry_0 = JournalEntry(date_0, str_0, bytes_0)
    from itertools import repeat
    assert ReadJournalEntries( repeat(journal_entry_0) )(Daterange.from_date(date_0)) == ( journal_entry_0 for i in range(0) )


# Generated at 2022-06-26 00:32:44.689299
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(1986, 12, 26)
    date_1 = None
    account_0 = Account(date_0, date_1, date_1, date_1)
    date_2 = datetime.date(1917, 1, 14)
    date_3 = datetime.date(1945, 3, 18)
    account_1 = Account(date_2, date_3, date_3, date_3)
    quantity_0 = Amount(8)
    journal_entry_0 = JournalEntry(date_0, str_0, bytes_0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    quantity_1 = Quantity(0)
    journal_entry_0.post(date_0, account_1, quantity_1)
    journal_entry_

# Generated at 2022-06-26 00:32:45.588446
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "Test not implemented."


# Generated at 2022-06-26 00:32:54.958724
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(year=1949, month=9, day=21)
    date_1 = datetime.date(year=1949, month=9, day=22)
    str_0 = 'Pn}rj]T&'
    int_0 = 514745462
    account_0 = Account(str_0, int_0)
    quantity_0 = Quantity(1703409098)
    boolean_0 = True
    boolean_1 = True
    journal_entry_0 = JournalEntry(date_0, str_0, bytes_0)
    journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_0.validate()
    journal_entry_1 = JournalEntry(date_0, str_0, bytes_0)
    journal

# Generated at 2022-06-26 00:33:01.545588
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(1972, 4, 7)
    str_0 = '&qHLt\x1c'
    bytes_0 = b'\x04\x0e$\x1a'
    journal_entry_0 = JournalEntry(date_0, str_0, bytes_0)

    date_1 = datetime.date(1989, 2, 17)
    account_1 = Account(AccountType.EXPENSES, 'n@BZ\x10\x0fy\x14')
    quantity_1 = -67.3636228989845
    journal_entry_0.post(date_1, account_1, quantity_1)

    date_1 = datetime.date(1989, 2, 17)

# Generated at 2022-06-26 00:33:06.468257
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(year=1984, month=4, day=29)
    date_1 = datetime.date(year=1996, month=12, day=23)
    amount_0 = Amount(quantity=-12009)
    amount_1 = Amount(quantity=2)
    account_0 = Account(name='', type=AccountType.ASSETS)
    quantity_0 = Quantity(value=0)
    journal_entry_0 = JournalEntry(date_0, str_0, bytes_0)
    journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_0

# Generated at 2022-06-26 00:33:18.969671
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.datetime(year=1973, month=11, day=19)
    str_0 = '`e*'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_0 = datetime.datetime(year=1977, month=12, day=31)
    account_0 = Account(';+', AccountType.ASSETS)
    quantity_0 = Decimal('-8.636E+9')
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()

# vim: et:ts=4:sw=4:tw=79:fdm=indent

# Generated at 2022-06-26 00:33:24.808375
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    period = DateRange(date_0, date_0)
    iterable_0 = journal_entry_0
    read_journal_entries_0 = lambda period: iterable_0
    iterable_1 = read_journal_entries_0(period)


# Generated at 2022-06-26 00:33:34.366238
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date.today()
    date_1 = datetime.date.today()
    date_2 = datetime.date.today()
    date_range_0 = DateRange(date_1, date_2)
    str_0 = 'T@o'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    str_1 = 'b'
    journal_entry_1 = JournalEntry(date_0, str_1, date_0)
    account_0 = Account('j.N', AccountType.EQUITIES)
    amount_0 = Amount(0)
    amount_1 = Amount(1)
    direction_0 = Direction.INC
    direction_1 = Direction.DEC

# Generated at 2022-06-26 00:33:44.091897
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime

    date_0 = datetime.date(1, 1, 1)
    str_0 = 'p{=1#'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = datetime.date(1, 1, 1)
    date_2 = datetime.date(1, 1, 1)
    str_1 = 'fR!$'
    date_3 = datetime.date(1, 1, 1)
    date_4 = datetime.date(1, 1, 1)
    str_2 = 'fR!$'
    account_0 = Account(date_2, str_1, AccountType.ASSETS)
    account_1 = Account(date_4, str_2, AccountType.EQUITIES)
    Amount_0

# Generated at 2022-06-26 00:33:44.698803
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()



# Generated at 2022-06-26 00:33:54.711514
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_1 = datetime.date(1976, 5, 23)
    date_2 = datetime.date(1941, 9, 23)
    str_1 = 'N>C'
    int_0 = 0
    journal_entry_1 = JournalEntry(date_1, str_1, date_1)
    account_0 = Account(str_1, AccountType.ASSETS)
    journal_entry_1.post(date_1, account_0, int_0)
    account_1 = Account(str_1, AccountType.EXPENSES)
    Direction_0 = Direction.DEC
    journal_entry_1.post(date_1, account_1, int_0)
    account_2 = Account(str_1, AccountType.REVENUES)
    Direction_1 = Direction.INC
    journal_entry_

# Generated at 2022-06-26 00:34:04.466647
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    account_0 = Account(str_0, int_0)
    total_debit = 0
    total_credit = 0
    str_0 = 'y#`zTu'
    str_1 = 'Ow4.\x7fg'
    journal_entry_0 = JournalEntry(date_0, str_1, str_0)
    journal_entry_1 = JournalEntry(date_0, str_1, str_0)
    journal_entry_1.post(datetime.date.today(), account_0, 1)
    date_range_0 = DateRange.current_year()
    date_range_1 = DateRange.current_year()
    account_1 = Account(str_0, int_0)
    account_0 = Account(str_0, int_0)


# Generated at 2022-06-26 00:34:07.413627
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'KeIyw'
    date_0 = datetime.date(19, 1, 14)
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    ReadJournalEntries.__call__(journal_entry_0, None)

# Generated at 2022-06-26 00:34:16.033534
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(1970,11,14)
    str_0 = 'i,4HX'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()

    account_0 = Account('GbzS,', AccountType.ASSETS)
    journal_entry_1 = JournalEntry(date_0, str_0, date_0)
    journal_entry_1.post(date_0, account_0, -90301929)

    journal_entry_1.validate()
    assert journal_entry_1.postings[0].amount == Amount(90301929)

# Generated at 2022-06-26 00:34:26.220860
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = '^l4'
    date_1 = datetime.date.today()
    str_1 = 'hjK>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_1 = JournalEntry(date_1, str_1, date_0)
    journal_entry_1.post(date_0, None, 0)
    journal_entry_1.post(None, None, -70)
    journal_entry_1.post(date_0, None, -5)
    journal_entry_1.post(date_0, None, 56)
    journal_entry_1.post(date_0, None, 56)
    journal_entry_1.validate()

# Generated at 2022-06-26 00:34:48.924081
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    def read_journal_entries_0(period: DateRange) -> Iterable[JournalEntry[DateRange]]:
        return iter([journal_entry_0])
    period_0 = DateRange(date_0, date_0)
    for i in read_journal_entries_0(period_0):
        i


# Generated at 2022-06-26 00:34:55.604532
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(2016, 3, 1)
    str_0 = 'z1.\\*aFo^'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    str_1 = ','
    str_2 = '+'
    str_3 = '#83"e'
    date_1 = datetime.date(2015, 12, 2)
    journal_entry_1 = JournalEntry(date_1, str_3, date_1)
    assert_equal(journal_entry_1, journal_entry_0)


# Generated at 2022-06-26 00:35:03.386733
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = None
    journal_entry_1 = JournalEntry(date_1, str_0, date_1)
    list_0 = [journal_entry_1]
    list_1 = []
    assert list_0 != list_1


# Generated at 2022-06-26 00:35:17.441214
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()
    posting_0 = Posting(journal_entry_0, date_0, None, Direction.INC)
    assert posting_0.is_debit == AccountType.INC
    assert posting_0.is_debit != AccountType.INC
    posting_1 = Posting(journal_entry_0, date_0, None, Direction.DEC)
    assert posting_1.is_debit == AccountType.INC
    assert posting_1.is_debit != AccountType.DEC
    journal_entry_1 = journal_entry_0.post(date_0, None, Amount(0))
    journal_entry_1

# Generated at 2022-06-26 00:35:19.519149
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Tests
    test_case_0()

if __name__ == '__main__':
    test_JournalEntry_validate()

# Generated at 2022-06-26 00:35:28.289462
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Instantiate and populate journal entry:
    journal_entry_0 = JournalEntry(date=None, description=None, source=None)
    date_0 = datetime.date(year=2000, month=1, day=1)
    account_0 = Account(name='K>K8', type=AccountType.REVENUES)
    quantity_0 = -30
    journal_entry_0.post(date_0, account_0, quantity_0)
    date_0 = datetime.date(year=2016, month=6, day=1)
    account_1 = Account(name='K>K8', type=AccountType.EXPENSES)
    quantity_1 = -85
    journal_entry_0.post(date_0, account_1, quantity_1)

# Generated at 2022-06-26 00:35:40.457011
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(year=2020, month=8, day=4)
    date_1 = datetime.date(year=2020, month=8, day=2)
    date_2 = datetime.date(year=2020, month=8, day=1)
    account_0 = Account(str_0, AccountType.ASSETS)
    account_1 = Account(str_1, AccountType.EQUITIES)
    str_0 = 'K>K8'
    str_1 = ','
    str_2 = 'QX9'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.post(date_0, account_0, Quantity(1))

# Generated at 2022-06-26 00:35:43.904082
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:35:47.759200
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(Guid(), '', Guid())
    journal_entry_0.post(Guid(), Account(Guid(), Guid(), Guid()), Quantity(-1))
    journal_entry_0.validate()
    return "success"

# Generated at 2022-06-26 00:35:50.601371
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:36:15.529319
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'K>K8'
    account_0 = Account(str_0, AccountType.ASSETS)
    datetime_date_0 = datetime.date(1944, 1, 1)
    journal_entry_0 = JournalEntry(datetime_date_0, str_0, str_0)
    journal_entry_0.post(datetime_date_0, account_0, 1)
    journal_entry_0.validate()
    account_1 = Account(str_0, AccountType.EXPENSES)
    journal_entry_0 = JournalEntry(datetime_date_0, str_0, str_0)
    journal_entry_0.post(datetime_date_0, account_0, -1)
    journal_entry_0.validate()
    journal_entry_0.post

# Generated at 2022-06-26 00:36:16.731023
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert callable(ReadJournalEntries.__call__)


# Generated at 2022-06-26 00:36:26.075208
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    for _ in range(10):
        import random
        import datetime
        from .accounts import AccountType
        from .businessobjects import BusinessObjectType
        from .commons.others import makeguid

        def new_account(account_type: AccountType) -> Account:
            return Account(makeguid(), "Account " + str(random.randint(0, 1000)), account_type)

        def new_journal_entry(business_object_type: BusinessObjectType):
            return JournalEntry(
                datetime.date(random.randint(0, 10000), random.randint(0, 12), random.randint(0, 28)),
                "Description " + str(random.randint(0, 1000)),
                business_object_type,
            )


# Generated at 2022-06-26 00:36:33.378860
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "J_TEST", "J_TEST")
    a = Account("J_TEST", AccountType.ASSETS)
    j.post(datetime.date.today(), a, 100)
    try:
        j.post(datetime.date.today(), a, 100)
    except:
        print("Journal entry must be unique")
    try:
        j.post(datetime.date.today(), a, 100)
    except:
        print("Journal entry must be unique")
    j.validate()


# Generated at 2022-06-26 00:36:37.205293
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Get the class to be tested.
    journal_entry = JournalEntry("hello","world","bye")
    assert journal_entry.guid is not None
    # Uncomment the below lines to test the function.
    # DateRange period()
    #  journal_entry.validate()

# Generated at 2022-06-26 00:36:45.030358
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from .readjournalentries import ReadJournalEntries
    from .readjournalentries import test_case_0
    from .readjournalentries import test_case_1
    from .readjournalentries import test_case_2
    from .readjournalentries import test_case_3
    from .readjournalentries import test_case_4
    from .readjournalentries import test_case_5
    from .readjournalentries import test_case_6
    test_ReadJournalEntries___call__.__annotations__ = {}
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5

# Generated at 2022-06-26 00:36:46.357626
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Test cases for class Direction

# Test cases for method of of class Direction

# Generated at 2022-06-26 00:36:48.250298
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass
    # TODO: Test fails; implement your test here
    #assert False, "Test fails"

# Generated at 2022-06-26 00:36:55.507048
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'K>K8'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account('A', AccountType.ASSETS)
    date_0 = datetime.date(1, 1, 1)
    amount_0 = Amount(1000)
    journal_entry_0.post(date_0, account_0, amount_0)
    account_1 = Account('B', AccountType.ASSETS)
    journal_entry_0.post(date_0, account_1, -amount_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:00.238048
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source = 'K>K8'
    journal_entry_0 = JournalEntry(datetime.date(2018, 1, 3), source, source)
    journal_entry_0.validate()
    account_0 = Account(name = "Account_0" , account_type = 0, balance = 100)
    journal_entry_0.post(datetime.date(2018, 2, 4), account_0, 0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:46.230931
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journalEntries = ReadJournalEntries(
        JournalEntry("date",      # date of journal entry
                     "description of journal entry",    # description of journal entry
                     "source of journal entry"),        # source of journal entry
        [Posting("journal entry", "date of posting", "account", "direction", "amount")]) # postings of journal entry
    pass


    def test__post(self):
        pass

# Generated at 2022-06-26 00:37:49.149727
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Test for method __call__
    """
    r = ReadJournalEntries()
    r.__call__(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 1, 2)))

# Generated at 2022-06-26 00:37:56.020488
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

test_case_0()

# Generated at 2022-06-26 00:37:57.087630
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_case_0()

# Generated at 2022-06-26 00:38:03.494594
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'K>K8'
    Account_0 = Account(str_0, str_0)
    DateRange_0 = DateRange(str_0)
    from ..data.values import *
    Amount_0 = Amount(str_0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1 = journal_entry_0.post(str_0, Account_0, DateRange_0)
    journal_entry_1.validate()


# Generated at 2022-06-26 00:38:04.006899
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-26 00:38:09.173561
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account('AASDF', AccountType.ASSETS)
    journal_entry_0 = JournalEntry('account_0', 'account_0', 'account_0')
    journal_entry_0.post(datetime.date.today(), account_0, 1)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:13.184712
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '~=gKO'
    from .accounts import Account
    # Test Case 0:
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, Account(str_0, str_0), 1)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:38:18.712538
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # create a JournalEntry instance
    journal_entry = JournalEntry(1, 'Grand Total', None)
    assert len(journal_entry.postings) == 0
    # assert the post method is working
    journal_entry.post(datetime.date(2018, 11, 28), 'A', 1)
    assert len(journal_entry.postings) == 1
    assert journal_entry.postings[0] == Posting(journal_entry, datetime.date(2018, 11, 28), 'A', Direction.INC, 1)



# Generated at 2022-06-26 00:38:26.431752
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest

    class ReadJournalEntriesImpl(ReadJournalEntries[str]):
        def __init__(self, entries: Iterable[JournalEntry[str]]):
            self.entries = entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            pass

    class ReadJournalEntriesTest(unittest.TestCase):
        def setUp(self):
            self.impl = ReadJournalEntriesImpl([])

    unittest.main()


if __name__ == "__main__":
    test_case_0()
    test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:39:07.813416
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # setup
    date_0 = datetime.date(2020, 5, 9)
    account_0 = Account('', '')
    quantity_0 = 1
    journal_entry_0 = JournalEntry(date_0, '', '')
    journal_entry_1 = journal_entry_0.post(date_0, account_0, quantity_0)
    # assert
    assert journal_entry_1 is journal_entry_0


# Generated at 2022-06-26 00:39:10.887459
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Y8Y'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_1 = Account(str_0, AccountType.ASSETS)
    journal_entry_0 = journal_entry_0.post(datetime.date(2018, 1, 1), account_1, -1)
    assert journal_entry_0.postings[0].account == account_1


# Generated at 2022-06-26 00:39:14.224125
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create JournalEntry
    journal_entry_0 = JournalEntry('K>K8', 'K>K8', 'K>K8')
    # Create Account
    account_0 = Account('C4^(4AL')
    # Create Date
    # Call method post
    journal_entry_0.post(account_0, 4)
    # Evaluate Assertion
    assert journal_entry_0.postings[0].account == account_0

# Generated at 2022-06-26 00:39:19.633860
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '1.0'
    account_0 = Account(AccountType.REVENUES, str_0, str_0)
    journal_entry_0 = JournalEntry('eU\\', str_0, ')k')
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    journal_entry_2 = JournalEntry('zv(', str_0, str_0)
    journal_entry_2.post(datetime.date(2019, 6, 20), account_0, 1)
    journal_entry_2.validate()
    journal_entry_1.post(datetime.date(2019, 6, 20), account_0, 1)
    journal_entry_1.validate()

# Generated at 2022-06-26 00:39:20.079534
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:39:24.434305
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'S>S8'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account = Account(str_0, str_0, str_0, str_0, str_0)
    date = datetime.date(2018, 10, 4)
    journal_entry_0.post(date, account, Quantity(531))
    journal_entry_0.post(date, account, Quantity(0))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:39:26.024064
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call__(self, period):
        pass

    r = ReadJournalEntries
    r.__call__ = __call__
    assert True

# Generated at 2022-06-26 00:39:27.924525
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'Ny!N'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:39:28.786688
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test cases for method __call__ of class ReadJournalEntries
    return

# Generated at 2022-06-26 00:39:33.241861
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'F(FX'
    str_1 = 'a!X^'
    def f(x: DateRange) -> Iterable[JournalEntry[None]]:
        y: DateRange
        for y in x:
            y.load()
            yield y
        return y
    read_journal_entries_0 = f
    read_journal_entries_0(str_0, str_1)
    read_journal_entries_0(str_1, str_1, str_1, str_1)


# Generated at 2022-06-26 00:40:27.655920
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test a simple case
    journal_entry_0 = JournalEntry(datetime.date(1,1,1), "description", "source", [])
    account_0 = Account("name", "type", "currency")
    journal_entry_0.post(datetime.date(1,1,1), account_0, 1000)
    journal_entry_0.validate()

    # Test a more complex case
    journal_entry_1 = JournalEntry(datetime.date(1,1,1), "description", "source", [])
    account_1 = Account("name", "type", "currency")
    journal_entry_1.post(datetime.date(1,1,1), account_1, 1000)
    journal_entry_1.post(datetime.date(1,1,1), account_1, -1000)

# Generated at 2022-06-26 00:40:31.269718
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    d1 = datetime.date(2000, 1, 1)
    d2 = datetime.date(2001, 1, 1)

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [JournalEntry('a', 'b', 'c')]

    res = read_journal_entries(DateRange(start=d1, end=d2))
    assert all(type(e) == JournalEntry for e in res)

# Generated at 2022-06-26 00:40:33.427479
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    debit_posting = Posting(None, None, None, Direction.DEC, None)
    JournalEntry.post(None, None, None)
    assert Posting.is_debit(debit_posting)  == True
    assert Posting.is_credit(debit_posting) == False

# Generated at 2022-06-26 00:40:41.866738
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_t = 'K>K8'
    acct_0 = Account(AccountType.EQUITIES, str_t)
    acct_1 = Account(AccountType.ASSETS, str_t)
    acct_2 = Account(AccountType.REVENUES, str_t)
    acct_3 = Account(AccountType.EXPENSES, str_t)
    journal_entry_t = JournalEntry(str_t, str_t, str_t)
    journal_entry_t.post(datetime.datetime.today(), acct_0, Quantity(1))
    journal_entry_t.post(datetime.datetime.today(), acct_1, Quantity(1))
    journal_entry_t.post(datetime.datetime.today(), acct_2, Quantity(1))
    journal_entry

# Generated at 2022-06-26 00:40:50.476747
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .currencies import Currency

    cash_account_argentine_peso = Account('Cash Argentine Peso', 'Assets', 'AR', Currency.ARS)
    cash_account_euro = Account('Cash Euro', 'Assets', 'EU', Currency.EUR)
    electricity_expense_account = Account('Electricity Expense', 'Expense', 'EE', Currency.EUR)
    revenue_account = Account('Revenue', 'Revenue', 'RV', Currency.EUR)

    journal_entry_string = 'K>K6'
    journal_entry = JournalEntry(journal_entry_string, journal_entry_string, journal_entry_string)


# Generated at 2022-06-26 00:40:54.104688
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry('test_JournalEntry_post', 'test_JournalEntry_post', 'test_JournalEntry_post')
    journal_entry.post(datetime.date(2020, 7, 3), Account('test', 'test', 'test', AccountType.ASSETS), 1.0)
