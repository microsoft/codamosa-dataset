

# Generated at 2022-06-26 00:31:05.680178
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_1 = module_0.date()
    quantity_0 = Quantity()
    account_0 = Account()
    journalentry_0 = JournalEntry()
    journalentry_0.post(date_1, account_0, quantity_0)


# Generated at 2022-06-26 00:31:11.277294
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = module_0.date()
    def test_function_0(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return JournalEntry[str]
    value_of_parameter_0 = DateRange(date_0, date_0)
    test_object_0 = ReadJournalEntries.__call__(test_function_0, value_of_parameter_0)

# Generated at 2022-06-26 00:31:14.301244
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # FIXME: Generate the DateRange with random data
    period_0 = DateRange()

    # Test case with the test document 'data/governance/journal.json'
    # FIXME:
    assert(True)

# Generated at 2022-06-26 00:31:23.532442
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # Input parameters:
    date_0 = date()
    date_1 = date()
    date_2 = date()
    date_3 = date()

    # Output parameters:
    journal_0 = JournalEntry()
    journal_1 = JournalEntry()
    journal_2 = JournalEntry()
    journal_3 = JournalEntry()
    journal_4 = JournalEntry([])

    # Constraints:
    journal_0 = journal_0
    journal_1 = journal_1
    journal_2 = journal_2
    journal_3 = journal_3
    journal_4 = journal_4

    assert journal_0
    assert journal_1
    assert journal_2
    assert journal_3
    assert journal_4


# Generated at 2022-06-26 00:31:34.052471
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    date_4 = module_0.date()
    date_5 = module_0.date()
    date_6 = module_0.date()
    date_7 = module_0.date()
    date_8 = module_0.date()
    date_9 = module_0.date()
    date_10 = module_0.date()
    date_11 = module_0.date()
    date_12 = module_0.date()
    date_13 = module_0.date()
    date_14 = module_0.date()
    date_15 = module_0.date()
    date_16 = module_

# Generated at 2022-06-26 00:31:41.244047
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import AssetAccount, EquityAccount
    from .journal_entries import JournalEntry, Posting
    from datetime import date
    je = JournalEntry(date(2020, 1, 1), "Sample journal entry", None, [
        Posting(je, date(2020, 1, 1), AssetAccount("A"), Direction.INC, 100000),
        Posting(je, date(2020, 1, 1), EquityAccount("B"), Direction.DEC, 100000),
    ])
    je.validate()

# Generated at 2022-06-26 00:31:47.383838
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    journalentry_0 = JournalEntry()
    account_0 = Account()
    journalentry_0.post(date_0, account_0, 10)
    account_1 = Account()
    journalentry_0.post(date_0, account_1, -10)
    journalentry_0.validate()

# Generated at 2022-06-26 00:31:56.220610
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_0 = JournalEntry()
    #  OFFSET_1
    date_0 = datetime.date(2019, 12, 1)
    #  OFFSET_2
    description_0 = "Posting description"
    #  OFFSET_3
    account_0 = Account("Account")
    #  OFFSET_4
    quantity_0 = Quantity(-10)
    #  OFFSET_5
    account_1 = Account("Account")
    #  OFFSET_6
    quantity_1 = Quantity(10)
    #  OFFSET_7
    account_2 = Account("Account")
    #  OFFSET_8
    quantity_2 = Quantity(10)
    #  OFFSET_9
    account_3 = Account("Account")
    #  OFFSET_10
    quantity

# Generated at 2022-06-26 00:31:59.233508
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange()

    journal_0 = JournalEntry[None]()

    journal_0.__call__(period_0)

# Generated at 2022-06-26 00:32:02.149147
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date()
    account_0 = Account()
    quantity_0 = Quantity()
    journal_entry_0 = JournalEntry()
    journal_entry_0.validate()


# Generated at 2022-06-26 00:32:07.995498
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry = JournalEntry()
    journal_entry.validate()


# Generated at 2022-06-26 00:32:11.230017
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_0 = JournalEntry()
    date_0 = datetime.date()
    account_0 = Account()
    quantity_0 = Quantity()
    journal_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:32:13.166249
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # TODO: Implement unit test for method __call__ of class ReadJournalEntries
    pass

import datetime as module_0


# Generated at 2022-06-26 00:32:15.145010
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = module_0.date()
    JournalEntry().post(date_0,Account(),Quantity()).validate()


# Generated at 2022-06-26 00:32:27.448006
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    account_0 = Account(0, '', '', AccountType.ASSETS)
    account_1 = Account(0, '', '', AccountType.REVENUES)
    account_2 = Account(0, '', '', AccountType.EQUITIES)
    account_3 = Account(0, '', '', AccountType.EXPENSES)
    j = JournalEntry(date_0, '', 0)
    j.post(date_1, account_0, 1)
    j.post(date_2, account_1, -1.0)
    j.post(date_3, account_2, 1.0)


# Generated at 2022-06-26 00:32:31.314358
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    _T = TypeVar("_T")
    period = DateRange

    # Code coverage for ReadJournalEntries.__call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
    assert True

# Generated at 2022-06-26 00:32:42.282552
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    date_4 = module_0.date()
    date_5 = module_0.date()
    date_6 = module_0.date()
    date_7 = module_0.date()
    date_8 = module_0.date()
    date_9 = module_0.date()
    date_10 = module_0.date()
    date_11 = module_0.date()
    date_12 = module_0.date()
    date_13 = module_0.date()
    date_14 = module_0.date()
    date_15 = module_0.date()
    date_16 = module_

# Generated at 2022-06-26 00:32:52.061536
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    guid_0 = Guid.of(0x0000000000000000)
    guid_1 = Guid.of(0x0000000000000001)
    guid_2 = Guid.of(0x0000000000000002)

    # Create journal entries

# Generated at 2022-06-26 00:32:59.935493
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = module_0.date()
    guid_0 = Guid()
    guid_1 = Guid()
    guid_2 = Guid()
    guid_3 = Guid()
    guid_4 = Guid()
    guid_5 = Guid()
    account_0 = Account(guid_0, "", AccountType.ASSETS)
    account_1 = Account(guid_1, "", AccountType.EQUITIES)
    account_2 = Account(guid_2, "", AccountType.ASSETS)
    account_3 = Account(guid_3, "", AccountType.REVENUES)
    account_4 = Account(guid_4, "", AccountType.EXPENSES)
    account_5 = Account(guid_5, "", AccountType.EQUITIES)

# Generated at 2022-06-26 00:33:08.950547
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    account_0 = Account()
    quantity_0 = Quantity()
    journal_0 = JournalEntry()
    journal_1 = journal_0.post(date_0, account_0, quantity_0)
    assert journal_1 == journal_0


# Generated at 2022-06-26 00:33:19.922743
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import account, AccountType
    #
    # This test is not entirely necessary, so long as we have the one for Journal.validate()
    #
    # It does serve to clarify the intent of method JournalEntry.post(), however.
    #
    # It also serves to verify that it is possible to import the AccountType enum
    # without having to make the common Account class visible.
    #

    #
    # Arrange
    #
    # An income account
    revenue = account("Unattributed revenue", AccountType.REVENUES)

    # A zero-quantity
    zero = 0

    # Two positive quantities
    positive1 = 1
    positive2 = 2

    # Two negative quantities
    negative1 = -1
    negative2 = -2
    #
    # Act
    #

# Generated at 2022-06-26 00:33:29.705239
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass, field
    from typing import List

    from .accounts import Account, AccountType
    from .products import Product, ProductFamily, ProductType

    ## Data definitions:
    @dataclass(frozen=True)
    class BusinessObject:
        """
        Declares a business object.
        """

        pass

    @dataclass(frozen=True)
    class Purchase:
        """
        Declares a purchase of a product.
        """

        date: datetime.date

        product: Product

        quantity: Quantity

        def __post_init__(self) -> None:
            self.product: Product = cast(Product, self.product)


# Generated at 2022-06-26 00:33:37.988834
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry = JournalEntry(datetime.date.today(),
                                 "Test entry",
                                 "source",
                                 )

    journal_entry.post(datetime.date.today(),
                       Account("debit_account", AccountType.ASSETS),
                       100)
    journal_entry.post(datetime.date.today(),
                       Account("credit_account", AccountType.ASSETS),
                       100)

    journal_entry.validate()

    journal_entry.post(datetime.date.today(),
                       Account("credit_account", AccountType.ASSETS),
                       100)

    try:
        journal_entry.validate()
        assert False, "Should raise an AssertionError"
    except AssertionError:
        pass

# Generated at 2022-06-26 00:33:48.387474
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountManager
    from .currencies import CurrencyManager

    am = AccountManager(["Assets:Bank:Checking", "Assets:Bank:Savings", "Expenses:Itemized:Food"])

    cm = CurrencyManager.from_transient_data(
        [
            ["Default", "USD", "United States Dollar", 1.0, ["USD", "US$"]],
            ["Default", "CAD", "Canadian Dollar", 1.35, ["CAD", "CA$"]],
        ]
    )

    j1 = JournalEntry[None](datetime.date(2019, 1, 1), "This is the description", None)
    j1.post(datetime.date(2019, 1, 1), am.get_account("Assets:Bank:Checking"), Quantity(100))

# Generated at 2022-06-26 00:33:54.199848
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    with pytest.raises(AssertionError):
        JournalEntry(
            datetime.date.today(),
            "Z-Test Journal Entry",
            None,
        ) \
            .post(datetime.date.today(), Account("1100", "Cash", AccountType.ASSETS), -1000) \
            .post(datetime.date.today(), Account("2100", "Accounts Receivable", AccountType.ASSETS), 1000) \
            .validate()


# Generated at 2022-06-26 00:34:04.039166
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import get_equity_account
    from .contacts import Contact
    from .invoice import get_invoice_account
    from .receipt import get_receipt_account
    from .transaction import get_transaction_account

    ACCOUNTS = {
        "Equity": get_equity_account,
        "Invoice": get_invoice_account,
        "Receipt": get_receipt_account,
        "Transaction": get_transaction_account,
    }

    def _make(start_at, end_at):
        def _read(period):
            assert period.start_at == start_at
            assert period.end_at == end_at
            return []

        return _read


# Generated at 2022-06-26 00:34:10.645803
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a_account = Account(name='a', type=AccountType.ASSETS)
    b_account = Account(name='b', type=AccountType.EXPENSES)
    c_account = Account(name='c', type=AccountType.LIABILITIES)
    source = "source"
    date = datetime.date.today()
    description = "description"

    entry = JournalEntry[str](date=date, description=description, source=source)
    entry.post(date, a_account, Quantity(100))
    entry.post(date, b_account, Quantity(-50))
    entry.post(date, c_account, Quantity(50))

    assert len(entry.postings) == 3
    assert any(posting.account == a_account for posting in entry.postings)

# Generated at 2022-06-26 00:34:14.232961
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f(period: DateRange) -> Iterable[JournalEntry[int]]:
        pass

    # noinspection PyUnresolvedReferences
    test_ReadJournalEntries___call__.var = f

    # Test is not required because the type checker can perform type checking of the function.
    pass

# Generated at 2022-06-26 00:34:24.476303
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Callable

    from .lib.dummy import Dummy, DummyJournalEntries

    dummy_source: Callable[[DateRange], Iterable[JournalEntry[Dummy]]] = lambda period: iter(())
    assert dummy_source(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 1))) == ()

    dummy_source = DummyJournalEntries(
        JournalEntry[Dummy](datetime.date(2020, 1, 1), "A", Dummy(), []).post(datetime.date(2020, 1, 1), "D1", 1000),
        JournalEntry[Dummy](datetime.date(2020, 1, 1), "B", Dummy(), []).post(datetime.date(2020, 1, 1), "C1", -500),
    )
    assert dummy_

# Generated at 2022-06-26 00:34:27.288029
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    je = JournalEntry("test").post("2020-01-01", Account("Assets", AccountType.ASSETS), 100)

    print(je)
    je.validate()

# Generated at 2022-06-26 00:34:52.760134
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(1, 1, 1)
    date_1 = datetime.date(1, 1, 1)
    str_0 = 'NL365'
    account_2 = Account(str_0, AccountType.ASSETS)

# Generated at 2022-06-26 00:34:56.579591
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, 1)
    journal_entry_0.validate()
    str_1 = 'Test : Asset A'
    account_1 = Account(str_1, AccountType.ASSETS)
    journal_entry_0.post(date_0, account_1, -1)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:07.920153
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    int_0 = 25
    int_1 = 12
    int_2 = -23
    account_0 = Account(int_0, int_1, int_2)
    int_3 = 34
    int_4 = -29
    int_5 = -23
    account_1 = Account(int_3, int_4, int_5)
    int_6 = -12
    int_7 = -39
    int_8 = -3
    account_2 = Account(int_6, int_7, int_8)
    int_9 = 52
    int_10 = 18
    int_11 = -23

# Generated at 2022-06-26 00:35:12.116652
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(1, 1, 1)
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    def _ReadJournalEntries___call___0(period):
        for _ in range(0, 2 + 1):
            yield journal_entry_0
    period = DateRange(date_0, date_0)
    actual: Iterable[JournalEntry] = _ReadJournalEntries___call___0(period)
    expected: Iterable[JournalEntry] = set([journal_entry_0, journal_entry_0, journal_entry_0])
    assert actual == expected


# Generated at 2022-06-26 00:35:14.288165
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_0 = None
    def test_function_0() -> Iterable[JournalEntry[_T]]:
        return [journal_entry_0]
    def test_function_1() -> Iterable[JournalEntry[_T]]:
        return [journal_entry_0]
    t = test_function_0
    t = test_function_1



# Generated at 2022-06-26 00:35:16.861517
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    print("Testing method validate of class JournalEntry ... ", end="")
    test_case_0()
    print("PASSED")

# Generated at 2022-06-26 00:35:25.656937
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = datetime.date(2017, 5, 9)
    str_1 = 'CARD'
    account_0 = Account(str_1, AccountType.ASSETS)
    int_1 = -1709
    quantity_0 = Quantity(int_1)
    journal_entry_0.post(date_1, account_0, quantity_0)


if __name__ == '__main__':
    test_case_0()
    test_JournalEntry_post()

# Generated at 2022-06-26 00:35:32.638559
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = None
    integer_0 = 1
    account_0 = Account(None, integer_0, str_0, str_0, integer_0)
    amount_0 = Amount.decimal(1)
    journal_entry_0.post(date_1, account_0, amount_0)



# Generated at 2022-06-26 00:35:44.243097
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-26 00:35:50.984980
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    date = datetime.date
    account = Account
    quantity = Quantity
    journal_entry = JournalEntry(date, str, str)

    journal_entry.post(date, account, quantity)
    # Verify the results.
    assert journal_entry.postings is not None


# Generated at 2022-06-26 00:36:05.401429
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:36:14.409806
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .leases import Lease
    from .leases.payments import Payment
    from .ledgers import Ledger
    from .ledgers.properties import Property
    from .ledgers.properties.rental_units import RentalUnit
    from .ledgers.properties.rental_units.tenancies import Tenancy
    from datetime import date
    str_0 = '7f1'
    date_0 = date(2020, 11, 20)
    date_1 = date(2020, 1, 10)
    account_0 = Account(AccountType.ASSETS, str_0)
    account_1 = Account(AccountType.EXPENSES, str_0)
    account_2 = Account(AccountType.ASSETS, str_0)

# Generated at 2022-06-26 00:36:20.009823
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = None
    account_0 = Account(0.0, str_0, date_1, date_0, date_1, date_0, date_0)
    quantity_0 = 0.0
    journal_entry_0.post(date_0, account_0, quantity_0)

# Generated at 2022-06-26 00:36:25.149292
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    date_range_0 = DateRange.of(date_0, date_0)
    read_journal_entries_0 = None
    read_journal_entries_0.__call__(date_range_0)


# Generated at 2022-06-26 00:36:27.906813
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:38.146602
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(1714, 6, 17)
    date_1 = datetime.date(1831, 5, 19)
    date_2 = datetime.date(1941, 12, 28)
    str_0 = 'S'
    str_1 = 'MkD'
    str_2 = 'J'
    str_3 = 'z'
    str_4 = 'Vx'
    str_5 = '{'
    str_6 = 'UJE'
    str_7 = '3'
    journal_entry_0 = JournalEntry(date_2, str_7, str_1)
    assert_raises(AssertionError, journal_entry_0.validate)
    journal_entry_1 = JournalEntry(date_0, str_7, str_5)
   

# Generated at 2022-06-26 00:36:42.345911
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert callable(JournalEntry.post)
    journal_entry_0 = JournalEntry(None, None, None)
    journal_entry_1 = journal_entry_0.post(datetime.date(2020, 4, 18), None, 1)
    assert journal_entry_0 is journal_entry_1
    assert journal_entry_1.postings[0].amount == Amount(1)


# Generated at 2022-06-26 00:36:48.325448
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_0 = None
    account_0 = Account(str_0, str_0, str_0)
    amount_0 = Amount(1)
    JournalEntry.post(journal_entry_0, date_0, account_0, amount_0)
    JournalEntry.post(journal_entry_0, date_0, account_0, amount_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:49.134121
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:36:58.454364
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def test_function_0():
        # Test unit for __call__ method of class ReadJournalEntries
        from datetime import date
        from typing import Iterable
        from .accounts import Account
        from .journal import JournalEntry
        from .numbers import Amount
        from .others import DateRange
        from .tags import Tag
        # Test body for __call__ method of class ReadJournalEntries
        from .journal import JournalEntry
        from .others import DateRange
        from .tags import Tag
        from .accounts import Account
        from .numbers import Amount
        from typing import Iterable
        date_0 = date()
        str_0 = 'NL365'
        journal_entry_0 = JournalEntry(date_0, str_0, str_0)
        journal_entry_0.validate()

# Generated at 2022-06-26 00:37:21.802971
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'NL100'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, Quantity(2))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:23.655271
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:31.332950
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .commons.zeitgeist import Month
    from .events import JournalEntryCreated, Event

    event_0 = JournalEntryCreated(str_0, str_0, str_0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    asset_0 = Account(str_0, str_0, AccountType.ASSETS)
    amount_0 = Amount.zero()
    date_0 = datetime.date(2000, 1, 1)

    journal_entry_0.post(date_0, asset_0, amount_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:33.556740
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:35.579134
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    with pytest.raises(AssertionError):
        test_case_0()

# Generated at 2022-06-26 00:37:48.647662
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from pytest import raises
    from rflx.expression import Scalar
    from rflx.expression import T, UNDEFINED, Variable

    from tests.common.containers import Journal
    from .accounts import Account, AccountType

    import datetime
    from typing import Dict, Generic, Iterable, TypeVar

    # Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        # Date of the entry.
        date: Scalar

        # Description of the entry.
        description: str

        # Business object as the source of the journal entry.
        source: _T

        # Postings of the journal entry.

# Generated at 2022-06-26 00:37:57.920527
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    a = 'OBNL365'
    b = datetime.date(1949, 10, 18)
    c = datetime.date(2016, 4, 7)
    d = DateRange(b, c)
    e = 'NL365'
    f = JournalEntry(e, e, e)
    g = Iterable[JournalEntry]
    h = g
    return ReadJournalEntries(h)


# Generated at 2022-06-26 00:37:58.742440
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False


# Generated at 2022-06-26 00:38:09.041648
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # 1) Method post shall post an increment event to a given account
    source_1 = "Sina"
    date_1 = datetime.date(2020,3,31)
    journal_entry_1 = JournalEntry(date_1, "Cash received from customer", source_1)
    account_1 = Account('Cash', AccountType.ASSETS)
    journal_entry_1.post(date_1, account_1, Quantity(100))
    assert len(journal_entry_1.postings) == 1
    assert journal_entry_1.postings[0].date == date_1
    assert journal_entry_1.postings[0].account == account_1
    assert journal_entry_1.postings[0].direction == Direction.INC
    assert journal_entry_1.postings[0].amount == Amount(100)


# Generated at 2022-06-26 00:38:10.798353
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call___of_ReadJournalEntries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    pass

# Generated at 2022-06-26 00:38:47.239308
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:38:49.549432
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:38:52.200908
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesStub:
        pass

    # Type check:
    result: Iterable[JournalEntry[str]] = ReadJournalEntriesStub.__call__()

    assert(isinstance(result, Iterable[JournalEntry[str]]))

# Generated at 2022-06-26 00:38:58.781887
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'k'
    str_1 = ':4|q?60{l<`)P\\'
    str_2 = 'e'
    str_3 = 'a'
    str_4 = 'Mk-a;'
    str_5 = 'P'
    str_6 = 'U'
    def func_0(self, date_range: DateRange) -> Iterable[JournalEntry[str]]:
        journal_entry = JournalEntry(str_0, str_1, str_2)
        journal_entry.validate()
        str_10 = 'NL365'
        journal_entry_0 = JournalEntry(str_10, str_10, str_10)
        journal_entry_0.validate()
        return [journal_entry, journal_entry_0]

# Generated at 2022-06-26 00:38:59.223536
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:39:04.927136
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_2 = 'NL365'
    journal_entry_1 = JournalEntry(str_2, str_2, str_2)
    journal_entry_1.validate()
    str_4 = 'NL365'
    journal_entry_2 = JournalEntry(str_4, str_4, str_4)
    journal_entry_2.validate()
    str_6 = 'NL365'
    journal_entry_3 = JournalEntry(str_6, str_6, str_6)
    journal_entry_3.validate()
    str_8 = 'NL365'
    journal_entry_4 = JournalEntry(str_8, str_8, str_8)
    journal_entry_4.validate()
    str_10 = 'NL365'

# Generated at 2022-06-26 00:39:10.429218
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # With a positive quantity
    str_0 = 'NL365'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0 = journal_entry_0.post(datetime.date(2020, 1, 1), Account('Assets'), Quantity(456.0))
    journal_entry_0 = journal_entry_0.post(datetime.date(2020, 1, 2), Account('Income'), Quantity(456.0))
    journal_entry_0.validate()

    # With a negative quantity
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0 = journal_entry_0.post(datetime.date(2020, 1, 1), Account('Equity'), Quantity(-456.0))
    journal_entry

# Generated at 2022-06-26 00:39:11.086729
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:39:13.898765
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry('test','test','test')
    d = datetime.datetime.today().date()
    a = Account('',AccountType.ASSETS,'','','','','','','','','','')
    q = 1
    
    j.post(d,a,q)
    assert j.postings[0].account.type, AccountType.ASSETS

# Generated at 2022-06-26 00:39:14.305208
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:41:02.333723
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .books import Book
    from .control import Controller
    from .transactions import Transaction, TransactionType
    controller_0 = Controller()
    journal_entry_0 = JournalEntry('NL365', 'NL365', 'NL365')
    journal_entry_0.post(datetime.date(2014, 12, 7), Account('NL365', AccountType.EXPENSES), Quantity(-1135))
    journal_entry_0.validate()
    controller_0.book('NL365', Book(datetime.date(2014, 12, 7), TransactionType.JOURNAL, journal_entry_0))