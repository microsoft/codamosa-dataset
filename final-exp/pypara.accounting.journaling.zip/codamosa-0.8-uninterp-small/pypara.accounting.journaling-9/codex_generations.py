

# Generated at 2022-06-26 00:31:05.302001
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Create an instance of ReadJournalEntries
    read_journal_entries_0 = ReadJournalEntries()

    # Call the method
    read_journal_entries_0.__call__()


if __name__ == "__main__":
    print(test_case_0())
    print(test_ReadJournalEntries___call__())

# Generated at 2022-06-26 00:31:11.409263
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    entry = JournalEntry[int](datetime.date.today(), "some description", 1)
    entry.post(datetime.date.today(), Account("some account", AccountType.ASSETS), +100)
    entry.post(datetime.date.today(), Account("some account", AccountType.REVENUES), -100)
    assert (entry.postings[0].amount.value == 100)
    assert (entry.postings[1].amount.value == 100)

# Generated at 2022-06-26 00:31:15.865884
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # create JournalEntry object
    journal_entry = JournalEntry()
    # create account object
    account = Account()
    # assign available account and quantity to post()
    journal_entry.post(account, 500)
    # check if debit account is updated or not
    assert journal_entry.debits == 500
    # check if credit account is updated or not
    assert journal_entry.credits == 500

# Generated at 2022-06-26 00:31:16.787173
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # TODO
    pass

# Generated at 2022-06-26 00:31:23.142929
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](datetime.date(2019, 11, 26), "JE Test", 10)
    je.post(datetime.date(2019, 11, 26), Account("123", "ABC", AccountType.EXPENSES, AccountType.NATURAL), 10)
    je.post(datetime.date(2019, 11, 26), Account("321", "CBA", AccountType.REVENUES, AccountType.NATURAL), -10)
    je.validate()

# Generated at 2022-06-26 00:31:29.276160
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.readaccounttree import read_account_tree
    ## Build an account tree:
    account_tree = read_account_tree('./contrib/accounts.csv')
    ## Build a dummy journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), 'debit-credit match', None)

    ## Postings:
    journal_entry.post(datetime.date(2020, 1, 1), account_tree['Assets']['Cash'], +100)
    journal_entry.post(datetime.date(2020, 1, 1), account_tree['Expenses']['Rent'], -100)

    ## Validate:
    journal_entry.validate()

# Generated at 2022-06-26 00:31:31.440152
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    try:
        assert (ReadJournalEntries()(None))
    except NotImplementedError:
        return
    assert False

# Generated at 2022-06-26 00:31:38.266474
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    It should post nothing if the quantity is zero.
    It should post increments if direction is positive.
    It should post decrements if direction is negative.
    It should post a debit if direction is positive and account type is an Asset.
    It should post a credit if direction is positive and account type is an Equity.
    It should post a credit if direction is positive and account type is a Liability.
    It should post a debit if direction is negative and account type is a Revenue.
    It should post a credit if direction is negative and account type is an Expense.
    """
    pass



# Generated at 2022-06-26 00:31:48.490630
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Unit test for method validate of class `JournalEntry`
    """
    accounts_0 = [
        Account(1, "Cash", AccountType.ASSETS, Guid("00000000-0000-0000-0000-000000000001")),
        Account(2, "Revenue", AccountType.REVENUES, Guid("00000000-0000-0000-0000-000000000002")),
        Account(3, "Interest Income", AccountType.REVENUES, Guid("00000000-0000-0000-0000-000000000003")),
    ]


# Generated at 2022-06-26 00:31:53.736767
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # setup
    date = datetime.date(2019, 1, 1)
    description = "description"
    source = "source"
    journal = JournalEntry[str](date, description, source)

    # exercise
    journal.post(date, Account("ACC", AccountType.ASSETS), Quantity.of(100))
    journal.post(date, Account("ACC", AccountType.REVENUES), Quantity.of(-100))

    # verify
    journal.validate()



# Generated at 2022-06-26 00:32:05.103567
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.accounts import Account
    journal = JournalEntry[None]('2020-10-22', 'Testing', None)
    journal.post(journal.date, Account.INCOME_TAX, -499)
    debits = [i.account for i in journal.debits]
    credits = [i.account for i in journal.credits]
    assert debits == [Account.INCOME_TAX]
    assert credits == [Account.INCOME_TAX]


# Generated at 2022-06-26 00:32:14.277320
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange
    from ..billing.models import Billable
    from ..store.models import Store
    store1 = Store('Pharmacy')
    store2 = Store('Grocery')
    bill1 = Billable(store1, "Inventory purchased", 35000, makeguid())
    bill2 = Billable(store2, "Inventory purchased", 15000, makeguid())
    # Post journal entries

# Generated at 2022-06-26 00:32:19.490167
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    '''
    Assert journal entry is invalid
    '''
    from .accounts import Account
    from .journal.service import JournalService
    from .ledger import Ledger
    from ..commons.times import now
    from ..products.model import Currency, Product, ProductType
    from ..users.model import User
    from .journal.service import JournalService

    # Arrange
    currency = Currency("USD")
    user = User("test@test.com", "1234")
    product = Product("product", ProductType.ASSET, currency, None)
    service = JournalService(Ledger())
    
    # Act
    j = JournalEntry(now(), "desc", product)
    j.post(now(), Account("1234", "ASSET", currency), 100)

# Generated at 2022-06-26 00:32:25.439085
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    '''
    if (total_debit == total_credit):
       assert total_debit == total_credit
    '''
    je1 = JournalEntry(datetime.date.today(), "description",  "source")
    assert je1.validate() == None, "Error validating journal entry!"
#test_JournalEntry_validate()

# Generated at 2022-06-26 00:32:36.646737
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AssetAccount, DebitAccount
    from .accounts import PayableAccount, ReceivableAccount
    from .accounts import EquityAccount
    from .accounts import ExpenseAccount
    from .accounts import RevenueAccount
    from datetime import date
    from pytest import raises
    from ..commons.exceptions import InvalidArgumentException
    from .journal_entries import JournalEntry

    # Arrange
    journal = JournalEntry(date(2019, 11, 9), "test_journal_entry")
    journal.post(date(2019, 11, 9), AssetAccount("CASH"), +100000)
    journal.post(date(2019, 11, 9), ExpenseAccount("SALARY_EXPENSE"), -100000)


# Generated at 2022-06-26 00:32:47.043553
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..bookkeeping.accounts.model import AccountRegistry
    from ..bookkeeping.accounts.objects import AssetType, EquityType, LiabilityType, RevenueType, ExpenseType

    account_registry = AccountRegistry.default()

    # register accounts
    asset_account_value = AssetType.MONETARY
    EquityType.EXTERNAL
    LiabilityType.LOANS_LIABILITIES
    RevenueType.SALES
    ExpenseType.PURCHASES

    # create journal entry with two postings
    j1 = JournalEntry(date=datetime.date.today(), description="J1", source=None)
    j1.post(datetime.date.today(), account_registry.get(asset_account_value), 100)

# Generated at 2022-06-26 00:32:50.203455
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MyClass:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    my_instance = MyClass()
    assert list(my_instance(DateRange.infinite())) == []

# Generated at 2022-06-26 00:32:58.854956
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    # Function
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[TestSource]]:
        return [TestJournalEntry(datetime.date.today(), "Test", TestSource(), [])]

    ##
    # Case 1: Success
    ##
    period = DateRange(datetime.date.today(), datetime.date.today())

    journal_entries = read_journal_entries(period)

    assert isinstance(journal_entries, Iterable)

    first_journal_entry = next(iter(journal_entries))


# Generated at 2022-06-26 00:33:05.431596
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @ReadJournalEntries
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        yield from []

    assert read_journal_entries(DateRange.now()) == []

# Generated at 2022-06-26 00:33:14.237091
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from ..books.accounts import BalanceSheetAccounts
    from ..books.read import GetBalanceSheet
    je= JournalEntry[BalanceSheetAccounts]
    b=BalanceSheetAccounts()
    je.post(date(2020,8,16),BalanceSheetAccounts.RECEIVABLES,5)
    je.post(date(2020,8,16),BalanceSheetAccounts.UNEARNED_REVENUE,5)
    je.validate()
    je= None
    assert je is None


# Generated at 2022-06-26 00:33:33.562540
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V.@mf\n+x?&Ux'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    assert journal_entry_0 is var_1
    assert journal_entry_0.debits == list_0


# Generated at 2022-06-26 00:33:43.314553
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = ''
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [journal_entry_0]
    list_1 = list_0
    account_0 = None
    direction_0 = Direction.INC
    var_1 = None
    list_1 = list_0[:-1]
    list_1 = list_0[1:]
    list_1 = list_0[1:]
    list_1 = list_0[1:]
    list_1 = list_0[:-1]
    list_1 = list_0[:-1]
    list_1 = list_0[:-1]
    list_1 = list_0[1:]

# Generated at 2022-06-26 00:33:51.742198
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V.@mf\n+x?&Ux'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    var_2 = None
    posting_0 = Posting(var_1, date_0, account_0, direction_0, var_2)


# Generated at 2022-06-26 00:33:59.675185
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    str_0 = 'U6k=iZ\x7fT'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    var_2 = None
    posting_0 = Posting(var_1, date_0, account_0, direction_0, var_2)


# Generated at 2022-06-26 00:34:08.366863
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V.@mf\n+x?&Ux'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    var_2 = None
    posting_0 = Posting(var_1, date_0, account_0, direction_0, var_2)
    var_3 = DateRange(date_0, date_0)
    var_4 = direction_0.name
    var_5 = journal_entry_

# Generated at 2022-06-26 00:34:09.850008
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    def test(self):
        self.assertEquals(0, 1, 'Test comparison is equal')

    pass

# Generated at 2022-06-26 00:34:18.762744
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # set up input values
    date = datetime.date(year=2017, month=5, day=10)
    account = None
    var_0 = Direction.INC
    var_1 = Quantity(1)
    quantity = var_0 * var_1
    var_2 = JournalEntry(date, '8V.@mf\n+x?&Ux', None)

# Generated at 2022-06-26 00:34:28.910252
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '8V.@mf\n+x?&Ux'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    var_2 = None
    posting_0 = Posting(var_1, date_0, account_0, direction_0, var_2)

# Generated at 2022-06-26 00:34:37.469173
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass
    # Setup
    str_0 = '8V.@mf\n+x?&Ux'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    var_2 = None
    posting_0 = Posting(var_1, date_0, account_0, direction_0, var_2)
    # Verify
    try:
        journal_entry_0.validate()
    except AssertionError:
        pass


# Generated at 2022-06-26 00:34:46.317856
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V.@mf\n+x?&Ux'
    date_0 = None
    var_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, var_0)
    list_0 = [str_0, str_0, journal_entry_0, var_0]
    direction_0 = Direction.DEC
    account_0 = None
    var_1 = journal_entry_0.post(date_0, account_0, direction_0)
    var_2 = None

    posting_0 = Posting(list_0, list_0, direction_0, null, list_0)
    posting_1 = Posting(journal_entry_0, direction_0, account_0, var_1)
    direction_1 = Direction.INC
    posting_

# Generated at 2022-06-26 00:34:54.338411
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:34:59.936772
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '9t<F&t'
    str_1 = 'R'
    account = Account(str_1, str_0)
    date = datetime.date(1, 1, 1)
    journal_entry = JournalEntry(date, str_0, str_0)
    journal_entry.post(date, account, 0)

test_case_0()
test_JournalEntry_post()

# Generated at 2022-06-26 00:35:06.991799
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(1929, 3, 31)
    account_0 = Account("F", AccountType.EXPENSES, "F")
    quantity_0 = Quantity(1)
    journal_entry = JournalEntry("", "", "")
    journal_entry_return = journal_entry.post(date_0, account_0, quantity_0)
    assert journal_entry_return == journal_entry


# Generated at 2022-06-26 00:35:20.756535
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    amount_20 = Amount(20)
    amount_80 = Amount(80)
    account_0 = Account("2-1", "2-2")

    source_0 = "5d5ab6f5-0c14-4b8f-82e6-5f6c1b6d8c5b"

    description_0 = "id"
    description_1 = "guid"

    journalEntry_0 = JournalEntry(description_0, description_1, source_0)
    journalEntry_0.post(description_0, account_0, amount_80)

    journalEntry_0.post(description_0, account_0, amount_20)

    journalEntry_0.post(description_0, account_0, amount_20)

    journalEntry_0.validate()


# Generated at 2022-06-26 00:35:26.518064
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    try:
        journal_entry_0.validate()
    except AssertionError:
        pass


# Generated at 2022-06-26 00:35:29.831069
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:35:36.645574
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1.validate()
    journal_entry_1.post(str_0, str_0, str_0)
    journal_entry_1.validate()


# Generated at 2022-06-26 00:35:42.549231
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_range_0 = DateRange(datetime.date(2011, 12, 30), datetime.date(2008, 1, 3))
    expected_result_0 = Posting(1, datetime.date(2022, 6, 7), '=A)F', Direction.DEC, 2)
    result_0 = ReadJournalEntries()(date_range_0)
    assert expected_result_0 == result_0


# Generated at 2022-06-26 00:35:46.997981
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    :return:
    """
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:49.885082
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str = '8V@f\n+x?&Ux'
    journal_entry = JournalEntry(str, str, str)
    journal_entry.validate()

# Generated at 2022-06-26 00:36:05.710402
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:36:06.607269
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:36:10.209721
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '{6\x03\x1c\x0f\x10'
    date_range = DateRange(str_0, str_0)
    journal_entry = ReadJournalEntries(str_0, date_range)


# Generated at 2022-06-26 00:36:19.256569
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Jp"b+U|}'
    int_0 = 1429

    # Test case 0
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, journal_entry_0, int_0)
    journal_entry_0.validate()

    # Test case 1
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1.post(str_0, journal_entry_1, int_0)
    journal_entry_1.validate()

    # Test case 2
    journal_entry_2 = JournalEntry(str_0, str_0, str_0)

# Generated at 2022-06-26 00:36:28.025136
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_0 = journal_entry_0.post(journal_entry_0, journal_entry_0, journal_entry_0)
    journal_entry_0.validate()
    journal_entry_0 = journal_entry_0.post(journal_entry_0, journal_entry_0, journal_entry_0)
    journal_entry_0.validate()
    journal_entry_0 = journal_entry_0.post(journal_entry_0, journal_entry_0, journal_entry_0)
    journal_entry_0.validate()
    journal_entry_0 = journal_entry

# Generated at 2022-06-26 00:36:28.542150
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert False == True

# Generated at 2022-06-26 00:36:36.876319
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Input arguments
    str_0 = 'eP9XD\n*h7g'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0) 
    # Output arguments
    # Expected exception to be thrown
    exception_expected = AssertionError("Total Debits and Credits are not equal: 0 != 0")

    # Invoke method

    # Check for expected exception
    try:
        journal_entry_0.validate()
    except AssertionError as e:
        # Check the message
        assert str(e) == str(exception_expected)



# Generated at 2022-06-26 00:36:41.514469
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, int)
    journal_entry_0.validate()
    assert len(journal_entry_0.postings) == 1 and journal_entry_0.postings[0].amount.value == 0

# Generated at 2022-06-26 00:36:49.608730
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V@f\n+x?&Ux'

# Generated at 2022-06-26 00:36:54.107380
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def mock_ReadJournalEntries___call__(journal_entries: List[JournalEntry[_T]]) -> Iterable[JournalEntry[_T]]:
        return journal_entries

    journal_entries = []
    assert mock_ReadJournalEntries___call__(journal_entries) == journal_entries


# Generated at 2022-06-26 00:37:36.721701
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f(period):
        return isinstance(period,DateRange) and True
    ReadJournalEntries.__call__ = f
    rje = ReadJournalEntries()
    assert rje.__call__(DateRange(datetime.date(1234,5,6),datetime.date(5678,9,10)))

# Generated at 2022-06-26 00:37:49.339553
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Set up the objects
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = '8V@f\n+x?&Ux'
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    str_2 = '8V@f\n+x?&Ux'
    journal_entry_2 = JournalEntry(str_2, str_2, str_2)
    str_3 = '8V@f\n+x?&Ux'
    journal_entry_3 = JournalEntry(str_3, str_3, str_3)
    account_0 = Account("Account 2", AccountType.EQUITIES)
    guid

# Generated at 2022-06-26 00:38:03.382684
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    string_0 = '8V@f\n+x?&Ux'
    string_1 = '4\t`0+\n0H'
    string_2 = '8V@f\n+x?&Ux'
    string_3 = 'I_Xz\x0cjJ\x15'
    date_0 = datetime.date(2017, 5, 3)
    date_1 = datetime.date(2017, 5, 3)
    date_2 = datetime.date(2017, 5, 3)
    date_3 = datetime.date(2017, 5, 3)
    account_0 = Account(string_0, string_1)
    account_1 = Account(string_2, string_3)
    quantity_0 = Quantity(1.0)

# Generated at 2022-06-26 00:38:10.081504
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test 1: Method should return an iterator of journal entries
    def test_1():
        period = DateRange.registry("2018-01")
        journal_entry_1 = journal_entry_0.post(journal_entry_0.date, str_1, 1)
        pass

    # Test 2: Parameter period should be a DateRange instance
    def test_2():
        # Expect exception
        period = 2
        pass

    test_case_0()
    test_1()
    test_2()

# Generated at 2022-06-26 00:38:14.616397
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\x17\x03{\x14?\x0c\x1d0\x1a\x1aQ\x12\x14'
    class ReadJournalEntriesImpl:
        def __call__(self, period):
            journal_entry = JournalEntry(str_0, str_0, str_0)
            return [journal_entry]
    ReadJournalEntriesImpl()(str_0)


# Generated at 2022-06-26 00:38:18.624912
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    j, str_0 = JournalEntry(None, None, None), 'J*EaT'
    read_journal_entries_0 = ReadJournalEntries()
    assert (None if not hasattr(read_journal_entries_0, '__call__') else read_journal_entries_0.__call__(str_0)) is not None


# Generated at 2022-06-26 00:38:26.039127
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

    date_range_0 = DateRange(journal_entry_0.date, journal_entry_0.date)
    read_journal_entries_0 = ReadJournalEntries(journal_entry_0, str_0, str_0)
    journal_entries_0 = read_journal_entries_0(date_range_0)
    journal_entries_0.validate()

# Generated at 2022-06-26 00:38:34.282670
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'hR'
    str_1 = '*"\x19\xe6\x89\x0cnZ'
    tuple_0 = (str_0, str_1)
    def function_0(arg):
        return arg
    class Class_0:
        def __init__(self):
            self.str_0 = 'F]\x92\x85\x1d\x15\x9f\x9e\xdf\x93a\xaaw\xdf\xb1\x0e\x93;\x9d\x9f\x16:c\xbb\xf4\x0e'

# Generated at 2022-06-26 00:38:36.871705
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:38:39.459923
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:40:18.973222
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:40:21.252885
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    try:
        journal_entry_0.validate()
    except AssertionError:
        pass



# Generated at 2022-06-26 00:40:21.917459
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:40:26.871981
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = '8V@f\n+x?&Ux'
    str_2 = '8V@f\n+x?&Ux'
    account_0 = Account(str_1, str_2)
    int_0 = 0
    quantity_0 = Quantity(int_0)
    journal_entry_0.post(str_0, account_0, quantity_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:40:29.410824
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V@f\n+x?&Ux'
    print('Test of method __call__ of class ReadJournalEntries started')
    print('Test of method __call__ of class ReadJournalEntries finished')
    # assert False #TODO: implement your test here


# Generated at 2022-06-26 00:40:30.675980
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass


# Generated at 2022-06-26 00:40:34.704134
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.ASSETS)
    account_1 = Account(str_0, AccountType.EXPENSES)
    journal_entry_0.post(None, account_0, None).post(None, account_1, None).validate()
    # Now we can use ReadJournalEntries as a function
    journal_entry_0 = ReadJournalEntries()(None)
    assert journal_entry_0 is not None

# Generated at 2022-06-26 00:40:42.283013
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Test case 1
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    # Expect
    # AssertionError("Total Debits and Credits are not equal: 0 != 0")
    # Test case 2
    str_1 = '\r7va}C=m5^a'
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.validate()
    # Expect
    # AssertionError("Total Debits and Credits are not equal: 0 != 0")
    # Test case 3
    str_2 = 'P8Wl{=\x0f?\x0f'
   

# Generated at 2022-06-26 00:40:46.742769
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '8V@f\n+x?&Ux'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:40:49.165810
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry('date', 'date', 'date')
    account = Account(AccountType.ASSETS, 'test_account')
    journal.post('date', account, 1)
    for posting in journal.increments:
        assert posting.amount == 1