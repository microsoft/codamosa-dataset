

# Generated at 2022-06-26 00:31:03.516632
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    For method valudate of class JournalEntry
    """
    pass



# Generated at 2022-06-26 00:31:06.265475
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
  # Create instance:
  obj = JournalEntry()

  # Get attribute value:
  result = obj.validate()

  # Assert result
  assert True


# Generated at 2022-06-26 00:31:11.715334
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # parameters
    date_0 = datetime.date()
    account_0 = Account()
    quantity_0 = Quantity()
    # object instance
    journal_entry_0 = JournalEntry()
    # call method
    result_0 = journal_entry_0.post(date_0, account_0, quantity_0)
    # assertion
    assert isinstance(result_0, JournalEntry)


# Generated at 2022-06-26 00:31:14.029240
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    obj_0 = ReadJournalEntries()
    var_0 = DateRange(date_0, date_0)
    var_1 = obj_0(var_0)

# Generated at 2022-06-26 00:31:16.394400
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    obj = JournalEntry()
    date = datetime.date()
    account = Account()
    quantity = Quantity()
    obj.post(date, account, quantity)


# Generated at 2022-06-26 00:31:20.972573
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange(date_0, date_0)
    journal_entries_0: Iterable[JournalEntry[_T]] = ReadJournalEntries.__call__(period_0)
    journal_entries_0: Iterable[JournalEntry[_T]] = ReadJournalEntries.__call__(period_0)

# Generated at 2022-06-26 00:31:24.281312
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

import datetime as module_1


# Generated at 2022-06-26 00:31:29.671825
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange()
    read_journal_entries_0 = ReadJournalEntries()

    try:
        actual_0 = read_journal_entries_0.__call__(period_0)
    except Exception as expected_0:
        actual_0 = expected_0

    assert actual_0 == NotImplemented

import datetime as module___0


# Generated at 2022-06-26 00:31:34.093331
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    obj = ReadJournalEntries()
    arg0 = DateRange()
    arg1 = __faux_factory(DateRange)
    __faux_factory(Iterable, JournalEntry)
    ret0 = obj.__call__(arg0)
    ret1 = obj.__call__(arg1)


# Generated at 2022-06-26 00:31:37.644109
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test without arguments
    test_0 = ReadJournalEntries()
    result_0 = test_0()

    # Test with arguments
    test_1 = ReadJournalEntries()
    period_0 = test_case_0()
    result_1 = test_1(period_0)

# Generated at 2022-06-26 00:31:50.515932
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date.today()
    description_0 = 'f&"|>Zz}I`x'
    source_0 = True
    journal_entry_0 = JournalEntry(date_0, description_0, source_0)
    quantity_0 = Quantity(5.82)
    account_0 = Account.make_trial_balance_account()
    date_1 = None
    journal_entry_0.post(date_1, account_0, quantity_0)
    source_1 = 'aG-NX,c<'
    date_2 = datetime.date.today()
    description_1 = 'L/#{*dS;j'
    journal_entry_1 = JournalEntry(date_2, description_1, source_1)
    quantity_1 = Quantity(9.7)


# Generated at 2022-06-26 00:32:00.469188
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_JournalEntry_validate0()
    test_JournalEntry_validate1()
    test_JournalEntry_validate2()
    test_JournalEntry_validate3()
    test_JournalEntry_validate4()
    test_JournalEntry_validate5()
    test_JournalEntry_validate6()
    test_JournalEntry_validate7()
    test_JournalEntry_validate8()
    test_JournalEntry_validate9()
    test_JournalEntry_validate10()
    test_JournalEntry_validate11()
    test_JournalEntry_validate12()
    test_JournalEntry_validate13()
    test_JournalEntry_validate14()
    test_JournalEntry_validate15()
    test_JournalEntry_validate16()
    test_JournalEntry_validate17()
   

# Generated at 2022-06-26 00:32:01.538455
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    return


# Generated at 2022-06-26 00:32:07.430006
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    date_1 = None
    str_0 = 'Arwca"7v5PF1'
    direction_0 = Direction.DEC
    journal_entry_0 = JournalEntry(date_0, str_0, direction_0)
    account_0 = Account.of('0', '0', '0')
    quantity_0 = Quantity(0.0)

    journal_entry_0.post(date_1, account_0, quantity_0)



# Generated at 2022-06-26 00:32:11.355312
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'Arwca"7v5PF1'
    direction_0 = Direction.DEC
    journal_entry_0 = JournalEntry(date_0, str_0, direction_0)
    assert journal_entry_0.credits == None


# Generated at 2022-06-26 00:32:14.703615
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'Arwca"7v5PF1'
    direction_0 = Direction.DEC
    journal_entry_0 = JournalEntry(date_0, str_0, direction_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:32:25.011167
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'Arwca"7v5PF1'
    direction_0 = Direction.DEC
    journal_entry_0 = JournalEntry(date_0, str_0, direction_0)
    date_1 = None
    account_0 = Account(str_0, date_0)
    quantity_0 = Amount(0)
    journal_entry_0 = journal_entry_0.post(date_1, str_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:32:36.420556
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date(2108, 8, 26)
    date_1 = datetime.date(2108, 8, 26)
    date_2 = datetime.date(2108, 8, 26)
    date_3 = datetime.date(2108, 8, 26)
    date_4 = datetime.date(2108, 8, 26)
    date_5 = datetime.date(2108, 8, 26)
    date_6 = datetime.date(2108, 8, 26)
    date_7 = datetime.date(2039, 6, 17)
    date_8 = datetime.date(2101, 10, 1)
    date_9 = datetime.date(2109, 5, 9)
    date_10 = datetime.date(2106, 9, 8)
   

# Generated at 2022-06-26 00:32:41.048342
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'Arwca"7v5PF1'
    direction_0 = Direction.DEC
    journal_entry_0 = JournalEntry(date_0, str_0, direction_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:32:43.689707
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # make some test inputs
    period_0 = 'E"%c]^@U6'

    # invoke the function
    __call__(period_0)


# Generated at 2022-06-26 00:32:56.722120
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()
    value_0 = []
    def f(period):
        return value_0
    read_journal_entries_0 = f
    obj = read_journal_entries_0
    result = obj(date_0)
    assert result == value_0


# Generated at 2022-06-26 00:33:01.635174
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = '"Tngbq&J'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = None
    read_journal_entries_0 = lambda period: [journal_entry_0]
    journal_entries_0 = read_journal_entries_0(date_1)
    journal_entries_1 = read_journal_entries_0(date_1)
    assert (journal_entries_0 == journal_entries_1)
    print("Test method __call__ of class ReadJournalEntries is successful")



# Generated at 2022-06-26 00:33:05.023721
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = None
    account_0 = None
    int_0 = -1
    quantity_0 = Quantity(int_0)
    journal_entry_1 = journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_1.validate()


# Generated at 2022-06-26 00:33:16.258764
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    if is_implemented(ReadJournalEntries.__call__):
        print('Test for method __call__ of class ReadJournalEntries')
        date_0 = datetime.date(1000, 2, 28)
        date_1 = datetime.date(1, 1, 1)
        date_range_0 = DateRange(date_0, date_1)
        account_0 = Account(date_range_0, date_0, date_0, '1', '1')
        account_1 = Account(date_range_0, date_0, date_0, '1', '1')
        account_2 = Account(date_range_0, date_0, date_0, '1', '1', '1', '1')
        quantity_0 = Quantity(0)

# Generated at 2022-06-26 00:33:25.780267
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(None, str_0, None)
    journal_entry_0.validate()
    account_0 = Account(None, str_0, None, None, None, None, 0)
    journa_posting_0_0 = journal_entry_0.post(None, account_0, 1)
    assert journa_posting_0_0.date is None
    assert journa_posting_0_0.account.name == str_0
    journa_posting_0_1 = journa_posting_0_0.post(None, account_0, 1)
    assert journa_posting_0_1.date is None
    assert journa_posting_0_1

# Generated at 2022-06-26 00:33:30.333773
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    fun_0 = lambda period: [journal_entry_0]
    assert fun_0(date_0) == [journal_entry_0]


# Generated at 2022-06-26 00:33:39.947526
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # (((((((())))))))
    print('\nMethod: post\n')

    # Set up a test journal entry
    date_0 = datetime.date(year = 1234, month = 12, day = 31)
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)

    # Test with a quantity <= 0
    amount = 0
    date_1 = datetime.date(year = 4321, month = 11, day = 22)
    account_0 = Account('Test_Account_0', '01', 'Test Description 0')
    quantity = -amount
    direction_0 = Direction.of(quantity)
    journal_entry_0.post(date_1, account_0, quantity)

    # Test with a quantity >

# Generated at 2022-06-26 00:33:46.154878
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date(1983, 1, 13)
    str_0 = '\\a~qzhj7VY'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = datetime.date(1970, 1, 1)
    account_0 = Account(str_0, AccountType.ASSETS)
    quantity_0 = -13
    journal_0 = journal_entry_0.post(date_1, account_0, quantity_0)
    test_case_0()

# Generated at 2022-06-26 00:33:54.373069
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Call method post of class JournalEntry
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    date_1 = datetime.date(1, 1, 1)
    account_0 = Account(str_0, 1, date_0, date_0, date_0)
    quantity_0 = None
    journal_entry_0.post(date_1, account_0, quantity_0)
    # Call method validate of class JournalEntry
    journal_entry_0.validate()
    assert True

# Generated at 2022-06-26 00:33:59.877761
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_0 = JournalEntry(None, '', None)
    date_range_0 = DateRange.to_endless()
    post_list_0 = []
    journal_entry_0.postings = post_list_0
    method_invocation_0 = ReadJournalEntries(journal_entry_0, date_range_0)
    assert isinstance(method_invocation_0, ReadJournalEntries)


# Generated at 2022-06-26 00:34:18.105364
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = "M\u0017,\u0005\u0015&"
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:28.415944
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    import datetime

    date_0 = datetime.date(1600, 3, 6)
    journal_entry_0 = JournalEntry(date_0, '}hV6U{66,b', date_0)
    journal_entry_0.validate()
    date_1 = datetime.date(2090, 5, 6)
    journal_entry_1 = JournalEntry(date_1, 'jJ<x-*1!Fu', date_1)
    journal_entry_1.validate()
    date_2 = datetime.date(1694, 8, 14)
    journal_entry_2 = JournalEntry(date_2, 'wgjY8"eWxT', date_2)
    journal_entry_2.validate()
    date_3 = datetime.date(1224, 5, 16)

# Generated at 2022-06-26 00:34:35.171165
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '!'
    str_1 = 'wDyV7Qz3q;4I7Q-n'
    date_0 = datetime.date(year=2019, month=4, day=1)
    journal_entry_0 = JournalEntry[str](date_0, str_0, str_1)
    account_0 = Account(AccountType.ASSETS, str_1)
    quantity_0 = Quantity(1)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:34:44.006705
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date.today()
    date_1 = date_0
    date_2 = date_0
    str_0 ="""AB"""
    account_type_0 = AccountType.ASSETS
    account_0 = Account("Account", account_type_0)
    account_1 = account_0
    journal_entry_0 = JournalEntry(date_0, str_0, date_1)
    try:
        journal_entry_0.post(date_2, account_0, 1)
    except AssertionError as e:
        print("exception: {}".format(e))
    try:
        journal_entry_0.post(date_2, account_1, 1)
    except AssertionError as e:
        print("exception: {}".format(e))

# Generated at 2022-06-26 00:34:48.923964
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests the method validate of class JournalEntry
    """
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:34:49.728223
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    print("--- Make a journal entry and validate")
    test_case_0()

# Generated at 2022-06-26 00:34:53.399576
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()
    test_case_0()

test_JournalEntry_validate()

# Generated at 2022-06-26 00:34:57.946010
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Variables initialization
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    account_0 = Account(str_0, AccountType.REVENUES, str_0, str_0)
    direction_0 = Direction.DEC
    date_0 = None
    account_1 = Account(str_0, AccountType.EXPENSES, str_0, str_0)
    direction_1 = Direction.DEC

    # Test with quantity greater than zero
    quantity = 2
    journal_entry_0.post(date_0, account_0, quantity)

    # Test with quantity equals zero
    quantity = 0
    journal_entry_0.post(date_0, account_1, quantity)

    #

# Generated at 2022-06-26 00:35:03.158600
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:35:08.841380
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    period_0 = None
    
    # Call method __call__
    actual_value = journal_entry_0.__call__(period_0)
     

# Generated at 2022-06-26 00:35:25.487799
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()



# Generated at 2022-06-26 00:35:27.174358
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    tc0 = 'Arwca"75PF41'
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

# Generated at 2022-06-26 00:35:28.402224
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_ReadJournalEntries___call___0()


# Generated at 2022-06-26 00:35:31.913099
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    a = ReadJournalEntries()
    b: ReadJournalEntries[str] = ReadJournalEntries()
    c = ReadJournalEntries()
    d = ReadJournalEntries()


# Generated at 2022-06-26 00:35:38.460077
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account(0)
    e_0 = JournalEntry(datetime.date(1,1,1), "", "")
    quantity_0 = 0
    assert e_0.postings == []
    e_0.post(datetime.date(1,1,1), account_0, quantity_0)
    assert e_0.postings == []


# Generated at 2022-06-26 00:35:42.353880
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('Arwca"75PF41')
    debit = journal_entry_0.post('Arwca"75PF41', 'Arwca"75PF41')
    assert debit == journal_entry_0.debits


# Generated at 2022-06-26 00:35:47.691281
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, 99)
    journal_entry_0.post(str_0, str_0, 99)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:48.805583
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:35:51.479350
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # Create a null JournalEntry
    journal_entry_0 = JournalEntry(None, None, None)

    # Validate the JournalEntry
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:00.928053
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_0 = JournalEntry(datetime.date(2018, 12, 28), "", "")
    journal_entry_1 = JournalEntry(datetime.date(2018, 12, 28), "", "")
    journal_entry_2 = JournalEntry(datetime.date(2018, 12, 28), "", "")
    journal_entry_3 = JournalEntry(datetime.date(2018, 12, 28), "", "")
    journal_entry_4 = JournalEntry(datetime.date(2018, 12, 28), "", "")
    journal_entry_5 = JournalEntry(datetime.date(2018, 12, 28), "", "")
    journal_entry_6 = JournalEntry(datetime.date(2018, 12, 28), "", "")

# Generated at 2022-06-26 00:36:22.653917
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'Arwca"75PF41'
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return (p for p in range(5))
    read_journal_entries_0: ReadJournalEntries[str] = read_journal_entries
    result = read_journal_entries_0(str_0)
    assert result is not None


# Generated at 2022-06-26 00:36:25.543338
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str, str, str)
    journal_entry_0.post(datetime.date(2, 1, 2), Account(str, AccountType(2), bool), Quantity(2))


# Generated at 2022-06-26 00:36:35.792909
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from .business import BusinessOf, BusinessRole
    from .commons.others import D, DR
    from .products import Product
    from .transactions import TransactionType
    from .trade import Trade, TradeItem
    from .transactions import Transaction
    from .transactions import EntryType

    _T = BusinessOf(Product)

    class JournalDataOf(BusinessRole[_T]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.entries: Iterable[JournalEntry[_T]] = list()

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return self.entries

    # Setup business data
    journal_data_of: JournalDataOf[Product] = JournalData

# Generated at 2022-06-26 00:36:36.635093
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_case_0()

# Generated at 2022-06-26 00:36:39.516022
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ledger = JournalEntry('Transaction', 'Transaction Description', 'Transaction Source')
    ledger.post(datetime.date.today(), Account('1001', 'Cash On Hand', AccountType.ASSETS), -300)
    ledger.validate()


# Generated at 2022-06-26 00:36:40.333439
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:36:42.594853
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post()


# Generated at 2022-06-26 00:36:45.993657
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    str_1 = 'Arwca"75PF41'
    str_2 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_1, str_2)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_1, int(0))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:36:49.685567
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, 100)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:56.331387
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create the class instance
    journal_entry_0 = JournalEntry(datetime.date(1970, 1, 1), "", "")
    assert journal_entry_0.postings == []

    # Call method post
    journal_entry_0.post(datetime.date(1970, 1, 1), Account(str), Quantity(1))

    # Check the instance variables
    assert journal_entry_0.postings == [Posting(journal_entry_0, datetime.date(1970, 1, 1), Account(str), Direction.INC, Amount(1))]

# Generated at 2022-06-26 00:37:36.685275
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry(None, None, None)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:46.268611
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Instantiation of the JournalEntry object
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    # call the post method
    account_0 = Account(str_0, str_0)
    str_1 = {'zyc'}
    journal_entry_0.post(str_1, account_0, Quantity(0))
    # call the validate method
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:48.700308
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # min size example
    assert True
    # checking with all kinds of postings
    assert True
    # using some good values
    assert True
    # using some bad values
    assert False

# Generated at 2022-06-26 00:37:50.280390
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journalEntry = JournalEntry(None, None, None)
    journalEntry.post(None, None, None)



# Generated at 2022-06-26 00:38:04.387993
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry(datetime.date.today(), "Test", "Test")
    
    # Simulate posting 100 units to asset account
    journal_entry.post(datetime.date.today(), Account("Assets"), Quantity(100))
    
    assert len(journal_entry.postings) == 1

    assert journal_entry.postings[0].journal.description == "Test"
    assert journal_entry.postings[0].journal.source == "Test"
    assert journal_entry.postings[0].journal.date == datetime.date.today()
    
    assert journal_entry.postings[0].account.name == "Assets"
    assert journal_entry.postings[0].account.type == AccountType.ASSETS
    
    assert journal_entry.postings[0].direction == Direction.INC
   

# Generated at 2022-06-26 00:38:08.865838
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
	journal_entry_0 = JournalEntry('test_date', 'test_description', 'test_source')
	journal_entry_0.post('test_date', Account('test_description', 'test_type'), Quantity(2))
	journal_entry_0.validate()


# Generated at 2022-06-26 00:38:17.022977
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from datetime import date
    from typing import Iterable, TypeVar
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from ..commons.zeitgeist import DateRange
    from .journal import Direction, JournalEntry, Posting
    from .journal import ReadJournalEntries

    _T = TypeVar("_T")

    # creates a simple account
    @dataclass(frozen=True)
    class Account_0:
        account_type: str
        name: str
        code: str = ''
        description: str = ''
        notes: str = ''
        parent: 'Account_0' = None
    
    account_0 = Account_0('ASSET', 'Account 0')
    amount_0 = Amount(100)

# Generated at 2022-06-26 00:38:26.845130
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert JournalEntry('1','2','3') == JournalEntry('1','2','3')
    assert JournalEntry('1','2','3').post('1','2','3') == JournalEntry('1','2','3').post('1','2','3')
    test_JournalEntry_post_0 = JournalEntry('1','2','3').post('1','5','6')
    assert str(test_JournalEntry_post_0.postings[0]) == "Posting(journal=JournalEntry('1', '2', '3'), date='1', account='5', direction=<Direction.INC: 1>, amount=Amount(6.00))"
    test_JournalEntry_post_1 = JournalEntry('1','2','3').post('1','5',Quantity(6))

# Generated at 2022-06-26 00:38:35.034633
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # 1.
    journal_entry = JournalEntry(1,2,3)
    journal_entry_post = journal_entry.post(1,Account(1),1)
    assert journal_entry_post.postings[0].account.name == journal_entry.postings[0].account.name and journal_entry_post.postings[0].amount == journal_entry.postings[0].amount
    # 2.
    journal_entry = JournalEntry(1,2,3)
    journal_entry_post = journal_entry.post(1,Account(1),0)
    assert journal_entry_post.postings == []
    # 3.
    journal_entry = JournalEntry(1,2,3)
    journal_entry_post = journal_entry.post(1,Account(1),-1)
    assert journal_entry

# Generated at 2022-06-26 00:38:40.856050
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = 'zN2h"V7/DjtB'
    date_0 = datetime.date(9, 11, 11)
    quantity_0 = Quantity(12.0)
    account_0 = Account(str_1, str_1)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:39:28.499354
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:39:34.815857
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'Z5)PbJ0r;r'
    str_1 = 'D=+B'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_range_0 = DateRange(str_0)
    journal_entry_0.validate()
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1.validate()
    journal_entry_1.validate()
    journal_entry_1.validate()
    journal_entry_1.post(str_1, str_1, 1)
    journal_entry_1.validate()
    journal_entry_1.validate()
    journal_entry_1.validate()
    journal_entry_1.validate()


# Generated at 2022-06-26 00:39:35.235425
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:39:38.156849
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Arwca"75PF41'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_0.post(2, 5, '4JJ')
    journal_entry_0.validate()


# Generated at 2022-06-26 00:39:42.658226
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class test_ReadJournalEntries___call__(ReadJournalEntries):
        def __init__(self):
            pass
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass
    test_ReadJournalEntries___call___instance = test_ReadJournalEntries___call__()
    assert isinstance(test_ReadJournalEntries___call___instance, ReadJournalEntries), 'test_ReadJournalEntries___call___instance is not an instance of class ReadJournalEntries'


# Generated at 2022-06-26 00:39:51.261747
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    arg_0 = 'Arwca"75PF41'
    arg_1 = datetime.date(year=1997, month=9, day=1)
    arg_2 = Account(arg_0, arg_0, arg_0)
    arg_3 = Quantity(123456)
    journal_entry_0 = JournalEntry(arg_0, arg_0, arg_0)
    journal_entry_0.post(arg_1, arg_2, arg_3)

# Generated at 2022-06-26 00:39:52.033261
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:39:55.403216
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    some_date = datetime.date(2020, 7, 17)
    some_account = Account(key='10', name='Cash', account_type=AccountType.ASSETS)
    some_quantity = Quantity(10)
    journal_entry = JournalEntry(str_0, str_0, str_0)

    journal_entry.post(some_date, some_account, some_quantity)
    journal_entry.validate()

# Generated at 2022-06-26 00:40:01.493485
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    year = datetime.datetime.today().year
    month = datetime.datetime.today().month
    day = datetime.datetime.today().day
    date = datetime.date(year,month,day)
    description = 'Test journal entry'
    source = 'String test'
    account = Account(name = "Account1", type = AccountType.REVENUES)
    journal_entry_0 = JournalEntry(date, description, source)
    journal_entry_0.post(date, account, Quantity(1))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:40:02.032780
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True == True
