

# Generated at 2022-06-26 00:31:13.282455
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # TODO: Add proper test cases
    def test_JournalEntry_post_1():
        m = Model()
        date = datetime.date.today()
        account = m.accounts.ASSETS.Cash
        quantity = 1
        journal_entry = JournalEntry(date, "description", None)
        journal_entry.post(date, account, quantity)
        assert len(journal_entry.postings) == 1
        assert journal_entry.postings[0].account == account
        assert journal_entry.postings[0].journal == journal_entry
        assert journal_entry.postings[0].date == date
        assert journal_entry.postings[0].direction == Direction.INC
        assert journal_entry.postings[0].amount == 1

    def test_JournalEntry_post_2():
        m = Model()
       

# Generated at 2022-06-26 00:31:17.056282
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[int](datetime.date(2020, 3, 1), "", 0)
    je.post(datetime.date(2020, 3, 1), Account("123", "test", AccountType.ASSETS), 1)

# Generated at 2022-06-26 00:31:19.004076
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry()
    j1.post()
    j1.validate()

# Generated at 2022-06-26 00:31:22.481526
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ## Arrange
    journal_entry = JournalEntry(date=None, description=None, source=None)
    date = None
    account = None
    quantity = None
    ## Act
    journal_entry.post(date, account, quantity)
    ## Assert

# Generated at 2022-06-26 00:31:28.060069
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Unit test for method valid of class JournalEntry. This test will cover if all the transactions are valid
    or not.
    """
    entry = JournalEntry[str]("2020-06-08", "My first journal entry", "Entry 1")
    entry.post(datetime.date(2020, 6, 9), Account("Salaries Expense", AccountType.EXPENSES), Quantity(4500.00))
    entry.post(datetime.date(2020, 6, 9), Account("Cash", AccountType.ASSETS), Quantity(-4500.00))
    entry.validate()



# Generated at 2022-06-26 00:31:36.956760
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source = "test"
    journal_entry = JournalEntry(datetime.date(2000, 1, 1), "test_journal_entry", source)
    account = Account("test_account", AccountType.EQUITIES)
    journal_entry.post(datetime.date(2000, 1, 1), account, Quantity(10))

    assert len(journal_entry.postings) == 1
    assert journal_entry.postings[0].date == datetime.date(2000, 1, 1)
    assert journal_entry.postings[0].account == account
    assert journal_entry.postings[0].direction == Direction.INC
    assert journal_entry.postings[0].amount == Amount(10)
    return journal_entry


# Generated at 2022-06-26 00:31:41.892058
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def period_0() -> DateRange:
        return DateRange(datetime.date(2020, 9, 5), datetime.date(2020, 9, 11))
    def run(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return ReadJournalEntries.__call__(None, period)
    run(period_0())

# Generated at 2022-06-26 00:31:42.460511
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert False

# Generated at 2022-06-26 00:31:47.905012
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from ..commons.zeitgeist import DateRange
    j1 = JournalEntry[object](datetime.date.today(), "Journal Entry", object)
    account = Account.of(AccountType.EQUITIES, "1")
    j1.post(datetime.date.today(), account, 1)
    j1.post(datetime.date.today(), account, -1)
    j1.validate()

# Generated at 2022-06-26 00:31:50.938934
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntries_Implementation(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            pass

    ReadJournalEntries_Implementation()


# Generated at 2022-06-26 00:32:04.704433
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2020, 4, 3)
    str_0 = "4x4vK1y7W8bNNOFcSfz1"
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.REVENUES)
    journal_entry_0.post(date_0, account_0, 3.5064687006223317)

    date_0 = datetime.date(2020, 3, 1)
    str_0 = '*Zp,g+$&e#z3q6B+n6nG'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)

# Generated at 2022-06-26 00:32:12.368338
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'bRd8uXQ'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_1 = JournalEntry(date_0, str_0, journal_entry_0)
    float_0 = -2075.3
    assert list(ReadJournalEntries(journal_entry_0, date_0).__call__(date_0)) == [], "Expected [], but got: %s" % list(ReadJournalEntries(journal_entry_0, date_0).__call__(date_0))

# Generated at 2022-06-26 00:32:23.097396
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = 'V7}fh'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    period = None
    ReadJournalEntries.__call__(journal_entry_0, period)
    str_1 = 'MKDd]3jO$'
    journal_entry_1 = JournalEntry(date_0, str_1, journal_entry_0)
    journal_entry_1.validate()
    journal_entry_2 = JournalEntry(date_0, str_0, journal_entry_1)
    journal_entry_2.validate()
    journal_entry_3 = JournalEntry(date_0, str_1, journal_entry_2)
    journal_entry_3.valid

# Generated at 2022-06-26 00:32:30.295911
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2020, 9, 5)
    str_0 = 'This is a test.'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    account_0 = Account('This is a test.', AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, 0.0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:32:41.433232
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date
    date_1 = date_0
    date_0 = date_1
    date_2 = date_1
    date_3 = date_2
    date_2 = date_3
    date_1 = date_0
    date_0 = date_1
    date_1 = date_0
    date_0 = date_1
    date_2 = date_3
    date_3 = date_2
    date_2 = date_1
    date_1 = date_0
    date_0 = date_1
    str_0 = 'ascii'
    quantity_0 = Quantity(float_0)
    account_0 = Account(str_0, str_0, str_0)
    journal_entry_0 = JournalEntry(date_0, str_0, None)

# Generated at 2022-06-26 00:32:43.313442
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # TODO: handle Unit test for method post of class JournalEntry
    pass


# Generated at 2022-06-26 00:32:53.022322
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .ledger import Ledger
    from .commons.others import makeguid

    journal_entry_0 = JournalEntry(datetime.date(month=9, year=2018, day=17), 'Z({$&NhMU>&etEA(', 'Z({$&NhMU>&etEA(')
    date_0 = datetime.date(year=2008, month=3, day=27)
    ledger_0 = Ledger()
    account_0 = Account(name='W(`[+vU_]C', type=AccountType.ASSETS, guid=makeguid())
    ledger_0.add(account_0)
    journal_entry_0.post(date_0, account_0, -0.5)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:33:00.373729
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'Z({$&NhMU>&etEA('
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.LIABILITIES)
    float_0 = -2075.3
    journal_entry_0.post(date_0, account_0, float_0)
    journal_entry_0.validate()
    float_1 = float_0
    journal_entry_1 = JournalEntry(date_0, str_0, journal_entry_0)
    journal_entry_1.post(date_0, account_0, float_1)
    journal_entry_1.validate()

# Generated at 2022-06-26 00:33:07.309373
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        journal_entry_0 = JournalEntry(None, '', '')
        journal_entry_0.validate()
    except AssertionError as e:
        assert e


# Generated at 2022-06-26 00:33:13.909294
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'Z({$&NhMU>&etEA('
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_1 = JournalEntry(date_0, str_0, journal_entry_0)
    float_0 = -2075.3


# Generated at 2022-06-26 00:33:21.879160
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    period_0 = DateRange(datetime.date(2005, 5, 3), datetime.date(2022, 8, 25))
    journal_entry_0.validate()
    journal_entry_0.validate()



# Generated at 2022-06-26 00:33:22.437545
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:33:32.408856
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2016, 1, 1)
    date_1 = datetime.date(2016, 1, 2)
    date_2 = datetime.date(2016, 1, 3)

    account_0 = Account("A")
    account_1 = Account("B")
    account_2 = Account("C")
    account_3 = Account("D")


    journal_entry_0 = JournalEntry("", "", "")
    journal_entry_0.validate()

    journal_entry_0.post(date_0, account_0, Amount(1.0))
    journal_entry_0.validate()

    journal_entry_0.post(date_1, account_1, Amount(1.0))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:33:36.948095
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # implement test functionality here
    str_0 = 'a'
    str_1 = 'ab'
    str_2 = 'abc'
    journal_entry_0 = JournalEntry(str_0, str_1, str_2)
    journal_entry_0.post(str_0, str_1, Amount(str_0))
    journal_entry_0.validate()



# Generated at 2022-06-26 00:33:40.632429
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, None)


# Generated at 2022-06-26 00:33:41.918005
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        test_case_0()
    except AssertionError:
        return

# Generated at 2022-06-26 00:33:44.746702
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """Unit tests for method post of class JournalEntry."""
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:33:46.005986
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    for t in range(20):
        try:
            test_case_0()
        except:
            pass

# Generated at 2022-06-26 00:33:56.247518
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    account_0 = Account(str_0, AccountType.UNDEFINED)
    amount_0 = Amount(0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, account_0, amount_0)

    str_1 = ''
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.post(str_1, account_0, amount_0)
    str_2 = ''
    account_1 = Account(str_2, AccountType.UNDEFINED)
    amount_1 = Amount(0)
    journal_entry_0.post(str_2, account_1, amount_1)

# Generated at 2022-06-26 00:34:02.087300
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 's'
    date_0 = datetime.date.fromordinal(1)
    account_0 = Account(str_0)
    direction_0 = Direction.INC
    quantity_0 = Quantity(0)
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:34:16.463389
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # journal_entry_0 is passed for testing method JournalEntry.post
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = '_f4_jQw7:g^'
    account_0 = Account(str_1, Amount(0), str_1)
    date_0 = datetime.date(2100, 1, 1)
    journal_entry_0.post(date_0, account_0, 1)
    journal_entry_0.validate()
    journal_entry_0.post(date_0, account_0, -1)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:18.968579
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:29.104068
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(2017, 1, 1), str_0, 0.0)
    journal_entry_0.is_debit()
    journal_entry_0.is_credit()
    read_journal_entries_0 = ReadJournalEntries()
    def read_journal_entries_0__call__(read_journal_entries_0_self, period):
        return []
        yield
    read_journal_entries_0.__call__ = read_journal_entries_0__call__

# Generated at 2022-06-26 00:34:29.633019
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-26 00:34:31.742112
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert (((JournalEntry("","","")).post("","",Amount(0))).post("","",Amount(0))).post("","",Amount(0))


# Generated at 2022-06-26 00:34:32.270785
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-26 00:34:34.109372
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MockReadJournalEntries:
        def __call__(self, period):
            pass
    MockReadJournalEntries()


# Generated at 2022-06-26 00:34:35.027952
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__()

# Generated at 2022-06-26 00:34:40.817941
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    str_1 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.date(1, 1, 1)
    account_0 = Account(str_1, AccountType.ASSETS, str_0)
    quantity_0 = int32(0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:50.760042
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def get_range_0() -> DateRange:
        return DateRange(datetime.date(datetime.date.today().year - 10, 12, 1), datetime.date(datetime.date.today().year - 10, 11, 1))
    Period = get_range_0()
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    def get_range_1() -> DateRange:
        return DateRange(datetime.date(datetime.date.today().year - 10, 12, 1), datetime.date(datetime.date.today().year - 10, 11, 1))
    Period = get_range_1()
    str_1 = ''
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
   

# Generated at 2022-06-26 00:35:04.961063
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    print("test_JournalEntry_validate")
    journal_entry_1 = JournalEntry("a","a","a")
    journal_entry_1.post(datetime.date(2020, 1, 1), Account("Asset"), -100)
    journal_entry_1.validate()

# Integration test for method validate of class JournalEntry

# Generated at 2022-06-26 00:35:17.311203
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'F'
    str_1 = '\''
    str_2 = '"`'
    datetime_0 = datetime.date(year=2018, month=7, day=20)
    transaction_0 = ReadJournalEntries()
    date_range_0 = DateRange(start=datetime_0, end=datetime_0)
    journal_entry_0 = JournalEntry(str_0, str_1, str_2)
    journal_entry_1 = JournalEntry(str_0, str_1, str_2)
    list_0 = [journal_entry_0, journal_entry_1]
    assert transaction_0(date_range_0) == list_0


# Generated at 2022-06-26 00:35:21.409876
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_1 = ''
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.post(datetime.date(2020,5,5),Account(str_1,str_1,str_1),Quantity(10))
    journal_entry_1.validate()

# Generated at 2022-06-26 00:35:29.121259
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = 'Payment for Purchase'
    str_2 = 'Buy Equipment'
    account_1 = Account(str_1, str_2)
    int_0 = 0
    int_1 = 1
    int_2 = -1
    int_3 = 1
    int_4 = -1
    journal_entry_1 = journal_entry_0.post(int_0, account_1, int_1)
    journal_entry_2 = journal_entry_0.post(int_0, account_1, int_2)
    journal_entry_3 = journal_entry_0.post(int_0, account_1, int_3)
    journal_entry_4 = journal_entry

# Generated at 2022-06-26 00:35:33.401630
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(1, 1, 1)
    account = Account('', AccountType.ASSETS)
    quantity = Quantity(1)
    journal_entry = JournalEntry('', '', '')
    journal_entry.post(date, account, quantity)

# Generated at 2022-06-26 00:35:40.415419
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(datetime.date(2017, 2, 5), '', 'source')
    journal_entry_1 = journal_entry_0.post(datetime.date(2018, 2, 5), Account(str(str.format('{0}', str.format('{0}', 'account')))), int(0))
    assert journal_entry_0 == journal_entry_1


# Generated at 2022-06-26 00:35:49.587112
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntries_0(ReadJournalEntries):
        def __init__(self, _computation_type):
            pass
        def __call__(self, period):
            return account_1
    account_0 = Account('', '', '')
    journal_entry_0 = JournalEntry('', '', '')
    journal_entry_1 = JournalEntry('', '', '')
    journal_entry_1.post(datetime.datetime(1959, 3, 24, 0, 0), account_0, 0)
    account_1 = Account('', '', '')
    account_1.is_mutable = False
    # As a side effect, the method __call__ of the class ReadJournalEntries will append to t_0 (type: List[JournalEntry[_T]])
    t_0 = []
    read

# Generated at 2022-06-26 00:35:50.461678
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:35:59.394656
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    float_0 = float()
    float_1 = float()
    date_0 = datetime.date()
    date_1 = datetime.date()
    datetime_0 = datetime.datetime()
    account_0 = Account(str_0, str_0, str_0, str_0)
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    JournalEntry.post(journal_entry_0, date_0, account_0, float_1)
    journal_entry_0.post(float_1, account_0, float_0)
    journal_entry_0.post(float_0, account_0, float_1)
    journal_entry_0.post(float_1, account_0, float_0)
    journal_

# Generated at 2022-06-26 00:36:02.692565
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    print('Testing method validate of class JournalEntry')
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:36:19.148811
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:36:21.166491
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:36:30.170740
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account0 = Account(str_0, str_0, str_0)
    journal_entry0 = JournalEntry(str_0, str_0, str_0)
    try:
        journal_entry0.validate()
        assert False
    except AssertionError as e:
        assert str(e) == "Total Debits and Credits are not equal: 0 != 0"
    try:
        journal_entry0.validate()
        assert False
    except AssertionError as e:
        assert str(e) == "Total Debits and Credits are not equal: 0 != 0"
    quantity0 = Quantity(0)
    journal_entry0.post(str_0, account0, quantity0)

# Generated at 2022-06-26 00:36:33.139097
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:36:34.609983
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    obj = ReadJournalEntries()
    assert isinstance(obj(Guid()), Iterable)


# Generated at 2022-06-26 00:36:36.086065
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert False, "Test case not implemented"

# Generated at 2022-06-26 00:36:44.067142
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    datetime_0 = datetime.datetime.now()
    datetime_1 = datetime.datetime.now()
    datetime_2 = datetime.datetime.now()
    datetime_3 = datetime.datetime.now()
    datetime_4 = datetime.datetime.now()
    date_0 = datetime.date(1, 1, 1)
    date_1 = datetime.date(1, 1, 1)
    date_2 = datetime.date(1, 1, 1)
    amount_0 = Amount(100)

# Generated at 2022-06-26 00:36:46.596014
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return ''
    read_journal_entries = ReadJournalEntriesImpl()
    date_range_0 = DateRange(0, 0)
    read_journal_entries.__call__(date_range_0)

# test.py ends here

# Generated at 2022-06-26 00:36:50.564486
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, str_0)
    journal_entry_0.post(str_0, account_0, 0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:55.913120
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('', '', '')
    str_0 = ''
    str_1 = ''
    str_2 = ''
    int_0 = 1
    journal_entry_0.post(str_0, str_1, int_0)
    journal_entry_0.post(str_0, str_2, int_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:36.864166
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry('', '', '')
    date = datetime.date(2000, 1, 1)
    account = Account(str_0, AccountType.ASSETS)
    quantity = Quantity(str_0)
    journal_entry.post(date, account, quantity)
    assert journal_entry.postings == [Posting(journal_entry, date, account, Direction.INC, Amount(1.0))]

# Generated at 2022-06-26 00:37:44.001527
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
	account_0 = Account(str_0, str_0, str_0)
	journal_entry_1 = JournalEntry(str_0, str_0, str_0)
	journal_entry_1.post(date_0, account_0, Quantity(int_0))

# Generated at 2022-06-26 00:37:45.428569
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    assert True
    # When
    test_case_0()
    # Then
    assert True

# Generated at 2022-06-26 00:37:51.790786
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    date_0 = datetime.date(2018, 10, 10)
    account_0 = Account(str_0, AccountType.ASSETS, str_0)
    account_1 = Account(str_0, AccountType.REVENUES, str_0)
    amount_0 = Amount(100)
    amount_1 = Amount(-100)
    quantity_0 = Quantity(100)
    quantity_1 = Quantity(-100)
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    x = journal_entry_0.post(date_0, account_0, quantity_0).post(date_0, account_1, quantity_1)

    assert(x.increments[0].date == date_0)

# Generated at 2022-06-26 00:37:56.657479
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_1 = ''
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    str_2 = 'Description'
    str_3 = 'Source'
    journal_entry_2 = JournalEntry(str_2, str_3, str_3)
    journal_entry_2.validate()

    # Test case 1
    datetime_date_var_1 = datetime.date(2020, 7, 1)
    account_1 = Account(str_1, AccountType.ASSETS)
    int_type_var_1 = 0
    journal_entry_1.post(datetime_date_var_1, account_1, int_type_var_1)
    journal_entry_1.validate()
    assert journal_entry_1 == journal_entry_1

    # Test case

# Generated at 2022-06-26 00:38:01.007789
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.datetime(2000, 1, 1)
    account = Account("E000", "Assets")
    quantity = Quantity(1)
    journal_entry_0 = JournalEntry(date, "E000", "Assets")
    journal_entry_0.post(date, account, quantity)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:01.630005
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-26 00:38:02.683736
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()


# Generated at 2022-06-26 00:38:03.387571
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:10.083854
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account("Account.Id.BalanceCheck", AccountType.ASSETS)
    journal_entry_0 = JournalEntry("JournalEntry.Id.BalanceCheck", "JournalEntry.Description.BalanceCheck", None)
    journal_entry_0.post(datetime.date(2019, 12, 30), account_0, Quantity.FromInteger(10))
    journal_entry_0.post(datetime.date(2019, 12, 30), account_0, Quantity.FromInteger(-10))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:39:34.872089
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = date(1, 1, 1)
    account_0 = Account(str_0, AccountType.EQUITIES)
    int_0 = 1
    journal_entry_0 = journal_entry_0.post(date_0, account_0, int_0)
    date_1 = date(1, 1, 1)
    account_1 = Account(str_0, AccountType.EQUITIES)
    int_1 = 1
    journal_entry_0 = journal_entry_0.post(date_1, account_1, int_1)
    date_2 = date(1, 1, 1)
    account_2 = Account(str_0, AccountType.EQUITIES)


# Generated at 2022-06-26 00:39:37.795725
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    date = datetime.date(2020, 6, 1)
    account = Account("AccountId", "Description", AccountType.SOME_TYPE)
    quantity = Quantity(1,1)
    journal = JournalEntry("My Journal", "Description", "Source")
    journal.post(date, account, quantity)
    return


# Generated at 2022-06-26 00:39:45.498405
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    str_1 = 'id'
    str_2 = 'name'
    str_3 = 'type'
    account_0 = Account(str_1, str_2, AccountType.REVENUES)
    account_1 = Account(str_1, str_2, AccountType.EXPENSES)
    quantity_0 = Quantity(1)
    quantity_1 = Quantity(2)
    date_0 = datetime.date(2018, 4, 23)
    date_1 = datetime.date(2018, 4, 24)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    assert journal_entry_0.increments[0].date == date_0
   

# Generated at 2022-06-26 00:39:49.552993
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(datetime.date.today(), '', '')
    journal_entry_0.validate()
    journal_entry_1 = journal_entry_0.post(datetime.date.today(), Account(AccountType.ASSETS, '', '', ''), 0)
    journal_entry_1.validate()


# Generated at 2022-06-26 00:39:52.977724
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define arguments for the method
    period = DateRange(datetime.date(1970, 1, 1), datetime.date(1970, 1, 1))

    try:
        # Call the method under test
        pass
    except Exception as e:
        print(e)
        assert False, "Unexpected exception raised during __call__ operation"
    else:
        assert True



# Generated at 2022-06-26 00:39:57.280344
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(date = datetime.date(2020, 7, 2),description = str_0,source = str_0)
    #Default value of account 'Account': '0-0-0-0'
    quantity = 0
    journal_entry_0.post(datetime.date(2020, 7, 2), account = Account(type = AccountType.ASSETS,code = '0-0-0-0',name = str_0), quantity = quantity)
    journal_entry_0.validate()
    assert journal_entry_0.postings[0].amount == 0

# Generated at 2022-06-26 00:40:03.985447
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(date=datetime.date(2015, 1, 1), description='Some description', source='a')
    j_0 = journal_entry_0.post(date=datetime.date(2015, 1, 1), account=Account(type=AccountType.ASSETS, code="A"), quantity=100)
    j_0 = journal_entry_0.post(date=datetime.date(2015, 1, 1), account=Account(type=AccountType.EXPENSES, code="B"), quantity=50)
    j_0 = journal_entry_0.post(date=datetime.date(2015, 1, 1), account=Account(type=AccountType.ASSETS, code="A"), quantity=-50)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:40:09.770790
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_0 = JournalEntry(str, str, str)
    guid_0 = makeguid()
    journal_entry_0.post(datetime.datetime.now(), Account(0, str, AccountType.LIABILITIES, int), Quantity(1))
    journal_entry_0.post(datetime.datetime.now(), Account(0, str, AccountType.REVENUES, int), Quantity(0))
    guid_0 = makeguid()
    journal_entry_0.post(datetime.datetime.now(), Account(0, str, AccountType.ASSETS, int), Quantity(2))
    journal_entry_0.post(datetime.datetime.now(), Account(0, str, AccountType.ASSETS, int), Quantity(-1))

# Generated at 2022-06-26 00:40:13.572375
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = ''
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.date(1900, 1, 1)
    account_0 = Account(str_0, str_0, str_0)
    int_0 = 100
    journal_entry_0.post(date_0, account_0, Quantity(int_0))

# Generated at 2022-06-26 00:40:15.379705
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test setup
    date_range_0 = DateRange(datetime.date.today(), datetime.date.today())
    iterable_0 = ReadJournalEntries.__call__(date_range_0)