

# Generated at 2022-06-26 00:31:12.202691
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date.today(), "desc", None)
    assert journal.postings == list()
    journal.post(datetime.date.today(), Account("salary", AccountType.REVENUES), Quantity(100))
    assert journal.postings[0] == Posting(journal, datetime.date.today(), Account("salary", AccountType.REVENUES), Direction.INC, Amount(100))
    journal.post(datetime.date.today(), Account("rent", AccountType.EXPENSES), Quantity(-100))
    assert journal.postings[1] == Posting(journal, datetime.date.today(), Account("rent", AccountType.EXPENSES), Direction.DEC, Amount(100))
    journal.post(datetime.date.today(), Account("salary", AccountType.REVENUES), Quantity(0))

# Generated at 2022-06-26 00:31:15.274965
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _func(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    result = ReadJournalEntries.__call__(_func, period=None)
    assert isinstance(result, Iterable[JournalEntry[_T]])


# Generated at 2022-06-26 00:31:24.854359
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..generators import Transaction
    from .accounts import Account

    account = Account("id", "desc", AccountType.ASSETS)
    journalEntry = JournalEntry(datetime.date(2020, 4, 26), "desc", Transaction(datetime.date(2020, 4, 26), "desc"))
    amount = Quantity(10)

    journalEntry.post(datetime.date(2020, 4, 26), account, amount)

    assert journalEntry.postings[0].journal == journalEntry
    assert journalEntry.postings[0].direction == Direction.INC
    assert journalEntry.postings[0].account == account
    assert journalEntry.postings[0].date == datetime.date(2020, 4, 26)
    assert journalEntry.postings[0].amount == amount


# Generated at 2022-06-26 00:31:29.551897
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry=JournalEntry[None] (datetime.date(2020, 5, 4), "Description", None, [])
    total_debit = 0
    total_credit = 0
    assert total_debit == total_credit, f"Total Debits and Credits are not equal: {total_debit} != {total_credit}"

# Generated at 2022-06-26 00:31:35.928470
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from core.accounts import Account

    journal = JournalEntry[str]("1/1/2016", "Test description", "Business object")
    journal = journal.post(datetime.date(2016, 1, 1), Account.of_type(AccountType.ASSETS, "Assets"), Quantity(100))
    journal = journal.post(datetime.date(2016, 1, 1), Account.of_type(AccountType.REVENUES, "Revenues"), Quantity(100))
    journal.validate()

# Generated at 2022-06-26 00:31:42.990283
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EQUITIES, "Test", None), Quantity(600))
    je.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Test", None), Quantity(-600))
    try:
        je.validate()
    except AssertionError:
        print("AssertionError in test case")

test_JournalEntry_validate()

# Generated at 2022-06-26 00:31:52.245970
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from itertools import chain
    from kata.books import AccountType, Account, BalanceSheet
    from kata.books.gl import GeneralLedger
    from kata.books.journals import JournalEntry, Posting

    # Create an instance of GeneralLedger class
    gl = GeneralLedger()

    # Initialize and register an account of type BalanceSheet
    account_0 = Account(gl, AccountType.EXPENSES, "Account 0", BalanceSheet)
    account_1 = Account(gl, AccountType.EXPENSES, "Account 1", BalanceSheet)

    # Create an instance of JournalEntry class
    journal_entry_0 = JournalEntry(date(2012, 1, 15), "Description 0", "Source 0")

    # Create an instance of Posting class

# Generated at 2022-06-26 00:31:57.284864
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    about_journal_entry = "journals.ledgers.JournalEntry"

    # Test for exception AssertionError in method validate of class JournalEntry
    # Input : [[journal1,description1,source1,postings1]] with postings1 = [Posting(journal, date, account, direction, amount),]
    #         where date = datetime.date, account = Account(AccountType.EQUITIES, 'Equity'), direction = Direction.DEC, 
    #         and amount = Amount(1000)
    # Expected output : Exception AssertionError
    journal1 = JournalEntry("journal1",datetime.datetime.now(),datetime.datetime.now())
    description1 = "Description 1"
    source1 = "Source 1"

# Generated at 2022-06-26 00:32:07.307839
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Tested Directly in test_case_2
    journal = JournalEntry([])
    assert journal.postings == [], "Expected journal.postings to be an empty list"
    journal.post(datetime.date(2020, 9, 5), Account('assets', 'cash'), -100)
    assert journal.postings != [], "Expected journal.postings to be not an empty list"
    assert journal.postings[0].date == datetime.date(2020, 9, 5), \
        "Expected journal.postings[0].date to be datetime.date(2020, 9, 5)"
    assert journal.postings[0].account.name == 'cash', "Expected journal.postings[0].account.name to be 'cash'"

# Generated at 2022-06-26 00:32:11.561038
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType
    from .ledger_query_providers import QueryProviders
    # Initialization
    period = DateRange()
    # Test
    journal_entries = QueryProviders.journal_entries.__call__(period)
    # Verification
    assert isinstance(journal_entries, Iterable[JournalEntry[_T]])

# Generated at 2022-06-26 00:32:17.705531
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__


# Generated at 2022-06-26 00:32:18.880409
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert(ReadJournalEntries.__name__ == "ReadJournalEntries")


# Generated at 2022-06-26 00:32:25.602546
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_JournalEntry = JournalEntry(
        date = datetime.date.today(),
        description = 'description',
        source = source,
        postings = [
            (date1, account1, Direction.INC, Amount(quantity1)),
            (date2, account2, Direction.DEC, Amount(quantity2))
        ],
        guid = guid
    )
    test_JournalEntry.validate()

# Generated at 2022-06-26 00:32:36.822306
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Initialize a new JournalEntry and post a transaction to two accounts
    journalEntry = JournalEntry(datetime.date(year = 2010, month = 1, day = 1), "description", "source")
    journalEntry.post(datetime.date(year = 2010, month = 1, day = 1), Account(name = "Assets"), 1)
    journalEntry.post(datetime.date(year = 2010, month = 1, day = 1), Account(name = "Liabilities"), -1)

    # Initialize a new JournalEntry and post a transaction to two accounts
    journalEntry = JournalEntry(datetime.date(year = 2010, month = 1, day = 1), "description", "source")
    journalEntry.post(datetime.date(year = 2010, month = 1, day = 1), Account(name = "Assets"), 1)
    journal

# Generated at 2022-06-26 00:32:37.774168
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    raise NotImplementedError()


# Generated at 2022-06-26 00:32:38.697402
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:32:49.118578
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    some_date = datetime.date(2019, 1, 1)
    account = Account("debit_acct", AccountType.ASSETS)
    quantity = Quantity(100)
    je = JournalEntry[object](date=some_date, description="Test", source=object())
    je.post(some_date, account, quantity)
    p = je.postings[0]
    assert p.journal == je
    assert p.date == some_date
    assert p.account == account
    assert p.direction == Direction.INC
    assert p.amount == amount_100
    assert p.is_debit
    assert not p.is_credit
    assert all(p2.is_credit for p2 in je.credits)
    assert all(p3.is_debit for p3 in je.debits)
    assert all

# Generated at 2022-06-26 00:32:52.360904
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal0 = JournalEntry(datetime.date(1, 1, 1), "", "")
    journal0.post(datetime.date(1, 1, 1), "", Quantity(0.0))
    journal0.validate()


# Generated at 2022-06-26 00:32:57.302818
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Create a sample journal entry
    entry_0 = JournalEntry[None]("2020-07-30", "Prepaid insurance", None)
    entry_0.post("2020-07-30", Account.ASSETS.Cash, 100.0)
    entry_0.post("2020-07-30", Account.EXPENSES.Insurance, -100.0)
    # Verify that the method validate() works
    entry_0.validate()

# Generated at 2022-06-26 00:33:02.804549
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    print('Validating journal entry on 11/10/2020')
    journal_entry_0 = JournalEntry()
    journal_entry_0.date = datetime.date(2020, 10, 11)
    journal_entry_0.description = 'Test journal entry'
    journal_entry_0.source = 'Test'
    journal_entry_0.post(date=datetime.date(2020, 10, 11), account=Account(name='Unassigned', type=AccountType.EXPENSES), quantity=Quantity(value=1))
    journal_entry_0.post(date=datetime.date(2020, 10, 11), account=Account(name='Unassigned', type=AccountType.EQUITIES), quantity=Quantity(value=-1))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:17.680738
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # 1. Generate the test data
    # a. Pre-defined account data
    acc_A = Account(None, None, "A", None, AccountType.ASSETS, None)
    acc_B = Account(None, None, "B", None, AccountType.EQUITIES, None)
    acc_C = Account(None, None, "C", None, AccountType.EXPENSES, None)
    acc_D = Account(None, None, "D", None, AccountType.REVENUES, None)

    # b. Initialize a JournalEntry
    journal = JournalEntry(
        date = datetime.date(year = 2020, month = 1, day = 1),
        description = "A test journal entry",
        source = None
    )

    # c. Posting to a journal

# Generated at 2022-06-26 00:33:27.687051
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test journal entries
    def _test_JournalEntry(source, date, description, postings):
        _postings = []
        entry = JournalEntry(date, description, source)
        for p in postings:
            entry.post(p['date'], p['account'], p['quantity'])
            _postings.append({'date': p['date'], 'account': p['account'], 'direction': p['direction'], 'amount': abs(p['quantity'])})

        # Generate JournalEntry from postings and test class attributes
        _entry = JournalEntry(date, description, source, _postings)
        assert entry.date == _entry.date
        assert entry.description == _entry.description
        assert entry.source == _entry.source
        assert entry.postings == _entry.postings
        assert entry.guid

# Generated at 2022-06-26 00:33:36.870568
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Atest(JournalEntry):
        def __init__(self,date,description,source,postings=[]):
            self.date = date
            self.description = description
            self.source = source
            self.postings = postings
    atest = Atest(datetime.date.today(),"test","test")
    atest1 = Atest(datetime.date.today(),"test","test",[Posting(atest,datetime.date.today(),Account("test"),Direction.INC,Amount(1))])

    assert atest.postings == []
    test = atest.post(datetime.date.today(),Account("test"),1)
    atest.post(datetime.date.today(),Account("test"),1)
    assert test.postings == atest1.postings
    assert atest.post

# Generated at 2022-06-26 00:33:43.314909
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    date: datetime.date = datetime.date(2020, 1, 1)
    account1: Account = Account(1, "Account1")
    account2: Account = Account(2, "Account2")

    # Exercise
    journal = JournalEntry[int](date, "Journal1", 1)
    journal.post(date, account1, 100)
    journal.post(date, account2, -200)
    journal.validate()

    # Verify



# Generated at 2022-06-26 00:33:48.718337
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import asdict
    je1 = JournalEntry[int](datetime.date(2019, 1, 1), "test1", 1)
    a1 = Account("a1", AccountType.ASSETS, AccountType.ASSETS, 1, None)
    a2 = Account("a2", AccountType.EQUITIES, AccountType.EQUITIES, 2, None)
    je2 = je1.post(datetime.date(2019, 1, 1), a1, 1)
    je3 = je1.post(datetime.date(2019, 1, 2), a2, -1)
    je4 = je1.post(datetime.date(2019, 1, 3), a2, 0)
    jes = [je2, je3, je4]
    a = jes[0].increments
    b = j

# Generated at 2022-06-26 00:33:51.231155
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert list(ReadJournalEntries.__call__.__annotations__) == ["period"]
    assert ReadJournalEntries.__call__.__annotations__["period"] is DateRange

# Generated at 2022-06-26 00:33:57.555570
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Book, Account
    from .transactions import Transaction

    @dataclass
    class SampleJournal:
        books: Dict[Account, Book] = field(default_factory=dict)

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[Transaction]]:
            for book in self.books.values():
                yield from book.query(period)


    journal = SampleJournal()
    assert isinstance(ReadJournalEntries.__getitem__(journal), JournalEntry)

# Generated at 2022-06-26 00:34:06.698199
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .ledgers import Ledger
    from datetime import date

    ## Initialization:
    ledger = Ledger()
    ledger.new_account(AccountType.ASSETS, "Cash", "", date(2020, 2, 14))
    ledger.new_account(AccountType.REVENUES, "Income", "", date(2020, 2, 14))

    journal = JournalEntry(date(2020, 2, 15), "Test", "")
    journal.post(date(2020, 2, 15), ledger.new_account(AccountType.ASSETS, "Cash", "", date(2020, 2, 15)), +100)
    journal.post(date(2020, 2, 15), ledger.new_account(AccountType.REVENUES, "Income", "", date(2020, 2, 15)), -100)

# Generated at 2022-06-26 00:34:11.469429
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account

    p = datetime.date.today().replace(day=1)
    d = datetime.date.today().replace(day=31)
    r = DateRange(p, d)

    def i(p: datetime.date, a: Account, q: Quantity) -> JournalEntry["object"]:
        return JournalEntry(p, "Desc.", object()) \
            .post(p, a, q)

    entries = [
        i(p, Account("1"), +1000),
        i(p, Account("2"), +2000),
    ]

    f: ReadJournalEntries["object"] = lambda p: entries

    x = list(f(r))
    assert x == entries

# Generated at 2022-06-26 00:34:18.750524
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    dr_account = Account(AccountType.ASSETS, "Cash")
    cr_account = Account(AccountType.EXPENSES, "Rent")
    j = JournalEntry(date=datetime.date(year=2019, month=8, day=15), description="Rent paid for August") \
        .post(date=datetime.date(year=2019, month=8, day=15), account=cr_account, quantity=+10000) \
        .post(date=datetime.date(year=2019, month=8, day=15), account=dr_account, quantity=-10000)
    j.validate()
    print(j)

# Generated at 2022-06-26 00:34:36.162101
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[str]("2019-01-01", "test", "test", [])
    je2 = JournalEntry[str]("2019-01-01", "test2", "test2", [])

    je.post("2019-01-01", "Assets:Cash", 10)
    je.post("2019-01-01", "Expenses:Taxes", -10)

    je2.post("2019-01-01", "Assets:Cash", 10.0)
    je2.post("2019-01-01", "Expenses:Taxes", -10.0)

    je.validate()
    je2.validate()

    assert je.postings == je2.postings

# Generated at 2022-06-26 00:34:37.045761
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-26 00:34:44.083468
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # test valid data
    from datetime import date as date
    from dataclasses import dataclass
    @dataclass(frozen=True)
    class Obj:
        def __init__(self, value):
            self.value = value

    a = JournalEntry(date.today(), 'test', Obj(1))
    a.post(date.today(), 'cash', 1)
    assert len(a.postings) == 1

    # test invalid data
    b = JournalEntry(date.today(), 'test', Obj(1))
    b.post(date.today(), 'cash', 0)
    assert len(b.postings) == 0

# Generated at 2022-06-26 00:34:44.594108
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:34:45.081170
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:34:52.912595
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    account_expense = Account("Expense", AccountType.EXPENSES, parent=None)
    account_revenue = Account("Revenue", AccountType.REVENUES, parent=None)
    date = datetime.date.today()
    # Act
    journalEntry = JournalEntry[None](date=date, description="", source=None)
    journalEntry.post(date, account=account_expense, quantity=1)
    journalEntry.post(date, account=account_revenue, quantity=1)
    # Assert
    journalEntry.validate()

# Generated at 2022-06-26 00:35:04.577635
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType

    class MockJournal(JournalEntry[None]):
        @classmethod
        def with_source(cls, source):
            return cls(source, "Test journal", None)

    def mock_read_entries(period):
        return [MockJournal.with_source(i) for i in period]

    def do_test(period):
        assert list(mock_read_entries(period)) == list(ReadJournalEntries.__call__(mock_read_entries, period))

    do_test(DateRange.from_dates(datetime.date(2020, 1, 1), datetime.date(2020, 1, 3)))

# Generated at 2022-06-26 00:35:17.096254
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .mocks import mock_accounts
    from .periods import Period
    from .sources import Source

    journal = JournalEntry()
    journal.date = datetime.date(2019, 12, 31)
    journal.description = "Trial description"
    journal.source = Source
    debit_amount = Amount(1000)
    credit_amount = Amount(2000)
    journal.post(datetime.date(2019, 12, 31), mock_accounts.depreciation_expense, debit_amount)
    journal.post(datetime.date(2019, 12, 31), mock_accounts.accumulated_depreciation, credit_amount)
    #AssertionError: Total Debits and Credits are not equal: -1000 != 2000

# Generated at 2022-06-26 00:35:27.073264
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date(2019, 1, 1), "Test_Data", "Test Data")
    journal.post(datetime.date(2019, 1, 1), Account(1, "Cash", AccountType.ASSETS), 500)
    journal.post(datetime.date(2019, 1, 1), Account(2, "Equipment", AccountType.ASSETS), 1000)
    journal.post(datetime.date(2019, 1, 1), Account(3, "Equity", AccountType.EQUITIES), 1500)
    journal.post(datetime.date(2019, 1, 1), Account(4, "Revenue", AccountType.REVENUES), -1200)
    journal.post(datetime.date(2019, 1, 1), Account(5, "Expense", AccountType.EXPENSES), -300)

# Generated at 2022-06-26 00:35:39.156758
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account, Accounts

    accounts = Accounts()
    entries = ReadJournalEntries[None]()

    def get_account(name: str) -> Account:
        return accounts.find_or_create(name, AccountType.EQUITIES)

    entries.post(datetime.date(2020, 1, 1), "Entry 1", None)\
        .post(datetime.date(2020, 1, 1), get_account("Cash"), 1000)\
        .post(datetime.date(2020, 1, 1), get_account("Capital"), -1000)


# Generated at 2022-06-26 00:36:09.289843
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'X$'
    date_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.validate()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 00:36:15.456203
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    account_1 = Account(str_0, int_0, AccountType.EQUITIES)
    str_1 = 'X$'
    date_1 = None
    journal_entry_1 = JournalEntry(date_1, str_1, date_1)
    journal_entry_1.post(date_1, account_1, int_0)
    journal_entry_1.validate()
    iterable_0 = ((journal_entry_1,),)
    ReadJournalEntries.__call__(iterable_0, date_range_0)


# Generated at 2022-06-26 00:36:20.123007
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    ReadJournalEntries.register(f)
    ReadJournalEntries.register(list)
    ReadJournalEntries.register(list.append)
    a: ReadJournalEntries[int] = lambda period: []
    ReadJournalEntries.__call__(a, None)

# Generated at 2022-06-26 00:36:23.976253
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call__(self, period, *, return_=None):
        pass


if __name__ == "__main__":
    # Test case: test_case_0
    test_case_0()

    # Test case: test_ReadJournalEntries___call__
    test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:36:33.667820
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'X$'
    str_1 = 'X$'
    str_2 = 'X$'
    str_3 = 'X$'
    str_4 = 'X$'
    str_5 = 'X$'
    str_6 = 'X$'
    str_7 = 'X$'
    str_8 = 'X$'
    str_9 = 'X$'
    date_0 = None
    date_1 = None
    date_2 = None
    date_3 = None
    date_4 = None
    date_5 = None
    date_6 = None
    date_7 = None
    date_8 = None
    date_9 = None
    guid_0 = Guid()
    guid_1 = Guid()
    guid_2 = Guid()

# Generated at 2022-06-26 00:36:37.858790
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'X$'
    date_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.post(date_0, None, 0)

test_case_0()
test_JournalEntry_post()

# Generated at 2022-06-26 00:36:45.654600
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'X$'
    str_1 = 'X$'
    str_2 = 'X$'
    str_3 = 'X$'
    date_0 = None
    date_1 = None
    date_2 = None
    date_3 = None
    date_4 = None
    date_5 = None
    date_6 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_1)
    account_0 = Account(str_1, AccountType.ASSETS)
    account_1 = Account(str_2, AccountType.ASSETS)
    account_2 = Account(str_3, AccountType.ASSETS)
    journal_entry_0.post(date_2, account_0, 4296)

# Generated at 2022-06-26 00:36:49.967767
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'X$'
    date_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    journal_entry_0.post(date_0, None, None)
    journal_entry_0.validate()
    assert journal_entry_0.postings == list()


# Generated at 2022-06-26 00:36:55.357127
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '@+<}'
    date_0 = datetime.date(2016, 6, 3)
    amount_0 = Amount(4)
    account_0 = Account(str_0)
    journal_entry_0 = JournalEntry(date_0, str_0, account_0)
    journal_entry_0.post(date_0, account_0, amount_0)


# Generated at 2022-06-26 00:36:59.704440
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'X$'
    date_0 = None
    journal_entry_0 = JournalEntry(date_0, str_0, date_0)
    account_0 = Account('account_0', AccountType.ASSETS)
    int_0 = -1
    journal_entry_0.post(date_0, account_0, int_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:26.575744
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'kq"L?v0"Fd0tm31'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = "5`b]\x06YUW\x13pv\x1a"
    account_0 = Account(str_1, str_1)
    date_0 = datetime.date(1949, 12, 17)
    int_0 = -1
    journal_entry_0.post(date_0, account_0, int_0)
    journal_entry_0.validate()

    assert True


# Generated at 2022-06-26 00:37:32.373126
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test if method post of class JournalEntry works correctly
    journal_entry_1 = JournalEntry('2020-01-01', 'Setup Fee', 'None')
    journal_entry_1.post('2020-01-01', Account('Initial Equity', AccountType.EQUITIES), 1000)
    journal_entry_1.post('2020-01-01', Account('Cash on Bank', AccountType.ASSETS), -1000)
    journal_entry_1.validate()
    # print(journal_entry_1)
    for i in journal_entry_1.postings:
        print(i.account.code, i.direction, i.amount.value)

# Generated at 2022-06-26 00:37:45.144525
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'kq"L?v0"Fd0tm31'
    str_1 = 'Bt4FaVtC2o@([hD3'
    str_2 = '-d<w1_hOyO&T=T~7'
    str_3 = 'GWAf8D@{b%cwRx>p'
    journal_entry_0 = JournalEntry(str_0, str_1, str_1)
    journal_entry_0.post(datetime.date(2017, 6, 5), Account(str_2), 5)
    assert journal_entry_0.date == datetime.date(2017, 6, 5)
    journal_entry_0.validate()
    assert journal_entry_0.description == str_1
    assert journal_entry_0.postings

# Generated at 2022-06-26 00:37:46.681551
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass


# Generated at 2022-06-26 00:38:00.648580
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    start_date = datetime.date.today()
    end_date = start_date + datetime.timedelta(days=10)

    period = DateRange(start_date, end_date)
    str_0 = 'kq"L?v0"Fd0tm31'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)

    journal_entry_1 = JournalEntry(start_date, str_0, journal_entry_0)
    journal_entry_2 = JournalEntry(end_date, str_0, journal_entry_1)

    def z(period: "DateRange") -> Iterable[JournalEntry["JournalEntry"]]:
        yield journal_entry_2

    z.__annotations__ = {"return": "Iterable[JournalEntry]"}


# Generated at 2022-06-26 00:38:02.515626
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    posting10 = Posting('journal_entry', 'date', 'account', 'direction', 'amount')

# Generated at 2022-06-26 00:38:12.218887
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    print("JournalEntry.post")
    str_0 = "kq"
    str_1 = 'L?v0"Fd0tm31'
    str_2 = 'L?v0"Fd0tm31'
    str_3 = 'L?v0"Fd0tm31'
    str_4 = "kq"
    str_5 = 'L?v0"Fd0tm31'
    str_6 = 'L?v0"Fd0tm31'
    str_7 = 'L?v0"Fd0tm31'
    datetime_0 = datetime.datetime(2020, 4, 27, 9, 5, 6, 915861)

# Generated at 2022-06-26 00:38:16.885439
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(datetime.date.today(), "", "")
    journal_entry_0.validate()
    journal_entry_0.post(datetime.date.today(), Account(AccountType.ASSETS, ""), 100)
    journal_entry_0.validate()
    journal_entry_0.validate()
    journal_entry_0.validate()
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:26.752257
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'kq"L?v0"Fd0tm31'
    str_1 = 'kq"L?v0"Fd0tm31'
    str_2 = 'kq"L?v0"Fd0tm31'
    account_0 = Account('kq"L?v0"Fd0tm31', AccountType.REVENUES)
    journal_entry_0 = JournalEntry(str_0, str_1, str_1)
    # Postings in journal entry are not empty.
    journal_entry_0.postings.clear()
    journal_entry_0.post(str_2, account_0, -1)
    journal_entry_0.postings.clear()
    # Postings in journal entry are empty.

# Generated at 2022-06-26 00:38:34.976844
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account(str_0, AccountType.ASSETS, str_0)
    account_1 = Account(str_0, AccountType.ASSETS, str_0)
    date_0 = datetime.date(1976, 4, 3)
    date_1 = datetime.date(1996, 2, 13)
    date_2 = datetime.date(2140, 5, 2)
    date_3 = datetime.date(1981, 12, 11)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = 'o?,!n?/FQ/'
    str_2 = 'a@.NnYf8N.]'
    str_3 = 'C!Lp9*JU#&=Z'

# Generated at 2022-06-26 00:39:20.139863
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass


# Generated at 2022-06-26 00:39:26.595769
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    description = 'description'
    date = datetime.date.today()
    source = 'source'
    j1 = JournalEntry(date=date, description=description, source=source)
    quantity = Quantity(1)
    j1.post(datetime.date.today(), Account('acc', AccountType.ASSETS), quantity)
    assert len(j1.postings) == 1
    assert (j1.debits).__next__().amount == quantity.to_int()
    assert len(list(j1.debits)) == 0
    assert (j1.credits).__next__().amount == quantity.to_int()
    assert len(list(j1.credits)) == 0
    j1.post(datetime.date.today(), Account('acc', AccountType.EXPENSES), -quantity)

# Generated at 2022-06-26 00:39:28.722805
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry(datetime.date.today(), "test", "source")
    journal_entry.post(datetime.date.today(), Account(AccountType.ASSETS, "A"), 1)
    journal_entry.validate()

# Generated at 2022-06-26 00:39:31.681163
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'ist0"f?tX0'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    try:
        journal_entry_0.validate()
    except AssertionError:
        pass
    else:
        raise RuntimeError("unexpected success")


# Generated at 2022-06-26 00:39:34.783962
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    for period_0 in [
        DateRange(0, 1),
    ]:
        
        for journal_entry_0 in [test_case_0]:
            assert JournalEntry(test_case_0).validate(), 1
    
        for journal_entry_1 in [test_case_0]:
            assert JournalEntry(test_case_0).validate(), 1

# Generated at 2022-06-26 00:39:36.635885
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    try:
        test_case_0()
    except AssertionError:
        print("AssertionError")
    else:
        print("Function __call__ of class ReadJournalEntries works correctly")

# Generated at 2022-06-26 00:39:38.859818
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entries = ReadJournalEntries()(DateRange(datetime.date(2013, 11, 10),
                                                     datetime.date(2014, 1, 12)))
    assert len(journal_entries) == 4

# Generated at 2022-06-26 00:39:42.189599
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    data = str('kq"L?v0"Fd0tm31')
    account = Account(data, data, data, data)
    journal_entry = JournalEntry(datetime.date.today(), data, data)
    journal_entry.post(datetime.date.today(), account, 123)
    journal_entry.validate()
    #assert journal_entry.postings != None, "Expected True to be False"

# Generated at 2022-06-26 00:39:43.844147
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert {}.__call__("") is None

# Generated at 2022-06-26 00:39:51.551338
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry('2010-1-1', 'test0', 'test0')
    j1.post('2010-1-1', Account.ASSETS.CASH, 100)
    j1.post('2010-1-1', Account.EXPENSES.RENT, -100)

    j2 = JournalEntry('2010-1-1', 'test1', 'test1')
    j2.post('2010-1-1', Account.ASSETS.CASH, -100)
    j2.post('2010-1-1', Account.EXPENSES.RENT, 100)

    j3 = JournalEntry('2010-1-1', 'test2', 'test2')
    j3.post('2010-1-1', Account.ASSETS.CASH, 0)