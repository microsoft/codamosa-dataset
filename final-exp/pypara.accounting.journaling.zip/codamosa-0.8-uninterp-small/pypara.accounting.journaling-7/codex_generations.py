

# Generated at 2022-06-26 00:31:04.108314
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test: Initialization
    date_0 = module_0.date()
    account_0 = Account(type=AccountType.ASSETS)
    quantity_0 = Quantity(value=0)
    obj_0 = JournalEntry(date=date_0, description='a', source=None)
    # Test: Execution
    obj_0.post(date=date_0, account=account_0, quantity=quantity_0)


# Generated at 2022-06-26 00:31:14.210147
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Assigning arguments
    period_0 = DateRange()

    # Assigning field parameters
    journal_0 = JournalEntry(date=datetime.date(2000, 1, 1), description='Description', source='Source', postings=[Posting(journal=JournalEntry(date=datetime.date(2000, 1, 1), description='Description', source='Source', postings=[]), date=datetime.date(2000, 1, 1), account='Account', direction=Direction.INC, amount=Amount())])

    # Setting up mock
    mock_0 = Mock()
    mock_0.__call__.return_value = [journal_0]

    # Calling method directly
    ret_0 = mock_0.__call__(period=period_0)

    # Getting return value
    ret_1 = ret_0[0]

    # Getting field value


# Generated at 2022-06-26 00:31:17.277612
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journ_0 = JournalEntry(date_0, '', test_case_0)
    test_case_0 = ReadJournalEntries()
    test_case_0.__call__()

import datetime as module_1


# Generated at 2022-06-26 00:31:26.760249
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import AccountBook
    from .ledgers import Ledger
    from .ledgers import LedgerBook
    from .ledgers import ReadLedger
    from . import journals
    from . import ledgers
    from . import journals
    from . import ledgers
    from .journals import JournalEntry
    account_book = AccountBook()
    ledger_book = LedgerBook(account_book)
    def __f_wrapped_0__(ledger_book):
        ledger = ledger_book.create(module_0.date(), "Test")
        return lambda date_0, account_0, amount_0: ledger.record(date_0, account_0, amount_0)
    record = __f_wrapped_0__(ledger_book)
    account_0 = account

# Generated at 2022-06-26 00:31:32.240696
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Create a concrete instance of protocol ReadJournalEntries, using a lambda to add behavior to protocol methods
    read_journal_entries_instance_0 = lambda period : 'TEST'
    # Call the __call__ method of the ReadJournalEntries instance
    result = read_journal_entries_instance_0(date_0)
    expected = 'TEST'
    assert result == expected

import datetime as module_1


# Generated at 2022-06-26 00:31:34.003382
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[object]()
    j.post(date_0,Account(),Quantity())

# Generated at 2022-06-26 00:31:36.527365
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    le = JournalEntry(date=datetime.date(1, 1, 1))
    le.post(date=date_0, account=None, quantity=0)

# Generated at 2022-06-26 00:31:39.083162
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    inst = JournalEntry()
    inst.date = test_case_0()
    inst.postings = list()
    inst.description = ''
    inst.validate()

import datetime as module_1


# Generated at 2022-06-26 00:31:49.382659
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    date_0 = datetime.date()
    description_0 = "The description"
    source_0 = "The source"
    journal_entry_0 = JournalEntry(date_0, description_0, source_0)
    date_0 = datetime.date()
    account_0 = Account("The account", AccountType.UNKNOWN)
    quantity_0 = 10
    journal_entry_0.post(date_0, account_0, quantity_0)
    date_0 = datetime.date()
    account_0 = Account("The account", AccountType.UNKNOWN)
    quantity_0 = 10
    journal_entry_0.post(date_0, account_0, quantity_0)

    # Act
    journal_entry_0.validate()

    # Assert

# Generated at 2022-06-26 00:31:53.325616
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = module_0.date()
    period_0 = DateRange(date_0, date_0)
    journal_entries_0 = JournalEntry()
    iterable_0 = Iterable[JournalEntry]()
    iterable_0.append(journal_entries_0)

test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:32:00.622412
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange.empty()
    # Call the method
    x = ReadJournalEntries.__call__(period=period_0)
    assert isinstance(x, Iterable) is True

import typing as module_1


# Generated at 2022-06-26 00:32:04.585235
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_1 = module_0.date()
    account_0 = Account()
    quantity_0 = Quantity()
    journal_entry_0 = JournalEntry()
    journal_entry_1 = journal_entry_0.post(date_1, account_0, quantity_0)


# Generated at 2022-06-26 00:32:07.915318
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    try:
        # Setup:
        period_0 = []
        # Exercise:
        __call__(period_0)
    except TypeError as err:
        print(err)
    else:
        print("[FAIL] Expected TypeError")


# Generated at 2022-06-26 00:32:10.477960
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange(date_0, date_0)
    journal_0 = JournalEntry(date_0, '', '')
    assert True

# Generated at 2022-06-26 00:32:17.051287
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Any

    class ReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[Any]]:
            ...
    ReadJournalEntries__object_0 = ReadJournalEntries()
    from . import zeitgeist as module_0
    DateRange__object_0 = module_0.Date(2020, 1, 1)
    DateRange__object_1 = module_0.Date(2021, 1, 1)
    period = module_0.DateRange(DateRange__object_0, DateRange__object_1)
    a = ReadJournalEntries__object_0(period)

# Generated at 2022-06-26 00:32:20.848453
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    new_instance_0 = JournalEntry(date_0, '', '')
    new_instance_0.post(date_0, Account(''), Quantity(0))


# Generated at 2022-06-26 00:32:30.169279
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    date_4 = module_0.date()
    date_5 = module_0.date()
    date_6 = module_0.date()
    date_7 = module_0.date()
    date_8 = module_0.date()
    date_9 = module_0.date()
    date_10 = module_0.date()
    date_11 = module_0.date()
    date_12 = module_0.date()
    date_13 = module_0.date()
    date_14 = module_0.date()
    date_15 = module_0.date()
    date_16 = module_

# Generated at 2022-06-26 00:32:31.411034
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Declare function to be tested
    # Assertion 1
    assert True


# Generated at 2022-06-26 00:32:37.680585
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date()
    account_0 = Account(account_id='foo-bar-baz-qux', account_type=AccountType.ASSETS)
    quantity_0 = Amount()
    journal_entry_0 = JournalEntry()
    journal_entry_1 = journal_entry_0.post(date_0, account_0, quantity_0)
    assert journal_entry_1 is journal_entry_0


# Generated at 2022-06-26 00:32:38.623037
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert False, "Not implemented"

# Generated at 2022-06-26 00:32:48.191731
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    account_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    date_1 = None
    journal_entry_1 = JournalEntry(date_1, str_0, str_0)
    journal_entry_1.post(date_1, account_0, 2147483647)
    journal_entry_1.validate()

# Generated at 2022-06-26 00:32:53.989551
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print("Testing method post of class JournalEntry")
    source = None
    description = "G"
    date = None
    account = None
    quantity = 1
    j = JournalEntry(date, description, source)
    j.post(date, account, quantity)
    assert(len(j.postings) == 1), "Test case failed."

if __name__ == '__main__':
    test_case_0()
    test_JournalEntry_post()

# Generated at 2022-06-26 00:32:56.921558
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    account_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    date_1 = None
    var_0 = journal_entry_0.__repr__()


# Generated at 2022-06-26 00:33:00.177030
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    account_0 = None
    str_0 = 'C'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    date_1 = None
    var_0 = journal_entry_0.__repr__()

# Generated at 2022-06-26 00:33:15.294073
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.increments
    journal_entry_0.postings
    journal_entry_0.decrements
    journal_entry_0.debits
    journal_entry_0.credits
    journal_entry_0.postings
    account_0 = None
    int_0 = 1
    quantity_0 = Quantity(int_0)
    journal_entry_0 = journal_entry_0.post(date_0, account_0, quantity_0)
    quantity_1 = Quantity(1)
    journal_entry_0 = journal_entry_0.post(date_0, account_0, quantity_1)

# Generated at 2022-06-26 00:33:18.072369
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    account_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)

    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:28.145328
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    date_1 = None
    quantity_0 = Quantity(0)
    str_1 = '+['
    account_0 = Account(str_1, AccountType.REVENUES)
    journal_entry_0.post(date_1, account_0, quantity_0)
    journal_entry_0.validate()
    str_2 = '/'
    account_1 = Account(str_2, AccountType.EXPENSES)
    journal_entry_0.post(date_1, account_1, quantity_0)
    journal_entry_0.validate()
    date_2 = None
    account_2

# Generated at 2022-06-26 00:33:37.111079
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Method validate of class JournalEntry
    """
    date_0 = None
    account_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    date_0 = None
    date_1 = None
    account_0 = None
    str_0 = 'G'
    journal_entry_1 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.increments

# Generated at 2022-06-26 00:33:46.951544
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from collections import deque
    from random import randrange
    from random import sample

    def test_mutation():
        DATE = sample(DATE_SET, 1)[0]
        ACCOUNT = sample(ACCOUNT_SET, 1)[0]
        QUANTITY = sample(QUANTITY_SET, 1)[0]

        journal_entry_1 = JournalEntry(DATE, DESCRIPTION, None)
        journal_entry_1.post(DATE, ACCOUNT, QUANTITY)
        journal_entry_1.validate()

    DATE_SET = {datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), datetime.date(2020, 1, 3)}

# Generated at 2022-06-26 00:33:57.333524
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    account_0 = None
    str_0 = 'G'
    journal_entry_0 = JournalEntry(date_0, str_0, str_0)
    journal_entry_0.validate()
    date_1 = None
    var_0 = journal_entry_0.__repr__()
    date_2 = None
    journal_entry_1 = JournalEntry(date_2, str_0, str_0)
    var_1 = journal_entry_1.validate()
    account_1 = None
    date_3 = None
    account_2 = None
    date_4 = None
    journal_entry_2 = JournalEntry(date_4, str_0, str_0)
    journal_entry_2.validate()
    dict_0 = None
    dict_0

# Generated at 2022-06-26 00:34:03.411276
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    method: 'ReadJournalEntries[_T]' = ReadJournalEntries.__call__
    t = ReadJournalEntries.__call__
    call: 'Iterable[JournalEntry[_T]]' = t(1)
    pass

# Generated at 2022-06-26 00:34:10.333008
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    description = "description"
    source = "source"
    j = JournalEntry(datetime.date.today(), description, source)
    amount = Amount(100)
    account1 = Account("name", AccountType.ASSETS)
    j.post(datetime.date.today(), account1, amount)
    assert j.postings[0].amount == amount
    assert j.postings[0].account == account1
    assert j.postings[0].direction == Direction.INC
    assert j.postings[0].journal == j
    assert j.postings[0].date == datetime.date.today()
    assert j.increments.count(j.postings[0]) == 1
    assert j.decrements.count(j.postings[0]) == 0

# Generated at 2022-06-26 00:34:13.902464
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_range_0 = DateRange(datetime.date(1, 1, 1), datetime.date(2, 2, 2))
    try:
        journal_entry_0 = call('l')
        journal_entry_0.validate()
    except:
        raise AssertionError


# Generated at 2022-06-26 00:34:19.250021
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class TestClass:
        def __init__(self, journal_entries):
            self.journal_entries = journal_entries
        def __call__(self, period):
            return self.journal_entries
    journal_entries_0 = [JournalEntry('1', '2', '3')]
    t = TestClass(journal_entries_0)
    val = t((1,))
    assert val == journal_entries_0

# Generated at 2022-06-26 00:34:22.470365
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period_0 = DateRange.between(datetime.date(1978, 2, 21), datetime.date(1988, 8, 8))
    journal_entries_0 = ReadJournalEntries()(period_0)
    len(journal_entries_0)

# Generated at 2022-06-26 00:34:26.823420
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry('date', 'description', 'object')
    journal_entry.post(datetime.date.today(), 'account', 1)
    journal_entry.post(datetime.date.today(), 'account', -1)
    journal_entry.validate()

# Generated at 2022-06-26 00:34:29.457792
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(1, 2, 3)
    account_0 = Account(str_0, AccountType.ASSETS)
    quantity_0 = Quantity(int_0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.post(date_0, account_0, int_0)

# Generated at 2022-06-26 00:34:34.788084
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    datetime_0 = datetime.datetime.today()
    date_0 = datetime_0.date()
    account_0 = Account(str_0, str_0, str_0, str_0)
    quantity_0 = Quantity(0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:38.286294
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('m', 'h', 'b')
    journal_entry_0.post(datetime.date(2021, 2, 1), Account('i', AccountType.OTHER), 3)

## Unit test for method validate of class JournalEntry

# Generated at 2022-06-26 00:34:39.861613
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    pass


# Generated at 2022-06-26 00:34:47.847700
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-26 00:34:49.109720
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:34:56.989835
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass
    from typing import List, Sequence
    
    # A type that has been annotated to satisfy the
    # parameterized type of the protocol
    from .accounts import Account
    from .currencies import Currency

    @dataclass
    class JournalEntry:
        date: datetime.date
        account: Account
        currency: Currency
        amount: float
        reference: str

    from .accounts import Account
    from .currencies import Currency
    from .interfaces import Event

    def read_journal_entries(period: DateRange) -> Sequence[Event]:
        pass

    # Test case:
    journal_entries = read_journal_entries(None)



# Generated at 2022-06-26 00:34:58.690718
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert callable(ReadJournalEntries.__call__)

# Generated at 2022-06-26 00:35:08.801730
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'l'
    period_0 = DateRange(str_0, str_0)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    post_0 = Posting(journal_entry_0, str_0, str_0, Direction.INC, Amount(str_0))
    journal_entry_0.postings.append(post_0)
    # def perform(self, self_0, period_0, journal_entry_0):
    #     pass
    # mock_ReadJournalEntries = lambda : perform
    # class ReadJournalEntries(Protocol):
    #     def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
    #         pass

    # print(mock_ReadJournalEntries)
    # ReadJournal

# Generated at 2022-06-26 00:35:21.819064
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = "date"
    date_1 = date_0
    date_2 = date_1
    date_3 = date_2
    date_4 = date_3
    date_5 = date_4
    date_6 = date_5
    date_7 = date_6
    date_8 = date_7
    date_9 = date_8
    date_10 = date_9
    date_11 = date_10
    date_12 = date_11
    str_0 = 'l'
    str_1 = str_0
    str_2 = str_1
    str_3 = str_2
    str_4 = str_3
    str_5 = str_4
    str_6 = str_5
    str_7 = str_6
    str_8 = str_7
   

# Generated at 2022-06-26 00:35:25.696079
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntries2: pass
    read_journal_entries_0 = ReadJournalEntries2()

# vim: et:sw=4:syntax=python:ts=4:

# Generated at 2022-06-26 00:35:28.540129
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '1'
    journal_entry_2 = JournalEntry(str_0, str_0, str_0)
    journal_entry_2.validate()


# Generated at 2022-06-26 00:35:31.666104
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:33.693204
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    assert True


# Generated at 2022-06-26 00:35:46.450255
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(AccountType.ASSETS, str_0)
    str_1 = 'z'
    journal_entry_0.post(str_0, account_0, str_1)

# Generated at 2022-06-26 00:35:56.809530
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_1 = 'l'
    str_2 = 's'
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.validate()
    journal_entry_2 = JournalEntry(str_1, str_2, str_2)
    journal_entry_2.validate()
    journal_entry_3 = JournalEntry(str_2, str_1, str_2)
    journal_entry_3.validate()
    journal_entry_4 = JournalEntry(str_2, str_2, str_1)
    journal_entry_4.validate()
    journal_entry_5 = JournalEntry(str_2, str_1, str_1)
    journal_entry_5.validate()

# Generated at 2022-06-26 00:35:57.957827
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    method_0 = ReadJournalEntries()
    assert False


# Generated at 2022-06-26 00:36:04.464460
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    class ReadJournalEntries_Impl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str_0]]:
            pass

    read_journal_entries_0 = ReadJournalEntries_Impl()
    read_journal_entries_0(DateRange.from_dates(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-26 00:36:13.544829
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'l'
    date_0 = datetime.date(1969, 12, 12)

    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, AccountType.ASSETS)

    journal_entry_0.post(date_0, account_0, Quantity(1))

    assert journal_entry_0.postings[0].journal == journal_entry_0
    assert journal_entry_0.postings[0].date == date_0
    assert journal_entry_0.postings[0].account == account_0
    assert journal_entry_0.postings[0].direction == Direction.INC
    assert journal_entry_0.postings[0].amount == Amount(1)

# Generated at 2022-06-26 00:36:20.639792
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    total_debit = isum(i.amount for i in self.debits)
    total_credit = isum(i.amount for i in self.credits)

    for posting in postings:
        if posting.direction == Direction.INC:
            if posting.account.type in _debit_mapping[Direction.INC]:
                total_debit += posting.amount
            else:
                total_credit += posting.amount
        else:
            if posting.account.type in _debit_mapping[Direction.DEC]:
                total_debit += posting.amount
            else:
                total_credit += posting.amount

    return amount

# Generated at 2022-06-26 00:36:22.958034
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]: pass
    pass


# Generated at 2022-06-26 00:36:32.085440
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_1 = 't'
    str_2 = 'r'
    str_3 = 't'
    str_4 = 'f'
    str_5 = 'h'
    str_6 = 'f'
    str_7 = 't'
    date_1 = datetime.date(2020, 2, 29)
    account_1 = Account(str_6, str_7, AccountType.ASSETS)
    direction_1 = Direction.INC
    amount = Amount(100)
    posting_1 = Posting(str_4, date_1, account_1, direction_1, amount)
    journal_entry = JournalEntry(str_1, str_2, str_3)
    journal_entry.post(date_1, account_1, amount.as_quantity())

# Generated at 2022-06-26 00:36:35.676842
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry('l', 'l', 'l')
    journal_entry.post(datetime.date(2015, 6, 5), 'l', Quantity(10))
    journal_entry.validate()

# Generated at 2022-06-26 00:36:37.507543
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    mapping = {
        'a': 1,
        'b': 2,
    }
    assert sum(mapping.values()) == 3


# Generated at 2022-06-26 00:36:54.941824
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(date=None, description='', source='',  postings=None)
    journal_entry_0.post(date=None, account=None, quantity=0)


# Generated at 2022-06-26 00:36:57.694374
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_0 = JournalEntry(str(), str(), str())
    def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
        journal_entry_0.validate()
    return


# Generated at 2022-06-26 00:37:06.352009
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    account_0 = Account('D', 'D', 'D', account_type=AccountType.ASSETS)
    journal_entry_1 = journal_entry_0.post(datetime.date.today(), account_0, 1)
    journal_entry_1.validate()
    account_1 = Account('D', 'D', 'D', account_type=AccountType.EQUITIES)
    journal_entry_2 = journal_entry_1.post(datetime.date.today(), account_1, 1)
    journal_entry_2.validate()

# Generated at 2022-06-26 00:37:10.229369
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    account_0 = Account(str_0)
    amount_0 = Amount(Amount)
    journal_entry_0.post(None, account_0, 0)
    journal_entry_0.validate()
    journal_entry_0.post(None, account_0, amount_0)
    journal_entry_0.validate()
    journal_entry_0.post(None, account_0, amount_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:14.176540
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    ## AssertionError: Total Debits and Credits are not equal: ZERO != ZERO
    try:
        journal_entry_0.validate()
    except AssertionError:
        pass
    else:
        raise AssertionError("AssertionError not raised")

# Generated at 2022-06-26 00:37:21.389767
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define string str_0
    str_0 = 'l'
    # Define DateRange period_0
    period_0 = DateRange(str_0)
    # Retrieve the journal entries for the date-range period_0:
    #
    #     period_0
    #

# Generated at 2022-06-26 00:37:30.634527
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('l', 'l', 'l')
    if (journal_entry_0.credits == []):
        pass
    else:
        assert ()  #Failed: Expected (), but got 'l'

    if (journal_entry_0.increments == []):
        pass
    else:
        assert ()  #Failed: Expected (), but got 'l'

    if (journal_entry_0.debits == []):
        pass
    else:
        assert ()  #Failed: Expected (), but got 'l'

    if (journal_entry_0.decrements == []):
        pass
    else:
        assert ()  #Failed: Expected (), but got 'l'

    if (journal_entry_0.postings == []):
        pass

# Generated at 2022-06-26 00:37:32.469953
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_case_0()


from .accounts import Account, AccountType


# Generated at 2022-06-26 00:37:41.677927
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange:
    journal = 'l'
    date = datetime.date(2019, 5, 29)
    account = Account("l", AccountType.ASSETS, 'l')
    quantity = Quantity(1)
    obj = JournalEntry(journal, 'l', 'l')
    # Act:
    result = obj.post(date, account, quantity)
    # Assert:
    assert result is obj
    # Validate:
    obj.validate()

# Generated at 2022-06-26 00:37:45.108248
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_1 = 'l'
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_1.post(str_1, str_1, str_1)
    journal_entry_1.validate()



# Generated at 2022-06-26 00:38:15.693593
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:38:21.947129
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'v'
    str_1 = 'B'
    str_2 = '9W1b8eSx'
    str_3 = 'ObQPO>%'
    str_4 = '&F'
    str_5 = 'i$z>dKkR'
    str_6 = '5VK'
    str_7 = 'I8Wqx'
    str_8 = 'N'
    str_9 = 'Kjb<f,'
    str_10 = 't'
    str_11 = 'p={GK!'
    journal_entry_0 = JournalEntry(str_10, str_2, str_3)
    journal_entry_1 = JournalEntry(str_1, str_7, str_9)

# Generated at 2022-06-26 00:38:31.131744
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'c'
    date_0 = datetime.date(2020, 8, 1)
    date_1 = datetime.date(2021, 10, 27)
    date_range_0 = DateRange(date_0, date_1)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    journal_entry_2 = JournalEntry(str_0, str_0, str_0)
    iterable_0 = [journal_entry_0, journal_entry_1, journal_entry_2]
    def ReadJournalEntries___call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        return iterable_0

# Generated at 2022-06-26 00:38:32.372429
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    type_0 = JournalEntry
    type_0.post(2020, None, None)

# Generated at 2022-06-26 00:38:37.339521
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(datetime.datetime.now(), '', None)
    journal_entry_0.post(datetime.datetime.now(), Account('', AccountType.EQUITIES, '', '', ''), Quantity(10000))
    journal_entry_0.post(datetime.datetime.now(), Account('', AccountType.REVENUES, '', '', ''), Quantity(10000))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:45.943730
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    import datetime
    from src.lib.commons.zeitgeist import DateRange
    from src.lib.domain.journal import JournalEntry, Posting, _debit_mapping, Direction, Amount, Account, AccountType, \
        ReadJournalEntries
    from src.lib.domain.services.users import User

    def read(period: DateRange) -> Iterable[JournalEntry[User]]:
        """
        Reads journal entries.
        :param period: Period to read entries within.
        :return: Iterable of entries.
        """
        je_00 = JournalEntry(date(year=2017, month=12, day=1), "Description of JE 0", User("u0000", "U0"))

# Generated at 2022-06-26 00:38:46.720901
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()


# Generated at 2022-06-26 00:38:50.359856
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    description = 'test description'
    source = 'test source'
    journal_entry = JournalEntry(datetime.date.today(), description, source)
    current = journal_entry.post(datetime.date.today(), Account.of(str_0, str_0), float_0)
    assert current is journal_entry

# Generated at 2022-06-26 00:38:52.865340
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'D'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:38:55.270101
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(None, '', None)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS), Quantity(10.0))
    journal.validate()


# Generated at 2022-06-26 00:39:39.103479
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:39:40.972513
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period = DateRange('2018-03-02', '2018-01-01')
    ret = ReadJournalEntries.__call__(ReadJournalEntries, period)
    assert ret is not None


# Generated at 2022-06-26 00:39:46.396822
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2020, 7, 12)
    account_0 = Account('Account_0')
    quantity_0 = Quantity(20)
    journal_0 = JournalEntry(date_0, 'Description of Journal_0', 'l')
    journal_0.post(date_0, account_0, quantity_0)
    assert journal_0.postings[0].account == account_0
    assert journal_0.postings[0].direction == Direction.INC


# Generated at 2022-06-26 00:39:47.371829
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()



# Generated at 2022-06-26 00:39:49.802247
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:39:50.648948
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:39:52.189012
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass


# Generated at 2022-06-26 00:39:57.137676
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.datetime.now()
    account = Account("Account", "description", AccountType.EQUITIES)
    quantity = 100
    journal = JournalEntry("Description", "Source")
    journal.post(date, account, quantity)
    journal.validate()
    journal.post(date, account, 100)
    journal.validate()
    journal.post(date, account, -200)
    journal.validate()
    journal.post(date, account, 0)
    journal.validate()

# Generated at 2022-06-26 00:39:59.108122
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'X'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:40:00.625584
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'i'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:40:41.867938
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'l'
    date_0 = datetime.datetime(2018, 10, 1, 16, 0)
    quantity_0 = Quantity(1)
    account_0 = Account('l', AccountType.ASSETS)
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(date_0, account_0, quantity_0)

    amount_0 = Amount(abs(quantity_0.value))
    posting_0 = Posting(journal_entry_0, date_0, account_0, Direction.of(quantity_0), amount_0)

    assert posting_0 == journal_entry_0.postings[0]

    str_1 = 'l'
    str_2 = 'l'
    str_3 = 'l'

# Generated at 2022-06-26 00:40:50.485843
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Test that, given an instance of JournalEntry, the validate method will return None.
    """
    # We test for all three cases that the method can take
    # (1) Internal variables are all of the same value
    str_0 = 'l'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    # (2) Only the first two variables are of the same value
    journal_entry_1 = JournalEntry(str_0, str_0, 'r')
    journal_entry_1.validate()
    # (3) None of the variables are of the same value
    journal_entry_2 = JournalEntry('f', 'g', 'h')
    journal_entry_2.validate()


# Generated at 2022-06-26 00:40:54.701393
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(1, 1, 1)
    account_0 = Account('test')
    quantity_0 = Quantity('test')
    
    journal_entry_0 = JournalEntry('test', 'test', 'test')
    
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()
