

# Generated at 2022-06-26 00:31:05.188072
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    #create journal entry object
    j = JournalEntry()
    j.date = datetime.date(2020, 12, 15)
    j.description = "Test case for validating journal entry"
    j.source = "Testing"
    j.postings.append(Posting(j, j.date, Account(), Direction.of(0), Amount(abs(0))))
    j.validate()

# Generated at 2022-06-26 00:31:15.231205
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .queries import ReadAccounts, ReadLedgerAccounts
    from . import natures

    read_accounts = ReadAccounts(natures=[natures.income, natures.expense])
    read_ledger_accounts = ReadLedgerAccounts(read_accounts)
    read_journal_entries = ReadJournalEntries()

    read_journal_entries.__call__(DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 7, 31)))
    # OK: Type of returned value is Iterable[JournalEntry[_T]]
    # OK: Call works

    read_journal_entries.__call__(DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 7, 31)))
    # OK:

# Generated at 2022-06-26 00:31:22.626653
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry[int]('2020-02-25', 'Description', 'Source')
    journal.post('2020-02-28', 'Account', +5000)

    assert journal.postings[0].date.strftime('%Y-%m-%d') == '2020-02-28'
    assert journal.postings[0].account == 'Account'
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount.rounded() == 5000
    assert journal.postings[0].is_debit == True



# Generated at 2022-06-26 00:31:29.568661
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .amounts import Accounts, Amounts
    from .source import Source

    book = Source()

    cash_in = JournalEntry(datetime.date.today(), "Cash in", book.cash)
    cash_in.post(datetime.date.today(), Accounts.CASH, Amounts.NINE_HUNDRED)
    assert len(cash_in.postings) == 1
    assert cash_in.debits == cash_in.postings

    cash_out = JournalEntry(datetime.date.today(), "Cash out", book.cash)
    cash_out.post(datetime.date.today(), Accounts.CASH, Amounts.NINE_HUNDRED.negated)
    assert len(cash_out.postings) == 1
    assert cash_out.credits == cash_out.postings

    g

# Generated at 2022-06-26 00:31:38.993674
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    post1 = Posting(JournalEntry(), datetime.date(2020, 8, 14), Account(50, "Bank", AccountType.ASSETS), Direction.INC,
                    Amount(200))
    post2 = Posting(JournalEntry(), datetime.date(2020, 8, 14), Account(10, "Cash", AccountType.ASSETS), Direction.DEC,
                    Amount(100))
    post3 = Posting(JournalEntry(), datetime.date(2020, 8, 14), Account(10, "Cash", AccountType.LIABILITIES), Direction.INC,
                    Amount(100))

# Generated at 2022-06-26 00:31:49.301642
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    asset = Account(AccountType.ASSETS, "1")
    revenue = Account(AccountType.REVENUES, "4")
    expense = Account(AccountType.EXPENSES, "6")
    equity = Account(AccountType.EQUITIES, "9")
    liability = Account(AccountType.LIABILITIES, "12")

    journal_entry_0 = JournalEntry()
    journal_entry_0.post(datetime.date(2020, 2, 20), asset, 0)
    journal_entry_0.post(datetime.date(2016, 1, 22), revenue, 0)
    journal_entry_0.post(datetime.date(2017, 5, 25), expense, 0)
    journal_entry_0.post(datetime.date(2018, 3, 30), equity, 0)

# Generated at 2022-06-26 00:31:55.429531
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry.__new__(JournalEntry)
    j.date = datetime.date(2020, 1, 1)
    j.description = "Test Journal Entry"
    j.source = None
    j.postings = []
    j.post(j.date, Account("1001", "Assets", "Cash"), -1)
    j.post(j.date, Account("1010", "Revenues", "Sales"), 1)
    j.validate()
    print("Test case passed: test_JournalEntry_validate")


# Generated at 2022-06-26 00:32:00.156106
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests the validate method of the JournalEntry class
    """
    # create mocking objects
    mock_object = JournalEntry(None, None, None)
    mock_object.postings = [Posting(mock_object, None, None, Direction.INC, Amount(10))]
    mock_object.validate()

# Generated at 2022-06-26 00:32:09.463256
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1 = Account('Assets', 'Cash', 'Assets')
    account2 = Account('Revenues', 'Cash', 'Revenues')
    account3 = Account('Revenues', 'Sales', 'Revenues')
    account4 = Account('Expenses', 'Credit Sales', 'Expenses')
    test = JournalEntry(datetime.date(2020, 1, 1), 'Cash Sale', '', [])
    test.post(datetime.date(2020, 1, 1), account1, -200)
    test.post(datetime.date(2020, 1, 1), account2, 200)
    test.validate()
    test.post(datetime.date(2020, 1, 1), account3, 200)
    test.validate()

# Generated at 2022-06-26 00:32:12.624244
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    assert False, "TODO: Implement"


# Generated at 2022-06-26 00:32:19.849329
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # arr = read_journal_entries_0(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    # return arr
    pass

# Generated at 2022-06-26 00:32:29.566569
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    This is a unit test for method post of class JournalEntry.
    The goal of the unit test is to evaluate the behaviour of the method under normal/exception/edge cases.
    """
    # Create test case 0:
    # Create test data:

    # Create an JournalEntry object
    j0 = JournalEntry()

    # Call the method
    j0.post(datetime.date(2019,2,2), Account.ASSETS, 2)

    # Check the results
    assert len(j0.postings)==1, "JournalEntry.post Failure: Test case 0 failed."

    # Create test case 1:
    # Create test data:

    # Create an JournalEntry object
    j1 = JournalEntry()

    # Call the method

# Generated at 2022-06-26 00:32:36.254649
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](date=datetime.datetime.now().date(), description="", source=1)
    je.post(datetime.datetime.now().date(), Account(name="Assets", type=AccountType.ASSETS), -100)
    je.post(datetime.datetime.now().date(), Account(name="Revenue", type=AccountType.REVENUES), 100)
    je.validate()



# Generated at 2022-06-26 00:32:37.603815
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    launch_pytest(__name__, __file__, [test_case_0])

# Generated at 2022-06-26 00:32:48.060519
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # Test case 1
    j = JournalEntry(datetime.date(2019, 10, 10), 'test', None)
    j.post(datetime.date(2019, 10, 10), Account('Assets', AccountType.ASSETS), 5)
    assert j is not None, 'j should not be None but it is'
    assert j.increments is not None, 'j.increments should not be None but it is'
    assert j.decrements is not None, 'j.decrements should not be None but it is'
    assert j.debits is not None, 'j.debits should not be None but it is'
    assert j.credits is not None, 'j.credits should not be None but it is'

# Generated at 2022-06-26 00:32:52.669771
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    t = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    t.post(datetime.date(2020, 1, 1), Account("Cash", AccountType.ASSETS), Quantity(10))
    t.post(datetime.date(2020, 1, 1), Account("Sales", AccountType.REVENUES), Quantity(-10))
    t.validate()

# Generated at 2022-06-26 00:32:53.949273
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()

# Generated at 2022-06-26 00:32:59.061982
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date = datetime.date.now()
    je = JournalEntry(date, "", "")
    je.post(date, Account(), 1)
    je.post(date, Account(), -1)
    je.validate()

    je.post(date, Account(), 1)
    je.post(date, Account(), -2)

    try:
        je.validate()
    except:
        pass
    else:
        assert False, "The journal entry validation failed."



# Generated at 2022-06-26 00:33:09.628902
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    date_range_0 = DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1))
    result_0 = read_journal_entries_0(date_range_0)
    assert isinstance(result_0, Iterable)
    assert isinstance(next(iter(result_0), None), JournalEntry)


# Generated at 2022-06-26 00:33:17.708681
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given a journal entry
    journal_entry_test = JournalEntry('20/6/2020', 'test', 200)
    # And an account
    account_test = Account('test account', AccountType.LIABILITIES, True)
    # When we post
    journal_entry_test.post('20/6/2020', account_test, -500)
    # Then the postings has one entry
    assert len(journal_entry_test.postings) == 1
    # And this entry is a debit
    assert journal_entry_test.debits[0].is_debit
    # And this entry is a credit
    assert not journal_entry_test.credits[0].is_credit


# Generated at 2022-06-26 00:33:22.305810
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:33:25.356215
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntries_0(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            pass
    pass


# Generated at 2022-06-26 00:33:34.868264
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    # skip "import"
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]: 
        str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
        journal_entry_0 = JournalEntry(str_0, str_0, str_0)
        journal_entry_0.validate()
        pass
    # skip "import"
    assert () == (read_journal_entries(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 1))))

# Unit test

# Generated at 2022-06-26 00:33:44.566812
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    amount_0 = Amount(1)
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(1, Account(str_0, str_0, AccountType.ASSETS), amount_0)
    journal_entry_0.validate()
    journal_entry_0.post(1, Account(str_0, str_0, AccountType.ASSETS), amount_0)
    journal_entry_0.validate()
    journal_entry_0.post(1, Account(str_0, str_0, AccountType.ASSETS), amount_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:45.257437
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:33:50.182688
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(2019, 1, 1), str_0, 0.0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:52.023537
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the read method for the journal entry protocol\n    '


# Generated at 2022-06-26 00:33:52.918424
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:34:01.861779
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date.today()
    account_0 = Account.of("testing", AccountType.ASSETS)
    date_1 = datetime.date.today()
    account_1 = Account.of("test", AccountType.ASSETS)
    journal_entry = JournalEntry(date_1, "first entry", "test")
    journal_entry.post(date_0, account_0, 1)
    try:
        journal_entry.validate()
    except AssertionError as assertion_error_0:
        print(assertion_error_0)
    journal_entry.post(date_1, account_1, -1)
    journal_entry.validate()


# Generated at 2022-06-26 00:34:02.439704
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-26 00:34:14.072829
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    assert journal_entry_0.post(datetime.date(2019, 12, 18), str_0, 100).validate() == None


# Generated at 2022-06-26 00:34:16.378220
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _(self, period: DateRange) -> Iterable[JournalEntry[_T]]: pass
    ReadJournalEntries.__call__(_, DateRange())

# Generated at 2022-06-26 00:34:21.828070
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(1, 1, 1), Account(str_0), Quantity(1))
    journal_entry_0.post(datetime.date(1, 1, 1), Account(str_0), Quantity(1))

# Generated at 2022-06-26 00:34:24.752633
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(None, None, None)
    journal_entry_0.post(None, None, None)



# Generated at 2022-06-26 00:34:28.256587
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str(), str(), str())
    journal_entry_0.post(datetime.date(1, 1, 1), Account(str(), str(), str(), AccountType.REVENUES), 0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:31.024398
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:33.838042
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:36.878076
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '#'
    var_0 = datetime.date.today()
    var_1 = datetime.date.today()
    var_2 = DateRange([var_0, var_1])


# Generated at 2022-06-26 00:34:41.180272
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    # Exercise
    journal_entry_0.post(0, 0, 0)
    # Verify
    assert journal_entry_0.__dict__ == {}

# Generated at 2022-06-26 00:34:42.123617
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()


# Generated at 2022-06-26 00:34:53.439188
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '

    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_0.validate()



# Generated at 2022-06-26 00:34:56.066858
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_0.post(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:59.357413
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests the validate method of the JournalEntry class
    """
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 00:35:04.767924
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(123, None, 123)

# Generated at 2022-06-26 00:35:05.465638
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:35:13.847447
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(2018, 2, 1), account_0, Quantity(0))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:35:15.531403
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__()


# Generated at 2022-06-26 00:35:19.200301
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:19.775007
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:35:20.708477
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:35:37.724219
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# vim: et:ts=4:sw=4:tw=91:fo=croql:nospell:ft=python:

# Generated at 2022-06-26 00:35:46.665260
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_1 = Account(str_0, AccountType.BALANCE_SHEET)
    account_2 = Account(str_0, AccountType.INCOME_STATEMENT)
    journal_entry_0.post(str_0, account_1, Quantity(1.0))
    journal_entry_0.post(str_0, account_2, Quantity(1.0))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:35:51.749198
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = "D"
    str_1 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_1, str_1, str_1)
    amount_0 = Amount(30)
    journal_entry_0.post(amount_0)


# Generated at 2022-06-26 00:35:56.367769
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account(str_0, str_0, str_0, AccountType.EXPENSES)
    journal_entry_0.post(str_0, account_0, 1)

# Generated at 2022-06-26 00:36:01.482724
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    This method reads the journal entries from the given source file.\n\n    :param source: Path to the source journal file\n    :param period: Read only journal entries in this period\n    '
    # AssertionError: Modification to argument 'source' of protocol method '__call__' of 'ReadJournalEntries' has no effect
    # ReadJournalEntries(str_0)()

# Generated at 2022-06-26 00:36:04.315760
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:36:05.520489
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries = ReadJournalEntries()


# Generated at 2022-06-26 00:36:10.131946
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(year=2019, month=11, day=17), Account(str_0, str_0), Quantity(10))


# Generated at 2022-06-26 00:36:11.306596
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    t = ReadJournalEntries
    t()


# Generated at 2022-06-26 00:36:16.547048
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    
    journal_entry_0.post(str_0, str_0, Amount(str_0))
    journal_entry_0.post(str_0, str_0, Amount(str_0))
    
    
    
    



# Generated at 2022-06-26 00:36:51.179972
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(1, 1, 1), Account(str_0), Quantity(1))

# Generated at 2022-06-26 00:36:55.469722
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, str_0, str(1))


# Generated at 2022-06-26 00:36:58.303753
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:02.003126
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entries = []
    read_journal_entries_0 = lambda period: entries
    period = DateRange(datetime.date(2020, 11, 27), datetime.date(2020, 11, 27))
    assert read_journal_entries_0(period) == entries, 'Failed test for class ReadJournalEntries'


# Generated at 2022-06-26 00:37:07.011111
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Unit test for method post of class JournalEntry\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1 = journal_entry_0.post(datetime.date(2017, 7, 22), Account(str_0, str_0), Quantity(1))
    assert journal_entry_0 == journal_entry_1, 'Assertion failed'

# Generated at 2022-06-26 00:37:09.487624
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:11.967257
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:12.862607
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:37:13.621436
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:37:20.938365
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    print("Test #1")
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:38:33.862261
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entries_0 = ReadJournalEntries()
    try:
        journal_entries_0(str_0)
        assert False
    except TypeError as e:
        str_1 = str(e)
        assert 'object is not subscriptable' in str_1 or "'ReadJournalEntries' object is not subscriptable" in str_1


# Generated at 2022-06-26 00:38:41.482955
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry('\n    Tests the post method of the JournalEntry class\n    ', '\n    Tests the post method of the JournalEntry class\n    ', '\n    Tests the post method of the JournalEntry class\n    ')
    journal_entry_0.post('\n    Tests the post method of the JournalEntry class\n    ', '\n    Tests the post method of the JournalEntry class\n    ', '\n    Tests the post method of the JournalEntry class\n    ')
    journal_entry_0.post('\n    Tests the post method of the JournalEntry class\n    ', '\n    Tests the post method of the JournalEntry class\n    ', '\n    Tests the post method of the JournalEntry class\n    ')

# Generated at 2022-06-26 00:38:46.632384
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime(int(0), int(0), int(0), int(0), int(0), int(0), int(0)), 'account_id_0', int(1))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:53.122764
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'eUy'
    int_0 = 9
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    datetime_0 = datetime.date(2016, 8, 9)
    int_1 = 9
    account_0 = Account(str_0, AccountType.ASSETS, int_1, int_0)
    quantity_0 = Quantity(int_0)
    journal_entry_0 = journal_entry_0.post(datetime_0, account_0, quantity_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:38:56.212985
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    date_range_0 = DateRange(datetime.datetime(2011, 4, 22, 12, 37, 11), datetime.datetime(2021, 2, 8, 1, 0, 17))
    iter_0 = read_journal_entries_0(date_range_0)

# Generated at 2022-06-26 00:39:02.242050
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Unit test for method post of class JournalEntry\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.date.today()
    account_0 = Account(AccountType.EQUITIES, str_0, str_0)
    amount_0 = Amount(4)
    journal_entry_0.post(date_0, account_0, amount_0)
    assert journal_entry_0.postings is not None
    post_0 = journal_entry_0.postings[0]
    assert post_0 is journal_entry_0.postings[0]
    assert post_0.journal is journal_entry_0
    assert isinstance(post_0, Posting)
    assert post_0.amount == Amount

# Generated at 2022-06-26 00:39:04.112027
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '\n    Tests the validate method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:39:07.180514
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2020, 8, 7)
    account_0 = Account(Amount(0), False, '', AccountType.EQUITIES, str())
    quantity_0 = Quantity(1)
    journal_entry_0 = JournalEntry(date_0, str(), str())
    journal_entry_0.post(date_0, account_0, quantity_0)


# Generated at 2022-06-26 00:39:09.441018
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '\n    Tests the post method of the JournalEntry class\n    '
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(str_0, Account('s', AccountType.ASSETS), int_0)


# Generated at 2022-06-26 00:39:14.794068
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(datetime.date(1, 1, 1), '', '')
    account = Account('')
    journal_entry_0.post(datetime.date(1, 1, 1), account, 0)

    journal_entry_1 = JournalEntry(datetime.date(1, 1, 1), '', '')
    account_1 = Account('')
    journal_entry_1.post(datetime.date(1, 1, 1), account_1, 1)

    journal_entry_2 = JournalEntry(datetime.date(1, 1, 1), '', '')
    account_2 = Account('')
    journal_entry_2.post(datetime.date(1, 1, 1), account_2, -1)

