

# Generated at 2022-06-26 00:31:07.459926
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    entry = JournalEntry[None](date=datetime.date(2019, 5, 1), description="Test", source=None)
    account0 = Account(code='1234', description="Test account", type=AccountType.ASSETS)
    entry.post(date=datetime.date(2019, 5, 1), account=account0, quantity=1000)
    assert len(entry.postings) == 1
    posting0 = entry.postings[0]
    assert posting0.account == account0
    assert posting0.amount == 1000


# Generated at 2022-06-26 00:31:11.277508
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries_0 = ReadJournalEntries()
    try:
        read_journal_entries_0.__call__(period=None)
    except NotImplementedError as e:
        print(e.args)
        print(str(e))

# Generated at 2022-06-26 00:31:13.950489
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    for _ in (
        [""],
        ["", "", ""],
        ["", "", "", "", ""],
    ):
        _: Iterable[int]
        assert list(_) == []


# Generated at 2022-06-26 00:31:23.935746
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .commons.business_objects import Customer, Item
    from .commons.date_range import TimePeriod
    from .ledgers import Ledger
    from .postings import Posting
    from .read_accounts import ReadAccounts
    from .read_entries_of_accounts import ReadEntriesOfAccounts

    def read_journal_entries(period: TimePeriod) -> Iterable[Ledger.journal_entry_type]:
        # TODO: Implement
        return iter(())

    # TODO: Implement
    read_customers = lambda: iter(())

    # TODO: Implement
    read_items = lambda: iter(())

    def read_accounts() -> Iterable[Account]:
        # TODO: Implement
        return iter(())


# Generated at 2022-06-26 00:31:30.987957
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
  j = JournalEntry(datetime.date(2020,1,1), "", "source")
  j.postings.append(Posting(j, datetime.date(2020,1,1), Account("A","A",0,AccountType.ASSETS), Direction.INC, Amount(100)))
  j.postings.append(Posting(j, datetime.date(2020,1,1), Account("A","A",0,AccountType.REVENUES), Direction.DEC, Amount(100)))
  j.validate()

# Generated at 2022-06-26 00:31:40.369988
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..sources.accounts import Accounts
    from ..sources.journals import Journals

    accounts = Accounts()
    journals = Journals()

    journal = journals.create_journal(
        "EXAMPLE_JOURNAL",
        """
    Example journal entries.
    """,
    )

    journal.post(date=datetime.date(2020, 1, 1), account=accounts.create_account("MyBank"), quantity=+1000)

    journal.validate()

    assert journal.postings[0].is_debit
    assert journal.postings[0].is_debit
    assert journal.postings[0].account.type in {AccountType.REVENUES, AccountType.EXPENSES}



# Generated at 2022-06-26 00:31:43.205443
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.datetime.now(), "descr", 0)
    je.post(datetime.datetime.now(), Account('A', AccountType.ASSETS), 50)
    je.validate()

# Generated at 2022-06-26 00:31:52.453291
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.zeitgeist import DateRange
    from .accounts import AccountType
    from .postings import Direction

    myJE=JournalEntry()
    date=datetime.date(2020,1,1)
    account=Account()
    account.type=AccountType.EQUITIES
    quantity=Quantity(1)
    myJE.post(date, account, quantity)

    assert myJE.postings[0].direction == Direction.INC, "Direction is not initialized correctly"
    assert myJE.postings[0].is_debit == True, "It is not a debit"
    assert myJE.postings[0].is_credit == False, "It is not a credit"

    account=Account()
    account.type=AccountType.REVENUES

# Generated at 2022-06-26 00:31:53.391140
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries = ReadJournalEntries()
    assert False


# Generated at 2022-06-26 00:31:57.884426
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    try:
        read_journal_entries_0 = ReadJournalEntries()
        read_journal_entries_0(DateRange(datetime.date(1970, 1, 1), datetime.date(1970, 1, 1)))
    except NotImplementedError:
        pass
    else:
        raise Exception()


# Generated at 2022-06-26 00:32:07.060359
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    # Test parameters
    period: DateRange

    # Test body
    read_journal_entries_0 = ReadJournalEntries()
    read_journal_entries_0(period)

# Generated at 2022-06-26 00:32:13.787284
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ledger = JournalEntry()

    ledger.post(datetime.date(2019, 1, 1), Account("100", "Cash"), 100)
    ledger.post(datetime.date(2019, 1, 1), Account("200", "Sales"), -200)

    assert len(ledger.postings) == 2
    assert ledger.postings[0].amount == Amount(100)
    assert ledger.postings[0].direction == Direction.INC
    assert ledger.postings[1].amount == Amount(200)
    assert ledger.postings[1].direction == Direction.DEC


# Generated at 2022-06-26 00:32:21.178787
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    jentry = JournalEntry(date=datetime.date(2018, 4, 1), description='Test Entry', source=None)
    jentry.post(date=datetime.date(2018, 4, 1), account=Account('Cash', AccountType.ASSETS), quantity=100)
    jentry.post(date=datetime.date(2018, 4, 1), account=Account('Revenue', AccountType.REVENUES), quantity=-100)
    jentry.validate()

# Generated at 2022-06-26 00:32:30.169468
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = Account()
    je = JournalEntry(datetime.datetime.today(), "", '')
    assert len(je.postings) == 0
    je.post(datetime.datetime.today(), a, 0)
    assert len(je.postings) == 0
    je.post(datetime.datetime.today(), a, 1)
    assert len(je.postings) == 1
    je.post(datetime.datetime.today(), a, -1)
    assert len(je.postings) == 2
    je.post(datetime.datetime.today(), a, -1)
    assert len(je.postings) == 3
    je.post(datetime.datetime.today(), a, 1)
    assert len(je.postings) == 4

# Generated at 2022-06-26 00:32:35.493688
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create JournalEntry instance
    j = JournalEntry()
    j.date = datetime.date(2020, 6, 30)
    j.description = "Test Journal Entry"

    # Post to account
    j.post(datetime.date(2020, 6, 30), Account("Account 1", AccountType.ASSETS), Quantity(100))


# Generated at 2022-06-26 00:32:37.140968
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    x = read_journal_entries_0(DateRange)
    assert x == expected_output

# Generated at 2022-06-26 00:32:47.629389
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType

    j0 = JournalEntry(date=datetime.date(2020, 4, 4), description="A")
    jt = j0.post(date=datetime.date(2020, 4, 4), account=Account(name="A", type=AccountType.EQUITIES), quantity=+100)
    assert j0.postings[0].direction == Direction.INC
    assert j0.postings[0].account.type == AccountType.EQUITIES
    assert isinstance(jt, JournalEntry)
    assert jt == j0
    assert len(jt.postings) == 1

    jt = j0.post(date=datetime.date(2020, 4, 4), account=Account(name="B", type=AccountType.EQUITIES), quantity=-100)
    assert j0.post

# Generated at 2022-06-26 00:32:50.329672
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries = ReadJournalEntries()
    assert read_journal_entries.__call__(DateRange(datetime.date(1,1,1),datetime.date(1,1,1))) == None

# Generated at 2022-06-26 00:32:53.667864
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "test", "")
    j.post(datetime.date.today(), "A", 1)
    j.post(datetime.date.today(), "B", -1)
    j.validate()

# Generated at 2022-06-26 00:32:54.878203
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert isinstance(ReadJournalEntries, type)
    pass


# Generated at 2022-06-26 00:33:17.629351
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import new_account, AccountType
    from ..commons.times import today
    from ..commons.zeitgeist import DateRange
    journal_0 = JournalEntry[int](today(), "Test Journal Entry 0", 0)
    journal_1 = JournalEntry[int](today(), "Test Journal Entry 1", 1)
    account_0 = new_account("Test Account 0", AccountType.ASSETS, "TestAccount0")
    account_1 = new_account("Test Account 1", AccountType.LIABILITIES, "TestAccount1")
    journal_0.post(today(), account_0, 1000.00)
    journal_0.post(today(), account_1, -1000.00)
    journal_1.post(today(), account_0, 100.00)

# Generated at 2022-06-26 00:33:25.356379
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.datetime.now().date(), "Test Journal Entry", "Test Biz Object", [])
    assert len(je.postings) == 0
    je.post(datetime.datetime.now().date(), Account("Test Account", AccountType.ASSETS), 100)
    assert len(je.postings) == 1
    assert je.postings[0].account.name == "Test Account"
    je.post(datetime.datetime.now().date(), Account("Test Account", AccountType.ASSETS), 100)
    assert len(je.postings) == 1


# Generated at 2022-06-26 00:33:27.133440
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal_entries = ReadJournalEntries()
    read_journal_entries.__call__()

# Generated at 2022-06-26 00:33:36.388210
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_JournalEntry1 = JournalEntry(datetime.date(2018,8,12), "test","test1")
    test_JournalEntry2 = JournalEntry(datetime.date(2018,8,12), "test","test1")
    test_JournalEntry1.post(datetime.date(2018,8,12), Account("a","a",AccountType.ASSETS),2)
    test_JournalEntry1.post(datetime.date(2018,8,12), Account("b","b",AccountType.LIABILITIES),2)
    test_JournalEntry2.post(datetime.date(2018,8,12), Account("a","a",AccountType.ASSETS),2)
    test_JournalEntry2.post(datetime.date(2018,8,12), Account("b","b",AccountType.LIABILITIES),3)
   

# Generated at 2022-06-26 00:33:37.782765
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True == True


# Generated at 2022-06-26 00:33:38.677087
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_case_0()


# Generated at 2022-06-26 00:33:49.056863
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    This method will test the function validate of class JournalEntry
    
    """
    # Create an object of class JournalEntry
    journalEntry_0 = JournalEntry()
    
    # Call the method validate - This should not throw any error
    journalEntry_0.validate()
    
    # Create a new list for the postings
    journalPostings_0 = [Posting(journal=journalEntry_0, date=datetime.date, account=Account, direction=Direction, amount=Amount)]
    
    # Create a new object of class JournalEntry
    journalEntry_1 = JournalEntry(
        date=datetime.date(2000, 1, 1),
        description="Expected",
        source=journalEntry_0,
        guid=None,
        postings=journalPostings_0
    )
    
    # Call the method validate -

# Generated at 2022-06-26 00:33:54.199362
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry(datetime.date(2019, 12, 31), "Cash Sale", None)
    journal_entry_0.post(datetime.date(2019, 12, 31), "Assets:Cash", -100)
    journal_entry_0.post(datetime.date(2019, 12, 31), "Revenues", 100)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:01.422120
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Setup:
    journal_entry_0 = JournalEntry(datetime.date(2010, 1, 20), "Test", None)
    journal_entry_0.post(datetime.date(2010, 1, 20), Account("Test", AccountType.ASSETS), 1)
    journal_entry_0.post(datetime.date(2010, 1, 20), Account("Test", AccountType.EQUITIES), -1)
    ## Exercise:
    journal_entry_0.validate()
    ## Verify:
    assert True



# Generated at 2022-06-26 00:34:05.571023
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_a = Account((0, "Assets", AccountType.ASSETS))
    journal_entry_a = JournalEntry[int](date=datetime.date.today(), description="description_a", source=0)
    journal_entry_a.post(date=datetime.date.today(), account=account_a, quantity=Quantity(1))
    journal_entry_a.validate()

# Generated at 2022-06-26 00:34:21.913784
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = None
    bool_0 = True
    journal_entry_0 = JournalEntry(date_0, str_0, bool_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:22.894315
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:34:28.614952
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = None
    bool_0 = True
    journal_entry_0 = JournalEntry(date_0, str_0, bool_0)
    date_0 = None
    account_0 = Account(str_0, str_0, str_0, bool_0)
    journal_entry_0.post(date_0, account_0, 0)


# Generated at 2022-06-26 00:34:31.705595
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str_0, bool_0, date_0)
    quantity_0 = bool_0
    journal_entry_0.post(date_0, account_0, quantity_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:34:37.840171
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = None
    str_0 = None
    bool_0 = True
    journal_entry_0 = JournalEntry(date_0, str_0, bool_0)
    date_0 = None
    account_0 = Account(date_0, Accounts)
    quantity_0 = None
    journal_entry_0.post(date_0, account_0, quantity_0)


if __name__ == "__main__":
    test_case_0()
    test_JournalEntry_post()
    print("All tests passed")

# Generated at 2022-06-26 00:34:41.051769
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    period = None
    # Template type: T
    t = None
    # Template type: T
    t = JournalEntry
    # Template type: T
    t = ReadJournalEntries
    t = None
    t = ReadJournalEntries(t)
    t(t)

# Generated at 2022-06-26 00:34:44.005766
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = None
    str_0 = None
    bool_0 = True
    journal_entry_0 = JournalEntry(date_0, str_0, bool_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:53.363333
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date.today()
    str_0 = "This is a test of the JournalEntry type. "
    str_1 = None
    journal_entry_0 = JournalEntry(date_0, str_0, str_1)
    account_0 = Account("Cash", AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, 1)
    journal_entry_0.post(date_0, account_0, -1)
    journal_entry_0.post(date_0, None, 1)
    journal_entry_0.post(date_0, account_0, 1)
    journal_entry_0.post(date_0, account_0, 0)



# Generated at 2022-06-26 00:34:58.571027
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = None
    str_0 = None
    bool_0 = True
    journal_entry_0 = JournalEntry(date_0, str_0, bool_0)
    journal_entry_0.validate()
    period_0 = None
    obj_0 = ReadJournalEntries(journal_entry_0)
    assert isinstance(obj_0, ReadJournalEntries)



# Generated at 2022-06-26 00:35:08.725563
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    num_0 = -0.0505
    num_1 = -0.1670
    num_2 = -0.5403
    num_3 = -0.8871
    str_0 = None
    bool_0 = True
    date_0 = None
    num_4 = -0.6956
    num_5 = 0.8265
    num_6 = 0.4509
    num_7 = -0.3730
    num_8 = -0.8603
    num_9 = -0.9333
    journal_entry_0 = JournalEntry(date_0, str_0, bool_0)
    journal_entry_0.post(date_0, bool_0, Quantity(num_0))
    journal_entry_0.post(date_0, bool_0, Quantity(num_1))

# Generated at 2022-06-26 00:35:24.231504
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 00:35:36.760001
# Unit test for method post of class JournalEntry

# Generated at 2022-06-26 00:35:47.494044
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(bool_1, bool_2, bool_3)
    bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6
    if bool_0:
        bool_0 = bool_6

# Generated at 2022-06-26 00:35:51.021753
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    bool_0 = True
    journal_entry_0 = JournalEntry(bool_0, bool_0, bool_0)
    journal_entry_0.post(datetime.date.today(), Account(bool_0, bool_0), 0)


# Generated at 2022-06-26 00:35:56.604226
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry = JournalEntry(bool, str, bool)
    from datetime import date
    date_0 = date(2018, 1, 1)
    date_1 = date(2019, 1, 1)
    def ReadJournalEntries___call__(period: DateRange) -> Iterable[JournalEntry[bool]]:
        pass
    ReadJournalEntries___call__(DateRange.date_to_date(date_0, date_1))


# Generated at 2022-06-26 00:35:58.928031
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    a= datetime.date(2017, 8, 29)
    aa= datetime.date(2017, 8, 30)
    aaa= DateRange(a,aa)


# Generated at 2022-06-26 00:36:05.644741
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    bool_0 = True
    journal_entry_0 = JournalEntry(bool_0, bool_0, bool_0)
    date_0 = datetime.date(1, 1, 1)
    account_0 = Account(bool_0, AccountType.EXPENSES, bool_0, bool_0)
    journal_entry_0.post(date_0, account_0, 123.4)
    journal_entry_0.post(date_0, account_0, 0.0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:36:14.628984
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass, field
    from datetime import date
    from datetime import datetime
    from datetime import time
    from datetime import timedelta
    from dataclasses import dataclass, field
    from pytz import utc
    from typing import List
    import sys
    import typing
    import unittest
    from unittest import TestCase
    from unittest import mock
    import uuid
    from abc import abstractmethod
    from dataclasses import dataclass, field
    from unittest import TestCase
    from ..commons.numbers import Quantity
    from ..commons.timeline import Span
    from ..commons.timeline import TimePeriod
    from ..commons.timeline import TimePeriodList

    # TODO: Define a fake class

# Generated at 2022-06-26 00:36:23.826856
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create the object for class int_0 with value 20
    int_0 = 20
    # Create the object for class bool_0 with value True
    bool_0 = True
    # Create the object for class journal_entry_0 with value bool_0, bool_0, bool_0
    journal_entry_0 = JournalEntry(bool_0, bool_0, bool_0)
    # Create the object for class date_0 with value bool_0
    date_0 = bool_0
    # Create the object for class quantity_0 with value int_0
    quantity_0 = int_0
    # Create the object for class account_0 with value bool_0
    account_0 = bool_0
    # Post to journal entry
    journal_entry_0.post(date_0, account_0, quantity_0)
    # Create the

# Generated at 2022-06-26 00:36:26.991547
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journalentry_0 = JournalEntry(datetime.date(2028, 7, 3), "", None)
    journalentry_0.post(datetime.date(2028, 7, 3), Account("", AccountType.ASSETS), 0)
    journalentry_0.validate()

# Generated at 2022-06-26 00:37:01.712985
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry(datetime.date(2020, 1, 20), "Description", True)
    date_0 = datetime.date(2020, 1, 20)
    account_0 = Account("Account", AccountType.ASSETS)
    quantity_0 = Quantity(1)
    journal_entry.post(date_0, account_0, quantity_0)
    journal_entry.post(date_0, account_0, quantity_0)
    journal_entry.post(date_0, account_0, quantity_0)

# Generated at 2022-06-26 00:37:07.598216
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assets = Account(AccountType.ASSETS, "99999", "Assets")
    revenues = Account(AccountType.REVENUES, "88888", "Revenues")
    journal_entry_0 = JournalEntry(datetime.date(1,1,1), "", None)
    journal_entry_0.post(datetime.date(1,1,1), assets, 1)
    journal_entry_0.post(datetime.date(1,1,1), revenues, 1)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:09.523846
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    bool_0 = True
    journal_entry_0 = JournalEntry(bool_0, bool_0, bool_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:21.273821
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = JournalEntry(True, True, True)
    a.post(True, Account("a", AccountType.ASSETS), 2.0)
    a.post(True, Account("b", AccountType.ASSETS), -2.0)
    a.validate()

    b = JournalEntry(True, True, True)
    b.post(True, Account("a", AccountType.ASSETS), 1.0)
    b.post(True, Account("b", AccountType.ASSETS), -0.5)
    b.post(True, Account("c", AccountType.ASSETS), -0.5)
    b.validate()

    c = JournalEntry(True, True, True)
    c.post(True, Account("a", AccountType.ASSETS), -1.0)
    c.validate()

# Generated at 2022-06-26 00:37:23.494951
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(False, False, False)
    journal_entry_0.post(False, False, 0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:32.082697
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date
    amount = 0
    amount_0 = amount
    amount_1 = amount
    amount_2 = amount
    amount_3 = amount
    amount_4 = amount
    amount_5 = amount
    amount_6 = amount
    amount_7 = amount
    amount_8 = amount
    account = Account.assets
    account_0 = account
    account_1 = account
    account_2 = account
    account_3 = account
    account_4 = account
    bool_0 = bool
    str_0 = str
    source_0 = bool_0
    quantity = 0
    quantity_0 = quantity
    quantity_1 = quantity
    quantity_2 = quantity
    quantity_3 = quantity
    quantity_4 = quantity
    quantity_5 = quantity
    quantity_6 = quantity
    quantity_7

# Generated at 2022-06-26 00:37:44.894676
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    bool_0 = True
    bool_1 = bool_0
    bool_1 = not bool_0
    journal_entry_0 = JournalEntry(bool_0, bool_0, bool_0)
    journal_entry_0.validate()
    bool_1 = bool_0
    if not bool_0:
        if not bool_0:
            if bool_1:
                bool_1 = bool_0
    if bool_0:
        bool_1 = bool_0
    if not bool_1:
        bool_1 = bool_0
    else:
        bool_1 = bool_0
    obj_0 = object()
    date_0 = datetime.date(1092, 10, 10)
    account_0 = Account(date_0, date_0)

# Generated at 2022-06-26 00:37:48.008416
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    bool_0 = True
    journal_entry_0 = JournalEntry(bool_0, bool_0, bool_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:01.056558
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    raising: bool = False

    # Define a journal entry object
    journal_entry_0 = JournalEntry(datetime.date(2020, 1, 1), '', object())
    journal_entry_0.validate()

    # Post a value to a given account using journal_entry_0
    journal_entry_0.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, '', '', ''), 10)
    journal_entry_0.validate()

    # Post a value to a given account using journal_entry_0
    journal_entry_0.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, '', '', ''), 0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:02.207897
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_case_0()

# Generated at 2022-06-26 00:39:06.219289
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..app.accounts import Account
    from ..app.main import date_range

    account_0 = Account(str(), str())
    amount_0 = Amount()
    date_0 = date.today()
    date_0_0 = date.today()
    date_range_0 = date_range(date_0, date_0_0)
    direction_0 = Direction.DEC
    journal_entry_0 = JournalEntry(date_0, str(), bool())
    posting_0 = Posting(journal_entry_0, date_0, account_0, direction_0, amount_0)
    journal_entries_0 = [posting_0]

    def _closure():
        yield posting_0

    read_journal_entries_0 = ReadJournalEntries()

# Generated at 2022-06-26 00:39:06.856520
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:39:07.257194
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True

# Generated at 2022-06-26 00:39:12.842488
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account
    from .accounts import AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry
    from .journal import Posting
    from .journal import ReadJournalEntries
    from .journal import Direction
    from .journal import _debit_mapping
    journal_entry_0 = JournalEntry(date(1, 1, 1), '', '')
    posting_0 = Posting(journal_entry_0, date(1, 1, 1), Account(AccountType.ASSETS, '', ''), Direction.INC, 1)
    bool_0 = bool()
    date_0 = date(1, 1, 1)
    amount_0 = Amount(1)
    account_0 = Account(AccountType.ASSETS, '', '')
    quantity_

# Generated at 2022-06-26 00:39:14.073790
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    func = ReadJournalEntries.__call__
    journal_entry = JournalEntry(None, None, None)
    assert func(journal_entry)

# Generated at 2022-06-26 00:39:16.527874
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Create an instance
    read_journal_0 = ReadJournalEntries()

    period = DateRange(datetime.date.today(), datetime.date.today())

    # Invoke method __call__
    r = read_journal_0.__call__(period)
    assert isinstance(r, Iterable[JournalEntry])


# Generated at 2022-06-26 00:39:17.858076
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry_0 = JournalEntry(True, True, True)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:39:19.705764
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0: JournalEntry[bool] = JournalEntry(bool, bool, bool)
    account_0 = Account(bool, bool)
    journal_entry_0.post(datetime.date, account_0, int)

# Generated at 2022-06-26 00:39:23.706908
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    bool_0 = True
    bool_1 = False
    myAccount = Account(bool_0, bool_0)
    myQuantity = Quantity(bool_0)
    myJournalEntry = JournalEntry(bool_0, bool_0, bool_0)
    myJournalEntry.post(bool_0, myAccount, myQuantity)
    # myJournalEntry.postings.append(myPosting)
    assert myJournalEntry.postings[0].amount.__eq__(myQuantity.numerator)



# Generated at 2022-06-26 00:39:27.613168
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a_journal_entry = JournalEntry(datetime.date.today(), "test description", "test source")
    a_posting = Posting(a_journal_entry,
                        datetime.date.today(),
                        Account("test account name", AccountType.ASSETS),
                        Direction.INC,
                        Amount(1))
    a_journal_entry.postings.append(a_posting)
    assert a_journal_entry.postings[0] == a_posting
