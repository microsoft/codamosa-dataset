

# Generated at 2022-06-26 00:31:01.075631
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_0 = JournalEntry('dummy_source', 'dummy_description')
    journal_0.post(datetime.date.today(), 'dummy_account', Quantity(10))
    journal_0.post(datetime.date.today(), 'dummy_account', Quantity(-10))
    journal_0.validate()

# Generated at 2022-06-26 00:31:04.012174
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    direction_0 = Direction.DEC
    period = DateRange(datetime.date(year=2019,month=6,day=6),datetime.date(year=2019,month=6,day=6))
    pass


# Generated at 2022-06-26 00:31:11.324382
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print("Testing method post of class JournalEntry")
    account = Account("Acc", AccountType.ASSETS, None, None)

    journal = JournalEntry(date = datetime.date(1900, 5, 25), description = "Desc", source = None, postings = [])
    quantity = Quantity(2001)
    journal.post(date = datetime.date(1900, 5, 25), account = account, quantity = quantity)

    # assert len(journal.postings) == 1
    print("Test passed for method post of class JournalEntry")


# Generated at 2022-06-26 00:31:18.464137
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = datetime.date(2020, 7, 1)
    account_0 = Account(100, "Cash")
    quantity_0 = Quantity(5000)
    journalentry_0 = JournalEntry(date_0, "Test Entry", None)
    journalentry_0.post(date_0, account_0, quantity_0)
    assert journalentry_0.postings[0].account == account_0
    assert journalentry_0.postings[0].direction == Direction.DEC
    assert journalentry_0.postings[0].amount == Amount(5000)


# Generated at 2022-06-26 00:31:29.406215
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(date=datetime.date(2020, 1, 1), description="Test", source="not_important")
    je.post(datetime.date(2020, 1, 1), Account(type=AccountType.ASSETS, name="Cash"), 1000)
    je.post(datetime.date(2020, 1, 1), Account(type=AccountType.LIABILITIES, name="Creditors"), -1000)


# Generated at 2022-06-26 00:31:38.835074
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Journal entry model must support validations.
    It must validate that the sum of debits is equal to the sum of credits.
    """
    je = JournalEntry(datetime.date(2020, 7, 1), "Simple example")
    je.post(datetime.date(2020, 6, 30), Account("FX", AccountType.ASSETS), amount=-100)
    je.post(datetime.date(2020, 6, 30), Account("Cash", AccountType.ASSETS), amount=100)
    je.validate()

    je = JournalEntry(datetime.date(2020, 7, 1), "Debits greater than credits")
    je.post(datetime.date(2020, 6, 30), Account("FX", AccountType.ASSETS), amount=-100)

# Generated at 2022-06-26 00:31:48.066072
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # journale1 is a valid JournalEntry
    journale1 = JournalEntry("11/11/11", "Accounting for 1st November", "A", [Posting("11/11/11", "Acc1", Direction.INC, 5), Posting("11/11/11", "Acc2", Direction.DEC, 5)])
    # journale2 is not a valid JournalEntry
    journale2 = JournalEntry("01/01/01", "Accounting for 1st January", "B", [Posting("01/01/01", "Acc1", Direction.INC, 5), Posting("01/01/01", "Acc2", Direction.DEC, 6)])
    journale1.validate()

# Generated at 2022-06-26 00:31:50.777009
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def test_instance_0():
        # Execute method __call__
        try:
            ReadJournalEntries.__call__(None, None)
        except NotImplementedError:
            pass

# Generated at 2022-06-26 00:31:58.885369
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    now = datetime.datetime.now()
    date = datetime.date(now.year, now.month, now.day)
    account = Account("Test Account", "Test Account Type")
    j = JournalEntry(date, "Test Journal", Account("Test Account", "Test Account Type"))
    j.post(date, account, Quantity(100))
    assert j.postings[0].journal == j
    assert j.postings[0].date == date
    assert j.postings[0].account == account
    assert j.postings[0].direction == Direction.INC
    assert j.postings[0].amount.quantity == 100



# Generated at 2022-06-26 00:32:04.137888
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journalEntry = JournalEntry[str](date = datetime.date(2020, 1, 1), description = "Opening Balances", source = "Initial Post", postings = [])
    journalEntry.post(datetime.date(2020, 1, 1), Account(account_id="A001", name = "Equities", type = AccountType.EQUITIES), Quantity(4))
    journalEntry.validate()

# Generated at 2022-06-26 00:32:10.733191
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Construct ReadJournalEntries
    # ReadJournalEntries()

    # Assert fail
    assert False, "Replace this with a real test"

# Generated at 2022-06-26 00:32:11.277023
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-26 00:32:16.420131
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    # first, let's create a class Object with right signature
    class Object:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    ReadJournalEntries.__instancecheck__(Object)   # let's do type checking
    ReadJournalEntries.__subclasscheck__(Object)   # let's do type checking
    ReadJournalEntries.register(Object)   # let's add it as a descendant of ReadJournalEntries

# Generated at 2022-06-26 00:32:17.428384
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-26 00:32:18.232220
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:32:25.682346
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given
    j = JournalEntry[object]("2020/10/01", "true", object(), [])
    date_0 = datetime.date(year=2020, month=10, day=1)
    account_0 = Account(0, "", "", AccountType.ASSETS)
    quantity_0 = Quantity(0)

    # When
    j.post(date_0, account_0, quantity_0)

    # Then
    assert True



# Generated at 2022-06-26 00:32:32.756380
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define some instances of ReadJournalEntries
    ReadJournalEntries_instance_0 = ReadJournalEntries()
    ReadJournalEntries_instance_1 = ReadJournalEntries()
    # Mute the following line in case you don't want to test `__call__`
    ReadJournalEntries_instance_0.__call__(DateRange())
    # Mute the following line in case you don't want to test `__call__`
    ReadJournalEntries_instance_1.__call__(DateRange())


# Generated at 2022-06-26 00:32:36.777031
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    a = ReadJournalEntries()
    b = DateRange.from_dates(date_from=datetime.date(2019, 1, 1), date_to=datetime.date(2019, 1, 30))
    a(b)

# Generated at 2022-06-26 00:32:47.171610
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    date = datetime.date.today()
    date_0 = date.replace(day=1)
    date_1 = date.replace(day=20)
    account_0 = Account("account_0", AccountType.REVENUES)
    account_1 = Account("account_1", AccountType.LIABILITIES)
    account_2 = Account("account_2", AccountType.EQUITIES)
    account_3 = Account("account_3", AccountType.EXPENSES)
    business_object_0 = 0
    journal_entry_0 = JournalEntry(date, "description", business_object_0)
    quantity_0 = 1
    quantity_1 = -1

    # Exercise
    journal_entry_1 = journal_entry_0.post(date_0, account_0, quantity_0)
    journal

# Generated at 2022-06-26 00:32:47.851820
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-26 00:33:00.097722
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account("Assets", "Savings", "Bank", "Checking")
    je = JournalEntry(datetime.date(2020, 2, 26), "description", "source")
    je.post(datetime.date(2020, 2, 26), account, 20)
    account = Account("Expenses", "Expenses", "Other", "Other")
    je.post(datetime.date(2020, 2, 26), account, -20)
    je.validate()
    je.post(datetime.date(2020, 2, 26), account, -10)
    je.validate()
    je.post(datetime.date(2020, 2, 26), account, 10)
    je.validate()

# Generated at 2022-06-26 00:33:15.213958
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    period = DateRange(datetime.date(2020, 1, 1))

    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(period.start, str_0, str_0)
    journal_entry_0.post(period.start, Account('Assets', 'Cash'), 1000)
    journal_entry_0.post(period.start, Account('Equities', 'Capital'), -1000)
    journal_entry_0.validate()  # This should not raise an exception

    journal_entry_1 = JournalEntry(period.start, str_0, str_0)
    journal_entry_1.post(period.start, Account('Equities', 'Capital'), 1000)
    journal_entry_1.post(period.start, Account('Assets', 'Cash'), -1000)
    journal_entry

# Generated at 2022-06-26 00:33:22.695095
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()
    journal_entry_0.post(datetime.date(year=2019, month=1, day=1), Account('ABC1', 'Account 1', AccountType.ASSETS),
                         Quantity(1000))
    journal_entry_0.post(datetime.date(year=2019, month=1, day=1), Account('ABC2', 'Account 2', AccountType.ASSETS),
                         Quantity(-1000))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:31.973509
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    test_account_0 = Account('Test_Account_0', AccountType.ASSETS, None)
    test_posting_0 = Posting(journal_entry_0, str_0, test_account_0, Direction.DEC, Amount(1))
    assert not hasattr(journal_entry_0, 'postings')
    journal_entry_0.post(str_0, test_account_0, Quantity(1))
    assert hasattr(journal_entry_0, 'postings')
    assert journal_entry_0.postings[0]==test_posting_0


# Generated at 2022-06-26 00:33:41.750062
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
  #Test for a successful read of journal entries for the period.
  class ReadJournalEntriesImpl_class_1(ReadJournalEntries[_T]):
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
      return [JournalEntry(_T(), _T(), _T()) for _T in range(10)]
  read_journal_entries_1 = ReadJournalEntriesImpl_class_1()
  assert read_journal_entries_1(DateRange(datetime.date.today(), datetime.date.today())) == [JournalEntry(_T(), _T(), _T()) for _T in range(10)]
  #Test for account type, giving a bad account type.

# Generated at 2022-06-26 00:33:46.063692
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry("Accounting for 1st January", "Accounting for 1st January", "Accounting for 1st January")
    journal_entry_0.post("Cash", 100)
    journal_entry_0.post("Cash", -20)
    journal_entry_0.post("Cash", -80)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:33:51.740605
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'Accounting for 1st January'
    def read_journal_entries(period:DateRange) -> Iterable[JournalEntry[str]]:
        return [JournalEntry(str_0, str_0, str_0)]
    read_journal_entries_0 = ReadJournalEntries(read_journal_entries)
    read_journal_entries_0(DateRange(str_0, str_0))

# Generated at 2022-06-26 00:33:54.372669
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:33:56.292098
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    obj = ReadJournalEntries()
    assert isinstance(obj.__call__(), Iterable)



# Generated at 2022-06-26 00:33:56.875053
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:34:05.481718
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()


# Generated at 2022-06-26 00:34:07.755088
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    # calling validate() without either DEBIT or CREDIT postings, should raise an error
    assert_raises(AssertionError, journal_entry_0.validate)

# Generated at 2022-06-26 00:34:11.728579
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(2019, 1, 1), Account('Cash', AccountType.ASSETS), 10)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:34:13.997410
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(None, None, None)
    account_0 = Account(None, None)
    journal_entry_0.post(None, account_0, None)

# Generated at 2022-06-26 00:34:16.678518
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True == True, "Cannot test abstract class ReadJournalEntries"

if __name__ == '__main__':
    test_case_0()
    test_ReadJournalEntries___call__()

# Generated at 2022-06-26 00:34:22.593510
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Test 0: Positive case
    try:
        test_case_0()
    except AssertionError as e:
        print('Test 0: Positive case')
        print('Response:')
        print('\tTotal debits and credits do not match, assertion error')
        print('Expected:')
        print('\tAssertionError')
        print('Actual:')
        print('\t' + str(e))
        assert False
    finally:
        print('\n')

# Generated at 2022-06-26 00:34:28.337514
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import datetime, timedelta
    from dataclasses import dataclass, field
    from typing import List, Iterable, Generic, Protocol, TypeVar
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    import itertools
    T = TypeVar('T')
    def __call__(_period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

# Generated at 2022-06-26 00:34:30.838849
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry("date", "description", "source")
    j.post(datetime.date.today(), Account("account_name"), Quantity(1))
    assert j.postings[0].direction == Direction.INC

# Generated at 2022-06-26 00:34:34.658302
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create a JournalEntry object with date, description and source
    date = datetime.date(2020, 7, 20)
    description = 'Accounting '
    source = 'first posting'
    je = JournalEntry(date, description, source)

    # Create an account
    account = 'cash'
    acc_type = AccountType.ASSETS
    a = Account(account, acc_type)

    # Post a positive value to the account
    quantity = 10
    je.post(date, a, quantity)

    # Post a negative value to the account
    quantity1 = -10
    je.post(date, a, quantity1)

    # Assert the value of postings

# Generated at 2022-06-26 00:34:43.615849
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_1 = JournalEntry('Accounting for 1st January', 'Accounting for 1st January', 'Accounting for 1st January')
    journal_entry_1.post(datetime.date(2000, 1, 1), Account('ASSET', 'Cash'), Quantity(10))
    journal_entry_1.post(datetime.date(2000, 1, 1), Account('ASSET', 'Cash'), Quantity(-5))
    journal_entry_1.post(datetime.date(2000, 1, 1), Account('ASSET', 'Cash'), Quantity(0))
    journal_entry_1.post(datetime.date(2000, 1, 1), Account('REVENUE', 'Consulting'), Quantity(5))

# Generated at 2022-06-26 00:35:00.714489
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:35:09.950382
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from datetime import date as dt_date

    start_date: dt_date = dt_date(2019, 1, 1)
    end_date: dt_date = dt_date(2019, 1, 31)
    period: DateRange = DateRange(start_date, end_date)

    class Dummy:
        pass

    dummy = Dummy()

    class DummyJournalEntry:
        def __init__(self, date: dt_date, description: str, source: object) -> None:
            self.date = date
            self.description = description
            self.source = source


# Generated at 2022-06-26 00:35:18.761432
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journalEntry = JournalEntry(datetime.date.today(), "test description", "test source")
    journalEntry.post(datetime.date.today(), Account(AccountType.ASSETS, "test account", "test account", None), 100)
    assert journalEntry.postings[0].account.type == AccountType.ASSETS
    assert journalEntry.postings[0].amount == 100


# Generated at 2022-06-26 00:35:28.003529
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = 'Accounting for 1st January'
    def function__0(period: DateRange) -> Iterable[JournalEntry[_T]]:
        post__0 = journal_entry_0.post(str_0,str_0,str_0)
        def function__1(self:Posting):
            return self.is_credit
        credits = journal_entry_0.credits
        def function__2(self):
            return self.account.type
        is_credit = function__1(function__0(credits))
        account_type = function__2(function__0(post__0))
        def function__3(self:Direction):
            return self.is_debit
        return function__3(Direction.of(is_credit))
    function__0(function__0(test_case_0()))

# Generated at 2022-06-26 00:35:32.681631
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.datetime(2020, 9, 8)
    account = Account("Account", AccountType.ASSETS)
    quantity = 1000
    journal_entry = JournalEntry(date, "A journal entry", "A journal entry")
    journal_entry.post(date, account, quantity)
    journal_entry.validate()

# Generated at 2022-06-26 00:35:41.214448
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.datetime(2020,2,2)
    account_0 = Account("get_ledger", AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, Quantity(-10))
    journal_entry_0.post(date_0, account_0, Quantity(-0))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:35:49.925922
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test case 1
    str_1 = 'Accounting for 1st January'
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    # post increment event
    journal_entry_1.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, 'Cash on hand'), 10)
    # post decrement event
    journal_entry_1.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, 'Deposits in bank'), -5)
    assert journal_entry_1.postings[0].amount == 10
    assert journal_entry_1.postings[1].amount == 5

    # Test case 2
    str_2 = 'Accounting for 2nd January'

# Generated at 2022-06-26 00:35:58.599244
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange):
        return iter([
            JournalEntry(datetime.date(2020, 1, 1), 'Accounting for 1st January', 'Journal Entry 1'),
            JournalEntry(datetime.date(2020, 1, 2), 'Accounting for 2nd January', 'Journal Entry 2'),
        ])

    read_journal_entries_0 = read_journal_entries
    entries_0: Iterable[JournalEntry[object]]
    try:
        entries_0 = read_journal_entries_0(DateRange(datetime.date(2020, 1, 2), datetime.date(2020, 1, 3)))
    except Exception as e:
        print(e)
        raise
    for entry in entries_0:
        entry.validate()

# Generated at 2022-06-26 00:36:06.858097
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    str_1 = 'Accounting for 2nd January'
    str_2 = 'Accounting for 3rd January'
    str_3 = 'Accounting for 4th January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1 = JournalEntry(str_1, str_1, str_1)
    journal_entry_2 = JournalEntry(str_2, str_2, str_2)
    journal_entry_3 = JournalEntry(str_3, str_3, str_3)
    journal_entry_0.post('01-01-2019', 'TATASTEEL', 100.0)

# Generated at 2022-06-26 00:36:11.099157
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def test_entries(entries: Iterable[JournalEntry[str]]) -> Iterable[JournalEntry[str]]:
        return entries

    protocol_0 = ReadJournalEntries()
    try:
        protocol_0.__call__(test_entries)
    except Exception:
        pass
    else:
        raise RuntimeError

# Generated at 2022-06-26 00:36:47.635138
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account()
    journal_entry_1 = journal_entry_0.post(None, account_0, 6)
    assert journal_entry_1.postings[0].account == account_0
    journal_entry_2 = journal_entry_1.post(None, account_0, -2)
    assert journal_entry_2.postings[1].account == account_0
    journal_entry_3 = journal_entry_2.post(None, account_0, 4)
    assert journal_entry_3.postings[2].account == account_0

# Generated at 2022-06-26 00:36:53.768464
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_1 = JournalEntry('Accounting for 31st January', 'Journal Entry 1', 'Source 1')
    journal_entry_1.post(datetime.date(2019, 1, 31), AccountType.ASSETS, Quantity(100))
    journal_entry_1.post(datetime.date(2019, 1, 31), AccountType.EQUITIES, Quantity(-100))
    journal_entry_1.validate()
    return journal_entry_1.postings

# Generated at 2022-06-26 00:36:59.048138
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    str_1 = 'Motorcycle'
    account_0 = Account(str_1)
    journal_entry_0.post(
        datetime.date(1949, 1, 1),
        account_0,
        -(-(-(-(-(-(-(-Quantity(1))))) / Quantity(1))))
    )
    journal_entry_0.validate()

# Generated at 2022-06-26 00:36:59.853668
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_case_0()

# Generated at 2022-06-26 00:37:03.450900
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test Case 0
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.datetime.now().date(),None,Amount(10))
    journal_entry_0.validate()


# Generated at 2022-06-26 00:37:08.371742
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(1800, 1, 1), 'Account_0', 1)
    journal_entry_0.post(datetime.date(1800, 1, 1), 'Account_1', -1)
    journal_entry_0.validate()
    pass

# Generated at 2022-06-26 00:37:18.998638
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Note that this unit test is incomplete as it does not test 'period' param.
    class JournalEntries(ReadJournalEntries[_T]):
        def __init__(self, journal_entries: Iterable[JournalEntry[_T]]):
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return self.journal_entries
    
    journal_entries_0 = JournalEntries([])
    assert isinstance(journal_entries_0, ReadJournalEntries)
    period_0 = DateRange.latest()
    journal_entries_1 = journal_entries_0(period_0)
    assert isinstance(journal_entries_1, Iterable)

# Generated at 2022-06-26 00:37:20.684091
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert ReadJournalEntries.__call__


# Generated at 2022-06-26 00:37:23.562953
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(None, None, None)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:27.542356
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given
    j1 = JournalEntry("Test", "Test", "Test")
    # When
    j1.post(datetime.date(2019, 11, 17), Account.of("Cash Account"), 1000)
    # Then
    assert len(j1.postings) == 1



# Generated at 2022-06-26 00:38:37.457254
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:37.972319
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-26 00:38:39.085136
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_journal = ReadJournalEntries.__call__
    pass


# Generated at 2022-06-26 00:38:39.879238
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:38:44.706088
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    journal_entry_1 = journal_entry_1.post(str_0, Account(str_0), Amount(str_0))
    journal_entry_1.validate()


# Generated at 2022-06-26 00:38:46.899493
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:55.046968
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass
    from typing import List
    from .accounts import Account
    from .journal_entries import Posting, ReadJournalEntries, JournalEntry

    @dataclass
    class PostingSource:
        date: datetime.date
        account: Account
        amount: int

    @dataclass
    class JournalEntrySource:
        date: datetime.date
        description: str
        postings: List[PostingSource]

    @dataclass
    class JournalEntries(ReadJournalEntries[JournalEntrySource]):
        journal_entries: List[JournalEntrySource]


# Generated at 2022-06-26 00:38:56.451459
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:38:58.037044
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    tce = ReadJournalEntries()
    test_case_0()
    print('Unit test for method __call__ of class ReadJournalEntries is successfully done!')

# Generated at 2022-06-26 00:39:03.878708
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Creating a journal entry object
    str_0 = 'Accounting for 1st January'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)

    # Defining account
    account_0 = Account("abcdef")

    # Posting an increment event
    journal_entry_0.post(datetime.date(2020, 1, 1), account_0, Quantity(+1))

    # Posting a decrement event
    journal_entry_0.post(datetime.date(2020, 1, 1), account_0, Quantity(-1))

    # Posting a zero event
    journal_entry_0.post(datetime.date(2020, 1, 1), account_0, Quantity(0))

    # Checking if event count is 2
    # (1 increment and 1 decrement event)
    assert len