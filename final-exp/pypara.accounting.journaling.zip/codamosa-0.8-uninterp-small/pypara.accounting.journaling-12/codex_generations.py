

# Generated at 2022-06-26 00:31:07.360226
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    account_0 = Account()
    journal_0 = JournalEntry.__init__(JournalEntry.__new__(JournalEntry), date_0, "", "")
    journal_1 = JournalEntry.post(journal_0, date_1, account_0, 0)
    journal_2 = JournalEntry.__init__(JournalEntry.__new__(JournalEntry), date_2, "", "")
    journal_3 = JournalEntry.post(journal_2, date_3, account_0, 0)
    journal_4 = JournalEntry.post(journal_2, date_2, account_0, 0)
    journal_5 = Journal

# Generated at 2022-06-26 00:31:15.405044
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    date_0 = datetime.date()
    period_0 = DateRange(date_0, date_0)
    journal_0 = JournalEntry()
    journal_1 = JournalEntry()
    journal_2 = JournalEntry()
    journal_3 = JournalEntry()
    journal_entries_0 = [journal_0, journal_1, journal_2, journal_3]
    def _read_journal_entries_0(period_0):
        return journal_entries_0
    _read_journal_entries_0 = ReadJournalEntries()(_read_journal_entries_0)
    assert _read_journal_entries_0(period_0) == journal_entries_0

# Generated at 2022-06-26 00:31:23.191044
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    def test_JournalEntry_post_method(self, date, account, quantity):
        assert (date and account and quantity)
        assert issubclass(date, module_0.date)
        assert issubclass(account, Account)
        assert issubclass(quantity, Quantity)
        assert isinstance(test_case_0, module_0.date)
        assert isinstance(test_case_0, Account)
        assert isinstance(test_case_0, Quantity)
        return test_case_0
    assert test_JournalEntry_post_method
    return test_JournalEntry_post_method



# Generated at 2022-06-26 00:31:24.537978
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()


# Generated at 2022-06-26 00:31:31.661715
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    #
    class test_JournalEntry_validate_0:
        def test_JournalEntry_validate_0_0(self):
            pass
    def JournalEntry_validate_0():
        post_0 = JournalEntry.postings
        JournalEntry_validate_0_0 = post_0.is_debit
        print(JournalEntry_validate_0_0)
    assert test_JournalEntry_validate_0.test_JournalEntry_validate_0_0() == JournalEntry_validate_0()


# Generated at 2022-06-26 00:31:32.244964
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True


# Generated at 2022-06-26 00:31:35.273599
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    data = JournalEntry(date=datetime.date(year=2019, month=7, day=10), description='cancel payment', source='s1', guid=makeguid())
    data.validate()


# Generated at 2022-06-26 00:31:35.847964
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-26 00:31:45.764745
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    date_3 = module_0.date()
    date_4 = module_0.date()
    date_5 = module_0.date()
    date_6 = module_0.date()
    date_7 = module_0.date()
    date_8 = module_0.date()
    date_9 = module_0.date()
    date_10 = module_0.date()
    date_11 = module_0.date()
    date_12 = module_0.date()
    date_13 = module_0.date()
    date_14 = module_0.date()
    date_15 = module_0.date()
    date_16 = module_

# Generated at 2022-06-26 00:31:50.021266
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date_0 = datetime.date()
    from .accounts import Account, AccountType
    account_0 = Account.get('', AccountType())
    quantity = 0
    journal_entry_0 = JournalEntry()
    journal_entry_0.post(date_0, account_0, quantity)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:32:00.359835
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account(type=AccountType.ASSETS, code='100')
    quantity = Amount(100)
    journal = JournalEntry[None]

# Generated at 2022-06-26 00:32:01.396227
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-26 00:32:10.693093
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class _SourceType:
        pass
    _journal_1 = JournalEntry(_SourceType)
    _journal_2 = JournalEntry(_SourceType)
    _journal_3 = JournalEntry(_SourceType)
    _journal_4 = JournalEntry(_SourceType)
    _journal_5 = JournalEntry(_SourceType)
    _JOURNAL_ENTRIES = [_journal_1, _journal_2, _journal_3, _journal_4, _journal_5]
    _sut = lambda period: (e for e in _JOURNAL_ENTRIES if period.start <= e.date <= period.end)

# Generated at 2022-06-26 00:32:18.091311
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class TestClass:
        pass

    test_journal_entries = [
        JournalEntry(TestClass(), "First journal entry", datetime.date(2020, 1, 1), []),
        JournalEntry(TestClass(), "Second journal entry", datetime.date(2020, 1, 2), []),
        JournalEntry(TestClass(), "Third journal entry", datetime.date(2020, 2, 1), []),
        JournalEntry(TestClass(), "Fourth journal entry", datetime.date(2020, 2, 2), []),
    ]

    def test_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[TestClass]]:
        for journal_entry in test_journal_entries:
            if period.start <= journal_entry.date < period.end:
                yield journal_entry

    test

# Generated at 2022-06-26 00:32:28.295566
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    account_usd = Account(AccountType.ASSETS, "USD", "US Dollars")
    account_cad = Account(AccountType.REVENUES, "CAD", "Canadian Dollars")
    account_eur = Account(AccountType.EXPENSES, "EUR", "Euros")

    journal = JournalEntry(date=datetime.date(2018, 1, 1), description="Journal entry #1", source=None)

# Generated at 2022-06-26 00:32:40.282028
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    '''
    JournalEntry.validate() is tested.
    '''
    journal_entry1=JournalEntry(
        date=datetime.date(2019,1,1),
        description="test",
        source="s")
    journal_entry1.post(date=datetime.date(2019,1,1),account=Account(type=AccountType.ASSETS,name="a"),quantity=1)
    journal_entry1.post(date=datetime.date(2019,1,1),account=Account(type=AccountType.EQUITIES,name="e"),quantity=-1)
    journal_entry2=JournalEntry(
        date=datetime.date(2019,1,1),
        description="test",
        source="s")

# Generated at 2022-06-26 00:32:47.805671
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    accounts = [Account(makeguid(), "Expenses", AccountType.EXPENSES),
                Account(makeguid(), "Assets", AccountType.ASSETS)]
    je = JournalEntry(datetime.date(2019, 1, 1), 'One', 'One', postings=[Posting(je, datetime.date(2019, 1, 1), accounts[0], Direction.INC, Amount(100)), Posting(je, datetime.date(2019, 1, 1), accounts[1], Direction.DEC, Amount(100))]) # journal = je
    
    # Act & Assert
    je.validate()

# Generated at 2022-06-26 00:32:56.878897
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .contacts import Company

    # Given a journal entry
    from datetime import date
    from numbers import Quantity
    journal = JournalEntry[Company](date.today(), "Test entry", Company("Test company"))

    # Given a valid account
    account = Account("Test account", AccountType.ASSETS)

    # When I post a positive amount
    from numbers import Amount
    journal.post(date.today(), account, Quantity(5))

    # Then I expect the journal to have 1 posting
    assert len(journal.postings) == 1

    # And I expect the posting to be a debit
    posting = journal.postings[0]
    assert posting.is_debit

    # And I expect the posting to have amount of the positive amount
    amount = Amount(5)
    assert posting.amount == amount

   

# Generated at 2022-06-26 00:33:10.492273
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType, open_account

    ## Data:

    CommonData = dataclass(frozen=True)({
        "date": datetime.date(2020, 1, 1),
        "span": DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2)),
        "accounts": [
            open_account("Cash Assets", AccountType.ASSETS, 0),
            open_account("Equity", AccountType.EQUITIES, 0),
            open_account("Sales Revenues", AccountType.REVENUES, 0),
            open_account("COGS Expense", AccountType.EXPENSES, 0),
        ],
    })

    ## Test:


# Generated at 2022-06-26 00:33:11.518432
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-26 00:33:31.443561
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    accounts = {
        Account("Assets:Bank",AccountType.ASSETS,"Bank account"), \
        Account("Assets:Cash",AccountType.ASSETS,"Cash account"), \
        Account("Expenses:Car",AccountType.EXPENSES,"Car expenses"), \
        Account("Expenses:Mortgage",AccountType.EXPENSES,"Mortgage expenses")
    }
    class TransactionSource:
        pass
    example_source = TransactionSource()
    example_journal_entry = JournalEntry[TransactionSource]( datetime.date(2020,5,5),"Mortgage payment",example_source)
    example_journal_entry.post(datetime.date(2020,5,5),accounts.__next__(),-500)

# Generated at 2022-06-26 00:33:41.205479
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import typing
    import unittest
    from datetime import date

    from ..commons.protocols import check_protocol
    from .accounts import AccountType
    from .ledgers import Posting

    class A:
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return isinstance(other, A) and other.name == self.name

    class B:
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return isinstance(other, B) and other.name == self.name

    class C:
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return isinstance(other, C) and other

# Generated at 2022-06-26 00:33:50.882728
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass, field
    from ..commons.enums import Direction

    transactions = list()
    @dataclass
    class Transaction:
        guid: str
        source: str
        credit: float
        debit: float
    def receipts(period: DateRange) -> List[Transaction]:
        nonlocal transactions
        return list(filter(lambda r: period.start <= r.date <= period.end, transactions))

    @dataclass
    class Account:
        guid: str
        direction: Direction
        type: str
        name: str
    @dataclass
    class Ledger:
        guid: str
        accounts: List[Account]


# Generated at 2022-06-26 00:34:00.723352
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Ledger
    from .tokens import Currency
    from .trading import Warehouse

    # Set up the ledger:
    ledger = Ledger()
    ledger.create_account(AccountType.ASSETS, "Cash", Currency.USD)
    ledger.create_account(AccountType.ASSETS, "Inventory", Currency.USD)
    ledger.create_account(AccountType.EQUITIES, "Capital", Currency.USD)
    ledger.create_account(AccountType.REVENUES, "Revenue", Currency.USD)
    ledger.create_account(AccountType.EXPENSES, "Cost of Goods Sold", Currency.USD)
    cash = ledger.get_account("Cash")
    inventory = ledger.get_account("Inventory")
    capital = ledger.get_account("Capital")
    revenue = ledger.get_account

# Generated at 2022-06-26 00:34:04.468478
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from ..commons.zeitgeist import DateRange

    class JournalReaderStub:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return None

    reader: ReadJournalEntries = JournalReaderStub()
    reader(DateRange())

# Generated at 2022-06-26 00:34:10.855887
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests the validate function of the JournalEntry class.
    :return: True if pass, False if fail.
    """
    # Test to see if the function works with a valid journal entry.
    print("Test 1")
    j = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="test1",
        source=123
    )
    j.post(
        date=datetime.date(2020, 1, 1),
        account=Account(
            type=AccountType.ASSETS,
            name="test4",
            code="123"
        ),
        quantity=100.0
    )

# Generated at 2022-06-26 00:34:20.012032
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, EquityAccount

    date = datetime.date.today()
    description = 'Test description'
    source = int

    equity_acc = EquityAccount('TestEquityAccount')

    je1 = JournalEntry[int](date, description, source)
    je1.post(date, equity_acc, 1)
    je1.post(date, equity_acc, 1)
    je1.validate()

    je2 = JournalEntry[int](date, description, source)
    je2.post(date, equity_acc, -1)
    je2.post(date, equity_acc, -1)
    je2.validate()

    je3 = JournalEntry[int](date, description, source)
    je3.post(date, equity_acc, -1)
    je3.post

# Generated at 2022-06-26 00:34:26.018866
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = JournalEntry(datetime.date(2020,3,1), "test journal entry", None)
    a.post(datetime.date(2020,3,1), Account(1, 'test account', AccountType.LIABILITIES), Quantity(100.00))
    a.post(datetime.date(2020,3,1), Account(1, 'test account', AccountType.EQUITIES), Quantity(100.00))
    a.validate()

# Generated at 2022-06-26 00:34:30.760556
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](datetime.date(2019, 1, 1), "Description", -1)
    je.post(datetime.date(2019, 1, 1), Account(AccountType.ASSETS, "Bank"), -100)
    je.post(datetime.date(2019, 1, 1), Account(AccountType.EXPENSES, "Supplier"), 100)
    je.validate()
    assert True

# Generated at 2022-06-26 00:34:31.309019
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert False



# Generated at 2022-06-26 00:34:57.210042
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock

    # Setup
    class MockJournalEntry(JournalEntry):
        pass

    mock_journals: Iterable[JournalEntry] = []
    def callback(period: DateRange):
        def actual_callback(period: DateRange):
            if period:
                yield MockJournalEntry(date(2020, 1, 13), "TEST-DESC", None)
        return actual_callback(period)

    # Act
    result = callback(None)

    # Check
    assert result is not None
    assert next(result).date == date(2020, 1, 13)

# Generated at 2022-06-26 00:35:08.379059
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Test the validate method of class JournalEntry
    """
    from ledger.accounts import Accounts
    from ledger.platform import JournalEntries
    from ledger.query import Query

    accounts = Accounts()
    journal = JournalEntries(accounts)

    # Case 1: Debit & Credit Account are different
    def case1():
        journal.post(datetime.date(2019, 12, 15), makeguid(), "Trans 1", "Accounts Receivable", 1000)
        journal.post(datetime.date(2019, 12, 15), makeguid(), "Trans 1", "Sales", -1000)
    assert case1() == None

    # Case 2: Debit & Credit Account are same
    def case2():
        journal.post(datetime.date(2019, 12, 15), makeguid(), "Trans 2", "Sales", 1000)

# Generated at 2022-06-26 00:35:21.214781
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.general import GeneralLedger
    ledger = GeneralLedger()

    entry = JournalEntry(datetime.date(2020, 1, 1), "Test Entry", "Just a Test")

    entry.post(datetime.date(2020, 1, 1), ledger.get_account_by_name("Income Account"), 100)
    entry.post(datetime.date(2020, 1, 1), ledger.get_account_by_name("Expenses Account"), 50)

    ## Test:
    assert len(entry.postings) == 2
    assert len(list(entry.increments)) == 1
    assert len(list(entry.decrements)) == 1
    assert len(list(entry.debits)) == 1
    assert len(list(entry.credits)) == 1

# Generated at 2022-06-26 00:35:29.038233
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Performs unit tests on method JournalEntry.validate.

    :raises AssertionError: If any of the assertion fails.
    """
    from .accounts import TransactionAccounts
    from .accounts import chart

    atype = TransactionAccounts.type_for(chart.TYPE_BANK)
    account = TransactionAccounts.find_account(chart.TYPE_BANK, "HDFC Cheque A/C")

    # noinspection PyTypeChecker
    je = JournalEntry(datetime.date.today(), "Test", None)
    je.post(datetime.date.today(), atype.revenues, 2000)
    je.post(datetime.date.today(), account, -2000)
    je.validate()

    # noinspection PyTypeChecker

# Generated at 2022-06-26 00:35:37.758919
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry('2011-10-28', "test", None)
    try:
        je.post(datetime.date(2011, 10, 28), Account(None, None, AccountType.ASSETS, 'Assets'), Amount(10))
        je.post(datetime.date(2011, 10, 28), Account(None, None, AccountType.LIABILITIES, 'Liabilities'), Amount(-10))
        je.validate()
    except AssertionError as e:
        print(e)
        je.validate()

# Generated at 2022-06-26 00:35:38.888384
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True


# Generated at 2022-06-26 00:35:48.688859
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Zero

    # Invalid case:
    # Note: We use `Zero` here instead of `0` as the former is a number utility class which represents a
    # zero quantity or amount. This makes it more versatile.
    #noinspection PyTypeChecker
    try:
        JournalEntry(datetime.date(2019, 1, 1), "Fake Journal Entry", Zero, [])
    except AssertionError as ex:
        assert "Total Debit" in str(ex)
        assert "Total Credit" in str(ex)
    else:
        assert False, "Expected an exception to be raised"

    # Valid case:
    #noinspection PyTypeChecker

# Generated at 2022-06-26 00:35:57.837820
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .business_objects import Expense
    from datetime import date
    from numbers import Quantity
    expense = Expense(date(2019, 12, 12), "QQQQQQ", 100)
    journalEntry = JournalEntry(date(2019, 12, 12), "SSSSSS", expense)
    journalEntry.post(date(2019, 12, 12), Account(AccountType.EXPENSES, "AAAAAA"), Quantity(10))
    journalEntry.post(date(2019, 12, 12), Account(AccountType.ASSETS, "BBBBBB"), Quantity(20))
    journalEntry.post(date(2019, 12, 12), Account(AccountType.EXPENSES, "CCCCCC"), Quantity(30))
    assert journalEntry.postings[0].date == date(2019, 12, 12)

# Generated at 2022-06-26 00:36:06.990810
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Transaction:
        pass

    x = Transaction()
    y = Transaction()

    a = JournalEntry(datetime.date(2019, 12, 31), "Test Transaction", x)
    a.post(datetime.date(2019, 12, 31), Account(AccountType.ASSETS, "Cash"), +100)
    a.post(datetime.date(2019, 12, 31), Account(AccountType.EXPENSES, "Inventory"), -100)
    a.validate()

    b = JournalEntry(datetime.date(2019, 12, 31), "Test Transaction", y)
    b.post(datetime.date(2019, 12, 31), Account(AccountType.EXPENSES, "Inventory"), -100)

# Generated at 2022-06-26 00:36:10.287282
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry[str]("18-12-2019","test_JournalEntry_validate",str,(Posting(journalentry, date, account, Direction.INC, Amount(5))))
    journal.validate()


# Generated at 2022-06-26 00:36:31.081615
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert 0 != 0

# Generated at 2022-06-26 00:36:40.518742
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    client_0 = 'client_0'
    journal_entry_0 = JournalEntry(client_0, client_0, client_0)
    date_0 = datetime.date(2015, 5, 15)
    account_0 = Account(client_0, client_0)
    quantity_0 = Quantity(client_0)
    journal_entry_0.post(date_0, account_0, quantity_0)
    # Here we are asserting that the post method appends a posting object to the list of postings in JournalEntry class
    if not journal_entry_0.postings:
        raise AssertionError()
    # Here we are asserting that the journal parameter passed to the Posting class is journal_entry_0
    if journal_entry_0.postings[0].journal is not journal_entry_0:
        raise AssertionError

# Generated at 2022-06-26 00:36:47.333700
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    account_0 = Account('Gross Profit', AccountType.EQUITIES)
    journal_entry_0_post_0 = journal_entry_0.post(str_0, account_0, Quantity(-8))
    journal_entry_0_post_0.post(str_0, account_0, Quantity(40))
    journal_entry_0_post_0.validate()

if __name__ == "__main__":
	# test_JournalEntry_post()
	test_case_0()

# Generated at 2022-06-26 00:36:48.187056
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-26 00:36:57.401325
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    amount_0 = Amount(1000)
    amount_1 = Amount(500)
    amount_2 = Amount(500)

    str_1 = '2011-10-2ct#'
    str_2 = '2011-10-2fc#'
    str_3 = '2011-10-2fcg#'
    str_4 = '2011-10-2fc#'

    account_0 = Account(str_1, AccountType.EXPENSES)
    account_1 = Account(str_2, AccountType.EQUITIES)
    account_2 = Account(str_3, AccountType.ASSETS)

    date_1 = datetime.date(2011, 10, 2)
    date_2 = datetime.date(2011, 10, 2)

    direction_0 = Direction.INC
    direction_1 = Direction.DEC



# Generated at 2022-06-26 00:37:02.425375
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EXPENSES, "Test"), 15)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EXPENSES, "Test"), -15)
    assert je.postings[0].amount == 15
    assert je.postings[1].amount == -15

# Generated at 2022-06-26 00:37:03.234450
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False


# Generated at 2022-06-26 00:37:05.969446
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # __main__.JournalEntry has no attribute '_JournalEntry__postings'
    with pytest.raises(AttributeError):
        test_case_0()

# Generated at 2022-06-26 00:37:08.415584
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry_1 = JournalEntry("Date", "Description", "Source")
    journal_entry_1.post("Date", "Account", 100)
    assert journal_entry_1.postings[0].amount == 100


# Generated at 2022-06-26 00:37:13.586135
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post('2011-10-2',str_0,0)
    journal_entry_1 = Posting(journal_entry_0, '2011-10-2',str_0,Direction.of(0),0)
    assert journal_entry_0.postings[0] == journal_entry_1
    journal_entry_0.validate()

# Generated at 2022-06-26 00:37:57.418774
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Test_object:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    recorded_amount_0 = journal_entry_0.post(str_0, str_0, 0)
    for p in journal_entry_0.postings:
        assert p.amount == 0
        assert p.date == str_0
        assert p.journal == journal_entry_0
    journal_entry_1 = JournalEntry(str_0, str_0, str_0)
    recorded_amount_1 = journal_entry_1.post(str_0, str_0, 100)

# Generated at 2022-06-26 00:38:00.649424
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Get the postings:
    journal_entries = get_read_journal_entries()(DateRange())
    postings_0 = journal_entries[0]
    # Assert postings_1 is ReadJournalEntries
    test_case_0()


# Generated at 2022-06-26 00:38:04.001128
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # Create JournalEntry object
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:07.696296
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account_0 = Account('name', AccountType.ASSETS)
    journal_entry_0 = JournalEntry('', '', '')
    journal_entry_0.post('', account_0, -907.5055962910643)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:13.325267
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = JournalEntry('2011-10-02', 'abc', 'abc')
    a = a.post(123, Account('asset', 'cash'), Quantity(10))
    assert a.postings[0].journal is a
    assert a.postings[0].date == 123
    assert a.postings[0].account == Account('asset', 'cash')
    assert a.postings[0].direction is Direction.INC
    assert a.postings[0].amount == Amount(10)

# Generated at 2022-06-26 00:38:18.058015
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post('2011-10-2fg#', Account('2011-10-2fg#', '2011-10-2fg#', '2011-10-2fg#'), '2011-10-2fg#')
    journal_entry_0.validate()


# Generated at 2022-06-26 00:38:19.449288
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # TODO: Implement assertion tests.
    pass


# Generated at 2022-06-26 00:38:26.188901
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str0 = '2011-1-1'
    str1 = 'test'
    str2 = 'test'
    journal_entry0 = JournalEntry(str0, str1, str2)
    account0 = Account(str1, AccountType.ASSETS)
    journal_entry0.post(str0, account0, (-1024))
    journal_entry0.post(str0, account0, (-1))
    journal_entry0.validate()
    assert len(journal_entry0.postings) == 2


# Generated at 2022-06-26 00:38:31.697001
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.post(datetime.date(2011, 10, 2),
                         Account('Expenses', AccountType.EXPENSES),
                         +1.0)
    journal_entry_0.post(datetime.date(2011, 10, 2),
                         Account('Expenses', AccountType.EXPENSES),
                         -1.0)
    journal_entry_0.validate()

# Generated at 2022-06-26 00:38:34.319496
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_1 = JournalEntry('2011-10-12', 'Entry #1', 'Business Object #1')
    journal_1.post('2011-10-12', 'Petty Cash', Quantity(10))

# Generated at 2022-06-26 00:40:08.771862
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry('2011-08-17', 'A journal entry', 'Some Business Object')
    j.post('2011-08-17', 'Assets:Cash', 100)
    j.post('2011-08-17', 'Expenses:Food', -50)
    j.post('2011-08-17', 'Expenses:Food', -50)
    j.validate()


# Generated at 2022-06-26 00:40:15.271181
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    str_0 = '2lb.'
    str_1 = 'C'
    str_2 = ")"
    str_3 = 'g~s;'
    journal_entry_0 = JournalEntry(str_2, str_2, str_2)
    journal_entry_0.validate()
    def read_journal_entries__0(_):
        yield journal_entry_0
    journal_entry_0.post(str_3, str_3, str_3)
    journal_entry_0.post(str_1, str_1, str_1)
    journal_entry_0.post(str_2, str_2, str_2)
    journal_entry_0.post(str_0, str_0, str_0)

# Generated at 2022-06-26 00:40:18.886731
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def ret():
        return JournalEntry(makeguid(), 'str_0', 'str_0')
    def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
        pass
    return __call__(ret(), 'str_0')


# Generated at 2022-06-26 00:40:19.574820
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ...


# Generated at 2022-06-26 00:40:26.161906
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2018, 10, 4)
    quantity1 = Amount(1)
    quantity2 = Amount(2)
    debitAmount = Amount(100)
    creditAmount = Amount(100)
    account1 = Account('1', 'a', AccountType.ASSETS)
    account2 = Account('2', 'b', AccountType.EXPENSES)
    journalEntry = JournalEntry(date, 'Journal entry', 'Source')
    # Test to post an increment event
    journalEntry.post(date, account1, quantity1)
    assert len(journalEntry.increments) == 1
    # Test to post a decrement event
    journalEntry.post(date, account2, quantity2)
    assert len(journalEntry.decrements) == 1
    # Test to post a debit event

# Generated at 2022-06-26 00:40:30.474601
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    date_0 = datetime.date(2020, 10, 23)
    account_0 = Account(str_0, AccountType.ASSETS)
    journal_entry_0.post(date_0, account_0, Quantity(5))
    journal_entry_0.validate()
    journal_entry_0.post(date_0, account_0, Quantity(5))
    journal_entry_0.validate()

# Generated at 2022-06-26 00:40:37.241235
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test 1: Call on an object that implements ReadJournalEntries
    str_0 = '2011-10-2fg#'
    journal_entry_0 = JournalEntry(str_0, str_0, str_0)
    journal_entry_0.validate()



# Generated at 2022-06-26 00:40:40.372165
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    quantity_0 = Amount(0)
    journal_entry_0 = JournalEntry(datetime.date(1, 1, 1), 'description', 'description')
    journal_entry_0.post(datetime.date(1, 1, 1), Account('description'), quantity_0)


# Generated at 2022-06-26 00:40:46.808366
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    parm_0 = DateRange('2019-06-03', '2019-08-30')
    parm_1 = 'DateRange(begin=2019-06-03, end=2019-08-30)'
    var_1 = ReadJournalEntries('DateRange(begin=2019-06-03, end=2019-08-30)')
    var_2 = var_1('DateRange(begin=2019-06-03, end=2019-08-30)')
    print(var_2)


# Generated at 2022-06-26 00:40:50.098555
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j_e = JournalEntry(datetime.date.today(), 'NULL_0', 'NULL_1')
    j_e.post(datetime.date.today(), Account('NULL_2', AccountType.ASSETS), Quantity(0)).post(datetime.date.today(), Account('NULL_3', AccountType.ASSETS), Quantity(5))
    j_e.validate()