

# Generated at 2022-06-18 02:19:33.329457
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import TestCase, mock

    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_returns_iterable(self):
            mock_iterable = mock.Mock(spec=Iterable[JournalEntry[_T]])
            mock_function = mock.Mock(spec=ReadJournalEntries[_T])
            mock_function.return_value = mock_iterable

            result = mock_function(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31)))

            self.assertIs(result, mock_iterable)

    test = Test()
    test.test_returns_iterable()

# Generated at 2022-06-18 02:19:44.244207
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:19:52.396589
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    transaction = Transaction(ledger)
    transaction.post(ledger.get_account("Assets:Cash"), Quantity(100))
    transaction.post(ledger.get_account("Expenses:Food"), Quantity(-50))
    transaction.post

# Generated at 2022-06-18 02:20:00.284147
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .exchanges import Exchange
    from .markets import Market
    from .portfolios import Portfolio
    from .securities import Security

    # Create a portfolio
    portfolio = Portfolio(
        name="Test Portfolio",
        description="Test Portfolio",
        currency=Currency.USD,
        exchanges=[Exchange.NYSE],
        markets=[Market.STOCK],
        securities=[Security(symbol="AAPL")],
    )

    # Create a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=portfolio,
    )

    # Post to the journal entry

# Generated at 2022-06-18 02:20:12.142509
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase
    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", None).post(date(2020, 1, 1), Account("A", AccountType.ASSETS), +100),
                    JournalEntry(date(2020, 1, 2), "Test", None).post(date(2020, 1, 2), Account("A", AccountType.ASSETS), -100),
                ]


# Generated at 2022-06-18 02:20:22.953869
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .ledgers import Ledger

    # Setup:
    ledger = Ledger(Currency.USD)
    business = Business("Test Business", ledger)
    account_1 = Account("Test Account 1", AccountType.ASSETS, ledger)
    account_2 = Account("Test Account 2", AccountType.REVENUES, ledger)
    account_3 = Account("Test Account 3", AccountType.EXPENSES, ledger)
    account_4 = Account("Test Account 4", AccountType.EQUITIES, ledger)
    account_5 = Account("Test Account 5", AccountType.LIABILITIES, ledger)

    # Test:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", business)
    journal_entry

# Generated at 2022-06-18 02:20:34.431063
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeTypeCategory
    from .transactions import TransactionTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeTypeType

# Generated at 2022-06-18 02:20:44.798851
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a business:
    business = Business("Test Business")

    # Create a ledger:
    ledger = Ledger(business)

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", business)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), +100)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), -100)

    # Validate the journal entry:
    journal.validate()

    # Create a transaction:

# Generated at 2022-06-18 02:20:56.521733
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a function which reads journal entries from a source:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        # Define some accounts:
        cash = Account("Cash", AccountType.ASSETS)
        sales = Account("Sales", AccountType.REVENUES)
        expenses = Account("Expenses", AccountType.EXPENSES)

        # Define a journal entry:
        journal_entry = JournalEntry(
            date=datetime.date(2020, 1, 1),
            description="Sales for the month of January 2020",
            source=None,
        )

# Generated at 2022-06-18 02:21:03.191978
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    # Create a journal entry
    je = JournalEntry[int]()
    je.date = datetime.date(2020, 1, 1)
    je.description = "Test Journal Entry"
    je.source = 1

    # Create accounts
    a1 = Account("A1", AccountType.ASSETS)
    a2 = Account("A2", AccountType.REVENUES)

    # Post to accounts
    je.post(datetime.date(2020, 1, 1), a1, 100)
    je.post(datetime.date(2020, 1, 1), a2, -100)

    # Validate the journal entry
    je.validate()

# Generated at 2022-06-18 02:21:22.145343
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .journal import JournalEntry, Posting

    # Create a journal entry
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry")

    # Post a debit
    journal.post(date=datetime.date(2020, 1, 1), account=Account(name="Debit Account", type=AccountType.ASSETS), quantity=10)

    # Post a credit
    journal.post(date=datetime.date(2020, 1, 1), account=Account(name="Credit Account", type=AccountType.LIABILITIES), quantity=-10)

    # Validate the journal entry
    journal.validate()

    # Post a debit

# Generated at 2022-06-18 02:21:27.837907
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupSubCategory
    from .accounts import AccountGroupSubSubCategory
    from .accounts import AccountGroupSubSubSubCategory
    from .accounts import AccountGroupSubSubSubSubCategory
    from .accounts import AccountGroupSubSubSubSubSubCategory
    from .accounts import AccountGroupSubSubSubSubSubSubCategory
    from .accounts import AccountGroupSubSubSubSubSubSubSubCategory
    from .accounts import AccountGroupSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountGroupSubSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountGroupSub

# Generated at 2022-06-18 02:21:38.408426
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .readers.journal_entry_readers import read_journal_entries_from_ledger
    from .readers.ledger_readers import read_ledger_from_file
    from .readers.transaction_readers import read_transactions_from_file
    from .transactions import Transaction
    from .writers import write_journal_entries_to_file

    # Read ledger from file
    ledger: Ledger = read_ledger_from_file("tests/data/ledgers/sample.ledger")

    # Read transactions from file

# Generated at 2022-06-18 02:21:47.983788
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction", datetime.date(2020, 1, 1))

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Create an account:
    account = Account(AccountType.ASSETS, "Test Account")

    # Post to the account:
    journal_entry.post(datetime.date(2020, 1, 1), account, 100)

    # Validate the journal entry:

# Generated at 2022-06-18 02:21:58.079001
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_returns_iterable(self):
            source = Mock()
            source.__call__.return_value = []
            self.assertIsInstance(source(DateRange(date(2020, 1, 1), date(2020, 1, 1))), Iterable)

        def test_returns_iterable_of_JournalEntry(self):
            source = Mock()
            source.__call__.return_value = [JournalEntry(date(2020, 1, 1), "", None)]

# Generated at 2022-06-18 02:22:05.503705
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", "Test Source")

    # Post an increment event to an account
    journal_entry.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))

    # Post a decrement event to an account
    journal_entry.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(-100))

    # Check if the journal entry is valid
    journal_entry.validate()

    # Check if the journal entry is invalid

# Generated at 2022-06-18 02:22:15.312687
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    mock_journal_entry = Mock(JournalEntry)
    mock_journal_entry.date = date(2020, 1, 1)
    mock_journal_entry.postings = [
        Mock(Posting, date=date(2020, 1, 1), account=Account("A", AccountType.ASSETS), direction=Direction.INC, amount=100),
        Mock(Posting, date=date(2020, 1, 1), account=Account("B", AccountType.REVENUES), direction=Direction.DEC, amount=100),
    ]


# Generated at 2022-06-18 02:22:27.922542
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:22:34.851668
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Arrange:
    read_journal_entries: ReadJournalEntries[str] = Mock()
    read_journal_entries.return_value = [
        JournalEntry(date(2020, 1, 1), "Description 1", "Source 1"),
        JournalEntry(date(2020, 1, 2), "Description 2", "Source 2"),
    ]

    # Act:
    result = read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 2)))

    # Assert:

# Generated at 2022-06-18 02:22:44.316054
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=None,
    )

    # Create a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=None,
    )

    # Post to the journal entry:

# Generated at 2022-06-18 02:23:05.047539
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a business:
    business = Business("Test Business")

    # Create a ledger:
    ledger = Ledger(business)

    # Create a transaction:
    transaction = Transaction(ledger, TransactionType.SALE, "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Create accounts:
    cash_account = Account(ledger, AccountType.ASSETS, "Cash")
    sales_account = Account(ledger, AccountType.REVENUES, "Sales")

    # Post to journal entry:

# Generated at 2022-06-18 02:23:16.729728
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:23:23.967860
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class MockSource:
        pass

    @dataclass(frozen=True)
    class MockJournalEntry(JournalEntry[MockSource]):
        pass

    @dataclass(frozen=True)
    class MockPosting(Posting[MockSource]):
        pass


# Generated at 2022-06-18 02:23:33.647827
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:23:40.291656
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass


# Generated at 2022-06-18 02:23:47.825650
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .business import Business
    from datetime import date
    from .ledger import Ledger
    from .accounts import Account
    from .business import Business
    from .journal import JournalEntry, Direction
    from .commons.numbers import Amount, Quantity
    from .commons.others import Guid
    from .commons.zeitgeist import DateRange
    from .accounts import AccountType
    from .ledger import Ledger
    from .journal import JournalEntry, Direction
    from .commons.numbers import Amount, Quantity
    from .commons.others import Guid
    from .commons.zeitgeist import DateRange
    from .accounts import AccountType

# Generated at 2022-06-18 02:23:55.207971
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
                return [JournalEntry(date(2020, 1, 1), "Test", None)]

            read_journal_entries_: ReadJournalEntries[_T] = read_journal_entries
            self.assertEqual(len(list(read_journal_entries_(DateRange(date(2020, 1, 1), date(2020, 1, 1))))), 1)

    main()

# Generated at 2022-06-18 02:24:02.733856
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries, Direction

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return [
            JournalEntry(date(2020, 1, 1), "Test", "Test", [
                Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                Posting(None, date(2020, 1, 1), Account("B", AccountType.EQUITIES), Direction.DEC, Amount(100)),
            ]),
        ]

    assert isinstance(read_journal_entries, ReadJournalEntries)
    assert isinstance(read_journal_entries, Callable)

# Generated at 2022-06-18 02:24:13.963430
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2019, 1, 1), "Test Journal Entry", transaction)

    # Create a posting:
    journal_entry.post(datetime.date(2019, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(100))

    # Validate the journal entry:
    journal_entry

# Generated at 2022-06-18 02:24:23.704186
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a read journal entries function:

# Generated at 2022-06-18 02:24:49.038680
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:24:57.736955
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import List
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class JournalEntry:
        date: date
        description: str
        postings: List[Posting]

    @dataclass(frozen=True)
    class Posting:
        account: Account
        direction: Direction
        amount: Amount

    @dataclass(frozen=True)
    class Account:
        name: str
        type: AccountType


# Generated at 2022-06-18 02:25:06.932962
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book("Test Book")

    # Create a ledger:
    ledger = Ledger("Test Ledger", Currency("USD"))

    # Create a transaction:
    transaction = Transaction("Test Transaction")

    # Create an account:
    account = Account("Test Account", AccountType.ASSETS)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post a debit:
    journal_entry.post(datetime.date(2020, 1, 1), account, +100)

    # Post a credit:

# Generated at 2022-06-18 02:25:17.963737
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType

    @dataclass
    class JournalEntrySource:
        """
        Provides a journal entry source.
        """

        #: Date of the entry.
        date: date

        #: Description of the entry.
        description: str

        #: Postings of the journal entry.
        postings: List[Posting[JournalEntrySource]]

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[JournalEntrySource]]:
        """
        Reads journal entries from a source.
        """

# Generated at 2022-06-18 02:25:28.454049
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account, AccountType
    from ..books.journals import JournalEntry
    from ..books.ledgers import Ledger
    from ..books.transactions import Transaction
    from ..books.transactions.samples import sample_transaction_1
    from ..books.transactions.samples import sample_transaction_2
    from ..books.transactions.samples import sample_transaction_3
    from ..books.transactions.samples import sample_transaction_4
    from ..books.transactions.samples import sample_transaction_5
    from ..books.transactions.samples import sample_transaction_6
    from ..books.transactions.samples import sample_transaction_7
    from ..books.transactions.samples import sample_transaction_8

# Generated at 2022-06-18 02:25:36.538611
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import List

    # Create a journal entry
    journal_entry = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a positive quantity
    journal_entry.post(date(2020, 1, 1), account, Quantity(1))

    # Post a negative quantity
    journal_entry.post(date(2020, 1, 1), account, Quantity(-1))

    # Post a zero quantity

# Generated at 2022-06-18 02:25:44.980501
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries

    class MockJournalEntry(JournalEntry[None]):
        def __init__(self, date: date, description: str, source: None, postings: Iterable[JournalEntry[None]]):
            super().__init__(date, description, source, postings)

    class MockReadJournalEntries(ReadJournalEntries[None]):
        def __init__(self, journal_entries: Iterable[JournalEntry[None]]):
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return self.journal_entries

    # Test:

# Generated at 2022-06-18 02:25:55.788500
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account(AccountType.ASSETS, "Cash"))
    ledger.add_account(Account(AccountType.REVENUES, "Sales"))
    ledger.add_account(Account(AccountType.EXPENSES, "Cost of Goods Sold"))

    transaction = Transaction(ledger)
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Cash"), Quantity(100))
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Sales"), Quantity(-100))

# Generated at 2022-06-18 02:26:06.454797
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a debit
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Post a credit
    journal.post(datetime.date(2020, 1, 1), account, Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Check the postings
    assert len(journal.postings) == 2

# Generated at 2022-06-18 02:26:16.065479
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date

    # Create a journal entry
    journal_entry = JournalEntry[str](date(2020, 1, 1), "Test Journal Entry", "Test Source")

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post a quantity to the account
    journal_entry.post(date(2020, 1, 1), account, Quantity(100))

    # Check if the journal entry has a posting
    assert len(journal_entry.postings) == 1

    # Check if the posting is correct
    posting = journal_entry.postings[0]
    assert posting.journal == journal_entry


# Generated at 2022-06-18 02:27:14.831751
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:27:20.843722
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class JournalEntryImpl(JournalEntry[None]):
        def __init__(self, date: date, description: str, postings: Iterable[Posting[None]]):
            super().__init__(date, description, None, postings)

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield JournalEntryImpl(date(2020, 1, 1), "", [Posting(None, date(2020, 1, 1), Account("A"), Direction.INC, 100)])

# Generated at 2022-06-18 02:27:28.936263
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTree
    from .accounts import AccountTreeBuilder
    from .accounts import AccountTreeNode
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeVisitor
    from .accounts import AccountTreeVisitor
    from .accounts import AccountVisitor
    from .accounts import AccountVisitorBase
    from .accounts import AccountVisitorContext
    from .accounts import AccountVisitorContextBase
    from .accounts import AccountVisitorContextType
    from .accounts import AccountVisitorType
    from .accounts import AccountVisitorTypeBase
    from .accounts import AccountVisitorTypeContext
    from .accounts import AccountVisitorTypeContextBase
    from .accounts import AccountVisitorTypeContextType

# Generated at 2022-06-18 02:27:34.599922
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Setup:
    mock_journal_entries = Mock(spec=Iterable[JournalEntry[_T]])
    mock_period = Mock(spec=DateRange)

    # Exercise:
    ReadJournalEntries.__call__(mock_journal_entries, mock_period)

    # Verify:
    mock_journal_entries.assert_called_once_with(mock_period)

# Generated at 2022-06-18 02:27:41.125169
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))

    transaction = Transaction(ledger)
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Assets"), Quantity(100))

# Generated at 2022-06-18 02:27:49.695072
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    #: Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier

# Generated at 2022-06-18 02:27:55.041975
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entry_1 = JournalEntry(date(2020, 1, 1), "Journal Entry 1", None)
            journal_entry_2 = JournalEntry(date(2020, 1, 2), "Journal Entry 2", None)
            journal_entry_3 = JournalEntry(date(2020, 1, 3), "Journal Entry 3", None)
            journal_entry_4 = JournalEntry(date(2020, 1, 4), "Journal Entry 4", None)
            journal_entry_5 = JournalEntry

# Generated at 2022-06-18 02:28:03.405955
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    je = JournalEntry[str]('2020-01-01', 'Test', 'Test', [])

    # Posting to a debit account
    je.post('2020-01-01', Account('Test', AccountType.ASSETS), Amount(100))

    # Posting to a credit account
    je.post('2020-01-01', Account('Test', AccountType.REVENUES), Amount(100))

    # Validate the journal entry
    je.validate()

# Generated at 2022-06-18 02:28:08.916060
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Setup:
    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    # Test:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", Transaction())
    journal_entry.post(datetime.date(2020, 1, 1), ledger.assets, +100)
    journal_

# Generated at 2022-06-18 02:28:16.907119
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Income:Salary", AccountType.REVENUES))

    txn = Transaction(ledger, "Salary")
    txn.post(datetime.date(2020, 1, 1), ledger.get_account("Income:Salary"), +100)