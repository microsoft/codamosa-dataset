

# Generated at 2022-06-18 02:19:34.562780
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return []

    assert TestReadJournalEntries()(DateRange(date(2020, 1, 1), date(2020, 1, 31))) == []

# Generated at 2022-06-18 02:19:45.783153
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder_with_default_accounts
    from .accounts import AccountRepositoryInMemoryBuilder_with_default_accounts_and_account_types
    from .accounts import AccountRepositoryInMemoryBuilder_with_default_account_types
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemoryBuilder
    from .accounts import AccountTypeRepositoryInMemoryBuilder_with_default_account_types
    from .accounts import AccountTypeRepositoryInMemoryBuilder_with_default_account_types_and_accounts

# Generated at 2022-06-18 02:19:53.311731
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    book = Book()
    ledger = Ledger(book)
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    txn = Transaction(ledger, "Sale", datetime.date(2020, 1, 1))
    txn.post("Assets:Cash", +100)
    txn.post("Revenues:Sales", -100)
    txn.commit

# Generated at 2022-06-18 02:20:03.336958
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .journal import JournalEntry, Posting
    from .money import Money
    from .numbers import Amount, Quantity
    from .tags import Tag

    # Create a journal entry:
    je = JournalEntry[Tag](
        date=datetime.date(2019, 1, 1),
        description="Test Journal Entry",
        source=Tag(name="Test"),
    )

    # Post some amounts:
    je.post(datetime.date(2019, 1, 1), Account(name="Cash", type=AccountType.ASSETS, currency=Currency.USD), Money(10, Currency.USD))

# Generated at 2022-06-18 02:20:12.849099
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    book = Book()
    ledger = Ledger(book)
    account_a = Account(ledger, "A", AccountType.ASSETS)
    account_b = Account(ledger, "B", AccountType.ASSETS)
    account_c = Account(ledger, "C", AccountType.EXPENSES)

    transaction = Transaction(ledger, "T1", datetime.date(2020, 1, 1))
    transaction.post(account_a, 100)
    transaction.post(account_b, -100)
    transaction.post(account_c, -100)

    journal_entry = transaction.journal_entry()
    journal_entry.validate()

# Generated at 2022-06-18 02:20:18.501128
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", transaction)

    # Create an account:
    account = Account(AccountType.ASSETS, "Test", "Test")

    # Post to the account:
    journal_entry.post(datetime.date(2020, 1, 1), account, 100)

    # Validate the journal entry:
    journal_entry.validate()

# Generated at 2022-06-18 02:20:25.891073
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction", datetime.date(2020, 1, 1))

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post a debit:
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), +100)

    # Post a credit:

# Generated at 2022-06-18 02:20:35.739139
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .books import Book
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction
    from .units import Unit
    from .users import User

    # Create a book:
    book = Book(
        name="Test Book",
        currency=Currency(name="Test Currency", code="TC", symbol="T", fraction=100),
        users=[User(name="Test User")],
    )

    # Create a ledger:

# Generated at 2022-06-18 02:20:45.667896
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .transactions import Transaction

    # Define a stub for reading journal entries:

# Generated at 2022-06-18 02:20:56.921569
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger

    ledger = Ledger()
    ledger.add_account(Account("A", AccountType.ASSETS))
    ledger.add_account(Account("B", AccountType.ASSETS))
    ledger.add_account(Account("C", AccountType.EXPENSES))
    ledger.add_account(Account("D", AccountType.EXPENSES))

    entry = JournalEntry(datetime.date.today(), "Test", None)
    entry.post(datetime.date.today(), ledger.get_account("A"), Quantity(100))
    entry.post(datetime.date.today(), ledger.get_account("B"), Quantity(-100))

# Generated at 2022-06-18 02:21:16.225430
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", "Test Source")
    journal.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(-100))

    assert len(journal.postings) == 2
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[1].direction == Direction.DEC

# Generated at 2022-06-18 02:21:21.614921
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a dummy journal entry:
    @dataclass(frozen=True)
    class DummyJournalEntry(JournalEntry):
        pass

    # Define a dummy read journal entries function:

# Generated at 2022-06-18 02:21:31.548733
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountManager
    from .accounts import AccountManagerFactory
    from .accounts import AccountManagerFactoryImpl
    from .accounts import AccountManagerImpl
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryImpl
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryImpl
    from .accounts import AccountTypeFactory
    from .accounts import AccountTypeFactoryImpl
    from .accounts import AccountFactory
    from .accounts import AccountFactoryImpl
    from .accounts import AccountFactory
    from .accounts import AccountFactoryImpl
    from .accounts import AccountFactory
    from .accounts import AccountFactoryImpl
    from .accounts import AccountFactory
    from .accounts import AccountFactoryImpl
   

# Generated at 2022-06-18 02:21:41.006935
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:21:51.604688
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date

    # Create a journal entry
    je = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Create a posting
    p1 = Posting(je, date(2020, 1, 1), Account("Test", AccountType.ASSETS, "Test"), Direction.INC, Amount(Quantity(100)))
    p2 = Posting(je, date(2020, 1, 1), Account("Test", AccountType.EXPENSES, "Test"), Direction.DEC, Amount(Quantity(100)))

    # Add postings to the journal entry
    je.postings.append(p1)
    je.postings.append(p2)

    # Validate the

# Generated at 2022-06-18 02:22:01.238464
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    # Setup
    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Salary", AccountType.REVENUES))

    # Exercise

# Generated at 2022-06-18 02:22:13.430472
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountSubGroup
    from .accounts import AccountSubSubGroup
    from .accounts import AccountSubSubSubGroup
    from .accounts import AccountSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubSubSubGroup

# Generated at 2022-06-18 02:22:25.957911
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[TestSource]):
        pass


# Generated at 2022-06-18 02:22:33.827079
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .numbers import Amount, Quantity
    from .transactions import Transaction

    # Setup:
    business = Business("My Business")
    currency = Currency("USD")
    cash = Account("Cash", AccountType.ASSETS, currency)
    revenue = Account("Revenue", AccountType.REVENUES, currency)
    expense = Account("Expense", AccountType.EXPENSES, currency)

    # Test:
    journal = JournalEntry(datetime.date.today(), "Test Journal", Transaction(business, "Test Transaction"))
    journal.post(datetime.date.today(), cash, Quantity(100))
    journal.post(datetime.date.today(), revenue, Amount(100))

# Generated at 2022-06-18 02:22:38.724243
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.accounts import Account, AccountType
    from ..accounts.accounts import AccountRepository
    from ..accounts.accounts import AccountRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepository
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:22:56.064317
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass


# Generated at 2022-06-18 02:23:05.940067
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        source: JournalEntrySource


# Generated at 2022-06-18 02:23:17.466546
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from datetime import timedelta
    from typing import List
    from typing import cast
    from typing import Iterable
    from typing import TypeVar
    from typing import Protocol
    from typing import Generic
    from typing import Optional
    from typing import Tuple
    from typing import overload
    from typing import Union
    from typing import Any
    from typing import Callable
    from typing import Type
    from typing import get_type_hints
    from typing import get_origin
    from typing import get_args
    from typing import NewType
    from typing import NamedTuple
    from typing import Literal
    from typing import Final
    from typing import TYPE_CHECKING
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import TYPE_CHECKING
    from typing import TYPE_CHECKING
    from typing import TYPE

# Generated at 2022-06-18 02:23:28.790530
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Test", [
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.REVENUES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:23:36.879203
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a positive quantity
    journal.post(datetime.date(2020, 1, 1), account, Quantity(1))

    # Check the posting
    assert journal.postings[0].amount == Amount(1)
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].is_debit == True
    assert journal.postings[0].is_credit == False

    # Post a negative quantity

# Generated at 2022-06-18 02:23:46.440618
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:23:46.872389
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-18 02:23:55.754437
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date

# Generated at 2022-06-18 02:24:05.111351
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return [
            JournalEntry(datetime.date(2020, 1, 1), "Test", "Test", [])
        ]

    # Define an account
    account = Account("Test", AccountType.ASSETS)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test", [])

    # Post a debit
    journal_entry.post(datetime.date(2020, 1, 1), account, 1)

    # Post a credit
    journal_entry.post

# Generated at 2022-06-18 02:24:14.294264
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .currencies import Currency

    # Create a journal entry
    je = JournalEntry[None](date(2020, 1, 1), "Test", None)

    # Create an account
    account = Account("Test", AccountType.ASSETS, Currency.USD)

    # Post an amount to the account
    je.post(date(2020, 1, 1), account, Quantity(100))

    # Check that the posting was created
    assert len(je.postings) == 1

    # Check that the posting is a debit
    assert je.postings[0].is_debit

    # Check that the posting is for the correct account
    assert je.postings[0].account == account

    # Check that the posting is for

# Generated at 2022-06-18 02:24:35.869704
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .transactions import Transaction

    # Create a journal entry
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=Transaction(guid=makeguid()))

    # Post an increment event to an account
    journal_entry.post(date=datetime.date(2020, 1, 1), account=Account(name="Test Account", type=AccountType.ASSETS), quantity=Quantity(1))

    # Post a decrement event to an account

# Generated at 2022-06-18 02:24:46.022476
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction", "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Post an increment event to an asset account:
    journal_entry.post(datetime.date.today(), Account(AccountType.ASSETS, "Test Asset Account"), +100)

    # Post a decrement event to an expense account:
    journal_entry.post(datetime.date.today(), Account(AccountType.EXPENSES, "Test Expense Account"), -100)

    # Validate the journal entry:
    journal_entry

# Generated at 2022-06-18 02:24:52.817200
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:25:01.865151
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class MockJournalEntry(JournalEntry):
        def __init__(self, date: date, description: str, source: object, postings: Iterable[Posting]):
            super().__init__(date, description, source, postings)

    class MockReadJournalEntries(ReadJournalEntries):
        def __init__(self, journal_entries: Iterable[JournalEntry]):
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return self.journal_entries

    ## Test:

# Generated at 2022-06-18 02:25:08.494264
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:25:17.694660
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Create an account:
    account = Account(AccountType.ASSETS, "Test Account")

    # Post an amount to the account:
    journal_entry.post(datetime.date.today(), account, 100)

    # Check if the journal entry is valid:
    journal_entry.validate()

# Generated at 2022-06-18 02:25:28.218101
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Account of the posting.
    account = Account("Test Account", AccountType.ASSETS)

    #: Direction of the posting.
    direction = Direction.INC

    #: Posted amount (in absolute

# Generated at 2022-06-18 02:25:36.539242
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:25:44.977534
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    transaction = Transaction(ledger)
    transaction.post(datetime.date(2020, 1, 1), ledger.accounts["Assets"], Amount(100))
    transaction.post(datetime.date(2020, 1, 1), ledger.accounts["Revenues"], Amount(100))

# Generated at 2022-06-18 02:25:55.787598
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-18 02:26:35.863592
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:26:45.612705
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts import Account
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from ..ledgers import Ledger
    from ..ledgers.read import ReadLedgers
    from ..ledgers.write import WriteLedgers
    from ..ledgers.journal import Journal
    from ..ledgers.journal.read import ReadJournalEntries
    from ..ledgers.journal.write import WriteJournalEntries
    from ..ledgers.journal.post import PostJournalEntries
    from ..ledgers.journal.post import PostJournalEntry
    from ..ledgers.journal.post import PostJournalEntryPosting
    from ..ledgers.journal.post import PostJournalEntryPostings
    from ..ledgers.journal.post import PostJournalEntryPostingAmount
    from ..ledgers.journal.post import PostJournalEntryPost

# Generated at 2022-06-18 02:26:53.809469
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger, LedgerType

    ledger = Ledger(LedgerType.ASSETS, "Cash", "Cash")
    account = Account(ledger, "Cash", AccountType.ASSETS)

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    journal.post(datetime.date(2020, 1, 1), account, 100)
    journal.post(datetime.date(2020, 1, 1), account, -100)

    assert journal.postings[0].amount == 100
    assert journal.postings[1].amount == 100

# Generated at 2022-06-18 02:27:00.179035
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    from .accounts import AccountType

    from ..commons.numbers import Amount, Quantity

    from ..commons.zeitgeist import DateRange

    from .journal import JournalEntry, Posting

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield JournalEntry(date(2020, 1, 1), "", None).post(date(2020, 1, 1), Account("A", AccountType.ASSETS), Quantity(100))
        yield JournalEntry(date(2020, 1, 1), "", None).post(date(2020, 1, 1), Account("B", AccountType.EQUITIES), Quantity(100))

# Generated at 2022-06-18 02:27:10.774612
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class TestReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    TestReadJournalEntries()(DateRange(date(2020, 1, 1), date(2020, 1, 31)))
    TestReadJournalEntries().__call__(DateRange(date(2020, 1, 1), date(2020, 1, 31)))
    TestReadJournalEntries.__call__(TestReadJournalEntries(), DateRange(date(2020, 1, 1), date(2020, 1, 31)))


# Generated at 2022-06-18 02:27:18.622164
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import AccountType, Account, AccountGroup
    from .ledgers import Ledger
    from .books import Book
    from .journals import Journal
    from .transactions import Transaction
    from .transactions.sales import SalesTransaction
    from .transactions.purchases import PurchasesTransaction
    from .transactions.cash import CashTransaction
    from .transactions.bank import BankTransaction
    from .transactions.general import GeneralTransaction
    from .transactions.payroll import PayrollTransaction
    from .transactions.adjustments import AdjustmentsTransaction
    from .transactions.closing import ClosingTransaction

    # Define a ledger:

# Generated at 2022-06-18 02:27:27.214392
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry")
    journal.post(datetime.date(2020, 1, 1), ledger.get_account("Assets:Cash"), Quantity(100))

# Generated at 2022-06-18 02:27:35.374012
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:27:41.967079
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:27:47.602194
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post a quantity to the account
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Check if the journal entry is valid
    journal.validate()

    # Check if the posting is valid
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020, 1, 1)