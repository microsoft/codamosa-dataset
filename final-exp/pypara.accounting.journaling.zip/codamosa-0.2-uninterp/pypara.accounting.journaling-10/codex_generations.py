

# Generated at 2022-06-18 02:19:38.044989
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a business:
    business = Business("Test Business")

    # Create a ledger:
    ledger = Ledger(business)

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Create accounts:
    account_1 = Account(business, "Test Account 1", AccountType.ASSETS)
    account_2 = Account(business, "Test Account 2", AccountType.EQUITIES)

    # Post to accounts:
    journal_entry.post(datetime.date.today(), account_1, 100)
    journal_entry

# Generated at 2022-06-18 02:19:48.264117
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger

    # Create a ledger
    ledger = Ledger()

    # Create a journal entry
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=None)

    # Post to the journal entry
    journal_entry.post(date=datetime.date(2020, 1, 1), account=Account(name="Cash", type=AccountType.ASSETS), quantity=Quantity(100))

# Generated at 2022-06-18 02:19:57.484781
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a transaction
    transaction = Transaction(book, "Test Transaction")

    # Create an event
    event = Event(transaction, "Test Event")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", event)

    # Create an account
    account = Account(ledger, "Test Account", AccountType.ASSETS)

    # Post an amount to the account

# Generated at 2022-06-18 02:20:05.280942
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post to the account
    journal_entry.post(datetime.date(2020, 1, 1), account, 100)

    # Validate the journal entry
    journal_entry.validate()

    # Get the postings
    postings = journal_entry.postings

    # Check the postings
    assert len(postings) == 1
    assert postings[0].date == datetime.date(2020, 1, 1)
    assert postings[0].account == account
    assert postings

# Generated at 2022-06-18 02:20:14.269022
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:20:19.738172
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

# Generated at 2022-06-18 02:20:30.061386
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountingPeriod
    from .accounts import AccountingPeriods
    from .accounts import AccountingPeriodType
    from .accounts import AccountingPeriodTypes
    from .accounts import AccountingYear
    from .accounts import AccountingYears
    from .accounts import AccountingYearType
    from .accounts import AccountingYearTypes
    from .accounts import ChartOfAccounts
    from .accounts import ChartOfAccountsEntry
    from .accounts import ChartOfAccountsEntryType
    from .accounts import ChartOfAccountsEntryTypes
    from .accounts import ChartOfAccountsType
    from .accounts import ChartOfAccountsTypes
    from .accounts import Currency
    from .accounts import CurrencyType
    from .accounts import CurrencyTypes
   

# Generated at 2022-06-18 02:20:40.652655
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .books import Book
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .books import Book

    # Create a business
    business = Business("Test Business")

    # Create a ledger
    ledger = Ledger(business, "Test Ledger")

    # Create a book
    book = Book(ledger, "Test Book")

    # Create an account
    account = Account(book, "Test Account", AccountType.ASSETS)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2019, 1, 1), "Test Journal Entry", business)

    # Post an amount to the account

# Generated at 2022-06-18 02:20:49.087017
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source="Test Source")

    # Define a journal entry reader:
    def read_journal_entries_2(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source="Test Source")

    # Define a journal entry reader:

# Generated at 2022-06-18 02:20:58.449798
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:21:13.762192
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            mock = Mock(spec=ReadJournalEntries)
            mock.__call__.return_value = [JournalEntry(date(2020, 1, 1), "Test", None)]
            self.assertEqual(mock(DateRange(date(2020, 1, 1), date(2020, 1, 2))), [JournalEntry(date(2020, 1, 1), "Test", None)])

    Test().test_ReadJournalEntries___call__()

# Generated at 2022-06-18 02:21:18.225972
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Define a journal entry:
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal", source=None)
    journal.post(date=datetime.date(2020, 1, 1), account=Account(type=AccountType.ASSETS, name="Cash"), quantity=+100)
    journal.post(date=datetime.date(2020, 1, 1), account=Account(type=AccountType.REVENUES, name="Sales"), quantity=-100)

    # Define a read journal entries function:

# Generated at 2022-06-18 02:21:29.050498
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from .accounts import AccountType

    # Arrange:
    mock = Mock(spec=ReadJournalEntries)
    mock.__call__.return_value = [
        JournalEntry(date(2020, 1, 1), "Test", None, [
            Posting(None, date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(100)),
            Posting(None, date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, Amount(100)),
        ]),
    ]

    # Act:
    result = mock(DateRange(date(2020, 1, 1), date(2020, 1, 1)))

    # Assert:

# Generated at 2022-06-18 02:21:39.225423
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from .accounts import Account, AccountType

    # Define a function which returns a list of journal entries.

# Generated at 2022-06-18 02:21:49.185666
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    from typing import List
    j = JournalEntry[None](date(2020, 1, 1), "Test", None)
    j.post(date(2020, 1, 1), Account("A", AccountType.ASSETS), Quantity(100))
    j.post(date(2020, 1, 1), Account("B", AccountType.ASSETS), Quantity(-100))
    assert j.postings[0].amount == Amount(100)
    assert j.postings[1].amount == Amount(100)
    assert j.postings[0].is_debit
    assert j.postings[1].is_credit
    assert j.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:21:59.195455
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield JournalEntry(date(2020, 1, 1), "First entry", None, [Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100))])
        yield JournalEntry(date(2020, 1, 2), "Second entry", None, [Posting(None, date(2020, 1, 2), Account("B", AccountType.ASSETS), Direction.INC, Amount(200))])


# Generated at 2022-06-18 02:22:05.921178
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    business = Business(ledger)

    # Create accounts:
    cash = Account(ledger, "Cash", AccountType.ASSETS)
    revenue = Account(ledger, "Revenue", AccountType.REVENUES)
    expense = Account(ledger, "Expense", AccountType.EXPENSES)

    # Create transaction:
    transaction = Transaction(ledger, "Test", business)

    # Create journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test", transaction)

    # Post to journal entry:
    journal_entry.post(datetime.date.today(), cash, 100)

# Generated at 2022-06-18 02:22:15.478356
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategoryType
   

# Generated at 2022-06-18 02:22:28.015206
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
   

# Generated at 2022-06-18 02:22:38.360064
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from datetime import timedelta
    from datetime import datetime
    from datetime import timezone
    from datetime import time
    from datetime import tzinfo
    from datetime import timezone
    from datetime import timedelta
    from datetime import datetime
    from datetime import date
    from datetime import timezone
    from datetime import time
    from datetime import tzinfo
    from datetime import timedelta
    from datetime import datetime
    from datetime import date
    from datetime import timezone
    from datetime import time
    from datetime import tzinfo
    from datetime import timedelta
    from datetime import datetime
    from datetime import date
    from datetime import timezone
    from datetime import time
    from datetime import tzinfo

# Generated at 2022-06-18 02:23:03.783587
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from datetime import date

    # Create a journal entry
    je = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Post an amount to an account
    je.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))

    # Check the postings
    assert len(je.postings) == 1
    assert je.postings[0].date == date(2020, 1, 1)
    assert je.postings[0].account.name == "Test"
    assert je.postings[0].account.type == AccountType.ASSETS
    assert je.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:23:15.629113
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .journal import JournalEntry, Direction
    from .postings import Posting

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a transaction
    transaction = Transaction(book, makeguid(), "Test Transaction", datetime.date(2020, 1, 1))

    # Create an event
    event = Event(transaction, makeguid(), "Test Event", datetime.date(2020, 1, 1))

    # Create a

# Generated at 2022-06-18 02:23:23.179684
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date

    # Create a journal entry
    journal = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a debit
    journal.post(date(2020, 1, 1), account, Quantity(100))

    # Post a credit
    journal.post(date(2020, 1, 1), account, Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Check the postings
    assert len(journal.postings) == 2

# Generated at 2022-06-18 02:23:33.028403
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .currencies import Currency
    from .exchanges import Exchange
    from .transactions import Transaction
    from .wallets import Wallet

    ## Setup:
    currency = Currency("USD", "US Dollar", "US$", "USD", "840", "2")
    exchange = Exchange("USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD")
    wallet = Wallet("USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD")

# Generated at 2022-06-18 02:23:40.102992
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .commons.zeitgeist import DateRange

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryTest:
        date: date
        description: str
        postings: List[Posting]

    # Define a read journal entries function:

# Generated at 2022-06-18 02:23:45.816595
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.sales import SalesInvoice
    from .transactions.purchases import PurchaseInvoice
    from .transactions.payments import Payment
    from .transactions.receipts import Receipt
    from .transactions.adjustments import Adjustment
    from .transactions.adjustments import AdjustmentType
    from .transactions.adjustments import AdjustmentReason
    from .transactions.adjustments import AdjustmentCategory
    from .transactions.adjustments import AdjustmentSubCategory
    from .transactions.adjustments import AdjustmentReasonCategory
    from .transactions.adjustments import AdjustmentReasonSubCategory
    from .transactions.adjustments import AdjustmentReason

# Generated at 2022-06-18 02:24:06.218634
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a debit
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Post a credit
    journal.post(datetime.date(2020, 1, 1), account, Quantity(-100))

    # Check the postings
    assert len(journal.postings) == 2
    assert journal.postings[0].is_debit

# Generated at 2022-06-18 02:24:14.765536
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
                from .journal import JournalEntry


# Generated at 2022-06-18 02:24:23.741083
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .journals import Journal
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a journal:
    journal = Journal(ledger)

    # Create a transaction:
    transaction = Transaction(journal)

    # Create a read journal entries function:
    read_journal_entries = ReadJournalEntries[Transaction]()

    # Create a journal entry:
    journal_entry = JournalEntry[Transaction](date(2020, 1, 1), "Test", transaction)

    # Create a posting:

# Generated at 2022-06-18 02:24:32.771084
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    from .accounts import Account, AccountType
    from .currencies import Currency, CurrencyUnit
    from .products import Product
    from .units import Unit

    # Act
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", Product("Test", Unit("Test", CurrencyUnit(Currency.USD))), [
        Posting(journal, datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
        Posting(journal, datetime.date(2020, 1, 1), Account("Test", AccountType.REVENUES), Direction.DEC, Amount(100)),
    ])

    # Assert
    journal.validate()

# Generated at 2022-06-18 02:25:00.325048
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    book = Book()
    ledger = Ledger(book)
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    txn = Transaction(ledger, datetime.date(2020, 1, 1), "Test Transaction")

# Generated at 2022-06-18 02:25:07.553730
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder

# Generated at 2022-06-18 02:25:18.154708
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import ReadLedger
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries
    from .readers import ReadJournalEntries

# Generated at 2022-06-18 02:25:28.650308
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class MockJournalEntry(JournalEntry):
        def __init__(self, date: date, description: str, source: str, postings: Iterable[Posting]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:25:35.764359
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger, LedgerType
    from .transactions import Transaction, TransactionType

    # Define a ledger:
    ledger = Ledger(
        name="Test Ledger",
        type=LedgerType.ASSETS,
        accounts=[
            Account(name="Cash", type=AccountType.ASSETS),
            Account(name="Equity", type=AccountType.EQUITIES),
            Account(name="Revenue", type=AccountType.REVENUES),
            Account(name="Expense", type=AccountType.EXPENSES),
        ],
    )

    # Define a transaction:

# Generated at 2022-06-18 02:25:44.443842
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Given: A mock journal entry
    mock_journal_entry = Mock(spec=JournalEntry)

    # And: A mock function which returns the mock journal entry
    mock_read_journal_entries = Mock(spec=ReadJournalEntries)
    mock_read_journal_entries.return_value = [mock_journal_entry]

    # When: I call the mock function with a date range
    result = mock_read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

    # Then: The mock function is called with the date range


# Generated at 2022-06-18 02:25:55.266601
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .ledgers import Ledger
    from .ledgers import LedgerEntry
    from .ledgers import LedgerEntryType
    from .ledgers import LedgerType
    from .ledgers import ReadLedgerEntries
    from .ledgers import ReadLedgers
    from .ledgers import WriteLedgerEntries
    from .ledgers import WriteLedgers
    from .ledgers import create_ledger
    from .ledgers import create_ledger_entry
    from .ledgers import create_ledger_entry_type
    from .ledgers import create_ledger_type
    from .ledgers import read_ledger_entries
    from .ledgers import read_ledgers

# Generated at 2022-06-18 02:26:06.040766
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a ledger:
    ledger = Ledger()

    # Define an account:
    account = Account(AccountType.ASSETS, "Cash")

    # Define a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post a debit:
    journal.post(datetime.date(2020, 1, 1), account, +100)

    # Post a credit:
    journal.post(datetime.date(2020, 1, 1), account, -100)

    # Validate the journal entry:

# Generated at 2022-06-18 02:26:15.989059
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase, mock
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_should_return_empty_list_when_no_journal_entries_found(self):
            # Given
            read_journal_entries: ReadJournalEntries[str] = mock.Mock()
            read_journal_entries.return_value = []

            # When
            actual = read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

            # Then
            self.assertEqual([], actual)

        def test_should_return_journal_entries_when_found(self):
            # Given
            journal_

# Generated at 2022-06-18 02:26:23.403960
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account
    from .commons import Period
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry1(JournalEntry):
        pass

    # Define a journal entry reader:
    def read_journal_entries(period: Period) -> List[JournalEntry1]:
        return [
            JournalEntry1(date(2020, 1, 1), "Test", None)
                .post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), +100)
                .post(date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), -100)
        ]

    # Test:

# Generated at 2022-06-18 02:27:19.313631
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock, call

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:27:28.287019
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable, List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:27:36.094039
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test(self):
            def read_journal_entries(period: DateRange) -> List[JournalEntry[None]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", None, [
                        Posting(None, date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, 100),
                        Posting(None, date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, 100),
                    ]),
                ]


# Generated at 2022-06-18 02:27:45.490761
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger, LedgerEntry
    from .readers import read_ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test transaction",
        source=None,
    )

    # Post the transaction to the ledger:
    ledger.post(transaction)

    # Create a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test journal entry",
        source=None,
    )

    # Post the journal entry to the ledger:

# Generated at 2022-06-18 02:27:52.225859
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            from .accounts import Account, AccountType

            def read_journal_entries(period: DateRange) -> List[JournalEntry[None]]:
                from .journal import JournalEntry

                return [
                    JournalEntry(date(2020, 1, 1), "Test", None).post(date(2020, 1, 1), Account("A", AccountType.ASSETS), 100),
                    JournalEntry(date(2020, 1, 1), "Test", None).post(date(2020, 1, 1), Account("B", AccountType.ASSETS), -100),
                ]


# Generated at 2022-06-18 02:28:00.917141
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Setup:
            def read_journal_entries(period: DateRange) -> List[JournalEntry[str]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Description", "Source", [
                        Posting(None, date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(100)),
                        Posting(None, date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                    ]),
                ]

           

# Generated at 2022-06-18 02:28:09.376403
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return []

    class TestCase(TestCase):
        def test_ReadJournalEntries___call__(self):
            read_journal_entries = TestReadJournalEntries()
            read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

# Generated at 2022-06-18 02:28:16.906497
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Salary", AccountType.REVENUES))

    t = Transaction(ledger, "Salary")
    t.post(datetime.date(2020, 1, 1), "Assets:Cash", +100)
    t.post(datetime.date(2020, 1, 1), "Revenues:Salary", -100)

    t.validate()
    t.journal.validate()

# Generated at 2022-06-18 02:28:24.989107
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import ZERO
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", None)
    journal.post(datetime.date(2020, 1, 1), Account(ledger, "Assets", AccountType.ASSETS), ZERO)
    journal.post(datetime.date(2020, 1, 1), Account(ledger, "Equities", AccountType.EQUITIES), ZERO)

# Generated at 2022-06-18 02:28:33.598491
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .readers import ReadLedger
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_
    from .readers import ReadJournalEntries as ReadJournalEntries_