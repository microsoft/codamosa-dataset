

# Generated at 2022-06-18 02:19:47.710610
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return [
                JournalEntry(date(2019, 1, 1), "Test", "Test", [
                    Posting(None, date(2019, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2019, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:19:57.448439
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger, "Test transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test journal entry", transaction)

    # Create an account:
    account = Account(AccountType.ASSETS, "Test account")

    # Post a debit:
    journal_entry.post(datetime.date.today(), account, Quantity(100))

    # Post a credit:
    journal_entry.post(datetime.date.today(), account, Quantity(-100))

   

# Generated at 2022-06-18 02:20:05.257821
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a ledger
    ledger = Ledger()

    # Create a transaction type
    transaction_type = TransactionType(name="Test Transaction Type")

    # Create a transaction
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        type=transaction_type,
        ledger=ledger,
    )

    # Create an account
    account = Account(
        name="Test Account",
        type=AccountType.ASSETS,
        ledger=ledger,
    )

    # Create a journal entry

# Generated at 2022-06-18 02:20:14.266232
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .commons.numbers import Amount, Quantity

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a read function:

# Generated at 2022-06-18 02:20:19.710610
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from dataclasses import asdict
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from dataclasses import asdict
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from dataclasses import asdict
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date

# Generated at 2022-06-18 02:20:26.374286
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries, Direction

    # Define a function which reads journal entries from a source.
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return [
            JournalEntry(date(2020, 1, 1), "Test Journal Entry", "Test Source", [
                Posting(None, date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Direction.INC, Amount(100)),
                Posting(None, date(2020, 1, 1), Account("Test Account", AccountType.EXPENSES), Direction.DEC, Amount(100)),
            ]),
        ]

    # Define a variable of type ReadJournalEntries.
    read_

# Generated at 2022-06-18 02:20:35.524706
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .transactions import Transaction

    book = Book(Currency.USD)
    event = Event(book, datetime.date(2020, 1, 1), "Test")
    transaction = Transaction(event, "Test")

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", transaction)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), 100)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), -100)
    journal.validate()

# Generated at 2022-06-18 02:20:44.162304
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger, LedgerType
    from .transactions import Transaction

    ledger = Ledger(LedgerType.ASSETS, "Test Ledger")
    account = Account(ledger, AccountType.ASSETS, "Test Account")
    transaction = Transaction("Test Transaction")

    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)
    journal_entry.post(datetime.date.today(), account, Quantity(100))
    journal_entry.validate()


# Generated at 2022-06-18 02:20:55.639266
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeTypeCategory
    from .transactions import TransactionTypeTypeCategoryType
    from .transactions import TransactionTypeTypeCategoryTypeType
    from .transactions import TransactionTypeTypeCategoryTypeTypeType
    from .transactions import TransactionTypeTypeCategoryTypeTypeTypeType
    from .transactions import TransactionTypeTypeCategoryTypeTypeTypeTypeType
    from .transactions import TransactionTypeTypeCategoryTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeTypeCategoryTypeTypeTypeTypeTypeTypeType

# Generated at 2022-06-18 02:21:02.581449
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Arrange:
    journal_entry_1 = JournalEntry(date(2020, 1, 1), "Description 1", "Source 1")
    journal_entry_1.postings.append(Posting(journal_entry_1, date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Direction.INC, Amount(100)))
    journal_entry_1.postings.append(Posting(journal_entry_1, date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), Direction.DEC, Amount(100)))

    journal_

# Generated at 2022-06-18 02:21:18.331515
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting):
        pass


# Generated at 2022-06-18 02:21:29.137278
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .journal import ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a journal entry read function.

# Generated at 2022-06-18 02:21:39.301357
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry
    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry):
        pass

    # Define a function to read journal entries

# Generated at 2022-06-18 02:21:44.660621
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.accounts import AccountTransaction
    from .transactions.ledgers import LedgerTransaction
    from .transactions.transactions import TransactionTransaction
    from .transactions.transactions import TransactionType


# Generated at 2022-06-18 02:21:55.865951
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    je = JournalEntry[object](datetime.date(2020, 1, 1), "Test", object())

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post to the account
    je.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Check the posting
    assert je.postings[0].journal == je
    assert je.postings[0].date == datetime.date(2020, 1, 1)
    assert je.postings[0].account == account
    assert je.postings[0].direction == Direction

# Generated at 2022-06-18 02:22:04.230704
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass


# Generated at 2022-06-18 02:22:14.919989
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        source: JournalEntrySource

    @dataclass(frozen=True)
    class JournalEntryPosting(Posting):
        journal: JournalEntry

    @dataclass(frozen=True)
    class JournalEntryRead(ReadJournalEntries):
        journal_entries: List[JournalEntry]


# Generated at 2022-06-18 02:22:27.478164
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger

    # Define a journal entry reader:

# Generated at 2022-06-18 02:22:33.285681
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    # Create a journal entry with two postings
    journal_entry = JournalEntry[int](date=datetime.date.today(), description="Test journal entry", source=1)
    journal_entry.post(date=datetime.date.today(), account=Account(code="101", name="Cash", type=AccountType.ASSETS), quantity=100)
    journal_entry.post(date=datetime.date.today(), account=Account(code="201", name="Sales", type=AccountType.REVENUES), quantity=-100)

    # Validate the journal entry
    journal_entry.validate()

# Generated at 2022-06-18 02:22:43.064027
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger
    from .ledgers.ledger import LedgerEntry
    from .ledgers.read import ReadLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries
    from .ledgers.write import WriteLedgerEntries

# Generated at 2022-06-18 02:22:59.082960
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, mock

    from ..commons.zeitgeist import DateRange

    class TestReadJournalEntries(ReadJournalEntries[None]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return []

    class TestCase(TestCase):
        def test_ReadJournalEntries___call__(self):
            read_journal_entries = TestReadJournalEntries()
            with mock.patch.object(read_journal_entries, "__call__") as mock_call:
                read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 12, 31)))

# Generated at 2022-06-18 02:23:06.229160
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    journal = JournalEntry[str]("2019-01-01", "test", "test")
    account = Account("test", AccountType.ASSETS)
    # Act
    journal.post("2019-01-01", account, 1)
    # Assert
    assert journal.postings[0].amount == 1
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].is_debit == True
    assert journal.postings[0].is_credit == False
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == "2019-01-01"


# Generated at 2022-06-18 02:23:17.724509
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .journal import JournalEntry, Direction

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    journal.post(datetime.date(2020, 1, 1), Account("A", "Assets"), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account("B", "Expenses"), Quantity(-100))

    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[1].direction == Direction.DEC
    assert journal.postings[0].is_debit
    assert journal.postings[1].is_credit
    assert journal.postings[0].amount == Amount(100)
   

# Generated at 2022-06-18 02:23:28.891238
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting):
        pass


# Generated at 2022-06-18 02:23:37.362950
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> List[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Test", [
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:23:46.469862
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader:

# Generated at 2022-06-18 02:23:55.246661
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    transaction_type = TransactionType("Test", TransactionTypeCategory.BUSINESS)
    transaction = Transaction(transaction_type)
    transaction.post(ledger.account("Assets"), 100)


# Generated at 2022-06-18 02:24:02.731916
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test"

    #: Business object as the source of the journal entry.
    source = "Test"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Journal entry the posting belongs to.
    journal = JournalEntry(date, description, source, postings, guid)

    #: Date of posting.
    date = datetime.date(2020, 1, 1)

    #

# Generated at 2022-06-18 02:24:13.963727
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency, CurrencyUnit
    from .ledgers import Ledger
    from .transactions import Transaction

    ## Setup:
    ledger = Ledger(Currency(CurrencyUnit.USD))
    business = Business("Test Business")
    ledger.add_business(business)

    ## Test:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", None)
    journal.post(datetime.date(2020, 1, 1), Account(ledger, AccountType.ASSETS, "Cash"), +100)
    journal.post(datetime.date(2020, 1, 1), Account(ledger, AccountType.EXPENSES, "Expenses"), -100)
    journal.validate()

    ## Test:
    journal

# Generated at 2022-06-18 02:24:23.703600
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a ledger:

# Generated at 2022-06-18 02:24:47.178987
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:24:57.135143
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> List[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Test", [
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:25:06.712123
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List, Tuple
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:25:17.797519
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
   

# Generated at 2022-06-18 02:25:28.336558
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger(makeguid())
    ledger.create_account(Account("Cash", AccountType.ASSETS))
    ledger.create_account(Account("Equity", AccountType.EQUITIES))
    ledger.create_account(Account("Revenue", AccountType.REVENUES))
    ledger.create_account(Account("Expense", AccountType.EXPENSES))

    # Create a transaction:
    transaction = Transaction(makeguid(), ledger)

    # Create a journal entry:

# Generated at 2022-06-18 02:25:34.665469
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

    # Act
    journal.post(datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))

    # Assert
    assert len(journal.postings) == 1
    assert journal.postings[0].amount == Amount(100)
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].is_debit
    assert not journal.postings[0].is_credit


# Generated at 2022-06-18 02:25:43.514180
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from datetime import date
    from dataclasses import asdict
    j = JournalEntry(date(2020, 1, 1), "test", "test")
    j.post(date(2020, 1, 1), Account("test", AccountType.ASSETS), Quantity(100))
    j.post(date(2020, 1, 1), Account("test", AccountType.ASSETS), Quantity(-100))

# Generated at 2022-06-18 02:25:54.286605
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account
    from ..books.ledgers import Ledger
    from ..books.ledgers import LedgerEntry
    from ..books.ledgers import LedgerEntryType
    from ..books.ledgers import LedgerType
    from ..books.ledgers import ReadLedgerEntries
    from ..books.ledgers import ReadLedgers
    from ..books.ledgers import ReadLedgersByType
    from ..books.ledgers import ReadLedgersByTypeAndName
    from ..books.ledgers import ReadLedgersByTypeAndNameAndCurrency
    from ..books.ledgers import ReadLedgersByTypeAndNameAndCurrencyAndParent
    from ..books.ledgers import ReadLedgersByTypeAndNameAndParent
    from ..books.ledgers import ReadLedgersByTypeAndParent
    from ..books.ledgers import ReadLedgers

# Generated at 2022-06-18 02:26:04.892802
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journals import JournalEntry, Posting, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a function type.
    _F = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #: Defines a function type.
    _G = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #: Defines a function type.
    _H = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #: Defines a function type.
    _I = Callable[[DateRange], Iterable[JournalEntry[_T]]]

    #:

# Generated at 2022-06-18 02:26:10.499397
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    # Define a journal entry:
    journal = JournalEntry[str](date(2020, 1, 1), "Test", "Test")
    journal.post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), +100)
    journal.post(date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), -100)

    # Define a function which reads journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield journal

    # Test:

# Generated at 2022-06-18 02:26:56.960601
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
    from .accounts import Account, AccountType
   

# Generated at 2022-06-18 02:27:07.450280
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a ledger:
    ledger = Ledger()

    # Define a transaction:
    transaction = Transaction(
        date=date(2020, 1, 1),
        description="Test Transaction",
        source=None,
        postings=[
            (ledger.accounts.assets.cash, 100),
            (ledger.accounts.expenses.office, -100),
        ],
    )

    # Define a read function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Transaction]]:
        return [transaction.journal]

# Generated at 2022-06-18 02:27:16.838535
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .readers import ReadJournalEntries
    from .transactions import Transaction

    # Define a ledger:
    ledger = Ledger()

    # Define accounts:
    cash = Account(ledger, "Cash", AccountType.ASSETS)
    revenue = Account(ledger, "Revenue", AccountType.REVENUES)
    expense = Account(ledger, "Expense", AccountType.EXPENSES)

    # Define a transaction:
    transaction = Transaction(ledger, "Test Transaction")

    # Define a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

# Generated at 2022-06-18 02:27:25.960218
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=None,
        ledger=ledger,
    )

    # Create a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=None,
    )

    # Create an account

# Generated at 2022-06-18 02:27:33.778103
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> List[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Source", [
                    Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("B", AccountType.LIABILITIES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:27:41.853137
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
                return [
                    JournalEntry(date(2020, 1, 1), "", 1),
                    JournalEntry(date(2020, 1, 2), "", 2),
                    JournalEntry(date(2020, 1, 3), "", 3),
                ]


# Generated at 2022-06-18 02:27:50.277181
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> List[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Test", [
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, 100),
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.REVENUES), Direction.DEC, 100),
                ]),
            ]


# Generated at 2022-06-18 02:27:59.432132
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book("Test Book")

    # Create a ledger:
    ledger = Ledger("Test Ledger", book)

    # Create accounts:
    assets = ledger.create_account("Assets", AccountType.ASSETS)
    revenues = ledger.create_account("Revenues", AccountType.REVENUES)
    expenses = ledger.create_account("Expenses", AccountType.EXPENSES)
    equities = ledger.create_account("Equities", AccountType.EQUITIES)

# Generated at 2022-06-18 02:28:05.738926
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase, mock

    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entries = [
                JournalEntry(date(2020, 1, 1), "", None),
                JournalEntry(date(2020, 1, 2), "", None),
                JournalEntry(date(2020, 1, 3), "", None),
            ]

            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
                return (j for j in journal_entries if j.date in period)

            # Act:

# Generated at 2022-06-18 02:28:15.338440
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    # Create a journal entry
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description='Test Journal Entry', source=None)

    # Create an account
    account = Account(type=AccountType.ASSETS, name='Test Account', description='Test Account')

    # Post a quantity to the account
    journal.post(date=datetime.date(2020, 1, 1), account=account, quantity=Quantity(100))

    # Check the postings
    assert len(journal.postings) == 1
    assert journal.postings[0].journal == journal