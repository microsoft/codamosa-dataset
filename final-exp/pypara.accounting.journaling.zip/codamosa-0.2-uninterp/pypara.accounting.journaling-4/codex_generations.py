

# Generated at 2022-06-18 02:19:39.156499
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Setup:
            journal_entry = JournalEntry[str](date(2020, 1, 1), "Test", "Test")
            journal_entry.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), +100)
            journal_entry.post(date(2020, 1, 1), Account("Test", AccountType.EXPENSES), -100)

            # Exercise:
            mock = Mock(spec=ReadJournalEntries[str])
            mock.__call__.return_value = [journal_entry]

            # Verify:


# Generated at 2022-06-18 02:19:49.042168
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .ledgers import Ledger
    from .books import Book
    from .business import Business
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a business
    business = Business(book)

    # Create a transaction
    transaction = Transaction(business)

    # Create an event
    event = Event(transaction)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2019, 1, 1), "Test", event)

    # Create an account

# Generated at 2022-06-18 02:19:57.752458
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:20:05.324223
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency, USD
    from .events import Event, EventType
    from .journals import Journal, JournalEntry
    from .ledgers import Ledger
    from .markets import Market
    from .portfolios import Portfolio
    from .positions import Position
    from .prices import Price
    from .securities import Security, SecurityType

    ## Create a book:

# Generated at 2022-06-18 02:20:14.296513
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .exchanges import Exchange
    from .markets import Market
    from .products import Product
    from .trades import Trade

    # Create a market
    market = Market("Test Market", "Test Market", Currency.USD, Exchange.TEST)

    # Create a product
    product = Product("Test Product", "Test Product", market)

    # Create a trade
    trade = Trade(product, datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), 100, 10.0)

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", trade)

    # Create an account
    account = Account("Test Account", "Test Account", AccountType.ASSETS)

    # Post

# Generated at 2022-06-18 02:20:23.667337
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    class JournalEntryImpl(JournalEntry[None]):
        def __init__(self, date, description, source, postings):
            super().__init__(date, description, source, postings)

    class PostingImpl(Posting[None]):
        def __init__(self, journal, date, account, direction, amount):
            super().__init__(journal, date, account, direction, amount)


# Generated at 2022-06-18 02:20:34.469372
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeGroup
    from .accounts import AccountTypeSubGroup
    from .accounts import AccountTypeSubSubGroup
    from .accounts import AccountTypeSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubSubGroup
    from .accounts import Account

# Generated at 2022-06-18 02:20:39.801687
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    je.post(datetime.date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Quantity(100))
    je.post(datetime.date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Quantity(-100))
    je.validate()

# Generated at 2022-06-18 02:20:48.559546
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from dataclasses import asdict
    from typing import List

    # Create a journal entry
    journal_entry = JournalEntry[str](date(2020, 1, 1), "Test Journal Entry", "Test Source")

    # Post to the journal entry
    journal_entry.post(date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))

    # Check if the posting is added to the journal entry
    assert len(journal_entry.postings) == 1

    # Check if the posting is added to the journal entry

# Generated at 2022-06-18 02:20:58.069070
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountGroup
    from .accounts import AccountGroupType, AccountGrouping
    from .accounts import AccountGroupingType
    from .accounts import AccountGroupingRule
    from .accounts import AccountGroupingRuleType
    from .accounts import AccountGroupingRuleOperator
    from .accounts import AccountGroupingRuleOperatorType
    from .accounts import AccountGroupingRuleOperatorValue
    from .accounts import AccountGroupingRuleOperatorValueType
    from .accounts import AccountGroupingRuleOperatorValue
    from .accounts import AccountGroupingRuleOperatorValueType
    from .accounts import AccountGroupingRuleOperatorValue
    from .accounts import AccountGroupingRuleOperatorValueType
    from .accounts import AccountGroupingRuleOperatorValue
    from .accounts import AccountGrouping

# Generated at 2022-06-18 02:21:07.029394
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry
    from .journal import ReadJournalEntries

    # Define a mock journal entry:
    journal_entry = JournalEntry(date(2020, 1, 1), "Description", Mock())

    # Define a mock journal entry reader:
    def read_journal_entries(period: DateRange) -> List[JournalEntry]:
        return [journal_entry]

    # Define a mock journal entry reader:
    read_journal_entries: ReadJournalEntries = read_journal_entries

    # Define a mock account:
    account = Account("Account", "Description", AccountType.ASSETS)

    # Define a mock journal

# Generated at 2022-06-18 02:21:19.024733
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Cash", AccountType.ASSETS))
    ledger.add_account(Account("Sales", AccountType.REVENUES))
    ledger.add_account(Account("Inventory", AccountType.ASSETS))
    ledger.add_account(Account("Cost of Goods Sold", AccountType.EXPENSES))

    transaction = Transaction(ledger)
    transaction.post(datetime.date(2019, 1, 1), "Cash", 100)
    transaction.post(datetime.date(2019, 1, 1), "Sales", 100)
    transaction.post(datetime.date(2019, 1, 1), "Inventory", -100)

# Generated at 2022-06-18 02:21:29.772736
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a function which reads journal entries:

# Generated at 2022-06-18 02:21:39.790414
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Setup:
    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    # Exercise:

# Generated at 2022-06-18 02:21:50.111273
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test journal entry", None)

    # Create accounts
    account_1 = Account("Account 1", AccountType.ASSETS)
    account_2 = Account("Account 2", AccountType.EQUITIES)

    # Post to accounts
    journal.post(datetime.date(2020, 1, 1), account_1, Quantity(100))
    journal.post(datetime.date(2020, 1, 1), account_2, Quantity(-100))

    # Check postings
    assert len(journal.postings) == 2
    assert journal.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:21:54.851347
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    class JournalEntryImpl(JournalEntry[str]):
        def __init__(self, date: date, description: str, source: str, postings: Iterable[Posting[str]]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:22:03.546543
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry[Transaction]()

    # Create a read journal entries function:
    read_journal_entries = ReadJournalEntries[Transaction]()

    # Create a date range:
    date_range = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))

    # Create an account:
    account = Account(AccountType.ASSETS, "Cash")

    # Create a posting:

# Generated at 2022-06-18 02:22:14.654063
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:22:27.194750
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def test(
                period: DateRange,
                expected: Iterable[JournalEntry[str]],
                *,
                read_journal_entries: Callable[[DateRange], Iterable[JournalEntry[str]]],
            ) -> None:
                actual = read_journal_entries(period)
                self.assertEqual(actual, expected)


# Generated at 2022-06-18 02:22:34.525453
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Test", [
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:22:46.138284
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, mock

    from ..commons.zeitgeist import DateRange

    class _ReadJournalEntries(ReadJournalEntries[str]):
        pass

    class _Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Setup:
            mock_journal_entries = [
                JournalEntry(date(2020, 1, 1), "", ""),
                JournalEntry(date(2020, 1, 2), "", ""),
                JournalEntry(date(2020, 1, 3), "", ""),
            ]
            mock_read_journal_entries = mock.Mock(spec=_ReadJournalEntries)
            mock_read_journal_entries.return_value = mock_journal_entries

            # Exercise:
            actual = mock_

# Generated at 2022-06-18 02:22:55.849260
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries

    #: Mock implementation of ReadJournalEntries.
    class MockReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return Mock(Iterable[JournalEntry])

    #: Mock implementation of ReadJournalEntries.
    class MockReadJournalEntries2(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return Mock(Iterable[JournalEntry])

    #: Mock implementation of ReadJournalEntries.

# Generated at 2022-06-18 02:23:05.783910
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledger import Ledger
    from .transactions import Transaction

    #: Ledger to post journal entries to.
    ledger = Ledger()

    #: Transaction to post journal entries to.
    transaction = Transaction(ledger)

    #: Journal entry to post journal entries to.
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    #: Account to post journal entries to.
    account = Account("Test Account", AccountType.ASSETS)

    #: Posting to post journal entries to.

# Generated at 2022-06-18 02:23:17.353092
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .journal import JournalEntry

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    book = Book(ledger)

    transaction = Transaction(book, "Test Transaction")

# Generated at 2022-06-18 02:23:28.789499
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger("Test Ledger")
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Cash", AccountType.ASSETS))
    ledger.add_account(Account("Bank", AccountType.ASSETS))

# Generated at 2022-06-18 02:23:29.413897
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "Not implemented"

# Generated at 2022-06-18 02:23:38.009084
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .tags import Tag

    # Create a journal entry
    journal = JournalEntry[Tag](date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=Tag("Test"))

    # Create an account
    account = Account(name="Test Account", type=AccountType.ASSETS)

    # Post an amount to the account
    journal.post(date=datetime.date(2020, 1, 1), account=account, quantity=Quantity(100))

    # Check the postings
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
   

# Generated at 2022-06-18 02:23:46.527027
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger, ReadLedgers
    from .transactions import Transaction, TransactionType

    # Define a ledger:
    ledger = Ledger(
        "Test Ledger",
        "Test Ledger",
        [
            Account(AccountType.ASSETS, "Cash", "Cash"),
            Account(AccountType.ASSETS, "Bank", "Bank"),
            Account(AccountType.EQUITIES, "Equity", "Equity"),
            Account(AccountType.REVENUES, "Sales", "Sales"),
            Account(AccountType.EXPENSES, "Cost of Goods Sold", "Cost of Goods Sold"),
        ],
    )

    # Define a transaction:
   

# Generated at 2022-06-18 02:23:55.316487
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a business:
    business = Business(name="Test Business")

    # Create a ledger:
    ledger = Ledger(business=business, name="Test Ledger")

    # Create an account:
    account = Account(ledger=ledger, name="Test Account", type=AccountType.ASSETS)

    # Create a transaction:
    transaction = Transaction(ledger=ledger, date=datetime.date(2020, 1, 1), description="Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=transaction)

    # Post to the account:
    journal_entry

# Generated at 2022-06-18 02:24:02.798799
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class _Source:
        pass

    @dataclass(frozen=True)
    class _JournalEntry(JournalEntry[_Source]):
        pass

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_Source]]:
        return [
            _JournalEntry(date=datetime.date(2020, 1, 1), description="A", source=_Source()),
            _JournalEntry(date=datetime.date(2020, 1, 2), description="B", source=_Source()),
            _JournalEntry(date=datetime.date(2020, 1, 3), description="C", source=_Source()),
        ]


# Generated at 2022-06-18 02:24:24.570820
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Setup:
    mock_journal_entries: List[JournalEntry[str]] = [
        JournalEntry(date(2020, 1, 1), "Description", "Source", []),
        JournalEntry(date(2020, 1, 2), "Description", "Source", []),
        JournalEntry(date(2020, 1, 3), "Description", "Source", []),
    ]

    def mock_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return (i for i in mock_journal_entries if period.contains(i.date))

    # Exercise:

# Generated at 2022-06-18 02:24:34.181192
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType

    #: Dummy journal entry reader.

# Generated at 2022-06-18 02:24:44.356710
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountSubCategory
    from .accounts import AccountScheme
    from .accounts import AccountSchemeCategory
    from .accounts import AccountSchemeSubCategory
    from .accounts import AccountSchemeCategoryType
    from .accounts import AccountSchemeSubCategoryType
    from .accounts import AccountSchemeType
    from .accounts import AccountSchemeCategoryType
    from .accounts import AccountSchemeSubCategoryType
    from .accounts import AccountSchemeType
    from .accounts import AccountSchemeCategoryType
    from .accounts import AccountSchemeSubCategoryType
    from .accounts import AccountSchemeType
    from .accounts import AccountSchemeCategoryType
    from .accounts import AccountSchemeSub

# Generated at 2022-06-18 02:24:54.496136
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-18 02:25:05.574260
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        pass

    #: Type of functions which read journal entries from a source.
    class ReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    #: Account of the posting.
    account = Account(AccountType.ASSETS, "Cash")

    #: Date of the entry.

# Generated at 2022-06-18 02:25:16.685134
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(transaction)

    # Create accounts:
    account_1 = Account(AccountType.ASSETS, "Cash")
    account_2 = Account(AccountType.EXPENSES, "Rent")

    # Post to the journal entry:
    journal_entry.post(datetime.date(2020, 1, 1), account_1, Quantity(100))

# Generated at 2022-06-18 02:25:27.516052
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique,

# Generated at 2022-06-18 02:25:35.035512
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTree
    from .accounts import AccountTreeBuilder
    from .accounts import AccountTreeNode
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeRoot
    from .accounts import AccountTreeRootBuilder
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType

# Generated at 2022-06-18 02:25:43.821229
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(ledger)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date.today(), "Test journal entry", transaction)

    # Create an account
    account = Account("Test account", AccountType.ASSETS)

    # Post a quantity to the account
    journal_entry.post(datetime.date.today(), account, Quantity(100))

    # Validate the journal entry
    journal_entry.validate()

    # Check if the journal entry is valid
    assert journal_entry.postings[0].amount == Amount(100)

# Generated at 2022-06-18 02:25:54.663831
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")
    journal.post(datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account("Test", AccountType.REVENUES), Quantity(-100))

    # Create a posting
    posting = Posting(journal, datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100))

    # Assertions
    assert posting.journal

# Generated at 2022-06-18 02:26:45.545216
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency, CurrencyPair
    from .markets import Market
    from .prices import Price
    from .transactions import Transaction

    # Create a book:
    book = Book("Test Book")

    # Create a market:
    market = Market("Test Market", CurrencyPair(Currency("USD"), Currency("INR")))

    # Create a transaction:
    transaction = Transaction(book, market, Price(1.0), Quantity(100))

    # Create a journal entry:
    journal = JournalEntry[Transaction](datetime.date(2020, 1, 1), "Test Journal", transaction)

    # Post to journal:
    journal.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))

# Generated at 2022-06-18 02:26:55.483779
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .commons.types import EventType
    from .commons.types import TransactionType
    from .commons.types import LedgerType
    from .commons.types import AccountType
    from .commons.types import AccountSubType
    from .commons.types import AccountCategory
    from .commons.types import AccountSubCategory
    from .commons.types import AccountGroup
    from .commons.types import AccountSubGroup
    from .commons.types import AccountClassification
    from .commons.types import AccountSub

# Generated at 2022-06-18 02:27:00.981924
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import AccountType, Account
    from .journal import JournalEntry, Posting, Direction
    from .transactions import Transaction
    from .transactions import TransactionType, TransactionStatus
    from .transactions import TransactionLine, TransactionLineType
    from .transactions import TransactionLineStatus, TransactionLineReason
    from .transactions import TransactionLineReasonType
    from .transactions import TransactionLineReasonCategory
    from .transactions import TransactionLineReasonCategoryType
    from .transactions import TransactionLineReasonCategorySubType
    from .transactions import TransactionLineReasonCategorySubTypeType
    from .transactions import TransactionLineReasonCategorySubTypeDetail
    from .transactions import TransactionLineReasonCategorySubTypeDetailType
    from .transactions import TransactionLineReasonCategorySubTypeDetailValue
    from .transactions import Transaction

# Generated at 2022-06-18 02:27:11.406619
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral

# Generated at 2022-06-18 02:27:19.061712
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test Journal Entry", None, [
                    Posting(None, date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ])
            ]


# Generated at 2022-06-18 02:27:28.089812
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return [
            JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=None)
            .post(datetime.date(2020, 1, 1), Account(type=AccountType.ASSETS, name="Cash"), +100)
            .post(datetime.date(2020, 1, 1), Account(type=AccountType.REVENUES, name="Sales"), -100),
        ]

    # Read journal entries:
    journal_entries: Iterable[JournalEntry[None]] = read_journal

# Generated at 2022-06-18 02:27:35.887198
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGrouping
    from .accounts import AccountGroupingType
    from .accounts import AccountTree
    from .accounts import AccountTreeType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeCategoryType
    from .accounts import AccountTypeGroup
    from .accounts import AccountTypeGrouping
    from .accounts import AccountTypeGroupingType
    from .accounts import AccountTypeTree
    from .accounts import AccountTypeTreeType
    from .accounts import AccountTypeType
    from .accounts import AccountingEntity
    from .accounts import AccountingEntityType
    from .accounts import AccountingEntity

# Generated at 2022-06-18 02:27:42.521160
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry reader
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        # Define accounts
        cash = Account("Cash", AccountType.ASSETS)
        revenue = Account("Revenue", AccountType.REVENUES)
        expense = Account("Expense", AccountType.EXPENSES)
        equity = Account("Equity", AccountType.EQUITIES)

        # Define journal entries
        je1 = JournalEntry(datetime.date(2020, 1, 1), "First journal entry", None)
        je1.post(datetime.date(2020, 1, 1), cash, +100)
       

# Generated at 2022-06-18 02:27:47.773546
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", None),
                JournalEntry(date(2020, 1, 2), "Test", None),
                JournalEntry(date(2020, 1, 3), "Test", None),
            ]

    class TestReadJournalEntriesTestCase(TestCase):
        def test_ReadJournalEntries___call__(self):
            read_journal_entries = TestReadJournalEntries

# Generated at 2022-06-18 02:27:53.939915
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[int]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[int]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", 1, [
                    Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("B", AccountType.EQUITIES), Direction.INC, Amount(100)),
                ]),
            ]

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            reader = Test