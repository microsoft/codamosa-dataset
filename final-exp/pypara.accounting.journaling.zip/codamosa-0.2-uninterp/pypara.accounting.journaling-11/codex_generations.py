

# Generated at 2022-06-18 02:19:38.780556
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    book = Book()
    ledger = Ledger(book)

    # Create accounts:
    cash = ledger.create_account(AccountType.ASSETS, "Cash")
    revenue = ledger.create_account(AccountType.REVENUES, "Revenue")
    expense = ledger.create_account(AccountType.EXPENSES, "Expense")

    # Create transactions:
    transaction = Transaction(book, "Test transaction")
    transaction.post(cash, +100)
    transaction.post(revenue, -100)

    # Create journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test journal entry", transaction)

# Generated at 2022-06-18 02:19:48.737867
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    class ReadJournalEntriesTest(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            mock_source = Mock()
            mock_source.__call__.return_value = [
                JournalEntry(date(2020, 1, 1), "", None),
                JournalEntry(date(2020, 1, 2), "", None),
                JournalEntry(date(2020, 1, 3), "", None),
            ]
            read_journal_entries: Callable[[DateRange], Iterable[JournalEntry[None]]] = ReadJournalEntries(mock_source)

            # Act:
            actual

# Generated at 2022-06-18 02:19:57.521437
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:20:05.303982
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    je = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", "Test Source")

    # Post an increment event to an asset account
    je.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))

    # Post a decrement event to an expense account
    je.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry
    je.validate()

    # Check the postings

# Generated at 2022-06-18 02:20:14.296226
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a ledger:
    ledger = Ledger()

    # Define a transaction:
    transaction = Transaction(ledger, "Test Transaction", datetime.date(2020, 1, 1))

    # Define a journal entry:
    journal_entry = JournalEntry[Transaction]()

    # Define a posting:
    posting = Posting[Transaction](journal_entry, datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Direction.INC, Amount(100))

    # Define a read journal entries function:

# Generated at 2022-06-18 02:20:19.761533
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader:

# Generated at 2022-06-18 02:20:26.389649
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .transactions import Transaction

    book = Book()
    book.add_account(Account("Assets:Cash", AccountType.ASSETS))
    book.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    book.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    book.add_account(Account("Income:Salary", AccountType.REVENUES))

    txn = Transaction(book, "Salary")
    txn.post(datetime.date(2020, 1, 1), book.account("Income:Salary"), +100)
    txn.post(datetime.date(2020, 1, 1), book.account("Assets:Cash"), -100)

    txn = Transaction

# Generated at 2022-06-18 02:20:36.080528
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    class Test(TestCase):
        def test_returns_journal_entries_from_the_given_period(self):
            # Arrange:
            period = DateRange(date(2020, 1, 1), date(2020, 1, 31))
            journal_entries = [
                JournalEntry(date(2020, 1, 1), "", None),
                JournalEntry(date(2020, 1, 31), "", None),
            ]

            # Act:
            result = ReadJournalEntries.__call__(lambda p: journal_entries, period)

            # Assert:

# Generated at 2022-06-18 02:20:45.890817
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return [
            JournalEntry(date(2020, 1, 1), "Description", None).post(date(2020, 1, 1), Account("A"), 100),
            JournalEntry(date(2020, 1, 2), "Description", None).post(date(2020, 1, 2), Account("A"), 200),
            JournalEntry(date(2020, 1, 3), "Description", None).post(date(2020, 1, 3), Account("A"), 300),
        ]


# Generated at 2022-06-18 02:20:57.036924
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.accounts import Account, AccountType
    from ..accounts.ledger import Ledger
    from ..accounts.ledger import LedgerEntry
    from ..accounts.ledger import ReadLedgerEntries
    from ..accounts.ledger import ReadLedgerEntry
    from ..accounts.ledger import ReadLedgerEntrySum
    from ..accounts.ledger import ReadLedgerEntrySumByAccount
    from ..accounts.ledger import ReadLedgerEntrySumByAccountType
    from ..accounts.ledger import ReadLedgerEntrySumByDate
    from ..accounts.ledger import ReadLedgerEntrySumByDateRange
    from ..accounts.ledger import ReadLedgerEntrySumByDescription
    from ..accounts.ledger import ReadLedgerEntrySumBySource
    from ..accounts.ledger import ReadLedger

# Generated at 2022-06-18 02:21:07.046569
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest.mock import Mock
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a mock function:
    mock_function: ReadJournalEntries[str] = Mock()
    mock_function.__call__.return_value = [
        JournalEntry(date(2019, 1, 1), "Description", "Source", [
            Posting(None, date(2019, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(100)),
            Posting(None, date(2019, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, Amount(100)),
        ])
    ]

    # Call the mock function:
   

# Generated at 2022-06-18 02:21:19.073662
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date


# Generated at 2022-06-18 02:21:29.814728
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency, CurrencyUnit
    from .ledgers import Ledger, LedgerType
    from .numbers import Amount, Quantity
    from .products import Product
    from .units import Unit

    # Create a business:
    business = Business("Test Business")

    # Create a ledger:
    ledger = Ledger(business, "Test Ledger", LedgerType.CASH)

    # Create accounts:
    account_cash = Account(business, "Cash", AccountType.ASSETS)
    account_sales = Account(business, "Sales", AccountType.REVENUES)
    account_product = Account(business, "Product", AccountType.EXPENSES)

    # Create a product:

# Generated at 2022-06-18 02:21:39.825527
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .transactions import Transaction, TransactionType
    from .transactions.transaction import TransactionSource

    # Define a transaction type:
    class MyTransactionType(TransactionType):
        pass

    # Define a transaction source:
    class MyTransactionSource(TransactionSource):
        pass

    # Define a transaction:
    class MyTransaction(Transaction[MyTransactionSource]):
        pass

    # Define a read journal entries function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[MyTransactionSource]]:
        # Define an account:
        account = Account("Test Account", AccountType.ASSETS)

        # Define a transaction source

# Generated at 2022-06-18 02:21:50.112663
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    ledger = Ledger()

    # Create a transaction type:
    transaction_type = TransactionType(
        name="Purchase",
        category=TransactionTypeCategory.PURCHASE,
        debit_account=ledger.accounts.get(AccountType.EXPENSES),
        credit_account=ledger.accounts.get(AccountType.ASSETS),
    )

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        type=transaction_type,
        description="Purchase of goods",
        amount=Amount(100),
    )

    # Create a journal entry:
   

# Generated at 2022-06-18 02:21:59.266910
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Create a read journal entries function:
    read_journal_entries = ReadJournalEntries()

    # Call the read journal entries function:
    journal_entries = read_journal_entries(DateRange(datetime.date.today(), datetime.date.today()))

    # Check:
    assert journal_entries == [journal_entry]

# Generated at 2022-06-18 02:22:05.960556
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest.mock import Mock
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Setup:
    mock_journal_entry = Mock(JournalEntry)
    mock_journal_entry.postings = [
        Posting(mock_journal_entry, date(2020, 1, 1), Account("A"), Direction.INC, Amount(100)),
        Posting(mock_journal_entry, date(2020, 1, 1), Account("B"), Direction.DEC, Amount(100)),
    ]

    # Exercise:
    mock_read_journal_entries: ReadJournalEntries = Mock()
    mock_read_journal_entries.return_value = [mock_journal_entry]

# Generated at 2022-06-18 02:22:15.504276
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase
    from unittest.mock import Mock
    from .accounts import Account, AccountType

    class _ReadJournalEntries(ReadJournalEntries[str]):
        pass

    def _test(period: DateRange, expected: Iterable[JournalEntry[str]]) -> None:
        actual = _ReadJournalEntries()(period)
        assert actual == expected

    _test(DateRange(date(2019, 1, 1), date(2019, 1, 31)), [])


# Generated at 2022-06-18 02:22:28.059811
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List, Tuple
    from unittest.mock import MagicMock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting

    #: Mock for a journal entry.
    journal_entry = JournalEntry(date(2020, 1, 1), "Description", "Source")

    #: Mock for a posting.
    posting = Posting(journal_entry, date(2020, 1, 1), Account("Account"), Direction.INC, Amount(100))

    #: Mock for a journal entry reader.
    journal_entry_reader = MagicMock(spec=ReadJournalEntries)
    journal_entry_reader.return_value = [journal_entry]

    #: Mock for a posting reader.
    posting_reader = MagicMock

# Generated at 2022-06-18 02:22:38.358487
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post to a ledger account:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get("Assets:Cash"), +100)

    # Post to a ledger account:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get("Expenses:Food"), -100)

    # Post to a ledger account:

# Generated at 2022-06-18 02:22:57.097180
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .business import BusinessType
    from .business import BusinessUnit
    from .business import BusinessUnitType
    from .business import BusinessUnitCategory
    from .business import BusinessUnitCategoryType
    from .business import BusinessUnitCategoryGroup
    from .business import BusinessUnitCategoryGroupType
    from .business import BusinessUnitCategoryGroupSubType
    from .business import BusinessUnitCategoryGroupSubTypeType
    from .business import BusinessUnitCategoryGroupSubTypeSubType
    from .business import BusinessUnitCategoryGroupSubTypeSubTypeType
    from .business import BusinessUnitCategoryGroupSubTypeSubTypeSubType
    from .business import BusinessUnitCategoryGroupSubTypeSubTypeSubTypeType
    from .business import BusinessUnitCategoryGroupSubTypeSubTypeSubTypeSubType
    from .business import BusinessUnitCategoryGroupSubType

# Generated at 2022-06-18 02:23:06.549509
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction
    from .transactions import Transaction

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[Transaction]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[Transaction]):
        pass

    @dataclass(frozen=True)
    class TestTransaction(Transaction):
        pass


# Generated at 2022-06-18 02:23:17.975116
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction
    from datetime import date
    from typing import Iterable
    from unittest import TestCase


# Generated at 2022-06-18 02:23:28.890578
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting, ReadJournalEntries
    from .transactions import Transaction

    @dataclass(frozen=True)
    class JournalEntrySource(Generic[_T]):
        """
        Provides a journal entry source model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:23:37.362154
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal_entry = JournalEntry[str](date=datetime.date(2020, 1, 1), description="Test", source="Test")
    journal_entry.postings.append(Posting(journal_entry, datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Test"), Direction.INC, Amount(Quantity(10))))
    journal_entry.postings.append(Posting(journal_entry, datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Test"), Direction.DEC, Amount(Quantity(10))))
    journal_entry.validate()


# Generated at 2022-06-18 02:23:46.475582
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a function which reads journal entries from a source.
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        # Create a journal entry.
        journal_entry = JournalEntry(date(2020, 1, 1), "Test Journal Entry", None)

        # Create a posting.
        posting = Posting(journal_entry, date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Direction.INC, 100)

        # Return the journal entry.
        return [journal_entry]

    # Create a read journal entries function.
    read_journal_entries_function

# Generated at 2022-06-18 02:23:55.280573
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .journal_entries import JournalEntry, Posting, Direction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(ledger, "Test Transaction", "Test Transaction")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post an amount to an account
    journal_entry.post(datetime.date(2020, 1, 1), Account(ledger, "Test Account", AccountType.ASSETS), Quantity(100))

    # Check the postings

# Generated at 2022-06-18 02:24:02.766544
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons import Currency
    from .journal import JournalEntry, Posting
    from .ledger import Ledger

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test journal entry", None)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), 100)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), -100)

    # Validate the journal entry:
    journal.validate()

    # Create a ledger entry:
    ledger.post(journal)

    # Validate the ledger entry:
    ledger.validate()

# Generated at 2022-06-18 02:24:11.941761
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Setup:
    mock = Mock(spec=ReadJournalEntries)
    mock.__call__.return_value = [JournalEntry(date(2020, 1, 1), "", None)]

    # Exercise:
    actual = mock(DateRange(date(2020, 1, 1), date(2020, 1, 1)))

    # Verify:
    assert actual == [JournalEntry(date(2020, 1, 1), "", None)]

# Generated at 2022-06-18 02:24:14.214610
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account

    j = JournalEntry(datetime.date.today(), "Test", None)
    j.post(datetime.date.today(), Account("A"), Quantity(100))
    j.post(datetime.date.today(), Account("B"), Quantity(-100))
    j.validate()

# Generated at 2022-06-18 02:24:43.863237
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        pass

    assert issubclass(read_journal_entries.__class__, ReadJournalEntries)

# Generated at 2022-06-18 02:24:50.727858
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .business import Business
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity

    # Create a business
    business = Business("My Business")

    # Create a ledger
    ledger = Ledger("My Ledger")

    # Create a book
    book = Book("My Book", ledger)

    # Create a transaction
    transaction = Transaction("My Transaction")

    # Create an event
    event = Event("My Event", transaction)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date.today(), "My Journal Entry", event)

    # Create an account
    account = Account("My Account", AccountType.ASSETS)

    # Post to the

# Generated at 2022-06-18 02:24:58.707162
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import TestCase, mock

    class MockReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            pass

    with mock.patch.object(MockReadJournalEntries, "__call__") as mock_call:
        mock_call.return_value = [JournalEntry(datetime.date(2020, 1, 1), "", "")]
        assert list(MockReadJournalEntries()(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))) == [
            JournalEntry(datetime.date(2020, 1, 1), "", "")
        ]



# Generated at 2022-06-18 02:25:05.357809
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass
    class TestSource:
        pass

    @dataclass
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    @dataclass
    class TestPosting(Posting[TestSource]):
        pass

    @dataclass
    class TestReadJournalEntries(ReadJournalEntries[TestSource]):
        journal_entries: List[TestJournalEntry]


# Generated at 2022-06-18 02:25:16.484969
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class Source:
        pass

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        date: datetime.date
        description: str
        source: _T
        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        guid: Guid = field(default_factory=makeguid, init=False)

        def post(self, date: datetime.date, account: Account, quantity: Quantity) -> "JournalEntry[_T]":
            if not quantity.is_zero():
                self.postings.append

# Generated at 2022-06-18 02:25:21.717570
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("A", AccountType.ASSETS))
    ledger.add_account(Account("B", AccountType.ASSETS))
    ledger.add_account(Account("C", AccountType.ASSETS))
    ledger.add_account(Account("D", AccountType.ASSETS))
    ledger.add_account(Account("E", AccountType.ASSETS))
    ledger.add_account(Account("F", AccountType.ASSETS))
    ledger.add_account(Account("G", AccountType.ASSETS))
    ledger.add_account(Account("H", AccountType.ASSETS))

# Generated at 2022-06-18 02:25:31.450180
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger

    # Create a ledger
    ledger = Ledger()

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post to the ledger

# Generated at 2022-06-18 02:25:40.137055
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry1(JournalEntry):
        pass

    # Define a function to read journal entries:

# Generated at 2022-06-18 02:25:46.682102
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import asdict
    from typing import NamedTuple
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting

    class Source(NamedTuple):
        pass


# Generated at 2022-06-18 02:25:56.243721
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase

    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            def make_journal_entry(date: date, description: str, source: str, postings: List[Tuple[Account, int]]) -> JournalEntry[str]:
                journal_entry = JournalEntry[str](date, description, source)
                for account, amount in postings:
                    journal_entry.post(date, account, amount)
                return journal_entry

            def make_account(type: AccountType, code: str, name: str) -> Account:
                return Account(type, code, name)


# Generated at 2022-06-18 02:26:43.008297
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:26:49.705633
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_returns_empty_list_when_no_journal_entries_exist(self):
            # Arrange:
            journal_entries: List[JournalEntry[str]] = []
            read_journal_entries = lambda period: journal_entries

            # Act:
            actual = read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

            # Assert:
            self.assertEqual([], actual)

        def test_returns_journal_entries_when_they_exist(self):
            # Arrange:
            journal_

# Generated at 2022-06-18 02:26:57.702609
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main
    from unittest.mock import Mock, patch

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:27:07.625977
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:27:16.979222
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date

    # Create a journal entry
    journal = JournalEntry[str](date(2020, 1, 1), "Test journal entry", "Test source")

    # Create an account
    account = Account("Test account", AccountType.ASSETS)

    # Post a positive amount to the account
    journal.post(date(2020, 1, 1), account, Quantity(100))

    # Check the postings
    assert len(journal.postings) == 1
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == date(2020, 1, 1)

# Generated at 2022-06-18 02:27:26.128390
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType

    # Create a ledger
    ledger = Ledger()

    # Create a business
    business = Business(name="Test Business")

    # Create a transaction type
    transaction_type = TransactionType(
        name="Test Transaction Type",
        category=TransactionTypeCategory(
            name="Test Transaction Type Category",
            type=TransactionTypeCategoryType.EXPENSE,
        ),
        type=TransactionTypeType.EXPENSE,
    )

    # Create a transaction

# Generated at 2022-06-18 02:27:33.889640
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from datetime import date
    from dataclasses import dataclass, field
    from typing import List, TypeVar
    _T = TypeVar("_T")
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """
        #: Date of the entry.
        date: datetime.date
        #: Description of the entry.
        description: str
        #: Business object as the source of the journal entry.
        source: _T
        #: Postings of the journal entry.

# Generated at 2022-06-18 02:27:42.417610
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book(
        name="Test Book",
        currency=Currency("USD"),
        ledger=Ledger(
            name="Test Ledger",
            accounts=[
                Account(name="Cash", type=AccountType.ASSETS),
                Account(name="Revenues", type=AccountType.REVENUES),
                Account(name="Expenses", type=AccountType.EXPENSES),
            ],
        ),
    )

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=None,
    )

    #

# Generated at 2022-06-18 02:27:50.306813
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory

# Generated at 2022-06-18 02:27:59.429953
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a debit
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Post a credit
    journal.post(datetime.date(2020, 1, 1), account, Quantity(-100))

    # Check the postings
    assert len(journal.postings) == 2
    assert journal.postings[0].direction == Direction.INC