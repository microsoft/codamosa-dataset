

# Generated at 2022-06-18 02:19:33.128277
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntry:
        date: date
        description: str

    @dataclass(frozen=True)
    class ReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return [JournalEntry(date(2020, 1, 1), "Description 1"), JournalEntry(date(2020, 1, 2), "Description 2")]

    read_journal_entries = ReadJournalEntries()
    assert len(list(read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 2))))) == 2

# Generated at 2022-06-18 02:19:44.058017
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency, CurrencyUnit
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book(
        "Test Book",
        Currency(CurrencyUnit.USD),
        [
            Ledger(Account("Assets", AccountType.ASSETS)),
            Ledger(Account("Equities", AccountType.EQUITIES)),
            Ledger(Account("Liabilities", AccountType.LIABILITIES)),
            Ledger(Account("Revenues", AccountType.REVENUES)),
            Ledger(Account("Expenses", AccountType.EXPENSES)),
        ],
    )

    # Create a transaction:
    transaction = Transaction(book, "Test Transaction")

    # Create a journal entry:
    journal_

# Generated at 2022-06-18 02:19:52.338760
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post to the account
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Check the posting
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account == account

# Generated at 2022-06-18 02:20:03.217830
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a transaction
    transaction = Transaction(book, "Test Transaction")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Create an account
    account = Account(AccountType.ASSETS, "Test Account")

    # Post an amount to the account
    journal_entry.post(datetime.date(2020, 1, 1), account, 100)

    # Validate the journal entry
    journal_entry.validate()

    # Create another journal entry
    journal_entry = Journal

# Generated at 2022-06-18 02:20:12.743434
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry:
    je = JournalEntry(datetime.date(2019, 1, 1), "Test", None)

    # Define an account:
    account = Account("Test", AccountType.ASSETS)

    # Post a debit:
    je.post(datetime.date(2019, 1, 1), account, +100)

    # Post a credit:
    je.post(datetime.date(2019, 1, 1), account, -100)

    # Validate the journal entry:
    je.validate()

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return

# Generated at 2022-06-18 02:20:23.020020
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.accounts import Account, AccountType
    from ..books.ledgers import Ledger
    from ..books.transactions import Transaction
    from ..books.transactions import TransactionType
    from ..books.transactions import TransactionPosting
    from ..books.transactions import TransactionPostingType
    from ..books.transactions import TransactionPostingRule
    from ..books.transactions import TransactionPostingRuleType
    from ..books.transactions import TransactionPostingRuleMatch
    from ..books.transactions import TransactionPostingRuleMatchType
    from ..books.transactions import TransactionPostingRuleMatchValue
    from ..books.transactions import TransactionPostingRuleMatchValueType
    from ..books.transactions import TransactionPostingRuleMatchValueData
    from ..books.transactions import TransactionPostingRuleMatchValueDataType
    from ..books.transactions import Transaction

# Generated at 2022-06-18 02:20:34.432504
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:20:44.798864
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date
    je = JournalEntry[str](date.today(), "Test", "Test")
    je.post(date.today(), Account("Test", AccountType.ASSETS), Quantity(100))
    assert len(je.postings) == 1
    assert je.postings[0].amount == Quantity(100)
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].is_debit == True
    assert je.postings[0].is_credit == False
    je.post(date.today(), Account("Test", AccountType.ASSETS), Quantity(-100))
    assert len(je.postings) == 2

# Generated at 2022-06-18 02:20:56.521114
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .exchanges import Exchange
    from .ledgers import Ledger
    from .markets import Market
    from .products import Product
    from .transactions import Transaction
    from .trades import Trade

    # Create a business:
    business = Business(
        name="Test Business",
        currency=Currency.USD,
        ledger=Ledger(
            name="Test Ledger",
            market=Market(
                name="Test Market",
                exchange=Exchange(name="Test Exchange"),
            ),
        ),
    )

    # Create a product:
    product = Product(
        name="Test Product",
        business=business,
    )

    # Create a transaction:

# Generated at 2022-06-18 02:21:04.329672
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(TransactionType.SALE, "Sale of goods")

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Sale of goods")

    # Post to the journal entry:
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), +100)

# Generated at 2022-06-18 02:21:21.515836
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield JournalEntry(date(2020, 1, 1), "Entry 1", "Source 1", [
            Posting(None, date(2020, 1, 1), Account("A1", AccountType.ASSETS), Direction.INC, Amount(100)),
            Posting(None, date(2020, 1, 1), Account("A2", AccountType.ASSETS), Direction.DEC, Amount(100)),
        ])

    # Test:
    assert isinstance(read_journal_entries, ReadJournalEntries)

# Generated at 2022-06-18 02:21:26.487827
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .ledgers import Ledger
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
    from .ledgers import LedgerType
   

# Generated at 2022-06-18 02:21:34.196921
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[str]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[str]):
        pass


# Generated at 2022-06-18 02:21:42.173814
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a business:
    business = Business(ledger, "My Business")

    # Create a transaction:
    transaction = Transaction(ledger, "My Transaction", business)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "My Journal Entry", transaction)

    # Post some amounts:
    journal_entry.post(datetime.date(2020, 1, 1), Account(ledger, "My Account", AccountType.ASSETS), +100)

# Generated at 2022-06-18 02:21:53.080687
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.accounts import Account, AccountType
    from ..books.ledgers import Ledger
    from ..books.transactions import Transaction
    from ..books.transactions.transaction import TransactionType

    # Define a ledger:
    ledger = Ledger()

    # Define accounts:
    ledger.add_account(Account(AccountType.ASSETS, "Cash"))
    ledger.add_account(Account(AccountType.ASSETS, "Accounts Receivable"))
    ledger.add_account(Account(AccountType.ASSETS, "Inventory"))
    ledger.add_account(Account(AccountType.ASSETS, "Prepaid Expenses"))
    ledger.add_account(Account(AccountType.ASSETS, "Fixed Assets"))
    ledger.add_account(Account(AccountType.ASSETS, "Accumulated Depreciation"))

# Generated at 2022-06-18 02:22:02.328082
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:22:07.394768
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons.zeitgeist import DateRange
    from datetime import date
    from .commons.others import makeguid
    from .commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons.others import makeguid
    from .commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons.others import makeguid
    from .commons.zeitgeist import DateRange

# Generated at 2022-06-18 02:22:16.090409
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeTypeCategory
    from .transactions import TransactionTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeTypeTypeCategoryType
    from .transactions import TransactionTypeTypeTypeTypeTypeTypeCategory
    from .transactions import TransactionTypeTypeTypeTypeType

# Generated at 2022-06-18 02:22:28.374825
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import mock
    from unittest.mock import Mock
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a mock function:

# Generated at 2022-06-18 02:22:38.402024
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries


# Generated at 2022-06-18 02:22:58.133428
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    business = Business("Test Business")
    transaction = Transaction(business, ledger)
    transaction.post(datetime.date(2020, 1, 1), ledger.get_account("Assets"), +100)

# Generated at 2022-06-18 02:23:06.679167
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from . import journals

    # Define a ledger:
    ledger = Ledger()

    # Define a book:
    book = Book(ledger)

    # Define a transaction:
    transaction = Transaction(book)

    # Define an event:
    event = Event(transaction)

    # Define a journal entry:
    journal_entry = JournalEntry[Event]()

    # Define a journal entry reader:

# Generated at 2022-06-18 02:23:16.849303
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))

    txn = Transaction(ledger, "Buy food", datetime.date(2020, 1, 1))
    txn.post(ledger.accounts["Assets:Cash"], -100)
    txn.post(ledger.accounts["Expenses:Food"], 100)

    journal_entry = txn.journal_entry()
    journal_entry.validate()

# Generated at 2022-06-18 02:23:28.011973
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[TestSource]):
        pass


# Generated at 2022-06-18 02:23:36.413064
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a read journal entries function:

# Generated at 2022-06-18 02:23:42.561092
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .transactions import Transaction

    @dataclass(frozen=True)
    class MockJournalEntry(JournalEntry[Transaction]):
        pass

    @dataclass(frozen=True)
    class MockPosting(Posting[Transaction]):
        pass

    @dataclass(frozen=True)
    class MockTransaction(Transaction):
        pass


# Generated at 2022-06-18 02:23:47.895965
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountGroup
    from .accounts import AccountGroupType, AccountGrouping
    from .accounts import AccountGroupingType, AccountGroupingTree
    from .accounts import AccountGroupingTreeNode, AccountGroupingTreeLeaf
    from .accounts import AccountGroupingTreeBranch
    from .accounts import AccountGroupingTreeRoot

    # Create an account grouping tree
    root = AccountGroupingTreeRoot()
    root.add_node(AccountGroupingTreeBranch(AccountGrouping(AccountGroupingType.ASSETS, "Assets")))
    root.add_node(AccountGroupingTreeBranch(AccountGrouping(AccountGroupingType.LIABILITIES, "Liabilities")))

# Generated at 2022-06-18 02:23:56.416088
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .journals import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .journals import JournalEntry, ReadJournalEntries

    # Create a ledger:
    ledger = Ledger()

    # Create a book:
    book = Book(ledger)

    # Create a transaction:
    transaction = Transaction(book, "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    #

# Generated at 2022-06-18 02:24:00.632803
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", None)
    journal_entry.post(datetime.date.today(), Account("Test Account", AccountType.ASSETS), Quantity(100))
    journal_entry.post(datetime.date.today(), Account("Test Account", AccountType.EXPENSES), Quantity(-100))

    # Act
    journal_entry.validate()

    # Assert
    assert True

# Generated at 2022-06-18 02:24:07.205913
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .ledgers import Ledger
    from .markets import Market
    from .parties import Party
    from .products import Product
    from .units import Unit
    from .utils import make_book, make_ledger, make_market, make_party, make_product, make_unit
    from .utils import make_journal_entry

    # Create a book:

# Generated at 2022-06-18 02:24:35.656274
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryFactory
    from .accounts import AccountRepositoryInMemoryFactoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImplFactory
    from .accounts import AccountRepositoryInMemoryImplFactoryImpl
    from .accounts import AccountRepositoryInMemoryImplFactoryImplFactory
    from .accounts import AccountRepositoryInMemoryImplFactoryImplFactoryImpl
    from .accounts import AccountRepositoryInMemoryImplFactoryImplFactoryImplFactory
    from .accounts import AccountRepositoryInMemoryImplFactoryImplFactoryImplFactoryImpl
    from .accounts import AccountRepositoryInMemoryImplFactoryImplFactoryImplFactoryImplFactory
    from .accounts import Account

# Generated at 2022-06-18 02:24:45.845790
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction type:
    transaction_type = TransactionType("SALE", "Sale", "Sale of goods")

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Sale of goods",
        type=transaction_type,
    )

    # Create an account:
    account = Account("SALES", "Sales", AccountType.REVENUES)

    # Create a journal entry:

# Generated at 2022-06-18 02:24:55.772054
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountTree
    from .accounts import AccountTreeNode
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeType
   

# Generated at 2022-06-18 02:25:05.787147
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    business = Business(ledger)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", business)
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), 100)
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), -100)

    # Validate the journal entry
    journal_entry.validate()

    # Create a journal entry with a different amount

# Generated at 2022-06-18 02:25:17.122926
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeCategoryTypeType
    from .transactions import TransactionTypeCategoryTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeTypeType
    from .transactions import Transaction

# Generated at 2022-06-18 02:25:27.568982
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .transactions import Transaction

    # Create a journal entry
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test", source=Transaction(makeguid()))

    # Post an amount to an account
    journal_entry.post(date=datetime.date(2020, 1, 1), account=Account(makeguid(), "Test", AccountType.ASSETS), quantity=Quantity(100))

    # Check if the posting is added to the journal entry
    assert len(journal_entry.postings) == 1

# Generated at 2022-06-18 02:25:36.110388
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .transactions import Transaction
    from .ledgers import Ledger
    from .books import Book
    from .accountants import Accountant
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .journal import JournalEntry, Direction
    from .commons.others import Guid
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .transactions import Transaction
    from .ledgers import Ledger
    from .books import Book
    from .accountants import Accountant
    from .journal import JournalEntry, Direction

# Generated at 2022-06-18 02:25:44.675235
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:25:55.495378
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .ledger import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry")

    # Create a transaction
    transaction = Transaction(datetime.date(2020, 1, 1), "Test Transaction")

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post to the journal entry
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Post to the transaction

# Generated at 2022-06-18 02:26:06.224562
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:27:08.234247
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries


# Generated at 2022-06-18 02:27:17.401884
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:27:26.571138
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:27:34.202976
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons import Currency
    from .journal import JournalEntry, Posting

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Create accounts
    account1 = Account("Account 1", AccountType.ASSETS, Currency.USD)
    account2 = Account("Account 2", AccountType.EXPENSES, Currency.USD)

    # Post to the journal entry
    journal.post(datetime.date(2020, 1, 1), account1, 100)
    journal.post(datetime.date(2020, 1, 1), account2, -100)

    # Check postings
    assert len(journal.postings) == 2

# Generated at 2022-06-18 02:27:43.361151
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a book:
    book = Book(
        name="Test Book",
        ledger=Ledger(
            name="Test Ledger",
            accounts=[
                Account(name="Assets", type=AccountType.ASSETS),
                Account(name="Equities", type=AccountType.EQUITIES),
                Account(name="Liabilities", type=AccountType.LIABILITIES),
                Account(name="Revenues", type=AccountType.REVENUES),
                Account(name="Expenses", type=AccountType.EXPENSES),
            ],
        ),
    )

    # Define a

# Generated at 2022-06-18 02:27:48.651557
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger, LedgerEntry
    from .transactions import Transaction, TransactionEntry

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        entries=[
            TransactionEntry(account=ledger.accounts.get(AccountType.ASSETS, "Cash"), quantity=+100),
            TransactionEntry(account=ledger.accounts.get(AccountType.EXPENSES, "Expenses"), quantity=-100),
        ],
    )

    # Post the transaction to the ledger:
    ledger.post(transaction)

   

# Generated at 2022-06-18 02:27:54.424957
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .tags import Tag
    from .business import Business
    from .business import BusinessType
    from .business import BusinessTag
    from .business import BusinessAccount
    from .business import BusinessCurrency
    from .business import BusinessCurrencyAccount
    from .business import BusinessCurrencyAccountTag
    from .business import BusinessCurrencyAccountTagAmount
    from .business import BusinessCurrencyAccountTagAmountDirection
    from .business import BusinessCurrencyAccountTagAmountDirectionDate
    from .business import BusinessCurrencyAccountTagAmountDirectionDateDescription
    from .business import BusinessCurrencyAccountTagAmountDirectionDateDescriptionJournalEntry
    from .business import BusinessCurrencyAccountTagAmountDirectionDateDescriptionJournalEntryPosting
    from .business import BusinessCurrencyAccountTagAmountDirectionDateDescriptionJournalEntry

# Generated at 2022-06-18 02:28:04.050839
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountSubCategory
    from .accounts import AccountGroup
    from .accounts import AccountSubGroup
    from .accounts import AccountClass
    from .accounts import AccountSubClass

    # Create an account
    account = Account(AccountType.ASSETS, AccountCategory.CURRENT, AccountSubCategory.CASH, AccountGroup.CASH, AccountSubGroup.CASH, AccountClass.CASH, AccountSubClass.CASH, "Cash", "Cash")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Cash", "Cash")

    # Post a debit
    journal_entry.post(datetime.date(2020, 1, 1), account, 100)



# Generated at 2022-06-18 02:28:09.152548
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    ## Setup:
    ledger = Ledger("Test Ledger", Currency.USD)
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    ## Test:
    txn = Transaction(ledger, "Test Transaction", datetime.date(2020, 1, 1))

# Generated at 2022-06-18 02:28:17.007797
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase, main

    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    @dataclass_json
    @dataclass(frozen=True)
    class Transaction:
        guid: str = field(default_factory=makeguid)
