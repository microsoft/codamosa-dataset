

# Generated at 2022-06-18 02:19:36.633242
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry
    from .ledger import Ledger
    from .ledger import LedgerEntry
    from .ledger import LedgerEntryType
    from .ledger import ReadLedgerEntries
    from .ledger import ReadLedgerEntry
    from .ledger import ReadLedgerEntryType
    from .ledger import ReadLedger
    from .ledger import ReadLedgerAccounts
    from .ledger import ReadLedgerAccount
    from .ledger import ReadLedgerAccountType
    from .ledger import ReadLedgerAccountTypes
    from .ledger import ReadLedgerAccountsByType
    from .ledger import ReadLedgerAccountsByTypes
    from .ledger import ReadLedgerAccountsByParent

# Generated at 2022-06-18 02:19:47.579833
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from typing import List
    from dataclasses import field, dataclass, asdict

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: str

        #: Postings of the journal entry.
        postings: List[Posting] = field(default_factory=list, init=False)

       

# Generated at 2022-06-18 02:19:54.058733
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", Transaction())

# Generated at 2022-06-18 02:20:03.421182
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    # Create a journal entry
    journal_entry = JournalEntry[str]("2020-01-01", "Test Journal Entry", "Test Source")

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post a quantity to the account
    journal_entry.post("2020-01-01", account, Quantity(100))

    # Validate the journal entry
    journal_entry.validate()

    # Check the postings
    assert journal_entry.postings[0].date == "2020-01-01"
    assert journal_entry.postings[0].account == account
    assert journal_entry.postings[0].direction == Direction.INC
    assert journal_

# Generated at 2022-06-18 02:20:12.836222
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    ## Setup:
    ledger = Ledger("Test Ledger", Currency("USD"))
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))

    ## Test:
    transaction = Transaction(ledger, "Test Transaction", DateRange.from_date(datetime.date(2020, 1, 1)))
    transaction.post(datetime.date(2020, 1, 1), ledger.get_account("Assets:Cash"), +100)

# Generated at 2022-06-18 02:20:18.775613
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.transactions import TransactionType

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Rent", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Salary", AccountType.REVENUES))

    transaction = Transaction(TransactionType.EXPENSE, datetime.date(2020, 1, 1), "Salary")
    transaction.post(ledger.get_account("Revenues:Salary"), 100)

# Generated at 2022-06-18 02:20:25.563963
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity

    # Create a journal entry
    journal_entry = JournalEntry[int](date(2020, 1, 1), "Test", 1)

    # Create a list of postings
    postings: List[Posting[int]] = []

    # Post an amount to an account
    journal_entry.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(Decimal(10)))

    # Check if the posting is added to the list of postings
    assert journal_entry.postings == postings

# Generated at 2022-06-18 02:20:35.525010
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test"

    #: Business object as the source of the journal entry.
    source = "Test"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.

# Generated at 2022-06-18 02:20:45.588148
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .journal_entries import JournalEntry, Posting, ReadJournalEntries

    # Define a ledger:
    ledger = Ledger()

    # Define accounts:
    cash = ledger.add_account(Account(AccountType.ASSETS, "Cash"))
    revenue = ledger.add_account(Account(AccountType.REVENUES, "Revenue"))
    expense = ledger.add_account(Account(AccountType.EXPENSES, "Expense"))

    # Define journal entries:

# Generated at 2022-06-18 02:20:56.843794
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create accounts:
    assets = ledger.create_account(AccountType.ASSETS, "Assets")
    liabilities = ledger.create_account(AccountType.LIABILITIES, "Liabilities")
    revenues = ledger.create_account(AccountType.REVENUES, "Revenues")
    expenses = ledger.create_account(AccountType.EXPENSES, "Expenses")

    # Create a transaction:
    transaction = Transaction(book, "Test Transaction")

    # Post to the transaction:

# Generated at 2022-06-18 02:21:07.047924
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    # Create a book:
    book = Book()
    book.create_account(Account("Assets", AccountType.ASSETS))
    book.create_account(Account("Liabilities", AccountType.LIABILITIES))
    book.create_account(Account("Equities", AccountType.EQUITIES))
    book.create_account(Account("Revenues", AccountType.REVENUES))
    book.create_account(Account("Expenses", AccountType.EXPENSES))

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction type:

# Generated at 2022-06-18 02:21:19.074726
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestJournalEntry(JournalEntry):
        def __init__(self, date: date, description: str, source: str, postings: List[Posting]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:21:29.814758
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry1(JournalEntry):
        pass

    # Define a journal entry reader:

# Generated at 2022-06-18 02:21:39.825526
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from datetime import date

    # Create a journal entry
    je = JournalEntry[int](date(2020, 1, 1), "Test", 1)

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post an amount to the account
    je.post(date(2020, 1, 1), account, Quantity(100))

    # Check if the posting is in the journal entry
    assert len(je.postings) == 1
    assert je.postings[0].date == date(2020, 1, 1)
    assert je.postings[0].account == account
    assert je.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:21:50.158678
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .writers import write_journal_entries

    # Create a ledger:
    ledger = Ledger()

    # Create accounts:
    ledger.create_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.create_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.create_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.create_account(Account("Revenues:Sales", AccountType.REVENUES))

    # Create journal entries:

# Generated at 2022-06-18 02:21:54.892901
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .events import EventType
    from .events import EventCategory
    from .events import EventSubCategory
    from .events import EventType
    from .events import EventCategory
    from .events import EventSubCategory
    from .events import EventType
    from .events import EventCategory
    from .events import EventSubCategory
    from .events import EventType
    from .events import EventCategory
    from .events import EventSubCategory
    from .events import EventType
    from .events import EventCategory
    from .events import EventSubCategory
    from .events import EventType
    from .events import EventCategory
    from .events import EventSubCategory
    from .events import EventType

# Generated at 2022-06-18 02:22:03.617058
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.accounts import AccountType
    from ..accounts.accounts import Account
    from ..accounts.accounts import AccountRepository
    from ..accounts.accounts import AccountRepositoryInMemory
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl
    from ..accounts.accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:22:14.687909
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account(AccountType.ASSETS, "Cash"))
    ledger.add_account(Account(AccountType.EXPENSES, "Rent"))
    ledger.add_account(Account(AccountType.REVENUES, "Sales"))

    txn = Transaction(ledger, "Sale of goods")
    txn.post(ledger.get_account("Cash"), Quantity(100))
    txn.post(ledger.get_account("Sales"), Quantity(-100))

    jrn = JournalEntry(datetime.date(2020, 1, 1), "Sale of goods", txn)
   

# Generated at 2022-06-18 02:22:27.274360
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=None,
    )

    # Post to ledger:
    ledger.post(transaction)

    # Create a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=None,
    )



# Generated at 2022-06-18 02:22:34.555076
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    ledger = Ledger()
    ledger.add_account(Account("Cash", AccountType.ASSETS))
    ledger.add_account(Account("Sales", AccountType.REVENUES))
    ledger.add_account(Account("Tax", AccountType.EXPENSES))
    ledger.add_account(Account("Inventory", AccountType.ASSETS))
    ledger.add_account(Account("Cost of Goods Sold", AccountType.EXPENSES))

    transaction_type = TransactionType("Sales", TransactionTypeCategory.SALES)
    transaction = Transaction(transaction_type, datetime.date(2020, 1, 1))

# Generated at 2022-06-18 02:22:54.654616
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class BusinessObject:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[BusinessObject]):
        pass

    @dataclass(frozen=True)
    class Posting(Posting[BusinessObject]):
        pass

    @dataclass(frozen=True)
    class ReadJournalEntries(ReadJournalEntries[BusinessObject]):
        pass

    def test_JournalEntry_post():
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the