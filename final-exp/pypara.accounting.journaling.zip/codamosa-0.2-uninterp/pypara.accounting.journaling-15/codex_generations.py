

# Generated at 2022-06-18 02:19:34.586165
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountGroup
    from .accounts import AccountGroupType, AccountGrouping
    from .accounts import AccountGroupingType, AccountGroupingRule
    from .accounts import AccountGroupingRuleType, AccountGroupingRuleCondition
    from .accounts import AccountGroupingRuleConditionType, AccountGroupingRuleConditionOperator
    from .accounts import AccountGroupingRuleConditionOperatorType, AccountGroupingRuleConditionOperand
    from .accounts import AccountGroupingRuleConditionOperandType, AccountGroupingRuleConditionOperandValue
    from .accounts import AccountGroupingRuleConditionOperandValueType, AccountGroupingRuleConditionOperandValue
    from .accounts import AccountGroupingRuleConditionOperandValueType, AccountGroupingRuleConditionOperandValue
    from .accounts import AccountGroupingRuleConditionOperandValueType, AccountGrouping

# Generated at 2022-06-18 02:19:45.785942
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons.zeitgeist import DateRange
    from datetime import date

    # Test 1:
    # Create a journal entry
    je = JournalEntry[int](date(2020, 1, 1), "Test", 1)
    # Post an increment event to an account
    je.post(date(2020, 1, 1), Account("A", AccountType.ASSETS), Quantity(10))
    # Post a decrement event to an account
    je.post(date(2020, 1, 1), Account("A", AccountType.EXPENSES), Quantity(-10))
    # Validate the journal entry
    je.validate()
    # Check the postings of the journal entry

# Generated at 2022-06-18 02:19:49.623181
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    ## Create a ledger:
    ledger = Ledger(Currency.USD)

    ## Create a business:
    business = Business(ledger, "Test Business")

    ## Create a transaction:
    transaction = Transaction(business, datetime.date(2020, 1, 1), "Test Transaction")

    ## Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    ## Create accounts:
    account_assets = Account(ledger, AccountType.ASSETS, "Test Account Assets")
    account_equities = Account(ledger, AccountType.EQUITIES, "Test Account Equities")

# Generated at 2022-06-18 02:19:58.215296
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a function which reads journal entries from a source.
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        # Define a journal entry.
        journal_entry = JournalEntry(date(2020, 1, 1), "Test Journal Entry", None)

        # Define a posting.
        posting = Posting(journal_entry, date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Direction.INC, 100)

        # Return the journal entry.
        return [journal_entry]

    # Define a function which reads journal entries

# Generated at 2022-06-18 02:20:08.489916
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger

    # Create a ledger
    ledger = Ledger()

    # Create an account
    account = Account(makeguid(), "Account", AccountType.ASSETS)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Description", ledger)

    # Post a debit
    journal_entry.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Post a credit
    journal_entry.post(datetime.date(2020, 1, 1), account, Quantity(-100))

    # Validate the journal entry
    journal

# Generated at 2022-06-18 02:20:20.413630
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry

    # Setup
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Exercise
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), Quantity(-100))

    # Verify
    assert journal.postings[0].amount == Amount(100)
    assert journal.postings[1].amount == Amount(100)

    # Teardown - none



# Generated at 2022-06-18 02:20:31.270695
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class _ReadJournalEntries(ReadJournalEntries[_T]):
        pass

    class _TestCase(TestCase):
        def test_ReadJournalEntries___call__(self):
            read_journal_entries: ReadJournalEntries[_T] = _ReadJournalEntries()
            read_journal_entries.__call__ = Mock(return_value=Iterable[JournalEntry[_T]])
            read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

# Generated at 2022-06-18 02:20:39.554147
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger, LedgerType
    from .transactions import Transaction, TransactionType

    # Define a ledger:
    ledger = Ledger(
        name="Test Ledger",
        type=LedgerType.ASSETS,
        accounts=[
            Account(name="Cash", type=AccountType.ASSETS),
            Account(name="Equity", type=AccountType.EQUITIES),
            Account(name="Revenue", type=AccountType.REVENUES),
            Account(name="Expense", type=AccountType.EXPENSES),
        ],
    )

    # Define a transaction:

# Generated at 2022-06-18 02:20:48.343199
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import ReadAccounts
    from .accounts import read_accounts
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import ReadAccounts
    from .accounts import read_accounts
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import ReadAccounts
    from .accounts import read_accounts
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import ReadAccounts
    from .accounts import read_accounts
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import ReadAccounts
    from .accounts import read_accounts
    from .accounts import Account
   

# Generated at 2022-06-18 02:20:57.925214
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.accounts import Account
    from ..accounts.accounts import AccountType
    from ..accounts.accounts import AccountTree
    from ..accounts.accounts import AccountTreeNode
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTreeNodeType
    from ..accounts.accounts import AccountTree

# Generated at 2022-06-18 02:21:14.415728
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .entities import Entity
    from .events import Event
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a book:
    book = Book()

    # Define an entity:
    entity = Entity(book, "Test Entity")

    # Define a ledger:
    ledger = Ledger(book, "Test Ledger", entity)

    # Define a transaction:
    transaction = Transaction(book, "Test Transaction", ledger)

    # Define an event:
    event = Event(book, "Test Event", transaction)

    # Define an account:
    account = Account(book, "Test Account", AccountType.ASSETS)

    # Define a journal entry:

# Generated at 2022-06-18 02:21:25.807134
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    class JournalEntry:
        def __init__(self, date: date, description: str, source: object, postings: List[Posting]):
            self.date = date
            self.description = description
            self.source = source
            self.postings = postings
            self.guid = makeguid()

    class Posting:
        def __init__(self, journal: JournalEntry, date: date, account: Account, direction: Direction, amount: Amount):
            self.journal = journal
            self.date = date
            self.account = account
            self.direction = direction
            self.amount = amount


# Generated at 2022-06-18 02:21:33.818319
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import ReadLedger

    ledger = Ledger(ReadLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))))
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), +100)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), -100)
    journal.validate()
    ledger.post(journal)

# Generated at 2022-06-18 02:21:41.961165
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Date of the entry.
    date: datetime.date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description: str = "Test"

    #: Business object as the source of the journal entry.
    source: _T = "Test"

    #: Postings of the journal entry.
    postings: List[Posting[_T]] = field(default_factory=list, init=False)

    #: Globally unique, ephemeral identifier.
    guid: Guid = field(default_factory=makeguid, init=False)

    #: Journal entry the posting belongs to.
    journal: "JournalEntry[_T]"



# Generated at 2022-06-18 02:21:52.823197
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_with_no_journal_entries(self):
            # Arrange:
            journal_entries: List[JournalEntry[str]] = []
            read_journal_entries = Mock(return_value=journal_entries)

            # Act:
            result = read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

            # Assert:
            self.assertEqual(journal_entries, result)


# Generated at 2022-06-18 02:22:02.170825
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    ledger = Ledger()

    # Create accounts:
    cash = ledger.create_account(AccountType.ASSETS, "Cash")
    revenue = ledger.create_account(AccountType.REVENUES, "Revenue")
    expense = ledger.create_account(AccountType.EXPENSES, "Expense")

    # Create transaction types:
    sale = ledger.create_transaction_type(TransactionTypeCategory.BUSINESS, "Sale")
    purchase = ledger.create_transaction_type(TransactionTypeCategory.BUSINESS, "Purchase")

    # Create transactions:
    sale_txn = Transaction(sale, "Sale of goods")
   

# Generated at 2022-06-18 02:22:14.244092
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry reader:

# Generated at 2022-06-18 02:22:26.660142
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class MockJournalEntry(JournalEntry):
        def __init__(self, date: date, description: str, source: str, postings: List[Posting[str]]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:22:34.262599
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    # Create a journal entry
    journal = JournalEntry(datetime.date.today(), "Test Journal Entry", "Test Source")

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post to the account
    journal.post(datetime.date.today(), account, Quantity(100))

    # Check if the posting was added
    assert len(journal.postings) == 1

    # Check if the posting is a debit
    assert journal.postings[0].is_debit

    # Check if the posting is a credit
    assert not journal.postings[0].is_credit

    # Check if the posting is an increment

# Generated at 2022-06-18 02:22:43.876218
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book("Test Book")

    # Create a ledger:
    ledger = Ledger("Test Ledger", book)

    # Create a transaction:
    transaction = Transaction("Test Transaction", ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Create an account:
    account = Account("Test Account", AccountType.ASSETS)

    # Post a debit:

# Generated at 2022-06-18 02:23:05.816381
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.accounts import Account, AccountType
    from ..books.ledgers import Ledger
    from ..books.journals import Journal
    from ..books.transactions import Transaction
    from ..books.transactions.transaction import TransactionType
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory
    from ..books.transactions.transaction_types import TransactionTypeFactory

# Generated at 2022-06-18 02:23:17.391416
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountTypeGroup
    from .accounts import AccountCategoryGroup
    from .accounts import AccountGroupGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupGroup
    from .accounts import AccountGroupTypeGroup
    from .accounts import AccountGroupCategoryGroup
    from .accounts import AccountGroupGroupGroup
    from .accounts import AccountGroupTypeGroupGroup
    from .accounts import AccountGroupCategoryGroupGroup
    from .accounts import AccountGroupGroupGroupGroup
    from .accounts import AccountGroupTypeGroupGroupGroup
    from .accounts import AccountGroupCategoryGroupGroupGroup
    from .accounts import AccountGroupGroup

# Generated at 2022-06-18 02:23:27.110983
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .currencies import Currency, CurrencyUnit
    from .money import Money
    from .units import Unit

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)
    journal.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Money(100, Currency(CurrencyUnit.USD)))
    journal.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.EXPENSES), Money(100, Currency(CurrencyUnit.USD)))

    # Validate the journal entry
    journal.validate()

# Generated at 2022-06-18 02:23:35.895721
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    # Create a journal entry
    journal = JournalEntry(datetime.date(2019, 1, 1), "Test Journal Entry", None)

    # Create an account
    account = Account("Test Account", AccountType.ASSETS, None)

    # Post a debit
    journal.post(datetime.date(2019, 1, 1), account, Quantity(100))

    # Post a credit
    journal.post(datetime.date(2019, 1, 1), account, Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Check the postings

# Generated at 2022-06-18 02:23:42.180806
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", None, [
                        Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                        Posting(None, date(2020, 1, 1), Account("B", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                    ]),
                ]


# Generated at 2022-06-18 02:23:46.906536
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date

    # Create a journal entry
    je = JournalEntry[str](date(2020, 1, 1), "Test", "Test")
    je.postings.append(Posting(je, date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(Quantity(100))))
    je.postings.append(Posting(je, date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Direction.DEC, Amount(Quantity(100))))
    je.validate()

# Generated at 2022-06-18 02:23:55.765812
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(ledger, "Test Transaction", "Test Transaction")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Create an account
    account = Account(ledger, "Test Account", AccountType.ASSETS)

    # Post to the account
    journal_entry.post(datetime.date.today(), account, Quantity(10))

    # Validate the journal entry
    journal_entry.validate()

    # Check the postings
    assert len

# Generated at 2022-06-18 02:24:05.116438
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:24:14.268591
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:24:23.705020
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .journal import JournalEntry, Posting, Direction
    from . import accounts, transactions, journal, books, ledgers
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import List

    # Create a ledger
    ledger = Ledger("Test Ledger")

    # Create a book
    book = Book("Test Book", ledger)

    # Create a transaction
    transaction = Transaction("Test Transaction", book)

    # Create a journal entry

# Generated at 2022-06-18 02:24:47.114659
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:24:57.134222
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from dataclasses import asdict
    from typing import List
    from pprint import pprint
    from decimal import Decimal
    import pytest

    @dataclass(frozen=True)
    class BusinessObject:
        """
        Provides a business object model.
        """

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)

    # Create a business object
    business_object = BusinessObject()

    # Create a journal entry

# Generated at 2022-06-18 02:25:06.686310
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[str]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[str]):
        pass


# Generated at 2022-06-18 02:25:10.500008
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class TestReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [JournalEntry(date(2020, 1, 1), "Test", None)]

    test_read_journal_entries = TestReadJournalEntries()
    assert test_read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 1))) == [JournalEntry(date(2020, 1, 1), "Test", None)]

# Generated at 2022-06-18 02:25:19.526905
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryFactory
    from .accounts import AccountRepositoryFactoryImpl
    from .accounts import AccountRepositoryImpl
    from .accounts import AccountType
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryFactory
    from .accounts import AccountTypeRepositoryFactoryImpl
    from .accounts import AccountTypeRepositoryImpl
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryFactory
    from .accounts import AccountTypeRepositoryFactoryImpl
    from .accounts import AccountTypeRepositoryImpl
    from .accounts import AccountTypeRepository

# Generated at 2022-06-18 02:25:30.033586
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeCategoryTypeType
    from .transactions import TransactionTypeCategoryTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeTypeType
    from .transactions import Transaction

# Generated at 2022-06-18 02:25:38.980686
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    txn = Transaction(ledger, "Buy food")
    txn.post(datetime.date(2020, 1, 1), "Assets:Cash", -100)
    txn.post(datetime.date(2020, 1, 1), "Expenses:Food", 100)
    txn.post(datetime.date(2020, 1, 1), "Revenues:Sales", 100)

# Generated at 2022-06-18 02:25:46.064785
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeGroup
    from .accounts import AccountTypeSubGroup
    from .accounts import AccountTypeSubSubGroup
    from .accounts import AccountTypeSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubSubGroup
    from .accounts import Account

# Generated at 2022-06-18 02:25:56.054616
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger, LedgerEntry
    from .readers import ReadLedgerEntries
    from .transactions import Transaction
    from .writers import WriteJournalEntries

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction()

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post to the ledger:
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), +100)

# Generated at 2022-06-18 02:26:06.483831
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return []

    class TestReadJournalEntriesTest(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            read_journal_entries = TestReadJournalEntries()
            period = DateRange(date(2020, 1, 1), date(2020, 1, 31))

            # Act:
            result = read_journal_entries(period)

            # Assert:

# Generated at 2022-06-18 02:26:59.484072
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", None, [
                    Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("B", AccountType.EQUITIES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:27:09.874177
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:27:18.073042
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test"

    #: Business object as the source of the journal entry.
    source = "Test"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Journal entry the posting belongs to.
    journal = JournalEntry(date, description, source, postings)

    #: Account of the posting.
    account = Account("Test", AccountType.ASSETS)

    #: Posted

# Generated at 2022-06-18 02:27:26.967764
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from dataclasses import dataclass, field
    from typing import List, TypeVar
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:27:34.789671
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .commons import DateRange
    from .journal import JournalEntry, ReadJournalEntries, Direction
    from .numbers import Amount, Quantity
    from .others import Guid

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a read function:

# Generated at 2022-06-18 02:27:41.367147
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.transactions import TransactionType

    # Define a ledger:
    ledger = Ledger()

    # Define a transaction type:
    transaction_type = TransactionType("SALE", "Sale of goods", "SALE")

    # Define a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Sale of goods",
        transaction_type=transaction_type,
        source=transaction_type,
    )

    # Define a journal entry:

# Generated at 2022-06-18 02:27:49.912437
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account
    from .accounts import ReadAccounts
    from .accounts import ReadAccountsByType
    from .accounts import ReadAccountsByTypeAndName
    from .accounts import ReadAccountsByTypeAndNameAndParent
    from .accounts import ReadAccountsByTypeAndNameAndParentAndCurrency
    from .accounts import ReadAccountsByTypeAndNameAndParentAndCurrencyAndIsActive
    from .accounts import ReadAccountsByTypeAndNameAndParentAndCurrencyAndIsActiveAndIsPlaceholder
    from .accounts import ReadAccountsByTypeAndNameAndParentAndCurrencyAndIsActiveAndIsPlaceholderAndIsSystem
    from .accounts import ReadAccountsByTypeAndNameAndParentAndCurrencyAndIsActiveAndIsPlaceholderAndIsSystemAndIsVirtual
    from .accounts import ReadAccount

# Generated at 2022-06-18 02:27:55.154718
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> List[JournalEntry]:
            return []

    class TestCase(TestCase):
        def test_ReadJournalEntries___call__(self):
            mock_journal_entry = Mock(JournalEntry)
            mock_journal_entry.date = date(2020, 1, 1)
            mock_journal_entry.description = "Mock Journal Entry"
            mock_journal_entry.source = "Mock Source"
            mock

# Generated at 2022-06-18 02:28:04.568361
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType, Account
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry:
    journal = JournalEntry[int](date(2020, 1, 1), "Test", 1)
    journal.post(date(2020, 1, 1), Account("A", AccountType.ASSETS), +100)
    journal.post(date(2020, 1, 1), Account("B", AccountType.EQUITIES), -100)

    # Create a function which reads journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        yield journal

    # Verify that the function is of the right type:
    assert isinstance(read_journal_entries, ReadJournalEntries)

    # Verify that the function returns the journal entry:


# Generated at 2022-06-18 02:28:14.453294
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a transaction
    transaction = Transaction(book, "Test Transaction")

    # Create an event
    event = Event(transaction, "Test Event")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", event)

    # Post an increment event to an asset account