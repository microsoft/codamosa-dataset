

# Generated at 2022-06-18 02:19:40.776582
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:19:50.184873
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountCode
    from .accounts import AccountName
    from .accounts import AccountDescription
    from .accounts import AccountCurrency
    from .accounts import AccountBalance
    from .accounts import AccountStatus
    from .accounts import AccountGroup
    from .accounts import AccountGroupName
    from .accounts import AccountGroupDescription
    from .accounts import AccountGroupStatus
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCode
    from .accounts import AccountGroupCurrency
    from .accounts import AccountGroupBalance
    from .accounts import AccountGroupParent
    from .accounts import AccountGroupChildren
    from .accounts import AccountGroupAccounts
    from .accounts import AccountGroupAccount

# Generated at 2022-06-18 02:19:58.612938
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency, CurrencyUnit
    from .products import Product, ProductType
    from .units import Unit

    # Create a business:
    business = Business("Test Business")

    # Create a product:
    product = Product("Test Product", ProductType.GOODS, Unit("Test Unit", "TU", "Test Unit"), CurrencyUnit("Test Currency", "TC", "Test Currency"), 1.0)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", product)

    # Create accounts:
    account_assets = Account("Test Assets", AccountType.ASSETS, CurrencyUnit("Test Currency", "TC", "Test Currency"))

# Generated at 2022-06-18 02:20:08.740873
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry[Transaction](datetime.date.today(), "Test Journal Entry", transaction)

    # Create a read journal entries function:
    read_journal_entries = ReadJournalEntries[Transaction]()

    # Test:
    assert read_journal_entries(DateRange.from_now()) == []
    assert read_journal_entries(DateRange.from_now()) == []
    assert read_journal_entries(DateRange.from_now()) == []
    assert read_journal

# Generated at 2022-06-18 02:20:21.102073
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post an amount to the account
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Check the posting
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account == account

# Generated at 2022-06-18 02:20:32.545845
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a mock function:
    def mock_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return [
            JournalEntry(date(2020, 1, 1), "Test", None, [
                Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                Posting(None, date(2020, 1, 1), Account("B", AccountType.EQUITIES), Direction.DEC, Amount(100)),
            ]),
        ]

   

# Generated at 2022-06-18 02:20:40.070346
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    # Create a journal entry
    journal = JournalEntry[str]("2019-01-01", "Test Journal Entry", "Test Source")
    journal.post(journal.date, Account("Assets", AccountType.ASSETS), 100)
    journal.post(journal.date, Account("Revenues", AccountType.REVENUES), -100)

    # Validate the journal entry
    journal.validate()

# Generated at 2022-06-18 02:20:48.712182
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction, Posting
    from datetime import date
    from dataclasses import asdict
    from pprint import pprint

    # Create a journal entry
    je = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Post an amount to an account
    je.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))

    # Post an amount to an account
    je.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(-100))

    # Post an amount to an account
    je.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(0))

# Generated at 2022-06-18 02:20:58.171962
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledger import Ledger
    from .readers import read_journal_entries
    from .writers import write_journal_entries

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post to a ledger account:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get("Assets:Cash"), +100)

    # Post to a ledger account:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get("Expenses:Food"), -100)

# Generated at 2022-06-18 02:21:04.204180
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business, BusinessType
    from .ledgers import Ledger, LedgerType
    from .transactions import Transaction, TransactionType

    # Create a business:
    business = Business(name="Test Business", type=BusinessType.SOLE_PROPRIETORSHIP)

    # Create a ledger:
    ledger = Ledger(business=business, type=LedgerType.GENERAL)

    # Create a transaction:
    transaction = Transaction(ledger=ledger, type=TransactionType.SALES, date=datetime.date(2020, 1, 1))

    # Create accounts:
    account_cash = Account(ledger=ledger, name="Cash", type=AccountType.ASSETS)

# Generated at 2022-06-18 02:21:21.516359
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .numbers import Amount, Quantity
    from .transactions import Transaction

    # Create a book:
    book = Book(Currency.USD)

    # Create a transaction:
    transaction = Transaction(book, datetime.date(2019, 1, 1), "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry[Transaction](datetime.date(2019, 1, 1), "Test Journal Entry", transaction)

    # Create accounts:
    account_1 = Account(book, "Account 1", AccountType.ASSETS)
    account_2 = Account(book, "Account 2", AccountType.LIABILITIES)

    # Post to accounts:

# Generated at 2022-06-18 02:21:31.479968
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a read journal entries function:

# Generated at 2022-06-18 02:21:40.977325
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "test", None)

    # create an account
    account = Account("test", AccountType.ASSETS)

    # post a quantity to the account
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # check the posting
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:21:51.557615
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main

    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_empty(self):
            def read_journal_entries(period: DateRange) -> List[JournalEntry[None]]:
                return []

            self.assertEqual(read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31))), [])


# Generated at 2022-06-18 02:22:01.199678
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AssetAccount
    from .accounts import ExpenseAccount
    from .accounts import RevenueAccount
    from .accounts import EquityAccount
    from .accounts import LiabilityAccount
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGrouping
    from .accounts import AccountGroupingType
    from .accounts import AccountGroupingCategory
    from .accounts import AccountGroupingCategoryType
    from .accounts import AccountTree
    from .accounts import AccountTreeType
    from .accounts import AccountTreeCategory
    from .accounts import AccountTreeCategoryType

# Generated at 2022-06-18 02:22:13.348193
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries, test_JournalEntry_post

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return (
            JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=None)
            .post(date=datetime.date(2020, 1, 1), account=Account(type=AccountType.ASSETS, name="Cash"), quantity=100)
            .post(date=datetime.date(2020, 1, 1), account=Account(type=AccountType.EXPENSES, name="Rent"), quantity=-100)
        )

    # Read journal entries:


# Generated at 2022-06-18 02:22:19.609255
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(datetime.date.today(), "Test Journal", None)
    journal.post(datetime.date.today(), Account("Assets", AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date.today(), Account("Revenues", AccountType.REVENUES), Quantity(-100))
    journal.validate()

# Generated at 2022-06-18 02:22:30.176009
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post a positive quantity
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Check the postings
    assert journal.postings == [Posting(journal, datetime.date(2020, 1, 1), account, Direction.INC, Amount(100))]

    # Post a negative quantity
    journal.post(datetime.date(2020, 1, 1), account, Quantity(-100))

    # Check the postings
   

# Generated at 2022-06-18 02:22:40.590834
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[TestSource]):
        pass


# Generated at 2022-06-18 02:22:46.341258
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger

    ledger = Ledger()
    account_cash = Account(ledger, "Cash", AccountType.ASSETS)
    account_revenue = Account(ledger, "Revenue", AccountType.REVENUES)
    account_expense = Account(ledger, "Expense", AccountType.EXPENSES)

    journal_entry = JournalEntry(datetime.date.today(), "Test", None)
    journal_entry.post(datetime.date.today(), account_cash, +100)
    journal_entry.post(datetime.date.today(), account_revenue, -100)
    journal_entry.validate()

    journal_entry = JournalEntry(datetime.date.today(), "Test", None)

# Generated at 2022-06-18 02:23:17.651202
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction, Posting
    from datetime import date
    from dataclasses import asdict
    import json

    # Create a journal entry
    journal = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Post a debit
    journal.post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Quantity(100))

    # Post a credit
    journal.post(date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Check the postings

# Generated at 2022-06-18 02:23:28.841813
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency, CurrencyUnit
    from .ledgers import Ledger
    from .units import Unit

    ## Create a ledger:
    ledger = Ledger()

    ## Create a business:
    business = Business(
        name="Test Business",
        currency=Currency(CurrencyUnit.USD),
        ledger=ledger,
    )

    ## Create a unit:
    unit = Unit(
        name="Test Unit",
        business=business,
    )

    ## Create accounts:

# Generated at 2022-06-18 02:23:36.912105
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Cash", AccountType.ASSETS))
    ledger.add_account(Account("Equity", AccountType.EQUITIES))
    ledger.add_account(Account("Revenue", AccountType.REVENUES))
    ledger.add_account(Account("Expense", AccountType.EXPENSES))

    transaction = Transaction(ledger)
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Cash"), +100)
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Equity"), -100)

# Generated at 2022-06-18 02:23:46.440614
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from typing import List
    from dataclasses import field, asdict
    from copy import deepcopy
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange
    from ..commons.types import BusinessObject
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..commons.types import BusinessObject
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid

# Generated at 2022-06-18 02:24:06.248634
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries, test_JournalEntry_post

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a type variable.
    _T = TypeVar("_T")

    #

# Generated at 2022-06-18 02:24:14.785167
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .events import EventType
    from .events import EventTypeCategory
    from .events import EventTypeGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroup
    from .events import EventType

# Generated at 2022-06-18 02:24:23.768682
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a function which reads journal entries:

# Generated at 2022-06-18 02:24:33.723968
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.zeitgeist import DateRange

    # Define a journal entry reader:

# Generated at 2022-06-18 02:24:43.822122
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .readers import ReadLedger
    from .writers import WriteLedger
    from .journal import Journal
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from datetime import date

    # create a ledger
    ledger = Ledger("Test Ledger")

    # create a book
    book = Book("Test Book", ledger)

    # create a journal
    journal = Journal("Test Journal", book)

    # create accounts
    account1 = Account("Test Account 1", AccountType.ASSETS)
    account2 = Account("Test Account 2", AccountType.ASSETS)

    # create a journal entry

# Generated at 2022-06-18 02:24:48.994091
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date

    journal = JournalEntry(date(2020, 1, 1), "Test Journal", "Test Source")
    journal.postings.append(Posting(journal, date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Direction.INC, Amount(Quantity(100))))
    journal.postings.append(Posting(journal, date(2020, 1, 1), Account("Test Account", AccountType.LIABILITIES), Direction.DEC, Amount(Quantity(100))))
    journal.validate()

# Generated at 2022-06-18 02:25:19.091815
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTree
    from .accounts import AccountTreeBuilder
    from .accounts import AccountTreeBuilderFromDict
    from .accounts import AccountTreeBuilderFromList
    from .accounts import AccountTreeBuilderFromTuple
    from .accounts import AccountTreeBuilderFromYaml
    from .accounts import AccountTreeBuilderFromJson
    from .accounts import AccountTreeBuilderFromXml
    from .accounts import AccountTreeBuilderFromCsv
    from .accounts import AccountTreeBuilderFromXlsx
    from .accounts import AccountTreeBuilderFromOds
    from .accounts import AccountTreeBuilderFromXls
    from .accounts import AccountTreeBuilderFromXlsb
    from .accounts import AccountTree

# Generated at 2022-06-18 02:25:29.643364
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:25:38.589309
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest.mock import MagicMock, call

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a mock journal entry:
    journal_entry = MagicMock(JournalEntry)
    journal_entry.date = date(2020, 1, 1)
    journal_entry.postings = [
        Posting(journal_entry, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
        Posting(journal_entry, date(2020, 1, 1), Account("B", AccountType.EQUITIES), Direction.DEC, Amount(100)),
    ]

    # Define a mock journal entry

# Generated at 2022-06-18 02:25:45.863008
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entries = [
                JournalEntry(date(2020, 1, 1), "Description 1", None),
                JournalEntry(date(2020, 2, 1), "Description 2", None),
                JournalEntry(date(2020, 3, 1), "Description 3", None),
            ]

            # Act:
            read_journal_entries = ReadJournalEntries.__call__(Mock(), DateRange(date(2020, 1, 1), date(2020, 2, 1)))

            #

# Generated at 2022-06-18 02:25:56.053152
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account(AccountType.ASSETS, "Cash"))
    ledger.add_account(Account(AccountType.ASSETS, "Bank"))
    ledger.add_account(Account(AccountType.EXPENSES, "Salaries"))
    ledger.add_account(Account(AccountType.REVENUES, "Sales"))

    t1 = Transaction(ledger, "Sale", datetime.date(2020, 1, 1))
    t1.post(ledger.account("Cash"), Quantity(100))
    t1.post(ledger.account("Sales"), Quantity(-100))

    t2 = Transaction

# Generated at 2022-06-18 02:26:06.482902
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a function which reads journal entries from a source.

# Generated at 2022-06-18 02:26:16.061602
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeCategoryType
    from .accounts import AccountTypeType
    from .accounts import AccountTypeSubType
    from .accounts import AccountTypeSubTypeType
    from .accounts import AccountTypeSubTypeCategory
    from .accounts import AccountTypeSubTypeCategoryType
    from .accounts import AccountTypeSubTypeCategorySubType
    from .accounts import AccountTypeSubTypeCategorySubTypeType
    from .accounts import AccountTypeSubTypeCategorySubTypeCategory
    from .accounts import AccountTypeSubTypeCategorySubTypeCategoryType
    from .accounts import AccountTypeSubTypeCategorySubTypeCategorySubType
    from .accounts import AccountTypeSubTypeCategorySubTypeCategorySubTypeType
    from .accounts import AccountType

# Generated at 2022-06-18 02:26:23.477019
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Create an account:
    account = Account(ledger, "Test Account", AccountType.ASSETS)

    # Post a quantity to the account:
    journal_entry.post(datetime.date.today(), account, Quantity(100))

    # Validate the journal entry:
   

# Generated at 2022-06-18 02:26:31.736958
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction, Posting, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        pass

    #: Defines a posting model.
    @dataclass(frozen=True)
    class Posting(Posting[_T]):
        pass

    #: Defines a journal entry reader.

# Generated at 2022-06-18 02:26:42.421584
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntrySource2:
        pass


# Generated at 2022-06-18 02:27:37.950662
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountCategory
    from .accounts import AccountCategoryType
    from .accounts import AccountSubCategory
    from .accounts import AccountSubCategoryType
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountCategory
    from .accounts import AccountCategoryType
    from .accounts import AccountSubCategory
    from .accounts import AccountSubCategoryType
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountGroup
    from .accounts import AccountGroupType


# Generated at 2022-06-18 02:27:46.732459
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        date: date
        description: str
        source: str
        guid: str = field(default_factory=makeguid)

    # Define a journal entry reader:

# Generated at 2022-06-18 02:27:53.225334
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Setup:
            journal_entry_1 = Mock(JournalEntry)
            journal_entry_2 = Mock(JournalEntry)
            journal_entry_3 = Mock(JournalEntry)
            journal_entry_4 = Mock(JournalEntry)
            journal_entry_5 = Mock(JournalEntry)
            journal_entry_6 = Mock(JournalEntry)
            journal_entry_7 = Mock(JournalEntry)
            journal_entry_8 = Mock(JournalEntry)
            journal_entry_9 = Mock(JournalEntry)

# Generated at 2022-06-18 02:28:03.201233
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import AccountType, Account
    from .journal_entries import JournalEntry, Posting, Direction
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        date: date
        description: str
        source: str
        postings: List[Posting] = field(default_factory=list, init=False)
        guid: str = field(default_factory=makeguid, init=False)

    # Define a function which returns journal entries:

# Generated at 2022-06-18 02:28:08.840922
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Posting, Direction
    from .commons import DateRange
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Posting, Direction
    from .commons import DateRange
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Posting, Direction
    from .commons import DateRange
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Posting, Direction
    from .commons import DateRange
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import Journal

# Generated at 2022-06-18 02:28:16.853345
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType

# Generated at 2022-06-18 02:28:24.338532
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Post a debit and credit:
    journal_entry.post(datetime.date.today(), Account(AccountType.ASSETS, "Test Account"), +100)
    journal_entry.post(datetime.date.today(), Account(AccountType.EXPENSES, "Test Account"), -100)

    # Validate the journal entry:
    journal_entry.validate()

# Generated at 2022-06-18 02:28:33.055005
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import Iterable
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class JournalEntry:
        date: date
        description: str
        postings: Iterable[Posting]

    @dataclass(frozen=True)
    class Posting:
        account: Account
        direction: Direction
        amount: Amount

    @dataclass(frozen=True)
    class Account:
        name: str
        type: AccountType


# Generated at 2022-06-18 02:28:43.001443
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestJournalEntry(JournalEntry):
        def __init__(self, date: date, description: str, source: str, postings: List[Posting]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:28:48.738487
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import List
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class Source:
        pass

    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry[Source]):
        pass

    @dataclass(frozen=True)
    class PostingImpl(Posting[Source]):
        pass
