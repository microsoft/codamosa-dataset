

# Generated at 2022-06-18 02:19:42.190278
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=None,
    )

    # Create a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=None,
    )

    # Create accounts:
    cash = ledger.create_account(AccountType.ASSETS, "Cash")

# Generated at 2022-06-18 02:19:51.113342
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a journal entry reader.

# Generated at 2022-06-18 02:19:59.362004
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a dummy journal entry:
    @dataclass(frozen=True)
    class DummyJournalEntry(JournalEntry):
        def __post_init__(self):
            super().__post_init__()
            self.postings.append(Posting(self, self.date, Account("A", AccountType.ASSETS), Direction.INC, Amount(Quantity(1))))
            self.postings.append(Posting(self, self.date, Account("B", AccountType.ASSETS), Direction.INC, Amount(Quantity(2))))

# Generated at 2022-06-18 02:20:08.842016
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTree
    from .accounts import AccountTreeInMemory
    from .accounts import AccountTreeRepository
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory

# Generated at 2022-06-18 02:20:21.100373
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        date: date
        description: str
        source: str
        postings: List[Posting] = field(default_factory=list, init=False)

    # Define a read journal entries function:

# Generated at 2022-06-18 02:20:32.595026
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilderWithDefaults
    from .accounts import AccountRepositoryInMemoryBuilderWithDefaultsAndMappings
    from .accounts import AccountRepositoryInMemoryBuilderWithMappings
    from .accounts import AccountRepositoryInMemoryWithDefaults
    from .accounts import AccountRepositoryInMemoryWithDefaultsAndMappings
    from .accounts import AccountRepositoryInMemoryWithMappings
    from .accounts import AccountRepositoryInMemoryWithMappingsAndDefaults
    from .accounts import AccountRepositoryInMemoryWithMappingsAndDefaultsAndMappings
    from .accounts import AccountRepositoryInMemoryWithMappingsAnd

# Generated at 2022-06-18 02:20:39.706706
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Arrange:
    mock = Mock(spec=ReadJournalEntries)
    mock.__call__.return_value = []

    # Act:
    result = mock(DateRange(date(2019, 1, 1), date(2019, 12, 31)))

    # Assert:
    assert isinstance(result, Iterable)

# Generated at 2022-06-18 02:20:48.478399
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange


# Generated at 2022-06-18 02:20:58.004718
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        source: JournalEntrySource

    @dataclass(frozen=True)
    class JournalEntryPosting(Posting):
        journal: JournalEntry


# Generated at 2022-06-18 02:21:04.090468
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestJournalEntry(JournalEntry[str]):
        def __init__(self, date: date, description: str, source: str, postings: List[Posting[str]]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:21:20.791859
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase
    from unittest.mock import Mock

    class Test(TestCase):
        def test_returns_journal_entries_for_the_given_period(self):
            # Arrange:
            journal_entries = [
                JournalEntry(date(2020, 1, 1), "", None),
                JournalEntry(date(2020, 1, 2), "", None),
                JournalEntry(date(2020, 1, 3), "", None),
                JournalEntry(date(2020, 1, 4), "", None),
                JournalEntry(date(2020, 1, 5), "", None),
            ]
            read_journal_entries = Mock(return_value=journal_entries)

            # Act:

# Generated at 2022-06-18 02:21:28.339982
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    journal_entry.post(datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))
    journal_entry.post(datetime.date(2020, 1, 1), Account("Test", AccountType.REVENUES), Quantity(-100))

    # Exercise
    journal_entry.validate()

    # Verify
    # Nothing to verify

    # Cleanup
    # Nothing to cleanup

# Generated at 2022-06-18 02:21:38.831390
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .sources import Source
    from .transactions import Transaction

    ## Define a source:
    class MySource(Source):
        def __init__(self, name: str):
            super().__init__(name)

    ## Define a transaction:
    class MyTransaction(Transaction):
        def __init__(self, date: datetime.date, description: str, source: MySource):
            super().__init__(date, description, source)

    ## Define a ledger:
    class MyLedger(Ledger):
        def __init__(self, name: str):
            super().__init__(name)


# Generated at 2022-06-18 02:21:44.437208
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:21:55.227964
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction

    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    je.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(100))
    je.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), Quantity(-100))

    assert je.postings[0].direction == Direction.INC
    assert je.postings[1].direction == Direction.DEC
    assert je.postings[0].amount == Amount(100)
    assert je.postings[1].amount == Amount(100)

# Generated at 2022-06-18 02:22:03.814433
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger

    book = Book()
    ledger = Ledger(book)
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", None)
    journal.post(datetime.date(2020, 1, 1), ledger.get_account("Assets"), 100)
    journal.post(datetime.date(2020, 1, 1), ledger.get_account("Expenses"), -100)
    journal.validate()


# Generated at 2022-06-18 02:22:14.775390
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .business import Business
    from .currencies import Currency
    from .ledgers import Ledger
    from .numbers import Amount, Quantity
    from .transactions import Transaction

    ## Setup:
    ledger = Ledger(Currency.USD)
    business = Business(ledger, "Test Business")
    transaction = Transaction(business, "Test Transaction")
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", transaction)

    ## Test:
    journal.post(datetime.date(2020, 1, 1), Account.ASSETS, Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account.REVENUES, Quantity(-100))
    journal.validate()

    ## Test:

# Generated at 2022-06-18 02:22:27.328678
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .exchanges import Exchange
    from .transactions import Transaction
    from .wallets import Wallet

    # Setup:
    currency = Currency("USD")
    exchange = Exchange("Test", currency)
    wallet = Wallet("Test", currency)
    transaction = Transaction("Test", exchange, wallet, currency)

    # Test:
    journal = JournalEntry(datetime.date.today(), "Test", transaction)
    journal.post(datetime.date.today(), Account("Test", AccountType.ASSETS), 100)
    journal.post(datetime.date.today(), Account("Test", AccountType.EXPENSES), -100)
    journal.validate()

    # Test:

# Generated at 2022-06-18 02:22:34.570449
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Arrange:

# Generated at 2022-06-18 02:22:44.120968
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGrouping
    from .accounts import AccountGroupingType
    from .accounts import AccountGroupingCategory
    from .accounts import AccountGroupingGroup
    from .accounts import AccountGroupingGroupType
    from .accounts import AccountGroupingGroupCategory
    from .accounts import AccountGroupingGroupGroup
    from .accounts import AccountGroupingGroupGroupType
    from .accounts import AccountGroupingGroupGroupCategory
    from .accounts import AccountGroupingGroupGroupGroup
    from .accounts import AccountGroupingGroupGroupGroupType
   

# Generated at 2022-06-18 02:23:05.580985
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from typing import List

    # Create a journal entry
    je = JournalEntry[None](date(2020, 1, 1), "Test", None)

    # Post a debit
    je.post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Quantity(100))

    # Post a credit
    je.post(date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry
    je.validate()

    # Check the postings
    assert len(je.postings) == 2
    assert je

# Generated at 2022-06-18 02:23:17.199154
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeGroup
    from .transactions import TransactionTypeGroupCategory

    # Create a ledger
    ledger = Ledger()

    # Create a transaction type
    transaction_type = TransactionType(
        name="Test Transaction Type",
        category=TransactionTypeCategory.FINANCIAL,
        group=TransactionTypeGroup(
            name="Test Transaction Type Group",
            category=TransactionTypeGroupCategory.FINANCIAL,
        ),
    )

    # Create a transaction
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        type=transaction_type,
    )



# Generated at 2022-06-18 02:23:28.638126
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledger import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post to an account:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get("Assets:Cash"), Quantity(100))

    # Post to an account:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get("Expenses:Food"), Quantity(-100))

    # Validate the journal entry:

# Generated at 2022-06-18 02:23:37.002238
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    # Create a journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Create an account
    account = Account("Test Account", AccountType.ASSETS)

    # Post a positive amount
    journal.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Post a negative amount
    journal.post(datetime.date(2020, 1, 1), account, Quantity(-50))

    # Check the postings
    assert len(journal.postings) == 2
    assert journal.postings[0].direction == Direction.INC
    assert journal

# Generated at 2022-06-18 02:23:46.441786
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Rent", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Salary", AccountType.REVENUES))

    t1 = Transaction(datetime.date(2019, 1, 1), "Salary")
    t1.post(ledger.get_account("Revenues:Salary"), 100)
    t1.post(ledger.get_account("Assets:Cash"), -100)


# Generated at 2022-06-18 02:23:55.245070
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries

    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    @dataclass(frozen=True)
    class TestReadJournalEntries(ReadJournalEntries[TestSource]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[TestSource]]:
            return [
                TestJournalEntry(date(2020, 1, 1), "Test", TestSource(), [])
            ]

    read_journal_entries = TestReadJournalEntries()

# Generated at 2022-06-18 02:24:02.732308
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import MagicMock
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a mock journal entry:
    journal_entry = JournalEntry(date(2020, 1, 1), "Mock Journal Entry", MagicMock())
    journal_entry.postings = [
        Posting(journal_entry, date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(100)),
        Posting(journal_entry, date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, Amount(100)),
    ]

    # Define a mock journal entry reader:

# Generated at 2022-06-18 02:24:13.963110
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a journal entry reader:

# Generated at 2022-06-18 02:24:23.706258
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[int]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[int]):
        pass


# Generated at 2022-06-18 02:24:33.725247
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry reader:

# Generated at 2022-06-18 02:25:01.769259
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    #: Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #

# Generated at 2022-06-18 02:25:08.476580
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry
    journal = JournalEntry(datetime.date.today(), "Test Journal Entry")

    # Post to the journal entry
    journal.post(datetime.date.today(), Account(AccountType.ASSETS, "Cash"), Quantity(100))
    journal.post(datetime.date.today(), Account(AccountType.REVENUES, "Sales"), Quantity(-100))

    # Add the journal entry to the transaction
    transaction.add(journal)

    # Post the transaction to the ledger


# Generated at 2022-06-18 02:25:18.217850
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

    # Post an amount to an account
    je.post(datetime.date(2020, 1, 1), Account(makeguid(), "Test Account", AccountType.ASSETS), Amount(100))

    # Check if the posting is added to the journal entry
    assert len(je.postings) == 1
    assert je.postings[0].journal == je
    assert je.postings[0].date == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 02:25:28.738603
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date

    # Create a journal entry
    j = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Post an amount to an account
    j.post(date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))

    # Check the posting
    assert j.postings[0].journal == j
    assert j.postings[0].date == date(2020, 1, 1)
    assert j.postings[0].account == Account("Test", AccountType.ASSETS)
    assert j.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:25:35.841584
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Posting

    #: Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class MockJournalEntry(JournalEntry[_T]):
        """
        Provides a mock journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.

# Generated at 2022-06-18 02:25:44.504085
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import mock
    from unittest.mock import Mock
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a mock journal entry:
    mock_journal_entry = JournalEntry(date(2020, 1, 1), "Mock Journal Entry", None)
    mock_journal_entry.postings = [
        Posting(mock_journal_entry, date(2020, 1, 1), Account("Assets:Cash"), Direction.INC, Amount(100)),
        Posting(mock_journal_entry, date(2020, 1, 1), Account("Expenses:Food"), Direction.DEC, Amount(100)),
    ]

    # Define a mock journal entry reader:
    mock_journal_entry_reader: Read

# Generated at 2022-06-18 02:25:55.344202
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import ReadLedger
    from .transactions import Transaction
    from .writers import WriteLedger

    # Create a ledger:
    ledger = Ledger(
        "Test Ledger",
        "Test ledger for unit testing",
        [
            Account(AccountType.ASSETS, "Cash", "Cash in hand"),
            Account(AccountType.ASSETS, "Bank", "Bank account"),
            Account(AccountType.REVENUES, "Sales", "Sales revenues"),
            Account(AccountType.EXPENSES, "Salaries", "Salaries paid"),
        ],
    )

    # Create a transaction:

# Generated at 2022-06-18 02:26:05.522692
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .entities import Entity
    from .events import Event
    from .transactions import Transaction

    book = Book(Currency.USD)
    entity = Entity("Test Entity")
    event = Event("Test Event")
    transaction = Transaction(book, entity, event)

    journal = JournalEntry(datetime.date.today(), "Test Journal", transaction)
    journal.post(datetime.date.today(), Account(AccountType.ASSETS, "Test Account"), Quantity(100))
    journal.post(datetime.date.today(), Account(AccountType.REVENUES, "Test Account"), Quantity(-100))
    journal.validate()

# Generated at 2022-06-18 02:26:15.169130
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledger import Ledger
    from .transactions import Transaction, TransactionType

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:26:22.882105
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .ledgers.read import ReadLedger
    from .ledgers.write import WriteLedger
    from .ledgers.write import WriteLedger
    from .ledgers.read import ReadLedger
    from .ledgers.write import WriteLedger
    from .ledgers.read import ReadLedger
    from .ledgers.write import WriteLedger
    from .ledgers.read import ReadLedger
    from .ledgers.write import WriteLedger
    from .ledgers.read import ReadLedger
    from .ledgers.write import WriteLedger
    from .ledgers.read import ReadLedger
    from .ledgers.write import WriteLedger

# Generated at 2022-06-18 02:27:19.233378
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    transaction = Transaction(ledger)
    transaction.post(datetime.date(2020, 1, 1), "Assets:Cash", Quantity(100))
    transaction.post(datetime.date(2020, 1, 1), "Expenses:Food", Quantity(10))
    transaction

# Generated at 2022-06-18 02:27:28.220625
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .sources import Source

    # Create a ledger:
    ledger = Ledger()

    # Create a source:
    source = Source(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry[Source](date=datetime.date(2019, 1, 1), description="Test Journal Entry")

    # Post to accounts:
    journal_entry.post(date=datetime.date(2019, 1, 1), account=Account(AccountType.ASSETS, "Cash"), quantity=+100)

# Generated at 2022-06-18 02:27:36.029199
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import NamedTuple
    from unittest import TestCase

    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    class Source(NamedTuple):
        pass

    class JournalEntry(NamedTuple):
        date: date
        description: str
        source: Source
        postings: List[Posting]

    class Posting(NamedTuple):
        date: date
        account: Account
        direction: Direction
        amount: Amount

    class ReadJournalEntries(Protocol):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass


# Generated at 2022-06-18 02:27:45.400800
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        date: date
        description: str
        source: str
        guid: str = field(default_factory=makeguid, init=False)
        postings: List[Posting] = field(default_factory=list, init=False)

    # Define a read journal entries function:

# Generated at 2022-06-18 02:27:52.114392
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
   

# Generated at 2022-06-18 02:28:00.823783
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a business:
    business = Business("Test Business")

    # Create a transaction:
    transaction = Transaction(ledger, business, datetime.date(2020, 1, 1), "Test Transaction")

    # Create accounts:
    cash = Account(ledger, AccountType.ASSETS, "Cash")
    revenue = Account(ledger, AccountType.REVENUES, "Revenue")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post to the journal entry:

# Generated at 2022-06-18 02:28:11.639015
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal")

    # Post to accounts:
    journal.post(datetime.date(2020, 1, 1), Account(ledger, "Assets:Cash", AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account(ledger, "Expenses:Food", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry:

# Generated at 2022-06-18 02:28:20.358689
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .ledgers import Ledger
    from .numbers import Amount, Quantity

    # Setup:
    business = Business(name="Test Business", currency=Currency.USD)
    ledger = Ledger(business=business)
    account_cash = Account(type=AccountType.ASSETS, name="Cash", ledger=ledger)
    account_revenue = Account(type=AccountType.REVENUES, name="Revenue", ledger=ledger)
    account_expense = Account(type=AccountType.EXPENSES, name="Expense", ledger=ledger)

    # Exercise:
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry", source=business)
    journal

# Generated at 2022-06-18 02:28:28.666851
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date
    from typing import List

    # Create a journal entry
    journal = JournalEntry[str](date(2020, 1, 1), "Test", "Test")

    # Post an increment event to an asset account
    journal.post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Quantity(100))

    # Post a decrement event to an expense account
    journal.post(date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Check the postings
    assert journal.post

# Generated at 2022-06-18 02:28:38.447320
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", None, [
                        Posting(None, date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(100)),
                        Posting(None, date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                    ]),
                ]

            self.assertE