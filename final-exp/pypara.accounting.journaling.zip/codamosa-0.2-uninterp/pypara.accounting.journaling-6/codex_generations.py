

# Generated at 2022-06-18 02:19:34.738001
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import TestCase, mock
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entry = JournalEntry(date(2020, 1, 1), "Description", None)
            journal_entry.postings.append(Posting(journal_entry, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)))
            journal_entry.postings.append(Posting(journal_entry, date(2020, 1, 1), Account("B", AccountType.ASSETS), Direction.DEC, Amount(100)))

            # Act:
           

# Generated at 2022-06-18 02:19:45.950625
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .ledgers import Ledger

    # Create a ledger
    ledger = Ledger()

    # Create a journal entry
    journal_entry = JournalEntry[Ledger](date=datetime.date(2019, 1, 1), description="Test journal entry")

    # Post an increment event to an asset account
    journal_entry.post(date=datetime.date(2019, 1, 1), account=ledger.accounts.assets.cash, quantity=Quantity(100))

    # Post a decrement event to an expense account
    journal_entry.post(date=datetime.date(2019, 1, 1), account=ledger.accounts.expenses.office, quantity=Quantity(-100))

    # Val

# Generated at 2022-06-18 02:19:53.382972
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger

    ledger = Ledger()
    ledger.add_account(Account("A", AccountType.ASSETS))
    ledger.add_account(Account("B", AccountType.EQUITIES))
    ledger.add_account(Account("C", AccountType.LIABILITIES))
    ledger.add_account(Account("D", AccountType.REVENUES))
    ledger.add_account(Account("E", AccountType.EXPENSES))


# Generated at 2022-06-18 02:20:00.979598
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .transactions import Transaction, TransactionType

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique,

# Generated at 2022-06-18 02:20:06.715007
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    # Create a journal entry
    journal_entry = JournalEntry[str]("2020-01-01", "Test", "Test")

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a quantity to the account
    journal_entry.post("2020-01-01", account, 100)

    # Check the postings
    assert journal_entry.postings[0].account.name == "Test"
    assert journal_entry.postings[0].amount == 100
    assert journal_entry.postings[0].direction == Direction.INC
    assert journal_entry.postings[0].is_debit == True
    assert journal_entry.postings[0].is_credit == False

# Generated at 2022-06-18 02:20:15.152147
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Create account
    account = Account("Test", AccountType.ASSETS)

    # Post to account
    journal.post(datetime.date(2020, 1, 1), account, Quantity(1))

    # Check postings
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Amount(1)


# Generated at 2022-06-18 02:20:20.472752
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .readjournalentries import readjournalentries
    from .sources import Source
    from .transactions import Transaction

    # Define accounts:
    cash = Account("Cash", AccountType.ASSETS)
    revenue = Account("Revenue", AccountType.REVENUES)
    expense = Account("Expense", AccountType.EXPENSES)

    # Define transactions:
    t1 = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Transaction 1",
        source=Source("Source 1"),
        postings=[
            (cash, +100),
            (revenue, -100),
        ],
    )

# Generated at 2022-06-18 02:20:31.404560
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Account of the posting.
    account = Account("Test Account", AccountType.ASSETS)

    #: Direction of the posting.
    direction = Direction.INC

    #: Posted amount (in absolute value).
    amount = Quantity(100)

    journal_entry

# Generated at 2022-06-18 02:20:39.585600
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .exchanges import Exchange
    from .transactions import Transaction

    ## Setup:
    currency = Currency("USD")
    exchange = Exchange(currency, datetime.date(2020, 1, 1), 1.0)
    account_cash = Account("Cash", AccountType.ASSETS, currency)
    account_equity = Account("Equity", AccountType.EQUITIES, currency)
    account_revenue = Account("Revenue", AccountType.REVENUES, currency)
    account_expense = Account("Expense", AccountType.EXPENSES, currency)

    ## Test:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", Transaction(exchange))

# Generated at 2022-06-18 02:20:45.864498
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Setup:
    mock = Mock(spec=ReadJournalEntries)
    mock.__call__.return_value = [JournalEntry(date(2020, 1, 1), "", None)]

    # Exercise:
    result = mock(DateRange(date(2020, 1, 1), date(2020, 1, 1)))

    # Verify:
    assert result == [JournalEntry(date(2020, 1, 1), "", None)]

# Generated at 2022-06-18 02:21:02.804844
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry:
        date: date
        description: str
        source: str

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [
            JournalEntry(date(2020, 1, 1), "First", "First"),
            JournalEntry(date(2020, 1, 2), "Second", "Second"),
            JournalEntry(date(2020, 1, 3), "Third", "Third"),
        ]

    # Define a journal entry reader:

# Generated at 2022-06-18 02:21:14.116180
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger, LedgerEntry, ReadLedgerEntries
    from .transactions import Transaction, TransactionEntry, TransactionType

    # Define a ledger:
    ledger = Ledger(
        name="Test Ledger",
        accounts=[
            Account(name="Cash", type=AccountType.ASSETS),
            Account(name="Equity", type=AccountType.EQUITIES),
            Account(name="Revenue", type=AccountType.REVENUES),
            Account(name="Expense", type=AccountType.EXPENSES),
        ],
    )

    # Define a transaction type:

# Generated at 2022-06-18 02:21:25.445636
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Date of posting.
    date1 = datetime.date(2020, 1, 1)

    #: Account of the posting.
    account1 = Account("Test Account 1", AccountType.ASSETS)

    #: Direction of the posting.
    direction

# Generated at 2022-06-18 02:21:33.609504
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeRepositoryInMemory

# Generated at 2022-06-18 02:21:41.793479
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    txn = Transaction(ledger, datetime.date(2020, 1, 1), "Sale")
    txn.post(ledger.account("Assets:Cash"), +100)
    txn.post(ledger.account("Revenues:Sales"), -100)
    txn.validate()

    tx

# Generated at 2022-06-18 02:21:52.649502
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        # Define accounts:
        cash = Account("Cash", AccountType.ASSETS)
        revenue = Account("Revenue", AccountType.REVENUES)
        expense = Account("Expense", AccountType.EXPENSES)

        # Define journal entries:
        yield JournalEntry(datetime.date(2020, 1, 1), "A", "A1").post(datetime.date(2020, 1, 1), cash, +100).post(
            datetime.date(2020, 1, 1), revenue, -100
        )
        yield

# Generated at 2022-06-18 02:22:02.063691
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class MockJournalEntry(JournalEntry[None]):
        def __init__(self, date: date, description: str, source: None, postings: List[Posting[None]]):
            super().__init__(date, description, source, postings)

    class MockPosting(Posting[None]):
        def __init__(self, journal: JournalEntry[None], date: date, account: Account, direction: Direction, amount: Amount):
            super().__init__(journal, date, account, direction, amount)


# Generated at 2022-06-18 02:22:14.242408
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entry_1 = JournalEntry(date(2020, 1, 1), "", None)
            journal_entry_2 = JournalEntry(date(2020, 1, 2), "", None)
            journal_entry_3 = JournalEntry(date(2020, 1, 3), "", None)
            journal_entry_4 = JournalEntry(date(2020, 1, 4), "", None)

# Generated at 2022-06-18 02:22:26.659988
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import List
    from .journal import JournalEntry, Posting, Direction
    from .commons.others import Guid

    # Create a ledger
    ledger = Ledger()

    # Create accounts
    account_cash = Account("Cash", AccountType.ASSETS)
    account_equity = Account("Equity", AccountType.EQUITIES)
    account_revenue = Account("Revenue", AccountType.REVENUES)
    account_expense = Account("Expense", AccountType.EXPENSES)

# Generated at 2022-06-18 02:22:34.262739
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    class MyJournalEntry(JournalEntry):
        pass


# Generated at 2022-06-18 02:23:04.249632
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .commons.numbers import Amount, Quantity

    # Create a ledger
    ledger = Ledger()
    ledger.add_account(Account('Assets', AccountType.ASSETS))
    ledger.add_account(Account('Equities', AccountType.EQUITIES))
    ledger.add_account(Account('Liabilities', AccountType.LIABILITIES))
    ledger.add_account(Account('Revenues', AccountType.REVENUES))
    ledger.add_account(Account('Expenses', AccountType.EXPENSES))

    # Create a book
    book = Book(ledger)

    # Create a transaction
    transaction = Transaction(book)

    # Create a journal entry
    journal

# Generated at 2022-06-18 02:23:15.942927
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .ledgers import Ledger
    from .numbers import Amount, Quantity
    from .transactions import Transaction

    # Create a book:
    book = Book(
        name="Test Book",
        currency=Currency.USD,
        ledger=Ledger(
            name="Test Ledger",
            accounts=[
                Account(name="Assets:Cash", type=AccountType.ASSETS),
                Account(name="Expenses:Food", type=AccountType.EXPENSES),
                Account(name="Expenses:Rent", type=AccountType.EXPENSES),
                Account(name="Income:Salary", type=AccountType.REVENUES),
            ],
        ),
    )

    # Create a transaction:
   

# Generated at 2022-06-18 02:23:23.430110
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:23:33.226914
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[str]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: str

        #: Postings of the journal entry.
        postings: List[Posting[str]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.

# Generated at 2022-06-18 02:23:40.245577
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGrouping
    from .accounts import AccountGroupingType
    from .accounts import AccountTree
    from .accounts import AccountTreeNode
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeType
    from .accounts import AccountType
    from .accounts import AccountTypeGroup
    from .accounts import AccountTypeGrouping
    from .accounts import AccountTypeGroupingType
    from .accounts import AccountTypeGroupingType
    from .accounts import AccountTypeGroupingType
    from .accounts import AccountTypeGroupingType

# Generated at 2022-06-18 02:23:47.762864
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    transaction = Transaction(makeguid(), datetime.date(2020, 1, 1), "Test Transaction")
    transaction.post(ledger.account("Assets:Cash"), Quantity(100))

# Generated at 2022-06-18 02:23:56.235789
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry
    from .readers import ReadJournalEntries
    from .readers.journal import read_journal_entries
    from .readers.ledger import read_ledger_entries
    from .readers.ledger.ledger import LedgerEntry
    from .readers.ledger.ledger import LedgerEntryType
    from .readers.ledger.ledger import LedgerEntryType
    from .readers.ledger.ledger import LedgerEntryType
    from .readers.ledger.ledger import LedgerEntryType
    from .readers.ledger.ledger import LedgerEntryType
    from .readers.ledger.ledger import LedgerEntryType

# Generated at 2022-06-18 02:24:05.569894
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction
    from .ledgers import Ledger
    from .transactions import Transaction

    # Define a read journal entries function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Transaction]]:
        # Create a ledger:
        ledger = Ledger()

        # Create accounts:
        ledger.create_account(Account("Assets", AccountType.ASSETS))
        ledger.create_account(Account("Equities", AccountType.EQUITIES))
        ledger.create_account(Account("Liabilities", AccountType.LIABILITIES))
        ledger.create_account(Account("Revenues", AccountType.REVENUES))
        ledger.create

# Generated at 2022-06-18 02:24:14.534606
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Setup:
    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))
    ledger.add_account(Account("Equities:Opening Balances", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities:Credit Card", AccountType.LIABILITIES))

    # Test:

# Generated at 2022-06-18 02:24:23.743672
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[None]):
        pass

    @dataclass(frozen=True)
    class TestReadJournalEntries:
        journal_entries: List[TestJournalEntry]

        def __call__(self, period: DateRange) -> Iterable[TestJournalEntry]:
            return (je for je in self.journal_entries if period.contains(je.date))


# Generated at 2022-06-18 02:24:54.447147
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book(
        name="Test Book",
        ledgers={
            "Assets": Ledger(name="Assets", type=AccountType.ASSETS),
            "Expenses": Ledger(name="Expenses", type=AccountType.EXPENSES),
            "Equities": Ledger(name="Equities", type=AccountType.EQUITIES),
            "Liabilities": Ledger(name="Liabilities", type=AccountType.LIABILITIES),
            "Revenues": Ledger(name="Revenues", type=AccountType.REVENUES),
        },
    )

    # Create a transaction:

# Generated at 2022-06-18 02:25:05.574648
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.

# Generated at 2022-06-18 02:25:16.680918
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", "Test", [
                        Posting(None, date(2020, 1, 1), Account("Assets:Cash"), Direction.INC, Amount(100)),
                        Posting(None, date(2020, 1, 1), Account("Expenses:Food"), Direction.DEC, Amount(100)),
                    ]),
                ]


# Generated at 2022-06-18 02:25:27.515927
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class TestSource:
        pass

    test_source = TestSource()

    test_account = Account(makeguid(), "Test Account", AccountType.ASSETS)

    test_journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", test_source)

    test_journal_entry.post(datetime.date.today(), test_account, Quantity(10))

    assert len(test_journal_entry.postings) == 1
    assert test_journal_entry.postings[0].journal == test_journal_entry
    assert test_journal_entry.postings[0].date == datetime.date.today

# Generated at 2022-06-18 02:25:35.037472
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))

    transaction = Transaction(ledger, "Sale", makeguid())
    transaction.post(datetime.date(2020, 1, 1), "Assets:Cash", Quantity(100))
    transaction.post(datetime.date(2020, 1, 1), "Revenues:Sales", Quantity(-100))


# Generated at 2022-06-18 02:25:43.257608
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    # Arrange
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)
    account = Account("Test Account", AccountType.ASSETS)
    quantity = Quantity(100)

    # Act
    journal.post(datetime.date(2020, 1, 1), account, quantity)

    # Assert
    assert journal.postings == [
        Posting(journal, datetime.date(2020, 1, 1), account, Direction.INC, Amount(100))
    ]


# Generated at 2022-06-18 02:25:53.951266
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique

# Generated at 2022-06-18 02:26:04.549192
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, mock
    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entry_1 = JournalEntry(date(2020, 1, 1), "Description 1", "Source 1")
            journal_entry_2 = JournalEntry(date(2020, 1, 2), "Description 2", "Source 2")
            journal_entry_3 = JournalEntry(date(2020, 1, 3), "Description 3", "Source 3")
            journal_entries = [journal_entry_1, journal_entry_2, journal_entry_3]
            read_journal_entries = mock.Mock(spec=ReadJournalEntries)
            read_journal_entries.__call__

# Generated at 2022-06-18 02:26:10.350555
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
   

# Generated at 2022-06-18 02:26:19.024163
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.transactions import TransactionType

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(
        ledger,
        TransactionType.EXPENSE,
        "Test Transaction",
        datetime.date(2020, 1, 1),
        "Test Transaction",
    )

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post to accounts:

# Generated at 2022-06-18 02:27:17.086914
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting, ReadJournalEntries, _T

    @dataclass(frozen=True)
    class _TestJournalEntry(JournalEntry[_T]):
        pass

    @dataclass(frozen=True)
    class _TestPosting(Posting[_T]):
        pass

    @dataclass(frozen=True)
    class _TestSource:
        pass


# Generated at 2022-06-18 02:27:26.212153
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:27:33.943034
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    business = Business(ledger)

    # Create accounts:
    account_cash = Account(AccountType.ASSETS, "Cash")
    account_revenue = Account(AccountType.REVENUES, "Revenue")
    account_expense = Account(AccountType.EXPENSES, "Expense")

    # Create journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", business)

    # Post to accounts:
    journal_entry.post(datetime.date(2020, 1, 1), account_cash, +100)

# Generated at 2022-06-18 02:27:43.055837
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a read journal entries function:

# Generated at 2022-06-18 02:27:50.420754
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main

    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_empty(self):
            def read_journal_entries(period: DateRange) -> List[JournalEntry[None]]:
                return []

            self.assertEqual(list(read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))), [])


# Generated at 2022-06-18 02:27:59.565277
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .exchanges import Exchange
    from .transactions import Transaction

    book = Book("Test Book")
    currency = Currency("USD", "US Dollar")
    exchange = Exchange(book, currency, datetime.date(2020, 1, 1), 1.0)
    transaction = Transaction(book, exchange, datetime.date(2020, 1, 1), "Test Transaction")

    account1 = Account(book, AccountType.ASSETS, "Account 1")
    account2 = Account(book, AccountType.LIABILITIES, "Account 2")

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", transaction)
    journal.post(datetime.date(2020, 1, 1), account1, 100)
   

# Generated at 2022-06-18 02:28:05.790231
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction
    from .commons.numbers import Amount, Quantity
    from datetime import date

    class JournalEntryImpl(JournalEntry):
        def __init__(self, date: date, description: str, source: str, postings: List[Posting]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:28:15.367130
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.

# Generated at 2022-06-18 02:28:23.917310
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings

# Generated at 2022-06-18 02:28:32.587351
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .exchanges import Exchange
    from .markets import Market
    from .products import Product
    from .trades import Trade

    ## Setup:
    currency = Currency("USD")
    exchange = Exchange("NYSE", currency)
    market = Market("NYSE", exchange)
    product = Product("MSFT", market)
    trade = Trade(product, "BUY", Quantity(100), Amount(100))

    ## Test:
    journal = JournalEntry(datetime.date.today(), "Test", trade)
    journal.post(datetime.date.today(), Account("Cash", AccountType.ASSETS, currency), -100)
    journal.post(datetime.date.today(), Account("MSFT", AccountType.ASSETS, currency), 100)
    journal.validate()