

# Generated at 2022-06-18 02:19:34.586350
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:19:45.783454
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique

# Generated at 2022-06-18 02:19:53.311986
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return [
                JournalEntry(date(2019, 1, 1), "Test Journal Entry", None, [
                    Posting(None, date(2019, 1, 1), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2019, 1, 1), Account("Expenses", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:19:57.102876
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class _ReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    _ReadJournalEntries()

# Generated at 2022-06-18 02:20:05.114011
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .journal import JournalEntry, Posting
    from .transactions import Transaction

    # Create a book:
    book = Book(Currency.USD)

    # Create a journal entry:
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", Transaction(book, datetime.date(2020, 1, 1), "Test"))

    # Post some amounts:
    je.post(datetime.date(2020, 1, 1), Account(book, AccountType.ASSETS, "Cash"), Quantity(100))

# Generated at 2022-06-18 02:20:13.985387
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting, ReadJournalEntries

    # Define a dummy journal entry:
    @dataclass(frozen=True)
    class DummyJournalEntry(JournalEntry):
        pass

    # Define a dummy read journal entries function:

# Generated at 2022-06-18 02:20:23.472726
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entries = [
                JournalEntry(date(2020, 1, 1), "Journal Entry 1", None),
                JournalEntry(date(2020, 1, 2), "Journal Entry 2", None),
                JournalEntry(date(2020, 1, 3), "Journal Entry 3", None),
                JournalEntry(date(2020, 1, 4), "Journal Entry 4", None),
                JournalEntry(date(2020, 1, 5), "Journal Entry 5", None),
            ]
            read_journal

# Generated at 2022-06-18 02:20:34.469465
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount
    from ..commons.others import makeguid
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType

# Generated at 2022-06-18 02:20:44.834027
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .tags import Tag

    # Create a journal entry
    journal_entry = JournalEntry[Tag]()

    # Create accounts
    account_1 = Account("Account 1", AccountType.ASSETS)
    account_2 = Account("Account 2", AccountType.EQUITIES)
    account_3 = Account("Account 3", AccountType.LIABILITIES)
    account_4 = Account("Account 4", AccountType.REVENUES)
    account_5 = Account("Account 5", AccountType.EXPENSES)

    # Create tags
    tag_1 = Tag("Tag 1")
    tag_2 = Tag("Tag 2")

    # Post to account 1

# Generated at 2022-06-18 02:20:56.562114
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create ledger:
    ledger = Ledger()

    # Create accounts:
    ledger.create_account("Cash", AccountType.ASSETS)
    ledger.create_account("Sales", AccountType.REVENUES)
    ledger.create_account("COGS", AccountType.EXPENSES)

    # Create transaction:
    transaction = Transaction(ledger)

    # Create journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Sales")

    # Post to journal entry:
    journal_entry.post(datetime.date.today(), ledger.get_account("Cash"), +100)
    journal_entry.post(datetime.date.today(), ledger.get_account("Sales"), +100)

# Generated at 2022-06-18 02:21:09.799364
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", "Test", [
                        Posting(None, date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(100)),
                        Posting(None, date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                    ]),
                ]

            assert isinstance

# Generated at 2022-06-18 02:21:21.621662
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = 'test'

    #: Business object as the source of the journal entry.
    source = 'test'

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Journal entry the posting belongs to.
    journal = JournalEntry(date, description, source, postings, guid)

    #: Date of posting.
    date = datetime.date(2020, 1, 1)

    #: Account of the posting.
    account = Account

# Generated at 2022-06-18 02:21:31.550239
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main
    from unittest.mock import Mock

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            mock = Mock(spec=ReadJournalEntries[int])
            mock.__call__.return_value = [
                JournalEntry(date(2020, 1, 1), "", 0),
                JournalEntry(date(2020, 1, 2), "", 0),
            ]
            result: List[JournalEntry[int]] = list(mock(DateRange(date(2020, 1, 1), date(2020, 1, 2))))
            self.assertEqual(len(result), 2)
            self.assertEqual(result[0].date, date(2020, 1, 1))

# Generated at 2022-06-18 02:21:36.953397
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .events import EventType
    from .events import EventTypeCategory
    from .events import EventTypeGroup
    from .events import EventTypeSubGroup
    from .events import EventTypeSubGroupCategory
    from .events import EventTypeSubGroupCategoryType
    from .events import EventTypeSubGroupType
    from .events import EventTypeType
    from .events import EventTypeTypeCategory
    from .events import EventTypeTypeCategoryType
    from .events import EventTypeTypeType
    from .events import EventTypeTypeTypeCategory
    from .events import EventTypeTypeTypeCategoryType
    from .events import EventTypeTypeType

# Generated at 2022-06-18 02:21:43.529520
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledger import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry[Transaction]()

    # Post to the journal entry:
    journal_entry.post(datetime.date(2020, 1, 1), Account("A", AccountType.ASSETS), +100)
    journal_entry.post(datetime.date(2020, 1, 1), Account("B", AccountType.REVENUES), -100)

    # Validate the journal entry:
    journal_entry.validate()

    # Post

# Generated at 2022-06-18 02:21:54.665658
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_returns_journal_entries_in_the_given_period(self):
            # Setup:
            journal_entries: List[JournalEntry[None]] = [
                JournalEntry(date(2020, 1, 1), "", None),
                JournalEntry(date(2020, 1, 2), "", None),
                JournalEntry(date(2020, 1, 3), "", None),
                JournalEntry(date(2020, 1, 4), "", None),
                JournalEntry(date(2020, 1, 5), "", None),
            ]
            read_journal_entries: ReadJournalEnt

# Generated at 2022-06-18 02:22:03.407470
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .ledgers import Ledger, LedgerEntry
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=makeguid(),
        ledger=ledger,
    )

    # Create a journal entry
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=makeguid(),
    )

    # Post to journal entry

# Generated at 2022-06-18 02:22:14.622421
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction


# Generated at 2022-06-18 02:22:27.131370
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.accounts import Account, AccountType
    from ..accounts.accounts import AccountRepository
    from ..accounts.accounts import AccountRepositoryInMemory
    from ..accounts.accounts import AccountTypeRepository
    from ..accounts.accounts import AccountTypeRepositoryInMemory

    account_type_repository = AccountTypeRepositoryInMemory()
    account_repository = AccountRepositoryInMemory(account_type_repository)

    account_type_repository.add(AccountType("ASSETS", "Assets"))
    account_type_repository.add(AccountType("EQUITIES", "Equities"))
    account_type_repository.add(AccountType("LIABILITIES", "Liabilities"))

# Generated at 2022-06-18 02:22:38.270219
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", None, [
                    Posting(None, date(2020, 1, 1), Account("A", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("B", AccountType.EQUITIES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:22:54.826745
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> List[JournalEntry]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", None, [
                    Posting(None, date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:23:04.133619
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    book = Book("Test Book")
    ledger = Ledger("Test Ledger", book)
    ledger.add_account(Account("Test Account", AccountType.ASSETS))
    transaction = Transaction("Test Transaction", ledger)
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)
    journal_entry.post(datetime.date.today(), ledger.accounts[0], 100)
    journal_entry.post(datetime.date.today(), ledger.accounts[0], -100)
    journal_entry.validate()

# Generated at 2022-06-18 02:23:15.860245
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    # Create a ledger:
    ledger = Ledger()

    # Create accounts:
    assets = ledger.create_account(AccountType.ASSETS, "Assets")
    liabilities = ledger.create_account(AccountType.LIABILITIES, "Liabilities")
    revenues = ledger.create_account(AccountType.REVENUES, "Revenues")
    expenses = ledger.create_account(AccountType.EXPENSES, "Expenses")

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry")

    # Post to accounts:
   

# Generated at 2022-06-18 02:23:23.369406
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry1(JournalEntry):
        pass

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry1]:
        yield JournalEntry1(date(2020, 1, 1), "Journal Entry 1", None).post(date(2020, 1, 1), Account("A", AccountType.ASSETS), Quantity(100))

# Generated at 2022-06-18 02:23:33.188356
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting):
        pass


# Generated at 2022-06-18 02:23:40.211786
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    # Setup:

# Generated at 2022-06-18 02:23:45.926020
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction
    from .journal import JournalEntry, ReadJournalEntries

    # Define a ledger:
    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))

    # Define a transaction:
    transaction = Transaction(ledger)
    transaction.post(date(2020, 1, 1), "Assets:Cash", -100)
    transaction.post(date(2020, 1, 1), "Expenses:Food", 100)

    # Define a journal entry:

# Generated at 2022-06-18 02:23:50.197927
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class _TestSource:
        pass

    @dataclass(frozen=True)
    class _TestJournalEntry(JournalEntry[_TestSource]):
        pass

    @dataclass(frozen=True)
    class _TestPosting(Posting[_TestSource]):
        pass


# Generated at 2022-06-18 02:24:06.218926
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry[None]):
        pass

    # Define a read journal entries function:

# Generated at 2022-06-18 02:24:14.764083
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountSubGroup
    from .accounts import AccountSubSubGroup
    from .accounts import AccountSubSubSubGroup
    from .accounts import AccountSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSub

# Generated at 2022-06-18 02:24:35.408185
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeCategoryType
    from .transactions import TransactionTypeCategoryTypeType
    from .transactions import TransactionTypeCategoryTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeTypeType
    from .transactions import TransactionTypeCategoryTypeTypeTypeTypeTypeTypeTypeType

# Generated at 2022-06-18 02:24:45.618164
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction

    # Create a journal entry
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

    # Create an account
    account = Account("Test", AccountType.ASSETS)

    # Post a quantity to the account
    je.post(datetime.date(2020, 1, 1), account, Quantity(100))

    # Check the result
    assert len(je.postings) == 1
    assert je.postings[0].date == datetime.date(2020, 1, 1)
    assert je.postings[0].account == account
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].amount == Quantity(100)


# Generated at 2022-06-18 02:24:55.539859
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountGroup
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType, TransactionCategory, TransactionGroup

    book = Book("Test Book")
    ledger = Ledger("Test Ledger", book)

    # Create a transaction type
    transaction_type = TransactionType("Test Transaction Type", ledger)

    # Create a transaction category
    transaction_category = TransactionCategory("Test Transaction Category", ledger)

    # Create a transaction group
    transaction_group = TransactionGroup("Test Transaction Group", ledger)

    # Create a transaction
    transaction = Transaction("Test Transaction", transaction_type, transaction_category, transaction_group)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

   

# Generated at 2022-06-18 02:25:05.640758
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger

    # Create a ledger:
    ledger = Ledger()

    # Create accounts:
    ledger.create_account(Account("Assets", AccountType.ASSETS))
    ledger.create_account(Account("Equities", AccountType.EQUITIES))
    ledger.create_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.create_account(Account("Revenues", AccountType.REVENUES))
    ledger.create_account(Account("Expenses", AccountType.EXPENSES))

    # Create journal entries:

# Generated at 2022-06-18 02:25:16.762259
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create accounts:
    cash = ledger.create_account(AccountType.ASSETS, "Cash")
    sales = ledger.create_account(AccountType.REVENUES, "Sales")
    revenue = ledger.create_account(AccountType.REVENUES, "Revenue")
    expenses = ledger.create_account(AccountType.EXPENSES, "Expenses")
    expense = ledger.create_account(AccountType.EXPENSES, "Expense")

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    #

# Generated at 2022-06-18 02:25:27.515853
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .writers import write_journal_entries

    # Create a ledger:
    ledger = Ledger(
        name="Test Ledger",
        accounts=[
            Account(code="101", name="Cash", type=AccountType.ASSETS),
            Account(code="201", name="Sales", type=AccountType.REVENUES),
            Account(code="301", name="Salaries", type=AccountType.EXPENSES),
        ],
    )

    # Create a journal entry:
    je = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry")
   

# Generated at 2022-06-18 02:25:35.036163
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction

    # Setup:
    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    # Test:
    assert list(ledger.read_journal_entries(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)))) == []

    #

# Generated at 2022-06-18 02:25:43.819363
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .writers import write_journal_entries

    # Define a ledger:
    ledger = Ledger(
        name="Test Ledger",
        accounts=[
            Account(name="Cash", type=AccountType.ASSETS),
            Account(name="Sales", type=AccountType.REVENUES),
            Account(name="Inventory", type=AccountType.ASSETS),
            Account(name="Cost of Goods Sold", type=AccountType.EXPENSES),
        ],
    )

    # Define a journal entry:

# Generated at 2022-06-18 02:25:54.664200
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry1(JournalEntry[None]):
        pass

    # Define a journal entry reader:

# Generated at 2022-06-18 02:26:05.340929
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:26:56.181709
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from datetime import date
    from dataclasses import dataclass, field
    from typing import List, TypeVar
    _T = TypeVar("_T")
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """
        #: Date of the entry.
        date: datetime.date
        #: Description of the entry.
        description: str
        #: Business object as the source of the journal entry.
        source: _T
        #: Postings of the journal entry.

# Generated at 2022-06-18 02:27:07.362284
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountTypeRepository
    from .accounts import ReadAccounts
    from .accounts import ReadAccountTypes
    from .accounts import ReadAccountTypes
    from .accounts import ReadAccounts
    from .accounts import AccountTypeRepository
    from .accounts import AccountRepository
    from .accounts import AccountType, Account
    from .accounts import ReadAccountTypes, ReadAccounts
    from .accounts import AccountTypeRepository, AccountRepository
    from .accounts import AccountType, Account
    from .accounts import ReadAccountTypes, ReadAccounts
    from .accounts import AccountTypeRepository, AccountRepository
    from .accounts import AccountType, Account
    from .accounts import ReadAccountTypes, Read

# Generated at 2022-06-18 02:27:16.766617
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction, Posting
    from .commons.zeitgeist import DateRange
    from datetime import date

    # Test for post method of class JournalEntry
    # Test for posting a debit and credit event
    def test_post_debit_credit():
        # Create a journal entry
        journal_entry = JournalEntry(date(2020, 1, 1), "Test Journal Entry", "Test Source")
        # Post a debit event
        journal_entry.post(date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))
        # Post a credit event

# Generated at 2022-06-18 02:27:25.902790
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class MyJournalEntry(JournalEntry):
        pass

    # Define a read journal entries function:

# Generated at 2022-06-18 02:27:33.761541
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .journals import Journal
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a journal
    journal = Journal(book)

    # Create a transaction
    transaction = Transaction(journal)

    # Create an event
    event = Event(transaction)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", event)

    # Create an account
    account = Account(AccountType.ASSETS, "Test Account")

    # Post an amount to the account


# Generated at 2022-06-18 02:27:41.853020
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeSubCategory
    from .accounts import AccountTypeSubSubCategory
    from .accounts import AccountTypeSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSub

# Generated at 2022-06-18 02:27:50.248005
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import asdict
    from typing import NamedTuple
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    class BusinessObject(NamedTuple):
        name: str

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[BusinessObject]]:
        yield JournalEntry(date(2020, 1, 1), "Journal Entry 1", BusinessObject("Business Object 1")) \
            .post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Quantity(100)) \
            .post(date(2020, 1, 1), Account("Revenues", AccountType.REVENUES), Quantity(-100))


# Generated at 2022-06-18 02:27:59.395303
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import Iterable
    from .commons.others import Guid
    from .commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import Iterable
    from .commons.others import Guid
    from .commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity

# Generated at 2022-06-18 02:28:05.663022
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .journal import JournalEntry
    from .tags import Tag

    # Create a journal entry:
    journal = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=Tag("Test"),
    )

    # Post some debits and credits:
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, Currency.USD, "Cash"), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, Currency.USD, "Sales"), Quantity(-100))

    # Validate the journal entry:
    journal.validate()

# Generated at 2022-06-18 02:28:15.280462
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons import DateRange
    from datetime import date
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons import DateRange
    from datetime import date
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons import DateRange
    from datetime import date
    from .accounts import Account, AccountType
    from .commons import Amount, Quantity
    from .journal import JournalEntry, Direction
    from .commons import DateRange
    from datetime import date
    from .accounts import Account, AccountType
