

# Generated at 2022-06-18 02:19:34.897803
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries, Direction
    from .commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class _TestJournalEntry(JournalEntry[str]):
        pass


# Generated at 2022-06-18 02:19:46.147045
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeGroup
    from .accounts import AccountTypeSubGroup
    from .accounts import AccountTypeSubSubGroup
    from .accounts import AccountTypeSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountTypeSubSubSubSubSubSubSubSub

# Generated at 2022-06-18 02:19:53.500392
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import NamedTuple
    from unittest.mock import Mock

    class Source(NamedTuple):
        pass

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Source]]:
        return [
            JournalEntry(date(2020, 1, 1), "Description", Source(), [
                Posting(None, date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(100)),
                Posting(None, date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Direction.DEC, Amount(100)),
            ]),
        ]


# Generated at 2022-06-18 02:20:01.036049
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction, TransactionType
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .journal import JournalEntry, Direction

    # Create ledger
    ledger = Ledger()

    # Create book
    book = Book(ledger, "Test Book")

    # Create accounts
    account_cash = Account(ledger, "Cash", AccountType.ASSETS)
    account_revenue = Account(ledger, "Revenue", AccountType.REVENUES)
    account_expense = Account(ledger, "Expense", AccountType.EXPENSES)

    # Create transaction

# Generated at 2022-06-18 02:20:05.948804
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

    # Post to the ledger:
    journal.post(datetime.date(2020, 1, 1), ledger.get_account(AccountType.ASSETS, "Cash"), +100)
    journal.post(datetime.date(2020, 1, 1), ledger.get_account(AccountType.REVENUES, "Sales"), -100)

    # Validate:
    journal.validate()

    # Post to the ledger:

# Generated at 2022-06-18 02:20:14.700505
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .exchanges import Exchange
    from .markets import Market
    from .products import Product
    from .units import Unit
    from .users import User

    # Create a business:
    business = Business(
        name="Test Business",
        currency=Currency.USD,
        market=Market.US,
        owner=User(name="Test User"),
    )

    # Create a product:
    product = Product(
        name="Test Product",
        unit=Unit.PIECE,
        business=business,
    )

    # Create an exchange:

# Generated at 2022-06-18 02:20:23.849955
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.others import makeguid
    from datetime import date
    from typing import Iterable, List, TypeVar
    import datetime
    import pytest

    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business

# Generated at 2022-06-18 02:20:29.019275
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return []
    assert TestReadJournalEntries()(DateRange.from_dates(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))) == []

# Generated at 2022-06-18 02:20:38.964058
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.transaction import TransactionType
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory
    from .transactions.transaction_types import TransactionTypeFactory

# Generated at 2022-06-18 02:20:47.878045
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a transaction
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=makeguid(),
    )

    # Create accounts
    account_cash = Account(
        name="Cash",
        type=AccountType.ASSETS,
        ledger=ledger,
    )
    account_expense = Account(
        name="Expense",
        type=AccountType.EXPENSES,
        ledger=ledger,
    )

    # Post to the transaction
    transaction.post

# Generated at 2022-06-18 02:20:59.191494
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Journal Entry"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Account of the posting.
    account = Account("Test Account", AccountType.ASSETS)

    #: Direction of the posting.
    direction = Direction.INC

    #: Posted amount (in absolute value).
    amount = Amount(10)

    #:

# Generated at 2022-06-18 02:21:04.881897
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book(
        "Test Book",
        "Test Book",
        Currency("USD", "US Dollar", "USD", "US$", "US Dollar", "US$"),
        "USD",
    )

    # Create a ledger:
    ledger = Ledger(
        book,
        "Test Ledger",
        "Test Ledger",
        Account(book, "Test Account", "Test Account", AccountType.ASSETS),
    )

    # Create an event:

# Generated at 2022-06-18 02:21:16.808631
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .business import Business
    from .ledger import Ledger
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import Account

# Generated at 2022-06-18 02:21:21.982866
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique

# Generated at 2022-06-18 02:21:31.780304
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .business import Business
    from .currencies import Currency
    from .products import Product
    from .taxes import Tax

    #: Business to use for testing.
    business = Business(
        name="Test Business",
        currency=Currency("USD"),
        tax_rates={
            Tax.SALES: 0.10,
            Tax.PURCHASE: 0.05,
        },
    )

    #: Product to use for testing.
    product = Product(
        name="Test Product",
        sales_price=Amount(100),
        purchase_price=Amount(50),
        tax_rate=Tax.SALES,
    )

    #: Journal entry to use for testing.

# Generated at 2022-06-18 02:21:41.072811
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger

    # Create a ledger:
    ledger = Ledger()

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post to the ledger:
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get(AccountType.ASSETS, "Cash"), +100)
    journal.post(datetime.date(2020, 1, 1), ledger.accounts.get(AccountType.EXPENSES, "Rent"), -100)

    # Validate the journal entry:
    journal.validate()

    # Create a journal entry reader:

# Generated at 2022-06-18 02:21:51.699738
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.zeitgeist import DateRange


# Generated at 2022-06-18 02:22:01.314069
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import now
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .ledgers import Ledger

    ledger = Ledger(Currency.USD)
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    journal = JournalEntry(now(), "Test Journal Entry", None)
    journal.post(now(), ledger.accounts["Assets"], +100)

# Generated at 2022-06-18 02:22:13.509873
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryBuilder
    from .accounts import AccountRepositoryInMemoryBuilderFromDict
    from .accounts import AccountRepositoryInMemoryBuilderFromList
    from .accounts import AccountRepositoryInMemoryBuilderFromTuples
    from .accounts import AccountRepositoryInMemoryBuilderFromYaml
    from .accounts import AccountRepositoryInMemoryBuilderFromJson
    from .accounts import AccountRepositoryInMemoryBuilderFromCsv
    from .accounts import AccountRepositoryInMemoryBuilderFromXlsx
    from .accounts import AccountRepositoryInMemoryBuilderFromXls
    from .accounts import AccountRepositoryInMemoryBuilderFromOds
    from .accounts import AccountRepository

# Generated at 2022-06-18 02:22:25.958379
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry reader:

# Generated at 2022-06-18 02:22:41.671314
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .transactions import Transaction

    # Define a read function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Transaction]]:
        # Define accounts:
        cash = Account("Cash", AccountType.ASSETS)
        revenue = Account("Revenue", AccountType.REVENUES)
        expense = Account("Expense", AccountType.EXPENSES)

        # Define transactions:
        t1 = Transaction(date=datetime.date(2020, 1, 1), description="T1")
        t2 = Transaction(date=datetime.date(2020, 1, 2), description="T2")

        # Define journal entries:

# Generated at 2022-06-18 02:22:50.920973
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency, CurrencyUnit
    from .ledgers import Ledger
    from .transactions import Transaction

    ## Create a currency:
    currency = Currency(CurrencyUnit("USD"), 2)

    ## Create a ledger:
    ledger = Ledger(currency)

    ## Create a book:
    book = Book(ledger)

    ## Create an account:
    account = Account("Test Account", AccountType.ASSETS, currency)

    ## Create a transaction:
    transaction = Transaction(book, "Test Transaction")

    ## Create a journal entry:
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    ## Post a debit:
    journal_entry.post(datetime.date.today(), account, 100)



# Generated at 2022-06-18 02:22:58.574761
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionStatus
    from .transactions import TransactionLine
    from .transactions import TransactionLineStatus
    from .transactions import TransactionLineType
    from .transactions import TransactionLineCategory
    from .transactions import TransactionLineCategoryType
    from .transactions import TransactionLineCategoryStatus
    from .transactions import TransactionLineCategoryType
    from .transactions import TransactionLineCategoryStatus
    from .transactions import TransactionLineCategoryType
    from .transactions import TransactionLineCategoryStatus
    from .transactions import TransactionLineCategoryType
    from .transactions import TransactionLineCategoryStatus
    from .transactions import TransactionLineCategoryType
    from .transactions import TransactionLineCategoryStatus

# Generated at 2022-06-18 02:23:06.729787
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .ledgers import Ledger
    from .readers import read_journal_entries
    from .sources import Source

    # Define a source:
    class MySource(Source):
        def __init__(self, name: str):
            self.name = name

    # Define a ledger:
    ledger = Ledger()

    # Define accounts:
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    # Define a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", MySource("MySource"))

    # Post to accounts:
    journal_

# Generated at 2022-06-18 02:23:18.045024
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountTree
    from .accounts import AccountTreeNode
    from .accounts import AccountTreeNodeType
    from .accounts import AccountTreeNodeVisitor
    from .accounts import AccountTreeVisitor
    from .accounts import AccountVisitor
    from .accounts import AccountGroupVisitor
    from .accounts import AccountGroupTypeVisitor
    from .accounts import AccountTypeVisitor
    from .accounts import AccountGroupTypeVisitor
    from .accounts import AccountTypeVisitor
    from .accounts import AccountTreeNodeTypeVisitor
    from .accounts import AccountTreeNodeVisitor
    from .accounts import AccountTreeVisitor
    from .accounts import Account

# Generated at 2022-06-18 02:23:24.870453
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountRepository
    from .businessobjects import BusinessObject, BusinessObjectRepository
    from .currencies import Currency, CurrencyRepository
    from .exchanges import Exchange, ExchangeRepository
    from .units import Unit, UnitRepository
    from .users import User, UserRepository
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, Direction
    from .commons.others import makeguid
    from datetime import date
    from typing import List, Iterable
    import pytest

    ## Create a user:

# Generated at 2022-06-18 02:23:34.347114
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a mock journal entry reader:

# Generated at 2022-06-18 02:23:40.788369
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AssetAccount
    from .accounts import EquityAccount
    from .accounts import ExpenseAccount
    from .accounts import LiabilityAccount
    from .accounts import RevenueAccount
    from .accounts import StockAccount
    from .accounts import StockAccountType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType
    from .accounts import StockAccountSubType

# Generated at 2022-06-18 02:23:48.117980
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        source: JournalEntrySource


# Generated at 2022-06-18 02:23:56.586867
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting
    from .transactions import Transaction

    # Define a journal entry:
    journal = JournalEntry[Transaction](date=datetime.date(2020, 1, 1), description="Test Journal", source=Transaction())
    journal.post(date=datetime.date(2020, 1, 1), account=Account("Assets:Cash"), quantity=+100)
    journal.post(date=datetime.date(2020, 1, 1), account=Account("Expenses:Food"), quantity=-100)

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Transaction]]:
        return [journal]

    # Test the journal entry reader:

# Generated at 2022-06-18 02:24:15.813284
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository, AccountRepositoryInMemory
    from .accounts import AccountService, AccountServiceImpl
    from .accounts import AccountTypeRepository, AccountTypeRepositoryInMemory
    from .accounts import AccountTypeService, AccountTypeServiceImpl
    from .accounts import AccountTree, AccountTreeRepository, AccountTreeRepositoryInMemory
    from .accounts import AccountTreeService, AccountTreeServiceImpl
    from .accounts import AccountTreeNode, AccountTreeNodeRepository, AccountTreeNodeRepositoryInMemory
    from .accounts import AccountTreeNodeService, AccountTreeNodeServiceImpl
    from .accounts import AccountTreeNodeType, AccountTreeNodeTypeRepository, AccountTreeNodeTypeRepositoryInMemory
    from .accounts import AccountTreeNodeTypeService, AccountTreeNodeTypeServiceImpl

# Generated at 2022-06-18 02:24:24.096908
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger

    # Define a function which reads journal entries from a ledger:
    def read_journal_entries(ledger: Ledger) -> ReadJournalEntries:
        def read_journal_entries_from_ledger(period: DateRange) -> Iterable[JournalEntry]:
            return ledger.read_journal_entries(period)

        return read_journal_entries_from_ledger

    # Define a ledger:
    ledger = Ledger()

    # Define a journal entry:

# Generated at 2022-06-18 02:24:33.821657
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .journal import JournalEntry, Posting
    from .markets import Market
    from .money import Money

    # Create a journal entry
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")
    je.postings.append(Posting(je, datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS, Currency("USD"), Market("USD")), Direction.INC, Money(1, Currency("USD"), Market("USD"))))
    je.postings.append(Posting(je, datetime.date(2020, 1, 1), Account("Test", AccountType.EXPENSES, Currency("USD"), Market("USD")), Direction.DEC, Money(1, Currency("USD"), Market("USD"))))

   

# Generated at 2022-06-18 02:24:43.986508
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test")

    # Post an amount to an account
    journal_entry.post(datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))

    # Check the postings
    assert journal_entry.postings[0].date == datetime.date(2020, 1, 1)
    assert journal_entry.postings[0].account.name == "Test"
    assert journal_entry.postings[0].account.type == AccountType.ASSETS
    assert journal_entry.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:24:54.447081
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        guid: str = field(default_factory=makeguid)

    @dataclass(frozen=True)
    class TestPosting(Posting[TestSource]):
        pass


# Generated at 2022-06-18 02:25:05.574350
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        date: date
        description: str
        source: str
        guid: str = field(default_factory=makeguid, init=False)
        postings: List[Posting] = field(default_factory=list, init=False)

    # Define a posting:
    @dataclass(frozen=True)
    class Posting(Posting):
        journal: JournalEntry
        date: date
        account: Account

# Generated at 2022-06-18 02:25:16.682072
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import Iterable
    from .accounts import Account, AccountType

    @dataclass
    class JournalEntry:
        date: date
        description: str
        source: str
        postings: Iterable[Posting]

    @dataclass
    class Posting:
        account: Account
        direction: Direction
        amount: Amount

    @dataclass
    class Account:
        name: str
        type: AccountType

    @dataclass
    class Direction:
        value: int

    @dataclass
    class Amount:
        value: int

    @dataclass
    class DateRange:
        start: date
        end: date

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return

# Generated at 2022-06-18 02:25:27.516179
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType
    from .commons.types import EventType

# Generated at 2022-06-18 02:25:32.206189
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from typing import List
    from ..commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntry:
        pass

    def read_journal_entries(period: DateRange) -> List[JournalEntry]:
        return []

    assert isinstance(read_journal_entries, ReadJournalEntries)

# Generated at 2022-06-18 02:25:40.707288
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class _JournalEntry(JournalEntry):
        def __init__(self, date: date, description: str, source: object, postings: Iterable[Posting]):
            super().__init__(date, description, source, postings)


# Generated at 2022-06-18 02:26:24.458117
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    @dataclass(frozen=True)
    class PostingImpl(Posting):
        pass


# Generated at 2022-06-18 02:26:32.532653
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    from .journal import JournalEntry, Direction, Posting
    from .commons.zeitgeist import DateRange
    from datetime import date
    from typing import Iterable
    import pytest

    # Create a journal entry
    journal_entry = JournalEntry[str](date(2020, 1, 1), "Test Journal Entry", "Test Source")
    # Create an account
    account = Account("Test Account", AccountType.ASSETS)
    # Create a date
    date = date(2020, 1, 1)
    # Create a quantity
    quantity = Quantity(100)

    # Post an increment event to the account
    journal_entry.post(date, account, quantity)

    # Check that the journal entry has a posting

# Generated at 2022-06-18 02:26:43.321905
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger("Test Ledger", Currency("USD"))

    # Create accounts:
    ledger.add_account("Assets:Cash", AccountType.ASSETS)
    ledger.add_account("Expenses:Food", AccountType.EXPENSES)

    # Create a transaction:
    transaction = Transaction(ledger, "Test Transaction", datetime.date(2020, 1, 1))

    # Post to accounts:
    transaction.post(datetime.date(2020, 1, 1), ledger.get_account("Assets:Cash"), -100)

# Generated at 2022-06-18 02:26:46.614744
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        source: _T

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    assert issubclass(read_journal_entries.__class__, ReadJournalEntries)
    assert issubclass(read_journal_entries.__class__, ReadJournalEntries[JournalEntrySource])

# Generated at 2022-06-18 02:26:56.422987
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction
    from datetime import date
    from typing import List
    from dataclasses import field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: str

        #: Postings of the journal entry.

# Generated at 2022-06-18 02:27:07.363283
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction, Posting
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid

    # Create a journal entry
    journal = JournalEntry(date(2020, 1, 1), "Test Journal Entry", "Test Source")

    # Post a debit
    journal.post(date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))

    # Post a credit
    journal.post(date(2020, 1, 1), Account("Test Account", AccountType.EXPENSES), Quantity(-100))

    # Check the postings
    assert len(journal.postings) == 2
    assert journal.postings[0].journal == journal

# Generated at 2022-06-18 02:27:16.765771
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from .accounts import Account, AccountType

    # Setup:
    mock_source = Mock()

# Generated at 2022-06-18 02:27:25.904955
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger, LedgerType
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .commons.others import makeguid
    from .journal import JournalEntry, Direction, Posting
    from . import events
    from . import transactions
    from . import journal
    from . import accounts
    from . import ledgers
    from . import books
    from . import commons
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __doc__
    from . import __file__
    from . import __name__
    from . import __package__

# Generated at 2022-06-18 02:27:33.749736
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType

# Generated at 2022-06-18 02:27:41.818966
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry reader:
    def read_journal_entries(period: DateRange) -> List[JournalEntry[str]]:
        return [
            JournalEntry(date(2020, 1, 1), "Test", "Test", [
                Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                Posting(None, date(2020, 1, 1), Account("Test", AccountType.EQUITIES), Direction.DEC, Amount(100)),
            ]),
        ]

    # Test:
    assert isinstance(read_journal_entries, ReadJournalEntries)