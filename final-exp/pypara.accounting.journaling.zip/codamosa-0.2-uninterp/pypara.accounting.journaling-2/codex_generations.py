

# Generated at 2022-06-18 02:19:34.183321
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryIn

# Generated at 2022-06-18 02:19:45.378286
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger, ReadLedger
    from .transactions import Transaction, TransactionType

    # Create a ledger:
    ledger = Ledger(
        "Test Ledger",
        "Test Ledger",
        [
            Account(AccountType.ASSETS, "Cash", "Cash"),
            Account(AccountType.ASSETS, "Bank", "Bank"),
            Account(AccountType.EQUITIES, "Equity", "Equity"),
            Account(AccountType.REVENUES, "Revenue", "Revenue"),
            Account(AccountType.EXPENSES, "Expense", "Expense"),
        ],
    )

    # Create a transaction:

# Generated at 2022-06-18 02:19:53.077703
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets", AccountType.ASSETS))
    ledger.add_account(Account("Equities", AccountType.EQUITIES))
    ledger.add_account(Account("Liabilities", AccountType.LIABILITIES))
    ledger.add_account(Account("Revenues", AccountType.REVENUES))
    ledger.add_account(Account("Expenses", AccountType.EXPENSES))

    transaction = Transaction(ledger, datetime.date(2020, 1, 1), "Test Transaction")
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Assets"), +100)

# Generated at 2022-06-18 02:20:00.780070
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    #: Date of the entry.
    date = datetime.date(2019, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Account of the posting.
    account = Account("Test Account", AccountType.ASSETS)

    #: Direction of the posting.
    direction = Direction.INC

    #: Posted amount (in absolute value).
    amount = Amount(10)

    #

# Generated at 2022-06-18 02:20:12.177967
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    # Define a journal entry reader:

# Generated at 2022-06-18 02:20:18.195768
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
    from .accounts import AccountGroupCategoryType
   

# Generated at 2022-06-18 02:20:25.699201
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .commons.numbers import Amount, Quantity
    from .commons.others import makeguid
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Direction
    from .postings import Posting
    from .readers import ReadJournalEntries
    from .writers import WriteJournalEntries

    # Create a ledger
    ledger = Ledger()

    # Create a book
    book = Book(ledger)

    # Create a transaction
    transaction = Transaction(book)

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Post to the journal entry

# Generated at 2022-06-18 02:20:35.602627
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class Source:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[Source]):
        pass

    @dataclass(frozen=True)
    class Posting(Posting[Source]):
        pass


# Generated at 2022-06-18 02:20:45.583681
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeGroup
    from .transactions import TransactionTypeGroupCategory
    from .transactions import TransactionTypeGroupType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeUsage
    from .transactions import TransactionTypeUsageCategory
    from .transactions import TransactionTypeUsageType
    from .transactions import TransactionUsage
    from .transactions import TransactionUsageCategory
    from .transactions import TransactionUsageType
    from .transactions import TransactionUsageUsage
    from .transactions import TransactionUsageUsageCategory
    from .transactions import TransactionUsageUsageType
    from .transactions import TransactionUsageUsageUsage

# Generated at 2022-06-18 02:20:56.883377
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction
    from .ledgers import Ledger
    from .transactions import Transaction
    from .books import Book
    from datetime import date
    from dataclasses import dataclass
    from typing import List

    @dataclass(frozen=True)
    class TestTransaction(Transaction):
        pass

    ledger = Ledger()
    book = Book(ledger)

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestTransaction]):
        pass

    journal_entry = TestJournalEntry(date(2020, 1, 1), "Test Journal Entry", TestTransaction())


# Generated at 2022-06-18 02:21:05.254850
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    je.post(datetime.date(2020, 1, 1), Account("Assets:Cash"), Quantity(100))
    je.post(datetime.date(2020, 1, 1), Account("Expenses:Food"), Quantity(-100))

    # Act
    je.validate()

    # Assert
    # No exception is raised

# Generated at 2022-06-18 02:21:17.168516
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Entertainment", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))
    ledger.add_account(Account("Equities:Opening Balances", AccountType.EQUITIES))

    transaction = Transaction(TransactionType.EXPENSE, "Food", datetime.date(2020, 1, 1))

# Generated at 2022-06-18 02:21:28.480237
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase
    from unittest.mock import Mock, call

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Setup:
            mock_journal_entry = Mock(JournalEntry)
            mock_read_journal_entries = Mock(ReadJournalEntries)
            mock_read_journal_entries.__call__.return_value = [mock_journal_entry]
            mock_date_range = Mock(DateRange)

            # Exercise:
            result = mock_read_journal_entries(mock_date_range)

            # Verify:
            self.assertEqual(result, [mock_journal_entry])

# Generated at 2022-06-18 02:21:38.960555
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a posting:
    @dataclass(frozen=True)
    class PostingImpl(Posting):
        pass

    # Define a journal entry reader:

# Generated at 2022-06-18 02:21:44.507707
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .commons.numbers import Amount, Quantity

    # Create a journal entry
    je = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=None,
    )

    # Post a debit and credit
    je.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.ASSETS), Quantity(100))
    je.post(datetime.date(2020, 1, 1), Account("Test Account", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry
    je.validate()

    # Post a debit and credit with different amounts

# Generated at 2022-06-18 02:21:55.690608
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledger import Ledger
    from .transactions import Transaction
    from .commons.numbers import Amount, Quantity

    # Create a business
    business = Business("Test Business")

    # Create a ledger for the business
    ledger = Ledger(business)

    # Create an account for the ledger
    account = Account(ledger, "Test Account", AccountType.ASSETS)

    # Create a transaction for the ledger
    transaction = Transaction(ledger, "Test Transaction")

    # Create a journal entry for the transaction
    journal_entry = JournalEntry(datetime.date.today(), "Test Journal Entry", transaction)

    # Post an amount to the account
    journal_entry.post(datetime.date.today(), account, Quantity(100))

    # Validate the

# Generated at 2022-06-18 02:22:04.095748
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Setup:
            journal_entries: List[JournalEntry[int]] = [
                JournalEntry(date(2020, 1, 1), "Test", 1),
                JournalEntry(date(2020, 1, 2), "Test", 2),
                JournalEntry(date(2020, 1, 3), "Test", 3),
            ]
            journal_entries[0].post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), +100)

# Generated at 2022-06-18 02:22:12.039518
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Create a journal entry
    je = JournalEntry[int](date=datetime.date.today(), description="Test", source=1)
    # Post a debit and credit
    je.post(date=datetime.date.today(), account=Account(type=AccountType.ASSETS, name="Cash"), quantity=100)
    je.post(date=datetime.date.today(), account=Account(type=AccountType.REVENUES, name="Sales"), quantity=-100)
    # Validate the journal entry
    je.validate()

# Generated at 2022-06-18 02:22:16.775829
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from datetime import date

    # Create a journal entry
    journal_entry = JournalEntry[int](date(2020, 1, 1), "Test", 1)
    journal_entry.post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), Quantity(100))
    journal_entry.post(date(2020, 1, 1), Account("Revenues", AccountType.REVENUES), Quantity(-100))

    # Validate the journal entry
    journal_entry.validate()

# Generated at 2022-06-18 02:22:28.552721
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    #: Date of the entry.
    date: datetime.date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description: str = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source: _T = "Test Source"

    #: Postings of the journal entry.
    postings: List[Posting[_T]] = field(default_factory=list, init=False)

    #: Globally unique, ephemeral identifier.

# Generated at 2022-06-18 02:22:45.841863
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account("Assets:Cash", AccountType.ASSETS))
    ledger.add_account(Account("Expenses:Food", AccountType.EXPENSES))
    ledger.add_account(Account("Expenses:Travel", AccountType.EXPENSES))
    ledger.add_account(Account("Revenues:Sales", AccountType.REVENUES))


# Generated at 2022-06-18 02:22:55.587070
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()

    # Create accounts:
    ledger.create_account(Account("Cash", AccountType.ASSETS))
    ledger.create_account(Account("Equity", AccountType.EQUITIES))
    ledger.create_account(Account("Revenue", AccountType.REVENUES))
    ledger.create_account(Account("Expense", AccountType.EXPENSES))

    # Create transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=None,
    )

    # Post to accounts:
    transaction.post(datetime.date(2020, 1, 1), ledger.get_account("Cash"), +100)
    transaction

# Generated at 2022-06-18 02:23:05.580481
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account, AccountType
    from ..books.journals import JournalEntry, Direction
    from ..books.ledgers import Ledger
    from ..books.transactions import Transaction
    from ..books.transactions.accounts import AccountTransaction
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType
    from ..books.transactions.accounts import AccountTransactionType

# Generated at 2022-06-18 02:23:17.198660
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType


# Generated at 2022-06-18 02:23:28.637520
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            journal_entry_1 = JournalEntry(date(2020, 1, 1), "Test", None)
            journal_entry_2 = JournalEntry(date(2020, 1, 2), "Test", None)
            journal_entry_3 = JournalEntry(date(2020, 1, 3), "Test", None)
            journal_entry_4 = JournalEntry(date(2020, 1, 4), "Test", None)
            journal_entry_5 = JournalEntry(date(2020, 1, 5), "Test", None)
            journal_

# Generated at 2022-06-18 02:23:36.789064
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction type:
    transaction_type = TransactionType(
        name="Sale",
        category=TransactionTypeCategory.SALE,
        debit_account=ledger.accounts.get(AccountType.REVENUES),
        credit_account=ledger.accounts.get(AccountType.ASSETS),
    )

    # Create a transaction:

# Generated at 2022-06-18 02:23:46.441264
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account
    from .accounts import Account

# Generated at 2022-06-18 02:24:06.272057
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event
    from .events import EventType
    from .events import EventTypeCategory
    from .events import EventTypeCategoryType
    from .events import EventTypeCategoryTypeType
    from .events import EventTypeCategoryTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeTypeTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeTypeTypeTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeTypeTypeTypeTypeTypeType
    from .events import EventTypeCategoryTypeTypeTypeTypeTypeType

# Generated at 2022-06-18 02:24:14.784918
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return []

    test_read_journal_entries = TestReadJournalEntries()

    class TestCase(TestCase):
        def test_ReadJournalEntries___call__(self):
            test_read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

    TestCase().test_ReadJournalEntries___call__()

# Generated at 2022-06-18 02:24:23.770195
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:24:47.940105
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:24:57.299584
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction
    from datetime import date

    @dataclass(frozen=True)
    class BusinessObject:
        pass


# Generated at 2022-06-18 02:25:06.787873
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    #: Defines a type variable.
    _T = Transaction

    #: Defines a type variable.
    _U = JournalEntry[_T]

    #: Defines a type variable.
    _V = Ledger

    #: Defines a type variable.
    _W = TransactionType

    #: Defines a type variable.
    _X = TransactionTypeCategory

    #: Defines a type variable.
    _Y = Account

    #: Defines a type variable.
    _Z = AccountType

    #: Defines a type variable.
    _A = ReadJournalEntries

# Generated at 2022-06-18 02:25:17.873936
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .books import Book
    from .books import BookEntry
    from .books import BookEntryType
    from .books import BookType
    from .books import PostingRule
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import PostingRuleType
    from .books import Posting

# Generated at 2022-06-18 02:25:28.376603
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class TestSource:
        pass

    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry[TestSource]):
        pass

    @dataclass(frozen=True)
    class TestPosting(Posting[TestSource]):
        pass


# Generated at 2022-06-18 02:25:36.537673
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from datetime import date

    # Create a journal entry
    journal = JournalEntry(date(2020, 1, 1), "Test Journal Entry", "Test Source")

    # Add postings to the journal entry
    journal.post(date(2020, 1, 1), Account("Test Account 1", AccountType.ASSETS), Quantity(100))
    journal.post(date(2020, 1, 1), Account("Test Account 2", AccountType.REVENUES), Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Add another posting to the journal entry

# Generated at 2022-06-18 02:25:44.977542
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger, LedgerEntry
    from .transactions import Transaction, TransactionEntry

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        source=TransactionEntry(
            account=ledger.account(AccountType.ASSETS, "Cash"),
            quantity=Quantity(100),
        ),
        target=TransactionEntry(
            account=ledger.account(AccountType.EXPENSES, "Food"),
            quantity=Quantity(100),
        ),
    )

    # Create a journal entry:

# Generated at 2022-06-18 02:25:55.788492
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class JournalEntry(Generic[_T]):
        def __init__(self, date: date, description: str, source: _T, postings: List[Posting[_T]]):
            self.date = date
            self.description = description
            self.source = source
            self.postings = postings

    class Posting(Generic[_T]):
        def __init__(self, journal: JournalEntry[_T], date: date, account: Account, direction: Direction, amount: int):
            self.journal = journal
            self.date = date
            self.account = account
            self.direction = direction
            self.amount = amount


# Generated at 2022-06-18 02:26:06.447336
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    def test_ReadJournalEntries___call__(self):
        mock_journal_entry = Mock(JournalEntry)
        mock_journal_entry.date = date(2020, 1, 1)
        mock_journal_entry.description = "Test"
        mock_journal_entry.source = "Test"

# Generated at 2022-06-18 02:26:16.061436
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry[Transaction]()

    # Create a read journal entries function:
    read_journal_entries = ReadJournalEntries[Transaction]()

    # Create a period:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))

    # Create an account:
    account = Account(AccountType.ASSETS, "Cash")

   

# Generated at 2022-06-18 02:27:15.306806
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import ZERO
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test Transaction",
        type=TransactionType.EXPENSE,
        ledger=ledger,
    )

    # Create a journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry",
        source=transaction,
    )

    # Create an account:

# Generated at 2022-06-18 02:27:24.822015
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType


# Generated at 2022-06-18 02:27:33.376521
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book(
        name="Test Book",
        currency=Currency.USD,
        ledger=Ledger(
            name="Test Ledger",
            accounts=[
                Account(name="Cash", type=AccountType.ASSETS),
                Account(name="Equity", type=AccountType.EQUITIES),
                Account(name="Revenue", type=AccountType.REVENUES),
                Account(name="Expense", type=AccountType.EXPENSES),
            ],
        ),
    )

    # Create a journal entry:
   

# Generated at 2022-06-18 02:27:41.686011
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:27:50.186918
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger

    # Define a ledger:
    ledger = Ledger()

    # Define a journal entry:
    journal_entry = JournalEntry(date(2020, 1, 1), "Test", None)

    # Define a posting:
    posting = Posting(journal_entry, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(Quantity(100)))

    # Define a read function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return [journal_entry]

    # Define a read journal entries:
   

# Generated at 2022-06-18 02:27:55.323311
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    class Test(TestCase):
        def test_empty(self):
            def read_journal_entries(period: DateRange) -> List[JournalEntry[None]]:
                return []

            self.assertEqual(list(read_journal_entries(DateRange(date(2020, 1, 1), date(2020, 1, 31)))), [])


# Generated at 2022-06-18 02:28:04.633564
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory

    # Create a business
    business = Business(
        name="Test Business",
        ledger=Ledger(
            name="Test Ledger",
            accounts=[
                Account(
                    name="Test Account",
                    type=AccountType.ASSETS,
                    ledger=Ledger(name="Test Ledger"),
                ),
            ],
        ),
    )

    # Create a transaction type
    transaction_type = TransactionType(
        name="Test Transaction Type",
        category=TransactionTypeCategory.INCOME,
        ledger=Ledger(name="Test Ledger"),
    )

    # Create a transaction

# Generated at 2022-06-18 02:28:14.514929
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountGroupType
    from .accounts import AccountGroupCategory
    from .accounts import AccountGrouping
    from .accounts import AccountGroupingType
    from .accounts import AccountGroupingCategory
    from .accounts import AccountGroupingCategoryType
    from .accounts import AccountGroupingCategoryTypeCategory
    from .accounts import AccountGroupingCategoryTypeCategoryType
    from .accounts import AccountGroupingCategoryTypeCategoryTypeType
    from .accounts import AccountGroupingCategoryTypeCategoryTypeTypeType
    from .accounts import AccountGroupingCategoryTypeCategoryTypeTypeTypeType
    from .accounts import AccountGroupingCategoryTypeCategoryTypeType

# Generated at 2022-06-18 02:28:23.224023
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .business import Business
    from .currencies import Currency
    from .ledgers import Ledger
    from .transactions import Transaction

    ledger = Ledger()
    ledger.add_account(Account(AccountType.ASSETS, "Cash", Currency.USD))
    ledger.add_account(Account(AccountType.EXPENSES, "Rent", Currency.USD))
    ledger.add_account(Account(AccountType.REVENUES, "Sales", Currency.USD))

    business = Business("Test Business", ledger)

    transaction = Transaction(business, datetime.date(2020, 1, 1), "Test Transaction")
    transaction.post(datetime.date(2020, 1, 1), ledger.account("Cash"), +100)

# Generated at 2022-06-18 02:28:31.927030
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account, AccountType
    from .commons import Currency
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    journal_entry = JournalEntry(date(2020, 1, 1), "Test Journal Entry", None)
    journal_entry.post(date(2020, 1, 1), Account("Assets", AccountType.ASSETS), +100)
    journal_entry.post(date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), -100)

    # Define a read journal entries function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [journal_entry]

    # Test the read journal entries function: