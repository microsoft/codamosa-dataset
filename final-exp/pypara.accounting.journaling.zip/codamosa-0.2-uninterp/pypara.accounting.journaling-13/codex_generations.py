

# Generated at 2022-06-18 02:19:39.911184
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry

    # Create a journal entry
    je = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", None)

    # Post a debit and credit
    je.post(datetime.date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Quantity(100))
    je.post(datetime.date(2020, 1, 1), Account("Expenses:Food", AccountType.EXPENSES), Quantity(-100))

    # Validate the journal entry
    je.validate()

# Generated at 2022-06-18 02:19:49.641114
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .commons import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .numbers import Amount, Quantity

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        date: date
        description: str
        source: str
        postings: List[Posting] = field(default_factory=list, init=False)

    # Define a read journal entries function:

# Generated at 2022-06-18 02:19:55.036899
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import DateRange
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryImpl
    from .accounts import AccountTree
    from .accounts import AccountTreeImpl
    from .accounts import AccountTreeRepository
    from .accounts import AccountTreeRepositoryImpl
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemoryImpl
    from .accounts import AccountTreeRepositoryInMemoryImpl
    from .accounts import AccountTreeRepositoryInMemoryImpl
    from .accounts import AccountTreeRepositoryInMemoryImpl
    from .accounts import AccountTreeRepositoryInMemoryImpl
    from .accounts import AccountTreeRepositoryInMemoryImpl
    from .accounts import AccountTreeRep

# Generated at 2022-06-18 02:20:01.990904
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    # Create a journal entry
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test", source=None)

    # Create an account
    account = Account(type=AccountType.ASSETS, name="Test", description="Test")

    # Post a quantity to the account
    journal_entry.post(date=datetime.date(2020, 1, 1), account=account, quantity=Quantity(100))

    # Check the posting

# Generated at 2022-06-18 02:20:12.175997
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    # Create a journal entry
    journal_entry = JournalEntry[int](date=datetime.date(2020, 1, 1), description="Test", source=1)

    # Create an account
    account = Account(name="Test", type=AccountType.ASSETS)

    # Post an amount to the account
    journal_entry.post(date=datetime.date(2020, 1, 1), account=account, quantity=100)

    # Check the postings
    assert len(journal_entry.postings) == 1
    assert journal_entry.postings[0].date == datetime.date(2020, 1, 1)
    assert journal_entry.postings[0].account == account
    assert journal_entry.postings[0].direction == Direction.INC

# Generated at 2022-06-18 02:20:22.954058
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .journal import JournalEntry
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger("Test Ledger")

    # Create a transaction:
    transaction = Transaction("Test Transaction")

    # Create a journal entry:
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Create accounts:
    account_1 = Account("Test Account 1", AccountType.ASSETS, ledger, Currency.USD)
    account_2 = Account("Test Account 2", AccountType.ASSETS, ledger, Currency.USD)
    account_3 = Account("Test Account 3", AccountType.ASSETS, ledger, Currency.USD)

# Generated at 2022-06-18 02:20:33.061850
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    # Arrange:
    mock = Mock(spec=ReadJournalEntries)
    mock.__call__.return_value = [
        JournalEntry(date(2020, 1, 1), "Test", None),
        JournalEntry(date(2020, 1, 2), "Test", None),
        JournalEntry(date(2020, 1, 3), "Test", None),
    ]

    # Act:
    result = mock(DateRange(date(2020, 1, 1), date(2020, 1, 2)))

    # Assert:
    assert len(result) == 2

# Generated at 2022-06-18 02:20:43.892414
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries
    from .commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass


# Generated at 2022-06-18 02:20:55.220006
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries
    from .ledgers import Ledger, LedgerType

    # Create a ledger:
    ledger = Ledger(
        name="Test Ledger",
        description="Test Ledger",
        type=LedgerType.GENERAL,
        accounts=[
            Account(name="Cash", type=AccountType.ASSETS),
            Account(name="Sales", type=AccountType.REVENUES),
            Account(name="Sales Tax", type=AccountType.EXPENSES),
        ],
    )

    # Create a journal entry:
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test Journal Entry")

    # Post to the ledger:
    journal_

# Generated at 2022-06-18 02:21:02.317203
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountManager
    from .accounts import AccountManagerFactory
    from .accounts import AccountManagerFactoryImpl
    from .accounts import AccountManagerImpl
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import AccountType
    from .accounts import Account

# Generated at 2022-06-18 02:21:20.580808
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            mock_source = Mock()

# Generated at 2022-06-18 02:21:26.480767
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    mock = Mock(spec=ReadJournalEntries)
    mock(DateRange(date(2020, 1, 1), date(2020, 1, 31)))
    mock.assert_called_once_with(DateRange(date(2020, 1, 1), date(2020, 1, 31)))

# Generated at 2022-06-18 02:21:37.160640
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a book:
    book = Book()

    # Create a ledger:
    ledger = Ledger(book)

    # Create a transaction:
    transaction = Transaction(ledger, date=datetime.date(2020, 1, 1), description="Test transaction")

    # Create a journal entry:
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test journal entry")

    # Create an account:
    account = Account(book, name="Test account", type=AccountType.ASSETS)

    # Post to the account:
    journal_

# Generated at 2022-06-18 02:21:43.631007
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .journal import JournalEntry, Posting, Direction

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Journal entry the posting belongs to.
    journal = JournalEntry(date, description, source, postings, guid)

    #: Date of posting.
    date = datetime.date(2020, 1, 1)

    #

# Generated at 2022-06-18 02:21:54.746512
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger
    ledger = Ledger()

    # Create a journal entry
    journal = JournalEntry[Transaction](datetime.date(2020, 1, 1), "Test", Transaction(makeguid()))

    # Post to the journal entry
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), Quantity(-100))

    # Validate the journal entry
    journal.validate()

    # Post the journal entry to the ledger

# Generated at 2022-06-18 02:22:03.473716
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, Direction

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Account of the posting.
    account = Account("Test Account", AccountType.ASSETS)

    #: Quantity of the posting.
    quantity = Quantity(100)

    #: Direction of the posting

# Generated at 2022-06-18 02:22:14.622201
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
                return [
                    JournalEntry(date(2020, 1, 1), "Test", "Test", [
                        Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                        Posting(None, date(2020, 1, 1), Account("Test", AccountType.REVENUES), Direction.DEC, Amount(100)),
                    ]),
                ]

            assert read_journal_

# Generated at 2022-06-18 02:22:27.131489
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .currencies import Currency
    from .events import Event
    from .transactions import Transaction
    from .users import User

    book = Book(
        name="Test Book",
        currency=Currency.USD,
        users=[User(name="Test User")],
        accounts=[
            Account(name="Cash", type=AccountType.ASSETS),
            Account(name="Equity", type=AccountType.EQUITIES),
            Account(name="Revenue", type=AccountType.REVENUES),
            Account(name="Expense", type=AccountType.EXPENSES),
            Account(name="Liability", type=AccountType.LIABILITIES),
        ],
    )


# Generated at 2022-06-18 02:22:34.497703
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger
    from .transactions import Transaction

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(ledger)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post to the journal entry:
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), +100)
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales"), -100)

   

# Generated at 2022-06-18 02:22:44.067302
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable
    from unittest import TestCase, main
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            mock = Mock(spec=ReadJournalEntries[str])
            mock.__call__.return_value = [
                JournalEntry(date(2020, 1, 1), "A", "A"),
                JournalEntry(date(2020, 1, 2), "B", "B"),
                JournalEntry(date(2020, 1, 3), "C", "C"),
            ]

            # Act:
            result = mock(DateRange(date(2020, 1, 1), date(2020, 1, 2)))

            # Ass

# Generated at 2022-06-18 02:23:02.708987
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .transactions import Transaction

    ## Setup:
    ledger = Ledger()
    ledger.add_account(Account("Cash", AccountType.ASSETS))
    ledger.add_account(Account("Revenue", AccountType.REVENUES))
    ledger.add_account(Account("Expense", AccountType.EXPENSES))

    ## Test:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Transaction]]:
        return ledger.read_journal_entries(period)

    assert isinstance(read_journal_entries, ReadJournalEntries)

# Generated at 2022-06-18 02:23:08.654786
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction

    #: Defines a sample book.
    book = Book(
        "Sample",
        Ledger(
            "Sample",
            [
                Account(AccountType.ASSETS, "Cash"),
                Account(AccountType.EQUITIES, "Equity"),
                Account(AccountType.EXPENSES, "Expenses"),
                Account(AccountType.LIABILITIES, "Liabilities"),
                Account(AccountType.REVENUES, "Revenues"),
            ],
        ),
    )

    #: Defines a sample transaction.

# Generated at 2022-06-18 02:23:12.635436
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)

# Generated at 2022-06-18 02:23:19.813581
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountTypeRepository
    from .accounts import AccountTypeRepositoryInMemory
    from .accounts import AccountTypeTree
    from .accounts import AccountTypeTreeInMemory
    from .accounts import AccountTypeTreeRepository
    from .accounts import AccountTypeTreeRepositoryInMemory
    from .accounts import AccountTree
    from .accounts import AccountTreeInMemory
    from .accounts import AccountTreeRepository
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryInMemory
    from .accounts import AccountTreeRepositoryIn

# Generated at 2022-06-18 02:23:25.990626
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry
    from .ledgers import Ledger, LedgerEntry
    from .transactions import Transaction, TransactionEntry

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(
        date=datetime.date(2020, 1, 1),
        description="Test transaction",
        source=TransactionEntry(
            account=ledger.account(AccountType.ASSETS, "Cash"),
            quantity=Quantity(100),
        ),
        target=TransactionEntry(
            account=ledger.account(AccountType.EXPENSES, "Food"),
            quantity=Quantity(100),
        ),
    )

    # Create a journal entry:

# Generated at 2022-06-18 02:23:31.433004
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(datetime.date(2020, 1, 1), "Test", "Test", [])
    j.post(datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(100))
    j.post(datetime.date(2020, 1, 1), Account("Test", AccountType.EXPENSES), Quantity(-100))
    j.validate()

# Generated at 2022-06-18 02:23:39.527491
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .business import Business
    from .ledgers import Ledger
    from .books import Book
    from .accounts import Account
    from .accounts import AccountType
    from .currencies import Currency
    from .business import Business
    from .ledgers import Ledger
    from .books import Book
    from .accounts import Account
    from .accounts import AccountType
    from .currencies import Currency
    from .business import Business
    from .ledgers import Ledger
    from .books import Book
    from .accounts import Account
    from .accounts import AccountType
    from .currencies import Currency
    from .business import Business
    from .ledgers import Ledger
    from .books import Book
    from .accounts import Account

# Generated at 2022-06-18 02:23:43.964302
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from .accounts import Account, AccountType
    from .journal import JournalEntry, ReadJournalEntries, Direction
    from .commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class Source:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry[Source]):
        pass

    @dataclass(frozen=True)
    class Posting(Posting[Source]):
        pass


# Generated at 2022-06-18 02:23:49.318085
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountTypeCategory
    from .accounts import AccountTypeSubCategory
    from .accounts import AccountTypeSubSubCategory
    from .accounts import AccountTypeSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSubSubSubSubSubCategory
    from .accounts import AccountTypeSubSubSubSubSub

# Generated at 2022-06-18 02:24:06.219979
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a ledger:
    ledger = Ledger()

    # Create a transaction:
    transaction = Transaction(TransactionType.EXPENSE, "Test Transaction", ledger.accounts.expense)

    # Create a journal entry:
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", transaction)

    # Post a debit and a credit:
    journal_entry.post(datetime.date(2020, 1, 1), ledger.accounts.expense, Quantity(100))
    journal_entry

# Generated at 2022-06-18 02:24:33.722792
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase, main

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, AccountType

    class TestReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> List[JournalEntry[str]]:
            return [
                JournalEntry(date(2020, 1, 1), "Test", "Test", [
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100)),
                    Posting(None, date(2020, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(100)),
                ]),
            ]


# Generated at 2022-06-18 02:24:40.943200
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import dataclass
    from typing import Iterable

    @dataclass
    class _T:
        pass

    @dataclass
    class _JournalEntry(_T):
        pass

    @dataclass
    class _ReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [_JournalEntry()]

    assert _ReadJournalEntries()(DateRange(date(2020, 1, 1), date(2020, 1, 31))) == [_JournalEntry()]

# Generated at 2022-06-18 02:24:48.278887
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import AccountSubGroup
    from .accounts import AccountSubSubGroup
    from .accounts import AccountSubSubSubGroup
    from .accounts import AccountSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSubSubSubSubSubSubSubSubSubSubGroup
    from .accounts import AccountSub

# Generated at 2022-06-18 02:24:57.397160
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal import JournalEntry, Posting, ReadJournalEntries


# Generated at 2022-06-18 02:25:05.506192
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    journal = JournalEntry(datetime.date.today(), "Test", None)
    account = Account("Test Account", AccountType.ASSETS)
    quantity = Quantity(100)

    # Act
    journal.post(datetime.date.today(), account, quantity)

    # Assert
    assert len(journal.postings) == 1
    assert journal.postings[0].date == datetime.date.today()
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Amount(100)

# Generated at 2022-06-18 02:25:16.643207
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .readjournalentries import ReadJournalEntries
    from .transactions import Transaction
    from .transactions.readtransactions import ReadTransactions

    # Define a read journal entries function:

# Generated at 2022-06-18 02:25:21.797717
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountId
    from .accounts import AccountName
    from .accounts import AccountDescription
    from .accounts import AccountCategory
    from .accounts import AccountSubCategory
    from .accounts import AccountGroup
    from .accounts import AccountTags
    from .accounts import AccountMetaData
    from .accounts import AccountReference
    from .accounts import AccountStatus
    from .accounts import AccountCurrency
    from .accounts import AccountBalance
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountId
    from .accounts import AccountName
    from .accounts import AccountDescription
    from .accounts import AccountCategory
    from .accounts import AccountSubCategory
   

# Generated at 2022-06-18 02:25:31.450053
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .business import Business
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions.transaction import TransactionType
    from .transactions.transaction_types import TransactionTypes
    from .transactions.transaction_types.transaction_type import TransactionTypeCategory

    # Create a ledger
    ledger = Ledger()

    # Create a business
    business = Business(name="Test Business", ledger=ledger)

    # Create a transaction type
    transaction_type = TransactionType(
        name="Test Transaction Type",
        category=TransactionTypeCategory.INCOME,
        ledger=ledger,
        business=business,
    )

    # Create a transaction

# Generated at 2022-06-18 02:25:37.434581
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType

    # Create a book
    book = Book()

    # Create a ledger
    ledger = Ledger(book)

    # Create a transaction
    transaction = Transaction(TransactionType.PURCHASE, datetime.date(2020, 1, 1), "Purchase")

    # Create a journal entry
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Purchase")

    # Create an account
    account = Account(AccountType.ASSETS, "Cash")

    # Post to the journal entry
    journal_entry.post(datetime.date(2020, 1, 1), account, 1000)

    # Post the journal entry to the ledger
    ledger

# Generated at 2022-06-18 02:25:45.160500
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Direction, Posting

    # Create a journal entry
    journal_entry = JournalEntry(date=datetime.date(2019, 1, 1), description="Test Journal Entry", source="Test Source")

    # Post a debit and credit to the journal entry
    journal_entry.post(date=datetime.date(2019, 1, 1), account=Account(name="Test Account", type=AccountType.ASSETS), quantity=Quantity(100))
    journal_entry.post(date=datetime.date(2019, 1, 1), account=Account(name="Test Account", type=AccountType.REVENUES), quantity=Quantity(-100))

    # Validate the journal entry


# Generated at 2022-06-18 02:26:29.129186
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    #: Date of the entry.
    date = datetime.date(2020, 1, 1)

    #: Description of the entry.
    description = "Test Journal Entry"

    #: Business object as the source of the journal entry.
    source = "Test Source"

    #: Globally unique, ephemeral identifier.
    guid = makeguid()

    #: Postings of the journal entry.
    postings = []

    #: Journal entry the posting belongs to.
    journal = JournalEntry(date, description, source, postings, guid)

    #: Date of posting.
    date = datetime.date(2020, 1, 1)

# Generated at 2022-06-18 02:26:33.849271
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.accounts import Account, AccountType
    from ..books.ledgers import Ledger
    from ..books.transactions import Transaction
    from ..books.transactions import TransactionType
    from ..books.transactions import TransactionPosting
    from ..books.transactions import TransactionPostingRule
    from ..books.transactions import TransactionPostingRuleSet
    from ..books.transactions import TransactionPostingRuleSetType
    from ..books.transactions import TransactionPostingRuleType
    from ..books.transactions import TransactionPostingRuleValue
    from ..books.transactions import TransactionPostingRuleValueType
    from ..books.transactions import TransactionPostingRuleValueType
    from ..books.transactions import TransactionPostingRuleValueType
    from ..books.transactions import TransactionPostingRuleValueType
    from ..books.transactions import TransactionPostingRule

# Generated at 2022-06-18 02:26:44.456153
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountRepository
    from .accounts import AccountRepositoryInMemory
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl
    from .accounts import AccountRepositoryInMemoryImpl

# Generated at 2022-06-18 02:26:50.223253
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class TestReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return Mock(Iterable[JournalEntry[_T]])

    class TestReadJournalEntriesTest(TestCase):
        def test_ReadJournalEntries___call__(self):
            read_journal_entries = TestReadJournalEntries()
            period = DateRange(date(2020, 1, 1), date(2020, 1, 31))
            read_journal_entries(period)

# Generated at 2022-06-18 02:26:58.067072
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class MockJournalEntry(JournalEntry[None]):
        guid: str = field(default_factory=makeguid)

    @dataclass(frozen=True)
    class MockPosting(Posting[None]):
        guid: str = field(default_factory=makeguid)


# Generated at 2022-06-18 02:27:07.748144
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class _T:
        pass

    @dataclass(frozen=True)
    class _JournalEntry(JournalEntry[_T]):
        pass

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [_JournalEntry(date=datetime.date(2020, 1, 1), description="", source=_T())]

    assert _read_journal_entries(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))[0].date == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 02:27:15.589840
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journal import JournalEntry

    # Create a journal entry
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)

    # Post a debit
    je.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(100))

    # Post a credit
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EXPENSES, "Rent"), Quantity(-100))

    # Validate the journal entry
    je.validate()

# Generated at 2022-06-18 02:27:24.831926
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import List
    from unittest import TestCase
    from unittest.mock import Mock
    from ..commons.zeitgeist import DateRange

    class Test(TestCase):
        def test_ReadJournalEntries___call__(self):
            # Arrange:
            mock = Mock(spec=ReadJournalEntries)
            mock.__call__.return_value = [JournalEntry(date(2020, 1, 1), "", None)]

            # Act:
            actual = mock(DateRange(date(2020, 1, 1), date(2020, 1, 2)))

            # Assert:
            self.assertIsInstance(actual, List)
            self.assertEqual(1, len(actual))
            self.assertIsInstance(actual[0], JournalEntry)

    Test().test_Read

# Generated at 2022-06-18 02:27:33.116630
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Iterable
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting, ReadJournalEntries

    # Define a journal entry:
    @dataclass(frozen=True)
    class JournalEntryImpl(JournalEntry):
        pass

    # Define a read journal entries function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntryImpl]:
        yield JournalEntryImpl(date(2020, 1, 1), "Test", None, [Posting(None, date(2020, 1, 1), Account("Test", AccountType.ASSETS), Direction.INC, Amount(100))])

    # Test:
    assert isinstance(read_journal_entries, ReadJournalEntries)

# Generated at 2022-06-18 02:27:41.654268
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from .accounts import Account
    from .journal import JournalEntry, Direction
    from .ledgers import Ledger
    from .transactions import Transaction
    from .transactions import TransactionType
    from .transactions import TransactionTypeCategory
    from .transactions import TransactionTypeGroup
    from .transactions import TransactionTypeGroupCategory
    from .transactions import TransactionTypeGroupType
    from .transactions import TransactionTypeType
    from .transactions import TransactionTypeUsage
    from .transactions import TransactionTypeUsageCategory
    from .transactions import TransactionTypeUsageType
    from .transactions import TransactionTypeUsageUsage
    from .transactions import TransactionTypeUsageUsageCategory
    from .transactions import TransactionTypeUsageUsageType
    from .transactions import TransactionTypeUsageUsage