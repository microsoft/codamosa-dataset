

# Generated at 2022-06-21 20:01:22.308718
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from .currencies import Currency
    from .enums import TransactionType
    from .tags import Tag
    from .trades import (
        BuySell,
        Commission,
        Dividend,
        Fee,
        Income,
        Split,
        Trade,
    )
    from .transactions import Transaction

    # Define some test values:
    date = datetime.date(2020, 1, 1)
    date0 = datetime.date(2000, 1, 1)
    date1 = datetime.date(2001, 1, 1)
    date2 = datetime.date(2002, 1, 1)
    date3 = datetime.date(2003, 1, 1)
    date4 = datetime.date(2004, 1, 1)
    description = "Description"
    description0 = "Description0"

# Generated at 2022-06-21 20:01:27.134113
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class C:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    C()

# Generated at 2022-06-21 20:01:37.811001
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    It is possible to initialize an instance of JournalEntry as a mutable record.
    """
    journal_entry = JournalEntry[int](date=datetime.date(2017, 3, 2), description="", source=1)
    journal_entry.guid = "123e4567-e89b-12d3-a456-426655440000"
    journal_entry.postings = [Posting(journal_entry, datetime.date(2017, 3, 2), Account.new(code="1001", type="ASSETS"), Direction.INC, Amount(100))]
    assert journal_entry.guid == "123e4567-e89b-12d3-a456-426655440000"
    # Freeze the instance

# Generated at 2022-06-21 20:01:48.960432
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Account1:
        """
        Some random class.
        """

    class Account2:
        """
        Some random class.
        """

    class Account3:
        """
        Some random class.
        """

    assert ReadJournalEntries.__call__.__annotations__ == {'period': DateRange, 'return': Iterable[JournalEntry[_T]]}
    assert ReadJournalEntries.__call__.__doc__ == None

    assert ReadJournalEntries[Account1].__call__.__annotations__ == {
        'period': DateRange, 'return': Iterable[JournalEntry[Account1]]
    }
    assert ReadJournalEntries[Account1].__call__.__doc__ == None


# Generated at 2022-06-21 20:01:59.761421
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from .portfolio import Stock, StockEmission

    stock = Stock(
        code="HUL",
        emission=StockEmission.of(code="HUL", description="HUL Ltd"),
        quantity=Quantity(10),
        price=Amount(1000),
        date=date(2020, 8, 8),
    )
    journal_entry = JournalEntry(date=stock.date, description="Purchase of shares", source=stock)

    # Expecting an AttributeError exception to be raised when trying to assign a value to an immutable instance.
    try:
        journal_entry.postings = []
    except AttributeError as exp:
        assert exp.args[0] == "can't set attribute"
    else:
        assert False

# Generated at 2022-06-21 20:02:12.616599
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    import datetime
    from pfrock.domain.accounts import G_L_Account, AccountType
    @dataclass(frozen=True)
    class G_L_Object:
        #: Globally unique, (persisted) identifier.
        guid: Guid

    # CUT
    entry1 = JournalEntry(datetime.date(2019, 1, 1), "Entry 1", G_L_Object("guid-1"), [
        Posting(entry1, datetime.date(2019, 1, 1), G_L_Account("A1", AccountType.ASSETS), Direction.INC, Amount(100)),
        Posting(entry1, datetime.date(2019, 1, 1), G_L_Account("A2", AccountType.REVENUES), Direction.DEC, Amount(100)),
    ])
    entry2 = JournalEntry

# Generated at 2022-06-21 20:02:13.253754
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-21 20:02:17.473062
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry[int](date=datetime.date(2017, 1, 1), description="Test", source=1) == JournalEntry[int](date=datetime.date(2017, 1, 1), description="Test", source=1)

# Generated at 2022-06-21 20:02:21.594192
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from .accounts import EquityAccount, Account
    from .accounts import AccountMetaType
    from dataclasses import dataclass
    from abc import ABC, abstractmethod
    
    @dataclass
    class X:
        pass
    
    x = X()
    
    y = Posting(x, date(2020,9,24), EquityAccount('x'), Direction.INC, Amount(10))



# Generated at 2022-06-21 20:02:24.068272
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # AutoTutor: exclude_post_test
    a = ReadJournalEntries()
    a.assert_callable()

# Generated at 2022-06-21 20:02:32.656496
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    """
    Tests the constructor of class JournalEntry
    :return:
    """
    class Test:
        pass
    test = Test()
    je = JournalEntry(test, 'Test', test, [])
    assert not je.postings



# Generated at 2022-06-21 20:02:37.211111
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Asset
    from .portfolios import Portfolio
    from .positions import Position

    # define
    Portfolio.hold(
        Position(
            asset=Asset.Cash(),
            date=datetime.date.today(),
            quantity=1000,
        )
    )

    # test
    def test_Posting___setattr__():
        from ..ledger.entries import JournalEntry, Posting

        # define
        posting = Posting(
            journal=JournalEntry(
                date=datetime.date.today(),
                description="test"
            ),
            date=datetime.date.today(),
            account=Account.Cash(),
            direction=Direction.INC,
            amount=1000
        )

        # test
        assert posting.journal
        assert posting.journal.date
        assert posting.journal

# Generated at 2022-06-21 20:02:43.984912
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    entry = JournalEntry(datetime.date.today(), 'entry-1', None)
    posting1 = Posting(entry, datetime.date.today(), Account(None, AccountType.ASSETS, '001', 'asset'), Direction.INC, Amount(10))
    posting2 = Posting(entry, datetime.date.today(), Account(None, AccountType.ASSETS, '001', 'asset'), Direction.INC, Amount(10))
    assert hash(posting1) == hash(posting2)

# Generated at 2022-06-21 20:02:48.752881
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from datetime import date

    from .accounts import Account

    journal1 = JournalEntry("Test journal")
    journal2 = JournalEntry("Test journal 2")

    posting1 = Posting(journal1, date(2019, 1, 1), Account("Test Account"), Direction.INC, Amount(100))
    posting2 = Posting(journal2, date(2019, 1, 1), Account("Test Account"), Direction.INC, Amount(100))

    assert hash(posting1) != hash(posting2)

# Generated at 2022-06-21 20:03:01.206016
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    p = Posting(object, datetime.date(2020,1,1), Account(name="Assets:Cash", type=AccountType.ASSETS), Direction.INC, 100.0)
    pe = Posting(object, datetime.date(2020,1,1), Account(name="Expenses:Salary", type=AccountType.EXPENSES), Direction.DEC, 100.0)
    pd = Posting(object, datetime.date(2020,1,1), Account(name="Assets:Cash", type=AccountType.ASSETS), Direction.DEC, 100.0)
    pd_ = Posting(object, datetime.date(2020,1,1), Account(name="Expenses:Salary", type=AccountType.EXPENSES), Direction.INC, 100.0)

# Generated at 2022-06-21 20:03:08.950407
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    """
    Tests posting class __hash__ method.
    """
    # Equivalent
    assert Posting.__hash__(Posting(None, None, None, None, None)) == Posting.__hash__(
        Posting(None, None, None, None, None)
    )

    # Not equal
    assert Posting.__hash__(Posting(None, None, None, None, None)) != Posting.__hash__(
        Posting(None, None, None, None, Amount(1))
    )

# Generated at 2022-06-21 20:03:13.678059
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(None, None, None, None, None)
    try:
        p.foo = None
        assert False, "Should not have allowed the attribute `foo` to be set."
    except AttributeError:
        pass


# Generated at 2022-06-21 20:03:16.765667
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    jentry = JournalEntry(date=datetime.date(2018, 1, 1), description="test", source="test")
    print("jentry=", jentry)

# Generated at 2022-06-21 20:03:29.142206
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Set up data
    account1 = Account(Guid("123"), "account1", "account1", AccountType.ASSETS)
    account2 = Account(Guid("456"), "account2", "account2", AccountType.EXPENSES)
    account3 = Account(Guid("789"), "account3", "account3", AccountType.EQUITIES)
    source1 = 'source1'
    source2 = 'source2'

    journal_entry1 = JournalEntry(datetime.date(2020, 1, 1), "description", source1)
    journal_entry2 = JournalEntry(datetime.date(2020, 1, 1), "description", source1)
    journal_entry3 = journal_entry1.post(datetime.date(2020, 1, 1), account1, +100)
    journal_entry3 = journal_entry3

# Generated at 2022-06-21 20:03:39.326003
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from datetime import date
    from .accounts import Account
    from .actors import Customer, Supplier
    from .commodities import Currency

    # ----- Data Setup -----

    # Create one Customer and one Supplier
    sam = Customer(name = "Samuel Jackson")
    sam.create_accounts()
    sam.allocate_cash(Currency.USD,10000)
    vendor = Supplier(name = "Vendor")
    vendor.create_accounts()
    vendor.allocate_cash(Currency.USD,10000)

    # ----- Test Setup -----

    # Create one JournalEntry with sam as source
    je = JournalEntry(date = date(2015, 1, 1), description = "Test")

# Generated at 2022-06-21 20:03:50.920842
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert datetime.date.today().month == 3
    assert datetime.date.today().day == 19


# Generated at 2022-06-21 20:03:54.391072
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date.today(), "description", None)) == "JournalEntry(date=2020-06-25, description='description', source=None)"



# Generated at 2022-06-21 20:03:55.361735
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-21 20:04:07.311942
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(journal='journal', date='2020-05-01', account='account', direction='direction', amount='10') == Posting(journal='journal', date='2020-05-01', account='account', direction='direction', amount='10')
    assert Posting(journal='journal', date='2020-05-01', account='account', direction='direction', amount='10') != Posting(journal='journal', date='2020-05-02', account='account', direction='direction', amount='10')
    assert Posting(journal='journal', date='2020-05-01', account='account', direction='direction', amount='10') != Posting(journal='journal', date='2020-05-01', account='account', direction='direction', amount='11')

# Generated at 2022-06-21 20:04:16.464736
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry.__new__(JournalEntry)
    journal.date = datetime.date(2020, 6, 26)
    journal.description = "Description"
    journal.source = "Source"
    journal.postings = []
    journal.guid = Guid("a5d7f27b-c1f7-471a-9b9c-d8a30fbc7b32")
    account = Account()
    account.name = 'Cash'
    account.type = AccountType.ASSETS
    posting = Posting(journal, datetime.date(2020, 6, 26), account, Direction.INC, Amount(100))
    assert hash(posting) == hash(posting)

# Generated at 2022-06-21 20:04:17.379752
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass



# Generated at 2022-06-21 20:04:17.885340
# Unit test for constructor of class Posting
def test_Posting():
    Posting()

# Generated at 2022-06-21 20:04:21.452940
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class MyClass:
        def __init__(self, amount):
            self.amount = amount

    my_class = MyClass(0)
    journal_entry = JournalEntry(my_class)
    journal_entry.post(datetime.date.today(), Account(AccountType.EXPENSES, Guid(), None, None), Quantity(1))
    journal_entry.validate()

# Generated at 2022-06-21 20:04:32.981434
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    account_1 = Account('Account_1', 'This is account 1')
    account_2 = Account('Account_2', 'This is account 2')
    account_3 = Account('Account_2', 'This is account 2')
    source_1 = 'source_1'
    source_2 = 'source_2'
    source_3 = 'source_3'
    # Posting 1
    posting_1 = Posting(source_1, datetime.date.today(), account_1, Direction.INC, Amount(1))
    # Posting 2
    posting_2 = Posting(source_2, datetime.date.today(), account_2, Direction.INC, Amount(2))
    # Posting 3

# Generated at 2022-06-21 20:04:36.740674
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    a = JournalEntry(postings = [(1,1,1,1)])
    b = JournalEntry(postings = [(1,1,1,2)])
    assert a.__hash__() != b.__hash__()

# Generated at 2022-06-21 20:04:56.573842
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass


# Generated at 2022-06-21 20:05:02.616289
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    print('Test test_Posting___repr__ started')
    p = Posting[int]('j', datetime.date(2020, 1, 1), Account('a'), Direction.DEC, Amount(100))
    print('posting p:')
    print(p)
    print('Test test_Posting___repr__ ended')


# Generated at 2022-06-21 20:05:13.700967
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .ledgers import Ledger, LedgerEntry
    from .booking_transactions import BookingTransaction
    from .customers import Customer
    from .products import Product
    import datetime as dt

    customer = Customer("cust", "a@b.c")
    prod = Product("s1", "some")
    prod2 = Product("s2", "some2")
    prod3 = Product("s3", "some3")
    ledger = Ledger(Account("cash", AccountType.ASSETS), Account("revenue", AccountType.REVENUES, Account("sale", AccountType.REVENUES, Account("sales", AccountType.REVENUES))) )
    bt = BookingTransaction(ledger, "", "", "", 100)

# Generated at 2022-06-21 20:05:16.568055
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Arrange
    # Act
    j = JournalEntry[str]()
    j.guid = 1234
    j.postings = 1234
    # Assert
    pass

# Generated at 2022-06-21 20:05:17.159371
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-21 20:05:25.461234
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account, AccountType
    from .currencies import USD
    from .sources import Trade, TradeType

    # trade: Trade = Trade(TradeType.buy, 'GOOG', 1, 10)
    # assert trade.value == 10
    # trade.value = 20
    # assert trade.value == 20

    trade = Trade(TradeType.BUY, 'GOOG', 1, 10)
    assert trade.value == 10
    trade.value = 20
    assert trade.value == 20

    # a: Account = Account(AccountType.ASSETS, 'APPL')
    # b: Account = Account(AccountType.EQUITIES, 'GOOG')
    # c: Account = Account(AccountType.ASSETS, 'CASH')
    # d: Account = Account(AccountType.REVENUES, 'RE

# Generated at 2022-06-21 20:05:34.191393
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class JournalEntryMock:
        """
        Mock implementation of journal entry.
        """

        #: Description of the entry.
        description: str

        #: Date of the entry.
        date: datetime.date

    @dataclass
    class SourceMock:
        """
        Mock implementation of read function.
        """

        #: Description of the entry.
        description: str

        #: Date of the entry.
        date: datetime.date

        def __call__(self, period: DateRange) -> Iterable[JournalEntryMock]:
            pass

    ReadJournalEntriesMock = ReadJournalEntries(SourceMock)

    # Assign read_journal_entries's type to a variable
    read_journal_entries_type = ReadJournalEntries
    # Assign ReadJournalEnt

# Generated at 2022-06-21 20:05:44.120360
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Test 1
    qy = Quantity(32)
    je = JournalEntry[str](date=datetime.date.today(), description='post journal entry', source='', guid=makeguid())
    je.post(datetime.date.today(), Account(type=AccountType.REVENUES, code='R1', name='Revenue'), qy)
    assert len(je.postings) == 1
    # Test 2
    qy2 = Quantity(0)
    je2 = JournalEntry[str](date=datetime.date.today(), description='post journal entry', source='', guid=makeguid())
    je2.post(datetime.date.today(), Account(type=AccountType.REVENUES, code='R1', name='Revenue'), qy2)
    assert len(je2.postings) == 0

#

# Generated at 2022-06-21 20:05:53.564170
# Unit test for method __repr__ of class JournalEntry

# Generated at 2022-06-21 20:06:05.599363
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Test for case in which both journal entries are equal.
    guid1 = makeguid()
    guid2 = makeguid()
    journal_entry1 = JournalEntry[str]("date1", "description1", "source1", [Posting("journal1", "date1", "account1", "Direction1", "1"), Posting("journal1", "date1", "account1", "Direction1", "1")], guid1)
    journal_entry2 = JournalEntry[str]("date1", "description1", "source1", [Posting("journal1", "date1", "account1", "Direction1", "1"), Posting("journal1", "date1", "account1", "Direction1", "1")], guid2)
    assert journal_entry1 == journal_entry2

    # Test for case in which both journal

# Generated at 2022-06-21 20:06:47.244432
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass


# Generated at 2022-06-21 20:06:52.257051
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    This function tests method __setattr__ of class JournalEntry.

    This test is supposed to ensure that the default value of postings is an empty list.
    """
    je = JournalEntry(datetime.date(2000, 1, 1), "test", object)
    assert je.postings == [], je.postings

# Generated at 2022-06-21 20:06:53.725893
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # JournalEntry.__delattr__()
    pass

# Generated at 2022-06-21 20:07:02.352486
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    import pytest
    @dataclass
    class MockJournal:
        pass
    journal_entry = JournalEntry[MockJournal](datetime.date(2019, 10, 10), "Hello", MockJournal())
    posting_1 = Posting[MockJournal](journal_entry, datetime.date(2019, 10, 10), Account("a1", AccountType.ASSETS), Direction.INC, Amount(100))
    posting_2 = Posting[MockJournal](journal_entry, datetime.date(2019, 10, 10), Account("a2", AccountType.EXPENSES), Direction.DEC, Amount(100))
    posting_3 = Posting[MockJournal](journal_entry, datetime.date(2019, 10, 10), Account("a1", AccountType.ASSETS), Direction.INC, Amount(100))
    assert posting_1 == posting

# Generated at 2022-06-21 20:07:12.543914
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal_entry = JournalEntry.of({}, datetime.date(2020, 7, 1), "Test")
    p1 = Posting(journal_entry, datetime.date(2020, 7, 1), Account.of('A'), Direction.INC, Amount(100))
    assert p1.__repr__() == "Posting(journal=JournalEntry(date=datetime.date(2020, 7, 1), description='Test', guid=0), date=datetime.date(2020, 7, 1), account=Account(name='A', type=<AccountType.ASSETS: 'Assets'>, guid=0), direction=Direction.INC, amount=100.0)"

# Generated at 2022-06-21 20:07:18.221719
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType

    j = JournalEntry(datetime.date.today(), "Testing JournalEntry_post", None)
    
    assert len(j.postings) == 0

    j.post(datetime.date.today(), Account(AccountType.ASSETS, "BANK"), 100)

    assert len(j.postings) == 1
    
    assert j.postings[0].account.type == AccountType.ASSETS
    assert j.postings[0].amount == 100


# Generated at 2022-06-21 20:07:22.595307
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry: JournalEntry[str] = JournalEntry(datetime.date(2020, 7, 15), "Test entry", "Test source", [])
    assert repr(journal_entry) == "JournalEntry(date=2020-07-15, description='Test entry', source='Test source', postings=[])"

# Generated at 2022-06-21 20:07:34.196823
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .charts import ChartOfAccount

    account_chart = ChartOfAccount()
    account_chart.post_account("Liability", "Loans")
    account_chart.post_account("Liability", "Loans", "Sundry Creditors")
    account_chart.post_account("Liability", "Loans", "Sundry Creditors", "ABC Co.")
    account_chart.post_account("Liability", "Loans", "Sundry Creditors", "ABC Co.", "Loan")
    account_chart.post_account("Assets", "Bank", "Bank Of India", "Current Account")

    assert  isinstance(account_chart, ChartOfAccount)
    assert  not account_chart.is_locked

    account_chart.lock()
    assert  account_chart.is_locked

# Generated at 2022-06-21 20:07:42.397110
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    def _(p1: Posting[str], p2: Posting[str]) -> None:
        assert (p1 == p2) == (p2 == p1)
        assert (p1 == p2) == (p1.__dict__ == p2.__dict__)

    #: A non-empty journal entry of a source.
    journal = JournalEntry("source")
    journal.post(datetime.date(2020, 1, 1), Account("a", AccountType.ASSETS), 100)
    journal_postings = journal.postings

    # Group 1: Same postings.
    _(journal_postings[0], journal_postings[0])

    # Group 2: postings with different journal entries.

# Generated at 2022-06-21 20:07:51.040687
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Test __setattr__ method of JournalEntry class
    """
    class Base:
        def __init__(self, name: str):
            self.name = name

    obj = Base("Test1")
    entry = JournalEntry(datetime.date(2020, 7, 26), "Description", obj)

    assert entry.date == datetime.date(2020, 7, 26)
    assert entry.description == "Description"
    assert entry.source == obj
    assert entry.postings == []
    assert isinstance(entry.guid, Guid)

# Generated at 2022-06-21 20:09:06.770650
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:09:11.323706
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    test_Posting_object = Posting("testjournal", datetime.date(2020, 10, 10), "bankacount", Direction.INC, 500)
    entries = JournalEntry("testdate", "testdescription", "testsource", [test_Posting_object])
    assert entries.increments==[test_Posting_object]
    assert entries.debits == [test_Posting_object]


# Generated at 2022-06-21 20:09:13.117207
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Test:
        def __init__(self, period: DateRange) -> None:
            pass

    Test()

# Generated at 2022-06-21 20:09:21.610988
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Given
    je = JournalEntry[None](date = datetime.date(2017, 3, 1), description = "test")
    je.post(date = datetime.date(2017, 3, 1), account = Account.of("A/A"), quantity = 1000)
    je.post(date = datetime.date(2017, 3, 1), account = Account.of("B/A"), quantity = -1000)

    # When
    hash = je.__hash__()
    hash_same = je.__hash__()

    # Then
    assert hash == hash_same


# Generated at 2022-06-21 20:09:24.796165
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, datetime.date(2000, 1, 1), None, None, None)) == "Posting(journal=None, date=2000-01-01, account=None, direction=None, amount=None)"

# Generated at 2022-06-21 20:09:30.495998
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    account = Account(account_type=AccountType.ASSETS, account_name='test')
    journal1 = JournalEntry('test', 'test', 'test')
    journal2 = JournalEntry('test', 'test', 'test')
    posting1 = Posting(journal1, date='test', account=account, direction='test', amount='test')
    posting2 = Posting(journal2, date='test', account=account, direction='test', amount='test')
    assert posting1 == posting2


# Generated at 2022-06-21 20:09:37.588759
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # given
    import datetime
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import List, Generic

    @dataclass
    class Posting(Generic[_T]):
        journal: "JournalEntry[_T]"
        date: datetime.date
        account: Account
        direction: Direction
        amount: Amount

    @dataclass
    class JournalEntry(Generic[_T]):
        date: datetime.date
        description: str
        source: _T
        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        guid: str = field(default_factory=str, init=False)

    # when
    journalEntry = JournalEntry(1, 2, 3, 4, 5)

    # then
    assert journalEntry is not None

# Generated at 2022-06-21 20:09:42.743850
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .journal import JournalEntry, Posting
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    @dataclass(frozen=True)
    class SampleRecord:
        pass


# Generated at 2022-06-21 20:09:49.145385
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    """ Unit test for method __repr__ of class Posting """
    assert str(Posting(date=datetime.date(2019, 11, 8), account=Account(type=AccountType.BANK, name="Chase Checking Account"), direction=Direction.INC, amount=Amount(10.0))) == "Posting(date=datetime.date(2019, 11, 8), account=Account(type=AccountType.BANK, name='Chase Checking Account'), direction=Direction.INC, amount=Amount(10.0))"


# Generated at 2022-06-21 20:09:49.691092
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass