

# Generated at 2022-06-21 20:01:17.395517
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass

# Generated at 2022-06-21 20:01:26.166466
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    try:
        del JournalEntry._date
    except:
        raise AssertionError("_date not found in JournalEntry")
    try:
        del JournalEntry._description
    except:
        raise AssertionError("_description not found in JournalEntry")
    try:
        del JournalEntry._source
    except:
        raise AssertionError("_source not found in JournalEntry")
    try:
        del JournalEntry._postings
    except:
        raise AssertionError("_postings not found in JournalEntry")
    try:
        del JournalEntry._guid
    except:
        raise AssertionError("_guid not found in JournalEntry")
    try:
        del JournalEntry._increments
    except:
        raise AssertionError("_increments not found in JournalEntry")

# Generated at 2022-06-21 20:01:27.620999
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = JournalEntry
    print(dir(a))


# Generated at 2022-06-21 20:01:28.462038
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-21 20:01:40.393520
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from ..books.accounts import account
    from .accounts import Account, AccountType

    class AccountFactory(Generic[_T]):
        @staticmethod
        def balance(source: _T) -> Account:
            ...

        @staticmethod
        def revenue(source: _T) -> Account:
            ...

    AccountFactory[int].balance = lambda _: account("Assets.Cash", AccountType.ASSETS)
    AccountFactory[int].revenue = lambda _: account("Revenues.Sales", AccountType.REVENUES)

    class JournalEntryFactory(Generic[_T]):
        @staticmethod
        def of(source: _T) -> JournalEntry[_T]:
            ...

    JournalEntryFactory[int].of = lambda source: JournalEntry[int](source, "...").post(date, AccountFactory[int].balance, 10)



# Generated at 2022-06-21 20:01:51.975989
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Checks:
    - Two JournalEntry instances are equal if their member fields are equal
    - Two JournalEntry instances are equal if their postings are equal irrespective their order
    """

    acc = Account("acc", AccountType.ASSETS)

    je1 = JournalEntry.__new__(JournalEntry)
    je1.date = datetime.date(2020, 9, 1)
    je1.description = "description"
    je1.source = "source"
    je1.guid = "guid"
    je1.postings = []
    je1.postings.append(Posting(je1, datetime.date(2020, 9, 1), acc, Direction.INC, Amount(50)))

# Generated at 2022-06-21 20:02:02.480084
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from datetime import date
    from .accounts import Account, AccountType
    je1 = JournalEntry(date(2020, 7, 1), 'Payment for July', 'Payment[3]')
    je1.post(date(2020, 7, 1), Account('EXPENSES:SUBSCRIPTIONS', AccountType.EXPENSES), 500)
    je1.post(date(2020, 7, 1), Account('EQUITIES:DEBITS', AccountType.EQUITIES), -500)
    je2 = JournalEntry(date(2020, 7, 1), 'Payment for July', 'Payment[3]')
    je2.post(date(2020, 7, 1), Account('EXPENSES:SUBSCRIPTIONS', AccountType.EXPENSES), 500)

# Generated at 2022-06-21 20:02:14.475000
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    """
    GIVEN:
        A Journal Entry viz.
        je = JournalEntry(date=datetime.date(2020,4,4), description='desc1')

    WHEN:
        repr(je)

    THEN:
        The output is as expected i.e.
        'JournalEntry(date=datetime.date(2020, 4, 4), description='desc1', source=None, guid=2935cf4c-9ad9-4863-b68e-1c2b23b3d3f3, postings=[])'

    """
    je = JournalEntry(date=datetime.date(2020,4,4), description='desc1')

# Generated at 2022-06-21 20:02:19.386046
# Unit test for constructor of class Posting
def test_Posting():

    journal = JournalEntry.__new__(JournalEntry)
    date = datetime.date(2020, 5, 10)
    account = Account.__new__(Account)
    direction = Direction.INC
    amount = Amount(12.00)

    posting = Posting(journal, date, account, direction, amount)
    posting.journal
    posting.date
    posting.account
    posting.direction
    posting.amount
    posting.is_debit
    posting.is_credit


# Generated at 2022-06-21 20:02:27.828488
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class TestObj(object):
        pass

    JE1 = JournalEntry(datetime.date(2019, 1, 1), "JE1", TestObj())
    JE2 = JournalEntry(datetime.date(2019, 1, 2), "JE2", TestObj())
    JE3 = JournalEntry(datetime.date(2019, 1, 3), "JE3", TestObj())
    PERIOD = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 2))

    data_set1_source = [JE1, JE2, JE3]
    data_set2_source = iter([JE1, JE2, JE3])

    def data_set1() -> Iterable[JournalEntry[TestObj]]:
        return data

# Generated at 2022-06-21 20:02:38.063078
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry = JournalEntry(date = '2018-01-01', description='journal entry')
    posting = Posting(journal=journal_entry, date='2018-01-01', account='Account', direction='INC', amount=100)
    hash(posting)
    assert True


# Generated at 2022-06-21 20:02:48.552934
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import dataclass
    from datetime import date
    from typing import List
    from datetime import datetime
    from datetime import timedelta

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Base class to hold data definition for JournalEntry
        """
        date: date
        description: str
        source: _T 
        postings: Iterable[Posting[_T]] = field(default_factory=list, init=False)
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-21 20:02:56.871512
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry[str]("date", "description", "source")
    posting = Posting(journal, "date", "account", "direction", "amount")
    assert posting.journal == "journal"
    assert posting.date == "date"
    assert posting.account == "account"
    assert posting.direction == "direction"
    assert posting.amount == "amount"
    assert posting.is_debit == _debit_mapping["direction"]["account.type"]


# Generated at 2022-06-21 20:03:06.361121
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from datetime import date
    from .accounts import Account
    from .commons import Direction
    from .journal import Posting

    # Setup
    journal = "journal"
    date = date(2020,2,2)
    account = Account("account name","desc")
    direction = Direction.INC
    amount = 654654
    one = Posting(journal,date,account,direction,amount)
    two = Posting(journal,date,account,direction,amount)

    # Actual
    result = one == two

    # Expect
    expected = True

    # Verify
    assert(result == expected)


# Generated at 2022-06-21 20:03:19.401550
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from dataclasses import Field
    from dataclasses import fields
    from dataclasses import is_dataclass
    from dataclasses import MISSING
    class TypeMock:
        pass
    type_mock = TypeMock()
    journal_entry_mock = JournalEntry[TypeMock]
    posting_mock = Posting[TypeMock](journal=journal_entry_mock, date=date(2020, 1, 1), account=Account(), direction=Direction.INC, amount=100)
    assert None == posting_mock.__setattr__('source', None)
    assert TypeMock == posting_mock.__setattr__('source', TypeMock)

# Generated at 2022-06-21 20:03:25.291336
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    @dataclass
    class TestSource:
        pass
    a=TestSource()
    b=TestSource()
    je=JournalEntry[TestSource](date=datetime.date(2020, 1, 1), source=a, description="")
    assert je.source==a
    je.source=b
    assert je.source==b, "Chaining .post() method is broken"

# Generated at 2022-06-21 20:03:37.356928
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .currencies import Currency
    from .locations import Location
    from .contacts import Contact

    loc1 = Location("test-c-loc-1")
    loc2 = Location("test-c-loc-2")
    curr = Currency("test-c", "tC", 2)
    ct1 = Contact("test-c1", loc1, curr)
    ct2 = Contact("test-c2", loc2, curr)

    a1 = Account("1", "One", AccountType.ASSETS)
    a2 = Account("2", "Two", AccountType.REVENUES)

    je = JournalEntry[str](datetime.date.today(), "test-je", "test-s")

    je.post(datetime.date.today(), a1, 1)
   

# Generated at 2022-06-21 20:03:40.120016
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry(datetime.date(2019, 11, 4), "description", "source", []) == JournalEntry(datetime.date(2019, 11, 4), "description", "source", [])


# Generated at 2022-06-21 20:03:52.349509
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from unittest import TestCase, main
    from datetime import date
    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from typing import Iterable, Optional

    class Acc(Account):
        @property
        def type(self) -> AccountType:
            return AccountType.ASSETS


# Generated at 2022-06-21 20:03:57.387787
# Unit test for constructor of class Posting
def test_Posting():
    x = Posting(123, datetime.date(2019, 10, 4), Account(1234, 'Asset'), Direction.INC, Amount(500))
    assert x.journal == 123
    assert x.date == datetime.date(2019, 10, 4)
    assert x.account == Account(1234, 'Asset')
    assert x.direction == Direction.INC
    assert x.amount == Amount(500)
    assert x.is_debit == True
    assert x.is_credit == False


# Generated at 2022-06-21 20:04:17.421236
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Convenience function to create a test journal entry
    def create_journal_entry(date: datetime=datetime.date.today(), description: str="Test Journal Entry", source_id: int=1) -> JournalEntry:
        from .transactions import Transaction
        source = Transaction(source_id)
        entry = JournalEntry(date, description, source)
        return entry

    # Creation of JournalEntry
    je1 = create_journal_entry()

    # Call of __repr__
    assert repr(je1) == f'JournalEntry(date=datetime.date({je1.date.year}, {je1.date.month}, {je1.date.day}), ' \
        f'description="{je1.description}", ' \
        f'source=Transaction(id={je1.source.id}), ' \
       

# Generated at 2022-06-21 20:04:28.869228
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from ..accounts import Accounts
    from ..books import Book
    from ..books import Ledger
    from ..books import ReadJournalEntries
    from ..books import create_book


# Generated at 2022-06-21 20:04:32.553559
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry[str]().__eq__(JournalEntry[str]()) is True
    assert not JournalEntry[str]().__eq__(JournalEntry[int]())
    assert not JournalEntry[str]().__eq__('')

# Generated at 2022-06-21 20:04:38.076998
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry = JournalEntry('Test')
    account = Account('Test')
    date = datetime.date(2020, 4, 16)
    direction = Direction.INC
    amount = Amount(1)
    posting = Posting(journal_entry, date, account, direction, amount)

    assert(hash(posting) == hash((journal_entry, date, account, direction, amount)))

# Generated at 2022-06-21 20:04:39.285249
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries is not None

# Generated at 2022-06-21 20:04:46.049167
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Test that the attribute debt is deleted
    journal = JournalEntry(source=None, description="test", date=1)
    account = Account(type=AccountType.ASSETS)
    posting = Posting(source="source", date=1, account=account, direction=Direction.INC, amount=0)
    posting.journal = journal
    posting.direction = Direction.DEC
    assert posting.journal == journal and posting.direction == Direction.DEC
    delattr(posting, "journal")
    delattr(posting, "direction")
    assert posting.journal == journal and posting.direction == Direction.DEC

# Generated at 2022-06-21 20:04:50.888204
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    journal = JournalEntry
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    read_journal_entries(DateRange)
    assert not read_journal_entries(DateRange)
    assert read_journal_entries(DateRange) == Dict
    return

# Generated at 2022-06-21 20:04:59.750203
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry = JournalEntry[str](date=datetime.date(2020, 2, 28), description='journal entry 1', source='Source 1')
    entry.post(date=datetime.date(2020, 2, 28), account=Account(name='account 1', type=AccountType.EXPENSES), quantity=Quantity(amount=10, unit='CAD'))
    entry.post(date=datetime.date(2020, 2, 28), account=Account(name='account 2', type=AccountType.REVENUES), quantity=Quantity(amount=-10, unit='CAD'))
    entry.validate()

# Generated at 2022-06-21 20:05:09.002616
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    @dataclass(frozen=True)
    class Payment:
        amount: Amount

        def to_journal_entry(self, date: datetime.date) -> JournalEntry[Payment]:
            j = JournalEntry[Payment](date, "For Payment", self)
            j.post(date, Account("Cash"), self.amount)
            return j
    payment1 = Payment(100)
    payment1_journal1 = payment1.to_journal_entry(datetime.date(2020, 1, 7))
    payment2 = Payment(100) # payment1.amount == payment2.amount
    payment2_journal1 = payment2.to_journal_entry(datetime.date(2020, 1, 7))
    payment1_journal2 = payment1.to_journal_entry(datetime.date(2020, 1, 8)) # payment1

# Generated at 2022-06-21 20:05:19.481613
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    class Test:
        def __init__(self, date: datetime.date):
            self.date = date

    je = JournalEntry[Test]('2020-08-01', 'Test', Test('2020-08-01'))

    # Test the method cannot be used to change the value of attr description
    try:
        je.description = 'Test'
        assert False
    except AttributeError as e:
        assert 'field \'description\' cannot be set after initialization' in str(e)

    # Test the method cannot be used to change the value of attr source
    try:
        je.source = Test('2020-08-02')
        assert False
    except AttributeError as e:
        assert 'field \'source\' cannot be set after initialization' in str(e)

    # Test the method cannot be used to change the value of att

# Generated at 2022-06-21 20:05:46.863124
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal_entry_1 = JournalEntry[int](datetime.date(2020, 1, 1), 'description_1', 1)
    journal_entry_2 = JournalEntry[int](datetime.date(2020, 1, 1), 'description_2', 1)
    journal_entry_3 = JournalEntry[int](datetime.date(2020, 1, 1), 'description_1', 1)
    assert hash(journal_entry_1) != hash(journal_entry_2)
    assert hash(journal_entry_1) == hash(journal_entry_3)

# Generated at 2022-06-21 20:05:48.240676
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    a=JournalEntry(None, None, None)
    assert a.date is None

# Generated at 2022-06-21 20:05:50.263148
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry = JournalEntry(datetime.date.today(), "sending money to mum", "")
    assert journal_entry is not None


# Generated at 2022-06-21 20:05:57.473479
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account
    from datetime import date
    import pytest
    from typing import Tuple
    from dataclasses import dataclass, field

    @dataclass
    class Test:
        key: str = field(hash = True)

    @dataclass(frozen = True)
    class A:
        guid: Guid = field(default_factory = makeguid, init = False)
        def __hash__(self) -> int:
            return hash(self.guid) #uses guid as a key value

    a = A()
    b = A()

    test1 = Test("test1")
    test2 = Test("test2")


# Generated at 2022-06-21 20:06:07.125699
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal = JournalEntry(datetime.date(2019, 1, 1), "Logon purchase",
                Account(AccountType.ASSETS, "Cash"),
                Amount(float(10000)),
                Guid("4dfcc81f-4986-4cfc-a7e8-9a9b20f0a710"))
    assert journal.date == datetime.date(2019, 1, 1)
    assert journal.description == "Logon purchase"
    assert journal.account == Account(AccountType.ASSETS, "Cash")
    assert journal.amount == Amount(float(10000))
    assert journal.guid == Guid("4dfcc81f-4986-4cfc-a7e8-9a9b20f0a710")

# Generated at 2022-06-21 20:06:16.677288
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1= Posting([1,2,3],datetime.date(2012,5,5),Account(AccountType.ASSETS,"A"),Direction.DEC,Amount(500))
    p2= Posting([1,2,3],datetime.date(2012,5,5),Account(AccountType.ASSETS,"A"),Direction.DEC,Amount(500))
    p3= Posting([1,2,3],datetime.date(2012,5,5),Account(AccountType.ASSETS,"A"),Direction.INC,Amount(500))
    p4= Posting([1,2,3],datetime.date(2013,5,5),Account(AccountType.ASSETS,"A"),Direction.DEC,Amount(500))

# Generated at 2022-06-21 20:06:18.206394
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Test method __setattr__ of class Posting
    """
    pass

# Generated at 2022-06-21 20:06:29.262361
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from typing import List
    _T = TypeVar("_T")
    class ReadJournalEntries(Protocol[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    class get_journal_entries:
        def __init__(self):
            self.journal_entries_list = []
            pass

        def __call__(self, period: DateRange) -> List[JournalEntry[_T]]:
            return self.journal_entries_list

    journal_entry_test = journal_entry_test = JournalEntry(date.today(), "test", None)
    read_journal_entires_test = ReadJournalEntries()
    read_journal_entires_test_object = get_journal_entries()
    read_journal

# Generated at 2022-06-21 20:06:41.336580
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .costs import CostAccount
    from .products import Product
    from .measurements import Measurement
    from ..currencies.context import set_currency_precision, get_currency_precision
    set_currency_precision(6)
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "test", Product("name"))
    journal_entry.post(datetime.date(2020, 1, 1), Product.Accounts.CostOfGoodsSold, 1)
    journal_entry.post(datetime.date(2020, 1, 1), CostAccount("name"), 1)
    assert len(journal_entry.postings) == 2
    del journal_entry.postings[0]
    assert len(journal_entry.postings) == 1
    assert len(journal_entry.decrements) == 1


# Generated at 2022-06-21 20:06:53.532523
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class Account:
        guid: str
        name: str

    @dataclass
    class JournalEntry:
        date: str
        account: str
        quantity: int

    @dataclass
    class Transaction:
        date: str
        name: str
        entries: List[JournalEntry]

        def journal(self, read_account: ReadAccount) -> journal_entries.JournalEntry:
            accounts = {a.name: a for a in read_account()}

            j = journal_entries.JournalEntry(self.date, self.name)

            for e in self.entries:
                j.post(self.date, accounts[e.account], Price(e.quantity))

            return j

    @dataclass
    class Book:
        accounts: List[Account]
        transactions: List

# Generated at 2022-06-21 20:07:40.996640
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import mock
    from .accounts import AccountProvider

    def make_journal_entry(ilist: List[Dict]) -> JournalEntry[None]:
        j = JournalEntry(datetime.date.today(), "Test entry", None)
        j.postings = [Posting(j, d['date'], d['account'], d['direction'], d['amount']) for d in ilist]
        return j

    def test_data() -> Iterable[JournalEntry[None]]:
        provider = mock.Mock(AccountProvider)
        provider.asset = Account("Assets", "A")
        provider.equity = Account("Equity", "EQ")
        provider.expense = Account("Expenses", "EXP")
        provider.liability = Account("Liabilities", "L")

# Generated at 2022-06-21 20:07:45.902572
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__(): 
    je = JournalEntry(datetime.date(2019, 2, 1), "test", "test") 
    delattr(je, 'postings') 
    assert hasattr(je, 'post') 
    assert not hasattr(je, 'postings')

# Generated at 2022-06-21 20:07:46.600910
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    pas

# Generated at 2022-06-21 20:07:47.260628
# Unit test for constructor of class Posting
def test_Posting():
    pass

# Generated at 2022-06-21 20:07:51.510344
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert (Posting(None, datetime.date(2020, 1, 1), Account(), Direction.INC, Amount(Amount))
            == Posting(None, datetime.date(2020, 1, 1), Account(), Direction.INC, Amount(Amount)))


# Generated at 2022-06-21 20:08:00.778925
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .implementations import Ledger, JournalEntry

    # Create a ledger:
    ledger = Ledger()

    # Add an account to the ledger:
    a = ledger.add(Account(id="A", name="Account A", type=AccountType.ASSETS))

    # Create a journal entry:
    j = JournalEntry(date=datetime.date(2020, 1, 1), description="ABC")

    # But do not post anything:
    j.validate()

    # Post an amount to the account:
    j.post(date=datetime.date(2020, 1, 1), account=a, quantity=3)

    # Validate the journal entry again:
    j.validate()

# Generated at 2022-06-21 20:08:09.620878
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    P1 = Posting('journal1', datetime.date(2020, 4, 15), Account('account1'), Direction.INC, Amount(1000))
    P2 = Posting('journal2', datetime.date(2020, 4, 16), Account('account2'), Direction.DEC, Amount(2000))
    assert hash(P1) == hash(P1), "The hash of same Posting is not equal"
    assert hash(P1) != hash(P2), "The hash of different Posting is equal"


# Generated at 2022-06-21 20:08:13.725250
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry = JournalEntry(date= datetime.date(2020,1,1), description= "Test Journal entry in Journal entry")
    assert journal_entry.date== datetime.date(2020,1,1)
    assert journal_entry.description == "Test Journal entry in Journal entry"


# Generated at 2022-06-21 20:08:18.698094
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(date=datetime.date(2018, 1, 1), description="Entry-1", source=None)).startswith(
        "<JournalEntry")
# EOF

# Generated at 2022-06-21 20:08:29.159656
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass(frozen=True)
    class JournalEntryT(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date = datetime.date(2001, 10, 2)

        #: Description of the entry.
        description: str = "description"

        #: Business object as the source of the journal entry.
        source: _T = 10101

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-21 20:09:57.361763
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:10:02.837689
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je1 = JournalEntry(date=datetime.date(2014,3,1), description="test1", source=None)
    je2 = JournalEntry(date=datetime.date(2014,3,1), description="test1", source=None)
    assert je1 != je2


# Generated at 2022-06-21 20:10:10.776396
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Define a class,
    @dataclass(frozen=True)
    class TestClass:
        a: str
        b: int
    # Try the setter (should fail):
    try:
        JournalEntry[TestClass](TestClass('', 0), '').a = ''  # type: ignore
        assert False
    except AttributeError as ex:
        assert str(ex) == "'JournalEntry' object attribute 'a' is read-only"
    # Done.
    return True


# Generated at 2022-06-21 20:10:13.765144
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, None, None, None, None)) == "Posting(journal=None, date=None, account=None, direction=None, amount=None)"


# Generated at 2022-06-21 20:10:17.280604
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():

    class JournalEntryImpl:
        pass

    class PostingImpl(Posting):
        pass

    journal = JournalEntryImpl()

    posting = PostingImpl(journal, datetime.date.today(), Account("Cash"), Direction.INC, Amount(1))

    assert posting.journal is journal

# Generated at 2022-06-21 20:10:29.031312
# Unit test for constructor of class Posting
def test_Posting():
    from gecoerp.commons.numbers import Amount, Quantity
    from gecoerp.commons.others import makeguid
    from gecoerp.domain.accounts import Account
    from gecoerp.domain.journaling.journal_entry import JournalEntry, Posting, Direction
    from datetime import date
    from typing import List
    from .accounts import AccountType
    # Test valid Posting construction

    acct = Account("account", AccountType.ASSETS)
    je_guid = makeguid()

    je = JournalEntry[object](date(2020, 7, 11), "je1", None)
    je.guid = je_guid

    jp = Posting[object](je, date(2020, 7, 11), acct, Direction.INC, Amount(10))

    assert jp.journal

# Generated at 2022-06-21 20:10:37.800368
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # arrange
    tested_posting = Posting(1, datetime.date(2020, 1, 1), Account(1, "", AccountType.ASSETS, 100), Direction.DEC, Amount(100))

    # act
    result = tested_posting.__repr__()

    # assert
    assert result == "Posting(journal=1, date=datetime.date(2020, 1, 1), account=Account(1, '', <AccountType.ASSETS: 1>, 100), direction=<Direction.DEC: -1>, amount=100.00)"


# Generated at 2022-06-21 20:10:38.435056
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert 1==1

# Generated at 2022-06-21 20:10:44.833316
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """Test class Posting's __setattr__ method."""
    post = Posting(JournalEntry(datetime.date(2020, 12, 21), '', None),
                   datetime.date(2020, 12, 21), Account(), Direction.INC, Amount(10))
    test_case = {"date": datetime.date(2021, 12, 21),
                 "description": "This is a test"}
    for k, v in test_case.items():
        with pytest.raises(TypeError):
            post.__setattr__(k, v)

# Generated at 2022-06-21 20:10:57.199160
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    account_asset = Account('A', AccountType.ASSETS)
    account_revenue = Account('R', AccountType.REVENUES)
    source_1 = "Source_1"
    source_2 = "Source_2"
    date_1 = datetime.date(2018, 1, 1)
    date_2 = datetime.date(2018, 1, 2)
    description = "Description"
    jentry = JournalEntry[str](date_1, description, source_1)
    jentry.post(date_1, account_asset, Quantity(10))
    jentry.post(date_1, account_revenue, Quantity(-10))
    jentry_same_1 = JournalEntry[str](date_1, description, source_1)