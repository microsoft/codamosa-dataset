

# Generated at 2022-06-21 20:01:19.842176
# Unit test for constructor of class Posting
def test_Posting():
    # Test variables
    journal = JournalEntry[int]
    date = datetime.date
    account = Account
    direction = Direction
    amount = Amount

    # Posting instance
    posting = Posting(journal, date, account, direction, amount)
    assert posting != None


# Generated at 2022-06-21 20:01:28.494842
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import datetime, timedelta

    @dataclass(frozen=True)
    class Customer:
        name: str = "Customer"

    @dataclass(frozen=True)
    class Assets(Account):
        type = AccountType.ASSETS

    @dataclass(frozen=True)
    class Expenses(Account):
        type = AccountType.EXPENSES

    @dataclass(frozen=True)
    class Revenues(Account):
        type = AccountType.REVENUES

    def _fake_read(period: DateRange) -> Iterable[JournalEntry[Customer]]:
        c1 = Customer()
        c2 = Customer()

        now = datetime.now().date()
        start_of_fiscal_year = now - timedelta(days=180)


# Generated at 2022-06-21 20:01:35.159110
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal =None
    date =None
    account=None
    direction=None
    amount=None
    posting= Posting(journal,date,account,direction,amount)

    try:
        del posting.journal
    except AttributeError as e:
        print(f"The exception is {e}")
    else:
        assert False #Should throw exception
        

# Generated at 2022-06-21 20:01:46.334076
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(1, datetime.date(2019, 1, 1), Account(AccountType.REVENUES, "R1"), Direction.INC, Amount(25))
    p2 = Posting(1, datetime.date(2019, 1, 1), Account(AccountType.REVENUES, "R1"), Direction.INC, Amount(25))
    p3 = Posting(2, datetime.date(2019, 1, 1), Account(AccountType.REVENUES, "R1"), Direction.INC, Amount(25))
    p4 = Posting(1, datetime.date(2019, 1, 2), Account(AccountType.REVENUES, "R1"), Direction.INC, Amount(25))

# Generated at 2022-06-21 20:01:46.961537
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass

# Generated at 2022-06-21 20:01:58.342879
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Define the postings to be added to the journal entry
    date = datetime.date(2020, 7, 1)
    description = "This is a dummy description"
    source = "This is a dummy source"
    guid = "1234-1234-1234-1234"
    postings = ['test1', 'test2']

    # Define the journal entry to be created
    test_journal_entry = JournalEntry(date, description, source, postings, guid)

    # Check that the journal entry created is the same provided
    assert test_journal_entry.date == date
    assert test_journal_entry.description == description
    assert test_journal_entry.source == source
    assert test_journal_entry.postings == postings
    assert test_journal_entry.guid == guid

# Generated at 2022-06-21 20:02:10.640218
# Unit test for constructor of class Posting
def test_Posting():
    # arrange
    journal = JournalEntry[str](datetime.date(2020, 9, 22), 'one journal entry')
    date = datetime.date(2020, 9, 22)
    account = Account('1-011-01', 'Raw Materials', AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(100)
    posting = Posting(journal, date, account, direction, amount)

    # assert
    assert posting.journal == journal
    assert posting.date == date
    assert posting.account == account
    assert posting.direction == direction
    assert posting.amount == amount
    assert posting.is_debit
    assert not posting.is_credit 




# Generated at 2022-06-21 20:02:18.818069
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    dummy_account_1 = Account("dummy account 1", AccountType.ASSETS)
    dummy_account_2 = Account("dummy account 2", AccountType.LIABILITIES)
    dummy_entry = JournalEntry(datetime.date(2019, 12, 31), "dummy description", object())
    dummy_entry.post(datetime.date(2019, 12, 31), dummy_account_1, 1000)
    dummy_entry.post(datetime.date(2019, 12, 31), dummy_account_2, -1000)
    dummy_entry.validate()

# Generated at 2022-06-21 20:02:20.267212
# Unit test for constructor of class Posting
def test_Posting():
    console.log("test_Posting");
    # TODO: Implement unit test

# Generated at 2022-06-21 20:02:24.073271
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import AccountFactory

    account = AccountFactory.create("Equity", "Capital")
    entry = JournalEntry[object](None, None, None)
    entry.post(None, account, 1_000)
    entry.post(None, account, -1_000)
    print(entry)

# Generated at 2022-06-21 20:02:30.093031
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass

# Generated at 2022-06-21 20:02:30.740741
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass # TODO

# Generated at 2022-06-21 20:02:41.768089
# Unit test for constructor of class Posting
def test_Posting():
    from .books import Book
    from .currencies import Currency, USD
    from .customers import Customer
    from .products import Product
    from .quantities import UnitOfMeasure

    book = Book.build("Test Book", USD)
    customer = Customer.build("Test Customer", book)
    product = Product.build("Test Product", book, UnitOfMeasure("Test UOM"))
    product.sell(10).to(customer)

    # Unit test for constructor of class Posting
    def test_Posting():
        from .books import Book
        from .currencies import Currency, USD
        from .customers import Customer
        from .products import Product
        from .quantities import UnitOfMeasure

        book = Book.build("Test Book", USD)
        customer = Customer.build("Test Customer", book)

# Generated at 2022-06-21 20:02:43.902168
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():

    journal = JournalEntry[int](date=datetime.date.today(), description='this is a new journal entry')

# Generated at 2022-06-21 20:02:50.855145
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .db import read
    from .events import BusinessEvent

    import datetime

    print("\nUnit testing class `JournalEntry`: method `post`")

    def read_event_journal(period: DateRange) -> Iterable[JournalEntry[BusinessEvent]]:
        event_db = read()
        return event_db.read_journal(period)

    def print_journal_entries(entries: Iterable):
        for entry in entries:
            print(f"\t`{entry.date}` {entry.description}:")

# Generated at 2022-06-21 20:03:02.043895
# Unit test for constructor of class Posting
def test_Posting():
    date = datetime.date(2020,2,20)
    account = Account(AccountType.EXPENSES, "Testing")
    direction = Direction.INC
    amount = Amount(20)
    source = "Test"
    journal = JournalEntry[str](date=date, source=source, description="Not available")
    test_posting = Posting(journal=journal, date=date, account=account, direction=direction, amount=amount)
    assert isinstance(test_posting, Posting)
    assert test_posting.journal == journal
    assert test_posting.date == date
    assert test_posting.account == account
    assert test_posting.direction == direction
    assert test_posting.amount == amount


# Generated at 2022-06-21 20:03:05.558590
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    method __setattr__ of class Posting

    by calling __setattr__, you will get a frozen class
    """
    pass

# Generated at 2022-06-21 20:03:19.348339
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Unit test for method __eq__ of class JournalEntry.
    """
    journal1 = JournalEntry(datetime.date(2019, 1, 1), "description1", "source1", Guid())
    journal2 = JournalEntry(datetime.date(2019, 1, 1), "description2", "source2", Guid())
    journal3 = JournalEntry(datetime.date(2019, 1, 1), "description1", "source1", journal1.guid)
    journal4 = JournalEntry(datetime.date(2019, 2, 1), "description1", "source1", journal1.guid)
    journal5 = JournalEntry(datetime.date(2019, 2, 1), "description1", "source1", "source1")

    assert journal1 != journal2
    assert journal1 == journal3
    assert journal1 != journal4


# Generated at 2022-06-21 20:03:22.103993
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    x = Posting(None, None, None, None, None)
    assert x.__hash__() == x.__hash__()


# Generated at 2022-06-21 20:03:34.685158
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    #p = Posting(journal="j", date=datetime.date.today(), account="acc", direction=Direction.INC, amount=1)
    p = Posting(journal="j", date=datetime.date.today(), account="acc", direction=Direction.INC, amount=1)
    p.journal = "asd"
    p.date = datetime.date.today()
    p.account = "acc"
    p.direction = Direction.INC
    p.amount = 2
    print(p)

    def set_attrib_1(p):
        p.journal = "asd"
        p.date = datetime.date.today()
        p.account = "acc"
        p.direction = Direction.INC
        p.amount = 2
        print(p)

    print(p)
    set

# Generated at 2022-06-21 20:03:48.355297
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journals(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    ReadJournalEntries()(DateRange.from_str("2018-01-01", "2019-01-01"))

# Generated at 2022-06-21 20:03:50.457395
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    i : ReadJournalEntries[_T]
    i = ReadJournalEntries()
    i(DateRange())
    return

# Generated at 2022-06-21 20:04:01.298964
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from pprint import pprint
    from ..commons.others import classproperty
    
    @dataclass(frozen=True)
    class TestClass:
        def __setattr__(self, name, value):
            print('__setattr__ is called. name:', name, 'value:', value)
            return super().__setattr__(name, value)

    @dataclass(frozen=True)
    class TestChildClass(TestClass):
        child_attr: str
        child_attr2: str = 'child_attr2_value'

    t = TestChildClass(child_attr='child_attr_value')
    print(t)


if __name__ == '__main__':
    test_Posting___setattr__()

# Generated at 2022-06-21 20:04:13.023050
# Unit test for constructor of class Posting
def test_Posting():
    account = Account("Computer")
    posting1 = Posting("journal", datetime.date(2019, 12, 12), account, Direction.INC, Amount(5))
    posting2 = Posting("journal", datetime.date(2019, 12, 12), account, Direction.DEC, Amount(5))

    assert posting1.journal == "journal"
    assert posting1.date == datetime.date(2019, 12, 12)
    assert posting1.account == account
    assert posting1.direction == Direction.INC
    assert posting1.amount == Amount(5)
    assert posting2.is_credit

    account.type = AccountType.REVENUES
    assert posting1.is_credit
    assert posting2.is_debit

    account.type = AccountType.EQUITIES
    assert posting1.is_debit

# Generated at 2022-06-21 20:04:24.204407
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    a = JournalEntry(date=datetime.date(2017,11,10), source=1, description="Test")
    a.post(date=a.date, account=Account("Assets", AccountType.ASSETS), quantity=100)
    a.post(date=a.date, account=Account("Revenues", AccountType.REVENUES), quantity=-100)
    b = JournalEntry(date=datetime.date(2017,11,10), source=1, description="Test")
    b.post(date=b.date, account=Account("Assets", AccountType.ASSETS), quantity=100)
    b.post(date=b.date, account=Account("Revenues", AccountType.REVENUES), quantity=-100)
    assert hash(a) == hash(b)

# Generated at 2022-06-21 20:04:35.995917
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date

    @dataclass(frozen=True)
    class Example:
        pass

    j1 = JournalEntry[Example](date.today(), 'description', Example())
    j1.post(date.today(), Account('Cash', AccountType.ASSETS), +0)
    j1.post(date.today(), Account('Inventory Purchases', AccountType.EXPENSES), -30)
    j1.post(date.today(), Account('Inventory', AccountType.ASSETS), -100)
    j1.post(date.today(), Account('Accounts Receivable', AccountType.ASSETS), +10)
    j1.post(date.today(), Account('Accounts Receivable', AccountType.LIABILITIES), -10)
    print(j1)
    j1.validate()
    #assert False

# Generated at 2022-06-21 20:04:43.190743
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    posting1 = Posting(None, None, None, None, None)
    posting2 = Posting(None, None, None, None, None)
    journal1 = JournalEntry(None, None, None, [posting1])
    journal2 = JournalEntry(None, None, None, [posting1])
    journal3 = JournalEntry(None, None, None, [posting2])
    assert hash(journal1) == hash(journal2)
    assert hash(journal1) != hash(journal3)

# Generated at 2022-06-21 20:04:50.349985
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import AccountingEntity, Currency, Account
    from .accounts import AccountType as at
    from .journal_entries import JournalEntry, Direction
    from .journal_entries import Posting
    from .accounts import AccountingEntity, Currency, Account
    from .accounts import AccountType as at
    from .journal_entries import JournalEntry, Direction
    from .journal_entries import Posting

    accEntity = AccountingEntity.new(name="TestAccount")
    accEntity.__delattr__(name="TestAccount")
    assert accEntity.name == "TestAccount"

    accEntityCurr = AccountingEntity.new(name="TestAccount", currency=Currency.new(name="TestCurrency", code="TC"))

# Generated at 2022-06-21 20:04:53.412299
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert Posting(journal=JournalEntry(None, None, None), date=None, account=None, direction=None, amount=None).__delattr__() != None

# Generated at 2022-06-21 20:05:03.638927
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from ..commons.others import makeguid
    from .accounts import Account, AccountType

    date = datetime.date(2020, 1, 1)
    source = makeguid()
    je = JournalEntry(date, "Testing JournalEntry.validate()", source)
    je.post(date, Account("Assets:MyBank:Checking", AccountType.ASSETS), 1000)
    je.post(date, Account("Expenses:Food", AccountType.EXPENSES), -700)
    je.post(date, Account("Liabilities:CreditCard", AccountType.LIABILITIES), -300)

    je.validate()

# Generated at 2022-06-21 20:05:29.753692
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    date = datetime.date(2019, 10, 6)
    journal = JournalEntry(date, "Test", None)
    account = Account("TEST", AccountType.EQUITIES)
    amount = Amount(1000)
    p1 = Posting(journal, date, account, Direction.INC, amount)
    p2 = Posting(journal, date, account, Direction.INC, amount)
    assert p1 == p2


# Generated at 2022-06-21 20:05:35.549676
# Unit test for constructor of class Posting
def test_Posting():
    """
    To test that the Posting is working properly
    """
    from .accounts import Account, AccountType
    from .journal import JournalEntry

    p = Posting(JournalEntry, datetime.date(2020, 1, 1), "Test Account", AccountType.EQUITIES, Direction.INC, 50)
    assert p.journal.date == datetime.date(2020, 1, 1)
    assert p.journal.description == "Test Account"
    assert p.journal.postings == []
    assert p.date == datetime.date(2020, 1, 1)
    assert p.account.type == AccountType.EQUITIES
    assert "INC" in str(p.direction)
    assert p.amount == 50
    assert p.is_debit is True
    assert p.is_credit is False

# Generated at 2022-06-21 20:05:41.352192
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    read_journal_entries = ReadJournalEntries()
    class TestReadJournalEntriesImpl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    read_journal_entries = TestReadJournalEntriesImpl()

# Generated at 2022-06-21 20:05:48.550930
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal= data.journal_entries[0]
    date= data.journal_entries[0].date
    account= data.journal_entries[0].postings[0].account
    direction= data.journal_entries[0].postings[0].direction
    amount= data.journal_entries[0].postings[0].amount
    p = Posting(journal, date, account, direction, amount)
    p.journal=1
    assert p.journal==1

# Generated at 2022-06-21 20:05:56.581556
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from dataclasses import _MISSING_TYPE
    from . import account, journal

    #: Date of posting.
    date = datetime.date(2020, 1, 1)
    #: Account of the posting.
    account = account.Account('456', 'Account name for i4', AccountType.ASSETS)
    #: Direction of the posting.
    direction = Direction.DEC
    #: Posted amount (in absolute value).
    amount = Amount(1.0)

    journal_entry = journal.JournalEntry('1', 'Trading account entry', 'source')
    posting = Posting(journal_entry, date, account, direction, amount)
    assert posting.journal == journal_entry
    assert posting.date == date
    assert posting.account == account
    assert posting.direction == direction
    assert posting.amount == amount

    # Dates

# Generated at 2022-06-21 20:05:58.244764
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-21 20:06:05.477899
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():

    data = JournalEntry[str]("2019-08-14", "This is a sample journal entry", "NL3000")

    assert repr(data) == (
        "JournalEntry("
        "date=datetime.date(2019, 8, 14), "
        "description='This is a sample journal entry', "
        "source='NL3000', "
        "postings=[], "
        "guid='" + str(data.guid) + "'"
        ")"
    )

# Generated at 2022-06-21 20:06:11.692645
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journalEntry = JournalEntry()
    # print('journalEntry:', journalEntry, journalEntry.__class__)
    try:
        journalEntry.x = 6
        delattr(journalEntry, 'x')
        print('journalEntry:', journalEntry, journalEntry.__class__)
    except AttributeError as err:
        print('AttributeError:', err, err.__class__)

# Generated at 2022-06-21 20:06:15.961314
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass(frozen=True)
    class ReadJournalEntriesImpl(ReadJournalEntries[_T]):
        """
        Implementation of ReadJournalEntries.
        """

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    assert isinstance(ReadJournalEntriesImpl(), ReadJournalEntries[_T])

# Generated at 2022-06-21 20:06:27.394878
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import Account
    from .books import Book
    from .currencies import Currency

    ## Setup:
    book = Book(Currency.USD, "Cash")

    # Case 1: Attribute is not allowed
    with raises(AssertionError):
        def testCase1_01():
            jE = JournalEntry[Book]('2019-04-01', 'Description', book)
            jE.amount = 1000
        testCase1_01()

    # Case 2: Attribute is allowed
    def testCase2_01():
        jE = JournalEntry[Book]('2019-04-01', 'Description', book)
        jE.date = '2020-04-01'
    testCase2_01()


# Generated at 2022-06-21 20:07:07.710663
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntriesImpl(ReadJournalEntries[int]):
        """
        Functor for reading journal entries from a source.
        """

    # Test the constructor.
    ReadJournalEntriesImpl()

# Generated at 2022-06-21 20:07:17.216551
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():

    import datetime
    from .accounts import Account
    from .journal_entries import Direction, JournalEntry, Posting, ReadJournalEntries
    from ..commons.numbers import Amount, Quantity

    post1 = Posting(
        JournalEntry(
            date=datetime.date(2019, 2, 17),
            description="Payment from Matt Brown",
            source=ReadJournalEntries(lambda dr: None),
        ),
        datetime.date(2019, 2, 17),
        Account("Assets/xx/Cash", AccountType.ASSETS),
        Direction.INC,
        Amount(Quantity(100.0, "USD")),
    )

# Generated at 2022-06-21 20:07:23.404053
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal = JournalEntry(datetime.date.today(), 'description', 'source')
    posting = Posting(journal, datetime.date.today(), Account('account', AccountType.ASSETS), Direction.INC, Amount(0))
    del posting.journal
    del posting.date
    del posting.account
    del posting.direction
    del posting.amount
    del posting.is_debit
    del posting.is_credit

# Generated at 2022-06-21 20:07:34.658792
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from .accounts import Account
    from .journal import Posting, JournalEntry
    from ..commons import Quantity, Amount

    # arrange
    today = date.today()
    account = Account()
    journal = JournalEntry()
    posting = Posting(journal, today, account, Direction.INC, Amount(0))
    # act
    posting.direction = Direction.DEC
    posting.date = today
    posting.account = account
    posting.journal = journal
    posting.amount = Amount(0)
    try:
        # assert
        assert False, 'In Posting class definition, method __setattr__ needs to be disabled.'
    except AttributeError as error:
        assert error.args[0] == "can't set attribute"


# Generated at 2022-06-21 20:07:36.120227
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-21 20:07:46.654293
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    P1 = Posting(None, datetime.date(2018, 1, 1), Account("A1"), Direction.INC, 999)
    P2 = Posting(None, datetime.date(2018, 1, 1), Account("A1"), Direction.INC, 999)
    P3 = Posting(None, datetime.date(2018, 1, 2), Account("A1"), Direction.INC, 999)
    print(P1 == P2)  # True
    print(P1 == P3)  # False


# Generated at 2022-06-21 20:07:54.581242
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from datetime import date
    from .accounts import Account, AccountType

    post1 = Posting(None, date(2018, 9, 10), Account(AccountType.REVENUES, "Sales", "Sales"), Direction.INC, 100)
    repr_post = repr(post1)
    assert repr_post == "Posting(date=datetime.date(2018, 9, 10), account=Account(type=REVENUES, guid='', code='Sales', name='Sales'), direction=INC, amount=Amount(value=100))"

    print(post1)
    print(repr_post)



# Generated at 2022-06-21 20:07:56.208719
# Unit test for method __delattr__ of class Posting

# Generated at 2022-06-21 20:08:01.373219
# Unit test for constructor of class Posting
def test_Posting():
    date = datetime.date(2020, 1, 20)
    acc = Account(1, "testAccount", AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(100)

    posting = Posting(None, date, acc, direction, amount)

    assert posting.date == datetime.date(2020, 1, 20)
    assert posting.account == Account(1, "testAccount", AccountType.ASSETS)
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(100)

#Unit test for constructor of class JournalEntry

# Generated at 2022-06-21 20:08:02.651940
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    ReadJournalEntries(period)

# Generated at 2022-06-21 20:09:25.081077
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Arrange
    assert hasattr(Posting, "guid") == False
    assert hasattr(Posting, "journal") == False
    assert hasattr(Posting, "date") == False
    assert hasattr(Posting, "account") == False
    assert hasattr(Posting, "direction") == False
    assert hasattr(Posting, "amount") == False
    Posting.journal = "journal"
    Posting.date = datetime.date(2020, 1, 1)
    Posting.account = Account("test_account")
    Posting.direction = Direction.INC
    Posting.amount = 12
    # Act
    actual_result = Posting(journal = "journal", date = datetime.date(2020, 1, 1), account = Account("test_account"), direction = Direction.INC, amount = 12)
   

# Generated at 2022-06-21 20:09:31.084102
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    name = "GST"
    description = "GST Paid"
    date = datetime.date(year=2020, month=8, day=20)
    # Create a JournalEntry object and assign values to attributes
    journal_entry = JournalEntry()
    journal_entry.name = name
    journal_entry.description = description
    journal_entry.date = date
    # Check the attributes of the JournalEntry object is assigned successfully
    assert journal_entry.name == name
    assert journal_entry.description == description
    assert journal_entry.date == date

# Generated at 2022-06-21 20:09:33.468770
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Setup
    date = datetime.date(2000, 12, 1)
    desc = "Some description"
    source = 'Some source'
    account = Account('Some account')
    quantity = 1
    journal = JournalEntry(date, desc, source)
    journal.post(date, account, quantity)

    # Exercise
    del journal.postings

    # Verify
    assert journal.postings == []


# Generated at 2022-06-21 20:09:46.500931
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountSet
    from .accounting import Ledger
    # Get an account set
    aset = AccountSet()

    # Create the general ledger from the account set
    gl = Ledger(aset)

    # Make the asset account
    acct = aset.make_account(AccountType.ASSETS, "A", description="Asset Account")

    # Make a journal entry
    je = JournalEntry(datetime.date(2020,1,1), "To put some money")

    # Do a posting
    je.post(datetime.date(2020,1,1), acct, 10)

    # Validate the journal entry
    je.validate()

    # Post it to the ledger
    gl.post(je)

    # Validate the ledger
    gl.validate()

    return je

# Generated at 2022-06-21 20:09:53.482082
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry[object]()
    account = Account()
    posting = Posting(journal, datetime.date(2020, 1, 1), account, Direction.INC, Amount(1))
    assert posting.journal == journal
    assert posting.date == datetime.date(2020, 1, 1)
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(1)
    assert posting.is_debit is True
    assert posting.is_credit is False
    assert posting.journal == journal
    assert posting.journal == journal
    assert posting.journal == journal
    assert posting.journal == journal
    assert posting.journal == journal


# Generated at 2022-06-21 20:09:54.693845
# Unit test for constructor of class Posting
def test_Posting():
    pass


# Generated at 2022-06-21 20:10:03.567934
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account
    from dataclasses import field
    from ..commons.numbers import isclose
    from .currencies import USD
    from ..commons.others import datetoday   
    p = Posting(JournalEntry(datetoday(), "Handle Purchase", None), datetoday(), Account(1, "Food", AccountType.EXPENSES), 
    Direction.INC, Amount(100, USD))
    del p.amount
    assert isclose(p.amount, 0)
    assert p.amount == 0

# Generated at 2022-06-21 20:10:04.904885
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journal_entries(period):
        pass
    assert isinstance(read_journal_entries, ReadJournalEntries)



# Generated at 2022-06-21 20:10:05.761266
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-21 20:10:11.104083
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal = JournalEntry("20/01/2020","ABC","20/01/2020")
    assert journal.date == datetime.date("20/01/2020")
    assert journal.description == "ABC"
    assert journal.source == "20/01/2020"
    assert journal.postings is []
    assert journal.guid is  Guid("")