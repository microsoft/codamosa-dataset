

# Generated at 2022-06-21 20:01:26.057898
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Create a journal entry
    from ledger.typings import Account, JournalEntry, Posting

    date = datetime.date(2020, 1, 2)
    description = "Entry for Test"
    source = 1
    postings = [
        Posting(
            journal=None,
            date=datetime.date.today(),
            account=Account("Assets/Savings", "ASSETS", ""),
            direction=Direction.INC,
            amount=Amount(1000),
        ),
        Posting(
            journal=None,
            date=datetime.date.today(),
            account=Account("Expenses/Uncategorized", "EXPENSES", ""),
            direction=Direction.INC,
            amount=Amount(1000),
        ),
    ]

# Generated at 2022-06-21 20:01:36.780328
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account, AccountType
    je = JournalEntry[str]('2019-08-15', "Bought 1,000 shares of a company at $0.45 each", "Source",
                           [Posting(None, '2019-08-15', Account("Cash", AccountType.ASSETS), Direction.DEC, Amount(1000000))])    # 1,000,000 = 1,000 * $0.45

    result = repr(je)

    assert result == "JournalEntry(date=datetime.date(2019, 8, 15), description=\"Bought 1,000 shares of a company at $0.45 each\", source=\"Source\", guid=\"b0ed81c5-7a40-4088-b7b1-6a1fc7b8cac3\")"


# Generated at 2022-06-21 20:01:39.001099
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting(None, None, None, None, None)) == id(Posting(None, None, None, None, None))

# Generated at 2022-06-21 20:01:49.314938
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from ..commons.test_utils import make_test_guid
    date = datetime.date(year=2020, month=2, day=22)
    description = "test for JournalEntry"
    guid = make_test_guid()
    source = object()
    postings = list()
    result = JournalEntry[object](date,description,source=source,postings=postings,guid=guid)
    assert result.__hash__() == hash(tuple(date,description, source,postings,guid))
    assert result.__hash__() == result.date.__hash__()+result.description.__hash__()+result.source.__hash__()+result.postings.__hash__()+result.guid.__hash__()

# Generated at 2022-06-21 20:01:53.232942
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry[object]()
    posting: Posting[object] = Posting(journal, datetime.date.today(), Account(None), Direction.INC, Amount(200))
    print(posting)
    assert True


# Generated at 2022-06-21 20:01:55.327805
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class Dummy:
        pass

    assert ReadJournalEntries(Dummy)

# Generated at 2022-06-21 20:01:58.294726
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        je = JournalEntry[int]()
        je.a = 1
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-21 20:02:12.299739
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from .accounts import Account
    from .globals import JAN_01, JAN_02, JAN_03, JAN_04, JAN_05

    # Setup
    j1 = JournalEntry("J1", JAN_01, "J1")
    j1.post(JAN_01, Account("A1"), Amount(100))
    j1.post(JAN_01, Account("A2"), Amount(-100))

    j2 = JournalEntry("J1", JAN_01, "J1")
    j2.post(JAN_01, Account("A1"), Amount(100))
    j2.post(JAN_01, Account("A2"), Amount(-100))

    j3 = JournalEntry("J1", JAN_03, "J1")

# Generated at 2022-06-21 20:02:22.094986
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    print("test_JournalEntry___delattr__")
    try:
        delattr(JournalEntry, 'date')
        assert False
    except:
        assert True
    try:
        delattr(JournalEntry, 'description')
        assert False
    except:
        assert True
    try:
        delattr(JournalEntry, 'source')
        assert False
    except:
        assert True
    try:
        delattr(JournalEntry, 'postings')
        assert False
    except:
        assert True
    try:
        delattr(JournalEntry, 'guid')
        JournalEntry.guid=1
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-21 20:02:34.134248
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Arrange
    journal_entry1 = JournalEntry(
        date = datetime.date(2020, 1, 1),
        description = "A description",
        source = 1,
        postings = None,
        guid = Guid(1)
    )
    journal_entry2 = JournalEntry(
        date = datetime.date(2020, 1, 1),
        description = "A description",
        source = 1,
        postings = None,
        guid = Guid(1)
    )
    journal_entry3 = JournalEntry(
        date = datetime.date(2020, 1, 1),
        description = "Another description",
        source = 1,
        postings = None,
        guid = Guid(1)
    )

    # Act
    result1 = journal_entry1 == journal_entry2
    result2 = journal_entry1

# Generated at 2022-06-21 20:02:50.634858
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from ..commons.numbers import Integer
    from .accounts import AccountType
    from .accounts import Account
    def _assert_valid(je):
        try:
            je.validate()
        except AssertionError:
            raise AssertionError(f"JournalEntry is not valid: {je}")
    def _assert_invalid(je):
        try:
            je.validate()
        except AssertionError:
            pass
        else:
            raise AssertionError(f"JournalEntry is valid: {je}")
    def _make_journal_entry(is_valid):
        # Define journal entry:
        journal_entry = JournalEntry[str]("dummy journal entry")
        # Post incremets and decrements:

# Generated at 2022-06-21 20:02:59.794962
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import datetime
    from dataclasses import asdict
    from collections import OrderedDict
    JE = JournalEntry(datetime.date.today(),"test string",None,None)
    # Check if all fields of JournalEntry were set correctly using __setattr__
    print(asdict(JE))
    assert type(JE.date) == datetime.date
    assert JE.description == "test string"
    assert JE.source == None
    assert JE.postings == []
    assert isinstance(JE.guid, str)


# Generated at 2022-06-21 20:03:00.394822
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert True

# Generated at 2022-06-21 20:03:06.256295
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry(_T=int,
                      date=datetime.date.today(),
                      description="test",
                      source=1,
                      guid="test")
    assert repr(je) == "JournalEntry(date=datetime.date(2020, 11, 2), description='test', source=1, guid='test')"

# Generated at 2022-06-21 20:03:09.537087
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry[str]("2020-01-01", "test", "source", [])
    assert hash(je) == hash(je.guid)

# Generated at 2022-06-21 20:03:10.672232
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:03:18.907795
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal = JournalEntry[int](datetime.date.today(), "Cash Sale", 123)
    journal.post(datetime.date.today(), Account("Assets:Cash"), 10)
    journal.post(datetime.date.today(), Account("Revenues:Sales"), -10)

    for i in journal.postings:
        assert i.is_credit == i.is_debit
        i.is_credit == False
        del i.is_credit
        del i.is_debit


# Generated at 2022-06-21 20:03:27.184557
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    # Make a new JournalEntry
    je = JournalEntry("1970-01-01", "Test validable", "test")

    # Postings for the journal entry
    je.post("1970-01-01", Account("Testing", AccountType.EXPENSES), -50)
    je.post("1970-01-01", Account("Testing", AccountType.ASSETS), 50)

    # Validate the journal entry
    je.validate()

    # We expect no error
    assert True == True

# Generated at 2022-06-21 20:03:38.189502
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import FrozenInstanceError

    # Create an instance of class JournalEntry
    entry = JournalEntry(datetime.date(year=1, month=1, day=1), "Test Entry", None)

    # Try changing the attributes of this entry
    try:
        entry.date = datetime.date(year=2, month=1, day=1)
    except FrozenInstanceError:
        pass
    else:
        assert False, "FrozenInstanceError not raised"

    try:
        entry.description = "Changed Test Entry"
    except FrozenInstanceError:
        pass
    else:
        assert False, "FrozenInstanceError not raised"

    try:
        entry.source = "Changed Source"
    except FrozenInstanceError:
        pass
    else:
        assert False, "FrozenInstanceError not raised"

    #

# Generated at 2022-06-21 20:03:50.347208
# Unit test for method __repr__ of class JournalEntry

# Generated at 2022-06-21 20:04:11.737816
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import List
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import make_account

    assert issubclass(ReadJournalEntries, Protocol)

    @dataclass(frozen=True)
    class JournalEntry:
        date: date
        description: str
        source: int

    def read_journal_entries(period: DateRange) -> List[JournalEntry]:
        # We are using __call__ as an example.
        # Hence, we need to actually call it and retrieve something.
        return []

    # Test whether read_journal_entries is a valid implementation of ReadJournalEntries.
    assert issubclass(ReadJournalEntries, ReadJournalEntries)


# Generated at 2022-06-21 20:04:20.415862
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    _account = Account(name="A", type=AccountType.ASSETS)
    _date = datetime.date(year=2020, month=2, day=18)

    _journal1 = JournalEntry[str](date=_date, description="J1", source="JE1")
    _journal2 = JournalEntry[str](date=_date, description="J2", source="JE2")

    _posting1 = Posting(_journal1, _date, _account, Direction.INC, Amount(100))
    _posting2 = Posting(_journal1, _date, _account, Direction.INC, Amount(100))
    _posting3 = Posting(_journal1, _date, _account, Direction.DEC, Amount(100))

# Generated at 2022-06-21 20:04:21.077278
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-21 20:04:24.205328
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class _T:
        pass
    _T()
    assert(isinstance(_T, object))
    """
    :param period: Date range for selecting journal entries.
    """

# Generated at 2022-06-21 20:04:35.998853
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f1(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    # The following is a valid implementation of the type protocol.
    @dataclass
    class F2:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    # The following is a valid implementation of the type protocol.
    def f3(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    F3 = type("F3", (object,), {"__call__": f3})

    # The following fails to pass the type check:
    #
    # @dataclass
    # class F4:
    #     def func(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
    #         return

# Generated at 2022-06-21 20:04:39.444446
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal = JournalEntry(date=datetime.date(2020, 4, 17), description="dummy description", source={})
    assert repr(journal) == "<2020-04-17:dummy description>"



# Generated at 2022-06-21 20:04:48.271304
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from dateutil.parser import parse
    from .accounts import Account
    from ..commons.numbers import Amount

    # Given
    journalEntry = JournalEntry[None](date=parse("2019-01-27"), description="New year's day", source=None)
    journalEntry.postings = [
        Posting(journal=journalEntry, date=parse("2019-01-27"), account=Account(name="Payable", type=AccountType.LIABILITIES), direction=Direction.DEC, amount=Amount(1000)), 
        Posting(journal=journalEntry, date=parse("2019-01-27"), account=Account(name="Cash", type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(1000)), 
    ]
    journalEntry.guid = "this is a guid string"

    # When
    reprStr

# Generated at 2022-06-21 20:04:58.679385
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import asdict
    from ..commons.others import unnamedaccount
    from .accounts import AccountType

    class Obituary():
        """
        For testing purposes
        """

    je = JournalEntry(datetime.date(2019, 10, 28), "descrip", Obituary())
    je.post(datetime.date(2019, 10, 28), Account("AccountName", AccountType.ASSETS, ""), 1000)
    assert asdict(je.postings[0]) == asdict(
        Posting(
            je, datetime.date(2019, 10, 28), unnamedaccount("AccountName"), Direction.INC, Amount(1000)
        )
    )

# Generated at 2022-06-21 20:05:06.693850
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Tests: JournalEntry.__eq__
    Given: Two JournalEntry instances, A and B
    When: A.__eq__(B) is called
    Then: Return value is True iff A and B have the same date, SAME description, SAME source, and SAME postings
    """
    # Setup
    journalEntry_equal = JournalEntry[int](date=datetime.date(2020, 1, 30), description='Test Description A', source=0)
    assert journalEntry_equal == journalEntry_equal
    journalEntry_notEqual_date = JournalEntry[int](date=datetime.date(2020, 2, 30), description='Test Description A', source=0)
    assert not journalEntry_equal == journalEntry_notEqual_date

# Generated at 2022-06-21 20:05:08.655826
# Unit test for constructor of class Posting
def test_Posting():
    j = JournalEntry()
    assert j is not None, "Failed to instantiate instance of JournalEntry"


# Generated at 2022-06-21 20:05:28.306293
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from datetime import date
    from .accounts import Account, AccountType
    j = JournalEntry(date.today(), "Test", "S1")
    j.post(date.today(), Account("A1", AccountType.ASSETS), 20000)
    p = j.postings[0]
    del p
    p.journal
    Posting.__delattr__(p, "journal")
    p.journal


# Generated at 2022-06-21 20:05:30.901963
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting("journal", DateRange.parse("2017-01-01"), "account", "direction", Amount("amount"))) == "Posting(journal, 2017-01-01, account, direction, amount)"

# Generated at 2022-06-21 20:05:38.332925
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # assigning the object of class JournalEntry
    journal_entry = JournalEntry(datetime.date(2010, 1, 1), 'Purchased something', 'purchase')
    # checking if the values are assigned correctly
    assert journal_entry.date == datetime.date(2010, 1, 1)
    assert journal_entry.description == 'Purchased something'
    assert journal_entry.source == 'purchase'

# Generated at 2022-06-21 20:05:44.192303
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    a = Posting("a", "b", "c", "d", "e")
    assert a.journal == "a"
    assert a.date == "b"
    assert a.account == "c"
    assert a.direction == "d"
    assert a.amount == "e"


# Generated at 2022-06-21 20:05:46.710998
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert eval(repr(Posting(None, None, None, None, None))) == Posting(None, None, None, None, None)


# Generated at 2022-06-21 20:05:50.217927
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from dataclasses import _process_class  # type: ignore
    from dataclasses import fields

    _process_class(JournalEntry)  # type: ignore
    assert "postings" in fields(JournalEntry), "`postings` not picked up by dataclasses library."



# Generated at 2022-06-21 20:05:53.975095
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # given
    je = JournalEntry[None](datetime.date.today(), "test", None)
    je.post(datetime.date.today(), Account("bank"), 1000)
    je.post(datetime.date.today(), Account("cash"), -1000)
    # when / then
    je.validate()

# Generated at 2022-06-21 20:05:56.025298
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry(datetime.date.today(), "Je", None)
    print("JournalEntry", je)

# Generated at 2022-06-21 20:06:00.194393
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(AttributeError):
        posting = Posting("", "", "", "")
        posting.field1 = 123
        posting.field2 = "abc"

# Generated at 2022-06-21 20:06:08.358728
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Arguments
    journal = JournalEntry[str](datetime.date(2018, 1, 1), "desc", "source")
    date = datetime.date(2018, 1, 1)
    account = Account("revenue", AccountType.REVENUES)
    direction = Direction.DEC
    amount = Amount(100)
    posting: Posting[str] = Posting(journal, date, account, direction, amount)

    # Operation
    try:
        posting.journal = JournalEntry[str](datetime.date(2018, 1, 2), "desc_2", "source_2")
    except AttributeError:
        AssertionError("AttributeError not thrown")

    # Verification
    # AssertionError: AttributeError not thrown

# Generated at 2022-06-21 20:06:46.468186
# Unit test for constructor of class Posting
def test_Posting():
    from ..modeling.taxes import SalesTaxAmount
    from ..modeling.sales import SalesBooking
    from ..modeling.expenses import ExpenseBooking
    from ..modeling.incomes import IncomeBooking
    from ..modeling.assets import AssetBooking
    from ..modeling.liabilities import LiabilityBooking
    from ..modeling.equities import EquityBooking
    from ..modeling.products import Product
    from ..modeling.vendors import Vendor
    from ..modeling.customers import Customer

    from .accounts import Account, Ledger, create_accounts



    # Create Ledger object
    ledger = Ledger.create('Test Ledger', 'test', 'HKD')

    # Create a Sales Journal Entry

# Generated at 2022-06-21 20:06:57.588375
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import MISSING
    from unittest.mock import Mock
    test_instance = JournalEntry[object](datetime.date.today(), '', None)
    assert test_instance.date == datetime.date.today()
    assert test_instance.description == ''
    assert test_instance.source is None
    assert isinstance(test_instance.postings, list)
    assert isinstance(test_instance.guid, Guid)
    assert test_instance.guid != ''
    def is_posting(v):
        return isinstance(v, Posting[object])
    def is_guid(v):
        return isinstance(v, Guid)
    def is_str(v):
        return isinstance(v, str)

# Generated at 2022-06-21 20:07:00.108856
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # noinspection PyTypeChecker
    p = Posting(None, None, None, None, None)
    assert p.journal is None
    p.journal = 99999
    assert p.journal == 99999

# Generated at 2022-06-21 20:07:11.752014
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date
    from .accounts import Account
    from ..commons.zeitgeist import DateRange

    def test_post():
        entry = JournalEntry(date=date(2018,1,8), description="test")
        entry.post(date=date(2018,1,8), account=Account("1"), quantity=300)

    def test_increments():
        entry = JournalEntry(date=date(2018,1,8), description="test")
        entry.post(date=date(2018,1,8), account=Account("1"), quantity=300)
        assert next(entry.increments).account.id == "1"

    def test_postings():
        entry = JournalEntry(date=date(2018,1,8), description="test")

# Generated at 2022-06-21 20:07:15.526926
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    post = Posting(journal=None)
    try:
        del post.journal
    except AttributeError:
        return
    raise AssertionError('AttributeError not raised')


# Generated at 2022-06-21 20:07:26.226397
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account

    # Build accounts:
    assets = Account(code="1000", name="Assets", type=AccountType.ASSETS)
    liabilities = Account(code="2000", name="Liabilities", type=AccountType.LIABILITIES)
    owner_equity = Account(code="3000", name="Owner's Equity", type=AccountType.EQUITIES)
    revenue = Account(code="4000", name="Revenues", type=AccountType.REVENUES)
    expense = Account(code="5000", name="Expenses", type=AccountType.EXPENSES)


    j1 = JournalEntry(date=datetime.date(2020,9,1), description="Trika")


    j1.post(date=datetime.date(2020,9,1), account=assets, quantity=1000)
    j1.post

# Generated at 2022-06-21 20:07:26.624818
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass

# Generated at 2022-06-21 20:07:31.387182
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    je = JournalEntry(
        date=datetime.date(2018, 11, 18),
        description="Donation to a social cause.",
        source="By cash",
        postings=[
            Posting(journal=None, date=datetime.date(2018, 11, 18), account=Account("Liabilities", "Current", "Cash"), direction=Direction.DEC, amount=Amount(500)),
            Posting(journal=None, date=datetime.date(2018, 11, 18), account=Account("Revenues", "Donation"), direction=Direction.INC, amount=Amount(500)),
        ]
    )
    assert je.debits != None
    assert je.credits != None
    assert je.increments != None
    assert je.decrements != None
    assert je.date != None
    assert je.description != None
   

# Generated at 2022-06-21 20:07:39.608676
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    a = JournalEntry(datetime.date(2019, 1, 1), "hello", "source")
    b = Posting(a, datetime.date(2019, 1, 1), "Account", Direction.INC, Amount(100))
    assert str(b) == "Posting(journal=JournalEntry(date=datetime.date(2019, 1, 1), description='hello', source='source'), date=datetime.date(2019, 1, 1), account='Account', direction=<Direction.INC: 1>, amount=Amount(100, 0))"

# Generated at 2022-06-21 20:07:47.092510
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Arrange
    journal_entry = JournalEntry(description="Journal Entry", date = datetime.date.today())
    account = Account(name="Account", type=AccountType.EQUITIES)
    journal_entry.post(datetime.date.today(), account, 100)

    assert journal_entry.amount == 100
    assert journal_entry.postings[0].direction == Direction.INC

# Generated at 2022-06-21 20:09:02.620312
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[None](
        datetime.date.today(),
        'Test journal entry',
        None,
    )

    je.post(datetime.date.today(), Account("111"), 1_000_000)
    je.post(datetime.date.today(), Account("112"), 1_000_000)

    je.validate()
    assert True


# Generated at 2022-06-21 20:09:11.945492
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    obj1 = JournalEntry[str](date=datetime.date(2019, 1, 1),
                             description='desc1',
                             source='src1',
                             postings=[
                                 Posting(journal=obj1, date=datetime.date(2019, 1, 1),
                                         account=Account('account1', AccountType.ASSETS),
                                         direction=Direction.INC, amount=Amount(1))
                             ])

# Generated at 2022-06-21 20:09:22.026588
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p = Posting(JournalEntry(date = datetime.date(2020, 1, 11), description = "desc", source = "source"),
        datetime.date(2020, 1, 11), Account(id = 5, type = AccountType.ASSETS, description = "assets"),
        Direction.INC, Amount(10))
    p2 = Posting(JournalEntry(date = datetime.date(2020, 1, 11), description = "desc", source = "source"),
        datetime.date(2020, 1, 11), Account(id = 5, type = AccountType.ASSETS, description = "assets"),
        Direction.INC, Amount(10))
    assert hash(p) == hash(p2)


# Generated at 2022-06-21 20:09:31.045270
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(date = datetime.date(1000, 11, 12), description = "bar", source = "foo") == JournalEntry(date = datetime.date(1000, 11, 12), description = "bar", source = "foo")
    assert JournalEntry(date = datetime.date(1000, 11, 12), description = "bar", source = "foo") != JournalEntry(date = datetime.date(1000, 11, 13), description = "bar", source = "foo")
    assert JournalEntry(date = datetime.date(1000, 11, 12), description = "bar", source = "foo") != JournalEntry(date = datetime.date(1000, 11, 12), description = "bar", source = "foo", guid = "x")

# Generated at 2022-06-21 20:09:35.719704
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..core.entities.accounts import Account, AccountType
    from ..core.entities.journal import JournalEntry
    # Create an account
    account = Account('Cash', AccountType.ASSETS)
    # Create a journal entry
    journal_entry = JournalEntry(date(2020, 2, 4))
    journal_entry.post(date(2020, 2, 4), account, 500)
    journal_entry.validate()

# Generated at 2022-06-21 20:09:48.058279
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    posting1 = Posting(
        journal = JournalEntry(
            date = datetime.date(2019, 5, 14),
            description = '',
            source = None
        ),
        date = datetime.date(2019, 5, 14),
        account = Account(
            type = AccountType.EXPENSES,
            name = 'Utilities',
            parent = None
        ),
        direction = Direction.DEC,
        amount = Amount(10)
    )

# Generated at 2022-06-21 20:09:49.766075
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(date=None, description=None, source=None))


# Generated at 2022-06-21 20:09:54.208701
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    post = Posting(datetime.datetime.now(), "Incasso", "HD14X8YT", "Lorem Ipsum", "Dolore Amet")
    assert repr(post) == "Posting(journal=%r, date=%r, account=%r, direction=%r, amount=%r)" % (
        post.journal,
        post.date,
        post.account,
        post.direction,
        post.amount,
    )

# Generated at 2022-06-21 20:09:56.161754
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:10:09.213980
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.others import makeguid

    class T:
        journal = JournalEntry(datetime.date(2019, 3, 7), "Test Description", 0)
        date = datetime.date(2019, 3, 7)
        account = Account("Test Account", AccountType.ASSETS)
        direction = Direction.DEC
        amount = Amount(0)
        guid = makeguid()

    assert T.journal == JournalEntry(datetime.date(2019, 3, 7), "Test Description", 0)
    assert T.date == datetime.date(2019, 3, 7)
    assert T.account == Account("Test Account", AccountType.ASSETS)
    assert T.direction == Direction.DEC
    assert T.amount == Amount(0)
    assert T.guid == makeguid()
