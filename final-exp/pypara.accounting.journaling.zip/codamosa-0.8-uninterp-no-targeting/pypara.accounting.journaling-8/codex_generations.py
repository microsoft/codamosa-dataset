

# Generated at 2022-06-21 20:01:23.374145
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Unit test for method __setattr__ of class JournalEntry
    """
    from datetime import date
    from .accounts import Account
    from .accounts import AccountType
    from .bookkeeping import JournalEntry
    from .bookkeeping import Posting

    date0 = date(2019, 1, 1)
    date1 = date(2019, 1, 2)
    date2 = date(2019, 1, 3)

    account0 = Account(AccountType.ASSETS, 0, 'Name')
    account1 = Account(AccountType.EQUITIES, 1, 'Name')
    account2 = Account(AccountType.LIABILITIES, 2, 'Name')
    account3 = Account(AccountType.REVENUES, 3, 'Name')
    account4 = Account(AccountType.EXPENSES, 4, 'Name')


# Generated at 2022-06-21 20:01:27.594870
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(datetime.date.today(), "", object())) > 0
    assert hash(JournalEntry(datetime.date.today(), "", object())) > 0

# Generated at 2022-06-21 20:01:36.164078
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Try to delete "guid" attribute
    # Should not raise AttributeError
    Posting('', datetime.date(2020, 11, 6), Account(1, '', 0), Direction.INC, Amount(0)).__delattr__('guid')

    # Try to delete non-existent attribute
    # Should raise AttributeError
    try:
        Posting('', datetime.date(2020, 11, 6), Account(1, '', 0), Direction.INC, Amount(0)).__delattr__('a')
    except AttributeError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-21 20:01:40.610157
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Setup
    p1 = Posting(None, None, None, None, None)
    p2 = Posting(None, None, None, None, None)
    # Exercise
    actual = p1 == p2
    # Verify
    assert actual
    # Cleanup - none necessary



# Generated at 2022-06-21 20:01:52.236347
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from .currencies import Currency, CurrencyConversion
    from .portfolios import Portfolio
    from .securities import Commodity
    from .transactions import BUY, SELL
    from .transactions import CostBasis, Transaction

    price = Amount(10)
    quantity = Quantity(1)
    currency = Currency("USD")

    xom = Commodity("XOM", "XOM")
    acme = Portfolio("ACME", currency)

# Generated at 2022-06-21 20:01:56.698677
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # By default, the __repr__ of a journal entry is its description.
    assert (JournalEntry(date=None, description='Citizen Kane', source=None)
            .__repr__() == 'Citizen Kane')



# Generated at 2022-06-21 20:01:59.274168
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f() -> Iterable[JournalEntry[_T]]:
        return ()
    assert callable(f)
    assert isinstance(f, ReadJournalEntries)

# Generated at 2022-06-21 20:02:12.462604
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest
    import unittest.mock

    import datetime as dt
    import testfixtures.datetime as _datetime

    class Mock(ReadJournalEntries[None]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return [
                JournalEntry(date=dt.date(2019, 1, 1), source=None, description="Journal Entry 1"),
                JournalEntry(date=dt.date(2019, 1, 2), source=None, description="Journal Entry 2"),
                JournalEntry(date=dt.date(2019, 1, 3), source=None, description="Journal Entry 3"),
            ]

    def test_with_mock(mock: ReadJournalEntries[None]) -> None:
        assert unittest.mock.call(mock)



# Generated at 2022-06-21 20:02:20.701057
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import AccountType
    from .commons.others import Guid
    from .posting.events import PostingCreatedEvent
    from .posting.posting_application_service import PostingApplicationService
    asset_account = Account(Guid(), "Asset", AccountType.ASSETS)
    source = 'name'
    event = PostingCreatedEvent(description='desc', amount=200, account=asset_account, source=source)
    posting1 = PostingApplicationService().Create(event)
    posting2 = PostingApplicationService().Create(event)
    assert posting1 == posting2

# Generated at 2022-06-21 20:02:21.605442
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert True


# Generated at 2022-06-21 20:02:39.784134
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():

    from datetime import date

    from budget.domain.accounts import Account, AccountType

    j = JournalEntry(date(2019, 10, 15), 'this is a test', object())
    j.post(date(2019,10, 14), Account('this is account A', AccountType.REVENUES), 50)
    j.post(date(2019,10, 14), Account('this is account B', AccountType.REVENUES), 40)


# Generated at 2022-06-21 20:02:42.534648
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    tests the method validate of class JournalEntry
    """
    # preparations:
    test_JournalEntry_post()
    assert total_debit == total_credit
    
    
    
    

# Generated at 2022-06-21 20:02:43.081080
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-21 20:02:45.500502
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j = JournalEntry(date=datetime.date(2020,1,1),description="description",source=None)
    print(repr(j))
    return None

# Generated at 2022-06-21 20:02:46.452659
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert True

# Generated at 2022-06-21 20:02:56.120413
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    def run(date: datetime.date, description: str) -> None:
        journal = JournalEntry(date, description)

        expected = f"JournalEntry(date={journal.date},description='{description}')"
        actual = repr(journal)

        assert expected == actual
    run(date=datetime.date.today(), description="Test1")
    run(date=datetime.date(2019, 1, 1), description="ABC")
    run(date=datetime.date(2019, 12, 31), description="")
    run(date=datetime.date.today(), description="")

# Generated at 2022-06-21 20:03:01.153731
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Any
    from io import StringIO
    import sys

    @dataclass
    class PrintLines:
        out: StringIO = StringIO()

        def __call__(self, *values, sep=" ") -> None:
            print(*values, sep=sep, file=self.out)

        def __str__(self) -> str:
            return self.out.getvalue()

    plines = PrintLines()
    saved_stdout = sys.stdout
    sys.stdout = plines

    class Class(_T=Any, x=ReadJournalEntries[_T]):
        @x
        def method(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            for i in range(4):
                print("Hello World")

# Generated at 2022-06-21 20:03:09.490595
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    src = JournalEntry("2019-08-12", "desc", "src")
    p = Posting(src, "2019-08-12", "acct", "INC", "100")
    assert p.journal == src
    assert p.date == "2019-08-12"
    assert p.account == "acct"
    assert p.direction == "INC"
    assert p.amount == "100"
    try:
        p.source = "new_src"
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 20:03:21.055926
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define a stub class:
    class MyStubClass:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return []
    # Define a stub function:
    def mystubfunc(period: DateRange) -> Iterable[JournalEntry[None]]:
        return []
    # Define a protocol instance:
    myprot = ReadJournalEntries[None]
    # Define a stub class instance:
    mystubclass = MyStubClass()
    # Define a stub function instance:
    mystubfunc = mystubfunc
    # The following must all pass:
    myprot.__call__(None)
    mystubclass(None)
    mystubfunc(None)

# Generated at 2022-06-21 20:03:23.564273
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    v_posting = Posting("journal", datetime.date(2020, 12, 20), "account", "Direction", "Amount")

    assert v_posting.__repr__() == """Posting(journal="journal", date=datetime.date(2020, 12, 20), account="account", direction="Direction", amount="Amount")"""


# Generated at 2022-06-21 20:03:34.448501
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-21 20:03:44.918084
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():

	from ..accounting.accounts import Account, AccountType
	from ..accounting.journals import JournalEntry, Posting
	from datetime import date
	from commons import Guid

	journal_entry = JournalEntry(date=date(2020, 1, 2))
	journal_entry.post(date=date(2020, 1, 2), account=Account(data=Guid(), name="Revenue 1", type=AccountType.REVENUES), quantity=100)
	
	posting = Posting(journal=journal_entry, date=date(2020, 1, 2), account=Account(data=Guid(), name="Revenue 1", type=AccountType.REVENUES), direction=Direction.INC, amount=100)
	
	assert posting == posting
	assert posting != "posting"

# Generated at 2022-06-21 20:03:45.904588
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-21 20:03:54.250131
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Tests the __setattr__ method of class Posting
    """

    from .accounts import Account, AccountType

    assert Posting.__setattr__(None, "date", datetime.date(2018, 1, 1)) == None # no error
    assert Posting.__setattr__(None, "postings", [Posting(None, datetime.date(2018, 1, 1), Account("Assets/Bank", AccountType.ASSETS), Direction.INC, Amount(1000))]) == None # no error
    assert Posting.__setattr__(None, "guid", 12345) == None # no error


# Generated at 2022-06-21 20:04:04.390185
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    """
    Test method __eq__ of the class Posting
    :return:
    """
    from ..core.accounts import ChartOfAccounts

    chart = ChartOfAccounts()
    an_account = chart("Assets").add("Cash")
    a_posting1 = Posting(None, 5, an_account, Direction.INC, Amount(100))
    a_posting2 = Posting(None, 5, an_account, Direction.INC, Amount(100))
    a_posting3 = Posting(None, 5, an_account, Direction.INC, Amount(50))
    assert not a_posting1 == a_posting3
    assert a_posting1 == a_posting2


# Generated at 2022-06-21 20:04:15.897231
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from time import time
    from dataclasses import dataclass
    from unittest import TestCase

    from .accounts import Account

    @dataclass
    class Order:
        def __init__(self, name: str, id: int):
            self.name = name
            self.id = id

    @dataclass
    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[Order]]:
            pass


# Generated at 2022-06-21 20:04:26.896032
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account
    from .orders import Order
    from .products import Product
    from ..commons import Quantity
    from .sales import Sale
    product = Product("my_product", Quantity(10.0), Quantity(1.0))
    order = Order.create(product, Quantity(10.0))
    sale = Sale.create(order)
    account = Account("my_account", AccountType.REVENUES, "my_account_id")
    i = JournalEntry(datetime.date(2020, 9, 10), description="description", source=sale)
    i.post(datetime.date(2020, 9, 10), account, Quantity(10.00))
    del i.postings[0].journal
    del i.postings[0].date

# Generated at 2022-06-21 20:04:27.700206
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-21 20:04:39.444686
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import account
    from ..books.accounts import AccountType
    from ..books.ledgers import ledger
    from datetime import date

    a1 = account('a1', AccountType.ASSETS)
    a2 = account('a2', AccountType.EQUITIES)
    accounts = ledger().accounts({a1, a2})

    j1 = JournalEntry(date(2020, 1, 1), 'j1', None)
    j1.post(date(2020, 1, 1), accounts.map('a1'), 100)
    j1.post(date(2020, 1, 1), accounts.map('a2'), -100)
    j1.validate()

    j2 = JournalEntry(date(2020, 1, 1), 'j2', None)

# Generated at 2022-06-21 20:04:44.004080
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    def _test(expected: int, journal_entry: JournalEntry):
        assert hash(journal_entry) == expected
    _test(
        0,
        JournalEntry(
            datetime.date(2020, 8, 14),
            "Description of the journal entry.",
            "The source of the journal entry."
        )
    )

# Generated at 2022-06-21 20:04:59.901060
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry4() == JournalEntry4()
    assert JournalEntry4() != JournalEntry4(date=datetime.date(2017, 12, 1))
    assert JournalEntry4() != JournalEntry4(description="Hello, World!")
    assert JournalEntry4() != JournalEntry4(source=1)


# Generated at 2022-06-21 20:05:09.109356
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry[int](datetime.date(2020, 10, 10), "Test", 1)
    je2 = JournalEntry[int](datetime.date(2020, 10, 10), "Test", 1)
    je3 = JournalEntry[int](datetime.date(2020, 10, 10), "", 1)
    je4 = JournalEntry[int](datetime.date(2020, 10, 10), "Test", 2)
    je5 = JournalEntry[int](datetime.date(2020, 10, 10), "Test", 1)
    je5.postings = [Posting(je5, datetime.date(2020, 10, 10), Account(AccountType.ASSETS, ""), Direction.INC, Amount(1000))]
    je6 = JournalEntry[int](datetime.date(2020, 10, 10), "Test", 1)

# Generated at 2022-06-21 20:05:12.350678
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class A(ReadJournalEntries[None]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return []
    success = True
    try:
        A()  # type: ignore
    except AttributeError:
        success = False
    assert success, "type check failed"

# Generated at 2022-06-21 20:05:16.017316
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Given
    journal = JournalEntry(datetime.date(2020, 1, 1), "My first transaction", Guid())
    journal = journal.post(datetime.date(2020, 1, 1), Account(Guid(), AccountType.EXPENSES, "My expense account"), -10)
    journal = journal.post(datetime.date(2020, 1, 1), Account(Guid(), AccountType.REVENUES, "My revenue account"), 10)
    # When
    hashCode = hash(journal)
    # Then
    assert hashCode == -8192228859301066574

# Generated at 2022-06-21 20:05:18.098267
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """Test __call__ of ReadJournalEntries class."""

    assert isinstance(ReadJournalEntries.__call__, property)

# Generated at 2022-06-21 20:05:27.432808
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    result = Posting(JournalEntry(datetime.date(2019, 9, 27), "Payment", "Petty Cash"), datetime.date(2019, 9, 27), "Petty Cash", Direction.DEC, 2612)
    assert result.__repr__() == "Posting(journal=JournalEntry(date=datetime.date(2019, 9, 27), description='Payment', source='Petty Cash'), date=datetime.date(2019, 9, 27), account='Petty Cash', direction=<Direction.DEC: -1>, amount=2612)"


test_Posting___repr__()


# Generated at 2022-06-21 20:05:34.352078
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry[None](
        date = datetime.date(2020, 1, 2),
        description = "Journal of a posting",
        source = None,
    )
    posting = Posting[None](
        journal = journal,
        date = datetime.date(2020, 1, 2),
        account = Account(Guid(), "My account", AccountType.ASSETS),
        direction = Direction.INC,
        amount = 100)

# Generated at 2022-06-21 20:05:43.318642
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import AccountType
    from .ledger import Ledger, read_journal_entries

    ledger = Ledger()

    def read_je(period: DateRange):
        return read_journal_entries(ledger, period)

    rje = ReadJournalEntries
    rje1 = rje[AccountType]
    rje2 = rje.__getitem__(AccountType)
    rje3 = rje.__getitem__(AccountType)
    assert read_je(ReadJournalEntries) == ReadJournalEntries
    assert rje1 == rje2
    assert rje2 == rje3
    assert rje1 is not rje2
    assert rje2 is not rje3

# Generated at 2022-06-21 20:05:46.515907
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, datetime.date(2020, 1, 2), Account("Assets"), Direction.INC, Amount(10.0))) == "Posting(journal=None, date=datetime.date(2020, 1, 2), account=Account(name='Assets', type=<AccountType.ASSETS: 1>), direction=<Direction.INC: 1>, amount=Amount(value=10.0))"


# Generated at 2022-06-21 20:05:47.553299
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    asser


# Generated at 2022-06-21 20:06:18.816637
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    import datetime
    from ledgersim.gui.commons.numbers import Amount, Quantity
    from ledgersim.model.accounts import Account, AccountType
    from ledgersim.model.journal import Direction, JournalEntry, Posting

    # Arrange
    journal = JournalEntry(date=datetime.date(2020, 4, 1), description="Test", source=None)

    # Act
    posting = Posting(journal, datetime.date(2020, 4, 1), Account("test", AccountType.ASSETS), Direction.INC, Amount(Quantity(3)))

    # Assert
    assert posting.journal == journal, f"Journal is: {posting.journal}"

    # Assert
    assert posting.date == datetime.date(2020, 4, 1), f"Date is: {posting.date}"

    # Assert
   

# Generated at 2022-06-21 20:06:29.751921
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    @dataclass(frozen=True)
    class EntrySource:
        pass
    source = EntrySource()
    journal = JournalEntry(date=datetime.date(2020,1,1), description="Test journal", source=source)
    journal.post(date=datetime.date(2020,1,1), account=Account("I1", AccountType.INCOMES), quantity=100)
    journal.post(date=datetime.date(2020,1,1), account=Account("A1", AccountType.ASSETS), quantity=-100)
    assert len(journal.postings) == 2
    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020,1,1)
    assert journal.postings[0].account

# Generated at 2022-06-21 20:06:41.697169
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # using the example posted earlier by @Grawp
    # https://stackoverflow.com/questions/62014034/implementing-double-entry-bookkeeping-using-dataclasses

    from .accounts import AccountFactory
    from .currencies import Currency


# Generated at 2022-06-21 20:06:49.013698
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(date=datetime.date(2020,1,1),description="Test",source="Test") == JournalEntry(
        date=datetime.date(2020, 1, 1), description="Test", source="Test")
    assert JournalEntry(date=datetime.date(2020,1,1),description="Test",source="Test") != JournalEntry(
        date=datetime.date(2020, 1, 2), description="Test", source="Test")

# Generated at 2022-06-21 20:06:54.594564
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    journal = JournalEntry(datetime.date(2014,1,1), "TestEntry", None)
    try:
        journal.postings.append(Posting(journal, datetime.date(2014,1,1), Account("TestAccount"), Direction.INC, Amount(100)))
    except:
        return False
    assert False, "Expected AttributeError"
    return True

# Generated at 2022-06-21 20:06:58.610872
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    import copy
    posting =  Posting(0,0,0,0,0)
    postingcopy = posting
    delattr(postingcopy,"journal")
    try:
        assert posting.journal == postingcopy.journal
    except:
        print("Error in test_Posting___delattr__")


# Generated at 2022-06-21 20:07:10.352698
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry_1 = JournalEntry(date=datetime.date(2020,1,1), description='journal_entry_1', source="Source")
    journal_entry_2 = JournalEntry(date=datetime.date(2020,1,1), description='journal_entry_2', source="Source")
    posting_1 = Posting(journal=journal_entry_1, date=datetime.date(2020,1,1), account=Account(code="1001", name="Cash", type=AccountType.ASSETS), direction=Direction.INC, amount=100)
    posting_2 = Posting(journal=journal_entry_1, date=datetime.date(2020,1,1), account=Account(code="1001", name="Cash", type=AccountType.ASSETS), direction=Direction.INC, amount=200)

# Generated at 2022-06-21 20:07:15.152982
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j = JournalEntry(datetime.date(2019, 1, 1), "test", None)
    j.post(j.date, Account.REVENUES, Quantity(10))
    j.post(j.date, Account.ASSETS, Quantity(-10))
    j.validate()
    assert hash(j) is not None
    assert hash(j) == hash(j)

# Generated at 2022-06-21 20:07:25.872911
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    #Setup
    journal1 = JournalEntry[str](datetime.date(2020, 5, 13), "test1", "Payment")
    journal1.post(datetime.date(2020, 5, 13), Account("629.01", AccountType.BANK_ACCOUNTS), 50000)
    journal1.post(datetime.date(2020, 5, 13), Account("801.01", AccountType.PAYMENTS_RECEIVED), -50000)
    journal2 = JournalEntry[str](datetime.date(2020, 5, 13), "test2", "Payment")
    journal2.post(datetime.date(2020, 5, 13), Account("629.01", AccountType.BANK_ACCOUNTS), 50000)

# Generated at 2022-06-21 20:07:31.729383
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import InvestmentAccount
    from .instruments import Bond
    from .markets import Market, Order

    bond = Bond("BAB", "BAB 10Y")
    market = Market("BAB", "BAB Market")
    market.register(bond)

    account = InvestmentAccount("BAB")
    account.add_asset(market.id, bond.id, 1000)

    order = Order(market, bond, 1000, 100.0)
    order.fill(1)

    entry = JournalEntry[Order]()
    entry.date = datetime.date(2019, 9, 1)
    entry.description = "Test"
    entry.source = order
    entry.post(datetime.date(2019, 9, 1), account.get_asset_account(market.id, bond.id), -1000)
   

# Generated at 2022-06-21 20:08:41.998949
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:08:49.799577
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Tests for the JournalEntry class.
    """
    j = JournalEntry[int](date=datetime.date.today(), description="Testing JournalEntry", source=1)
    with pytest.raises(Exception) as excinfo:
        j.postings = 23
    print(excinfo.type)
    print(excinfo.value)
    print(excinfo.traceback)
    j.post(date=datetime.date.today(), account=Account(name="Bal", type=AccountType.ASSETS), quantity=100)
    print(j.postings)


# Generated at 2022-06-21 20:09:00.039796
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry(datetime.date(2020, 8, 5), "Purchase of A", "Source",
                           [Posting(journal, datetime.date(2020, 8, 5), Account(AccountType.ASSETS, "Cash"),
                                    Direction.INC, Amount(100))])
    expected_posting = Posting(journal, datetime.date(2020, 8, 5), Account(AccountType.ASSETS, "Cash"), Direction.INC,
                               Amount(100))
    assert Posting(journal, datetime.date(2020, 8, 5), Account(AccountType.ASSETS, "Cash"), Direction.INC,
                   Amount(100)) == expected_posting

# Generated at 2022-06-21 20:09:04.785110
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, datetime.date(2020, 8, 2), Account("cash", AccountType.ASSETS, None), Direction.INC, Amount(10)) # noqa
    b = Posting(None, datetime.date(2020, 8, 2), Account("cash", AccountType.ASSETS, None), Direction.INC, Amount(10)) # noqa
    assert a.__eq__(b) == True


# Generated at 2022-06-21 20:09:08.289697
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from dataclasses import _MISSING_TYPE  # type: ignore

    with pytest.raises(AttributeError):
        Posting(_MISSING_TYPE, datetime.date.today(), None, None, None).guid = "hello"



# Generated at 2022-06-21 20:09:14.688180
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import AccountType, Account
    from .accounts import AccountName
    from .currency import Currency, CurrencyType

    # Data used in the unit test
    date = datetime.date(2020, 1, 1)
    description = "Test"
    source = "Source"
    postings = [
        Posting(JournalEntry, date, Account(AccountType.ASSETS, AccountName.CASH), Direction.INC, Amount(1)),
        Posting(JournalEntry, date, Account(AccountType.LIABILITIES, AccountName.DEBT), Direction.DEC, Amount(1))
    ]
    guid = "123-abc"

    # Create instances of the class JournalEntry
    test_JournalEntry = JournalEntry(date, description, source, postings)

    # Test the constructor of the class JournalEntry
    assert test_JournalEntry.date == date

# Generated at 2022-06-21 20:09:24.084535
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from ..accounts import Portfolio, AccountType, Account
    from ..portfolio.events import Transaction, TransactionDirection
    from ..portfolio.events import TransactionType

    cash_account = Account(AccountType.ASSETS, 'Current account')
    credit_account = Account(AccountType.LIABILITIES, 'Credit account')

    portfolio = Portfolio('Test portfolio')
    portfolio.add_transaction(Transaction(datetime.date.today(), portfolio.guid, credit_account, TransactionDirection.RECEIVE, TransactionType.CURRENCY,
                                          1000, 0, 0, 1000))

    journal_entry = JournalEntry(datetime.date.today(),
                                 "test desc",
                                 portfolio)
    journal_entry.post(datetime.date.today(), cash_account, 1000)

# Generated at 2022-06-21 20:09:33.307011
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import RootAccount

    test = RootAccount()

    from .testtools import MockJournalEntryGenerator
    entries = MockJournalEntryGenerator(test).generate(datetime.date(2020, 1, 1), datetime.date(2020, 12, 12))

    read_entries: ReadJournalEntries[_T] = lambda period: entries

    dates_1 = DateRange(min_date=datetime.date(2020, 1, 1), max_date=datetime.date(2020, 12, 31))
    dates_2 = DateRange(min_date=datetime.date(2021, 1, 1), max_date=datetime.date(2021, 12, 31))

# Generated at 2022-06-21 20:09:46.501099
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    print(JournalEntry[int](datetime.date(2020,1,1),"test",0,[]))
    print(JournalEntry[int](datetime.date(2020,1,1),"test",0,[]))
    assert JournalEntry[int](datetime.date(2020,1,1),"test",0,[])==JournalEntry[int](datetime.date(2020,1,1),"test",0,[])
    assert JournalEntry[int](datetime.date(2020,1,1),"test",0,[])!=JournalEntry[int](datetime.date(2020,1,2),"test",0,[])
    assert JournalEntry[int](datetime.date(2020,1,1),"test",0,[])!=JournalEntry[int](datetime.date(2020,1,1),"test2",0,[])

# Generated at 2022-06-21 20:09:49.561466
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry_1 = JournalEntry(datetime.date.today(), 'Description', 'Source')
    assert repr(journal_entry_1) == '<JournalEntry(date=2020-06-30, description=Description, postings=[])>'
